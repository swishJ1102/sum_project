package jp.co.unisys.enability.cis.web.common.controller;

import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.ThreadContext;
import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.AbstractInterceptor;

import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.web.gk.model.UserValueObject;

/**
 * <pre>
 * ユーザIDを利用できるようにする。 ログフォーマットで%X{uId}を指定することによりユーザIDを出力可能。
 * セッションIDを利用できるようにする。ログフォーマットで%X{sId}を指定することによりセッションIDを出力可能。
 * </pre>
 *
 */
public class LogmarkInterceptor extends AbstractInterceptor {

  /** シリアルバージョンUID */
  private static final long serialVersionUID = 1L;

  /*
   * (非 Javadoc)
   *
   * @see AbstractInterceptor#intercept
   */
  @Override
  public String intercept(ActionInvocation invocation) throws Exception {
    HttpSession session = ServletActionContext.getRequest().getSession();
    if (session != null) {
      UserValueObject userValueObject = (UserValueObject) session.getAttribute(ECISConstants.SESSION_KEY_USER);
      if (userValueObject != null) {

        ThreadContext.put("uId", userValueObject.getUserId());
      }
      ThreadContext.put("sId", session.getId());
    }
    return invocation.invoke();
  }
}
