/*-------------------------------------------------------------------------------
 * All Rights Reserved. Copyright(C) Nihon Unisys, Ltd.
 * vendor : Nihon Unisys, Ltd.
 * since : 2014/09/01
 *-----------------------------------------------------------------------------*/
package jp.co.unisys.enability.cis.web.common.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.config.entities.ExceptionMappingConfig;
import com.opensymphony.xwork2.interceptor.ExceptionHolder;
import com.opensymphony.xwork2.interceptor.ExceptionMappingInterceptor;

import jp.co.unisys.enability.cis.common.util.EMSConstants;
import jp.co.unisys.enability.cis.common.util.ThreadContext;

/**
 * デフォルトのExceptionMappingInterceptorを拡張したクラス<br>
 * Actionの実行前に動作し、Actionクラスから例外が出力された場合、log4jのエラーログ出力を行う
 */
public class CustomExceptionInterceptor extends ExceptionMappingInterceptor {
  private static final Logger LOGGER = LogManager.getLogger();
  private static final String REGEX_ACTION_CLASS_NAME = ".*Action$";

  public CustomExceptionInterceptor() {
  }

  /**
   * インターセプト処理<br>
   */
  @Override
  public String intercept(ActionInvocation invocation) throws Exception {
    String result;
    try {
      result = invocation.invoke();
    } catch (Exception e) {
      // デフォルトの処理をほぼそのまま使う
      List<ExceptionMappingConfig> exceptionMappings = invocation
          .getProxy().getConfig().getExceptionMappings();
      ExceptionMappingConfig mappingConfig = super.findMappingFromExceptions(
          exceptionMappings, e);
      if ((mappingConfig != null) && (mappingConfig.getResult() != null)) {
        Map parameterMap = mappingConfig.getParams();

        invocation.getInvocationContext().setParameters(
            new HashMap(parameterMap));
        result = mappingConfig.getResult();

        // オーバーライドしたException処理を実行
        this.publishException(invocation, new ExceptionHolder(e));
      } else {
        throw e;
      }
    } finally {
      // threadContextを削除
      ThreadContext.getRequestThreadContext().clear();
    }
    return result;
  }

  /**
   * オーバーライドしたException時処理<br>
   * Actionクラスからの例外の場合、log4jのログ出力を行う
   */
  @Override
  protected void publishException(ActionInvocation invocation,
      ExceptionHolder exceptionHolder) {
    // アクション名取得
    String execActionName = invocation.getAction().getClass().getSimpleName();
    if (execActionName.matches(REGEX_ACTION_CLASS_NAME)) {
      this.doLog(LOGGER, exceptionHolder.getException(), execActionName);
    }
  }

  /**
   * エラーログ出力を行う
   * 
   * @param log
   * @param e
   * @param actionName
   */
  protected void doLog(Logger logger, Exception e, String actionName) {
    // 画面ID取得
    String viewId = EMSConstants.getScreenIdMap().get(actionName);
    // エラーログ出力
    logger.error("ViewId {} : Caused by {} : Message - {}", viewId, e.getCause(), e.getMessage());
    logger.catching(e);
  }

}
