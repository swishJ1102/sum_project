/*-------------------------------------------------------------------------------
 * All Rights Reserved. Copyright(C) Nihon Unisys, Ltd.
 * vendor : Nihon Unisys, Ltd.
 * since : 2014/09/01
 *-----------------------------------------------------------------------------*/
package jp.co.unisys.enability.cis.web.common.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.ValidationAware;
import com.opensymphony.xwork2.interceptor.MethodFilterInterceptor;

import jp.co.unisys.enability.cis.common.util.EMSConstants;
import jp.co.unisys.enability.cis.common.util.EMSMessageResource;
import jp.co.unisys.enability.cis.web.gk.model.UserValueObject;

/**
 * 認証チェックインターセプタ<br>
 * Actionの実行前に動作し、権限や実行方法による画面の遷移制御を行う.<br>
 * 各インターセプタの実行順序はstruts.xmlにおいて定義される.
 */
public class AuthorizationInterceptor extends MethodFilterInterceptor {

  /** メッセージプロパティ */
  private EMSMessageResource emsMessageResource;

  /*
   * (非 Javadoc)
   *
   * @see
   * com.opensymphony.xwork2.interceptor.MethodFilterInterceptor#doIntercept
   * (com.opensymphony.xwork2.ActionInvocation)
   */
  @Override
  public String doIntercept(ActionInvocation invocation) throws Exception {

    // リクエストを取得
    HttpServletRequest request = ServletActionContext.getRequest();
    // セッション情報を取得
    HttpSession session = request.getSession();

    // ユーザ情報をセッションから取得
    UserValueObject uvo = (UserValueObject) session
        .getAttribute(EMSConstants.SESSION_KEY_USER_INFO);

    // 認証チェック
    if (uvo == null) {
      // セッションが切れている場合、セッション切れメッセージを
      // 設定し、ログイン画面に遷移
      ((ValidationAware) invocation.getAction())
          .addActionError(emsMessageResource.getMessage(
              EMSMessageResource.E0013_MSG_KEY, null));
      return "relogin";
    }
    if (uvo.getUserId() == null) {
      // ユーザIDが取得出来ない場合、セッションを破棄し
      // セッション切れメッセージでログイン画面に遷移
      ((ValidationAware) invocation.getAction())
          .addActionError(emsMessageResource.getMessage(
              EMSMessageResource.E0013_MSG_KEY, null));
      session.invalidate();
      return "relogin";
    }

    // URLにパラメータ指定された場合は、不正操作
    if (request.getQueryString() != null) {
      ((ValidationAware) invocation.getAction())
          .addActionError(emsMessageResource.getMessage(
              EMSMessageResource.E0014_MSG_KEY, null));
      session.invalidate();
      return "relogin";
    }

    // 実行アクションクラス名取得
    // 実際のクラス名を取得する
    String execActionName = invocation.getAction().getClass()
        .getSimpleName();

    // パスワード初期化フラグが立っている場合、パスワード変更画面以外には遷移出来ない
    if (EMSConstants.USER_PASSWORD_INITIALIZATION_FLG_ON.equals(uvo.getPasswordInitializationFlag())) {
      if (!execActionName.equals(EMSConstants.F0100_CHANGEPASSWORDACTION)) {
        return "initialpassword";
      }
    }

    return invocation.invoke();
  }

  /**
   * emsMessageResourceのセッター
   *
   * @param emsMessageResource
   *          セットする emsMessageResource
   */
  public void setEmsMessageResource(EMSMessageResource emsMessageResource) {
    this.emsMessageResource = emsMessageResource;
  }

}