package jp.co.unisys.enability.cis.web.common.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.Preparable;

import jp.co.unisys.enability.cis.business.gk.AccessLogRegisterBussiness;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;

/**
 * 共通アクションクラス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public abstract class ScreenCommonAction extends ActionSupport
    implements ServletRequestAware, ServletResponseAware, Preparable {

  /** アクセスログ登録ビジネス（DI） */
  protected AccessLogRegisterBussiness accessLogRegisterBussiness;

  /** リクエスト */
  protected HttpServletRequest request;

  /** レスポンス */
  protected HttpServletResponse response;

  /** セッション */
  protected HttpSession session;

  /** アクションメッセージ */
  protected String actionMsg;

  /** アクションエラーメッセージ */
  protected String actionErrMsg;

  /** 遷移元フラグ */
  protected String transferFlag;

  /** 一覧選択インデックス */
  protected String listSelectionIndex;

  /**
   * 初期処理。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リクエストからセッション、遷移元フラグ、一覧選択インデックスを取得する。
   * また、アクションメッセージ、またはアクションエラーメッセージが設定されている場合は
   * 画面に登録する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   */
  @Override
  public void prepare() throws Exception {

    // リクエストからセッションを取得
    session = request.getSession();

    // 自画面IDを取得
    String myScreenId = this.getMyScreenId();

    // リクエスト.遷移元フラグ取得
    StringBuilder requestParamNameBuilder = new StringBuilder();
    requestParamNameBuilder.append(myScreenId);
    requestParamNameBuilder.append(ECISConstants.TRANSFER_SCREEN_FLAG_NAME);
    this.transferFlag = request.getParameter(requestParamNameBuilder
        .toString());

    // リクエスト.一覧選択インデックス取得
    requestParamNameBuilder.setLength(0);
    requestParamNameBuilder.append(myScreenId);
    requestParamNameBuilder.append(ECISConstants.LIST_SELECTION_INDEX);
    this.listSelectionIndex = request.getParameter(requestParamNameBuilder
        .toString());
  }

  /**
   * ajaxでエラーが発生した場合にシステムエラー画面へ遷移させるコントローラ
   * 
   * @return 遷移先情報
   */
  public String ajaxError() {
    return "ajaxerror";
  }

  /**
   * アクセスログ登録ビジネスを設定する。（DI）
   *
   * @param accessLogRegisterBussiness
   *          アクセスログ登録ビジネス
   */
  public void setAccessLogRegisterBussiness(AccessLogRegisterBussiness accessLogRegisterBussiness) {
    this.accessLogRegisterBussiness = accessLogRegisterBussiness;
  }

  /**
   * リクエストを設定する。
   *
   * @param paramHttpServletRequest
   *          リクエスト
   */
  @Override
  public void setServletRequest(HttpServletRequest paramHttpServletRequest) {
    this.request = paramHttpServletRequest;
  }

  /**
   * レスポンスを設定する。
   *
   * @param paramHttpServletResponse
   *          レスポンス
   */
  @Override
  public void setServletResponse(HttpServletResponse paramHttpServletResponse) {
    this.response = paramHttpServletResponse;
  }

  /**
   * アクションメッセージを取得する。
   *
   * @return アクションメッセージ
   */
  public String getActionMsg() {
    return actionMsg;
  }

  /**
   * アクションメッセージを設定する。
   *
   * @param actionMsg
   *          アクションメッセージ
   */
  public void setActionMsg(String actionMsg) {
    this.actionMsg = actionMsg;
  }

  /**
   * アクションエラーメッセージを取得する。
   *
   * @return アクションエラーメッセージ
   */
  public String getActionErrMsg() {
    return actionErrMsg;
  }

  /**
   * アクションエラーメッセージを設定する。
   *
   * @param actionErrMsg
   *          アクションエラーメッセージ
   */
  public void setActionErrMsg(String actionErrMsg) {
    this.actionErrMsg = actionErrMsg;
  }

  /**
   * 遷移元画面IDのセッションキー取得。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * セッションIDを元に遷移元画面IDのセッションキーを取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 遷移元画面IDのセッションキー
   */
  protected String getForwordKey() {
    // 遷移元画面IDのセッションキーを生成し、返却する。
    StringBuilder forwordKey = new StringBuilder();
    forwordKey.append(ECISConstants.SESSION_KEY_SCREEN_ID_PREFIX);
    forwordKey.append(session.getId());
    return forwordKey.toString();
  }

  /**
   * 完了画面遷移先画面IDのセッションキー取得。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * セッションIDを元に完了画面遷移先画面IDのセッションキーを取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 完了画面遷移先画面IDのセッションキー
   */
  protected String getDestinationKey() {
    // 遷移元画面IDのセッションキーを生成し、返却する。
    StringBuilder destinationKey = new StringBuilder();
    destinationKey.append(ECISConstants.SESSION_KEY_DESTINATION_PREFIX);
    destinationKey.append(session.getId());
    return destinationKey.toString();
  }

  /**
   * 一覧・キー情報のセッションキー取得。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 自画面IDとセッションIDを元に一覧・キー情報のセッションキーを取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 一覧・キー情報のセッションキー
   */
  protected String getListKey() {
    // 一覧・キー情報のセッションキーを生成し、返却する。
    StringBuilder listKey = new StringBuilder();
    listKey.append(ECISConstants.SESSION_KEY_PERMISSION_ACTION_ID_MAP_PREFIX);
    listKey.append(this.getMyScreenId());
    listKey.append(session.getId());
    return listKey.toString();
  }

  /**
   * 自画面情報のセッションキー取得。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 自画面IDとセッションIDを元に、自画面の再表示およびインデックスを用いない
   * 次画面に使用するセッションキーを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 自画面情報のセッションキー
   */
  protected String getMyScreenKey() {
    // 画面引継情報のセッションキーを生成し、返却する。
    StringBuilder myScreenKey = new StringBuilder();
    myScreenKey.append(this.getMyScreenId());
    myScreenKey.append(session.getId());
    return myScreenKey.toString();
  }

  /**
   * 検索条件情報のセッションキー取得。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 自画面IDとセッションIDを元に検索条件情報のセッションキーを取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 検索条件情報のセッションキー
   */
  protected String getConditionKey() {
    // 検索条件情報のセッションキーを生成し、返却する。
    StringBuilder conditionKey = new StringBuilder();
    conditionKey.append(ECISConstants.SESSION_KEY_CONDITION_PREFIX);
    conditionKey.append(this.getMyScreenId());
    conditionKey.append(session.getId());
    return conditionKey.toString();
  }

  /**
   * 初期処理用セッションキー取得。
   * 
   * <pre>
   * <p><b>【仕様詳細】<b><p>
   * 前画面からの一覧・キー情報または画面引継情報の受け取り、もしくは自画面の再表示に必要な
   * 画面引継情報セッションキーを生成する。
   *
   * リクエストの遷移元フラグの値、一覧選択インデックスの有無により、キーを分岐する。
   * ・前画面からの遷移かつ一覧選択インデックスありの場合
   *   →セッションキー共通接頭辞：一覧・キー情報 + セッション.遷移元画面ID + セッションID
   * ・前画面からの遷移かつ一覧選択インデックスなしの場合
   *   →セッション.遷移元画面ID + セッションID
   * ・前画面からの遷移でない場合
   *   →自画面ID + セッションID
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 初期処理用セッションキー
   */
  protected String getInitialSessionKey() {
    // 初期処理用セッションキーの生成
    StringBuilder initialInfoKey = new StringBuilder();
    if (ECISConstants.TRANSFER_SCREEN_FLAG.equals(transferFlag)) {
      // 前画面からの遷移の場合
      if (StringUtils.isNotEmpty(listSelectionIndex)) {
        // インデックスが存在する場合、セッションキー共通接頭辞：一覧・キー情報を付与
        initialInfoKey
            .append(ECISConstants.SESSION_KEY_PERMISSION_ACTION_ID_MAP_PREFIX);
      }
      // 遷移元画面IDの値を使用
      String beforeScreenId = (String) session.getAttribute(this
          .getForwordKey());
      initialInfoKey.append(beforeScreenId);
    } else {
      // 前画面からの遷移でない場合、自画面IDを使用する
      initialInfoKey.append(this.getMyScreenId());
    }

    // 末尾のセッションIDは共通
    initialInfoKey.append(session.getId());
    return initialInfoKey.toString();
  }

  /**
   * リクエストチェック処理。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リクエストが"POST"であるかチェックを行う。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return チェック結果（true：正常、false：異常）
   */
  protected boolean checkRequestMethod() {

    // チェックフラグ
    boolean checkFlag = false;

    // リクエストが"POST"でない場合はエラーとする。
    if (!"POST".equals(request.getMethod())) {
      this.setActionErrMsg(getText("error.E0014"));

    } else {
      checkFlag = true;
    }

    // チェック結果を返却する。
    return checkFlag;
  }

  /**
   * メッセージ設定処理。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * chainでの呼び出し元アクションで設定されたメッセージを画面に設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   */
  protected void setMessages() {
    // アクションメッセージがある場合は設定
    if (!StringUtils.isEmpty(actionMsg)) {
      addActionMessage(actionMsg);
    }

    // アクションエラーメッセージがある場合は設定
    if (!StringUtils.isEmpty(actionErrMsg)) {
      addActionError(actionErrMsg);
    }
  }

  /**
   * 自画面IDを取得する。
   *
   * @return 自画面ID
   */
  protected abstract String getMyScreenId();
}