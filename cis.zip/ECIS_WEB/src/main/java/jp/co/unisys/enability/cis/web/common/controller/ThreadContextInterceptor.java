package jp.co.unisys.enability.cis.web.common.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.MethodFilterInterceptor;

import jp.co.unisys.enability.cis.common.util.EMSConstants;
import jp.co.unisys.enability.cis.common.util.ThreadContext;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.web.gk.model.UserValueObject;

/**
 * WEB共通情報設定インターセプタークラス。
 *
 * <pre>
 * <p><b>【仕様詳細】<b><p>
 * WEBで使用する共通情報を{@link ThreadContext}へ格納する。
 * ・クラス名（コントローラークラス名）
 * ・ユーザID（セッションより取得）
 * ・オンラインフラグ（{@link ECISConstants#ONLINE_FLAG_ONLINE オンライン}）
 * ・セッションID（セッションより取得）
 *
 * また、セッションIDに関してはlog4jの{@link org.apache.logging.log4j.ThreadContext}へも格納する。
 * </pre>
 *
 *
 * @author "Nihon Unisys, Ltd."
 *
 */
public class ThreadContextInterceptor extends MethodFilterInterceptor {

  /*
   * (非 Javadoc)
   *
   * @see
   * com.opensymphony.xwork2.interceptor.MethodFilterInterceptor#doIntercept
   * (com.opensymphony.xwork2.ActionInvocation)
   */
  @Override
  protected String doIntercept(ActionInvocation invocation) throws Exception {

    // リクエストを取得
    HttpServletRequest request = ServletActionContext.getRequest();

    // セッション情報を取得
    HttpSession session = request.getSession();

    // ユーザ情報をセッションから取得
    UserValueObject uvo = (UserValueObject) session
        .getAttribute(EMSConstants.SESSION_KEY_USER_INFO);

    // 実行アクションクラス名取得
    String execActionName = invocation.getAction().getClass()
        .getSimpleName();

    // クラス名を設定
    ThreadContext.getRequestThreadContext().put(
        ECISConstants.CLASS_NAME_KEY, execActionName);

    // ユーザID
    ThreadContext.getRequestThreadContext().put(ECISConstants.USER_ID_KEY,
        uvo.getUserId());

    // オンラインフラグ
    ThreadContext.getRequestThreadContext()
        .put(ECISConstants.ONLINE_FLAG_KEY,
            ECISConstants.ONLINE_FLAG_ONLINE);

    // セッションID（システム用）
    ThreadContext.getRequestThreadContext().put(
        ECISConstants.SESSION_ID_KEY, session.getId());
    // セッションID（ログ用）
    org.apache.logging.log4j.ThreadContext.put(
        ECISConstants.SESSION_ID_KEY, session.getId());

    return invocation.invoke();
  }

}
