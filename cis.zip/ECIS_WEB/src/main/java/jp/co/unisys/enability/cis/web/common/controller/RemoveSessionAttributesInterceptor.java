package jp.co.unisys.enability.cis.web.common.controller;

import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.MethodFilterInterceptor;

import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;

/**
 * セッションオブジェクト破棄インターセプタ。
 *
 * <pre>
 * <p><b>【仕様詳細】<b><p>
 * メニュー操作であるか否かを判定。
 * メニュー操作である場合、セッションオブジェクトを破棄する。
 * ただし、以下のオブジェクトは破棄しない。
 * ・ユーザ情報（属性名：uvo）
 * ・トークン情報（属性名：struts.tokens.token）
 * ・権限情報（属性名：permissioninfo）
 * ・メニュー情報（属性名：menuinfo）
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 *
 */
public class RemoveSessionAttributesInterceptor extends MethodFilterInterceptor {

  /*
   * (非 Javadoc)
   *
   * @see
   * com.opensymphony.xwork2.interceptor.MethodFilterInterceptor#doIntercept
   * (com.opensymphony.xwork2.ActionInvocation)
   */
  @Override
  protected String doIntercept(ActionInvocation invocation) throws Exception {

    // 破棄しない属性名の配列
    final String[] excludeAttributeNames = {
        ECISConstants.SESSION_KEY_USER, "struts.tokens.token",
        ECISConstants.SESSION_KEY_PERMISSION_ACTION_ID_MAP,
        ECISConstants.SESSION_KEY_MENU_INFO };

    // リクエストを取得
    HttpServletRequest request = ServletActionContext.getRequest();

    // リクエストパラメータ"isMenu"を取得
    String isMenu = request.getParameter("isMenu");

    // "isMenu"が"0"の場合のみセッションオブジェクト破棄
    if (StringUtils.equals(isMenu, "0")) {

      // セッション情報を取得
      HttpSession session = request.getSession();
      // セッション内の属性名を取得
      Enumeration<?> attributeNames = session.getAttributeNames();
      // 破棄対象フラグ（初期値true：破棄する）
      boolean canRemove = true;

      // セッション内の属性分ループ
      while (attributeNames.hasMoreElements()) {
        String name = attributeNames.nextElement().toString();
        // 破棄しない属性か否かを判定
        for (String excludeName : excludeAttributeNames) {
          if (StringUtils.equals(name, excludeName)) {
            // 一致した場合、この属性（オブジェクト）は破棄しない
            canRemove = false;
            break;
          }
        }
        if (canRemove) {
          // 破棄対象フラグがtrueだったら破棄
          session.removeAttribute(name);
        }
        canRemove = true;
      }
    }
    // 後続処理を実行
    return invocation.invoke();
  }

}
