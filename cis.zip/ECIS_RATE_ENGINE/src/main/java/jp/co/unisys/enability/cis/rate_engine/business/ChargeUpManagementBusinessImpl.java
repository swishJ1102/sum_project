package jp.co.unisys.enability.cis.rate_engine.business;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import jp.co.unisys.enability.cis.common.Exception.RateEngineException;
import jp.co.unisys.enability.cis.common.util.DateCalculateUtil;
import jp.co.unisys.enability.cis.common.util.StringConvertUtil;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;
import jp.co.unisys.enability.cis.common.util.rk.RateEngineCommonUtil;
import jp.co.unisys.enability.cis.entity.common.Cr;
import jp.co.unisys.enability.cis.entity.common.CrExample;
import jp.co.unisys.enability.cis.entity.common.CrUp;
import jp.co.unisys.enability.cis.entity.common.CrUpDetail;
import jp.co.unisys.enability.cis.entity.common.CrUpDetailExample;
import jp.co.unisys.enability.cis.entity.common.CrUpExample;
import jp.co.unisys.enability.cis.entity.common.CtRateM;
import jp.co.unisys.enability.cis.entity.common.CtRateMExample;
import jp.co.unisys.enability.cis.entity.common.FcaUpM;
import jp.co.unisys.enability.cis.entity.common.FcaUpMExample;
import jp.co.unisys.enability.cis.entity.common.FcaUpTrM;
import jp.co.unisys.enability.cis.entity.common.FcaUpTrMExample;
import jp.co.unisys.enability.cis.entity.common.RcUpM;
import jp.co.unisys.enability.cis.entity.common.RcUpMExample;
import jp.co.unisys.enability.cis.entity.common.RecUpM;
import jp.co.unisys.enability.cis.entity.common.RecUpMExample;
import jp.co.unisys.enability.cis.entity.common.RecUpTrM;
import jp.co.unisys.enability.cis.entity.common.RecUpTrMExample;
import jp.co.unisys.enability.cis.entity.common.RmUp;
import jp.co.unisys.enability.cis.entity.common.RmUpDetail;
import jp.co.unisys.enability.cis.entity.common.RmUpDetailExample;
import jp.co.unisys.enability.cis.entity.common.RmUpExample;
import jp.co.unisys.enability.cis.entity.common.Spm;
import jp.co.unisys.enability.cis.entity.common.SpmExample;
import jp.co.unisys.enability.cis.entity.common.SpmUp;
import jp.co.unisys.enability.cis.entity.common.SpmUpExample;
import jp.co.unisys.enability.cis.mapper.common.CrMapper;
import jp.co.unisys.enability.cis.mapper.common.CrUpDetailMapper;
import jp.co.unisys.enability.cis.mapper.common.CrUpMapper;
import jp.co.unisys.enability.cis.mapper.common.CtRateMMapper;
import jp.co.unisys.enability.cis.mapper.common.FcaUpMMapper;
import jp.co.unisys.enability.cis.mapper.common.FcaUpTrMMapper;
import jp.co.unisys.enability.cis.mapper.common.RcUpMMapper;
import jp.co.unisys.enability.cis.mapper.common.RecUpMMapper;
import jp.co.unisys.enability.cis.mapper.common.RecUpTrMMapper;
import jp.co.unisys.enability.cis.mapper.common.RmUpDetailMapper;
import jp.co.unisys.enability.cis.mapper.common.RmUpMapper;
import jp.co.unisys.enability.cis.mapper.common.SpmMapper;
import jp.co.unisys.enability.cis.mapper.common.SpmUpMapper;
import jp.co.unisys.enability.cis.rate_engine.model.RateEngineBusinessBean;

/**
 * 料金単価を管理するビジネスクラス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class ChargeUpManagementBusinessImpl implements ChargeUpManagementBusiness {

  /** ロガー */
  private static final Logger LOGGER = LogManager.getLogger();

  /**
   * 料金メニュー単価Mapper(DI)
   */
  private RmUpMapper rmUpMapper;

  /**
   * 料金メニュー単価明細Mapper(DI)
   */
  private RmUpDetailMapper rmUpDetailMapper;

  /**
   * 燃調単価取得Mapper(DI)
   */
  private FcaUpMMapper fcaUpMMapper;

  /**
   * 再エネ単価取得Mapper(DI)
   */
  private RecUpMMapper recUpMMapper;

  /**
   * 託送メニュー取得Mapper(DI)
   */
  private CrMapper crMapper;

  /**
   * 託送メニュー単価取得Mapper(DI)
   */
  private CrUpMapper crUpMapper;

  /**
   * 託送メニュー単価明細取得Mapper(DI)
   */
  private CrUpDetailMapper crUpDetailMapper;

  /**
   * 付帯メニュー単価取得Mapper(DI)
   */
  private SpmMapper spmMapper;

  /**
   * 付帯メニュー単価明細取得Mapper(DI)
   */
  private SpmUpMapper spmUpMapper;

  /**
   * 予備契約単価取得Mapper(DI)
   */
  private RcUpMMapper rcUpMMapper;

  /**
   * 消費税率マスタ取得Mapper(DI)
   */
  private CtRateMMapper ctRateMMapper;

  /**
   * 燃調単価消費税改定取得Mapper(DI)
   */
  private FcaUpTrMMapper fcaUpTrMMapper;

  /**
   * 再エネ単価消費税改定取得Mapper(DI)
   */
  private RecUpTrMMapper recUpTrMMapper;

  /**
   * 料金メニュー単価. mapkey:料金メニューID＋単価設定区分＋適用開始日
   */
  private TreeMap<String, RmUp> planRmUp = new TreeMap<String, RmUp>();

  /**
   * 料金メニュー単価明細. mapkey:料金メニューID＋単価設定区分＋適用開始日
   */
  private TreeMap<String, Map<String, RmUpDetail>> planRmUpDetail = new TreeMap<String, Map<String, RmUpDetail>>();

  /**
   * 燃調単価. mapkey:エリアコード＋電圧区分＋適用開始日
   */
  private TreeMap<String, FcaUpM> planFcaUpM = new TreeMap<String, FcaUpM>();

  /**
   * 燃調単価. mapkey:エリアコード＋電圧区分＋利用年月
   */
  private TreeMap<String, FcaUpM> planFcaUpUsePeriodM = new TreeMap<String, FcaUpM>();

  /**
   * 再エネ. mapkey:エリアコード＋適用開始日
   */
  private TreeMap<String, RecUpM> planRecUpM = new TreeMap<String, RecUpM>();

  /**
   * 託送メニュー. mapkey:託送メニューID
   */
  private TreeMap<String, Cr> planCr = new TreeMap<String, Cr>();

  /**
   * 託送メニュー単価. mapkey:託送メニューID＋適用開始日
   */
  private TreeMap<String, CrUp> planCrUp = new TreeMap<String, CrUp>();

  /**
   * 託送メニュー明細単価. mapkey:託送メニューID＋適用開始日
   */
  private TreeMap<String, Map<String, CrUpDetail>> planCrUpDetail = new TreeMap<String, Map<String, CrUpDetail>>();

  /**
   * 付帯メニュー単価. mapkey:託送メニューID＋適用開始日
   */
  private TreeMap<String, Spm> planSpm = new TreeMap<String, Spm>();

  /**
   * 付帯メニュー明細単価. mapkey:託送メニューID＋適用開始日
   */
  private TreeMap<String, Map<String, SpmUp>> planSpmUp = new TreeMap<String, Map<String, SpmUp>>();

  /**
   * 予備契約単価. mapkey:エリアコード＋料金メニューID
   */
  private TreeMap<String, Map<String, RcUpM>> planRcUpM = new TreeMap<String, Map<String, RcUpM>>();

  /**
   * 消費税率マスタ. mapkey:適用開始日
   */
  private TreeMap<String, CtRateM> planCtRateM = new TreeMap<String, CtRateM>();

  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.rate_engine.business.ChargeUpManagementBusiness#loadData()
   */
  public void loadData() throws RateEngineException {
    String treeMapkey;

    // 料金メニュー単価取得
    RmUpExample rmUpExample = new RmUpExample();
    List<RmUp> listRmUp = new ArrayList<RmUp>();

    listRmUp = rmUpMapper.selectByExample(rmUpExample);
    for (RmUp oneRmUp : listRmUp) {
      treeMapkey = RateEngineCommonUtil.createMapKey(oneRmUp.getRmId(),
          oneRmUp.getUpCatCode(), oneRmUp.getUpApplySd());

      planRmUp.put(treeMapkey, oneRmUp);
    }

    // 料金メニュー単価明細取得
    RmUpDetailExample rmUpDetailExample = new RmUpDetailExample();
    List<RmUpDetail> listRmUpDetail = new ArrayList<RmUpDetail>();

    listRmUpDetail = rmUpDetailMapper.selectByExample(rmUpDetailExample);
    for (RmUpDetail oneRmUpDetail : listRmUpDetail) {
      treeMapkey = RateEngineCommonUtil.createMapKey(
          oneRmUpDetail.getRmId(), oneRmUpDetail.getUpCatCode(), oneRmUpDetail.getUpApplySd());

      // 料金メニューキー、＜明細メニューキー、明細メニュー＞
      Map<String, RmUpDetail> subMap = planRmUpDetail.get(treeMapkey);
      if (subMap == null) {
        subMap = new HashMap<String, RmUpDetail>();
        planRmUpDetail.put(treeMapkey, subMap);
      }

      String subMapkey = RateEngineCommonUtil.createMapKey(
          oneRmUpDetail.getDcecCatCode(), oneRmUpDetail.getTsCode(),
          oneRmUpDetail.getBranchNo());

      subMap.put(subMapkey, oneRmUpDetail);
    }

    // 燃調単価取得
    FcaUpMExample fcaUpMExample = new FcaUpMExample();
    List<FcaUpM> listFcaUpM = new ArrayList<FcaUpM>();

    listFcaUpM = fcaUpMMapper.selectByExample(fcaUpMExample);
    for (FcaUpM oneFcaUpM : listFcaUpM) {
      // 適用開始日により、データ設定する
      treeMapkey = RateEngineCommonUtil.createMapKey(
          oneFcaUpM.getAreaCode(), oneFcaUpM.getVoltageCatCode(), oneFcaUpM.getUpApplySd());

      planFcaUpM.put(treeMapkey, oneFcaUpM);

      // 利用年月により、データ設定する
      treeMapkey = RateEngineCommonUtil.createMapKey(
          oneFcaUpM.getAreaCode(), oneFcaUpM.getVoltageCatCode(), oneFcaUpM.getUsePeriod());

      planFcaUpUsePeriodM.put(treeMapkey, oneFcaUpM);
    }

    // 再エネ単価取得
    RecUpMExample recUpMExample = new RecUpMExample();
    List<RecUpM> listRecUpM = new ArrayList<RecUpM>();
    listRecUpM = recUpMMapper.selectByExample(recUpMExample);
    for (RecUpM oneRecUpM : listRecUpM) {
      // 利用年月により、データ設定する
      treeMapkey = RateEngineCommonUtil.createMapKey(
          oneRecUpM.getAreaCode(), oneRecUpM.getUsePeriod());

      planRecUpM.put(treeMapkey, oneRecUpM);
    }

    // 託送メニュー
    CrExample crExample = new CrExample();
    List<Cr> listCr = new ArrayList<Cr>();
    listCr = crMapper.selectByExample(crExample);
    for (Cr oneCr : listCr) {
      planCr.put(oneCr.getConsignmentMenuId(), oneCr);
    }

    // 託送メニュー単価
    CrUpExample crUpExample = new CrUpExample();
    List<CrUp> listCrUp = new ArrayList<CrUp>();
    listCrUp = crUpMapper.selectByExample(crUpExample);
    for (CrUp oneCrUp : listCrUp) {
      treeMapkey = RateEngineCommonUtil.createMapKey(
          oneCrUp.getConsignmentMenuId(), oneCrUp.getUpApplySd());

      planCrUp.put(treeMapkey, oneCrUp);
    }

    // 託送メニュー明細単価
    CrUpDetailExample crUpDetailExample = new CrUpDetailExample();
    List<CrUpDetail> listCrUpDetail = new ArrayList<CrUpDetail>();
    listCrUpDetail = crUpDetailMapper.selectByExample(crUpDetailExample);
    for (CrUpDetail oneCrUpDetail : listCrUpDetail) {
      treeMapkey = RateEngineCommonUtil.createMapKey(
          oneCrUpDetail.getConsignmentMenuId(),
          oneCrUpDetail.getUpApplySd());

      Map<String, CrUpDetail> subMap = planCrUpDetail.get(treeMapkey);
      if (subMap == null) {
        subMap = new HashMap<String, CrUpDetail>();
        planCrUpDetail.put(treeMapkey, subMap);
      }

      String subMapkey = RateEngineCommonUtil.createMapKey(
          oneCrUpDetail.getDcecCatCode(), oneCrUpDetail.getTsCode(),
          oneCrUpDetail.getBranchNo());

      subMap.put(subMapkey, oneCrUpDetail);
    }

    // 付帯メニュー単価
    SpmExample spmExample = new SpmExample();
    List<Spm> listSpm = new ArrayList<Spm>();
    listSpm = spmMapper.selectByExample(spmExample);
    for (Spm oneSpm : listSpm) {
      treeMapkey = RateEngineCommonUtil.createMapKey(oneSpm.getSpmId());

      planSpm.put(treeMapkey, oneSpm);
    }

    // 付帯メニュー明細単価
    SpmUpExample spmUpExample = new SpmUpExample();
    List<SpmUp> listSpmUp = new ArrayList<SpmUp>();
    listSpmUp = spmUpMapper.selectByExample(spmUpExample);
    for (SpmUp oneSpmUp : listSpmUp) {
      treeMapkey = RateEngineCommonUtil.createMapKey(
          oneSpmUp.getSpmId());

      Map<String, SpmUp> subMap = planSpmUp.get(treeMapkey);
      if (subMap == null) {
        subMap = new HashMap<String, SpmUp>();
        planSpmUp.put(treeMapkey, subMap);
      }

      String subMapkey = RateEngineCommonUtil.createMapKey(oneSpmUp.getUpApplySd());

      subMap.put(subMapkey, oneSpmUp);
    }

    // 予備契約単価
    RcUpMExample rcUpMExample = new RcUpMExample();
    List<RcUpM> listRcUpM = new ArrayList<RcUpM>();
    listRcUpM = rcUpMMapper.selectByExample(rcUpMExample);
    for (RcUpM oneRcUpM : listRcUpM) {
      treeMapkey = RateEngineCommonUtil.createMapKey(
          oneRcUpM.getAreaCode(), oneRcUpM.getRmId());

      Map<String, RcUpM> subMap = planRcUpM.get(treeMapkey);
      if (subMap == null) {
        subMap = new HashMap<String, RcUpM>();
        planRcUpM.put(treeMapkey, subMap);
      }

      String subMapkey = RateEngineCommonUtil.createMapKey(oneRcUpM.getUpApplySd());

      subMap.put(subMapkey, oneRcUpM);
    }

    // 消費税率マスタ
    CtRateMExample ctRateMExample = new CtRateMExample();
    List<CtRateM> listCtRateM = new ArrayList<CtRateM>();
    listCtRateM = ctRateMMapper.selectByExample(ctRateMExample);
    for (CtRateM ctRateM : listCtRateM) {
      treeMapkey = RateEngineCommonUtil.createMapKey(ctRateM.getApplySd());

      planCtRateM.put(treeMapkey, ctRateM);
    }
  }

  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.rate_engine.business.ChargeUpManagementBusiness#getRateMenuUnitPrice(java.lang.String, java.lang.String, java.util.Date)
   */
  public RmUp getRateMenuUnitPrice(String menuId, String upCatCode,
      Date applyStartDate) throws RateEngineException {
    String treeMapkey = RateEngineCommonUtil.createMapKey(menuId,
        upCatCode, applyStartDate);

    Entry<String, RmUp> entry = planRmUp.floorEntry(treeMapkey);
    if (entry == null) {
      // 例外をスロー
      LOGGER.error(
          "指定された料金メニュー単価が見つかりません。料金メニューID:{} 単価設定区分:{} 適用開始日:{}",
          menuId, upCatCode, StringConvertUtil.convertDateToString(
              applyStartDate,
              ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH));

      throw new RateEngineException(
          "指定された料金メニュー単価が見つかりません。料金メニューID:{0} 単価設定区分:{1} 適用開始日:{2}",
          new String[] {
              menuId,
              upCatCode,
              StringConvertUtil.convertDateToString(
                  applyStartDate,
                  ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH) });
    }

    RmUp rmUp = entry.getValue();

    if (!rmUp.getUpCatCode().equals(upCatCode)) {
      // 例外をスロー
      LOGGER.error(
          "指定された料金メニュー単価が見つかりません。料金メニューID:{} 単価設定区分:{} 適用開始日:{}",
          menuId, upCatCode, StringConvertUtil.convertDateToString(
              applyStartDate,
              ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH));

      throw new RateEngineException(
          "指定された料金メニュー単価が見つかりません。料金メニューID:{0} 単価設定区分:{1} 適用開始日:{2}",
          new String[] {
              menuId,
              upCatCode,
              StringConvertUtil.convertDateToString(
                  applyStartDate,
                  ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH) });
    }

    return rmUp;
  }

  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.rate_engine.business.ChargeUpManagementBusiness#getRateMenuUnitPriceDetail(java.lang.String, java.lang.String, java.util.Date, java.lang.String, java.lang.String, int)
   */
  public RmUpDetail getRateMenuUnitPriceDetail(String menuId,
      String upCatCode, Date applyStartDate, String dcecKbn,
      String timelineCd, int branchNumber) throws RateEngineException {
    String treeMapkey = RateEngineCommonUtil.createMapKey(menuId,
        upCatCode, applyStartDate);

    Entry<String, Map<String, RmUpDetail>> entry = planRmUpDetail
        .floorEntry(treeMapkey);

    if (entry == null) {
      // 例外をスロー
      LOGGER.error(
          "指定された料金メニュー単価明細が見つかりません。料金メニューID:{} 単価設定区分:{} 適用開始日:{}",
          menuId, upCatCode, StringConvertUtil.convertDateToString(
              applyStartDate,
              ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH));

      throw new RateEngineException(
          "指定された料金メニュー単価明細が見つかりません。料金メニューID:{0} 単価設定区分:{1} 適用開始日:{2}",
          new String[] {
              menuId,
              upCatCode,
              StringConvertUtil.convertDateToString(
                  applyStartDate,
                  ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH) });
    }

    Map<String, RmUpDetail> subMap = entry.getValue();
    String subMapKey = RateEngineCommonUtil.createMapKey(dcecKbn,
        timelineCd, branchNumber);
    RmUpDetail rmUpDetail = subMap.get(subMapKey);

    if (rmUpDetail != null && !rmUpDetail.getUpCatCode().equals(upCatCode)) {
      // 例外をスロー
      LOGGER.error(
          "指定された料金メニュー単価明細が見つかりません。料金メニューID:{} 単価設定区分:{} 適用開始日:{}",
          menuId, upCatCode, StringConvertUtil.convertDateToString(
              applyStartDate,
              ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH));

      throw new RateEngineException(
          "指定された料金メニュー単価明細が見つかりません。料金メニューID:{0} 単価設定区分:{1} 適用開始日:{2}",
          new String[] {
              menuId,
              upCatCode,
              StringConvertUtil.convertDateToString(
                  applyStartDate,
                  ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH) });
    }

    return rmUpDetail;
  }

  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.rate_engine.business.ChargeUpManagementBusiness#getRateMenuUnitPriceDetailNoTimeSlotCode(java.lang.String, java.lang.String, java.util.Date)
   */
  public Map<String, RmUpDetail> getRateMenuUnitPriceDetailNoTimeSlotCode(String menuId, String upCatCode,
      Date applyStartDate) throws RateEngineException {
    String treeMapkey = RateEngineCommonUtil.createMapKey(menuId, upCatCode,
        applyStartDate);

    Entry<String, Map<String, RmUpDetail>> entry = planRmUpDetail
        .floorEntry(treeMapkey);

    if (entry == null) {
      // 例外をスロー
      LOGGER.error(
          "指定された料金メニュー単価明細が見つかりません。料金メニューID:{} 単価設定区分:{} 適用開始日:{}",
          menuId, upCatCode, StringConvertUtil.convertDateToString(
              applyStartDate,
              ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH));

      throw new RateEngineException(
          "指定された料金メニュー単価明細が見つかりません。料金メニューID:{0} 単価設定区分:{1} 適用開始日:{2}",
          new String[] {
              menuId,
              upCatCode,
              StringConvertUtil.convertDateToString(
                  applyStartDate,
                  ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH) });
    }

    return entry.getValue();
  }

  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.rate_engine.business.ChargeUpManagementBusiness#getFuelCostAdjustUnitPrice(java.lang.String, java.lang.String, java.util.Date)
   */
  public FcaUpM getFuelCostAdjustUnitPrice(String areaCd, String voltageCatCode, Date applyStartDate)
      throws RateEngineException {
    String treeMapkey = RateEngineCommonUtil.createMapKey(areaCd, voltageCatCode,
        applyStartDate);

    Entry<String, FcaUpM> entry = planFcaUpM.floorEntry(treeMapkey);

    if (entry == null) {
      // 例外をスロー
      LOGGER.error(
          "指定された燃調単価が見つかりません。エリアコード:{} 電圧区分:{} 適用開始日:{}",
          areaCd, voltageCatCode,
          StringConvertUtil.convertDateToString(applyStartDate,
              ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH));

      throw new RateEngineException("指定された燃調単価が見つかりません。エリアコード:{0} 電圧区分:{1} 適用開始日:{2}",
          new String[] {areaCd, voltageCatCode, StringConvertUtil.convertDateToString(applyStartDate,
              ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH) });

    }

    FcaUpM fcaUpM = entry.getValue();

    // 利用日が単価適用開始日と単価適用終了日の間ではない場合、または、電圧区分が異なる場合、例外とする
    if (!fcaUpM.getUpApplySd().after(applyStartDate)
        && !fcaUpM.getUpApplyEd().before(applyStartDate)
        && fcaUpM.getVoltageCatCode().equals(voltageCatCode)) {
      // 利用日が単価適用開始日と単価適用終了日の間、かつ、電圧区分が一致
      return fcaUpM;
    } else {
      // 例外をスロー
      LOGGER.error(
          "指定された燃調単価が見つかりません。エリアコード:{} 電圧区分:{} 適用開始日:{}",
          areaCd, voltageCatCode,
          StringConvertUtil.convertDateToString(applyStartDate,
              ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH));

      throw new RateEngineException("指定された燃調単価が見つかりません。エリアコード:{0} 電圧区分:{1} 適用開始日:{2}",
          new String[] {areaCd, voltageCatCode, StringConvertUtil.convertDateToString(applyStartDate,
              ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH) });
    }

  }

  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.rate_engine.business.ChargeUpManagementBusiness#getFuelCostAdjustUnitPriceUsePeriod(java.lang.String, java.lang.String, java.lang.String)
   */
  public FcaUpM getFuelCostAdjustUnitPriceUsePeriod(String areaCd, String voltageCatCode, String usePeriod)
      throws RateEngineException {
    String treeMapkey = RateEngineCommonUtil.createMapKey(areaCd, voltageCatCode, usePeriod);

    FcaUpM fcaUpM = planFcaUpUsePeriodM.get(treeMapkey);

    if (fcaUpM == null) {
      // -- 料金シミュレーション不具合対応 Added Start
      // 利用年月により、データ設定する
      treeMapkey = RateEngineCommonUtil.createMapKey(
          areaCd, voltageCatCode, StringConvertUtil.convertDateObjectToString(
              ECISRKConstants.UP_APPLY_MAX_DATE, ECISConstants.FORMAT_DATE_yyyyMMdd,
              ECISConstants.FORMAT_DATE_yyyyMM));

      fcaUpM = planFcaUpUsePeriodM.get(treeMapkey);
      if (fcaUpM == null) {
        // 例外をスロー
        LOGGER.error(
            "指定された燃調単価が見つかりません。エリアコード:{} 電圧区分:{} 利用年月:{}", areaCd,
            voltageCatCode, StringConvertUtil.convertDateFormatAddDelimitor(usePeriod, ECISConstants.SLASH));

        throw new RateEngineException("指定された燃調単価が見つかりません。エリアコード:{0} 電圧区分:{1} 利用年月:{2}",
            new String[] {areaCd, voltageCatCode,
                StringConvertUtil.convertDateFormatAddDelimitor(usePeriod, ECISConstants.SLASH) });
      }
    }

    return fcaUpM;
  }

  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.rate_engine.business.ChargeUpManagementBusiness#getRenewableEnergyChargeUnitPrice(java.lang.String, java.util.Date)
   */
  public RecUpM getRenewableEnergyChargeUnitPrice(String areaCd,
      String usePeriod) throws RateEngineException {
    String treeMapkey = RateEngineCommonUtil.createMapKey(areaCd,
        usePeriod);

    RecUpM recUpM = planRecUpM.get(treeMapkey);

    if (recUpM == null) {
      // 例外をスロー
      LOGGER.error(
          "指定された再エネ単価が見つかりません。エリアコード:{} 利用年月:{}", areaCd,
          StringConvertUtil.convertDateFormatAddDelimitor(usePeriod, ECISConstants.SLASH));

      throw new RateEngineException("指定された再エネ単価が見つかりません。エリアコード:{0} 利用年月:{1}",
          new String[] {areaCd,
              StringConvertUtil.convertDateFormatAddDelimitor(usePeriod, ECISConstants.SLASH) });
    }

    return recUpM;
  }

  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.rate_engine.business.ChargeUpManagementBusiness#getConsignmentRateMenu(java.lang.String)
   */
  @Override
  public Cr getConsignmentRateMenu(String menuId) {
    return planCr.get(menuId);
  }

  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.rate_engine.business.ChargeUpManagementBusiness#getConsignmentRateMenuUnitPrice(java.lang.String, java.util.Date)
   */
  public CrUp getConsignmentRateMenuUnitPrice(String menuId,
      Date applyStartDate) {
    String treeMapkey = RateEngineCommonUtil.createMapKey(menuId,
        applyStartDate);

    Entry<String, CrUp> entry = planCrUp.floorEntry(treeMapkey);

    CrUp crUp = entry.getValue();

    return crUp;
  }

  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.rate_engine.business.ChargeUpManagementBusiness#getConsignmentRateMenuUnitPriceDetail(java.lang.String, java.util.Date, java.lang.String, java.lang.String, int)
   */
  public CrUpDetail getConsignmentRateMenuUnitPriceDetail(String menuId,
      Date applyStartDate, String dcecKbn, String timelineCd,
      int branchNumber) {
    String treeMapkey = RateEngineCommonUtil.createMapKey(menuId,
        applyStartDate);

    Entry<String, Map<String, CrUpDetail>> entry = planCrUpDetail
        .floorEntry(treeMapkey);

    Map<String, CrUpDetail> subMap = entry.getValue();
    String subMapKey = RateEngineCommonUtil.createMapKey(dcecKbn,
        timelineCd, branchNumber);
    CrUpDetail crUpDetail = subMap.get(subMapKey);

    return crUpDetail;
  }

  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.rate_engine.business.ChargeUpManagementBusiness#getConsignmentRateMenuUnitPrice(java.lang.String, java.util.Date)
   */
  public Spm getSpm(String spmId) {
    Spm spm = planSpm.get(spmId);

    return spm;
  }

  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.rate_engine.business.ChargeUpManagementBusiness#getConsignmentRateMenuUnitPriceDetail(java.lang.String, java.util.Date, java.lang.String, java.lang.String, int)
   */
  public SpmUp getSpmUp(String spmId, Date applyStartDate) {
    String treeMapkey = RateEngineCommonUtil.createMapKey(spmId);

    Entry<String, Map<String, SpmUp>> entry = planSpmUp.floorEntry(treeMapkey);

    Map<String, SpmUp> subMap = entry.getValue();

    SpmUp spmUp = null;
    for (Map.Entry<String, SpmUp> e : subMap.entrySet()) {
      if (!e.getValue().getUpApplySd().after(applyStartDate)
          && !e.getValue().getUpApplyEd().before(applyStartDate)) {
        spmUp = e.getValue();
        break;
      }
    }

    return spmUp;
  }

  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.rate_engine.business.ChargeUpManagementBusiness#getRcUpM(java.lang.String, java.lang.String, java.util.Date)
   */
  public RcUpM getRcUpM(String areaCode, String menuId, Date upGetDate) throws RateEngineException {
    String treeMapkey = RateEngineCommonUtil.createMapKey(areaCode, menuId);

    Entry<String, Map<String, RcUpM>> entry = planRcUpM.floorEntry(treeMapkey);

    Map<String, RcUpM> subMap = entry.getValue();

    RcUpM rcUpM = null;
    if (entry.getKey().equals(treeMapkey)) {
      for (Map.Entry<String, RcUpM> e : subMap.entrySet()) {
        if (upGetDate.compareTo(e.getValue().getUpApplySd()) >= 0
            && upGetDate.compareTo(e.getValue().getUpApplyEd()) <= 0) {
          rcUpM = e.getValue();
          break;
        }
      }
    }

    if (rcUpM == null) {
      // 例外をスロー
      LOGGER.error(
          "指定された予備契約単価が見つかりません。エリアコード:{} 料金メニューID:{} 単価適用開始日:{}",
          areaCode, menuId,
          StringConvertUtil.convertDateToString(upGetDate,
              ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH));

      throw new RateEngineException(
          "指定された予備契約単価が見つかりません。エリアコード:{0} 料金メニューID:{1} 単価適用開始日:{2}",
          new String[] {areaCode, menuId,
              StringConvertUtil.convertDateToString(
                  upGetDate, ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH) });
    }

    return rcUpM;
  }

  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.rate_engine.business.ChargeUpManagementBusiness#getCtRateM(java.util.Date)
   */
  public CtRateM getCtRateM(Date baseDt) throws RateEngineException {

    CtRateM ctRateM = null;
    for (Map.Entry<String, CtRateM> e : planCtRateM.entrySet()) {
      if (baseDt.compareTo(e.getValue().getApplySd()) >= 0
          && baseDt.compareTo(e.getValue().getApplyEd()) <= 0) {
        ctRateM = e.getValue();
        break;
      }
    }

    if (ctRateM == null) {
      // 例外をスロー
      LOGGER.error(
          "指定された消費税率マスタが見つかりません。基準日:{}",
          StringConvertUtil.convertDateToString(baseDt, ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH));

      throw new RateEngineException(
          "指定された消費税率マスタが見つかりません。基準日:{0}",
          new String[] {
              StringConvertUtil.convertDateToString(baseDt, ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH) });
    }

    return ctRateM;
  }

  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.rate_engine.business.ChargeUpManagementBusiness#getRateMenuUnitPriceCount()
   */
  public int getRateMenuUnitPriceCount() {
    return planRmUp.size();
  }

  /**
   * 託送メニューのsetter(DI)
   *
   * @param crUpMapper
   */
  public void setCrMapper(CrMapper crMapper) {
    this.crMapper = crMapper;
  }

  /**
   * 託送メニュー単価のsetter(DI)
   *
   * @param crUpMapper
   */
  public void setCrUpMapper(CrUpMapper crUpMapper) {
    this.crUpMapper = crUpMapper;
  }

  /**
   * 託送メニュー単価明細のsetter(DI)
   *
   * @param crUpDetailMapper
   */
  public void setCrUpDetailMapper(CrUpDetailMapper crUpDetailMapper) {
    this.crUpDetailMapper = crUpDetailMapper;
  }

  /**
   * 燃調単価のsetter(DI)
   *
   * @param fcaUpMMapper
   */
  public void setFcaUpMMapper(FcaUpMMapper fcaUpMMapper) {
    this.fcaUpMMapper = fcaUpMMapper;
  }

  /**
   * 料金メニュー単価のsetter(DI)
   *
   * @param crUpDetailMapper
   */
  public void setRmUpMapper(RmUpMapper rmUpMapper) {
    this.rmUpMapper = rmUpMapper;
  }

  /**
   * 料金メニュー単価明細のsetter(DI)
   *
   * @param crUpDetailMapper
   */
  public void setRmUpDetailMapper(RmUpDetailMapper rmUpDetailMapper) {
    this.rmUpDetailMapper = rmUpDetailMapper;
  }

  /**
   * 再エネ単価のsetter(DI)
   *
   * @param fcaUpMMapper
   */
  public void setRecUpMMapper(RecUpMMapper recUpMMapper) {
    this.recUpMMapper = recUpMMapper;
  }

  /**
   * 付帯メニュー単価のsetter(DI)
   *
   * @param crUpMapper
   */
  public void setspMMapper(SpmMapper spMMapper) {
    this.spmMapper = spMMapper;
  }

  /**
   * 付帯メニュー単価明細のsetter(DI)
   *
   * @param crUpDetailMapper
   */
  public void setSpmUpMapper(SpmUpMapper spmUpMapper) {
    this.spmUpMapper = spmUpMapper;
  }

  /**
   * 予備契約単価のsetter(DI)
   *
   * @param crUpMapper
   */
  public void setRcUpMMapper(RcUpMMapper rcUpMMapper) {
    this.rcUpMMapper = rcUpMMapper;
  }

  /**
   * 消費税率マスタのsetter(DI)
   *
   * @param ctRateMMapper
   */
  public void setCtRateMMapper(CtRateMMapper ctRateMMapper) {
    this.ctRateMMapper = ctRateMMapper;
  }

  /**
   * ＜消費税改定対応＞<br>
   * 燃調単価消費税改定マスタマッパーのsetter(DI)
   *
   * @param fcaUpTrMMapper
   *          燃調単価消費税改定マスタマッパー
   */
  public void setFcaUpTrMMapper(FcaUpTrMMapper fcaUpTrMMapper) {
    this.fcaUpTrMMapper = fcaUpTrMMapper;
  }

  /**
   * ＜消費税改定対応＞<br>
   * 再エネ単価消費税改定マスタマッパーのsetter(DI)
   *
   * @param recUpTrMMapper
   *          再エネ単価消費税改定マスタマッパー
   */
  public void setRecUpTrMMapper(RecUpTrMMapper recUpTrMMapper) {
    this.recUpTrMMapper = recUpTrMMapper;
  }

  // 2016/07/01 料金シミュレーション不具合対応 Add Start
  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.rate_engine.business.ChargeUpManagementBusiness#loadData(java.lang.String)
   */
  @Override
  public void loadData(Date upBaseDate, RateEngineBusinessBean rateEngineBusinessBean, String usePeriod) throws RateEngineException {
    // TreeMap用のキー
    String treeMapkey;
    // キー変換＆登録用のMap（料金メニュー）
    Map<String, String> keyConvRmUpMap = new HashMap<String, String>();

    // -- 料金メニュー単価の取得と保持 --
    RmUpExample rmUpExample = new RmUpExample();
    // 単価設定区分のみ設定
    rmUpExample.createCriteria().andUpCatCodeEqualTo(rateEngineBusinessBean.getContractHist().getUpCatCode());
    List<RmUp> listRmUp = new ArrayList<RmUp>();

    listRmUp = rmUpMapper.selectByExample(rmUpExample);

    // - 単価基準日から適用する単価を判定 -
    String workRmId = "";
    for (RmUp oneRmUp : listRmUp) {
      if (!workRmId.equals(oneRmUp.getRmId())) {
        // 単価基準日がはまる単価があるか？
        if (oneRmUp.getUpApplySd().compareTo(upBaseDate) <= 0
            && oneRmUp.getUpApplyEd().compareTo(upBaseDate) >= 0) {
          // 単価があった場合、適用開始日を19000101に変換して登録する（準備）
          keyConvRmUpMap.put(
              RateEngineCommonUtil.createMapKey(oneRmUp.getRmId(), oneRmUp.getUpCatCode(), oneRmUp.getUpApplySd()),
              RateEngineCommonUtil.createMapKey(oneRmUp.getRmId(), oneRmUp.getUpCatCode(),
                  StringConvertUtil.stringToDate(ECISRKConstants.UP_APPLY_MIN_DATE,
                      ECISConstants.FORMAT_DATE_yyyyMMdd)));
        }
        workRmId = oneRmUp.getRmId();
      }
    }

    // - メモリ上に保持 -
    for (RmUp oneRmUp : listRmUp) {
      treeMapkey = RateEngineCommonUtil.createMapKey(oneRmUp.getRmId(), oneRmUp.getUpCatCode(),
          oneRmUp.getUpApplySd());
      // キー変換＆登録用Mapに値が存在したら変換値をキーとし、メモリ上に保持する
      if (keyConvRmUpMap.get(treeMapkey) != null) {
        treeMapkey = keyConvRmUpMap.get(treeMapkey);
        // 適用開始日を19000101、適用終了日を99991231に変換して登録する
        oneRmUp.setUpApplySd(
            StringConvertUtil.stringToDate(ECISRKConstants.UP_APPLY_MIN_DATE,
                ECISConstants.FORMAT_DATE_yyyyMMdd));
        oneRmUp.setUpApplyEd(
            StringConvertUtil.stringToDate(ECISRKConstants.UP_APPLY_MAX_DATE,
                ECISConstants.FORMAT_DATE_yyyyMMdd));
        planRmUp.put(treeMapkey, oneRmUp);
      }
    }

    // -- 料金メニュー単価明細の取得と保持 --
    RmUpDetailExample rmUpDetailExample = new RmUpDetailExample();
    // 単価設定区分のみ設定
    rmUpDetailExample.createCriteria().andUpCatCodeEqualTo(rateEngineBusinessBean.getContractHist().getUpCatCode());
    List<RmUpDetail> listRmUpDetail = new ArrayList<RmUpDetail>();

    listRmUpDetail = rmUpDetailMapper.selectByExample(rmUpDetailExample);

    // - メモリ上に保持 -
    for (RmUpDetail oneRmUpDetail : listRmUpDetail) {
      treeMapkey = RateEngineCommonUtil.createMapKey(
          oneRmUpDetail.getRmId(), oneRmUpDetail.getUpCatCode(), oneRmUpDetail.getUpApplySd());

      // キー変換＆登録用Mapに値が存在したら変換値をキーとし、メモリ上に保持する
      if (keyConvRmUpMap.get(treeMapkey) != null) {
        treeMapkey = keyConvRmUpMap.get(treeMapkey);

        // 料金メニューキー、＜明細メニューキー、明細メニュー＞
        Map<String, RmUpDetail> subMap = planRmUpDetail.get(treeMapkey);
        if (subMap == null) {
          subMap = new HashMap<String, RmUpDetail>();
          planRmUpDetail.put(treeMapkey, subMap);
        }

        // 適用開始日を19000101に変換して登録する
        oneRmUpDetail.setUpApplySd(
            StringConvertUtil.stringToDate(ECISRKConstants.UP_APPLY_MIN_DATE,
                ECISConstants.FORMAT_DATE_yyyyMMdd));

        String subMapkey = RateEngineCommonUtil.createMapKey(
            oneRmUpDetail.getDcecCatCode(), oneRmUpDetail.getTsCode(),
            oneRmUpDetail.getBranchNo());

        subMap.put(subMapkey, oneRmUpDetail);
      }
    }

    // キー変換＆登録用のMap（燃調単価）
    Map<String, String> keyConvFcaMap = new HashMap<String, String>();

    // -- 燃調単価の取得と保持 --
    FcaUpMExample fcaUpMExample = new FcaUpMExample();
    // 電圧区分のみ設定
    fcaUpMExample.createCriteria().andVoltageCatCodeEqualTo(rateEngineBusinessBean.getContractHist().getVoltageCatCode());
    List<FcaUpM> listFcaUpM = new ArrayList<FcaUpM>();

    listFcaUpM = fcaUpMMapper.selectByExample(fcaUpMExample);

    // - 単価基準日から適用する単価を判定 -
    for (FcaUpM oneFcaUpM : listFcaUpM) {
      // 単価基準日がはまる単価があるか？
      if (oneFcaUpM.getUpApplySd().compareTo(upBaseDate) <= 0
          && oneFcaUpM.getUpApplyEd().compareTo(upBaseDate) >= 0) {
        // 単価があった場合、適用開始日を19000101に変換して登録する（準備）
        keyConvFcaMap.put(
            RateEngineCommonUtil.createMapKey(oneFcaUpM.getAreaCode(), oneFcaUpM.getVoltageCatCode(), oneFcaUpM.getUpApplySd()),
            RateEngineCommonUtil.createMapKey(oneFcaUpM.getAreaCode(), oneFcaUpM.getVoltageCatCode(),
                StringConvertUtil.stringToDate(ECISRKConstants.UP_APPLY_MIN_DATE,
                    ECISConstants.FORMAT_DATE_yyyyMMdd)));
      }
    }

    // - メモリ上に保持 -
    for (FcaUpM oneFcaUpM : listFcaUpM) {
      treeMapkey = RateEngineCommonUtil.createMapKey(
          oneFcaUpM.getAreaCode(), oneFcaUpM.getVoltageCatCode(), oneFcaUpM.getUpApplySd());

      // キー変換＆登録用Mapに値が存在したら変換値をキーとし、メモリ上に保持する
      if (keyConvFcaMap.get(treeMapkey) != null) {
        treeMapkey = keyConvFcaMap.get(treeMapkey);
        // 適用開始日を19000101、適用終了日を99991231に変換して登録する
        oneFcaUpM.setUpApplySd(
            StringConvertUtil.stringToDate(ECISRKConstants.UP_APPLY_MIN_DATE,
                ECISConstants.FORMAT_DATE_yyyyMMdd));
        oneFcaUpM.setUpApplyEd(
            StringConvertUtil.stringToDate(ECISRKConstants.UP_APPLY_MAX_DATE,
                ECISConstants.FORMAT_DATE_yyyyMMdd));
        planFcaUpM.put(treeMapkey, oneFcaUpM);
      }
    }

    // -- 料金シミュレーション不具合対応 Added Start
    String executeUsePeriod = StringConvertUtil.convertDateToString(
        upBaseDate, ECISConstants.FORMAT_DATE_yyyyMM);
    // - 単価基準日から適用する単価を判定 -
    for (FcaUpM oneFcaUpM : listFcaUpM) {
      // 単価基準日がはまる単価があるか？
      if (oneFcaUpM.getUsePeriod().compareTo(executeUsePeriod) == 0) {
        // 単価があった場合、利用年月を999912に変換して登録する（準備）
        keyConvFcaMap.put(RateEngineCommonUtil.createMapKey(oneFcaUpM
            .getAreaCode(), oneFcaUpM.getVoltageCatCode(), executeUsePeriod),
            RateEngineCommonUtil.createMapKey(oneFcaUpM.getAreaCode(),
                oneFcaUpM.getVoltageCatCode(),
                StringConvertUtil.convertDateObjectToString(
                    ECISRKConstants.UP_APPLY_MAX_DATE, ECISConstants.FORMAT_DATE_yyyyMMdd,
                    ECISConstants.FORMAT_DATE_yyyyMM)));
      }
    }

    // - メモリ上に保持 -
    for (FcaUpM oneFcaUpM : listFcaUpM) {
      treeMapkey = RateEngineCommonUtil.createMapKey(oneFcaUpM.getAreaCode(),
          oneFcaUpM.getVoltageCatCode(), oneFcaUpM.getUsePeriod());

      // キー変換＆登録用Mapに値が存在したら変換値をキーとし、メモリ上に保持する
      if (keyConvFcaMap.get(treeMapkey) != null) {
        treeMapkey = keyConvFcaMap.get(treeMapkey);
        planFcaUpUsePeriodM.put(treeMapkey, oneFcaUpM);
      }
    }
    // -- 料金シミュレーション不具合対応 Added End

    // キー変換＆登録用のMap（再エネ単価）
    Map<String, String> keyConvRecMap = new HashMap<String, String>();

    // -- 再エネ単価の取得と保持 --
    RecUpMExample recUpMExample = new RecUpMExample();
    List<RecUpM> listRecUpM = new ArrayList<RecUpM>();

    listRecUpM = recUpMMapper.selectByExample(recUpMExample);

    String upBasePeriod = StringConvertUtil.convertDateToString(upBaseDate, ECISConstants.FORMAT_DATE_yyyyMM);
    // - 利用年月（単価基準日から算出）から適用する単価を判定 -
    for (RecUpM oneRecUpM : listRecUpM) {
      // 利用年月（単価基準日から算出）と一致する単価があるか？
      if (oneRecUpM.getUsePeriod().compareTo(upBasePeriod) == 0) {
        // 単価があった場合、利用年月を利用年月（引数）に変換して登録する（準備）
        keyConvRecMap.put(
            RateEngineCommonUtil.createMapKey(oneRecUpM.getAreaCode(), oneRecUpM.getUsePeriod()),
            RateEngineCommonUtil.createMapKey(oneRecUpM.getAreaCode(), usePeriod));
      }
    }

    // - メモリ上に保持 -
    for (RecUpM oneRecUpM : listRecUpM) {
      // 利用年月により、データ設定する
      treeMapkey = RateEngineCommonUtil.createMapKey(
          oneRecUpM.getAreaCode(), oneRecUpM.getUsePeriod());

      // キー変換＆登録用Mapに値が存在したら変換値をキーとし、メモリ上に保持する
      if (keyConvRecMap.get(treeMapkey) != null) {
        treeMapkey = keyConvRecMap.get(treeMapkey);
        // 適用開始日を利用年月の初日、適用終了日を利用年月の最終日に変換して登録する
        oneRecUpM.setUpApplySd(
            StringConvertUtil.stringToDate(usePeriod + "01",
                ECISConstants.FORMAT_DATE_yyyyMMdd));
        oneRecUpM.setUpApplyEd(DateCalculateUtil.getEndOfMonth(oneRecUpM.getUpApplySd()));
        planRecUpM.put(treeMapkey, oneRecUpM);
      }
    }

    // -- 託送メニューの取得と保持 --
    CrExample crExample = new CrExample();
    List<Cr> listCr = new ArrayList<Cr>();
    listCr = crMapper.selectByExample(crExample);
    for (Cr oneCr : listCr) {
      planCr.put(oneCr.getConsignmentMenuId(), oneCr);
    }

    // キー変換＆登録用のMap（託送単価）
    Map<String, String> keyConvCrMap = new HashMap<String, String>();

    // -- 託送メニュー単価の取得と保持 --
    CrUpExample crUpExample = new CrUpExample();
    List<CrUp> listCrUp = new ArrayList<CrUp>();

    listCrUp = crUpMapper.selectByExample(crUpExample);

    // - 単価基準日から適用する単価を判定 -
    for (CrUp oneCrUp : listCrUp) {
      // 単価基準日がはまる単価があるか？
      if (oneCrUp.getUpApplySd().compareTo(upBaseDate) <= 0
          && oneCrUp.getUpApplyEd().compareTo(upBaseDate) >= 0) {
        // 単価があった場合、適用開始日を19000101に変換して登録する（準備）
        keyConvCrMap.put(
            RateEngineCommonUtil.createMapKey(oneCrUp.getConsignmentMenuId(), oneCrUp.getUpApplySd()),
            RateEngineCommonUtil.createMapKey(oneCrUp.getConsignmentMenuId(),
                StringConvertUtil.stringToDate(ECISRKConstants.UP_APPLY_MIN_DATE,
                    ECISConstants.FORMAT_DATE_yyyyMMdd)));
      }
    }

    // - メモリ上に保持 -
    for (CrUp oneCrUp : listCrUp) {
      treeMapkey = RateEngineCommonUtil.createMapKey(
          oneCrUp.getConsignmentMenuId(), oneCrUp.getUpApplySd());

      // キー変換＆登録用Mapに値が存在したら変換値をキーとし、メモリ上に保持する
      if (keyConvCrMap.get(treeMapkey) != null) {
        treeMapkey = keyConvCrMap.get(treeMapkey);
        // 適用開始日を19000101、適用終了日を99991231に変換して登録する
        oneCrUp.setUpApplySd(
            StringConvertUtil.stringToDate(ECISRKConstants.UP_APPLY_MIN_DATE,
                ECISConstants.FORMAT_DATE_yyyyMMdd));
        oneCrUp.setUpApplyEd(
            StringConvertUtil.stringToDate(ECISRKConstants.UP_APPLY_MAX_DATE,
                ECISConstants.FORMAT_DATE_yyyyMMdd));
        planCrUp.put(treeMapkey, oneCrUp);
      }
    }

    // -- 託送メニュー明細単価の取得と保持 --
    CrUpDetailExample crUpDetailExample = new CrUpDetailExample();
    List<CrUpDetail> listCrUpDetail = new ArrayList<CrUpDetail>();

    listCrUpDetail = crUpDetailMapper.selectByExample(crUpDetailExample);

    // - メモリ上に保持 -
    for (CrUpDetail oneCrUpDetail : listCrUpDetail) {
      treeMapkey = RateEngineCommonUtil.createMapKey(
          oneCrUpDetail.getConsignmentMenuId(),
          oneCrUpDetail.getUpApplySd());

      // キー変換＆登録用Mapに値が存在したら変換値をキーとし、メモリ上に保持する
      if (keyConvCrMap.get(treeMapkey) != null) {
        treeMapkey = keyConvCrMap.get(treeMapkey);

        Map<String, CrUpDetail> subMap = planCrUpDetail.get(treeMapkey);
        if (subMap == null) {
          subMap = new HashMap<String, CrUpDetail>();
          planCrUpDetail.put(treeMapkey, subMap);
        }

        String subMapkey = RateEngineCommonUtil.createMapKey(
            oneCrUpDetail.getDcecCatCode(), oneCrUpDetail.getTsCode(),
            oneCrUpDetail.getBranchNo());

        subMap.put(subMapkey, oneCrUpDetail);
      }
    }

    // -- 付帯メニュー単価の取得と保持 --
    SpmExample spmExample = new SpmExample();
    List<Spm> listSpm = new ArrayList<Spm>();
    listSpm = spmMapper.selectByExample(spmExample);
    for (Spm oneSpm : listSpm) {
      treeMapkey = RateEngineCommonUtil.createMapKey(oneSpm.getSpmId());

      planSpm.put(treeMapkey, oneSpm);
    }

    // -- 付帯メニュー明細単価の取得と保持 --
    SpmUpExample spmUpExample = new SpmUpExample();
    List<SpmUp> listSpmUp = new ArrayList<SpmUp>();

    listSpmUp = spmUpMapper.selectByExample(spmUpExample);

    // - メモリ上に保持 -
    for (SpmUp oneSpmUp : listSpmUp) {
      treeMapkey = RateEngineCommonUtil.createMapKey(
          oneSpmUp.getSpmId());

      Map<String, SpmUp> subMap = planSpmUp.get(treeMapkey);
      if (subMap == null) {
        subMap = new HashMap<String, SpmUp>();
        planSpmUp.put(treeMapkey, subMap);
      }

      // 単価基準日がはまる単価があるか？
      if (oneSpmUp.getUpApplySd().compareTo(upBaseDate) <= 0
          && oneSpmUp.getUpApplyEd().compareTo(upBaseDate) >= 0) {
        // 適用開始日を19000101、適用終了日を99991231に変換して登録する
        oneSpmUp.setUpApplySd(
            StringConvertUtil.stringToDate(ECISRKConstants.UP_APPLY_MIN_DATE,
                ECISConstants.FORMAT_DATE_yyyyMMdd));
        oneSpmUp.setUpApplyEd(
            StringConvertUtil.stringToDate(ECISRKConstants.UP_APPLY_MAX_DATE,
                ECISConstants.FORMAT_DATE_yyyyMMdd));
        String subMapkey = RateEngineCommonUtil.createMapKey(oneSpmUp.getUpApplySd());
        subMap.put(subMapkey, oneSpmUp);
      }
    }

    // -- 予備契約単価の取得と保持 --
    RcUpMExample rcUpMExample = new RcUpMExample();
    List<RcUpM> listRcUpM = new ArrayList<RcUpM>();

    listRcUpM = rcUpMMapper.selectByExample(rcUpMExample);

    // - メモリ上に保持 -
    for (RcUpM oneRcUpM : listRcUpM) {
      treeMapkey = RateEngineCommonUtil.createMapKey(
          oneRcUpM.getAreaCode(), oneRcUpM.getRmId());

      Map<String, RcUpM> subMap = planRcUpM.get(treeMapkey);
      if (subMap == null) {
        subMap = new HashMap<String, RcUpM>();
        planRcUpM.put(treeMapkey, subMap);
      }

      // 単価基準日がはまる単価があるか？
      if (oneRcUpM.getUpApplySd().compareTo(upBaseDate) <= 0
          && oneRcUpM.getUpApplyEd().compareTo(upBaseDate) >= 0) {
        // 適用開始日を19000101、適用終了日を99991231に変換して登録する
        oneRcUpM.setUpApplySd(
            StringConvertUtil.stringToDate(ECISRKConstants.UP_APPLY_MIN_DATE,
                ECISConstants.FORMAT_DATE_yyyyMMdd));
        oneRcUpM.setUpApplyEd(
            StringConvertUtil.stringToDate(ECISRKConstants.UP_APPLY_MAX_DATE,
                ECISConstants.FORMAT_DATE_yyyyMMdd));
        String subMapkey = RateEngineCommonUtil.createMapKey(oneRcUpM.getUpApplySd());
        subMap.put(subMapkey, oneRcUpM);
      }
    }

    // -- 消費税率マスタの取得と保持 --
    CtRateMExample ctRateMExample = new CtRateMExample();
    List<CtRateM> listCtRateM = new ArrayList<CtRateM>();
    listCtRateM = ctRateMMapper.selectByExample(ctRateMExample);
    for (CtRateM ctRateM : listCtRateM) {
      treeMapkey = RateEngineCommonUtil.createMapKey(ctRateM.getApplySd());

      planCtRateM.put(treeMapkey, ctRateM);
    }
  }
  // 2016/07/01 料金シミュレーション不具合対応 Add End

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.rate_engine.business.ChargeUpManagementBusiness#getRecUpTrMForResetting(java.lang.String, java.lang.String)
   */
  @Override
  public RecUpTrM getRecUpTrMForResetting(String areaCd, String usePeriod) throws RateEngineException {

    RecUpTrMExample recUpTrMExample = new RecUpTrMExample();
    // エリアコード、利用年月を設定
    recUpTrMExample.createCriteria().andAreaCodeEqualTo(areaCd).andUsePeriodEqualTo(usePeriod);
    List<RecUpTrM> listRecUpTrM = new ArrayList<RecUpTrM>();

    listRecUpTrM = recUpTrMMapper.selectByExample(recUpTrMExample);

    if (CollectionUtils.isEmpty(listRecUpTrM)) {
      // 例外をスロー
      LOGGER.error("指定された再エネ単価消費税改定マスタが見つかりません。エリアコード:{} 利用年月:{}", areaCd,
          StringConvertUtil.convertDateFormatAddDelimitor(usePeriod, ECISConstants.SLASH));

      throw new RateEngineException("指定された再エネ単価消費税改定マスタが見つかりません。エリアコード:{0} 利用年月:{1}", new String[] {areaCd,
          StringConvertUtil.convertDateFormatAddDelimitor(usePeriod, ECISConstants.SLASH) });
    }

    return listRecUpTrM.get(0);
  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.rate_engine.business.ChargeUpManagementBusiness#getFcaUpTrMForResetting(java.lang.String, java.lang.String, java.lang.String)
   */
  @Override
  public FcaUpTrM getFcaUpTrMForResetting(String areaCd, String voltageCatCode, String usePeriod)
      throws RateEngineException {

    FcaUpTrMExample fcaUpTrMExample = new FcaUpTrMExample();
    // エリアコード、電圧区分コード、利用年月を設定
    fcaUpTrMExample.createCriteria().andAreaCodeEqualTo(areaCd).andVoltageCatCodeEqualTo(voltageCatCode)
        .andUsePeriodEqualTo(usePeriod);
    List<FcaUpTrM> listFcaUpTrM = new ArrayList<FcaUpTrM>();

    listFcaUpTrM = fcaUpTrMMapper.selectByExample(fcaUpTrMExample);

    if (CollectionUtils.isEmpty(listFcaUpTrM)) {
      // 例外をスロー
      LOGGER.error("指定された燃調単価消費税改定マスタが見つかりません。エリアコード:{} 電圧区分:{} 利用年月:{}",
          areaCd, voltageCatCode,
          StringConvertUtil.convertDateFormatAddDelimitor(usePeriod, ECISConstants.SLASH));

      throw new RateEngineException("指定された燃調単価消費税改定マスタが見つかりません。エリアコード:{0} 電圧区分:{1} 利用年月:{2}", new String[] {
          areaCd, voltageCatCode,
          StringConvertUtil.convertDateFormatAddDelimitor(usePeriod, ECISConstants.SLASH) });
    }

    return listFcaUpTrM.get(0);
  }
}
