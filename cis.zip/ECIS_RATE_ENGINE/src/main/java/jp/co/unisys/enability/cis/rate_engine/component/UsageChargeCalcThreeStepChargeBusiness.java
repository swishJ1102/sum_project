package jp.co.unisys.enability.cis.rate_engine.component;

import java.math.BigDecimal;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import jp.co.unisys.enability.cis.common.Exception.RateEngineException;
import jp.co.unisys.enability.cis.common.util.rk.RateEngineCommonUtil;

/**
 * 従量料金計算（3段制）ビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class UsageChargeCalcThreeStepChargeBusiness implements FeeCalcParts {
  /** ロガー */
  private static final Logger LOGGER = LogManager.getLogger();

  /** この部品がサポートする固定パラメータ数 */
  private static final int ARG_LENGTH = 3;

  /**
   * 従量料金（3段制）の計算を行う。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された情報をもとに従量料金（3段制）を計算する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param args
   *          args[0]:Object 段料金使用量<br>
   *          args[1]:Object 段料金使用単価<br>
   *          args[2]:Object 燃料費調整額<br>
   * @return 従量料金[合計額、1...N段毎の従量料金]
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   * @see RateEngineCommonUtil#checkArgsLength(Object...)
   * @see RateEngineCommonUtil#convertToDecimals(Object...)
   * @see RateEngineCommonUtil#convertToDecimal(Object...)
   */
  @Override
  public Object[] calc(Object... args) throws RateEngineException {
    // 引数長チェック
    RateEngineCommonUtil.checkArgsLength(args, ARG_LENGTH);

    // 段料金使用量、段料金使用単価、燃料費調整額を数値型に変換
    BigDecimal[] usageAmount = RateEngineCommonUtil
        .convertToDecimals((Object[]) args[ArrayIndex.ZERO.ordinal()]);
    BigDecimal[] usageUnitPrice = RateEngineCommonUtil
        .convertToDecimals((Object[]) args[ArrayIndex.ONE.ordinal()]);
    BigDecimal fuelAdjustPrice = RateEngineCommonUtil
        .convertToDecimal(args[ArrayIndex.TWO.ordinal()]);

    // 料金を計算する
    BigDecimal usagePrice;
    BigDecimal sum = BigDecimal.ZERO;

    // 段使用量の数
    int iUsageAmountCount = usageAmount.length;
    Object[] prices = new Object[iUsageAmountCount + 1];

    // 段使用量の数分処理を行う
    for (int index = 0; index < iUsageAmountCount; index++) {
      // 使用量×単価
      usagePrice = usageAmount[index].multiply(usageUnitPrice[index]);
      prices[index + 1] = usagePrice;

      // 合計
      sum = sum.add(usagePrice);
    }

    // 合計（＋燃料費調整額）
    sum = sum.add(fuelAdjustPrice);
    prices[ArrayIndex.ZERO.ordinal()] = sum;

    // 段使用量の数分、デバッグログ出力
    for (int index = 0; index < iUsageAmountCount; index++) {
      LOGGER.debug("段料金使用量{} 段料金使用単価{} 料金{}", usageAmount[index],
          usageUnitPrice[index], prices[index]);
    }

    // デバッグログ出力
    LOGGER.debug("3段料金{}", sum);

    // 結果を返却
    return prices;
  }

}
