package jp.co.unisys.enability.cis.rate_engine.component;

import java.math.BigDecimal;
import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import jp.co.unisys.enability.cis.common.Exception.RateEngineException;
import jp.co.unisys.enability.cis.common.util.rk.RateEngineCommonUtil;

/**
 * 託送料金計算（二部料金制電灯標準メニューA）ビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class ConsignmentChargeCalcTwoPartChargeElecLightStandardMenuABusiness extends ChargeCalcBaseBusiness
    implements FeeCalcParts {
  /** ロガー */
  private static final Logger LOGGER = LogManager.getLogger();

  /** この部品がサポートする固定パラメータ数 */
  private static final int ARG_LENGTH = 18;

  /**
   * 二部料金制電灯標準メニュー（A）の託送料金の計算を行う。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された情報をもとに託送料金（二部料金制電灯標準(A)）を計算する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param args
   *          args[0]:Object 契約容量<br>
   *          args[1]:Object 段リスト<br>
   *          args[2]:Object 単価リスト<br>
   *          args[3]:Object 使用量<br>
   *          args[4]:Object 使用量単価<br>
   *          args[5]:Object 最低月額料金<br>
   *          args[6]:Object 検針日数<br>
   *          args[7]:Object 日割日数<br>
   *          args[8]:Object 丸め桁（内訳）<br>
   *          args[9]:Object 丸め方法（内訳）<br>
   *          args[10]:Object 丸め桁（合計）<br>
   *          args[11]:Object 丸め方法（合計）<br>
   *          args[12]:Object 算定期間開始日<br>
   *          args[13]:Object 算定期間終了日<br>
   *          args[14]:Object 契約開始日<br>
   *          args[15]:Object 契約終了日<br>
   *          args[16]:Object 基本料金無料有無<br>
   *          args[17]:Object 最低月額料金適用有無<br>
   * @return 託送料金[合計額、基本料金、従量料金、最低月額料金適用有無]
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   * @see RateEngineCommonUtil#checkArgsLength(Object...)
   * @see RateEngineCommonUtil#convertToDecimals(Object...)
   * @see RateEngineCommonUtil#convertStringToInt(Object...)
   * @see RateEngineCommonUtil#getRoundMode(Object...)
   */
  @Override
  public Object[] calc(Object... args) throws RateEngineException {
    // パラメータをデバッグログ出力
    LOGGER.debug("契約容量={} 契約容量1...N={} 基本料金単価1...N={} 使用量={} 使用量単価={} 最低月額料金={} 検針日数={} 日割日数={} "
        + "丸め桁(第三位)={} 丸め方法(第三位)={} 丸め桁(第一位)={} 丸め方法(第一位)={} 算定期間開始日={} 算定期間終了日={} "
        + "契約開始日={} 契約終了日={} 基本料金無料有無={} 最低月額料金適用有無={}",
        args[ArrayIndex.ZERO.ordinal()], args[ArrayIndex.ONE.ordinal()], args[ArrayIndex.TWO.ordinal()],
        args[ArrayIndex.THREE.ordinal()], args[ArrayIndex.FOUR.ordinal()], args[ArrayIndex.FIVE.ordinal()],
        args[ArrayIndex.SIX.ordinal()], args[ArrayIndex.SEVEN.ordinal()], args[ArrayIndex.EIGHT.ordinal()],
        args[ArrayIndex.NINE.ordinal()], args[ArrayIndex.TEN.ordinal()], args[ArrayIndex.ELEVEN.ordinal()],
        args[ArrayIndex.TWELEV.ordinal()], args[ArrayIndex.THIRTEEN.ordinal()],
        args[ArrayIndex.FOURTEEN.ordinal()],
        args[ArrayIndex.FIFTEEN.ordinal()], args[ArrayIndex.SIXTEEN.ordinal()],
        args[ArrayIndex.SEVENTEEN.ordinal()]);

    // 引数長チェック
    int[] nullPermitIndexs = new int[] {1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 };
    RateEngineCommonUtil.checkArgsLengthPermitNullVal(args, ARG_LENGTH, nullPermitIndexs);

    // 料金計算の準備
    Object[] argsBigDecimalPart = new Object[] {args[ArrayIndex.ZERO.ordinal()], args[ArrayIndex.THREE.ordinal()],
        args[ArrayIndex.FOUR.ordinal()], args[ArrayIndex.FIVE.ordinal()], args[ArrayIndex.SIX.ordinal()],
        args[ArrayIndex.SEVEN.ordinal()], args[ArrayIndex.EIGHT.ordinal()], args[ArrayIndex.NINE.ordinal()],
        args[ArrayIndex.TEN.ordinal()], args[ArrayIndex.ELEVEN.ordinal()] };
    BigDecimal[] decimals = RateEngineCommonUtil.convertToDecimals(argsBigDecimalPart);

    // 契約容量をチェックする。
    int priceIndex = RateEngineCommonUtil.getIndexByContractCapacity(decimals[ArrayIndex.ZERO.ordinal()],
        args[ArrayIndex.ONE.ordinal()]);
    if (priceIndex < 0) {
      LOGGER.error("ConsignmentChargeCalcTwoPartChargeElecLightStandardMenuABusiness＞契約容量が存在しません。容量={}",
          args[ArrayIndex.ZERO.ordinal()]);
      // 契約容量に該当する単価が存在しないため、料金の計算が行えません。契約容量:{0}
      throw new RateEngineException("error.E1327", decimals[ArrayIndex.ZERO.ordinal()].toString());
    }

    // 基本料金計算係数
    super.setBasicPriceCoefficient(decimals[ArrayIndex.ONE.ordinal()]);
    // 日割り率
    super.setPerDiemRate(decimals[ArrayIndex.FIVE.ordinal()], decimals[ArrayIndex.FOUR.ordinal()]);

    // 基本料金
    BigDecimal dcPrice = RateEngineCommonUtil.getContractCapacityPrice(priceIndex, args[ArrayIndex.TWO.ordinal()]);
    dcPrice = super.calcDCPrice(dcPrice, decimals[ArrayIndex.SIX.ordinal()], decimals[ArrayIndex.SEVEN.ordinal()]);

    // 初月無料であるか計算する
    dcPrice = super.getBasePrice(dcPrice, (Date) args[ArrayIndex.TWELEV.ordinal()],
        (Date) args[ArrayIndex.THIRTEEN.ordinal()], (Date) args[ArrayIndex.FOURTEEN.ordinal()],
        (Date) args[ArrayIndex.FIFTEEN.ordinal()], args[ArrayIndex.SIXTEEN.ordinal()].toString());

    // 従量料金（使用量、使用量単価、丸め桁(第三位)、丸め方法(第三位)）
    BigDecimal ecPrice = super.calcCharge(decimals[ArrayIndex.ONE.ordinal()], decimals[ArrayIndex.TWO.ordinal()],
        decimals[ArrayIndex.SIX.ordinal()], decimals[ArrayIndex.SEVEN.ordinal()]);

    // 最低月額料金（最低月額料金、丸め桁(第三位)、丸め方法(第三位)）
    BigDecimal lowestPrice = super.calcCharge(decimals[ArrayIndex.THREE.ordinal()],
        decimals[ArrayIndex.SIX.ordinal()], decimals[ArrayIndex.SEVEN.ordinal()]);

    // 合計額を算出（基本料金、従量料金、最低月額料金、丸め桁(第一位)、丸め方法(第一位)）
    Object[] result = super.getTotalPrice(dcPrice, ecPrice, lowestPrice,
        args[ArrayIndex.SEVENTEEN.ordinal()].toString(), decimals[ArrayIndex.EIGHT.ordinal()],
        decimals[ArrayIndex.NINE.ordinal()]);

    // デバッグログ出力
    LOGGER.debug("合計額={} 基本料金={} 従量料金={} 最低月額料金適用有無={}", result);

    // 結果を返却
    return result;
  }
}
