package jp.co.unisys.enability.cis.rate_engine.component;

import java.math.BigDecimal;
import java.util.Map;
import java.util.TreeMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import jp.co.unisys.enability.cis.common.Exception.RateEngineException;
import jp.co.unisys.enability.cis.common.util.rk.RateEngineCommonUtil;
import jp.co.unisys.enability.cis.entity.common.CalculatingTsUsage;

/**
 * 高圧季節別時間帯別ビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class HighVoltageUsageChargeCalcSeasonByTimeSlotByBusiness implements FeeCalcParts {
  /** ロガー */
  private static final Logger LOGGER = LogManager.getLogger();

  /** この部品がサポートする固定パラメータ数 */
  private static final int ARG_LENGTH = 3;

  /**
   * 高圧の料金計算（高圧一般、高圧季時別、高圧休日）を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された情報をもとに高圧の料金を計算する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param args
   *          args[0]:Object 使用量Map<br>
   *          args[1]:Object 単価Map<br>
   *          args[2]:Object 燃料費調整額<br>
   * @return 高圧料金[合計額、季節1時間帯1金額、季節1時間帯2金額、季節1時間帯3金額、季節1時間帯4金額....]戻り値は可変
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   * @see RateEngineCommonUtil#checkArgsLengthAndArgsNullVal(Object, int, boolean)
   */
  @Override
  public Object[] calc(Object... args) throws RateEngineException {

    // 引数長チェック
    RateEngineCommonUtil.checkArgsLengthAndArgsNullVal(args, ARG_LENGTH, true);

    // 使用量Mapの取得
    TreeMap<String, BigDecimal> usageQuantityMap = convertToMapUsageQuantity(args[0]);

    // 使用量Mapの要素数が0の場合
    if (usageQuantityMap.size() == 0) {
      throw new RateEngineException("error.E1551", new String[] {"0" });
    }

    // 単価Mapの取得
    TreeMap<String, BigDecimal> upMap = convertToMapUp(args[1]);

    BigDecimal[] sumResult = new BigDecimal[usageQuantityMap.size() + 1];

    sumResult[0] = BigDecimal.valueOf(0);

    // ループ回数 ※0には合計が入るため、1からで問題ない。
    Integer roopCount = 1;

    //Mapのキーとバリューの型チェック
    for (Map.Entry<String, BigDecimal> mapDetail : usageQuantityMap.entrySet()) {
      // 単価の取得
      if (!(upMap.containsKey(mapDetail.getKey()))) {

        throw new RateEngineException("error.E1552", mapDetail.getKey());
      }

      //使用量*単価の計算
      BigDecimal sum = mapDetail.getValue().multiply(upMap.get(mapDetail.getKey()));
      //時間帯別単位の結果格納
      sumResult[roopCount] = sum;
      //総合計金額算出
      sumResult[0] = sum.add(sumResult[0]);

      roopCount = roopCount + 1;

      LOGGER.debug("時間帯別コード{} 使用量{} 単価{} 計算金額{}", mapDetail.getKey(),
          mapDetail.getValue(), upMap.get(mapDetail.getKey()), sum);

    }

    // 燃料費調整額を総合計金額に加算
    sumResult[0] = sumResult[0].add(RateEngineCommonUtil.convertToDecimal(args[2]));

    // デバッグログ出力
    LOGGER.debug("合計金額{}", sumResult[0]);

    Object[] prices = new Object[roopCount];
    // 計算結果の詰め替え
    for (int index = 0; index < roopCount; index++) {
      prices[index] = sumResult[index];
    }

    return prices;
  }

  /**
   * 使用量Mapの型変換を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定されたオブジェクトの型をMap形式に詰め替える。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param args:Object
   *          使用量Map<br>
   *
   * @return 使用量Map
   */
  private TreeMap<String, BigDecimal> convertToMapUsageQuantity(Object args) throws RateEngineException {

    TreeMap<String, BigDecimal> calculatingTsUsagemap = new TreeMap<String, BigDecimal>();

    //渡ってきたオブジェクトがTreeMapか確認
    if (!(args instanceof Map<?, ?>)) {
      LOGGER.error("HighVoltageUsageChargeCalcSeasonByTimeSlotByBusiness＞変換エラー 対象={}", args.getClass().getName());
      // Mapに変換できない文字列です。文字列:{0}
      throw new RateEngineException("error.E1556", new String[] {"Map", args.getClass().getName() });
    }

    @SuppressWarnings("unchecked")
    Map<String, CalculatingTsUsage> map = (Map<String, CalculatingTsUsage>) args;

    //TreeMapのキーとバリューの型チェック
    for (Map.Entry<String, CalculatingTsUsage> mapDetail : map.entrySet()) {

      calculatingTsUsagemap.put(mapDetail.getKey(), mapDetail.getValue().getUsageQuantity());
    }

    return calculatingTsUsagemap;
  }

  /**
   * 単価Mapの型変換を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定されたオブジェクトの型をMap形式に詰め替える。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param args:Object
   *          単価Map<br>
   *
   * @return 単価Map
   */
  private TreeMap<String, BigDecimal> convertToMapUp(Object args) throws RateEngineException {

    TreeMap<String, BigDecimal> upMap = new TreeMap<String, BigDecimal>();

    //渡ってきたオブジェクトがTreeMapか確認
    if (!(args instanceof TreeMap<?, ?>)) {
      LOGGER.error("HighVoltageUsageChargeCalcSeasonByTimeSlotByBusiness＞変換エラー 対象={}", args.getClass().getName());
      // TreeMapに変換できない文字列です。文字列:{0}
      throw new RateEngineException("error.E1556", new String[] {"TreeMap", args.getClass().getName() });
    }
    @SuppressWarnings("unchecked")
    TreeMap<String, BigDecimal> map = (TreeMap<String, BigDecimal>) args;

    //TreeMapのキーとバリューの型チェック
    for (Map.Entry<String, BigDecimal> mapDetail : map.entrySet()) {
      upMap.put(mapDetail.getKey(), mapDetail.getValue());
    }

    return upMap;
  }

}
