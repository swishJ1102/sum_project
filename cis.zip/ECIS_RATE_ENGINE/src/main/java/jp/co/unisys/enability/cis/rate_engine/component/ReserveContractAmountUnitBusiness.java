package jp.co.unisys.enability.cis.rate_engine.component;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import jp.co.unisys.enability.cis.common.Exception.RateEngineException;
import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;
import jp.co.unisys.enability.cis.common.util.rk.RateEngineCommonUtil;
import jp.co.unisys.enability.cis.rate_engine.engine.CalcPartsFactory;

/**
 * 予備契約金額単価ビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class ReserveContractAmountUnitBusiness extends ChargeCalcBaseBusiness
    implements FeeCalcParts {
  /** ロガー */
  private static final Logger LOGGER = LogManager.getLogger();

  /** この部品がサポートする固定パラメータ数 */
  private static final int ARG_LENGTH = 8;

  /**
   * 予備契約金額単価の計算を行う。<br>
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   *
   * 引数で指定された情報をもとに"日割前予備契約基本料金（単価）と予備契約基本料金（単価）を計算する。
   * ※引数の「予備契約開始日」と「契約容量」と「予備単価」と「予備契約種別」と「日割日数」の配列数は同じである。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param args
   *          args[0]:Object (Date[0]…[N]) 予備契約開始日リスト<br>
   *          args[1]:Object (BigDecimal[0]…[N]) 契約容量リスト<br>
   *          args[2]:Object (BigDecimal[0]…[N]) 予備単価リスト<br>
   *          args[3]:Object (String[0]…[N]) 予備契約種別リスト<br>
   *          args[4]:Object (BigDecimal[0]…[N]) 日割日数リスト<br>
   *          args[5]:Object 検針日数<br>
   *          args[6]:Object 丸め桁<br>
   *          args[7]:Object 丸め方法<br>
   * @return 計算結果配列 [予備契約種別配列、予備契約開始日配列、予備契約基本料金配列、日割前予備契約基本料金配列、契約容量配列]
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   * @see RateEngineCommonUtil#checkArgLength(Object...)
   * @see RateEngineCommonUtil#convertToDecimal(Object...)
   * @see RateEngineCommonUtil#convertToDecimals(Object...)
   */
  @Override
  public Object[] calc(Object... args) throws RateEngineException {

    // 引数長チェック
    RateEngineCommonUtil.checkArgsLength(args, ARG_LENGTH);

    // 検針日数
    BigDecimal mDays = RateEngineCommonUtil.convertToDecimal((Object) args[ArrayIndex.FIVE.ordinal()]);
    // 丸め桁
    BigDecimal scale = RateEngineCommonUtil.convertToDecimal((Object) args[ArrayIndex.SIX.ordinal()]);
    // 丸め方法
    BigDecimal rMode = RateEngineCommonUtil.convertToDecimal((Object) args[ArrayIndex.SEVEN.ordinal()]);

    // 検針日数をチェック
    if (BigDecimal.ZERO.compareTo(mDays) == 0) {
      // 検針日数が0のため、料金の計算が行えません。
      throw new RateEngineException("error.E1326");
    }

    // 予備契約基本料金リストを生成
    List<Object> priceLineList = new ArrayList<Object>();

    // 日割前予備契約基本料金リストを生成
    List<Object> priceBeforeList = new ArrayList<Object>();

    // 予備契約開始日配列
    Date[] reserveContractSdList = Arrays.stream((Object[]) args[ArrayIndex.ZERO.ordinal()]).toArray(Date[]::new);

    // 予備契約種別配列
    String[] classList = Arrays.stream((Object[]) args[ArrayIndex.THREE.ordinal()]).toArray(String[]::new);

    // 契約容量配列
    BigDecimal[] capacityList = RateEngineCommonUtil.convertToDecimals((Object[]) args[ArrayIndex.ONE.ordinal()]);
    // 予備単価配列
    BigDecimal[] costList = RateEngineCommonUtil.convertToDecimals((Object[]) args[ArrayIndex.TWO.ordinal()]);
    // 日割日数配列
    BigDecimal[] dayList = RateEngineCommonUtil.convertToDecimals((Object[]) args[ArrayIndex.FOUR.ordinal()]);

    // 予備契約基本料金を計算する
    CalcPartsFactory calcPartsFactory = new CalcPartsFactory();
    FeeCalcParts parts = calcPartsFactory.getParts(Round.class.getSimpleName());

    for (int i = 0; i < reserveContractSdList.length; i++) {

      // 予備契約基本料金を計算して四捨五入・切上げ・切捨て部品.計算処理を呼び出し端数処理を行う。
      // 処理対象:契約容量配列[n] × 予備単価配列[n] × 日割日数配列[n] ／ 検針日数(除算時小数桁6桁以下を切り捨て)
      Object[] calcRet = parts.calc(
          capacityList[i].multiply(costList[i]).multiply(dayList[i])
              .divide(mDays, ECISRKConstants.DIVIDE_DECIMAL_SCALE, ECISRKConstants.ROUNDMODE_DOWN),
          scale, rMode);
      priceLineList.add((BigDecimal) calcRet[ArrayIndex.ZERO.ordinal()]);

      // 日割前予備契約基本料金を計算して四捨五入・切上げ・切捨て部品.計算処理を呼び出し端数処理を行う。
      // 処理対象:契約容量配列[n] × 予備単価配列[n]
      Object[] calcRetBefore = parts.calc(capacityList[i].multiply(costList[i]),
          scale, rMode);
      priceBeforeList.add((BigDecimal) calcRetBefore[ArrayIndex.ZERO.ordinal()]);
    }

    // 予備契約基本料金リストを配列変換
    BigDecimal[] priceLine = RateEngineCommonUtil.convertToDecimals(priceLineList.toArray());

    // 日割前予備契約基本料金リストを配列変換
    BigDecimal[] priceBefore = RateEngineCommonUtil.convertToDecimals(priceBeforeList.toArray());

    // デバッグログ出力
    LOGGER.debug("予備契約種別配列={} 予備契約開始日配列={} 予備契約基本料金配列={} 日割前予備契約基本料金配列={} 契約容量配列={}",
        classList, reserveContractSdList, priceLine, priceBefore, capacityList);

    // 結果を返却
    return new Object[] {classList, reserveContractSdList, priceLine, priceBefore, capacityList };
  }

}
