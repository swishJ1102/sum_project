package jp.co.unisys.enability.cis.rate_engine.component;

import java.math.BigDecimal;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import jp.co.unisys.enability.cis.common.Exception.RateEngineException;
import jp.co.unisys.enability.cis.common.util.rk.RateEngineCommonUtil;

/**
 * 減算。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class Subtract implements FeeCalcParts {
  /** ロガー */
  private static final Logger LOGGER = LogManager.getLogger();

  /**
   * 減算（四則演算）を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数の値をBigDecimal型に変換した後、全て引数の値を減算した結果を返却する。
   * </pre>
   * 
   * @param args
   *          引数(可変長)<br>
   *          args[0]:Object 減算元の数値<br>
   *          args[1]:Object 減算する数値1<br>
   *          args[2]:Object 減算する数値2<br>
   *          args[n]:Object 減算する数値n<br>
   * @return 計算結果(配列の要素数は1固定)
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   * @see RateEngineCommonUtil#convertToDecimals(Object...)
   */
  @Override
  public Object[] calc(Object... args) throws RateEngineException {
    // 引数を変換
    BigDecimal[] decimals = RateEngineCommonUtil.convertToDecimals(args);

    BigDecimal calced = decimals[ArrayIndex.ZERO.ordinal()];
    // 引数の数分、演算
    for (int i = 1; i < decimals.length; i++) {
      calced = calced.subtract(decimals[i]);
    }

    // デバッグログ出力
    LOGGER.debug("減算結果={}", calced.toString());

    Object[] ret = new Object[1];
    ret[0] = calced;
    // 結果を返却
    return ret;
  }
}
