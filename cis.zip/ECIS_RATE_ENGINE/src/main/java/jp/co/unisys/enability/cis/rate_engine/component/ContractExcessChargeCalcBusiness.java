package jp.co.unisys.enability.cis.rate_engine.component;

import java.math.BigDecimal;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import jp.co.unisys.enability.cis.common.Exception.RateEngineException;
import jp.co.unisys.enability.cis.common.util.constants.ECISCodeConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;
import jp.co.unisys.enability.cis.common.util.rk.RateEngineCommonUtil;

/**
 * 契約超過金計算ビジネス
 *
 * @author "Nihon Unisys, Ltd."
 */
public class ContractExcessChargeCalcBusiness extends ChargeCalcBaseBusiness implements FeeCalcParts {
  /** ロガー */
  private static final Logger LOGGER = LogManager.getLogger();

  /** この部品がサポートする固定パラメータ数 */
  private static final int ARG_LENGTH = 14;

  /** 表示名称2生成フラグ */
  private static final String DISPLAY_NAME2_FLG = "1";

  /**
   * 契約超過金計算を行う<br>
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された情報をもとに契約超過金を計算する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param args
   *          args[0]:Object 基本料金単価<br>
   *          args[1]:Object 最大電力<br>
   *          args[2]:Object 契約容量<br>
   *          args[3]:Object 力率<br>
   *          args[4]:Object 検針日数<br>
   *          args[5]:Object 日割日数<br>
   *          args[6]:Object 倍率<br>
   *          args[7]:Object 丸め桁<br>
   *          args[8]:Object 丸め方法<br>
   *          args[9]:Object 契約電力決定区分<br>
   *          args[10]:Object 日割個数<br>
   *          args[11]:Object 表示名称1<br>
   *          args[12]:Object 表示名称2<br>
   *          args[13]:Object 表示名称2生成フラグ<br>
   * @return 契約超過金[契約超過金,契約超過電力,基本料金単価,表示名称1,表示名称2]
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   * @see RateEngineCommonUtil#checkArgsLengthPermitNullVal(Object...)
   * @see RateEngineCommonUtil#convertToDecimals(Object...)
   * @see RateEngineCommonUtil#getRoundMode(Object...)
   */
  @Override
  public Object[] calc(Object... args) throws RateEngineException {
    // パラメータをデバッグログ出力
    LOGGER.debug("基本料金単価={} 最大電力={} 契約容量={} 力率={} 検針日数={} 日割日数={} 倍率={} 丸め桁={} "
        + "丸め方法={} 契約電力決定区分={} 日割個数={} 表示名称1={} 表示名称2={} 表示名称2生成フラグ={} ",
        args[ArrayIndex.ZERO.ordinal()], args[ArrayIndex.ONE.ordinal()], args[ArrayIndex.TWO.ordinal()],
        args[ArrayIndex.THREE.ordinal()], args[ArrayIndex.FOUR.ordinal()], args[ArrayIndex.FIVE.ordinal()],
        args[ArrayIndex.SIX.ordinal()], args[ArrayIndex.SEVEN.ordinal()], args[ArrayIndex.EIGHT.ordinal()],
        args[ArrayIndex.NINE.ordinal()], args[ArrayIndex.TEN.ordinal()], args[ArrayIndex.ELEVEN.ordinal()],
        args[ArrayIndex.TWELEV.ordinal()], args[ArrayIndex.THIRTEEN.ordinal()]);

    // 引数長チェック
    int[] nullPermitIndexs = new int[] {1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1 };
    RateEngineCommonUtil.checkArgsLengthPermitNullVal(args, ARG_LENGTH, nullPermitIndexs);

    // 数値変換
    BigDecimal[] decimals = RateEngineCommonUtil.convertToDecimals(args[ArrayIndex.ZERO.ordinal()],
        args[ArrayIndex.ONE.ordinal()], args[ArrayIndex.TWO.ordinal()],
        args[ArrayIndex.THREE.ordinal()], args[ArrayIndex.FOUR.ordinal()], args[ArrayIndex.FIVE.ordinal()],
        args[ArrayIndex.SIX.ordinal()], args[ArrayIndex.SEVEN.ordinal()], args[ArrayIndex.EIGHT.ordinal()],
        args[ArrayIndex.TEN.ordinal()]);

    // 契約超過電力
    BigDecimal contractExcessPower = BigDecimal.ZERO;
    // 契約超過金
    BigDecimal contractExcessCharge = BigDecimal.ZERO;

    // 契約超過金計算実施判定
    // 契約電力決定区分 ＝ '1'
    if (ECISCodeConstants.CONTRACT_CAPACITY_DECISION_CATEGORY_CODE_DISCUSSIONS.equals(args[ArrayIndex.NINE.ordinal()])
        // 日割個数 ＝ 1
        && BigDecimal.ONE.equals(decimals[ArrayIndex.NINE.ordinal()])
        // 最大電力＞ 契約容量
        && decimals[ArrayIndex.ONE.ordinal()].compareTo(decimals[ArrayIndex.TWO.ordinal()]) > 0) {

      // 契約超過電力の設定を行う
      // 最大電力 - 契約容量
      contractExcessPower = decimals[ArrayIndex.ONE.ordinal()].subtract(decimals[ArrayIndex.TWO.ordinal()]);

      // 力率割引割増率の算出
      // 力率割引割増率
      BigDecimal calcPorwerRate = null;
      // 力率が0だった場合
      if (BigDecimal.ZERO.equals(decimals[ArrayIndex.THREE.ordinal()])) {
        // 1.0を設定
        calcPorwerRate = BigDecimal.ONE;
      } else {
        // ％から小数に
        calcPorwerRate = decimals[ArrayIndex.THREE.ordinal()].divide(ECISRKConstants.RATE_DIVIDE_VAL);
        // 1 - (力率-0.85)
        calcPorwerRate = BigDecimal.ONE
            .subtract(calcPorwerRate.subtract(new BigDecimal(ECISRKConstants.POWER_FACTOR_EIGHTY_FIVE)
                .divide(ECISRKConstants.RATE_DIVIDE_VAL)));
      }

      // 日割率の設定
      super.setPerDiemRate(decimals[ArrayIndex.FIVE.ordinal()], decimals[ArrayIndex.FOUR.ordinal()]);

      // 契約超過金の計算を行う
      // 契約超過電力×基本料金単価×力率割引割増率×倍率×日割率
      contractExcessCharge = super.calcCharge(contractExcessPower.multiply(decimals[ArrayIndex.ZERO.ordinal()])
          .multiply(calcPorwerRate).multiply(decimals[ArrayIndex.SIX.ordinal()]),
          decimals[ArrayIndex.SEVEN.ordinal()], decimals[ArrayIndex.EIGHT.ordinal()]);
    }

    // 表示名称2設定
    String displayName2 = null;
    // 表示名称2生成フラグが"1"の場合、表示名称2と倍率を文字列結合する
    if (DISPLAY_NAME2_FLG.equals(args[ArrayIndex.THIRTEEN.ordinal()])) {
      StringBuilder str = new StringBuilder();
      str.append(args[ArrayIndex.TWELEV.ordinal()]);
      str.append(decimals[ArrayIndex.SIX.ordinal()]);
      displayName2 = str.toString();
    }

    // デバッグログ出力
    LOGGER.debug("契約超過金= {} 契約超過電力= {} 基本料金単価= {} 表示名称1= {} 表示名称2={}",
        contractExcessCharge.toString(), contractExcessPower.toString(), decimals[ArrayIndex.ZERO.ordinal()],
        args[ArrayIndex.ELEVEN.ordinal()], displayName2);

    // 結果を返却
    return new Object[] {contractExcessCharge, contractExcessPower, decimals[ArrayIndex.ZERO.ordinal()],
        args[ArrayIndex.ELEVEN.ordinal()], displayName2 };
  }
}
