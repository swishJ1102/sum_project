package jp.co.unisys.enability.cis.rate_engine.component;

import java.math.BigDecimal;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import jp.co.unisys.enability.cis.common.Exception.RateEngineException;
import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;
import jp.co.unisys.enability.cis.common.util.rk.RateEngineCommonUtil;

/**
 * 丸め。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class Round implements FeeCalcParts {
  /** ロガー */
  private static final Logger LOGGER = LogManager.getLogger();

  /** この部品がサポートする固定パラメータ数 */
  private static final int ARG_LENGTH = 3;

  /**
   * 丸め処理を行う。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 丸め処理を計算する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param args
   *          args[0]:Object 処理対象<br>
   *          args[1]:Object 丸め桁<br>
   *          args[2]:Object 丸め方法<br>
   * @return 計算結果(BigDecimal型 配列の要素数は1固定)
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   * @see RateEngineCommonUtil#checkArgsLength(Object...)
   * @see RateEngineCommonUtil#convertToDecimals(Object...)
   * @see RateEngineCommonUtil#convertStringToInt(Object...)
   * @see RateEngineCommonUtil#getRoundMode(Object...)
   */
  @Override
  public Object[] calc(Object... args) throws RateEngineException {
    // デバッグログ出力
    LOGGER.debug("小数点桁数丸め処理 処理前={} 小数点以下桁数={} 丸めモード={}", args[0], args[2], args[1]);

    // 引数チェック
    RateEngineCommonUtil.checkArgsLength(args, ARG_LENGTH);

    // 引数を変換
    BigDecimal[] decimals = RateEngineCommonUtil.convertToDecimals(args);

    // 丸め桁と丸め方法
    int scale = decimals[ArrayIndex.ONE.ordinal()].intValue();
    int roundMode = RateEngineCommonUtil.getRoundMode(decimals[ArrayIndex.TWO.ordinal()].intValue());
    // 丸め処理
    BigDecimal scaled = BigDecimal.ZERO;
    if (roundMode == ECISRKConstants.ROUNDMODE_OFF) {
      scaled = decimals[ArrayIndex.ZERO.ordinal()];
    } else {
      scaled = decimals[ArrayIndex.ZERO.ordinal()].setScale(scale, roundMode);
    }

    // デバッグログ出力
    LOGGER.debug("小数点桁数丸め処理 処理後={}", scaled.toString());

    // 結果を返却
    return new BigDecimal[] {scaled };
  }
}
