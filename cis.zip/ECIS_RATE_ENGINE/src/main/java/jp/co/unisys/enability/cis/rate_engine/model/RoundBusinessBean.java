package jp.co.unisys.enability.cis.rate_engine.model;

/**
 * 丸め情報管理ビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RoundBusinessBean {

  /**
   * 丸めキーを保有する。
   */
  private String roundKey;

  /**
   * 丸め桁を保有する。
   */
  private String roundDigit;

  /**
   * 丸め方法を保有する。
   */
  private String roundMethod;

  /**
   * 丸めキーのgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 丸めキー
   */
  public String getRoundKey() {
    return this.roundKey;
  }

  /**
   * 丸めキーのsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param roundKey
   *          丸めキー
   */
  public void setRoundKey(String roundKey) {
    this.roundKey = roundKey;
  }

  /**
   * 丸め桁のgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 丸め桁
   */
  public String getRoundDigit() {
    return this.roundDigit;
  }

  /**
   * 丸め桁のsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param roundDigit
   *          丸め桁
   */
  public void setRoundDigit(String roundDigit) {
    this.roundDigit = roundDigit;
  }

  /**
   * 丸め方法のgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 丸め方法
   */
  public String getRoundMethod() {
    return this.roundMethod;
  }

  /**
   * 丸め方法のsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param roundMethod
   *          丸め方法
   */
  public void setRoundMethod(String roundMethod) {
    this.roundMethod = roundMethod;
  }

}
