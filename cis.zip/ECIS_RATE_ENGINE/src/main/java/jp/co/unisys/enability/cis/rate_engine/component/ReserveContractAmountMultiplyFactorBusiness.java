package jp.co.unisys.enability.cis.rate_engine.component;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import jp.co.unisys.enability.cis.common.Exception.RateEngineException;
import jp.co.unisys.enability.cis.common.util.constants.ECISKJConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;
import jp.co.unisys.enability.cis.common.util.rk.RateEngineCommonUtil;
import jp.co.unisys.enability.cis.rate_engine.engine.CalcPartsFactory;

/**
 * 予備契約金額掛率ビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class ReserveContractAmountMultiplyFactorBusiness extends
    ChargeCalcBaseBusiness implements FeeCalcParts {
  /** ロガー */
  private static final Logger LOGGER = LogManager.getLogger();

  /** この部品がサポートする固定パラメータ数 */
  private static final int ARG_LENGTH = 7;

  /** 掛率 予備線 0.05 */
  private static final BigDecimal HANG_RATE_LINE = BigDecimal.valueOf(0.05);

  /** 掛率 予備電源 0.1 */
  private static final BigDecimal HANG_RATE_POWER = BigDecimal.valueOf(0.1);

  /** 予備契約容量（ダミー） **/
  private static final BigDecimal DUMMY_CONTRACT_CAPACITY = BigDecimal.valueOf(-1L);

  /**
   * 予備契約金額掛率の計算を行う。<br>
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   *
   * 引数で指定された情報をもとに"予備線"と"予備電源"の予備契約基本料金（掛率）を計算する。
   * ※引数の「予備契約種別」で"予備線"と"予備電源"を判断する。
   * また、「予備契約種別」で設定されていない種別の戻り値はNULLとする。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param args
   *          args[0]:Object 基本料金<br>
   *          args[1]:Object (Date[0]…[N]) 予備契約開始日リスト<br>
   *          args[2]:Object (String[0]…[N]) 予備契約種別リスト<br>
   *          args[3]:Object 丸め桁<br>
   *          args[4]:Object 丸め方法<br>
   *          args[5]:Object (BigDecimal[0]…[N]) 日割日数リスト<br>
   *          args[6]:Object 検針日数<br>
   *          :
   * @return 計算結果配列[予備契約種別配列、予備契約開始日配列、予備契約基本料金配列、日割前予備契約基本料金配列、契約容量配列（ダミー）]<br/>
   *         <br/>
   *         ※掛率制予備契約では契約容量は使用しないが、単価制予備契約のために予備契約金額加算ビジネスの引数を増加した関係でエラーにならないようダミーとして用意。<br/>
   *         ※ダミーのため、掛率制予備契約では計算結果内訳の表示などには使用しないこと（契約種別計算明細TBLの設定注意）
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   * @see RateEngineCommonUtil#checkArgsLength(Object...)
   * @see RateEngineCommonUtil#convertToDecimal(Object...)
   */
  @Override
  public Object[] calc(Object... args) throws RateEngineException {

    // 引数長チェック
    RateEngineCommonUtil.checkArgsLength(args, ARG_LENGTH);

    // 基本料金
    BigDecimal base = RateEngineCommonUtil.convertToDecimal((Object) args[ArrayIndex.ZERO.ordinal()]);
    // 丸め桁
    BigDecimal scale = RateEngineCommonUtil.convertToDecimal((Object) args[ArrayIndex.THREE.ordinal()]);
    // 丸め方法
    BigDecimal rMode = RateEngineCommonUtil.convertToDecimal((Object) args[ArrayIndex.FOUR.ordinal()]);
    // 検針日数
    BigDecimal mDays = RateEngineCommonUtil.convertToDecimal((Object) args[ArrayIndex.SIX.ordinal()]);

    // 検針日数をチェック
    if (BigDecimal.ZERO.compareTo(mDays) == 0) {
      // 検針日数が0のため、料金の計算が行えません。
      throw new RateEngineException("error.E1326");
    }

    // 予備契約基本料金リストを生成
    List<Object> priceLineList = new ArrayList<Object>();

    // 日割前予備契約基本料金リストを生成
    List<Object> priceBeforeList = new ArrayList<Object>();

    // 予備契約開始日配列
    Date[] reserveContractSdList = Arrays.stream((Object[]) args[ArrayIndex.ONE.ordinal()]).toArray(Date[]::new);

    // 予備契約種別配列
    String[] classList = Arrays.stream((Object[]) args[ArrayIndex.TWO.ordinal()]).toArray(String[]::new);

    // 日割日数配列
    BigDecimal[] dayList = RateEngineCommonUtil.convertToDecimals((Object[]) args[ArrayIndex.FIVE.ordinal()]);

    // 予備契約容量配列（ダミー）
    BigDecimal[] reserveContractCapacityList = new BigDecimal[reserveContractSdList.length];

    // 予備契約基本料金を計算する
    CalcPartsFactory calcPartsFactory = new CalcPartsFactory();
    FeeCalcParts parts = calcPartsFactory.getParts(Round.class.getSimpleName());

    for (int i = 0; i < reserveContractSdList.length; i++) {
      // 予備線の場合
      if (ECISKJConstants.RESERVE_CONTRACT_CLASS_LINE.equals(classList[i])) {
        // 予備線基本料金を計算して四捨五入・切上げ・切捨て部品.計算処理を呼び出し端数処理を行う。
        // 処理対象:引数.基本料金 × 0.05 × 日割日数配列[n] ／ 検針日数(除算時小数桁6桁以下を切り捨て)）
        Object[] calcRet = parts.calc(base.multiply(HANG_RATE_LINE).multiply(dayList[i])
            .divide(mDays, ECISRKConstants.DIVIDE_DECIMAL_SCALE, ECISRKConstants.ROUNDMODE_DOWN), scale, rMode);
        priceLineList.add((BigDecimal) calcRet[ArrayIndex.ZERO.ordinal()]);

        // 日割前予備線基本料金を計算して四捨五入・切上げ・切捨て部品.計算処理を呼び出し端数処理を行う。
        // 処理対象:引数.基本料金 × 0.05）
        Object[] calcRetBefore = parts.calc(base.multiply(HANG_RATE_LINE), scale, rMode);
        priceBeforeList.add((BigDecimal) calcRetBefore[ArrayIndex.ZERO.ordinal()]);
      }

      // 予備電源の場合
      if (ECISKJConstants.RESERVE_CONTRACT_CLASS_POWER.equals(classList[i])) {
        // 予備電源基本料金を計算して四捨五入・切上げ・切捨て部品.計算処理を呼び出し端数処理を行う。
        // 処理対象:（引数.基本料金 × 0.1 × 日割日数配列[n] ／ 検針日数(除算時小数桁6桁以下を切り捨て)）
        Object[] calcRet = parts.calc(base.multiply(HANG_RATE_POWER).multiply(dayList[i])
            .divide(mDays, ECISRKConstants.DIVIDE_DECIMAL_SCALE, ECISRKConstants.ROUNDMODE_DOWN), scale, rMode);
        priceLineList.add((BigDecimal) calcRet[ArrayIndex.ZERO.ordinal()]);

        // 日割前予備電源基本料金を計算して四捨五入・切上げ・切捨て部品.計算処理を呼び出し端数処理を行う。
        // 処理対象:（引数.基本料金 × 0.1）
        Object[] calcRetBefore = parts.calc(base.multiply(HANG_RATE_POWER), scale, rMode);
        priceBeforeList.add((BigDecimal) calcRetBefore[ArrayIndex.ZERO.ordinal()]);
      }

      // 予備契約容量配列にダミーの値を設定
      reserveContractCapacityList[i] = DUMMY_CONTRACT_CAPACITY;
    }

    // 予備契約基本料金リスト、日割前予備契約基本料金リストを配列変換
    BigDecimal[] priceLine = RateEngineCommonUtil.convertToDecimals(priceLineList.toArray());
    BigDecimal[] priceBefore = RateEngineCommonUtil.convertToDecimals(priceBeforeList.toArray());

    // デバッグログ出力
    LOGGER.debug("予備契約種別配列={} 予備契約開始日配列={} 予備契約基本料金配列={} 日割前予備契約基本料金配列={} 契約容量配列（ダミー）={}",
        classList, reserveContractSdList, priceLine, priceBefore, reserveContractCapacityList);

    // 結果を返却
    return new Object[] {classList, reserveContractSdList, priceLine, priceBefore, reserveContractCapacityList };
  }

}
