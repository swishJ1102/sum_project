package jp.co.unisys.enability.cis.rate_engine.component;

import java.util.List;

import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;
import jp.co.unisys.enability.cis.entity.common.CalculatingDsUsage;
import jp.co.unisys.enability.cis.rate_engine.model.RK_CalculatingWarningCheckBusinessBean;

/**
 * BRK0103-10メニュー変更チェックビジネス
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_ChangedRateMenuCheckBusiness {

  /**
   * メニュー変更チェック
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計算用日割別使用量リストの全レコードの料金メニューIDが計算用使用量の料金メニューIDと同じかチェックを行う。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param calculatingWarningCheckBusinessBean
   *          《料金計算中警告チェックビジネスBean》
   * @return 警告コード
   */
  public String check(RK_CalculatingWarningCheckBusinessBean calculatingWarningCheckBusinessBean) {

    // 《料金計算中警告チェックビジネスBean》.計算用使用量．料金メニューIDを取得
    String rmId = calculatingWarningCheckBusinessBean.getCalculatingUsage().getRmId();

    if (rmId == null) {
      // メニュー変更あり
      return ECISRKConstants.WARNING_CLASS_MASTER_CALC_MENU_CHANGE;
    }

    List<CalculatingDsUsage> calculatingDateSlotUsage = calculatingWarningCheckBusinessBean.getCalculatingDateSlotUsage();

    for (CalculatingDsUsage calcDsu : calculatingDateSlotUsage) {
      // 計算用使用量の料金メニューIDと計算用日割別使用量リスト内の料金メニューIDのチェック
      if (!rmId.equals(calcDsu.getRmId())) {
        // メニュー変更あり
        return ECISRKConstants.WARNING_CLASS_MASTER_CALC_MENU_CHANGE;
      }
    }

    return null;
  }
}
