package jp.co.unisys.enability.cis.rate_engine.component;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import jp.co.unisys.enability.cis.common.Exception.RateEngineException;
import jp.co.unisys.enability.cis.common.util.constants.ECISCodeConstants;
import jp.co.unisys.enability.cis.common.util.rk.RateEngineCommonUtil;
import jp.co.unisys.enability.cis.rate_engine.engine.CalcPartsFactory;

/**
 * 制限中止割引金額部品ビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RestrictionDiscountInfoAmountPartstBusiness extends ChargeCalcBaseBusiness
    implements FeeCalcParts {
  /** ロガー */
  private static final Logger LOGGER = LogManager.getLogger();

  /** この部品がサポートする固定パラメータ数 */
  private static final int ARG_LENGTH = 10;

  /** 掛率 協議制 0.002 */
  private static final BigDecimal HANG_RATE_DISCUSSIONS = BigDecimal.valueOf(0.002);

  /** 掛率 実量制 0.04 */
  private static final BigDecimal HANG_RATE_REALQUANTITY = BigDecimal.valueOf(0.04);

  /**
   * 制限中止割引金額部品。<br>
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   *
   * 引数で指定された情報をもとに制限中止割引額を計算する。<br>
   * ※引数の「基本料金」と「予備契約開始日」と「予備契約終了日」の配列数は同じである。
   * ※引数の「算定期間開始日」と「契約決定区分」と「制限中止日数」と「制限中止時間数」の配列数は同じである。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param args
   *          args[0]:Object (BigDecimal[0]…[M]) 基本料金リスト<br>
   *          args[1]:Object (Date[0]…[M]) 予備契約開始日リスト<br>
   *          args[2]:Object (Date[0]…[M]) 予備契約終了日リスト<br>
   *          args[3]:Object (Date[0]…[N]) 算定期間開始日リスト<br>
   *          args[4]:Object (String[0]…[N]) 契約決定区分リスト<br>
   *          args[5]:Object (BigDecimal[0]…[N]) 制限中止日数リスト<br>
   *          args[6]:Object (BigDecimal[0]…[N]) 制限中止時間数リスト<br>
   *          args[7]:Object 電圧区分コード<br>
   *          args[8]:Object 丸め桁<br>
   *          args[9]:Object 丸め方法<br>
   *          (※1)日割を行う前の対象基本料金
   * @return 計算結果配列[制限中止割引額]
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   * @see RateEngineCommonUtil#checkArgsLengthPermitNullVal(Object...)
   * @see RateEngineCommonUtil#convertToDecimal(Object...)
   */
  @Override
  public Object[] calc(Object... args) throws RateEngineException {

    // チェック対象指定
    int[] nullPermitIndexs = new int[] {0, 0, 0, 0, 0, 0, 0, 1, 1, 1 };

    // 引数長チェック
    RateEngineCommonUtil.checkArgsLengthPermitNullVal(args, ARG_LENGTH, nullPermitIndexs);

    // 制限中止割引額
    BigDecimal retDiscount = BigDecimal.ZERO;

    // 契約決定区分リストに値がない場合は制限中止なしと判定し処理を終了する
    if (((Object[]) args[ArrayIndex.FOUR.ordinal()]).length == 0) {
      // デバッグログ出力
      LOGGER.debug("制限中止割引額={}", retDiscount);

      return new Object[] {retDiscount };
    }

    // 予備契約開始日配列
    Date[] reserveContractSdList = Arrays.stream((Object[]) args[ArrayIndex.ONE.ordinal()]).toArray(Date[]::new);

    // 予備契約終了日配列
    Date[] reserveContractedList = Arrays.stream((Object[]) args[ArrayIndex.TWO.ordinal()]).toArray(Date[]::new);

    // 算定期間開始日配列
    Date[] ccSdList = Arrays.stream((Object[]) args[ArrayIndex.THREE.ordinal()]).toArray(Date[]::new);

    // 契約決定区分配列
    String[] categoryList = Arrays.stream((Object[]) args[ArrayIndex.FOUR.ordinal()]).toArray(String[]::new);

    // 対象基本料金
    BigDecimal[] basePriceList = RateEngineCommonUtil.convertToDecimals((Object[]) args[ArrayIndex.ZERO.ordinal()]);

    // 制限中止日数
    BigDecimal[] dateList = RateEngineCommonUtil.convertToDecimals((Object[]) args[ArrayIndex.FIVE.ordinal()]);

    // 制限中止時間数
    BigDecimal[] timeList = RateEngineCommonUtil.convertToDecimals((Object[]) args[ArrayIndex.SIX.ordinal()]);

    // 電圧区分コード
    String voltagecatcode = args[ArrayIndex.SEVEN.ordinal()].toString();

    // 丸め桁
    BigDecimal scale = RateEngineCommonUtil.convertToDecimal((Object) args[ArrayIndex.EIGHT.ordinal()]);

    // 丸め方法
    BigDecimal rMode = RateEngineCommonUtil.convertToDecimal((Object) args[ArrayIndex.NINE.ordinal()]);

    CalcPartsFactory calcPartsFactory = new CalcPartsFactory();
    FeeCalcParts parts = calcPartsFactory.getParts(Round.class.getSimpleName());

    for (int n = 0; n < ccSdList.length; n++) {
      for (int m = 0; m < basePriceList.length; m++) {
        // 予備契約開始日配列[m] ≦ 算定期間開始日配列[n] かつ
        // 予備契約終了日配列[m] ≧ 算定期間開始日配列[n] 　の場合
        if (reserveContractSdList[m].compareTo(ccSdList[n]) <= 0
            && reserveContractedList[m].compareTo(ccSdList[n]) >= 0) {
          // 電圧区分コードが特高 または、電圧区分コードが高圧かつ契約決定区分が協議制の場合
          if (ECISCodeConstants.CUSTOM_VOLTAGE_CAT_CODE_SPECIALLY_HIGH.equals(voltagecatcode)
              || (ECISCodeConstants.CUSTOM_VOLTAGE_CAT_CODE_HIGH_TENSION.equals(voltagecatcode)
                  && ECISCodeConstants.CONTRACT_CAPACITY_DECISION_CATEGORY_CODE_DISCUSSIONS
                      .equals(categoryList[n]))) {
            // 対象基本料金と制限中止時間数ともにNULLでない場合
            if (!basePriceList[m].equals(BigDecimal.ZERO) && !timeList[n].equals(BigDecimal.ZERO)) {
              // 協議制の制限中止割引額の計算
              Object[] calcRet = parts.calc(basePriceList[m]
                  .multiply(timeList[n]
                      .multiply(HANG_RATE_DISCUSSIONS)),
                  scale, rMode);

              retDiscount = retDiscount.add((BigDecimal) calcRet[ArrayIndex.ZERO.ordinal()]);
            }
          }

          // 電圧区分コードが高圧かつ契約決定区分が実量制の場合
          if (ECISCodeConstants.CUSTOM_VOLTAGE_CAT_CODE_HIGH_TENSION.equals(voltagecatcode)
              && ECISCodeConstants.CONTRACT_CAPACITY_DECISION_CATEGORY_CODE_REALQUANTITY
                  .equals(categoryList[n])) {
            // 対象基本料金と制限中止日数ともにNULLでない場合
            if (!basePriceList[m].equals(BigDecimal.ZERO) && !dateList[n].equals(BigDecimal.ZERO)) {
              // 実量制の制限中止割引額の計算
              Object[] calcRet = parts.calc(basePriceList[m]
                  .multiply(dateList[n]
                      .multiply(HANG_RATE_REALQUANTITY)),
                  scale, rMode);

              retDiscount = retDiscount.add((BigDecimal) calcRet[ArrayIndex.ZERO.ordinal()]);
            }
          }
        }
      }
    }

    // デバッグログ出力
    LOGGER.debug("制限中止割引額={}", retDiscount);

    // 結果を返却
    return new Object[] {retDiscount };
  }
}
