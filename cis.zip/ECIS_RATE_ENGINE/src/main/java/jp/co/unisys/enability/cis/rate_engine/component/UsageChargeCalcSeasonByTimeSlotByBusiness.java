package jp.co.unisys.enability.cis.rate_engine.component;

import java.math.BigDecimal;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import jp.co.unisys.enability.cis.common.Exception.RateEngineException;
import jp.co.unisys.enability.cis.common.util.rk.RateEngineCommonUtil;

/**
 * 従量料金計算（季節別時間帯別）ビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class UsageChargeCalcSeasonByTimeSlotByBusiness implements FeeCalcParts {
  /** ロガー */
  private static final Logger LOGGER = LogManager.getLogger();

  /** この部品がサポートする固定パラメータ数 */
  private static final int ARG_LENGTH = 13;

  /**
   * 従量料金（季節別時間帯別）の計算を行う。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された情報をもとに従量料金（季節別時間帯別）を計算する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param args
   *          args[0]:Object 季節1全日使用量<br>
   *          args[1]:Object 季節1時間帯1使用量<br>
   *          args[2]:Object 季節1時間帯2使用量<br>
   *          args[3]:Object 季節2全日使用量<br>
   *          args[4]:Object 季節2時間帯1使用量<br>
   *          args[5]:Object 季節2時間帯2使用量<br>
   *          args[6]:Object 季節1全日単価<br>
   *          args[7]:Object 季節1時間帯1単価<br>
   *          args[8]:Object 季節1時間帯2単価<br>
   *          args[9]:Object 季節2全日単価<br>
   *          args[10]:Object 季節2時間帯1単価<br>
   *          args[11]:Object 季節2時間帯2単価<br>
   *          args[12]:Object 燃料費調整額<br>
   * @return 従量料金[合計額、季節1合計額、季節1時間帯1金額、季節1時間帯2金額、季節2合計額、季節2時間帯1金額、季節2時間帯2金額]
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   * @see RateEngineCommonUtil#checkArgsLengthPermitNullVal(Object...)
   * @see RateEngineCommonUtil#convertToDecimals(Object...)
   */
  @Override
  public Object[] calc(Object... args) throws RateEngineException {

    LOGGER.debug(
        "季節1全日使用量={} 季節1時間帯1使用量={} 季節1時間帯2使用量={} 季節2全日使用量={} 季節2時間帯1使用量={} 季節2時間帯2使用量={} 季節1全日単価={} 季節1時間帯1単価={} ",
        args[ArrayIndex.ZERO.ordinal()],
        args[ArrayIndex.ONE.ordinal()], args[ArrayIndex.TWO.ordinal()],
        args[ArrayIndex.THREE.ordinal()],
        args[ArrayIndex.FOUR.ordinal()],
        args[ArrayIndex.FIVE.ordinal()],
        args[ArrayIndex.SIX.ordinal()],
        args[ArrayIndex.SEVEN.ordinal()]);

    int[] nullPermitIndexs = new int[] {0, 0, 0, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1 };

    BigDecimal[] prices = new BigDecimal[] {BigDecimal.valueOf(0),
        BigDecimal.valueOf(0), BigDecimal.valueOf(0),
        BigDecimal.valueOf(0), BigDecimal.valueOf(0),
        BigDecimal.valueOf(0), BigDecimal.valueOf(0) };

    // 引数長チェック
    RateEngineCommonUtil.checkArgsLengthPermitNullVal(args, ARG_LENGTH,
        nullPermitIndexs);

    // 料金計算の準備
    BigDecimal[] decimals = RateEngineCommonUtil.convertToDecimals(args);

    // 季節1全日の料金を計算する
    BigDecimal entireDayPrice;
    BigDecimal timeZone1Price;
    BigDecimal timeZone2Price;
    entireDayPrice = decimals[ArrayIndex.ZERO.ordinal()]
        .multiply(decimals[ArrayIndex.SIX.ordinal()]);
    prices[ArrayIndex.ZERO.ordinal()] = entireDayPrice;

    // 季節1時間帯1の料金を計算する
    timeZone1Price = decimals[ArrayIndex.ONE.ordinal()].multiply(decimals[ArrayIndex.SEVEN
        .ordinal()]);
    prices[ArrayIndex.ONE.ordinal()] = timeZone1Price;

    // 季節1時間帯2の料金を計算する
    timeZone2Price = decimals[ArrayIndex.TWO.ordinal()].multiply(decimals[ArrayIndex.EIGHT
        .ordinal()]);
    prices[ArrayIndex.TWO.ordinal()] = timeZone2Price;

    // 料金再計算
    if (timeZone1Price.compareTo(BigDecimal.ZERO) > 0
        || timeZone2Price.compareTo(BigDecimal.ZERO) > 0) {
      entireDayPrice = timeZone1Price.add(timeZone2Price);
      prices[ArrayIndex.ZERO.ordinal()] = entireDayPrice;
    }

    // 季節2全日の料金を計算する
    entireDayPrice = decimals[ArrayIndex.THREE.ordinal()]
        .multiply(decimals[ArrayIndex.NINE.ordinal()]);
    prices[ArrayIndex.THREE.ordinal()] = entireDayPrice;

    // 季節2時間帯1の料金を計算する
    timeZone1Price = decimals[ArrayIndex.FOUR.ordinal()]
        .multiply(decimals[ArrayIndex.TEN.ordinal()]);
    prices[ArrayIndex.FOUR.ordinal()] = timeZone1Price;

    // 季節2時間帯2の料金を計算する
    timeZone2Price = decimals[ArrayIndex.FIVE.ordinal()]
        .multiply(decimals[ArrayIndex.ELEVEN.ordinal()]);
    prices[ArrayIndex.FIVE.ordinal()] = timeZone2Price;

    // 料金再計算
    if (timeZone1Price.compareTo(BigDecimal.ZERO) > 0
        || timeZone2Price.compareTo(BigDecimal.ZERO) > 0) {
      entireDayPrice = timeZone1Price.add(timeZone2Price);
      prices[ArrayIndex.THREE.ordinal()] = entireDayPrice;
    }

    // 従量料金の合計を計算する
    BigDecimal sum = prices[ArrayIndex.ZERO.ordinal()].add(prices[ArrayIndex.THREE.ordinal()]).add(
        decimals[ArrayIndex.TWELEV.ordinal()]);

    LOGGER.debug("従量料金の合計={} ", sum);

    return new Object[] {sum, prices[ArrayIndex.ZERO.ordinal()], prices[ArrayIndex.ONE.ordinal()],
        prices[ArrayIndex.TWO.ordinal()], prices[ArrayIndex.THREE.ordinal()],
        prices[ArrayIndex.FOUR.ordinal()], prices[ArrayIndex.FIVE.ordinal()] };
  }

}
