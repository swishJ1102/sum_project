package jp.co.unisys.enability.cis.rate_engine.component;

import java.math.BigDecimal;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import jp.co.unisys.enability.cis.common.Exception.RateEngineException;
import jp.co.unisys.enability.cis.common.util.rk.RateEngineCommonUtil;

/**
 * 時間帯別3段料金計算Businessクラス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class UsageChargeCalcByTimeSlotChargeBusiness implements FeeCalcParts {
  /** ロガー */
  private static final Logger LOGGER = LogManager.getLogger();

  /** この部品がサポートする固定パラメータ数 */
  private static final int ARG_LENGTH = 5;

  /**
   * 時間帯別3段料金の計算を行う。<br>
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された情報をもとに時間帯別3段料金を計算する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param args
   *          args[0]:Object 時間帯1_段料金使用量リスト<br>
   *          args[1]:Object 時間帯1_段料金単価リスト<br>
   *          args[2]:Object 時間帯2_使用量<br>
   *          args[3]:Object 時間帯2_単価<br>
   *          args[4]:Object 燃料費調整額<br>
   * @return 従量料金[従量料金合計、時間帯1...N段毎の従量料金、時間帯2_従量料金]
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   * @see RateEngineCommonUtil#checkArgsLength(Object...)
   * @see RateEngineCommonUtil#convertToDecimals(Object...)
   */
  @Override
  public Object[] calc(Object... args) throws RateEngineException {
    // 引数長チェック
    RateEngineCommonUtil.checkArgsLength(args, ARG_LENGTH);

    // デバッグログ出力
    LOGGER.debug("時間帯1_段料金使用量リスト...N={} 時間帯1_段料金単価リスト...N={} "
        + "時間帯2_使用量={} 時間帯2_単価={} 燃料費調整額={} ",
        args[ArrayIndex.ZERO.ordinal()], args[ArrayIndex.ONE.ordinal()], args[ArrayIndex.TWO.ordinal()],
        args[ArrayIndex.THREE.ordinal()], args[ArrayIndex.FOUR.ordinal()]);

    // 数値変換
    BigDecimal[] decimals = RateEngineCommonUtil.convertToDecimals(args[ArrayIndex.TWO.ordinal()],
        args[ArrayIndex.THREE.ordinal()], args[ArrayIndex.FOUR.ordinal()]);
    // 時間帯1_段料金使用量リスト
    BigDecimal[] oneSlotUsageAmount = RateEngineCommonUtil
        .convertToDecimals((Object[]) args[ArrayIndex.ZERO.ordinal()]);
    // 時間帯1_段料金単価リスト
    BigDecimal[] oneSlotUnitPrice = RateEngineCommonUtil
        .convertToDecimals((Object[]) args[ArrayIndex.ONE.ordinal()]);

    // 時間帯1_段従量料金リスト
    BigDecimal[] oneSlotPrices = new BigDecimal[oneSlotUnitPrice.length];
    // 従量料金合計
    BigDecimal sumPrice = BigDecimal.ZERO;
    for (int i = 0; i < oneSlotUnitPrice.length; i++) {
      // 使用量 ＊ 料金単価
      oneSlotPrices[i] = oneSlotUsageAmount[i].multiply(oneSlotUnitPrice[i]);
      sumPrice = sumPrice.add(oneSlotPrices[i]);
    }
    // 時間帯2_従量料金
    // 時間帯2_使用量 ＊ 時間帯2_単価
    BigDecimal twoSlotPrice = decimals[ArrayIndex.ZERO.ordinal()].multiply(decimals[ArrayIndex.ONE.ordinal()]);
    // 時間帯1_従量料金 + 時間帯2_従量料金 + 燃料費調整額
    sumPrice = sumPrice.add(twoSlotPrice).add(decimals[ArrayIndex.TWO.ordinal()]);

    // 従量料金リスト
    Object[] prices = new Object[oneSlotUnitPrice.length + ArrayIndex.TWO.ordinal()];
    prices[ArrayIndex.ZERO.ordinal()] = sumPrice;
    for (int j = 0; j < oneSlotPrices.length; j++) {
      prices[j + ArrayIndex.ONE.ordinal()] = oneSlotPrices[j];
      LOGGER.debug("時間帯1_段従量料金{} ", oneSlotPrices[j]);
    }
    prices[prices.length - 1] = twoSlotPrice;

    // デバッグログを出力
    LOGGER.debug("従量料金合計{} 時間帯2_従量料金{} ",
        prices[ArrayIndex.ZERO.ordinal()], prices[prices.length - 1]);

    // 結果を返却
    return prices;
  }
}
