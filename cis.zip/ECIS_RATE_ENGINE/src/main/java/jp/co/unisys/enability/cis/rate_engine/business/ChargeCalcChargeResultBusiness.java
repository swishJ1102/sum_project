package jp.co.unisys.enability.cis.rate_engine.business;

import java.util.Map;

import jp.co.unisys.enability.cis.entity.common.CalculationResult;
import jp.co.unisys.enability.cis.entity.common.ClcBreakdown;

/**
 * 計算結果保持ビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class ChargeCalcChargeResultBusiness {

  /** 計算結果 */
  private CalculationResult calculationResult;

  /** 計算結果内訳 */
  private Map<String, ClcBreakdown> clcBreakdownList;

  /**
   * コンストラクタ
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * コンストラクタ
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param calcResult
   *          計算結果
   * @param clcBreakList
   *          計算結果内訳
   */
  public ChargeCalcChargeResultBusiness(CalculationResult calcResult,
      Map<String, ClcBreakdown> clcBreakList) {
    this.calculationResult = calcResult;
    this.clcBreakdownList = clcBreakList;
  }

  /**
   * 計算結果取得
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計算結果取得
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 計算結果
   */
  public CalculationResult getResult() {
    return this.calculationResult;
  }

  /**
   * 計算結果内訳取得
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計算結果内訳取得
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 計算結果内訳
   */
  public Map<String, ClcBreakdown> getResultBreakDown() {
    return this.clcBreakdownList;
  }
}
