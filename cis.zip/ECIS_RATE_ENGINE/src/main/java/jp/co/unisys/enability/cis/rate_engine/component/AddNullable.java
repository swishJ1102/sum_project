package jp.co.unisys.enability.cis.rate_engine.component;

import java.math.BigDecimal;

import jp.co.unisys.enability.cis.common.Exception.RateEngineException;
import jp.co.unisys.enability.cis.common.util.rk.RateEngineCommonUtil;

/**
 * 加算（NULL指定可）。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class AddNullable implements FeeCalcParts {

  /**
   * 加算（NULL指定可）（四則演算）を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数の値をBigDecimal型に変換した後、全て引数の値を加算した結果を返却する。<br/>
   * NULL値が設定された場合、0として計算を行う。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param args
   *          引数(可変長)<br>
   *          args[0]:Object 加算する数値1<br>
   *          args[1]:Object 加算する数値2<br>
   *          args[n]:Object 加算する数値n<br>
   * @return 合計値(要素数1の配列)
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   * @see RateEngineCommonUtil#convertToDecimalsNullable(Object...)
   */
  @Override
  public Object[] calc(Object... args) throws RateEngineException {
    // 引数を数値変換
    BigDecimal[] decimals = RateEngineCommonUtil.convertToDecimalsNullable(args);

    // 処理結果を返却
    return new Add().calc((Object[]) decimals);
  }
}
