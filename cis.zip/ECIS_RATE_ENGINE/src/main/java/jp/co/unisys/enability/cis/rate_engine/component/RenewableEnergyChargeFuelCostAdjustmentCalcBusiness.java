package jp.co.unisys.enability.cis.rate_engine.component;

import java.math.BigDecimal;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import jp.co.unisys.enability.cis.common.Exception.RateEngineException;
import jp.co.unisys.enability.cis.common.util.rk.RateEngineCommonUtil;
import jp.co.unisys.enability.cis.rate_engine.engine.CalcPartsFactory;

/**
 * 再エネ賦課金燃料費調整額計算ビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RenewableEnergyChargeFuelCostAdjustmentCalcBusiness extends ChargeCalcBaseBusiness
    implements FeeCalcParts {
  /** ロガー */
  private static final Logger LOGGER = LogManager.getLogger();

  /** この部品がサポートする固定パラメータ数 */
  private static final int ARG_LENGTH = 10;

  /**
   * 再エネ賦課金、燃料費調整額の計算を行う。<br>
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された情報をもとに再エネ賦課金、燃料費調整額を計算する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param args
   *          args[0]:Object 最低料金部分使用量<br>
   *          args[1]:Object 使用量<br>
   *          args[2]:Object 単価<br>
   *          args[3]:Object 最低料金<br>
   *          args[4]:Object 丸め桁（使用量）<br>
   *          args[5]:Object 丸め方法（使用量）<br>
   *          args[6]:Object 丸め桁（料金）<br>
   *          args[7]:Object 丸め方法（料金）<br>
   *          args[8]:Object 検針日数<br>
   *          args[9]:Object 日割日数<br>
   * @return 再エネ賦課金または燃料費調整額[合計額、従量部分、最低料金部分]
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   * @see RateEngineCommonUtil#checkArgsLengthPermitNullVal(Object...)
   * @see RateEngineCommonUtil#convertToDecimals(Object...)
   * @see RateEngineCommonUtil#convertStringToInt(Object...)
   * @see RateEngineCommonUtil#getRoundMode(Object...)
   */
  @Override
  public Object[] calc(Object... args) throws RateEngineException {
    // チェック対象指定
    int[] nullPermitIndexs = new int[] {0, 1, 1, 0, 1, 1, 1, 1, 1, 1 };

    // 引数長チェック
    RateEngineCommonUtil.checkArgsLengthPermitNullVal(args, ARG_LENGTH, nullPermitIndexs);

    // 料金計算の準備
    BigDecimal[] decimals = RateEngineCommonUtil.convertToDecimals(args);

    // 日割の設定
    super.setPerDiemRate(decimals[ArrayIndex.NINE.ordinal()], decimals[ArrayIndex.EIGHT.ordinal()]);

    // 最低料金部分使用量を日割する
    BigDecimal lowestPriceUsage = super.calcCharge(decimals[ArrayIndex.ZERO.ordinal()],
        decimals[ArrayIndex.FOUR.ordinal()], decimals[ArrayIndex.FIVE.ordinal()]);

    // 最低料金額
    BigDecimal lowestPrice = decimals[ArrayIndex.THREE.ordinal()];
    if (args[ArrayIndex.THREE.ordinal()] != null) {
      // 最低料金が定義されている場合は、日割した金額を最低料金額に設定する
      lowestPrice = super.calcCharge(lowestPrice, decimals[ArrayIndex.SIX.ordinal()],
          decimals[ArrayIndex.SEVEN.ordinal()]);
    } else {
      // 最低料金が定義されていない場合は、[最低料金分の使用量 × 単価]を最低料金額に設定する
      lowestPrice = lowestPriceUsage.multiply(decimals[ArrayIndex.TWO.ordinal()]);
    }

    BigDecimal price = BigDecimal.ZERO;
    // 使用量が最低料金使用量より大きい場合は、差分の計算を行い加算
    if (lowestPriceUsage.compareTo(decimals[ArrayIndex.ONE.ordinal()]) < 0) {
      // ( (使用量 - 最低料金分の使用量) × 単価 )
      price = decimals[ArrayIndex.ONE.ordinal()].subtract(lowestPriceUsage).multiply(
          decimals[ArrayIndex.TWO.ordinal()]);
    }

    // 合計金額
    BigDecimal totalPrice = lowestPrice.add(price);

    // 丸め部品を呼び出し
    CalcPartsFactory calcPartsFactory = new CalcPartsFactory();
    FeeCalcParts parts = calcPartsFactory.getParts(Round.class.getSimpleName());
    Object[] roundResult = parts.calc(totalPrice, decimals[ArrayIndex.SIX.ordinal()],
        RateEngineCommonUtil.getRoundMode(decimals[ArrayIndex.SEVEN.ordinal()].intValue()));

    totalPrice = (BigDecimal) roundResult[ArrayIndex.ZERO.ordinal()];

    // 計算結果を格納
    BigDecimal[] result = new BigDecimal[] {totalPrice, lowestPrice, price };

    // デバッグログ出力
    LOGGER.debug("算出結果={} 合計額={} 最低料金部分={}", result[0], price, lowestPrice);

    // 結果を返却
    return result;
  }

}
