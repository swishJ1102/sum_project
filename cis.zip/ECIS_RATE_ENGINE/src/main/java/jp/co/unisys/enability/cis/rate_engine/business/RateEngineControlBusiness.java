package jp.co.unisys.enability.cis.rate_engine.business;

import java.util.Map;

import jp.co.unisys.enability.cis.common.Exception.RateEngineException;
import jp.co.unisys.enability.cis.rate_engine.model.RateEngineBusinessBean;
import jp.co.unisys.enability.cis.rate_engine.model.RoundBusinessBean;

/**
 * 料金計算エンジンコントロールビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public interface RateEngineControlBusiness {

  /**
   * 料金メニュー合算計算処理
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金メニュー合算前計算処理
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractId
   *          契約ID
   * @param applyDate
   *          利用年月
   * @param RateEngineBusinessBean
   *          料金計算エンジンビジネス
   * @throws RateEngineException
   */
  public void execute(String contractId, String applyDate,
      RateEngineBusinessBean rateEngineBusinessBean) throws RateEngineException;

  /**
   * 丸め処理
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * プロパティから丸め処理
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return Map<String, RoundBusinessBean> 丸めマップ
   * @throws RateEngineException
   */
  public Map<String, RoundBusinessBean> getRoundMap()
      throws RateEngineException;

}
