package jp.co.unisys.enability.cis.rate_engine.component;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import jp.co.unisys.enability.cis.common.Exception.RateEngineException;
import jp.co.unisys.enability.cis.common.util.rk.RateEngineCommonUtil;

/**
 * 使用量計算（3段料金制向け）ビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class UsageCalcThreeStepChargeBusiness extends ChargeCalcBaseBusiness implements FeeCalcParts {
  /** ロガー */
  private static final Logger LOGGER = LogManager.getLogger();

  /** この部品がサポートする固定パラメータ数 */
  private static final int ARG_LENGTH = 7;

  /**
   * 使用量（3段料金制向け）の計算を行う。<br>
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された情報（閾値リスト）をもとに段毎の使用量を計算、仕訳したリストを返却する。<br>
   * 閾値の段数（リストの数）に満たない部分は0を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param args
   *          args[0]:Object 使用量<br>
   *          args[1]:Object 日数検針<br>
   *          args[2]:Object 日割日数<br>
   *          args[3]:Object 丸め桁（仕訳後の使用量）<br>
   *          args[4]:Object 丸め方法（仕訳後の使用量）<br>
   *          args[5]:Object 1...N段料金適用閾値<br>
   *          args[6]:Object 最低料金部分使用量<br>
   * @return 計算後使用量リスト
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   * @see RateEngineCommonUtil#checkArgsLength(Object...)
   * @see RateEngineCommonUtil#convertToDecimals(Object...)
   * @see RateEngineCommonUtil#convertStringToInt(Object...)
   * @see RateEngineCommonUtil#getRoundMode(Object...)
   * @see RateEngineCommonUtil#convertListToObject(Object...)
   */
  @Override
  public Object[] calc(Object... args) throws RateEngineException {
    // 引数長チェック
    RateEngineCommonUtil.checkArgsLength(args, ARG_LENGTH);

    // 使用量、検針日数、日割日数を数値に変換
    BigDecimal[] decimals = RateEngineCommonUtil
        .convertToDecimals(new Object[] {args[ArrayIndex.ZERO.ordinal()], args[ArrayIndex.ONE.ordinal()],
            args[ArrayIndex.TWO.ordinal()], args[ArrayIndex.THREE.ordinal()],
            args[ArrayIndex.FOUR.ordinal()], args[ArrayIndex.SIX.ordinal()] });

    // 日割率
    super.setPerDiemRate(decimals[ArrayIndex.TWO.ordinal()], decimals[ArrayIndex.ONE.ordinal()]);

    // 1...N段料金適用閾値処理
    BigDecimal[] thresholdList = RateEngineCommonUtil.convertToDecimals((Object[]) args[ArrayIndex.FIVE.ordinal()]);
    // int thresholdCount = thresholdList.length;

    // 日割り率考慮後の閾値リスト
    List<BigDecimal> thresholdPerDiemRateList = new ArrayList<>(thresholdList.length);

    // 日割適用前閾値を最低料金部分使用量で初期化する
    BigDecimal beforePerDiemThreshold = decimals[ArrayIndex.FIVE.ordinal()];

    // 日割適用後閾値を最低料金部分使用量に日割を適用した値で初期化する
    BigDecimal afterPerDiemThreshold = super.calcThresholdUsage(beforePerDiemThreshold,
        decimals[ArrayIndex.THREE.ordinal()], decimals[ArrayIndex.FOUR.ordinal()]);

    // 取得できたリスト分繰り返す
    for (int i = 0; i < thresholdList.length - 1; i++) {
      // 閾値を日割し、前段の閾値を加算する
      BigDecimal threshold = super.calcThresholdUsage(thresholdList[i].subtract(beforePerDiemThreshold),
          decimals[ArrayIndex.THREE.ordinal()], decimals[ArrayIndex.FOUR.ordinal()]).add(
              afterPerDiemThreshold);

      // 日割した結果をリストに追加する
      thresholdPerDiemRateList.add(threshold);

      // 日割前の閾値を変数に退避
      beforePerDiemThreshold = thresholdList[i];

      // 日割後の閾値を変数に退避
      afterPerDiemThreshold = threshold;
    }
    // -1を最後に入れておく
    thresholdPerDiemRateList.add(BigDecimal.ONE.negate());

    // 前回分の閾値、デフォルトはゼロ
    BigDecimal preThreshold = BigDecimal.ZERO;
    // 閾値との差分の使用量、デフォルトは全量
    BigDecimal diffUsage = decimals[ArrayIndex.ZERO.ordinal()];

    // 使用量を閾値ごとに分けた値を格納する
    List<BigDecimal> usageThresholdList = new ArrayList<>(thresholdList.length);
    // 取得できた閾値がある限り繰り返す
    for (int i = 0; i < thresholdPerDiemRateList.size(); i++) {
      BigDecimal thresholdPerDiemRate = thresholdPerDiemRateList.get(i);
      // 使用量と閾値を比較して、使用量の方が小さいか同じ、または-1場合
      if (decimals[ArrayIndex.ZERO.ordinal()].compareTo(thresholdPerDiemRate) <= 0
          || BigDecimal.ONE.negate().equals(thresholdPerDiemRate)) {
        // 差分の使用量を全て設定してループを抜ける
        usageThresholdList.add(diffUsage);
        // 残りがあればゼロで埋めて、ループを抜ける
        for (int j = i + 1; j < thresholdPerDiemRateList.size(); j++) {
          usageThresholdList.add(BigDecimal.ZERO);
        }
        break;
      } else {
        // 今回閾値と前回閾値の差分を設定
        usageThresholdList.add(thresholdPerDiemRate.subtract(preThreshold));
        // 全量と閾値の差分を出しておく
        diffUsage = decimals[ArrayIndex.ZERO.ordinal()].subtract(thresholdPerDiemRate);
        // 今回閾値を記憶
        preThreshold = thresholdPerDiemRate;
      }
    }

    LOGGER.debug("計算結果 ={}", usageThresholdList.toArray());

    Object[] returnVal = new Object[usageThresholdList.size() + 1];
    // 使用量リストを格納
    returnVal[ArrayIndex.ZERO.ordinal()] = usageThresholdList.toArray();
    // 各使用量を格納
    for (int k = 0; k < usageThresholdList.size(); k++) {
      returnVal[k + 1] = usageThresholdList.get(k);
    }

    // 結果を返却
    return returnVal;
  }
}
