package jp.co.unisys.enability.cis.rate_engine.model;

import java.math.BigDecimal;
import java.util.Date;

/**
 * 計算用制限中止割引情報ビジネスBean。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class CalRestrictDisInfoBusinessBean {

  /**
   * 日割開始日を保有する。
   */
  private Date dateSlotStartDate;

  /**
   * 算定期間開始日を保有する。
   */
  private Date chargeCalStartDate;

  /**
   * 割引対象コードを保有する。
   */
  private String discountCoveredCode;

  /**
   * 契約電力決定区分コードを保有する。
   */
  private String ccDecisionCategoryCode;

  /**
   * 割引時間数を保有する。
   */
  private BigDecimal discountCoveredTime;

  /**
   * 割引日数を保有する。
   */
  private BigDecimal discountCoveredDays;

  /**
   * 日割開始日のgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 日割開始日
   */
  public Date getDateSlotStartDate() {
    return this.dateSlotStartDate;
  }

  /**
   * 日割開始日のsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param dateSlotStartDate
   *          日割開始日
   */
  public void setDateSlotStartDate(Date dateSlotStartDate) {
    this.dateSlotStartDate = dateSlotStartDate;
  }

  /**
   * 算定期間開始日のgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 算定期間開始日
   */
  public Date getChargeCalStartDate() {
    return this.chargeCalStartDate;
  }

  /**
   * 算定期間開始日のsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param chargeCalStartDate
   *          算定期間開始日
   */
  public void setChargeCalStartDate(Date chargeCalStartDate) {
    this.chargeCalStartDate = chargeCalStartDate;
  }

  /**
   * 割引対象コードのgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 割引対象コード
   */
  public String getDiscountCoveredCode() {
    return this.discountCoveredCode;
  }

  /**
   * 割引対象コードのsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param discountCoveredCode
   *          割引対象コード
   */
  public void setDiscountCoveredCode(String discountCoveredCode) {
    this.discountCoveredCode = discountCoveredCode;
  }

  /**
   * 契約電力決定区分コードのgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約電力決定区分コード
   */
  public String getCcDecisionCategoryCode() {
    return this.ccDecisionCategoryCode;
  }

  /**
   * 契約電力決定区分コードのsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param ccDecisionCategoryCode
   *          契約電力決定区分コード
   */
  public void setCcDecisionCategoryCode(String ccDecisionCategoryCode) {
    this.ccDecisionCategoryCode = ccDecisionCategoryCode;
  }

  /**
   * 割引時間数のgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 割引時間数
   */
  public BigDecimal getDiscountCoveredTime() {
    return this.discountCoveredTime;
  }

  /**
   * 割引時間数のsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param discountCoveredTime
   *          割引時間数
   */
  public void setDiscountCoveredTime(BigDecimal discountCoveredTime) {
    this.discountCoveredTime = discountCoveredTime;
  }

  /**
   * 割引日数のgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 割引日数
   */
  public BigDecimal getDiscountCoveredDays() {
    return this.discountCoveredDays;
  }

  /**
   * 割引日数のsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param discountCoveredDays
   *          割引日数
   */
  public void setDiscountCoveredDays(BigDecimal discountCoveredDays) {
    this.discountCoveredDays = discountCoveredDays;
  }
}
