package jp.co.unisys.enability.cis.rate_engine.model;

import java.math.BigDecimal;
import java.util.Date;

/**
 * 計算用予備契約情報ビジネスBean。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class CalReserveContractBusinessBean {

  /**
   * 日割開始日を保有する。
   */
  private Date dateSlotStartDate;

  /**
   * 予備契約種別を保有する。
   */
  private String reserveContractClass;

  /**
   * 予備契約開始日を保有する。
   */
  private Date reserveContractStartDate;

  /**
   * 予備契約終了日を保有する。
   */
  private Date reserveContractEndDate;

  /**
   * 契約容量を保有する。
   */
  private BigDecimal contractCapacity;

  /**
   * 予備単価を保有する。
   */
  private BigDecimal reserveUnitPrice;

  /**
   * 検針日数を保有する。
   */
  private BigDecimal meterReadingDays;

  /**
   * 予備契約日割日数を保有する。
   */
  private BigDecimal proratedBasisDays;

  /**
   * 日割開始日のgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 日割開始日
   */
  public Date getDateSlotStartDate() {
    return this.dateSlotStartDate;
  }

  /**
   * 日割開始日のsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param dateSlotStartDate
   *          日割開始日
   */
  public void setDateSlotStartDate(Date dateSlotStartDate) {
    this.dateSlotStartDate = dateSlotStartDate;
  }

  /**
   * 予備契約種別のgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 予備契約種別
   */
  public String getReserveContractClass() {
    return this.reserveContractClass;
  }

  /**
   * 予備契約種別のsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param reserveContractClass
   *          予備契約種別
   */
  public void setReserveContractClass(String reserveContractClass) {
    this.reserveContractClass = reserveContractClass;
  }

  /**
   * 予備契約開始日のgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 予備契約開始日
   */
  public Date getReserveContractStartDate() {
    return this.reserveContractStartDate;
  }

  /**
   * 予備契約開始日のsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param reserveContractStartDate
   *          予備契約開始日
   */
  public void setReserveContractStartDate(Date reserveContractStartDate) {
    this.reserveContractStartDate = reserveContractStartDate;
  }

  /**
   * 予備契約終了日のgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 予備契約終了日
   */
  public Date getReserveContractEndDate() {
    return this.reserveContractEndDate;
  }

  /**
   * 予備契約終了日のsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param reserveContractEndDate
   *          予備契約終了日
   */
  public void setReserveContractEndDate(Date reserveContractEndDate) {
    this.reserveContractEndDate = reserveContractEndDate;
  }

  /**
   * 契約容量のgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約容量
   */
  public BigDecimal getContractCapacity() {
    return this.contractCapacity;
  }

  /**
   * 契約容量のsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractCapacity
   *          契約容量
   */
  public void setContractCapacity(BigDecimal contractCapacity) {
    this.contractCapacity = contractCapacity;
  }

  /**
   * 予備単価のgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 予備単価
   */
  public BigDecimal getReserveUnitPrice() {
    return this.reserveUnitPrice;
  }

  /**
   * 予備単価のsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param reserveUnitPrice
   *          予備単価
   */
  public void setReserveUnitPrice(BigDecimal reserveUnitPrice) {
    this.reserveUnitPrice = reserveUnitPrice;
  }

  /**
   * 検針日数のgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 検針日数
   */
  public BigDecimal getMeterReadingDays() {
    return this.meterReadingDays;
  }

  /**
   * 検針日数のsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param meterReadingDays
   *          検針日数
   */
  public void setMeterReadingDays(BigDecimal meterReadingDays) {
    this.meterReadingDays = meterReadingDays;
  }

  /**
   * 予備契約日割日数のgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 予備契約日割日数
   */
  public BigDecimal getProratedBasisDays() {
    return this.proratedBasisDays;
  }

  /**
   * 予備契約日割日数のsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param proratedBasisDays
   *          予備契約日割日数
   */
  public void setProratedBasisDays(BigDecimal proratedBasisDays) {
    this.proratedBasisDays = proratedBasisDays;
  }
}
