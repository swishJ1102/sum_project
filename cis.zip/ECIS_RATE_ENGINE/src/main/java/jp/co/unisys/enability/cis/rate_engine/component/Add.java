package jp.co.unisys.enability.cis.rate_engine.component;

import java.math.BigDecimal;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import jp.co.unisys.enability.cis.common.Exception.RateEngineException;
import jp.co.unisys.enability.cis.common.util.rk.RateEngineCommonUtil;

/**
 * 加算。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class Add implements FeeCalcParts {
  /** ロガー */
  private static final Logger LOGGER = LogManager.getLogger();

  /**
   * 加算（四則演算）を行う。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数の値をBigDecimal型に変換した後、全て引数の値を加算した結果を返却する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param args
   *          引数(可変長)<br>
   *          args[0]:Object 加算する数値1<br>
   *          args[1]:Object 加算する数値2<br>
   *          args[n]:Object 加算する数値n<br>
   * @return 合計値(要素数1の配列)
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   * @see RateEngineCommonUtil#convertToDecimals(Object...)
   */
  @Override
  public Object[] calc(Object... args) throws RateEngineException {
    // 引数を数値変換
    BigDecimal[] decimals = RateEngineCommonUtil.convertToDecimals(args);

    // 加算
    BigDecimal calced = BigDecimal.ZERO;
    for (BigDecimal addValue : decimals) {
      calced = calced.add(addValue);
    }

    // デバッグログ
    LOGGER.debug("加算結果={}", calced.toString());

    // 処理結果を返却
    return new BigDecimal[] {calced };
  }
}
