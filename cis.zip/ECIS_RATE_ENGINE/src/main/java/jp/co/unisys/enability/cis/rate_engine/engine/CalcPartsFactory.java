package jp.co.unisys.enability.cis.rate_engine.engine;

import jp.co.unisys.enability.cis.common.Exception.RateEngineException;
import jp.co.unisys.enability.cis.rate_engine.component.FeeCalcParts;

/**
 * 料金計算部品インスタンス生成クラス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class CalcPartsFactory {
  private static final String PKG = "jp.co.unisys.enability.cis.rate_engine.component.";

  /**
   * コンストラクタ。
   *
   * @author "Nihon Unisys, Ltd."
   */
  public CalcPartsFactory() {
  }

  /**
   * 計算部品インスタンスの取得を行う。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 一度インスタンスを生成した部品はキャッシュする。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param className
   *          部品クラス名(クラス名のみ。パッケージは不要)
   * @return 計算部品のインスタンス
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   */
  public FeeCalcParts getParts(String className) throws RateEngineException {
    FeeCalcParts parts = createNewPartsInstance(className);
    return parts;
  }

  /**
   * 計算部品インスタンスの生成を行う。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計算部品のインスタンスを生成する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param className
   *          部品クラス名(クラス名のみ。パッケージは不要)
   * @return 計算部品のインスタンス
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   */
  private FeeCalcParts createNewPartsInstance(String className) throws RateEngineException {
    FeeCalcParts parts = null;
    try {
      parts = (FeeCalcParts) Class.forName(PKG + className).newInstance();
    } catch (Exception e) {
      //設定対象情報名が不正であるため、「代入」演算が行えません。取得元情報:{0}
      throw new RateEngineException("error.E1331", className);
    }
    return parts;
  }
}
