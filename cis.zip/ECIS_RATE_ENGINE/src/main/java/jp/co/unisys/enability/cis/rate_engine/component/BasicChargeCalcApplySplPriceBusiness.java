package jp.co.unisys.enability.cis.rate_engine.component;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import jp.co.unisys.enability.cis.common.Exception.RateEngineException;
import jp.co.unisys.enability.cis.common.util.constants.ECISCodeConstants;
import jp.co.unisys.enability.cis.common.util.rk.RateEngineCommonUtil;

/**
 * 付帯金額適用後基本料金計算ビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class BasicChargeCalcApplySplPriceBusiness extends
    ChargeCalcBaseBusiness implements FeeCalcParts {
  /** ロガー */
  private static final Logger LOGGER = LogManager.getLogger();

  /** この部品がサポートする固定パラメータ数 */
  private static final int ARG_LENGTH = 7;

  /**
   * 付帯金額を適用した後の基本料金の計算を行う。<br>
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された情報をもとに付帯金額を適用した基本料金を計算する。<br>
   * 対象とする付帯は付帯種別コード=3:電力毎　のみ
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param args
   *          args[0]:Object 基本料金<br>
   *          args[1]:Object 契約電力<br>
   *          args[2]:Object 付帯メニューリスト<br>
   *          args[3]:Object 検針日数<br>
   *          args[4]:Object 日割日数<br>
   *          args[5]:Object 丸め桁<br>
   *          args[6]:Object 丸め方法<br>
   * @return 計算結果オブジェクト配列[計算後基本料金、付帯金額合計]
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   * @see RateEngineCommonUtil#checkArgsLengthPermitNullVal(Object...)
   * @see RateEngineCommonUtil#convertToDecimals(Object...)
   */
  @Override
  public Object[] calc(Object... args) throws RateEngineException {
    // 引数長チェック
    RateEngineCommonUtil.checkArgsLength(args, ARG_LENGTH);

    // 付帯メニュー配列を生成
    Object[] spmArray = (Object[]) args[ArrayIndex.TWO.ordinal()];

    // 配列の詰め替え
    BigDecimal[] decimals = RateEngineCommonUtil
        .convertToDecimals(args[ArrayIndex.ZERO.ordinal()],
            args[ArrayIndex.ONE.ordinal()],
            args[ArrayIndex.THREE.ordinal()],
            args[ArrayIndex.FOUR.ordinal()],
            args[ArrayIndex.FIVE.ordinal()],
            args[ArrayIndex.SIX.ordinal()]);

    // 計算後基本料金
    BigDecimal calcedBasicCharge = decimals[ArrayIndex.ZERO.ordinal()];

    // 付帯金額リスト
    List<BigDecimal> splChargeList = new ArrayList<>();

    // 付帯種別コード配列
    BigDecimal[] classCodes = RateEngineCommonUtil
        .convertToDecimals(((Object[]) spmArray[ArrayIndex.TWO
            .ordinal()]));

    // 割引割増コード配列
    BigDecimal[] discountCodes = RateEngineCommonUtil
        .convertToDecimals(((Object[]) spmArray[ArrayIndex.THREE
            .ordinal()]));

    // 付帯単価配列
    BigDecimal[] splPrices = RateEngineCommonUtil
        .convertToDecimals(((Object[]) spmArray[ArrayIndex.FOUR
            .ordinal()]));

    // 付帯種別コード配列の数分処理を行う
    for (int i = 0; i < classCodes.length; i++) {
      // 付帯種別コードが”3:電力毎”以外の場合
      if (!ECISCodeConstants.SUPPLEMENTARY_CLASS_CODE_EVERY_POWER
          .equals(classCodes[i].toString())) {
        continue;
      }

      // 契約電力×単価
      BigDecimal splCharge = decimals[ArrayIndex.ONE.ordinal()]
          .multiply(splPrices[i]);

      // 割引割増コードが”1:割引”の場合
      if (ECISCodeConstants.DISCOUNT_CATEGORY_CODE_DISCOUNT
          .equals(discountCodes[i].toString())) {
        splCharge = splCharge.multiply(BigDecimal.valueOf(-1));
      }

      // 計算後基本料金を計算
      calcedBasicCharge = calcedBasicCharge.add(splCharge);
      splChargeList.add(splCharge);
    }

    // 日割日数、検針日数の設定
    super.setPerDiemRate(decimals[ArrayIndex.THREE.ordinal()],
        decimals[ArrayIndex.TWO.ordinal()]);

    // 基本料金の日割と丸めを処理
    calcedBasicCharge = super.calcDCPrice(calcedBasicCharge,
        decimals[ArrayIndex.FOUR.ordinal()],
        decimals[ArrayIndex.FIVE.ordinal()]);

    // 付帯金額の合計を計算
    BigDecimal totalSplCharge = BigDecimal.ZERO;
    for (BigDecimal charge : splChargeList) {
      totalSplCharge = totalSplCharge.add(charge);
    }

    // 日割後の金額計算（付帯額）
    BigDecimal calcedTotalSplCharge = super.calcDCPrice(totalSplCharge,
        decimals[ArrayIndex.FOUR.ordinal()],
        decimals[ArrayIndex.FIVE.ordinal()]);

    // 結果を格納
    BigDecimal[] result = new BigDecimal[] {calcedBasicCharge, calcedTotalSplCharge };

    // デバッグログを出力
    LOGGER.debug("付帯適用後基本料金（日割後）={} 付帯金額合計（日割後）={}", calcedBasicCharge,
        calcedTotalSplCharge);

    // 結果を返却
    return result;
  }
}
