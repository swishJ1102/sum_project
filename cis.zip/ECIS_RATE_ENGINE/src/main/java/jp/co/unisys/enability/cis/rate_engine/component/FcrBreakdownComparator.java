package jp.co.unisys.enability.cis.rate_engine.component;

import java.util.Comparator;
import java.util.Objects;

import jp.co.unisys.enability.cis.entity.common.FcrBreakdown;

/**
 * 確定料金実績内訳のソートクラス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class FcrBreakdownComparator implements Comparator<FcrBreakdown> {

  @Override
  public int compare(FcrBreakdown o1, FcrBreakdown o2) {
    // 項目で比較
    if (o1.getDisplayOrder() > o2.getDisplayOrder()) {
      return 1;
    } else if (Objects.equals(o1.getDisplayOrder(), o2.getDisplayOrder())) {
      if (o1.getDetailOutputOrder() > o2.getDetailOutputOrder()) {
        return 1;
      } else {
        return -1;
      }
    } else {
      return -1;
    }
  }

}
