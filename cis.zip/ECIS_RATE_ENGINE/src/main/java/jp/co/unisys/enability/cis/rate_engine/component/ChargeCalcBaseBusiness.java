package jp.co.unisys.enability.cis.rate_engine.component;

import java.math.BigDecimal;
import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import jp.co.unisys.enability.cis.common.Exception.RateEngineException;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;
import jp.co.unisys.enability.cis.common.util.rk.RateEngineCommonUtil;

/**
 * 料金計算共通ビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public abstract class ChargeCalcBaseBusiness {
  /** ロガー */
  private static final Logger LOGGER = LogManager.getLogger();
  /** 力率の基本値 85% */
  private static final BigDecimal BASE_POWER_RATE = new BigDecimal(ECISRKConstants.POWER_FACTOR_EIGHTY_FIVE)
      .divide(ECISRKConstants.RATE_DIVIDE_VAL);
  /** 基本料金係数、デフォルトで1 */
  private BigDecimal basicPriceCoefficient = BigDecimal.ONE;
  /** 日割日数 デフォルトで1 */
  protected BigDecimal dayOfPerDiem = BigDecimal.ONE;
  /** 検針日数 デフォルトで1 */
  protected BigDecimal dayOfMeterRead = BigDecimal.ONE;
  /** 力率割引割増率、デフォルトで1 */
  private BigDecimal calcPorwerRate = BigDecimal.ONE;

  /**
   * 基本料金係数設定処理<br>
   * 基本料金係数を設定、保持する。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された使用量がゼロの場合、基本料金係数を0.5に設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param kWh
   *          使用量
   */
  public void setBasicPriceCoefficient(BigDecimal kWh) {
    // 使用量がゼロの場合、基本料金係数を0.5に設定
    if (BigDecimal.ZERO.compareTo(kWh) == 0) {
      this.basicPriceCoefficient = new BigDecimal(ECISRKConstants.CALCULATION_COEFFICIENT_HALF);
    }

    // デバッグログ出力
    LOGGER.debug("基本料金係数={}", this.basicPriceCoefficient);
  }

  /**
   * 日割日数／検針日数設定処理<br>
   * 日割り率を計算するための情報を設定、保持する。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 日割日数／検針日数で計算した値を設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param dayOfPerDiemParam
   *          日割日数
   * @param dayOfMeterReadParam
   *          検針日数
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   */
  public void setPerDiemRate(BigDecimal dayOfPerDiemParam,
      BigDecimal dayOfMeterReadParam) throws RateEngineException {
    // 検針日数をチェック
    if (BigDecimal.ZERO.compareTo(dayOfMeterReadParam) == 0) {
      // 検針日数が0のため、料金の計算が行えません。
      throw new RateEngineException("error.E1326");
    }

    // 日割日数、検針日数を保持
    this.dayOfPerDiem = dayOfPerDiemParam;
    this.dayOfMeterRead = dayOfMeterReadParam;

    // デバッグログ出力
    LOGGER.debug("日割日数={}、検針日数={}", this.dayOfPerDiem, this.dayOfMeterRead);
  }

  /**
   * 力率割引割増率設定処理<br>
   * 力率割引割増率を設定、保持する。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 力率が100%(1)の場合、15%(0.15)引き。力率が80%(0.8)の場合、5%増し。<br>
   * 指定される力率は％の値とする。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param powerRate
   *          力率
   */
  private void setCalcPorwerRate(BigDecimal powerRate) {
    // 力率がNULLだった場合
    if (powerRate == null) {
      // 1.0を設定
      this.calcPorwerRate = BigDecimal.ONE;
    } else {
      // ％から小数に
      this.calcPorwerRate = powerRate.divide(ECISRKConstants.RATE_DIVIDE_VAL);
      // 1 - (力率-0.85)
      this.calcPorwerRate = BigDecimal.ONE.subtract(this.calcPorwerRate.subtract(BASE_POWER_RATE));
    }

    // デバッグログ出力
    LOGGER.debug("力率割引割増={}", this.calcPorwerRate.toString());
  }

  /**
   * 料金計算（閾値指定）<br>
   * 指定した閾値に日割率を乗算し、指定した端数処理を実施する。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * ロジックは基本料金計算と同じ。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param threshold
   *          閾値
   * @param scale
   *          丸め桁
   * @param mode
   *          丸め方法
   * @return 端数処理後の閾値
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   */
  public BigDecimal calcThresholdUsage(BigDecimal threshold, BigDecimal scale, BigDecimal mode)
      throws RateEngineException {
    // 計算結果を返却
    return this.calcDCPrice(threshold, scale, mode);
  }

  /**
   * 料金計算（基本料金指定）<br>
   * 指定された基本料金に基本料金係数と日割率を乗算し、指定されたスケール、モードで端数処理を実施する。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param dcPrice
   *          基本料金
   * @param scale
   *          丸め桁
   * @param mode
   *          丸め方法
   * @return 端数処理後の基本料金
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   */
  public BigDecimal calcDCPrice(BigDecimal dcPrice, BigDecimal scale, BigDecimal mode) throws RateEngineException {
    // 計算結果を返却
    return this.calcDCPrice(dcPrice, scale, mode, null);
  }

  /**
   * 料金計算（量/単価/力率指定）<br>
   * 指定した量と単価、力率から基本料金を計算後、基本料金係数と日割率を乗算し、<br>
   * 指定されたスケールとモードで端数処理を実施する。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param amount
   *          量
   * @param unitPrice
   *          単価
   * @param scale
   *          丸め桁
   * @param mode
   *          丸め方法
   * @param powerRate
   *          力率
   * @return 計算結果
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   */
  public BigDecimal calcDCPrice(BigDecimal amount, BigDecimal unitPrice, BigDecimal scale, BigDecimal mode,
      BigDecimal powerRate) throws RateEngineException {
    // 計算結果を返却
    return this.calcDCPrice(amount.multiply(unitPrice), scale, mode, powerRate);
  }

  /**
   * 料金計算（基本料金/力率指定）<br>
   * 指定した力率から基本料金を計算後、基本料金係数と日割率を乗算し、<br>
   * 指定されたスケールとモードで端数処理を実施する。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param dcPrice
   *          基本料金
   * @param scale
   *          丸め桁
   * @param mode
   *          丸め方法
   * @param powerRate
   *          力率
   * @return 基本料金計算結果
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   */
  public BigDecimal calcDCPrice(BigDecimal dcPrice, BigDecimal scale, BigDecimal mode, BigDecimal powerRate)
      throws RateEngineException {
    // 力率を設定
    this.setCalcPorwerRate(powerRate);

    // 基本料金 * 基本料金係数 * 力率割引割増率 を設定し
    // 料金計算（単価指定）を呼出し返却する
    return this.calcCharge(dcPrice.multiply(this.basicPriceCoefficient)
        .multiply(this.calcPorwerRate), scale, mode);
  }

  /**
   * 日割前基本料金計算（容量/単価/力率指定）<br>
   *
   * 指定した力率から日割前の基本料金を計算後、基本料金係数と日割率を乗算し、<br>
   * 指定されたスケールとモードで端数処理を実施する。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param capacity
   *          容量
   * @param unitPrice
   *          単価
   * @param scale
   *          丸め桁
   * @param mode
   *          丸め方法
   * @param powerRate
   *          力率
   * @return 基本料金計算結果
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   * @see RateEngineCommonUtil#getRoundMode(Object...)
   */
  public BigDecimal calcBeforeDCPrice(BigDecimal capacity,
      BigDecimal unitPrice, BigDecimal scale, BigDecimal mode,
      BigDecimal powerRate) throws RateEngineException {
    // 力率を設定
    this.setCalcPorwerRate(powerRate);

    // 丸めモード取得
    int roundMode = RateEngineCommonUtil.getRoundMode(mode.intValue());

    // -- 丸めモードにより判定し、結果を返却 --
    // 何もしない設定の場合
    if (ECISRKConstants.ROUNDMODE_OFF == roundMode) {
      // 計算結果を返却
      return capacity
          .multiply(unitPrice)
          .multiply(this.basicPriceCoefficient)
          .multiply(this.calcPorwerRate);
    } else {
      // 計算結果を返却
      return capacity
          .multiply(unitPrice)
          .multiply(this.basicPriceCoefficient)
          .multiply(this.calcPorwerRate)
          .setScale(scale.intValue(),
              RateEngineCommonUtil.getRoundMode(mode.intValue()));
    }
  }

  /**
   * 料金計算（量/単価指定）<br>
   * 料金計算の基本料金系の端数処理を実施する。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param amount
   *          量
   * @param unitPrice
   *          単価
   * @param scale
   *          丸め桁
   * @param mode
   *          丸め方法
   * @return 計算結果
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   */
  public BigDecimal calcCharge(BigDecimal amount, BigDecimal unitPrice, BigDecimal scale, BigDecimal mode)
      throws RateEngineException {

    // 丸めモード取得
    int roundMode = RateEngineCommonUtil.getRoundMode(mode.intValue());

    // -- 丸めモードにより判定し、結果を返却 --
    // 何もしない設定の場合
    if (roundMode == ECISRKConstants.ROUNDMODE_OFF) {
      // 計算結果を返却
      return amount.multiply(unitPrice);
    } else {
      // 計算結果を返却
      return amount.multiply(unitPrice).setScale(scale.intValue(),
          RateEngineCommonUtil.getRoundMode(mode.intValue()));
    }
  }

  /**
   * 料金計算（単価指定）<br>
   * 料金計算の基本料金系の端数処理を実施する。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param unitPrice
   *          単価
   * @param scale
   *          丸め桁
   * @param mode
   *          丸め方法
   * @return 計算結果
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   */
  public BigDecimal calcCharge(BigDecimal unitPrice, BigDecimal scale, BigDecimal mode)
      throws RateEngineException {

    // 丸めモード取得
    int roundMode = RateEngineCommonUtil.getRoundMode(mode.intValue());

    // -- 丸めモードにより判定し、結果を返却 --
    // 何もしない設定の場合
    if (roundMode == ECISRKConstants.ROUNDMODE_OFF) {
      // 計算結果を返却
      return unitPrice.multiply(this.dayOfPerDiem).divide(this.dayOfMeterRead,
          ECISRKConstants.DIVIDE_DECIMAL_SCALE, ECISRKConstants.ROUNDMODE_DOWN);
    } else {
      // 計算結果を返却
      return unitPrice.multiply(this.dayOfPerDiem)
          .divide(this.dayOfMeterRead, ECISRKConstants.DIVIDE_DECIMAL_SCALE, ECISRKConstants.ROUNDMODE_DOWN)
          .setScale(scale.intValue(),
              roundMode);
    }
  }

  /**
   * 合計額計算<br>
   * 基本料金と従量料金から合計額を算出し、最低月額料金の適用有無を検査した後、<br>
   * 円確定し、{合計金額、基本料金、従量料金}の計算結果の配列を返却する。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param dcPrice
   *          基本料金
   * @param ecPrice
   *          従量料金
   * @param lowestPrice
   *          最低月額料金
   * @param lowestPriceFlag
   *          最低月額料金適用有無フラグ
   * @param scale
   *          丸め桁
   * @param mode
   *          丸め方法
   * @return 計算結果
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   */
  public Object[] getTotalPrice(BigDecimal dcPrice, BigDecimal ecPrice, BigDecimal lowestPrice,
      String lowestPriceFlag, BigDecimal scale, BigDecimal mode) throws RateEngineException {
    // 最低月額料金適用有無フラグ
    String flag = lowestPriceFlag;
    //ECISRKConstants.MONTHLY_MIN_FEE_APPLY_NOT;
    // 合計額を計算する
    BigDecimal totalPrice = dcPrice.add(ecPrice);

    // 最低料金額より小さい場合は、最低料金額に設定する
    if (ECISRKConstants.MONTHLY_MIN_FEE_APPLY.equals(lowestPriceFlag)
        && lowestPrice != null
        && totalPrice.compareTo(lowestPrice) < 0) {
      totalPrice = lowestPrice;
      flag = ECISRKConstants.MONTHLY_MIN_FEE_APPLY;
    } else {
      flag = ECISRKConstants.MONTHLY_MIN_FEE_APPLY_NOT;
    }

    // 端数処理（円確定）
    mode = new BigDecimal(RateEngineCommonUtil.getRoundMode(mode.intValue()));
    if (mode.compareTo(new BigDecimal(ECISRKConstants.ROUNDMODE_OFF)) != 0) {
      totalPrice = totalPrice.setScale(scale.intValue(), mode.intValue());
    }

    // 結果を返却
    return new Object[] {totalPrice, dcPrice, ecPrice, flag };
  }

  /**
   * 合計額計算（最低月額料金適用なし）<br>
   * 基本料金と従量料金から合計額を算出し、円確定し、{合計金額、基本料金、従量料金}の計算結果の配列を返却する。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param dcPrice
   *          基本料金
   * @param ecPrice
   *          従量料金
   * @param scale
   *          丸め桁
   * @param mode
   *          丸め方法
   * @return 計算結果
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   */
  public Object[] getTotalPrice(BigDecimal dcPrice, BigDecimal ecPrice, BigDecimal scale, BigDecimal mode)
      throws RateEngineException {
    // 結果を返却
    return this.getTotalPrice(dcPrice, ecPrice, null, null, scale, mode);
  }

  /***
   * 初月料金適用判定<br>
   * 初月かどうか判定し、判定した結果の基本料金を返却する。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 基本料金初月無料のフラグがONの場合、かつ、算定期間開始日と契約開始日が一致した場合、<br>
   * 初月と判断し、基本料金を0で計算する。<br>
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param dcPrice
   *          基本料金
   * @param calcStartDate
   *          算定開始日
   * @param calcEndDate
   *          算定終了日
   * @param contractStartDate
   *          契約開始日
   * @param contractEndDate
   *          契約終了日
   * @param basicChargeFree
   *          基本料金無料有無
   * @return 計算結果
   */
  public BigDecimal getBasePrice(BigDecimal dcPrice, Date calcStartDate, Date calcEndDate, Date contractStartDate,
      Date contractEndDate, String basicChargeFree) {
    BigDecimal calcCharge = dcPrice;

    // 基本料金無料有無が設定されている場合のみ
    if (ECISConstants.FLG_ON.equals(basicChargeFree)) {
      // 算定期間開始日と契約開始日が一致するか
      if (calcStartDate.compareTo(contractStartDate) == 0) {
        // 算定季終了日と契約終了日が一致しないか
        if (calcEndDate.compareTo(contractEndDate) != 0) {
          calcCharge = BigDecimal.ZERO;
        }
      }
    }

    return calcCharge;
  }
}