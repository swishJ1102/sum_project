package jp.co.unisys.enability.cis.rate_engine.component;

import java.math.BigDecimal;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import jp.co.unisys.enability.cis.common.Exception.RateEngineException;
import jp.co.unisys.enability.cis.common.util.constants.ECISCodeConstants;
import jp.co.unisys.enability.cis.common.util.rk.RateEngineCommonUtil;
import jp.co.unisys.enability.cis.rate_engine.engine.CalcPartsFactory;

/**
 * 基本料金用制限中止割引金額計算ビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RestrictionDiscountInfoAmountToBasicChargeCalcBusiness extends ChargeCalcBaseBusiness
    implements FeeCalcParts {
  /** ロガー */
  private static final Logger LOGGER = LogManager.getLogger();

  /** この部品がサポートする固定パラメータ数 */
  private static final int ARG_LENGTH = 7;

  /** 掛率 協議制 0.002 */
  private static final BigDecimal HANG_RATE_DISCUSSIONS = BigDecimal.valueOf(0.002);

  /** 掛率 実量制 0.04 */
  private static final BigDecimal HANG_RATE_REALQUANTITY = BigDecimal.valueOf(0.04);

  /**
   * 基本料金用制限中止割引金額計算ビジネス<br>
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   *
   * 引数で指定された情報をもとに制限中止割引額を計算する。<br>
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param args
   *          args[0]:Object 基本料金(※1)<br>
   *          args[1]:Object (BigDecimal[0]…[N]) 制限中止日数リスト<br>
   *          args[2]:Object (BigDecimal[0]…[N]) 制限中止時間数リスト<br>
   *          args[3]:Object (String[0]…[N]) 契約決定区分リスト<br>
   *          args[4]:Object 電圧区分コード<br>
   *          args[5]:Object 丸め桁<br>
   *          args[6]:Object 丸め方法<br>
   *          (※1)日割を行う前の対象基本料金
   * @return 計算結果配列[制限中止割引額]
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   * @see RateEngineCommonUtil#checkArgsLengthPermitNullVal(Object...)
   * @see RateEngineCommonUtil#convertToDecimal(Object...)
   */
  @Override
  public Object[] calc(Object... args) throws RateEngineException {

    // チェック対象指定
    int[] nullPermitIndexs = new int[] {1, 0, 0, 0, 1, 1, 1 };

    // 引数長チェック
    RateEngineCommonUtil.checkArgsLengthPermitNullVal(args, ARG_LENGTH, nullPermitIndexs);

    // 制限中止割引額
    BigDecimal retDiscount = BigDecimal.ZERO;

    // 契約決定電力決定区分が渡ってきていない場合は制限中止なしと判定し処理を終了する
    if (((Object[]) args[ArrayIndex.THREE.ordinal()]).length == 0) {
      // デバッグログ出力
      LOGGER.debug("制限中止割引額={}", retDiscount);

      return new Object[] {retDiscount };
    }

    // 計算用変数
    BigDecimal[] arrayCalcVal = new BigDecimal[] {};
    BigDecimal calcRate = null;

    // 基本料金
    BigDecimal basePrice = RateEngineCommonUtil.convertToDecimal((Object) args[ArrayIndex.ZERO.ordinal()]);

    // 丸め桁
    BigDecimal scale = RateEngineCommonUtil.convertToDecimal((Object) args[ArrayIndex.FIVE.ordinal()]);

    // 丸め方法
    BigDecimal rMode = RateEngineCommonUtil.convertToDecimal((Object) args[ArrayIndex.SIX.ordinal()]);

    // 契約電力決定区分(同一日割別使用量内で電力決定区分コードが変わることはないため最初の1件を対象とする)
    String decisionCd = ((Object[]) args[ArrayIndex.THREE.ordinal()])[0].toString();

    // 電圧区分コード
    String voltagecatcode = args[ArrayIndex.FOUR.ordinal()].toString();

    // 電圧区分コードが特高 または、電圧区分コードが高圧かつ契約決定区分が協議制の場合
    if (ECISCodeConstants.CUSTOM_VOLTAGE_CAT_CODE_SPECIALLY_HIGH.equals(voltagecatcode)
        || (ECISCodeConstants.CUSTOM_VOLTAGE_CAT_CODE_HIGH_TENSION.equals(voltagecatcode)
            && ECISCodeConstants.CONTRACT_CAPACITY_DECISION_CATEGORY_CODE_DISCUSSIONS.equals(decisionCd))) {
      // 制限中止時間数が存在する場合
      if (((Object[]) args[ArrayIndex.TWO.ordinal()]).length != 0) {

        // 制限中止時間数
        arrayCalcVal = RateEngineCommonUtil.convertToDecimals((Object[]) args[ArrayIndex.TWO.ordinal()]);
        // 掛率
        calcRate = HANG_RATE_DISCUSSIONS;
      }
    }

    // 電圧区分コードが高圧かつ契約決定区分が実量制の場合
    if (ECISCodeConstants.CUSTOM_VOLTAGE_CAT_CODE_HIGH_TENSION.equals(voltagecatcode)
        && ECISCodeConstants.CONTRACT_CAPACITY_DECISION_CATEGORY_CODE_REALQUANTITY.equals(decisionCd)) {
      // 実量制の場合（制限中止日数が存在する場合計算）
      if (((Object[]) args[ArrayIndex.ONE.ordinal()]).length != 0) {

        // 制限中止日数
        arrayCalcVal = RateEngineCommonUtil.convertToDecimals((Object[]) args[ArrayIndex.ONE.ordinal()]);
        // 掛率
        calcRate = HANG_RATE_REALQUANTITY;
      }
    }

    CalcPartsFactory calcPartsFactory = new CalcPartsFactory();
    FeeCalcParts parts = calcPartsFactory.getParts(Round.class.getSimpleName());
    Object[] calcRet = null;

    // 計算実施
    for (BigDecimal arrayCalc : (BigDecimal[]) arrayCalcVal) {
      calcRet = parts.calc(basePrice.multiply(arrayCalc).multiply(calcRate), scale, rMode);
      retDiscount = retDiscount.add((BigDecimal) calcRet[ArrayIndex.ZERO.ordinal()]);
    }

    // デバッグログ出力
    LOGGER.debug("制限中止割引額={}", retDiscount);

    return new Object[] {retDiscount };
  }
}
