package jp.co.unisys.enability.cis.rate_engine.model;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import jp.co.unisys.enability.cis.entity.common.CalculatingDsUsage;
import jp.co.unisys.enability.cis.entity.common.CalculatingFixIn;
import jp.co.unisys.enability.cis.entity.common.CalculatingTsUsage;
import jp.co.unisys.enability.cis.entity.common.CalculatingUsage;
import jp.co.unisys.enability.cis.entity.common.CalculationResult;
import jp.co.unisys.enability.cis.entity.common.ClcBreakdown;
import jp.co.unisys.enability.cis.entity.common.ClcWarningData;
import jp.co.unisys.enability.cis.entity.common.ContractHist;
import jp.co.unisys.enability.cis.entity.common.Fcr;
import jp.co.unisys.enability.cis.entity.common.FcrBreakdown;
import jp.co.unisys.enability.cis.entity.common.FcrWarningData;
import jp.co.unisys.enability.cis.entity.common.Rm;
import jp.co.unisys.enability.cis.entity.common.SplContract;
import jp.co.unisys.enability.cis.rate_engine.business.ChargeUpManagementBusiness;
import jp.co.unisys.enability.cis.rate_engine.business.ContractClassCalcDetailManagementBusiness;

/**
 * 料金計算エンジンビジネスBean。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RateEngineBusinessBean {

  /**
   * 処理結果を保有する。
   */
  private Integer executeResult;

  /**
   * 計算結果をDBに登録するかのフラグを保有する。
   */
  private boolean registResultFlag = true;

  /**
   * 計算用使用量を保有する。
   */
  private CalculatingUsage calculatingUsage;

  /**
   * 計算用日割別使用量を保有する。
   */
  private List<CalculatingDsUsage> calculatingDateSlotUsage;

  /**
   * 計算用時間帯別使用量を保有する。
   */
  private List<CalculatingTsUsage> calculatingTimeSlotUsage;

  /**
   * 計算用指示数を保有する。
   */
  private CalculatingFixIn calculatingFixIn;

  /**
   * 計算結果を保有する。
   */
  private CalculationResult calculationResult;

  /**
   * 計算結果内訳を保有する。
   */
  private List<ClcBreakdown> clcBreakdown;

  /**
   * 計算結果警告データを保有する。
   */
  private List<ClcWarningData> calculationResultWarningData;

  /**
   * 付帯契約を保有する。
   */
  private List<SplContract> splContract;

  /**
   * 契約種別コードを保有する。
   */
  private String contractClassCode;

  /**
   * 契約種別管理ビジネスを保有する。
   */
  private ContractClassCalcDetailManagementBusiness contractClassCalcDetailManagement;

  /**
   * 料金単価管理ビジネスを保有する。
   */
  private ChargeUpManagementBusiness chargeUpManagement;

  /**
   * 確定料金実績を保有する。
   */
  private Fcr fixChargeResult;

  /**
   * 確定料金実績内訳データを保有する。
   */
  private List<FcrBreakdown> fcrBreakdowns;

  /**
   * 確定料金実績警告データを保有する。
   */
  private FcrWarningData fcrWarningData;

  /**
   * エリアコードを保有する。
   */
  private String areaCd;

  /**
   * 託送メニューIDを保有する。
   */
  private String consignmentMenuId;

  /**
   * 契約開始日を保有する。
   */
  private Date contractStartDate;

  /**
   * 契約終了日を保有する。
   */
  private Date contractEndDate;

  /**
   * 最低月額料金の名称を保有する。
   */
  private String minMonthlyChargeName;

  /**
   * 基本料金無料有無を保有する。
   */
  private String basicChargeFree;

  /**
   * 固定部分有りエリアリストを保有する。
   */
  private String fixChargeAreaList;

  /**
   * 付帯の名称を保有する。
   */
  private String supplementaryName;

  /**
   * 料金メニューを保有する。
   */
  private Rm rm;

  /**
   * 契約履歴を保有する。
   */
  private ContractHist contractHist;

  /**
   * 日割個数を保有する。
   */
  private int proratedQuantity;

  /**
   * 契約超過金計算倍率を保有する。
   */
  private BigDecimal contractExcessChargeCalcScaleFactor;

  /**
   * 契約超過金表示名称1を保有する。
   */
  private String contractExcessChargeDisplayName1;

  /**
   * 契約超過金表示名称2を保有する。
   */
  private String contractExcessChargeDisplayName2;

  /**
   * 処理結果のgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 処理結果
   */
  public Integer getExecuteResult() {
    return this.executeResult;
  }

  /**
   * 処理結果のsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param executeResult
   *          処理結果
   */
  public void setExecuteResult(Integer executeResult) {
    this.executeResult = executeResult;
  }

  /**
   * 計算用使用量のgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 計算用使用量
   */
  public CalculatingUsage getCalculatingUsage() {
    return this.calculatingUsage;
  }

  /**
   * 計算用使用量のsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param calculatingUsage
   *          計算用使用量
   */
  public void setCalculatingUsage(CalculatingUsage calculatingUsage) {
    this.calculatingUsage = calculatingUsage;
  }

  /**
   * 計算用日割別使用量のgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 計算用日割別使用量
   */
  public List<CalculatingDsUsage> getCalculatingDateSlotUsage() {
    return calculatingDateSlotUsage;
  }

  /**
   * 計算用日割別使用のsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param calculatingDateSlotUsage
   *          計算用日割別使用量
   */
  public void setCalculatingDateSlotUsage(List<CalculatingDsUsage> calculatingDateSlotUsage) {
    this.calculatingDateSlotUsage = calculatingDateSlotUsage;
  }

  /**
   * 計算用時間帯別使用量のgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 計算用時間帯別使用量
   */
  public List<CalculatingTsUsage> getCalculatingTimeSlotUsage() {
    return this.calculatingTimeSlotUsage;
  }

  /**
   * 計算用時間帯別使用量のsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param calculatingTimeSlotUsage
   *          計算用時間帯別使用量
   */
  public void setCalculatingTimeSlotUsage(
      List<CalculatingTsUsage> calculatingTimeSlotUsage) {
    this.calculatingTimeSlotUsage = calculatingTimeSlotUsage;
  }

  /**
   * 計算用指示数のgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 計算用指示数
   */
  public CalculatingFixIn getCalculatingFixIn() {
    return calculatingFixIn;
  }

  /**
   * 計算用指示数のsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param calculatingFixIn
   *          計算用指示数
   */
  public void setCalculatingFixIn(CalculatingFixIn calculatingFixIn) {
    this.calculatingFixIn = calculatingFixIn;
  }

  /**
   * 計算結果のgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 計算結果
   */
  public CalculationResult getCalculationResult() {
    return this.calculationResult;
  }

  /**
   * 計算結果のsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param calculationResult
   *          計算結果
   */
  public void setCalculationResult(CalculationResult calculationResult) {
    this.calculationResult = calculationResult;
  }

  /**
   * 計算結果内訳のgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 計算結果内訳
   */
  public List<ClcBreakdown> getClcBreakdown() {
    return this.clcBreakdown;
  }

  /**
   * 計算結果内訳のsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param clcBreakdown
   *          計算結果内訳
   */
  public void setClcBreakdown(List<ClcBreakdown> clcBreakdown) {
    this.clcBreakdown = clcBreakdown;
  }

  /**
   * 計算結果警告データのgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 計算結果警告データ
   */
  public List<ClcWarningData> getCalculationResultWarningData() {
    return this.calculationResultWarningData;
  }

  /**
   * 計算結果警告データのsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param calculationResultWarningData
   *          計算結果警告データ
   */
  public void setCalculationResultWarningData(List<ClcWarningData> calculationResultWarningData) {
    this.calculationResultWarningData = calculationResultWarningData;
  }

  /**
   * 付帯契約のgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 付帯契約
   */
  public List<SplContract> getSplContract() {
    return this.splContract;
  }

  /**
   * 付帯契約のsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param splContract
   *          付帯契約
   */
  public void setSplContract(List<SplContract> splContract) {
    this.splContract = splContract;
  }

  /**
   * 契約種別コードのgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約種別コード
   */
  public String getContractClassCode() {
    return this.contractClassCode;
  }

  /**
   * 契約種別コードのsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractClassCode
   *          契約種別コード
   */
  public void setContractClassCode(String contractClassCode) {
    this.contractClassCode = contractClassCode;
  }

  /**
   * 契約種別管理ビジネスのgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約種別管理ビジネス
   */
  public ContractClassCalcDetailManagementBusiness getContractClassCalcDetailManagement() {
    return this.contractClassCalcDetailManagement;
  }

  /**
   * 契約種別管理ビジネスのsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractClassCalcDetailManagement
   *          契約種別管理ビジネス
   */
  public void setContractClassCalcDetailManagement(
      ContractClassCalcDetailManagementBusiness contractClassCalcDetailManagement) {
    this.contractClassCalcDetailManagement = contractClassCalcDetailManagement;
  }

  /**
   * 料金単価管理ビジネスのgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 料金単価管理ビジネス
   */
  public ChargeUpManagementBusiness getChargeUpManagement() {
    return this.chargeUpManagement;
  }

  /**
   * 料金単価管理ビジネスのsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param chargeUpManagement
   *          料金単価管理ビジネス
   */
  public void setChargeUpManagement(
      ChargeUpManagementBusiness chargeUpManagement) {
    this.chargeUpManagement = chargeUpManagement;
  }

  /**
   * 確定料金実績のgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 確定料金実績
   */
  public Fcr getFixChargeResult() {
    return fixChargeResult;
  }

  /**
   * 確定料金実績のsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param fixChargeResult
   *          確定料金実績
   */
  public void setFixChargeResult(Fcr fixChargeResult) {
    this.fixChargeResult = fixChargeResult;
  }

  /**
   * 確定料金実績内訳のgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 確定料金実績内訳
   */
  public List<FcrBreakdown> getFcrBreakdowns() {
    return fcrBreakdowns;
  }

  /**
   * 確定料金実績内訳のsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param fcrBreakdowns
   *          確定料金実績内訳
   */
  public void setFcrBreakdowns(List<FcrBreakdown> fcrBreakdowns) {
    this.fcrBreakdowns = fcrBreakdowns;
  }

  /**
   * 確定料金実績警告データのgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 確定料金実績警告データ
   */
  public FcrWarningData getFcrWarningData() {
    return fcrWarningData;
  }

  /**
   * 確定料金実績警告データのsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param fcrWarningData
   *          確定料金実績警告データ
   */
  public void setFcrWarningData(FcrWarningData fcrWarningData) {
    this.fcrWarningData = fcrWarningData;
  }

  /**
   * 計算結果登録フラグのgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 計算結果登録フラグ
   */
  public boolean isRegistResultFlag() {
    return registResultFlag;
  }

  /**
   * 計算結果登録フラグのsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param registResultFlag
   *          計算結果登録フラグ
   */
  public void setRegistResultFlag(boolean registResultFlag) {
    this.registResultFlag = registResultFlag;
  }

  /**
   * エリアコードのgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return エリアコード
   */
  public String getAreaCd() {
    return areaCd;
  }

  /**
   * エリアコードのsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param areaCd
   *          エリアコード
   */
  public void setAreaCd(String areaCd) {
    this.areaCd = areaCd;
  }

  /**
   * 託送メニューIDのgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 託送メニューID
   */
  public String getConsignmentMenuId() {
    return consignmentMenuId;
  }

  /**
   * 託送メニューIDのsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param consignmentMenuId
   *          託送メニューID
   */
  public void setConsignmentMenuId(String consignmentMenuId) {
    this.consignmentMenuId = consignmentMenuId;
  }

  /**
   * 契約開始日のgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約開始日
   */
  public Date getContractStartDate() {
    return contractStartDate;
  }

  /**
   * 契約開始日のsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractStartDate
   *          契約開始日
   */
  public void setContractStartDate(Date contractStartDate) {
    this.contractStartDate = contractStartDate;
  }

  /**
   * 契約終了日のgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約終了日
   */
  public Date getContractEndDate() {
    return contractEndDate;
  }

  /**
   * 契約終了日のsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractEndDate
   *          契約終了日
   */
  public void setContractEndDate(Date contractEndDate) {
    this.contractEndDate = contractEndDate;
  }

  /**
   * 最低月額料金の名称のgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 最低月額料金の名称
   */
  public String getMinMonthlyChargeName() {
    return minMonthlyChargeName;
  }

  /**
   * 最低月額料金の名称のsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param minMonthlyChargeName
   *          最低月額料金の名称
   */
  public void setMinMonthlyChargeName(String minMonthlyChargeName) {
    this.minMonthlyChargeName = minMonthlyChargeName;
  }

  /**
   * 基本料金無料有無のgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 基本料金無料有無
   */
  public String getBasicChargeFree() {
    return basicChargeFree;
  }

  /**
   * 基本料金無料有無のsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param basicChargeFree
   *          基本料金無料有無
   */
  public void setBasicChargeFree(String basicChargeFree) {
    this.basicChargeFree = basicChargeFree;
  }

  /**
   * 固定部分有りエリアリストのgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 固定部分有りエリアリスト
   */
  public String getFixChargeAreaList() {
    return fixChargeAreaList;
  }

  /**
   * 固定部分有りエリアリストのsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param fixChargeAreaList
   *          固定部分有りエリアリスト
   */
  public void setFixChargeAreaList(String fixChargeAreaList) {
    this.fixChargeAreaList = fixChargeAreaList;
  }

  /**
   * 付帯の名称のgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 付帯の名称
   */
  public String getSupplementaryName() {
    return supplementaryName;
  }

  /**
   * 付帯の名称のsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param supplementaryName
   *          付帯の名称
   */
  public void setSupplementaryName(String supplementaryName) {
    this.supplementaryName = supplementaryName;
  }

  /**
   * 料金メニューのgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 料金メニュー
   */
  public Rm getRm() {
    return rm;
  }

  /**
   * 料金メニューのsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param rm
   *          料金メニュー
   */
  public void setRm(Rm rm) {
    this.rm = rm;
  }

  /**
   * 契約履歴のgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約履歴
   */
  public ContractHist getContractHist() {
    return contractHist;
  }

  /**
   * 契約履歴のsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractHist
   *          契約履歴
   */
  public void setContractHist(ContractHist contractHist) {
    this.contractHist = contractHist;
  }

  /**
   * 日割個数のgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 日割個数
   */
  public int getProratedQuantity() {
    return proratedQuantity;
  }

  /**
   * 日割個数のsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param proratedQuantity
   *          日割個数
   */
  public void setProratedQuantity(int proratedQuantity) {
    this.proratedQuantity = proratedQuantity;
  }

  /**
   * 契約超過金計算倍率のgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約超過金計算倍率
   */
  public BigDecimal getContractExcessChargeCalcScaleFactor() {
    return contractExcessChargeCalcScaleFactor;
  }

  /**
   * 契約超過金計算倍率のsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractExcessChargeCalcScaleFactor
   *          契約超過金計算倍率
   */
  public void setContractExcessChargeCalcScaleFactor(BigDecimal contractExcessChargeCalcScaleFactor) {
    this.contractExcessChargeCalcScaleFactor = contractExcessChargeCalcScaleFactor;
  }

  /**
   * 契約超過金表示名称1のgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約超過金表示名称1
   */
  public String getContractExcessChargeDisplayName1() {
    return contractExcessChargeDisplayName1;
  }

  /**
   * 契約超過金表示名称1のsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractExcessChargeDisplayName1
   *          契約超過金表示名称1
   */
  public void setContractExcessChargeDisplayName1(String contractExcessChargeDisplayName1) {
    this.contractExcessChargeDisplayName1 = contractExcessChargeDisplayName1;
  }

  /**
   * 契約超過金表示名称2のgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約超過金表示名称2
   */
  public String getContractExcessChargeDisplayName2() {
    return contractExcessChargeDisplayName2;
  }

  /**
   * 契約超過金表示名称2のsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractExcessChargeDisplayName2
   *          契約超過金表示名称2
   */
  public void setContractExcessChargeDisplayName2(String contractExcessChargeDisplayName2) {
    this.contractExcessChargeDisplayName2 = contractExcessChargeDisplayName2;
  }
}
