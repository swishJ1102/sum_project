package jp.co.unisys.enability.cis.rate_engine.component;

import java.math.BigDecimal;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import jp.co.unisys.enability.cis.common.Exception.RateEngineException;
import jp.co.unisys.enability.cis.common.util.rk.RateEngineCommonUtil;

/**
 * 除算。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class Divide implements FeeCalcParts {
  /** ロガー */
  private static final Logger LOGGER = LogManager.getLogger();

  /** 引数の数 */
  private static final int ARG_LENGTH = 4;

  /**
   * 除算（四則演算）を行う。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数の値を除算し、指定された桁数、方法で丸め処理を行った結果を返却する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param args
   *          args[0]:Object 被除数<br>
   *          args[1]:Object 除数<br>
   *          args[2]:Object 丸め桁（除算結果）<br>
   *          args[3]:Object 丸め方法（除算結果）<br>
   * @return 除算後、小数位置で丸めた結果(配列の要素数は1固定)
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   * @see RateEngineCommonUtil#checkArgsLength(Object...)
   * @see RateEngineCommonUtil#convertToDecimals(Object...)
   * @see RateEngineCommonUtil#convertStringToInt(Object...)
   * @see RateEngineCommonUtil#getRoundMode(Object...)
   */
  @Override
  public Object[] calc(Object... args) throws RateEngineException {
    // 引数チェック
    RateEngineCommonUtil.checkArgsLength(args, ARG_LENGTH);

    // 引数を変換
    BigDecimal[] decimals = RateEngineCommonUtil.convertToDecimals(args);

    // 除数が0の場合
    if (BigDecimal.ZERO.compareTo(decimals[ArrayIndex.ONE.ordinal()]) == 0) {
      // 除数が0のため、料金の計算が行えません。
      throw new RateEngineException("error.E1336");
    }

    // 丸め桁と丸め方法
    int scale = decimals[ArrayIndex.TWO.ordinal()].intValue();
    int roundMode = RateEngineCommonUtil.getRoundMode(decimals[ArrayIndex.THREE.ordinal()].intValue());

    // 丸め処理
    BigDecimal calced = decimals[ArrayIndex.ZERO.ordinal()].divide(decimals[ArrayIndex.ONE.ordinal()], scale, roundMode);

    // デバッグログ出力
    LOGGER.debug("小数点桁数丸め処理 ={} 小数点以下桁数={} 丸めモード={}", calced.toString(), scale, roundMode);

    // 結果を返却
    return new BigDecimal[] {calced };
  }

}
