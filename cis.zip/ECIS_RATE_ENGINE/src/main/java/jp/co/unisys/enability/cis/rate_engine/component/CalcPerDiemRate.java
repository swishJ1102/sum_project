package jp.co.unisys.enability.cis.rate_engine.component;

import java.math.BigDecimal;
import java.util.Date;

import jp.co.unisys.enability.cis.common.Exception.RateEngineException;
import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;
import jp.co.unisys.enability.cis.common.util.rk.RateEngineCommonUtil;

/**
 * 日割日数計算ビジネス
 *
 * @author "Nihon Unisys, Ltd."
 *
 */
public class CalcPerDiemRate extends
    ChargeCalcBaseBusiness implements FeeCalcParts {

  /***
   * 日割日数を返却する。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数.算定開始日 = 引数.契約開始日 または引数.算定終了日 = 引数.契約終了日 かつ<br>
   * 引数.算定終了日 － 引数.算定開始日 ＋ 1 ＜ 30の場合、<br>
   * 引数.算定終了日 － 引数.算定開始日 ＋ 1を分子に設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param args
   *          args[0]:Object 算定開始日<br>
   *          args[1]:Object 算定終了日<br>
   *          args[2]:Object 契約開始日<br>
   *          args[3]:Object 契約終了日<br>
   * @return 日割日数
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   * @see RateEngineCommonUtil#convertToDecimal(Object...)
   */
  @Override
  public Object[] calc(Object... args) throws RateEngineException {

    // 内部変数へキャストする
    // 算定開始日
    Date calcStartDate = (Date) args[ArrayIndex.ZERO.ordinal()];
    // 算定終了日
    Date calcEndDate = (Date) args[ArrayIndex.ONE.ordinal()];
    // 契約開始日
    Date contractStartDate = (Date) args[ArrayIndex.TWO.ordinal()];
    // 契約終了日
    Date contractEndDate = (Date) args[ArrayIndex.THREE.ordinal()];

    BigDecimal[] perDiem = new BigDecimal[] {new BigDecimal(ECISRKConstants.PER_DIEM_DAYS),
        new BigDecimal(ECISRKConstants.PER_DIEM_DAYS) };

    // 引数.算定終了日 － 引数.算定開始日 ＋ 1を求める。
    int dayDifference = (int) ((calcEndDate.getTime() - calcStartDate.getTime())
        / (24 * 60 * 60 * 1000) + 1);

    // 引数.算定開始日 = 引数.契約開始日 または
    if ((calcStartDate.equals(contractStartDate) ||
    // 引数.算定終了日 = 引数.契約終了日 かつ
        calcEndDate.equals(contractEndDate)) &&
    // 引数.算定終了日 － 引数.算定開始日 ＋ 1 ＜ 30の場合
        dayDifference < 30) {
      // 引数.算定終了日 － 引数.算定開始日 ＋ 1を分子に設定する。
      perDiem[0] = RateEngineCommonUtil.convertToDecimal(dayDifference);
    }

    return perDiem;
  }

}
