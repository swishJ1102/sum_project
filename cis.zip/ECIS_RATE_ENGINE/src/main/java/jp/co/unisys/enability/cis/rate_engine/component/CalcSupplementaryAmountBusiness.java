package jp.co.unisys.enability.cis.rate_engine.component;

import java.math.BigDecimal;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import jp.co.unisys.enability.cis.common.Exception.RateEngineException;
import jp.co.unisys.enability.cis.common.util.constants.ECISCodeConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;
import jp.co.unisys.enability.cis.common.util.rk.RateEngineCommonUtil;

/**
 * 付帯金額個別計算ビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class CalcSupplementaryAmountBusiness implements FeeCalcParts {
  /** ロガー */
  private static final Logger LOGGER = LogManager.getLogger();

  /** この部品がサポートする固定パラメータ数 */
  private static final int ARG_LENGTH = 11;

  /**
   * 付帯金額を付帯契約単位に計算を行う。<br>
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された情報をもとに付帯金額を計算する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param args
   *          args[0]:Object 基本料金<br>
   *          args[1]:Object 従量料金<br>
   *          args[2]:Object 対象区分<br>
   *          args[3]:Object 適用区分<br>
   *          args[4]:Object 種別<br>
   *          args[5]:Object 割引割増区分<br>
   *          args[6]:Object 額率<br>
   *          args[7]:Object 上限額<br>
   *          args[8]:Object 下限額<br>
   *          args[9]:Object 丸め桁（計算額）<br>
   *          args[10]:Object 丸め方法（計算額）<br>
   * @return 付帯金額
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   * @see RateEngineCommonUtil#checkArgsLengthPermitNullVal(Object...)
   * @see RateEngineCommonUtil#convertToDecimals(Object...)
   */
  @Override
  public Object[] calc(Object... args) throws RateEngineException {
    int[] nullPermitIndexs = new int[] {1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1 };
    // 引数長チェック
    RateEngineCommonUtil.checkArgsLengthPermitNullVal(args, ARG_LENGTH, nullPermitIndexs);

    BigDecimal[] decimals = RateEngineCommonUtil.convertToDecimals(args);

    // 付帯金額算出対象となるベースを決める
    BigDecimal supplementaryObjectPrice;
    // 対象区分により、付帯対象金額取得
    switch (decimals[ArrayIndex.TWO.ordinal()].toString()) {
      case ECISCodeConstants.SPL_COVERED_CAT_CODE_DC:
        // 基本料金
        supplementaryObjectPrice = decimals[ArrayIndex.ZERO.ordinal()];
        break;
      case ECISCodeConstants.SPL_COVERED_CAT_CODE_EC:
        // 従量料金
        supplementaryObjectPrice = decimals[ArrayIndex.ONE.ordinal()];
        break;
      case ECISCodeConstants.SPL_COVERED_CAT_CODE_DCEC:
        // 基本料金 ＋ 従量料金
        supplementaryObjectPrice = decimals[ArrayIndex.ZERO.ordinal()].add(decimals[ArrayIndex.ONE.ordinal()]);
        break;
      default:
        // 対象無し
        supplementaryObjectPrice = BigDecimal.ZERO;
    }

    // 付帯の額・率をまずはそのまま格納
    BigDecimal supplementarytValue = decimals[ArrayIndex.SIX.ordinal()];
    // 付帯額は別で定義（付帯額に別の意味合いの値が入るのはバグにつながる）
    BigDecimal supplementarytPrice = BigDecimal.ZERO;

    // 種別により、付帯額取得
    switch (decimals[ArrayIndex.FOUR.ordinal()].toString()) {
      case ECISRKConstants.SUPPLEMENTARY_CLASS_CODE_FIXED_AMOUNT:
        // 定額（指定された額をそのまま設定）
        supplementarytPrice = supplementarytValue;
        break;
      case ECISRKConstants.SUPPLEMENTARY_CLASS_CODE_FIXED_RATE:
        // 定率
        // 算出対象となるベース金額に乗算
        supplementarytPrice = supplementaryObjectPrice.multiply(supplementarytValue);
        break;
      default:
        // 変な種別が指定された場合は付帯をゼロにしておく。
        supplementarytPrice = BigDecimal.ZERO;
    }

    // 端数処理（丸め桁、丸め方法）
    int scale = decimals[ArrayIndex.NINE.ordinal()].intValue();
    int roundMode = decimals[ArrayIndex.TEN.ordinal()].intValue();
    // 丸め処理
    supplementarytPrice = supplementarytPrice.setScale(scale, roundMode);

    // 定率のときだけ、以下の処理を行う（定率以外は上限、下限が0の可能性を考慮）
    if (ECISRKConstants.SUPPLEMENTARY_CLASS_CODE_FIXED_RATE.equals(decimals[ArrayIndex.FOUR.ordinal()].toString())) {
      // 上限額の適用：もし上限を超えていたら上限額に設定
      if (supplementarytPrice.compareTo(decimals[ArrayIndex.SEVEN.ordinal()]) > 0
          && decimals[ArrayIndex.SEVEN.ordinal()].compareTo(BigDecimal.ZERO) != 0) {
        supplementarytPrice = decimals[ArrayIndex.SEVEN.ordinal()];
      } else if (supplementarytPrice.compareTo(decimals[ArrayIndex.EIGHT.ordinal()]) < 0) {
        // 下限額の適用：もし下限額を下回っていたら、下限に設定
        supplementarytPrice = decimals[ArrayIndex.EIGHT.ordinal()];
      }
    }

    // 額・率は常に正の値である前提。
    // 割引割増区分コードが1：割引の場合は符号をマイナスに
    if (ECISCodeConstants.DISCOUNT_CATEGORY_CODE_DISCOUNT.equals(decimals[ArrayIndex.FIVE.ordinal()].toString())) {
      supplementarytPrice = supplementarytPrice.negate();
    }

    // 結果を格納
    BigDecimal[] result = new BigDecimal[] {
        supplementarytPrice, decimals[ArrayIndex.TWO.ordinal()],
        decimals[ArrayIndex.THREE.ordinal()], decimals[ArrayIndex.FOUR.ordinal()],
        decimals[ArrayIndex.FIVE.ordinal()], decimals[ArrayIndex.SIX.ordinal()] };

    // デバッグログを出力
    LOGGER.debug("付帯額={} 対象区分={} 適用区分={} 種別={} 割引区分={} 額率={}", (Object[]) result);

    // 結果を返却
    return result;
  }

}
