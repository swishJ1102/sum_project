package jp.co.unisys.enability.cis.rate_engine.component;

import java.math.BigDecimal;
import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import jp.co.unisys.enability.cis.common.Exception.RateEngineException;
import jp.co.unisys.enability.cis.common.util.rk.RateEngineCommonUtil;

/**
 * 基本料金計算（従量電灯B）ビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class BasicChargeCalcUsageBasedBRateBusiness extends ChargeCalcBaseBusiness implements FeeCalcParts {
  /** ロガー */
  private static final Logger LOGGER = LogManager.getLogger();

  /** この部品がサポートする固定パラメータ数 */
  private static final int ARG_LENGTH = 16;

  /**
   * 従量電灯Bの基本料金の計算を行う。<br>
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された情報をもとに従量電灯Bの基本料金を計算する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param args
   *          args[0]:Object 契約容量<br>
   *          args[1]:Object 段リスト<br>
   *          args[2]:Object 単価リスト<br>
   *          args[3]:Object 使用量<br>
   *          args[4]:Object 検針日数<br>
   *          args[5]:Object 日割日数<br>
   *          args[6]:Object 丸め桁（合計）<br>
   *          args[7]:Object 丸め方法（合計）<br>
   *          args[8]:Object 閾値名称リスト<br>
   *          args[9]:Object 算定期間開始日<br>
   *          args[10]:Object 算定期間終了日<br>
   *          args[11]:Object 契約開始日<br>
   *          args[12]:Object 契約終了日<br>
   *          args[13]:Object 基本料金無料有無<br>
   *          args[14]:Object 表示用名称1リスト<br>
   *          args[15]:Object 表示用名称2リスト<br>
   * @return 基本料金(従量電灯B)
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   * @see RateEngineCommonUtil#checkArgsLength(Object...)
   * @see RateEngineCommonUtil#convertToDecimals(Object...)
   * @see RateEngineCommonUtil#getCompareResult(Object...)
   * @see RateEngineCommonUtil#convertStringToInt(Object...)
   * @see RateEngineCommonUtil#getRoundMode(Object...)
   */
  @Override
  public Object[] calc(Object... args) throws RateEngineException {
    // 引数長チェック
    RateEngineCommonUtil.checkArgsLength(args, ARG_LENGTH);

    BigDecimal[] decimals = RateEngineCommonUtil.convertToDecimals(new Object[] {args[ArrayIndex.ZERO.ordinal()],
        args[ArrayIndex.THREE.ordinal()], args[ArrayIndex.FOUR.ordinal()], args[ArrayIndex.FIVE.ordinal()],
        args[ArrayIndex.SIX.ordinal()], args[ArrayIndex.SEVEN.ordinal()] });

    // 基本料金計算係数
    super.setBasicPriceCoefficient(decimals[ArrayIndex.ONE.ordinal()]);
    // 日割り率
    super.setPerDiemRate(decimals[ArrayIndex.THREE.ordinal()], decimals[ArrayIndex.TWO.ordinal()]);

    // 契約容量をチェックする。
    int priceIndex = RateEngineCommonUtil.getIndexByContractCapacity(args[ArrayIndex.ZERO.ordinal()],
        args[ArrayIndex.ONE.ordinal()]);
    if (priceIndex < 0) {
      LOGGER.error("BasicChargeCalcUsageBasedBRateBusiness＞契約容量が存在しません。容量={}", args[ArrayIndex.ZERO.ordinal()]);
      // 契約容量に該当する単価が存在しないため、料金の計算が行えません。契約容量:{0}
      throw new RateEngineException("error.E1327", args[ArrayIndex.ZERO.ordinal()].toString());
    }

    // 単価を取得する
    BigDecimal unitPrice = RateEngineCommonUtil.getContractCapacityPrice(priceIndex,
        args[ArrayIndex.TWO.ordinal()]);

    // 料金計算する
    BigDecimal basicPrice = super.calcDCPrice(unitPrice, decimals[ArrayIndex.FOUR.ordinal()],
        decimals[ArrayIndex.FIVE.ordinal()]);

    // 閾値名称を取得する
    Object[] nameArray = (Object[]) args[ArrayIndex.EIGHT.ordinal()];
    String name = null;
    if (nameArray[priceIndex] != null) {
      name = nameArray[priceIndex].toString();
    }
    // 表示用名称1を取得する
    Object[] dispName1Array = (Object[]) args[ArrayIndex.FOURTEEN.ordinal()];
    String dispName1 = null;
    if (dispName1Array[priceIndex] != null) {
      dispName1 = dispName1Array[priceIndex].toString();
    }

    // 表示用名称2を取得する
    Object[] dispName2Array = (Object[]) args[ArrayIndex.FIFTEEN.ordinal()];
    String dispName2 = null;
    if (dispName2Array[priceIndex] != null) {
      dispName2 = dispName2Array[priceIndex].toString();
    }

    // 初月無料であるか計算する
    basicPrice = super.getBasePrice(basicPrice, (Date) args[ArrayIndex.NINE.ordinal()],
        (Date) args[ArrayIndex.TEN.ordinal()], (Date) args[ArrayIndex.ELEVEN.ordinal()],
        (Date) args[ArrayIndex.TWELEV.ordinal()], args[ArrayIndex.THIRTEEN.ordinal()].toString());

    LOGGER.debug("基本料金計算（従量電灯B={} 契約容量={} 単価={} 閾値名称={}", basicPrice.toString(),
        decimals[ArrayIndex.ZERO.ordinal()].toString(),
        unitPrice.toString(), name);

    return new Object[] {basicPrice, decimals[ArrayIndex.ZERO.ordinal()], unitPrice, name, dispName1, dispName2 };
  }

}
