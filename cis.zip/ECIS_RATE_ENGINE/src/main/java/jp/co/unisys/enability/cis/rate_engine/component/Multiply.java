package jp.co.unisys.enability.cis.rate_engine.component;

import java.math.BigDecimal;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import jp.co.unisys.enability.cis.common.Exception.RateEngineException;
import jp.co.unisys.enability.cis.common.util.rk.RateEngineCommonUtil;

/**
 * 乗算。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class Multiply implements FeeCalcParts {

  /** ロガー */
  private static final Logger LOGGER = LogManager.getLogger();

  /**
   * 乗算（四則演算）を行う。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数の値をBigDecimal型に変換した後、全て引数の値を乗算した結果を返却する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param args
   *          引数(可変長)<br>
   *          args[0]:Object 乗算する数値1<br>
   *          args[1]:Object 乗算する数値2<br>
   *          args[n]:Object 乗算する数値n<br>
   * @return 乗算結果(配列の要素数は1固定)
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   * @see RateEngineCommonUtil#convertToDecimals(Object...)
   */
  @Override
  public Object[] calc(Object... args) throws RateEngineException {
    // 引数を変換
    BigDecimal[] decimals = RateEngineCommonUtil.convertToDecimals(args);

    BigDecimal calced = decimals[0];
    // 引数で指定された要素の数分、演算
    for (int i = 1; i < decimals.length; i++) {
      calced = calced.multiply(decimals[i]);
    }

    // デバッグログ出力
    LOGGER.debug("乗算結果={}", calced.toString());

    Object[] ret = new Object[1];
    ret[0] = calced;

    // 結果を返却
    return ret;
  }

  /**
   * 乗算を行う。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数の値をBigDecimal型に変換した後、全て引数の値を乗算した結果を返却する。
   * </pre>
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param args
   *          引数(可変長)<br>
   *          args[0]:BigDecimal 乗算する数値1<br>
   *          args[1]:BigDecimal 乗算する数値2<br>
   *          args[n]:BigDecimal 乗算する数値n<br>
   * @return 乗算結果(配列の要素数は1固定)
   */
  public static BigDecimal multiply(BigDecimal... args) {

    BigDecimal calced = args[0];

    // 引数で指定された要素の数分、演算
    for (int i = 1; i < args.length; i++) {
      calced = calced.multiply(args[i]);
    }

    // デバッグログ出力
    LOGGER.debug("乗算結果={}", calced.toString());

    // 結果を返却
    return calced;
  }

}
