package jp.co.unisys.enability.cis.rate_engine.component;

import java.math.BigDecimal;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import jp.co.unisys.enability.cis.common.Exception.RateEngineException;
import jp.co.unisys.enability.cis.common.util.rk.RateEngineCommonUtil;

/**
 * 3段料金可変閾値計算ビジネス
 *
 * @author "Nihon Unisys, Ltd."
 *
 */
public class VariableThresholdOfThreeStepChargeCalcBusiness extends
    ChargeCalcBaseBusiness implements FeeCalcParts {
  /** ロガー */
  private static final Logger LOGGER = LogManager.getLogger();

  /** この部品がサポートする固定パラメータ数 */
  private static final int ARG_LENGTH = 2;

  /**
   * 3段料金可変閾値を算出する<br>
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された閾値係数リストをもとに閾値を算出したリストを返却する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param args
   *          args[0]:Object 契約電力<br>
   *          args[1]:Object 閾値係数リスト<br>
   * @return 閾値リスト
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   * @see RateEngineCommonUtil#checkArgsLength(Object...)
   * @see RateEngineCommonUtil#convertToDecimals(Object...)
   */
  @Override
  public Object[] calc(Object... args) throws RateEngineException {

    // 引数長チェック
    RateEngineCommonUtil.checkArgsLength(args, ARG_LENGTH);

    // パラメータをデバッグログ出力
    LOGGER.debug("契約電力={} 閾値係数1...n={}",
        args[ArrayIndex.ZERO.ordinal()], args[ArrayIndex.ONE.ordinal()]);

    // 契約電力を数値に変換
    BigDecimal contractPower = RateEngineCommonUtil
        .convertToDecimal(args[ArrayIndex.ZERO.ordinal()]);

    // 閾値係数リストを数値に変換
    BigDecimal[] thresholdCoefficientList = RateEngineCommonUtil
        .convertToDecimals((Object[]) args[ArrayIndex.ONE.ordinal()]);

    // 閾値係数リストをチェックする。
    for (int n = 0; n < thresholdCoefficientList.length; n++) {
      // 変数：閾値係数リスト[n] ＜ 0 の場合
      if (thresholdCoefficientList[n].compareTo(BigDecimal.ZERO) < 0) {
        LOGGER.error("VariableThresholdOfThreeStepChargeCalcBusiness＞閾値係数が0未満のため、料金の計算が行えません。閾値係数={}",
            thresholdCoefficientList[n]);
        // {0}段目の閾値係数が0未満のため、料金の計算が行えません。閾値係数:{1}
        throw new RateEngineException("error.E9010", String.valueOf(n), thresholdCoefficientList[n].toString());
      }
    }

    // 閾値リストを変数：閾値係数リストの要素数で宣言する
    BigDecimal[] thresholdList = new BigDecimal[thresholdCoefficientList.length];
    // 変数：閾値係数リストの要素数分、以下の処理を繰り返し行う。
    for (int i = 0; i < thresholdCoefficientList.length; i++) {
      // 閾値を算出する。
      thresholdList[i] = contractPower.multiply(thresholdCoefficientList[i]);
    }

    // 結果を返却
    LOGGER.debug("計算結果 ={}", (Object[]) thresholdList);
    return new Object[] {thresholdList };
  }

}
