package jp.co.unisys.enability.cis.rate_engine.business;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.TreeMap;
import java.util.regex.Pattern;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import jp.co.unisys.enability.cis.common.Exception.RateEngineException;
import jp.co.unisys.enability.cis.common.util.CommonValidationUtil;
import jp.co.unisys.enability.cis.common.util.EMSConstants;
import jp.co.unisys.enability.cis.common.util.StringConvertUtil;
import jp.co.unisys.enability.cis.common.util.constants.ECISCodeConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISKJConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;
import jp.co.unisys.enability.cis.common.util.rk.DcecDetailProps;
import jp.co.unisys.enability.cis.common.util.rk.RateEngineCommonUtil;
import jp.co.unisys.enability.cis.common.util.rk.RateEngineReflectionUtil;
import jp.co.unisys.enability.cis.common.util.rk.SetArgs;
import jp.co.unisys.enability.cis.entity.common.CalculatingDsUsage;
import jp.co.unisys.enability.cis.entity.common.CalculatingTsUsage;
import jp.co.unisys.enability.cis.entity.common.CalculatingUsage;
import jp.co.unisys.enability.cis.entity.common.CalculationResult;
import jp.co.unisys.enability.cis.entity.common.ClcBreakdown;
import jp.co.unisys.enability.cis.entity.common.ContractHist;
import jp.co.unisys.enability.cis.entity.common.Cr;
import jp.co.unisys.enability.cis.entity.common.CrUp;
import jp.co.unisys.enability.cis.entity.common.CrUpDetail;
import jp.co.unisys.enability.cis.entity.common.CtRateM;
import jp.co.unisys.enability.cis.entity.common.FcaUpM;
import jp.co.unisys.enability.cis.entity.common.FcaUpTrM;
import jp.co.unisys.enability.cis.entity.common.RcUpM;
import jp.co.unisys.enability.cis.entity.common.RecUpM;
import jp.co.unisys.enability.cis.entity.common.RecUpTrM;
import jp.co.unisys.enability.cis.entity.common.RmUp;
import jp.co.unisys.enability.cis.entity.common.RmUpDetail;
import jp.co.unisys.enability.cis.entity.common.SplContract;
import jp.co.unisys.enability.cis.entity.common.Spm;
import jp.co.unisys.enability.cis.entity.common.SpmUp;
import jp.co.unisys.enability.cis.rate_engine.component.CalcSupplementaryAmountBusiness;
import jp.co.unisys.enability.cis.rate_engine.component.CalcSupplementaryAmountProratedBusiness;
import jp.co.unisys.enability.cis.rate_engine.model.CalReserveContractBusinessBean;
import jp.co.unisys.enability.cis.rate_engine.model.CalRestrictDisInfoBusinessBean;
import jp.co.unisys.enability.cis.rate_engine.model.CalcReserveContractInfoBean;
import jp.co.unisys.enability.cis.rate_engine.model.RoundBusinessBean;

/**
 * 料金計算情報管理ビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class CalcInfoManagementBusiness {

  /** ロガー */
  private static final Logger LOGGER = LogManager.getLogger();

  /** 代入フラグ */
  private static final Pattern PTN_ACCESS_TO_CALCED_RESULT = Pattern
      .compile("\\d+-\\d+");

  /** 付帯代入フラグ */
  private static final String SETSPM = "SETSPM";

  // 2016/04/08 付帯の日割 start
  private static final String SETSPMPRORATED = "SETSPMPRORATED";
  // 2016/04/08 付帯の日割 end

  /** 不要な段を削除する演算方式 */
  private static final String DELETESTAGE = "DELETESTAGE";

  /** 不要な最低月額料金を削除する演算方式 */
  private static final String DELETELOWESTPRICE = "DELETELOWESTPRICE";

  // 2016/03/24 契約電力あたりの割引 start
  /** 不要な付帯契約を削除する演算方式 */
  private static final String DELETESPLCONTRACT = "DELETESPLCONTRACT";
  // 2016/03/24 契約電力あたりの割引 end

  /** 不要な金額段削除を削除する演算方式 */
  private static final String DELETERENONEEDCHARGESTAGE = "DELETERENONEEDCHARGESTAGE";

  /** 複数代入フラグ */
  private static final String SETPLURAL = "SETPLURAL";

  /** 足し込み有無（足し込み） */
  private static final String ADDCHECK_ADD = "1";

  /** 計算用予備契約情報ビジネスBeanの予備単価項目の物理項目名 */
  private static final String RESERVEUNITPRICE = "reserveUnitPrice";

  /** 契約ID */
  private String contractId;

  /** 利用年月 */
  private String usePeriod;

  /** 料金算定開始日 */
  private Date calcSd;

  /** 料金算定終了日 */
  private Date calcEd;

  /** 料金メニューID */
  private String rateMenuId;

  /** 託送メニューID */
  private String consignmentMenuId;

  /** エリアコード */
  private String areaCd;

  /** 契約開始日 */
  private Date contractSd;

  /** 契約終了日 */
  private Date contractEd;

  /** 付帯契約リスト */
  private Map<String, SplContract> splContractMap;

  /** 計算用使用量 */
  private CalculatingUsage calcUsage;

  /** 計算用日割別使用量 */
  private List<CalculatingDsUsage> calcDsUsageList;

  /** 計算用時間帯別使用量 */
  private Map<String, CalculatingTsUsage> calcTsUsageMap;

  /** 計算用予備契約情報 */
  private List<CalReserveContractBusinessBean> calResContList;

  /** 計算用制限中止割引情報 */
  private List<CalRestrictDisInfoBusinessBean> calResDisInfoList;

  /** 料金単価管理ビジネス */
  private ChargeUpManagementBusiness chargeUpManagement;

  /** 計算結果 */
  private CalculationResult calculationResult;

  /** 計算結果内訳 */
  private Map<String, ClcBreakdown> clcBreakdownMap;

  /** 計算結果マップ */
  private Map<Integer, Object[]> calcDetailResultsMap;

  /** 契約種別コードを保有 */
  private String contractClassCode;

  /** 丸め情報 */
  private Map<String, RoundBusinessBean> roundMap;

  /** 最低月額料金の名称 */
  private String minMonthlyChargeName;

  /** 基本料金無料 */
  private String basicChargeFree;

  /** 固定部分有りエリアリスト */
  private String fixChargeAreaList;

  /** 付帯の名称 */
  private String supplementaryName;

  /** 時間帯別使用量Map */
  private Map<String, CalculatingTsUsage> calculatingTsUsageList;

  /** 契約履歴 */
  private ContractHist contractHist;

  /** 燃調単価取得方法区分 */
  private String fcaUpGetWayCategory;

  /** 日割山インデックス */
  private int proratedIndex;

  /** 日割開始日 */
  private Date dateSlotStartDate;

  /** 計算後予備契約情報 */
  private List<CalcReserveContractInfoBean> calcResContInfoList;

  /** 予備契約基本料金の名称 */
  private String reserveContractBasicChargeRowName;

  /** 予備線基本料金の名称 */
  private String reserveLineBasicChargeRowName;

  /** 予備電源基本料金の名称 */
  private String reservePowerSupplyBasicChargeRowName;

  /** 制限中止割引金額の名称 */
  private String restrictionDiscountChargeRowName;

  /** 制限中止_主契約の名称 */
  private String restrictionDiscountContractRowName;

  /** 制限中止_予備線の名称 */
  private String restrictionDiscountReserveLineRowName;

  /** 制限中止_予備電源の名称 */
  private String restrictionDiscountReservePowerRowName;

  /** 日割個数 */
  private int proratedQuantity;

  /** 契約超過金計算倍率 */
  private BigDecimal contractExcessChargeCalcScaleFactor;

  /** 契約超過金表示名称1 */
  private String contractExcessChargeDisplayName1;

  /** 契約超過金表示名称2 */
  private String contractExcessChargeDisplayName2;

  /** 消費税率マスタ */
  private CtRateM ctRateM;

  /**
   * コンストラクタ。
   *
   * @author "Nihon Unisys, Ltd." * @param chargeUPManagement 料金単価管理ビジネス
   */
  public CalcInfoManagementBusiness(
      ChargeUpManagementBusiness chargeUpManagement) {
    this.chargeUpManagement = chargeUpManagement;
  }

  /**
   * 演算方式が「代入」であるか判定を行う。
   *
   * @author "Nihon Unisys, Ltd."
   * @param oprationName
   *          演算方式
   * @return 判定結果（true：代入／false：代入以外）
   */
  public static boolean isWriteOperaion(String oprationName) {
    if (ECISRKConstants.CALC_RESERVED_OPERATION_SET.equals(oprationName)) {
      return true;
    }
    return false;
  }

  /**
   * 演算方式が「付帯代入」であるか判定を行う。
   *
   * @author "Nihon Unisys, Ltd."
   * @param oprationName
   *          演算方式
   * @return 判定結果（true：付帯代入／false：付帯代入以外）
   */
  public static boolean isWriteSpmOperaion(String oprationName) {
    if (SETSPM.equals(oprationName)) {
      return true;
    }
    return false;
  }

  // 2016/04/08 付帯の日割 start
  /**
   * 演算方式が「付帯日割代入」であるか判定を行う。
   *
   * @author "Nihon Unisys, Ltd."
   * @param oprationName
   *          演算方式
   * @return 判定結果（true：付帯日割代入／false：付帯日割代入以外）
   */
  public static boolean isWriteSpmProratedOperaion(String oprationName) {
    if (SETSPMPRORATED.equals(oprationName)) {
      return true;
    }
    return false;
  }

  // 2016/04/08 付帯の日割 end

  /**
   * 演算方式が「段削除」であるか判定を行う。
   *
   * @author "Nihon Unisys, Ltd."
   * @param oprationName
   *          演算方式
   * @return 判定結果（true：段削除／false：段削除以外）
   */
  public static boolean isWriteDeleteStageOperaion(String oprationName) {
    if (DELETESTAGE.equals(oprationName)) {
      return true;
    }
    return false;
  }

  /**
   * 演算方式が「最低料金月額削除」であるか判定を行う。
   *
   * @author "Nihon Unisys, Ltd."
   * @param oprationName
   *          演算方式
   * @return 判定結果（true：最低料金月額削除／false：最低料金月額削除以外）
   */
  public static boolean isWriteDeleteLowestPriceOperaion(String oprationName) {
    if (DELETELOWESTPRICE.equals(oprationName)) {
      return true;
    }
    return false;
  }

  // 2016/03/24 契約電力あたりの割引 start
  /**
   * 演算方式が「付帯契約削除」であるか判定を行う。
   *
   * @author "Nihon Unisys, Ltd."
   * @param oprationName
   *          演算方式
   * @return 判定結果（true：付帯契約削除／false：付帯契約削除以外）
   */
  public static boolean isWriteDeleteSplContractOperaion(String oprationName) {
    if (DELETESPLCONTRACT.equals(oprationName)) {
      return true;
    }
    return false;
  }

  // 2016/03/24 契約電力あたりの割引 end

  /**
   * 演算方式が「不要金額段削除判定」であるか判定を行う。
   *
   * @author "Nihon Unisys, Ltd."
   * @param oprationName
   *          操作名
   * @return 判定結果（true:不要金額段削除フラグ／false:不要金額段削除フラグ以外）
   */
  public static boolean isWriteDeleteNoNeedStageOperaion(String oprationName) {
    if (DELETERENONEEDCHARGESTAGE.equals(oprationName)) {
      return true;
    }
    return false;
  }

  /**
   * 演算方式が「複数代入」であるか判定を行う。
   *
   * @author "Nihon Unisys, Ltd."
   * @param oprationName
   *          操作名
   * @return 判定結果（true：複数代入／false：複数代入以外）
   */
  public static boolean isWritePluralOperaion(String oprationName) {
    if (SETPLURAL.equals(oprationName)) {
      return true;
    }
    return false;
  }

  /**
   * 計算処理1回分の計算のための情報と計算結果データの初期化を行う。
   *
   * @param contractIdParam
   *          契約ID
   * @param usePeriodParam
   *          利用年月
   * @param calcSdParam
   *          料金算定開始日
   * @param calcEdParam
   *          料金算定終了日
   * @param rateMenuIdParam
   *          料金メニューID
   * @param areaCdParam
   *          エリアコード
   * @param consignmentMenuIdParam
   *          託送メニューID
   * @param contractSdParam
   *          契約開始日
   * @param contractEdParam
   *          契約終了日
   * @param splContractMapParam
   *          付帯契約Map
   * @param calcUsageParam
   *          計算用使用量
   * @param calcDsUsageListParam
   *          計算用日割別使用量
   * @param calcTsUsageMapParam
   *          計算用時間帯別使用量
   * @param calReserveContractListParam
   *          計算用予備契約情報
   * @param calRestrictDisInfoListParam
   *          計算用制限中止割引情報
   * @param ccCodeParam
   *          契約種別コード
   * @param roundMapParam
   *          丸め
   * @param minMonthlyChargeNameParam
   *          最低月額料金名称
   * @param basicChargeFreeParam
   *          基本料金無料
   * @param fixChargeAreaListParam
   *          固定部分有りエリアリスト
   * @param supplementaryNameParam
   *          付帯名称
   * @param calculatingTsUsageListParam
   *          時間帯別使用量Map
   * @param contractHistParam
   *          契約履歴
   * @param fcaUpGetWayCategoryParam
   *          燃調単価取得方法区分
   * @param resContractBasicChargeRowName
   *          予備契約基本料金の名称
   * @param resLineBasicChargeRowName
   *          予備線基本料金の名称
   * @param resPowerSupplyBasicChargeRowName
   *          予備電源基本料金の名称
   * @param restrictionDisChargeRowName
   *          制限中止割引金額の名称
   * @param restrictionDisContractRowName
   *          制限中止_主契約の名称
   * @param restrictionDisReserveLineRowName
   *          制限中止_予備線の名称
   * @param restrictionDisReservePowerRowName
   *          制限中止_予備電源の名称
   * @param proratedQuantity
   *          日割個数
   * @param contractExcessChargeCalcScaleFactor
   *          契約超過金計算倍率
   * @param contractExcessChargeDisplayName1
   *          契約超過金表示名称1
   * @param contractExcessChargeDisplayName2
   *          契約超過金表示名称2
   * @throws RateEngineException
   */
  public void initData(String contractIdParam, String usePeriodParam,
      Date calcSdParam, Date calcEdParam, String rateMenuIdParam, String areaCdParam,
      String consignmentMenuIdParam, Date contractSdParam, Date contractEdParam,
      Map<String, SplContract> splContractMapParam,
      CalculatingUsage calcUsageParam, List<CalculatingDsUsage> calcDsUsageListParam,
      List<CalculatingTsUsage> calcTsUsageMapParam,
      List<CalReserveContractBusinessBean> calReserveContractListParam,
      List<CalRestrictDisInfoBusinessBean> calRestrictDisInfoListParam, String ccCodeParam,
      Map<String, RoundBusinessBean> roundMapParam, String minMonthlyChargeNameParam,
      String basicChargeFreeParam,
      String fixChargeAreaListParam,
      String supplementaryNameParam,
      Map<String, CalculatingTsUsage> calculatingTsUsageListParam,
      ContractHist contractHistParam,
      String fcaUpGetWayCategoryParam,
      String resContractBasicChargeRowName, String resLineBasicChargeRowName,
      String resPowerSupplyBasicChargeRowName, String restrictionDisChargeRowName,
      String restrictionDisContractRowName, String restrictionDisReserveLineRowName,
      String restrictionDisReservePowerRowName,
      BigDecimal contractExcessChargeCalcScaleFactor,
      int proratedQuantity,
      String contractExcessChargeDisplayName1,
      String contractExcessChargeDisplayName2) throws RateEngineException {

    // --- キー情報の初期化 ---
    // 契約ID
    this.contractId = contractIdParam;
    // 利用年月
    this.usePeriod = usePeriodParam;
    // 料金算定開始日
    this.calcSd = calcSdParam;
    // 料金算定終了日
    this.calcEd = calcEdParam;
    // 料金メニューID
    this.rateMenuId = rateMenuIdParam;
    // エリアコード
    this.areaCd = areaCdParam;
    // 託送メニューID
    this.consignmentMenuId = consignmentMenuIdParam;
    // 契約開始日
    this.contractSd = contractSdParam;
    // 契約終了日
    this.contractEd = contractEdParam;
    // 付帯契約Map
    this.splContractMap = splContractMapParam;
    // 時間帯別使用量Map
    this.calculatingTsUsageList = calculatingTsUsageListParam;
    // 燃調単価取得方法区分
    this.fcaUpGetWayCategory = fcaUpGetWayCategoryParam;

    // --- エンティティ情報の初期化 ---
    // 計算用使用量
    this.calcUsage = calcUsageParam;

    //計算用日割別使用量
    this.calcDsUsageList = calcDsUsageListParam;

    // 計算用時間帯別使用量をMapで格納
    Map<String, CalculatingTsUsage> calcMap = new HashMap<String, CalculatingTsUsage>();
    for (CalculatingTsUsage calculatingTsUsage : calcTsUsageMapParam) {
      StringBuilder keyCode = new StringBuilder();
      keyCode.append(calculatingTsUsage.getDsSd())
          .append(ECISConstants.UNDERLINE)
          .append(calculatingTsUsage.getTsCode());
      calcMap.put(keyCode.toString(), calculatingTsUsage);
    }
    this.calcTsUsageMap = calcMap;

    // 計算用予備契約情報
    this.calResContList = calReserveContractListParam;

    // 計算用制限中止割引情報
    this.calResDisInfoList = calRestrictDisInfoListParam;

    // --- 計算結果情報の初期化 ---
    // 計算結果
    this.calculationResult = new CalculationResult();
    // 計算結果内訳
    this.clcBreakdownMap = new HashMap<>();

    this.calcDetailResultsMap = new TreeMap<Integer, Object[]>();

    // 契約種別コード
    this.contractClassCode = ccCodeParam;

    // 丸め
    this.roundMap = roundMapParam;

    // 最低月額料金の名称
    this.minMonthlyChargeName = minMonthlyChargeNameParam;

    // 基本料金無料有無
    this.basicChargeFree = basicChargeFreeParam;

    // 固定部分有りエリアリスト
    this.fixChargeAreaList = fixChargeAreaListParam;

    // 付帯の名称
    this.supplementaryName = supplementaryNameParam;

    // 契約履歴
    this.contractHist = contractHistParam;

    // 計算後予備契約情報リスト
    this.calcResContInfoList = new ArrayList<CalcReserveContractInfoBean>();

    // 予備契約基本料金の名称
    this.reserveContractBasicChargeRowName = resContractBasicChargeRowName;

    // 予備線基本料金の名称
    this.reserveLineBasicChargeRowName = resLineBasicChargeRowName;

    // 予備電源基本料金の名称
    this.reservePowerSupplyBasicChargeRowName = resPowerSupplyBasicChargeRowName;

    // 制限中止割引金額の名称
    this.restrictionDiscountChargeRowName = restrictionDisChargeRowName;

    // 制限中止_主契約の名称
    this.restrictionDiscountContractRowName = restrictionDisContractRowName;

    // 制限中止_予備線の名称
    this.restrictionDiscountReserveLineRowName = restrictionDisReserveLineRowName;

    // 制限中止_予備電源の名称
    this.restrictionDiscountReservePowerRowName = restrictionDisReservePowerRowName;

    // 契約超過金計算倍率
    this.contractExcessChargeCalcScaleFactor = contractExcessChargeCalcScaleFactor;

    // 日割個数
    this.proratedQuantity = proratedQuantity;

    // 契約超過金表示名称1
    this.contractExcessChargeDisplayName1 = contractExcessChargeDisplayName1;

    // 契約超過金表示名称2
    this.contractExcessChargeDisplayName2 = contractExcessChargeDisplayName2;

    // --- 日割山情報の初期化 ---
    // 日割山インデックス
    this.proratedIndex = 0;

    // 日割開始日
    this.dateSlotStartDate = calcDsUsageListParam.get(0).getDsSd();

    // 利用年月（末尾に"01"付加）が属する消費税率マスタを取得
    this.ctRateM = this.chargeUpManagement.getCtRateM(StringConvertUtil.stringToDate(this.usePeriod
        + ECISConstants.DATE_FIRST, EMSConstants.FORMAT_DATE_yyyyMMdd));
  }

  /**
   * 計算用日割別使用量情報を次の日割山に進める。
   *
   * @author "Nihon Unisys, Ltd."
   * @param branchNo
   *          契約種別計算明細の枝番
   * @param calcResult
   *          計算結果
   */
  public void setNextDs() {

    // 計算用日割別使用量の要素数－1が、日割山インデックスと一致するかチェック
    if (this.proratedIndex == (this.calcDsUsageList.size() - 1)) {
      // 一致する場合、処理を終了する
      return;
    }

    // クラス変数.日割山インデックスを1進める
    this.proratedIndex++;

    // 日割山情報の更新
    this.dateSlotStartDate = this.calcDsUsageList.get(proratedIndex).getDsSd();
  }

  /**
   * 計算結果の保持を行う。
   *
   * @author "Nihon Unisys, Ltd."
   * @param branchNo
   *          契約種別計算明細の枝番
   * @param calcResult
   *          計算結果
   */
  public void addCalcResults(int branchNo, Object[] calcResult) {
    this.calcDetailResultsMap.put(branchNo, calcResult);
  }

  /**
   * 契約種別計算明細で指定されたプロパティ値の取得を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 取得元項目(dataName)が予約語「定数」の場合は、取得元項目名に設定された値をそのまま返却する。<br>
   * 取得元項目(dataName)が予約語「枝番」の場合は、前の計算結果から値取得する。<br>
   * 取得元項目(dataName)がデータクラス名の場合は、保持している各データから取得元項目名で指定されたプロパティ値を取得する。<br>
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param dataName
   *          取得元情報名
   * @param itemName
   *          取得元項目名
   * @return 取得されたプロパティ値
   * @throws RateEngineException
   *           取得元情報名にサポート外の値が設定されていた場合
   */
  public Object readProperty(String dataName, String itemName)
      throws RateEngineException {

    if (ECISRKConstants.CALC_RESERVED_DATA_RESULT.equals(dataName)) {
      // 予約後「枝番」→ 前の計算結果から取得する
      return this.getCalcedResult(itemName);

    } else if (ECISRKConstants.CALC_RESERVED_DATA_CONST.equals(dataName)) {
      // 予約後「定数」→ 取得元項目値をそのまま返す
      return itemName;

    } else if (CalculatingUsage.class.getSimpleName().equals(dataName)) {
      return RateEngineReflectionUtil.getProperty(calcUsage, itemName);

    } else if (CalculatingDsUsage.class.getSimpleName().equals(dataName)) {
      // 計算用日割別使用量を参照
      return RateEngineReflectionUtil.getProperty(this.calcDsUsageList.get(this.proratedIndex), itemName);

    } else if (CalculatingTsUsage.class.getSimpleName().equals(dataName)) {
      // 計算用時間帯別使用量を参照
      String[] dataAndTimeSlotCode = parsePowerConsumptionDataName(itemName);

      if (dataAndTimeSlotCode.length == 2) {
        StringBuffer keyCode = new StringBuffer();
        keyCode.append(this.dateSlotStartDate).append(ECISConstants.UNDERLINE).append(dataAndTimeSlotCode[1]);
        CalculatingTsUsage powerTs = calcTsUsageMap.get(keyCode.toString());
        if (powerTs == null) {
          // デバッグログ
          LOGGER.warn("時間帯データがnull 取得元情報名:{}",
              Arrays.toString(dataAndTimeSlotCode));
          // 指定された時間帯コードに対応する使用量のデータが見つかりません。時間帯コード:{0}
          throw new RateEngineException("error.E1329",
              dataAndTimeSlotCode[0]);
        }
        return RateEngineReflectionUtil.getProperty(powerTs,
            dataAndTimeSlotCode[0]);
      } else {
        // {0}の取得元情報名のフォーマットが不正です。値：{1}
        throw new RateEngineException("error.E1332", itemName);
      }

    } else if ("CalculatingReserveContract".equals(dataName)) {
      // 計算用予備契約情報を生成
      List<Object> objectList = new ArrayList<Object>();

      String[] calcReserveCode = parsePowerConsumptionDataName(itemName);

      if (calcReserveCode.length == 1) {
        for (CalReserveContractBusinessBean calResContBean : this.calResContList) {
          if (this.dateSlotStartDate.compareTo(calResContBean.getDateSlotStartDate()) == 0) {
            // 取得元項目名配列[0]が単価の場合
            if (RESERVEUNITPRICE.equals(calcReserveCode[0])) {
              RcUpM rcUpM = this.chargeUpManagement.getRcUpM(this.areaCd, this.rateMenuId,
                  this.createGetReserveContractUp(calResContBean.getReserveContractStartDate()));

              if (ECISKJConstants.RESERVE_CONTRACT_CLASS_LINE.equals(
                  calResContBean.getReserveContractClass())) {
                // 予備線の場合
                calResContBean.setReserveUnitPrice(rcUpM.getRlUp());

              } else if (ECISKJConstants.RESERVE_CONTRACT_CLASS_POWER.equals(
                  calResContBean.getReserveContractClass())) {
                // 予備電源の場合
                calResContBean.setReserveUnitPrice(rcUpM.getRpsUp());
              }
            }

            Object objItem = RateEngineReflectionUtil.getProperty(calResContBean, calcReserveCode[0]);
            objectList.add(objItem);
          }
        }
        Object[] objLists = objectList.toArray();
        return objLists;

      } else if (calcReserveCode.length == 2) {
        for (CalReserveContractBusinessBean calResContBean : this.calResContList) {
          if (this.dateSlotStartDate.compareTo(calResContBean.getDateSlotStartDate()) == 0
              && calcReserveCode[1].equals(calResContBean.getReserveContractClass())) {
            // 取得元項目名配列[0]が単価の場合
            // 予備契約開始日が算定期間開始日より未来の場合は、契約開始日時点の単価を取得
            // それ以外の場合は算定開始日時点の単価を取得する
            if (RESERVEUNITPRICE.equals(calcReserveCode[0])) {
              RcUpM rcUpM = this.chargeUpManagement.getRcUpM(this.areaCd, this.rateMenuId,
                  this.createGetReserveContractUp(calResContBean.getReserveContractStartDate()));

              if (ECISKJConstants.RESERVE_CONTRACT_CLASS_LINE.equals(
                  calResContBean.getReserveContractClass())) {
                // 予備線の場合
                calResContBean.setReserveUnitPrice(rcUpM.getRlUp());

              } else if (ECISKJConstants.RESERVE_CONTRACT_CLASS_POWER.equals(
                  calResContBean.getReserveContractClass())) {
                // 予備電源の場合
                calResContBean.setReserveUnitPrice(rcUpM.getRpsUp());
              }
            }

            Object objItem = RateEngineReflectionUtil.getProperty(calResContBean, calcReserveCode[0]);
            objectList.add(objItem);
          }
        }
        Object[] objLists = objectList.toArray();
        return objLists;

      } else {
        // {0}の取得元情報名のフォーマットが不正です。値：{1}
        throw new RateEngineException("error.E1332", itemName);
      }

    } else if ("CalculatingRestrictionDiscountInfo".equals(dataName)) {
      // 計算用制限中止割引情報を生成
      List<Object> objectList = new ArrayList<Object>();

      String[] calcReserveCode = parsePowerConsumptionDataName(itemName);

      if (calcReserveCode.length == 2) {
        for (CalRestrictDisInfoBusinessBean calResDisInfoBean : this.calResDisInfoList) {
          if (this.dateSlotStartDate.compareTo(calResDisInfoBean.getDateSlotStartDate()) == 0
              && calcReserveCode[1].equals(calResDisInfoBean.getDiscountCoveredCode())) {
            Object objItem = RateEngineReflectionUtil.getProperty(calResDisInfoBean, calcReserveCode[0]);
            objectList.add(objItem);
          }
        }
        Object[] objLists = objectList.toArray();
        return objLists;

      } else {
        // {0}の取得元情報名のフォーマットが不正です。値：{1}
        throw new RateEngineException("error.E1332", itemName);
      }

    } else if (RmUp.class.getSimpleName().equals(dataName)) {
      // 料金メニュー単価を参照
      RmUp price = chargeUpManagement.getRateMenuUnitPrice(
          this.rateMenuId, this.contractHist.getUpCatCode(), this.calcSd);
      return RateEngineReflectionUtil.getProperty(price, itemName);

    } else if (RmUpDetail.class.getSimpleName().equals(dataName)) {
      // 料金メニュー単価明細を参照
      DcecDetailProps parsedProps = DcecDetailProps
          .parseDcecProps(itemName);

      List<Object> objectList = new ArrayList<Object>();
      for (int index = 1; index <= parsedProps.getBranchNo(); index++) {
        RmUpDetail detail = chargeUpManagement
            .getRateMenuUnitPriceDetail(this.rateMenuId, this.contractHist.getUpCatCode(), this.calcSd,
                parsedProps.getDcecCategory(),
                parsedProps.getTimeSlotCode(), index);
        if (detail == null) {
          break;
        }
        Object objItem = RateEngineReflectionUtil.getProperty(detail, parsedProps.getItemName());
        objectList.add(objItem);
      }

      Object[] objLists = objectList.toArray();
      return objLists;
    } else if ("RmUpDetailSingle".equals(dataName)) {
      // 料金メニュー単価明細を単発で取得
      DcecDetailProps parsedProps = DcecDetailProps
          .parseDcecProps(itemName);

      RmUpDetail detail = chargeUpManagement
          .getRateMenuUnitPriceDetail(this.rateMenuId, this.contractHist.getUpCatCode(), this.calcSd,
              parsedProps.getDcecCategory(),
              parsedProps.getTimeSlotCode(), parsedProps.getBranchNo());
      return RateEngineReflectionUtil.getProperty(detail, parsedProps.getItemName());
    } else if ("RmUpDetailNoTimeSlotCode".equals(dataName)) {
      // 料金メニュー単価明細を取得(時間帯コード指定なし)
      TreeMap<String, BigDecimal> upMap = new TreeMap<String, BigDecimal>();

      Map<String, RmUpDetail> detail = chargeUpManagement
          .getRateMenuUnitPriceDetailNoTimeSlotCode(
              this.rateMenuId, this.contractHist.getUpCatCode(), this.calcSd);

      for (Map.Entry<String, RmUpDetail> mapDetail : detail.entrySet()) {
        upMap.put(mapDetail.getValue().getTsCode(), mapDetail.getValue().getUp());
      }

      return upMap;
    } else if ("calcTsUsageMap".equals(dataName)) {
      // 時間帯別使用量Mapの取得
      Map<String, CalculatingTsUsage> calcTsUsageList = new TreeMap<String, CalculatingTsUsage>();

      for (Map.Entry<String, CalculatingTsUsage> data : this.calculatingTsUsageList.entrySet()) {
        if (this.dateSlotStartDate.compareTo(data.getValue().getDsSd()) == 0) {
          calcTsUsageList.put(data.getValue().getTsCode(), data.getValue());
        }
      }
      return calcTsUsageList;

    } else if (RecUpM.class.getSimpleName().equals(dataName)) {
      // 再エネ単価を参照
      // 利用年月により、再エネ単価取得
      RecUpM recUpM = chargeUpManagement.getRenewableEnergyChargeUnitPrice(this.areaCd, this.usePeriod);

      // 単価が再設定対象であるかを判断（消費税改定対応）
      if (this.isResettingRecUp()) {
        // 再設定対象である場合
        // エリア、利用年月により再エネ単価消費税改定マスタを取得し、再設定する
        recUpM = this.copyRecUpM(recUpM,
            chargeUpManagement.getRecUpTrMForResetting(this.areaCd, this.usePeriod));
      }

      return RateEngineReflectionUtil.getProperty(recUpM, itemName);
    } else if (FcaUpM.class.getSimpleName().equals(dataName)) {

      // 燃調単価を参照
      // 燃調単価取得方法区分が"算定期間開始日"の場合
      if (ECISRKConstants.FUEL_COST_ADJUST_GET_WAY_CAT_CALC_PERIOD_START.equals(this.fcaUpGetWayCategory)) {
        // エリア、電圧区分、料金算定開始日により、燃調単価取得
        FcaUpM fcaUpM = chargeUpManagement.getFuelCostAdjustUnitPrice(
            this.areaCd, this.contractHist.getVoltageCatCode(), this.calcSd);
        return RateEngineReflectionUtil.getProperty(fcaUpM, itemName);
        // 燃調単価取得方法区分が"利用年月"の場合
      } else {
        // エリア、電圧区分、利用年月により、燃調単価取得
        FcaUpM fcaUpM = chargeUpManagement.getFuelCostAdjustUnitPriceUsePeriod(
            this.areaCd, this.contractHist.getVoltageCatCode(), this.usePeriod);

        // 単価が再設定対象であるかを判断（消費税改定対応）
        if (this.isResettingFcaUp()) {
          // 再設定対象である場合
          // エリア、電圧区分、利用年月により燃調単価消費税改定マスタを取得し、再設定する
          fcaUpM = this.copyFcaUpM(
              fcaUpM,
              chargeUpManagement.getFcaUpTrMForResetting(this.areaCd,
                  this.contractHist.getVoltageCatCode(), this.usePeriod));
        }

        return RateEngineReflectionUtil.getProperty(fcaUpM, itemName);
      }
    } else if (RoundBusinessBean.class.getSimpleName().equals(dataName)) {

      DcecDetailProps parsedProps = DcecDetailProps
          .parseDcecProps(itemName);

      RoundBusinessBean round = roundMap.get(parsedProps
          .getDcecCategory());

      return RateEngineReflectionUtil.getProperty(round,
          parsedProps.getItemName());
    } else if (Cr.class.getSimpleName().equals(dataName)) {
      // 託送メニュー
      Cr cr = chargeUpManagement.getConsignmentRateMenu(this.consignmentMenuId);
      return RateEngineReflectionUtil.getProperty(cr, itemName);
    } else if (CrUp.class.getSimpleName().equals(dataName)) {

      // 託送メニュー単価
      CrUp crUp = chargeUpManagement.getConsignmentRateMenuUnitPrice(this.consignmentMenuId, this.calcSd);
      return RateEngineReflectionUtil.getProperty(crUp, itemName);
    } else if (CrUpDetail.class.getSimpleName().equals(dataName)) {

      // 託送メニュー単価明細
      DcecDetailProps parsedProps = DcecDetailProps
          .parseDcecProps(itemName);

      List<Object> objectList = new ArrayList<Object>();
      for (int index = 1; index <= parsedProps.getBranchNo(); index++) {
        CrUpDetail crUpDetail = chargeUpManagement.getConsignmentRateMenuUnitPriceDetail(
            this.consignmentMenuId, this.calcSd,
            parsedProps.getDcecCategory(),
            parsedProps.getTimeSlotCode(), index);
        if (crUpDetail == null) {
          break;
        }
        Object objItem = RateEngineReflectionUtil.getProperty(crUpDetail, parsedProps.getItemName());
        objectList.add(objItem);
      }

      Object[] objLists = objectList.toArray();
      return objLists;
    } else if ("CrUpDetailSingle".equals(dataName)) {
      // 託送メニュー単価明細を単発で取得
      DcecDetailProps parsedProps = DcecDetailProps
          .parseDcecProps(itemName);
      CrUpDetail crUpDetail = chargeUpManagement.getConsignmentRateMenuUnitPriceDetail(
          this.consignmentMenuId, this.calcSd,
          parsedProps.getDcecCategory(),
          parsedProps.getTimeSlotCode(), parsedProps.getBranchNo());
      return RateEngineReflectionUtil.getProperty(crUpDetail, parsedProps.getItemName());

    } else if (Spm.class.getSimpleName().equals(dataName)) {

      return readSpmProperty(dataName, itemName);
    } else if ("BaseInfo".equals(dataName)) {
      // 基本情報を取得
      return RateEngineReflectionUtil.getProperty(this, itemName);
    } else if ("CalcReserveContractInfo".equals(dataName)) {
      // 計算後予備契約情報を取得
      List<Object> objectList = new ArrayList<Object>();
      String[] calcReserveCode = parsePowerConsumptionDataName(itemName);

      if (calcReserveCode.length == 2) {
        for (CalcReserveContractInfoBean calcResContInfoBean : this.calcResContInfoList) {
          if (calcReserveCode[1].equals(calcResContInfoBean.getReserveContractClass())) {
            Object objItem = RateEngineReflectionUtil.getProperty(calcResContInfoBean, calcReserveCode[0]);
            objectList.add(objItem);
          }
        }
        Object[] objLists = objectList.toArray();
        return objLists;
      } else {
        // {0}の取得元情報名のフォーマットが不正です。値：{1}
        throw new RateEngineException("error.E1332", itemName);
      }
    } else if ("RcUpSingle".equals(dataName)) {
      // 予備契約単価情報を取得
      // 料金算定開始時点の情報を取得
      RcUpM rcUpM = this.chargeUpManagement.getRcUpM(this.areaCd, this.rateMenuId, this.calcSd);
      return RateEngineReflectionUtil.getProperty(rcUpM, itemName);
    }
    return null;
  }

  /**
   * 契約種別計算明細で指定されたプロパティ値の取得を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 取得元項目(dataName)が予約語「定数」の場合は、取得元項目名に設定された値をそのまま返却する。<br>
   * 取得元項目(dataName)が予約語「枝番」の場合は、前の計算結果から値取得する。<br>
   * 取得元項目(dataName)がデータクラス名の場合は、保持している各データから取得元項目名で指定されたプロパティ値を取得する。<br>
   * </p>
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param dataName
   *          取得元情報名
   * @param itemName
   *          取得元項目名
   * @return 取得されたプロパティ値
   * @throws RateEngineException
   *           取得元情報名にサポート外の値が設定されていた場合
   */
  public Object readSpmProperty(String dataName, String itemName) throws RateEngineException {
    // 付帯メニューを参照
    DcecDetailProps parsedProps = DcecDetailProps.parseDcecProps(itemName);

    // 対象区分リスト
    List<String> catCodeList = new ArrayList<String>();

    // 適用区分リスト
    List<String> applyList = new ArrayList<String>();

    // 種別リスト
    List<String> classCodeList = new ArrayList<String>();

    // 割引割増区分リスト
    List<String> discountList = new ArrayList<String>();

    // 額率リスト
    List<BigDecimal> rateList = new ArrayList<BigDecimal>();

    // 上限額リスト
    List<BigDecimal> upperList = new ArrayList<BigDecimal>();

    // 下限額リスト
    List<BigDecimal> lowerList = new ArrayList<BigDecimal>();

    // 丸め桁数リスト
    List<Short> roundScaleList = new ArrayList<Short>();

    // 丸め方法リスト
    List<String> roundModeList = new ArrayList<String>();

    for (Map.Entry<String, SplContract> data : splContractMap.entrySet()) {
      SplContract contract = data.getValue();
      String spmId = contract.getSpmId();

      // 付帯メニュー取得
      Spm spm = chargeUpManagement.getSpm(spmId);
      if (spm == null) {
        continue;
      }

      String catCode = spm.getSplApplyCatCode();

      // 前処理
      if (catCode.equals(parsedProps.getDcecCategory())
          && catCode.equals(ECISCodeConstants.SPL_APPLY_CAT_CODE_BEFORE)) {

        // 各リストに値を設定する
        catCodeList.add(spm.getSplCoveredCatCode());
        applyList.add(spm.getSplApplyCatCode());
        classCodeList.add(spm.getSplClassCode());
        discountList.add(spm.getDiscountCatCode());
        roundScaleList.add(spm.getRoundingCode());
        roundModeList.add(spm.getRoundingCatCode());

        SpmUp spmUp = chargeUpManagement.getSpmUp(spm.getSpmId(), this.calcSd);
        if (spmUp == null) {
          upperList.add(BigDecimal.ZERO);
          lowerList.add(BigDecimal.ZERO);
        } else {
          upperList.add(spmUp.getMaximumAmount());
          lowerList.add(spmUp.getMinimumAmount());
        }

        if (spm.getIndividualSettingFlag().equals(ECISCodeConstants.INDIVIDUAL_SETTING_FLAG_REQUIRED)) {
          // 定額・定率
          rateList.add(contract.getAmountOrRate());
        } else {
          // 定額・定率
          if (spmUp != null) {
            rateList.add(spmUp.getAmountOrRate());
          } else {
            rateList.add(BigDecimal.ZERO);
          }
        }
      }

      // 後処理
      if (catCode.equals(parsedProps.getDcecCategory())
          && catCode.equals(ECISCodeConstants.SPL_APPLY_CAT_CODE_AFTER)) {
        // 各リストに値を設定する
        catCodeList.add(spm.getSplCoveredCatCode());
        applyList.add(spm.getSplApplyCatCode());
        classCodeList.add(spm.getSplClassCode());
        discountList.add(spm.getDiscountCatCode());
        roundScaleList.add(spm.getRoundingCode());
        roundModeList.add(spm.getRoundingCatCode());

        SpmUp spmUp = chargeUpManagement.getSpmUp(spm.getSpmId(), this.calcSd);
        if (spmUp == null) {
          upperList.add(BigDecimal.ZERO);
          lowerList.add(BigDecimal.ZERO);
        } else {
          upperList.add(spmUp.getMaximumAmount());
          lowerList.add(spmUp.getMinimumAmount());
        }

        if (spm.getIndividualSettingFlag().equals(ECISCodeConstants.INDIVIDUAL_SETTING_FLAG_REQUIRED)) {
          // 定額・定率
          rateList.add(contract.getAmountOrRate());
        } else {
          // 定額・定率
          if (spmUp != null) {
            rateList.add(spmUp.getAmountOrRate());
          } else {
            rateList.add(BigDecimal.ZERO);
          }
        }
      }
    }

    Object[] objs = new Object[] {catCodeList.toArray(), applyList.toArray(), classCodeList.toArray(), discountList.toArray(), rateList.toArray(),
        upperList.toArray(), lowerList.toArray(), roundScaleList.toArray(), roundModeList.toArray() };

    return objs;
  }

  /**
   * 演算方式が「代入」の場合のデータの設定を行う。
   * <p>
   * 【詳細仕様】<br>
   * 代入対象オブジェクトは確定料金実績、あるいは確定料金実績内訳
   * </p>
   *
   * @param setArgs
   *          「代入」演算方式時のパラメータ
   * @param branchNo
   *          契約種別計算明細の枝番
   * @throws RateEngineException
   *           「代入」演算で指定された代入先の情報名がサポート対象外(実績データではない)場合
   */
  public void writeProperty(SetArgs setArgs, String branchNo) throws RateEngineException {
    // 代入値を取得
    Object setValue = this.readProperty(setArgs.getOriginData(),
        setArgs.getOriginItem());
    Object assignFlg = this.readProperty(setArgs.getAssignData(),
        setArgs.getAssignFlg());
    // 足し込み有無を取得
    Object addCheck = this.readProperty(setArgs.getSpmData(),
        setArgs.getSpmItem());

    // デバッグログ
    LOGGER.debug(
        "writeProperty setData:{} setItem:{} setVal:{} assignFlg:{}",
        setArgs.getOriginData(), setArgs.getOriginItem(), setValue,
        assignFlg);

    // 代入フラグによって処理わけ
    if (ECISRKConstants.CALC_WRITE_UNCONDITIONAL.equals(assignFlg)) {
      // 無条件に代入

    } else if (ECISRKConstants.CALC_WRITE_NOT_NULL_PROC.equals(assignFlg)) {
      // 代入値がnullの場合、代入しない
      if (setValue == null) {
        return;
      }

    } else if (ECISRKConstants.CALC_WRITE_NOT_ZERO_PROC.equals(assignFlg)) {
      // 代入値が0の場合、代入しない（nullは代入する）
      if (setValue != null) {
        BigDecimal[] decimals = RateEngineCommonUtil
            .convertToDecimals(setValue);
        if (BigDecimal.ZERO.compareTo(decimals[0]) == 0) {
          return;
        }
      }

    } else if (ECISRKConstants.CALC_WRITE_NOT_NULL_OR_ZERO_PROC
        .equals(assignFlg)) {
      // 代入値がnullまたは0の場合、代入しない
      if (setValue == null) {
        return;
      } else {
        BigDecimal[] decimals = RateEngineCommonUtil
            .convertToDecimals(setValue);
        if (BigDecimal.ZERO.compareTo(decimals[0]) == 0) {
          return;
        }
      }

    } else if (!ECISRKConstants.CALC_WRITE_UNCONDITIONAL.equals(assignFlg)) {
      // 代入フラグの値が不正であるため、「代入」することができません。代入フラグ:{0}
      throw new RateEngineException("error.E1330",
          assignFlg.toString());
    }

    String dataName = setArgs.getDestData();
    if (CalculationResult.class.getSimpleName().equals(dataName)) {
      // 足し込みチェック
      if (ADDCHECK_ADD.equals(addCheck)) {
        Object nowValue = RateEngineReflectionUtil.getProperty(calculationResult, setArgs.getDestItem());

        // 数値チェック
        if ((!Objects.isNull(setValue) && !CommonValidationUtil.isBigDecimal(setValue.toString()))
            || (!Objects.isNull(nowValue) && !CommonValidationUtil.isBigDecimal(nowValue.toString()))) {
          // エラーの文字列情報を作成
          StringBuffer errData = new StringBuffer();
          errData.append(nowValue).append(ECISConstants.COMMA).append(setValue);

          // 指定された文字列を数値に変換できません。文字列:{0}
          throw new RateEngineException("error.E1341", errData.toString());
        }

        BigDecimal decSetValue = RateEngineCommonUtil.convertToDecimal(setValue);
        BigDecimal decNowValue = RateEngineCommonUtil.convertToDecimal(nowValue);
        setValue = decSetValue.add(decNowValue);
      }

      // 計算結果のプロパティを代入
      RateEngineReflectionUtil.setProperty(calculationResult,
          setArgs.getDestItem(), setValue);
    } else if (ClcBreakdown.class.getSimpleName().equals(dataName)) {
      // 計算結果のプロパティを代入
      DcecDetailProps dcecProp = DcecDetailProps.parseDcecProps(setArgs
          .getDestItem());

      String key = RateEngineCommonUtil.createMapKey(
          dcecProp.getDcecCategory(), dcecProp.getTimeSlotCode(),
          dcecProp.getBranchNo());

      ClcBreakdown detail = clcBreakdownMap.get(key);
      if (detail == null) {
        // 計算結果インスタンスがない場合は生成
        detail = new ClcBreakdown();
        detail.setContractId(calculationResult.getContractId());
        detail.setUsePeriod(calculationResult.getUsePeriod());
        clcBreakdownMap.put(key, detail);
      }

      // 足し込みチェック
      if (ADDCHECK_ADD.equals(addCheck)) {
        Object nowValue = RateEngineReflectionUtil.getProperty(detail, dcecProp.getItemName());

        // 数値チェック
        if ((!Objects.isNull(setValue) && !CommonValidationUtil.isBigDecimal(setValue.toString()))
            || (!Objects.isNull(nowValue) && !CommonValidationUtil.isBigDecimal(nowValue.toString()))) {
          // エラーの文字列情報を作成
          StringBuffer errData = new StringBuffer();
          errData.append(nowValue).append(ECISConstants.COMMA).append(setValue);

          // 指定された文字列を数値に変換できません。文字列:{0}
          throw new RateEngineException("error.E1341", errData.toString());
        }

        BigDecimal decSetValue = RateEngineCommonUtil.convertToDecimal(setValue);
        BigDecimal decNowValue = RateEngineCommonUtil.convertToDecimal(nowValue);
        setValue = decSetValue.add(decNowValue);
      }

      RateEngineReflectionUtil.setProperty(detail,
          dcecProp.getItemName(), setValue);

    } else {
      // 設定対象情報名が不正であるため、「代入」演算が行えません。取得元情報:{0}
      throw new RateEngineException("error.E1331", dataName);
    }

    // 計算結果保持する
    this.addCalcResults(StringConvertUtil.stringToInteger(branchNo), new Object[] {setValue });
  }

  /**
   * 演算方式が「付帯代入」の場合のデータを設定する
   * <p>
   * 代入対象オブジェクトは確定料金実績内訳
   * </p>
   *
   * @param setArgs
   *          「代入」演算方式時のパラメータ
   * @throws RateEngineException
   *           「代入」演算で指定された代入先の情報名がサポート対象外(実績データではない)場合
   */
  public void writeSpmProperty(SetArgs setArgs) throws RateEngineException {
    // 代入値を取得
    Object basicPrice = this.readProperty(setArgs.getOriginData(),
        setArgs.getOriginItem());
    Object meterEdPrice = this.readProperty(setArgs.getAssignData(),
        setArgs.getAssignFlg());
    String dataName = setArgs.getDestData();

    // デバッグログ
    LOGGER.debug(
        "writeSpmProperty setData:{} setItem:{} setVal:{} assignFlg:{} spmData:{} spmItem{}",
        setArgs.getOriginData(), setArgs.getOriginItem(), basicPrice,
        meterEdPrice, setArgs.getSpmData(), setArgs.getSpmItem());

    // 計算結果のプロパティを代入
    DcecDetailProps dcecProp = DcecDetailProps.parseDcecProps(setArgs
        .getDestItem());

    // 設定値取得
    // 前後処理
    String spmDcecCategory = dcecProp.getDcecCategory();
    // 表示順
    String spmTimeSlotCode = dcecProp.getTimeSlotCode();

    if (ClcBreakdown.class.getSimpleName().equals(dataName)) {

      // 付帯契約処理
      for (Map.Entry<String, SplContract> data : splContractMap.entrySet()) {
        SplContract contract = data.getValue();
        Integer splContractId = contract.getSplContractId();
        String spmId = contract.getSpmId();

        // 付帯メニュー取得
        Spm spm = chargeUpManagement.getSpm(spmId);
        if (spm == null) {
          return;
        }

        // 付帯メニュー明細出力順
        Short spmDetailOutputOrder = spm.getDetailOutputOrder();

        String catCode = spm.getSplApplyCatCode();
        if (catCode.equals(spmDcecCategory)) {
          String splClassCode = spm.getSplClassCode();

          String key = RateEngineCommonUtil.createMapKey(
              spmDcecCategory, spmTimeSlotCode, spmDetailOutputOrder);
          ClcBreakdown detail = clcBreakdownMap.get(key);

          if (detail == null) {
            // 計算結果インスタンスがない場合は生成
            detail = new ClcBreakdown();
            detail.setContractId(calculationResult.getContractId());
            detail.setUsePeriod(calculationResult.getUsePeriod());
            clcBreakdownMap.put(key, detail);
          }

          // 個別設定フラグにより、取得先から定額・定率を取得する
          SpmUp spmUp = chargeUpManagement.getSpmUp(spmId, this.calcSd);
          // 額・率
          BigDecimal rate = spmUp.getAmountOrRate();
          if (spm.getIndividualSettingFlag().equals(ECISCodeConstants.INDIVIDUAL_SETTING_FLAG_REQUIRED)) {
            // 定額・定率
            if (splClassCode.equals(ECISCodeConstants.SUPPLEMENTARY_CLASS_CODE_FIXED_AMOUNT)) {
              // 定額
              RateEngineReflectionUtil.setProperty(detail, "up", contract.getAmountOrRate());
            }

            if (splClassCode.equals(ECISCodeConstants.SUPPLEMENTARY_CLASS_CODE_FIXED_RATE)) {
              // 定率
              RateEngineReflectionUtil.setProperty(detail, "splRate", contract.getAmountOrRate());
            }
            rate = contract.getAmountOrRate();
          } else {
            // 定額・定率
            if (spmUp != null) {
              if (splClassCode.equals(ECISCodeConstants.SUPPLEMENTARY_CLASS_CODE_FIXED_AMOUNT)) {
                // 定額
                RateEngineReflectionUtil.setProperty(detail, "up", spmUp.getAmountOrRate());
              }

              if (splClassCode.equals(ECISCodeConstants.SUPPLEMENTARY_CLASS_CODE_FIXED_RATE)) {
                // 定率
                RateEngineReflectionUtil.setProperty(detail, "splRate", spmUp.getAmountOrRate());
              }

            }
          }

          // 上限
          BigDecimal maxCharge = BigDecimal.ZERO;
          if (spmUp.getMaximumAmount() != null) {
            maxCharge = spmUp.getMaximumAmount();
          }
          // 下限
          BigDecimal minCharge = BigDecimal.ZERO;
          if (spmUp.getMinimumAmount() != null) {
            minCharge = spmUp.getMinimumAmount();
          }

          // 付帯額計算
          CalcSupplementaryAmountBusiness calcSupplementaryAmountBusiness = new CalcSupplementaryAmountBusiness();
          Object[] args = null;

          // 部品のパラメータを設定する
          args = new Object[] {basicPrice, meterEdPrice,
              spm.getSplCoveredCatCode(), catCode, splClassCode, spm.getDiscountCatCode(), rate, maxCharge, minCharge, spm.getRoundingCode(),
              spm.getRoundingCatCode() };

          Object[] obj = calcSupplementaryAmountBusiness.calc(args);

          // すべての項目を設定する
          RateEngineReflectionUtil.setProperty(detail, "displayOrder", spmTimeSlotCode);
          RateEngineReflectionUtil.setProperty(detail, "detailOutputOrder", spmDetailOutputOrder);
          RateEngineReflectionUtil.setProperty(detail, "displayName1", this.getSupplementaryName());
          RateEngineReflectionUtil.setProperty(detail, "displayName2", spm.getSpmName());
          RateEngineReflectionUtil.setProperty(detail, "amount", obj[0]);
          RateEngineReflectionUtil.setProperty(detail, "splContractId", splContractId);
          RateEngineReflectionUtil.setProperty(detail, "splCoveredCatCode", spm.getSplCoveredCatCode());

          if (catCode.equals(ECISCodeConstants.SPL_APPLY_CAT_CODE_BEFORE)) {
            RateEngineReflectionUtil
                .setProperty(
                    detail,
                    "fcrBreakdownCatCode",
                    ECISCodeConstants.FCR_BREAKDOWN_CATEGORY_CODE_MINIMUM_AMOUNT_APPLICATION_BEFORE_SPL_CHARGE);
          } else {
            RateEngineReflectionUtil
                .setProperty(
                    detail,
                    "fcrBreakdownCatCode",
                    ECISCodeConstants.FCR_BREAKDOWN_CATEGORY_CODE_MINIMUM_AMOUNT_APPLICATION_AFTER_SPL_CHARGE);
          }
        }
      }

    } else {
      // 設定対象情報名が不正であるため、「代入」演算が行えません。取得元情報:{0}
      throw new RateEngineException("error.E1331", dataName);
    }
  }

  /**
   * 演算方式が「付帯日割代入」の場合のデータを設定する
   * <p>
   * 代入対象オブジェクトは確定料金実績内訳
   * </p>
   *
   * @param setArgs
   *          「代入」演算方式時のパラメータ
   * @throws RateEngineException
   *           「代入」演算で指定された代入先の情報名がサポート対象外(実績データではない)場合
   */
  public void writeSpmProratedProperty(SetArgs setArgs) throws RateEngineException {
    // 代入値を取得
    Object basicPrice = this.readProperty(setArgs.getOriginData(),
        setArgs.getOriginItem());
    Object meterEdPrice = this.readProperty(setArgs.getAssignData(),
        setArgs.getAssignFlg());
    // 付帯額計算用のパラメータ取得
    Object spmData = this.readProperty(setArgs.getSpmData(),
        setArgs.getSpmItem());
    String dataName = setArgs.getDestData();

    //検針日数、日割日数取得
    Object spmDataCcDays = this.readProperty(setArgs.getSpmDataCcDays(),
        setArgs.getSpmItemCcDays());

    Object spmDataProratedDays = this.readProperty(setArgs.getSpmDataProratedDays(),
        setArgs.getSpmItemProratedDays());

    // デバッグログ
    LOGGER.debug(
        "writeSpmProratedProperty setData:{} setItem:{} setVal:{} assignFlg:{} spmData:{} spmItem{}",
        setArgs.getOriginData(), setArgs.getOriginItem(), basicPrice,
        meterEdPrice, setArgs.getSpmData(), setArgs.getSpmItem());

    // 計算結果のプロパティを代入
    DcecDetailProps dcecProp = DcecDetailProps.parseDcecProps(setArgs
        .getDestItem());

    // 設定値取得
    // 前後処理
    String spmDcecCategory = dcecProp.getDcecCategory();
    // 表示順
    String spmTimeSlotCode = dcecProp.getTimeSlotCode();

    if (ClcBreakdown.class.getSimpleName().equals(dataName)) {

      // 付帯契約処理
      int index = 1;
      for (Map.Entry<String, SplContract> data : splContractMap.entrySet()) {
        SplContract contract = data.getValue();
        Integer splContractId = contract.getSplContractId();
        String spmId = contract.getSpmId();

        // 付帯メニュー取得
        Spm spm = chargeUpManagement.getSpm(spmId);
        if (spm == null) {
          return;
        }

        String catCode = spm.getSplApplyCatCode();
        if (catCode.equals(spmDcecCategory)) {
          String splClassCode = spm.getSplClassCode();

          String key = RateEngineCommonUtil.createMapKey(
              spmDcecCategory, spmTimeSlotCode, index);
          ClcBreakdown detail = clcBreakdownMap.get(key);

          if (detail == null) {
            // 計算結果インスタンスがない場合は生成
            detail = new ClcBreakdown();
            detail.setContractId(calculationResult.getContractId());
            detail.setUsePeriod(calculationResult.getUsePeriod());
            clcBreakdownMap.put(key, detail);
          }

          // 個別設定フラグにより、取得先から定額・定率を取得する
          SpmUp spmUp = chargeUpManagement.getSpmUp(spmId, this.calcSd);
          // 額・率
          BigDecimal rate = spmUp.getAmountOrRate();
          if (spm.getIndividualSettingFlag().equals(ECISCodeConstants.INDIVIDUAL_SETTING_FLAG_REQUIRED)) {
            // 定額・定率
            if (splClassCode.equals(ECISCodeConstants.SUPPLEMENTARY_CLASS_CODE_FIXED_AMOUNT)) {
              // 定額
              RateEngineReflectionUtil.setProperty(detail, "up", contract.getAmountOrRate());
            }

            if (splClassCode.equals(ECISCodeConstants.SUPPLEMENTARY_CLASS_CODE_FIXED_RATE)) {
              // 定率
              RateEngineReflectionUtil.setProperty(detail, "splRate", contract.getAmountOrRate());
            }
            rate = contract.getAmountOrRate();
          } else {
            // 定額・定率
            if (spmUp != null) {
              if (splClassCode.equals(ECISCodeConstants.SUPPLEMENTARY_CLASS_CODE_FIXED_AMOUNT)) {
                // 定額
                RateEngineReflectionUtil.setProperty(detail, "up", spmUp.getAmountOrRate());
              }

              if (splClassCode.equals(ECISCodeConstants.SUPPLEMENTARY_CLASS_CODE_FIXED_RATE)) {
                // 定率
                RateEngineReflectionUtil.setProperty(detail, "splRate", spmUp.getAmountOrRate());
              }

            }
          }

          // 上限
          BigDecimal maxCharge = BigDecimal.ZERO;
          if (spmUp.getMaximumAmount() != null) {
            maxCharge = spmUp.getMaximumAmount();
          }
          // 下限
          BigDecimal minCharge = BigDecimal.ZERO;
          if (spmUp.getMinimumAmount() != null) {
            minCharge = spmUp.getMinimumAmount();
          }

          // 付帯額計算
          CalcSupplementaryAmountProratedBusiness calcSupplementaryAmountProratedBusiness = new CalcSupplementaryAmountProratedBusiness();
          Object[] args = null;

          RoundBusinessBean round = roundMap.get(spmData);

          // 部品のパラメータを設定する
          args = new Object[] {basicPrice, meterEdPrice,
              spm.getSplCoveredCatCode(), catCode, splClassCode, spm.getDiscountCatCode(), rate, maxCharge, minCharge, round.getRoundDigit(),
              round.getRoundMethod(), spmDataCcDays, spmDataProratedDays };

          Object[] obj = calcSupplementaryAmountProratedBusiness.calc(args);

          // すべての項目を設定する
          RateEngineReflectionUtil.setProperty(detail, "displayOrder", spmTimeSlotCode);
          RateEngineReflectionUtil.setProperty(detail, "detailOutputOrder", index);
          RateEngineReflectionUtil.setProperty(detail, "displayName1", this.getSupplementaryName());
          RateEngineReflectionUtil.setProperty(detail, "displayName2", spm.getSpmName());
          RateEngineReflectionUtil.setProperty(detail, "amount", obj[0]);
          RateEngineReflectionUtil.setProperty(detail, "splContractId", splContractId);
          RateEngineReflectionUtil.setProperty(detail, "splCoveredCatCode", spm.getSplCoveredCatCode());

          if (catCode.equals(ECISCodeConstants.SPL_APPLY_CAT_CODE_BEFORE)) {
            RateEngineReflectionUtil
                .setProperty(
                    detail,
                    "fcrBreakdownCatCode",
                    ECISCodeConstants.FCR_BREAKDOWN_CATEGORY_CODE_MINIMUM_AMOUNT_APPLICATION_BEFORE_SPL_CHARGE);
          } else {
            RateEngineReflectionUtil
                .setProperty(
                    detail,
                    "fcrBreakdownCatCode",
                    ECISCodeConstants.FCR_BREAKDOWN_CATEGORY_CODE_MINIMUM_AMOUNT_APPLICATION_AFTER_SPL_CHARGE);
          }
          index++;
        }
      }

    } else {
      // 設定対象情報名が不正であるため、「代入」演算が行えません。取得元情報:{0}
      throw new RateEngineException("error.E1331", dataName);
    }
  }

  /**
   * 演算方式が「不要な段を削除する」の場合のデータを設定する
   * <p>
   * 代入対象オブジェクトは確定料金実績内訳
   * </p>
   *
   * @param setArgs
   *          「代入」演算方式時のパラメータ
   * @throws RateEngineException
   *           「代入」演算で指定された代入先の情報名がサポート対象外(実績データではない)場合
   */
  public void writeDeleteStageProperty(SetArgs setArgs) throws RateEngineException {
    // 代入値を取得
    Object setValue = this.readProperty(setArgs.getOriginData(),
        setArgs.getOriginItem());
    Object assignFlg = this.readProperty(setArgs.getAssignData(),
        setArgs.getAssignFlg());

    // デバッグログ
    LOGGER.debug(
        "writeDeleteStageProperty setData:{} setItem:{} setVal:{} assignFlg:{} spmData:{} spmItem{}",
        setArgs.getOriginData(), setArgs.getOriginItem(), setValue,
        assignFlg);

    String dataName = setArgs.getDestData();
    List<String> delList = new ArrayList<String>();
    if (ClcBreakdown.class.getSimpleName().equals(dataName)) {
      for (Map.Entry<String, ClcBreakdown> data : clcBreakdownMap.entrySet()) {
        ClcBreakdown clcBreakdown = data.getValue();
        if (clcBreakdown.getDisplayOrder().compareTo(Short.valueOf(setValue.toString())) != 0) {
          continue;
        }

        if (clcBreakdown.getDetailOutputOrder().compareTo(Short.valueOf(assignFlg.toString())) < 0) {
          continue;
        }

        if (clcBreakdown.getCapacityOrUsage().compareTo(BigDecimal.ZERO) == 0) {
          delList.add(data.getKey());
        }
      }

      // 削除
      for (String key : delList) {
        clcBreakdownMap.remove(key);
      }
    } else {
      // 設定対象情報名が不正であるため、「代入」演算が行えません。取得元情報:{0}
      throw new RateEngineException("error.E1331", dataName);
    }
  }

  /**
   * 演算方式が「不要な最低月額料金を削除する」の場合のデータを設定する
   * <p>
   * 代入対象オブジェクトは確定料金実績内訳
   * </p>
   *
   * @param setArgs
   *          「代入」演算方式時のパラメータ
   * @throws RateEngineException
   *           「代入」演算で指定された代入先の情報名がサポート対象外(実績データではない)場合
   */
  public void writeDeleteLowestPriceProperty(SetArgs setArgs) throws RateEngineException {
    // 代入値を取得
    Object setValue = this.readProperty(setArgs.getOriginData(),
        setArgs.getOriginItem());
    Object assignFlg = this.readProperty(setArgs.getAssignData(),
        setArgs.getAssignFlg());

    // デバッグログ
    LOGGER.debug(
        "writeDeleteLowestPriceProperty setData:{} setItem:{} setVal:{} assignFlg:{} spmData:{} spmItem{}",
        setArgs.getOriginData(), setArgs.getOriginItem(), setValue,
        assignFlg);

    if (!assignFlg.equals(ECISRKConstants.MONTHLY_MIN_FEE_APPLY_NOT)) {
      return;
    }

    // 削除
    String dataName = setArgs.getDestData();
    List<String> delList = new ArrayList<String>();
    if (ClcBreakdown.class.getSimpleName().equals(dataName)) {
      for (Map.Entry<String, ClcBreakdown> data : clcBreakdownMap.entrySet()) {
        ClcBreakdown clcBreakdown = data.getValue();
        if (clcBreakdown.getDisplayOrder().compareTo(Short.valueOf(setValue.toString())) != 0) {
          continue;
        }

        delList.add(data.getKey());
      }

      // 削除
      for (String key : delList) {
        clcBreakdownMap.remove(key);
      }
    } else {
      // 設定対象情報名が不正であるため、「代入」演算が行えません。取得元情報:{0}
      throw new RateEngineException("error.E1331", dataName);
    }
  }

  // 2016/03/24 契約電力あたりの割引 start
  /**
   * 演算方式が「付帯契約を削除する」の場合のデータを設定する
   * <p>
   * 代入対象オブジェクトは付帯契約情報Map
   * </p>
   *
   * @param setArgs
   *          演算方式時のパラメータ
   * @throws RateEngineException
   *           演算で指定された情報名がサポート対象外(付帯契約ではない)場合
   */
  public void writeDeleteSplContractProperty(SetArgs setArgs) throws RateEngineException {
    // 削除キー（設定対象情報名）
    Object deleteKey = this.readProperty(setArgs.getOriginData(), setArgs.getOriginItem());
    // 削除キー種別（代入フラグ）
    Object deleteKeyType = this.readProperty(setArgs.getAssignData(), setArgs.getAssignFlg());
    // データ名
    String dataName = setArgs.getDestData();

    // デバッグログ
    LOGGER.debug(
        "writeDeleteSplContractProperty dataName:{} deleteKey:{} deleteKeyType{}",
        dataName, deleteKey, deleteKeyType);

    // 付帯契約削除リストを生成
    List<String> deleteTargetKeyList = new ArrayList<String>();

    // 対象のデータが”付帯契約”でない場合
    if (!SplContract.class.getSimpleName().equals(dataName)) {
      // Msg:設定対象情報名が不正であるため、「代入」演算が行えません。取得元情報:{0}
      throw new RateEngineException("error.E1331", dataName);
    }

    // 付帯契約数分処理を行う
    for (Map.Entry<String, SplContract> data : splContractMap.entrySet()) {
      // 付帯契約を取得
      SplContract splContract = data.getValue();
      // 付帯契約に紐づく、付帯メニューを取得
      Spm spm = chargeUpManagement.getSpm(splContract.getSpmId());

      // -- 削除キー種別により処理を分岐 --
      // キー種別：付帯種別コード
      if (ECISRKConstants.DELETE_TARGET_KEY_TYPE_SPL_CLASS_CODE.equals(deleteKeyType.toString())) {
        // 契約種別コードが一致
        if (spm.getSplClassCode().equals(deleteKey.toString())) {
          deleteTargetKeyList.add(data.getKey());
        }
        // キー種別：付帯メニューID
      } else if (ECISRKConstants.DELETE_TARGET_KEY_TYPE_SPM_ID.equals(deleteKeyType.toString())) {
        // 契約種別コードが一致
        if (spm.getSpmId().equals(deleteKey.toString())) {
          deleteTargetKeyList.add(data.getKey());
        }
        // キー種別：上記以外
      } else {
        // Msg:代入フラグの値が不正であるため、「代入」することができません。代入フラグ:{0}
        throw new RateEngineException("error.E1330", deleteKeyType.toString());
      }
    }

    // 削除処理
    for (String targetKey : deleteTargetKeyList) {
      splContractMap.remove(targetKey);
    }
  }

  // 2016/03/24 契約電力あたりの割引 end

  /**
   * 演算方式が「不要な金額段を削除する」の場合のデータを設定する
   * <p>
   * 代入対象オブジェクトは確定料金実績内訳
   * </p>
   *
   * @param setArgs
   *          演算方式時のパラメータ
   * @throws RateEngineException
   *           演算で指定された情報名がサポート対象外(不要金額段削除ではない)場合
   */
  public void writeDeleteNoNeedStageProperty(SetArgs setArgs) throws RateEngineException {
    // 削除対象表示順
    Object deleteDisplayOrder = this.readProperty(setArgs.getOriginData(), setArgs.getOriginItem());
    // 削除開始明細出力順
    Object deleteDetailOutputOrder = this.readProperty(setArgs.getAssignData(), setArgs.getAssignFlg());

    // デバッグログ
    LOGGER.debug(
        "writeDeleteNoNeedStageProperty deleteDisplayOrder:{} deleteDetailOutputOrder{}",
        deleteDisplayOrder, deleteDetailOutputOrder);

    String dataName = setArgs.getDestData();
    if (!ClcBreakdown.class.getSimpleName().equals(dataName)) {
      // 設定対象情報名が不正であるため、「代入」演算が行えません。取得元情報:{0}
      throw new RateEngineException("error.E1331", dataName);
    }

    List<String> delList = new ArrayList<String>();
    for (Map.Entry<String, ClcBreakdown> data : clcBreakdownMap.entrySet()) {
      ClcBreakdown clcBreakdown = data.getValue();

      // 計算結果内訳の表示順が削除対象表示順でなく、かつ計算結果内訳の明細出力順が削除開始明細出力順以下の場合
      if (!clcBreakdown.getDisplayOrder().equals(Short.valueOf(deleteDisplayOrder.toString()))
          || clcBreakdown.getDetailOutputOrder().compareTo(
              Short.valueOf(deleteDetailOutputOrder.toString())) < 0) {
        continue;
      }

      // 計算結果内訳の金額の0円チェック
      if (clcBreakdown.getAmount().compareTo(BigDecimal.ZERO) == 0) {
        delList.add(data.getKey());
      }
    }

    // 削除処理
    for (String key : delList) {
      clcBreakdownMap.remove(key);
    }
  }

  /**
   * 演算方式が「複数代入」の場合のデータを設定する
   * <p>
   * 代入対象は計算後予備契約情報Bean
   * </p>
   *
   * @param setArgs
   *          演算方式時のパラメータ
   * @throws RateEngineException
   */
  public void writePluralProperty(SetArgs setArgs) throws RateEngineException {

    String dataName = setArgs.getDestData();

    if ("CalcReserveContractInfo".equals(dataName)) {
      // 計算後予備契約情報の場合

      // 予備契約開始日配列
      Object[] resContStDate = (Object[]) this.readProperty(setArgs.getOriginData(), setArgs.getOriginItem());
      // 予備契約種別配列
      Object[] resContClass = (Object[]) this.readProperty(setArgs.getAssignData(), setArgs.getAssignFlg());
      // 予備契約基本料金配列
      Object[] resContBasicCharge = (Object[]) this.readProperty(setArgs.getSpmData(), setArgs.getSpmItem());
      // 日割前予備契約基本料金配列
      Object[] dsRreContBasicCharge = (Object[]) this.readProperty(setArgs.getSpmDataCcDays(), setArgs.getSpmItemCcDays());

      for (int i = 0; i < resContStDate.length; i++) {
        for (CalReserveContractBusinessBean calResContBean : this.calResContList) {
          if (calResContBean.getReserveContractClass().equals(resContClass[i])
              && calResContBean.getReserveContractStartDate().compareTo((Date) resContStDate[i]) == 0) {
            CalcReserveContractInfoBean calcReserveContractInfoBean = new CalcReserveContractInfoBean();

            calcReserveContractInfoBean.setReserveContractStartDate((Date) resContStDate[i]);
            calcReserveContractInfoBean.setReserveContractEndDate(
                calResContBean.getReserveContractEndDate());
            calcReserveContractInfoBean.setReserveContractClass(resContClass[i].toString());
            calcReserveContractInfoBean.setReserveContractBasicCharge(
                RateEngineCommonUtil.convertToDecimal(resContBasicCharge[i]));
            if (dsRreContBasicCharge != null && dsRreContBasicCharge.length > 0) {
              calcReserveContractInfoBean.setDsRreserveContractBasicCharge(
                  RateEngineCommonUtil.convertToDecimal(dsRreContBasicCharge[i]));
            } else {
              calcReserveContractInfoBean.setDsRreserveContractBasicCharge(BigDecimal.ZERO);
            }

            calcResContInfoList.add(calcReserveContractInfoBean);
          }
        }
      }
    }
  }

  /**
   * 計算結果を設定する
   *
   * @param calculationResultPara
   *          計算結果
   */
  public void setCalculateResult(CalculationResult calculationResultPara) {
    this.calculationResult = calculationResultPara;
  }

  /**
   * 計算結果を取得する<br>
   * 一連の計算実行後に「代入」演算方式の処理によって値がセットされたものを最終的に取得する想定
   *
   * @return 計算結果
   */
  public CalculationResult getCalculateResult() {
    return this.calculationResult;
  }

  /**
   * 計算結果内訳を取得する<br>
   * 一連の計算実行後に「代入」演算方式の処理によって値がセットされたものを最終的に取得する想定
   *
   * @return 計算結果内訳マップ(key: DCEC区分、時間帯コード、枝番より生成したキー)
   */
  public Map<String, ClcBreakdown> getCalculateResultDetailMap() {
    return this.clcBreakdownMap;
  }

  /**
   * 計算結果内訳を設定する
   *
   * @param clcBreakdownMapPara
   *          計算結果内訳マップ
   */
  public void setCalculateResultDetailMap(
      Map<String, ClcBreakdown> clcBreakdownMapPara) {
    this.clcBreakdownMap = clcBreakdownMapPara;
  }

  /**
   * 契約IDを取得する
   *
   * @return 契約ID
   */
  public String getContractId() {
    return contractId;
  }

  /**
   * 利用年月を取得する
   *
   * @return 契約ID
   */
  public String getUsePeriod() {
    return usePeriod;
  }

  /**
   * 料金算定開始日を取得する
   *
   * @return 料金算定開始日
   */
  public Date getCalcSd() {
    return calcSd;
  }

  /**
   * 料金算定終了日を取得する
   *
   * @return 料金算定終了日
   */
  public Date getCalcEd() {
    return calcEd;
  }

  /**
   * 契約開始日を取得する
   *
   * @return 契約開始日
   */
  public Date getContractSd() {
    return contractSd;
  }

  /**
   * 契約終了日を取得する
   *
   * @return 契約終了日
   */
  public Date getContractEd() {
    return contractEd;
  }

  /**
   * 料金メニューIDを取得する
   *
   * @return 料金メニューID
   */
  public String getRateMenuId() {
    return rateMenuId;
  }

  /**
   * エリアコードを取得する
   *
   * @return エリアコード
   */
  public String getAreaCd() {
    return areaCd;
  }

  /**
   * 契約種別コードを取得する
   *
   * @return 契約種別コード
   */
  public String getContractClassCode() {
    return contractClassCode;
  }

  /**
   * 計算用使用量を取得する
   *
   * @return 計算用使用量
   */
  public CalculatingUsage getCalculatingUsage() {
    return calcUsage;
  }

  /**
   * 託送メニューIDを取得する
   *
   * @return 託送メニューID
   */
  public String getConsignmentMenuId() {
    return consignmentMenuId;
  }

  /**
   * 最低月額料金の名称を取得する
   *
   * @return 最低月額料金の名称
   */
  public String getMinMonthlyChargeName() {
    return minMonthlyChargeName;
  }

  /**
   * 基本料金無料有無を取得する
   *
   * @return 基本料金無料有無
   */
  public String getBasicChargeFree() {
    return basicChargeFree;
  }

  /**
   * 固定部分有りエリアリストを取得する
   *
   * @return 固定部分有りエリアリスト
   */
  public String getFixChargeAreaList() {
    return fixChargeAreaList;
  }

  /**
   * 付帯の名称を取得する
   *
   * @return 付帯の名称
   */
  public String getSupplementaryName() {
    return supplementaryName;
  }

  /**
   * 予備契約基本料金の名称のgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 予備契約基本料金の名称
   */
  public String getReserveContractBasicChargeRowName() {
    return reserveContractBasicChargeRowName;
  }

  /**
   * 予備線基本料金の名称のgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 予備線基本料金の名称
   */
  public String getReserveLineBasicChargeRowName() {
    return reserveLineBasicChargeRowName;
  }

  /**
   * 予備電源基本料金の名称のgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 予備電源基本料金の名称
   */
  public String getReservePowerSupplyBasicChargeRowName() {
    return reservePowerSupplyBasicChargeRowName;
  }

  /**
   * 制限中止割引金額の名称のgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 制制限中止割引金額の名称
   */
  public String getRestrictionDiscountChargeRowName() {
    return restrictionDiscountChargeRowName;
  }

  /**
   * 制限中止_主契約の名称のgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 制限中止_主契約の名称
   */
  public String getRestrictionDiscountContractRowName() {
    return restrictionDiscountContractRowName;
  }

  /**
   * 制限中止_予備線の名称のgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 制限中止_予備線の名称
   */
  public String getRestrictionDiscountReserveLineRowName() {
    return restrictionDiscountReserveLineRowName;
  }

  /**
   * 制限中止_予備電源のgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 制限中止_予備電源
   */
  public String getRestrictionDiscountReservePowerRowName() {
    return restrictionDiscountReservePowerRowName;
  }

  /**
   * 日割個数のgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 日割個数
   */
  public int getProratedQuantity() {
    return proratedQuantity;
  }

  /**
   * 日割個数のsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param proratedQuantity
   *          日割個数
   */
  public void setProratedQuantity(int proratedQuantity) {
    this.proratedQuantity = proratedQuantity;
  }

  /**
   * 契約超過金計算倍率のgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約超過金計算倍率
   */
  public BigDecimal getContractExcessChargeCalcScaleFactor() {
    return contractExcessChargeCalcScaleFactor;
  }

  /**
   * 契約超過金計算倍率のsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractExcessChargeCalcScaleFactor
   *          契約超過金計算倍率
   */
  public void setContractExcessChargeCalcScaleFactor(BigDecimal contractExcessChargeCalcScaleFactor) {
    this.contractExcessChargeCalcScaleFactor = contractExcessChargeCalcScaleFactor;
  }

  /**
   * 契約超過金表示名称1のgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約超過金表示名称1
   */
  public String getContractExcessChargeDisplayName1() {
    return contractExcessChargeDisplayName1;
  }

  /**
   * 契約超過金表示名称1のsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractExcessChargeDisplayName1
   *          契約超過金表示名称1
   */
  public void setContractExcessChargeDisplayName1(String contractExcessChargeDisplayName1) {
    this.contractExcessChargeDisplayName1 = contractExcessChargeDisplayName1;
  }

  /**
   * 契約超過金表示名称2のgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約超過金表示名称2
   */
  public String getContractExcessChargeDisplayName2() {
    return contractExcessChargeDisplayName2;
  }

  /**
   * 契約超過金表示名称2のsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractExcessChargeDisplayName2
   *          契約超過金表示名称2
   */
  public void setContractExcessChargeDisplayName2(String contractExcessChargeDisplayName2) {
    this.contractExcessChargeDisplayName2 = contractExcessChargeDisplayName2;
  }

  /**
   * [ 使用量のクラス名/時間帯コード ]の書式の取得元項目の文字列を解析して分解する
   *
   * @param dataName
   *          使用量の取得元情報名の値
   * @return 分解後のデータ
   * @throws RateEngineException
   *           書式が異なるなど、解析できない場合
   */
  private String[] parsePowerConsumptionDataName(String dataName)
      throws RateEngineException {

    String[] props = dataName.split("/");

    return props;
  }

  /**
   * 計算済結果として保持されている情報を参照する
   *
   * @param propertyName
   *          取得元項目の指定値。※[枝番] + "-" + [結果のIndex値] ("1-1"、"1-2"等)
   * @return 計算済結果の値
   * @throws RateEngineException
   *           propertyNameの書式が不正な場合、あるいは指定された計算済情報が存在しない場合
   */
  private Object getCalcedResult(String propertyName)
      throws RateEngineException {
    if (!PTN_ACCESS_TO_CALCED_RESULT.matcher(propertyName).matches()) {
      // 取得元項目名が計算結果へのアクセス可能なフォーマットではありません。取得元項目名:{0}
      throw new RateEngineException("error.E1333", propertyName);
    }
    String[] splited = propertyName.split("-");
    int branchNum = Integer.parseInt(splited[0]);
    int arrayIndex = Integer.parseInt(splited[1]) - 1;

    Object[] calcedResult = calcDetailResultsMap.get(branchNum);
    if (calcedResult == null) {
      // 指定された枝番の計算結果が存在しません。取得元項目名:{0}
      throw new RateEngineException("error.E1334", propertyName);
    }

    Object ret = null;
    try {
      ret = calcedResult[arrayIndex];
    } catch (ArrayIndexOutOfBoundsException e) {
      // 指定されたインデックスの計算結果にアクセスできません。取得元項目名:{0}
      throw new RateEngineException("error.E1335", e, propertyName);
    }
    return ret;
  }

  /**
   * ＜消費税改定対応＞<br>
   * 再エネ単価の再設定が必要か判断する
   *
   * @return 再設定必要有無
   */
  private boolean isResettingRecUp() {
    // 消費税率マスタ.適用開始日を年月(yyyyMM)変換
    String ctRateApplySdYm = StringConvertUtil.convertDateToString(this.ctRateM.getApplySd(),
        ECISConstants.FORMAT_DATE_yyyyMM);

    // 料金算定開始日を年月(yyyyMM)変換
    String calcSdYm = StringConvertUtil.convertDateToString(this.calcSd, ECISConstants.FORMAT_DATE_yyyyMM);

    // 利用年月 ＝ 消費税率マスタ.適用開始日の年月　かつ　料金算定開始日の年月 ＝ 消費税率マスタ.適用開始日の年月
    if (this.usePeriod.equals(ctRateApplySdYm) && calcSdYm.equals(ctRateApplySdYm)) {
      return true;
    }
    return false;
  }

  /**
   * ＜消費税改定対応＞<br>
   * 燃料費調整単価の再設定が必要か判断する<br>
   * <b>※燃調単価取得方法区分が利用年月であること</b>
   *
   * @return 再設定必要有無
   */
  private boolean isResettingFcaUp() {
    // 消費税率マスタ.適用開始日を年月(yyyyMM)変換
    String ctRateApplySdYm = StringConvertUtil.convertDateToString(this.ctRateM.getApplySd(),
        ECISConstants.FORMAT_DATE_yyyyMM);

    // 料金算定開始日を年月(yyyyMM)変換
    String calcSdYm = StringConvertUtil.convertDateToString(this.calcSd, ECISConstants.FORMAT_DATE_yyyyMM);

    if (ECISCodeConstants.CUSTOM_VOLTAGE_CAT_CODE_LOW_TENSION.equals(this.contractHist.getVoltageCatCode())
        && this.usePeriod.equals(ctRateApplySdYm) && calcSdYm.equals(ctRateApplySdYm)) {
      // 低圧　かつ　利用年月 ＝ 消費税率マスタ.適用開始日の年月　かつ　料金算定開始日の年月 ＝ 消費税率マスタ.適用開始日の年月
      return true;
    } else if (!ECISCodeConstants.CUSTOM_VOLTAGE_CAT_CODE_LOW_TENSION.equals(this.contractHist.getVoltageCatCode())
        && this.usePeriod.equals(ctRateApplySdYm) && !calcSdYm.equals(ctRateApplySdYm)) {
      // 低圧以外　かつ　利用年月 ＝ 消費税率マスタ.適用開始日の年月　かつ　料金算定開始日の年月 ＜＞ 消費税率マスタ.適用開始日の年月
      return true;
    }
    return false;
  }

  /**
   * ＜消費税改定対応＞ 再エネ単価をコピーし、再エネ単価消費税改定マスタから必要項目を再設定する
   *
   * @param orgRecUpM
   *          再エネ単価
   * @param recUpTrM
   *          再エネ単価消費税改定マスタ
   * @return 再エネ単価
   */
  private RecUpM copyRecUpM(RecUpM orgRecUpM, RecUpTrM recUpTrM) {
    RecUpM recUpM = new RecUpM();

    // 単価・最低金額は再エネ単価消費税改定マスタの値を設定
    recUpM.setUp(recUpTrM.getUp());
    recUpM.setMinimumCharge(recUpTrM.getMinimumCharge());

    // 上記以外の項目はオリジナルの再エネ単価の値を設定
    recUpM.setAreaCode(orgRecUpM.getAreaCode());
    recUpM.setUpApplySd(orgRecUpM.getUpApplySd());
    recUpM.setUpApplyEd(orgRecUpM.getUpApplyEd());
    recUpM.setUsePeriod(orgRecUpM.getUsePeriod());
    recUpM.setDisplayName(orgRecUpM.getDisplayName());
    recUpM.setThresholdName(orgRecUpM.getThresholdName());
    recUpM.setNote(orgRecUpM.getNote());
    recUpM.setUpdateCount(orgRecUpM.getUpdateCount());
    recUpM.setCreateTime(orgRecUpM.getCreateTime());
    recUpM.setOnlineUpdateTime(orgRecUpM.getOnlineUpdateTime());
    recUpM.setOnlineUpdateUserId(orgRecUpM.getOnlineUpdateUserId());
    recUpM.setUpdateTime(orgRecUpM.getUpdateTime());
    recUpM.setUpdateModuleCode(orgRecUpM.getUpdateModuleCode());

    return recUpM;
  }

  /**
   * ＜消費税改定対応＞ 燃料費調整単価をコピーし、燃調単価消費税改定マスタから必要項目を再設定する
   *
   * @param orgFcaUpM
   *          燃料費調整単価
   * @param fcaUpTrM
   *          燃調単価消費税改定マスタ
   * @return 燃料費調整単価
   */
  private FcaUpM copyFcaUpM(FcaUpM orgFcaUpM, FcaUpTrM fcaUpTrM) {
    FcaUpM fcaUpM = new FcaUpM();

    // 単価・最低金額は燃調単価消費税改定マスタの値を設定
    fcaUpM.setUp(fcaUpTrM.getUp());
    fcaUpM.setMinimumCharge(fcaUpTrM.getMinimumCharge());

    // 単価以外の項目はオリジナルの燃料費調整単価の値を設定
    fcaUpM.setAreaCode(orgFcaUpM.getAreaCode());
    fcaUpM.setVoltageCatCode(orgFcaUpM.getVoltageCatCode());
    fcaUpM.setUpApplySd(orgFcaUpM.getUpApplySd());
    fcaUpM.setUpApplyEd(orgFcaUpM.getUpApplyEd());
    fcaUpM.setUsePeriod(orgFcaUpM.getUsePeriod());
    fcaUpM.setDisplayName(orgFcaUpM.getDisplayName());
    fcaUpM.setThresholdName(orgFcaUpM.getThresholdName());
    fcaUpM.setNote(orgFcaUpM.getNote());
    fcaUpM.setUpdateCount(orgFcaUpM.getUpdateCount());
    fcaUpM.setCreateTime(orgFcaUpM.getCreateTime());
    fcaUpM.setOnlineUpdateTime(orgFcaUpM.getOnlineUpdateTime());
    fcaUpM.setOnlineUpdateUserId(orgFcaUpM.getOnlineUpdateUserId());
    fcaUpM.setUpdateTime(orgFcaUpM.getUpdateTime());
    fcaUpM.setUpdateModuleCode(orgFcaUpM.getUpdateModuleCode());

    return fcaUpM;
  }

  /**
   * 予備契約適用単価取得 予備契約開始日が算定期間開始日より未来の場合は、契約開始日時点の単価を取得し、 それ以外の場合は算定開始日時点の単価を取得する
   *
   * @param reserveContractStartDate
   *          予備契約開始日
   * @return 予備契約適用単価取得
   */
  private Date createGetReserveContractUp(Date reserveContractStartDate) {
    if (reserveContractStartDate.compareTo(this.calcSd) > 0) {
      return reserveContractStartDate;
    } else {
      return this.calcSd;
    }
  }

}