package jp.co.unisys.enability.cis.rate_engine.component;

import java.math.BigDecimal;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import jp.co.unisys.enability.cis.common.Exception.RateEngineException;
import jp.co.unisys.enability.cis.common.util.rk.RateEngineCommonUtil;

/**
 * 付帯日割の合計金額計算ビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class CalcSupplementaryListAmountProratedBusiness implements FeeCalcParts {
  /** ロガー */
  private static final Logger LOGGER = LogManager.getLogger();

  /** この部品がサポートする固定パラメータ数 */
  private static final int ARG_CALC_LENGTH = 7;

  /** この部品がサポートする固定パラメータ数 */
  private static final int ARG_LENGTH = 13;

  /**
   * 付帯日割の合計額の計算を行う。<br>
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された情報をもとに付帯契約単位で計算を行い、その合計額を計算する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param args
   *          args[0]:Object 基本料金<br>
   *          args[1]:Object 従量料金<br>
   *          args[2]:Object 付帯メニューリスト<br>
   *          args[3]:Object 丸め桁（計算額）<br>
   *          args[4]:Object 丸め方法（計算額）<br>
   *          args[5]:Object 検針日数<br>
   *          args[6]:Object 日割日数
   * @return 付帯金額合計
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   * @see RateEngineCommonUtil#checkArgsLengthPermitNullVal(Object...)
   * @see RateEngineCommonUtil#convertToDecimals(Object...)
   */
  @Override
  public Object[] calc(Object... args) throws RateEngineException {
    RateEngineCommonUtil.checkArgsLength(args, ARG_CALC_LENGTH);

    Object[] list = (Object[]) args[ArrayIndex.TWO.ordinal()];
    Object[] argsDetails = new Object[] {args[ArrayIndex.ZERO.ordinal()], args[ArrayIndex.ONE.ordinal()],
        list[ArrayIndex.ZERO.ordinal()], list[ArrayIndex.ONE.ordinal()],
        list[ArrayIndex.TWO.ordinal()], list[ArrayIndex.THREE.ordinal()],
        list[ArrayIndex.FOUR.ordinal()], list[ArrayIndex.FIVE.ordinal()],
        list[ArrayIndex.SIX.ordinal()],
        args[ArrayIndex.THREE.ordinal()],
        args[ArrayIndex.FOUR.ordinal()],
        args[ArrayIndex.FIVE.ordinal()],
        args[ArrayIndex.SIX.ordinal()] };

    Object[] result = calcDetail(argsDetails);

    return result;
  }

  /**
   * 付帯(日割)金額の合計額を計算する。<br>
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された情報をもとに付帯契約単位で計算を行う。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param args
   *          args[0]:Object 基本料金<br>
   *          args[1]:Object 従量料金<br>
   *          args[2]:Object 対象区分リスト<br>
   *          args[3]:Object 適用区分リスト<br>
   *          args[4]:Object 種別リスト<br>
   *          args[5]:Object 割引割増区分リスト<br>
   *          args[6]:Object 額率リスト<br>
   *          args[7]:Object 上限額リスト<br>
   *          args[8]:Object 下限額リスト<br>
   *          args[9]:Object 丸め桁<br>
   *          args[10]:Object 丸め方法<br>
   *          args[11]:Object 検針日数<br>
   *          args[12]:Object 日割日数
   * @return 付帯金額
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   * @see RateEngineCommonUtil#checkArgsLengthPermitNullVal(Object...)
   * @see RateEngineCommonUtil#convertToDecimals(Object...)
   */
  public Object[] calcDetail(Object... args) throws RateEngineException {
    RateEngineCommonUtil.checkArgsLength(args, ARG_LENGTH);

    BigDecimal[] decimals = RateEngineCommonUtil
        .convertToDecimals(new Object[] {args[ArrayIndex.ZERO.ordinal()], args[ArrayIndex.ONE.ordinal()],
            args[ArrayIndex.NINE.ordinal()], args[ArrayIndex.TEN.ordinal()],
            args[ArrayIndex.ELEVEN.ordinal()], args[ArrayIndex.TWELEV.ordinal()] });

    // 対象区分リスト
    BigDecimal[] catCodeList = RateEngineCommonUtil.convertToDecimals((Object[]) args[ArrayIndex.TWO.ordinal()]);

    // 適用区分リスト
    BigDecimal[] applyList = RateEngineCommonUtil.convertToDecimals((Object[]) args[ArrayIndex.THREE.ordinal()]);

    // 種別リスト
    BigDecimal[] classCodeList = RateEngineCommonUtil.convertToDecimals((Object[]) args[ArrayIndex.FOUR.ordinal()]);

    // 割引割増区分リスト
    BigDecimal[] discountList = RateEngineCommonUtil.convertToDecimals((Object[]) args[ArrayIndex.FIVE.ordinal()]);

    // 額率リスト
    BigDecimal[] rateList = RateEngineCommonUtil.convertToDecimals((Object[]) args[ArrayIndex.SIX.ordinal()]);

    // 上限額リスト
    BigDecimal[] upperList = RateEngineCommonUtil.convertToDecimals((Object[]) args[ArrayIndex.SEVEN.ordinal()]);

    // 下限額リスト
    BigDecimal[] lowerList = RateEngineCommonUtil.convertToDecimals((Object[]) args[ArrayIndex.EIGHT.ordinal()]);

    // 結果を格納
    Object[] tempResult;
    Object[] resultDetail = new Object[catCodeList.length];
    for (int index = 0; index < catCodeList.length; index++) {
      CalcSupplementaryAmountProratedBusiness calcSupplementaryAmountProratedBusiness = new CalcSupplementaryAmountProratedBusiness();

      Object[] subArgs = new Object[] {decimals[ArrayIndex.ZERO.ordinal()], decimals[ArrayIndex.ONE.ordinal()], catCodeList[index], applyList[index],
          classCodeList[index], discountList[index], rateList[index], upperList[index], lowerList[index], decimals[ArrayIndex.TWO.ordinal()],
          decimals[ArrayIndex.THREE.ordinal()], decimals[ArrayIndex.FOUR.ordinal()], decimals[ArrayIndex.FIVE.ordinal()]
      };

      tempResult = calcSupplementaryAmountProratedBusiness.calc(subArgs);

      resultDetail[index] = tempResult[0];
    }

    BigDecimal amount = new BigDecimal("0");
    for (int index = 0; index < resultDetail.length; index++) {
      amount = amount.add(RateEngineCommonUtil.convertToDecimal(resultDetail[index]));
    }

    Object[] result = new Object[] {amount };

    LOGGER.debug("付帯値合計={}", (Object[]) result);

    // 結果を返却
    return result;
  }

}
