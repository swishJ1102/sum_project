package jp.co.unisys.enability.cis.rate_engine.component;

import java.math.BigDecimal;
import java.util.Objects;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import jp.co.unisys.enability.cis.common.Exception.RateEngineException;
import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;
import jp.co.unisys.enability.cis.common.util.rk.RateEngineCommonUtil;

/**
 * 力率計算ビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class PowerFactorBusiness implements FeeCalcParts {
  /** ロガー */
  private static final Logger LOGGER = LogManager.getLogger();

  /**
   * 力率を返却する。<br>
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 力率がNULLの場合は85、使用量がNULLまたは使用量が0の場合は85、それ以外は入力値を返却する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param args
   *          args[0]:Object 力率<br>
   *          args[1]:Object 使用量<br>
   * @return 力率
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   * @see RateEngineCommonUtil#convertToDecimals(Object...)
   */
  @Override
  public Object[] calc(Object... args) throws RateEngineException {
    // オブジェクト生成
    Object[] ret = new Object[2];

    // 初期化
    ret[ArrayIndex.ZERO.ordinal()] = BigDecimal.valueOf(ECISRKConstants.POWER_FACTOR_EIGHTY_FIVE);
    // 元々の力率を入れておく
    ret[ArrayIndex.ONE.ordinal()] = args[ArrayIndex.ZERO.ordinal()];

    // 力率でNULLが設定された場合
    if (args[ArrayIndex.ZERO.ordinal()] == null) {
      // 85を返却
      ret[ArrayIndex.ZERO.ordinal()] = BigDecimal.valueOf(ECISRKConstants.POWER_FACTOR_EIGHTY_FIVE);
      return ret;
    }

    // 引数を変換
    BigDecimal[] decimals = RateEngineCommonUtil.convertToDecimals(args);
    // 使用量がNULLまたは0の場合
    if (decimals[ArrayIndex.ONE.ordinal()] == null || Objects.equals(decimals[ArrayIndex.ONE.ordinal()], BigDecimal.valueOf(0))) {
      // 85を設定
      ret[ArrayIndex.ZERO.ordinal()] = BigDecimal.valueOf(ECISRKConstants.POWER_FACTOR_EIGHTY_FIVE);
    } else {
      ret[ArrayIndex.ZERO.ordinal()] = decimals[ArrayIndex.ZERO.ordinal()];
    }

    // デバッグログ出力
    LOGGER.debug("力率は、" + ret[ArrayIndex.ZERO.ordinal()]);

    // 結果を返却
    return ret;
  }

}