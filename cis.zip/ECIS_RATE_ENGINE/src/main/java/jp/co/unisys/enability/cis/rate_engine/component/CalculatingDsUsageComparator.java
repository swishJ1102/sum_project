package jp.co.unisys.enability.cis.rate_engine.component;

import java.util.Comparator;

import jp.co.unisys.enability.cis.entity.common.CalculatingDsUsage;

/**
 * 計算用日割別使用量のソートクラス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class CalculatingDsUsageComparator implements Comparator<CalculatingDsUsage> {

  @Override
  public int compare(CalculatingDsUsage o1, CalculatingDsUsage o2) {
    // 項目で比較
    if (o1.getDsSd().compareTo(o2.getDsSd()) > 0) {
      return 1;
    } else {
      return -1;
    }
  }

}