package jp.co.unisys.enability.cis.rate_engine.component;

import java.math.BigDecimal;
import java.util.Objects;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import jp.co.unisys.enability.cis.common.Exception.RateEngineException;
import jp.co.unisys.enability.cis.common.util.rk.RateEngineCommonUtil;

/**
 * 制限中止割引金額頭打ち判定部品ビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RestrictionDiscountInfoAmountReachingLimitPartstBusiness extends ChargeCalcBaseBusiness
    implements FeeCalcParts {
  /** ロガー */
  private static final Logger LOGGER = LogManager.getLogger();

  /** この部品がサポートする固定パラメータ数 */
  private static final int ARG_LENGTH = 4;

  /** 利用年月のMM開始位置 */
  private static final int MM_START = 4;

  /**
   * 制限中止割引金額頭打ち判定部品。<br>
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   *
   * 引数で指定された情報をもとに頭打ち判定を行い、制限中止割引額を取得する。<br>
   * また、引数で指定された情報より、表示項目名称の作成する。<br>
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param args
   *          args[0]:Object 制限中止割引額<br>
   *          args[1]:Object 基本料金<br>
   *          args[2]:Object 利用年月<br>
   *          args[3]:Object 表示名称<br>
   * @return 計算結果配列[制限中止割引額、表示項目名称]
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   * @see RateEngineCommonUtil#checkArgLength(Object...)
   * @see RateEngineCommonUtil#convertToDecimal(Object...)
   */
  @Override
  public Object[] calc(Object... args) throws RateEngineException {

    // チェック対象指定
    int[] nullPermitIndexs = new int[] {0, 0, 1, 1 };

    // 引数長チェック
    RateEngineCommonUtil.checkArgsLengthPermitNullVal(args, ARG_LENGTH, nullPermitIndexs);

    // 頭打ち制限中止割引額
    BigDecimal amount = null;

    // 表示名称
    String dispName = null;

    // 制限中止割引額と基本料金ともにNULLでない場合
    if (!Objects.isNull((Object) args[ArrayIndex.ZERO.ordinal()])
        && !Objects.isNull((Object) args[ArrayIndex.ONE.ordinal()])) {
      // 制限中止割引額
      BigDecimal downPrice = RateEngineCommonUtil.convertToDecimal((Object) args[ArrayIndex.ZERO.ordinal()]);
      // 基本料金
      BigDecimal basePrice = RateEngineCommonUtil.convertToDecimal((Object) args[ArrayIndex.ONE.ordinal()]);
      // 制限中止割引額 > 基本料金の場合
      if (downPrice.compareTo(basePrice) > 0) {
        // 対象基本料金を設定
        amount = basePrice;
      } else {
        // 制限中止割引額を設定
        amount = downPrice;
      }

      // 表示名称の生成
      StringBuilder sb = new StringBuilder();
      sb.append(args[ArrayIndex.THREE.ordinal()].toString());
      sb.append("（");
      sb.append(args[ArrayIndex.TWO.ordinal()].toString().substring(MM_START));
      sb.append("月分）");
      dispName = sb.toString();
    }

    if (!Objects.isNull(amount)) {
      // 制限中止割引額をマイナスにする
      amount = amount.multiply(new BigDecimal(-1));
    }

    // デバッグログ出力
    LOGGER.debug("制限中止割引額={} 表示項目名称={}", amount, dispName);

    // 結果を返却
    return new Object[] {amount, dispName };
  }
}
