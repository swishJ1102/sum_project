package jp.co.unisys.enability.cis.rate_engine.component;

import java.math.BigDecimal;
import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import jp.co.unisys.enability.cis.common.Exception.RateEngineException;
import jp.co.unisys.enability.cis.common.util.rk.RateEngineCommonUtil;

/**
 * 託託送料金計算（二部料金制電灯標準メニューkVA1）ビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class ConsignmentChargeCalcTwoPartChargeElecLightStandardMenukVA1Business extends ChargeCalcBaseBusiness
    implements FeeCalcParts {
  /** ロガー */
  private static final Logger LOGGER = LogManager.getLogger();

  /** この部品がサポートする固定パラメータ数 */
  private static final int ARG_LENGTH = 17;

  /**
   * 二部料金制電灯標準メニュー（kVA：関西、中国、四国以外）の託送料金の計算を行う。<br>
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された情報をもとに託送料金（二部料金制電灯標準(kVA)：関西、中国、四国以外）を計算する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param args
   *          args[0]:Object 契約容量<br>
   *          args[1]:Object 基本料金単価<br>
   *          args[2]:Object 使用量<br>
   *          args[3]:Object 使用量単価<br>
   *          args[4]:Object 最低月額料金<br>
   *          args[5]:Object 検針日数<br>
   *          args[6]:Object 日割日数<br>
   *          args[7]:Object 丸め桁（内訳）<br>
   *          args[8]:Object 丸め方法（内訳）<br>
   *          args[9]:Object 丸め桁（合計）<br>
   *          args[10]:Object 丸め方法（合計）<br>
   *          args[11]:Object 算定期間開始日<br>
   *          args[12]:Object 算定期間終了日<br>
   *          args[13]:Object 契約開始日<br>
   *          args[14]:Object 契約終了日<br>
   *          args[15]:Object 基本料金無料有無<br>
   *          args[16]:Object 最低月額料金適用有無<br>
   * @return 託送料金[合計額、基本料金、従量料金、最低月額料金適用有無]
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   * @see RateEngineCommonUtil#checkArgsLength(Object...)
   * @see RateEngineCommonUtil#convertToDecimals(Object...)
   */
  @Override
  public Object[] calc(Object... args) throws RateEngineException {
    // パラメータをデバッグログ出力
    LOGGER.debug("契約容量={} 基本料金単価={} 使用量={} 使用量単価={} 最低月額料金={} 検針日数={} 日割日数={} ",
        args[ArrayIndex.ZERO.ordinal()], args[ArrayIndex.ONE.ordinal()], args[ArrayIndex.TWO.ordinal()],
        args[ArrayIndex.THREE.ordinal()], args[ArrayIndex.FOUR.ordinal()], args[ArrayIndex.FIVE.ordinal()],
        args[ArrayIndex.SIX.ordinal()]);

    // 引数長チェック
    int[] nullPermitIndexs = new int[] {1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 };
    RateEngineCommonUtil.checkArgsLengthPermitNullVal(args, ARG_LENGTH, nullPermitIndexs);

    // 数値変換
    BigDecimal[] decimals = RateEngineCommonUtil.convertToDecimals(args[ArrayIndex.ZERO.ordinal()],
        args[ArrayIndex.ONE.ordinal()], args[ArrayIndex.TWO.ordinal()],
        args[ArrayIndex.THREE.ordinal()], args[ArrayIndex.FOUR.ordinal()], args[ArrayIndex.FIVE.ordinal()],
        args[ArrayIndex.SIX.ordinal()], args[ArrayIndex.SEVEN.ordinal()], args[ArrayIndex.EIGHT.ordinal()],
        args[ArrayIndex.NINE.ordinal()], args[ArrayIndex.TEN.ordinal()]);

    // 基本料金計算係数
    super.setBasicPriceCoefficient(decimals[ArrayIndex.TWO.ordinal()]);
    // 日割率
    super.setPerDiemRate(decimals[ArrayIndex.SIX.ordinal()], decimals[ArrayIndex.FIVE.ordinal()]);

    // 基本料金を計算する
    // 契約容量×単価
    BigDecimal dcPrice = super.calcDCPrice(
        decimals[ArrayIndex.ZERO.ordinal()].multiply(decimals[ArrayIndex.ONE.ordinal()]),
        decimals[ArrayIndex.SEVEN.ordinal()], decimals[ArrayIndex.EIGHT.ordinal()]);

    // 初月無料であるか計算する
    dcPrice = super.getBasePrice(dcPrice, (Date) args[ArrayIndex.ELEVEN.ordinal()],
        (Date) args[ArrayIndex.TWELEV.ordinal()], (Date) args[ArrayIndex.THIRTEEN.ordinal()],
        (Date) args[ArrayIndex.FOURTEEN.ordinal()], args[ArrayIndex.FIFTEEN.ordinal()].toString());

    // 従量料金を計算する
    BigDecimal ecPrice = super.calcCharge(decimals[ArrayIndex.TWO.ordinal()], decimals[ArrayIndex.THREE.ordinal()],
        decimals[ArrayIndex.SEVEN.ordinal()], decimals[ArrayIndex.EIGHT.ordinal()]);

    // 最低月額料金
    BigDecimal lowestPrice = super.calcCharge(decimals[ArrayIndex.FOUR.ordinal()],
        decimals[ArrayIndex.SEVEN.ordinal()], decimals[ArrayIndex.EIGHT.ordinal()]);

    // 合計額を計算する
    Object[] result = super.getTotalPrice(dcPrice, ecPrice, lowestPrice,
        args[ArrayIndex.SIXTEEN.ordinal()].toString(), decimals[ArrayIndex.NINE.ordinal()],
        decimals[ArrayIndex.TEN.ordinal()]);

    // デバッグログ出力
    LOGGER.debug("合計額={} 基本料金={} 従量料金={} 最低月額料金適用有無={}", result);

    // 結果を返却
    return result;
  }
}
