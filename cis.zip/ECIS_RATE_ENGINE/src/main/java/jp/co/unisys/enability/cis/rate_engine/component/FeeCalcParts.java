package jp.co.unisys.enability.cis.rate_engine.component;

import jp.co.unisys.enability.cis.common.Exception.RateEngineException;

/**
 * 計算部品のインターフェースクラス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public interface FeeCalcParts {

  /**
   * 引数で指定された情報をもとに計算を行う。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された情報をもとに計算する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param args
   *          引数(可変長)<br>
   * @return Object[] 計算結果 ※計算結果にかかわらず必ずオブジェクト配列を返す。
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   */
  Object[] calc(Object... args) throws RateEngineException;

  /**
   * 配列のインデックス定義。
   *
   * @author "Nihon Unisys, Ltd."
   */
  enum ArrayIndex {
    /** インデックス：0 */
    ZERO,
    /** インデックス：1 */
    ONE,
    /** インデックス：2 */
    TWO,
    /** インデックス：3 */
    THREE,
    /** インデックス：4 */
    FOUR,
    /** インデックス：5 */
    FIVE,
    /** インデックス：6 */
    SIX,
    /** インデックス：7 */
    SEVEN,
    /** インデックス：8 */
    EIGHT,
    /** インデックス：9 */
    NINE,
    /** インデックス：10 */
    TEN,
    /** インデックス：11 */
    ELEVEN,
    /** インデックス：12 */
    TWELEV,
    /** インデックス：13 */
    THIRTEEN,
    /** インデックス：14 */
    FOURTEEN,
    /** インデックス：15 */
    FIFTEEN,
    /** インデックス：16 */
    SIXTEEN,
    /** インデックス：17 */
    SEVENTEEN,
    /** インデックス：18 */
    EIGHTEEN,
    /** インデックス：19 */
    NINETEEN;
  }
}
