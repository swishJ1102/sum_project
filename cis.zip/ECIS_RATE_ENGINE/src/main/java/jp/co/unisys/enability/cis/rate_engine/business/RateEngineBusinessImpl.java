package jp.co.unisys.enability.cis.rate_engine.business;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.config.PropertiesFactoryBean;

import jp.co.unisys.enability.cis.common.Exception.BusinessLogicException;
import jp.co.unisys.enability.cis.common.Exception.RateEngineException;
import jp.co.unisys.enability.cis.common.util.RK_PropertyUtil;
import jp.co.unisys.enability.cis.common.util.StringConvertUtil;
import jp.co.unisys.enability.cis.common.util.constants.ECISCodeConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;
import jp.co.unisys.enability.cis.entity.common.CalculatingDsUsage;
import jp.co.unisys.enability.cis.entity.common.CalculatingDsUsageExample;
import jp.co.unisys.enability.cis.entity.common.CalculatingTsUsage;
import jp.co.unisys.enability.cis.entity.common.CalculatingTsUsageExample;
import jp.co.unisys.enability.cis.entity.common.CalculatingUsage;
import jp.co.unisys.enability.cis.entity.common.CalculatingUsageExample;
import jp.co.unisys.enability.cis.entity.common.CalculationResult;
import jp.co.unisys.enability.cis.entity.common.ClcBreakdown;
import jp.co.unisys.enability.cis.entity.common.Contract;
import jp.co.unisys.enability.cis.entity.common.ContractExample;
import jp.co.unisys.enability.cis.entity.common.ContractHist;
import jp.co.unisys.enability.cis.entity.common.ContractHistExample;
import jp.co.unisys.enability.cis.entity.common.Fcr;
import jp.co.unisys.enability.cis.entity.common.FcrBreakdown;
import jp.co.unisys.enability.cis.entity.common.Rm;
import jp.co.unisys.enability.cis.entity.common.RmExample;
import jp.co.unisys.enability.cis.entity.common.SplContract;
import jp.co.unisys.enability.cis.entity.common.SplContractExample;
import jp.co.unisys.enability.cis.mapper.common.CalculatingDsUsageMapper;
import jp.co.unisys.enability.cis.mapper.common.CalculatingTsUsageMapper;
import jp.co.unisys.enability.cis.mapper.common.CalculatingUsageMapper;
import jp.co.unisys.enability.cis.mapper.common.ContractHistMapper;
import jp.co.unisys.enability.cis.mapper.common.ContractMapper;
import jp.co.unisys.enability.cis.mapper.common.RmMapper;
import jp.co.unisys.enability.cis.mapper.common.SplContractMapper;
import jp.co.unisys.enability.cis.rate_engine.component.FcrBreakdownComparator;
import jp.co.unisys.enability.cis.rate_engine.model.RateEngineBusinessBean;

/***
 * 料金計算エンジンビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.rate_engine.business.RateEngineBusiness
 */
public class RateEngineBusinessImpl implements RateEngineBusiness {
  /**
   * プロパティ(DI)
   */
  private PropertiesFactoryBean applicationProperties;

  /**
   * 料金計算エンジン単価情報管理ビジネス(DI)
   */
  private ChargeUpManagementBusiness chargeUpManagement;

  /**
   * 料金計算エンジンコントロールビジネス(DI)
   */
  private RateEngineControlBusiness rateEngineControl;

  /**
   * 計算用使用量Mapper(DI)
   */
  private CalculatingUsageMapper calculatingUsageMapper;

  /**
   * 計算用日割別使用量Mapper(DI)
   */
  private CalculatingDsUsageMapper calculatingDsUsageMapper;

  /**
   * 計算用時間帯別使用量Mapper(DI)
   */
  private CalculatingTsUsageMapper calculatingTsUsageMapper;

  /**
   * 付帯契約Mapper(DI)
   */
  private SplContractMapper splContractMapper;

  /**
   * 料金メニューMapper(DI)
   */
  private RmMapper rmMapper;

  /**
   * 契約Mapper(DI)
   */
  private ContractMapper contractMapper;

  /**
   * 契約履歴Mapper(DI)
   */
  private ContractHistMapper contractHistMapper;

  /**
   * 契約種別計算明細管理ビジネス(DI)
   */
  private ContractClassCalcDetailManagementBusiness contractClassCalcDetailManagement;

  /**
   * 最低月額料金の名称
   */
  private String minMonthlyChargeName;

  /**
   * 基本料金無料
   */
  private String basicChargeFree;

  /**
   * 固定部分有りエリアリスト
   */
  private String fixChargeAreaList;

  /**
   * 付帯の名称
   */
  private String supplementaryName;

  /**
   * 契約超過金計算倍率
   */
  private BigDecimal contractExcessChargeCalcScaleFactor;

  /**
   * 契約超過金表示名称1
   */
  private String contractExcessChargeDisplayName1;

  /**
   * 契約超過金表示名称2
   */
  private String contractExcessChargeDisplayName2;

  /** ロガー */
  private static final Logger LOGGER = LogManager.getLogger();

  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.rate_engine.business.RateEngineBusiness#calculateOnline(java.lang.Integer, java.lang.String, jp.co.unisys.enability.cis.rate_engine.model.RateEngineBusinessBean)
   */
  @Override
  public void calculateOnline(Integer constractId, String usePeriod, RateEngineBusinessBean rateEngineBusinessBean) {
    try {
      // 設定値をロード
      loadSettings();

      // 単価情報をロード
      chargeUpManagement.loadData();
      // 契約種別計算明細管理をロード
      contractClassCalcDetailManagement.loadData();
      // 単価情報を設定
      rateEngineBusinessBean.setChargeUpManagement(chargeUpManagement);

      // -- 付帯契約の取得と設定
      SplContractExample splExample = new SplContractExample();
      // 抽出条件を設定
      splExample.createCriteria()
          .andContractIdEqualTo(constractId)
          .andSplContractSdLessThanOrEqualTo(rateEngineBusinessBean.getCalculatingUsage().getCcSd())
          .andSplContractEdGreaterThanOrEqualTo(rateEngineBusinessBean.getCalculatingUsage().getCcSd());
      List<SplContract> splContracts = splContractMapper.selectByExample(splExample);

      rateEngineBusinessBean.setSplContract(splContracts);

      // -- 契約種別コードの取得と設定
      RmExample rmExample = new RmExample();
      rmExample.createCriteria().andRmIdEqualTo(rateEngineBusinessBean.getCalculatingUsage().getRmId());
      List<Rm> rms = rmMapper.selectByExample(rmExample);

      rateEngineBusinessBean.setRm(rms.get(0));

      rateEngineBusinessBean.setContractClassCode(rms.get(0).getCclCode());

      // -- 契約種別計算明細管理の設定
      rateEngineBusinessBean.setContractClassCalcDetailManagement(contractClassCalcDetailManagement);

      // -- エリアコードの設定
      rateEngineBusinessBean.setAreaCd(rms.get(0).getAreaCode());

      // -- 託送メニューIDの設定
      rateEngineBusinessBean.setConsignmentMenuId(rms.get(0).getConsignmentMenuId());

      // -- 計算結果登録フラグの設定（false）
      rateEngineBusinessBean.setRegistResultFlag(false);

      // -- 契約の取得と設定
      ContractExample contractExample = new ContractExample();
      contractExample.createCriteria().andContractIdEqualTo(constractId);
      List<Contract> contractList = contractMapper.selectByExample(contractExample);
      if (contractList.size() == 0) {
        // 契約開始日
        rateEngineBusinessBean.setContractStartDate(rateEngineBusinessBean.getCalculatingUsage().getCcSd());

        // 契約終了日
        rateEngineBusinessBean.setContractEndDate(rateEngineBusinessBean.getCalculatingUsage().getCcEd());

      } else {
        Contract contract = contractList.get(0);

        // 契約開始日
        rateEngineBusinessBean.setContractStartDate(contract.getContractSd());

        // 契約終了日
        rateEngineBusinessBean.setContractEndDate(contract.getContractEd());
      }

      // 契約履歴を取得し、設定
      if (rateEngineBusinessBean.getContractHist() == null) {
        ContractHistExample cHistExample = new ContractHistExample();
        cHistExample.createCriteria()
            .andContractIdEqualTo(constractId)
            .andApplyEdGreaterThanOrEqualTo(rateEngineBusinessBean.getCalculatingUsage().getCcSd())
            .andApplySdLessThanOrEqualTo(rateEngineBusinessBean.getCalculatingUsage().getCcSd());
        List<ContractHist> contractHistList = contractHistMapper.selectByExample(cHistExample);
        rateEngineBusinessBean.setContractHist(contractHistList.get(0));
      }

      // -- プロパティからの設定値を設定
      // 最低月額料金名称
      rateEngineBusinessBean.setMinMonthlyChargeName(this.minMonthlyChargeName);

      // 基本料金無料有無
      rateEngineBusinessBean.setBasicChargeFree(this.basicChargeFree);

      // 固定部分有りエリアリスト
      rateEngineBusinessBean.setFixChargeAreaList(this.fixChargeAreaList);

      // 付帯名称
      rateEngineBusinessBean.setSupplementaryName(this.supplementaryName);

      // 日割個数
      rateEngineBusinessBean.setProratedQuantity(rateEngineBusinessBean.getCalculatingDateSlotUsage().size());

      // 契約超過金計算倍率
      rateEngineBusinessBean.setContractExcessChargeCalcScaleFactor(this.contractExcessChargeCalcScaleFactor);

      // 契約超過金表示名称1
      rateEngineBusinessBean.setContractExcessChargeDisplayName1(this.contractExcessChargeDisplayName1);

      // 契約超過金表示名称2
      rateEngineBusinessBean.setContractExcessChargeDisplayName2(this.contractExcessChargeDisplayName2);

      // 計算処理の呼び出し
      rateEngineControl.execute(String.valueOf(constractId), usePeriod, rateEngineBusinessBean);

      rateEngineBusinessBean.setExecuteResult(0);

      // オンライン用にデータの詰め替え
      convertToOnlineData(rateEngineBusinessBean);
    } catch (RateEngineException e) {
      rateEngineBusinessBean.setExecuteResult(1);
    }
  }

  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.rate_engine.business.RateEngineBusiness#calculateBatch(java.lang.Integer, java.lang.String)
   */
  @Override
  public void calculateBatch(Integer constractId, String usePeriod) throws BusinessLogicException {
    RateEngineBusinessBean rateEngineBusinessBean = new RateEngineBusinessBean();

    try {
      // 設定値をロード
      loadSettings();

      if (chargeUpManagement.getRateMenuUnitPriceCount() == 0) {
        // 単価情報をロード
        chargeUpManagement.loadData();
      }
      if (contractClassCalcDetailManagement.getgetContractClassMasterCount() == 0) {
        // 契約種別計算明細管理をロード
        contractClassCalcDetailManagement.loadData();
      }
      // 単価情報を設定
      rateEngineBusinessBean.setChargeUpManagement(chargeUpManagement);

      // -- 計算用使用量の取得と設定
      CalculatingUsageExample example = new CalculatingUsageExample();
      // 抽出条件を設定
      example.createCriteria()
          .andContractIdEqualTo(constractId)
          .andUsePeriodEqualTo(usePeriod);
      List<CalculatingUsage> calculatingUsages = calculatingUsageMapper.selectByExample(example);
      // 1件だけほしいので最初の1件だけ取得
      CalculatingUsage calculatingUsage = calculatingUsages.get(0);

      rateEngineBusinessBean.setCalculatingUsage(calculatingUsage);

      // -- 計算用日割別使用量の取得と設定
      CalculatingDsUsageExample dsExample = new CalculatingDsUsageExample();
      // 抽出条件を設定
      dsExample.createCriteria()
          .andContractIdEqualTo(constractId)
          .andUsePeriodEqualTo(usePeriod);
      List<CalculatingDsUsage> calculatingDsUsages = calculatingDsUsageMapper.selectByExample(dsExample);

      rateEngineBusinessBean.setCalculatingDateSlotUsage(calculatingDsUsages);

      // -- 日割個数の設定
      rateEngineBusinessBean.setProratedQuantity(calculatingDsUsages.size());

      // -- 計算用時間帯別使用量の取得と設定
      CalculatingTsUsageExample tsExample = new CalculatingTsUsageExample();
      // 抽出条件を設定
      tsExample.createCriteria()
          .andContractIdEqualTo(constractId)
          .andUsePeriodEqualTo(usePeriod);
      List<CalculatingTsUsage> calculatingTsUsages = calculatingTsUsageMapper.selectByExample(tsExample);

      rateEngineBusinessBean.setCalculatingTimeSlotUsage(calculatingTsUsages);

      // -- 付帯契約の取得と設定
      SplContractExample splExample = new SplContractExample();
      // 抽出条件を設定
      splExample.createCriteria()
          .andContractIdEqualTo(constractId)
          .andSplContractSdLessThanOrEqualTo(calculatingUsage.getCcSd())
          .andSplContractEdGreaterThanOrEqualTo(calculatingUsage.getCcSd());
      List<SplContract> splContracts = splContractMapper.selectByExample(splExample);

      rateEngineBusinessBean.setSplContract(splContracts);

      // -- 契約種別コードの取得と設定
      RmExample rmExample = new RmExample();
      rmExample.createCriteria().andRmIdEqualTo(calculatingUsage.getRmId());
      List<Rm> rms = rmMapper.selectByExample(rmExample);

      rateEngineBusinessBean.setContractClassCode(rms.get(0).getCclCode());

      // -- 契約種別計算明細管理の設定
      rateEngineBusinessBean.setContractClassCalcDetailManagement(contractClassCalcDetailManagement);

      // -- エリアコードの設定
      rateEngineBusinessBean.setAreaCd(rms.get(0).getAreaCode());

      // -- 託送メニューIDの設定
      rateEngineBusinessBean.setConsignmentMenuId(rms.get(0).getConsignmentMenuId());

      // -- 契約の取得と設定
      ContractExample contractExample = new ContractExample();
      contractExample.createCriteria().andContractIdEqualTo(constractId);
      List<Contract> contractList = contractMapper.selectByExample(contractExample);
      Contract contract = contractList.get(0);

      // 契約履歴を取得し、設定
      ContractHistExample cHistExample = new ContractHistExample();
      cHistExample.createCriteria()
          .andContractIdEqualTo(constractId)
          .andApplyEdGreaterThanOrEqualTo(rateEngineBusinessBean.getCalculatingUsage().getCcSd())
          .andApplySdLessThanOrEqualTo(rateEngineBusinessBean.getCalculatingUsage().getCcSd());
      List<ContractHist> contractHistList = contractHistMapper.selectByExample(cHistExample);
      rateEngineBusinessBean.setContractHist(contractHistList.get(0));

      // 契約開始日
      rateEngineBusinessBean.setContractStartDate(contract.getContractSd());

      // 契約終了日
      rateEngineBusinessBean.setContractEndDate(contract.getContractEd());

      // -- プロパティからの設定値を設定
      // 最低月額料金名称
      rateEngineBusinessBean.setMinMonthlyChargeName(this.minMonthlyChargeName);

      // 基本料金無料有無
      rateEngineBusinessBean.setBasicChargeFree(this.basicChargeFree);

      // 固定部分有りエリアリスト
      rateEngineBusinessBean.setFixChargeAreaList(this.fixChargeAreaList);

      // 付帯名称
      rateEngineBusinessBean.setSupplementaryName(this.supplementaryName);

      // 契約超過金計算倍率
      rateEngineBusinessBean.setContractExcessChargeCalcScaleFactor(this.contractExcessChargeCalcScaleFactor);

      // 契約超過金表示名称1
      rateEngineBusinessBean.setContractExcessChargeDisplayName1(this.contractExcessChargeDisplayName1);

      // 契約超過金表示名称2
      rateEngineBusinessBean.setContractExcessChargeDisplayName2(this.contractExcessChargeDisplayName2);

      // 計算処理の呼び出し
      rateEngineControl.execute(String.valueOf(constractId), usePeriod, rateEngineBusinessBean);
    } catch (RateEngineException e) {
      throw new BusinessLogicException(null, e);
    }
  }

  /**
   * 料金計算エンジンコントロールビジネスのsetter(DI)
   *
   * @param calcInfoManagement
   */
  public void setRateEngineControl(RateEngineControlBusiness rateEngineControl) {
    this.rateEngineControl = rateEngineControl;
  }

  /**
   * 料金計算エンジン単価情報管理ビジネスのsetter(DI)
   *
   * @param chargeUpManagement
   */
  public void setChargeUpManagement(ChargeUpManagementBusiness chargeUpManagement) {
    this.chargeUpManagement = chargeUpManagement;
  }

  /**
   * 計算用使用量Mapperのsetter(DI)
   *
   * @param calculatingUsageMapper
   */
  public void setCalculatingUsageMapper(CalculatingUsageMapper calculatingUsageMapper) {
    this.calculatingUsageMapper = calculatingUsageMapper;
  }

  /**
   * 計算用日割別使用量Mapperのsetter(DI)
   *
   * @param calculatingTsUsageMapper
   */
  public void setCalculatingDsUsageMapper(CalculatingDsUsageMapper calculatingDsUsageMapper) {
    this.calculatingDsUsageMapper = calculatingDsUsageMapper;
  }

  /**
   * 計算用時間帯別使用量Mapperのsetter(DI)
   *
   * @param calculatingTsUsageMapper
   */
  public void setCalculatingTsUsageMapper(CalculatingTsUsageMapper calculatingTsUsageMapper) {
    this.calculatingTsUsageMapper = calculatingTsUsageMapper;
  }

  /**
   * 付帯契約Mapperのsetter(DI)
   *
   * @param splContractMapper
   */
  public void setSplContractMapper(SplContractMapper splContractMapper) {
    this.splContractMapper = splContractMapper;
  }

  /**
   * 料金メニューMapperのsetter(DI)
   *
   * @param rmMapper
   */
  public void setRmMapper(RmMapper rmMapper) {
    this.rmMapper = rmMapper;
  }

  /**
   * 契約Mapperのsetter(DI)
   *
   * @param contractMapper
   */
  public void setContractMapper(ContractMapper contractMapper) {
    this.contractMapper = contractMapper;
  }

  /**
   * 契約履歴Mapperのsetter(DI)
   *
   * @param contractHistMapper
   */
  public void setContractHistMapper(ContractHistMapper contractHistMapper) {
    this.contractHistMapper = contractHistMapper;
  }

  /**
   * 契約種別計算明細管理ビジネスのsetter(DI)
   *
   * @param contractClassCalcDetailManagement
   */
  public void setContractClassCalcDetailManagement(
      ContractClassCalcDetailManagementBusiness contractClassCalcDetailManagement) {
    this.contractClassCalcDetailManagement = contractClassCalcDetailManagement;
  }

  /**
   * コード定義プロパティを設定します。(DI)
   *
   * @author "Nihon Unisys, Ltd."
   * @param applicationProperties
   *          コード定義プロパティ
   */
  public void setApplicationProperties(
      PropertiesFactoryBean applicationProperties) {
    this.applicationProperties = applicationProperties;
  }

  /**
   * プロパティの設定値を読み出し、設定します。
   */
  private void loadSettings() {
    // プロパティから設定を読み取り
    this.minMonthlyChargeName = RK_PropertyUtil
        .getProperty(applicationProperties, "rate.engine.mincharge.name");
    this.basicChargeFree = RK_PropertyUtil.getProperty(applicationProperties, "rate.engine.basiccharge.free");
    this.fixChargeAreaList = RK_PropertyUtil.getProperty(applicationProperties,
        "rate.engine.conscharge.basiccharge.fixed.arealist");
    this.supplementaryName = RK_PropertyUtil.getProperty(applicationProperties,
        "rate.engine.supplementary.name");
    this.contractExcessChargeCalcScaleFactor = new BigDecimal(RK_PropertyUtil.getProperty(applicationProperties,
        "rate.engine.contractExcessCharge.calcScaleFactor"));
    this.contractExcessChargeDisplayName1 = RK_PropertyUtil.getProperty(applicationProperties,
        "rate.engine.contractExcessCharge.DisplayName1");
    this.contractExcessChargeDisplayName2 = RK_PropertyUtil.getProperty(applicationProperties,
        "rate.engine.contractExcessCharge.DisplayName2");
  }

  /***
   * オンライン用にデータの詰め替えを行います。
   *
   * @param rateEngineBusinessBean
   *          料金計算エンジンビジネスBean
   */
  private void convertToOnlineData(RateEngineBusinessBean rateEngineBusinessBean) {
    // ----- 各Beanへの設定 -----
    // --- 確定料金実績 ---
    Fcr fixChargeResult = new Fcr();

    // 料金計算エンジンビジネスの結果
    CalculationResult calcResult = rateEngineBusinessBean.getCalculationResult();

    // 契約ID
    fixChargeResult.setContractId(calcResult.getContractId());

    // 利用年月
    fixChargeResult.setUsePeriod(calcResult.getUsePeriod());

    // 計算用力率
    fixChargeResult.setCalculatingPowerFactor(calcResult.getCalculatingPowerFactor());

    // 基本料金
    fixChargeResult.setBasicCharge(calcResult.getBasicCharge());

    // 従量料金
    fixChargeResult.setUsageCharge(calcResult.getUsageCharge());

    // 燃料費調整額
    fixChargeResult.setFca(calcResult.getFca());

    // 再エネ賦課金
    fixChargeResult.setRec(calcResult.getRec());

    // 付帯金額
    fixChargeResult.setSplAmount(calcResult.getSplAmount());

    // 契約超過金
    fixChargeResult.setCec(calcResult.getCec());

    // 託送料金相当額
    fixChargeResult.setConsignmentChargeEquivalent(calcResult
        .getConsignmentChargeEquivalent());

    // 料金メニューID
    fixChargeResult.setRmId(rateEngineBusinessBean.getCalculatingUsage().getRmId());

    // 算定期間開始日
    fixChargeResult.setCcSd(rateEngineBusinessBean.getCalculatingUsage().getCcSd());

    // 算定期間終了日
    fixChargeResult.setCcEd(rateEngineBusinessBean.getCalculatingUsage().getCcEd());

    // 返却値の項目に設定
    rateEngineBusinessBean.setFixChargeResult(fixChargeResult);

    // --- 確定料金実績内訳 ---
    List<FcrBreakdown> fixChargeResultBreakdownList = new ArrayList<FcrBreakdown>();
    FcrBreakdown fixChargeResultBreakdown = null;

    // 確定料金実績内訳の数分、以下の処理を行う
    for (ClcBreakdown clcBreakdown : rateEngineBusinessBean.getClcBreakdown()) {
      // Beanを生成
      fixChargeResultBreakdown = new FcrBreakdown();
      // 表示順
      fixChargeResultBreakdown.setDisplayOrder(clcBreakdown.getDisplayOrder());

      // 明細出力順
      fixChargeResultBreakdown.setDetailOutputOrder(clcBreakdown.getDetailOutputOrder());

      // 表示名称1
      fixChargeResultBreakdown.setDisplayName1(clcBreakdown.getDisplayName1());

      // 表示名称2
      fixChargeResultBreakdown.setDisplayName2(clcBreakdown.getDisplayName2());

      // 容量・使用量
      fixChargeResultBreakdown.setCapacityOrUsage(clcBreakdown.getCapacityOrUsage());

      // 単価
      fixChargeResultBreakdown.setUp(clcBreakdown.getUp());

      // 金額
      fixChargeResultBreakdown.setAmount(clcBreakdown.getAmount());

      // 付帯契約ID
      fixChargeResultBreakdown.setSplContractId(clcBreakdown.getSplContractId());

      // 付帯率
      fixChargeResultBreakdown.setSplRate(clcBreakdown.getSplRate());

      // 付帯対象区分コード
      fixChargeResultBreakdown.setSplCoveredCatCode(clcBreakdown.getSplCoveredCatCode());

      // 確定料金実績内訳区分コード
      fixChargeResultBreakdown.setFcrBreakdownCatCode(clcBreakdown.getFcrBreakdownCatCode());

      // リストに追加
      fixChargeResultBreakdownList.add(fixChargeResultBreakdown);
    }

    // リストをソート
    Collections.sort(fixChargeResultBreakdownList, new FcrBreakdownComparator());

    // 内訳をセット
    rateEngineBusinessBean.setFcrBreakdowns(fixChargeResultBreakdownList);

    // 計算結果の力率を設定
    rateEngineBusinessBean.getCalculatingUsage().setPowerFactor(calcResult.getCalculatingPowerFactor());
  }

  // 商品化追加開発：料金シミュレーション ykomoto 2016/04/20 Edit Start
  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.rate_engine.business.RateEngineBusiness#calculateSimulation(java.lang.Integer, java.lang.String, jp.co.unisys.enability.cis.rate_engine.model.RateEngineBusinessBean)
   */
  @Override
  public void rateSimulation(Integer constractId, String usePeriod,
      RateEngineBusinessBean rateEngineBusinessBean, Date upBaseDate) {
    try {
      // 設定値をロード
      loadSettings();

      // -- 料金シミュレーション不具合対応（高圧改修関連） Added Start
      ContractHist cHist = new ContractHist();
      // 単価設定区分：メニュー毎
      cHist.setUpCatCode(ECISConstants.UNIT_PRICE_SETTING_CATEGORY_DEF);
      // 電圧区分：低圧（燃調単価取得用）
      cHist.setVoltageCatCode(ECISCodeConstants.CUSTOM_VOLTAGE_CAT_CODE_LOW_TENSION);
      rateEngineBusinessBean.setContractHist(cHist);
      // -- 料金シミュレーション不具合対応（高圧改修関連） Added End

      // 単価情報をロード
      // 2016/07/01 料金シミュレーション不具合対応 Mod Start
      // chargeUpManagement.loadData();
      chargeUpManagement.loadData(upBaseDate, rateEngineBusinessBean, usePeriod);
      // 2016/07/01 料金シミュレーション不具合対応 Mod End
      // 契約種別計算明細管理をロード
      contractClassCalcDetailManagement.loadData();
      // 単価情報を設定
      rateEngineBusinessBean.setChargeUpManagement(chargeUpManagement);

      rateEngineBusinessBean.setSplContract(new ArrayList<>());

      // -- 契約種別コードの取得と設定
      RmExample rmExample = new RmExample();
      rmExample.createCriteria().andRmIdEqualTo(rateEngineBusinessBean.getCalculatingUsage().getRmId());
      List<Rm> rms = rmMapper.selectByExample(rmExample);

      rateEngineBusinessBean.setRm(rms.get(0));

      rateEngineBusinessBean.setContractClassCode(rms.get(0).getCclCode());

      // -- 契約種別計算明細管理の設定
      rateEngineBusinessBean.setContractClassCalcDetailManagement(contractClassCalcDetailManagement);

      // -- エリアコードの設定
      rateEngineBusinessBean.setAreaCd(rms.get(0).getAreaCode());

      // -- 託送メニューIDの設定
      rateEngineBusinessBean.setConsignmentMenuId(rms.get(0).getConsignmentMenuId());

      // -- 計算結果登録フラグの設定（false）
      rateEngineBusinessBean.setRegistResultFlag(false);

      // 2016/07/01 料金シミュレーション不具合対応 #1134 Mod Start
      //			// 契約開始日
      //			rateEngineBusinessBean.setContractStartDate(rateEngineBusinessBean.getCalculatingUsage().getCcSd());
      //
      //			// 契約終了日
      //			rateEngineBusinessBean.setContractEndDate(rateEngineBusinessBean.getCalculatingUsage().getCcEd());
      // 契約開始日
      rateEngineBusinessBean.setContractStartDate(
          StringConvertUtil.stringToDate(ECISRKConstants.UP_APPLY_MIN_DATE, ECISConstants.FORMAT_DATE_yyyyMMdd));

      // 契約終了日
      rateEngineBusinessBean.setContractEndDate(
          StringConvertUtil.stringToDate(ECISRKConstants.UP_APPLY_MAX_DATE, ECISConstants.FORMAT_DATE_yyyyMMdd));

      // 2016/07/01 料金シミュレーション不具合対応 #1134 Mod End

      // -- プロパティからの設定値を設定
      // 最低月額料金名称
      rateEngineBusinessBean.setMinMonthlyChargeName(this.minMonthlyChargeName);

      // 基本料金無料有無
      rateEngineBusinessBean.setBasicChargeFree(this.basicChargeFree);

      // 固定部分有りエリアリスト
      rateEngineBusinessBean.setFixChargeAreaList(this.fixChargeAreaList);

      // 付帯名称
      rateEngineBusinessBean.setSupplementaryName(this.supplementaryName);

      // 日割個数
      rateEngineBusinessBean.setProratedQuantity(rateEngineBusinessBean.getCalculatingDateSlotUsage().size());

      // 契約超過金計算倍率
      rateEngineBusinessBean.setContractExcessChargeCalcScaleFactor(this.contractExcessChargeCalcScaleFactor);

      // 契約超過金表示名称1
      rateEngineBusinessBean.setContractExcessChargeDisplayName1(this.contractExcessChargeDisplayName1);

      // 契約超過金表示名称2
      rateEngineBusinessBean.setContractExcessChargeDisplayName2(this.contractExcessChargeDisplayName2);

      // 計算処理の呼び出し
      rateEngineControl.execute(String.valueOf(constractId), usePeriod, rateEngineBusinessBean);

      rateEngineBusinessBean.setExecuteResult(0);

      // オンライン用にデータの詰め替え
      convertToOnlineData(rateEngineBusinessBean);
    } catch (Throwable e) {

      StringBuilder sb = new StringBuilder();
      sb.append(ECISRKConstants.RATE_CALUC_ERROR);
      sb.append(System.lineSeparator());
      sb.append(e);
      sb.append(System.lineSeparator());
      for (StackTraceElement stack : e.getStackTrace()) {
        sb.append(stack.toString());
        sb.append(System.lineSeparator());
      }
      sb.deleteCharAt(sb.length() - 1);

      LOGGER.info(sb.toString());
      rateEngineBusinessBean.setExecuteResult(1);
    }
  }
  // 商品化追加開発：料金シミュレーション ykomoto 2016/04/20 Edit End
}
