package jp.co.unisys.enability.cis.rate_engine.business;

import java.util.List;

import jp.co.unisys.enability.cis.entity.common.CclCalculationDetail;
import jp.co.unisys.enability.cis.entity.common.CclM;
import jp.co.unisys.enability.cis.entity.common.MfRcclM;

/**
 * 契約種別計算明細管理ビジネス
 *
 * @author "Nihon Unisys, Ltd."
 */
public interface ContractClassCalcDetailManagementBusiness {

  /**
   * 契約種別情報、契約種別計算明細情報をロードする。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約種別情報、契約種別計算明細情報をロードする。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   *
   */
  public abstract void loadData();

  /**
   * 契約種別情報を取得する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約種別情報を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param cclCode
   *          契約種別コード
   * @return 契約種別情報
   *
   */
  public abstract CclM getContractClassMaster(String cclCode);

  /**
   * 契約種別計算明細合算前情報を取得する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約種別計算明細合算前情報を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param cclCode
   *          契約種別コード
   * @return 契約種別計算明細合算前情報のリスト
   *
   */
  public abstract List<CclCalculationDetail> getContractClassCalcDetailAddupBfr(
      String cclCode);

  /**
   * 契約種別計算明細合算後情報を取得する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約種別計算明細合算後情報を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param cclCode
   *          契約種別コード
   * @return 契約種別計算明細合算後情報のリスト
   *
   */
  public abstract List<CclCalculationDetail> getContractClassCalcDetailAddupAft(
      String cclCode);

  /**
   * 契約種別情報のレコード数を返却する。
   *
   * @return 契約種別情報のレコード数
   */
  public abstract int getgetContractClassMasterCount();

  /**
   * 掛率制予備契約種別マスタ情報を取得する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約種別コードと一致する掛率制予備契約種別マスタ情報を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param cclCode
   *          契約種別コード
   * @return 掛率制予備契約種別マスタEntityBean
   */
  public abstract MfRcclM getMultiplyFactorReserveContractClassMaster(String cclCode);
}
