package jp.co.unisys.enability.cis.rate_engine.model;

import java.util.List;

import jp.co.unisys.enability.cis.entity.common.CalculatingDsUsage;
import jp.co.unisys.enability.cis.entity.common.CalculatingUsage;

/**
 * 料金計算中警告チェックビジネスBean。
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * メニュー変更チェックビジネス。
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_CalculatingWarningCheckBusinessBean {

  /**
   * 計算用使用量を保有する。
   */
  private CalculatingUsage calculatingUsage;

  /**
   * 計算用日割別使用量リストを保有する。
   */
  private List<CalculatingDsUsage> calculatingDateSlotUsage;

  /**
   * 計算用使用量のgetter。
   * 
   * <pre>
   *
   * 計算用使用量を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 計算用使用量
   */
  public CalculatingUsage getCalculatingUsage() {
    return calculatingUsage;
  }

  /**
   * 計算用使用量のsetter。
   * 
   * <pre>
   *
   * 計算用使用量を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param calculatingUsage
   *          計算用使用量
   */
  public void setCalculatingUsage(CalculatingUsage calculatingUsage) {
    this.calculatingUsage = calculatingUsage;
  }

  /**
   * 計算用日割別使用量リストのgetter。
   * 
   * <pre>
   *
   * 計算用日割別使用量リストを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 計算用日割別使用量リスト
   */
  public List<CalculatingDsUsage> getCalculatingDateSlotUsage() {
    return calculatingDateSlotUsage;
  }

  /**
   * 計算用日割別使用量リストのsetter。
   * 
   * <pre>
   *
   * 計算用日割別使用量リストを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param calculatingDateSlotUsage
   *          計算用日割別使用量リスト
   */
  public void setCalculatingDateSlotUsage(List<CalculatingDsUsage> calculatingDateSlotUsage) {
    this.calculatingDateSlotUsage = calculatingDateSlotUsage;
  }
}
