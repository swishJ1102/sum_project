package jp.co.unisys.enability.cis.rate_engine.component;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Objects;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import jp.co.unisys.enability.cis.common.Exception.RateEngineException;
import jp.co.unisys.enability.cis.common.util.constants.ECISKJConstants;
import jp.co.unisys.enability.cis.common.util.rk.RateEngineCommonUtil;

/**
 * 予備契約金額加算ビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class ReserveContractAmountAddBusiness extends ChargeCalcBaseBusiness
    implements FeeCalcParts {
  /** ロガー */
  private static final Logger LOGGER = LogManager.getLogger();

  /** この部品がサポートする固定パラメータ数 */
  private static final int ARG_LENGTH = 3;

  /**
   * 予備契約基本料金の加算処理を行う。<br>
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   *
   * 引数で指定された情報をもとに"予備線"と"予備電源"毎に基本料金の加算し合計金額の計算を行う。
   * ※引数の「予備契約種別」と「予備契約基本料金」と「予備契約容量」の配列数は同じである。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param args
   *          args[0]:Object (String[0]…[N]) 予備契約種別リスト<br>
   *          args[1]:Object (BigDecimal[0]…[N]) 予備契約基本料金リスト<br>
   *          args[2]:Object (BigDecimal[0]…[N]) 予備契約容量リスト<br>
   * @return 計算結果配列 [予備線合計金額、予備電源合計金額、予備線契約容量、予備電源契約容量]
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   * @see RateEngineCommonUtil#checkArgLength(Object...)
   */
  @Override
  public Object[] calc(Object... args) throws RateEngineException {

    // 引数長チェック
    RateEngineCommonUtil.checkArgsLength(args, ARG_LENGTH);

    // 予備線合計金額の変数を生成
    BigDecimal rlTotalAmount = BigDecimal.ZERO;

    // 予備電源合計金額の変数を生成
    BigDecimal rpsTotalAmount = BigDecimal.ZERO;

    // 予備契約種別配列
    String[] classList = Arrays.stream((Object[]) args[ArrayIndex.ZERO.ordinal()]).toArray(String[]::new);

    // 予備契約基本料金配列
    BigDecimal[] reserveBasicList = Arrays.stream((Object[]) args[ArrayIndex.ONE.ordinal()]).toArray(
        BigDecimal[]::new);

    // 予備契約容量配列
    BigDecimal[] reserveContractCapacityList = Arrays.stream((Object[]) args[ArrayIndex.TWO.ordinal()]).toArray(
        BigDecimal[]::new);

    // 予備線契約容量の変数を生成
    BigDecimal rlContractCapacity = null;

    // 予備電源契約容量の変数を生成
    BigDecimal rpsContractCapacity = null;

    for (int i = 0; i < classList.length; i++) {
      // 予備契約基本料金がNULL以外の場合
      if (!Objects.isNull(reserveBasicList[i])) {
        // 予備線の場合
        if (ECISKJConstants.RESERVE_CONTRACT_CLASS_LINE.equals(classList[i])) {
          rlTotalAmount = rlTotalAmount.add(reserveBasicList[i]);
          rlContractCapacity = reserveContractCapacityList[i];
        }

        // 予備電源の場合
        if (ECISKJConstants.RESERVE_CONTRACT_CLASS_POWER.equals(classList[i])) {
          rpsTotalAmount = rpsTotalAmount.add(reserveBasicList[i]);
          rpsContractCapacity = reserveContractCapacityList[i];
        }
      }
    }

    // デバッグログ出力
    LOGGER.debug("予備線合計金額={} 予備電源合計金額={} 予備線契約容量={} 予備電源契約容量={}",
        rlTotalAmount, rpsTotalAmount, rlContractCapacity, rpsContractCapacity);

    // 結果を返却
    return new Object[] {rlTotalAmount, rpsTotalAmount, rlContractCapacity, rpsContractCapacity };
  }
}
