package jp.co.unisys.enability.cis.rate_engine.business;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

import jp.co.unisys.enability.cis.common.util.constants.ECISCodeConstants;
import jp.co.unisys.enability.cis.entity.common.CclCalculationDetail;
import jp.co.unisys.enability.cis.entity.common.CclCalculationDetailExample;
import jp.co.unisys.enability.cis.entity.common.CclM;
import jp.co.unisys.enability.cis.entity.common.CclMExample;
import jp.co.unisys.enability.cis.entity.common.MfRcclM;
import jp.co.unisys.enability.cis.entity.common.MfRcclMExample;
import jp.co.unisys.enability.cis.mapper.common.CclCalculationDetailMapper;
import jp.co.unisys.enability.cis.mapper.common.CclMMapper;
import jp.co.unisys.enability.cis.mapper.common.MfRcclMMapper;

/**
 * 契約種別計算明細管理ビジネス
 *
 * @author "Nihon Unisys, Ltd."
 */
public class ContractClassCalcDetailManagementBusinessImpl implements ContractClassCalcDetailManagementBusiness {
  /**
   * 契約種別情報のキャッシュ. mapkey: 契約種別コード
   */
  private TreeMap<String, CclM> contractClass = null;

  /**
   * 契約種別計算明細情報（合算前）のキャッシュ. mapkey: 契約種別コード
   */
  private TreeMap<String, List<CclCalculationDetail>> beforeContractClassDetail = null;

  /**
   * 契約種別計算明細情報（合算後）のキャッシュ. mapkey: 契約種別コード
   */
  private TreeMap<String, List<CclCalculationDetail>> afterContractClassDetail = null;

  /**
   * 掛率制予備契約種別マスタ情報のキャッシュ. mapkey: 契約種別コード
   */
  private TreeMap<String, MfRcclM> multiplyFactorReserveContractClass = null;

  /**
   * 契約種別マッパー(DI)
   */
  private CclMMapper cclMMapper;

  /**
   * 契約種別計算明細マッパー(DI)
   */
  private CclCalculationDetailMapper cclCalculationDetailMapper;

  /**
   * 掛率制予備契約種別マスタマッパー(DI)
   */
  private MfRcclMMapper mfRcclMMapper;

  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.rate_engine.business.ContractClassCalcDetailManagementBusiness#loadData()
   */
  @Override
  public void loadData() {
    CclMExample cclMExample = new CclMExample();
    List<CclM> list = new ArrayList<CclM>();
    String key;

    // 初期化
    contractClass = new TreeMap<String, CclM>();

    // 契約種別マスタ取得
    list = cclMMapper.selectByExample(cclMExample);
    for (CclM value : list) {
      key = value.getCclCode();
      contractClass.put(key, value);
    }

    // 契約種別計算明細定義
    CclCalculationDetailExample cclCalculationDetailExample = new CclCalculationDetailExample();
    cclCalculationDetailExample.setOrderByClause("ccl_code ASC, calculate_unit_cat_code ASC, branch_no ASC");
    List<CclCalculationDetail> listDetail = new ArrayList<CclCalculationDetail>();

    // 初期化
    beforeContractClassDetail = new TreeMap<String, List<CclCalculationDetail>>();
    afterContractClassDetail = new TreeMap<String, List<CclCalculationDetail>>();
    listDetail = cclCalculationDetailMapper
        .selectByExample(cclCalculationDetailExample);

    // 契約種別計算明細取得
    for (CclCalculationDetail value : listDetail) {
      key = value.getCclCode();

      TreeMap<String, List<CclCalculationDetail>> map = null;
      List<CclCalculationDetail> tempList = null;

      if (ECISCodeConstants.DCEC_CATEGORY_CODE_EC.equals(value.getCalculateUnitCatCode())) {
        // 契約種別計算明細情報（合算後）
        map = afterContractClassDetail;
      } else {
        // 契約種別計算明細情報（合算前）
        map = beforeContractClassDetail;
      }

      tempList = map.get(key);
      if (tempList == null) {
        tempList = new ArrayList<CclCalculationDetail>();
        map.put(key, tempList);
      }

      tempList.add(value);
    }

    // 掛率制予備契約種別マスタ取得
    // 初期化
    multiplyFactorReserveContractClass = new TreeMap<String, MfRcclM>();
    // マスタ情報取得
    MfRcclMExample mfRcclMExample = new MfRcclMExample();
    List<MfRcclM> listMfRcclM = mfRcclMMapper.selectByExample(mfRcclMExample);
    for (MfRcclM value : listMfRcclM) {
      key = value.getCclCode();
      multiplyFactorReserveContractClass.put(key, value);
    }
  }

  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.rate_engine.business.ContractClassCalcDetailManagementBusiness#getContractClassMaster(java.lang.String)
   */
  @Override
  public CclM getContractClassMaster(String cclCode) {
    CclM ccLm = contractClass.get(cclCode);

    return ccLm;
  }

  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.rate_engine.business.ContractClassCalcDetailManagementBusiness#getContractClassCalcDetailAddupBfr(java.lang.String)
   */
  @Override
  public List<CclCalculationDetail> getContractClassCalcDetailAddupBfr(
      String cclCode) {

    List<CclCalculationDetail> list = beforeContractClassDetail.get(cclCode);

    if (list == null) {
      list = new ArrayList<>();
    }

    return list;
  }

  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.rate_engine.business.ContractClassCalcDetailManagementBusiness#getContractClassCalcDetailAddupAft(java.lang.String)
   */
  @Override
  public List<CclCalculationDetail> getContractClassCalcDetailAddupAft(
      String cclCode) {

    List<CclCalculationDetail> list = afterContractClassDetail.get(cclCode);

    if (list == null) {
      list = new ArrayList<>();
    }

    return list;
  }

  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.rate_engine.business.ContractClassCalcDetailManagementBusiness#getgetContractClassMasterCount()
   */
  @Override
  public int getgetContractClassMasterCount() {
    if (contractClass == null) {
      return 0;
    }
    return contractClass.size();
  }

  /*
   * (非 Javadoc)
   * @see jp.co.unisys.enability.cis.rate_engine.business.ContractClassCalcDetailManagementBusiness#getMultiplyFactorReserveContractClassMaster()
   */
  @Override
  public MfRcclM getMultiplyFactorReserveContractClassMaster(String cclCode) {
    MfRcclM mfRcclM = multiplyFactorReserveContractClass.get(cclCode);
    return mfRcclM;
  }

  /**
   * 契約種別マッパー。(DI)
   *
   * @author "Nihon Unisys, Ltd."
   * @param ccl
   *          契約種別マッパー
   */
  public void setSelectCclMMapper(CclMMapper ccl) {
    this.cclMMapper = ccl;
  }

  /**
   * 契約種別計算明細マッパー。(DI)
   *
   * @author "Nihon Unisys, Ltd."
   * @param cclCalculationDetail
   *          契約種別計算明細マッパー
   */
  public void setSelectCclCalculationDetailMapper(CclCalculationDetailMapper cclCalculationDetail) {
    this.cclCalculationDetailMapper = cclCalculationDetail;
  }

  /**
   * 掛率制予備契約種別マスタマッパー。(DI)
   *
   * @author "Nihon Unisys, Ltd."
   * @param mfRcclMMapper
   *          掛率制予備契約種別マスタマッパー
   */
  public void setMfRcclMMapper(MfRcclMMapper mfRcclMMapper) {
    this.mfRcclMMapper = mfRcclMMapper;
  }
}
