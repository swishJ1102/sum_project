package jp.co.unisys.enability.cis.rate_engine.component;

import java.math.BigDecimal;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import jp.co.unisys.enability.cis.common.Exception.RateEngineException;
import jp.co.unisys.enability.cis.common.util.rk.RateEngineCommonUtil;

/**
 * 託送料金計算（最低料金制電灯標準メニュー）ビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class ConsignmentChargeCalcMinChargeElecLightStandardMenuBusiness extends ChargeCalcBaseBusiness
    implements FeeCalcParts {
  /** ロガー */
  private static final Logger LOGGER = LogManager.getLogger();

  /** この部品がサポートする固定パラメータ数 */
  private static final int ARG_LENGTH = 9;

  /**
   * 最低料金制電灯標準メニューの託送料金の計算を行う。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された情報をもとに託送料金（最低料金制電灯標準）を計算する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param args
   *          args[0]:Object 基本料金単価<br>
   *          args[1]:Object 使用量<br>
   *          args[2]:Object 使用量単価<br>
   *          args[3]:Object 検針日数<br>
   *          args[4]:Object 日割日数<br>
   *          args[5]:Object 丸め桁（内訳）<br>
   *          args[6]:Object 丸め方法（内訳）<br>
   *          args[7]:Object 丸め桁（合計）<br>
   *          args[8]:Object 丸め方法（合計）<br>
   * @return 託送料金[合計額、基本料金、従量料金、最低月額料金適用有無]
   * @throws RateEngineException
   *           パラメータ不正により計算不能の場合にthrowされる
   * @see RateEngineCommonUtil#checkArgsLength(Object...)
   * @see RateEngineCommonUtil#convertToDecimals(Object...)
   * @see RateEngineCommonUtil#convertStringToInt(Object...)
   * @see RateEngineCommonUtil#getRoundMode(Object...)
   */
  @Override
  public Object[] calc(Object... args) throws RateEngineException {
    // パラメータをデバッグログ出力
    LOGGER.debug("基本料金単価={} 使用量={} 使用量単価={} 検針日数={} 日割日数={} ",
        args[ArrayIndex.ZERO.ordinal()], args[ArrayIndex.ONE.ordinal()], args[ArrayIndex.TWO.ordinal()],
        args[ArrayIndex.THREE.ordinal()], args[ArrayIndex.FOUR.ordinal()]);

    // 引数をチェック
    RateEngineCommonUtil.checkArgsLength(args, ARG_LENGTH);

    // 引数を変換
    BigDecimal[] decimals = RateEngineCommonUtil.convertToDecimals(args);

    // 日割り率の設定
    super.setPerDiemRate(decimals[ArrayIndex.FOUR.ordinal()], decimals[ArrayIndex.THREE.ordinal()]);

    // 基本料金を計算する
    BigDecimal dcPrice = super.calcDCPrice(decimals[ArrayIndex.ZERO.ordinal()],
        decimals[ArrayIndex.FIVE.ordinal()],
        decimals[ArrayIndex.SIX.ordinal()]);

    // 従量料金を計算する
    // 使用量×単価
    BigDecimal ecPrice = super.calcCharge(decimals[ArrayIndex.ONE.ordinal()], decimals[ArrayIndex.TWO.ordinal()],
        decimals[ArrayIndex.FIVE.ordinal()], decimals[ArrayIndex.SIX.ordinal()]);

    // 合計の算出
    Object[] result = super.getTotalPrice(dcPrice, ecPrice, decimals[ArrayIndex.SEVEN.ordinal()],
        decimals[ArrayIndex.EIGHT.ordinal()]);

    // デバッグログ出力
    LOGGER.debug("合計額={} 基本料金={} 従量料金={} 最低月額料金適用有無={}", result);

    // 結果を返却
    return result;
  }
}
