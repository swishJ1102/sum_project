package jp.co.unisys.enability.cis.rate_engine.component;

import java.math.BigDecimal;
import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import jp.co.unisys.enability.cis.common.Exception.RateEngineException;
import jp.co.unisys.enability.cis.common.util.rk.RateEngineCommonUtil;

/**
 * 基本料金計算（従量電灯C）ビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class BasicChargeCalcUsageBasedCRateBusiness extends ChargeCalcBaseBusiness implements FeeCalcParts {
  /** ロガー */
  private static final Logger LOGGER = LogManager.getLogger();

  /** この部品がサポートする固定パラメータ数 */
  private static final int ARG_LENGTH = 12;

  /**
   * 従量電灯Cの基本料金の計算を行う。<br>
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された情報をもとに従量電灯Cの基本料金を計算する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param args
   *          args[0]:Object 契約容量<br>
   *          args[1]:Object 基本料金単価<br>
   *          args[2]:Object 使用量<br>
   *          args[3]:Object 検針日数<br>
   *          args[4]:Object 日割日数<br>
   *          args[5]:Object 丸め桁（合計）<br>
   *          args[6]:Object 丸め方法（合計）<br>
   *          args[7]:Object 算定期間開始日<br>
   *          args[8]:Object 算定期間終了日<br>
   *          args[9]:Object 契約開始日<br>
   *          args[10]:Object 契約終了日<br>
   *          args[11]:Object 基本料金無料有無<br>
   * @return 基本料金(従量電灯C)
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   * @see RateEngineCommonUtil#checkArgsLength(Object...)
   * @see RateEngineCommonUtil#convertToDecimals(Object...)
   * @see RateEngineCommonUtil#convertStringToInt(Object...)
   * @see RateEngineCommonUtil#getRoundMode(Object...)
   */
  @Override
  public Object[] calc(Object... args) throws RateEngineException {
    // 引数長チェック
    RateEngineCommonUtil.checkArgsLength(args, ARG_LENGTH);

    // 数値変換
    BigDecimal[] decimals = RateEngineCommonUtil.convertToDecimals(
        args[ArrayIndex.ZERO.ordinal()], args[ArrayIndex.ONE.ordinal()], args[ArrayIndex.TWO.ordinal()],
        args[ArrayIndex.THREE.ordinal()], args[ArrayIndex.FOUR.ordinal()], args[ArrayIndex.FIVE.ordinal()],
        args[ArrayIndex.SIX.ordinal()]);

    // 基本料金計算係数
    super.setBasicPriceCoefficient(decimals[ArrayIndex.TWO.ordinal()]);
    // 日割率
    super.setPerDiemRate(decimals[ArrayIndex.FOUR.ordinal()], decimals[ArrayIndex.THREE.ordinal()]);

    // 料金計算する
    // 契約容量 × 基本料金単価
    BigDecimal basicPrice = super.calcDCPrice(
        decimals[ArrayIndex.ZERO.ordinal()].multiply(decimals[ArrayIndex.ONE.ordinal()]),
        decimals[ArrayIndex.FIVE.ordinal()], decimals[ArrayIndex.SIX.ordinal()]);

    // 初月無料であるか計算する
    basicPrice = super.getBasePrice(basicPrice, (Date) args[ArrayIndex.SEVEN.ordinal()],
        (Date) args[ArrayIndex.EIGHT.ordinal()], (Date) args[ArrayIndex.NINE.ordinal()],
        (Date) args[ArrayIndex.TEN.ordinal()], args[ArrayIndex.ELEVEN.ordinal()].toString());

    // デバッグログ出力
    LOGGER.debug("基本料金計算（従量電灯C）= {}", basicPrice.toString());

    // 結果を返却
    return new BigDecimal[] {basicPrice };
  }

}
