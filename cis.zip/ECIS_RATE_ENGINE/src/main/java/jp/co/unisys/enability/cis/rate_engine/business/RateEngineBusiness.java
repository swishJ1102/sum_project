package jp.co.unisys.enability.cis.rate_engine.business;

import java.util.Date;

import jp.co.unisys.enability.cis.common.Exception.BusinessLogicException;
import jp.co.unisys.enability.cis.rate_engine.model.RateEngineBusinessBean;

/***
 * 料金計算エンジンビジネスのインターフェースを提供する。
 *
 * @author "Nihon Unisys, Ltd."
 *
 */
public interface RateEngineBusiness {

  /**
   * 料金計算をオンラインで計算する。
   *
   * @author "Nihon Unisys, Ltd."
   * @param constractId
   *          契約ID
   * @param usePeriod
   *          利用年月
   * @param rateEngineBusinessBean
   *          料金計算エンジンビジネス
   */
  public abstract void calculateOnline(Integer constractId, String usePeriod,
      RateEngineBusinessBean rateEngineBusinessBean);

  /**
   * 料金計算をバッチで計算する。
   *
   * @author "Nihon Unisys, Ltd."
   * @param constractId
   *          契約ID
   * @param usePeriod
   *          利用年月
   * @exception BusinessLogicException
   *              業務例外が発生した場合
   */
  public abstract void calculateBatch(Integer constractId, String usePeriod) throws BusinessLogicException;

  // 商品化追加開発：料金シミュレーション ykomoto 2016/04/20 Edit Start
  /**
   * 料金シミュレーション用の計算をする。
   *
   * @author "Nihon Unisys, Ltd."
   * @param constractId
   *          契約ID
   * @param usePeriod
   *          利用年月
   * @param upBaseDate
   *          単価基準日
   * @param rateEngineBusinessBean
   *          料金計算エンジンビジネス
   */
  public abstract void rateSimulation(Integer constractId, String usePeriod,
      RateEngineBusinessBean rateEngineBusinessBean, Date upBaseDate);
  // 商品化追加開発：料金シミュレーション ykomoto 2016/04/20 Edit End
}
