package jp.co.unisys.enability.cis.rate_engine.business;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import jp.co.unisys.enability.cis.common.Exception.RateEngineException;
import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;
import jp.co.unisys.enability.cis.common.util.rk.RateEngineReflectionUtil;
import jp.co.unisys.enability.cis.common.util.rk.SetArgs;
import jp.co.unisys.enability.cis.entity.common.CclCalculationDetail;
import jp.co.unisys.enability.cis.rate_engine.component.FeeCalcParts;
import jp.co.unisys.enability.cis.rate_engine.engine.CalcPartsFactory;

/**
 * 料金計算エンジン実行ビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RateEngineExecuteBusiness {

  /** ロガー */
  private static final Logger LOGGER = LogManager.getLogger();

  /** 契約種別計算明細 メモリキャッシュ */
  private ContractClassCalcDetailManagementBusiness contractClassCalcDetailManagementBusiness;

  /**
   * 契約種別計算明細をロードする
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約種別計算明細をロードする
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractClassCalcDetailManagementData
   *          契約種別計算明細管理ビジネス
   */
  public RateEngineExecuteBusiness(ContractClassCalcDetailManagementBusiness contractClassCalcDetailManagementData) {
    this.contractClassCalcDetailManagementBusiness = contractClassCalcDetailManagementData;
  }

  /**
   * 料金メニュー合算前計算処理
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金メニュー合算前計算処理
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param CalcInfoManagementBusiness
   *          計算情報管理ビジネス
   * @throws RateEngineException
   */
  public void executeCalculateRateMenuAddupBfr(
      CalcInfoManagementBusiness calcInfoManagementBusiness) throws RateEngineException {
    // クラス変数.契約種別計算明細管理ビジネス.契約種別計算明細合算前取得を呼び出す。

    List<CclCalculationDetail> cclCalculationDetailList = contractClassCalcDetailManagementBusiness
        .getContractClassCalcDetailAddupBfr(calcInfoManagementBusiness
            .getContractClassCode());

    // 料金メニュー毎計算処理を呼び出す。
    this.executeCalculateRateMenu(calcInfoManagementBusiness,
        cclCalculationDetailList);

  }

  /**
   * 料金メニュー合算後計算処理
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金メニュー合算後計算処理
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param CalcInfoManagementBusiness
   *          計算情報管理ビジネス
   * @throws RateEngineException
   */
  public void executeCalculateRateMenuAddupAfr(
      CalcInfoManagementBusiness calcInfoManagementBusiness) throws RateEngineException {

    // クラス変数.契約種別計算明細管理ビジネス.契約種別計算明細合算後取得を呼び出す。
    List<CclCalculationDetail> cclCalculationDetailList = contractClassCalcDetailManagementBusiness
        .getContractClassCalcDetailAddupAft(calcInfoManagementBusiness
            .getContractClassCode());

    // 料金メニュー毎計算処理を呼び出す。
    this.executeCalculateRateMenu(calcInfoManagementBusiness,
        cclCalculationDetailList);

  }

  /**
   * 料金メニュー毎計算処理
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金メニュー毎計算処理を実行する
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param CalcInfoManagementBusiness
   *          計算情報管理ビジネス
   * @param cclCalculationDetaillist
   *          契約種別計算明細管理Bean
   * @throws RateEngineException
   */
  private void executeCalculateRateMenu(CalcInfoManagementBusiness calcInfoManagementBusiness,
      List<CclCalculationDetail> cclCalculationDetaillist) throws RateEngineException {
    // 料金計算部品インスタンス取得を生成する。
    CalcPartsFactory factory = new CalcPartsFactory();

    // 《契約種別計算明細管理Bean》リストの件数分以下の処理を行う。
    for (CclCalculationDetail detail : cclCalculationDetaillist) {
      String operation = detail.getCalculateMethod();

      if (CalcInfoManagementBusiness.isWriteOperaion(operation)) {
        // 代入
        LOGGER.debug("代入演算の実行 枝番[{}]", detail.getBranchNo());
        SetArgs setArgs = new SetArgs();
        setArgs.setDestData(detail.getGetInformation01());
        setArgs.setDestItem(detail.getGetItemName01());
        setArgs.setOriginData(detail.getGetInformation02());
        setArgs.setOriginItem(detail.getGetItemName02());
        setArgs.setAssignData(detail.getGetInformation03());
        setArgs.setAssignFlg(detail.getGetItemName03());
        setArgs.setSpmData(detail.getGetInformation04());
        setArgs.setSpmItem(detail.getGetItemName04());

        // 引数. 《計算情報管理ビジネス》のプロパティへ設定する。
        calcInfoManagementBusiness.writeProperty(setArgs, detail.getBranchNo().toString());
      } else if (CalcInfoManagementBusiness.isWriteSpmOperaion(operation)) {
        // 付帯代入
        LOGGER.debug("代入演算の実行 枝番[{}]", detail.getBranchNo());
        SetArgs setArgs = new SetArgs();
        setArgs.setDestData(detail.getGetInformation01());
        setArgs.setDestItem(detail.getGetItemName01());
        setArgs.setOriginData(detail.getGetInformation02());
        setArgs.setOriginItem(detail.getGetItemName02());
        setArgs.setAssignData(detail.getGetInformation03());
        setArgs.setAssignFlg(detail.getGetItemName03());

        // 付帯価格
        setArgs.setSpmData(detail.getGetInformation04());
        setArgs.setSpmItem(detail.getGetItemName04());

        // 引数. 《計算情報管理ビジネス》のプロパティへ設定する。
        calcInfoManagementBusiness.writeSpmProperty(setArgs);

        // 2016/04/08 付帯の日割 start
      } else if (CalcInfoManagementBusiness.isWriteSpmProratedOperaion(operation)) {
        // 付帯日割代入
        LOGGER.debug("代入演算の実行 枝番[{}]", detail.getBranchNo());
        SetArgs setArgs = new SetArgs();
        setArgs.setDestData(detail.getGetInformation01());
        setArgs.setDestItem(detail.getGetItemName01());
        setArgs.setOriginData(detail.getGetInformation02());
        setArgs.setOriginItem(detail.getGetItemName02());
        setArgs.setAssignData(detail.getGetInformation03());
        setArgs.setAssignFlg(detail.getGetItemName03());

        // 付帯価格
        setArgs.setSpmData(detail.getGetInformation04());
        setArgs.setSpmItem(detail.getGetItemName04());

        setArgs.setSpmDataCcDays(detail.getGetInformation05());
        setArgs.setSpmItemCcDays(detail.getGetItemName05());

        setArgs.setSpmDataProratedDays(detail.getGetInformation06());
        setArgs.setSpmItemProratedDays(detail.getGetItemName06());

        // 引数. 《計算情報管理ビジネス》のプロパティへ設定する。
        calcInfoManagementBusiness.writeSpmProratedProperty(setArgs);
        // 2016/04/08 付帯の日割 end

      } else if (CalcInfoManagementBusiness.isWriteDeleteStageOperaion(operation)) {
        // 不要な段を削除する
        LOGGER.debug("代入演算の実行 枝番[{}]", detail.getBranchNo());
        // DeleteStage	ClcBreakdown	A/2/1/1	CONST	2	CONST	0
        SetArgs setArgs = new SetArgs();
        setArgs.setDestData(detail.getGetInformation01());
        setArgs.setDestItem(detail.getGetItemName01());
        setArgs.setOriginData(detail.getGetInformation02());
        setArgs.setOriginItem(detail.getGetItemName02());
        setArgs.setAssignData(detail.getGetInformation03());
        setArgs.setAssignFlg(detail.getGetItemName03());

        // 引数. 《計算情報管理ビジネス》のプロパティへ設定する。
        calcInfoManagementBusiness.writeDeleteStageProperty(setArgs);
      } else if (CalcInfoManagementBusiness.isWriteDeleteLowestPriceOperaion(operation)) {
        // 不要な最低月額料金を削除する
        LOGGER.debug("代入演算の実行 枝番[{}]", detail.getBranchNo());
        // DeleteLowestPrice	ClcBreakdown	A/2/1/1	CONST	4	RESULT	25-1
        SetArgs setArgs = new SetArgs();
        setArgs.setDestData(detail.getGetInformation01());
        setArgs.setDestItem(detail.getGetItemName01());
        setArgs.setOriginData(detail.getGetInformation02());
        setArgs.setOriginItem(detail.getGetItemName02());
        setArgs.setAssignData(detail.getGetInformation03());
        setArgs.setAssignFlg(detail.getGetItemName03());

        // 引数. 《計算情報管理ビジネス》のプロパティへ設定する。
        calcInfoManagementBusiness.writeDeleteLowestPriceProperty(setArgs);
        // 2016/03/24 契約電力あたりの割引 start
      } else if (CalcInfoManagementBusiness.isWriteDeleteSplContractOperaion(operation)) {
        // 不要な付帯契約を削除する
        LOGGER.debug("代入演算の実行 枝番[{}] 演算方式[{}]", detail.getBranchNo(), operation);
        // 定義方法
        // DELETESPLCONTRACT	SplContract	0	CONST	3	CONST	1
        // DELETESPLCONTRACT	SplContract	0	CONST	0300001	CONST	2
        SetArgs setArgs = new SetArgs();
        setArgs.setDestData(detail.getGetInformation01());
        setArgs.setDestItem(detail.getGetItemName01());
        setArgs.setOriginData(detail.getGetInformation02());
        setArgs.setOriginItem(detail.getGetItemName02());
        setArgs.setAssignData(detail.getGetInformation03());
        setArgs.setAssignFlg(detail.getGetItemName03());

        // 引数. 《計算情報管理ビジネス》のプロパティへ設定する。
        calcInfoManagementBusiness.writeDeleteSplContractProperty(setArgs);
        // 2016/03/24 契約電力あたりの割引 end
      } else if (CalcInfoManagementBusiness.isWriteDeleteNoNeedStageOperaion(operation)) {
        // 不要な金額段を削除する
        LOGGER.debug("代入演算の実行 枝番[{}] 演算方式[{}]", detail.getBranchNo(), operation);
        SetArgs setArgs = new SetArgs();
        setArgs.setDestData(detail.getGetInformation01());
        setArgs.setDestItem(detail.getGetItemName01());
        setArgs.setOriginData(detail.getGetInformation02());
        setArgs.setOriginItem(detail.getGetItemName02());
        setArgs.setAssignData(detail.getGetInformation03());
        setArgs.setAssignFlg(detail.getGetItemName03());

        // 引数. 《計算情報管理ビジネス》のプロパティへ設定する。
        calcInfoManagementBusiness.writeDeleteNoNeedStageProperty(setArgs);
      } else if (CalcInfoManagementBusiness.isWritePluralOperaion(operation)) {
        // 複数代入
        LOGGER.debug("複数代入演算の実行 枝番[{}]", detail.getBranchNo());
        SetArgs setArgs = new SetArgs();
        setArgs.setDestData(detail.getGetInformation01());
        setArgs.setDestItem(detail.getGetItemName01());
        setArgs.setOriginData(detail.getGetInformation02());
        setArgs.setOriginItem(detail.getGetItemName02());
        setArgs.setAssignData(detail.getGetInformation03());
        setArgs.setAssignFlg(detail.getGetItemName03());
        setArgs.setSpmData(detail.getGetInformation04());
        setArgs.setSpmItem(detail.getGetItemName04());
        setArgs.setSpmDataCcDays(detail.getGetInformation05());
        setArgs.setSpmItemCcDays(detail.getGetItemName05());

        // 複数代入処理
        calcInfoManagementBusiness.writePluralProperty(setArgs);
      } else {
        // 部品処理
        LOGGER.debug("計算部品の実行 枝番[{}] 演算方式[{}]", detail.getBranchNo(), operation);
        FeeCalcParts parts = factory.getParts(operation);
        Object[] args = this.createArgument(detail,
            calcInfoManagementBusiness);
        Object[] result = null;
        try {
          result = parts.calc(args);

          // 計算結果の保管
          calcInfoManagementBusiness.addCalcResults(
              detail.getBranchNo(), result);
        } catch (Exception e) {
          // 計算部品にて計算が失敗しました。枝番:{0}、演算方式:{1}、部品パラメータ:{2}
          throw new RateEngineException("error.E1345", detail.getBranchNo().toString(),
              operation, Arrays.toString(args));
        }
      }
    }
  }

  /**
   * パラメータ生成処理
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * パラメータ生成処理
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param cclCalculationDetaillist
   *          契約種別計算明細管理
   * @param CalcInfoManagementBusiness
   *          計算情報管理ビジネス
   * @return 計算部品のパラメータ
   * @throws RateEngineException
   */
  private Object[] createArgument(
      CclCalculationDetail cclCalculationDetaillist,
      CalcInfoManagementBusiness calcInfoManagementBusiness)
      throws RateEngineException {
    List<Object> argList = new ArrayList<>();

    for (int i = 1; i <= ECISRKConstants.CALC_DETAIL_ITEM_NUM; i++) {
      String seq = String.format("%02d", i);
      String dataName = (String) RateEngineReflectionUtil.getProperty(
          cclCalculationDetaillist,
          ECISRKConstants.CALC_DETAIL_PREFIX_DATA + seq);

      if (StringUtils.isNotBlank(dataName)) {
        String itemName = (String) RateEngineReflectionUtil
            .getProperty(cclCalculationDetaillist,
                ECISRKConstants.CALC_DETAIL_PREFIX_ITEM + seq);

        Object obj = calcInfoManagementBusiness.readProperty(dataName,
            itemName);
        argList.add(obj);
      }
    }

    return argList.toArray(new Object[argList.size()]);
  }
}
