package jp.co.unisys.enability.cis.rate_engine.business;

import java.util.Date;
import java.util.Map;

import jp.co.unisys.enability.cis.common.Exception.RateEngineException;
import jp.co.unisys.enability.cis.entity.common.Cr;
import jp.co.unisys.enability.cis.entity.common.CrUp;
import jp.co.unisys.enability.cis.entity.common.CrUpDetail;
import jp.co.unisys.enability.cis.entity.common.CtRateM;
import jp.co.unisys.enability.cis.entity.common.FcaUpM;
import jp.co.unisys.enability.cis.entity.common.FcaUpTrM;
import jp.co.unisys.enability.cis.entity.common.RcUpM;
import jp.co.unisys.enability.cis.entity.common.RecUpM;
import jp.co.unisys.enability.cis.entity.common.RecUpTrM;
import jp.co.unisys.enability.cis.entity.common.RmUp;
import jp.co.unisys.enability.cis.entity.common.RmUpDetail;
import jp.co.unisys.enability.cis.entity.common.Spm;
import jp.co.unisys.enability.cis.entity.common.SpmUp;
import jp.co.unisys.enability.cis.rate_engine.model.RateEngineBusinessBean;

/**
 * 料金単価管理ビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public interface ChargeUpManagementBusiness {

  /**
   * 料金マスタの取得を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 以下の料金マスタ情報を取得する。<br>
   * ・料金メニュー単価<br>
   * ・料金メニュー単価明細<br>
   * ・燃調単価<br>
   * ・再エネ単価<br>
   * ・託送メニュー<br>
   * ・託送メニュー単価<br>
   * ・託送メニュー単価明細<br>
   * ・付帯メニュー単価<br>
   * ・付帯メニュー単価明細<br>
   * ・予備契約単価<br>
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   */
  public abstract void loadData() throws RateEngineException;

  /**
   * 料金メニュー単価の取得を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 指定されたキー情報をもとに料金メニュー単価を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param menuId
   *          料金メニューID
   * @param upCatCode
   *          単価設定区分
   * @param applyStartDate
   *          適用開始日
   * @return 料金メニュー単価
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   */
  public abstract RmUp getRateMenuUnitPrice(String menuId, String upCatCode, Date applyStartDate) throws RateEngineException;

  /**
   * 料金メニュー単価明細の取得を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 指定されたキー情報をもとに料金メニュー単価明細を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param menuId
   *          料金メニューID
   * @param upCatCode
   *          単価設定区分
   * @param applyStartDate
   *          適用開始日
   * @param dcecKbn
   *          DCEC区分
   * @param timelineCd
   *          時間帯コード
   * @param branchNumber
   *          枝番
   * @return 料金メニュー単価明細
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   */
  public abstract RmUpDetail getRateMenuUnitPriceDetail(String menuId, String upCatCode,
      Date applyStartDate, String dcecKbn, String timelineCd, int branchNumber) throws RateEngineException;

  /**
   * 燃調単価の取得を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 指定されたキー情報をもとに燃調単価を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param areaCd
   *          エリアコード
   * @param voltageCatCode
   *          電圧区分
   * @param applyStartDate
   *          適用開始日
   * @return 燃調単価
   * @throws RateEngineException
   *           燃調単価が取得できなかった場合
   */
  public abstract FcaUpM getFuelCostAdjustUnitPrice(String areaCd, String voltageCatCode, Date applyStartDate) throws RateEngineException;

  /**
   * 燃調単価の取得を行う。（取得条件：利用年月）
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 指定されたキー情報をもとに燃調単価を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param areaCd
   *          エリアコード
   * @param voltageCatCode
   *          電圧区分
   * @param usePeriod
   *          利用年月
   * @return 燃調単価
   * @throws RateEngineException
   *           燃調単価が取得できなかった場合
   */
  public abstract FcaUpM getFuelCostAdjustUnitPriceUsePeriod(String areaCd, String voltageCatCode, String usePeriod)
      throws RateEngineException;

  /**
   * 再エネ単価の取得を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 指定されたキー情報をもとに再エネ単価を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param areaCd
   *          エリアコード
   * @param usePeriod
   *          利用年月
   * @return 再エネ単価
   * @throws RateEngineException
   *           再エネ単価が取得できなかった場合
   */
  public abstract RecUpM getRenewableEnergyChargeUnitPrice(String areaCd, String usePeriod)
      throws RateEngineException;

  /**
   * 託送メニューの取得を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 指定されたキー情報をもとに託送メニューを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param menuId
   *          託送メニューID
   * @return 託送メニュー
   */
  public abstract Cr getConsignmentRateMenu(String menuId);

  /**
   * 託送メニュー単価の取得を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 指定されたキー情報をもとに託送メニュー単価を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param menuId
   *          託送メニューID
   * @param applyStartDate
   *          適用開始日
   * @return 託送メニュー単価
   */
  public abstract CrUp getConsignmentRateMenuUnitPrice(String menuId,
      Date applyStartDate);

  /**
   * 託送メニュー単価明細の取得を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 指定されたキー情報をもとに託送メニュー単価明細を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param menuId
   *          託送メニューID
   * @param applyStartDate
   *          適用開始日
   * @param dcecKbn
   *          DCEC区分
   * @param timelineCd
   *          時間帯コード
   * @param branchNumber
   *          枝番
   * @return 託送メニュー単価明細
   */
  public abstract CrUpDetail getConsignmentRateMenuUnitPriceDetail(String menuId,
      Date applyStartDate, String dcecKbn, String timelineCd,
      int branchNumber);

  /**
   * 付帯メニュー単価の取得を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 指定されたキー情報をもとに付帯メニュー単価を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param spmId
   *          付帯メニューID
   * @return 付帯メニュー単価
   */
  public abstract Spm getSpm(String spmId);

  /**
   * 付帯メニュー単価明細の取得を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 指定されたキー情報をもとに付帯メニュー単価明細を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param spmId
   *          付帯メニューID
   * @param applyStartDate
   *          適用開始日
   * @return 付帯メニュー単価明細
   *
   */
  public abstract SpmUp getSpmUp(String spmId,
      Date applyStartDate);

  /**
   * 予備契約単価取得の取得を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 指定されたキー情報をもとに予備契約単価を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param areaCode
   *          エリアコード
   * @param menuId
   *          料金メニューID
   * @param reserveContractSd
   *          予備契約開始日
   * @return 予備契約単価
   * @throws RateEngineException
   *           予備契約単価が取得できなかった場合
   *
   */
  public abstract RcUpM getRcUpM(String areaCode, String menuId, Date reserveContractSd) throws RateEngineException;

  /**
   * 消費税率マスタ取得の取得を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 指定されたキー情報をもとに消費税率マスタを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param baseDt
   *          基準日
   * @return 消費税率マスタ
   * @throws RateEngineException
   *           消費税率マスタが取得できなかった場合
   *
   */
  public abstract CtRateM getCtRateM(Date baseDt) throws RateEngineException;

  /**
   * ロード済みの料金メニュー単価数を返却する。
   *
   * @return 単価数
   */
  public abstract int getRateMenuUnitPriceCount();

  // 2016/07/01 料金シミュレーション不具合対応 Add Start
  /**
   * 料金マスタの取得を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 以下の料金マスタ情報を取得する。<br>
   * ・料金メニュー単価<br>
   * ・料金メニュー単価明細<br>
   * ・燃調単価<br>
   * ・再エネ単価<br>
   * ・託送メニュー<br>
   * ・託送メニュー単価<br>
   * ・託送メニュー単価明細<br>
   * ・付帯メニュー単価<br>
   * ・付帯メニュー単価明細<br>
   * ・予備契約単価<br>
   * 基準日時点での単価が存在しない場合は単価の適用期間を引き延ばし保持する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param upBaseDate
   *          料金単価基準日
   * @param rateEngineBusinessBean
   *          料金計算エンジンビジネスBean
   * @param usePeriod
   *          利用年月
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   */
  public abstract void loadData(Date upBaseDate, RateEngineBusinessBean rateEngineBusinessBean, String usePeriod) throws RateEngineException;

  // 2016/07/01 料金シミュレーション不具合対応 Add End
  /**
   * 料金メニュー単価明細(時間帯コード指定なし)
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 指定されたキー情報をもとに料金メニュー単価明細を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param menuId
   *          料金メニューID
   * @param upCatCode
   *          単価設定区分
   * @param applyStartDate
   *          適用開始日
   * @return 料金メニュー単価明細Map
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   */
  public abstract Map<String, RmUpDetail> getRateMenuUnitPriceDetailNoTimeSlotCode(
      String rateMenuId, String upCatCode, Date calcSd) throws RateEngineException;

  /**
   * 再エネ単価消費税改定マスタの取得を行う
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 指定されたキー情報をもとに再エネ単価消費税改定マスタ情報を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param areaCd
   *          エリアコード
   * @param usePeriod
   *          利用年月
   * @return 再エネ単価消費税改定マスタ
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   */
  public abstract RecUpTrM getRecUpTrMForResetting(String areaCd, String usePeriod) throws RateEngineException;

  /**
   * 燃調単価消費税改定マスタの取得を行う
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 指定されたキー情報をもとに燃調単価消費税改定マスタ情報を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param areaCd
   *          エリアコード
   * @param voltageCatCode
   *          電圧区分コード
   * @param usePeriod
   *          利用年月
   * @return 燃調単価消費税改定マスタ
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   */
  public FcaUpTrM getFcaUpTrMForResetting(String areaCd, String voltageCatCode, String usePeriod)
      throws RateEngineException;
}
