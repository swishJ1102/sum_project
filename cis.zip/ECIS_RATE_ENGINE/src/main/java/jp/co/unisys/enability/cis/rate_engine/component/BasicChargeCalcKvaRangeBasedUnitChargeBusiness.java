package jp.co.unisys.enability.cis.rate_engine.component;

import java.math.BigDecimal;
import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import jp.co.unisys.enability.cis.common.Exception.RateEngineException;
import jp.co.unisys.enability.cis.common.util.rk.RateEngineCommonUtil;

/**
 * 基本料金計算kVA範囲ごとの固定単価ビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class BasicChargeCalcKvaRangeBasedUnitChargeBusiness extends ChargeCalcBaseBusiness implements FeeCalcParts {
  /** ロガー */
  private static final Logger LOGGER = LogManager.getLogger();

  /** この部品がサポートする固定パラメータ数 */
  private static final int ARG_LENGTH = 16;

  /**
   * kVA範囲ごとの基本料金の計算を行う。<br>
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された情報をもとにkVA範囲ごとの基本料金の計算を行う。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param args
   *          args[0]:Object 契約容量<br>
   *          args[1]:Object 基本料金単価<br>
   *          args[2]:Object 契約容量固定部分1<br>
   *          args[3]:Object 基本料金単価固定部分1<br>
   *          args[4]:Object 契約容量固定部分2<br>
   *          args[5]:Object 基本料金単価固定部分2<br>
   *          args[6]:Object 使用量<br>
   *          args[7]:Object 検針日数<br>
   *          args[8]:Object 日割日数<br>
   *          args[9]:Object 丸め桁<br>
   *          args[10]:Object 丸め方法<br>
   *          args[11]:Object 算定期間開始日<br>
   *          args[12]:Object 算定期間終了日<br>
   *          args[13]:Object 契約開始日<br>
   *          args[14]:Object 契約終了日<br>
   *          args[15]:Object 基本料金無料有無<br>
   * @return 基本料金
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   * @see RateEngineCommonUtil#checkArgsLength(Object...)
   * @see RateEngineCommonUtil#convertToDecimals(Object...)
   */
  @Override
  public Object[] calc(Object... args) throws RateEngineException {
    // 引数長チェック
    RateEngineCommonUtil.checkArgsLength(args, ARG_LENGTH);

    // デバッグログ出力
    LOGGER.debug("契約容量={} 基本料金単価={} 契約容量固定部分1={} 基本料金単価固定部分1={} 契約容量固定部分2={} "
        + "基本料金単価固定部分2={} 使用量={} 検針日数={} 日割日数={} 丸め桁={} 丸め方法={} 算定期間開始日={} "
        + "算定期間終了日={} 契約開始日={} 契約終了日={} 基本料金無料有無={} ",
        args[ArrayIndex.ZERO.ordinal()], args[ArrayIndex.ONE.ordinal()], args[ArrayIndex.TWO.ordinal()],
        args[ArrayIndex.THREE.ordinal()], args[ArrayIndex.FOUR.ordinal()], args[ArrayIndex.FIVE.ordinal()],
        args[ArrayIndex.SIX.ordinal()], args[ArrayIndex.SEVEN.ordinal()], args[ArrayIndex.EIGHT.ordinal()],
        args[ArrayIndex.NINE.ordinal()], args[ArrayIndex.TEN.ordinal()], args[ArrayIndex.ELEVEN.ordinal()],
        args[ArrayIndex.TWELEV.ordinal()], args[ArrayIndex.THIRTEEN.ordinal()], args[ArrayIndex.FOURTEEN.ordinal()],
        args[ArrayIndex.FIFTEEN.ordinal()]);

    // 数値変換
    BigDecimal[] decimals = RateEngineCommonUtil.convertToDecimals(args[ArrayIndex.ZERO.ordinal()],
        args[ArrayIndex.ONE.ordinal()], args[ArrayIndex.TWO.ordinal()],
        args[ArrayIndex.THREE.ordinal()], args[ArrayIndex.FOUR.ordinal()], args[ArrayIndex.FIVE.ordinal()],
        args[ArrayIndex.SIX.ordinal()], args[ArrayIndex.SEVEN.ordinal()], args[ArrayIndex.EIGHT.ordinal()],
        args[ArrayIndex.NINE.ordinal()], args[ArrayIndex.TEN.ordinal()]);

    // 基本料金計算係数の設定
    super.setBasicPriceCoefficient(decimals[ArrayIndex.SIX.ordinal()]);
    // 日割率の設定
    super.setPerDiemRate(decimals[ArrayIndex.EIGHT.ordinal()], decimals[ArrayIndex.SEVEN.ordinal()]);

    // 契約容量をチェックする
    if (decimals[ArrayIndex.ZERO.ordinal()].compareTo(BigDecimal.ZERO) < 0) {
      LOGGER.error("BasicChargeCalcKvaRangeBasedUnitChargeBusiness＞契約容量が0未満のため、料金の計算が行えません。契約容量:{}",
          decimals[ArrayIndex.ZERO.ordinal()].toString());
      // 契約容量が0未満のため、料金の計算が行えません。契約容量:{0}
      throw new RateEngineException("error.E9007",
          new String[] {decimals[ArrayIndex.ZERO.ordinal()].toString() });
    }

    // 契約容量固定部分をチェックする
    if (decimals[ArrayIndex.TWO.ordinal()].compareTo(BigDecimal.ZERO) < 0) {
      LOGGER.error("BasicChargeCalcKvaRangeBasedUnitChargeBusiness＞契約容量固定部分{}が0未満のため、料金の計算が行えません。契約容量固定部分:{}",
          "1", decimals[ArrayIndex.TWO.ordinal()].toString());
      // 契約容量固定部分{0}が0未満のため、料金の計算が行えません。契約容量固定部分:{1}
      throw new RateEngineException("error.E9008",
          new String[] {"1", decimals[ArrayIndex.TWO.ordinal()].toString() });
    }

    if (decimals[ArrayIndex.FOUR.ordinal()].compareTo(BigDecimal.ZERO) < 0) {
      LOGGER.error("BasicChargeCalcKvaRangeBasedUnitChargeBusiness＞契約容量固定部分{}が0未満のため、料金の計算が行えません。契約容量固定部分:{}",
          "2", decimals[ArrayIndex.FOUR.ordinal()].toString());
      // 契約容量固定部分{0}が0未満のため、料金の計算が行えません。契約容量固定部分:{1}
      throw new RateEngineException("error.E9008",
          new String[] {"2", decimals[ArrayIndex.FOUR.ordinal()].toString() });
    }

    if (decimals[ArrayIndex.TWO.ordinal()].compareTo(decimals[ArrayIndex.FOUR.ordinal()]) >= 0) {
      LOGGER.error("BasicChargeCalcKvaRangeBasedUnitChargeBusiness＞契約容量固定部分2段目より1段目の方が大きいため、料金の計算が行えません。契約容量固定部分1:{}、契約容量固定部分2:{}",
          decimals[ArrayIndex.TWO.ordinal()].toString(), decimals[ArrayIndex.FOUR.ordinal()].toString());
      // 契約容量固定部分2段目より1段目の方が大きいため、料金の計算が行えません。契約容量固定部分1:{0}、契約容量固定部分2:{1}
      throw new RateEngineException("error.E9009",
          new String[] {decimals[ArrayIndex.TWO.ordinal()].toString(), decimals[ArrayIndex.FOUR.ordinal()].toString() });
    }

    // 基本料金
    BigDecimal basicPrice = decimals[ArrayIndex.THREE.ordinal()];
    // 基本料金を設定
    if (decimals[ArrayIndex.ZERO.ordinal()].compareTo(decimals[ArrayIndex.TWO.ordinal()]) <= 0) {
      // 基本料金単価固定部分1
      basicPrice = decimals[ArrayIndex.THREE.ordinal()];
    } else if (decimals[ArrayIndex.TWO.ordinal()].compareTo(decimals[ArrayIndex.ZERO.ordinal()]) < 0
        && decimals[ArrayIndex.ZERO.ordinal()].compareTo(decimals[ArrayIndex.FOUR.ordinal()]) <= 0) {
      // 基本料金単価固定部分2
      basicPrice = decimals[ArrayIndex.FIVE.ordinal()];
    } else if (decimals[ArrayIndex.FOUR.ordinal()].compareTo(decimals[ArrayIndex.ZERO.ordinal()]) < 0) {
      // 基本料金単価固定部分2 + (契約容量 － 契約容量固定部分2) ＊ 基本料金単価
      basicPrice = decimals[ArrayIndex.FIVE.ordinal()].add(
          (decimals[ArrayIndex.ZERO.ordinal()].subtract(decimals[ArrayIndex.FOUR.ordinal()]))
              .multiply(decimals[ArrayIndex.ONE.ordinal()]));
    }

    // 基本料金を計算
    basicPrice = super.calcDCPrice(basicPrice,
        decimals[ArrayIndex.NINE.ordinal()],
        decimals[ArrayIndex.TEN.ordinal()]);

    // 初月判定後の料金を計算
    basicPrice = super.getBasePrice(basicPrice,
        (Date) args[ArrayIndex.ELEVEN.ordinal()],
        (Date) args[ArrayIndex.TWELEV.ordinal()],
        (Date) args[ArrayIndex.THIRTEEN.ordinal()],
        (Date) args[ArrayIndex.FOURTEEN.ordinal()],
        args[ArrayIndex.FIFTEEN.ordinal()].toString());

    // デバッグログ出力
    LOGGER.debug("kVA範囲ごとの基本料金計算= {}", basicPrice.toString());

    // 結果を返却
    return new Object[] {basicPrice };
  }
}
