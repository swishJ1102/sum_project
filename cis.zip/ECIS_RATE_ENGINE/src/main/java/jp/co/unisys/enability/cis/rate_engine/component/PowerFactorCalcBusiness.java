package jp.co.unisys.enability.cis.rate_engine.component;

import java.math.BigDecimal;
import java.util.Objects;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import jp.co.unisys.enability.cis.common.Exception.RateEngineException;
import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;
import jp.co.unisys.enability.cis.common.util.rk.RateEngineCommonUtil;

/**
 * 力率計算ビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class PowerFactorCalcBusiness implements FeeCalcParts {
  /** ロガー */
  private static final Logger LOGGER = LogManager.getLogger();

  /**
   * 力率の計算を行う。<br>
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * NULLまたは0の場合は85、85より小さい場合は80、85より大きい場合は90を返却する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param args
   *          args[0]:Object 力率<br>
   *          args[1]:Object 使用量<br>
   * @return 計算後力率
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   * @see RateEngineCommonUtil#convertToDecimals(Object...)
   */
  @Override
  public Object[] calc(Object... args) throws RateEngineException {
    // オブジェクト生成
    Object[] ret = new Object[1];

    // 初期化
    ret[ArrayIndex.ZERO.ordinal()] = BigDecimal.valueOf(ECISRKConstants.POWER_FACTOR_EIGHTY_FIVE);

    // 引数でNULLが設定された場合
    if (args[ArrayIndex.ZERO.ordinal()] == null) {
      // 85を返却
      ret[ArrayIndex.ZERO.ordinal()] = BigDecimal.valueOf(ECISRKConstants.POWER_FACTOR_EIGHTY_FIVE);
      return ret;
    }

    // 引数を変換
    BigDecimal[] decimals = RateEngineCommonUtil.convertToDecimals(args);
    BigDecimal calced = decimals[ArrayIndex.ZERO.ordinal()];
    // 使用量がNULLまたは0の場合
    if (decimals[ArrayIndex.ONE.ordinal()] == null || Objects.equals(decimals[ArrayIndex.ONE.ordinal()], BigDecimal.valueOf(0))) {
      // 85を設定
      ret[ArrayIndex.ZERO.ordinal()] = BigDecimal.valueOf(ECISRKConstants.POWER_FACTOR_EIGHTY_FIVE);
    } else {
      // 上記以外の場合
      // 85より小さい場合
      if (calced.compareTo(BigDecimal.valueOf(ECISRKConstants.POWER_FACTOR_EIGHTY_FIVE)) < 0) {
        // 80を設定
        ret[ArrayIndex.ZERO.ordinal()] = BigDecimal.valueOf(ECISRKConstants.POWER_FACTOR_EIGHTY);
      }

      // 85より大きい場合
      if (calced.compareTo(BigDecimal.valueOf(ECISRKConstants.POWER_FACTOR_EIGHTY_FIVE)) > 0) {
        // 90を設定
        ret[ArrayIndex.ZERO.ordinal()] = BigDecimal.valueOf(ECISRKConstants.POWER_FACTOR_NINETY);
      }
    }

    // デバッグログ出力
    LOGGER.debug("力率は、" + ret[ArrayIndex.ZERO.ordinal()]);

    // 結果を返却
    return ret;
  }

}