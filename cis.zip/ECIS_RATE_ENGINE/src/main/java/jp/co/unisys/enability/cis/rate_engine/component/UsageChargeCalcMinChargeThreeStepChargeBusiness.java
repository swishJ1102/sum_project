package jp.co.unisys.enability.cis.rate_engine.component;

import java.math.BigDecimal;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import jp.co.unisys.enability.cis.common.Exception.RateEngineException;
import jp.co.unisys.enability.cis.common.util.rk.RateEngineCommonUtil;

/**
 * 従量料金計算（最低料金制）ビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class UsageChargeCalcMinChargeThreeStepChargeBusiness extends ChargeCalcBaseBusiness implements
    FeeCalcParts {
  /** ロガー */
  private static final Logger LOGGER = LogManager.getLogger();

  /** この部品がサポートする固定パラメータ数 */
  private static final int ARG_LENGTH = 11;

  /**
   * 従量料金（最低料金制）の計算を行う。<br>
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された情報をもとに従量料金（最低料金制）を計算する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param args
   *          args[0]:Object 段料金使用量<br>
   *          args[1]:Object 最低料金適用使用量<br>
   *          args[2]:Object 段料金使用単価<br>
   *          args[3]:Object 最低料金<br>
   *          args[4]:Object 燃料費調整額<br>
   *          args[5]:Object 検針日数<br>
   *          args[6]:Object 日割日数<br>
   *          args[7]:Object 丸め桁（使用量）<br>
   *          args[8]:Object 丸め方法（使用量）<br>
   *          args[9]:Object 丸め桁（料金）<br>
   *          args[10]:Object 丸め方法（料金）<br>
   * @return 従量料金（最低料金制）[従量料金合計額、最低料金部分、1...N段毎の従量料金]
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   * @see RateEngineCommonUtil#checkArgsLength(Object...)
   * @see RateEngineCommonUtil#convertToDecimals(Object...)
   * @see RateEngineCommonUtil#convertToDecimal(Object...)
   */
  @Override
  public Object[] calc(Object... args) throws RateEngineException {
    // 引数長チェック
    RateEngineCommonUtil.checkArgsLength(args, ARG_LENGTH);

    // 段料金使用量、最低料金適用使用量、段料金使用単価、最低料金、燃料費調整額を数値型に変換
    BigDecimal[] usageAmount = RateEngineCommonUtil.convertToDecimals((Object[]) args[ArrayIndex.ZERO.ordinal()]);
    BigDecimal[] usageUnitPrice = RateEngineCommonUtil.convertToDecimals((Object[]) args[ArrayIndex.TWO.ordinal()]);
    BigDecimal lowestPriceUsageAmount = RateEngineCommonUtil.convertToDecimal(args[ArrayIndex.ONE.ordinal()]);
    BigDecimal lowestPrice = RateEngineCommonUtil
        .convertToDecimal(args[ArrayIndex.THREE.ordinal()]);
    BigDecimal fuelAdjustPrice = RateEngineCommonUtil
        .convertToDecimal(args[ArrayIndex.FOUR.ordinal()]);
    BigDecimal dayOfMeterRead = RateEngineCommonUtil.convertToDecimal(args[ArrayIndex.FIVE.ordinal()]);
    BigDecimal dayOfPerDiem = RateEngineCommonUtil.convertToDecimal(args[ArrayIndex.SIX.ordinal()]);
    BigDecimal usageScale = RateEngineCommonUtil.convertToDecimal(args[ArrayIndex.SEVEN.ordinal()]);
    BigDecimal usageMode = RateEngineCommonUtil.convertToDecimal(args[ArrayIndex.EIGHT.ordinal()]);
    BigDecimal chargeScale = RateEngineCommonUtil.convertToDecimal(args[ArrayIndex.NINE.ordinal()]);
    BigDecimal chargeMode = RateEngineCommonUtil.convertToDecimal(args[ArrayIndex.TEN.ordinal()]);

    // 料金を計算する
    int iUsageAmountCount = usageAmount.length;

    // 配列を宣言
    BigDecimal[] decimals = new BigDecimal[iUsageAmountCount];

    // 表示用使用量（1段用、再エネ・燃調用）
    BigDecimal displayUsageFirstStep = BigDecimal.ZERO;
    BigDecimal displayUsageFcaRec = BigDecimal.ZERO;

    // 日割の設定
    super.setPerDiemRate(dayOfPerDiem, dayOfMeterRead);

    // 最低料金適用使用量を日割する
    lowestPriceUsageAmount = super.calcCharge(lowestPriceUsageAmount, usageScale, usageMode);

    // 最低料金を日割する
    lowestPrice = super.calcCharge(lowestPrice, chargeScale, chargeMode);

    // 1段料金計算使用量
    BigDecimal firstUsage = usageAmount[ArrayIndex.ZERO.ordinal()].subtract(lowestPriceUsageAmount);
    BigDecimal usagePrice = BigDecimal.ZERO;
    if (firstUsage.compareTo(BigDecimal.ZERO) > 0) {
      usagePrice = firstUsage.multiply(usageUnitPrice[ArrayIndex.ZERO.ordinal()]);
      // 1段目使用量
      displayUsageFirstStep = firstUsage;
      // 合計使用量
      for (BigDecimal usage : usageAmount) {
        displayUsageFcaRec = displayUsageFcaRec.add(usage);
      }
    } else {
      // 再エネ・燃調用使用量
      displayUsageFcaRec = lowestPriceUsageAmount;
    }
    decimals[ArrayIndex.ZERO.ordinal()] = usagePrice;

    // 2段以降の料金計算
    for (int index = 1; index < iUsageAmountCount; index++) {
      usagePrice = usageAmount[index].multiply(usageUnitPrice[index]);
      decimals[index] = usagePrice;
    }

    // 合計を計算する
    BigDecimal sum = BigDecimal.ZERO;
    for (int index = 0; index < iUsageAmountCount; index++) {
      sum = sum.add(decimals[index]);
    }

    // 燃料費調整額を加算
    sum = sum.add(fuelAdjustPrice);

    // 配列コピー
    Object[] prices = new Object[iUsageAmountCount + ArrayIndex.FOUR.ordinal()];
    prices[ArrayIndex.ZERO.ordinal()] = sum;
    prices[ArrayIndex.ONE.ordinal()] = lowestPrice;
    for (int index = 0; index < iUsageAmountCount; index++) {
      prices[index + 2] = decimals[index];
    }
    // 1段の使用量を設定
    prices[prices.length - 2] = displayUsageFirstStep;
    prices[prices.length - 1] = displayUsageFcaRec;

    // 要素の数分、デバッグログを出力
    for (int index = 0; index < iUsageAmountCount; index++) {
      LOGGER.debug("段料金使用量{} 段料金使用単価{} 料金{}", usageAmount[index],
          usageUnitPrice[index], prices[index + 2]);
    }

    // デバッグログ出力
    LOGGER.debug("従量料金{} 最低料金{}", prices[ArrayIndex.ZERO.ordinal()], prices[ArrayIndex.ONE.ordinal()]);

    // 結果を返却
    return prices;
  }
}
