package jp.co.unisys.enability.cis.rate_engine.business;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.config.PropertiesFactoryBean;

import jp.co.unisys.enability.cis.common.Exception.RateEngineException;
import jp.co.unisys.enability.cis.common.util.Custom_DateCalculateUtil;
import jp.co.unisys.enability.cis.common.util.EMSConstants;
import jp.co.unisys.enability.cis.common.util.RK_PropertyUtil;
import jp.co.unisys.enability.cis.common.util.ThreadContext;
import jp.co.unisys.enability.cis.common.util.constants.ECISCodeConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;
import jp.co.unisys.enability.cis.common.util.rk.RateEngineCommonUtil;
import jp.co.unisys.enability.cis.entity.common.CalculatingDsUsage;
import jp.co.unisys.enability.cis.entity.common.CalculatingTsUsage;
import jp.co.unisys.enability.cis.entity.common.CalculationResult;
import jp.co.unisys.enability.cis.entity.common.ClcBreakdown;
import jp.co.unisys.enability.cis.entity.common.ClcWarningData;
import jp.co.unisys.enability.cis.entity.common.ContractHist;
import jp.co.unisys.enability.cis.entity.common.ContractHistExample;
import jp.co.unisys.enability.cis.entity.common.MfRcclM;
import jp.co.unisys.enability.cis.entity.common.RestrictionDiscountInfo;
import jp.co.unisys.enability.cis.entity.common.RestrictionDiscountInfoExample;
import jp.co.unisys.enability.cis.entity.common.SplContract;
import jp.co.unisys.enability.cis.entity.rk.SelectCalcReserveContractInfoEntityBean;
import jp.co.unisys.enability.cis.mapper.common.CalculationResultMapper;
import jp.co.unisys.enability.cis.mapper.common.ClcBreakdownMapper;
import jp.co.unisys.enability.cis.mapper.common.ClcWarningDataMapper;
import jp.co.unisys.enability.cis.mapper.common.ContractHistMapper;
import jp.co.unisys.enability.cis.mapper.common.RestrictionDiscountInfoMapper;
import jp.co.unisys.enability.cis.mapper.rk.SelectCalcReserveContractInfoMapper;
import jp.co.unisys.enability.cis.rate_engine.component.CalculatingDsUsageComparator;
import jp.co.unisys.enability.cis.rate_engine.component.RK_ChangedRateMenuCheckBusiness;
import jp.co.unisys.enability.cis.rate_engine.model.CalReserveContractBusinessBean;
import jp.co.unisys.enability.cis.rate_engine.model.CalRestrictDisInfoBusinessBean;
import jp.co.unisys.enability.cis.rate_engine.model.RK_CalculatingWarningCheckBusinessBean;
import jp.co.unisys.enability.cis.rate_engine.model.RateEngineBusinessBean;
import jp.co.unisys.enability.cis.rate_engine.model.RoundBusinessBean;

/**
 * 料金計算エンジンコントロールビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RateEngineControlBusinessImpl implements RateEngineControlBusiness {

  /** プロパティ(DI) */
  private PropertiesFactoryBean applicationProperties;

  /** 計算結果(DI) */
  private CalculationResultMapper calculationResultMapper;

  /** 計算結果内訳(DI) */
  private ClcBreakdownMapper clcBreakdownMapper;

  /** 契約履歴Mapper(DI) */
  private ContractHistMapper contractHistMapper;

  /** 計算結果警告データMapper(DI) */
  private ClcWarningDataMapper clcWarningDataMapper;

  /** 制限中止割引情報(DI) */
  private RestrictionDiscountInfoMapper restrictionDiscountInfoMapper;

  /** 計算用予備契約情報(DI) */
  private SelectCalcReserveContractInfoMapper selectCalcReserveContractInfoMapper;

  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.rate_engine.business.RateEngineControlBusiness
   * #execute(java.lang.String, java.lang.String, jp.co.unisys.enability.cis.rate_engine.model.RateEngineBusinessBean)
   */
  @Override
  public void execute(String contractId, String applyDate,
      RateEngineBusinessBean rateEngineBusinessBean) throws RateEngineException {

    /*
     * execute <br />
     * ①《料金計算中警告チェックビジネスBean》<br />
     * RK_CalculatingWarningCheckBusinessBean 初期化 <br />
     * ②計算前チェック処理を呼び出す <br />
     * メニュー変更チェック <br />
     * ③警告有りの場合、ダミーデータを作成する<br />
     * ④《計算情報管理ビジネス》<br />
     * CalcInfoManagementBusiness 初期化 <br />
     * （料金単価 ChargeUpManagementBusiness）<br />
     * ？料金単価単価取得必要（管理番号：26）<br />
     * ⑤基本情報を取得し、設定する <br />
     * 引数RateEngineBusinessBeanを使う<br />
     * ⑥時間帯別の使用量Mapを作成する <br />
     * ＜時間帯コード、時間帯別の使用量＞ <br />
     * 引数RateEngineBusinessBeanを使う<br />
     * ⑦付帯契約リストを作成する <br />
     * Map<String, SplContract> <br />
     * 引数RateEngineBusinessBeanを使う <br />
     * ⑧計算用予備契約情報リストを作成する <br />
     * ⑨計算用日割別使用量を日割開始日でソートする <br />
     * ⑩計算用制限中止割引情報リストを作成する <br />
     * ⑪《計算情報管理ビジネス》初期化<br />
     * ⑫計算結果設定処理<br />
     * ⑬計算後チェック処理を行う <br />
     * ⑭更新処理を行う <br />
     */

    // 《料金計算中警告チェックビジネスBean》を生成する。
    RK_CalculatingWarningCheckBusinessBean rKCalculatingWarningCheckBusinessBean = this.getRKCalculatingWarningCheckBusinessBean(rateEngineBusinessBean);

    // 計算前チェック処理を呼び出す（メニュー変更チェック）
    List<String> warningClassCodeList = new ArrayList<String>();
    RK_ChangedRateMenuCheckBusiness rKChangedRateMenuCheckBusiness = new RK_ChangedRateMenuCheckBusiness();
    String warningClassCode = rKChangedRateMenuCheckBusiness.check(rKCalculatingWarningCheckBusinessBean);
    if (!StringUtils.isEmpty(warningClassCode)) {
      warningClassCodeList.add(warningClassCode);
    }

    // 警告有無チェック
    if (warningClassCodeList.size() > 0) {
      // 警告有り
      // 計算結果ダミーデータ作成処理を呼び出す
      this.createDummyCalculationResults(rateEngineBusinessBean);

      // 計算結果警告データ作成処理を呼び出す
      List<ClcWarningData> clcWarningDataList = this.createClcWarningData(
          rateEngineBusinessBean.getCalculatingUsage().getContractId(),
          rateEngineBusinessBean.getCalculatingUsage().getUsePeriod(), warningClassCodeList);

      rateEngineBusinessBean.setCalculationResultWarningData(clcWarningDataList);

    } else {
      // 警告無し

      // 《計算情報管理ビジネス》を生成する。
      CalcInfoManagementBusiness calcInfoManagementBusiness = new CalcInfoManagementBusiness(
          rateEngineBusinessBean.getChargeUpManagement());

      // 基本情報を取得し、設定する
      Integer calcUsagecontractId = rateEngineBusinessBean
          .getCalculatingUsage().getContractId();
      String usePeriod = rateEngineBusinessBean.getCalculatingUsage()
          .getUsePeriod();
      String rateMenuId = rateEngineBusinessBean.getCalculatingUsage()
          .getRmId();
      Date ccSd = rateEngineBusinessBean.getCalculatingUsage().getCcSd();
      Date ccEd = rateEngineBusinessBean.getCalculatingUsage().getCcEd();

      String areaCd = rateEngineBusinessBean.getAreaCd();

      // 時間帯別の使用量Mapを作成する
      Map<String, CalculatingTsUsage> calculatingTsUsageList = new TreeMap<String, CalculatingTsUsage>();
      for (CalculatingTsUsage value : rateEngineBusinessBean
          .getCalculatingTimeSlotUsage()) {
        String tsCode = value.getTsCode();
        String dsSd = (new SimpleDateFormat(ECISConstants.FORMAT_DATE_yyyyMMdd)).format(value.getDsSd());
        // 日割山が割れる可能性を考慮し、算定開始日 + 時間帯コードをキーとする
        calculatingTsUsageList.put(dsSd + ECISConstants.UNDERLINE + tsCode, value);
      }

      // 付帯契約リストを作成する
      Map<String, SplContract> spmMap = new TreeMap<String, SplContract>();
      Integer indexKey = 1;
      for (SplContract value : rateEngineBusinessBean.getSplContract()) {
        spmMap.put(indexKey.toString(), value);
        indexKey = indexKey + 1;
      }

      // 計算用日割別使用量を日割開始日でソートする
      List<CalculatingDsUsage> calculatingDsUsageList = rateEngineBusinessBean.getCalculatingDateSlotUsage();
      Collections.sort(calculatingDsUsageList, new CalculatingDsUsageComparator());

      // 計算用予備契約情報作成処理を呼び出す
      List<CalReserveContractBusinessBean> calReserveContractBusinessBeanList = this.createCalcReserveContractInfo(contractId, applyDate,
          calculatingDsUsageList, rateEngineBusinessBean.getContractClassCode(), rateEngineBusinessBean.getContractClassCalcDetailManagement());

      // 計算用制限中止割引情報を呼び出す
      List<CalRestrictDisInfoBusinessBean> calRestrictDisInfoBusinessBeanList = this.createCalRestrictDisInfo(contractId, applyDate, calculatingDsUsageList);

      // 《計算情報管理ビジネス》インスタンス.データ初期化を呼び出す。
      calcInfoManagementBusiness.initData(calcUsagecontractId.toString(),
          usePeriod, ccSd, ccEd, rateMenuId, areaCd,
          rateEngineBusinessBean.getConsignmentMenuId(),
          rateEngineBusinessBean.getContractStartDate(),
          rateEngineBusinessBean.getContractEndDate(),
          spmMap,
          rateEngineBusinessBean.getCalculatingUsage(),
          rateEngineBusinessBean.getCalculatingDateSlotUsage(),
          rateEngineBusinessBean.getCalculatingTimeSlotUsage(),
          calReserveContractBusinessBeanList,
          calRestrictDisInfoBusinessBeanList,
          rateEngineBusinessBean.getContractClassCode(), getRoundMap(),
          rateEngineBusinessBean.getMinMonthlyChargeName(),
          rateEngineBusinessBean.getBasicChargeFree(),
          rateEngineBusinessBean.getFixChargeAreaList(),
          rateEngineBusinessBean.getSupplementaryName(),
          calculatingTsUsageList,
          rateEngineBusinessBean.getContractHist(),
          RK_PropertyUtil.getProperty(applicationProperties, "fuelcostadjust.get.way.category"),
          RK_PropertyUtil.getProperty(applicationProperties, "rate.engine.reserveContractBasicCharge.name"),
          RK_PropertyUtil.getProperty(applicationProperties, "rate.engine.reserveLineBasicCharge.name"),
          RK_PropertyUtil
              .getProperty(applicationProperties, "rate.engine.reservePowerSupplyBasicCharge.name"),
          RK_PropertyUtil.getProperty(applicationProperties, "rate.engine.restrictionDiscountCharge.name"),
          RK_PropertyUtil.getProperty(applicationProperties, "rate.engine.restrictionDiscountContract.name"),
          RK_PropertyUtil.getProperty(applicationProperties,
              "rate.engine.restrictionDiscountReserveLine.name"),
          RK_PropertyUtil.getProperty(applicationProperties,
              "rate.engine.restrictionDiscountReservePower.name"),
          rateEngineBusinessBean.getContractExcessChargeCalcScaleFactor(),
          rateEngineBusinessBean.getProratedQuantity(),
          rateEngineBusinessBean.getContractExcessChargeDisplayName1(),
          rateEngineBusinessBean.getContractExcessChargeDisplayName2());

      for (int i = 0; i < rateEngineBusinessBean.getCalculatingDateSlotUsage().size(); i++) {
        // 合算前の料金メニュー毎の計算処理を実行する
        RateEngineExecuteBusiness rateEngineExecuteBusiness = new RateEngineExecuteBusiness(
            rateEngineBusinessBean.getContractClassCalcDetailManagement());
        rateEngineExecuteBusiness.executeCalculateRateMenuAddupBfr(calcInfoManagementBusiness);

        // 日割山切り替え処理を呼び出す
        calcInfoManagementBusiness.setNextDs();
      }

      // 合算後の料金メニュー毎の計算処理を実行する
      RateEngineExecuteBusiness rateEngineExecuteBusinessAfr = new RateEngineExecuteBusiness(
          rateEngineBusinessBean.getContractClassCalcDetailManagement());
      rateEngineExecuteBusinessAfr.executeCalculateRateMenuAddupAfr(calcInfoManagementBusiness);

      // 計算結果明細リストを生成する
      List<ClcBreakdown> clcBreakdownList = new ArrayList<ClcBreakdown>();

      for (Map.Entry<String, ClcBreakdown> clcBreakdown : calcInfoManagementBusiness
          .getCalculateResultDetailMap().entrySet()) {

        clcBreakdownList.add(clcBreakdown.getValue());
      }

      // 計算結果と計算結果内訳を設定する
      rateEngineBusinessBean.setCalculationResult(calcInfoManagementBusiness.getCalculateResult());
      rateEngineBusinessBean.setClcBreakdown(clcBreakdownList);

      // 計算後チェックを行う
      for (CalRestrictDisInfoBusinessBean calRestrictDisInfo : calRestrictDisInfoBusinessBeanList) {
        // 制限中止割引契約電力チェック処理を呼び出す
        if (!this.restrictionDiscountDecisionCategoryCheck(calRestrictDisInfo,
            rateEngineBusinessBean.getContractHist().getVoltageCatCode())) {
          // 警告種別コードを追加
          warningClassCodeList.add(ECISRKConstants.WARNING_CLASS_MASTER_RES_DISCOUNT_INFO_INCONSISTENCY);
          break;
        }
      }

      if (warningClassCodeList.size() != 0) {
        // 警告あり
        // 計算結果警告データ作成処理を呼び出す
        List<ClcWarningData> clcWarningDataList = this.createClcWarningData(
            rateEngineBusinessBean.getCalculatingUsage().getContractId(),
            rateEngineBusinessBean.getCalculatingUsage().getUsePeriod(), warningClassCodeList);

        rateEngineBusinessBean.setCalculationResultWarningData(clcWarningDataList);
      }
    }

    // 計算結果保存判断
    if (rateEngineBusinessBean.isRegistResultFlag()) {

      // 計算後処理を行う。
      int updateCount = 0;
      Timestamp systemTime = new Timestamp(System.currentTimeMillis());
      String requestThreadContext = ThreadContext.getRequestThreadContext()
          .get(EMSConstants.CLASS_NAME_KEY).toString();

      // 計算結果保存
      rateEngineBusinessBean.getCalculationResult().setUpdateCount(updateCount);
      rateEngineBusinessBean.getCalculationResult().setCreateTime(systemTime);
      rateEngineBusinessBean.getCalculationResult().setUpdateTime(systemTime);
      rateEngineBusinessBean.getCalculationResult().setUpdateModuleCode(requestThreadContext);
      calculationResultMapper.insert(rateEngineBusinessBean.getCalculationResult());

      // 計算結果内訳保存
      for (ClcBreakdown clcBreakdown : rateEngineBusinessBean.getClcBreakdown()) {
        clcBreakdown.setUpdateCount(updateCount);
        clcBreakdown.setCreateTime(systemTime);
        clcBreakdown.setUpdateTime(systemTime);
        clcBreakdown.setUpdateModuleCode(requestThreadContext);
        clcBreakdownMapper.insert(clcBreakdown);
      }

      if (rateEngineBusinessBean.getCalculationResultWarningData() != null) {
        // 計算結果警告データ保存
        for (ClcWarningData clcWarningData : rateEngineBusinessBean.getCalculationResultWarningData()) {
          clcWarningData.setUpdateCount(updateCount);
          clcWarningData.setCreateTime(systemTime);
          clcWarningData.setUpdateTime(systemTime);
          clcWarningData.setUpdateModuleCode(requestThreadContext);
          clcWarningDataMapper.insert(clcWarningData);
        }
      }
    }
  }

  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.rate_engine.business.RateEngineControlBusiness#getRoundMap()
   */
  @Override
  public Map<String, RoundBusinessBean> getRoundMap()
      throws RateEngineException {
    Map<String, RoundBusinessBean> roundMap = new TreeMap<String, RoundBusinessBean>();

    List<String> propKeyList = new ArrayList<String>();
    propKeyList.add("rate.engine.roundmode.halfup.three");
    propKeyList.add("rate.engine.roundmode.down.three");
    propKeyList.add("rate.engine.roundmode.up.three");
    propKeyList.add("rate.engine.roundmode.halfup.one");
    propKeyList.add("rate.engine.roundmode.down.one");
    propKeyList.add("rate.engine.roundmode.off");

    Map<String, String> properties = new HashMap<String, String>();
    properties = RK_PropertyUtil.getProperty(applicationProperties, propKeyList);

    for (Map.Entry<String, String> data : properties.entrySet()) {
      RoundBusinessBean roundBusinessBean = this
          .getRoundBusinessBeanDetail(data.getKey(), data.getValue());
      roundMap.put(data.getKey(), roundBusinessBean);
    }

    return roundMap;
  }

  /**
   * 丸め処理
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * プロパティから丸め処理
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param roundKey
   *          キー
   * @param roundData
   *          値
   * @return RoundBusinessBean 丸めデータ
   */
  private RoundBusinessBean getRoundBusinessBeanDetail(String roundKey, String roundData) {

    if (!StringUtils.isNotBlank(roundData)) {
      return null;
    }

    RoundBusinessBean roundBusinessBean = new RoundBusinessBean();
    String[] data = roundData
        .split(ECISRKConstants.DELIMITER_METER_CATEGORY_CODE_COMMA);

    roundBusinessBean.setRoundKey(roundKey);
    roundBusinessBean.setRoundDigit(data[0]);
    roundBusinessBean.setRoundMethod(data[1]);

    return roundBusinessBean;
  }

  /**
   * 計算結果警告データ作成処理
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計算結果警告データを作成する
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractId
   *          契約ID
   * @param applyDate
   *          利用年月
   * @param warningClassCodeList
   *          警告種別コードリスト
   * @return 計算結果警告データリスト
   */
  private List<ClcWarningData> createClcWarningData(Integer contractId, String applyDate,
      List<String> warningClassCodeList) {

    List<ClcWarningData> clcWarningDataList = new ArrayList<ClcWarningData>();

    for (String warningClassCode : warningClassCodeList) {
      ClcWarningData clcWarningData = new ClcWarningData();

      clcWarningData.setContractId(contractId);
      clcWarningData.setUsePeriod(applyDate);
      clcWarningData.setWarningClassCode(warningClassCode);

      clcWarningDataList.add(clcWarningData);
    }

    return clcWarningDataList;
  }

  /**
   * 計算結果ダミーデータ作成処理
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計算結果ダミーデータを作成する
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param rateEngineBusinessBean
   *          《料金計算エンジンビジネスBean》
   */
  private void createDummyCalculationResults(RateEngineBusinessBean rateEngineBusinessBean) {

    Timestamp systemTime = new Timestamp(System.currentTimeMillis());
    String requestThreadContext;

    if (rateEngineBusinessBean.isRegistResultFlag()) {
      // バッチからの呼び出し時は更新機能名をここで設定する
      requestThreadContext = ThreadContext.getRequestThreadContext().get(EMSConstants.CLASS_NAME_KEY).toString();
    } else {
      // 画面からの呼び出し時は画面側で更新モジュールを書き換えるため取得不要
      requestThreadContext = null;
    }

    /* 計算結果のダミー情報の設定を行う */
    CalculationResult calculationResult = new CalculationResult();
    calculationResult.setContractId(rateEngineBusinessBean.getCalculatingUsage().getContractId());
    calculationResult.setUsePeriod(rateEngineBusinessBean.getCalculatingUsage().getUsePeriod());
    calculationResult.setRmId(rateEngineBusinessBean.getCalculatingUsage().getRmId());
    calculationResult.setCalculatingPowerFactor(rateEngineBusinessBean.getCalculatingUsage().getPowerFactor());
    calculationResult.setBasicCharge(BigDecimal.ZERO);
    calculationResult.setUsageCharge(BigDecimal.ZERO);
    calculationResult.setFca(BigDecimal.ZERO);
    calculationResult.setSplAmount(BigDecimal.ZERO);
    calculationResult.setRec(BigDecimal.ZERO);
    calculationResult.setCec(BigDecimal.ZERO);
    calculationResult.setConsignmentChargeEquivalent(Long.valueOf(0));
    calculationResult.setUpdateCount(0);
    calculationResult.setCreateTime(systemTime);
    calculationResult.setUpdateTime(systemTime);
    calculationResult.setUpdateModuleCode(requestThreadContext);
    rateEngineBusinessBean.setCalculationResult(calculationResult);

    /*計算結果内訳のダミー情報の設定を行う（基本料金・従量料金・燃料費調整額・再エネ賦課金） */
    List<ClcBreakdown> clcBreakdownbasicList = new ArrayList<ClcBreakdown>();
    // 計算結果内訳（基本料金）の設定
    ClcBreakdown clcBreakdownBasic = new ClcBreakdown();
    clcBreakdownBasic.setContractId(rateEngineBusinessBean.getCalculatingUsage().getContractId());
    clcBreakdownBasic.setUsePeriod(rateEngineBusinessBean.getCalculatingUsage().getUsePeriod());
    clcBreakdownBasic.setDisplayOrder(Short.valueOf(RK_PropertyUtil.getProperty(applicationProperties,
        "rate.engine.clcbreakdown.dummy.basiccharge.displayorder")));
    clcBreakdownBasic.setDetailOutputOrder(Short.valueOf(RK_PropertyUtil.getProperty(applicationProperties,
        "rate.engine.clcbreakdown.dummy.basiccharge.detailoutputorder")));
    clcBreakdownBasic.setDisplayName1(RK_PropertyUtil.getProperty(applicationProperties,
        "rate.engine.clcbreakdown.dummy.basiccharge.displayname1"));
    clcBreakdownBasic.setAmount(BigDecimal.ZERO);
    clcBreakdownBasic.setFcrBreakdownCatCode(RK_PropertyUtil.getProperty(applicationProperties,
        "rate.engine.clcbreakdown.dummy.basiccharge.fcrbreakdowncatcode"));
    clcBreakdownBasic.setUpdateCount(0);
    clcBreakdownBasic.setCreateTime(systemTime);
    clcBreakdownBasic.setUpdateTime(systemTime);
    clcBreakdownBasic.setUpdateModuleCode(requestThreadContext);
    clcBreakdownbasicList.add(clcBreakdownBasic);

    // 計算結果内訳（従量料金）の設定
    ClcBreakdown clcBreakdownUsage = new ClcBreakdown();
    clcBreakdownUsage.setContractId(rateEngineBusinessBean.getCalculatingUsage().getContractId());
    clcBreakdownUsage.setUsePeriod(rateEngineBusinessBean.getCalculatingUsage().getUsePeriod());
    clcBreakdownUsage.setDisplayOrder(Short.valueOf(RK_PropertyUtil.getProperty(applicationProperties,
        "rate.engine.clcbreakdown.dummy.usagecharge.displayorder")));
    clcBreakdownUsage.setDetailOutputOrder(Short.valueOf(RK_PropertyUtil.getProperty(applicationProperties,
        "rate.engine.clcbreakdown.dummy.usagecharge.detailoutputorder")));
    clcBreakdownUsage.setDisplayName1(RK_PropertyUtil.getProperty(applicationProperties,
        "rate.engine.clcbreakdown.dummy.usagecharge.displayname1"));
    clcBreakdownUsage.setAmount(BigDecimal.ZERO);
    clcBreakdownUsage.setFcrBreakdownCatCode(RK_PropertyUtil.getProperty(applicationProperties,
        "rate.engine.clcbreakdown.dummy.usagecharge.fcrbreakdowncatcode"));
    clcBreakdownUsage.setUpdateCount(0);
    clcBreakdownUsage.setCreateTime(systemTime);
    clcBreakdownUsage.setUpdateTime(systemTime);
    clcBreakdownUsage.setUpdateModuleCode(requestThreadContext);
    clcBreakdownbasicList.add(clcBreakdownUsage);

    // 計算結果内訳（燃料費調整額）の設定
    ClcBreakdown clcBreakdownFca = new ClcBreakdown();
    clcBreakdownFca.setContractId(rateEngineBusinessBean.getCalculatingUsage().getContractId());
    clcBreakdownFca.setUsePeriod(rateEngineBusinessBean.getCalculatingUsage().getUsePeriod());
    clcBreakdownFca.setDisplayOrder(Short.valueOf(RK_PropertyUtil.getProperty(applicationProperties,
        "rate.engine.clcbreakdown.dummy.fca.displayorder")));
    clcBreakdownFca.setDetailOutputOrder(Short.valueOf(RK_PropertyUtil.getProperty(applicationProperties,
        "rate.engine.clcbreakdown.dummy.fca.detailoutputorder")));
    clcBreakdownFca.setDisplayName1(RK_PropertyUtil.getProperty(applicationProperties,
        "rate.engine.clcbreakdown.dummy.fca.displayname1"));
    clcBreakdownFca.setDisplayName2(RK_PropertyUtil.getProperty(applicationProperties,
        "rate.engine.clcbreakdown.dummy.fca.displayname2"));
    clcBreakdownFca.setAmount(BigDecimal.ZERO);
    clcBreakdownFca.setFcrBreakdownCatCode(RK_PropertyUtil.getProperty(applicationProperties,
        "rate.engine.clcbreakdown.dummy.fca.fcrbreakdowncatcode"));
    clcBreakdownFca.setUpdateCount(0);
    clcBreakdownFca.setCreateTime(systemTime);
    clcBreakdownFca.setUpdateTime(systemTime);
    clcBreakdownFca.setUpdateModuleCode(requestThreadContext);
    clcBreakdownbasicList.add(clcBreakdownFca);

    // 計算結果内訳（再エネ賦課金）の設定
    ClcBreakdown clcBreakdownRec = new ClcBreakdown();
    clcBreakdownRec.setContractId(rateEngineBusinessBean.getCalculatingUsage().getContractId());
    clcBreakdownRec.setUsePeriod(rateEngineBusinessBean.getCalculatingUsage().getUsePeriod());
    clcBreakdownRec.setDisplayOrder(Short.valueOf(RK_PropertyUtil.getProperty(applicationProperties,
        "rate.engine.clcbreakdown.dummy.rec.displayorder")));
    clcBreakdownRec.setDetailOutputOrder(Short.valueOf(RK_PropertyUtil.getProperty(applicationProperties,
        "rate.engine.clcbreakdown.dummy.rec.detailoutputorder")));
    clcBreakdownRec.setDisplayName1(RK_PropertyUtil.getProperty(applicationProperties,
        "rate.engine.clcbreakdown.dummy.rec.displayname1"));
    clcBreakdownRec.setAmount(BigDecimal.ZERO);
    clcBreakdownRec.setFcrBreakdownCatCode(RK_PropertyUtil.getProperty(applicationProperties,
        "rate.engine.clcbreakdown.dummy.rec.fcrbreakdowncatcode"));
    clcBreakdownRec.setUpdateCount(0);
    clcBreakdownRec.setCreateTime(systemTime);
    clcBreakdownRec.setUpdateTime(systemTime);
    clcBreakdownRec.setUpdateModuleCode(requestThreadContext);
    clcBreakdownbasicList.add(clcBreakdownRec);

    rateEngineBusinessBean.setClcBreakdown(clcBreakdownbasicList);
  }

  /**
   * 料金計算中警告チェックビジネスBean取得処理
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金計算中警告チェックビジネスBeanを生成する
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param rateEngineBusinessBean
   *          《料金計算エンジンビジネスBean》
   * @param warningClassCodeList
   *          警告種別コードリスト
   * @return RK_CalculatingWarningCheckBusinessBean 《料金計算中警告チェックビジネスBean》
   */
  private RK_CalculatingWarningCheckBusinessBean getRKCalculatingWarningCheckBusinessBean(
      RateEngineBusinessBean rateEngineBusinessBean) {

    RK_CalculatingWarningCheckBusinessBean calculatingWarningCheckBusinessBean = new RK_CalculatingWarningCheckBusinessBean();

    calculatingWarningCheckBusinessBean.setCalculatingUsage(rateEngineBusinessBean.getCalculatingUsage());
    calculatingWarningCheckBusinessBean.setCalculatingDateSlotUsage(
        rateEngineBusinessBean.getCalculatingDateSlotUsage());

    return calculatingWarningCheckBusinessBean;
  }

  /**
   * 計算用予備契約情報作成処理
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計算用予備契約情報を作成する
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractId
   *          契約ID
   * @param applyDate
   *          利用年月
   * @param calculatingDsUsageList
   *          計算用日割別使用量リスト
   * @param cclCode
   *          契約種別コード
   * @param contractClassCalcDetailManagement
   *          契約種別管理ビジネスBean
   * @return 計算用予備契約情報リスト
   */
  private List<CalReserveContractBusinessBean> createCalcReserveContractInfo(String contractId, String applyDate,
      List<CalculatingDsUsage> calculatingDsUsageList, String cclCode,
      ContractClassCalcDetailManagementBusiness contractClassCalcDetailManagement) throws RateEngineException {

    List<CalReserveContractBusinessBean> calReserveContractBusinessBeanList = new ArrayList<CalReserveContractBusinessBean>();
    int proratedBasisDays;

    // 計算用の予備契約情報を取得
    Map<String, Object> map = new LinkedHashMap<String, Object>();
    map.put("contractId", Integer.parseInt(contractId));
    map.put("usePeriod", applyDate);
    List<SelectCalcReserveContractInfoEntityBean> selCalcResContEntityList = selectCalcReserveContractInfoMapper.selectByExample(map);

    // 掛率制予備契約種別マスタ情報を取得
    MfRcclM mfRcclMInfo = contractClassCalcDetailManagement.getMultiplyFactorReserveContractClassMaster(cclCode);

    for (SelectCalcReserveContractInfoEntityBean selCalcResContEntity : selCalcResContEntityList) {
      BigDecimal rcCapacity = selCalcResContEntity.getCapacity();
      // 主契約変更日割フラグ作成
      boolean dateSlogBasedOnContractChangedFlag = false;
      if (mfRcclMInfo != null || rcCapacity == null || BigDecimal.ZERO.compareTo(rcCapacity) == 0) {
        // 契約種別コードと一致する掛率制予備契約種別マスタ情報が存在する、または予備契約情報の容量が未設定の場合
        dateSlogBasedOnContractChangedFlag = true;
      }
      for (CalculatingDsUsage calculatingDsUsage : calculatingDsUsageList) {
        if (((calculatingDsUsage.getDsSd().compareTo(selCalcResContEntity.getReserveContractSd()) <= 0)
            && (calculatingDsUsage.getDsEd().compareTo(selCalcResContEntity.getReserveContractSd()) >= 0))
            || ((calculatingDsUsage.getDsSd().compareTo(selCalcResContEntity.getReserveContractEd()) <= 0)
                && (calculatingDsUsage.getDsEd().compareTo(selCalcResContEntity.getReserveContractEd()) >= 0))
            || ((calculatingDsUsage.getDsSd().compareTo(selCalcResContEntity.getReserveContractSd()) > 0)
                && (calculatingDsUsage.getDsEd().compareTo(selCalcResContEntity.getReserveContractEd()) < 0))) {

          // 予備契約日割日数を計算する際の開始日を取得
          Date stDate = null;
          if (selCalcResContEntity.getReserveContractSd().compareTo(selCalcResContEntity.getCcSd()) < 0) {
            stDate = selCalcResContEntity.getCcSd();
          } else {
            stDate = selCalcResContEntity.getReserveContractSd();
          }

          // 予備契約日割日数を計算する際の終了日を取得
          Date edDate = null;
          if (selCalcResContEntity.getReserveContractEd().compareTo(selCalcResContEntity.getCcEd()) > 0) {
            edDate = selCalcResContEntity.getCcEd();
          } else {
            edDate = selCalcResContEntity.getReserveContractEd();
          }

          // 主契約変更日割フラグがtrueの場合、予備契約日割日数を計算する際の開始日と終了日を再判定
          if (dateSlogBasedOnContractChangedFlag) {
            // 予備契約日割日数を計算する際の開始日
            if (stDate.compareTo(calculatingDsUsage.getDsSd()) < 0) {
              stDate = calculatingDsUsage.getDsSd();
            }
            // 予備契約日割日数を計算する際の終了日
            if (edDate.compareTo(calculatingDsUsage.getDsEd()) > 0) {
              edDate = calculatingDsUsage.getDsEd();
            }
          }

          CalReserveContractBusinessBean calResContractBusinessBean = new CalReserveContractBusinessBean();

          // 日割開始日
          calResContractBusinessBean.setDateSlotStartDate(calculatingDsUsage.getDsSd());
          // 予備契約種別
          calResContractBusinessBean.setReserveContractClass(
              selCalcResContEntity.getReserveContractClass().toString());
          // 予備契約開始日（予備契約日割日数を計算する際の開始日を設定）
          calResContractBusinessBean.setReserveContractStartDate(stDate);
          // 予備契約終了日（予備契約日割日数を計算する際の終了日を設定）
          calResContractBusinessBean.setReserveContractEndDate(edDate);
          // 契約容量
          if (!dateSlogBasedOnContractChangedFlag) {
            calResContractBusinessBean.setContractCapacity(rcCapacity);
          } else {
            calResContractBusinessBean.setContractCapacity(calculatingDsUsage.getCca());
          }
          // 予備単価
          calResContractBusinessBean.setReserveUnitPrice(BigDecimal.ZERO);
          // 検針日数
          calResContractBusinessBean.setMeterReadingDays(
              BigDecimal.valueOf(selCalcResContEntity.getProratedBasisDays()));
          // 予備契約日割日数
          proratedBasisDays = Custom_DateCalculateUtil.getDifferenceDate(edDate, stDate) + 1;
          calResContractBusinessBean.setProratedBasisDays(BigDecimal.valueOf(proratedBasisDays));

          calReserveContractBusinessBeanList.add(calResContractBusinessBean);

          if (!dateSlogBasedOnContractChangedFlag) {
            // 主契約変更日割フラグがfalse（主契約の変更で日割しない）場合
            break;
          }
        }
      }
    }

    return calReserveContractBusinessBeanList;
  }

  /**
   * 計算用制限中止割引情報作成処理
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計算用制限中止割引情報を作成する
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractId
   *          契約ID
   * @param applyDate
   *          利用年月
   * @param calculatingDsUsageList
   *          計算用日割別使用量リスト
   * @return 計算用予備契約情報リスト
   */
  private List<CalRestrictDisInfoBusinessBean> createCalRestrictDisInfo(String contractId, String applyDate,
      List<CalculatingDsUsage> calculatingDsUsageList) throws RateEngineException {

    List<CalRestrictDisInfoBusinessBean> calRestrictDisInfoBusinessBeanList = new ArrayList<CalRestrictDisInfoBusinessBean>();

    // 制限中止割引情報取得
    RestrictionDiscountInfoExample rDiscountInfoExample = new RestrictionDiscountInfoExample();
    rDiscountInfoExample.createCriteria()
        .andContractIdEqualTo(Integer.parseInt(contractId))
        .andCoveredPeriodEqualTo(applyDate);
    List<RestrictionDiscountInfo> restrictionDiscountInfoList = restrictionDiscountInfoMapper.selectByExample(rDiscountInfoExample);

    for (RestrictionDiscountInfo restrictionDiscountInfo : restrictionDiscountInfoList) {
      for (CalculatingDsUsage calculatingDsUsage : calculatingDsUsageList) {
        /*
         * 計算用日割別使用量の日割開始日 ≦ 制限中止割引情報の算定期間開始日　かつ
         * 計算用日割別使用量の日割終了日 ≧ 制限中止割引情報の算定期間開始日　の場合
         */
        if (calculatingDsUsage.getDsSd().compareTo(restrictionDiscountInfo.getCcSd()) <= 0
            && calculatingDsUsage.getDsEd().compareTo(restrictionDiscountInfo.getCcSd()) >= 0) {

          CalRestrictDisInfoBusinessBean calRestrictDisInfoBusinessBean = new CalRestrictDisInfoBusinessBean();

          // 契約履歴取得
          ContractHistExample cHistExample = new ContractHistExample();
          cHistExample.createCriteria()
              .andContractIdEqualTo(calculatingDsUsage.getContractId())
              .andApplyEdGreaterThanOrEqualTo(calculatingDsUsage.getDsSd())
              .andApplySdLessThanOrEqualTo(calculatingDsUsage.getDsSd());
          List<ContractHist> contractHistList = contractHistMapper.selectByExample(cHistExample);

          // 日割開始日
          calRestrictDisInfoBusinessBean.setDateSlotStartDate(calculatingDsUsage.getDsSd());
          //算定期間開始日
          calRestrictDisInfoBusinessBean.setChargeCalStartDate(restrictionDiscountInfo.getCcSd());
          // 割引対象コード
          calRestrictDisInfoBusinessBean.setDiscountCoveredCode(restrictionDiscountInfo.getdCoveredCode());
          // 契約電力決定区分コード
          calRestrictDisInfoBusinessBean.setCcDecisionCategoryCode(
              contractHistList.get(0).getCcDecisionCategoryCode());
          // 割引時間数
          calRestrictDisInfoBusinessBean.setDiscountCoveredTime(
              RateEngineCommonUtil.convertToDecimal(restrictionDiscountInfo.getdCoveredTime()));
          // 割引日数
          calRestrictDisInfoBusinessBean.setDiscountCoveredDays(
              RateEngineCommonUtil.convertToDecimal(restrictionDiscountInfo.getdCoveredDays()));

          calRestrictDisInfoBusinessBeanList.add(calRestrictDisInfoBusinessBean);
        }
      }
    }

    return calRestrictDisInfoBusinessBeanList;
  }

  /**
   * 制限中止割引契約電力チェック
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 制限中止割引情報の契約電力決定区分コード・割引時間数・割引日数と電圧区分コードよりチェックを行う
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param calRestrictDisInfoBusinessBean
   *          計算用制限中止割引情報
   * @param voltageCatCode
   *          電圧区分コード
   * @return チェック結果（true：正常／false：エラー）
   */
  private Boolean restrictionDiscountDecisionCategoryCheck(
      CalRestrictDisInfoBusinessBean calRestrictDisInfoBusinessBean,
      String voltageCatCode) {

    if (ECISCodeConstants.CUSTOM_VOLTAGE_CAT_CODE_LOW_TENSION.equals(voltageCatCode)) {
      // 電圧区分コードが"1"（低圧）の場合

      // 割引日数がNULLまたは0かチェック
      if (calRestrictDisInfoBusinessBean.getDiscountCoveredDays() == null
          || calRestrictDisInfoBusinessBean.getDiscountCoveredDays().compareTo(BigDecimal.ZERO) == 0) {
        return false;
      }

    } else if (ECISCodeConstants.CUSTOM_VOLTAGE_CAT_CODE_HIGH_TENSION.equals(voltageCatCode)) {
      // 電圧区分コードが"2"（高圧）の場合

      // 契約電力決定区分コードが"1"（協議制）または"2"（実量制）以外かチェック
      if (!ECISCodeConstants.CONTRACT_CAPACITY_DECISION_CATEGORY_CODE_DISCUSSIONS.equals(
          calRestrictDisInfoBusinessBean.getCcDecisionCategoryCode())
          && !ECISCodeConstants.CONTRACT_CAPACITY_DECISION_CATEGORY_CODE_REALQUANTITY.equals(
              calRestrictDisInfoBusinessBean.getCcDecisionCategoryCode())) {
        return false;
      }

      // 契約電力決定区分コードが"1"（協議制）で割引時間数がNULLまたは0かチェック
      if (ECISCodeConstants.CONTRACT_CAPACITY_DECISION_CATEGORY_CODE_DISCUSSIONS.equals(
          calRestrictDisInfoBusinessBean.getCcDecisionCategoryCode())
          && (calRestrictDisInfoBusinessBean.getDiscountCoveredTime() == null
              || calRestrictDisInfoBusinessBean.getDiscountCoveredTime().compareTo(BigDecimal.ZERO) == 0)) {
        return false;
      }

      // 契約電力決定区分コードが"2"（実量制）で割引日数がNULLまたは0かチェック
      if (ECISCodeConstants.CONTRACT_CAPACITY_DECISION_CATEGORY_CODE_REALQUANTITY.equals(
          calRestrictDisInfoBusinessBean.getCcDecisionCategoryCode())
          && (calRestrictDisInfoBusinessBean.getDiscountCoveredDays() == null
              || calRestrictDisInfoBusinessBean.getDiscountCoveredDays().compareTo(BigDecimal.ZERO) == 0)) {
        return false;
      }

    } else if (ECISCodeConstants.CUSTOM_VOLTAGE_CAT_CODE_SPECIALLY_HIGH.equals(voltageCatCode)) {
      // 電圧区分コードが"3"（特高）の場合

      // 割引時間数がNULLまたは0かチェック
      if (calRestrictDisInfoBusinessBean.getDiscountCoveredTime() == null
          || calRestrictDisInfoBusinessBean.getDiscountCoveredTime().compareTo(BigDecimal.ZERO) == 0) {
        return false;
      }

    } else {
      // 電圧区分コードが"上記以外の値の場合
      return false;
    }

    return true;
  }

  /**
   * コード定義プロパティを設定します。(DI)
   *
   * @author "Nihon Unisys, Ltd."
   * @param applicationProperties
   *          コード定義プロパティ
   */
  public void setApplicationProperties(
      PropertiesFactoryBean applicationProperties) {
    this.applicationProperties = applicationProperties;
  }

  /**
   * 計算結果を設定します。(DI)
   *
   * @author "Nihon Unisys, Ltd."
   * @param calculationResultMapperPara
   *          計算結果
   */
  public void setInertCalculationResult(
      CalculationResultMapper calculationResultMapperPara) {
    this.calculationResultMapper = calculationResultMapperPara;
  }

  /**
   * 計算結果内訳を設定します。(DI)
   *
   * @author "Nihon Unisys, Ltd."
   * @param clcBreakdownMapperPara
   *          計算結果内訳
   */
  public void setInertClcBreakdown(ClcBreakdownMapper clcBreakdownMapperPara) {
    this.clcBreakdownMapper = clcBreakdownMapperPara;
  }

  /**
   * 契約履歴を設定します。(DI)
   *
   * @param contractHistMapper
   *          契約履歴
   */
  public void setContractHistMapper(ContractHistMapper contractHistMapper) {
    this.contractHistMapper = contractHistMapper;
  }

  /**
   * 計算結果警告データを設定します。(DI)
   *
   * @param clcWarningDataMapper
   *          計算結果警告データ
   */
  public void setClcWarningDataMapper(ClcWarningDataMapper clcWarningDataMapper) {
    this.clcWarningDataMapper = clcWarningDataMapper;
  }

  /**
   * 制限中止割引情報を設定します。(DI)
   *
   * @author "Nihon Unisys, Ltd."
   * @param restrictionDiscountInfoMapper
   *          制限中止割引情報
   */
  public void setRestrictionDiscountInfoMapper(RestrictionDiscountInfoMapper restrictionDiscountInfoMapper) {
    this.restrictionDiscountInfoMapper = restrictionDiscountInfoMapper;
  }

  /**
   * 計算用予備契約情報を設定します。(DI)
   *
   * @author "Nihon Unisys, Ltd."
   * @param selectCalcReserveContractInfoMapper
   *          計算用予備契約情報
   */
  public void setSelectCalcReserveContractInfoMapper(
      SelectCalcReserveContractInfoMapper selectCalcReserveContractInfoMapper) {
    this.selectCalcReserveContractInfoMapper = selectCalcReserveContractInfoMapper;
  }

}
