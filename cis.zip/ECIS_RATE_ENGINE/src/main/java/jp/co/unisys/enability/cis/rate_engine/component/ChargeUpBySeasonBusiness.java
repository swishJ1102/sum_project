package jp.co.unisys.enability.cis.rate_engine.component;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import jp.co.unisys.enability.cis.common.Exception.RateEngineException;
import jp.co.unisys.enability.cis.common.util.EMSConstants;
import jp.co.unisys.enability.cis.common.util.rk.RateEngineCommonUtil;

/**
 * 季節別適用単価判定ビジネス
 *
 * @author "Nihon Unisys, Ltd."
 *
 */
public class ChargeUpBySeasonBusiness extends ChargeCalcBaseBusiness implements
    FeeCalcParts {
  /** ロガー */
  private static final Logger LOGGER = LogManager.getLogger();

  /** この部品がサポートする固定パラメータ数 */
  private static final int ARG_LENGTH = 7;

  /**
   * 季節別適用単価の判定を行う<br>
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された情報をもとに季節別適用単価リストを返却する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param args
   *          args[0]:Object 算定期間終了日<br>
   *          args[1]:Object 夏季期間開始日<br>
   *          args[2]:Object 夏季期間終了日<br>
   *          args[3]:Object 夏季段料金使用単価リスト<br>
   *          args[4]:Object その他季段料金使用単価リスト<br>
   *          args[5]:Object 夏季表示用名称2リスト<br>
   *          args[6]:Object その他季表示用名称2リスト<br>
   * @return 段料金使用単価リスト,適用単価[0],適用表示用名称2[0],...適用単価[N],適用表示用名称2[N]
   * @throws RateEngineException
   *           判定処理が継続不能な状態となった場合
   * @see RateEngineCommonUtil#checkArgsLength(Object...)
   * @see RateEngineCommonUtil#convertToDecimals(Object...)
   */
  @Override
  public Object[] calc(Object... args) throws RateEngineException {

    // 引数長チェック
    RateEngineCommonUtil.checkArgsLength(args, ARG_LENGTH);

    // パラメータをデバッグログ出力
    LOGGER.debug("算定期間終了日={} 夏季期間開始日={} 夏季期間終了日={} "
        + "夏季段料金使用単価リスト1...n={} その他季段料金使用単価リスト1...n={}"
        + "夏季表示用名称2リスト1...n={} その他季表示用名称2リスト1...n={}",
        args[ArrayIndex.ZERO.ordinal()], args[ArrayIndex.ONE.ordinal()],
        args[ArrayIndex.TWO.ordinal()], args[ArrayIndex.THREE.ordinal()],
        args[ArrayIndex.FOUR.ordinal()], args[ArrayIndex.FIVE.ordinal()],
        args[ArrayIndex.SIX.ordinal()]);

    // 夏季段料金使用単価リストを数値に変換
    BigDecimal[] summerSeasonUnitPriceList = RateEngineCommonUtil.convertToDecimals((Object[]) args[ArrayIndex.THREE.ordinal()]);

    // その他季段料金使用単価リストを数値に変換
    BigDecimal[] otherSeasonUnitPriceList = RateEngineCommonUtil
        .convertToDecimals((Object[]) args[ArrayIndex.FOUR.ordinal()]);

    // 算定期間終了日を文字列型に変換
    SimpleDateFormat sdf = new SimpleDateFormat(EMSConstants.FORMAT_DATE_yyyyMMdd);
    String calcEndDate = sdf.format((Date) args[ArrayIndex.ZERO.ordinal()]).substring(4, 8);

    // 夏季/その他季を判定する。
    if (((String) args[ArrayIndex.ONE.ordinal()]).compareTo(calcEndDate) <= 0 &&
        (calcEndDate).compareTo((String) args[ArrayIndex.TWO.ordinal()]) <= 0) {

      LOGGER.debug("判定結果={}", (Object[]) summerSeasonUnitPriceList);
      return setReturn(summerSeasonUnitPriceList, (Object[]) args[ArrayIndex.FIVE.ordinal()]);
    } else {
      // 結果を返却
      LOGGER.debug("判定結果={}", (Object[]) otherSeasonUnitPriceList);
      return setReturn(otherSeasonUnitPriceList, (Object[]) args[ArrayIndex.SIX.ordinal()]);
    }
  }

  /**
   * 返却値設定<br>
   *
   * @author "Nihon Unisys, Ltd."
   * @param unitPriceList:適用単価リスト
   * @param displayName2List:表示用名称2リスト
   * @return 段料金使用単価リスト,適用単価[0],適用表示用名称2[0],...適用単価[N],適用表示用名称2[N]
   */
  private Object[] setReturn(BigDecimal[] unitPriceList, Object[] displayName2List) {
    // 結果を返却
    Object[] returnVal = new Object[unitPriceList.length + displayName2List.length + 1];
    //リストを格納
    returnVal[ArrayIndex.ZERO.ordinal()] = unitPriceList;
    // 各単価を格納
    for (int i = 0; i < unitPriceList.length; i++) {
      int index = i * 2;
      returnVal[index + 1] = unitPriceList[i];
      returnVal[index + 2] = displayName2List[i].toString();
    }
    return returnVal;
  }

}
