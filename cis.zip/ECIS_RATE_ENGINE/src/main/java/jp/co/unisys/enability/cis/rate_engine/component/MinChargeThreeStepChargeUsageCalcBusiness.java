package jp.co.unisys.enability.cis.rate_engine.component;

import java.math.BigDecimal;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import jp.co.unisys.enability.cis.common.Exception.RateEngineException;
import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;
import jp.co.unisys.enability.cis.common.util.rk.RateEngineCommonUtil;

/**
 * 最低月額料金計算ビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class MinChargeThreeStepChargeUsageCalcBusiness extends ChargeCalcBaseBusiness implements FeeCalcParts {
  /** ロガー */
  private static final Logger LOGGER = LogManager.getLogger();

  /** この部品がサポートする固定パラメータ数 */
  private static final int ARG_LENGTH = 9;

  /**
   * 最低月額料金の計算を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された情報をもとに最低月額料金と電気料金（基本料金＋従量料金）を比較し、<br>
   * 月額料金（最低月額料金）を計算する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param args
   *          args[0]:Object 電気料金（基本料金＋従量料金）<br>
   *          args[1]:Object 最低月額料金<br>
   *          args[2]:Object 検針日数<br>
   *          args[3]:Object 日割日数<br>
   *          args[4]:Object 丸め桁（電気料金）<br>
   *          args[5]:Object 丸め方法（電気料金）<br>
   *          args[6]:Object 丸め桁（最低月額料金）<br>
   *          args[7]:Object 丸め方法（最低月額料金）<br>
   *          args[8]:Object 最低月額料金適用有無フラグ<br>
   * @return 算出結果(配列の要素数は2固定{月額料金，最低月額料金適用フラグ})
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   * @see RateEngineCommonUtil#checkArgsLength(Object...)
   * @see RateEngineCommonUtil#convertToDecimals(Object...)
   * @see RateEngineCommonUtil#convertStringToInt(Object...)
   * @see RateEngineCommonUtil#getRoundMode(Object...)
   */
  @Override
  public Object[] calc(Object... args) throws RateEngineException {
    // null許可リスト
    int nullPermitIndexs[] = {1, 0, 1, 1, 1, 1, 1, 1, 1 };

    // 引数チェック
    RateEngineCommonUtil.checkArgsLengthPermitNullVal(args, ARG_LENGTH, nullPermitIndexs);

    // 引数を変換
    BigDecimal[] decimals = RateEngineCommonUtil.convertToDecimals(args);

    // 日割り率設定
    super.setPerDiemRate(decimals[ArrayIndex.THREE.ordinal()], decimals[ArrayIndex.TWO.ordinal()]);

    // 電気料金（基本料金＋従量料金）の丸め
    BigDecimal lowestPrice = super.calcCharge(decimals[ArrayIndex.ONE.ordinal()],
        decimals[ArrayIndex.FOUR.ordinal()], decimals[ArrayIndex.FIVE.ordinal()]);

    Object[] result = null;
    // 最低月額料金
    if (ECISRKConstants.MONTHLY_MIN_FEE_APPLY.equals(String.valueOf(decimals[ArrayIndex.EIGHT.ordinal()]))) {
      // 従量料金をゼロに見立てて、トータルと比較して合計値を取得
      result = super.getTotalPrice(decimals[ArrayIndex.ZERO.ordinal()], BigDecimal.ZERO, lowestPrice,
          String.valueOf(decimals[ArrayIndex.EIGHT.ordinal()]), decimals[ArrayIndex.SIX.ordinal()],
          decimals[ArrayIndex.SEVEN.ordinal()]);
    } else {
      result = new Object[] {lowestPrice, lowestPrice, BigDecimal.ZERO, ECISRKConstants.MONTHLY_MIN_FEE_APPLY_NOT };
    }

    // デバッグ出力
    LOGGER.debug("算出結果={} 電力料金小計={} 日割り前最低月額料金={} 日割り後最低月額料金={} 日割日数={} 検針日数={} 最低月額料金適用有無={}",
        result[ArrayIndex.ZERO.ordinal()],
        decimals[ArrayIndex.ZERO.ordinal()],
        decimals[ArrayIndex.ONE.ordinal()], lowestPrice,
        decimals[ArrayIndex.THREE.ordinal()], decimals[ArrayIndex.TWO.ordinal()],
        result[ArrayIndex.THREE.ordinal()]);

    // 結果を返却
    return new Object[] {result[ArrayIndex.ZERO.ordinal()], result[ArrayIndex.THREE.ordinal()] };
  }
}
