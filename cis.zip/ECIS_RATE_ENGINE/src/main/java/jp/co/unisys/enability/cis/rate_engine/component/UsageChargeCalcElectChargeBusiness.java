package jp.co.unisys.enability.cis.rate_engine.component;

import java.math.BigDecimal;

import jp.co.unisys.enability.cis.common.Exception.RateEngineException;
import jp.co.unisys.enability.cis.common.util.rk.RateEngineCommonUtil;

/**
 * 従量料金計算発電料金ビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 */

public class UsageChargeCalcElectChargeBusiness extends ChargeCalcBaseBusiness implements FeeCalcParts {

  /** この部品がサポートする固定パラメータ数 */
  private static final int ARG_LENGTH = 20;

  /** -1(BigDecimal型) */
  private static final BigDecimal MINUS_ONE = new BigDecimal("-1");

  /**
   * 使用量（発電料金）の計算を行う。<br>
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された情報（発電量、発電買取単価）をもとに発電量料金の計算を行う。<br>
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param args[0]：Object
   *          発電量01<br>
   *          args[1]：Object 発電買取単価01<br>
   *          args[2]：Object 発電量02<br>
   *          args[3]：Object 発電買取単価02<br>
   *          args[4]：Object 発電量03<br>
   *          args[5]：Object 発電買取単価03<br>
   *          args[6]：Object 発電量04<br>
   *          args[7]：Object 発電買取単価04<br>
   *          args[8]：Object 発電量05<br>
   *          args[9]：Object 発電買取単価05<br>
   *          args[10]：Object 発電量06<br>
   *          args[11]：Object 発電買取単価06<br>
   *          args[12]：Object 発電量07<br>
   *          args[13]：Object 発電買取単価07<br>
   *          args[14]：Object 発電買取単価08<br>
   *          args[15]：Object 発電量08<br>
   *          args[16]：Object 発電買取単価09<br>
   *          args[17]：Object 発電量09<br>
   *          args[18]：Object 発電量10<br>
   *          args[19]：Object 発電買取単価10<br>
   * @return 発電料金計算結果リスト
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   * @see RateEngineCommonUtil#checkArgsLengthPermitNullVal(Object...)
   * @see RateEngineCommonUtil#convertToDecimals(Object...)
   */

  @Override
  public Object[] calc(Object... args) throws RateEngineException {

    // NULL許可リスト
    // 1 → 不可、0 → 許可
    int[] argsNullCheckIndex = new int[] {1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };

    // メソッド引数チェック
    RateEngineCommonUtil.checkArgsLengthPermitNullVal(args, ARG_LENGTH, argsNullCheckIndex);

    // BigDecimal型配列を作成し、メソッド引数をBigDecimal配列に詰め替え
    BigDecimal[] chargeAmountPrices = RateEngineCommonUtil.convertToDecimals(args);

    // 計算結果格納配列
    BigDecimal[] calcResult = new BigDecimal[] {BigDecimal.valueOf(0), BigDecimal.valueOf(0),
        BigDecimal.valueOf(0), BigDecimal.valueOf(0), BigDecimal.valueOf(0), BigDecimal.valueOf(0),
        BigDecimal.valueOf(0), BigDecimal.valueOf(0), BigDecimal.valueOf(0), BigDecimal.valueOf(0) };

    // 発電料金の計算
    int counter = 0;
    for (int index = 0; index < ARG_LENGTH; index += 2) {
      // 発電量×発電買取単価×-1
      calcResult[counter] = chargeAmountPrices[index].multiply(chargeAmountPrices[index + 1]).multiply(MINUS_ONE);
      counter++;
    }

    // 計算結果オブジェクトリストの生成、返却
    return new Object[] {calcResult[ArrayIndex.ZERO.ordinal()], calcResult[ArrayIndex.ONE.ordinal()],
        calcResult[ArrayIndex.TWO.ordinal()], calcResult[ArrayIndex.THREE.ordinal()],
        calcResult[ArrayIndex.FOUR.ordinal()], calcResult[ArrayIndex.FIVE.ordinal()],
        calcResult[ArrayIndex.SIX.ordinal()], calcResult[ArrayIndex.SEVEN.ordinal()],
        calcResult[ArrayIndex.EIGHT.ordinal()], calcResult[ArrayIndex.NINE.ordinal()] };
  }

}