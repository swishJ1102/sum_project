package jp.co.unisys.enability.cis.rate_engine.model;

import java.math.BigDecimal;
import java.util.Date;

/**
 * 計算後予備契約情報Bean。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class CalcReserveContractInfoBean {

  /**
   * 予備契約開始日を保有する。
   */
  private Date reserveContractStartDate;

  /**
   * 予備契約終了日を保有する。
   */
  private Date reserveContractEndDate;

  /**
   * 予備契約種別を保有する。
   */
  private String reserveContractClass;

  /**
   * 予備契約基本料金を保有する。
   */
  private BigDecimal reserveContractBasicCharge;

  /**
   * 日割前予備契約基本料金を保有する。
   */
  private BigDecimal dsRreserveContractBasicCharge;

  /**
   * 予備契約開始日のgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 予備契約開始日
   */
  public Date getReserveContractStartDate() {
    return this.reserveContractStartDate;
  }

  /**
   * 予備契約開始日のsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param reserveContractStartDate
   *          予備契約開始日
   */
  public void setReserveContractStartDate(Date reserveContractStartDate) {
    this.reserveContractStartDate = reserveContractStartDate;
  }

  /**
   * 予備契約終了日のgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 予備契約終了日
   */
  public Date getReserveContractEndDate() {
    return this.reserveContractEndDate;
  }

  /**
   * 予備契約終了日のsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param reserveContractEndDate
   *          予備契約終了日
   */
  public void setReserveContractEndDate(Date reserveContractEndDate) {
    this.reserveContractEndDate = reserveContractEndDate;
  }

  /**
   * 予備契約種別のgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 予備契約種別
   */
  public String getReserveContractClass() {
    return this.reserveContractClass;
  }

  /**
   * 予備契約種別のsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param reserveContractClass
   *          予備契約種別
   */
  public void setReserveContractClass(String reserveContractClass) {
    this.reserveContractClass = reserveContractClass;
  }

  /**
   * 予備契約基本料金のgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 予備契約基本料金
   */
  public BigDecimal getReserveContractBasicCharge() {
    return this.reserveContractBasicCharge;
  }

  /**
   * 予備契約基本料金のsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param reserveContractBasicCharge
   *          予備契約基本料金
   */
  public void setReserveContractBasicCharge(BigDecimal reserveContractBasicCharge) {
    this.reserveContractBasicCharge = reserveContractBasicCharge;
  }

  /**
   * 日割前予備契約基本料金のgetter
   *
   * @author "Nihon Unisys, Ltd."
   * @return 日割前予備契約基本料金
   */
  public BigDecimal getDsRreserveContractBasicCharge() {
    return this.dsRreserveContractBasicCharge;
  }

  /**
   * 日割前予備契約基本料金のsetter
   *
   * @author "Nihon Unisys, Ltd."
   * @param dsRreserveContractBasicCharge
   *          日割前予備契約基本料金
   */
  public void setDsRreserveContractBasicCharge(BigDecimal dsRreserveContractBasicCharge) {
    this.dsRreserveContractBasicCharge = dsRreserveContractBasicCharge;
  }

}
