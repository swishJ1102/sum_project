package jp.co.unisys.enability.cis.business.gk;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.context.MessageSource;

import jp.co.unisys.enability.cis.business.kj.model.ContractManagementInformationFileConfigCommon;
import jp.co.unisys.enability.cis.business.kj.model.ContractManagementInformationFileConfigContract;
import jp.co.unisys.enability.cis.common.util.CommonValidationUtil;
import jp.co.unisys.enability.cis.common.util.EMSMessageResource;

/**
 * バリデーション
 *
 * @author "Nihon Unisys, Ltd."
 */
public class ContractInformationFileRegistValidator {

  /** プロパティクラスを定義 */
  private MessageSource messageSource;

  /**
   * メッセージプロパティキー管理のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージプロパティキー管理を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param messageSource
   *          メッセージプロパティキー管理
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }

  /**
   * のバリデーションを実施、チェック結果のメッセージListを返却する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 1 引数のバリデーションを行う。
   * 2 チェック結果がNGの場合、戻り値のメッセージListにエラーメッセージを詰めて返却する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param args
   *          バッチ引数
   * @return メッセージList
   */
  public List<String> validate(Map<Integer, String> dataRecode) {

    List<String> messageList = new ArrayList<String>();

    String dataRecordClass = dataRecode
        .get(ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_INDEX);
    // データレコード種別：必須チェック
    if (CommonValidationUtil.isNull(dataRecordClass)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_NAME },
                  Locale.getDefault()));

      // データレコード種別：正規表現チェック
    } else if (dataRecordClass != null
        && !CommonValidationUtil
            .checkByPattern(
                dataRecordClass,
                ContractManagementInformationFileConfigCommon.DATA_KIND_MASK_STRING)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_ITEM_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_NAME },
                  Locale.getDefault()));
    }

    String contractNo = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_CONTRACT_NO_INDEX);
    // 契約番号：必須チェック
    if (CommonValidationUtil.isNull(contractNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_NO_NAME },
                  Locale.getDefault()));

      // 契約番号：文字種別チェック（半角英数字）
    } else if (contractNo != null
        && !CommonValidationUtil.isAlphabetNumric(contractNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_ALPHANUMERIC_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_NO_NAME },
                  Locale.getDefault()));

      // 契約番号：文字種別チェック（半角英数字　低圧CISシステム許容文字）
    } else if (contractNo != null
        && !CommonValidationUtil.isRangeWordByECIS(contractNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_NO_NAME,
                      "半角英数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 契約番号：文字列最大長チェック
    } else if (contractNo != null
        && !CommonValidationUtil
            .maxLength(
                contractNo,
                ContractManagementInformationFileConfigContract.DATA_CONTRACT_NO_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_NO_NAME,
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_NO_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String contractorNo = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_CONTRACTOR_NO_INDEX);
    // 契約者番号：必須チェック
    if (CommonValidationUtil.isNull(contractorNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONTRACTOR_NO_NAME },
                  Locale.getDefault()));

      // 契約者番号：文字種別チェック（半角英数字）
    } else if (contractorNo != null
        && !CommonValidationUtil.isAlphabetNumric(contractorNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_ALPHANUMERIC_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONTRACTOR_NO_NAME },
                  Locale.getDefault()));

      // 契約者番号：文字種別チェック（半角英数字　低圧CISシステム許容文字）
    } else if (contractorNo != null
        && !CommonValidationUtil.isRangeWordByECIS(contractorNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONTRACTOR_NO_NAME,
                      "半角英数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 契約者番号：文字列最大長チェック
    } else if (contractorNo != null
        && !CommonValidationUtil
            .maxLength(
                contractorNo,
                ContractManagementInformationFileConfigContract.DATA_CONTRACTOR_NO_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONTRACTOR_NO_NAME,
                      ContractManagementInformationFileConfigContract.DATA_CONTRACTOR_NO_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String paymentNo = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_PAYMENT_NO_INDEX);
    // 支払番号：必須チェック
    if (CommonValidationUtil.isNull(paymentNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_PAYMENT_NO_NAME },
                  Locale.getDefault()));

      // 支払番号：文字種別チェック（半角英数字）
    } else if (paymentNo != null
        && !CommonValidationUtil.isAlphabetNumric(paymentNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_ALPHANUMERIC_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_PAYMENT_NO_NAME },
                  Locale.getDefault()));

      // 支払番号：文字種別チェック（半角英数字　低圧CISシステム許容文字）
    } else if (paymentNo != null
        && !CommonValidationUtil.isRangeWordByECIS(paymentNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_PAYMENT_NO_NAME,
                      "半角英数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 支払番号：文字列最大長チェック
    } else if (paymentNo != null
        && !CommonValidationUtil
            .maxLength(
                paymentNo,
                ContractManagementInformationFileConfigContract.DATA_PAYMENT_NO_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_PAYMENT_NO_NAME,
                      ContractManagementInformationFileConfigContract.DATA_PAYMENT_NO_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String meterLocationId = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_METER_LOCATION_ID_INDEX);
    // メータ設置場所ID：必須チェック
    if (CommonValidationUtil.isNull(meterLocationId)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_METER_LOCATION_ID_NAME },
                  Locale.getDefault()));

      // メータ設置場所ID：文字種別チェック（半角数字）
    } else if (meterLocationId != null
        && !CommonValidationUtil
            .isNumric(meterLocationId)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_METER_LOCATION_ID_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // メータ設置場所ID：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (meterLocationId != null
        && !CommonValidationUtil
            .isRangeWordByECIS(meterLocationId)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_METER_LOCATION_ID_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // メータ設置場所ID：数値範囲チェック
    } else if (meterLocationId != null
        && !CommonValidationUtil.checkRange(meterLocationId, 1,
            2147483647)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_RANGE_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_METER_LOCATION_ID_NAME,
                      "1～2147483647" },
                  Locale.getDefault()));
    }

    String contractGroupNo = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_CONTRACT_GROUP_NO_INDEX);
    // 契約グループ番号：文字種別チェック（半角英数字）
    if (contractGroupNo != null
        && !CommonValidationUtil.isAlphabetNumric(contractGroupNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_ALPHANUMERIC_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_GROUP_NO_NAME },
                  Locale.getDefault()));

      // 契約グループ番号：文字種別チェック（半角英数字　低圧CISシステム許容文字）
    } else if (contractGroupNo != null
        && !CommonValidationUtil.isRangeWordByECIS(contractGroupNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_GROUP_NO_NAME,
                      "半角英数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 契約グループ番号：文字列最大長チェック
    } else if (contractGroupNo != null
        && !CommonValidationUtil
            .maxLength(
                contractGroupNo,
                ContractManagementInformationFileConfigContract.DATA_CONTRACT_GROUP_NO_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_GROUP_NO_NAME,
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_GROUP_NO_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String contractStartDate = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_CONTRACT_START_DATE_INDEX);
    // 契約開始日：必須チェック
    if (CommonValidationUtil.isNull(contractStartDate)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_START_DATE_NAME },
                  Locale.getDefault()));

      // 契約開始日：日付フォーマットチェック
    } else if (contractStartDate != null
        && !CommonValidationUtil.checkDateFormat(contractStartDate,
            "yyyy/MM/dd")) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_START_DATE_NAME,
                      "日付形式（yyyy/MM/dd）" },
                  Locale.getDefault()));
    }

    String contractEndDate = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_CONTRACT_END_DATE_INDEX);
    // 契約終了日：日付フォーマットチェック
    if (contractEndDate != null
        && !CommonValidationUtil.checkDateFormat(contractEndDate,
            "yyyy/MM/dd")) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_END_DATE_NAME,
                      "日付形式（yyyy/MM/dd）" },
                  Locale.getDefault()));
    }

    String consignmentContractCapacity = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_CONTRACT_CAPACITY_INDEX);
    // 託送契約容量：数値フォーマットチェック
    if (consignmentContractCapacity != null
        && !CommonValidationUtil.checkByPattern(
            consignmentContractCapacity,
            "^(([1-9][0-9]*|0){1}(\\.[0-9]+)?)?$")) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_CONTRACT_CAPACITY_NAME,
                      "数値形式（マイナス符号：否、カンマ：否、小数：可）" },
                  Locale.getDefault()));

      // 託送契約容量：数値桁数チェック
    } else if (consignmentContractCapacity != null
        && !CommonValidationUtil
            .checkBigDecimalDigit(
                consignmentContractCapacity,
                ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_CONTRACT_CAPACITY_DIGIT_INTEGER,
                ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_CONTRACT_CAPACITY_DIGIT_FLOAT)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MONEYRANGE,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_CONTRACT_CAPACITY_NAME,
                      ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_CONTRACT_CAPACITY_DIGIT_INTEGER_STRING,
                      ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_CONTRACT_CAPACITY_DIGIT_FLOAT_STRING },
                  Locale.getDefault()));
    }

    String consignmentContractCapacityDecisionDate = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_CONTRACT_CAPACITY_DECISION_DATE_INDEX);
    // 託送契約容量判定日：日付フォーマットチェック
    if (consignmentContractCapacityDecisionDate != null
        && !CommonValidationUtil.checkDateFormat(
            consignmentContractCapacityDecisionDate, "yyyy/MM/dd")) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_CONTRACT_CAPACITY_DECISION_DATE_NAME,
                      "日付形式（yyyy/MM/dd）" },
                  Locale.getDefault()));
    }

    String chargeCheckFlag = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_CHARGE_CHECK_FLAG_INDEX);
    // 料金チェックフラグ：必須チェック
    if (CommonValidationUtil.isNull(chargeCheckFlag)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CHARGE_CHECK_FLAG_NAME },
                  Locale.getDefault()));

      // 料金チェックフラグ：文字種別チェック（半角数字）
    } else if (chargeCheckFlag != null
        && !CommonValidationUtil
            .isNumric(chargeCheckFlag)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CHARGE_CHECK_FLAG_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 料金チェックフラグ：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (chargeCheckFlag != null
        && !CommonValidationUtil
            .isRangeWordByECIS(chargeCheckFlag)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CHARGE_CHECK_FLAG_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 料金チェックフラグ：数値範囲チェック
    } else if (chargeCheckFlag != null
        && !CommonValidationUtil.checkRange(chargeCheckFlag, 0, 1)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_RANGE_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CHARGE_CHECK_FLAG_NAME,
                      "0～1" },
                  Locale.getDefault()));
    }

    String contractInformationNameKana = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_NAME_KANA_INDEX);
    // 連絡先氏名（カナ）：文字列最大長チェック
    if (contractInformationNameKana != null
        && !CommonValidationUtil
            .maxLength(
                contractInformationNameKana,
                ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_NAME_KANA_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_NAME_KANA_NAME,
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_NAME_KANA_LENGTH_STRING },
                  Locale.getDefault()));

      // 連絡先氏名（カナ）：正規表現チェック
    } else if (contractInformationNameKana != null
        && !CommonValidationUtil.checkByPattern(
            contractInformationNameKana, "^[０-９Ａ-Ｚａ-ｚァ-ヶー（）－　]+$")) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_ITEM_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_NAME_KANA_NAME },
                  Locale.getDefault()));
    }

    String contractInformationName1 = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_NAME1_INDEX);
    // 連絡先氏名1：文字種別チェック（全角）
    if (contractInformationName1 != null
        && !CommonValidationUtil
            .isZenkakuType(contractInformationName1)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_NAME1_NAME },
                  Locale.getDefault()));

      // 連絡先氏名1：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (contractInformationName1 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(contractInformationName1)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_NAME1_NAME,
                      "全角（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 連絡先氏名1：文字列最大長チェック
    } else if (contractInformationName1 != null
        && !CommonValidationUtil
            .maxLength(
                contractInformationName1,
                ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_NAME1_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_NAME1_NAME,
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_NAME1_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String contractInformationName2 = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_NAME2_INDEX);
    // 連絡先氏名2：文字種別チェック（全角）
    if (contractInformationName2 != null
        && !CommonValidationUtil
            .isZenkakuType(contractInformationName2)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_NAME2_NAME },
                  Locale.getDefault()));

      // 連絡先氏名2：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (contractInformationName2 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(contractInformationName2)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_NAME2_NAME,
                      "全角（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 連絡先氏名2：文字列最大長チェック
    } else if (contractInformationName2 != null
        && !CommonValidationUtil
            .maxLength(
                contractInformationName2,
                ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_NAME2_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_NAME2_NAME,
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_NAME2_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String contractInformationAddressPostalCode = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_ADDRESS_POSTAL_CODE_INDEX);
    // 連絡先住所（郵便番号）：文字種別チェック（半角数字）
    if (contractInformationAddressPostalCode != null
        && !CommonValidationUtil
            .isNumric(contractInformationAddressPostalCode)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_ADDRESS_POSTAL_CODE_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 連絡先住所（郵便番号）：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (contractInformationAddressPostalCode != null
        && !CommonValidationUtil
            .isRangeWordByECIS(contractInformationAddressPostalCode)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_ADDRESS_POSTAL_CODE_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 連絡先住所（郵便番号）：文字列指定長チェック
    } else if (StringUtils.isNotEmpty(contractInformationAddressPostalCode)
        && !CommonValidationUtil
            .justLength(
                contractInformationAddressPostalCode,
                ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_ADDRESS_POSTAL_CODE_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_STRINGLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_ADDRESS_POSTAL_CODE_NAME,
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_ADDRESS_POSTAL_CODE_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String contractInformationAddressFull = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_ADDRESS_FULL_INDEX);
    // 連絡先住所（住所）：文字種別チェック（低圧CISシステム許容文字）
    if (contractInformationAddressFull != null
        && !CommonValidationUtil
            .isRangeWordByECIS(contractInformationAddressFull)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_ADDRESS_FULL_NAME,
                      "低圧CISシステム許容文字" },
                  Locale.getDefault()));
      // 連絡先住所（住所）：文字列最大長チェック
    } else if (contractInformationAddressFull != null
        && !CommonValidationUtil
            .maxLength(
                contractInformationAddressFull,
                ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_ADDRESS_FULL_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_ADDRESS_FULL_NAME,
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_ADDRESS_FULL_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String contractInformationAddressBuilding = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_ADDRESS_BUILDING_INDEX);
    // 連絡先住所（建物・部屋名）：文字種別チェック（全角）
    if (contractInformationAddressBuilding != null
        && !CommonValidationUtil
            .isZenkakuType(contractInformationAddressBuilding)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_ADDRESS_BUILDING_NAME },
                  Locale.getDefault()));

      // 連絡先住所（建物・部屋名）：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (contractInformationAddressBuilding != null
        && !CommonValidationUtil
            .isRangeWordByECIS(contractInformationAddressBuilding)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_ADDRESS_BUILDING_NAME,
                      "全角（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 連絡先住所（建物・部屋名）：文字列最大長チェック
    } else if (contractInformationAddressBuilding != null
        && !CommonValidationUtil
            .maxLength(
                contractInformationAddressBuilding,
                ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_ADDRESS_BUILDING_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_ADDRESS_BUILDING_NAME,
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_ADDRESS_BUILDING_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String contractInformationAreaCode = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_AREA_CODE_INDEX);
    // 連絡先電話（市外局番）：文字種別チェック（半角数字）
    if (contractInformationAreaCode != null
        && !CommonValidationUtil.isNumric(contractInformationAreaCode)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_AREA_CODE_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 連絡先電話（市外局番）：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (contractInformationAreaCode != null
        && !CommonValidationUtil
            .isRangeWordByECIS(contractInformationAreaCode)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_AREA_CODE_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 連絡先電話（市外局番）：文字列最大長チェック
    } else if (contractInformationAreaCode != null
        && !CommonValidationUtil
            .maxLength(
                contractInformationAreaCode,
                ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_AREA_CODE_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_AREA_CODE_NAME,
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_AREA_CODE_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String contractInformationLocalNo = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_LOCAL_NO_INDEX);
    // 連絡先電話（市内局番）：文字種別チェック（半角数字）
    if (contractInformationLocalNo != null
        && !CommonValidationUtil.isNumric(contractInformationLocalNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_AREA_CODE_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 連絡先電話（市内局番）：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (contractInformationLocalNo != null
        && !CommonValidationUtil
            .isRangeWordByECIS(contractInformationLocalNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_AREA_CODE_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 連絡先電話（市内局番）：文字列最大長チェック
    } else if (contractInformationLocalNo != null
        && !CommonValidationUtil
            .maxLength(
                contractInformationLocalNo,
                ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_LOCAL_NO_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_AREA_CODE_NAME,
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_LOCAL_NO_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String contractInformationDirectoryNo = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_DIRECTORY_NO_INDEX);
    // 連絡先電話（加入者番号）：文字種別チェック（半角数字）
    if (contractInformationDirectoryNo != null
        && !CommonValidationUtil
            .isNumric(contractInformationDirectoryNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_DIRECTORY_NO_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 連絡先電話（加入者番号）：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (contractInformationDirectoryNo != null
        && !CommonValidationUtil
            .isRangeWordByECIS(contractInformationDirectoryNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_DIRECTORY_NO_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 連絡先電話（加入者番号）：文字列最大長チェック
    } else if (contractInformationDirectoryNo != null
        && !CommonValidationUtil
            .maxLength(
                contractInformationDirectoryNo,
                ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_DIRECTORY_NO_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_DIRECTORY_NO_NAME,
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_DIRECTORY_NO_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String consumerContractAffiliation = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_AFFILIATION_INDEX);
    // 需要者窓口連絡先所属：文字種別チェック（全角）
    if (consumerContractAffiliation != null
        && !CommonValidationUtil
            .isZenkakuType(consumerContractAffiliation)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_AFFILIATION_NAME },
                  Locale.getDefault()));

      // 需要者窓口連絡先所属：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (consumerContractAffiliation != null
        && !CommonValidationUtil
            .isRangeWordByECIS(consumerContractAffiliation)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_AFFILIATION_NAME,
                      "全角（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 需要者窓口連絡先所属：文字列最大長チェック
    } else if (consumerContractAffiliation != null
        && !CommonValidationUtil
            .maxLength(
                consumerContractAffiliation,
                ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_AFFILIATION_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_AFFILIATION_NAME,
                      ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_AFFILIATION_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String consumerContractName = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_NAME_INDEX);
    // 需要者窓口連絡先氏名：文字種別チェック（全角）
    if (consumerContractName != null
        && !CommonValidationUtil
            .isZenkakuType(consumerContractName)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_NAME_NAME },
                  Locale.getDefault()));

      // 需要者窓口連絡先氏名：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (consumerContractName != null
        && !CommonValidationUtil
            .isRangeWordByECIS(consumerContractName)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_NAME_NAME,
                      "全角（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 需要者窓口連絡先氏名：文字列最大長チェック
    } else if (consumerContractName != null
        && !CommonValidationUtil
            .maxLength(
                consumerContractName,
                ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_NAME_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_NAME_NAME,
                      ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_NAME_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String consumerContractAreaCode = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_AREA_CODE_INDEX);
    // 需要者窓口連絡先電話番号（市外局番）：文字種別チェック（半角数字）
    if (consumerContractAreaCode != null
        && !CommonValidationUtil.isNumric(consumerContractAreaCode)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_AREA_CODE_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 需要者窓口連絡先電話番号（市外局番）：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (consumerContractAreaCode != null
        && !CommonValidationUtil
            .isRangeWordByECIS(consumerContractAreaCode)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_AREA_CODE_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 需要者窓口連絡先電話番号（市外局番）：文字列最大長チェック
    } else if (consumerContractAreaCode != null
        && !CommonValidationUtil
            .maxLength(
                consumerContractAreaCode,
                ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_AREA_CODE_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_AREA_CODE_NAME,
                      ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_AREA_CODE_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String consumerContractLocalNo = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_LOCAL_NO_INDEX);
    // 需要者窓口連絡先電話番号（市内局番）：文字種別チェック（半角数字）
    if (consumerContractLocalNo != null
        && !CommonValidationUtil.isNumric(consumerContractLocalNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_AREA_CODE_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 需要者窓口連絡先電話番号（市内局番）：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (consumerContractLocalNo != null
        && !CommonValidationUtil
            .isRangeWordByECIS(consumerContractLocalNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_AREA_CODE_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 需要者窓口連絡先電話番号（市内局番）：文字列最大長チェック
    } else if (consumerContractLocalNo != null
        && !CommonValidationUtil
            .maxLength(
                consumerContractLocalNo,
                ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_LOCAL_NO_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_AREA_CODE_NAME,
                      ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_LOCAL_NO_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String consumerContractDirectoryNo = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_DIRECTORY_NO_INDEX);
    // 需要者窓口連絡先電話番号（加入者番号）：文字種別チェック（半角数字）
    if (consumerContractDirectoryNo != null
        && !CommonValidationUtil
            .isNumric(consumerContractDirectoryNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_DIRECTORY_NO_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 需要者窓口連絡先電話番号（加入者番号）：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (consumerContractDirectoryNo != null
        && !CommonValidationUtil
            .isRangeWordByECIS(consumerContractDirectoryNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_DIRECTORY_NO_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 需要者窓口連絡先電話番号（加入者番号）：文字列最大長チェック
    } else if (consumerContractDirectoryNo != null
        && !CommonValidationUtil
            .maxLength(
                consumerContractDirectoryNo,
                ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_DIRECTORY_NO_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_DIRECTORY_NO_NAME,
                      ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_DIRECTORY_NO_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String chiefEngineerOfficerAffiliation = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_AFFILIATION_INDEX);
    // 主任技術者連絡先所属：文字種別チェック（全角）
    if (chiefEngineerOfficerAffiliation != null
        && !CommonValidationUtil
            .isZenkakuType(chiefEngineerOfficerAffiliation)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_AFFILIATION_NAME },
                  Locale.getDefault()));

      // 主任技術者連絡先所属：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (chiefEngineerOfficerAffiliation != null
        && !CommonValidationUtil
            .isRangeWordByECIS(chiefEngineerOfficerAffiliation)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_AFFILIATION_NAME,
                      "全角（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 主任技術者連絡先所属：文字列最大長チェック
    } else if (chiefEngineerOfficerAffiliation != null
        && !CommonValidationUtil
            .maxLength(
                chiefEngineerOfficerAffiliation,
                ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_AFFILIATION_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_AFFILIATION_NAME,
                      ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_AFFILIATION_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String chiefEngineerOfficerName = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_NAME_INDEX);
    // 主任技術者連絡先氏名：文字種別チェック（全角）
    if (chiefEngineerOfficerName != null
        && !CommonValidationUtil
            .isZenkakuType(chiefEngineerOfficerName)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_NAME_NAME },
                  Locale.getDefault()));

      // 主任技術者連絡先氏名：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (chiefEngineerOfficerName != null
        && !CommonValidationUtil
            .isRangeWordByECIS(chiefEngineerOfficerName)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_NAME_NAME,
                      "全角（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 主任技術者連絡先氏名：文字列最大長チェック
    } else if (chiefEngineerOfficerName != null
        && !CommonValidationUtil
            .maxLength(
                chiefEngineerOfficerName,
                ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_NAME_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_NAME_NAME,
                      ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_NAME_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String chiefEngineerOfficerAreaCode = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_AREA_CODE_INDEX);
    // 主任技術者連絡先電話番号（市外局番）：文字種別チェック（半角数字）
    if (chiefEngineerOfficerAreaCode != null
        && !CommonValidationUtil.isNumric(chiefEngineerOfficerAreaCode)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_AREA_CODE_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 主任技術者連絡先電話番号（市外局番）：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (chiefEngineerOfficerAreaCode != null
        && !CommonValidationUtil
            .isRangeWordByECIS(chiefEngineerOfficerAreaCode)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_AREA_CODE_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 主任技術者連絡先電話番号（市外局番）：文字列最大長チェック
    } else if (chiefEngineerOfficerAreaCode != null
        && !CommonValidationUtil
            .maxLength(
                chiefEngineerOfficerAreaCode,
                ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_AREA_CODE_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_AREA_CODE_NAME,
                      ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_AREA_CODE_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String chiefEngineerOfficerLocalNo = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_LOCAL_NO_INDEX);
    // 主任技術者連絡先電話番号（市内局番）：文字種別チェック（半角数字）
    if (chiefEngineerOfficerLocalNo != null
        && !CommonValidationUtil.isNumric(chiefEngineerOfficerLocalNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_AREA_CODE_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 主任技術者連絡先電話番号（市内局番）：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (chiefEngineerOfficerLocalNo != null
        && !CommonValidationUtil
            .isRangeWordByECIS(chiefEngineerOfficerLocalNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_AREA_CODE_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 主任技術者連絡先電話番号（市内局番）：文字列最大長チェック
    } else if (chiefEngineerOfficerLocalNo != null
        && !CommonValidationUtil
            .maxLength(
                chiefEngineerOfficerLocalNo,
                ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_LOCAL_NO_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_AREA_CODE_NAME,
                      ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_LOCAL_NO_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String chiefEngineerOfficerDirectoryNo = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_DIRECTORY_NO_INDEX);
    // 主任技術者連絡先電話番号（加入者番号）：文字種別チェック（半角数字）
    if (chiefEngineerOfficerDirectoryNo != null
        && !CommonValidationUtil
            .isNumric(chiefEngineerOfficerDirectoryNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_DIRECTORY_NO_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 主任技術者連絡先電話番号（加入者番号）：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (chiefEngineerOfficerDirectoryNo != null
        && !CommonValidationUtil
            .isRangeWordByECIS(chiefEngineerOfficerDirectoryNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_DIRECTORY_NO_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 主任技術者連絡先電話番号（加入者番号）：文字列最大長チェック
    } else if (chiefEngineerOfficerDirectoryNo != null
        && !CommonValidationUtil
            .maxLength(
                chiefEngineerOfficerDirectoryNo,
                ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_DIRECTORY_NO_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_DIRECTORY_NO_NAME,
                      ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_DIRECTORY_NO_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String note = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_NOTE_INDEX);
    // 備考：文字種別チェック（低圧CISシステム許容文字）
    if (note != null
        && !CommonValidationUtil
            .isRangeWordByECIS(note)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_NOTE_NAME,
                      "低圧CISシステム許容文字" },
                  Locale.getDefault()));
      // 備考：文字列最大長チェック
    } else if (note != null
        && !CommonValidationUtil
            .maxLength(
                note,
                ContractManagementInformationFileConfigContract.DATA_NOTE_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_NOTE_NAME,
                      ContractManagementInformationFileConfigContract.DATA_NOTE_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String free1 = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_FREE1_INDEX);
    // フリー項目1：文字種別チェック（低圧CISシステム許容文字）
    if (free1 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(free1)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_FREE1_NAME,
                      "低圧CISシステム許容文字" },
                  Locale.getDefault()));
      // フリー項目1：文字列最大長チェック
    } else if (free1 != null
        && !CommonValidationUtil
            .maxLength(
                free1,
                ContractManagementInformationFileConfigContract.DATA_FREE1_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_FREE1_NAME,
                      ContractManagementInformationFileConfigContract.DATA_FREE1_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String free2 = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_FREE2_INDEX);
    // フリー項目2：文字種別チェック（低圧CISシステム許容文字）
    if (free2 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(free2)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_FREE2_NAME,
                      "低圧CISシステム許容文字" },
                  Locale.getDefault()));
      // フリー項目2：文字列最大長チェック
    } else if (free2 != null
        && !CommonValidationUtil
            .maxLength(
                free2,
                ContractManagementInformationFileConfigContract.DATA_FREE2_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_FREE2_NAME,
                      ContractManagementInformationFileConfigContract.DATA_FREE2_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String free3 = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_FREE3_INDEX);
    // フリー項目3：文字種別チェック（低圧CISシステム許容文字）
    if (free3 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(free3)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_FREE3_NAME,
                      "低圧CISシステム許容文字" },
                  Locale.getDefault()));
      // フリー項目3：文字列最大長チェック
    } else if (free3 != null
        && !CommonValidationUtil
            .maxLength(
                free3,
                ContractManagementInformationFileConfigContract.DATA_FREE3_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_FREE3_NAME,
                      ContractManagementInformationFileConfigContract.DATA_FREE3_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String free4 = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_FREE4_INDEX);
    // フリー項目4：文字種別チェック（低圧CISシステム許容文字）
    if (free4 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(free4)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_FREE4_NAME,
                      "低圧CISシステム許容文字" },
                  Locale.getDefault()));
      // フリー項目4：文字列最大長チェック
    } else if (free4 != null
        && !CommonValidationUtil
            .maxLength(
                free4,
                ContractManagementInformationFileConfigContract.DATA_FREE4_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_FREE4_NAME,
                      ContractManagementInformationFileConfigContract.DATA_FREE4_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String free5 = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_FREE5_INDEX);
    // フリー項目5：文字種別チェック（低圧CISシステム許容文字）
    if (free5 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(free5)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_FREE5_NAME,
                      "低圧CISシステム許容文字" },
                  Locale.getDefault()));
      // フリー項目5：文字列最大長チェック
    } else if (free5 != null
        && !CommonValidationUtil
            .maxLength(
                free5,
                ContractManagementInformationFileConfigContract.DATA_FREE5_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_FREE5_NAME,
                      ContractManagementInformationFileConfigContract.DATA_FREE5_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String free6 = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_FREE6_INDEX);
    // フリー項目6：文字種別チェック（低圧CISシステム許容文字）
    if (free6 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(free6)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_FREE6_NAME,
                      "低圧CISシステム許容文字" },
                  Locale.getDefault()));
      // フリー項目6：文字列最大長チェック
    } else if (free6 != null
        && !CommonValidationUtil
            .maxLength(
                free6,
                ContractManagementInformationFileConfigContract.DATA_FREE6_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_FREE6_NAME,
                      ContractManagementInformationFileConfigContract.DATA_FREE6_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String free7 = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_FREE7_INDEX);
    // フリー項目7：文字種別チェック（低圧CISシステム許容文字）
    if (free7 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(free7)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_FREE7_NAME,
                      "低圧CISシステム許容文字" },
                  Locale.getDefault()));
      // フリー項目7：文字列最大長チェック
    } else if (free7 != null
        && !CommonValidationUtil
            .maxLength(
                free7,
                ContractManagementInformationFileConfigContract.DATA_FREE7_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_FREE7_NAME,
                      ContractManagementInformationFileConfigContract.DATA_FREE7_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String free8 = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_FREE8_INDEX);
    // フリー項目8：文字種別チェック（低圧CISシステム許容文字）
    if (free8 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(free8)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_FREE8_NAME,
                      "低圧CISシステム許容文字" },
                  Locale.getDefault()));
      // フリー項目8：文字列最大長チェック
    } else if (free8 != null
        && !CommonValidationUtil
            .maxLength(
                free8,
                ContractManagementInformationFileConfigContract.DATA_FREE8_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_FREE8_NAME,
                      ContractManagementInformationFileConfigContract.DATA_FREE8_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String free9 = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_FREE9_INDEX);
    // フリー項目9：文字種別チェック（低圧CISシステム許容文字）
    if (free9 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(free9)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_FREE9_NAME,
                      "低圧CISシステム許容文字" },
                  Locale.getDefault()));
      // フリー項目9：文字列最大長チェック
    } else if (free9 != null
        && !CommonValidationUtil
            .maxLength(
                free9,
                ContractManagementInformationFileConfigContract.DATA_FREE9_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_FREE9_NAME,
                      ContractManagementInformationFileConfigContract.DATA_FREE9_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String free10 = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_FREE10_INDEX);
    // フリー項目10：文字種別チェック（低圧CISシステム許容文字）
    if (free10 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(free10)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_FREE10_NAME,
                      "低圧CISシステム許容文字" },
                  Locale.getDefault()));
      // フリー項目10：文字列最大長チェック
    } else if (free10 != null
        && !CommonValidationUtil
            .maxLength(
                free10,
                ContractManagementInformationFileConfigContract.DATA_FREE10_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_FREE10_NAME,
                      ContractManagementInformationFileConfigContract.DATA_FREE10_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String free11 = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_FREE11_INDEX);
    // フリー項目11：文字種別チェック（低圧CISシステム許容文字）
    if (free11 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(free11)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_FREE11_NAME,
                      "低圧CISシステム許容文字" },
                  Locale.getDefault()));
      // フリー項目11：文字列最大長チェック
    } else if (free11 != null
        && !CommonValidationUtil
            .maxLength(
                free11,
                ContractManagementInformationFileConfigContract.DATA_FREE11_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_FREE11_NAME,
                      ContractManagementInformationFileConfigContract.DATA_FREE11_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String free12 = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_FREE12_INDEX);
    // フリー項目12：文字種別チェック（低圧CISシステム許容文字）
    if (free12 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(free12)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_FREE12_NAME,
                      "低圧CISシステム許容文字" },
                  Locale.getDefault()));
      // フリー項目12：文字列最大長チェック
    } else if (free12 != null
        && !CommonValidationUtil
            .maxLength(
                free12,
                ContractManagementInformationFileConfigContract.DATA_FREE12_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_FREE12_NAME,
                      ContractManagementInformationFileConfigContract.DATA_FREE12_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String free13 = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_FREE13_INDEX);
    // フリー項目13：文字種別チェック（低圧CISシステム許容文字）
    if (free13 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(free13)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_FREE13_NAME,
                      "低圧CISシステム許容文字" },
                  Locale.getDefault()));
      // フリー項目13：文字列最大長チェック
    } else if (free13 != null
        && !CommonValidationUtil
            .maxLength(
                free13,
                ContractManagementInformationFileConfigContract.DATA_FREE13_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_FREE13_NAME,
                      ContractManagementInformationFileConfigContract.DATA_FREE13_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String free14 = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_FREE14_INDEX);
    // フリー項目14：文字種別チェック（低圧CISシステム許容文字）
    if (free14 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(free14)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_FREE14_NAME,
                      "低圧CISシステム許容文字" },
                  Locale.getDefault()));
      // フリー項目14：文字列最大長チェック
    } else if (free14 != null
        && !CommonValidationUtil
            .maxLength(
                free14,
                ContractManagementInformationFileConfigContract.DATA_FREE14_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_FREE14_NAME,
                      ContractManagementInformationFileConfigContract.DATA_FREE14_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String consignmentUseItem1 = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_USE_ITEM1_INDEX);
    // 委託先使用項目1：文字種別チェック（低圧CISシステム許容文字）
    if (consignmentUseItem1 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(consignmentUseItem1)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_USE_ITEM1_NAME,
                      "低圧CISシステム許容文字" },
                  Locale.getDefault()));
      // 委託先使用項目1：文字列最大長チェック
    } else if (consignmentUseItem1 != null
        && !CommonValidationUtil
            .maxLength(
                consignmentUseItem1,
                ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_USE_ITEM1_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_USE_ITEM1_NAME,
                      ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_USE_ITEM1_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String consignmentUseItem2 = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_USE_ITEM2_INDEX);
    // 委託先使用項目2：文字種別チェック（低圧CISシステム許容文字）
    if (consignmentUseItem2 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(consignmentUseItem2)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_USE_ITEM2_NAME,
                      "低圧CISシステム許容文字" },
                  Locale.getDefault()));
      // 委託先使用項目2：文字列最大長チェック
    } else if (consignmentUseItem2 != null
        && !CommonValidationUtil
            .maxLength(
                consignmentUseItem2,
                ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_USE_ITEM2_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_USE_ITEM2_NAME,
                      ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_USE_ITEM2_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String consignmentUseItem3 = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_USE_ITEM3_INDEX);
    // 委託先使用項目3：文字種別チェック（低圧CISシステム許容文字）
    if (consignmentUseItem3 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(consignmentUseItem3)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_USE_ITEM3_NAME,
                      "低圧CISシステム許容文字" },
                  Locale.getDefault()));
      // 委託先使用項目3：文字列最大長チェック
    } else if (consignmentUseItem3 != null
        && !CommonValidationUtil
            .maxLength(
                consignmentUseItem3,
                ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_USE_ITEM3_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_USE_ITEM3_NAME,
                      ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_USE_ITEM3_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String ourManagementPersonInChargeCode = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_OUR_MANAGEMENT_PERSON_IN_CHARGE_CODE_INDEX);
    // 自社担当者コード：文字種別チェック（半角英数字）
    if (ourManagementPersonInChargeCode != null
        && !CommonValidationUtil
            .isAlphabetNumric(ourManagementPersonInChargeCode)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_ALPHANUMERIC_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_OUR_MANAGEMENT_PERSON_IN_CHARGE_CODE_NAME },
                  Locale.getDefault()));

      // 自社担当者コード：文字種別チェック（半角英数字　低圧CISシステム許容文字）
    } else if (ourManagementPersonInChargeCode != null
        && !CommonValidationUtil
            .isRangeWordByECIS(ourManagementPersonInChargeCode)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_OUR_MANAGEMENT_PERSON_IN_CHARGE_CODE_NAME,
                      "半角英数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 自社担当者コード：文字列最大長チェック
    } else if (ourManagementPersonInChargeCode != null
        && !CommonValidationUtil
            .maxLength(
                ourManagementPersonInChargeCode,
                ContractManagementInformationFileConfigContract.DATA_OUR_MANAGEMENT_PERSON_IN_CHARGE_CODE_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_OUR_MANAGEMENT_PERSON_IN_CHARGE_CODE_NAME,
                      ContractManagementInformationFileConfigContract.DATA_OUR_MANAGEMENT_PERSON_IN_CHARGE_CODE_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String ourManagementDepartmentCode = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_OUR_MANAGEMENT_DEPARTMENT_CODE_INDEX);
    // 自社部署コード：文字種別チェック（半角英数字）
    if (ourManagementDepartmentCode != null
        && !CommonValidationUtil
            .isAlphabetNumric(ourManagementDepartmentCode)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_ALPHANUMERIC_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_OUR_MANAGEMENT_DEPARTMENT_CODE_NAME },
                  Locale.getDefault()));

      // 自社部署コード：文字種別チェック（半角英数字　低圧CISシステム許容文字）
    } else if (ourManagementDepartmentCode != null
        && !CommonValidationUtil
            .isRangeWordByECIS(ourManagementDepartmentCode)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_OUR_MANAGEMENT_DEPARTMENT_CODE_NAME,
                      "半角英数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 自社部署コード：文字列最大長チェック
    } else if (ourManagementDepartmentCode != null
        && !CommonValidationUtil
            .maxLength(
                ourManagementDepartmentCode,
                ContractManagementInformationFileConfigContract.DATA_OUR_MANAGEMENT_DEPARTMENT_CODE_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_OUR_MANAGEMENT_DEPARTMENT_CODE_NAME,
                      ContractManagementInformationFileConfigContract.DATA_OUR_MANAGEMENT_DEPARTMENT_CODE_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String businessTypeCode = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_BUSINESS_TYPE_CODE_INDEX);
    // 業種コード：文字種別チェック（半角英数字）
    if (businessTypeCode != null
        && !CommonValidationUtil.isAlphabetNumric(businessTypeCode)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_ALPHANUMERIC_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_BUSINESS_TYPE_CODE_NAME },
                  Locale.getDefault()));

      // 業種コード：文字種別チェック（半角英数字　低圧CISシステム許容文字）
    } else if (businessTypeCode != null
        && !CommonValidationUtil.isRangeWordByECIS(businessTypeCode)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_BUSINESS_TYPE_CODE_NAME,
                      "半角英数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 業種コード：文字列最大長チェック
    } else if (businessTypeCode != null
        && !CommonValidationUtil
            .maxLength(
                businessTypeCode,
                ContractManagementInformationFileConfigContract.DATA_BUSINESS_TYPE_CODE_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_BUSINESS_TYPE_CODE_NAME,
                      ContractManagementInformationFileConfigContract.DATA_BUSINESS_TYPE_CODE_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String rateMenuId = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_RATE_MENU_ID_INDEX);
    // 料金メニューID：必須チェック
    if (CommonValidationUtil.isNull(rateMenuId)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_RATE_MENU_ID_NAME },
                  Locale.getDefault()));
    }

    String contractCapacity = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_CONTRACT_CAPACITY_INDEX);
    // 契約容量：数値フォーマットチェック
    if (contractCapacity != null
        && !CommonValidationUtil.checkByPattern(contractCapacity,
            "^(([1-9][0-9]*|0){1}(\\.[0-9]+)?)?$")) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_CAPACITY_NAME,
                      "数値形式（マイナス符号：否、カンマ：否、小数：可）" },
                  Locale.getDefault()));

      // 契約容量：数値桁数チェック
    } else if (contractCapacity != null
        && !CommonValidationUtil
            .checkBigDecimalDigit(
                contractCapacity,
                ContractManagementInformationFileConfigContract.DATA_CONTRACT_CAPACITY_DIGIT_INTEGER,
                ContractManagementInformationFileConfigContract.DATA_CONTRACT_CAPACITY_DIGIT_FLOAT)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MONEYRANGE,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_CAPACITY_NAME,
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_CAPACITY_DIGIT_INTEGER_STRING,
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_CAPACITY_DIGIT_FLOAT_STRING },
                  Locale.getDefault()));
    }
    return messageList;
  }

}
