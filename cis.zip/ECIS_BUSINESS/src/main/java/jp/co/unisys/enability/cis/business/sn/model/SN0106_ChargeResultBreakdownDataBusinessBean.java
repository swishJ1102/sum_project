package jp.co.unisys.enability.cis.business.sn.model;

/**
 * 料金実績内訳データビジネスBean. 料金実績内訳のデータを保持するBeanクラス
 *
 * @author "Nihon Unisys, Ltd."
 */
public class SN0106_ChargeResultBreakdownDataBusinessBean extends SN_CreateCsvBusinessBean {

  /** 確定料金実績ID */
  private String fcrId;

  /** 表示順 */
  private String displayOrder;

  /** 明細出力順 */
  private String detailOutputOrder;

  /** 表示名称1 */
  private String displayName1;

  /** 表示名称2 */
  private String displayName2;

  /** 容量・使用量 */
  private String capacityOrUsage;

  /** 単価 */
  private String up;

  /** 金額 */
  private String amount;

  /** 付帯契約ID */
  private String splContractId;

  /** 付帯率 */
  private String splRate;

  /** 付帯対象区分コード */
  private String splCoveredCatCode;

  /** 確定料金実績内訳区分コード */
  private String fcrBreakdownCatCode;

  /** 付帯対象区分 */
  private String supplementaryCoveredCat;

  /** 確定料金実績内訳区分 */
  private String fcrBreakdownCat;

  /**
   * 確定料金実績IDを設定する。
   *
   * @param fcrId
   *          確定料金実績ID
   */
  public void setFcrId(String fcrId) {
    this.fcrId = fcrId;
  }

  /**
   * 確定料金実績IDを取得する。
   *
   * @return 確定料金実績ID
   */
  public String getFcrId() {
    return this.fcrId;
  }

  /**
   * 表示順を設定する。
   *
   * @param displayOrder
   *          表示順
   */
  public void setDisplayOrder(String displayOrder) {
    this.displayOrder = displayOrder;
  }

  /**
   * 表示順を取得する。
   *
   * @return 表示順
   */
  public String getDisplayOrder() {
    return this.displayOrder;
  }

  /**
   * 明細出力順を設定する。
   *
   * @param detailOutputOrder
   *          明細出力順
   */
  public void setDetailOutputOrder(String detailOutputOrder) {
    this.detailOutputOrder = detailOutputOrder;
  }

  /**
   * 明細出力順を取得する。
   *
   * @return 明細出力順
   */
  public String getDetailOutputOrder() {
    return this.detailOutputOrder;
  }

  /**
   * 表示名称1を設定する。
   *
   * @param displayName1
   *          表示名称1
   */
  public void setDisplayName1(String displayName1) {
    this.displayName1 = displayName1;
  }

  /**
   * 表示名称1を取得する。
   *
   * @return 表示名称1
   */
  public String getDisplayName1() {
    return this.displayName1;
  }

  /**
   * 表示名称2を設定する。
   *
   * @param displayName2
   *          表示名称2
   */
  public void setDisplayName2(String displayName2) {
    this.displayName2 = displayName2;
  }

  /**
   * 表示名称2を取得する。
   *
   * @return 表示名称2
   */
  public String getDisplayName2() {
    return this.displayName2;
  }

  /**
   * 容量・使用量を設定する。
   *
   * @param capacityOrUsage
   *          容量・使用量
   */
  public void setCapacityOrUsage(String capacityOrUsage) {
    this.capacityOrUsage = capacityOrUsage;
  }

  /**
   * 容量・使用量を取得する。
   *
   * @return 容量・使用量
   */
  public String getCapacityOrUsage() {
    return this.capacityOrUsage;
  }

  /**
   * 単価を設定する。
   *
   * @param up
   *          単価
   */
  public void setUp(String up) {
    this.up = up;
  }

  /**
   * 単価を取得する。
   *
   * @return 単価
   */
  public String getUp() {
    return this.up;
  }

  /**
   * 金額を設定する。
   *
   * @param amount
   *          金額
   */
  public void setAmount(String amount) {
    this.amount = amount;
  }

  /**
   * 金額を取得する。
   *
   * @return 金額
   */
  public String getAmount() {
    return this.amount;
  }

  /**
   * 付帯契約IDを設定する。
   *
   * @param splContractId
   *          付帯契約ID
   */
  public void setSplContractId(String splContractId) {
    this.splContractId = splContractId;
  }

  /**
   * 付帯契約IDを取得する。
   *
   * @return 付帯契約ID
   */
  public String getSplContractId() {
    return this.splContractId;
  }

  /**
   * 付帯率を設定する。
   *
   * @param splRate
   *          付帯率
   */
  public void setSplRate(String splRate) {
    this.splRate = splRate;
  }

  /**
   * 付帯率を取得する。
   *
   * @return 付帯率
   */
  public String getSplRate() {
    return this.splRate;
  }

  /**
   * 付帯対象区分コードを設定する。
   *
   * @param splCoveredCatCode
   *          付帯対象区分コード
   */
  public void setSplCoveredCatCode(String splCoveredCatCode) {
    this.splCoveredCatCode = splCoveredCatCode;
  }

  /**
   * 付帯対象区分コードを取得する。
   *
   * @return 付帯対象区分コード
   */
  public String getSplCoveredCatCode() {
    return this.splCoveredCatCode;
  }

  /**
   * 確定料金実績内訳区分コードを設定する。
   *
   * @param fcrBreakdownCatCode
   *          確定料金実績内訳区分コード
   */
  public void setFcrBreakdownCatCode(String fcrBreakdownCatCode) {
    this.fcrBreakdownCatCode = fcrBreakdownCatCode;
  }

  /**
   * 確定料金実績内訳区分コードを取得する。
   *
   * @return 確定料金実績内訳区分コード
   */
  public String getFcrBreakdownCatCode() {
    return this.fcrBreakdownCatCode;
  }

  /**
   * 付帯対象区分を設定する。
   *
   * @param supplementaryCoveredCat
   *          付帯対象区分
   */
  public void setSupplementaryCoveredCat(String supplementaryCoveredCat) {
    this.supplementaryCoveredCat = supplementaryCoveredCat;
  }

  /**
   * 付帯対象区分を取得する。
   *
   * @return 付帯対象区分
   */
  public String getSupplementaryCoveredCat() {
    return this.supplementaryCoveredCat;
  }

  /**
   * 確定料金実績内訳区分を設定する。
   *
   * @param fcrBreakdownCat
   *          確定料金実績内訳区分
   */
  public void setFcrBreakdownCat(String fcrBreakdownCat) {
    this.fcrBreakdownCat = fcrBreakdownCat;
  }

  /**
   * 確定料金実績内訳区分を取得する。
   *
   * @return 確定料金実績内訳区分
   */
  public String getFcrBreakdownCat() {
    return this.fcrBreakdownCat;
  }
}