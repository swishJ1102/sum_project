package jp.co.unisys.enability.cis.business.sn.model;

/**
 * 経理データファイル名ビジネスBean. サービスに受け渡すBeanクラス名
 *
 * @author "Nihon Unisys, Ltd."
 */
public class SN0601_AccountingDataFileNameBusinessBean {

  /** 経理データファイルパス */
  private String accountingDataFilePath;

  /** 経理データ論理ファイル名 */
  private String accountingDataLogicalFileName;

  /**
   * 経理データファイルパスを設定する。
   *
   * @param accountingDataFilePath
   *          経理データファイルパス
   */
  public void setAccountingDataFilePath(String accountingDataFilePath) {
    this.accountingDataFilePath = accountingDataFilePath;
  }

  /**
   * 経理データファイルパスを取得する。
   *
   * @return 経理データファイルパス
   */
  public String getAccountingDataFilePath() {
    return this.accountingDataFilePath;
  }

  /**
   * 経理データ論理ファイル名を設定する。
   *
   * @param accountingDataLogicalFileName
   *          経理データ論理ファイル名
   */
  public void setAccountingDataLogicalFileName(String accountingDataLogicalFileName) {
    this.accountingDataLogicalFileName = accountingDataLogicalFileName;
  }

  /**
   * 経理データ論理ファイル名を取得する。
   *
   * @return 経理データ論理ファイル名
   */
  public String getAccountingDataLogicalFileName() {
    return this.accountingDataLogicalFileName;
  }
}