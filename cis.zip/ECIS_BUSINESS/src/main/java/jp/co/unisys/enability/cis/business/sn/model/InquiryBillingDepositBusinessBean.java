package jp.co.unisys.enability.cis.business.sn.model;

import java.util.List;

import jp.co.unisys.enability.cis.entity.sn.SN_InquiryBillingDepositInformationEntityBean;

/**
 * 請求入金一覧照会で、検索条件および検索結果を格納するビジネスBean
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * 請求入金情報ビジネス
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class InquiryBillingDepositBusinessBean {

  /**
   * 契約者IDを保有する。
   */
  private Integer contractorId;

  /**
   * 契約者番号を保有する。
   */
  private String contractorNo;

  /**
   * ご利用年月FROMを保有する。
   */
  private String usePeriodFrom;

  /**
   * ご利用年月TOを保有する。
   */
  private String usePeriodTo;

  /**
   * 請求IDを保有する。
   */
  private Integer billingId;

  /**
   * 請求番号を保有する。
   */
  private String billingNo;

  /**
   * 請求入金情報リストを保有する。
   */
  private List<SN_InquiryBillingDepositInformationEntityBean> billingDepositInformationList;

  /**
   * リターンコードを保有する。
   */
  private String returnCode;

  /**
   * メッセージを保有する。
   */
  private String message;

  /**
   * 契約者IDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者IDを取得。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者ID
   */
  public Integer getContractorId() {
    return this.contractorId;
  }

  /**
   * 契約者IDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者IDを設定。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorId
   *          契約者ID
   */
  public void setContractorId(Integer contractorId) {
    this.contractorId = contractorId;
  }

  /**
   * 契約者番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者番号を取得。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者番号
   */
  public String getContractorNo() {
    return this.contractorNo;
  }

  /**
   * 契約者番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者番号を設定。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorNo
   *          契約者番号
   */
  public void setContractorNo(String contractorNo) {
    this.contractorNo = contractorNo;
  }

  /**
   * ご利用年月FROMのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * ご利用年月FROMを取得。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return ご利用年月FROM
   */
  public String getUsePeriodFrom() {
    return this.usePeriodFrom;
  }

  /**
   * ご利用年月FROMのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * ご利用年月FROMを設定。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param usePeriodFrom
   *          ご利用年月FROM
   */
  public void setUsePeriodFrom(String usePeriodFrom) {
    this.usePeriodFrom = usePeriodFrom;
  }

  /**
   * ご利用年月TOのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * ご利用年月TOを取得。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return ご利用年月TO
   */
  public String getUsePeriodTo() {
    return this.usePeriodTo;
  }

  /**
   * ご利用年月TOのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * ご利用年月TOを設定。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param usePeriodTo
   *          ご利用年月TO
   */
  public void setUsePeriodTo(String usePeriodTo) {
    this.usePeriodTo = usePeriodTo;
  }

  /**
   * 請求IDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求IDを取得。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 請求ID
   */
  public Integer getBillingId() {
    return this.billingId;
  }

  /**
   * 請求IDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求IDを設定。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param billingId
   *          請求ID
   */
  public void setBillingId(Integer billingId) {
    this.billingId = billingId;
  }

  /**
   * 請求番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求番号を取得。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 請求番号
   */
  public String getBillingNo() {
    return this.billingNo;
  }

  /**
   * 請求番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求番号を設定。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param billingNo
   *          請求番号
   */
  public void setBillingNo(String billingNo) {
    this.billingNo = billingNo;
  }

  /**
   * 請求入金情報リストのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求入金情報リストを取得。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 請求入金情報リスト
   */
  public List<SN_InquiryBillingDepositInformationEntityBean> getBillingDepositInformationList() {
    return this.billingDepositInformationList;
  }

  /**
   * 請求入金情報リストのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求入金情報リストを設定。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param billingDepositInformationList
   *          請求入金情報リスト
   */
  public void setBillingDepositInformationList(
      List<SN_InquiryBillingDepositInformationEntityBean> billingDepositInformationList) {
    this.billingDepositInformationList = billingDepositInformationList;
  }

  /**
   * リターンコードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを取得。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return リターンコード
   */
  public String getReturnCode() {
    return this.returnCode;
  }

  /**
   * リターンコードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを設定。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param returnCode
   *          リターンコード
   */
  public void setReturnCode(String returnCode) {
    this.returnCode = returnCode;
  }

  /**
   * メッセージのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを取得。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return メッセージ
   */
  public String getMessage() {
    return this.message;
  }

  /**
   * メッセージのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを設定。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param message
   *          メッセージ
   */
  public void setMessage(String message) {
    this.message = message;
  }

}
