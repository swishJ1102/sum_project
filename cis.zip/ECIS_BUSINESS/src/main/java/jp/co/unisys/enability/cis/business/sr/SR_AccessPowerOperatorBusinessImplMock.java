package jp.co.unisys.enability.cis.business.sr;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.channels.FileChannel;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;

import javax.net.ssl.SSLSocket;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.config.PropertiesFactoryBean;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import jp.co.unisys.enability.cis.business.sr.model.SR_SSLauthenticationBusinessBean;
import jp.co.unisys.enability.cis.common.Exception.SystemException;
import jp.co.unisys.enability.cis.common.util.RK_PropertyUtil;
import jp.co.unisys.enability.cis.common.util.StringConvertUtil;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISSRConstants;
import jp.co.unisys.enability.cis.entity.common.AreaM;
import jp.co.unisys.enability.cis.entity.common.PmCompanyM;
import jp.co.unisys.enability.cis.entity.common.TfMng;

/**
 * 電力事業者アクセスクラス
 *
 * @note ＃37617の対応でモックのファイル取得元を変更しています Mock向けファイル設置先 ※【プロパティの値】/提供モデルコード/提供モデル企業コード/PPS区分/エリアコード/"
 *
 * @author "Nihon Unisys, Ltd."
 */
public class SR_AccessPowerOperatorBusinessImplMock implements
    SR_AccessPowerOperatorBusiness {
  /** ロガー */
  private static final Logger LOGGER = LogManager.getLogger();

  /** コード定義プロパティ(DI) */
  private PropertiesFactoryBean applicationProperties;

  /** SSLの接続情報 */
  private SSLSocket sslSock;

  /** SSLの接続情報ゲッター */
  private SSLSocket getSslSock() {
    return this.sslSock;
  }

  /** ファイル種別切り取り文字数 */
  private static final Integer FILETYPECOUNT = 6;

  /** メッセージプロパティ(DI) */
  private MessageSource messageSource;

  /** 提供モデル企業マスタ(認証時のキープ用) */
  private PmCompanyM pmCompanyM;

  /** エリアマスタ(認証時のキープ用) */
  private AreaM areaM;

  private static int fileCount = 0;

  /*********** 受信ファイル一覧(START) ***********/
  /** 受信ファイル一覧(Zip出力) */
  private ResponseEntity<byte[]> zipFileListResponse;

  /** 受信ファイル一覧ゲッター(Zip出力) */
  private ResponseEntity<byte[]> getZipFileListResponse() {
    return this.zipFileListResponse;
  }

  /** 受信ファイル一覧セッター(Zip出力) */
  private void setZipFileListResponse(
      ResponseEntity<byte[]> zipFileListResponse) {
    this.zipFileListResponse = zipFileListResponse;
  }

  /*********** 受信ファイル一覧(END) ***********/

  /** システム日時 */
  private Timestamp systemTime;

  /** システム日時ゲッター */
  private Timestamp getsystemTime() {
    return this.systemTime;
  }

  /** システム日時セッター */
  private void setsystemTime(Timestamp systemTime) {
    this.systemTime = systemTime;
  }

  /** バッチ処理基準日 **/
  private Date batchExecutesDate = null;

  /*********** 受信ファイル(START) ***********/
  /** 受信ファイル */
  private ResponseEntity<byte[]> zipFileResponse;

  /** 受信ファイルゲッター(Zip出力) */
  private ResponseEntity<byte[]> getZipFileResponse() {
    return this.zipFileResponse;
  }

  /** 受信ファイルセッター(Zip出力) */
  private void setZipFileResponse(ResponseEntity<byte[]> zipFileResponse) {
    this.zipFileResponse = zipFileResponse;
  }

  /*********** 受信ファイル一覧(END) ***********/

  /**
   * SSL認証
   *
   * <pre>
   * <p>
   * <b>【仕様詳細】</b>
   * </p>
   * SSL認証を行い、接続を行う。
   *
   * @author "Nihon Unisys, Ltd."
   * @param SR_SSLauthenticationBusinessBean
   *          SSL認証ビジネスBean
   * @param systemTime
   *          システム日時
   * @param batchExecutesDate
   *          バッチ処理基準日
   */
  public void sslAuthentication(
      SR_SSLauthenticationBusinessBean sslAuthentication,
      Timestamp systemTime, Date batchExecutesDate, PmCompanyM pmCompany, AreaM areaMaster)
      throws SystemException {

    setsystemTime(systemTime);

    // バッチ処理基準日の保持
    setBatchExecutesDate(batchExecutesDate);
    try {

      // 認証時の情報を保存
      this.pmCompanyM = pmCompany;
      this.areaM = areaMaster;

      sslAuthentication.setReturnCode(ECISSRConstants.SSL_ACCESS_OK);

    } catch (Exception e) {
      // 予期せぬエラー
      sslClose();
      throw new SystemException("error.E1587", e);
    }
  }

  /**
   * ファイルリスト受信要求
   *
   * <pre>
   * <p>
   * <b>【仕様詳細】</b>
   * </p>
   * ファイル受信要求を行い、受信可能一覧を取得する。
   *
   * @author "Nihon Unisys, Ltd."
   * @param SR_SSLauthenticationBusinessBean
   *          SSL認証ビジネスBean
   */
  public void fileListReceptionRequest(
      SR_SSLauthenticationBusinessBean sslAuthentication) {

    LOGGER.info("ファイルリスト受信要求アクセスURL：" + sslAuthentication.getAccessUrl());

    // 外部ファイル取得
    Properties prop = RK_PropertyUtil
        .getPropertiesFactory(applicationProperties);
    // タグ検索文字
    String searchName = prop.getProperty("SSR0601.search.Name");

    // setresponseにはファイル情報ではなく、ファイル一覧リストを設定。
    List<String> fileList = new ArrayList<String>();
    ResponseEntity<byte[]> result = getFileList(sslAuthentication.getAreaCode());
    if (result.getStatusCode().equals(HttpStatus.ACCEPTED)) {
      setZipFileListResponse(result);
    } else {
      // 空のリストを設定して返却
      sslAuthentication.setReceivableFileList(fileList);
      return;
    }

    receivableFileListBackUp(sslAuthentication);

    // commentタグの抽出
    String comment = commentLine(new String(getZipFileListResponse()
        .getBody()));

    // ファイル名とファイル容量を取得
    for (String item : comment.split(ECISConstants.COMMA)) {
      if (item.indexOf(searchName) != -1) {
        for (String info : item.split(":")) {
          if (info.indexOf(searchName) == -1) {
            fileList.add(info.replaceAll("\"", "").trim());
          }
        }
      }
    }
    sslAuthentication.setReceivableFileList(fileList);
  }

  /**
   * ファイル受信要求
   *
   * <pre>
   * <p>
   * <b>【仕様詳細】</b>
   * </p>
   * ファイル受信要求を行い、Zipファイルを取得する。
   *
   * @author "Nihon Unisys, Ltd."
   * @param SR_SSLauthenticationBusinessBean
   *          SSL認証ビジネスBean
   * @param noReceivableFile
   *          未受信ファイル
   */
  public void fileReceptionRequest(
      SR_SSLauthenticationBusinessBean sslAuthentication,
      TfMng noReceivableFile) throws SystemException {

    // 外部ファイル取得
    Properties prop = RK_PropertyUtil
        .getPropertiesFactory(applicationProperties);

    // 文字検索（要求回答）_OK
    String youkyukaitoOk = prop.getProperty("SSR0601.youkyukaito_ok");

    StringBuffer sb = new StringBuffer();
    // 文字列連結
    sb.append(sslAuthentication.getAccessUrl());
    sb.append(noReceivableFile.getFileName().replaceAll(ECISConstants.FILE_EXTENSION_XML,
        ECISConstants.FILE_EXTENSION_ZIP));

    LOGGER.info("ファイル受信要求アクセスURL：" + sb.toString());

    // setresponseにはファイル一覧リストではなく、ファイル情報を設定。
    // 接続に失敗した場合、接続失敗を返却する。
    try {
      setZipFileResponse(getFileData(noReceivableFile.getFileName().replaceAll(ECISConstants.FILE_EXTENSION_XML,
          ECISConstants.FILE_EXTENSION_ZIP)));
      sb.setLength(0);
    } catch (Exception e) {
      sslAuthentication
          .setReceptionCode(ECISSRConstants.SSL_ACCESS_FILE_RECEPTION_NO);
      return;
    }

    try {
      // 対象ファイルのバックアップ
      saveFile(
          sslAuthentication,
          noReceivableFile.getFileName().replaceAll(ECISConstants.FILE_EXTENSION_XML,
              ECISConstants.FILE_EXTENSION_ZIP),
          noReceivableFile.getFileName().substring(0, FILETYPECOUNT),
          prop.getProperty("SSR0601.ReceivableSaveFilePath"),
          getZipFileResponse());
    } catch (SystemException e) {
      LOGGER.error("ファイルのバックアップに失敗しました。");
      throw new SystemException("ファイルのバックアップに失敗しました。", e);
    }

    try {

      // PPS区分+エリアコード+ファイル種別+対象年月日の基本パス作成
      StringBuffer bathPath = new StringBuffer();
      StringBuffer outputpath = new StringBuffer();
      File outputfile = null;
      bathPath.append(ECISConstants.SLASH);
      bathPath.append(sslAuthentication.getPpsCat());
      bathPath.append(ECISConstants.SLASH);
      bathPath.append(sslAuthentication.getAreaCode());
      bathPath.append(ECISConstants.SLASH);
      bathPath.append(noReceivableFile.getFileName()
          .substring(0, FILETYPECOUNT));
      bathPath.append(ECISConstants.SLASH);
      bathPath.append(new SimpleDateFormat(ECISConstants.FORMAT_DATE_yyyyMMdd)
          .format(getBatchExecutesDate()));
      bathPath.append(ECISConstants.SLASH);

      // バックアップしたZipファイルを取得
      sb.append(prop.getProperty("SSR0601.ReceivableSaveFilePath"));
      sb.append(bathPath);
      sb.append(noReceivableFile.getFileName().replaceAll(ECISConstants.FILE_EXTENSION_XML,
          ECISConstants.FILE_EXTENSION_ZIP));
      File rcvFile = new File(sb.toString());

      switch (noReceivableFile.getFileName().substring(0, FILETYPECOUNT)) {
        // 高圧計量器交換ファイル
        case ECISSRConstants.LINKAGE_FILE_CATEGORY_M_HIGH_TENSION_METER_CHANGE_FILE:
          // 低圧計量器交換ファイル
        case ECISSRConstants.LINKAGE_FILE_CATEGORY_M_LOW_TENSION_METER_CHANGE_FILE:
          // 高圧臨時検針ファイル
        case ECISSRConstants.LINKAGE_FILE_CATEGORY_M_HIGH_TENSION_SPECIAL_METER_READING_FILE:
          // 低圧臨時検針ファイル
        case ECISSRConstants.LINKAGE_FILE_CATEGORY_M_LOW_TENSION_SPECIAL_METER_READING_FILE:

          // 使用量XMLファイル集信ディレクトリを指定
          outputpath.append(StringUtils.defaultString(prop
              .getProperty("batch.sr.usage.xmlfiles.receive.dir")));
          outputpath.append(bathPath);
          // フォルダ作成
          new File(outputpath.toString()).mkdirs();
          outputpath.append(noReceivableFile.getFileName().replaceAll(
              ECISConstants.FILE_EXTENSION_ZIP,
              ECISConstants.FILE_EXTENSION_XML));
          outputfile = new File(outputpath.toString());
          // ファイルの存在チェック
          if (outputfile.exists()) {
            outputpath.setLength(0);
            outputpath.append(noReceivableFile.getFileName());
            throw new SystemException(messageSource.getMessage(
                "error.E1061",
                new String[] {outputpath.toString() },
                Locale.getDefault()));
          }
          decodeZip(rcvFile, outputfile);
          break;
        // 高圧臨時検針ファイル
        case ECISSRConstants.LINKAGE_FILE_CATEGORY_M_HIGH_VOLTAGE_MONTH:
          // 低圧臨時検針ファイル
        case ECISSRConstants.LINKAGE_FILE_CATEGORY_M_LOW_VOLTAGE_MONTH:

          // 使用量XMLファイル集信ディレクトリを指定
          outputpath.append(StringUtils.defaultString(prop
              .getProperty("batch.sr.mdms.linkagefile.receive.dir")));
          outputpath.append(bathPath);
          // フォルダ作成
          new File(outputpath.toString()).mkdirs();
          // バックアップフォルダ作成
          StringBuffer sbBackUp = new StringBuffer();
          sbBackUp.append(outputpath.toString());
          sbBackUp.append(StringUtils.defaultString(prop
              .getProperty("batch.sr.mdms.unprocessname.backup")));
          new File(sbBackUp.toString()).mkdirs();

          // エラーフォルダ作成
          StringBuffer sbError = new StringBuffer();
          sbError.append(outputpath.toString());
          sbError.append(StringUtils.defaultString(prop
              .getProperty("batch.sr.mdms.unprocessname.error")));
          new File(sbError.toString()).mkdirs();
          // 取得したファイルの拡張子を変更
          outputpath.append(noReceivableFile.getFileName().replaceAll(
              ECISConstants.FILE_EXTENSION_ZIP,
              ECISConstants.FILE_EXTENSION_XML));
          outputfile = new File(outputpath.toString());
          // ファイルの存在チェック
          if (outputfile.exists()) {
            outputpath.setLength(0);
            outputpath.append(noReceivableFile.getFileName());
            throw new SystemException(messageSource.getMessage(
                "error.E1061",
                new String[] {outputpath.toString() },
                Locale.getDefault()));
          }
          decodeZip(rcvFile, outputfile);
          break;
        default:
          throw new SystemException("想定外の区分:" + noReceivableFile.getFileName());
      }
    } catch (Exception e) {
      LOGGER.error("ファイルの配置に失敗しました。{}", noReceivableFile.getFileName());
      throw new SystemException("ファイルの配置に失敗しました。", e);
    }
    sslAuthentication
        .setReceptionCode(ECISSRConstants.SSL_ACCESS_FILE_RECEPTION_OK);
  }

  /**
   * 受信可能ファイル一覧のバックアップ
   *
   * <pre>
   * <p>
   * <b>【仕様詳細】</b>
   * </p>
   * 受信可能ファイル一覧のバックアップ。
   *
   * @author "Nihon Unisys, Ltd."
   * @param SR_SSLauthenticationBusinessBean
   *          SSL認証ビジネスBean
   */
  public void receivableFileListBackUp(
      SR_SSLauthenticationBusinessBean sslAuthentication)
      throws SystemException {
    /** 外部ファイル取得 */
    Properties prop = RK_PropertyUtil
        .getPropertiesFactory(applicationProperties);

    try {
      StringBuffer sb = new StringBuffer();
      sb.append(prop
          .getProperty("SSR0601.ReceivableFileListBackUpFileName"));
      sb.append(new SimpleDateFormat(
          ECISConstants.FORMAT_DATE_yyyyMMddHHmmss)
              .format(getsystemTime()));
      sb.append("_");
      sb.append(String.valueOf(++fileCount));
      sb.append(ECISConstants.FILE_EXTENSION_XML);
      // 受信可能ファイル一覧のバックアップ
      saveFile(
          sslAuthentication,
          sb.toString(),
          null,
          prop.getProperty("SSR0601.ReceivableFileListBackUpFilePath"),
          getZipFileListResponse());
    } catch (SystemException e) {
      throw new SystemException(messageSource.getMessage("error.E1587",
          null, Locale.getDefault()), e);
    }
  }

  /**
   * SSL接続のクローズ
   *
   * <pre>
   * <p>
   * <b>【仕様詳細】</b>
   * </p>
   * 接続しているSSLをクローズする。
   *
   * @author "Nihon Unisys, Ltd."
   */
  public void sslClose() throws SystemException {

    if (getSslSock() != null) {
      try {
        getSslSock().close();
      } catch (IOException e) {
        throw new SystemException(messageSource.getMessage(
            "error.E1587", null, Locale.getDefault()));
      }
    }
  }

  /**
   * commentタグの内容取得
   *
   * <pre>
   * <p>
   * <b>【仕様詳細】</b>
   * </p>
   * 取得したHTMLを解析し、commentタグの文字列を取得する。
   *
   * @author "Nihon Unisys, Ltd."
   * @param String
   *          response 取得結果
   */
  private String commentLine(String response) {

    /** 外部ファイル取得 */
    Properties prop = RK_PropertyUtil
        .getPropertiesFactory(applicationProperties);
    /** 改行コードのパターン */
    String lineSeparatorPattern = prop
        .getProperty("SSR0601.Line.Separator.Pattern");
    /** レスポンスの開始タグ */
    String resStartTag = prop.getProperty("SSR0601.Res.Start.Tag");
    /** レスポンスの終了タグ */
    String resEndTag = prop.getProperty("SSR0601.Res.End.Tag");
    StringBuffer commentMessage = new StringBuffer();
    // 行分活用のパターン
    Pattern pattern = Pattern.compile(lineSeparatorPattern);
    // 文字列を改行コードで行ごとに分割する。
    boolean startFlg = false;

    // HTMLの解析を行う。
    for (String s : pattern.split(response.trim())) {
      // 前後の制御文字を削除した文字列を処理する
      String line = s.trim();
      // <comment>タグの判定
      if (line.indexOf(resStartTag) != -1 || startFlg) {
        startFlg = true;
        commentMessage.append(s);
      }
      // </coment>タグが存在し、かつフラグがtrueの場合
      if (line.indexOf(resEndTag) != -1 && startFlg) {
        startFlg = false;
        break;
      }
    }
    return commentMessage.toString();
  }

  /**
   * ファイルの保存
   *
   * <pre>
   * <p>
   * <b>【仕様詳細】</b>
   * </p>
   * getresponseに設定したデータを保存する。
   *
   * @author "Nihon Unisys, Ltd."
   * @param sslAuthentication
   *          SSL認証ビジネスBean
   * @param saveFileName
   *          保存ファイル名
   * @param saveFileType
   *          保存ファイル種別
   * @param saveFilePath
   *          保存先ファイルパス
   */
  private void saveFile(SR_SSLauthenticationBusinessBean sslAuthentication,
      String saveFileName, String saveFileType, String saveFilePath,
      ResponseEntity<byte[]> getZipFile) throws SystemException {
    FileOutputStream stream = null;
    StringBuffer sb = new StringBuffer();
    try {
      // 文字列連結
      sb.append(saveFilePath);
      sb.append(ECISConstants.SLASH);
      sb.append(sslAuthentication.getPpsCat());
      sb.append(ECISConstants.SLASH);
      sb.append(sslAuthentication.getAreaCode());
      sb.append(ECISConstants.SLASH);
      if (saveFileType != null) {
        sb.append(saveFileType);
        sb.append(ECISConstants.SLASH);
      }
      sb.append(new SimpleDateFormat(ECISConstants.FORMAT_DATE_yyyyMMdd)
          .format(getBatchExecutesDate()));
      // バックアップフォルダを作成
      new File(sb.toString()).mkdirs();
      sb.append(ECISConstants.SLASH);
      sb.append(saveFileName);

      // バックアップファイルを作成
      File rcvFile = new File(sb.toString());

      // ファイルの存在チェック
      if (rcvFile.exists()) {
        sb.setLength(0);
        sb.append(saveFileName);
        throw new SystemException(messageSource.getMessage(
            "error.E1061", new String[] {sb.toString() },
            Locale.getDefault()));
      }
      stream = new FileOutputStream(rcvFile);
      // バックアップ
      byte[] receivableFileListBackUp = getZipFile.getBody();
      stream.write(receivableFileListBackUp);

    } catch (FileNotFoundException e) {
      LOGGER.error("saveFile＞FileOutputStreamエラー 出力先パス={}", sb.toString());
      throw new SystemException("FileNotFoundExceptionが発生しました", e);
    } catch (IOException e) {
      LOGGER.error(
          "saveFile＞IOExceptionエラー Zipの書き込みに失敗しました。PPS区分:{},エリア:{}",
          sslAuthentication.getPpsCat(),
          sslAuthentication.getAreaCode());
      throw new SystemException("IOExceptionエラー Zipの書き込みに失敗しました。", e);
    } finally {
      try {
        if (stream != null) {
          stream.close();
        }
      } catch (IOException e) {
        LOGGER.error("streamのクローズに失敗しました。");
        throw new SystemException("streamのクローズに失敗しました。", e);
      }
    }
  }

  /**
   * ZIPファイル解凍
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * XMLファイル連携で取得したZIPファイルを解凍する。
   * 保存したいファイルは事前に作成しておくこと。
   * </pre>
   *
   * @param inputFile
   *          解凍前のZIPファイル
   * @param outputFile
   *          解凍後のファイル
   *
   * @throws SystemException
   *           例外が発生した場合
   */
  private void decodeZip(File inputFile, File outputFile)
      throws SystemException {

    List<File> unzipFileList = new ArrayList<File>();
    FileChannel fc = null;
    boolean unzipflg = false;
    try (ZipFile zipFile = new ZipFile(inputFile)) {
      try (ZipInputStream zis = new ZipInputStream(new FileInputStream(
          inputFile))) {
        for (ZipEntry entry = zis.getNextEntry(); entry != null; entry = zis
            .getNextEntry()) {

          try (BufferedOutputStream bos = new BufferedOutputStream(
              new FileOutputStream(outputFile));
              InputStream is = zipFile.getInputStream(entry)) {
            byte[] buf = new byte[ECISConstants.UNZIP_BUFFER_SIZE];
            int readSize = 0;
            while ((readSize = is.read(buf)) != -1) {
              bos.write(buf, 0, readSize);
            }
          }
        }
      }
    } catch (Exception e) {
      if (unzipflg) {
        for (Iterator<File> iterator = unzipFileList.iterator(); iterator
            .hasNext();) {
          File unzipedFile = (File) iterator.next();
          unzipedFile.delete();
        }
      }
      LOGGER.error("解凍対象ファイルが見つかりませんでした。");
      throw new SystemException("解凍対象ファイルが見つかりませんでした。", e);
    } finally {
      if (fc != null) {
        try {
          fc.close();
        } catch (IOException e) {
          LOGGER.error("ファイルをクローズできませんでした。");
          throw new SystemException("ファイルをクローズできませんでした。", e);
        }
      }
    }

  }

  /**
   * メッセージプロパティのsetter（DI）
   *
   * @param messageSource
   *          メッセージプロパティ
   */
  public void setmessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }

  /**
   * コード定義プロパティのsetter（DI）
   *
   * @param messageSource
   *          メッセージプロパティ
   */
  public void setapplicationProperties(
      PropertiesFactoryBean applicationProperties) {
    this.applicationProperties = applicationProperties;
  }

  /**
   * バッチ処理基準日のgetter
   *
   * @return バッチ処理基準日
   */
  public Date getBatchExecutesDate() {
    return batchExecutesDate;
  }

  /**
   * バッチ処理基準日のsetter
   *
   * @param batchExecutesDate
   *          バッチ処理基準日
   */
  public void setBatchExecutesDate(Date batchExecutesDate) {
    this.batchExecutesDate = batchExecutesDate;
  }

  /**
   * モック用ファイルリスト
   */
  public ResponseEntity<byte[]> getFileList(String areaCode) {
    // バッチ実行日取得
    Date executeDate = getBatchExecutesDate();
    // 日付を文字列化
    String dayString = StringConvertUtil.convertDateToString(executeDate, "yyyyMMdd");
    Properties prop = RK_PropertyUtil
        .getPropertiesFactory(applicationProperties);
    // フィル名の作成
    String fileName = areaCode + "_" + dayString + "_list" + ".txt";
    // ファイルパスの作成
    String filePath = prop.getProperty("SSR0601.ReceivableSaveFilePath");
    filePath = filePath.replace("SR9001", "SR0601");
    filePath = absolutePath(filePath, this.pmCompanyM.getPmCode());
    filePath = absolutePath(filePath, this.pmCompanyM.getPmCompanyCode());
    filePath = absolutePath(filePath, this.pmCompanyM.getPpsCat());
    filePath = absolutePath(filePath, this.areaM.getAreaCode());
    filePath = absolutePath(filePath, fileName);

    // 返却値用のバイト配列
    byte[] byteData = new byte[1];
    ByteArrayOutputStream baos = new ByteArrayOutputStream();

    FileInputStream fis = null;

    try {
      fis = new FileInputStream(filePath);
      while (fis.read(byteData) > 0) {
        baos.write(byteData);
      }
      byteData = baos.toByteArray();
      fis.close();
      baos.close();
    } catch (FileNotFoundException fe) {
      return new ResponseEntity<byte[]>(byteData, HttpStatus.BAD_REQUEST);
    } catch (Exception e) {
      LOGGER.error("ファイルリストを取得できませんでした。");
      throw new SystemException("ファイルリストを取得できませんでした。", e);
    }

    return new ResponseEntity<byte[]>(byteData, HttpStatus.ACCEPTED);
  }

  /**
   * モック用ファイル
   */
  public ResponseEntity<byte[]> getFileData(String fileName) {
    // バッチ実行日取得
    Properties prop = RK_PropertyUtil
        .getPropertiesFactory(applicationProperties);
    // ファイルパスの作成
    String filePath = prop.getProperty("SSR0601.ReceivableSaveFilePath");
    filePath = filePath.replace("SR9001", "SR0601");
    filePath = absolutePath(filePath, this.pmCompanyM.getPmCode());
    filePath = absolutePath(filePath, this.pmCompanyM.getPmCompanyCode());
    filePath = absolutePath(filePath, this.pmCompanyM.getPpsCat());
    filePath = absolutePath(filePath, this.areaM.getAreaCode());
    filePath = absolutePath(filePath, fileName);

    // 返却値用のバイト配列
    byte[] byteData = new byte[1];
    ByteArrayOutputStream baos = new ByteArrayOutputStream();

    FileInputStream fis = null;

    try {
      fis = new FileInputStream(filePath);
      while (fis.read(byteData) > 0) {
        baos.write(byteData);
      }
      byteData = baos.toByteArray();
      fis.close();
      baos.close();
    } catch (Exception e) {
      LOGGER.error("ファイルを取得できませんでした。ファイル名：" + filePath);
      throw new SystemException("ファイルを取得できませんでした。", e);
    }

    return new ResponseEntity<byte[]>(byteData, HttpStatus.ACCEPTED);
  }

  /**
   * ファイルパスの作成
   *
   * @param p1
   * @param p2
   * @return
   */
  private String absolutePath(String p1, String p2) {
    return new File(p1, p2).getAbsolutePath();
  }

}
