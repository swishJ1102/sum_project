package jp.co.unisys.enability.cis.business.kj.model;

import java.util.List;

import jp.co.unisys.enability.cis.dao.kj.ContractManagementInformationDownloadSearchInformationBean;
import jp.co.unisys.enability.cis.entity.kj.KJ_PaymentInformationFileEntityBean;

/**
 * 支払情報ダウンロードBusinessBean
 *
 *
 * <pre>
* <p><b>【使用ビジネス】</b></p>
* 支払情報情報ビジネス
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class DownloadPaymentBusinessBean {

  /**
   * ダウンロードファイル名を保有する。
   */
  private String downloadFileName;

  /**
   * 契約管理情報ダウンロード検索条件Beanを保有する。
   */
  private ContractManagementInformationDownloadSearchInformationBean contractManagementInformationDownloadSearchInformationBean;

  /**
   * List 《支払情報ファイルEntityBean》を保有する。
   */
  private List<KJ_PaymentInformationFileEntityBean> paymentInformationFileEntityBeanList;

  /**
   * ダウンロードファイル名のgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * ダウンロードファイル名を取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return ダウンロードファイル名
   */
  public String getDownloadFileName() {
    return this.downloadFileName;
  }

  /**
   * ダウンロードファイル名のsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * ダウンロードファイル名を設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param downloadFileName
   *          ダウンロードファイル名
   */
  public void setDownloadFileName(String downloadFileName) {
    this.downloadFileName = downloadFileName;
  }

  /**
   * 契約管理情報ダウンロード検索条件Beanのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 契約管理情報ダウンロード検索条件Beanを取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 契約管理情報ダウンロード検索条件Bean
   */
  public ContractManagementInformationDownloadSearchInformationBean getContractManagementInformationDownloadSearchInformationBean() {
    return this.contractManagementInformationDownloadSearchInformationBean;
  }

  /**
   * 契約管理情報ダウンロード検索条件Beanのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 契約管理情報ダウンロード検索条件Beanを設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param contractManagementInformationDownloadSearchInformationBean
   *          契約管理情報ダウンロード検索条件Bean
   */
  public void setContractManagementInformationDownloadSearchInformationBean(
      ContractManagementInformationDownloadSearchInformationBean contractManagementInformationDownloadSearchInformationBean) {
    this.contractManagementInformationDownloadSearchInformationBean = contractManagementInformationDownloadSearchInformationBean;
  }

  /**
   * List 《支払情報ファイルEntityBean》のgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * List 《支払情報ファイルEntityBean》を取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return List 《支払情報ファイルEntityBean》
   */
  public List<KJ_PaymentInformationFileEntityBean> getPaymentInformationFileEntityBeanList() {
    return this.paymentInformationFileEntityBeanList;
  }

  /**
   * List 《支払情報ファイルEntityBean》のsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * List 《支払情報ファイルEntityBean》を設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param paymentInformationFileEntityBeanList
   *          List 《支払情報ファイルEntityBean》
   */
  public void setPaymentInformationFileEntityBeanList(
      List<KJ_PaymentInformationFileEntityBean> paymentInformationFileEntityBeanList) {
    this.paymentInformationFileEntityBeanList = paymentInformationFileEntityBeanList;
  }

}
