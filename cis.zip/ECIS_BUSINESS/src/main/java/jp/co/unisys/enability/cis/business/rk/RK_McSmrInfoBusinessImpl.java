package jp.co.unisys.enability.cis.business.rk;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.dao.DataAccessException;

import jp.co.unisys.enability.cis.business.rk.model.InquiryMcSmrInfoBusinessBean;
import jp.co.unisys.enability.cis.business.rk.model.McSmrInfoBusinessBean;
import jp.co.unisys.enability.cis.business.rk.model.McSmrInfoDetail1BusinessBean;
import jp.co.unisys.enability.cis.common.util.KJ_CommonUtil;
import jp.co.unisys.enability.cis.common.util.StringConvertUtil;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISKJConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISReturnCodeConstants;
import jp.co.unisys.enability.cis.entity.common.McSmrDetail2;
import jp.co.unisys.enability.cis.entity.rk.RK_InquiryMcSmrInfoEntityBean;
import jp.co.unisys.enability.cis.mapper.rk.RK_McSmrInfoMapper;

/**
 * 計量器交換・臨時検針情報ビジネス
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.rk.RK_McSmrInfoBusiness
 *
 */
public class RK_McSmrInfoBusinessImpl implements RK_McSmrInfoBusiness {

  /**
   * 計量器交換・臨時検針情報表示Mapper(DI)
   */
  private RK_McSmrInfoMapper rkMcSmrInfoMapper;

  /**
   * メッセージプロパティ(DI)
   */
  private MessageSource messageSource;

  /**
   * ログマネジャー
   */
  private static Logger logger = LogManager.getLogger();

  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.business.rk.RK_McSmrInfoBusiness#inquiry(jp.co.unisys.enability.cis.business.rk.model.InquiryMcSmrInfoBusinessBean)
   */
  @Override
  public InquiryMcSmrInfoBusinessBean inquiry(
      InquiryMcSmrInfoBusinessBean businessBean) {
    String systemErrorMessage = null;
    try {
      // システムエラーメッセージ
      systemErrorMessage = messageSource.getMessage(KJ_CommonUtil
          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G017),
          new String[] {}, Locale.getDefault());
      //地点特定番号
      String spotNo = businessBean.getSpotNo();
      //契約ID
      Integer contractId = businessBean.getContractId();
      //対象年月
      String coveredPeriod = businessBean.getCoveredPeriod();

      //照会パターンチェック
      Map<String, Object> exampleMap = new LinkedHashMap<String, Object>();
      if ((spotNo != null || StringUtils.isNotEmpty(spotNo))
          && contractId != null
          && (coveredPeriod != null || StringUtils.isNotEmpty(coveredPeriod))) {
        exampleMap.put("spotNo", spotNo);
        exampleMap.put("contractId", contractId);
        exampleMap.put("coveredPeriod", coveredPeriod);
      } else {
        businessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P001);
        return businessBean;
      }

      //計量器交換・臨時検針情報を取得する。
      List<RK_InquiryMcSmrInfoEntityBean> resultList = rkMcSmrInfoMapper.selectMcSmr(exampleMap);

      //照会結果設定
      List<McSmrInfoBusinessBean> mCInfoList = new ArrayList<McSmrInfoBusinessBean>();
      List<McSmrInfoBusinessBean> sMRInfoList = new ArrayList<McSmrInfoBusinessBean>();
      String tempFileName = new String();
      String tempMeterChangeDate = new String();
      String tempMeterCatCode = new String();
      String tempMrDate = new String();
      McSmrInfoBusinessBean tempBean = new McSmrInfoBusinessBean();
      McSmrInfoDetail1BusinessBean mcSmrInfoDetail1 = new McSmrInfoDetail1BusinessBean();
      for (RK_InquiryMcSmrInfoEntityBean resultUnit : resultList) {
        //計量器交換・臨時検針情報
        if (!tempFileName.equals(resultUnit.getFileName())) {
          tempFileName = resultUnit.getFileName();
          //設定
          tempBean = new McSmrInfoBusinessBean();
          if (resultUnit.getMeterChangeDate() != null) {
            mCInfoList.add(tempBean);
          } else {
            sMRInfoList.add(tempBean);
          }
          tempBean.setFileName(resultUnit.getFileName());
          tempBean.setSpotPkw(resultUnit.getSpotPkw());
          tempBean.setCoveredPeriod(resultUnit.getCoveredPeriod());
          tempBean.setMcSmrInfoDetail1List(new ArrayList<McSmrInfoDetail1BusinessBean>());
        }

        //明細１
        if ((tempMeterChangeDate != null && !tempMeterChangeDate.equals(resultUnit.getMeterChangeDate()))
            || !tempMeterCatCode.equals(resultUnit.getMeterCatCode())
            || (tempMeterChangeDate == null && resultUnit.getMeterChangeDate() != null)
            || !tempMrDate.equals(resultUnit.getMrDate())) {
          tempMeterChangeDate = resultUnit.getMeterChangeDate();
          tempMeterCatCode = resultUnit.getMeterCatCode();
          tempMrDate = resultUnit.getMrDate();
          //設定
          mcSmrInfoDetail1 = new McSmrInfoDetail1BusinessBean();
          tempBean.getMcSmrInfoDetail1List().add(mcSmrInfoDetail1);
          mcSmrInfoDetail1.setMeterChangeDate(
              StringConvertUtil.convertDateObjectToString(resultUnit.getMeterChangeDate(), "yyyy-MM-dd",
                  ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH));
          mcSmrInfoDetail1.setMeterCatCode(resultUnit.getMeterCatCode());
          mcSmrInfoDetail1.setMeterCat(resultUnit.getMeterCat());
          mcSmrInfoDetail1.setPkw(resultUnit.getPkw());
          mcSmrInfoDetail1.setFullTimeUsage(resultUnit.getFullTimeUsage());
          mcSmrInfoDetail1.setEffectiveUsage(resultUnit.getEffectiveUsage());
          mcSmrInfoDetail1.setReactiveUsage(resultUnit.getReactiveUsage());
          mcSmrInfoDetail1.setMcSmrInfoDetail2List(new ArrayList<McSmrDetail2>());
        }
        //明細２
        McSmrDetail2 mcSmrDetail2 = new McSmrDetail2();
        mcSmrInfoDetail1.getMcSmrInfoDetail2List().add(mcSmrDetail2);
        mcSmrDetail2.setMeterChangeCategoryCode(resultUnit.getMeterChangeCategoryCode());
        mcSmrDetail2.setMeterIdn(resultUnit.getMeterIdn());
        mcSmrDetail2.setMultiplyingFactor(StringConvertUtil.stringToInteger(resultUnit.getMultiplyingFactor()));
        mcSmrDetail2.setKwDisadvantageFactor(
            StringConvertUtil.stringToBigDecimal(resultUnit.getKwDisadvantageFactor()));
        mcSmrDetail2.setKwhDisadvantageFactor(
            StringConvertUtil.stringToBigDecimal(resultUnit.getKwhDisadvantageFactor()));
        mcSmrDetail2.setPd(StringConvertUtil.stringToInteger(resultUnit.getPd()));
        mcSmrDetail2.setPdIn(StringConvertUtil.stringToBigDecimal(resultUnit.getPdIn()));
        mcSmrDetail2.setFtKwhIn01(StringConvertUtil.stringToBigDecimal(resultUnit.getFtKwhIn01()));
        mcSmrDetail2.setEffectiveIn(StringConvertUtil.stringToBigDecimal(resultUnit.getEffectiveIn()));
        mcSmrDetail2.setReactiveIn(StringConvertUtil.stringToBigDecimal(resultUnit.getReactiveIn()));
      }
      businessBean.setMeterChangeInformationList(mCInfoList);
      businessBean.setSpecialMeterReadingInformationList(sMRInfoList);
      //正常終了
      businessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);
      return businessBean;
    } catch (DataAccessException e) {
      logger.error(messageSource.getMessage("error.E1129", null, Locale.getDefault()), e);
      // 照会結果設定
      businessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      businessBean.setMessage(systemErrorMessage);
      return businessBean;
    } catch (NoSuchMessageException e) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, e);
      // 照会結果設定
      businessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      businessBean.setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
      return businessBean;
    }
  }

  /**
   * 計量器交換・臨時検針情報表示マッパーのセッター(DI)
   *
   * @param rkMcSmrInfoMapper
   *          計量器交換・臨時検針情報表示マッパー
   */
  public void setRkMcSmrInfoMapper(RK_McSmrInfoMapper rkMcSmrInfoMapper) {
    this.rkMcSmrInfoMapper = rkMcSmrInfoMapper;
  }

  /**
   * メッセージプロパティのセッター(DI)
   *
   * @param messageSource
   *          メッセージプロパティ
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }

}
