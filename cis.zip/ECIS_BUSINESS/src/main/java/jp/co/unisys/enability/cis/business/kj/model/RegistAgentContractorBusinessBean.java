package jp.co.unisys.enability.cis.business.kj.model;

/**
 * 契約者情報照会で、登録情報を格納するビジネスBean
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * 契約者情報ビジネス
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RegistAgentContractorBusinessBean {

  /**
   * 契約者IDを保有する。
   */
  private Integer contractorId;

  /**
   * 契約者番号を保有する。
   */
  private String contractorNo;

  /**
   * 契約者名1（カナ）を保有する。
   */
  private String contractorName1Kana;

  /**
   * 契約者名1を保有する。
   */
  private String contractorName1;

  /**
   * 契約者名2を保有する。
   */
  private String contractorName2;

  /**
   * 契約者名1（宛名用）を保有する。
   */
  private String contractorName1MailingName;

  /**
   * 契約者名2（宛名用）を保有する。
   */
  private String contractorName2MailingName;

  /**
   * 敬称を保有する。
   */
  private String prefix;

  /**
   * 契約者住所（郵便番号）を保有する。
   */
  private String contractorAddressPostalCode;

  /**
   * 契約者住所（都道府県名）を保有する。
   */
  private String contractorAddressPrefectures;

  /**
   * 契約者住所（市区郡町村名）を保有する。
   */
  private String contractorAddressMunicipality;

  /**
   * 契約者住所（字名・丁目）を保有する。
   */
  private String contractorAddressSection;

  /**
   * 契約者住所（番地･号）を保有する。
   */
  private String contractorAddressBlock;

  /**
   * 契約者住所（建物名）を保有する。
   */
  private String contractorAddressBuildingName;

  /**
   * 契約者住所（部屋名）を保有する。
   */
  private String contractorAddressRoom;

  /**
   * 契約者電話区分コード1を保有する。
   */
  private String contractorPhoneCategoryCode1;

  /**
   * 契約者電話1（市外局番）を保有する。
   */
  private String contractorPhoneAreaCode1;

  /**
   * 契約者電話1（市内局番）を保有する。
   */
  private String contractorPhoneLocalNo1;

  /**
   * 契約者電話1（加入者番号）を保有する。
   */
  private String contractorPhoneDirectoryNo1;

  /**
   * 契約者電話区分コード2を保有する。
   */
  private String contractorPhoneCategoryCode2;

  /**
   * 契約者電話2（市外局番）を保有する。
   */
  private String contractorPhoneAreaCode2;

  /**
   * 契約者電話2（市内局番）を保有する。
   */
  private String contractorPhoneLocalNo2;

  /**
   * 契約者電話2（加入者番号）を保有する。
   */
  private String contractorPhoneDirectoryNo2;

  /**
   * 契約者メールアドレス1を保有する。
   */
  private String contractorMailAddress1;

  /**
   * 契約者メールアドレス2を保有する。
   */
  private String contractorMailAddress2;

  /**
   * 提供モデルコードを保有する。
   */
  private String provideModelCode;

  /**
   * 提供モデル企業コードを保有する。
   */
  private String provideModelCompanyCode;

  /**
   * 利用不能フラグを保有する。
   */
  private String unavailableFlag;

  /**
   * 取引先コードを保有する。
   */
  private String customerCode;

  /**
   * 督促対象外フラグを保有する。
   */
  private String urgeNotCoveredFlag;

  /**
   * 個人・法人区分コードを保有する。
   */
  private String individualLegalEntityCategoryCode;

  /**
   * 見える化提供フラグを保有する。
   */
  private String visualizationProvideFlag;

  /**
   * 備考を保有する。
   */
  private String note;

  /**
   * 卸取次店契約者番号を保有する。
   */
  private String agentContractorNo;

  /**
   * 契約者フリー項目1を保有する。
   */
  private String contractorFree1;

  /**
   * 契約者フリー項目2を保有する。
   */
  private String contractorFree2;

  /**
   * 契約者フリー項目3を保有する。
   */
  private String contractorFree3;

  /**
   * 契約者フリー項目4を保有する。
   */
  private String contractorFree4;

  /**
   * 契約者フリー項目5を保有する。
   */
  private String contractorFree5;

  /**
   * 契約者フリー項目6を保有する。
   */
  private String contractorFree6;

  /**
   * 契約者フリー項目7を保有する。
   */
  private String contractorFree7;

  /**
   * 契約者フリー項目8を保有する。
   */
  private String contractorFree8;

  /**
   * 契約者フリー項目9を保有する。
   */
  private String contractorFree9;

  /**
   * 契約者フリー項目10を保有する。
   */
  private String contractorFree10;

  /**
   * リターンコードを保有する。
   */
  private String returnCode;

  /**
   * メッセージを保有する。
   */
  private String message;

  /**
   * 契約者IDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者IDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者ID
   */
  public Integer getContractorId() {
    return this.contractorId;
  }

  /**
   * 契約者IDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者IDを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorId
   *          契約者ID
   */
  public void setContractorId(Integer contractorId) {
    this.contractorId = contractorId;
  }

  /**
   * 契約者番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者番号を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者番号
   */
  public String getContractorNo() {
    return this.contractorNo;
  }

  /**
   * 契約者番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者番号を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorNo
   *          契約者番号
   */
  public void setContractorNo(String contractorNo) {
    this.contractorNo = contractorNo;
  }

  /**
   * 契約者名1（カナ）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者名1（カナ）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者名1（カナ）
   */
  public String getContractorName1Kana() {
    return this.contractorName1Kana;
  }

  /**
   * 契約者名1（カナ）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者名1（カナ）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorName1Kana
   *          契約者名1（カナ）
   */
  public void setContractorName1Kana(String contractorName1Kana) {
    this.contractorName1Kana = contractorName1Kana;
  }

  /**
   * 契約者名1のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者名1を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者名1
   */
  public String getContractorName1() {
    return this.contractorName1;
  }

  /**
   * 契約者名1のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者名1を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorName1
   *          契約者名1
   */
  public void setContractorName1(String contractorName1) {
    this.contractorName1 = contractorName1;
  }

  /**
   * 契約者名2のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者名2を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者名2
   */
  public String getContractorName2() {
    return this.contractorName2;
  }

  /**
   * 契約者名2のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者名2を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorName2
   *          契約者名2
   */
  public void setContractorName2(String contractorName2) {
    this.contractorName2 = contractorName2;
  }

  /**
   * 契約者名1（宛名用）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者名1（宛名用）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者名1（宛名用）
   */
  public String getContractorName1MailingName() {
    return this.contractorName1MailingName;
  }

  /**
   * 契約者名1（宛名用）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者名1（宛名用）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorName1MailingName
   *          契約者名1（宛名用）
   */
  public void setContractorName1MailingName(String contractorName1MailingName) {
    this.contractorName1MailingName = contractorName1MailingName;
  }

  /**
   * 契約者名2（宛名用）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者名2（宛名用）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者名2（宛名用）
   */
  public String getContractorName2MailingName() {
    return this.contractorName2MailingName;
  }

  /**
   * 契約者名2（宛名用）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者名2（宛名用）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorName2MailingName
   *          契約者名2（宛名用）
   */
  public void setContractorName2MailingName(String contractorName2MailingName) {
    this.contractorName2MailingName = contractorName2MailingName;
  }

  /**
   * 敬称のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 敬称を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 敬称
   */
  public String getPrefix() {
    return this.prefix;
  }

  /**
   * 敬称のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 敬称を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param prefix
   *          敬称
   */
  public void setPrefix(String prefix) {
    this.prefix = prefix;
  }

  /**
   * 契約者住所（郵便番号）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者住所（郵便番号）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者住所（郵便番号）
   */
  public String getContractorAddressPostalCode() {
    return this.contractorAddressPostalCode;
  }

  /**
   * 契約者住所（郵便番号）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者住所（郵便番号）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorAddressPostalCode
   *          契約者住所（郵便番号）
   */
  public void setContractorAddressPostalCode(
      String contractorAddressPostalCode) {
    this.contractorAddressPostalCode = contractorAddressPostalCode;
  }

  /**
   * 契約者住所（都道府県名）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者住所（都道府県名）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者住所（都道府県名）
   */
  public String getContractorAddressPrefectures() {
    return this.contractorAddressPrefectures;
  }

  /**
   * 契約者住所（都道府県名）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者住所（都道府県名）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorAddressPrefectures
   *          契約者住所（都道府県名）
   */
  public void setContractorAddressPrefectures(
      String contractorAddressPrefectures) {
    this.contractorAddressPrefectures = contractorAddressPrefectures;
  }

  /**
   * 契約者住所（市区郡町村名）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者住所（市区郡町村名）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者住所（市区郡町村名）
   */
  public String getContractorAddressMunicipality() {
    return this.contractorAddressMunicipality;
  }

  /**
   * 契約者住所（市区郡町村名）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者住所（市区郡町村名）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorAddressMunicipality
   *          契約者住所（市区郡町村名）
   */
  public void setContractorAddressMunicipality(
      String contractorAddressMunicipality) {
    this.contractorAddressMunicipality = contractorAddressMunicipality;
  }

  /**
   * 契約者住所（字名・丁目）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者住所（字名・丁目）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者住所（字名・丁目）
   */
  public String getContractorAddressSection() {
    return this.contractorAddressSection;
  }

  /**
   * 契約者住所（字名・丁目）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者住所（字名・丁目）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorAddressSection
   *          契約者住所（字名・丁目）
   */
  public void setContractorAddressSection(String contractorAddressSection) {
    this.contractorAddressSection = contractorAddressSection;
  }

  /**
   * 契約者住所（番地･号）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者住所（番地･号）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者住所（番地･号）
   */
  public String getContractorAddressBlock() {
    return this.contractorAddressBlock;
  }

  /**
   * 契約者住所（番地･号）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者住所（番地･号）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorAddressBlock
   *          契約者住所（番地･号）
   */
  public void setContractorAddressBlock(String contractorAddressBlock) {
    this.contractorAddressBlock = contractorAddressBlock;
  }

  /**
   * 契約者住所（建物名）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者住所（建物名）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者住所（建物名）
   */
  public String getContractorAddressBuildingName() {
    return this.contractorAddressBuildingName;
  }

  /**
   * 契約者住所（建物名）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者住所（建物名）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorAddressBuildingName
   *          契約者住所（建物名）
   */
  public void setContractorAddressBuildingName(
      String contractorAddressBuildingName) {
    this.contractorAddressBuildingName = contractorAddressBuildingName;
  }

  /**
   * 契約者住所（部屋名）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者住所（部屋名）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者住所（部屋名）
   */
  public String getContractorAddressRoom() {
    return this.contractorAddressRoom;
  }

  /**
   * 契約者住所（部屋名）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者住所（部屋名）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorAddressRoom
   *          契約者住所（部屋名）
   */
  public void setContractorAddressRoom(String contractorAddressRoom) {
    this.contractorAddressRoom = contractorAddressRoom;
  }

  /**
   * 契約者電話区分コード1のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者電話区分コード1を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者電話区分コード1
   */
  public String getContractorPhoneCategoryCode1() {
    return this.contractorPhoneCategoryCode1;
  }

  /**
   * 契約者電話区分コード1のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者電話区分コード1を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorPhoneCategoryCode1
   *          契約者電話区分コード1
   */
  public void setContractorPhoneCategoryCode1(
      String contractorPhoneCategoryCode1) {
    this.contractorPhoneCategoryCode1 = contractorPhoneCategoryCode1;
  }

  /**
   * 契約者電話1（市外局番）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者電話1（市外局番）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者電話1（市外局番）
   */
  public String getContractorPhoneAreaCode1() {
    return this.contractorPhoneAreaCode1;
  }

  /**
   * 契約者電話1（市外局番）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者電話1（市外局番）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorPhoneAreaCode1
   *          契約者電話1（市外局番）
   */
  public void setContractorPhoneAreaCode1(String contractorPhoneAreaCode1) {
    this.contractorPhoneAreaCode1 = contractorPhoneAreaCode1;
  }

  /**
   * 契約者電話1（市内局番）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者電話1（市内局番）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者電話1（市内局番）
   */
  public String getContractorPhoneLocalNo1() {
    return this.contractorPhoneLocalNo1;
  }

  /**
   * 契約者電話1（市内局番）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者電話1（市内局番）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorPhoneLocalNo1
   *          契約者電話1（市内局番）
   */
  public void setContractorPhoneLocalNo1(String contractorPhoneLocalNo1) {
    this.contractorPhoneLocalNo1 = contractorPhoneLocalNo1;
  }

  /**
   * 契約者電話1（加入者番号）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者電話1（加入者番号）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者電話1（加入者番号）
   */
  public String getContractorPhoneDirectoryNo1() {
    return this.contractorPhoneDirectoryNo1;
  }

  /**
   * 契約者電話1（加入者番号）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者電話1（加入者番号）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorPhoneDirectoryNo1
   *          契約者電話1（加入者番号）
   */
  public void setContractorPhoneDirectoryNo1(
      String contractorPhoneDirectoryNo1) {
    this.contractorPhoneDirectoryNo1 = contractorPhoneDirectoryNo1;
  }

  /**
   * 契約者電話区分コード2のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者電話区分コード2を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者電話区分コード2
   */
  public String getContractorPhoneCategoryCode2() {
    return this.contractorPhoneCategoryCode2;
  }

  /**
   * 契約者電話区分コード2のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者電話区分コード2を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorPhoneCategoryCode2
   *          契約者電話区分コード2
   */
  public void setContractorPhoneCategoryCode2(
      String contractorPhoneCategoryCode2) {
    this.contractorPhoneCategoryCode2 = contractorPhoneCategoryCode2;
  }

  /**
   * 契約者電話2（市外局番）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者電話2（市外局番）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者電話2（市外局番）
   */
  public String getContractorPhoneAreaCode2() {
    return this.contractorPhoneAreaCode2;
  }

  /**
   * 契約者電話2（市外局番）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者電話2（市外局番）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorPhoneAreaCode2
   *          契約者電話2（市外局番）
   */
  public void setContractorPhoneAreaCode2(String contractorPhoneAreaCode2) {
    this.contractorPhoneAreaCode2 = contractorPhoneAreaCode2;
  }

  /**
   * 契約者電話2（市内局番）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者電話2（市内局番）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者電話2（市内局番）
   */
  public String getContractorPhoneLocalNo2() {
    return this.contractorPhoneLocalNo2;
  }

  /**
   * 契約者電話2（市内局番）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者電話2（市内局番）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorPhoneLocalNo2
   *          契約者電話2（市内局番）
   */
  public void setContractorPhoneLocalNo2(String contractorPhoneLocalNo2) {
    this.contractorPhoneLocalNo2 = contractorPhoneLocalNo2;
  }

  /**
   * 契約者電話2（加入者番号）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者電話2（加入者番号）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者電話2（加入者番号）
   */
  public String getContractorPhoneDirectoryNo2() {
    return this.contractorPhoneDirectoryNo2;
  }

  /**
   * 契約者電話2（加入者番号）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者電話2（加入者番号）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorPhoneDirectoryNo2
   *          契約者電話2（加入者番号）
   */
  public void setContractorPhoneDirectoryNo2(
      String contractorPhoneDirectoryNo2) {
    this.contractorPhoneDirectoryNo2 = contractorPhoneDirectoryNo2;
  }

  /**
   * 契約者メールアドレス1のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者メールアドレス1を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者メールアドレス1
   */
  public String getContractorMailAddress1() {
    return this.contractorMailAddress1;
  }

  /**
   * 契約者メールアドレス1のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者メールアドレス1を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorMailAddress1
   *          契約者メールアドレス1
   */
  public void setContractorMailAddress1(String contractorMailAddress1) {
    this.contractorMailAddress1 = contractorMailAddress1;
  }

  /**
   * 契約者メールアドレス2のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者メールアドレス2を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者メールアドレス2
   */
  public String getContractorMailAddress2() {
    return this.contractorMailAddress2;
  }

  /**
   * 契約者メールアドレス2のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者メールアドレス2を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorMailAddress2
   *          契約者メールアドレス2
   */
  public void setContractorMailAddress2(String contractorMailAddress2) {
    this.contractorMailAddress2 = contractorMailAddress2;
  }

  /**
   * 提供モデルコードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 提供モデルコードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 提供モデルコード
   */
  public String getProvideModelCode() {
    return this.provideModelCode;
  }

  /**
   * 提供モデルコードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 提供モデルコードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param provideModelCode
   *          提供モデルコード
   */
  public void setProvideModelCode(String provideModelCode) {
    this.provideModelCode = provideModelCode;
  }

  /**
   * 提供モデル企業コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 提供モデル企業コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 提供モデル企業コード
   */
  public String getProvideModelCompanyCode() {
    return this.provideModelCompanyCode;
  }

  /**
   * 提供モデル企業コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 提供モデル企業コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param provideModelCompanyCode
   *          提供モデル企業コード
   */
  public void setProvideModelCompanyCode(String provideModelCompanyCode) {
    this.provideModelCompanyCode = provideModelCompanyCode;
  }

  /**
   * 利用不能フラグのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 利用不能フラグを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 利用不能フラグ
   */
  public String getUnavailableFlag() {
    return this.unavailableFlag;
  }

  /**
   * 利用不能フラグのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 利用不能フラグを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param unavailableFlag
   *          利用不能フラグ
   */
  public void setUnavailableFlag(String unavailableFlag) {
    this.unavailableFlag = unavailableFlag;
  }

  /**
   * 取引先コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 取引先コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 取引先コード
   */
  public String getCustomerCode() {
    return this.customerCode;
  }

  /**
   * 取引先コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 取引先コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param customerCode
   *          取引先コード
   */
  public void setCustomerCode(String customerCode) {
    this.customerCode = customerCode;
  }

  /**
   * 督促対象外フラグのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 督促対象外フラグを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 督促対象外フラグ
   */
  public String getUrgeNotCoveredFlag() {
    return this.urgeNotCoveredFlag;
  }

  /**
   * 督促対象外フラグのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 督促対象外フラグを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param urgeNotCoveredFlag
   *          督促対象外フラグ
   */
  public void setUrgeNotCoveredFlag(String urgeNotCoveredFlag) {
    this.urgeNotCoveredFlag = urgeNotCoveredFlag;
  }

  /**
   * 個人・法人区分コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 個人・法人区分コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 個人・法人区分コード
   */
  public String getIndividualLegalEntityCategoryCode() {
    return this.individualLegalEntityCategoryCode;
  }

  /**
   * 個人・法人区分コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 個人・法人区分コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param individualLegalEntityCategoryCode
   *          個人・法人区分コード
   */
  public void setIndividualLegalEntityCategoryCode(
      String individualLegalEntityCategoryCode) {
    this.individualLegalEntityCategoryCode = individualLegalEntityCategoryCode;
  }

  /**
   * 見える化提供フラグのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 見える化提供フラグを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 見える化提供フラグ
   */
  public String getVisualizationProvideFlag() {
    return this.visualizationProvideFlag;
  }

  /**
   * 見える化提供フラグのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 見える化提供フラグを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param visualizationProvideFlag
   *          見える化提供フラグ
   */
  public void setVisualizationProvideFlag(String visualizationProvideFlag) {
    this.visualizationProvideFlag = visualizationProvideFlag;
  }

  /**
   * 備考のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 備考を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 備考
   */
  public String getNote() {
    return this.note;
  }

  /**
   * 備考のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 備考を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param note
   *          備考
   */
  public void setNote(String note) {
    this.note = note;
  }

  /**
   * 卸取次店契約者番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 卸取次店契約者番号を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 卸取次店契約者番号
   */
  public String getAgentContractorNo() {
    return agentContractorNo;
  }

  /**
   * 卸取次店契約者番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 卸取次店契約者番号を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param agentContractorNo
   *          卸取次店契約者番号
   */
  public void setAgentContractorNo(String agentContractorNo) {
    this.agentContractorNo = agentContractorNo;
  }

  /**
   * 契約者フリー項目1のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者フリー項目1を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者フリー項目1
   */
  public String getContractorFree1() {
    return contractorFree1;
  }

  /**
   * 契約者フリー項目1のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者フリー項目1を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorFree1
   *          契約者フリー項目1
   */
  public void setContractorFree1(String contractorFree1) {
    this.contractorFree1 = contractorFree1;
  }

  /**
   * 契約者フリー項目2のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者フリー項目2を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者フリー項目2
   */
  public String getContractorFree2() {
    return contractorFree2;
  }

  /**
   * 契約者フリー項目2のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者フリー項目2を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorFree2
   *          契約者フリー項目2
   */
  public void setContractorFree2(String contractorFree2) {
    this.contractorFree2 = contractorFree2;
  }

  /**
   * 契約者フリー項目3のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者フリー項目3を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者フリー項目3
   */
  public String getContractorFree3() {
    return contractorFree3;
  }

  /**
   * 契約者フリー項目3のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者フリー項目3を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorFree3
   *          契約者フリー項目3
   */
  public void setContractorFree3(String contractorFree3) {
    this.contractorFree3 = contractorFree3;
  }

  /**
   * 契約者フリー項目4のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者フリー項目4を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者フリー項目4
   */
  public String getContractorFree4() {
    return contractorFree4;
  }

  /**
   * 契約者フリー項目4のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者フリー項目4を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorFree4
   *          契約者フリー項目4
   */
  public void setContractorFree4(String contractorFree4) {
    this.contractorFree4 = contractorFree4;
  }

  /**
   * 契約者フリー項目5のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者フリー項目5を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者フリー項目5
   */
  public String getContractorFree5() {
    return contractorFree5;
  }

  /**
   * 契約者フリー項目5のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者フリー項目5を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorFree5
   *          契約者フリー項目5
   */
  public void setContractorFree5(String contractorFree5) {
    this.contractorFree5 = contractorFree5;
  }

  /**
   * 契約者フリー項目6のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者フリー項目6を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者フリー項目6
   */
  public String getContractorFree6() {
    return contractorFree6;
  }

  /**
   * 契約者フリー項目6のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者フリー項目6を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorFree6
   *          契約者フリー項目6
   */
  public void setContractorFree6(String contractorFree6) {
    this.contractorFree6 = contractorFree6;
  }

  /**
   * 契約者フリー項目7のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者フリー項目7を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者フリー項目7
   */
  public String getContractorFree7() {
    return contractorFree7;
  }

  /**
   * 契約者フリー項目7のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者フリー項目7を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorFree7
   *          契約者フリー項目7
   */
  public void setContractorFree7(String contractorFree7) {
    this.contractorFree7 = contractorFree7;
  }

  /**
   * 契約者フリー項目8のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者フリー項目8を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者フリー項目8
   */
  public String getContractorFree8() {
    return contractorFree8;
  }

  /**
   * 契約者フリー項目8のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者フリー項目8を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorFree8
   *          契約者フリー項目8
   */
  public void setContractorFree8(String contractorFree8) {
    this.contractorFree8 = contractorFree8;
  }

  /**
   * 契約者フリー項目9のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者フリー項目9を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者フリー項目9
   */
  public String getContractorFree9() {
    return contractorFree9;
  }

  /**
   * 契約者フリー項目9のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者フリー項目9を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorFree9
   *          契約者フリー項目9
   */
  public void setContractorFree9(String contractorFree9) {
    this.contractorFree9 = contractorFree9;
  }

  /**
   * 契約者フリー項目10のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者フリー項目10を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者フリー項目10
   */
  public String getContractorFree10() {
    return contractorFree10;
  }

  /**
   * 契約者フリー項目10のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者フリー項目10を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorFree10
   *          契約者フリー項目10
   */
  public void setContractorFree10(String contractorFree10) {
    this.contractorFree10 = contractorFree10;
  }

  /**
   * リターンコードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return リターンコード
   */
  public String getReturnCode() {
    return this.returnCode;
  }

  /**
   * リターンコードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param returnCode
   *          リターンコード
   */
  public void setReturnCode(String returnCode) {
    this.returnCode = returnCode;
  }

  /**
   * メッセージのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return メッセージ
   */
  public String getMessage() {
    return this.message;
  }

  /**
   * メッセージのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param message
   *          メッセージ
   */
  public void setMessage(String message) {
    this.message = message;
  }
}
