package jp.co.unisys.enability.cis.business.kj;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.util.CollectionUtils;

import jp.co.unisys.enability.cis.business.common.DateBusiness;
import jp.co.unisys.enability.cis.business.kj.model.InquiryAgentContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.InquiryAgentContractorBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.InquiryProvideModelCompanyBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.RegistAgentContractorBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.UpdateAgentContractorBusinessBean;
import jp.co.unisys.enability.cis.common.Exception.BusinessLogicException;
import jp.co.unisys.enability.cis.common.Exception.SystemException;
import jp.co.unisys.enability.cis.common.util.KJ_CommonUtil;
import jp.co.unisys.enability.cis.common.util.ThreadContext;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISKJConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISReturnCodeConstants;
import jp.co.unisys.enability.cis.entity.common.Contractor;
import jp.co.unisys.enability.cis.entity.common.ContractorAddInfo;
import jp.co.unisys.enability.cis.entity.common.ContractorExample;
import jp.co.unisys.enability.cis.entity.common.PaymentExample;
import jp.co.unisys.enability.cis.entity.kj.KJ_InquiryAgentContractorInformationEntityBean;
import jp.co.unisys.enability.cis.mapper.common.ContractorAddInfoMapper;
import jp.co.unisys.enability.cis.mapper.common.ContractorMapper;
import jp.co.unisys.enability.cis.mapper.common.IlcMMapper;
import jp.co.unisys.enability.cis.mapper.common.PaymentMapper;
import jp.co.unisys.enability.cis.mapper.common.PhoneNoCatMMapper;
import jp.co.unisys.enability.cis.mapper.kj.AgentContractorInformationCommonMapper;

/**
 * 契約者情報ビジネス
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.kj.KJ_AgentContractorInformationBusiness
 *
 */
public class KJ_AgentContractorInformationBusinessImpl implements
    KJ_AgentContractorInformationBusiness {

  /**
   * 契約者情報共通マッパー(DI)
   */
  private AgentContractorInformationCommonMapper contractorInformationCommonMapper;

  /**
   * 電話番号区分マッパー(DI)
   */
  private PhoneNoCatMMapper phoneNoCatMMapper;

  /**
   * マスタ情報マッパー(DI)
   */
  private KJ_MasterInformationBusiness kjMasterInformationBusiness;

  /**
   * 個人法人マスターマッパー(DI)
   */
  private IlcMMapper ilcMMapper;

  /**
   * 契約者情報マッパー(DI)
   */
  private ContractorMapper contractorMapper;

  /**
   * 契約者付加情報マッパー
   */
  private ContractorAddInfoMapper contractorAddInfoMapper;

  /**
   * 支払マッパー(DI)
   */
  private PaymentMapper paymentMapper;

  /**
   * 日付関連共通ビジネスインタフェース(DI)
   */
  private DateBusiness dateBusiness;

  /**
   * 契約情報ビジネス(DI)
   */
  private KJ_AgentContractInformationBusiness kjContractInformationBusiness;

  /**
   * メッセージプロパティ(DI)
   */
  private MessageSource messageSource;

  /**
   * ログマネジャー
   */
  private static Logger logger = LogManager.getLogger();

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.kj.KJ_AgentContractorInformationBusiness
   * #inquiry (jp.co.unisys.enability.cis.business.kj.model.
   * InquiryAgentContractorBusinessBean )
   */
  @Override
  public InquiryAgentContractorBusinessBean inquiry(
      InquiryAgentContractorBusinessBean inquiryBean) {

    // 契約者情報照会条件Map
    Map<String, Object> conditionsMap = new HashMap<String, Object>();

    // DataAccessException用エラーメッセージ
    String dataAccessExceptionEMsg = null;

    try {

      dataAccessExceptionEMsg = messageSource.getMessage(KJ_CommonUtil
          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G017),
          new String[] {}, Locale.getDefault());

      // 《契約者情報共通DAO》.契約者情報取得を呼び出す。
      // 照会結果設定
      // 条件Map.契約者ID
      conditionsMap.put("contractorId", inquiryBean.getContractorId());
      // 条件Map.契約者番号
      conditionsMap.put("contractorNo", inquiryBean.getContractorNo());
      List<KJ_InquiryAgentContractorInformationEntityBean> inquiryContractorInformationEntityBeanList = contractorInformationCommonMapper
          .selectContractor(conditionsMap);
      inquiryBean
          .setAgentContractorInformationList(inquiryContractorInformationEntityBeanList);
      // 正常終了
      inquiryBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);

    } catch (DataAccessException e) {
      logger.error(
          messageSource.getMessage("error.E1129", null,
              Locale.getDefault()),
          e);
      // catch 業務例外クラス
      inquiryBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      inquiryBean.setMessage(dataAccessExceptionEMsg);

    } catch (NoSuchMessageException e) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, e);
      inquiryBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      inquiryBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
    }
    return inquiryBean;
  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.kj.KJ_AgentContractorInformationBusiness
   * #regist (jp.co.unisys.enability.cis.business.kj.model.
   * RegistAgentContractorBusinessBean )
   */
  @Override
  public RegistAgentContractorBusinessBean regist(
      RegistAgentContractorBusinessBean registContractorBusinessBean) {

    // BusinessLogicException用エラーメッセージ
    String businessLogicExceptionEMsg = null;

    // DuplicateKeyException用エラーメッセージ
    String duplicateKeyExceptionEMsg = null;

    // 提供モデル企業一覧照会BusinessBean
    InquiryProvideModelCompanyBusinessBean inquiryProvideModelCompanyBusinessBean;

    // 契約者Entity
    Contractor contractor;

    // 契約者付加Entity
    ContractorAddInfo contractorAddInfo;

    try {

      businessLogicExceptionEMsg = messageSource.getMessage(KJ_CommonUtil
          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G017),
          new String[] {}, Locale.getDefault());

      duplicateKeyExceptionEMsg = messageSource.getMessage(KJ_CommonUtil
          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D023),
          new String[] {}, Locale.getDefault());

      // DB存在チェック
      // 《電話番号区分Mapper》.検索（主キー）電話番号区分1の取得結果が0件の場合
      if (contractorPhoneCategoryCodeCheck(registContractorBusinessBean
          .getContractorPhoneCategoryCode1())) {

        registContractorBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P019);
        registContractorBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P019),
                new String[] {}, Locale.getDefault()));

        return registContractorBusinessBean;

      }
      // 《電話番号区分Mapper》.検索（主キー）電話番号区分2の取得結果が0件の場合
      if (contractorPhoneCategoryCodeCheck(registContractorBusinessBean
          .getContractorPhoneCategoryCode2())) {

        registContractorBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P019);
        registContractorBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P019),
                new String[] {}, Locale.getDefault()));
        return registContractorBusinessBean;

      }
      inquiryProvideModelCompanyBusinessBean = new InquiryProvideModelCompanyBusinessBean();
      // 《提供モデル企業一覧照会BusinessBean》.提供モデルコードに《契約者情報登録BusinessBean》.提供モデルコードを設定する。
      inquiryProvideModelCompanyBusinessBean
          .setProvideModelCode(registContractorBusinessBean
              .getProvideModelCode());
      // 《提供モデル企業一覧照会BusinessBean》.提供モデル企業コードに《契約者情報登録BusinessBean》.提供モデル企業コードを設定する。
      inquiryProvideModelCompanyBusinessBean
          .setProvideModelCompanyCode(registContractorBusinessBean
              .getProvideModelCompanyCode());
      // 《提供モデル企業一覧照会BusinessBean》.提供モデル企業有効フラグに“1”を設定する。
      inquiryProvideModelCompanyBusinessBean
          .setProvideModelCompanyEffectiveFlag(ECISKJConstants.PROVIDE_MODEL_COMPANYEFFECTIVE_FLAG_ALL);
      // 提供モデル企業一覧照会
      inquiryProvideModelCompanyBusinessBean = kjMasterInformationBusiness
          .inquiryProvideModelCompany(inquiryProvideModelCompanyBusinessBean);
      // 《提供モデル企業一覧照会BusinessBean》.リターンコードが“0000”以外の場合
      if (!ECISReturnCodeConstants.RETURN_CODE_0000
          .equals(inquiryProvideModelCompanyBusinessBean
              .getReturnCode())) {

        throw new BusinessLogicException(messageSource.getMessage(
            "error.E1287", new String[] {}, Locale.getDefault()),
            false);
      }
      // 《提供モデル企業一覧照会BusinessBean》.提供モデル情報リストの返却値が0件の場合
      if (CollectionUtils.isEmpty(inquiryProvideModelCompanyBusinessBean
          .getProvideModelList())) {

        registContractorBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P040);
        registContractorBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P040),
                new String[] {}, Locale.getDefault()));
        return registContractorBusinessBean;

      }
      // 《個人・法人区分マスタDao》.検索（主キー）の返却値が0件の場合
      if (ilcMMapper.selectByPrimaryKey(registContractorBusinessBean
          .getIndividualLegalEntityCategoryCode()) == null) {

        registContractorBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P021);
        registContractorBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P021),
                new String[] {}, Locale.getDefault()));
        return registContractorBusinessBean;

      }
      // 契約者情報登録
      Timestamp systemDate = new Timestamp(System.currentTimeMillis());
      contractor = new Contractor();
      // 契約者番号
      contractor.setContractorNo(registContractorBusinessBean
          .getContractorNo());
      // 契約者名1（カナ）
      contractor.setCn1Kana(registContractorBusinessBean
          .getContractorName1Kana());
      // 契約者名1
      contractor
          .setCn1(registContractorBusinessBean.getContractorName1());
      // 契約者名2
      contractor
          .setCn2(registContractorBusinessBean.getContractorName2());
      // 契約者名1（宛名用）
      contractor.setCn1MailingName(registContractorBusinessBean
          .getContractorName1MailingName());
      // 契約者名2（宛名用）
      contractor.setCn2MailingName(registContractorBusinessBean
          .getContractorName2MailingName());
      // 敬称
      contractor.setPrefix(registContractorBusinessBean.getPrefix());
      // 契約者住所（郵便番号）
      contractor.setCaPostalCode(registContractorBusinessBean
          .getContractorAddressPostalCode());
      // 契約者住所（都道府県名）
      contractor.setCaPrefectures(registContractorBusinessBean
          .getContractorAddressPrefectures());
      // 契約者住所（市区郡町村名）
      contractor.setCaMunicipality(registContractorBusinessBean
          .getContractorAddressMunicipality());
      // 契約者住所（字名・丁目）
      contractor.setCaSection(registContractorBusinessBean
          .getContractorAddressSection());
      // 契約者住所（番地･号）
      contractor.setCaBlock(registContractorBusinessBean
          .getContractorAddressBlock());
      // 契約者住所（建物名）
      contractor.setCaBuildingName(registContractorBusinessBean
          .getContractorAddressBuildingName());
      // 契約者住所（部屋名）
      contractor.setCaRoom(registContractorBusinessBean
          .getContractorAddressRoom());
      // 契約者電話区分コード1
      contractor.setCphCatCode1(registContractorBusinessBean
          .getContractorPhoneCategoryCode1());
      // 契約者電話1（市外局番）
      contractor.setCphAreaCode1(registContractorBusinessBean
          .getContractorPhoneAreaCode1());
      // 契約者電話1（市内局番）
      contractor.setCphLocalNo1(registContractorBusinessBean
          .getContractorPhoneLocalNo1());
      // 契約者電話1（加入者番号）
      contractor.setCphDirectoryNo1(registContractorBusinessBean
          .getContractorPhoneDirectoryNo1());
      // 契約者電話区分コード2
      contractor.setCphCatCode2(registContractorBusinessBean
          .getContractorPhoneCategoryCode2());
      // 契約者電話2（市外局番）
      contractor.setCphAreaCode2(registContractorBusinessBean
          .getContractorPhoneAreaCode2());
      // 契約者電話2（市内局番）
      contractor.setCphLocalNo2(registContractorBusinessBean
          .getContractorPhoneLocalNo2());
      // 契約者電話2（加入者番号）
      contractor.setCphDirectoryNo2(registContractorBusinessBean
          .getContractorPhoneDirectoryNo2());
      // 契約者メールアドレス1
      contractor.setCma1(registContractorBusinessBean
          .getContractorMailAddress1());
      // 契約者メールアドレス1
      contractor.setCma2(registContractorBusinessBean
          .getContractorMailAddress2());
      // 提供モデルコード
      contractor.setPmCode(registContractorBusinessBean
          .getProvideModelCode());
      // 提供モデル企業コード
      contractor.setPmCompanyCode(registContractorBusinessBean
          .getProvideModelCompanyCode());
      // 利用不能フラグ
      // 《契約者情報登録BusinessBean》.利用不能フラグがnullまたは空文字以外の場合
      if (StringUtils.isNotEmpty(registContractorBusinessBean
          .getUnavailableFlag())) {
        contractor.setUnavailableFlag(registContractorBusinessBean
            .getUnavailableFlag());
      } else {
        contractor
            .setUnavailableFlag(ECISKJConstants.UNAVAILABLE_FLAG_USE_POSSIBLE);
      }
      // 取引先コード
      contractor.setCustomerCode(registContractorBusinessBean
          .getCustomerCode());
      // 督促対象外フラグ
      contractor.setUrgeNotCoveredFlag(registContractorBusinessBean
          .getUrgeNotCoveredFlag());
      // 個人・法人区分コード
      contractor.setIlcCode(registContractorBusinessBean
          .getIndividualLegalEntityCategoryCode());
      // 見える化提供フラグ
      contractor.setVisualizationProvideFlag(registContractorBusinessBean
          .getVisualizationProvideFlag());
      // 備考
      contractor.setNote(registContractorBusinessBean.getNote());
      // 契約者住所(住所)
      contractor.setCaFull(registCaFullStrBuilder(
          registContractorBusinessBean
              .getContractorAddressPrefectures(),
          registContractorBusinessBean
              .getContractorAddressMunicipality(),
          registContractorBusinessBean.getContractorAddressSection(),
          registContractorBusinessBean.getContractorAddressBlock()));
      // 契約者住所(建物・部屋名)
      contractor.setCaBuilding(registCaBuildingStrBuilder(
          registContractorBusinessBean
              .getContractorAddressBuildingName(),
          registContractorBusinessBean.getContractorAddressRoom()));
      // 契約者電話番号1
      contractor.setCphNo1(cphNoStrBuilder(registContractorBusinessBean
          .getContractorPhoneAreaCode1(),
          registContractorBusinessBean.getContractorPhoneLocalNo1(),
          registContractorBusinessBean
              .getContractorPhoneDirectoryNo1()));
      // 契約者電話番号2
      contractor.setCphNo2(cphNoStrBuilder(registContractorBusinessBean
          .getContractorPhoneAreaCode2(),
          registContractorBusinessBean.getContractorPhoneLocalNo2(),
          registContractorBusinessBean
              .getContractorPhoneDirectoryNo2()));
      // 更新回数
      contractor.setUpdateCount(0);
      // 作成日時
      contractor.setCreateTime(systemDate);
      // オンライン更新日時
      contractor.setOnlineUpdateTime(systemDate);
      // オンライン更新ユーザID
      contractor.setOnlineUpdateUserId(ThreadContext
          .getRequestThreadContext().get(ECISConstants.USER_ID_KEY)
          .toString());
      // 更新日時
      contractor.setUpdateTime(systemDate);
      // 更新モジュールコード
      contractor.setUpdateModuleCode(ThreadContext
          .getRequestThreadContext()
          .get(ECISConstants.CLASS_NAME_KEY).toString());
      // 《契約者情報共通Dao》.契約者情報登録を呼び出す。
      contractorMapper.insertBySequence(contractor);
      registContractorBusinessBean.setContractorId(contractor
          .getContractorId());

      // 契約者付加情報登録
      contractorAddInfo = new ContractorAddInfo();

      // 契約者番号
      contractorAddInfo.setContractorId(registContractorBusinessBean
          .getContractorId());
      // 卸取次店契約者番号
      contractorAddInfo.setAgentContractorNo(registContractorBusinessBean
          .getAgentContractorNo());
      // 契約者フリー項目1
      contractorAddInfo.setFree1(registContractorBusinessBean
          .getContractorFree1());
      // 契約者フリー項目2
      contractorAddInfo.setFree2(registContractorBusinessBean
          .getContractorFree2());
      // 契約者フリー項目3
      contractorAddInfo.setFree3(registContractorBusinessBean
          .getContractorFree3());
      // 契約者フリー項目4
      contractorAddInfo.setFree4(registContractorBusinessBean
          .getContractorFree4());
      // 契約者フリー項目5
      contractorAddInfo.setFree5(registContractorBusinessBean
          .getContractorFree5());
      // 契約者フリー項目6
      contractorAddInfo.setFree6(registContractorBusinessBean
          .getContractorFree6());
      // 契約者フリー項目7
      contractorAddInfo.setFree7(registContractorBusinessBean
          .getContractorFree7());
      // 契約者フリー項目8
      contractorAddInfo.setFree8(registContractorBusinessBean
          .getContractorFree8());
      // 契約者フリー項目9
      contractorAddInfo.setFree9(registContractorBusinessBean
          .getContractorFree9());
      // 契約者フリー項目10
      contractorAddInfo.setFree10(registContractorBusinessBean
          .getContractorFree10());
      // 更新回数
      contractorAddInfo.setUpdateCount(0);
      // 作成日時
      contractorAddInfo.setCreateTime(systemDate);
      // オンライン更新日時
      contractorAddInfo.setOnlineUpdateTime(systemDate);
      // オンライン更新ユーザID
      contractorAddInfo.setOnlineUpdateUserId(ThreadContext
          .getRequestThreadContext().get(ECISConstants.USER_ID_KEY)
          .toString());
      // 更新日時
      contractorAddInfo.setUpdateTime(systemDate);
      // 更新モジュールコード
      contractorAddInfo.setUpdateModuleCode(ThreadContext
          .getRequestThreadContext()
          .get(ECISConstants.CLASS_NAME_KEY).toString());
      // 《契約者付加情報共通Dao》.契約者情報付加登録を呼び出す。
      contractorAddInfoMapper.insert(contractorAddInfo);

      // 正常終了
      registContractorBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);

    } catch (DuplicateKeyException e) {
      logger.error(
          messageSource.getMessage("error.E1129", null,
              Locale.getDefault()),
          e);
      // 重複例外クラス
      registContractorBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D023);
      registContractorBusinessBean.setMessage(duplicateKeyExceptionEMsg);
    } catch (DataIntegrityViolationException dataIntegrityViolationException) {
      logger.error(
          messageSource.getMessage("error.E1129", null,
              Locale.getDefault()),
          dataIntegrityViolationException);
      // 制約違反例外クラス
      registContractorBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D023);
      registContractorBusinessBean.setMessage(duplicateKeyExceptionEMsg);
    } catch (BusinessLogicException e) {
      logger.error(
          messageSource.getMessage("error.E1129", null,
              Locale.getDefault()),
          e);
      // 業務例外クラス
      registContractorBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      registContractorBusinessBean.setMessage(businessLogicExceptionEMsg);
    } catch (NoSuchMessageException e) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, e);
      registContractorBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      registContractorBusinessBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
    } catch (DataAccessException e) {
      logger.error(
          messageSource.getMessage("error.E1129", null,
              Locale.getDefault()),
          e);
      registContractorBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      registContractorBusinessBean.setMessage(e.getMessage());
    }
    return registContractorBusinessBean;
  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.kj.KJ_AgentContractorInformationBusiness
   * #update (jp.co.unisys.enability.cis.business.kj.model.
   * UpdateAgentContractorBusinessBean )
   */
  @Override
  public UpdateAgentContractorBusinessBean update(
      UpdateAgentContractorBusinessBean updateContractorBusinessBean) {

    // BusinessLogicException用エラーメッセージ
    String businessLogicExceptionEMsg = null;

    // オンライン処理基準日取得エラー用エラーメッセージ
    String getProcessBaseDateErrorEMsg = null;

    // 契約者情報照会BusinessBean
    InquiryAgentContractorBusinessBean inquiryContractorBusinessBean;

    // 契約者情報照会EntityBean
    KJ_InquiryAgentContractorInformationEntityBean inquiryContractorInformationEntityBean;

    // 契約情報ビジネスBean
    InquiryAgentContractBusinessBean inquiryContractBusinessBean;

    // 契約者Entity
    Contractor contractor;

    // 契約者EntityExample
    ContractorExample contractorExample;

    // 契約者付加Entity
    ContractorAddInfo contractorAddInfo;

    try {

      businessLogicExceptionEMsg = messageSource.getMessage(KJ_CommonUtil
          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G017),
          new String[] {}, Locale.getDefault());
      getProcessBaseDateErrorEMsg = messageSource.getMessage(
          "error.E1286", new String[] {}, Locale.getDefault());

      // DB存在チェック
      inquiryContractorBusinessBean = new InquiryAgentContractorBusinessBean();
      // 《契約者情報更新BusinessBean》.契約者IDを設定する。
      inquiryContractorBusinessBean
          .setContractorId(updateContractorBusinessBean
              .getContractorId());
      // 《契約者情報更新BusinessBean》.契約者番号を設定する。
      inquiryContractorBusinessBean
          .setContractorNo(updateContractorBusinessBean
              .getContractorNo());
      // 契約者情報照会呼び出し
      inquiryContractorBusinessBean = inquiry(inquiryContractorBusinessBean);
      // 《契約者情報照会BusinessBean》.リターンコードが'0000'以外の場合
      if (!ECISReturnCodeConstants.RETURN_CODE_0000
          .equals(inquiryContractorBusinessBean.getReturnCode())) {

        throw new BusinessLogicException(messageSource.getMessage(
            "error.E1281", new String[] {}, Locale.getDefault()),
            false);
      }
      // 《契約者情報照会EntityBean》リストが0件の場合
      if (CollectionUtils.isEmpty(inquiryContractorBusinessBean
          .getAgentContractorInformationList())) {

        updateContractorBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P003);
        updateContractorBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P003),
                new String[] {}, Locale.getDefault()));
        return updateContractorBusinessBean;

      }
      inquiryContractorInformationEntityBean = inquiryContractorBusinessBean
          .getAgentContractorInformationList().get(0);
      // 《電話番号区分Dao》.検索（主キー）電話番号区分1のが0件の場合
      if (contractorPhoneCategoryCodeCheck(updateContractorBusinessBean
          .getContractorPhoneCategoryCode1())) {

        updateContractorBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P019);
        updateContractorBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P019),
                new String[] {}, Locale.getDefault()));
        return updateContractorBusinessBean;

      }
      // 《電話番号区分Dao》.検索（主キー）電話番号区分2の取得結果が0件の場合
      if (contractorPhoneCategoryCodeCheck(updateContractorBusinessBean
          .getContractorPhoneCategoryCode2())) {

        updateContractorBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P019);
        updateContractorBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P019),
                new String[] {}, Locale.getDefault()));
        return updateContractorBusinessBean;

      }
      // 《契約者情報更新BusinessBean》.個人・法人区分コードがnullまたは空文字でない場合
      // 《個人・法人区分マスタDao》.検索（主キー）の返却値が0件の場合
      if (StringUtils.isNotEmpty(updateContractorBusinessBean
          .getIndividualLegalEntityCategoryCode())
          && ilcMMapper
              .selectByPrimaryKey(updateContractorBusinessBean
                  .getIndividualLegalEntityCategoryCode()) == null) {

        updateContractorBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P021);
        updateContractorBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P021),
                new String[] {}, Locale.getDefault()));
        return updateContractorBusinessBean;

      }
      // 《契約者情報更新BusinessBean》.利用不能フラグが"1：利用不能" かつ
      // 《契約者情報照会EntityBean》.利用不能フラグが"0：利用可能"の場合
      if ((ECISKJConstants.UNAVAILABLE_FLAG_USE_IMPOSSIBLE)
          .equals(updateContractorBusinessBean.getUnavailableFlag())
          && (ECISKJConstants.UNAVAILABLE_FLAG_USE_POSSIBLE)
              .equals(inquiryContractorInformationEntityBean
                  .getUnavailableFlag())) {

        inquiryContractBusinessBean = new InquiryAgentContractBusinessBean();
        // 《契約者情報照会EntityBean》.契約者番号を設定する。
        inquiryContractBusinessBean
            .setContractorNo(inquiryContractorInformationEntityBean
                .getContractorNo());
        // オンライン処理基準日を設定する。
        inquiryContractBusinessBean
            .setInqCoveredDate(dateBusiness
                .getProcessBaseDate(ECISConstants.EXEC_BASE_DATE_ONLINE));
        // 契約情報照会呼び出し
        inquiryContractBusinessBean = kjContractInformationBusiness
            .inquiry(inquiryContractBusinessBean);
        // 《契約情報照会BusinessBean》.リターンコードが'0000'以外の場合
        if (!ECISReturnCodeConstants.RETURN_CODE_0000
            .equals(inquiryContractBusinessBean.getReturnCode())) {

          throw new BusinessLogicException(
              messageSource.getMessage("error.E1285",
                  new String[] {}, Locale.getDefault()),
              false);

        }
        // 《契約情報ビジネスBean》.契約情報リストが1件以上の場合
        if (inquiryContractBusinessBean
            .getAgentContractInformationList().size() >= 1) {

          updateContractorBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D005);
          updateContractorBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D005),
                  new String[] {}, Locale.getDefault()));
          return updateContractorBusinessBean;

        }
      }

      // 督促対象チェック
      // 《契約者情報更新BusinessBean》.督促対象外フラグが"0：督促対象"の場合
      if (ECISKJConstants.URGE_NOT_COVERED_FLAG_URGE_COVERED
          .equals(updateContractorBusinessBean
              .getUrgeNotCoveredFlag())) {

        // 支払Exampleを生成し値を設定
        PaymentExample paymentExample = new PaymentExample();

        // 検索条件
        // 前月請求合算フラグが"0：否"
        paymentExample
            .createCriteria()
            .andContractorIdEqualTo(
                inquiryContractorInformationEntityBean.getContractorId())
            .andPreviousBlAddUpFlagEqualTo(
                ECISKJConstants.BILLING_ADD_UP_FLAG_UNNECESSARY);
        // または、支払期限個別設定フラグが"1：個別"
        paymentExample
            .or(paymentExample
                .createCriteria()
                .andContractorIdEqualTo(
                    inquiryContractorInformationEntityBean
                        .getContractorId())
                .andPeIndividualSettingFlagEqualTo(
                    ECISKJConstants.PAYMENT_EXPIRATION_CATEGORY_FLAG_INDIVIDUAL));

        // 支払Mapaar.countByExampleを呼出
        int count = paymentMapper.countByExample(paymentExample);

        // 返却値が1件以上の場合、以下のメッセージ情報を設定
        if (count >= 1) {
          updateContractorBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G046);
          updateContractorBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G046),
                  new String[] {}, Locale.getDefault()));
          return updateContractorBusinessBean;
        }
      }

      // 契約者情報更新
      Timestamp systemDate = new Timestamp(System.currentTimeMillis());
      contractor = new Contractor();
      contractorExample = new ContractorExample();
      // 契約者名1（カナ）
      contractor.setCn1Kana(updateContractorBusinessBean
          .getContractorName1Kana());
      // 契約者名1
      contractor
          .setCn1(updateContractorBusinessBean.getContractorName1());
      // 契約者名2
      contractor
          .setCn2(updateContractorBusinessBean.getContractorName2());
      // 契約者名1（宛名用）
      contractor.setCn1MailingName(updateContractorBusinessBean
          .getContractorName1MailingName());
      // 契約者名2（宛名用）
      contractor.setCn2MailingName(updateContractorBusinessBean
          .getContractorName2MailingName());
      // 敬称
      contractor.setPrefix(updateContractorBusinessBean.getPrefix());
      // 契約者住所（郵便番号）
      contractor.setCaPostalCode(updateContractorBusinessBean
          .getContractorAddressPostalCode());
      // 契約者住所（都道府県名）
      contractor.setCaPrefectures(updateContractorBusinessBean
          .getContractorAddressPrefectures());
      // 契約者住所（市区郡町村名）
      contractor.setCaMunicipality(updateContractorBusinessBean
          .getContractorAddressMunicipality());
      // 契約者住所（字名・丁目）
      contractor.setCaSection(updateContractorBusinessBean
          .getContractorAddressSection());
      // 契約者住所（番地･号）
      contractor.setCaBlock(updateContractorBusinessBean
          .getContractorAddressBlock());
      // 契約者住所（建物名）
      contractor.setCaBuildingName(updateContractorBusinessBean
          .getContractorAddressBuildingName());
      // 契約者住所（部屋名）
      contractor.setCaRoom(updateContractorBusinessBean
          .getContractorAddressRoom());
      // 契約者電話区分コード1
      contractor.setCphCatCode1(updateContractorBusinessBean
          .getContractorPhoneCategoryCode1());
      // 契約者電話1（市外局番）
      contractor.setCphAreaCode1(updateContractorBusinessBean
          .getContractorPhoneAreaCode1());
      // 契約者電話1（市内局番）
      contractor.setCphLocalNo1(updateContractorBusinessBean
          .getContractorPhoneLocalNo1());
      // 契約者電話1（加入者番号）
      contractor.setCphDirectoryNo1(updateContractorBusinessBean
          .getContractorPhoneDirectoryNo1());
      // 契約者電話区分コード2
      contractor.setCphCatCode2(updateContractorBusinessBean
          .getContractorPhoneCategoryCode2());
      // 契約者電話2（市外局番）
      contractor.setCphAreaCode2(updateContractorBusinessBean
          .getContractorPhoneAreaCode2());
      // 契約者電話2（市内局番）
      contractor.setCphLocalNo2(updateContractorBusinessBean
          .getContractorPhoneLocalNo2());
      // 契約者電話2（加入者番号）
      contractor.setCphDirectoryNo2(updateContractorBusinessBean
          .getContractorPhoneDirectoryNo2());
      // 契約者メールアドレス1
      contractor.setCma1(updateContractorBusinessBean
          .getContractorMailAddress1());
      // 契約者メールアドレス2
      contractor.setCma2(updateContractorBusinessBean
          .getContractorMailAddress2());
      // 利用不能フラグ
      contractor.setUnavailableFlag(updateContractorBusinessBean
          .getUnavailableFlag());
      // 取引先コード
      contractor.setCustomerCode(updateContractorBusinessBean
          .getCustomerCode());
      // 督促対象外フラグ
      contractor.setUrgeNotCoveredFlag(updateContractorBusinessBean
          .getUrgeNotCoveredFlag());
      // 個人・法人区分コード
      contractor.setIlcCode(updateContractorBusinessBean
          .getIndividualLegalEntityCategoryCode());
      // 見える化提供フラグ
      contractor.setVisualizationProvideFlag(updateContractorBusinessBean
          .getVisualizationProvideFlag());
      // 備考
      contractor.setNote(updateContractorBusinessBean.getNote());
      // 更新回数
      contractor.setUpdateCount(updateContractorBusinessBean
          .getUpdateCount() + 1);
      // 契約者住所(住所)
      contractor.setCaFull(updateCaFullStrBuilder(
          updateContractorBusinessBean
              .getContractorAddressPrefectures(),
          updateContractorBusinessBean
              .getContractorAddressMunicipality(),
          updateContractorBusinessBean.getContractorAddressSection(),
          updateContractorBusinessBean.getContractorAddressBlock(),
          inquiryContractorInformationEntityBean
              .getContractorAddressSection(),
          inquiryContractorInformationEntityBean
              .getContractorAddressBlock()));
      // 契約者住所(建物・部屋名)
      contractor.setCaBuilding(updateCaBuildingStrBuilder(
          updateContractorBusinessBean
              .getContractorAddressBuildingName(),
          updateContractorBusinessBean.getContractorAddressRoom(),
          inquiryContractorInformationEntityBean
              .getContractorAddressBuildingName(),
          inquiryContractorInformationEntityBean
              .getContractorAddressRoom()));
      // 契約者電話番号1
      contractor.setCphNo1(cphNoStrBuilder(updateContractorBusinessBean
          .getContractorPhoneAreaCode1(),
          updateContractorBusinessBean.getContractorPhoneLocalNo1(),
          updateContractorBusinessBean
              .getContractorPhoneDirectoryNo1()));
      // 契約者電話番号
      contractor.setCphNo2(cphNoStrBuilder(updateContractorBusinessBean
          .getContractorPhoneAreaCode2(),
          updateContractorBusinessBean.getContractorPhoneLocalNo2(),
          updateContractorBusinessBean
              .getContractorPhoneDirectoryNo2()));
      // オンライン更新日時
      contractor.setOnlineUpdateTime(systemDate);
      // オンライン更新ユーザID
      contractor.setOnlineUpdateUserId(ThreadContext
          .getRequestThreadContext().get(ECISConstants.USER_ID_KEY)
          .toString());
      // 更新日時
      contractor.setUpdateTime(systemDate);
      // 更新モジュールコード
      contractor.setUpdateModuleCode(ThreadContext
          .getRequestThreadContext()
          .get(ECISConstants.CLASS_NAME_KEY).toString());
      // 契約者ID
      // 更新回数
      contractorExample
          .createCriteria()
          .andContractorIdEqualTo(
              inquiryContractorInformationEntityBean
                  .getContractorId())
          .andUpdateCountEqualTo(
              updateContractorBusinessBean.getUpdateCount());
      // 《契約者情報共通Dao》.契約者情報更新の返却値が0件の場合
      if (contractorMapper.updateByExampleSelective(contractor,
          contractorExample) == 0) {

        updateContractorBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_H001);
        updateContractorBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_H001),
                new String[] {}, Locale.getDefault()));
        return updateContractorBusinessBean;

      }

      // 契約者付加情報取得
      ContractorAddInfo contractorAddInfoUpdateCountEntity = contractorAddInfoMapper.selectByPrimaryKey(
          inquiryContractorInformationEntityBean.getContractorId());

      // 契約者付加情報更新件数
      int contractorAddInfoNum = 0;

      if (contractorAddInfoUpdateCountEntity != null) {
        // 契約者付加情報更新
        contractorAddInfo = new ContractorAddInfo();
        // 契約者ID
        contractorAddInfo.setContractorId(inquiryContractorInformationEntityBean.getContractorId());
        // 契約者電話番号
        contractorAddInfo.setAgentContractorNo(updateContractorBusinessBean
            .getAgentContractorNo());
        // 契約者フリー項目1
        contractorAddInfo.setFree1(updateContractorBusinessBean
            .getContractorFree1());
        // 契約者フリー項目2
        contractorAddInfo.setFree2(updateContractorBusinessBean
            .getContractorFree2());
        // 契約者フリー項目3
        contractorAddInfo.setFree3(updateContractorBusinessBean
            .getContractorFree3());
        // 契約者フリー項目4
        contractorAddInfo.setFree4(updateContractorBusinessBean
            .getContractorFree4());
        // 契約者フリー項目5
        contractorAddInfo.setFree5(updateContractorBusinessBean
            .getContractorFree5());
        // 契約者フリー項目6
        contractorAddInfo.setFree6(updateContractorBusinessBean
            .getContractorFree6());
        // 契約者フリー項目7
        contractorAddInfo.setFree7(updateContractorBusinessBean
            .getContractorFree7());
        // 契約者フリー項目8
        contractorAddInfo.setFree8(updateContractorBusinessBean
            .getContractorFree8());
        // 契約者フリー項目9
        contractorAddInfo.setFree9(updateContractorBusinessBean
            .getContractorFree9());
        // 契約者フリー項目10
        contractorAddInfo.setFree10(updateContractorBusinessBean
            .getContractorFree10());
        // 更新回数
        contractorAddInfo.setUpdateCount(contractorAddInfoUpdateCountEntity
            .getUpdateCount() + 1);
        // オンライン更新日時
        contractorAddInfo.setOnlineUpdateTime(systemDate);
        // オンライン更新ユーザID
        contractorAddInfo.setOnlineUpdateUserId(ThreadContext
            .getRequestThreadContext().get(ECISConstants.USER_ID_KEY)
            .toString());
        // 更新日時
        contractorAddInfo.setUpdateTime(systemDate);
        // 更新モジュールコード
        contractorAddInfo.setUpdateModuleCode(ThreadContext
            .getRequestThreadContext()
            .get(ECISConstants.CLASS_NAME_KEY).toString());

        // 契約者付加情報更新
        contractorAddInfoNum = contractorAddInfoMapper.updateByPrimaryKeySelective(contractorAddInfo);
      }

      // 《契約者付加情報Mapper》.契約者付加情報更新の返却値が0件の場合
      if (contractorAddInfoNum == 0) {
        updateContractorBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_H001);
        updateContractorBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_H001),
                new String[] {}, Locale.getDefault()));

        return updateContractorBusinessBean;

      }

      // 正常終了
      updateContractorBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);
      // 契約者IDを返す。
      updateContractorBusinessBean
          .setContractorId(inquiryContractorInformationEntityBean.getContractorId());

    } catch (BusinessLogicException e) {
      logger.error(
          messageSource.getMessage("error.E1129", null,
              Locale.getDefault()),
          e);
      // catch 業務例外クラス
      updateContractorBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      updateContractorBusinessBean.setMessage(businessLogicExceptionEMsg);

    } catch (NoSuchMessageException e) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, e);
      updateContractorBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      updateContractorBusinessBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
    } catch (SystemException e) {
      logger.error(
          messageSource.getMessage("error.E1129", null,
              Locale.getDefault()),
          e);
      updateContractorBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      updateContractorBusinessBean
          .setMessage(getProcessBaseDateErrorEMsg);
    }
    return updateContractorBusinessBean;
  }

  /**
   * 登録用契約者住所（建物・部屋名）を生成
   *
   * @param contractorAddressBuildingName
   *          建物名
   * @param contractorAddressRoom
   *          部屋名
   *
   */
  private String registCaBuildingStrBuilder(
      String contractorAddressBuildingName, String contractorAddressRoom) {
    String caBuilding = "";

    // 建物、部屋名がNULLまたは空文字でない場合
    if (StringUtils.isNotEmpty(contractorAddressBuildingName)
        && StringUtils.isNotEmpty(contractorAddressRoom)) {

      caBuilding = new StringBuilder(contractorAddressBuildingName)
          .append(ECISKJConstants.STRING_BUILDER_ZENKAKU_SPACE)
          .append(contractorAddressRoom).toString();

      // 建物、部屋名のどちらかがNULLまたは空文字でない場合
    } else if (StringUtils.isNotEmpty(contractorAddressBuildingName)
        || StringUtils.isNotEmpty(contractorAddressRoom)) {

      caBuilding = new StringBuilder(
          StringUtils.defaultString(contractorAddressBuildingName))
              .append(StringUtils.defaultString(contractorAddressRoom))
              .toString();
    }
    return caBuilding;
  }

  /**
   * 更新用契約者住所（建物・部屋名）を生成
   *
   * @param newContractorAddressBuildingName
   *          更新後建物名
   * @param newContractorAddressRoom
   *          更新後部屋名
   * @param oldContractorAddressBuildingName
   *          更新前建物
   * @param oldCcontractorAddressRoom
   *          更新前部屋名
   *
   */
  private String updateCaBuildingStrBuilder(
      String newContractorAddressBuildingName,
      String newContractorAddressRoom,
      String oldContractorAddressBuildingName,
      String oldCcontractorAddressRoom) {
    String caBuilding = null;
    // 契約者住所（建物名）に更新前建物名を設定
    String contractorAddressBuildingName = oldContractorAddressBuildingName;
    // 契約者住所（部屋名）に更新前部屋名を設定
    String contractorAddressRoom = oldCcontractorAddressRoom;

    // 更新後建物名に入力がある場合
    if (null != newContractorAddressBuildingName) {
      // 契約者住所（建物名）に更新後建物名を設定
      contractorAddressBuildingName = newContractorAddressBuildingName;
    }
    // 更新後部屋名に入力がある場合
    if (null != newContractorAddressRoom) {
      // 契約者住所（部屋名）に更新後部屋名を設定
      contractorAddressRoom = newContractorAddressRoom;
    }

    // 建物、部屋名がNULLまたは空文字でない場合
    if (StringUtils.isNotEmpty(contractorAddressBuildingName)
        && StringUtils.isNotEmpty(contractorAddressRoom)) {

      caBuilding = new StringBuilder(contractorAddressBuildingName)
          .append(ECISKJConstants.STRING_BUILDER_ZENKAKU_SPACE)
          .append(contractorAddressRoom).toString();

      // 建物、部屋名のどちらかがNULLでない場合
    } else if (null != contractorAddressBuildingName
        || null != contractorAddressRoom) {

      caBuilding = new StringBuilder(
          StringUtils.defaultString(contractorAddressBuildingName))
              .append(StringUtils.defaultString(contractorAddressRoom))
              .toString();
    }
    return caBuilding;
  }

  /**
   * 契約者電話番号を生成
   *
   * @param contractorPhoneAreaCode
   *          市外局番
   * @param contractorPhoneLocalNo
   *          市内局番
   * @param contractorPhoneDirectoryNo
   *          加入者番号
   *
   */
  private String cphNoStrBuilder(String contractorPhoneAreaCode,
      String contractorPhoneLocalNo, String contractorPhoneDirectoryNo) {
    String cphNo = null;
    // 市外局番、市内局番、加入者番号がNULLまたは空文字でない場合
    if (StringUtils.isNotEmpty(contractorPhoneAreaCode)
        && StringUtils.isNotEmpty(contractorPhoneLocalNo)
        && StringUtils.isNotEmpty(contractorPhoneDirectoryNo)) {

      cphNo = new StringBuilder(contractorPhoneAreaCode)
          .append(ECISConstants.HYPHEN)
          .append(contractorPhoneLocalNo)
          .append(ECISConstants.HYPHEN)
          .append(contractorPhoneDirectoryNo).toString();

    } else if (null != contractorPhoneAreaCode
        && null != contractorPhoneLocalNo
        && null != contractorPhoneDirectoryNo) {

      cphNo = "";

    }
    return cphNo;
  }

  /**
   * 登録用契約者住所を生成
   *
   * @param contractorAddressPrefectures
   *          都道府県名
   * @param contractorAddressMunicipality
   *          市区郡町村名
   * @param contractorAddressSection
   *          字名・丁目
   * @param contractorAddressBlock
   *          番地・号
   *
   */
  private String registCaFullStrBuilder(String contractorAddressPrefectures,
      String contractorAddressMunicipality,
      String contractorAddressSection, String contractorAddressBlock) {
    String caFull = new StringBuilder(contractorAddressPrefectures).append(
        contractorAddressMunicipality).toString();
    // 字名・丁目、番地・号がNULLまたは空文字でない場合
    if (StringUtils.isNotEmpty(contractorAddressBlock)
        && StringUtils.isNotEmpty(contractorAddressSection)) {

      caFull = new StringBuilder(caFull).append(contractorAddressSection)
          .append(ECISKJConstants.STRING_BUILDER_ZENKAKU_SPACE)
          .append(contractorAddressBlock).toString();

      return caFull;
    }
    // 字名・丁目がNULLまたは空文字でない場合
    if (StringUtils.isNotEmpty(contractorAddressSection)) {

      caFull = new StringBuilder(caFull).append(
          StringUtils.defaultString(contractorAddressSection))
          .toString();

    }
    // 番地・号がNULLまたは空文字でない場合
    if (StringUtils.isNotEmpty(contractorAddressBlock)) {

      caFull = new StringBuilder(caFull)
          .append(ECISKJConstants.STRING_BUILDER_ZENKAKU_SPACE)
          .append(StringUtils.defaultString(contractorAddressBlock))
          .toString();

    }
    return caFull;
  }

  /**
   * 更新用契約者住所を生成
   *
   * @param contractorAddressPrefectures
   *          都道府県名
   * @param contractorAddressMunicipality
   *          市区郡町村名
   * @param newContractorAddressSection
   *          更新前字名・丁目
   * @param newContractorAddressBlock
   *          更新前番地・号
   * @param oldContractorAddressSection
   *          更新後字名・丁目
   * @param oldContractorAddressBlock
   *          更新後番地・号
   *
   */
  private String updateCaFullStrBuilder(String contractorAddressPrefectures,
      String contractorAddressMunicipality,
      String newContractorAddressSection,
      String newContractorAddressBlock,
      String oldContractorAddressSection, String oldContractorAddressBlock) {

    String caFull = new StringBuilder(contractorAddressPrefectures).append(
        contractorAddressMunicipality).toString();

    // 字名・丁目に更新前字名・丁目を設定
    String contractorAddressSection = oldContractorAddressSection;
    // 番地・号に更新前番地・号を設定
    String contractorAddressBlock = oldContractorAddressBlock;

    // 更新後字名・丁目に入力がある場合
    if (null != newContractorAddressSection) {
      // 字名・丁目に更新後字名・丁目を設定
      contractorAddressSection = newContractorAddressSection;
    }
    // 更新後番地・号に入力がある場合
    if (null != newContractorAddressBlock) {
      // 番地・号に更新後番地・号を設定
      contractorAddressBlock = newContractorAddressBlock;
    }

    // 字名・丁目、番地・号がNULLまたは空文字でない場合
    if (StringUtils.isNotEmpty(contractorAddressSection)
        && StringUtils.isNotEmpty(contractorAddressBlock)) {

      caFull = new StringBuilder(caFull).append(contractorAddressSection)
          .append(ECISKJConstants.STRING_BUILDER_ZENKAKU_SPACE)
          .append(contractorAddressBlock).toString();

      return caFull;
    }
    // 字名・丁目がNULLまたは空文字でない場合
    if (StringUtils.isNotEmpty(contractorAddressSection)) {

      caFull = new StringBuilder(caFull).append(contractorAddressSection)
          .toString();

    }
    // 番地・号がNULLまたは空文字でない場合
    if (StringUtils.isNotEmpty(contractorAddressBlock)) {

      caFull = new StringBuilder(caFull)
          .append(ECISKJConstants.STRING_BUILDER_ZENKAKU_SPACE)
          .append(contractorAddressBlock).toString();

    }
    return caFull;
  }

  /**
   * 契約者電話番号区分コードの存在チェック
   *
   * @param contractorPhoneCategoryCode
   *          契約者電話番号区分コード
   *
   */
  private Boolean contractorPhoneCategoryCodeCheck(
      String contractorPhoneCategoryCode) {
    // 契約者電話番号区分コードがNULLまたは空文字でない場合かつ返却値が0件の場合
    if (StringUtils.isNotEmpty(contractorPhoneCategoryCode)
        && phoneNoCatMMapper
            .selectByPrimaryKey(contractorPhoneCategoryCode) == null) {

      return true;
    }
    return false;

  }

  /**
   * 契約者情報共通マッパーのセッター(DI)
   *
   * @param contractorInformationCommonMapper
   *          契約者情報共通マッパー
   *
   */
  public void setAgentContractorInformationCommonMapper(
      AgentContractorInformationCommonMapper contractorInformationCommonMapper) {
    this.contractorInformationCommonMapper = contractorInformationCommonMapper;
  }

  /**
   * 電話番号区分マッパーのセッター(DI)
   *
   * @param phoneNoCategoryMasterMapper
   *          電話番号区分マッパー
   *
   */
  public void setPhoneNoCategoryMasterMapper(
      PhoneNoCatMMapper phoneNoCategoryMasterMapper) {
    this.phoneNoCatMMapper = phoneNoCategoryMasterMapper;
  }

  /**
   * マスタ情報マッパーのセッター(DI)
   *
   * @param masterInformationBusiness
   *          マスタ情報マッパー
   *
   */
  public void setKjMasterInformationBusiness(
      KJ_MasterInformationBusiness masterInformationBusiness) {
    this.kjMasterInformationBusiness = masterInformationBusiness;
  }

  /**
   * 個人法人マスタマッパーのセッター(DI)
   *
   * @param individualLegalEntityCategoryMasterMapper
   *          個人法人マスタマッパー
   *
   */
  public void setIndividualLegalEntityCategoryMasterMapper(
      IlcMMapper individualLegalEntityCategoryMasterMapper) {
    this.ilcMMapper = individualLegalEntityCategoryMasterMapper;
  }

  /**
   * 契約者情報マッパーのセッター(DI)
   *
   * @param contractorMapper
   *          契約者情報マッパー
   *
   */
  public void setContractorMapper(ContractorMapper contractorMapper) {
    this.contractorMapper = contractorMapper;
  }

  /**
   * 契約者付加情報マッパーのセッター(DI)
   *
   * @param contractorAddInfoMapper
   *          契約者付加情報マッパー
   *
   */
  public void setContractorAddInfoMapper(
      ContractorAddInfoMapper contractorAddInfoMapper) {
    this.contractorAddInfoMapper = contractorAddInfoMapper;
  }

  /**
   * 支払マッパーのセッター(DI)
   *
   * @param paymentMapper
   *          支払マッパー
   *
   */
  public void setPaymentMapper(PaymentMapper paymentMapper) {
    this.paymentMapper = paymentMapper;
  }

  /**
   * 日付関連共通ビジネスインタフェースのセッター(DI)
   *
   * @param dateBusiness
   *          日付関連共通ビジネス
   *
   */
  public void setDateBusiness(DateBusiness dateBusiness) {
    this.dateBusiness = dateBusiness;
  }

  /**
   * 契約情報ビジネスのセッター(DI)
   *
   * @param kjContractInformationBusiness
   *          契約情報ビジネス
   *
   */
  public void setKjContractInformationBusiness(
      KJ_AgentContractInformationBusiness kjContractInformationBusiness) {
    this.kjContractInformationBusiness = kjContractInformationBusiness;
  }

  /**
   * messageSourceのセッター(DI)
   *
   * @param messageSource
   *          メッセージソース
   *
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }
}
