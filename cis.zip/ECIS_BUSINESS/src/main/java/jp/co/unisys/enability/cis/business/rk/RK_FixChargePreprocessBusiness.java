package jp.co.unisys.enability.cis.business.rk;

import java.util.Date;

/**
 * 確定使用量前処理ビジネスインターフェース。
 *
 * <pre>
 * <p><b>【仕様詳細】</b></p>
 * 確定使用量前処理サービスから呼び出される各ビジネスクラスは、このクラスを実装する。
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public interface RK_FixChargePreprocessBusiness {

  /**
   * 確定使用量前処理の実処理を定義する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 確定使用量メッセージの取り込み前に、前処理を行うメソッド。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   */
  public abstract void process(Date executeDate);
}
