package jp.co.unisys.enability.cis.business.kj.model;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * 付帯契約情報登録・更新（一括登録）BusinessBean
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * 付帯契約情報ビジネス
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class ContractManagementInformationFileConfigSupplementaryContract {

  /** ファイル名接頭辞 */
  public static final String FILE_NAME_PREFIX = "supplementaryContract_";

  // ヘッダレコード定義
  /** ヘッダレコード：ファイル種別-パラメータ */
  public static final String HEADER_FILE_KIND_PARAM = "5";

  // データレコード定義
  public static final String[] DATA_TITLE_ROW;
  /** データレコード：項目数 */
  public static final int DATA_COLUMN_COUNT;

  // 付帯契約ID
  /** データレコード：付帯契約ID-インデックス */
  public static final int DATA_SUPPLEMENTARY_CONTRACT_ID_INDEX = 1;
  /** データレコード：付帯契約ID-名称 */
  public static final String DATA_SUPPLEMENTARY_CONTRACT_ID_NAME = "付帯契約ID";
  /** データレコード：付帯契約ID-文字数 */
  public static final int DATA_SUPPLEMENTARY_CONTRACT_ID_LENGTH = 10;
  /** データレコード：付帯契約ID-文字数（文字列） */
  public static final String DATA_SUPPLEMENTARY_CONTRACT_ID_LENGTH_STRING = String
      .valueOf(DATA_SUPPLEMENTARY_CONTRACT_ID_LENGTH);

  // 契約番号
  /** データレコード：契約番号-インデックス */
  public static final int DATA_CONTRACT_NO_INDEX = 2;
  /** データレコード：契約番号-名称 */
  public static final String DATA_CONTRACT_NO_NAME = "契約番号";
  /** データレコード：契約番号-文字数 */
  public static final int DATA_CONTRACT_NO_LENGTH = 25;
  /** データレコード：契約番号-文字数（文字列） */
  public static final String DATA_CONTRACT_NO_LENGTH_STRING = String
      .valueOf(DATA_CONTRACT_NO_LENGTH);

  // 付帯メニューID
  /** データレコード：付帯メニューID-インデックス */
  public static final int DATA_SUPPLEMENTARY_MENU_ID_INDEX = 3;
  /** データレコード：付帯メニューID-名称 */
  public static final String DATA_SUPPLEMENTARY_MENU_ID_NAME = "付帯メニューID";
  /** データレコード：付帯メニューID-文字数 */
  public static final int DATA_SUPPLEMENTARY_MENU_ID_LENGTH = 8;
  /** データレコード：付帯メニューID-文字数（文字列） */
  public static final String DATA_SUPPLEMENTARY_MENU_ID_LENGTH_STRING = String
      .valueOf(DATA_SUPPLEMENTARY_MENU_ID_LENGTH);

  // 付帯契約開始日
  /** データレコード：付帯契約開始日-インデックス */
  public static final int DATA_SUPPLEMENTARY_CONTRACT_START_DATE_INDEX = 4;
  /** データレコード：付帯契約開始日-名称 */
  public static final String DATA_SUPPLEMENTARY_CONTRACT_START_DATE_NAME = "付帯契約開始日";
  /** データレコード：付帯契約開始日-文字数 */
  public static final int DATA_SUPPLEMENTARY_CONTRACT_START_DATE_LENGTH = 10;
  /** データレコード：付帯契約開始日-文字数（文字列） */
  public static final String DATA_SUPPLEMENTARY_CONTRACT_START_DATE_LENGTH_STRING = String
      .valueOf(DATA_SUPPLEMENTARY_CONTRACT_START_DATE_LENGTH);

  // 付帯契約終了日
  /** データレコード：付帯契約終了日-インデックス */
  public static final int DATA_SUPPLEMENTARY_CONTRACT_END_DATE_INDEX = 5;
  /** データレコード：付帯契約終了日-名称 */
  public static final String DATA_SUPPLEMENTARY_CONTRACT_END_DATE_NAME = "付帯契約終了日";
  /** データレコード：付帯契約終了日-文字数 */
  public static final int DATA_SUPPLEMENTARY_CONTRACT_END_DATE_LENGTH = 10;
  /** データレコード：付帯契約終了日-文字数（文字列） */
  public static final String DATA_SUPPLEMENTARY_CONTRACT_END_DATE_LENGTH_STRING = String
      .valueOf(DATA_SUPPLEMENTARY_CONTRACT_END_DATE_LENGTH);

  // 額・率
  /** データレコード：額・率-インデックス */
  public static final int DATA_AMOUNT_OR_RATE_INDEX = 6;
  /** データレコード：額・率-名称 */
  public static final String DATA_AMOUNT_OR_RATE_NAME = "額・率";
  /** データレコード：額・率-文字数 */
  public static final int DATA_AMOUNT_OR_RATE_LENGTH = 8;
  /** データレコード：額・率-文字数（文字列） */
  public static final String DATA_AMOUNT_OR_RATE_LENGTH_STRING = String
      .valueOf(DATA_AMOUNT_OR_RATE_LENGTH);
  /** データレコード：額・率-定額時の整数部桁数上限 */
  public static final int DATA_AMOUNT_OR_RATE_AMOUNT_DIGIT_INTEGER = 4;
  /** データレコード：額・率-定額時の小数部桁数 */
  public static final int DATA_AMOUNT_OR_RATE_AMOUNT_DIGIT_FLOAT = 3;
  /** データレコード：額・率-定額時の整数部桁数上限（文字列） */
  public static final String DATA_AMOUNT_OR_RATE_AMOUNT_DIGIT_INTEGER_STRING = String
      .valueOf(DATA_AMOUNT_OR_RATE_AMOUNT_DIGIT_INTEGER);
  /** データレコード：額・率-定額時の小数部桁数（文字列） */
  public static final String DATA_AMOUNT_OR_RATE_AMOUNT_DIGIT_FLOAT_STRING = String
      .valueOf(DATA_AMOUNT_OR_RATE_AMOUNT_DIGIT_FLOAT);
  /** データレコード：額・率-定率時の最低値 */
  public static final BigDecimal DATA_AMOUNT_OR_RATE_RATE_MIN_VALUE = new BigDecimal(
      "1.000");

  // 更新回数
  /** データレコード：更新回数-インデックス */
  public static final int DATA_UPDATE_COUNT_INDEX = 7;
  /** データレコード：更新回数-名称 */
  public static final String DATA_UPDATE_COUNT_NAME = "更新回数";
  /** データレコード：更新回数-文字数 */
  public static final int DATA_UPDATE_COUNT_LENGTH = 10;
  /** データレコード：更新回数-文字数（文字列） */
  public static final String DATA_UPDATE_COUNT_LENGTH_STRING = String
      .valueOf(DATA_UPDATE_COUNT_LENGTH);

  // 登録・更新・削除区分
  /** データレコード：登録・更新・削除区分-インデックス */
  public static final int DATA_REGISTER_UPDATE_DELETE_CATEGORY_INDEX = 8;
  /** データレコード：登録・更新・削除区分-名称 */
  public static final String DATA_REGISTER_UPDATE_DELETE_CATEGORY_NAME = "登録・更新・削除区分";
  /** データレコード：登録・更新・削除区分-文字数 */
  public static final int DATA_REGISTER_UPDATE_DELETE_CATEGORY_LENGTH = 1;
  /** データレコード：登録・更新・削除区分-文字数（文字列） */
  public static final String DATA_REGISTER_UPDATE_DELETE_CATEGORY_LENGTH_STRING = String
      .valueOf(DATA_REGISTER_UPDATE_DELETE_CATEGORY_LENGTH);

  /**
   * staticイニシャライザ.<br>
   * タイトル行の生成を行う<br>
   * インデックス=タイトル配列のインデックスになるため、番号は自動で設定される<br>
   * カラムの追加・削除があった場合に修正が必要
   */
  static {
    Map<Integer, String> titleMap = new HashMap<Integer, String>();

    // 項目を順番に入れ込んでいく
    // レコード種別は共通のものを使う
    titleMap.put(
        ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_INDEX,
        ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_NAME);

    titleMap.put(DATA_SUPPLEMENTARY_CONTRACT_ID_INDEX,
        DATA_SUPPLEMENTARY_CONTRACT_ID_NAME);
    titleMap.put(DATA_CONTRACT_NO_INDEX, DATA_CONTRACT_NO_NAME);
    titleMap.put(DATA_SUPPLEMENTARY_MENU_ID_INDEX,
        DATA_SUPPLEMENTARY_MENU_ID_NAME);
    titleMap.put(DATA_SUPPLEMENTARY_CONTRACT_START_DATE_INDEX,
        DATA_SUPPLEMENTARY_CONTRACT_START_DATE_NAME);
    titleMap.put(DATA_SUPPLEMENTARY_CONTRACT_END_DATE_INDEX,
        DATA_SUPPLEMENTARY_CONTRACT_END_DATE_NAME);
    titleMap.put(DATA_AMOUNT_OR_RATE_INDEX, DATA_AMOUNT_OR_RATE_NAME);
    titleMap.put(DATA_UPDATE_COUNT_INDEX, DATA_UPDATE_COUNT_NAME);
    titleMap.put(DATA_REGISTER_UPDATE_DELETE_CATEGORY_INDEX,
        DATA_REGISTER_UPDATE_DELETE_CATEGORY_NAME);

    // タイトル文字列に書き換える
    Iterator<Integer> it = titleMap.keySet().iterator();
    String[] titleArray = new String[titleMap.size()];
    while (it.hasNext()) {
      Integer key = it.next();
      titleArray[key] = titleMap.get(key);
    }

    DATA_TITLE_ROW = titleArray;
    DATA_COLUMN_COUNT = DATA_TITLE_ROW.length;
  }

}
