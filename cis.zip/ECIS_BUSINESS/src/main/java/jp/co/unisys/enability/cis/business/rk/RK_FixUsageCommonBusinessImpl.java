package jp.co.unisys.enability.cis.business.rk;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import jp.co.unisys.enability.cis.entity.common.DemandResult;

/**
 * 確定使用量共通ビジネスクラス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_FixUsageCommonBusinessImpl implements RK_FixUsageCommonBusiness {

  /** 30分確定電力量のコマ数 */
  private static final int FIX_USAGE_CAPACITY = 48;

  /** 時分を表すhhmm形式の文字列から"時"を取り出すインデックス */
  private static final int START_INDEX_HOUR = 0;
  private static final int END_INDEX_HOUR = 2;

  /** 時分を表すhhmm形式の文字列から"分"を取り出すインデックス */
  private static final int START_INDEX_MINUTE = 2;
  private static final int END_INDEX_MINUTE = 4;

  /** "時・分"を表す数値に乗じることで、序数を取得する乗数 */
  private static final int MULTIPLIER_HOUR = 2;
  private static final int MULTIPLIER_MINUTE = 30;

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.rk.RK_FixUsageCommonBusiness#
   * demandResultToFixUsageList
   * (jp.co.unisys.enability.cis.entity.common.DemandResult)
   */
  @Override
  public List<BigDecimal> demandResultToFixUsageList(DemandResult demandResult) {
    // 30分確定電力量を格納するリストを作成
    List<BigDecimal> fixUsageList = new ArrayList<BigDecimal>(
        FIX_USAGE_CAPACITY);

    // リストに30分確定電力量01～30分確定電力量48までの値を追加する
    fixUsageList.add(demandResult.getKwh01());
    fixUsageList.add(demandResult.getKwh02());
    fixUsageList.add(demandResult.getKwh03());
    fixUsageList.add(demandResult.getKwh04());
    fixUsageList.add(demandResult.getKwh05());
    fixUsageList.add(demandResult.getKwh06());
    fixUsageList.add(demandResult.getKwh07());
    fixUsageList.add(demandResult.getKwh08());
    fixUsageList.add(demandResult.getKwh09());
    fixUsageList.add(demandResult.getKwh10());
    fixUsageList.add(demandResult.getKwh11());
    fixUsageList.add(demandResult.getKwh12());
    fixUsageList.add(demandResult.getKwh13());
    fixUsageList.add(demandResult.getKwh14());
    fixUsageList.add(demandResult.getKwh15());
    fixUsageList.add(demandResult.getKwh16());
    fixUsageList.add(demandResult.getKwh17());
    fixUsageList.add(demandResult.getKwh18());
    fixUsageList.add(demandResult.getKwh19());
    fixUsageList.add(demandResult.getKwh20());
    fixUsageList.add(demandResult.getKwh21());
    fixUsageList.add(demandResult.getKwh22());
    fixUsageList.add(demandResult.getKwh23());
    fixUsageList.add(demandResult.getKwh24());
    fixUsageList.add(demandResult.getKwh25());
    fixUsageList.add(demandResult.getKwh26());
    fixUsageList.add(demandResult.getKwh27());
    fixUsageList.add(demandResult.getKwh28());
    fixUsageList.add(demandResult.getKwh29());
    fixUsageList.add(demandResult.getKwh30());
    fixUsageList.add(demandResult.getKwh31());
    fixUsageList.add(demandResult.getKwh32());
    fixUsageList.add(demandResult.getKwh33());
    fixUsageList.add(demandResult.getKwh34());
    fixUsageList.add(demandResult.getKwh35());
    fixUsageList.add(demandResult.getKwh36());
    fixUsageList.add(demandResult.getKwh37());
    fixUsageList.add(demandResult.getKwh38());
    fixUsageList.add(demandResult.getKwh39());
    fixUsageList.add(demandResult.getKwh40());
    fixUsageList.add(demandResult.getKwh41());
    fixUsageList.add(demandResult.getKwh42());
    fixUsageList.add(demandResult.getKwh43());
    fixUsageList.add(demandResult.getKwh44());
    fixUsageList.add(demandResult.getKwh45());
    fixUsageList.add(demandResult.getKwh46());
    fixUsageList.add(demandResult.getKwh47());
    fixUsageList.add(demandResult.getKwh48());

    return fixUsageList;
  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.rk.RK_FixUsageCommonBusiness#
   * convertHmToOrdinal(java.lang.String)
   */
  @Override
  public int convertHmToOrdinal(String hhmm) {

    // 時
    int hh = Integer.parseInt(hhmm.substring(START_INDEX_HOUR,
        END_INDEX_HOUR));

    // 分
    int mm = Integer.parseInt(hhmm.substring(START_INDEX_MINUTE,
        END_INDEX_MINUTE));

    // 序数を求める
    return (hh * MULTIPLIER_HOUR) + (mm / MULTIPLIER_MINUTE);
  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.rk.RK_FixUsageCommonBusiness#roundUsage
   * (java.math.BigDecimal)
   */
  @Override
  public BigDecimal roundUsage(BigDecimal usage) {

    // 小数部第１位を四捨五入
    return usage.setScale(0, BigDecimal.ROUND_HALF_UP);
  }

}
