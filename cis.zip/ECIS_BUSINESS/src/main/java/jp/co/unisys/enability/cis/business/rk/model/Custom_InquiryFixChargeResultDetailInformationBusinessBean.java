package jp.co.unisys.enability.cis.business.rk.model;

import java.math.BigDecimal;

import jp.co.unisys.enability.cis.business.kj.model.RealQuantityHistoryBusinessBean;
import jp.co.unisys.enability.cis.entity.common.CContractor;
import jp.co.unisys.enability.cis.entity.kj.KJ_InquiryContractorInformationEntityBean;
import jp.co.unisys.enability.cis.entity.kj.KJ_InquiryMeterLocationEntityBean;
import jp.co.unisys.enability.cis.entity.rk.RK_InquiryFixChargeResultEntityBean;

/**
 * 確定料金実績明細情報照会BusinessBean_カスタム
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * 確定料金実績明細情報ビジネス_カスタム
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 *
 *         変更履歴(kg-epj) 2016.02.05 ko 新規作成
 */
public class Custom_InquiryFixChargeResultDetailInformationBusinessBean {

  /**
   * 契約IDを保有する。
   */
  private Integer contractId;

  /**
   * 契約番号を保有する。
   */
  private String contractNo;

  /**
   * 利用年月を保有する。
   */
  private String usePeriod;

  /**
   * 確定料金実績情報を保有する。
   */
  private RK_InquiryFixChargeResultEntityBean fixChargeResultInformation;

  /**
   * 契約者情報を保有する。
   */
  private KJ_InquiryContractorInformationEntityBean contractorInformation;

  /**
   * カスタム契約者情報を保有する。
   */
  private CContractor customContractorInformation;

  /**
   * メータ設置場所情報を保有する。
   */
  private KJ_InquiryMeterLocationEntityBean meterLocationInformation;

  /**
   * 当月燃調単価を保有する。
   */
  private BigDecimal currentFuelCostUnitPrice;

  /**
   * 翌月燃調単価を保有する。
   */
  private BigDecimal nextFuelCostUnitPrice;

  /**
   * 燃調単価差額を保有する。
   */
  private BigDecimal diffFuelCostUnitPrice;

  /**
   * 当月再エネ単価を保有する。
   */
  private BigDecimal currentRenewableEnergyUnitPrice;

  /**
   * 翌月再エネ単価を保有する。
   */
  private BigDecimal nextRenewableEnergyUnitPrice;

  /**
   * 実量歴管理情報を保有する。
   */
  private RealQuantityHistoryBusinessBean realQuantityHistoryInformation;

  /**
   * リターンコードを保有する。
   */
  private String returnCode;

  /**
   * メッセージを保有する。
   */
  private String message;

  /**
   * 契約IDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約IDを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約ID
   */
  public Integer getContractId() {
    return this.contractId;
  }

  /**
   * 契約IDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約IDを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractId
   *          契約ID
   */
  public void setContractId(Integer contractId) {
    this.contractId = contractId;
  }

  /**
   * 契約番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約番号を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約番号
   */
  public String getContractNo() {
    return this.contractNo;
  }

  /**
   * 契約番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約番号を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractNo
   *          契約番号
   */
  public void setContractNo(String contractNo) {
    this.contractNo = contractNo;
  }

  /**
   * 利用年月のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 利用年月を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 利用年月
   */
  public String getUsePeriod() {
    return this.usePeriod;
  }

  /**
   * 利用年月のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 利用年月を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param usePeriod
   *          利用年月
   */
  public void setUsePeriod(String usePeriod) {
    this.usePeriod = usePeriod;
  }

  /**
   * 確定料金実績情報のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 確定料金実績情報を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 確定料金実績情報
   */
  public RK_InquiryFixChargeResultEntityBean getFixChargeResultInformation() {
    return this.fixChargeResultInformation;
  }

  /**
   * 確定料金実績情報のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 確定料金実績情報を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param fixChargeResultInformation
   *          確定料金実績情報
   */
  public void setFixChargeResultInformation(RK_InquiryFixChargeResultEntityBean fixChargeResultInformation) {
    this.fixChargeResultInformation = fixChargeResultInformation;
  }

  /**
   * 契約者情報のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者情報を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者情報
   */
  public KJ_InquiryContractorInformationEntityBean getContractorInformation() {
    return this.contractorInformation;
  }

  /**
   * 契約者情報のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者情報を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorInformation
   *          契約者情報
   */
  public void setContractorInformation(KJ_InquiryContractorInformationEntityBean contractorInformation) {
    this.contractorInformation = contractorInformation;
  }

  /**
   * カスタム契約者情報のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * カスタム契約者情報を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return カスタム契約者情報
   */
  public CContractor getCustomContractorInformation() {
    return this.customContractorInformation;
  }

  /**
   * カスタム契約者情報のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * カスタム契約者情報を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param CContractor
   *          カスタム契約者情報
   */
  public void setCustomContractorInformation(CContractor customContractorInformation) {
    this.customContractorInformation = customContractorInformation;
  }

  /**
   * メータ設置場所情報のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メータ設置場所情報を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return メータ設置場所情報
   */
  public KJ_InquiryMeterLocationEntityBean getMeterLocationInformation() {
    return this.meterLocationInformation;
  }

  /**
   * メータ設置場所情報のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メータ設置場所情報を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param meterLocationInformation
   *          メータ設置場所情報
   */
  public void setMeterLocationInformation(KJ_InquiryMeterLocationEntityBean meterLocationInformation) {
    this.meterLocationInformation = meterLocationInformation;
  }

  /**
   * 当月燃調単価のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 当月燃調単価を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 当月燃調単価
   */
  public BigDecimal getCurrentFuelCostUnitPrice() {
    return this.currentFuelCostUnitPrice;
  }

  /**
   * 当月燃調単価のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 当月燃調単価を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param currentFuelCostUnitPrice
   *          当月燃調単価
   */
  public void setCurrentFuelCostUnitPrice(BigDecimal currentFuelCostUnitPrice) {
    this.currentFuelCostUnitPrice = currentFuelCostUnitPrice;
  }

  /**
   * 翌月燃調単価のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 翌月燃調単価を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 翌月燃調単価
   */
  public BigDecimal getNextFuelCostUnitPrice() {
    return this.nextFuelCostUnitPrice;
  }

  /**
   * 翌月燃調単価のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 翌月燃調単価を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param nextFuelCostUnitPrice
   *          翌月燃調単価
   */
  public void setNextFuelCostUnitPrice(BigDecimal nextFuelCostUnitPrice) {
    this.nextFuelCostUnitPrice = nextFuelCostUnitPrice;
  }

  /**
   * 燃調単価差額のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 燃調単価差額を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 燃調単価差額
   */
  public BigDecimal getDiffFuelCostUnitPrice() {
    return this.diffFuelCostUnitPrice;
  }

  /**
   * 燃調単価差額のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 燃調単価差額を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param diffFuelCostUnitPrice
   *          燃調単価差額
   */
  public void setDiffFuelCostUnitPrice(BigDecimal diffFuelCostUnitPrice) {
    this.diffFuelCostUnitPrice = diffFuelCostUnitPrice;
  }

  /**
   * 当月再エネ単価のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 当月再エネ単価を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 当月再エネ単価
   */
  public BigDecimal getCurrentRenewableEnergyUnitPrice() {
    return this.currentRenewableEnergyUnitPrice;
  }

  /**
   * 当月再エネ単価のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 当月再エネ単価を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param currentRenewableEnergyUnitPrice
   *          当月再エネ単価
   */
  public void setCurrentRenewableEnergyUnitPrice(BigDecimal currentRenewableEnergyUnitPrice) {
    this.currentRenewableEnergyUnitPrice = currentRenewableEnergyUnitPrice;
  }

  /**
   * 翌月再エネ単価のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 翌月再エネ単価を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 翌月再エネ単価
   */
  public BigDecimal getNextRenewableEnergyUnitPrice() {
    return this.nextRenewableEnergyUnitPrice;
  }

  /**
   * 翌月再エネ単価のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 翌月再エネ単価を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param nextRenewableEnergyUnitPrice
   *          翌月再エネ単価
   */
  public void setNextRenewableEnergyUnitPrice(BigDecimal nextRenewableEnergyUnitPrice) {
    this.nextRenewableEnergyUnitPrice = nextRenewableEnergyUnitPrice;
  }

  /**
   * 実量歴管理情報のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 実量歴管理情報を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 実量歴管理情報
   */
  public RealQuantityHistoryBusinessBean getRealQuantityHistoryInformation() {
    return realQuantityHistoryInformation;
  }

  /**
   * 実量歴管理情報のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 実量歴管理情報を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param nextRenewableEnergyUnitPrice
   *          実量歴管理情報
   */
  public void setRealQuantityHistoryInformation(RealQuantityHistoryBusinessBean realQuantityHistoryInformation) {
    this.realQuantityHistoryInformation = realQuantityHistoryInformation;
  }

  /**
   * リターンコードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return リターンコード
   */
  public String getReturnCode() {
    return this.returnCode;
  }

  /**
   * リターンコードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param returnCode
   *          リターンコード
   */
  public void setReturnCode(String returnCode) {
    this.returnCode = returnCode;
  }

  /**
   * メッセージのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return メッセージ
   */
  public String getMessage() {
    return this.message;
  }

  /**
   * メッセージのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param message
   *          メッセージ
   */
  public void setMessage(String message) {
    this.message = message;
  }
}