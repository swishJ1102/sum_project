package jp.co.unisys.enability.cis.business.rk;

import java.math.BigDecimal;
import java.util.Comparator;
import java.util.List;

import jp.co.unisys.enability.cis.business.rk.model.RK_FixUsageApplyCategorizeResultBusinessBean;
import jp.co.unisys.enability.cis.business.rk.model.RK_FixUsageApplyTimeCategorizeResultBusinessBean;

/**
 * 使用量しわ取りビジネスクラス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_FixUsageApplyUsageCorrectionBusinessImpl implements
    RK_FixUsageApplyUsageCorrectionBusiness {

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.rk.
   * RK_FixUsageApplyUsageCorrectionBusiness#correct(java.math.BigDecimal,
   * java.util.List)
   */
  @Override
  public void correct(
      BigDecimal totalUsage,
      List<RK_FixUsageApplyCategorizeResultBusinessBean> categorizeResultBusinessBeanList) {

    // 仕訳結果の合計値を取得
    BigDecimal totalCategorized = BigDecimal.ZERO;
    for (RK_FixUsageApplyCategorizeResultBusinessBean result : categorizeResultBusinessBeanList) {
      totalCategorized = totalCategorized.add(result
          .getCategorizedUsage());
    }

    // 使用量全量と仕訳後使用量の合計が異なる場合、仕訳後使用量の補正を行う
    if (totalUsage.compareTo(totalCategorized) != 0) {

      // 使用量全量と仕訳後使用量の合計の差分
      BigDecimal diff = totalUsage.subtract(totalCategorized);

      // 引数のリストを日割開始日の降順でソートする
      categorizeResultBusinessBeanList.sort(Comparator.comparing(
          RK_FixUsageApplyCategorizeResultBusinessBean::getDateSlotStartDate, Comparator.reverseOrder()));

      for (RK_FixUsageApplyCategorizeResultBusinessBean result : categorizeResultBusinessBeanList) {
        // 補正後の値を計算
        BigDecimal calcVal = result.getCategorizedUsage().add(diff);

        // 補正後の値が0以上になる場合（補正しきれた場合）、
        // 仕訳後使用量に値を設定し、繰り返しを抜ける
        if (calcVal.compareTo(BigDecimal.ZERO) >= 0) {
          result.setCategorizedUsage(calcVal);
          break;
        } else {
          // 補正後の値が0未満の場合（補正しきれない場合）、
          // 差分より補正値を引き、仕訳後使用量に0を設定し、次の要素へ進む
          diff = diff.add(result.getCategorizedUsage());
          result.setCategorizedUsage(BigDecimal.ZERO);
        }
      }

      // 引数のリストを日割開始日の昇順でソートする
      categorizeResultBusinessBeanList.sort(Comparator
          .comparing(RK_FixUsageApplyCategorizeResultBusinessBean::getDateSlotStartDate));

      // 仕訳結果（時間帯毎）を集計
      for (RK_FixUsageApplyCategorizeResultBusinessBean result : categorizeResultBusinessBeanList) {

        boolean isSetCuPriorityOrder = false;

        // 仕訳結果の合計値を取得
        BigDecimal totalSubCategorized = BigDecimal.ZERO;
        for (RK_FixUsageApplyTimeCategorizeResultBusinessBean resultSub : result
            .getFixUsageApplyTimeCategorizeResultList()) {
          totalSubCategorized = totalSubCategorized.add(resultSub.getCategorizedUsage());

          // しわ取り優先順位が設定されているかチェック
          if (resultSub.getCuPriorityOrder() != null) {
            isSetCuPriorityOrder = true;
          }
        }

        // 日割毎の仕訳後使用量と仕訳後使用量の合計が異なる場合、仕訳後使用量の補正を行う
        if (result.getCategorizedUsage().compareTo(totalSubCategorized) != 0) {

          // 使用量全量と仕訳後使用量の合計の差分
          BigDecimal diffSub = result.getCategorizedUsage().subtract(totalSubCategorized);

          if (isSetCuPriorityOrder) {
            // しわ取り優先順位が設定されている場合

            // 仕訳結果時間帯リストをしわ取り優先順位の昇順でソートする
            // ※しわ取り優先順位がNULL（時間帯が料金算定期間内）は優先順が最後になるようにする
            result.getFixUsageApplyTimeCategorizeResultList().sort(
                Comparator.comparing(
                    RK_FixUsageApplyTimeCategorizeResultBusinessBean::getCuPriorityOrder,
                    Comparator.nullsLast(Comparator.naturalOrder())));

            for (RK_FixUsageApplyTimeCategorizeResultBusinessBean resultSub : result
                .getFixUsageApplyTimeCategorizeResultList()) {

              // 補正後の値を計算
              BigDecimal calcVal = resultSub.getCategorizedUsage().add(diffSub);

              // 補正後の値が0以上になる場合（補正しきれた場合）、
              // 仕訳後使用量に値を設定し、繰り返しを抜ける
              if (calcVal.compareTo(BigDecimal.ZERO) >= 0) {
                resultSub.setCategorizedUsage(calcVal);
                break;
              } else {
                // 補正後の値が0未満の場合（補正しきれない場合）、
                // 差分より補正値を引き、仕訳後使用量に0を設定し、次の要素へ進む
                diffSub = diffSub.add(resultSub.getCategorizedUsage());
                resultSub.setCategorizedUsage(BigDecimal.ZERO);
              }
            }

          } else {
            // しわ取り優先順位が設定されていない場合

            // 仕訳結果時間帯リストを仕訳後使用量の降順、表示順の昇順でソートする
            result.getFixUsageApplyTimeCategorizeResultList().sort(
                Comparator.comparing(
                    RK_FixUsageApplyTimeCategorizeResultBusinessBean::getCategorizedUsage,
                    Comparator.reverseOrder())
                    .thenComparing(
                        RK_FixUsageApplyTimeCategorizeResultBusinessBean::getDisplayOrder));

            // 補正値を取得
            // 使用量全量が仕訳後使用量の合計より大きい場合は1、それ以外は-1
            BigDecimal correct = BigDecimal.ZERO;
            if (diffSub.intValue() > 0) {
              correct = BigDecimal.ONE;
            } else {
              correct = BigDecimal.ONE.negate();
            }

            // 補正（使用量が大きいものから順に補正を行う）
            int endVal = Math.abs(diffSub.intValue());
            for (int index = 0; index < endVal; index++) {
              RK_FixUsageApplyTimeCategorizeResultBusinessBean resultSub = result
                  .getFixUsageApplyTimeCategorizeResultList().get(index);
              resultSub.setCategorizedUsage(resultSub.getCategorizedUsage().add(correct));
            }
          }

          // 仕訳結果時間帯リストを表示順の昇順でソートする
          result.getFixUsageApplyTimeCategorizeResultList().sort(
              Comparator.comparing(RK_FixUsageApplyTimeCategorizeResultBusinessBean::getDisplayOrder));
        }
      }
    }
  }
}
