package jp.co.unisys.enability.cis.business.rk;

import jp.co.unisys.enability.cis.business.rk.model.RK_ChargeCalcWarningCheckBusinessBean;
import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;
import jp.co.unisys.enability.cis.entity.common.DsUsageExample;
import jp.co.unisys.enability.cis.mapper.common.DsUsageMapper;

/**
 * BRK0103-03日割山最大数チェックビジネス
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.common.DateBusiness
 * @see jp.co.unisys.enability.cis.dao.rk.RK_ChargeCalcWarningCheckDao
 */
public class RK_ProratedUnitMaxCheckBusinessImpl implements
    RK_ChargeCalcWarningCheckBusiness {
  /**
   * 日割別使用量Mapper（DI）
   */
  private DsUsageMapper dsUsageMapper;

  /**
   * 日割山最大数チェックビジネス
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param chargeCalcWarningCheckBean
   *          《料金計算警告チェックビジネスBean》
   * @return 警告コード
   * @see jp.co.unisys.enability.cis.dao.rk.RK_ChargeCalcWarningCheckDao
   */
  @Override
  public String check(
      RK_ChargeCalcWarningCheckBusinessBean chargeCalcWarningCheckBean) {

    // 日割別使用量の取込状況を取得する。
    // 日割別使用量Example
    DsUsageExample dsUsageExample = new DsUsageExample();
    //【日割別使用量】を取得する条件を設定
    dsUsageExample.createCriteria()
        //確定使用量ID
        .andFuIdEqualTo(chargeCalcWarningCheckBean.getFuId());
    //日割別使用量Mapper.countByExampleを呼び出し、件数を取得する。
    //変数.件数が４件以上の場合
    if (dsUsageMapper.countByExample(dsUsageExample) >= ECISRKConstants.MAX_PRORATED_UNIT) {
      //戻り値に358 を設定する
      return ECISRKConstants.WARNING_CLASS_MASTER_PRORATED_UNIT_MAX;
    }
    //// 戻り値にnull を設定する。
    return null;
  }

  /**
   * 日割別使用量Mapperのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 日割別使用量Mapperを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param dsUsageMapper
   *          日割別使用量Mapper
   */
  public void setDsUsageMapper(DsUsageMapper dsUsageMapper) {
    this.dsUsageMapper = dsUsageMapper;
  }

}
