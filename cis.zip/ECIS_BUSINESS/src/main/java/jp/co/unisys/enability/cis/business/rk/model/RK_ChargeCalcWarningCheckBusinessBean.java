package jp.co.unisys.enability.cis.business.rk.model;

import java.math.BigDecimal;
import java.util.Date;

import jp.co.unisys.enability.cis.entity.common.CalculatingUsage;
import jp.co.unisys.enability.cis.entity.common.Rm;

/**
 * 料金計算警告チェックビジネスの情報を保持するクラス。
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * 1.RK_ManualCorrectionObjectCheckBusiness - 手動補正対象チェックビジネス
 * 2.RK_MonthlyChargeMinusCheckBusiness - 月額料金マイナスチェックビジネス
 * 3.RK_InstructionsNumAmountToUseDiffExistenceCheckBusiness - 指示数使用量差異有無チェックビジネス
 * 4.RK_PowerFactorIsNullCheckBusiness - 力率NULLチェックビジネス
 * 5.RK_CreditCardExpiryDateCheckBusiness - クレカ有効期限チェックビジネス
 * 6.RK_ProratedUnitMaxCheckBusiness - 日割山最大数チェックビジネス
 * 7.RK_HighVoltDiscussPowerExcessCheckBusiness - 高圧協議制の契約電力超過チェックビジネス
 * 8.RK_HighVoltDiscussExcessChargeCheckBusiness - 高圧協議制の契約超過金発生チェックビジネス
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_ChargeCalcWarningCheckBusinessBean {
  /**
   * 契約ID
   */
  private Integer contractId;

  /**
   * 利用年月
   */
  private String usePeriod;

  /**
   * 月額料金
   */
  private Long monthlyCharge;

  /**
   * 指示数算出使用量
   */
  private BigDecimal indicationNoCalculationUsage;

  /**
   * 使用量合計
   */
  private BigDecimal totalUsage;

  /**
   * チェック基準日
   */
  private Date checkBaseDate;

  /**
   * 料金算定開始日
   */
  private Date chargeCalculationStartDate;

  /**
   * 計算用使用量
   */
  private CalculatingUsage calculatingUsage;

  /**
   * 料金メニュー
   */
  private Rm rm;

  /**
   * 指示数使用量差異フラグ
   */
  private String fixInUsageDiffFlag;

  /**
   * 検針日数
   */
  private Integer meterReadingDays;

  /**
   * 置換前検針日数
   */
  private Integer beforeReplacementMeterReadingDays;

  /**
   * 確定使用量ID
   */
  private Integer fuId;

  /**
   * 部分供給区分コード
   */
  private String psInfoCatCode;

  /**
   * 契約超過金
   */
  private BigDecimal contractExcessCharge;

  /**
   * 契約IDのgetter。
   *
   * <pre>
   *
   * 契約IDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約ID
   */
  public Integer getContractId() {
    return contractId;
  }

  /**
   * 契約IDのsetter。
   *
   * <pre>
   *
   * 契約IDを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractId
   *          契約ID
   */
  public void setContractId(Integer contractId) {
    this.contractId = contractId;
  }

  /**
   * 利用年月のgetter。
   *
   * <pre>
   *
   * 利用年月を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 利用年月
   */
  public String getUsePeriod() {
    return usePeriod;
  }

  /**
   * 利用年月のsetter。
   *
   * <pre>
   *
   * 利用年月を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param usePeriod
   *          利用年月
   */
  public void setUsePeriod(String usePeriod) {
    this.usePeriod = usePeriod;
  }

  /**
   * 月額料金のgetter。
   *
   * <pre>
   *
   * 月額料金を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 月額料金
   */
  public Long getMonthlyCharge() {
    return monthlyCharge;
  }

  /**
   * 月額料金のsetter。
   *
   * <pre>
   *
   * 月額料金を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param usePeriod
   *          月額料金
   */
  public void setMonthlyCharge(Long monthlyCharge) {
    this.monthlyCharge = monthlyCharge;
  }

  /**
   * 指示数算出使用量のgetter。
   *
   * <pre>
   *
   * 指示数算出使用量を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 指示数算出使用量
   */
  public BigDecimal getIndicationNoCalculationUsage() {
    return indicationNoCalculationUsage;
  }

  /**
   * 指示数算出使用量のsetter。
   *
   * <pre>
   *
   * 指示数算出使用量を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param usePeriod
   *          指示数算出使用量
   */
  public void setIndicationNoCalculationUsage(BigDecimal indicationNoCalculationUsage) {
    this.indicationNoCalculationUsage = indicationNoCalculationUsage;
  }

  /**
   * 使用量合計のgetter。
   *
   * <pre>
   *
   * 使用量合計を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 使用量合計
   */
  public BigDecimal getTotalUsage() {
    return totalUsage;
  }

  /**
   * 使用量合計のsetter。
   *
   * <pre>
   *
   * 使用量合計を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param totalUsage
   *          使用量合計
   */
  public void setTotalUsage(BigDecimal totalUsage) {
    this.totalUsage = totalUsage;
  }

  /**
   * チェック基準日のgetter。
   *
   * <pre>
   *
   * チェック基準日を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return チェック基準日
   */
  public Date getCheckBaseDate() {
    return checkBaseDate;
  }

  /**
   * チェック基準日のsetter。
   *
   * <pre>
   *
   * チェック基準日を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param checkBaseDate
   *          チェック基準日
   */
  public void setCheckBaseDate(Date checkBaseDate) {
    this.checkBaseDate = checkBaseDate;
  }

  /**
   * 料金算定開始日のgetter。
   *
   * <pre>
   *
   * 料金算定開始日を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 料金算定開始日
   */
  public Date getChargeCalculationStartDate() {
    return chargeCalculationStartDate;
  }

  /**
   * 料金算定開始日のsetter。
   *
   * <pre>
   *
   * 料金算定開始日を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param chargeCalculationStartDate
   *          チェック基準日
   */
  public void setChargeCalculationStartDate(Date chargeCalculationStartDate) {
    this.chargeCalculationStartDate = chargeCalculationStartDate;
  }

  /**
   * 計算用使用量のgetter。
   *
   * <pre>
   *
   * 計算用使用量を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 計算用使用量
   */
  public CalculatingUsage getCalculatingUsage() {
    return calculatingUsage;
  }

  /**
   * 計算用使用量のsetter。
   *
   * <pre>
   *
   * 計算用使用量を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param calculatingUsage
   *          計算用使用量
   */
  public void setCalculatingUsage(CalculatingUsage calculatingUsage) {
    this.calculatingUsage = calculatingUsage;
  }

  /**
   * 料金メニューのgetter。
   *
   * <pre>
   *
   * 料金メニューを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 料金メニュー
   */
  public Rm getRm() {
    return rm;
  }

  /**
   * 料金メニューのsetter。
   *
   * @author "Nihon Unisys, Ltd."
   * @param rm
   *          料金メニュー
   */
  public void setRm(Rm rm) {
    this.rm = rm;
  }

  /**
   * 指示数使用量差異フラグのgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 指示数使用量差異フラグを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 指示数使用量差異フラグ
   */
  public String getFixInUsageDiffFlag() {
    return fixInUsageDiffFlag;
  }

  /**
   * 指示数使用量差異フラグのsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 指示数使用量差異フラグを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param fixInUsageDiffFlag
   *          指示数使用量差異フラグ
   */
  public void setFixInUsageDiffFlag(String fixInUsageDiffFlag) {
    this.fixInUsageDiffFlag = fixInUsageDiffFlag;
  }

  /**
   * 検針日数のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 検針日数を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 検針日数
   */
  public Integer getMeterReadingDays() {
    return this.meterReadingDays;
  }

  /**
   * 検針日数のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 検針日数を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param meterReadingDays
   *          検針日数
   */
  public void setMeterReadingDays(Integer meterReadingDays) {
    this.meterReadingDays = meterReadingDays;
  }

  /**
   * 置換前検針日数のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 置換前検針日数を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 置換前検針日数
   */
  public Integer getBeforeReplacementMeterReadingDays() {
    return this.beforeReplacementMeterReadingDays;
  }

  /**
   * 置換前検針日数のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 置換前検針日数を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param beforeReplacementMeterReadingDays
   *          置換前検針日数
   */
  public void setBeforeReplacementMeterReadingDays(Integer beforeReplacementMeterReadingDays) {
    this.beforeReplacementMeterReadingDays = beforeReplacementMeterReadingDays;
  }

  /**
   * 確定使用量IDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 確定使用量IDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 確定使用量ID
   */
  public Integer getFuId() {
    return this.fuId;
  }

  /**
   * 確定使用量IDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 確定使用量IDを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param fuId
   *          確定使用量ID
   */
  public void setFuId(Integer fuId) {
    this.fuId = fuId;
  }

  /**
   * 部分供給区分コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 部分供給区分コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 部分供給区分コード
   */
  public String getPsInfoCatCode() {
    return this.psInfoCatCode;
  }

  /**
   * 部分供給区分コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 部分供給区分コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param psInfoCatCode
   *          部分供給区分コード
   */
  public void setPsInfoCatCode(String psInfoCatCode) {
    this.psInfoCatCode = psInfoCatCode;
  }

  /**
   * 契約超過金のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約超過金を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約超過金
   */
  public BigDecimal getContractExcessCharge() {
    return contractExcessCharge;
  }

  /**
   * 契約超過金のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約超過金を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param psInfoCatCode
   *          契約超過金
   */
  public void setContractExcessCharge(BigDecimal contractExcessCharge) {
    this.contractExcessCharge = contractExcessCharge;
  }

}
