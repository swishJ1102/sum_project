package jp.co.unisys.enability.cis.business.gk;

import java.io.File;
import java.util.Date;
import java.util.List;

import jp.co.unisys.enability.cis.business.gk.model.GK_RegistDownloadManageBusinessBean;
import jp.co.unisys.enability.cis.business.sn.model.SN_CreateMailBusinessBean;
import jp.sf.orangesignal.csv.CsvWriter;

/**
 * 業務共通共通ビジネスインタフェース。
 * 
 * @author "Nihon Unisys, Ltd."
 *
 */
public interface GK_WorkCommonBusiness {

  /**
   * 計上年月日取得
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数の計上基準年月日を元に月次締め日を取得する。
   * 取得した月次締め日と引数の処理年月日を元に
   * 計上年月日を算出し返却する
   * </pre>
   * 
   * @param baseDate
   *          計上基準年月日
   * @param executeDate
   *          処理年月日
   * @return 計上年月日
   */
  public Date getRecordedDate(Date baseDate, Date executeDate);

  /**
   * CSVファイル出力
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数のヘッダ文字列が設定されている場合、
   * ヘッダ文字列をカンマで分割し、引数のCSVファイル出力リストの先頭に挿入する。
   * 引数のCSVファイル区分が"決済代行連携CSVファイル"か
   * "その他ファイル"の場合、ファイルを出力する。
   * それ以外の場合はシステム例外をスローする。
   * </pre>
   * 
   * @param fileOutputList
   *          CSVファイル出力リスト
   * @param csvCategory
   *          CSVファイル区分
   * @param file
   *          対象CSVファイル
   * @param header
   *          ヘッダ文字列
   */
  public void outputCsvFile(List<String[]> fileOutputList, String csvCategory, File file, String header);

  /**
   * CSVWriter作成
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数のCSVファイル区分を判定し、出力するCSVファイルの設定を行う。
   * ただし、CSVファイル区分が"決済代行CSVファイル"、もしくは"その他ファイル"以外の場合は
   * システム例外をスローする。
   * 区分毎に設定したCSVファイルの設定を元にCSVWriterオブジェクトを生成する。
   * ヘッダ文字列が設定されている場合は、カンマ区切りで分割し
   * CSVWriterオブジェクトのwriteValueメソッドを呼び出して先に分割した
   * ヘッダ文字列を出力する。
   * 上記処理がすべて終了後、CSVWriterオブジェクトを返却する。
   * </pre>
   * 
   * @param csvCategory
   *          CSVファイル区分
   * @param file
   *          対象CSVファイル
   * @param header
   *          ヘッダ文字列
   * @return CSVWriterオブジェクト
   */
  public CsvWriter createCsvWriter(String csvCategory, File file, String header);

  /**
   * ダウンロード登録管理
   * 
   * <pre>
   *<p><b>【仕様詳細】</b></p>
   * 引数の業務共通ダウンロード管理登録Bean.ダウンロード期限日数取得キーを元に
   * プロパティからダウンロード期限日数を取得する。
   * 取得した情報と引数を元に、ダウンロード管理へ登録する。
   * </pre>
   * 
   * @param businessBean
   *          業務共通ダウンロード管理登録Bean
   */
  public void registDownloadManage(GK_RegistDownloadManageBusinessBean businessBean);

  /**
   * 請求番号編集
   * 
   * <pre>
   *<p><b>【仕様詳細】</b></p>
   * 引数の請求番号に対し、画面表示用にハイフン編集を行い、返却する。
   *
   * </pre>
   * 
   * @param billingNo
   *          請求番号
   * @return 請求番号
   */
  public String editBillingNo(String billingNo);

  /**
   * メールテンプレート編集
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   *  メールテンプレートを編集する。
   *  メールテンプレートファイルを読み込み、該当する置換文字列を
   *  Beanプロパティの値に置換する。
   * </pre>
   *
   * @param mailTemplate
   *          メールテンプレート
   * @param bean
   *          メール作成用ビジネスBean
   * @return 編集後テンプレート
   */
  public String mailTextMaker(String mailTemplate, SN_CreateMailBusinessBean bean);

  /**
   * 文字列フォーマット編集
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   *  文字列フォーマットを編集する。
   *  文字列フォーマットを読み込み、該当する置換文字列を
   *  Beanプロパティの値に置換する。
   *  値がnullの置換文字列は空に設定して返却する。
   * </pre>
   *
   * @param stringFormat
   *          文字列フォーマット
   * @param bean
   *          メール作成用ビジネスBean
   * @return 編集後文字列
   */
  public String evaluateStringVelocity(String stringFormat, SN_CreateMailBusinessBean bean);
}
