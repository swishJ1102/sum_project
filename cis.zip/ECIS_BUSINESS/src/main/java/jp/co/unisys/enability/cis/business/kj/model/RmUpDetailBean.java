package jp.co.unisys.enability.cis.business.kj.model;

import java.math.BigDecimal;

/**
 * 契約情報更新で、更新条件を格納するビジネスBean
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * 契約情報更新ビジネス
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RmUpDetailBean {

  /** DCEC区分コード */
  private String dcecCategoryCode;

  /** 時間帯コード */
  private String timeSlotCode;

  /** 枝番 */
  private Short branchNo;

  /** 表示名称1 */
  private String displayName1;

  /** 表示名称2 */
  private String displayName2;

  /** 閾値 */
  private Integer threshold;

  /** 閾値名称 */
  private String thresholdName;

  /** 単価 */
  private BigDecimal unitPrice;

  /** 表示順 */
  private Short displayOrder;

  /** 明細出力順 */
  private Short detailOutputOrder;

  public String getDcecCategoryCode() {
    return dcecCategoryCode;
  }

  public void setDcecCategoryCode(String dcecCategoryCode) {
    this.dcecCategoryCode = dcecCategoryCode;
  }

  public String getTimeSlotCode() {
    return timeSlotCode;
  }

  public void setTimeSlotCode(String timeSlotCode) {
    this.timeSlotCode = timeSlotCode;
  }

  public Short getBranchNo() {
    return branchNo;
  }

  public void setBranchNo(Short branchNo) {
    this.branchNo = branchNo;
  }

  public String getDisplayName1() {
    return displayName1;
  }

  public void setDisplayName1(String displayName1) {
    this.displayName1 = displayName1;
  }

  public String getDisplayName2() {
    return displayName2;
  }

  public void setDisplayName2(String displayName2) {
    this.displayName2 = displayName2;
  }

  public Integer getThreshold() {
    return threshold;
  }

  public void setThreshold(Integer threshold) {
    this.threshold = threshold;
  }

  public String getThresholdName() {
    return thresholdName;
  }

  public void setThresholdName(String thresholdName) {
    this.thresholdName = thresholdName;
  }

  public BigDecimal getUnitPrice() {
    return unitPrice;
  }

  public void setUnitPrice(BigDecimal unitPrice) {
    this.unitPrice = unitPrice;
  }

  public Short getDisplayOrder() {
    return displayOrder;
  }

  public void setDisplayOrder(Short displayOrder) {
    this.displayOrder = displayOrder;
  }

  public Short getDetailOutputOrder() {
    return detailOutputOrder;
  }

  public void setDetailOutputOrder(Short detailOutputOrder) {
    this.detailOutputOrder = detailOutputOrder;
  }

}
