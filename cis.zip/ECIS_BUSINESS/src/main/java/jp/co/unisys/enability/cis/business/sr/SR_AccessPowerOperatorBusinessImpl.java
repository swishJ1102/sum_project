package jp.co.unisys.enability.cis.business.sr;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.URL;
import java.net.UnknownHostException;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.KeyStore;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SNIHostName;
import javax.net.ssl.SNIServerName;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLParameters;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.config.PropertiesFactoryBean;
import org.springframework.context.MessageSource;

import jp.co.unisys.enability.cis.business.sr.model.SR_SSLauthenticationBusinessBean;
import jp.co.unisys.enability.cis.common.Exception.SystemException;
import jp.co.unisys.enability.cis.common.util.RK_PropertyUtil;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISSRConstants;
import jp.co.unisys.enability.cis.entity.common.AreaM;
import jp.co.unisys.enability.cis.entity.common.PmCompanyM;
import jp.co.unisys.enability.cis.entity.common.TfMng;

/**
 * 電力事業者アクセスクラス
 *
 * @author "Nihon Unisys, Ltd."
 */
public class SR_AccessPowerOperatorBusinessImpl implements
    SR_AccessPowerOperatorBusiness {

  /** ロガー */
  private static final Logger LOGGER = LogManager.getLogger();

  /** コード定義プロパティ(DI) */
  private PropertiesFactoryBean applicationProperties;

  /** SSLSocket */
  private SSLSocket sslSock;

  /** SSLSocketのゲッター */
  private SSLSocket getSslSock() {
    return this.sslSock;
  }

  /** SSLSocketのセッター */
  private void setSslSock(SSLSocket sslSock) {
    this.sslSock = sslSock;
  }

  /** SSLSocketFactory */
  private SSLSocketFactory sslSocketFactory;

  /** SSLSocketFactoryのゲッター */
  private SSLSocketFactory getSSLSocketFactory() {
    return this.sslSocketFactory;
  }

  /** SSLSocketFactoryのゲッター */
  private void setSSLSocketFactory(SSLSocketFactory sslSocketFactory) {
    this.sslSocketFactory = sslSocketFactory;
  }

  /** ファイル種別切り取り文字数 */
  private static final Integer FILETYPECOUNT = 6;

  /** 受信ファイル一覧バックアップ時のファイルカウント */
  private static int fileCount = 0;

  /** メッセージプロパティ(DI) */
  private MessageSource messageSource;

  /** システム日時 */
  private Timestamp systemTime;

  /** システム日時ゲッター */
  private Timestamp getsystemTime() {
    return this.systemTime;
  }

  /** システム日時セッター */
  private void setsystemTime(Timestamp systemTime) {
    this.systemTime = systemTime;
  }

  /** バッチ処理基準日 **/
  private Date batchExecutesDate = null;

  /**
   * SSL認証
   *
   * <pre>
   * <p>
   * <b>【仕様詳細】</b>
   * </p>
   * SSL認証を行い、接続を行う。
   *
   * @author "Nihon Unisys, Ltd."
   * @param SR_SSLauthenticationBusinessBean
   *          SSL認証ビジネスBean
   * @param systemTime
   *          システム日時
   * @param batchExecutesDate
   *          バッチ処理基準日
   * @param pmCompany
   *          提供モデル企業マスタ
   * @param areaMaster
   *          エリアコードマスタ
   */
  public void sslAuthentication(
      SR_SSLauthenticationBusinessBean sslAuthentication,
      Timestamp systemTime, Date batchExecutesDate, PmCompanyM pmCompany, AreaM areaMaster)
      throws SystemException {

    setsystemTime(systemTime);

    // バッチ処理基準日の保持
    setBatchExecutesDate(batchExecutesDate);
    try {

      // 外部ファイル取得
      Properties prop = RK_PropertyUtil
          .getPropertiesFactory(applicationProperties);

      // KeyStoreの読み込み
      KeyStore keyStore = KeyStore.getInstance(pmCompany.getKeyStoreType());

      char[] keyPassChar = pmCompany.getCertificatePassword().toCharArray();

      keyStore.load(new FileInputStream(pmCompany.getCertificatePath()), keyPassChar);

      KeyManagerFactory kmf = KeyManagerFactory.getInstance(pmCompany.getKeyStoreAlgorithm());
      kmf.init(keyStore, keyPassChar);
      /**
       * // TrustStoreの読み込み KeyStore trustStore = KeyStore.getInstance(prop.getProperty("SSR0601.keyStore.Type")); char[]
       * trustPassChar = prop.getProperty("SSR0601.trustStorePass") .toCharArray(); trustStore.load( new
       * FileInputStream(prop.getProperty("SSR0601.trustStoreFilePath")), trustPassChar); TrustManagerFactory tmf =
       * TrustManagerFactory.getInstance(prop.getProperty("SSR0601.keyStore.Algorithm")); tmf.init(trustStore);
       */
      KeyManager[] keymanagers = kmf.getKeyManagers();

      SSLContext sContext = SSLContext.getInstance(pmCompany.getAccessProtocol());
      // TrustStoreは使用しないため、コメントアウト（念のため処理は残しておく）
      //TrustManager[] trustmanagers = tmf.getTrustManagers();
      //sContext.init(keymanagers, trustmanagers, null);

      //ホスト名の設定
      StringBuffer host_name = new StringBuffer();
      host_name.append(areaMaster.getHostName());
      host_name.append(":");
      host_name.append(areaMaster.getPortNo());
      sContext.init(keymanagers, null, null);
      SSLSocketFactory sslSokectFactory = sContext.getSocketFactory();
      setSSLSocketFactory(sslSokectFactory);

      Socket proxySocket = null;

      // プロパティにポート等設定されていない場合
      if (StringUtils.isNotEmpty(prop.getProperty("proxy.host"))) {
        proxySocket = new Socket(prop.getProperty("proxy.host"),
            Integer.parseInt(prop.getProperty("proxy.Port")));
      } else {
        proxySocket = new Socket();
      }

      doTunnelHandshake(proxySocket, host_name.toString(), areaMaster.getPortNo());
      // コネクション確立
      setSslSock((SSLSocket) sslSokectFactory.createSocket(
          proxySocket,
          host_name.toString(),
          areaMaster.getPortNo(),
          true));

      // ホスト名指定
      SNIHostName serverName = new SNIHostName(areaMaster.getHostName());
      List<SNIServerName> serverNames = new ArrayList<>(1);
      serverNames.add(serverName);
      SSLParameters params = getSslSock().getSSLParameters();
      params.setServerNames(serverNames);
      getSslSock().setSSLParameters(params);
      getSslSock().setUseClientMode(true);

      // 証明書の確認
      getSslSock().startHandshake();

      sslAuthentication.setReturnCode(ECISSRConstants.SSL_ACCESS_OK);

    } catch (UnknownHostException e) {
      LOGGER.error("接続先がありませんでした。(UnknownHostException)");
      // 接続なし
      sslAuthentication
          .setReturnCode(ECISSRConstants.SSL_ACCESS_NOACCESS);
      sslClose();
    } catch (IOException e) {
      LOGGER.error("接続先がありませんでした。(IOException)");
      // 接続なし
      sslAuthentication
          .setReturnCode(ECISSRConstants.SSL_ACCESS_NOACCESS);
      sslClose();
    } catch (Exception e) {
      // 予期せぬエラー
      sslClose();
      throw new SystemException("error.E1587", e);
    }
  }

  /**
   * ファイルリスト受信要求
   *
   * <pre>
   * <p>
   * <b>【仕様詳細】</b>
   * </p>
   * ファイル受信要求を行い、受信可能一覧を取得する。
   *
   * @author "Nihon Unisys, Ltd."
   * @param SR_SSLauthenticationBusinessBean
   *          SSL認証ビジネスBean
   */
  public void fileListReceptionRequest(
      SR_SSLauthenticationBusinessBean sslAuthentication) throws SystemException {

    // 外部ファイル取得
    Properties prop = RK_PropertyUtil
        .getPropertiesFactory(applicationProperties);
    // タグ検索文字
    String searchName = prop.getProperty("SSR0601.search.Name");

    HttpsURLConnection conn = getHttpsURLConnection(sslAuthentication.getAccessUrl());
    BufferedReader fileReader = null;
    try {
      // ファイルの取得かつ、保存
      String saveFilePath = receivableFileListBackUp(sslAuthentication, conn);

      // 保存したファイルを読み込む
      File file = new File(saveFilePath);
      fileReader = new BufferedReader(new FileReader(file));
      String fileReaderLine = null;
      StringBuffer allLine = new StringBuffer();
      while ((fileReaderLine = fileReader.readLine()) != null) {
        allLine.append(fileReaderLine);
      }

      List<String> fileList = new ArrayList<String>();

      // commentタグの抽出
      String comment = commentLine(allLine.toString());

      // ファイル名を取得
      for (String item : comment.split(ECISConstants.COMMA)) {
        if (item.indexOf(searchName) != -1) {
          for (String info : item.split(":")) {
            if (info.indexOf(searchName) == -1) {
              fileList.add(info.replaceAll("\"", "").trim());
            }
          }
        }
      }
      sslAuthentication.setReceivableFileList(fileList);
      fileReader.close();
    } catch (IOException e) {
      throw new SystemException("ファイルリスト受信要求に失敗しました", e);
    }
  }

  /**
   * ファイル受信要求
   *
   * <pre>
   * <p>
   * <b>【仕様詳細】</b>
   * </p>
   * ファイル受信要求を行い、Zipファイルを取得する。
   *
   * @author "Nihon Unisys, Ltd."
   * @param SR_SSLauthenticationBusinessBean
   *          SSL認証ビジネスBean
   * @param noReceivableFile
   *          未受信ファイル
   */
  public void fileReceptionRequest(
      SR_SSLauthenticationBusinessBean sslAuthentication,
      TfMng noReceivableFile) throws SystemException {

    // 外部ファイル取得
    Properties prop = RK_PropertyUtil
        .getPropertiesFactory(applicationProperties);

    StringBuffer sb1 = new StringBuffer();
    // 文字列連結
    sb1.append(sslAuthentication.getAccessUrl());
    sb1.append(noReceivableFile.getFileName().replaceAll(ECISConstants.FILE_EXTENSION_XML,
        ECISConstants.FILE_EXTENSION_ZIP));
    // setresponseにはファイル一覧リストではなく、ファイル情報を設定。
    // 接続に失敗した場合、接続失敗を返却する。
    HttpsURLConnection conn = null;
    conn = getHttpsURLConnection(sb1.toString());
    switch (distinguishContentType(conn.getContentType())) {
      case 0:
        try {
          // 対象ファイルのバックアップ
          saveFile(sslAuthentication,
              noReceivableFile.getFileName().replaceAll(ECISConstants.FILE_EXTENSION_XML,
                  ECISConstants.FILE_EXTENSION_ZIP),
              noReceivableFile.getFileName().substring(0, FILETYPECOUNT),
              prop.getProperty("SSR0601.ReceivableSaveFilePath"),
              conn.getInputStream());
        } catch (Exception e) {
          LOGGER.error("ファイルのバックアップに失敗しました。");
          throw new SystemException("ファイルのバックアップに失敗しました。", e);
        }
        break;
      case 1:
        sslAuthentication.setReceptionCode(ECISSRConstants.SSL_ACCESS_FILE_RECEPTION_NO);
        return;
      case -1:
        throw new SystemException("予期せぬ形式のファイルを受信しました");
    }

    try {
      // PPS区分+エリアコード+ファイル種別+対象年月日の基本パス作成
      StringBuffer bathPath = new StringBuffer();
      StringBuffer outputpath = new StringBuffer();
      StringBuffer sb = new StringBuffer();
      File outputfile = null;
      bathPath.append(ECISConstants.SLASH);
      bathPath.append(sslAuthentication.getPpsCat());
      bathPath.append(ECISConstants.SLASH);
      bathPath.append(sslAuthentication.getAreaCode());
      bathPath.append(ECISConstants.SLASH);
      bathPath.append(noReceivableFile.getFileName()
          .substring(0, FILETYPECOUNT));
      bathPath.append(ECISConstants.SLASH);
      bathPath.append(new SimpleDateFormat(ECISConstants.FORMAT_DATE_yyyyMMdd)
          .format(getBatchExecutesDate()));
      bathPath.append(ECISConstants.SLASH);

      // バックアップしたZipファイルを取得
      sb.append(prop.getProperty("SSR0601.ReceivableSaveFilePath"));
      sb.append(bathPath);
      sb.append(noReceivableFile.getFileName().replaceAll(ECISConstants.FILE_EXTENSION_XML,
          ECISConstants.FILE_EXTENSION_ZIP));
      File rcvFile = new File(sb.toString());

      switch (noReceivableFile.getFileName().substring(0, FILETYPECOUNT)) {
        // 高圧計量器交換ファイル
        case ECISSRConstants.LINKAGE_FILE_CATEGORY_M_HIGH_TENSION_METER_CHANGE_FILE:
          // 低圧計量器交換ファイル
        case ECISSRConstants.LINKAGE_FILE_CATEGORY_M_LOW_TENSION_METER_CHANGE_FILE:
          // 高圧臨時検針ファイル
        case ECISSRConstants.LINKAGE_FILE_CATEGORY_M_HIGH_TENSION_SPECIAL_METER_READING_FILE:
          // 低圧臨時検針ファイル
        case ECISSRConstants.LINKAGE_FILE_CATEGORY_M_LOW_TENSION_SPECIAL_METER_READING_FILE:

          // 使用量XMLファイル集信ディレクトリを指定
          outputpath.append(StringUtils.defaultString(prop
              .getProperty("batch.sr.usage.xmlfiles.receive.dir")));
          outputpath.append(bathPath);
          // フォルダ作成
          new File(outputpath.toString()).mkdirs();
          outputpath.append(noReceivableFile.getFileName().replaceAll(
              ECISConstants.FILE_EXTENSION_ZIP,
              ECISConstants.FILE_EXTENSION_XML));
          outputfile = new File(outputpath.toString());
          // ファイルの存在チェック
          if (outputfile.exists()) {
            outputpath.setLength(0);
            outputpath.append(noReceivableFile.getFileName());
            throw new SystemException(messageSource.getMessage(
                "error.E1061",
                new String[] {outputpath.toString() },
                Locale.getDefault()));
          }
          decodeZip(rcvFile, outputfile);
          break;
        // 高圧臨時検針ファイル
        case ECISSRConstants.LINKAGE_FILE_CATEGORY_M_HIGH_VOLTAGE_MONTH:
          // 低圧臨時検針ファイル
        case ECISSRConstants.LINKAGE_FILE_CATEGORY_M_LOW_VOLTAGE_MONTH:

          // 使用量XMLファイル集信ディレクトリを指定
          outputpath.append(StringUtils.defaultString(prop
              .getProperty("batch.sr.mdms.linkagefile.receive.dir")));
          outputpath.append(bathPath);
          // フォルダ作成
          new File(outputpath.toString()).mkdirs();

          // バックアップフォルダ作成
          StringBuffer sbBackUp = new StringBuffer();
          sbBackUp.append(outputpath.toString());
          sbBackUp.append(StringUtils.defaultString(prop
              .getProperty("batch.sr.mdms.unprocessname.backup")));
          new File(sbBackUp.toString()).mkdirs();

          // エラーフォルダ作成
          StringBuffer sbError = new StringBuffer();
          sbError.append(outputpath.toString());
          sbError.append(StringUtils.defaultString(prop
              .getProperty("batch.sr.mdms.unprocessname.error")));
          new File(sbError.toString()).mkdirs();
          // 取得したファイルの拡張子を変更
          outputpath.append(noReceivableFile.getFileName().replaceAll(
              ECISConstants.FILE_EXTENSION_ZIP,
              ECISConstants.FILE_EXTENSION_XML));
          outputfile = new File(outputpath.toString());
          // ファイルの存在チェック
          if (outputfile.exists()) {
            outputpath.setLength(0);
            outputpath.append(noReceivableFile.getFileName());
            throw new SystemException(messageSource.getMessage(
                "error.E1061",
                new String[] {outputpath.toString() },
                Locale.getDefault()));
          }
          decodeZip(rcvFile, outputfile);
          break;
      }
    } catch (Exception e) {
      LOGGER.error("ファイルの配置に失敗しました。{}", noReceivableFile.getFileName());
      throw new SystemException("ファイルの配置に失敗しました。", e);
    }
    sslAuthentication
        .setReceptionCode(ECISSRConstants.SSL_ACCESS_FILE_RECEPTION_OK);
  }

  /**
   * 受信可能ファイル一覧のバックアップ
   *
   * <pre>
   * <p>
   * <b>【仕様詳細】</b>
   * </p>
   * 受信可能ファイル一覧のバックアップ。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param SR_SSLauthenticationBusinessBean
   *          SSL認証ビジネスBean
   * @param conn
   *          SSL認証ビジネスBean
   */
  private String receivableFileListBackUp(
      SR_SSLauthenticationBusinessBean sslAuthentication, HttpsURLConnection conn)
      throws SystemException {
    // 外部ファイル取得
    Properties prop = RK_PropertyUtil
        .getPropertiesFactory(applicationProperties);
    try {
      StringBuffer sb = new StringBuffer();
      sb.append(prop
          .getProperty("SSR0601.ReceivableFileListBackUpFileName"));
      sb.append(new SimpleDateFormat(
          ECISConstants.FORMAT_DATE_yyyyMMddHHmmss)
              .format(getsystemTime()));
      sb.append("_");
      sb.append(String.valueOf(++fileCount));
      sb.append(ECISConstants.FILE_EXTENSION_XML);
      // 受信可能ファイル一覧のバックアップ
      String savePath = saveFile(sslAuthentication, sb.toString(),
          null, prop.getProperty("SSR0601.ReceivableFileListBackUpFilePath"), conn.getInputStream());
      return savePath;

    } catch (Exception e) {
      throw new SystemException(messageSource.getMessage("error.E1587",
          null, Locale.getDefault()), e);
    }
  }

  /**
   * SSL接続のクローズ
   *
   * <pre>
   * <p>
   * <b>【仕様詳細】</b>
   * </p>
   * 接続しているSSLをクローズする。
   *
   * @author "Nihon Unisys, Ltd."
   */
  public void sslClose() throws SystemException {

    if (getSslSock() != null) {
      try {
        getSslSock().close();
      } catch (IOException e) {
        throw new SystemException(messageSource.getMessage(
            "error.E1587", null, Locale.getDefault()));
      }
    }
  }

  /**
   * commentタグの内容取得
   *
   * <pre>
   * <p>
   * <b>【仕様詳細】</b>
   * </p>
   * 取得したHTMLを解析し、commentタグの文字列を取得する。
   *
   * @author "Nihon Unisys, Ltd."
   * @param String
   *          response 取得結果
   */
  private String commentLine(String response) {

    /** 外部ファイル取得 */
    Properties prop = RK_PropertyUtil
        .getPropertiesFactory(applicationProperties);
    /** 改行コードのパターン */
    String lineSeparatorPattern = prop
        .getProperty("SSR0601.Line.Separator.Pattern");
    /** レスポンスの開始タグ */
    String resStartTag = prop.getProperty("SSR0601.Res.Start.Tag");
    /** レスポンスの終了タグ */
    String resEndTag = prop.getProperty("SSR0601.Res.End.Tag");
    StringBuffer commentMessage = new StringBuffer();
    // 行分活用のパターン
    Pattern pattern = Pattern.compile(lineSeparatorPattern);
    // 文字列を改行コードで行ごとに分割する。
    boolean startFlg = false;
    // HTMLの解析を行う。
    for (String s : pattern.split(response.trim())) {
      // 前後の制御文字を削除した文字列を処理する
      String line = s.trim();
      // <comment>タグの判定
      if (line.indexOf(resStartTag) != -1 || startFlg) {
        startFlg = true;
        commentMessage.append(s);
      }
      // </coment>タグが存在し、かつフラグがtrueの場合
      if (line.indexOf(resEndTag) != -1 && startFlg) {
        startFlg = false;
        break;
      }
    }
    return commentMessage.toString();
  }

  /**
   * ファイルの保存
   *
   * <pre>
   * <p>
   * <b>【仕様詳細】</b>
   * </p>
   * getresponseに設定したデータを保存する。
   *
   * @author "Nihon Unisys, Ltd."
   * @param sslAuthentication
   *          SSL認証ビジネスBean
   * @param saveFileName
   *          保存ファイル名
   * @param saveFileType
   *          保存ファイル種別
   * @param saveFilePath
   *          保存先ファイルパス
   */
  private String saveFile(SR_SSLauthenticationBusinessBean sslAuthentication,
      String saveFileName, String saveFileType, String saveFilePath,
      InputStream getZipFile) throws SystemException {
    FileOutputStream stream = null;
    StringBuffer sb = new StringBuffer();
    try {
      // 文字列連結
      sb.append(saveFilePath);
      sb.append(ECISConstants.SLASH);
      sb.append(sslAuthentication.getPpsCat());
      sb.append(ECISConstants.SLASH);
      sb.append(sslAuthentication.getAreaCode());
      sb.append(ECISConstants.SLASH);
      if (saveFileType != null) {
        sb.append(saveFileType);
        sb.append(ECISConstants.SLASH);
      }
      sb.append(new SimpleDateFormat(ECISConstants.FORMAT_DATE_yyyyMMdd)
          .format(getBatchExecutesDate()));
      // バックアップフォルダを作成
      new File(sb.toString()).mkdirs();
      sb.append(ECISConstants.SLASH);
      sb.append(saveFileName);
      // バックアップファイルを作成
      File rcvFile = new File(sb.toString());
      // ファイルの存在チェック
      if (rcvFile.exists()) {
        sb.setLength(0);
        sb.append(saveFileName);
        throw new SystemException(messageSource.getMessage(
            "error.E1061", new String[] {sb.toString() },
            Locale.getDefault()));
      }
      // ファイルの保存
      Files.copy(getZipFile, rcvFile.toPath());
      return sb.toString();

    } catch (FileNotFoundException e) {
      LOGGER.error("saveFile＞FileOutputStreamエラー 出力先パス={}", sb.toString());
      throw new SystemException("FileNotFoundExceptionが発生しました", e);
    } catch (IOException e) {
      LOGGER.error(
          "saveFile＞IOExceptionエラー Zipの書き込みに失敗しました。PPS区分:{},エリア:{}",
          sslAuthentication.getPpsCat(),
          sslAuthentication.getAreaCode());
      throw new SystemException("IOExceptionエラー Zipの書き込みに失敗しました。", e);
    } finally {
      try {
        if (stream != null) {
          stream.close();
        }
      } catch (IOException e) {
        LOGGER.error("streamのクローズに失敗しました。");
        throw new SystemException("streamのクローズに失敗しました。", e);
      }
    }
  }

  /**
   * コンテントタイプ判別および変換処理
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 取得したファイルのコンテントタイプが
   * ZipかHTMLか判定を行う。
   * </pre>
   *
   * @param contentType
   *          コンテントタイプ
   * @throws SystemException
   *           例外が発生した場合
   */
  private int distinguishContentType(String contentType) {

    Matcher zipMatcher = Pattern.compile("^application/zip;.*").matcher(contentType);
    Matcher htmlMatcher = Pattern.compile("^application/html;.*").matcher(contentType);

    if (zipMatcher.find()) {
      return 0; //ZIP
    } else if (htmlMatcher.find()) {
      return 1; //html
    } else {
      return -1; //その他
    }

  }

  /**
   * ZIPファイル解凍
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * XMLファイル連携で取得したZIPファイルを解凍する。
   * 保存したいファイルは事前に作成しておくこと。
   * </pre>
   *
   * @param inputFile
   *          解凍前のZIPファイル
   * @param outputFile
   *          解凍後のファイル
   *
   * @throws SystemException
   *           例外が発生した場合
   */
  private void decodeZip(File inputFile, File outputFile)
      throws SystemException {

    List<File> unzipFileList = new ArrayList<File>();
    FileChannel fc = null;
    boolean unzipflg = false;
    try (ZipFile zipFile = new ZipFile(inputFile)) {
      try (ZipInputStream zis = new ZipInputStream(new FileInputStream(
          inputFile))) {
        for (ZipEntry entry = zis.getNextEntry(); entry != null; entry = zis
            .getNextEntry()) {

          try (BufferedOutputStream bos = new BufferedOutputStream(
              new FileOutputStream(outputFile));
              InputStream is = zipFile.getInputStream(entry)) {
            byte[] buf = new byte[ECISConstants.UNZIP_BUFFER_SIZE];
            int readSize = 0;
            while ((readSize = is.read(buf)) != -1) {
              bos.write(buf, 0, readSize);
            }
          }
        }
      }
    } catch (Exception e) {
      if (unzipflg) {
        for (Iterator<File> iterator = unzipFileList.iterator(); iterator
            .hasNext();) {
          File unzipedFile = (File) iterator.next();
          unzipedFile.delete();
        }
      }
      LOGGER.error("解凍対象ファイルが見つかりませんでした。");
      throw new SystemException("解凍対象ファイルが見つかりませんでした。", e);
    } finally {
      if (fc != null) {
        try {
          fc.close();
        } catch (IOException e) {
          LOGGER.error("ファイルをクローズできませんでした。");
          throw new SystemException("ファイルをクローズできませんでした。", e);
        }
      }
    }

  }

  /**
   * トネリング接続
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * SSL接続を行う前にCONNECTコマンドを実行し、
   * プロキシとの接続を行う。
   * </pre>
   *
   * @param tunnel
   *          プロキシ設定されたソケット
   * @param host
   *          接続先のホスト名
   * @param port
   *          接続先のポート番号
   *
   * @throws IOException
   *           例外が発生した場合
   */
  private void doTunnelHandshake(Socket tunnel, String host, int port) throws IOException {

    // 外部ファイル取得
    Properties prop = RK_PropertyUtil
        .getPropertiesFactory(applicationProperties);
    try {
      // プロキシソケットから出力ストリーム取得
      OutputStream out = tunnel.getOutputStream();

      // HTTPのCONNECTコマンド内容の設定
      String msg = "CONNECT " + host + " HTTP/1.0\r\n"
          + "User-Agent:"
          + sun.net.www.protocol.http.HttpURLConnection.userAgent
          + "\r\n\r\n";
      // 出力ストリームの書き込み
      out.write(msg.getBytes(StandardCharsets.US_ASCII));
      // 出力ストリームのフラッシュ
      out.flush();

      // 公開Webサーバからの返信内容格納バッファ
      byte[] reply = new byte[200];
      int replyLen = 0;
      int newlinesSeen = 0;
      // ヘッダ読み込み完了フラグ
      boolean headerDone = false;
      // プロキシソケットから入力ストリーム取得
      InputStream in = tunnel.getInputStream();
      // 返信内容のステータス行の抽出
      while (newlinesSeen < 2) {
        //入力ストリームの読み込み
        int i = in.read();

        if (i < 0) {
          // EOF到達の場合
          throw new IOException("プロキシサーバから予期しないEOFが返却された");
        }

        if (i == '\n') {
          // LF検知の場合、ヘッダ読み込み完了フラグをtrueに設定。
          headerDone = true;
          ++newlinesSeen;
        } else if (i != '\r') {
          // CR以外検知の場合(CRは読み捨て)
          newlinesSeen = 0;
          if (!headerDone && replyLen < reply.length) {
            // レスポンスメッセージのステータス行の内容を格納
            reply[replyLen++] = (byte) i;
          }
        }
      }
      // 返信内容のステータス行を文字列変換
      String replyStr = new String(reply, 0, replyLen, StandardCharsets.US_ASCII);
      // ステータス行が正常を返しているかどうかを判別する。
      if (!(replyStr.startsWith("HTTP/1.0 200") || replyStr.startsWith("HTTP/1.1 200"))) {
        throw new IOException(("Unable to tunnel through ")
            + prop.getProperty("proxy.host") + ":" + Integer.parseInt(prop.getProperty("proxy.Port"))
            + ".  Proxy returns \"" + replyStr + "\"");
      }
    } catch (IOException e) {
      LOGGER.info("トネリンングの確立に失敗しました。接続先ホスト:{} 接続先ポート:{} プロキシホスト{} プロキシポート{}",
          host, port, prop.getProperty("proxy.host"), Integer.parseInt(prop.getProperty("proxy.Port")));
      throw new IOException();
    }
  }

  /**
   * URLコネクション設定
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * ファイルの取得を行う際に必要な設定を行う。
   * </pre>
   *
   * @param accessUrl
   *          接続先URL
   */
  public HttpsURLConnection getHttpsURLConnection(String accessUrl) throws SystemException {

    // 外部ファイル取得
    Properties prop = RK_PropertyUtil
        .getPropertiesFactory(applicationProperties);

    // SSLによるURL接続インスタンス
    HttpsURLConnection conn = null;

    // プロキシサーバ有無の設定
    System.setProperty("https.proxySet", "true");
    if (StringUtils.isNotEmpty(prop.getProperty("proxy.host"))) {
      // プロキシサーバアドレスの設定
      System.setProperty("https.proxyHost", prop.getProperty("proxy.host"));
      // プロキシサーバポートの設定
      System.setProperty("https.proxyPort", prop.getProperty("proxy.Port"));
    }

    // 使用量外部接続タイムアウト値
    int connectionTimeout = Integer.parseInt(prop.getProperty("usage.external.connection.timeout"));

    // 使用量外部読込タイムアウト値
    int readTimeout = Integer.parseInt(prop.getProperty("usage.external.read.timeout"));

    try {
      // URLクラスのインスタンス生成（HTTPS接続実行）
      URL url = new URL(accessUrl);

      // URLクラスのコネクション開始呼出
      conn = (HttpsURLConnection) url.openConnection();

      // SSLソケットファクトリ設定
      conn.setSSLSocketFactory(getSSLSocketFactory());

      // 使用量外部接続タイムアウト設定
      conn.setConnectTimeout(connectionTimeout);

      // 使用量外部読込タイムアウト設定
      conn.setReadTimeout(readTimeout);

      // SSL経由で接続
      conn.connect();

      // レスポンスチェック
      if (conn.getResponseCode() != HttpsURLConnection.HTTP_OK) {
        throw new IOException(
            " accessUrl " + accessUrl +
                " responseCode " + conn.getResponseCode() +
                " proxyHost " + prop.getProperty("proxy.host") +
                " proxyPort " + prop.getProperty("proxy.Port"));
      }
      return conn;

    } catch (Exception e) {
      throw new SystemException("ファイル取得時の接続に失敗しました。", e);
    }
  }

  /**
   * メッセージプロパティのsetter（DI）
   *
   * @param messageSource
   *          メッセージプロパティ
   */
  public void setmessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }

  /**
   * コード定義プロパティのsetter（DI）
   *
   * @param messageSource
   *          メッセージプロパティ
   */
  public void setapplicationProperties(
      PropertiesFactoryBean applicationProperties) {
    this.applicationProperties = applicationProperties;
  }

  /**
   * バッチ処理基準日のgetter
   *
   * @return バッチ処理基準日
   */
  public Date getBatchExecutesDate() {
    return batchExecutesDate;
  }

  /**
   * バッチ処理基準日のsetter
   *
   * @param batchExecutesDate
   *          バッチ処理基準日
   */
  public void setBatchExecutesDate(Date batchExecutesDate) {
    this.batchExecutesDate = batchExecutesDate;
  }

}
