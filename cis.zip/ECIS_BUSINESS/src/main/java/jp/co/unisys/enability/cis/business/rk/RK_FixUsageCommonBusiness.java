package jp.co.unisys.enability.cis.business.rk;

import java.math.BigDecimal;
import java.util.List;

import jp.co.unisys.enability.cis.entity.common.DemandResult;

/**
 * 確定使用量共通ビジネスインターフェース。
 *
 * @author "Nihon Unisys, Ltd."
 */
public interface RK_FixUsageCommonBusiness {

  /**
   * 需要実績から30分確定電力量のリストを取得する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 【需要実績】の30分確定電力量01～48の項目をリスト化して返却する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param demandResult
   *          需要実績EntityBean
   * @return 30分確定電力量のリスト
   */
  public abstract List<BigDecimal> demandResultToFixUsageList(DemandResult demandResult);

  /**
   * 時分を表す文字列（"0000"～"2330"）を0～47の序数に変換する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金メニュー時間帯詳細の開始時分・終了時分の文字列をリストの序数に変換する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param mmdd
   *          時分を表す文字列
   * @return 0から47の数値
   */
  public abstract int convertHmToOrdinal(String mmdd);

  /**
   * 使用量の丸めを行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 使用量の丸めを行う。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param usage
   *          丸めを行う使用量
   * @return 丸め結果
   */
  public abstract BigDecimal roundUsage(BigDecimal usage);
}
