package jp.co.unisys.enability.cis.business.rk;

import java.util.List;

import jp.co.unisys.enability.cis.business.rk.model.RK_FixUsageApplyCategorizeResultBusinessBean;
import jp.co.unisys.enability.cis.business.rk.model.RK_FixUsageApplyUsageBusinessBean;
import jp.co.unisys.enability.cis.entity.common.ContractHist;

/**
 * 使用量仕訳ビジネスインターフェース。
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.gk.CalendarBusiness
 * @see jp.co.unisys.enability.cis.mapper.rk.RK_FixUsageApplyMapper
 */
public interface RK_FixUsageApplyUsageCategorizeBusiness {

  /**
   * 引数で指定された料金メニューで使用量の仕訳を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金メニューIDから時間帯で仕訳を行うための情報を取得し、
   * 使用量の仕訳を行った結果を返却する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractHistList
   *          契約履歴リスト
   * @param usageBusinessBeanList
   *          使用量を保持するBean
   * @return 仕訳結果のリスト
   * @see jp.co.unisys.enability.cis.business.gk.CalendarBusiness
   * @see jp.co.unisys.enability.cis.mapper.rk.RK_FixUsageApplyMapper
   */
  public abstract List<RK_FixUsageApplyCategorizeResultBusinessBean> categorize(
      List<ContractHist> contractHistList,
      List<RK_FixUsageApplyUsageBusinessBean> usageBusinessBeanList);
}
