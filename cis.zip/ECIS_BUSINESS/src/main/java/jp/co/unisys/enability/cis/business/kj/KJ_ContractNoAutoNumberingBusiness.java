package jp.co.unisys.enability.cis.business.kj;

import jp.co.unisys.enability.cis.business.kj.model.RegistAgentContractBusinessBean;

/**
 * 契約番号自動発番ビジネスインターフェース。
 *
 * @author "Nihon Unisys, Ltd."
 *
 */
public interface KJ_ContractNoAutoNumberingBusiness {

  /**
   * 契約番号自動発番を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約番号自動発番を行う。
   * ※テナントによってDIするクラスが異なる。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param registAgentContractBusinessBean
   *          契約情報登録BusinessBean
   */
  public void autoNumbering(RegistAgentContractBusinessBean registAgentContractBusinessBean);
}
