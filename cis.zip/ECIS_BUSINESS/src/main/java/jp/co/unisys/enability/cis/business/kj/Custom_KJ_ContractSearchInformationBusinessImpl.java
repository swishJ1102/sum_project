/**
 *
 */
package jp.co.unisys.enability.cis.business.kj;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.config.PropertiesFactoryBean;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.dao.DataAccessException;

import jp.co.unisys.enability.cis.business.common.DateBusiness;
//[kg-epj]<d-start>
//import jp.co.unisys.enability.cis.business.kj.model.SearchContractBusinessBean;
//[kg-epj]<d-end>
//[kg-epj]<i-start>
import jp.co.unisys.enability.cis.business.kj.model.Custom_SearchContractBusinessBean;
//[kg-epj]<i-end>
import jp.co.unisys.enability.cis.common.Exception.SystemException;
import jp.co.unisys.enability.cis.common.util.KJ_CommonUtil;
import jp.co.unisys.enability.cis.common.util.StringConvertUtil;
import jp.co.unisys.enability.cis.common.util.constants.ECISCodeConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISKJConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISReturnCodeConstants;
//[kg-epj]<d-start>
//import jp.co.unisys.enability.cis.entity.kj.KJ_ContractorInformationSearchEntityBean;
//import jp.co.unisys.enability.cis.mapper.kj.ContractInfoSearchCommonMapper;
//[kg-epj]<d-end>
//[kg-epj]<i-start>
import jp.co.unisys.enability.cis.entity.kj.Custom_KJ_ContractorInformationSearchEntityBean;
import jp.co.unisys.enability.cis.mapper.kj.Custom_ContractInfoSearchCommonMapper;
//[kg-epj]<i-end>

/**
 * 契約情報検索ビジネス
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.kj.Custom_KJ_ContractSearchInformationBusiness
 */
//[kg-epj]<d-start>
//public class KJ_ContractSearchInformationBusinessImpl implements
//		KJ_ContractSearchInformationBusiness {
//[kg-epj]<d-end>
//[kg-epj]<i-start>
public class Custom_KJ_ContractSearchInformationBusinessImpl implements
    Custom_KJ_ContractSearchInformationBusiness {
  //[kg-epj]<i-end>

  /**
   * メッセージリソース(DI)
   */
  private MessageSource messageSource;

  /**
   * 契約情報検索共通マッパー(DI)
   */
  //[kg-epj]<d-start>
  //private ContractInfoSearchCommonMapper contractInfoSearchCommonMapper;
  //[kg-epj]<d-end>
  //[kg-epj]<i-start>
  private Custom_ContractInfoSearchCommonMapper contractInfoSearchCommonMapper;
  //[kg-epj]<i-end>

  /**
   * 日付関連共通ビジネス(DI)
   */
  private DateBusiness dateBusiness;

  /**
   * プロパティファクトリー(DI)
   */
  private PropertiesFactoryBean applicationProperties;

  /**
   * ログマネジャー
   */
  private static Logger logger = LogManager.getLogger();

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.kj.
   * Custom_KJ_ContractSearchInformationBusiness #search(jp.co.unisys.enability.cis
   * .business.kj.model.Custom_SearchContractBusinessBean)
   */
  @Override
  //[kg-epj]<d-start>
  //public SearchContractBusinessBean search(
  //		SearchContractBusinessBean searchContractBusiness) {
  //[kg-epj]<d-end>
  //[kg-epj]<i-start>
  public Custom_SearchContractBusinessBean search(
      Custom_SearchContractBusinessBean searchContractBusiness) {
    //[kg-epj]<i-end>

    String errMsg = null;
    String fileMsg = null;

    try {

      // Propaertiesオブジェクト取得
      Properties prop = applicationProperties.getObject();

      // システムエラーメッセージを取得
      errMsg = messageSource.getMessage(KJ_CommonUtil
          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G017),
          new String[] {}, Locale.getDefault());

      fileMsg = messageSource.getMessage("error.E1283", null,
          Locale.getDefault());

      // 契約情報検索BusinessBean.最大検索結果件数がnullまたは'0'の場合、以下を設定する。
      if (searchContractBusiness.getMaxSearchResultCount() == null
          || searchContractBusiness.getMaxSearchResultCount().equals(
              0)) {
        // 契約情報検索BusinessBean.最大検索結果件数:システム定義.最大検索結果件数
        // 最大検索件数を取得する。
        searchContractBusiness
            .setMaxSearchResultCount(StringConvertUtil
                .stringToInteger(prop
                    .getProperty("maxsearchcount.SKJ020101")));
      }

      // 契約情報検索BusinessBean.契約者電話番号が設定されている場合、以下を設定する。
      String cntractorPhoneNo = searchContractBusiness
          .getContractorPhoneNo();
      if (cntractorPhoneNo != null) {
        // 契約情報検索BusinessBean.契約者電話番号のハイフンを除去
        cntractorPhoneNo = cntractorPhoneNo.replace(
            ECISConstants.HYPHEN, "");
      }

      // 契約情報検索マップに契約情報検索BusinessBeanを設定する。
      Map<String, Object> exampleMap = new HashMap<String, Object>();
      // 契約者ID
      exampleMap.put("contractorId",
          searchContractBusiness.getContractorId());
      // 契約者番号
      exampleMap.put("contractorNo",
          searchContractBusiness.getContractorNo());
      // 個人・法人区分コード
      exampleMap.put("individualLegalEntityCategoryCode",
          searchContractBusiness
              .getIndividualLegalEntityCategoryCode());
      // 契約者名カナ
      exampleMap.put("contractorNameKana",
          searchContractBusiness.getContractorNameKana());
      // 契約者名
      exampleMap.put("contractorNameKanji",
          searchContractBusiness.getContractorNameKanji());
      // 契約者住所
      exampleMap.put("contractorAddress",
          searchContractBusiness.getContractorAddress());
      // 契約者電話番号
      exampleMap.put("contractorPhoneNo", cntractorPhoneNo);
      // 契約者メールアドレス
      exampleMap.put("contractorMailAddress",
          searchContractBusiness.getContractorMailAddress());
      // 提供モデルコード
      exampleMap.put("provideModelCode",
          searchContractBusiness.getProvideModelCode());
      // 提供モデル企業コード
      exampleMap.put("provideModelCompanyCode",
          searchContractBusiness.getProvideModelCompanyCode());
      // 契約ID
      exampleMap
          .put("contractId", searchContractBusiness.getContractId());
      // 契約番号
      exampleMap
          .put("contractNo", searchContractBusiness.getContractNo());
      // 営業委託先コード
      exampleMap.put("salesConsignmentCode",
          searchContractBusiness.getSalesConsignmentCode());
      // メータ設置場所ID
      exampleMap.put("meterLocationId",
          searchContractBusiness.getMeterLocationId());
      // 地点特定番号
      exampleMap.put("spotNo", searchContractBusiness.getSpotNo());
      // 送受電区分コード
      exampleMap.put("transmissionCategoryCode",
          searchContractBusiness.getTransmissionCategoryCode());
      // 需要場所住所
      exampleMap.put("placeAddress",
          searchContractBusiness.getPlaceAddress());
      // 請求ID
      exampleMap.put("billingId", searchContractBusiness.getBillingId());
      // 請求番号
      exampleMap.put("billingNo", searchContractBusiness.getBillingNo());
      // 契約終了状況
      exampleMap.put("contractEndSts",
          searchContractBusiness.getContractEndSts());
      // 契約者利用状況
      exampleMap.put("contractorUseSts",
          searchContractBusiness.getContractorUseSts());
      // 最大検索結果件数
      exampleMap.put("maxSearchResultCount",
          searchContractBusiness.getMaxSearchResultCount());

      // オンライン基準処理日
      exampleMap.put("onlineDate", dateBusiness
          .getProcessBaseDate(ECISConstants.EXEC_BASE_DATE_ONLINE));

      //[kg-epj]<i-start>
      // 外部システム契約者番号
      exampleMap.put("gasCustomerNo", searchContractBusiness.getGasCustomerNo());
      // 外部システム契約番号
      exampleMap.put("gasSupplyContractNo", searchContractBusiness
          .getGasSupplyContractNo());
      // 外部システム支払番号
      exampleMap.put("gasPaymentNo", searchContractBusiness
          .getGasPaymentNo());
      //[kg-epj]<i-end>
      // 電圧区分コード
      if (searchContractBusiness.getVoltageCategoryCode() == null) {
        exampleMap.put("voltageCategoryCode",
            ECISCodeConstants.CUSTOM_VOLTAGE_CAT_CODE_LOW_TENSION);
      } else {
        exampleMap.put("voltageCategoryCode",
            searchContractBusiness.getVoltageCategoryCode());
      }
      // 契約電力決定区分コード
      exampleMap.put("contractCapacityDecisionCategoryCode",
          searchContractBusiness.getContractCapacityDecisionCategoryCode());

      // 検索結果件数取得
      // 1契約情報検索共通マッパー.契約情報検索件数呼び出し
      // 引数：契約情報検索マップ
      int resultCount = contractInfoSearchCommonMapper
          .countByControctInfoSearch(exampleMap);

      // 契約情報検索
      //[kg-epj]<d-start>
      //List<KJ_ContractorInformationSearchEntityBean> resultList = new ArrayList<KJ_ContractorInformationSearchEntityBean>();
      //[kg-epj]<d-end>
      //[kg-epj]<i-start>
      List<Custom_KJ_ContractorInformationSearchEntityBean> resultList = new ArrayList<Custom_KJ_ContractorInformationSearchEntityBean>();
      //[kg-epj]<i-end>
      // 検索結果件数取得の結果が1件以上の場合、以下の処理を行う。
      if (resultCount > 0) {
        // 契約情報検索共通マッパー.契約情報検索呼び出し
        // 引数：契約情報検索マップ
        resultList = contractInfoSearchCommonMapper
            .controctInfoSearch(exampleMap);
      }

      // 契約情報検索BusinessBeanを作成し、契約情報検索共通マッパー.契約情報検索の戻り値等を設定する。
      // 契約情報検索BusinessBean.検索結果件数：検索結果件数取得の戻り値
      searchContractBusiness.setSearchResultCount(resultCount);
      // 契約情報検索BusinessBean.契約者情報検索結果一覧エンティティリスト：契約情報検索の戻り値
      searchContractBusiness.setSerchContractorEntityList(resultList);
      // 契約情報検索BusinessBean.ページ内一覧表示件数：システム定義.ページ内一覧表示件数
      // ページ内一覧表示件数を取得する
      searchContractBusiness.setPageDisplayCount(StringConvertUtil
          .stringToInteger(prop.getProperty("pagedisplaycount.SKJ020101")));

      // 正常終了
      searchContractBusiness
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);

    } catch (DataAccessException e) {
      logger.error(errMsg, e);
      // 契約情報検索BusinessBean.リターンコードに（G017）を設定し処理を終了する。
      searchContractBusiness
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      searchContractBusiness.setMessage(errMsg);
    } catch (NoSuchMessageException e) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, e);
      searchContractBusiness
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      searchContractBusiness
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
    } catch (IOException e) {
      logger.error(errMsg, e);
      searchContractBusiness
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      searchContractBusiness.setMessage(fileMsg);
    } catch (SystemException e) {
      logger.error(errMsg, e);
      searchContractBusiness
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      searchContractBusiness.setMessage(errMsg);
    }

    return searchContractBusiness;
  }

  /**
   * メッセージリソースのsetter(DI)
   *
   * @param messageSource
   *          メッセージリソース
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }

  /**
   * 契約情報検索共通マッパーのsetter(DI)
   *
   * @param contractInfoSearchCommonMapper
   *          契約情報検索共通マッパー
   */
  public void setContractInfoSearchCommonMapper(
      //[kg-epj]<d-start>
      //ContractInfoSearchCommonMapper contractInfoSearchCommonMapper) {
      //[kg-epj]<d-end>
      //[kg-epj]<i-start>
      Custom_ContractInfoSearchCommonMapper contractInfoSearchCommonMapper) {
    //[kg-epj]<i-end>
    this.contractInfoSearchCommonMapper = contractInfoSearchCommonMapper;
  }

  /**
   * 日付関連共通ビジネスのsetter(DI)
   *
   * @param dateBusiness
   *          日付関連共通ビジネス
   */
  public void setDateBusiness(DateBusiness dateBusiness) {
    this.dateBusiness = dateBusiness;
  }

  /**
   * プロパティファクトリーを設定する。(DI)
   *
   * @param applicationProperties
   *          プロパティファクトリー
   */
  public void setApplicationProperties(
      PropertiesFactoryBean applicationProperties) {
    this.applicationProperties = applicationProperties;
  }
}