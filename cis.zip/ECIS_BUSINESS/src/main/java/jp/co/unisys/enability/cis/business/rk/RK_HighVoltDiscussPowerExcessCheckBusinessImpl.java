package jp.co.unisys.enability.cis.business.rk;

import java.util.Arrays;
import java.util.List;

import jp.co.unisys.enability.cis.business.rk.model.RK_ChargeCalcWarningCheckBusinessBean;
import jp.co.unisys.enability.cis.common.util.DateCalculateUtil;
import jp.co.unisys.enability.cis.common.util.constants.ECISCodeConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISKJConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;
import jp.co.unisys.enability.cis.entity.common.ContractHist;
import jp.co.unisys.enability.cis.entity.common.ContractHistExample;
import jp.co.unisys.enability.cis.entity.common.DsUsageExample;
import jp.co.unisys.enability.cis.entity.common.ReserveContractHist;
import jp.co.unisys.enability.cis.entity.common.ReserveContractHistExample;
import jp.co.unisys.enability.cis.entity.common.Rqh;
import jp.co.unisys.enability.cis.entity.common.RqhExample;
import jp.co.unisys.enability.cis.mapper.common.ContractHistMapper;
import jp.co.unisys.enability.cis.mapper.common.DsUsageMapper;
import jp.co.unisys.enability.cis.mapper.common.ReserveContractHistMapper;
import jp.co.unisys.enability.cis.mapper.common.RqhMapper;

/**
 * BRK0103-03高圧協議制の契約電力超過チェックビジネス
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.common.DateBusiness
 * @see jp.co.unisys.enability.cis.dao.rk.RK_ChargeCalcWarningCheckDao
 */
public class RK_HighVoltDiscussPowerExcessCheckBusinessImpl implements
    RK_ChargeCalcWarningCheckBusiness {
  /**
   * 実量歴管理Mapper（DI）
   */
  private RqhMapper rqhMapper;

  /**
   * 日割別使用量Mapper（DI）
   */
  private DsUsageMapper dsUsageMapper;

  /**
   * 契約履歴Mapper（DI）
   */
  private ContractHistMapper contractHistMapper;

  /**
   * 予備契約履歴Mapper（DI）
   */
  private ReserveContractHistMapper reserveContractHistMapper;

  /**
   * 高圧協議制の契約電力超過チェックビジネス
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param chargeCalcWarningCheckBean
   *          《料金計算警告チェックビジネスBean》
   * @return 警告コード
   * @see jp.co.unisys.enability.cis.dao.rk.RK_ChargeCalcWarningCheckDao
   */
  @Override
  public String check(
      RK_ChargeCalcWarningCheckBusinessBean chargeCalcWarningCheckBean) {

    // 【実量歴管理】取得
    List<Rqh> rqhList = getRqhData(chargeCalcWarningCheckBean);

    if (rqhList.size() == 0) {
      return null;
    }

    // 【実量歴管理】リストの1件目を取得
    Rqh rqh = rqhList.get(0);

    // 【契約履歴】取得
    List<ContractHist> contractHistList = getConstractHistData(
        chargeCalcWarningCheckBean, rqh);

    // 【予備契約履歴】取得
    List<ReserveContractHist> reserveContractHistList = getReserveConstractHistData(
        chargeCalcWarningCheckBean, rqh);

    // 【日割別使用量】件数取得
    int dsUsageCount = getDsUsageCount(chargeCalcWarningCheckBean);

    /**
     * チェックの判断を行い、取得した警告コードを返す。
     */
    return getErrorCode(rqh, contractHistList, reserveContractHistList, dsUsageCount);
  }

  /**
   * 警告コード取得
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 警告コードを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param Rqh
   *          実量歴管理
   * @param List<ContractHist>
   *          契約履歴リスト
   * @param List<ReserveContractHist>
   *          予備契約履歴リスト
   * @param int
   *          日割別使用量件数
   */
  private String getErrorCode(Rqh rqh, List<ContractHist> contractHistList,
      List<ReserveContractHist> reserveContractHistList, Integer dsUsageCount) {
    /**
     * チェックの判断を行う。
     */
    // 取得した契約履歴Listのデータ数が0の場合、戻り値にnull を設定する。
    if (contractHistList.size() == 0 || rqh.getPkw() == null) {
      return null;
    }

    // 取得した契約履歴Listのデータ数だけ繰り返す。
    for (ContractHist contractHist : contractHistList) {
      // 実量歴管理.最大電力＞契約履歴.契約容量の場合
      if (rqh.getPkw().compareTo(contractHist.getCca()) > 0) {
        // 日割別使用量件数が二件以上の場合
        if (dsUsageCount >= 2) {
          return ECISRKConstants.WARNING_CLASS_MASTER_HIGH_VOLT_DISCUSS_POWER_EXCESS_MULTI_PRORATED;
        } else {
          // 取得した予備契約履歴Listのデータ数だけ繰り返す。
          if (reserveContractHistList.size() != 0) {
            for (ReserveContractHist reserveContractHist : reserveContractHistList) {
              // 契約履歴一件目.契約容量≠予備契約履歴.容量の場合
              if (reserveContractHist.getCapacity() != null) {
                if (contractHistList.get(0).getCca().compareTo(
                    reserveContractHist.getCapacity()) != 0) {
                  return ECISRKConstants.WARNING_CLASS_MASTER_HIGH_VOLT_DISCUSS_POWER_EXCESS_RESERVE_CONTRACT;
                }
              }
            }
          }
        }
      }
    }
    // 取得した予備契約履歴Listのデータ数だけ繰り返す。
    if (reserveContractHistList.size() != 0) {
      for (ReserveContractHist reserveContractHist : reserveContractHistList) {
        // 実量歴管理.最大電力＞予備契約履歴.容量の場合
        if (reserveContractHist.getCapacity() != null) {
          if (rqh.getPkw().compareTo(reserveContractHist.getCapacity()) > 0) {
            return ECISRKConstants.WARNING_CLASS_MASTER_HIGH_VOLT_DISCUSS_POWER_EXCESS_RESERVE_CONTRACT;
          }
        }
      }
    }

    // 戻り値にnull を設定する。
    return null;
  }

  /**
   * 実量歴管理取得
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 実量歴管理を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param RK_ChargeCakcWarningCheckBusinessBean
   *          料金計算警告チェックビジネスBean
   */
  private List<Rqh> getRqhData(
      RK_ChargeCalcWarningCheckBusinessBean chargeCalcWarningCheckBean) {
    // 実量歴管理EntityBeanを取得する
    // 実量歴管理Example
    RqhExample rqhExample = new RqhExample();

    // 【実量歴管理】を取得する条件を設定
    rqhExample
        .createCriteria()
        // 契約ID
        .andContractIdEqualTo(chargeCalcWarningCheckBean.getContractId())
        // 対象年月
        .andCoveredPeriodEqualTo(chargeCalcWarningCheckBean.getUsePeriod());

    // 【実量歴管理】取得
    return rqhMapper.selectByExample(rqhExample);
  }

  /**
   * 契約履歴取得
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約履歴を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param RK_ChargeCakcWarningCheckBusinessBean
   *          料金計算警告チェックビジネスBean
   * @param Rqh
   *          実量歴管理
   */
  private List<ContractHist> getConstractHistData(
      RK_ChargeCalcWarningCheckBusinessBean chargeCalcWarningCheckBean,
      Rqh rqh) {
    // 契約履歴EntityBeanを取得する
    // 契約履歴Example
    ContractHistExample contractHistExample = new ContractHistExample();

    // 【契約履歴】を取得する条件を設定
    contractHistExample
        .createCriteria()
        // 契約ID
        .andContractIdEqualTo(
            chargeCalcWarningCheckBean.getContractId())
        // 契約電力決定区分コード
        .andCcDecisionCategoryCodeEqualTo(
            ECISCodeConstants.CONTRACT_CAPACITY_DECISION_CATEGORY_CODE_DISCUSSIONS)
        // 契約容量単位
        .andCcaUnitEqualTo(ECISKJConstants.UNIT_KW)
        // 適用開始日
        .andApplySdLessThanOrEqualTo(
            DateCalculateUtil.calculateDate(rqh.getCcSd(), 0, 1, -1))
        // 適用終了日
        .andApplyEdGreaterThanOrEqualTo(rqh.getCcSd())
        // 電圧区分コード
        .andVoltageCatCodeIn(
            Arrays.asList(
                ECISCodeConstants.CUSTOM_VOLTAGE_CAT_CODE_HIGH_TENSION,
                ECISCodeConstants.CUSTOM_VOLTAGE_CAT_CODE_SPECIALLY_HIGH));

    // 【契約履歴】取得
    return contractHistMapper
        .selectByExample(contractHistExample);
  }

  /**
   * 予備契約履歴取得
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 予備契約履歴を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param RK_ChargeCakcWarningCheckBusinessBean
   *          料金計算警告チェックビジネスBean
   * @param Rqh
   *          実量歴管理
   */
  private List<ReserveContractHist> getReserveConstractHistData(
      RK_ChargeCalcWarningCheckBusinessBean chargeCalcWarningCheckBean, Rqh rqh) {
    // 予備契約履歴EntityBeanを取得する
    // 予備契約履歴Example
    ReserveContractHistExample reserveContractHistExample = new ReserveContractHistExample();

    // 【予備契約履歴】を取得する条件を設定
    reserveContractHistExample
        .createCriteria()
        // 契約ID
        .andContractIdEqualTo(chargeCalcWarningCheckBean.getContractId())
        // 予備契約開始日
        .andReserveContractSdLessThanOrEqualTo(
            DateCalculateUtil.calculateDate(rqh.getCcSd(), 0, 1, -1))
        // 予備契約終了日
        .andReserveContractEdGreaterThanOrEqualTo(rqh.getCcSd());

    // 【予備契約履歴】取得
    return reserveContractHistMapper
        .selectByExample(reserveContractHistExample);
  }

  /**
   * 日割別使用量件数取得
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 日割別使用量件数を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param RK_ChargeCakcWarningCheckBusinessBean
   *          料金計算警告チェックビジネスBean
   */
  private int getDsUsageCount(
      RK_ChargeCalcWarningCheckBusinessBean chargeCalcWarningCheckBean) {
    DsUsageExample dsUsageExample = new DsUsageExample();

    // 【日割別使用量】を取得する条件を設定
    dsUsageExample.createCriteria()
        // 確定使用量ID
        .andFuIdEqualTo(chargeCalcWarningCheckBean.getFuId());

    // 【日割別使用量】件数取得
    return dsUsageMapper.countByExample(dsUsageExample);
  }

  /**
   * 実量歴管理マスタMapperのsetter（DI）
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 実量歴管理マスタMapperを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param rqhMapper
   *          実量歴管理マスタMapper
   */
  public void setRqhMapper(RqhMapper rqhMapper) {
    this.rqhMapper = rqhMapper;
  }

  /**
   * 日割別使用量マスタMapperのsetter（DI）
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 日割別使用量マスタMapperを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param dsUsageMapper
   *          日割別使用量マスタMapper
   */
  public void setDsUsageMapper(DsUsageMapper dsUsageMapper) {
    this.dsUsageMapper = dsUsageMapper;
  }

  /**
   * 契約履歴マスタMapperのsetter（DI）
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約履歴マスタMapperを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractHistMapper
   *          契約履歴マスタMapper
   */
  public void setContractHistMapper(ContractHistMapper contractHistMapper) {
    this.contractHistMapper = contractHistMapper;
  }

  /**
   * 予備契約履歴マスタMapperのsetter（DI）
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 予備契約履歴マスタMapperを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param reserveContractHistMapper
   *          予備契約履歴マスタMapper
   */
  public void setReserveContractHistMapper(
      ReserveContractHistMapper reserveContractHistMapper) {
    this.reserveContractHistMapper = reserveContractHistMapper;
  }

}
