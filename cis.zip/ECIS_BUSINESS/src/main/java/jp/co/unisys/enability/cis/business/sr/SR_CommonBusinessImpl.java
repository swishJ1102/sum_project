package jp.co.unisys.enability.cis.business.sr;

import java.sql.Timestamp;
import java.util.List;
import java.util.Locale;

import org.apache.commons.lang3.StringUtils;
import org.springframework.context.MessageSource;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.springframework.util.CollectionUtils;

import jp.co.unisys.enability.cis.business.common.TodoBusiness;
import jp.co.unisys.enability.cis.business.common.model.TodoBusinessBean;
import jp.co.unisys.enability.cis.common.Exception.SystemException;
import jp.co.unisys.enability.cis.common.util.ThreadContext;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.entity.common.BulkRegControlProc;
import jp.co.unisys.enability.cis.entity.common.BulkRegControlProcExample;
import jp.co.unisys.enability.cis.mapper.common.BulkRegControlProcMapper;

/**
 * 他シス連携共通ビジネス。
 * 
 * @author "Nihon Unisys, Ltd."
 */
public class SR_CommonBusinessImpl implements SR_CommonBusiness {

  /** メッセージソース（DI） */
  private MessageSource messageSource;

  /** トランザクションマネージャー(DI) */
  private DataSourceTransactionManager txManager;

  /** 処理別一括登録制御マッパー（DI） */
  private BulkRegControlProcMapper bulkRegControlProcMapper;

  /** Todo共通ビジネス(DI) */
  private TodoBusiness todoBusiness;

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.sr.SR_ImportConsignmentCcaCommonBusiness#
   * registTodoList(String, String, String[], String, List<String>)
   */
  @Override
  public void registTodoList(String functionId, String messageId, String[] placeholder,
      String noteHeader, List<String> noteList) {
    // メッセージ作成
    String todoMessage = messageSource.getMessage(
        messageId, placeholder, Locale.getDefault());

    TodoBusinessBean todoBean = new TodoBusinessBean();
    // サブシステムID
    todoBean.setSubsystemId(ECISConstants.SUBSYSTEM_ID_SR);
    // 機能ID
    todoBean.setFunctionId(functionId);
    // メッセージID
    todoBean.setMessageId(messageId);
    // メッセージ
    todoBean.setMessage(todoMessage);
    // 備考
    StringBuilder note = new StringBuilder();
    if (StringUtils.isNotEmpty(noteHeader)) {
      note.append(noteHeader);
    }

    if (!CollectionUtils.isEmpty(noteList)) {
      for (int i = 0; i < noteList.size(); i++) {
        //備考に、改行＋備考リスト(インデックス）の値を追加する。
        if (note.length() != 0) {
          //備考の文字列長が0でない場合、改行コードを追加
          note.append(ECISConstants.ENTER_CODE_LF);
        }
        note.append(noteList.get(i));

        //備考リストの最後、もしくは現在の備考+改行+次の備考リスト要素が4000バイトを超えていた場合、TODO登録
        if (i == noteList.size() - 1
            || ECISConstants.ORACLE_VARCHAR2_MAX_BYTES < (note.toString().getBytes().length
                + ECISConstants.ENTER_CODE_LF.getBytes().length
                + noteList.get(i + 1).getBytes().length)) {
          //備考を設定
          todoBean.setNote(note.toString());
          // 共通処理.TODO登録機能を呼び出し、TODOを登録する。
          todoBusiness.registTodo(todoBean);

          // ヘッダを再設定
          note.setLength(0);
          if (StringUtils.isNotEmpty(noteHeader)) {
            note.append(noteHeader);
          }
        }
      }
    } else {
      // 共通処理.TODO登録機能を呼び出し、TODOを登録する。
      todoBusiness.registTodo(todoBean);
    }
  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.sr.SR_ImportConsignmentCcaCommonBusiness#existLock(String)
   */
  @Override
  public boolean existLock(String executeId) {
    //処理IDを指定。
    BulkRegControlProcExample example = new BulkRegControlProcExample();
    example.createCriteria().andExecuteIdEqualTo(executeId);

    //処理別一括登録制御リスト取得
    List<BulkRegControlProc> resultList = bulkRegControlProcMapper.selectByExample(example);

    //処理IDに合致するデータが存在しない場合、システムエラーをスロー
    if (CollectionUtils.isEmpty(resultList)) {
      throw new SystemException(messageSource.getMessage("error.E1439",
          new String[] {executeId }, Locale.getDefault()));
    }

    //ロックフラグがONの場合true。
    return resultList.get(0).getLockFlg().equals(ECISConstants.FLG_ON);
  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.sr.SR_ImportConsignmentCcaCommonBusiness#lock(String)
   */
  @Override
  public int lock(String executeId) {

    int resultUpdateCnt = 0;

    // トランザクションの開始。
    DefaultTransactionDefinition def = new DefaultTransactionDefinition();
    def.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
    def.setIsolationLevel(TransactionDefinition.ISOLATION_DEFAULT);
    TransactionStatus status = this.txManager.getTransaction(def);

    try {
      //更新条件に処理IDとロックフラグ（ロック解除状態）を指定。
      BulkRegControlProcExample example = new BulkRegControlProcExample();
      example.createCriteria().andLockFlgEqualTo(ECISConstants.FLG_OFF).andExecuteIdEqualTo(executeId);

      //更新情報にロックフラグ（ロック状態）を設定。
      BulkRegControlProc record = new BulkRegControlProc();
      record.setLockFlg(ECISConstants.FLG_ON);
      // システム日時
      Timestamp timestamp = new Timestamp(System.currentTimeMillis());
      record.setUpdateTime(timestamp);
      // 更新モジュールコード
      record.setUpdateModuleCode(
          ThreadContext.getRequestThreadContext().get(ECISConstants.CLASS_NAME_KEY).toString());

      //更新
      resultUpdateCnt = bulkRegControlProcMapper.updateByExampleSelective(record, example);

      //コミット
      this.txManager.commit(status);
    } catch (Exception e) {
      // トランザクションをロールバックする。
      this.txManager.rollback(status);
      throw new SystemException(messageSource.getMessage("error.E1434",
          new String[] {executeId }, Locale.getDefault()), e);
    }
    return resultUpdateCnt;
  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.sr.SR_ImportConsignmentCcaCommonBusiness#unlock(String)
   */
  @Override
  public int unlock(String executeId) {

    int resultUpdateCnt = 0;

    // トランザクションの開始。
    DefaultTransactionDefinition def = new DefaultTransactionDefinition();
    def.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
    def.setIsolationLevel(TransactionDefinition.ISOLATION_DEFAULT);
    TransactionStatus status = this.txManager.getTransaction(def);

    try {
      //更新条件に処理IDとロックフラグ（ロック状態）を指定。
      BulkRegControlProcExample example = new BulkRegControlProcExample();
      example.createCriteria().andLockFlgEqualTo(ECISConstants.FLG_ON).andExecuteIdEqualTo(executeId);

      //更新情報にロックフラグ（ロック解除状態）を設定。
      BulkRegControlProc record = new BulkRegControlProc();
      record.setLockFlg(ECISConstants.FLG_OFF);
      // システム日時
      Timestamp timestamp = new Timestamp(System.currentTimeMillis());
      record.setUpdateTime(timestamp);
      // 更新モジュールコード
      record.setUpdateModuleCode(
          ThreadContext.getRequestThreadContext().get(ECISConstants.CLASS_NAME_KEY).toString());

      //更新
      resultUpdateCnt = bulkRegControlProcMapper.updateByExampleSelective(record, example);

      //コミット
      this.txManager.commit(status);
    } catch (Exception e) {
      // トランザクションをロールバックする。
      this.txManager.rollback(status);
      throw new SystemException(messageSource.getMessage("error.E1434",
          new String[] {executeId }, Locale.getDefault()), e);
    }
    return resultUpdateCnt;
  }

  /**
   * メッセージソースを設定する。（DI）
   *
   * @param messageSource
   *          メッセージソース
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }

  /**
   * トランザクションマネージャを設定する。(DI)
   *
   * @param txManager
   *          トランザクションマネージャ
   */
  public void setTxManager(DataSourceTransactionManager txManager) {
    this.txManager = txManager;
  }

  /**
   * 処理別一括登録制御マッパーを設定する。（DI）
   *
   * @param bulkRegControlProcMapper
   *          処理別一括登録制御マッパー
   */
  public void setBulkRegControlProcMapper(BulkRegControlProcMapper bulkRegControlProcMapper) {
    this.bulkRegControlProcMapper = bulkRegControlProcMapper;
  }

  /**
   * Todo共通ビジネスを設定する。(DI)
   *
   * @param todoBusiness
   *          Todo共通ビジネス
   */
  public void setTodoBusiness(TodoBusiness todoBusiness) {
    this.todoBusiness = todoBusiness;
  }
}
