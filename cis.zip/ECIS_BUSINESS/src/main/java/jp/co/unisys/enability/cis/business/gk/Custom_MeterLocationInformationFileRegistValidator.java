package jp.co.unisys.enability.cis.business.gk;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import jp.co.unisys.enability.cis.business.kj.model.ContractManagementInformationFileConfigCommon;
import jp.co.unisys.enability.cis.business.kj.model.Custom_ContractManagementInformationFileConfigMeterLocation;
import jp.co.unisys.enability.cis.common.util.CommonValidationUtil;
import jp.co.unisys.enability.cis.common.util.EMSMessageResource;

/**
 * メータ設置場所情報ファイル登録バリデーション
 *
 * @author "Nihon Unisys, Ltd."
 */
public class Custom_MeterLocationInformationFileRegistValidator {

  /** プロパティクラスを定義 */
  private EMSMessageResource emsMessageResource;

  /**
   * メッセージプロパティキー管理のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージプロパティキー管理を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param emsMessageResource
   *          メッセージプロパティキー管理
   */
  public void setEmsMessageResource(EMSMessageResource emsMessageResource) {
    this.emsMessageResource = emsMessageResource;
  }

  /**
   * メータ設置場所情報ファイル登録のバリデーションを実施、チェック結果のメッセージListを返却する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 1 引数のバリデーションを行う。
   * 2 チェック結果がNGの場合、戻り値のメッセージListにエラーメッセージを詰めて返却する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param dataRecordMap
   *          データレコードマップ
   * @return メッセージList
   */
  public List<String> validate(Map<Integer, String> dataRecordMap) {

    List<String> messageList = new ArrayList<String>();

    // データレコード種別：必須チェック
    String dataRecordClass = dataRecordMap
        .get(ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_INDEX);
    if (CommonValidationUtil.isNull(dataRecordClass)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_NAME }));

      // データレコード種別：正規表現チェック
    } else if (dataRecordClass != null
        && !CommonValidationUtil
            .checkByPattern(
                dataRecordClass,
                ContractManagementInformationFileConfigCommon.DATA_KIND_MASK_STRING)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_ITEM_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_NAME }));
    }

    // 需要場所住所（郵便番号）：必須チェック
    String placeAddressPostalCode = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_PLACE_ADDRESS_POSTAL_CODE_INDEX);
    if (CommonValidationUtil.isNull(placeAddressPostalCode)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_PLACE_ADDRESS_POSTAL_CODE_NAME }));

      // 需要場所住所（郵便番号）：文字種別チェック（半角数字）
    } else if (placeAddressPostalCode != null
        && !CommonValidationUtil.isNumric(placeAddressPostalCode)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_PLACE_ADDRESS_POSTAL_CODE_NAME,
                      "半角数字" }));

      // 需要場所住所（郵便番号）：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (placeAddressPostalCode != null
        && !CommonValidationUtil
            .isRangeWordByECIS(placeAddressPostalCode)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_PLACE_ADDRESS_POSTAL_CODE_NAME,
                      "半角数字（低圧CISシステム許容文字）" }));

      // 需要場所住所（郵便番号）：文字列指定長チェック
    } else if (placeAddressPostalCode != null
        && !CommonValidationUtil
            .justLength(
                placeAddressPostalCode,
                Custom_ContractManagementInformationFileConfigMeterLocation.DATA_PLACE_ADDRESS_POSTAL_CODE_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_STRINGLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_PLACE_ADDRESS_POSTAL_CODE_NAME,
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_PLACE_ADDRESS_POSTAL_CODE_LENGTH_STRING }));
    }

    // 需要場所住所（住所）：必須チェック
    String placeAddressFull = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_PLACE_ADDRESS_FULL_INDEX);
    if (CommonValidationUtil.isNull(placeAddressFull)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_PLACE_ADDRESS_FULL_NAME }));

      // 需要場所住所（住所）：文字種別チェック（低圧CISシステム許容文字）
    } else if (placeAddressFull != null
        && !CommonValidationUtil.isRangeWordByECIS(placeAddressFull)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_PLACE_ADDRESS_FULL_NAME,
                      "低圧CISシステム許容文字" }));

      // 需要場所住所（住所）：文字列最大長チェック
    } else if (placeAddressFull != null
        && !CommonValidationUtil
            .maxLength(
                placeAddressFull,
                Custom_ContractManagementInformationFileConfigMeterLocation.DATA_PLACE_ADDRESS_FULL_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_PLACE_ADDRESS_FULL_NAME,
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_PLACE_ADDRESS_FULL_LENGTH_STRING }));
    }

    // 需要場所住所（建物・部屋名）：文字種別チェック（全角）
    String placeAddressBuilding = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_PLACE_ADDRESS_BUILDING_INDEX);
    if (placeAddressBuilding != null
        && !CommonValidationUtil.isZenkakuType(placeAddressBuilding)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_PLACE_ADDRESS_BUILDING_NAME }));

      // 需要場所住所（建物・部屋名）：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (placeAddressBuilding != null
        && !CommonValidationUtil
            .isRangeWordByECIS(placeAddressBuilding)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_PLACE_ADDRESS_BUILDING_NAME,
                      "全角（低圧CISシステム許容文字）" }));

      // 需要場所住所（建物・部屋名）：文字列最大長チェック
    } else if (placeAddressBuilding != null
        && !CommonValidationUtil
            .maxLength(
                placeAddressBuilding,
                Custom_ContractManagementInformationFileConfigMeterLocation.DATA_PLACE_ADDRESS_BUILDING_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_PLACE_ADDRESS_BUILDING_NAME,
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_PLACE_ADDRESS_BUILDING_LENGTH_STRING }));
    }

    // 地点特定番号：必須チェック
    String spotNo = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_SPOT_NO_INDEX);
    if (CommonValidationUtil.isNull(spotNo)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_SPOT_NO_NAME }));

      // 地点特定番号：文字種別チェック（半角英数字）
    } else if (spotNo != null
        && !CommonValidationUtil.isAlphabetNumric(spotNo)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_ALPHANUMERIC_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_SPOT_NO_NAME }));

      // 地点特定番号：文字種別チェック（半角英数字　低圧CISシステム許容文字）
    } else if (spotNo != null
        && !CommonValidationUtil.isRangeWordByECIS(spotNo)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_SPOT_NO_NAME,
                      "半角英数字（低圧CISシステム許容文字）" }));

      // 地点特定番号：文字列最大長チェック
    } else if (spotNo != null
        && !CommonValidationUtil
            .maxLength(
                spotNo,
                Custom_ContractManagementInformationFileConfigMeterLocation.DATA_SPOT_NO_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_SPOT_NO_NAME,
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_SPOT_NO_LENGTH_STRING }));
    }

    // 需要家識別番号：文字種別チェック（半角英数字）
    String contractorIdentificationNo = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_CONTRACTOR_IDENTIFICATION_NO_INDEX);
    if (contractorIdentificationNo != null
        && !CommonValidationUtil
            .isAlphabetNumric(contractorIdentificationNo)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_ALPHANUMERIC_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_CONTRACTOR_IDENTIFICATION_NO_NAME }));

      // 需要家識別番号：文字種別チェック（半角英数字　低圧CISシステム許容文字）
    } else if (contractorIdentificationNo != null
        && !CommonValidationUtil
            .isRangeWordByECIS(contractorIdentificationNo)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_CONTRACTOR_IDENTIFICATION_NO_NAME,
                      "半角英数字（低圧CISシステム許容文字）" }));

      // 需要家識別番号：文字列最大長チェック
    } else if (contractorIdentificationNo != null
        && !CommonValidationUtil
            .maxLength(
                contractorIdentificationNo,
                Custom_ContractManagementInformationFileConfigMeterLocation.DATA_CONTRACTOR_IDENTIFICATION_NO_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_CONTRACTOR_IDENTIFICATION_NO_NAME,
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_CONTRACTOR_IDENTIFICATION_NO_LENGTH_STRING }));
    }

    // エリアコード：必須チェック
    String areaCode = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_AREA_CODE_INDEX);
    if (CommonValidationUtil.isNull(areaCode)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_AREA_CODE_NAME }));
    }

    // 基本検針日：必須チェック
    String basicMeterReadingDate = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_BASIC_METER_READING_DATE_INDEX);
    if (CommonValidationUtil.isNull(basicMeterReadingDate)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_BASIC_METER_READING_DATE_NAME }));

      // 基本検針日：文字種別チェック（半角数字）
    } else if (basicMeterReadingDate != null
        && !CommonValidationUtil.isNumric(basicMeterReadingDate)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_BASIC_METER_READING_DATE_NAME,
                      "半角数字" }));

      // 基本検針日：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (basicMeterReadingDate != null
        && !CommonValidationUtil
            .isRangeWordByECIS(basicMeterReadingDate)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_BASIC_METER_READING_DATE_NAME,
                      "半角数字（低圧CISシステム許容文字）" }));
      // 基本検針日：数値範囲チェック
    } else if (basicMeterReadingDate != null
        && !CommonValidationUtil
            .checkRange(
                basicMeterReadingDate,
                Custom_ContractManagementInformationFileConfigMeterLocation.DATA_BASIC_METER_READING_DATE_RANGE_MIN,
                Custom_ContractManagementInformationFileConfigMeterLocation.DATA_BASIC_METER_READING_DATE_RANGE_MAX)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_RANGE_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_BASIC_METER_READING_DATE_NAME,
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_BASIC_METER_READING_DATE_MESSAGE }));
    }

    // 次回検針予定日：必須チェック
    String nextMeterReadingScheduledDate = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_NEXT_METER_READING_SCHEDULED_DATE_INDEX);
    if (CommonValidationUtil.isNull(nextMeterReadingScheduledDate)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_NEXT_METER_READING_SCHEDULED_DATE_NAME }));

      // 次回検針予定日：日付フォーマットチェック
    } else if (nextMeterReadingScheduledDate != null
        && !CommonValidationUtil
            .checkDateFormat(
                nextMeterReadingScheduledDate,
                Custom_ContractManagementInformationFileConfigMeterLocation.DATA_NEXT_METER_READING_SCHEDULED_DATE_FORMAT)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_NEXT_METER_READING_SCHEDULED_DATE_NAME,
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_NEXT_METER_READING_SCHEDULED_DATE_MESSAGE }));
    }

    // 送受電区分コード：必須チェック
    String transmissionCategoryCode = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_TRANSMISSION_CATEGORY_CODE_INDEX);
    if (CommonValidationUtil.isNull(transmissionCategoryCode)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_TRANSMISSION_CATEGORY_CODE_NAME }));
    }

    // 自家発連携有無コード：必須チェック
    String generatorLinkageCheckCode = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_GENERATOR_LINKAGE_CHECK_CODE_INDEX);
    if (CommonValidationUtil.isNull(generatorLinkageCheckCode)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_GENERATOR_LINKAGE_CHECK_CODE_NAME }));
    }

    // 供給方式コード：必須チェック
    String supplyMethodCode = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_SUPPLY_METHOD_CODE_INDEX);
    if (CommonValidationUtil.isNull(supplyMethodCode)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_SUPPLY_METHOD_CODE_NAME }));
    }

    // 計器識別番号1：必須チェック
    String meterIdentificationNo1 = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO1_INDEX);
    if (CommonValidationUtil.isNull(meterIdentificationNo1)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO1_NAME }));

      // 計器識別番号1：文字種別チェック（半角英数字）
    } else if (meterIdentificationNo1 != null
        && !CommonValidationUtil
            .isAlphabetNumric(meterIdentificationNo1)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_ALPHANUMERIC_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO1_NAME }));

      // 計器識別番号1：文字種別チェック（半角英数字　低圧CISシステム許容文字）
    } else if (meterIdentificationNo1 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(meterIdentificationNo1)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO1_NAME,
                      "半角英数字（低圧CISシステム許容文字）" }));

      // 計器識別番号1：文字列最大長チェック
    } else if (meterIdentificationNo1 != null
        && !CommonValidationUtil
            .maxLength(
                meterIdentificationNo1,
                Custom_ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO1_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO1_NAME,
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO1_LENGTH_STRING }));
    }

    // 計器識別番号2：文字種別チェック（半角英数字）
    String meterIdentificationNo2 = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO2_INDEX);
    if (meterIdentificationNo2 != null
        && !CommonValidationUtil
            .isAlphabetNumric(meterIdentificationNo2)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_ALPHANUMERIC_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO2_NAME }));

      // 計器識別番号2：文字種別チェック（半角英数字　低圧CISシステム許容文字）
    } else if (meterIdentificationNo2 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(meterIdentificationNo2)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO2_NAME,
                      "半角英数字（低圧CISシステム許容文字）" }));

      // 計器識別番号2：文字列最大長チェック
    } else if (meterIdentificationNo2 != null
        && !CommonValidationUtil
            .maxLength(
                meterIdentificationNo2,
                Custom_ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO2_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO2_NAME,
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO2_LENGTH_STRING }));
    }

    // 計器識別番号3：文字種別チェック（半角英数字）
    String meterIdentificationNo3 = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO3_INDEX);
    if (meterIdentificationNo3 != null
        && !CommonValidationUtil
            .isAlphabetNumric(meterIdentificationNo3)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_ALPHANUMERIC_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO3_NAME }));

      // 計器識別番号3：文字種別チェック（半角英数字　低圧CISシステム許容文字）
    } else if (meterIdentificationNo3 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(meterIdentificationNo3)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO3_NAME,
                      "半角英数字（低圧CISシステム許容文字）" }));

      // 計器識別番号3：文字列最大長チェック
    } else if (meterIdentificationNo3 != null
        && !CommonValidationUtil
            .maxLength(
                meterIdentificationNo3,
                Custom_ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO3_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO3_NAME,
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO3_LENGTH_STRING }));
    }

    // 計器識別番号4：文字種別チェック（半角英数字）
    String meterIdentificationNo4 = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO4_INDEX);
    if (meterIdentificationNo4 != null
        && !CommonValidationUtil
            .isAlphabetNumric(meterIdentificationNo4)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_ALPHANUMERIC_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO4_NAME }));

      // 計器識別番号4：文字種別チェック（半角英数字　低圧CISシステム許容文字）
    } else if (meterIdentificationNo4 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(meterIdentificationNo4)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO4_NAME,
                      "半角英数字（低圧CISシステム許容文字）" }));

      // 計器識別番号4：文字列最大長チェック
    } else if (meterIdentificationNo4 != null
        && !CommonValidationUtil
            .maxLength(
                meterIdentificationNo4,
                Custom_ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO4_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO4_NAME,
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO4_LENGTH_STRING }));
    }

    // 計器識別番号5：文字種別チェック（半角英数字）
    String meterIdentificationNo5 = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO5_INDEX);
    if (meterIdentificationNo5 != null
        && !CommonValidationUtil
            .isAlphabetNumric(meterIdentificationNo5)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_ALPHANUMERIC_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO5_NAME }));

      // 計器識別番号5：文字種別チェック（半角英数字　低圧CISシステム許容文字）
    } else if (meterIdentificationNo5 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(meterIdentificationNo5)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO5_NAME,
                      "半角英数字（低圧CISシステム許容文字）" }));

      // 計器識別番号5：文字列最大長チェック
    } else if (meterIdentificationNo5 != null
        && !CommonValidationUtil
            .maxLength(
                meterIdentificationNo5,
                Custom_ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO5_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO5_NAME,
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO5_LENGTH_STRING }));
    }

    // 30分値収集可否・自動検針可否コード1：必須チェック
    String automaticMeterReadingCkeckCode1 = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_AUTOMATIC_METER_READING_CHECK_CODE1_INDEX);
    if (CommonValidationUtil.isNull(automaticMeterReadingCkeckCode1)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_AUTOMATIC_METER_READING_CHECK_CODE1_NAME }));
    }

    // 検針日区分コード：必須チェック
    String meterReadingDateCategoryCode = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigMeterLocation.METER_READING_DATE_CATEGORY_CODE_INDEX);
    if (CommonValidationUtil.isNull(meterReadingDateCategoryCode)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.METER_READING_DATE_CATEGORY_CODE_NAME }));
    }

    // フリー項目1：必須チェック
    String free01 = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_01_INDEX);
    if (CommonValidationUtil.isNull(free01)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_01_NAME }));

      // フリー項目1：文字種別チェック（低圧CISシステム許容文字）
    } else if (free01 != null
        && !CommonValidationUtil.isRangeWordByECIS(free01)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_01_NAME,
                      "低圧CISシステム許容文字" }));

      // フリー項目1：文字列最大長チェック
    } else if (free01 != null
        && !CommonValidationUtil
            .maxLength(
                free01,
                Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_01_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_01_NAME,
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_01_LENGTH_STRING }));
    }

    String free02 = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_02_INDEX);
    // フリー項目2：文字種別チェック（低圧CISシステム許容文字）
    if (free02 != null
        && !CommonValidationUtil.isRangeWordByECIS(free02)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_02_NAME,
                      "低圧CISシステム許容文字" }));

      // フリー項目2：文字列最大長チェック
    } else if (free02 != null
        && !CommonValidationUtil
            .maxLength(
                free02,
                Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_02_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_02_NAME,
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_02_LENGTH_STRING }));

    }

    String free03 = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_03_INDEX);
    // フリー項目3：文字種別チェック（低圧CISシステム許容文字）
    if (free03 != null
        && !CommonValidationUtil.isRangeWordByECIS(free03)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_03_NAME,
                      "低圧CISシステム許容文字" }));

      // フリー項目3：文字列最大長チェック
    } else if (free03 != null
        && !CommonValidationUtil
            .maxLength(
                free03,
                Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_03_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_03_NAME,
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_03_LENGTH_STRING }));

    }

    String free04 = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_04_INDEX);
    // フリー項目4：文字種別チェック（低圧CISシステム許容文字）
    if (free04 != null
        && !CommonValidationUtil.isRangeWordByECIS(free04)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_04_NAME,
                      "低圧CISシステム許容文字" }));

      // フリー項目4：文字列最大長チェック
    } else if (free04 != null
        && !CommonValidationUtil
            .maxLength(
                free04,
                Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_04_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_04_NAME,
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_04_LENGTH_STRING }));

    }

    String free05 = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_05_INDEX);
    // フリー項目5：文字種別チェック（低圧CISシステム許容文字）
    if (free05 != null
        && !CommonValidationUtil.isRangeWordByECIS(free05)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_05_NAME,
                      "低圧CISシステム許容文字" }));

      // フリー項目5：文字列最大長チェック
    } else if (free05 != null
        && !CommonValidationUtil
            .maxLength(
                free05,
                Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_05_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_05_NAME,
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_05_LENGTH_STRING }));

    }

    String free06 = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_06_INDEX);
    // フリー項目6：文字種別チェック（低圧CISシステム許容文字）
    if (free06 != null
        && !CommonValidationUtil.isRangeWordByECIS(free06)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_06_NAME,
                      "低圧CISシステム許容文字" }));

      // フリー項目6：文字列最大長チェック
    } else if (free06 != null
        && !CommonValidationUtil
            .maxLength(
                free06,
                Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_06_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_06_NAME,
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_06_LENGTH_STRING }));

    }

    String free07 = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_07_INDEX);
    // フリー項目7：文字種別チェック（低圧CISシステム許容文字）
    if (free07 != null
        && !CommonValidationUtil.isRangeWordByECIS(free07)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_07_NAME,
                      "低圧CISシステム許容文字" }));

      // フリー項目7：文字列最大長チェック
    } else if (free07 != null
        && !CommonValidationUtil
            .maxLength(
                free07,
                Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_07_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_07_NAME,
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_07_LENGTH_STRING }));

    }

    String free08 = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_08_INDEX);
    // フリー項目8：文字種別チェック（低圧CISシステム許容文字）
    if (free08 != null
        && !CommonValidationUtil.isRangeWordByECIS(free08)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_08_NAME,
                      "低圧CISシステム許容文字" }));

      // フリー項目8：文字列最大長チェック
    } else if (free08 != null
        && !CommonValidationUtil
            .maxLength(
                free08,
                Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_08_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_08_NAME,
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_08_LENGTH_STRING }));

    }

    String free09 = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_09_INDEX);
    // フリー項目9：文字種別チェック（低圧CISシステム許容文字）
    if (free09 != null
        && !CommonValidationUtil.isRangeWordByECIS(free09)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_09_NAME,
                      "低圧CISシステム許容文字" }));

      // フリー項目9：文字列最大長チェック
    } else if (free09 != null
        && !CommonValidationUtil
            .maxLength(
                free09,
                Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_09_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_09_NAME,
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_09_LENGTH_STRING }));

    }

    String free10 = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_10_INDEX);
    // フリー項目10：文字種別チェック（低圧CISシステム許容文字）
    if (free10 != null
        && !CommonValidationUtil.isRangeWordByECIS(free10)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_10_NAME,
                      "低圧CISシステム許容文字" }));

      // フリー項目10：文字列最大長チェック
    } else if (free10 != null
        && !CommonValidationUtil
            .maxLength(
                free10,
                Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_10_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_10_NAME,
                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_10_LENGTH_STRING }));

    }

    return messageList;
  }
}
