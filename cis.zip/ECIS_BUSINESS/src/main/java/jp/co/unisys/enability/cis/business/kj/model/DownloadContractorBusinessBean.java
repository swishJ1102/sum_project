package jp.co.unisys.enability.cis.business.kj.model;

import java.util.List;

import jp.co.unisys.enability.cis.dao.kj.ContractManagementInformationDownloadSearchInformationBean;
import jp.co.unisys.enability.cis.entity.kj.KJ_ContractorInformationFileEntityBean;

/**
 * 契約者情報ダウンロードBusinessBean
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * 契約者情報ビジネス
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class DownloadContractorBusinessBean {

  /**
   * ダウンロードファイル名を保有する。
   */
  private String downloadFileName;

  /**
   * 契約管理情報ダウンロード検索条件を保有する。
   */
  private ContractManagementInformationDownloadSearchInformationBean contractManagementInformationDownloadSearchInformationBean;

  /**
   * 契約者情報ファイルリストを保有する。
   */
  private List<KJ_ContractorInformationFileEntityBean> contractorInformationFileEntityBeanList;

  /**
   * ダウンロードファイル名のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * ダウンロードファイル名を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return ダウンロードファイル名
   */
  public String getDownloadFileName() {
    return downloadFileName;
  }

  /**
   * ダウンロードファイル名のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * ダウンロードファイル名を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param downloadFileName
   *          ダウンロードファイル名
   */
  public void setDownloadFileName(String downloadFileName) {
    this.downloadFileName = downloadFileName;
  }

  /**
   * 契約管理情報ダウンロード検索条件のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約管理情報ダウンロード検索条件を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約管理情報ダウンロード検索条件
   */
  public ContractManagementInformationDownloadSearchInformationBean getContractManagementInformationDownloadSearchInformationBean() {
    return contractManagementInformationDownloadSearchInformationBean;
  }

  /**
   * 契約管理情報ダウンロード検索条件のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約管理情報ダウンロード検索条件を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractManagementInformationDownloadSearchInformationBean
   *          契約管理情報ダウンロード検索条件
   */
  public void setContractManagementInformationDownloadSearchInformationBean(
      ContractManagementInformationDownloadSearchInformationBean contractManagementInformationDownloadSearchInformationBean) {
    this.contractManagementInformationDownloadSearchInformationBean = contractManagementInformationDownloadSearchInformationBean;
  }

  /**
   * 契約者情報ファイルリストのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者情報ファイルリストを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者情報ファイルリスト
   */
  public List<KJ_ContractorInformationFileEntityBean> getContractorInformationFileEntityBeanList() {
    return contractorInformationFileEntityBeanList;
  }

  /**
   * 契約者情報ファイルリストのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者情報ファイルリストを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorInformationFileEntityBeanList
   *          契約者情報ファイルリスト
   */
  public void setContractorInformationFileEntityBeanList(
      List<KJ_ContractorInformationFileEntityBean> contractorInformationFileEntityBeanList) {
    this.contractorInformationFileEntityBeanList = contractorInformationFileEntityBeanList;
  }

}
