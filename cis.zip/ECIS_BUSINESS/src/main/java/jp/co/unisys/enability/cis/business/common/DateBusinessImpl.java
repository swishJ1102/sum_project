package jp.co.unisys.enability.cis.business.common;

import java.text.ParseException;
import java.util.Date;
import java.util.Locale;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.springframework.context.MessageSource;

import jp.co.unisys.enability.cis.business.gk.CalendarBusiness;
import jp.co.unisys.enability.cis.business.gk.model.CalendarBusinessBean;
import jp.co.unisys.enability.cis.common.Exception.SystemException;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISReturnCodeConstants;
import jp.co.unisys.enability.cis.entity.common.ExecuteBaseDateM;
import jp.co.unisys.enability.cis.entity.common.WorkDaysM;
import jp.co.unisys.enability.cis.mapper.common.ExecuteBaseDateMMapper;
import jp.co.unisys.enability.cis.mapper.common.WorkDaysMMapper;

/**
 * 日付関連共通ビジネスクラス。
 *
 * <pre>
 * <p><b>【仕様詳細】<b><p>
 * 共通的な日付関連機能を扱う。
 * ・処理基準日取得
 * ・業務日付計算
 * ・月初営業日取得
 * ・月末営業日取得
 * </pre>
 *
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.gk.CalendarBusiness
 * @see jp.co.unisys.enability.cis.mapper.common.WorkDaysMMapper
 * @see jp.co.unisys.enability.cis.mapper.common.ExecuteBaseDateMMapper
 */
public class DateBusinessImpl implements DateBusiness {

  /** カレンダー関連機能共通処理 */
  private CalendarBusiness calendarBusiness;

  /** 業務日数マスターマッパー */
  private WorkDaysMMapper workDaysMMapper;

  /** 処理基準日マスタマッパー */
  private ExecuteBaseDateMMapper executeBaseDateMMapper;

  /** メッセージ */
  private MessageSource messageResource;

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.common.DateBusiness#
   * isWorkDayforMonthBegin(java.lang.String,
   * jp.co.unisys.enability.cis.business.common.model.HolidayFlagBean)
   */
  @Override
  public Date getWorkDayforMonthBegin(Date baseDate) {
    // 月初を設定
    Date fstDate = DateUtils.setDays(baseDate, 1);

    // カレンダー関連機能を呼び出して月初営業日を取得
    CalendarBusinessBean bean = new CalendarBusinessBean();
    bean.setBaseDate(fstDate);
    bean.setTermNumberOfDays(0);
    bean.setOperatorHolidayCategory(ECISConstants.OPERATOR_HOLIDAY);
    bean = calendarBusiness.calculateSalesDate(bean);

    // リターンコードが正常終了以外の場合は、システムエラーとする
    if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(bean
        .getReturnCode())) {
      throw new SystemException(messageResource.getMessage("error.E0001",
          new String[] {"営業日取得" }, Locale.getDefault()));
    }

    Date result = null;
    try {
      result = DateUtils.parseDate(bean.getProcessingResult(),
          ECISConstants.FORMAT_DATE_yyyyMMdd);
    } catch (ParseException e) {
      throw new SystemException(messageResource.getMessage("error.E0001",
          new String[] {"日付変換" }, Locale.getDefault()), e);
    }
    return result;
  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.common.DateBusiness#getWorkDayforMonthEnd
   * (java.util.Date)
   */
  @Override
  public Date getWorkDayforMonthEnd(Date baseDate) {

    // 日付を翌月1日に設定
    Date endDate = DateUtils.setDays(baseDate, 1);
    endDate = DateUtils.addMonths(endDate, 1);

    // カレンダー関連機能を呼び出して月末営業日を取得
    CalendarBusinessBean bean = new CalendarBusinessBean();
    bean.setBaseDate(endDate);
    bean.setTermNumberOfDays(-1);
    bean.setOperatorHolidayCategory(ECISConstants.OPERATOR_HOLIDAY);
    bean = calendarBusiness.calculateSalesDate(bean);

    // リターンコードが正常終了以外の場合は、システムエラーとする
    if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(bean
        .getReturnCode())) {
      throw new SystemException(messageResource.getMessage("error.E0001",
          new String[] {"営業日取得" }, Locale.getDefault()));
    }

    Date result = null;
    try {
      result = DateUtils.parseDate(bean.getProcessingResult(),
          ECISConstants.FORMAT_DATE_yyyyMMdd);
    } catch (ParseException e) {
      throw new SystemException(messageResource.getMessage("error.E0001",
          new String[] {"日付変換" }, Locale.getDefault()), e);
    }
    return result;
  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.common.DateBusiness#getProcessBaseDate
   * (java.lang.String)
   */
  @Override
  public Date getProcessBaseDate(String code) {
    ExecuteBaseDateM baseDate = executeBaseDateMMapper
        .selectByPrimaryKey(code);
    if (baseDate == null) {
      throw new SystemException(messageResource.getMessage("error.E1352",
          new String[] {"処理基準日コード", "処理基準日マスタ", code },
          Locale.getDefault()));
    }
    Date date = baseDate.getExecuteBaseDate();

    return date;

  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.common.DateBusiness#calcWorkDate(
   * java.util.Date, java.lang.String)
   */
  @Override
  public Date calcWorkDate(Date baseDate, String workDaysCode) {

    // 業務日数コードをキーにして、業務日数マスタ情報を取得
    WorkDaysM entity = workDaysMMapper.selectByPrimaryKey(workDaysCode);

    if (entity == null) {
      throw new SystemException(messageResource.getMessage("error.E1352",
          new String[] {"業務日数コード", "業務日数マスタ", workDaysCode },
          Locale.getDefault()));

    }

    Date resultDate = null;
    CalendarBusinessBean calcBean = new CalendarBusinessBean();
    CalendarBusinessBean resultBean = new CalendarBusinessBean();

    try {
      // 日数区分により処理を分岐
      switch (entity.getDaysCat()) {
        // 暦日
        case ECISConstants.WORK_DAYS_CATEGORY_CALENDAR:
          resultBean.setBaseDate(DateUtils.addDays(baseDate,
              entity.getDays()));
          resultDate = resultBean.getBaseDate();
          break;
        // エネット営業日、金融機関営業日
        case ECISConstants.WORK_DAYS_CATEGORY_ENNET:
          // 事業者休日区分に事業者休日を設定し、営業日付計算を呼び出す
          calcBean.setBaseDate(baseDate);
          calcBean.setOperatorHolidayCategory(ECISConstants.OPERATOR_HOLIDAY);
          calcBean.setTermNumberOfDays(entity.getDays());
          calcBean = calendarBusiness.calculateSalesDate(calcBean);
          resultBean.setBaseDate(DateUtils.parseDate(
              calcBean.getProcessingResult(),
              ECISConstants.FORMAT_DATE_yyyyMMdd));
          resultDate = resultBean.getBaseDate();
          break;
        case ECISConstants.WORK_DAYS_CATEGORY_FINANCIAL:
          // 事業者休日区分に金融機関休日を設定し、営業日付計算を呼び出す
          calcBean.setBaseDate(baseDate);
          calcBean.setOperatorHolidayCategory(ECISConstants.BANK_HOLIDAY);
          calcBean.setTermNumberOfDays(entity.getDays());
          calcBean = calendarBusiness.calculateSalesDate(calcBean);
          resultBean.setBaseDate(DateUtils.parseDate(
              calcBean.getProcessingResult(),
              ECISConstants.FORMAT_DATE_yyyyMMdd));
          resultDate = resultBean.getBaseDate();
          break;
        // 上記以外のコード値はエラーとする
        default:
          throw new SystemException(
              messageResource.getMessage("error.E1353", new String[] {
                  "業務日数マスタ", "日数区分", entity.getDaysCat() },
                  Locale.getDefault()));
      }

      // 補正のため、期間指定を0日に指定
      resultBean.setTermNumberOfDays(0);

      // 算出日区分により補正を行う
      switch (entity.getCalculationDateCat()) {
        // 暦日
        case ECISConstants.WORK_DAYS_CATEGORY_CALENDAR:
          // 何もしない
          break;
        // エネット営業日
        case ECISConstants.WORK_DAYS_CATEGORY_ENNET:
          // 日数区分がエネット営業日でない場合のみ、補正を行う
          if (!ECISConstants.WORK_DAYS_CATEGORY_ENNET.equals(entity
              .getDaysCat())) {
            // 事業者休日区分に事業者休日を設定し、営業日付計算を呼び出す
            resultBean
                .setOperatorHolidayCategory(ECISConstants.OPERATOR_HOLIDAY);
            resultBean = calendarBusiness
                .calculateSalesDate(resultBean);

            // リターンコードが正常終了以外の場合は、システムエラーとする
            if (!ECISReturnCodeConstants.RETURN_CODE_0000
                .equals(resultBean.getReturnCode())) {
              throw new SystemException(messageResource.getMessage(
                  "error.E0001", new String[] {"営業日取得" },
                  Locale.getDefault()));
            }

            resultDate = DateUtils.parseDate(
                resultBean.getProcessingResult(),
                ECISConstants.FORMAT_DATE_yyyyMMdd);
          }
          break;
        // 金融機関営業日
        case ECISConstants.WORK_DAYS_CATEGORY_FINANCIAL:
          // 日数区分が金融機関営業日でない場合のみ、補正を行う
          if (!ECISConstants.WORK_DAYS_CATEGORY_FINANCIAL.equals(entity
              .getDaysCat())) {
            // 事業者休日区分に金融機関休日を設定し、営業日付計算を呼び出す
            resultBean
                .setOperatorHolidayCategory(ECISConstants.BANK_HOLIDAY);
            resultBean = calendarBusiness
                .calculateSalesDate(resultBean);

            // リターンコードが正常終了以外の場合は、システムエラーとする
            if (!ECISReturnCodeConstants.RETURN_CODE_0000
                .equals(resultBean.getReturnCode())) {
              throw new SystemException(messageResource.getMessage(
                  "error.E0001", new String[] {"営業日取得" },
                  Locale.getDefault()));
            }

            resultDate = DateUtils.parseDate(
                resultBean.getProcessingResult(),
                ECISConstants.FORMAT_DATE_yyyyMMdd);
          }
          break;
        // 上記以外のコード値はエラーとする。
        default:
          throw new SystemException(messageResource.getMessage(
              "error.E1353", new String[] {"業務日数マスタ", "算出日区分",
                  entity.getCalculationDateCat() },
              Locale.getDefault()));
      }
    } catch (ParseException e) {
      throw new SystemException(messageResource.getMessage("error.E0001",
          new String[] {"日付変換" }, Locale.getDefault()), e);
    }

    return resultDate;
  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.common.DateBusiness#getBatchEffectiveDate
   * (java.util.Date)
   */
  public Date getBatchEffectiveDate(String processBaseDate) {
    // バッチ実行日を宣言
    Date effectiveDate = null;
    if (StringUtils.isNotEmpty(processBaseDate)) {
      try {
        effectiveDate = DateUtils.parseDateStrictly(processBaseDate,
            ECISConstants.FORMAT_DATE_yyyyMMdd);
      } catch (ParseException e) {
        throw new SystemException(messageResource.getMessage(
            "error.E0001", new String[] {"日付変換" },
            Locale.getDefault()), e);
      }
    } else {
      // 引数 1:バッチ処理基準日 で処理基準日取得を呼び出す
      effectiveDate = getProcessBaseDate(ECISConstants.EXEC_BASE_DATE_BATCH);
    }

    return effectiveDate;
  }

  public void setCalendarBusiness(CalendarBusiness calendarBusiness) {
    this.calendarBusiness = calendarBusiness;
  }

  public void setWorkDaysMMapper(WorkDaysMMapper workDaysMMapper) {
    this.workDaysMMapper = workDaysMMapper;
  }

  public void setExecuteBaseDateMMapper(
      ExecuteBaseDateMMapper executeBaseDateMMapper) {
    this.executeBaseDateMMapper = executeBaseDateMMapper;
  }

  public void setEmsMessageResource(MessageSource messageResource) {
    this.messageResource = messageResource;
  }

}
