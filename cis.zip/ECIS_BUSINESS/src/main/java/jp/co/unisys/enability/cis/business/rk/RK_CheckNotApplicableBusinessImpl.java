package jp.co.unisys.enability.cis.business.rk;

import java.util.Locale;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.MessageSource;

import jp.co.unisys.enability.cis.business.rk.model.RK_UsageLinkageCheckCheckDataBusinessBean;
import jp.co.unisys.enability.cis.business.rk.model.RK_UsageLinkageCheckTermDecisionBusinessBean;
import jp.co.unisys.enability.cis.common.util.StringConvertUtil;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;

/**
 * 取り込み対象外チェックビジネスクラス。
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.rk.RK_UsageLinkageCheckBusiness
 */
public class RK_CheckNotApplicableBusinessImpl implements
    RK_CheckFixUsageBusiness {

  /** 料金計算チェックビジネス(DI) */
  private RK_UsageLinkageCheckBusiness rkUsageLinkageCheckBusiness;

  /** メッセージプロパティ */
  private MessageSource messageSource;

  /** ロガー */
  private static final Logger LOGGER = LogManager.getLogger();

  /**
   * 取り込み対象外チェック。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 対象の確定使用量メッセージが取り込みの対象外か判定を行う。
   * 取り込みの対象外となるのは、以下条件のいずれかに該当する場合。
   * １．【月次実績】.提供可否コードが"否"
   * ２．同日に訂正データが連携されている
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param checkDataBusinessBean
   *          チェック対象ビジネスBean
   * @param termDecisionBusinessBean
   *          期間判定情報ビジネスBean
   * @return true:処理継続、false:処理終了
   */
  @Override
  public boolean check(
      RK_UsageLinkageCheckCheckDataBusinessBean checkDataBusinessBean,
      RK_UsageLinkageCheckTermDecisionBusinessBean termDecisionBusinessBean) {

    // 継続フラグ
    boolean continuation = true;

    // 提供可否コードが"否"か、同日に訂正データが届いている場合は、
    // 【月次実績】.月次実績エラー区分コードを"無視"で更新する
    if (ECISRKConstants.PROVIDE_CHECK_MASTER_NOT_APPLICABLE.equals(checkDataBusinessBean.getProvideCheckCode())
        || Integer.parseInt(checkDataBusinessBean.getUpdateNo()) < Integer
            .parseInt(checkDataBusinessBean.getMaxUpdateNo())) {

      // 【月次実績】を更新
      rkUsageLinkageCheckBusiness
          .updateMonthlyUsageResultIgnore(checkDataBusinessBean);

      // ログのパラメーター
      String[] parameters = new String[] {
          // 処理日
          StringConvertUtil.convertDateToString(checkDataBusinessBean.getExecuteDate(),
              ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
          // 地点特定番号
          checkDataBusinessBean.getSpotNo(),
          // 確定使用量ファイル名
          checkDataBusinessBean.getFixUsageFileName(),
          // エリアコード
          checkDataBusinessBean.getAreaCode(),
          // 提供可否コード
          checkDataBusinessBean.getProvideCheckCode(),
          // 更新番号
          checkDataBusinessBean.getUpdateNo(),
          // 最大更新番号
          checkDataBusinessBean.getMaxUpdateNo()
      };

      // 取り込み対象外となった確定使用量メッセージの情報を出力
      LOGGER.info(messageSource.getMessage("info.I1025", parameters, Locale.getDefault()));

      // 処理を継続しない
      continuation = false;
    }

    return continuation;
  }

  /**
   * 料金計算チェックビジネスを設定します。(DI)
   *
   * @param rkUsageLinkageCheckBusiness
   *          料金計算チェックビジネス
   */
  public void setRkUsageLinkageCheckBusiness(
      RK_UsageLinkageCheckBusiness rkUsageLinkageCheckBusiness) {
    this.rkUsageLinkageCheckBusiness = rkUsageLinkageCheckBusiness;
  }

  /**
   * メッセージプロパティを設定します。(DI)
   *
   * @param messageSource
   *          メッセージプロパティ
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }

}
