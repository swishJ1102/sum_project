package jp.co.unisys.enability.cis.business.kj.model;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * 契約情報登録・更新（一括登録）BusinessBean
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * 契約情報ビジネス
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class ContractManagementInformationFileConfigContract {

  /** ファイル名接頭辞 */
  public static final String FILE_NAME_PREFIX = "contract_";

  // ヘッダレコード定義
  /** ヘッダレコード：ファイル種別-パラメータ */
  public static final String HEADER_FILE_KIND_PARAM = "4";

  public static final String DATA_FILE_KIND_MASK_STRING = "^" + HEADER_FILE_KIND_PARAM + "$";

  // データレコード定義
  public static final String[] DATA_TITLE_ROW;
  /** データレコード：項目数 */
  public static final int DATA_COLUMN_COUNT;

  // 契約番号
  /** データレコード：契約番号-インデックス */
  public static final int DATA_CONTRACT_NO_INDEX = 1;
  /** データレコード：契約番号-名称 */
  public static final String DATA_CONTRACT_NO_NAME = "契約番号";
  /** データレコード：契約番号-文字数 */
  public static final int DATA_CONTRACT_NO_LENGTH = 25;
  /** データレコード：契約番号-文字数（文字列） */
  public static final String DATA_CONTRACT_NO_LENGTH_STRING = String.valueOf(DATA_CONTRACT_NO_LENGTH);

  // 契約者番号
  /** データレコード：契約者番号-インデックス */
  public static final int DATA_CONTRACTOR_NO_INDEX = 2;
  /** データレコード：契約者番号-名称 */
  public static final String DATA_CONTRACTOR_NO_NAME = "契約者番号";
  /** データレコード：契約者番号-文字数 */
  public static final int DATA_CONTRACTOR_NO_LENGTH = 25;
  /** データレコード：契約者番号-文字数（文字列） */
  public static final String DATA_CONTRACTOR_NO_LENGTH_STRING = String.valueOf(DATA_CONTRACTOR_NO_LENGTH);

  // 支払番号
  /** データレコード：支払番号-インデックス */
  public static final int DATA_PAYMENT_NO_INDEX = 3;
  /** データレコード：支払番号-名称 */
  public static final String DATA_PAYMENT_NO_NAME = "支払番号";
  /** データレコード：支払番号-文字数 */
  public static final int DATA_PAYMENT_NO_LENGTH = 25;
  /** データレコード：支払番号-文字数（文字列） */
  public static final String DATA_PAYMENT_NO_LENGTH_STRING = String.valueOf(DATA_PAYMENT_NO_LENGTH);

  // メータ設置場所ID
  /** データレコード：メータ設置場所ID-インデックス */
  public static final int DATA_METER_LOCATION_ID_INDEX = 4;
  /** データレコード：メータ設置場所ID-名称 */
  public static final String DATA_METER_LOCATION_ID_NAME = "メータ設置場所ID";
  /** データレコード：メータ設置場所ID-文字数 */
  public static final int DATA_METER_LOCATION_ID_LENGTH = 10;
  /** データレコード：メータ設置場所ID-文字数（文字列） */
  public static final String DATA_METER_LOCATION_ID_LENGTH_STRING = String.valueOf(DATA_METER_LOCATION_ID_LENGTH);

  // 契約グループ番号
  /** データレコード：契約グループ番号-インデックス */
  public static final int DATA_CONTRACT_GROUP_NO_INDEX = 5;
  /** データレコード：契約グループ番号-名称 */
  public static final String DATA_CONTRACT_GROUP_NO_NAME = "契約グループ番号";
  /** データレコード：契約グループ番号-文字数 */
  public static final int DATA_CONTRACT_GROUP_NO_LENGTH = 25;
  /** データレコード：契約グループ番号-文字数（文字列） */
  public static final String DATA_CONTRACT_GROUP_NO_LENGTH_STRING = String.valueOf(DATA_CONTRACT_GROUP_NO_LENGTH);

  // 契約開始日
  /** データレコード：契約開始日-インデックス */
  public static final int DATA_CONTRACT_START_DATE_INDEX = 6;
  /** データレコード：契約開始日-名称 */
  public static final String DATA_CONTRACT_START_DATE_NAME = "契約開始日";
  /** データレコード：契約開始日-文字数 */
  public static final int DATA_CONTRACT_START_DATE_LENGTH = 10;
  /** データレコード：契約開始日-文字数（文字列） */
  public static final String DATA_CONTRACT_START_DATE_LENGTH_STRING = String.valueOf(DATA_CONTRACT_START_DATE_LENGTH);

  // 契約終了日
  /** データレコード：契約終了日-インデックス */
  public static final int DATA_CONTRACT_END_DATE_INDEX = 7;
  /** データレコード：契約終了日-名称 */
  public static final String DATA_CONTRACT_END_DATE_NAME = "契約終了日";
  /** データレコード：契約終了日-文字数 */
  public static final int DATA_CONTRACT_END_DATE_LENGTH = 10;
  /** データレコード：契約終了日-文字数（文字列） */
  public static final String DATA_CONTRACT_END_DATE_LENGTH_STRING = String.valueOf(DATA_CONTRACT_END_DATE_LENGTH);

  // 契約終了理由コード
  /** データレコード：契約終了理由コード-インデックス */
  public static final int DATA_CONTRACT_END_REASON_CODE_INDEX = 8;
  /** データレコード：契約終了理由コード-名称 */
  public static final String DATA_CONTRACT_END_REASON_CODE_NAME = "契約終了理由コード";
  /** データレコード：契約終了理由コード-文字数 */
  public static final int DATA_CONTRACT_END_REASON_CODE_LENGTH = 1;
  /** データレコード：契約終了理由コード-文字数（文字列） */
  public static final String DATA_CONTRACT_END_REASON_CODE_LENGTH_STRING = String
      .valueOf(DATA_CONTRACT_END_REASON_CODE_LENGTH);

  // 託送契約容量
  /** データレコード：託送契約容量-インデックス */
  public static final int DATA_CONSIGNMENT_CONTRACT_CAPACITY_INDEX = 9;
  /** データレコード：託送契約容量-名称 */
  public static final String DATA_CONSIGNMENT_CONTRACT_CAPACITY_NAME = "託送契約容量";
  /** データレコード：託送契約容量-整数部桁数上限 */
  public static final int DATA_CONSIGNMENT_CONTRACT_CAPACITY_DIGIT_INTEGER = 6;
  /** データレコード：託送契約容量-小数部桁数 */
  public static final int DATA_CONSIGNMENT_CONTRACT_CAPACITY_DIGIT_FLOAT = 2;
  /** データレコード：託送契約容量-整数部桁数上限（文字列） */
  public static final String DATA_CONSIGNMENT_CONTRACT_CAPACITY_DIGIT_INTEGER_STRING = String
      .valueOf(DATA_CONSIGNMENT_CONTRACT_CAPACITY_DIGIT_INTEGER);
  /** データレコード：託送契約容量-小数部桁数（文字列） */
  public static final String DATA_CONSIGNMENT_CONTRACT_CAPACITY_DIGIT_FLOAT_STRING = String
      .valueOf(DATA_CONSIGNMENT_CONTRACT_CAPACITY_DIGIT_FLOAT);

  // 託送契約容量単位
  /** データレコード：託送契約容量単位-インデックス */
  public static final int DATA_CONSIGNMENT_CONTRACT_CAPACITY_UNIT_INDEX = 10;
  /** データレコード：託送契約容量単位-名称 */
  public static final String DATA_CONSIGNMENT_CONTRACT_CAPACITY_UNIT_NAME = "託送契約容量単位";
  /** データレコード：託送契約容量単位-文字数 */
  public static final int DATA_CONSIGNMENT_CONTRACT_CAPACITY_UNIT_LENGTH = 1;
  /** データレコード：託送契約容量単位-文字数（文字列） */
  public static final String DATA_CONSIGNMENT_CONTRACT_CAPACITY_UNIT_LENGTH_STRING = String
      .valueOf(DATA_CONSIGNMENT_CONTRACT_CAPACITY_UNIT_LENGTH);

  // 託送契約容量判定日
  /** データレコード：託送契約容量判定日-インデックス */
  public static final int DATA_CONSIGNMENT_CONTRACT_CAPACITY_DECISION_DATE_INDEX = 11;
  /** データレコード：託送契約容量判定日-名称 */
  public static final String DATA_CONSIGNMENT_CONTRACT_CAPACITY_DECISION_DATE_NAME = "託送契約容量判定日";
  /** データレコード：託送契約容量判定日-文字数 */
  public static final int DATA_CONSIGNMENT_CONTRACT_CAPACITY_DECISION_DATE_LENGTH = 10;
  /** データレコード：託送契約容量判定日-文字数（文字列） */
  public static final String DATA_CONSIGNMENT_CONTRACT_CAPACITY_DECISION_DATE_LENGTH_STRING = String
      .valueOf(DATA_CONSIGNMENT_CONTRACT_CAPACITY_DECISION_DATE_LENGTH);

  // 料金チェックフラグ
  /** データレコード：料金チェックフラグ-インデックス */
  public static final int DATA_CHARGE_CHECK_FLAG_INDEX = 12;
  /** データレコード：料金チェックフラグ-名称 */
  public static final String DATA_CHARGE_CHECK_FLAG_NAME = "料金チェックフラグ";
  /** データレコード：料金チェックフラグ-文字数 */
  public static final int DATA_CHARGE_CHECK_FLAG_LENGTH = 1;
  /** データレコード：料金チェックフラグ-文字数（文字列） */
  public static final String DATA_CHARGE_CHECK_FLAG_LENGTH_STRING = String.valueOf(DATA_CHARGE_CHECK_FLAG_LENGTH);

  // 個人・法人区分コード
  /** データレコード：個人・法人区分コード-インデックス */
  public static final int DATA_INDIVIDUAL_LEGAL_ENTITY_CATEGORY_CODE_INDEX = 13;
  /** データレコード：個人・法人区分コード-名称 */
  public static final String DATA_INDIVIDUAL_LEGAL_ENTITY_CATEGORY_CODE_NAME = "個人・法人区分コード";
  /** データレコード：個人・法人区分コード-文字数 */
  public static final int DATA_INDIVIDUAL_LEGAL_ENTITY_CATEGORY_CODE_LENGTH = 1;
  /** データレコード：個人・法人区分コード-文字数（文字列） */
  public static final String DATA_INDIVIDUAL_LEGAL_ENTITY_CATEGORY_CODE_LENGTH_STRING = String
      .valueOf(DATA_INDIVIDUAL_LEGAL_ENTITY_CATEGORY_CODE_LENGTH);

  // 連絡先氏名（カナ）
  /** データレコード：連絡先氏名（カナ）-インデックス */
  public static final int DATA_CONTRACT_INFORMATION_NAME_KANA_INDEX = 14;
  /** データレコード：連絡先氏名（カナ）-名称 */
  public static final String DATA_CONTRACT_INFORMATION_NAME_KANA_NAME = "連絡先氏名（カナ）";
  /** データレコード：連絡先氏名（カナ）-文字数 */
  public static final int DATA_CONTRACT_INFORMATION_NAME_KANA_LENGTH = 40;
  /** データレコード：連絡先氏名（カナ）-文字数（文字列） */
  public static final String DATA_CONTRACT_INFORMATION_NAME_KANA_LENGTH_STRING = String
      .valueOf(DATA_CONTRACT_INFORMATION_NAME_KANA_LENGTH);

  // 連絡先氏名1
  /** データレコード：連絡先氏名1-インデックス */
  public static final int DATA_CONTRACT_INFORMATION_NAME1_INDEX = 15;
  /** データレコード：連絡先氏名1-名称 */
  public static final String DATA_CONTRACT_INFORMATION_NAME1_NAME = "連絡先氏名1";
  /** データレコード：連絡先氏名1-文字数 */
  public static final int DATA_CONTRACT_INFORMATION_NAME1_LENGTH = 35;
  /** データレコード：連絡先氏名1-文字数（文字列） */
  public static final String DATA_CONTRACT_INFORMATION_NAME1_LENGTH_STRING = String
      .valueOf(DATA_CONTRACT_INFORMATION_NAME1_LENGTH);

  // 連絡先氏名2
  /** データレコード：連絡先氏名2-インデックス */
  public static final int DATA_CONTRACT_INFORMATION_NAME2_INDEX = 16;
  /** データレコード：連絡先氏名2-名称 */
  public static final String DATA_CONTRACT_INFORMATION_NAME2_NAME = "連絡先氏名2";
  /** データレコード：連絡先氏名2-文字数 */
  public static final int DATA_CONTRACT_INFORMATION_NAME2_LENGTH = 27;
  /** データレコード：連絡先氏名2-文字数（文字列） */
  public static final String DATA_CONTRACT_INFORMATION_NAME2_LENGTH_STRING = String
      .valueOf(DATA_CONTRACT_INFORMATION_NAME2_LENGTH);

  // 連絡先住所（郵便番号）
  /** データレコード：連絡先住所（郵便番号）-インデックス */
  public static final int DATA_CONTRACT_INFORMATION_ADDRESS_POSTAL_CODE_INDEX = 17;
  /** データレコード：連絡先住所（郵便番号）-名称 */
  public static final String DATA_CONTRACT_INFORMATION_ADDRESS_POSTAL_CODE_NAME = "連絡先住所（郵便番号）";
  /** データレコード：連絡先住所（郵便番号）-文字数 */
  public static final int DATA_CONTRACT_INFORMATION_ADDRESS_POSTAL_CODE_LENGTH = 7;
  /** データレコード：連絡先住所（郵便番号）-文字数（文字列） */
  public static final String DATA_CONTRACT_INFORMATION_ADDRESS_POSTAL_CODE_LENGTH_STRING = String
      .valueOf(DATA_CONTRACT_INFORMATION_ADDRESS_POSTAL_CODE_LENGTH);

  // 連絡先住所（住所）
  /** データレコード：連絡先住所（住所）-インデックス */
  public static final int DATA_CONTRACT_INFORMATION_ADDRESS_FULL_INDEX = 18;
  /** データレコード：連絡先住所（住所）-名称 */
  public static final String DATA_CONTRACT_INFORMATION_ADDRESS_FULL_NAME = "連絡先住所（住所）";
  /** データレコード：連絡先住所（住所）-文字数 */
  public static final int DATA_CONTRACT_INFORMATION_ADDRESS_FULL_LENGTH = 60;
  /** データレコード：連絡先住所（住所）-文字数（文字列） */
  public static final String DATA_CONTRACT_INFORMATION_ADDRESS_FULL_LENGTH_STRING = String
      .valueOf(DATA_CONTRACT_INFORMATION_ADDRESS_FULL_LENGTH);

  // 連絡先住所（建物・部屋名）
  /** データレコード：連絡先住所（建物・部屋名）-インデックス */
  public static final int DATA_CONTRACT_INFORMATION_ADDRESS_BUILDING_INDEX = 19;
  /** データレコード：連絡先住所（建物・部屋名）-名称 */
  public static final String DATA_CONTRACT_INFORMATION_ADDRESS_BUILDING_NAME = "連絡先住所（建物・部屋名）";
  /** データレコード：連絡先住所（建物・部屋名）-文字数 */
  public static final int DATA_CONTRACT_INFORMATION_ADDRESS_BUILDING_LENGTH = 36;
  /** データレコード：連絡先住所（建物・部屋名）-文字数（文字列） */
  public static final String DATA_CONTRACT_INFORMATION_ADDRESS_BUILDING_LENGTH_STRING = String
      .valueOf(DATA_CONTRACT_INFORMATION_ADDRESS_BUILDING_LENGTH);

  // 連絡先電話区分コード
  /** データレコード：連絡先電話区分コード-インデックス */
  public static final int DATA_CONTRACT_INFORMATION_CATEGORY_CODE_INDEX = 20;
  /** データレコード：連絡先電話区分コード-名称 */
  public static final String DATA_CONTRACT_INFORMATION_CATEGORY_CODE_NAME = "連絡先電話区分コード";
  /** データレコード：連絡先電話区分コード-文字数 */
  public static final int DATA_CONTRACT_INFORMATION_CATEGORY_CODE_LENGTH = 1;
  /** データレコード：連絡先電話区分コード-文字数（文字列） */
  public static final String DATA_CONTRACT_INFORMATION_CATEGORY_CODE_LENGTH_STRING = String
      .valueOf(DATA_CONTRACT_INFORMATION_CATEGORY_CODE_LENGTH);

  // 連絡先電話（市外局番）
  /** データレコード：連絡先電話（市外局番）-インデックス */
  public static final int DATA_CONTRACT_INFORMATION_AREA_CODE_INDEX = 21;
  /** データレコード：連絡先電話（市外局番）-名称 */
  public static final String DATA_CONTRACT_INFORMATION_AREA_CODE_NAME = "連絡先電話（市外局番）";
  /** データレコード：連絡先電話（市外局番）-文字数 */
  public static final int DATA_CONTRACT_INFORMATION_AREA_CODE_LENGTH = 6;
  /** データレコード：連絡先電話（市外局番）-文字数（文字列） */
  public static final String DATA_CONTRACT_INFORMATION_AREA_CODE_LENGTH_STRING = String
      .valueOf(DATA_CONTRACT_INFORMATION_AREA_CODE_LENGTH);

  // 連絡先電話（市内局番）
  /** データレコード：連絡先電話（市内局番）-インデックス */
  public static final int DATA_CONTRACT_INFORMATION_LOCAL_NO_INDEX = 22;
  /** データレコード：連絡先電話（市内局番）-名称 */
  public static final String DATA_CONTRACT_INFORMATION_LOCAL_NO_NAME = "連絡先電話（市内局番）";
  /** データレコード：連絡先電話（市内局番）-文字数 */
  public static final int DATA_CONTRACT_INFORMATION_LOCAL_NO_LENGTH = 4;
  /** データレコード：連絡先電話（市内局番）-文字数（文字列） */
  public static final String DATA_CONTRACT_INFORMATION_LOCAL_NO_LENGTH_STRING = String
      .valueOf(DATA_CONTRACT_INFORMATION_LOCAL_NO_LENGTH);

  // 連絡先電話（加入者番号）
  /** データレコード：連絡先電話（加入者番号）-インデックス */
  public static final int DATA_CONTRACT_INFORMATION_DIRECTORY_NO_INDEX = 23;
  /** データレコード：連絡先電話（加入者番号）-名称 */
  public static final String DATA_CONTRACT_INFORMATION_DIRECTORY_NO_NAME = "連絡先電話（加入者番号）";
  /** データレコード：連絡先電話（加入者番号）-文字数 */
  public static final int DATA_CONTRACT_INFORMATION_DIRECTORY_NO_LENGTH = 6;
  /** データレコード：連絡先電話（加入者番号）-文字数（文字列） */
  public static final String DATA_CONTRACT_INFORMATION_DIRECTORY_NO_LENGTH_STRING = String
      .valueOf(DATA_CONTRACT_INFORMATION_DIRECTORY_NO_LENGTH);

  // 接続送電サービス区分コード
  /** データレコード：接続送電サービス区分コード-インデックス */
  public static final int DATA_CONNECTED_SUPPLY_SERVICE_CATEGORY_CODE_INDEX = 24;
  /** データレコード：接続送電サービス区分コード-名称 */
  public static final String DATA_CONNECTED_SUPPLY_SERVICE_CATEGORY_CODE_NAME = "接続送電サービス区分コード";
  /** データレコード：接続送電サービス区分コード-文字数 */
  public static final int DATA_CONNECTED_SUPPLY_SERVICE_CATEGORY_CODE_LENGTH = 5;
  /** データレコード：接続送電サービス区分コード-文字数（文字列） */
  public static final String DATA_CONNECTED_SUPPLY_SERVICE_CATEGORY_CODE_LENGTH_STRING = String
      .valueOf(DATA_CONNECTED_SUPPLY_SERVICE_CATEGORY_CODE_LENGTH);

  // 備考
  /** データレコード：備考-インデックス */
  public static final int DATA_NOTE_INDEX = 25;
  /** データレコード：備考-名称 */
  public static final String DATA_NOTE_NAME = "備考";
  /** データレコード：備考-文字数 */
  public static final int DATA_NOTE_LENGTH = 200;
  /** データレコード：備考-文字数（文字列） */
  public static final String DATA_NOTE_LENGTH_STRING = String.valueOf(DATA_NOTE_LENGTH);

  // フリー項目1
  /** データレコード：フリー項目1-インデックス */
  public static final int DATA_FREE1_INDEX = 26;
  /** データレコード：フリー項目1-名称 */
  public static final String DATA_FREE1_NAME = "フリー項目1";
  /** データレコード：フリー項目1-文字数 */
  public static final int DATA_FREE1_LENGTH = 100;
  /** データレコード：フリー項目1-文字数（文字列） */
  public static final String DATA_FREE1_LENGTH_STRING = String.valueOf(DATA_FREE1_LENGTH);

  // フリー項目2
  /** データレコード：フリー項目2-インデックス */
  public static final int DATA_FREE2_INDEX = 27;
  /** データレコード：フリー項目2-名称 */
  public static final String DATA_FREE2_NAME = "フリー項目2";
  /** データレコード：フリー項目2-文字数 */
  public static final int DATA_FREE2_LENGTH = 100;
  /** データレコード：フリー項目2-文字数（文字列） */
  public static final String DATA_FREE2_LENGTH_STRING = String.valueOf(DATA_FREE2_LENGTH);

  // フリー項目3
  /** データレコード：フリー項目3-インデックス */
  public static final int DATA_FREE3_INDEX = 28;
  /** データレコード：フリー項目3-名称 */
  public static final String DATA_FREE3_NAME = "フリー項目3";
  /** データレコード：フリー項目3-文字数 */
  public static final int DATA_FREE3_LENGTH = 100;
  /** データレコード：フリー項目3-文字数（文字列） */
  public static final String DATA_FREE3_LENGTH_STRING = String.valueOf(DATA_FREE3_LENGTH);

  // フリー項目4
  /** データレコード：フリー項目4-インデックス */
  public static final int DATA_FREE4_INDEX = 29;
  /** データレコード：フリー項目4-名称 */
  public static final String DATA_FREE4_NAME = "フリー項目4";
  /** データレコード：フリー項目4-文字数 */
  public static final int DATA_FREE4_LENGTH = 100;
  /** データレコード：フリー項目4-文字数（文字列） */
  public static final String DATA_FREE4_LENGTH_STRING = String.valueOf(DATA_FREE4_LENGTH);

  // フリー項目5
  /** データレコード：フリー項目5-インデックス */
  public static final int DATA_FREE5_INDEX = 30;
  /** データレコード：フリー項目5-名称 */
  public static final String DATA_FREE5_NAME = "フリー項目5";
  /** データレコード：フリー項目5-文字数 */
  public static final int DATA_FREE5_LENGTH = 100;
  /** データレコード：フリー項目5-文字数（文字列） */
  public static final String DATA_FREE5_LENGTH_STRING = String.valueOf(DATA_FREE5_LENGTH);

  // フリー項目6
  /** データレコード：フリー項目6-インデックス */
  public static final int DATA_FREE6_INDEX = 31;
  /** データレコード：フリー項目6-名称 */
  public static final String DATA_FREE6_NAME = "フリー項目6";
  /** データレコード：フリー項目6-文字数 */
  public static final int DATA_FREE6_LENGTH = 100;
  /** データレコード：フリー項目6-文字数（文字列） */
  public static final String DATA_FREE6_LENGTH_STRING = String.valueOf(DATA_FREE6_LENGTH);

  // フリー項目7
  /** データレコード：フリー項目7-インデックス */
  public static final int DATA_FREE7_INDEX = 32;
  /** データレコード：フリー項目7-名称 */
  public static final String DATA_FREE7_NAME = "フリー項目7";
  /** データレコード：フリー項目7-文字数 */
  public static final int DATA_FREE7_LENGTH = 100;
  /** データレコード：フリー項目7-文字数（文字列） */
  public static final String DATA_FREE7_LENGTH_STRING = String.valueOf(DATA_FREE7_LENGTH);

  // フリー項目8
  /** データレコード：フリー項目8-インデックス */
  public static final int DATA_FREE8_INDEX = 33;
  /** データレコード：フリー項目8-名称 */
  public static final String DATA_FREE8_NAME = "フリー項目8";
  /** データレコード：フリー項目8-文字数 */
  public static final int DATA_FREE8_LENGTH = 100;
  /** データレコード：フリー項目8-文字数（文字列） */
  public static final String DATA_FREE8_LENGTH_STRING = String.valueOf(DATA_FREE8_LENGTH);

  // 設備ID
  /** データレコード：設備ID-インデックス */
  public static final int DATA_FREE9_INDEX = 34;
  /** データレコード：設備ID-名称 */
  public static final String DATA_FREE9_NAME = "設備ID";
  /** データレコード：設備ID-文字数 */
  public static final int DATA_FREE9_LENGTH = 10;
  /** データレコード：設備ID-文字数（文字列） */
  public static final String DATA_FREE9_LENGTH_STRING = String.valueOf(DATA_FREE9_LENGTH);

  // フリー項目10
  /** データレコード：フリー項目10-インデックス */
  public static final int DATA_FREE10_INDEX = 35;
  /** データレコード：フリー項目10-名称 */
  public static final String DATA_FREE10_NAME = "フリー項目10";
  /** データレコード：フリー項目10-文字数 */
  public static final int DATA_FREE10_LENGTH = 100;
  /** データレコード：フリー項目10-文字数（文字列） */
  public static final String DATA_FREE10_LENGTH_STRING = String.valueOf(DATA_FREE10_LENGTH);

  // フリー項目11
  /** データレコード：フリー項目11-インデックス */
  public static final int DATA_FREE11_INDEX = 36;
  /** データレコード：フリー項目11-名称 */
  public static final String DATA_FREE11_NAME = "フリー項目11";
  /** データレコード：フリー項目11-文字数 */
  public static final int DATA_FREE11_LENGTH = 100;
  /** データレコード：フリー項目11-文字数（文字列） */
  public static final String DATA_FREE11_LENGTH_STRING = String.valueOf(DATA_FREE11_LENGTH);

  // フリー項目12
  /** データレコード：フリー項目12-インデックス */
  public static final int DATA_FREE12_INDEX = 37;
  /** データレコード：フリー項目12-名称 */
  public static final String DATA_FREE12_NAME = "フリー項目12";
  /** データレコード：フリー項目12-文字数 */
  public static final int DATA_FREE12_LENGTH = 100;
  /** データレコード：フリー項目12-文字数（文字列） */
  public static final String DATA_FREE12_LENGTH_STRING = String.valueOf(DATA_FREE12_LENGTH);

  // フリー項目13
  /** データレコード：フリー項目13-インデックス */
  public static final int DATA_FREE13_INDEX = 38;
  /** データレコード：フリー項目13-名称 */
  public static final String DATA_FREE13_NAME = "フリー項目13";
  /** データレコード：フリー項目13-文字数 */
  public static final int DATA_FREE13_LENGTH = 100;
  /** データレコード：フリー項目13-文字数（文字列） */
  public static final String DATA_FREE13_LENGTH_STRING = String.valueOf(DATA_FREE13_LENGTH);

  // フリー項目14
  /** データレコード：フリー項目14-インデックス */
  public static final int DATA_FREE14_INDEX = 39;
  /** データレコード：フリー項目14-名称 */
  public static final String DATA_FREE14_NAME = "フリー項目14";
  /** データレコード：フリー項目14-文字数 */
  public static final int DATA_FREE14_LENGTH = 100;
  /** データレコード：フリー項目14-文字数（文字列） */
  public static final String DATA_FREE14_LENGTH_STRING = String.valueOf(DATA_FREE14_LENGTH);

  // 委託先使用項目1
  /** データレコード：委託先使用項目1-インデックス */
  public static final int DATA_CONSIGNMENT_USE_ITEM1_INDEX = 40;
  /** データレコード：委託先使用項目1-名称 */
  public static final String DATA_CONSIGNMENT_USE_ITEM1_NAME = "委託先使用項目1";
  /** データレコード：委託先使用項目1-文字数 */
  public static final int DATA_CONSIGNMENT_USE_ITEM1_LENGTH = 128;
  /** データレコード：委託先使用項目1-文字数（文字列） */
  public static final String DATA_CONSIGNMENT_USE_ITEM1_LENGTH_STRING = String
      .valueOf(DATA_CONSIGNMENT_USE_ITEM1_LENGTH);

  // 委託先使用項目2
  /** データレコード：委託先使用項目2-インデックス */
  public static final int DATA_CONSIGNMENT_USE_ITEM2_INDEX = 41;
  /** データレコード：委託先使用項目2-名称 */
  public static final String DATA_CONSIGNMENT_USE_ITEM2_NAME = "委託先使用項目2";
  /** データレコード：委託先使用項目2-文字数 */
  public static final int DATA_CONSIGNMENT_USE_ITEM2_LENGTH = 128;
  /** データレコード：委託先使用項目2-文字数（文字列） */
  public static final String DATA_CONSIGNMENT_USE_ITEM2_LENGTH_STRING = String
      .valueOf(DATA_CONSIGNMENT_USE_ITEM2_LENGTH);

  // 委託先使用項目3
  /** データレコード：委託先使用項目3-インデックス */
  public static final int DATA_CONSIGNMENT_USE_ITEM3_INDEX = 42;
  /** データレコード：委託先使用項目3-名称 */
  public static final String DATA_CONSIGNMENT_USE_ITEM3_NAME = "委託先使用項目3";
  /** データレコード：委託先使用項目3-文字数 */
  public static final int DATA_CONSIGNMENT_USE_ITEM3_LENGTH = 128;
  /** データレコード：委託先使用項目3-文字数（文字列） */
  public static final String DATA_CONSIGNMENT_USE_ITEM3_LENGTH_STRING = String
      .valueOf(DATA_CONSIGNMENT_USE_ITEM3_LENGTH);

  // 自社担当者コード
  /** データレコード：自社担当者コード-インデックス */
  public static final int DATA_OUR_MANAGEMENT_PERSON_IN_CHARGE_CODE_INDEX = 43;
  /** データレコード：自社担当者コード-名称 */
  public static final String DATA_OUR_MANAGEMENT_PERSON_IN_CHARGE_CODE_NAME = "自社担当者コード";
  /** データレコード：自社担当者コード-文字数 */
  public static final int DATA_OUR_MANAGEMENT_PERSON_IN_CHARGE_CODE_LENGTH = 20;
  /** データレコード：自社担当者コード-文字数（文字列） */
  public static final String DATA_OUR_MANAGEMENT_PERSON_IN_CHARGE_CODE_LENGTH_STRING = String
      .valueOf(DATA_OUR_MANAGEMENT_PERSON_IN_CHARGE_CODE_LENGTH);

  // 自社部署コード
  /** データレコード：自社部署コード-インデックス */
  public static final int DATA_OUR_MANAGEMENT_DEPARTMENT_CODE_INDEX = 44;
  /** データレコード：自社部署コード-名称 */
  public static final String DATA_OUR_MANAGEMENT_DEPARTMENT_CODE_NAME = "自社部署コード";
  /** データレコード：自社部署コード-文字数 */
  public static final int DATA_OUR_MANAGEMENT_DEPARTMENT_CODE_LENGTH = 10;
  /** データレコード：自社部署コード-文字数（文字列） */
  public static final String DATA_OUR_MANAGEMENT_DEPARTMENT_CODE_LENGTH_STRING = String
      .valueOf(DATA_OUR_MANAGEMENT_DEPARTMENT_CODE_LENGTH);

  // 業種コード
  /** データレコード：業種コード-インデックス */
  public static final int DATA_BUSINESS_TYPE_CODE_INDEX = 45;
  /** データレコード：業種コード-名称 */
  public static final String DATA_BUSINESS_TYPE_CODE_NAME = "業種コード";
  /** データレコード：業種コード-文字数 */
  public static final int DATA_BUSINESS_TYPE_CODE_LENGTH = 3;
  /** データレコード：業種コード-文字数（文字列） */
  public static final String DATA_BUSINESS_TYPE_CODE_LENGTH_STRING = String.valueOf(DATA_BUSINESS_TYPE_CODE_LENGTH);

  // 営業委託先コード
  /** データレコード：営業委託先コード-インデックス */
  public static final int DATA_SALES_CONSIGNMENT_CODE_INDEX = 46;
  /** データレコード：営業委託先コード-名称 */
  public static final String DATA_SALES_CONSIGNMENT_CODE_NAME = "営業委託先コード";
  /** データレコード：営業委託先コード-文字数 */
  public static final int DATA_SALES_CONSIGNMENT_CODE_LENGTH = 9;
  /** データレコード：営業委託先コード-文字数（文字列） */
  public static final String DATA_SALES_CONSIGNMENT_CODE_LENGTH_STRING = String
      .valueOf(DATA_SALES_CONSIGNMENT_CODE_LENGTH);

  // 適用開始日
  /** データレコード：適用開始日-インデックス */
  public static final int DATA_APPLY_START_DATE_INDEX = 47;
  /** データレコード：適用開始日-名称 */
  public static final String DATA_APPLY_START_DATE_NAME = "適用開始日";
  /** データレコード：適用開始日-文字数 */
  public static final int DATA_APPLY_START_DATE_LENGTH = 10;
  /** データレコード：適用開始日-文字数（文字列） */
  public static final String DATA_APPLY_START_DATE_LENGTH_STRING = String.valueOf(DATA_APPLY_START_DATE_LENGTH);

  // 料金メニューID
  /** データレコード：料金メニューID-インデックス */
  public static final int DATA_RATE_MENU_ID_INDEX = 48;
  /** データレコード：料金メニューID-名称 */
  public static final String DATA_RATE_MENU_ID_NAME = "料金メニューID";
  /** データレコード：料金メニューID-文字数 */
  public static final int DATA_RATE_MENU_ID_LENGTH = 8;
  /** データレコード：料金メニューID-文字数（文字列） */
  public static final String DATA_RATE_MENU_ID_LENGTH_STRING = String.valueOf(DATA_RATE_MENU_ID_LENGTH);

  // 契約容量
  /** データレコード：契約容量-インデックス */
  public static final int DATA_CONTRACT_CAPACITY_INDEX = 49;
  /** データレコード：契約容量-名称 */
  public static final String DATA_CONTRACT_CAPACITY_NAME = "契約容量";
  /** データレコード：契約容量-整数部桁数上限 */
  public static final int DATA_CONTRACT_CAPACITY_DIGIT_INTEGER = 6;
  /** データレコード：契約容量-小数部桁数 */
  public static final int DATA_CONTRACT_CAPACITY_DIGIT_FLOAT = 2;
  /** データレコード：契約容量-整数部桁数上限（文字列） */
  public static final String DATA_CONTRACT_CAPACITY_DIGIT_INTEGER_STRING = String
      .valueOf(DATA_CONTRACT_CAPACITY_DIGIT_INTEGER);
  /** データレコード：契約容量-小数部桁数（文字列） */
  public static final String DATA_CONTRACT_CAPACITY_DIGIT_FLOAT_STRING = String
      .valueOf(DATA_CONTRACT_CAPACITY_DIGIT_FLOAT);

  // 契約変更理由
  /** データレコード：契約変更理由-インデックス */
  public static final int DATA_CONTRACT_CHANGE_REASON_INDEX = 50;
  /** データレコード：契約変更理由-名称 */
  public static final String DATA_CONTRACT_CHANGE_REASON_NAME = "契約変更理由";
  /** データレコード：契約変更理由-文字数 */
  public static final int DATA_CONTRACT_CHANGE_REASON_LENGTH = 200;
  /** データレコード：契約変更理由-文字数（文字列） */
  public static final String DATA_CONTRACT_CHANGE_REASON_LENGTH_STRING = String
      .valueOf(DATA_CONTRACT_CHANGE_REASON_LENGTH);

  // 更新回数
  /** データレコード：更新回数-インデックス */
  public static final int DATA_UPDATE_COUNT_INDEX = 51;
  /** データレコード：更新回数-名称 */
  public static final String DATA_UPDATE_COUNT_NAME = "更新回数";
  /** データレコード：更新回数-文字数 */
  public static final int DATA_UPDATE_COUNT_LENGTH = 10;
  /** データレコード：更新回数-文字数（文字列） */
  public static final String DATA_UPDATE_COUNT_LENGTH_STRING = String.valueOf(DATA_UPDATE_COUNT_LENGTH);

  // 登録・更新・削除区分
  /** データレコード：登録・更新・削除区分-インデックス */
  public static final int DATA_REGISTER_UPDATE_DELETE_CATEGORY_INDEX = 52;
  /** データレコード：登録・更新・削除区分-名称 */
  public static final String DATA_REGISTER_UPDATE_DELETE_CATEGORY_NAME = "登録・更新・削除区分";
  /** データレコード：登録・更新・削除区分-文字数 */
  public static final int DATA_REGISTER_UPDATE_DELETE_CATEGORY_LENGTH = 1;
  /** データレコード：登録・更新・削除区分-文字数（文字列） */
  public static final String DATA_REGISTER_UPDATE_DELETE_CATEGORY_LENGTH_STRING = String
      .valueOf(DATA_REGISTER_UPDATE_DELETE_CATEGORY_LENGTH);

  // 需要者窓口連絡先所属
  /** データレコード：需要者窓口連絡先所属-インデックス */
  public static final int DATA_CONSUMER_CONTRACT_AFFILIATION_INDEX = 53;
  /** データレコード：需要者窓口連絡先所属-名称 */
  public static final String DATA_CONSUMER_CONTRACT_AFFILIATION_NAME = "需要者窓口連絡先所属";
  /** データレコード：需要者窓口連絡先所属-文字数 */
  public static final int DATA_CONSUMER_CONTRACT_AFFILIATION_LENGTH = 55;
  /** データレコード：需要者窓口連絡先所属-文字数（文字列） */
  public static final String DATA_CONSUMER_CONTRACT_AFFILIATION_LENGTH_STRING = String
      .valueOf(DATA_CONSUMER_CONTRACT_AFFILIATION_LENGTH);

  // 需要者窓口連絡先氏名
  /** データレコード：需要者窓口連絡先氏名-インデックス */
  public static final int DATA_CONSUMER_CONTRACT_NAME_INDEX = 54;
  /** データレコード：需要者窓口連絡先氏名-名称 */
  public static final String DATA_CONSUMER_CONTRACT_NAME_NAME = "需要者窓口連絡先氏名";
  /** データレコード：需要者窓口連絡先氏名-文字数 */
  public static final int DATA_CONSUMER_CONTRACT_NAME_LENGTH = 55;
  /** データレコード：需要者窓口連絡先氏名-文字数（文字列） */
  public static final String DATA_CONSUMER_CONTRACT_NAME_LENGTH_STRING = String
      .valueOf(DATA_CONSUMER_CONTRACT_NAME_LENGTH);

  // 需要者窓口連絡先電話（市外局番）
  /** データレコード：需要者窓口連絡先電話（市外局番）-インデックス */
  public static final int DATA_CONSUMER_CONTRACT_AREA_CODE_INDEX = 55;
  /** データレコード：需要者窓口連絡先電話（市外局番）-名称 */
  public static final String DATA_CONSUMER_CONTRACT_AREA_CODE_NAME = "需要者窓口連絡先電話（市外局番）";
  /** データレコード：需要者窓口連絡先電話（市外局番）-文字数 */
  public static final int DATA_CONSUMER_CONTRACT_AREA_CODE_LENGTH = 6;
  /** データレコード：需要者窓口連絡先電話（市外局番）-文字数（文字列） */
  public static final String DATA_CONSUMER_CONTRACT_AREA_CODE_LENGTH_STRING = String
      .valueOf(DATA_CONSUMER_CONTRACT_AREA_CODE_LENGTH);

  // 需要者窓口連絡先電話（市内局番）
  /** データレコード：需要者窓口連絡先電話（市内局番）-インデックス */
  public static final int DATA_CONSUMER_CONTRACT_LOCAL_NO_INDEX = 56;
  /** データレコード：需要者窓口連絡先電話（市内局番）-名称 */
  public static final String DATA_CONSUMER_CONTRACT_LOCAL_NO_NAME = "需要者窓口連絡先電話（市内局番）";
  /** データレコード：需要者窓口連絡先電話（市内局番）-文字数 */
  public static final int DATA_CONSUMER_CONTRACT_LOCAL_NO_LENGTH = 4;
  /** データレコード：需要者窓口連絡先電話（市内局番）-文字数（文字列） */
  public static final String DATA_CONSUMER_CONTRACT_LOCAL_NO_LENGTH_STRING = String
      .valueOf(DATA_CONSUMER_CONTRACT_LOCAL_NO_LENGTH);

  // 需要者窓口連絡先電話（加入者番号）
  /** データレコード：需要者窓口連絡先電話（加入者番号）-インデックス */
  public static final int DATA_CONSUMER_CONTRACT_DIRECTORY_NO_INDEX = 57;
  /** データレコード：需要者窓口連絡先電話（加入者番号）-名称 */
  public static final String DATA_CONSUMER_CONTRACT_DIRECTORY_NO_NAME = "需要者窓口連絡先電話（加入者番号）";
  /** データレコード：需要者窓口連絡先電話（加入者番号）-文字数 */
  public static final int DATA_CONSUMER_CONTRACT_DIRECTORY_NO_LENGTH = 4;
  /** データレコード：需要者窓口連絡先電話（加入者番号）-文字数（文字列） */
  public static final String DATA_CONSUMER_CONTRACT_DIRECTORY_NO_LENGTH_STRING = String
      .valueOf(DATA_CONSUMER_CONTRACT_DIRECTORY_NO_LENGTH);

  // 主任技術者連絡先所属
  /** データレコード：主任技術者連絡先所属-インデックス */
  public static final int DATA_CHIEF_ENGINEER_OFFICER_AFFILIATION_INDEX = 58;
  /** データレコード：主任技術者連絡先所属-名称 */
  public static final String DATA_CHIEF_ENGINEER_OFFICER_AFFILIATION_NAME = "主任技術者連絡先所属";
  /** データレコード：主任技術者連絡先所属-文字数 */
  public static final int DATA_CHIEF_ENGINEER_OFFICER_AFFILIATION_LENGTH = 55;
  /** データレコード：主任技術者連絡先所属-文字数（文字列） */
  public static final String DATA_CHIEF_ENGINEER_OFFICER_AFFILIATION_LENGTH_STRING = String
      .valueOf(DATA_CHIEF_ENGINEER_OFFICER_AFFILIATION_LENGTH);

  // 主任技術者連絡先氏名
  /** データレコード：主任技術者連絡先氏名-インデックス */
  public static final int DATA_CHIEF_ENGINEER_OFFICER_NAME_INDEX = 59;
  /** データレコード：主任技術者連絡先氏名-名称 */
  public static final String DATA_CHIEF_ENGINEER_OFFICER_NAME_NAME = "主任技術者連絡先氏名";
  /** データレコード：主任技術者連絡先氏名-文字数 */
  public static final int DATA_CHIEF_ENGINEER_OFFICER_NAME_LENGTH = 55;
  /** データレコード：主任技術者連絡先氏名-文字数（文字列） */
  public static final String DATA_CHIEF_ENGINEER_OFFICER_NAME_LENGTH_STRING = String
      .valueOf(DATA_CHIEF_ENGINEER_OFFICER_NAME_LENGTH);

  // 主任技術者連絡先電話（市外局番）
  /** データレコード：主任技術者連絡先電話（市外局番）-インデックス */
  public static final int DATA_CHIEF_ENGINEER_OFFICER_AREA_CODE_INDEX = 60;
  /** データレコード：主任技術者連絡先電話（市外局番）-名称 */
  public static final String DATA_CHIEF_ENGINEER_OFFICER_AREA_CODE_NAME = "主任技術者連絡先電話（市外局番）";
  /** データレコード：主任技術者連絡先電話（市外局番）-文字数 */
  public static final int DATA_CHIEF_ENGINEER_OFFICER_AREA_CODE_LENGTH = 6;
  /** データレコード：主任技術者連絡先電話（市外局番）-文字数（文字列） */
  public static final String DATA_CHIEF_ENGINEER_OFFICER_AREA_CODE_LENGTH_STRING = String
      .valueOf(DATA_CHIEF_ENGINEER_OFFICER_AREA_CODE_LENGTH);

  // 主任技術者連絡先電話（市内局番）
  /** データレコード：主任技術者連絡先電話（市内局番）-インデックス */
  public static final int DATA_CHIEF_ENGINEER_OFFICER_LOCAL_NO_INDEX = 61;
  /** データレコード：主任技術者連絡先電話（市内局番）-名称 */
  public static final String DATA_CHIEF_ENGINEER_OFFICER_LOCAL_NO_NAME = "主任技術者連絡先電話（市内局番）";
  /** データレコード：主任技術者連絡先電話（市内局番）-文字数 */
  public static final int DATA_CHIEF_ENGINEER_OFFICER_LOCAL_NO_LENGTH = 4;
  /** データレコード：主任技術者連絡先電話（市内局番）-文字数（文字列） */
  public static final String DATA_CHIEF_ENGINEER_OFFICER_LOCAL_NO_LENGTH_STRING = String
      .valueOf(DATA_CHIEF_ENGINEER_OFFICER_LOCAL_NO_LENGTH);

  // 主任技術者連絡先電話（加入者番号）
  /** データレコード：主任技術者連絡先電話（加入者番号）-インデックス */
  public static final int DATA_CHIEF_ENGINEER_OFFICER_DIRECTORY_NO_INDEX = 62;
  /** データレコード：主任技術者連絡先電話（加入者番号）-名称 */
  public static final String DATA_CHIEF_ENGINEER_OFFICER_DIRECTORY_NO_NAME = "主任技術者連絡先電話（加入者番号）";
  /** データレコード：主任技術者連絡先電話（加入者番号）-文字数 */
  public static final int DATA_CHIEF_ENGINEER_OFFICER_DIRECTORY_NO_LENGTH = 4;
  /** データレコード：主任技術者連絡先電話（加入者番号）-文字数（文字列） */
  public static final String DATA_CHIEF_ENGINEER_OFFICER_DIRECTORY_NO_LENGTH_STRING = String
      .valueOf(DATA_CHIEF_ENGINEER_OFFICER_DIRECTORY_NO_LENGTH);

  /** 市外局番、市内局番、加入者番号を連結し、かつハイフンを除いた最大桁 */
  public static final int PHONE_MAX = 14;

  /**
   * staticイニシャライザ.<br>
   * タイトル行の生成を行う<br>
   * インデックス=タイトル配列のインデックスになるため、番号は自動で設定される<br>
   * カラムの追加・削除があった場合に修正が必要
   */
  static {
    Map<Integer, String> titleMap = new HashMap<Integer, String>();

    // 項目を順番に入れ込んでいく
    // レコード種別は共通のものを使う
    titleMap.put(ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_INDEX,
        ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_NAME);

    titleMap.put(DATA_CONTRACT_NO_INDEX, DATA_CONTRACT_NO_NAME);
    titleMap.put(DATA_CONTRACTOR_NO_INDEX, DATA_CONTRACTOR_NO_NAME);
    titleMap.put(DATA_PAYMENT_NO_INDEX, DATA_PAYMENT_NO_NAME);
    titleMap.put(DATA_METER_LOCATION_ID_INDEX, DATA_METER_LOCATION_ID_NAME);
    titleMap.put(DATA_CONTRACT_GROUP_NO_INDEX, DATA_CONTRACT_GROUP_NO_NAME);
    titleMap.put(DATA_CONTRACT_START_DATE_INDEX,
        DATA_CONTRACT_START_DATE_NAME);
    titleMap.put(DATA_CONTRACT_END_DATE_INDEX, DATA_CONTRACT_END_DATE_NAME);
    titleMap.put(DATA_CONTRACT_END_REASON_CODE_INDEX,
        DATA_CONTRACT_END_REASON_CODE_NAME);
    titleMap.put(DATA_CONSIGNMENT_CONTRACT_CAPACITY_INDEX,
        DATA_CONSIGNMENT_CONTRACT_CAPACITY_NAME);
    titleMap.put(DATA_CONSIGNMENT_CONTRACT_CAPACITY_UNIT_INDEX,
        DATA_CONSIGNMENT_CONTRACT_CAPACITY_UNIT_NAME);
    titleMap.put(DATA_CONSIGNMENT_CONTRACT_CAPACITY_DECISION_DATE_INDEX,
        DATA_CONSIGNMENT_CONTRACT_CAPACITY_DECISION_DATE_NAME);
    titleMap.put(DATA_CHARGE_CHECK_FLAG_INDEX, DATA_CHARGE_CHECK_FLAG_NAME);
    titleMap.put(DATA_INDIVIDUAL_LEGAL_ENTITY_CATEGORY_CODE_INDEX,
        DATA_INDIVIDUAL_LEGAL_ENTITY_CATEGORY_CODE_NAME);
    titleMap.put(DATA_CONTRACT_INFORMATION_NAME_KANA_INDEX,
        DATA_CONTRACT_INFORMATION_NAME_KANA_NAME);
    titleMap.put(DATA_CONTRACT_INFORMATION_NAME1_INDEX,
        DATA_CONTRACT_INFORMATION_NAME1_NAME);
    titleMap.put(DATA_CONTRACT_INFORMATION_NAME2_INDEX,
        DATA_CONTRACT_INFORMATION_NAME2_NAME);
    titleMap.put(DATA_CONTRACT_INFORMATION_ADDRESS_POSTAL_CODE_INDEX,
        DATA_CONTRACT_INFORMATION_ADDRESS_POSTAL_CODE_NAME);
    titleMap.put(DATA_CONTRACT_INFORMATION_ADDRESS_FULL_INDEX,
        DATA_CONTRACT_INFORMATION_ADDRESS_FULL_NAME);
    titleMap.put(DATA_CONTRACT_INFORMATION_ADDRESS_BUILDING_INDEX,
        DATA_CONTRACT_INFORMATION_ADDRESS_BUILDING_NAME);
    titleMap.put(DATA_CONTRACT_INFORMATION_CATEGORY_CODE_INDEX,
        DATA_CONTRACT_INFORMATION_CATEGORY_CODE_NAME);
    titleMap.put(DATA_CONTRACT_INFORMATION_AREA_CODE_INDEX,
        DATA_CONTRACT_INFORMATION_AREA_CODE_NAME);
    titleMap.put(DATA_CONTRACT_INFORMATION_LOCAL_NO_INDEX,
        DATA_CONTRACT_INFORMATION_LOCAL_NO_NAME);
    titleMap.put(DATA_CONTRACT_INFORMATION_DIRECTORY_NO_INDEX,
        DATA_CONTRACT_INFORMATION_DIRECTORY_NO_NAME);
    titleMap.put(DATA_CONNECTED_SUPPLY_SERVICE_CATEGORY_CODE_INDEX,
        DATA_CONNECTED_SUPPLY_SERVICE_CATEGORY_CODE_NAME);
    titleMap.put(DATA_NOTE_INDEX, DATA_NOTE_NAME);
    titleMap.put(DATA_FREE1_INDEX, DATA_FREE1_NAME);
    titleMap.put(DATA_FREE2_INDEX, DATA_FREE2_NAME);
    titleMap.put(DATA_FREE3_INDEX, DATA_FREE3_NAME);
    titleMap.put(DATA_FREE4_INDEX, DATA_FREE4_NAME);
    titleMap.put(DATA_FREE5_INDEX, DATA_FREE5_NAME);
    titleMap.put(DATA_FREE6_INDEX, DATA_FREE6_NAME);
    titleMap.put(DATA_FREE7_INDEX, DATA_FREE7_NAME);
    titleMap.put(DATA_FREE8_INDEX, DATA_FREE8_NAME);
    titleMap.put(DATA_FREE9_INDEX, DATA_FREE9_NAME);
    titleMap.put(DATA_FREE10_INDEX, DATA_FREE10_NAME);
    titleMap.put(DATA_FREE11_INDEX, DATA_FREE11_NAME);
    titleMap.put(DATA_FREE12_INDEX, DATA_FREE12_NAME);
    titleMap.put(DATA_FREE13_INDEX, DATA_FREE13_NAME);
    titleMap.put(DATA_FREE14_INDEX, DATA_FREE14_NAME);
    titleMap.put(DATA_CONSIGNMENT_USE_ITEM1_INDEX,
        DATA_CONSIGNMENT_USE_ITEM1_NAME);
    titleMap.put(DATA_CONSIGNMENT_USE_ITEM2_INDEX,
        DATA_CONSIGNMENT_USE_ITEM2_NAME);
    titleMap.put(DATA_CONSIGNMENT_USE_ITEM3_INDEX,
        DATA_CONSIGNMENT_USE_ITEM3_NAME);
    titleMap.put(DATA_OUR_MANAGEMENT_PERSON_IN_CHARGE_CODE_INDEX,
        DATA_OUR_MANAGEMENT_PERSON_IN_CHARGE_CODE_NAME);
    titleMap.put(DATA_OUR_MANAGEMENT_DEPARTMENT_CODE_INDEX,
        DATA_OUR_MANAGEMENT_DEPARTMENT_CODE_NAME);
    titleMap.put(DATA_BUSINESS_TYPE_CODE_INDEX,
        DATA_BUSINESS_TYPE_CODE_NAME);
    titleMap.put(DATA_SALES_CONSIGNMENT_CODE_INDEX,
        DATA_SALES_CONSIGNMENT_CODE_NAME);
    titleMap.put(DATA_APPLY_START_DATE_INDEX, DATA_APPLY_START_DATE_NAME);
    titleMap.put(DATA_RATE_MENU_ID_INDEX, DATA_RATE_MENU_ID_NAME);
    titleMap.put(DATA_CONTRACT_CAPACITY_INDEX, DATA_CONTRACT_CAPACITY_NAME);
    titleMap.put(DATA_CONTRACT_CHANGE_REASON_INDEX,
        DATA_CONTRACT_CHANGE_REASON_NAME);
    titleMap.put(DATA_UPDATE_COUNT_INDEX, DATA_UPDATE_COUNT_NAME);
    titleMap.put(DATA_REGISTER_UPDATE_DELETE_CATEGORY_INDEX,
        DATA_REGISTER_UPDATE_DELETE_CATEGORY_NAME);

    // タイトル文字列に書き換える
    Iterator<Integer> it = titleMap.keySet().iterator();
    String[] titleArray = new String[titleMap.size()];
    while (it.hasNext()) {
      Integer key = it.next();
      titleArray[key] = titleMap.get(key);
    }

    DATA_TITLE_ROW = titleArray;
    DATA_COLUMN_COUNT = DATA_TITLE_ROW.length;
  }

}
