package jp.co.unisys.enability.cis.business.rk.model;

import java.util.List;

/**
 * 計量器交換・臨時検針情報を格納するビジネスBean
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * 計量器交換・臨時検針情報照会ビジネス
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class McSmrInfoBusinessBean {

  /**
   * ファイル名を保有する。
   */
  private String fileName;

  /**
   * 地点の最大電力を保有する。
   */
  private String spotPkw;

  /**
   * 対象年月を保有する。
   */
  private String coveredPeriod;

  /**
   * 明細1リストを保有する。
   */
  private List<McSmrInfoDetail1BusinessBean> mcSmrInfoDetail1List;

  /**
   * ファイル名のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * ファイル名を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return ファイル名
   */
  public String getFileName() {
    return fileName;
  }

  /**
   * ファイル名のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * ファイル名を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param fileName
   *          ファイル名
   */
  public void setFileName(String fileName) {
    this.fileName = fileName;
  }

  /**
   * 地点の最大電力のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 地点の最大電力を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 地点の最大電力
   */
  public String getSpotPkw() {
    return spotPkw;
  }

  /**
   * 地点の最大電力のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 地点の最大電力を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param spotPkw
   *          地点の最大電力
   */
  public void setSpotPkw(String spotPkw) {
    this.spotPkw = spotPkw;
  }

  /**
   * 対象年月のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 対象年月を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 対象年月
   */
  public String getCoveredPeriod() {
    return coveredPeriod;
  }

  /**
   * 対象年月のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 対象年月を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param coveredPeriod
   *          対象年月
   */
  public void setCoveredPeriod(String coveredPeriod) {
    this.coveredPeriod = coveredPeriod;
  }

  /**
   * 明細1リストのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 明細1リストを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 明細1リスト
   */
  public List<McSmrInfoDetail1BusinessBean> getMcSmrInfoDetail1List() {
    return mcSmrInfoDetail1List;
  }

  /**
   * 明細1リストのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 明細1リストを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param mcSmrInfoDetail1List
   *          明細1リスト
   */
  public void setMcSmrInfoDetail1List(
      List<McSmrInfoDetail1BusinessBean> mcSmrInfoDetail1List) {
    this.mcSmrInfoDetail1List = mcSmrInfoDetail1List;
  }

}
