package jp.co.unisys.enability.cis.business.kj;

import jp.co.unisys.enability.cis.business.kj.model.Custom_AddCustomContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.Custom_DeleteCustomContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.Custom_InquiryCustomContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.Custom_UpdateCustomContractBusinessBean;

/**
 * カスタム 契約情報ビジネスインターフェース。
 *
 * @author "Nihon Unisys, Ltd."
 *
 *         変更履歴(kg-epj) 2016.02.17 liu 新規作成
 *
 */
public interface Custom_KJ_CustomContractInformationBusiness {

  /**
   * カスタム契約情報照会を行う。
   *
   * @author "Nihon Unisys, Ltd."
   * @param Custom_InquiryCustomContractBusinessBean
   *          カスタム契約情報照会BusinessBean
   * @return カスタム契約情報照会BusinessBean
   */
  public Custom_InquiryCustomContractBusinessBean inquiry(
      Custom_InquiryCustomContractBusinessBean inquiryCustomContractBusinessBean);

  /**
   * 契約情報更新を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 指定された契約情報を更新する。確定された料金実績が存在しているかどうかをチェックし、
   * 存在していた場合、更新不可とする。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param updateContractBusinessBean
   *          カスタム契約情報更新BusinessBean
   * @return カスタム契約情報更新BusinessBean
   */
  public Custom_UpdateCustomContractBusinessBean update(
      Custom_UpdateCustomContractBusinessBean updateContractBusinessBean);

  /**
   * 契約情報追加を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 既に契約をしているお客様が別需要場所で契約申込をする際に契約情報を追加登録する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param addContractBusinessBean
   *          カスタム契約情報追加BusinessBean
   * @return カスタム契約情報追加BusinessBean
   */
  public Custom_AddCustomContractBusinessBean add(
      Custom_AddCustomContractBusinessBean addContractBusinessBean);

  /**
   * 契約情報削除を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 指定契約IDのカスタム契約情報を削除する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param deleteContractBusinessBean
   *          カスタム契約情報削除BusinessBean
   * @return カスタム契約情報削除BusinessBean
   */
  public Custom_DeleteCustomContractBusinessBean delete(
      Custom_DeleteCustomContractBusinessBean deleteContractBusinessBean);

}
