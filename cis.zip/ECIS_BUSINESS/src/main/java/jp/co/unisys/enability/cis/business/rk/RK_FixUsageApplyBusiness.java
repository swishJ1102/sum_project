package jp.co.unisys.enability.cis.business.rk;

import java.util.Date;
import java.util.List;

import jp.co.unisys.enability.cis.business.rk.model.RK_FixUsageApplyDataBusinessBean;

/**
 * 確定使用量情報反映ビジネスインターフェース。
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.dao.rk.RK_FixUsageApplyDao
 * @see jp.co.unisys.enability.cis.business.rk.RK_FixUsageCommonBusiness
 * @see jp.co.unisys.enability.cis.mapper.common.FuMapper
 * @see jp.co.unisys.enability.cis.mapper.common.DemandResultMapper
 */
public interface RK_FixUsageApplyBusiness {

  /**
   * 使用量登録対象データを取得する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 確定使用量メッセージの取り込みを行うための情報を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param executeDate
   *          バッチ実行日
   * @return 取得した確定使用量情報のリスト
   * @see jp.co.unisys.enability.cis.dao.rk.RK_FixUsageApplyDao
   * @see jp.co.unisys.enability.cis.business.rk.RK_FixUsageCommonBusiness
   * @see jp.co.unisys.enability.cis.mapper.common.FuMapper
   * @see jp.co.unisys.enability.cis.mapper.common.DemandResultMapper
   */
  public abstract List<RK_FixUsageApplyDataBusinessBean> selectApplyData(
      Date executeDate);
}
