package jp.co.unisys.enability.cis.business.kj.model;

import java.util.Date;

/**
 * 契約電力算定処理BusinessBean
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 *  契約電力算定処理ビジネス
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class KJ_CalculationContractCapacityBusinessBean {

  /**
   * 契約IDを保有する。
   */
  private Integer contractId;

  /**
   * 対象年月を保有する。
   */
  private String coveredPeriod;

  /**
   * 算定期間開始日を保有する。
   */
  private Date chargeCalculationStartDate;

  /**
   * 実行機能区分コードを保有する。
   */
  private Integer implementFunctionCode;

  /**
   * リターンコードを保有する。
   */
  private String returnCode;

  /**
   * メッセージを保有する。
   */
  private String message;

  /**
   * 契約IDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約IDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約ID
   */
  public Integer getContractId() {
    return contractId;
  }

  /**
   * 契約IDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約IDを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractId
   *          契約ID
   */
  public void setContractId(Integer contractId) {
    this.contractId = contractId;
  }

  /**
   * 対象年月のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 対象年月を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 対象年月
   */
  public String getCoveredPeriod() {
    return coveredPeriod;
  }

  /**
   * 対象年月のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 対象年月を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param coveredPeriod
   *          対象年月
   */
  public void setCoveredPeriod(String coveredPeriod) {
    this.coveredPeriod = coveredPeriod;
  }

  /**
   * 算定期間開始日のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 算定期間開始日時を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 算定期間開始日
   */
  public Date getChargeCalculationStartDate() {
    return chargeCalculationStartDate;
  }

  /**
   * 算定期間開始日のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 算定期間開始日を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param chargeCalculationStartDate
   *          算定期間開始日
   */
  public void setChargeCalculationStartDate(Date chargeCalculationStartDate) {
    this.chargeCalculationStartDate = chargeCalculationStartDate;
  }

  /**
   * 実行機能区分コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 実行機能区分コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 実行機能区分コード
   */
  public Integer getImplementFunctionCode() {
    return implementFunctionCode;
  }

  /**
   * 実行機能区分コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 実行機能区分コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param implementFunctionCode
   *          実行機能区分コード
   */
  public void setImplementFunctionCode(Integer implementFunctionCode) {
    this.implementFunctionCode = implementFunctionCode;
  }

  /**
   * リターンコードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return リターンコード
   */
  public String getReturnCode() {
    return returnCode;
  }

  /**
   * リターンコードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param returnCode
   *          リターンコード
   */
  public void setReturnCode(String returnCode) {
    this.returnCode = returnCode;
  }

  /**
   * メッセージのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return メッセージ
   */
  public String getMessage() {
    return message;
  }

  /**
   * メッセージのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param message
   *          メッセージ
   */
  public void setMessage(String message) {
    this.message = message;
  }

}
