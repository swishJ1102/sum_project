package jp.co.unisys.enability.cis.business.rk;

import jp.co.unisys.enability.cis.business.rk.model.RK_SaleProceedsRelationItemCalcBusinessBean;

/**
 * 売上関連項目計算ビジネスインターフェース
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.rk.RK_ConsumptionTaxEquivalentCalcBusiness
 * @see jp.co.unisys.enability.cis.mapper.common.RmMapper
 * @see jp.co.unisys.enability.cis.mapper.common.CclMMapper
 * @see jp.co.unisys.enability.cis.mapper.common.DealClassMMapper
 */
public interface RK_SaleProceedsRelationItemCalcBusiness {

  /**
   * 売上関連項目の計算を行う。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数の情報をもとに、基本料金・従量料金等の売上関連項目の計算処理を行う。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param saleProceedsRelationItemCalcBusinessBean
   *          売上関連項目計算ビジネスBean
   * @throws Exception
   *           予期せぬエラーが発生した場合
   * @see jp.co.unisys.enability.cis.business.rk.RK_ConsumptionTaxEquivalentCalcBusiness
   * @see jp.co.unisys.enability.cis.mapper.common.RmMapper
   * @see jp.co.unisys.enability.cis.mapper.common.CclMMapper
   * @see jp.co.unisys.enability.cis.mapper.common.DealClassMMapper
   */
  void calculate(RK_SaleProceedsRelationItemCalcBusinessBean saleProceedsRelationItemCalcBusinessBean);
}
