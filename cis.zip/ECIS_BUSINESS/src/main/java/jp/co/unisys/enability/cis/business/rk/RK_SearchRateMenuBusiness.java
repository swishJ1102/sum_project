package jp.co.unisys.enability.cis.business.rk;

import jp.co.unisys.enability.cis.business.rk.model.RK_SearchRateMenuRateMenuConditionsBusinessBean;
import jp.co.unisys.enability.cis.business.rk.model.RK_SearchRateMenuSupplementaryMenuConditionsBusinessBean;

/**
 * 料金メニュー検索APIビジネスインターフェース。
 *
 * @author "Nihon Unisys, Ltd."
 */
public interface RK_SearchRateMenuBusiness {

  /**
   * 料金メニューの検索を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数の条件と一致する料金メニューを検索し、結果を返します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param rKSearchRateMenuRateMenuConditionsBusinessBean
   *          検索条件
   * @return 引数の条件と一致する料金メニューのリスト
   * @see jp.co.unisys.Dao.SearchRateMenuDao
   */
  RK_SearchRateMenuRateMenuConditionsBusinessBean selectRateMenu(
      RK_SearchRateMenuRateMenuConditionsBusinessBean rKSearchRateMenuRateMenuConditionsBusinessBean);

  /**
   * 付帯メニューの検索を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数の条件と一致する付帯メニューを検索し、結果を返します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param rKSearchRateMenuSupplementaryMenuConditionsBusinessBean
   *          検索条件
   * @return 引数の条件と一致する付帯メニューのリスト
   * @see jp.co.unisys.Dao.SearchRateMenuDao
   */
  RK_SearchRateMenuSupplementaryMenuConditionsBusinessBean selectSupplementaryMenu(
      RK_SearchRateMenuSupplementaryMenuConditionsBusinessBean rKSearchRateMenuSupplementaryMenuConditionsBusinessBean);
}
