package jp.co.unisys.enability.cis.business.sn;

import java.sql.Timestamp;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

import org.springframework.context.MessageSource;

import jp.co.unisys.enability.cis.business.common.TodoBusiness;
import jp.co.unisys.enability.cis.business.common.model.TodoBusinessBean;
import jp.co.unisys.enability.cis.common.Exception.BusinessLogicException;
import jp.co.unisys.enability.cis.common.Exception.SystemException;
import jp.co.unisys.enability.cis.common.util.StringConvertUtil;
import jp.co.unisys.enability.cis.common.util.ThreadContext;
import jp.co.unisys.enability.cis.common.util.constants.ECISCodeConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISTodoConstants;
import jp.co.unisys.enability.cis.entity.common.Bl;
import jp.co.unisys.enability.cis.entity.common.CorpAccountMngM;
import jp.co.unisys.enability.cis.entity.common.Deposit;
import jp.co.unisys.enability.cis.entity.common.PmCompanyM;
import jp.co.unisys.enability.cis.entity.common.PmCompanyMExample;
import jp.co.unisys.enability.cis.entity.common.Rr;
import jp.co.unisys.enability.cis.entity.common.RrNgReasonM;
import jp.co.unisys.enability.cis.entity.common.RrNgReasonMKey;
import jp.co.unisys.enability.cis.entity.common.UrgeMngExample;
import jp.co.unisys.enability.cis.entity.sn.SN_ReceiptBillingEntityBean;
import jp.co.unisys.enability.cis.mapper.common.BlMapper;
import jp.co.unisys.enability.cis.mapper.common.DepositMapper;
import jp.co.unisys.enability.cis.mapper.common.PmCompanyMMapper;
import jp.co.unisys.enability.cis.mapper.common.RrMapper;
import jp.co.unisys.enability.cis.mapper.common.RrNgReasonMMapper;
import jp.co.unisys.enability.cis.mapper.common.UrgeMngMapper;
import jp.co.unisys.enability.cis.mapper.gk.GK_WorkCommonMapper;
import jp.co.unisys.enability.cis.mapper.sn.SN_CreateDepositMapper;

/**
 * 請求入金共通入金作成ビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.sn.SN_BillingCommonBusiness
 * @see jp.co.unisys.enability.cis.mapper.common.BlMapper
 * @see jp.co.unisys.enability.cis.mapper.common.DepositMapper
 * @see jp.co.unisys.enability.cis.mapper.common.PmCompanyMMapper
 * @see jp.co.unisys.enability.cis.mapper.common.RrMapper
 * @see jp.co.unisys.enability.cis.mapper.common.RrNgReasonMMapper
 * @see jp.co.unisys.enability.cis.mapper.common.UrgeMngMapper
 * @see jp.co.unisys.enability.cis.mapper.common.FixChargeBlLinkageMapper
 * @see jp.co.unisys.enability.cis.mapper.gk.GK_WorkCommonMapper
 * @see jp.co.unisys.enability.cis.mapper.sn.SN_CreateDepositMapper
 * @see jp.co.unisys.enability.cis.business.common.TodoBusiness
 */
public class SN_CreateDepositBusinessImpl implements SN_CreateDepositBusiness {

  /** 請求入金共通ビジネス(DI) */
  private SN_BillingCommonBusiness snBillingCommonBusiness;

  /** 請求マッパー(DI) */
  private BlMapper blMapper;

  /** 入金マッパー(DI) */
  private DepositMapper depositMapper;

  /** 提供モデル企業マスタマッパー(DI) */
  private PmCompanyMMapper pmCompanyMMapper;

  /** 収納結果マッパー(DI) */
  private RrMapper rrMapper;

  /** 収納結果NG理由マスタマッパー(DI) */
  private RrNgReasonMMapper rrNgReasonMMapper;

  /** 督促管理マッパー(DI) */
  private UrgeMngMapper urgeMngMapper;

  /** 業務共通共通マッパー(DI) */
  private GK_WorkCommonMapper gkWorkCommonMapper;

  /** 請求入金共通入金作成共通マッパー(DI) */
  private SN_CreateDepositMapper snCreateDepositMapper;

  /** Todo共通ビジネス(DI) */
  private TodoBusiness todoBusiness;

  /** メッセージプロパティ(DI) */
  private MessageSource messageSource;

  /*
   * (非 Javadoc)
   * @see jp.co.unisys.enability.cis.business.sn.SN_CreateDepositBusiness#
   * createDepositForAccountTransferAndCredit(jp.co.unisys.enability.cis.entity.common.Rr, java.util.Date)
   */
  @Override
  public void createDepositForAccountTransferAndCredit(Rr rr, Date batchBaseDate) throws BusinessLogicException {

    // 収納先の請求情報取得（収納先請求情報取得処理呼び出し）
    SN_ReceiptBillingEntityBean snReceiptBillingEntityBean = this.selectReceiptBilling(rr);

    // 「収納結果NG」の判定と対応

    // 引数.《収納結果EntityBean》.NGフラグ ＝ “ON”の場合、
    if (ECISConstants.FLG_ON.equals(rr.getNgFlag())) {

      // NG理由を取得（収納結果NG理由マスタ取得処理呼び出し）
      RrNgReasonM rrNgReasonM = this.selectRrNgReasonM(rr);

      // 《収納先請求情報EntityBean》が取得できなかった場合、
      if (snReceiptBillingEntityBean == null) {

        // TODO登録（TODO登録処理（収納結果ファイル取込）呼び出し）
        //   収納結果NG、かつ収納先の請求が不明な収納が発生
        this.registTodo("todo.T1031", rr, rrNgReasonM, null, null);

        // 入金作成済フラグの更新（入金作成済フラグ更新処理呼び出し）
        this.updateDepositCreatedFlag(rr.getRrId(), null);

        // 処理を終了する。
        return;
      }

      // TODO登録（TODO登録処理（収納結果ファイル取込）呼び出し）
      //   収納結果NGの収納が発生
      this.registTodo("todo.T1007", rr, rrNgReasonM, snReceiptBillingEntityBean, null);

      // 取得した《収納先請求情報EntityBean》.請求ステータスコード ≠ “消込済”の場合
      if (!ECISCodeConstants.BILLING_STATUS_CODE_RECONCILE.equals(
          snReceiptBillingEntityBean.getBillingStatusCode())) {

        // 未収に伴う更新処理を呼び出す。
        snBillingCommonBusiness.updateReceiptRelation(
            snReceiptBillingEntityBean.getBillingId(),
            snReceiptBillingEntityBean.getBillingNo(),
            snReceiptBillingEntityBean.getContractorNo(),
            snReceiptBillingEntityBean.getPaymentId(),
            snReceiptBillingEntityBean.getUsePeriod(),
            snReceiptBillingEntityBean.getPreviousBlAddUpFlag(),
            ECISConstants.FLG_OFF,
            ECISTodoConstants.TODO_FUNCTION_ID.SN0201.toString());
      }

      // 入金作成済フラグの更新（入金作成済フラグ更新処理呼び出し）
      this.updateDepositCreatedFlag(rr.getRrId(), null);

      // 上記以外の場合（引数.《収納結果EntityBean》.NGフラグ ≠ “ON”）
    } else {

      // 《収納先請求情報EntityBean》が取得できなかった場合、
      if (snReceiptBillingEntityBean == null) {

        // 入金情報（不明入金）の登録（不明入金登録処理呼び出し）
        Integer depositId = this.registUnknownDeposit(rr);

        // TODO登録（TODO登録処理（収納結果ファイル取込）呼び出し）
        //   収納先の請求が不明な入金
        this.registTodo("todo.T1005", rr, null, null, null);

        // 入金作成済フラグの更新（入金作成済フラグ更新処理呼び出し）
        this.updateDepositCreatedFlag(rr.getRrId(), depositId);

        // 処理を終了する。
        return;
      }

      // 引数.《収納結果EntityBean》.収納金額 <> 取得した《収納先請求情報EntityBean》.請求額の場合
      if (!snReceiptBillingEntityBean.getBillingAmount().equals(rr.getReceiptAmount())) {

        // 不明入金登録処理呼び出し
        Integer depositId = this.registUnknownDeposit(rr);

        // TODO登録（TODO登録処理（収納結果ファイル取込）呼び出し）
        //   請求額と異なる入金
        this.registTodo("todo.T1010", null, null, snReceiptBillingEntityBean, null);

        // 入金作成済フラグの更新（入金作成済フラグ更新処理呼び出し）
        this.updateDepositCreatedFlag(rr.getRrId(), depositId);

        // 引数.《収納結果EntityBean》.収納金額 ＝ 取得した《収納先請求情報EntityBean》.請求額の場合
      } else {

        // 督促ステータスチェック呼び出し
        int cancellationDecisionCount = this.checkUrgeStatus(snReceiptBillingEntityBean);

        // 解約決定されている収納がある場合
        if (cancellationDecisionCount > 0) {

          // TODO登録（TODO登録処理（収納結果ファイル取込）呼び出し）
          //   解約決定されている請求への入金
          this.registTodo("todo.T1008", rr, null, snReceiptBillingEntityBean, null);
        }

        // 入金情報の登録（入金登録処理呼び出し）
        Integer depositId = this.registDeposit(rr, snReceiptBillingEntityBean);

        // 入金作成済フラグの更新（入金作成済フラグ更新処理呼び出し）
        this.updateDepositCreatedFlag(rr.getRrId(), depositId);
      }
    }
  }

  /*
   * (非 Javadoc)
   * @see jp.co.unisys.enability.cis.business.sn.SN_CreateDepositBusiness#
   * createDepositForConvenience(jp.co.unisys.enability.cis.entity.common.Rr, java.util.Date)
   */
  @Override
  public void createDepositForConvenience(Rr rr, Date batchBaseDate) {

    // 収納先の請求情報取得（収納先請求情報取得処理呼び出し）
    SN_ReceiptBillingEntityBean snReceiptBillingEntityBean = this.selectReceiptBilling(rr);

    // 引数.《収納結果EntityBean》.速報・確報区分コード ＝ “速報”の場合
    if (ECISCodeConstants.EARLY_FIX_NOTIFICATION_SEGMENT_CODE_EARLY.equals(rr.getEfnSegmentCode())) {

      // 《収納先請求情報EntityBean》が取得できなかった場合、
      if (snReceiptBillingEntityBean == null) {

        // 入金作成済フラグの更新（入金作成済フラグ更新処理呼び出し）
        this.updateDepositCreatedFlag(rr.getRrId(), null);

        // 処理を終了する
        return;

        // 《収納先請求情報EntityBean》が取得できた場合、
      } else {

        // 請求ステータスコード（“仮消込（速報）”）の更新（請求ステータスコード更新処理呼び出し）
        this.updateBillingStatusCode(rr, snReceiptBillingEntityBean);

        // 入金作成済フラグの更新（入金作成済フラグ更新処理呼び出し）
        this.updateDepositCreatedFlag(rr.getRrId(), null);

        // 処理を終了する
        return;
      }

      // 引数.《収納結果EntityBean》.速報・確報区分コード ＝ “速報取消”の場合
    } else if (ECISCodeConstants.EARLY_FIX_NOTIFICATION_SEGMENT_CODE_CANCEL.equals(rr.getEfnSegmentCode())) {

      // 《収納先請求情報EntityBean》が取得できなかった場合、
      if (snReceiptBillingEntityBean == null) {

        // 入金作成済フラグの更新（入金作成済フラグ更新処理呼び出し）
        this.updateDepositCreatedFlag(rr.getRrId(), null);

        // 処理を終了する
        return;

        // 《収納先請求情報EntityBean》が取得できた場合、
      } else {

        // 請求ステータスコード（“請求中”）の更新（請求ステータスコード更新処理呼び出し）
        this.updateBillingStatusCode(rr, snReceiptBillingEntityBean);

        // 入金作成済フラグの更新（入金作成済フラグ更新処理呼び出し）
        this.updateDepositCreatedFlag(rr.getRrId(), null);

        // 処理を終了する
        return;
      }

      // 引数.《収納結果EntityBean》.速報・確報区分コード ＝ “確報”の場合
    } else if (ECISCodeConstants.EARLY_FIX_NOTIFICATION_SEGMENT_CODE_FIX.equals(rr.getEfnSegmentCode())) {

      // 《収納先請求情報EntityBean》が取得できなかった場合、
      if (snReceiptBillingEntityBean == null) {

        // 入金情報（不明入金）の登録（不明入金登録処理呼び出し）
        Integer depositId = this.registUnknownDeposit(rr);

        // TODO登録（TODO登録処理（収納結果ファイル取込）呼び出し）
        //   収納先の請求が不明な入金
        this.registTodo("todo.T1005", rr, null, null, null);

        // 入金作成済フラグの更新（入金作成済フラグ更新処理呼び出し）
        this.updateDepositCreatedFlag(rr.getRrId(), depositId);

        // 処理を終了する。
        return;
      }

      // 引数.《収納結果EntityBean》.収納金額 <> 取得した《収納先請求情報EntityBean》.請求額の場合
      if (!snReceiptBillingEntityBean.getBillingAmount().equals(rr.getReceiptAmount())) {

        // 入金情報（不明入金）の登録（不明入金登録処理呼び出し）
        Integer depositId = this.registUnknownDeposit(rr);

        // TODO登録（TODO登録処理（収納結果ファイル取込）呼び出し）
        //   請求額と異なる入金
        this.registTodo("todo.T1010", null, null, snReceiptBillingEntityBean, null);

        // 入金作成済フラグの更新（入金作成済フラグ更新処理呼び出し）
        this.updateDepositCreatedFlag(rr.getRrId(), depositId);

        // 処理を終了する
        return;

        // 引数.《収納結果EntityBean》.収納金額 ＝ 取得した《収納先請求情報EntityBean》.請求額の場合
      } else {

        // 督促ステータスチェック呼び出し
        int cancellationDecisionCount = this.checkUrgeStatus(snReceiptBillingEntityBean);

        // 解約決定されている収納がある場合
        if (cancellationDecisionCount > 0) {

          // TODO登録（TODO登録処理（収納結果ファイル取込）呼び出し）
          //   解約決定されている請求への入金
          this.registTodo("todo.T1008", rr, null, snReceiptBillingEntityBean, null);
        }

        // 入金情報の登録（入金登録処理呼び出し）
        Integer depositId = this.registDeposit(rr, snReceiptBillingEntityBean);

        // 入金作成済フラグの更新（入金作成済フラグ更新処理呼び出し）
        this.updateDepositCreatedFlag(rr.getRrId(), depositId);

        // 処理を終了する
        return;
      }
    }
  }

  /*
   * (非 Javadoc)
   * @see jp.co.unisys.enability.cis.business.sn.SN_CreateDepositBusiness#createDepositForTransfer(
   * jp.co.unisys.enability.cis.entity.common.Rr, java.util.Date, java.util.List)
   */
  @Override
  public void createDepositForTransfer(Rr rr, Date batchBaseDate, List<CorpAccountMngM> corpAccountMngMList) {

    // 提供モデル企業マスタ取得（提供モデル企業マスタ取得処理呼び出し）
    List<PmCompanyM> pmCompanyMList = this.selectProvideModelMaster(rr);

    // 提供モデル企業マスタが取得できた場合、
    if (pmCompanyMList.size() > 0) {

      // 入金情報の登録（入金登録処理（卸／取次事業者）呼び出し）
      Integer depositId = this.registDepositForWholesaleAgencyOperator(rr, pmCompanyMList.get(0));

      // TODO登録（TODO登録処理（収納結果ファイル取込）呼び出し）
      //   卸／取次事業者からの入金
      this.registTodo("todo.T1006", rr, null, null, pmCompanyMList.get(0));

      // 入金作成済フラグの更新（入金作成済フラグ更新処理呼び出し）
      this.updateDepositCreatedFlag(rr.getRrId(), depositId);

      // 処理を終了する
      return;

      // 提供モデル企業マスタが取得できなかった場合、
    } else {

      // 自社口座への収納であるか判定する。
      for (CorpAccountMngM corpAccountMngM : corpAccountMngMList) {
        if (corpAccountMngM.getBankCode().equals(rr.getReceiptBankCode())
            && corpAccountMngM.getBankBranchCode().equals(rr.getReceiptBankBlanchCode())
            && corpAccountMngM.getBtOfAccountCode().equals(rr.getReceiptTypeOfAccountCode())
            && corpAccountMngM.getAccountNo().equals(rr.getReceiptAccountNo())) {

          // 不明入金登録処理呼び出し
          Integer depositId = this.registUnknownDeposit(rr);

          // TODO登録（TODO登録処理（収納結果ファイル取込）呼び出し）
          //   収納先の請求が不明な入金
          this.registTodo("todo.T1005", rr, null, null, null);

          // 入金作成済フラグの更新（入金作成済フラグ更新処理呼び出し）
          this.updateDepositCreatedFlag(rr.getRrId(), depositId);

          // 処理を終了する
          return;
        }
      }

      // 収納先の請求情報取得（収納先請求情報取得処理呼び出し）
      SN_ReceiptBillingEntityBean snReceiptBillingEntityBean = this.selectReceiptBilling(rr);

      // 《収納先請求情報EntityBean》が取得できなかった場合、
      if (snReceiptBillingEntityBean == null) {

        // 不明入金登録処理呼び出し
        Integer depositId = this.registUnknownDeposit(rr);

        // TODO登録（TODO登録処理（収納結果ファイル取込）呼び出し）
        //   収納先の請求が不明な入金
        this.registTodo("todo.T1005", rr, null, null, null);

        // 入金作成済フラグの更新（入金作成済フラグ更新処理呼び出し）
        this.updateDepositCreatedFlag(rr.getRrId(), depositId);

        // 処理を終了する
        return;

        // 《収納先請求情報EntityBean》が取得できた場合、
      } else {

        // 督促ステータスチェック呼び出し
        int cancellationDecisionCount = this.checkUrgeStatus(snReceiptBillingEntityBean);

        // 解約決定されている収納がある場合
        if (cancellationDecisionCount > 0) {

          // TODO登録（TODO登録処理（収納結果ファイル取込）呼び出し）
          //   解約決定されている請求への入金
          this.registTodo("todo.T1008", rr, null, snReceiptBillingEntityBean, null);
        }

        // 入金情報の登録（入金登録処理呼び出し）
        Integer depositId = this.registDeposit(rr, snReceiptBillingEntityBean);

        // 入金作成済フラグの更新（入金作成済フラグ更新処理呼び出し）
        this.updateDepositCreatedFlag(rr.getRrId(), depositId);

        // 処理を終了する
        return;
      }
    }
  }

  /*
   * (非 Javadoc)
   * @see jp.co.unisys.enability.cis.business.sn.SN_CreateDepositBusiness#
   * createDepositForCommissionCollectionClaim(jp.co.unisys.enability.cis.entity.common.Rr, java.util.Date)
   */
  @Override
  public String createDepositForCommissionCollectionClaim(Rr rr, Date batchBaseDate) {

    // 収納先の請求情報取得（収納先請求情報取得処理呼び出し）
    SN_ReceiptBillingEntityBean snReceiptBillingEntityBean = this
        .selectReceiptBillingForCommissionCollectionClaim(rr);

    // 《収納先請求情報EntityBean》が取得できなかった場合、
    if (snReceiptBillingEntityBean == null) {

      // 不明入金登録処理呼び出し
      Integer depositId = this.registUnknownDeposit(rr);

      // TODO登録（TODO登録処理（債権回収結果ファイル取込）呼び出し）
      //   対象となる債権回収依頼に無い入金があり
      this.registTodoForCommissionCollectionClaim("todo.T1001", rr, null);

      // 入金作成済フラグの更新（入金作成済フラグ更新処理呼び出し）
      this.updateDepositCreatedFlag(rr.getRrId(), depositId);

      // 処理を終了する。（NULLを返却）
      return null;
    }

    // 引数.《収納結果EntityBean》.収納金額 ＝ 取得した《収納先請求情報EntityBean》.請求額の場合
    if (snReceiptBillingEntityBean.getBillingAmount().equals(rr.getReceiptAmount())) {

      // 入金情報の登録（入金登録処理呼び出し）
      Integer depositId = this.registDeposit(rr, snReceiptBillingEntityBean);

      // 入金作成済フラグの更新（入金作成済フラグ更新処理呼び出し）
      this.updateDepositCreatedFlag(rr.getRrId(), depositId);

      // 備考の編集
      String noteMessage = messageSource.getMessage(
          "todo.T1042",
          new String[] {
              snReceiptBillingEntityBean.getContractorNo(),
              snReceiptBillingEntityBean.getContractorName1(),
              snReceiptBillingEntityBean.getContractorName2() == null
                  ? ""
                  : snReceiptBillingEntityBean.getContractorName2(),
              snReceiptBillingEntityBean.getBillingNo(),
              rr.getReceiptDate() == null ? ""
                  : StringConvertUtil.convertDateToString(
                      rr.getReceiptDate(), ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
              NumberFormat.getNumberInstance().format(snReceiptBillingEntityBean.getBillingAmount()),
              NumberFormat.getNumberInstance().format(rr.getReceiptAmount()) },
          Locale.getDefault());

      // 備考を返す
      return noteMessage;

      // 引数.《収納結果EntityBean》.収納金額 <> 取得した《収納先請求情報EntityBean》.請求額の場合
    } else {

      // 入金情報（不明入金）の登録（不明入金登録処理呼び出し）
      Integer depositId = this.registUnknownDeposit(rr);

      // TODO登録（TODO登録処理（債権回収結果ファイル取込）呼び出し）
      //   対象となる債権回収依頼に対して一致しない入金
      this.registTodoForCommissionCollectionClaim("todo.T1002", rr, snReceiptBillingEntityBean);

      // 入金作成済フラグの更新（入金作成済フラグ更新処理呼び出し）
      this.updateDepositCreatedFlag(rr.getRrId(), depositId);

      // 処理を終了する。（NULLを返却）
      return null;
    }
  }

  /**
   * 収納先請求情報取得処理
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 収納先の請求情報を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param rr
   *          収納結果EntityBean
   * @return 収納先請求情報EntityBean
   */
  private SN_ReceiptBillingEntityBean selectReceiptBilling(Rr rr) {

    // 収納先請求情報EntityBean
    SN_ReceiptBillingEntityBean snReceiptBillingEntityBean = null;

    // 条件Map生成
    Map<String, Object> selectReceiptBillingMap = new HashMap<String, Object>();

    // 請求ステータスコード生成
    List<String> blStatusCodeList = new ArrayList<>();

    // 振込フラグ
    String transferFlag = ECISConstants.FLG_OFF;

    // 《収納結果EntityBean》.収納区分コードが“口座振替”または“クレジット”の場合
    if (ECISCodeConstants.RS_CODE_CREDIT.equals(rr.getRsCode())
        || ECISCodeConstants.RS_CODE_ACCOUNT.equals(rr.getRsCode())) {

      // 条件Map設定（請求番号）
      selectReceiptBillingMap.put("blNo", rr.getBlNo());

      // 請求ステータスコード
      // “請求中”
      blStatusCodeList.add(ECISCodeConstants.BILLING_STATUS_CODE_BILLING);
      // “未収”
      blStatusCodeList.add(ECISCodeConstants.BILLING_STATUS_CODE_UNPAID);
      // “消込済”
      blStatusCodeList.add(ECISCodeConstants.BILLING_STATUS_CODE_RECONCILE);

      // 《収納結果EntityBean》.収納区分コードが“コンビニ”の場合
    } else if (ECISCodeConstants.RS_CODE_CONVENI.equals(rr.getRsCode())) {

      // 条件Map設定（請求番号）
      selectReceiptBillingMap.put("blNo", rr.getBlNo());

      // 《収納結果EntityBean》.速報・確報区分コード ＝ “速報”の場合
      if (ECISCodeConstants.EARLY_FIX_NOTIFICATION_SEGMENT_CODE_EARLY.equals(rr.getEfnSegmentCode())) {

        // 請求ステータスコード
        // “請求中”
        blStatusCodeList.add(ECISCodeConstants.BILLING_STATUS_CODE_BILLING);
        // “未収”
        blStatusCodeList.add(ECISCodeConstants.BILLING_STATUS_CODE_UNPAID);

        // 《収納結果EntityBean》.速報・確報区分コード ＝ “速報取消”の場合
      } else if (ECISCodeConstants.EARLY_FIX_NOTIFICATION_SEGMENT_CODE_CANCEL.equals(rr.getEfnSegmentCode())) {

        // 請求ステータスコード
        // “仮消込（速報）”
        blStatusCodeList.add(ECISCodeConstants.BILLING_STATUS_CODE_RECONCILE_PRELIMINARY_REPORT);

        // 《収納結果EntityBean》.速報・確報区分コード ＝ “確報”の場合
      } else if (ECISCodeConstants.EARLY_FIX_NOTIFICATION_SEGMENT_CODE_FIX.equals(rr.getEfnSegmentCode())) {

        // 請求ステータスコード
        // “仮消込（速報）”
        blStatusCodeList.add(ECISCodeConstants.BILLING_STATUS_CODE_RECONCILE_PRELIMINARY_REPORT);
        // “請求中”
        blStatusCodeList.add(ECISCodeConstants.BILLING_STATUS_CODE_BILLING);
        // “未収”
        blStatusCodeList.add(ECISCodeConstants.BILLING_STATUS_CODE_UNPAID);
        // “消込済”
        blStatusCodeList.add(ECISCodeConstants.BILLING_STATUS_CODE_RECONCILE);

        // 《収納結果EntityBean》.速報・確報区分コード が、上記以外の場合（不正）
      } else {

        // システム例外をスロー
        throw new SystemException(messageSource.getMessage(
            "error.E1389",
            new String[] {rr.getEfnSegmentCode() },
            Locale.getDefault()));
      }

      // 《収納結果EntityBean》.収納区分コードが“振込”の場合
    } else if (ECISCodeConstants.RS_CODE_TRANSFER.equals(rr.getRsCode())) {

      // 条件Map設定（収納金融機関コード）
      selectReceiptBillingMap.put("receiptBankCode", rr.getReceiptBankCode());
      // 条件Map設定（収納金融機関支店コード）
      selectReceiptBillingMap.put("receiptBankBlanchCode", rr.getReceiptBankBlanchCode());
      // 条件Map設定（収納金融機関預金種目コード）
      selectReceiptBillingMap.put("receiptTypeOfAccountCode", rr.getReceiptTypeOfAccountCode());
      // 条件Map設定（収納金融機関口座番号）
      selectReceiptBillingMap.put("receiptAccountNo", rr.getReceiptAccountNo());
      // 条件Map設定（請求額）
      selectReceiptBillingMap.put("receiptAmount", rr.getReceiptAmount());

      // 請求ステータスコード
      // “請求中”
      blStatusCodeList.add(ECISCodeConstants.BILLING_STATUS_CODE_BILLING);
      // “未収”
      blStatusCodeList.add(ECISCodeConstants.BILLING_STATUS_CODE_UNPAID);

      // 振込フラグ
      transferFlag = ECISConstants.FLG_ON;
    }

    // 条件Map設定（請求ステータスコード）
    selectReceiptBillingMap.put("blStatusCode", blStatusCodeList);
    // 条件Map設定（振込フラグ）
    selectReceiptBillingMap.put("transferFlag", transferFlag);

    // 収納先請求情報取得（請求入金共通入金作成Mapper.収納先請求情報取得呼び出し）
    List<SN_ReceiptBillingEntityBean> snReceiptBillingEntityBeanList = snCreateDepositMapper
        .selectReceiptBilling(selectReceiptBillingMap);

    if (snReceiptBillingEntityBeanList != null && snReceiptBillingEntityBeanList.size() > 0) {
      // 収納先請求情報が1件以上取得できた場合のみ、取得した収納先請求情報EntityBeanリストの先頭を返却する。
      snReceiptBillingEntityBean = snReceiptBillingEntityBeanList.get(0);
    }

    // 収納先請求情報EntityBean を返す
    return snReceiptBillingEntityBean;
  }

  /**
   * 収納先請求情報取得処理（債権回収依頼）
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 収納先の請求情報を取得する。（債権回収依頼用）
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param rr
   *          収納結果EntityBean
   * @return 収納先請求情報EntityBean
   */
  private SN_ReceiptBillingEntityBean selectReceiptBillingForCommissionCollectionClaim(Rr rr) {

    // 収納先請求情報EntityBean
    SN_ReceiptBillingEntityBean snReceiptBillingEntityBean = null;

    // 条件Map生成
    Map<String, Object> selectReceiptBillingMap = new HashMap<String, Object>();

    // 条件Map設定（請求番号）
    selectReceiptBillingMap.put("blNo", rr.getBlNo());

    // 条件Map設定（請求区分コード）
    selectReceiptBillingMap.put("blCatCode", rr.getRsCode());

    // 請求ステータスコード
    List<String> blStatusCodeList = new ArrayList<>();
    // “請求中”
    blStatusCodeList.add(ECISCodeConstants.BILLING_STATUS_CODE_BILLING);
    // “未収”
    blStatusCodeList.add(ECISCodeConstants.BILLING_STATUS_CODE_UNPAID);

    // 条件Map設定（請求ステータスコード）
    selectReceiptBillingMap.put("blStatusCode", blStatusCodeList);

    // 収納先請求情報取得（請求入金共通入金作成マッパー.収納先請求情報取得（債権回収依頼）呼び出し）
    snReceiptBillingEntityBean = snCreateDepositMapper
        .selectReceiptBillingForCommissionCollectionClaim(selectReceiptBillingMap);

    // 収納先請求情報EntityBean を返す
    return snReceiptBillingEntityBean;
  }

  /**
   * 収納結果NG理由マスタ取得処理
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 収納結果NG理由マスタよりNG理由を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param rr
   *          収納結果EntityBean
   * @return 収納結果NG理由マスタEntityBean
   */
  private RrNgReasonM selectRrNgReasonM(Rr rr) {

    // 収納結果NG理由マスタ
    RrNgReasonM rrNgReasonM = null;

    // 《収納結果NG理由マスタEntityBean》生成
    RrNgReasonMKey rrNgReasonMKey = new RrNgReasonMKey();

    // 収納区分コード
    rrNgReasonMKey.setRsCode(rr.getRsCode());
    // NG理由コード
    rrNgReasonMKey.setNgReasonCode(rr.getNgReasonCode());

    // 収納結果NG理由マスタDao.検索（主キー）呼び出し
    rrNgReasonM = rrNgReasonMMapper.selectByPrimaryKey(rrNgReasonMKey);

    // 収納結果NG理由マスタが取得できなかった場合は、システム例外をスロー
    if (rrNgReasonM == null) {
      throw new SystemException(messageSource.getMessage(
          "error.E1386",
          new String[] {
              rr.getRsCode(),
              rr.getNgReasonCode() },
          Locale.getDefault()));
    }

    // 収納結果NG理由マスタ を返す
    return rrNgReasonM;
  }

  /**
   * TODO登録処理（収納結果ファイル取込）
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * TODOへの登録を行う。（収納結果ファイル取込用）
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param messageId
   *          メッセージID
   * @param rr
   *          収納結果EntityBean
   * @param rrNgReasonM
   *          収納結果NG理由マスタEntityBean
   * @param snReceiptBillingEntityBean
   *          収納先請求情報EntityBean
   * @param pmCompanyM
   *          提供モデル企業マスタEntityBean
   */
  private void registTodo(
      String messageId,
      Rr rr,
      RrNgReasonM rrNgReasonM,
      SN_ReceiptBillingEntityBean snReceiptBillingEntityBean,
      PmCompanyM pmCompanyM) {

    // TODO用メッセージ
    String todoMessage = null;

    // todo.T1031(収納結果NG、かつ収納先の請求が不明な収納が発生)
    if ("todo.T1031".equals(messageId)) {

      // TODO用メッセージ
      todoMessage = messageSource.getMessage(
          messageId,
          new String[] {
              rr.getBlNo(),
              rr.getNgReasonCode(),
              rrNgReasonM.getNgReason() },
          Locale.getDefault());

      // todo.T1007（収納結果NGの収納が発生）
    } else if ("todo.T1007".equals(messageId)) {

      // TODO用メッセージ
      todoMessage = messageSource.getMessage(
          messageId,
          new String[] {
              rr.getBlNo(),
              rr.getNgReasonCode(),
              rrNgReasonM.getNgReason() },
          Locale.getDefault());

      // todo.T1009（督促対象とならない契約者への請求が”未収”）
    } else if ("todo.T1009".equals(messageId)) {

      // TODO用メッセージ
      todoMessage = messageSource.getMessage(
          messageId,
          new String[] {
              snReceiptBillingEntityBean.getBillingNo(),
              snReceiptBillingEntityBean.getContractorNo() },
          Locale.getDefault());

      // todo.T1005（収納先の請求が不明な入金）
    } else if ("todo.T1005".equals(messageId)) {

      // TODO用メッセージ
      todoMessage = messageSource.getMessage(
          messageId,
          new String[] {
              rr.getReceiptAccountNo(),
              rr.getBlNo(),
              NumberFormat.getNumberInstance().format(rr.getReceiptAmount()),
              rr.getReceiptDate() == null ? ""
                  : StringConvertUtil.convertDateToString(
                      rr.getReceiptDate(), ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
              rr.getRsCode(),
              rr.getTsbNameHwk(),
              rr.getTsbBranchNameHwk(),
              rr.getTransferClientNameHwk() },
          Locale.getDefault());

      // todo.T1010（請求額と異なる入金）
    } else if ("todo.T1010".equals(messageId)) {

      // TODO用メッセージ
      todoMessage = messageSource.getMessage(
          messageId,
          new String[] {
              snReceiptBillingEntityBean.getContractorNo(),
              snReceiptBillingEntityBean.getBillingNo(),
              StringConvertUtil.convertDateObjectToString(
                  snReceiptBillingEntityBean.getUsePeriod(),
                  ECISConstants.FORMAT_DATE_yyyyMM,
                  ECISConstants.FORMAT_DATE_yyyyMM_SLASH) },
          Locale.getDefault());

      // todo.T1008（解約決定されている請求への入金）
    } else if ("todo.T1008".equals(messageId)) {

      // TODO用メッセージ
      todoMessage = messageSource.getMessage(
          messageId,
          new String[] {
              snReceiptBillingEntityBean.getBillingNo(),
              NumberFormat.getNumberInstance().format(rr.getReceiptAmount()),
              rr.getReceiptDate() == null ? ""
                  : StringConvertUtil.convertDateToString(
                      rr.getReceiptDate(), ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH) },
          Locale.getDefault());

      // todo.T1006（卸／取次事業者からの入金）
    } else if ("todo.T1006".equals(messageId)) {

      // TODO用メッセージ
      todoMessage = messageSource.getMessage(
          messageId,
          new String[] {
              pmCompanyM.getPmCompanyCode(),
              rr.getReceiptAccountNo(),
              rr.getReceiptBankCode(),
              rr.getReceiptBankBlanchCode(),
              rr.getReceiptTypeOfAccountCode(),
              rr.getTransferClientNameHwk(),
              NumberFormat.getNumberInstance().format(rr.getReceiptAmount()),
              rr.getReceiptDate() == null ? ""
                  : StringConvertUtil.convertDateToString(
                      rr.getReceiptDate(), ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
              rr.getDepositScheduledDate() == null ? ""
                  : StringConvertUtil.convertDateToString(
                      rr.getDepositScheduledDate(), ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH) },
          Locale.getDefault());
    }
    // 《TODOビジネスBean》生成
    TodoBusinessBean todoBusinessBean = new TodoBusinessBean();

    // サブシステムID
    todoBusinessBean.setSubsystemId(ECISConstants.SUBSYSTEM_ID_SN);
    // 機能ID
    todoBusinessBean.setFunctionId(ECISTodoConstants.TODO_FUNCTION_ID.SN0201.toString());
    // メッセージID
    todoBusinessBean.setMessageId(messageId);
    // メッセージ設定
    todoBusinessBean.setMessage(todoMessage);
    // todo.T1007（収納結果NGの収納が発生）
    if ("todo.T1007".equals(messageId)) {
      todoBusinessBean.setContractorNo(Objects.isNull(snReceiptBillingEntityBean) ? null
          : snReceiptBillingEntityBean.getContractorNo());
    }

    // TODO登録実行
    todoBusiness.registTodo(todoBusinessBean);
  }

  /**
   * TODO登録処理（債権回収結果ファイル取込）
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * TODOへの登録を行う。（債権回収結果ファイル取込用）
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param messageId
   *          メッセージID
   * @param rr
   *          収納結果EntityBean
   * @param snReceiptBillingEntityBean
   *          収納先請求情報EntityBean
   */
  private void registTodoForCommissionCollectionClaim(
      String messageId,
      Rr rr,
      SN_ReceiptBillingEntityBean snReceiptBillingEntityBean) {

    // TODO用メッセージ
    String todoMessage = null;

    // todo.T1001（対象となる債権回収依頼に無い入金があり）
    if ("todo.T1001".equals(messageId)) {

      // TODO用メッセージ
      todoMessage = messageSource.getMessage(
          messageId,
          new String[] {
              rr.getBlNo(),
              rr.getReceiptDate() == null ? ""
                  : StringConvertUtil.convertDateToString(
                      rr.getReceiptDate(), ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
              rr.getReceiptAmount() == null
                  ? ""
                  : NumberFormat.getNumberInstance().format(rr.getReceiptAmount()), },
          Locale.getDefault());

      // todo.T1002（対象となる債権回収依頼に対して一致しない入金）
    } else if ("todo.T1002".equals(messageId)) {

      // TODO用メッセージ
      todoMessage = messageSource.getMessage(
          messageId,
          new String[] {
              rr.getBlNo(),
              rr.getReceiptDate() == null ? ""
                  : StringConvertUtil.convertDateToString(
                      rr.getReceiptDate(), ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
              NumberFormat.getNumberInstance().format(snReceiptBillingEntityBean.getBillingAmount()),
              rr.getReceiptAmount() == null
                  ? ""
                  : NumberFormat.getNumberInstance().format(rr.getReceiptAmount()), },
          Locale.getDefault());
    }

    // 《TODOビジネスBean》生成
    TodoBusinessBean todoBusinessBean = new TodoBusinessBean();

    // サブシステムID
    todoBusinessBean.setSubsystemId(ECISConstants.SUBSYSTEM_ID_SN);
    // 機能ID
    todoBusinessBean.setFunctionId(ECISTodoConstants.TODO_FUNCTION_ID.SN0202.toString());
    // メッセージID
    todoBusinessBean.setMessageId(messageId);
    // メッセージ設定
    todoBusinessBean.setMessage(todoMessage);

    // TODO登録実行
    todoBusiness.registTodo(todoBusinessBean);
  }

  /**
   * 請求ステータスコード更新処理
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 収納結果に応じた、請求ステータスに更新する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param rr
   *          収納結果EntityBean
   * @param snReceiptBillingEntityBean
   *          収納先請求情報EntityBean
   */
  private void updateBillingStatusCode(Rr rr, SN_ReceiptBillingEntityBean snReceiptBillingEntityBean) {

    // 《請求EntityBean》生成
    Bl bl = new Bl();

    // 請求ID
    bl.setBlId(snReceiptBillingEntityBean.getBillingId());

    // 請求ステータスコード
    // 引数.《収納結果EntityBean》.速報・確報区分コード ＝ “速報”の場合
    if (ECISCodeConstants.EARLY_FIX_NOTIFICATION_SEGMENT_CODE_EARLY.equals(rr.getEfnSegmentCode())) {

      // 請求ステータスコード（“仮消込（速報）”）
      bl.setBlStatusCode(ECISCodeConstants.BILLING_STATUS_CODE_RECONCILE_PRELIMINARY_REPORT);

      // 引数.《収納結果EntityBean》.速報・確報区分コード ＝ “速報取消”の場合
    } else if (ECISCodeConstants.EARLY_FIX_NOTIFICATION_SEGMENT_CODE_CANCEL.equals(rr.getEfnSegmentCode())) {

      // 請求ステータスコード（“請求中”）
      bl.setBlStatusCode(ECISCodeConstants.BILLING_STATUS_CODE_BILLING);
    }

    // 更新日時
    bl.setUpdateTime(new Timestamp(System.currentTimeMillis()));
    // 更新モジュールコード
    bl.setUpdateModuleCode(
        ThreadContext.getRequestThreadContext().get(ECISConstants.CLASS_NAME_KEY).toString());

    // 請求UPDATE（請求Dao.選択項目更新（主キー）呼び出し）
    blMapper.updateByPrimaryKeySelective(bl);
  }

  /**
   * 提供モデル企業マスタ取得処理
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 提供モデル企業マスタを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param rr
   *          収納結果EntityBean
   * @return 提供モデル企業マスタEntityBeanリスト
   */
  private List<PmCompanyM> selectProvideModelMaster(Rr rr) {

    // 《提供モデル企業マスタEntityBean》生成
    PmCompanyMExample pmCompanyMExample = new PmCompanyMExample();

    pmCompanyMExample.createCriteria()
        .andPmCodeNotEqualTo(ECISCodeConstants.PROVIDE_MODEL_CODE_DIRECT_MANAGEMENT)
        .andAllotmentBankCodeEqualTo(rr.getReceiptBankCode())
        .andAllotmentBankBranchCodeEqualTo(rr.getReceiptBankBlanchCode())
        .andAllotmentBtOfAccountCodeEqualTo(rr.getReceiptTypeOfAccountCode())
        .andAaNoEqualTo(rr.getReceiptAccountNo())
        .andEffectiveSdLessThanOrEqualTo(rr.getReceiptDate())
        .andEffectiveEdGreaterThanOrEqualTo(rr.getReceiptDate());

    // 提供モデル企業マスタSELECT（提供モデル企業マスタ.selectByExample呼び出し）
    List<PmCompanyM> pmCompanyMList = pmCompanyMMapper.selectByExample(pmCompanyMExample);

    // 提供モデル企業マスタ を返す
    return pmCompanyMList;
  }

  /**
   * 入金登録処理（卸／取次事業者）
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 「卸／取次事業者」からの収納結果の内容を【入金】に登録する。
   * また登録した際の入金IDを呼び元に返す。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param rr
   *          収納結果EntityBean
   * @param pmCompanyM
   *          提供モデル企業マスタEntityBean
   * @return 入金ID
   */
  private Integer registDepositForWholesaleAgencyOperator(
      Rr rr, PmCompanyM pmCompanyM) {

    // 入金IDの採番
    Map<String, Object> excessExampleMap = new HashMap<String, Object>();
    excessExampleMap.put("sqName", ECISConstants.SEQUENCE_NAME_DEPOSIT_ID);
    Integer depositId = gkWorkCommonMapper.selectSequenceId(excessExampleMap);

    // 作成日時、更新日時
    Timestamp wTimestamp = new Timestamp(System.currentTimeMillis());

    // 《入金EntityBean》生成
    Deposit deposit = new Deposit();
    // 入金ID
    deposit.setDepositId(depositId);
    // 提供モデルコード
    deposit.setPmCode(pmCompanyM.getPmCode());
    // 提供モデル企業コード
    deposit.setPmCompanyCode(pmCompanyM.getPmCompanyCode());
    // 収納日
    deposit.setReceiptDate(rr.getReceiptDate());
    // 入金日
    deposit.setDepositDate(rr.getDepositScheduledDate());
    // 入金ステータスコード（“収納”）
    deposit.setDepositStatusCode(ECISCodeConstants.DEPOSIT_STATUS_CODE_RECEIPT);
    // 金額
    deposit.setAmount(rr.getReceiptAmount());
    // 収納結果コード（“正常収納”）
    deposit.setRrCode(ECISCodeConstants.RR_CODE_NOMAL_RECEIPT);
    // 収納区分コード
    deposit.setRsCode(rr.getRsCode());
    // 振込元金融機関名（半角カナ）
    deposit.setTsbNameHwk(rr.getTsbNameHwk());
    // 振込元金融機関支店名（半角カナ）
    deposit.setTsbBranchNameHwk(rr.getTsbBranchNameHwk());
    // 振込依頼者名（半角カナ）
    deposit.setTransferClientNameHwk(rr.getTransferClientNameHwk());
    // 収納金融機関コード
    deposit.setReceiptBankCode(rr.getReceiptBankCode());
    // 収納金融機関支店コード
    deposit.setReceiptBankBlanchCode(rr.getReceiptBankBlanchCode());
    // 収納金融機関預金種目コード
    deposit.setReceiptTypeOfAccountCode(rr.getReceiptTypeOfAccountCode());
    // 収納金融機関口座番号
    deposit.setReceiptAccountNo(rr.getReceiptAccountNo());
    // 完了フラグ
    deposit.setCompletedFlag(ECISConstants.FLG_OFF);
    // 更新回数
    deposit.setUpdateCount(0);
    // 作成日時
    deposit.setCreateTime(wTimestamp);
    // 更新日時
    deposit.setUpdateTime(wTimestamp);
    // 更新モジュールコード
    deposit.setUpdateModuleCode(
        ThreadContext.getRequestThreadContext().get(ECISConstants.CLASS_NAME_KEY).toString());

    // 入金INSERT（入金Dao.選択項目挿入呼び出し）
    depositMapper.insertSelective(deposit);

    // 入金ID を返す
    return depositId;
  }

  /**
   * 不明入金登録処理
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 収納結果の収納先の【請求】が特定できなかった、又は請求額と異なる入金があった場合、
   * 収納結果の内容を“不明入金”として【入金】に登録する。
   * また登録した際の入金IDを呼び元に返す。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param rr
   *          収納結果EntityBean
   * @return 入金ID
   */
  private Integer registUnknownDeposit(Rr rr) {

    // 入金IDの採番
    Map<String, Object> excessExampleMap = new HashMap<String, Object>();
    excessExampleMap.put("sqName", ECISConstants.SEQUENCE_NAME_DEPOSIT_ID);
    Integer depositId = gkWorkCommonMapper.selectSequenceId(excessExampleMap);

    // 作成日時、更新日時
    Timestamp wTimestamp = new Timestamp(System.currentTimeMillis());

    // 《入金EntityBean》生成
    Deposit deposit = new Deposit();
    // 入金ID
    deposit.setDepositId(depositId);
    // 収納日
    deposit.setReceiptDate(rr.getReceiptDate());
    // 入金日
    deposit.setDepositDate(rr.getDepositScheduledDate());
    // 入金ステータスコード（“不明入金”）
    deposit.setDepositStatusCode(ECISCodeConstants.DEPOSIT_STATUS_CODE_UNKNOWN_DEPOSIT);
    // 金額
    deposit.setAmount(rr.getReceiptAmount());
    // 収納結果コード（“未処理”）
    deposit.setRrCode(ECISCodeConstants.RR_CODE_NON_EXECUTE);
    // 収納区分コード
    deposit.setRsCode(rr.getRsCode());
    // 振込元金融機関名（半角カナ）
    deposit.setTsbNameHwk(rr.getTsbNameHwk());
    // 振込元金融機関支店名（半角カナ）
    deposit.setTsbBranchNameHwk(rr.getTsbBranchNameHwk());
    // 振込依頼者名（半角カナ）
    deposit.setTransferClientNameHwk(rr.getTransferClientNameHwk());
    // 収納金融機関コード
    deposit.setReceiptBankCode(rr.getReceiptBankCode());
    // 収納金融機関支店コード
    deposit.setReceiptBankBlanchCode(rr.getReceiptBankBlanchCode());
    // 収納金融機関預金種目コード
    deposit.setReceiptTypeOfAccountCode(rr.getReceiptTypeOfAccountCode());
    // 収納金融機関口座番号
    deposit.setReceiptAccountNo(rr.getReceiptAccountNo());
    // 完了フラグ
    deposit.setCompletedFlag(ECISConstants.FLG_OFF);
    // 更新回数
    deposit.setUpdateCount(0);
    // 作成日時
    deposit.setCreateTime(wTimestamp);
    // 更新日時
    deposit.setUpdateTime(wTimestamp);
    // 更新モジュールコード
    deposit.setUpdateModuleCode(
        ThreadContext.getRequestThreadContext().get(ECISConstants.CLASS_NAME_KEY).toString());

    // 入金INSERT（入金Dao.選択項目挿入呼び出し）
    depositMapper.insertSelective(deposit);

    // 入金ID を返す
    return depositId;
  }

  /**
   * 督促ステータスチェック
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 収納先の請求が、既に解約決定されているかチェックする。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param snReceiptBillingEntityBean
   *          収納先請求情報EntityBean
   * @return 検索結果件数
   */
  private int checkUrgeStatus(SN_ReceiptBillingEntityBean snReceiptBillingEntityBean) {

    // 《督促管理EntityBean》生成
    UrgeMngExample urgeMngExample = new UrgeMngExample();

    urgeMngExample.createCriteria()
        .andCpBlIdEqualTo(snReceiptBillingEntityBean.getBillingId())
        .andUrgeStatusCodeEqualTo(ECISCodeConstants.URGE_STATUS_CODE_CANCELLATION_DECISION);

    // 解約決定件数SELECT（督促管理Dao.件数検索呼び出し）
    int cancellationDecisionCount = urgeMngMapper.countByExample(urgeMngExample);

    // 検索結果件数 を返す
    return cancellationDecisionCount;
  }

  /**
   * 入金登録処理
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 収納先の【請求】が特定できた収納結果の内容を【入金】に登録する。
   * また登録した際の入金IDを呼び元に返す。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param rr
   *          収納結果EntityBean
   * @param snReceiptBillingEntityBean
   *          収納先請求情報EntityBean
   * @return 入金ID
   */
  private Integer registDeposit(Rr rr, SN_ReceiptBillingEntityBean snReceiptBillingEntityBean) {

    // 入金IDの採番
    Map<String, Object> excessExampleMap = new HashMap<String, Object>();
    excessExampleMap.put("sqName", ECISConstants.SEQUENCE_NAME_DEPOSIT_ID);
    Integer depositId = gkWorkCommonMapper.selectSequenceId(excessExampleMap);

    // 作成日時、更新日時
    Timestamp wTimestamp = new Timestamp(System.currentTimeMillis());

    // 《入金EntityBean》生成
    Deposit deposit = new Deposit();
    // 入金ID
    deposit.setDepositId(depositId);
    // 消込先請求番号
    deposit.setRccBlNo(snReceiptBillingEntityBean.getBillingNo());
    // 契約者ID
    deposit.setContractorId(snReceiptBillingEntityBean.getContractorId());
    // 契約者番号
    deposit.setContractorNo(snReceiptBillingEntityBean.getContractorNo());
    // 取引先コード
    deposit.setCustomerCode(snReceiptBillingEntityBean.getCustomerCode());
    // 提供モデルコード
    deposit.setPmCode(snReceiptBillingEntityBean.getProvideModelCode());
    // 提供モデル企業コード
    deposit.setPmCompanyCode(snReceiptBillingEntityBean.getProvideModelCompanyCode());
    // 収納日
    deposit.setReceiptDate(rr.getReceiptDate());
    // 入金日
    deposit.setDepositDate(rr.getDepositScheduledDate());
    // 入金ステータスコード（“収納”）
    deposit.setDepositStatusCode(ECISCodeConstants.DEPOSIT_STATUS_CODE_RECEIPT);
    // 金額
    deposit.setAmount(rr.getReceiptAmount());
    // 収納結果コード（“未処理”）
    deposit.setRrCode(ECISCodeConstants.RR_CODE_NON_EXECUTE);
    // 収納区分コード
    deposit.setRsCode(rr.getRsCode());
    // 振込元金融機関名（半角カナ）
    deposit.setTsbNameHwk(rr.getTsbNameHwk());
    // 振込元金融機関支店名（半角カナ）
    deposit.setTsbBranchNameHwk(rr.getTsbBranchNameHwk());
    // 振込依頼者名（半角カナ）
    deposit.setTransferClientNameHwk(rr.getTransferClientNameHwk());
    // 収納金融機関コード
    deposit.setReceiptBankCode(rr.getReceiptBankCode());
    // 収納金融機関支店コード
    deposit.setReceiptBankBlanchCode(rr.getReceiptBankBlanchCode());
    // 収納金融機関預金種目コード
    deposit.setReceiptTypeOfAccountCode(rr.getReceiptTypeOfAccountCode());
    // 収納金融機関口座番号
    deposit.setReceiptAccountNo(rr.getReceiptAccountNo());
    // 完了フラグ
    deposit.setCompletedFlag(ECISConstants.FLG_OFF);
    // 更新回数
    deposit.setUpdateCount(0);
    // 作成日時
    deposit.setCreateTime(wTimestamp);
    // 更新日時
    deposit.setUpdateTime(wTimestamp);
    // 更新モジュールコード
    deposit.setUpdateModuleCode(
        ThreadContext.getRequestThreadContext().get(ECISConstants.CLASS_NAME_KEY).toString());

    // 入金INSERT（入金Dao.選択項目挿入呼び出し）
    depositMapper.insertSelective(deposit);

    // 入金ID を返す
    return depositId;
  }

  /**
   * 入金作成済フラグ更新
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 入金作成処理を行った【収納結果】を処理済みに更新する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param receiptResultId
   *          収納結果ID
   * @param depositId
   *          入金ID
   */
  private void updateDepositCreatedFlag(Integer receiptResultId, Integer depositId) {

    // 《収納結果EntityBean》生成
    Rr rr = new Rr();

    // 収納結果ID
    rr.setRrId(receiptResultId);
    // 入金ID
    rr.setDepositId(depositId);
    // 入金作成済フラグ（入金作成処理済み）
    rr.setDepositCreatedFlag(ECISConstants.FLG_ON);
    // 更新日時
    rr.setUpdateTime(new Timestamp(System.currentTimeMillis()));
    // 更新モジュールコード
    rr.setUpdateModuleCode(ThreadContext.getRequestThreadContext().get(ECISConstants.CLASS_NAME_KEY).toString());

    // 収納結果UPDATE（収納結果Dao.選択項目更新（主キー）呼び出し）
    rrMapper.updateByPrimaryKeySelective(rr);
  }

  /**
   * 請求入金共通ビジネスを設定する。(DI)
   *
   * @param snBillingCommonBusiness
   *          請求入金共通ビジネス
   */
  public void setSnBillingCommonBusiness(
      SN_BillingCommonBusiness snBillingCommonBusiness) {
    this.snBillingCommonBusiness = snBillingCommonBusiness;
  }

  /**
   * 請求マッパーを設定する。(DI)
   *
   * @param blMapper
   *          請求マッパー
   */
  public void setBlMapper(
      BlMapper blMapper) {
    this.blMapper = blMapper;
  }

  /**
   * 入金マッパーを設定する。(DI)
   *
   * @param depositMapper
   *          入金マッパー
   */
  public void setDepositMapper(
      DepositMapper depositMapper) {
    this.depositMapper = depositMapper;
  }

  /**
   * 提供モデル企業マスタマッパーを設定する。(DI)
   *
   * @param pmCompanyMMapper
   *          提供モデル企業マスタマッパー
   */
  public void setPmCompanyMMapper(
      PmCompanyMMapper pmCompanyMMapper) {
    this.pmCompanyMMapper = pmCompanyMMapper;
  }

  /**
   * 収納結果マッパーを設定する。(DI)
   *
   * @param rrMapper
   *          収納結果マッパー
   */
  public void setRrMapper(
      RrMapper rrMapper) {
    this.rrMapper = rrMapper;
  }

  /**
   * 収納結果NG理由マスタマッパーを設定する。(DI)
   *
   * @param rrNgReasonMMapper
   *          収納結果NG理由マスタマッパー
   */
  public void setRrNgReasonMMapper(
      RrNgReasonMMapper rrNgReasonMMapper) {
    this.rrNgReasonMMapper = rrNgReasonMMapper;
  }

  /**
   * 督促管理マッパーを設定する。(DI)
   *
   * @param urgeMngMapper
   *          督促管理マッパー
   */
  public void setUrgeMngMapper(
      UrgeMngMapper urgeMngMapper) {
    this.urgeMngMapper = urgeMngMapper;
  }

  /**
   * 業務共通共通マッパーを設定する。（DI）
   *
   * @param gkWorkCommonMapper
   *          業務共通共通マッパー
   */
  public void setGkWorkCommonMapper(
      GK_WorkCommonMapper gkWorkCommonMapper) {
    this.gkWorkCommonMapper = gkWorkCommonMapper;
  }

  /**
   * 請求入金共通入金作成共通マッパーを設定する。(DI)
   *
   * @param snCreateDepositMapper
   *          請求入金共通入金作成共通マッパー
   */
  public void setSnCreateDepositMapper(
      SN_CreateDepositMapper snCreateDepositMapper) {
    this.snCreateDepositMapper = snCreateDepositMapper;
  }

  /**
   * Todo共通ビジネスを設定する。(DI)
   *
   * @param todoBusiness
   *          Todo共通ビジネス
   */
  public void setTodoBusiness(
      TodoBusiness todoBusiness) {
    this.todoBusiness = todoBusiness;
  }

  /**
   * メッセージプロパティを設定する。(DI)
   *
   * @param messageSource
   *          メッセージプロパティ
   */
  public void setMessageSource(
      MessageSource messageSource) {
    this.messageSource = messageSource;
  }

}
