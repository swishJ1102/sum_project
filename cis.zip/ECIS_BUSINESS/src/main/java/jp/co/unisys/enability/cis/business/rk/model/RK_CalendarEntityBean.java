package jp.co.unisys.enability.cis.business.rk.model;

/**
 * カレンダー情報を保持するEntityBean。
 * 
 * <pre>
* 料金確定共通Dao。
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_CalendarEntityBean {

  /**
   * 祝祭日フラグを保有する。
   */
  private Integer publicHolidayFlag;

  /**
   * 事業者休日フラグを保有する。
   */
  private Integer operatorHolidayFlag;

  /**
   * 金融機関休日フラグを保有する。
   */
  private Integer bankHolidayFlag;

  /**
   * 北海道エリア休日フラグを保有する。
   */
  private Integer hokkaidoAreaHolidayFlag;

  /**
   * 東北エリア休日フラグを保有する。
   */
  private Integer tohokuAreaHolidayFlag;

  /**
   * 東京エリア休日フラグを保有する。
   */
  private Integer tokyoAreaHolidayFlag;

  /**
   * 中部エリア休日フラグを保有する。
   */
  private Integer chubuAreaHolidayFlag;

  /**
   * 北陸エリア休日フラグを保有する。
   */
  private Integer hokurikuAreaHolidayFlag;

  /**
   * 関西エリア休日フラグを保有する。
   */
  private Integer kansaiAreaHolidayFlag;

  /**
   * 中国エリア休日フラグを保有する。
   */
  private Integer chugokuAreaHolidayFlag;

  /**
   * 四国エリア休日フラグを保有する。
   */
  private Integer shikokuAreaHolidayFlag;

  /**
   * 九州エリア休日フラグを保有する。
   */
  private Integer kyushuAreaHolidayFlag;

  /**
   * 沖縄エリア休日フラグを保有する。
   */
  private Integer okinawaAreaHolidayFlag;

  /**
   * 土曜フラグを保有する。
   */
  private String saturdayFlag;

  /**
   * 日曜フラグを保有する。
   */
  private String SundayFlag;

  /**
   * 祝祭日フラグのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 祝祭日フラグを取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 祝祭日フラグ
   */
  public Integer getPublicHolidayFlag() {
    return this.publicHolidayFlag;
  }

  /**
   * 祝祭日フラグのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 祝祭日フラグを設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param publicHolidayFlag
   *          祝祭日フラグ
   */
  public void setPublicHolidayFlag(Integer publicHolidayFlag) {
    this.publicHolidayFlag = publicHolidayFlag;
  }

  /**
   * 事業者休日フラグのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 事業者休日フラグを取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 事業者休日フラグ
   */
  public Integer getOperatorHolidayFlag() {
    return this.operatorHolidayFlag;
  }

  /**
   * 事業者休日フラグのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 事業者休日フラグを設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param operatorHolidayFlag
   *          事業者休日フラグ
   */
  public void setOperatorHolidayFlag(Integer operatorHolidayFlag) {
    this.operatorHolidayFlag = operatorHolidayFlag;
  }

  /**
   * 金融機関休日フラグのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 金融機関休日フラグを取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 金融機関休日フラグ
   */
  public Integer getBankHolidayFlag() {
    return this.bankHolidayFlag;
  }

  /**
   * 金融機関休日フラグのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 金融機関休日フラグを設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param bankHolidayFlag
   *          金融機関休日フラグ
   */
  public void setBankHolidayFlag(Integer bankHolidayFlag) {
    this.bankHolidayFlag = bankHolidayFlag;
  }

  /**
   * 北海道エリア休日フラグのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 北海道エリア休日フラグを取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 北海道エリア休日フラグ
   */
  public Integer getHokkaidoAreaHolidayFlag() {
    return this.hokkaidoAreaHolidayFlag;
  }

  /**
   * 北海道エリア休日フラグのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 北海道エリア休日フラグを設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param hokkaidoAreaHolidayFlag
   *          北海道エリア休日フラグ
   */
  public void setHokkaidoAreaHolidayFlag(Integer hokkaidoAreaHolidayFlag) {
    this.hokkaidoAreaHolidayFlag = hokkaidoAreaHolidayFlag;
  }

  /**
   * 東北エリア休日フラグのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 東北エリア休日フラグを取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 東北エリア休日フラグ
   */
  public Integer getTohokuAreaHolidayFlag() {
    return this.tohokuAreaHolidayFlag;
  }

  /**
   * 東北エリア休日フラグのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 東北エリア休日フラグを設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param tohokuAreaHolidayFlag
   *          東北エリア休日フラグ
   */
  public void setTohokuAreaHolidayFlag(Integer tohokuAreaHolidayFlag) {
    this.tohokuAreaHolidayFlag = tohokuAreaHolidayFlag;
  }

  /**
   * 東京エリア休日フラグのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 東京エリア休日フラグを取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 東京エリア休日フラグ
   */
  public Integer getTokyoAreaHolidayFlag() {
    return this.tokyoAreaHolidayFlag;
  }

  /**
   * 東京エリア休日フラグのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 東京エリア休日フラグを設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param tokyoAreaHolidayFlag
   *          東京エリア休日フラグ
   */
  public void setTokyoAreaHolidayFlag(Integer tokyoAreaHolidayFlag) {
    this.tokyoAreaHolidayFlag = tokyoAreaHolidayFlag;
  }

  /**
   * 中部エリア休日フラグのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 中部エリア休日フラグを取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 中部エリア休日フラグ
   */
  public Integer getChubuAreaHolidayFlag() {
    return this.chubuAreaHolidayFlag;
  }

  /**
   * 中部エリア休日フラグのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 中部エリア休日フラグを設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param chubuAreaHolidayFlag
   *          中部エリア休日フラグ
   */
  public void setChubuAreaHolidayFlag(Integer chubuAreaHolidayFlag) {
    this.chubuAreaHolidayFlag = chubuAreaHolidayFlag;
  }

  /**
   * 北陸エリア休日フラグのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 北陸エリア休日フラグを取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 北陸エリア休日フラグ
   */
  public Integer getHokurikuAreaHolidayFlag() {
    return this.hokurikuAreaHolidayFlag;
  }

  /**
   * 北陸エリア休日フラグのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 北陸エリア休日フラグを設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param hokurikuAreaHolidayFlag
   *          北陸エリア休日フラグ
   */
  public void setHokurikuAreaHolidayFlag(Integer hokurikuAreaHolidayFlag) {
    this.hokurikuAreaHolidayFlag = hokurikuAreaHolidayFlag;
  }

  /**
   * 関西エリア休日フラグのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 関西エリア休日フラグを取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 関西エリア休日フラグ
   */
  public Integer getKansaiAreaHolidayFlag() {
    return this.kansaiAreaHolidayFlag;
  }

  /**
   * 関西エリア休日フラグのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 関西エリア休日フラグを設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param kansaiAreaHolidayFlag
   *          関西エリア休日フラグ
   */
  public void setKansaiAreaHolidayFlag(Integer kansaiAreaHolidayFlag) {
    this.kansaiAreaHolidayFlag = kansaiAreaHolidayFlag;
  }

  /**
   * 中国エリア休日フラグのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 中国エリア休日フラグを取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 中国エリア休日フラグ
   */
  public Integer getChugokuAreaHolidayFlag() {
    return this.chugokuAreaHolidayFlag;
  }

  /**
   * 中国エリア休日フラグのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 中国エリア休日フラグを設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param chugokuAreaHolidayFlag
   *          中国エリア休日フラグ
   */
  public void setChugokuAreaHolidayFlag(Integer chugokuAreaHolidayFlag) {
    this.chugokuAreaHolidayFlag = chugokuAreaHolidayFlag;
  }

  /**
   * 四国エリア休日フラグのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 四国エリア休日フラグを取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 四国エリア休日フラグ
   */
  public Integer getShikokuAreaHolidayFlag() {
    return this.shikokuAreaHolidayFlag;
  }

  /**
   * 四国エリア休日フラグのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 四国エリア休日フラグを設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param shikokuAreaHolidayFlag
   *          四国エリア休日フラグ
   */
  public void setShikokuAreaHolidayFlag(Integer shikokuAreaHolidayFlag) {
    this.shikokuAreaHolidayFlag = shikokuAreaHolidayFlag;
  }

  /**
   * 九州エリア休日フラグのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 九州エリア休日フラグを取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 九州エリア休日フラグ
   */
  public Integer getKyushuAreaHolidayFlag() {
    return this.kyushuAreaHolidayFlag;
  }

  /**
   * 九州エリア休日フラグのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 九州エリア休日フラグを設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param kyushuAreaHolidayFlag
   *          九州エリア休日フラグ
   */
  public void setKyushuAreaHolidayFlag(Integer kyushuAreaHolidayFlag) {
    this.kyushuAreaHolidayFlag = kyushuAreaHolidayFlag;
  }

  /**
   * 沖縄エリア休日フラグのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 沖縄エリア休日フラグを取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 沖縄エリア休日フラグ
   */
  public Integer getOkinawaAreaHolidayFlag() {
    return this.okinawaAreaHolidayFlag;
  }

  /**
   * 沖縄エリア休日フラグのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 沖縄エリア休日フラグを設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param okinawaAreaHolidayFlag
   *          沖縄エリア休日フラグ
   */
  public void setOkinawaAreaHolidayFlag(Integer okinawaAreaHolidayFlag) {
    this.okinawaAreaHolidayFlag = okinawaAreaHolidayFlag;
  }

  /**
   * 土曜フラグのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 土曜フラグを取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 土曜フラグ
   */
  public String getSaturdayFlag() {
    return this.saturdayFlag;
  }

  /**
   * 土曜フラグのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 土曜フラグを設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param saturdayFlag
   *          土曜フラグ
   */
  public void setSaturdayFlag(String saturdayFlag) {
    this.saturdayFlag = saturdayFlag;
  }

  /**
   * 日曜フラグのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 日曜フラグを取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 日曜フラグ
   */
  public String getSundayFlag() {
    return this.SundayFlag;
  }

  /**
   * 日曜フラグのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 日曜フラグを設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param SundayFlag
   *          日曜フラグ
   */
  public void setSundayFlag(String SundayFlag) {
    this.SundayFlag = SundayFlag;
  }
}
