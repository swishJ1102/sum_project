package jp.co.unisys.enability.cis.business.kj;

import jp.co.unisys.enability.cis.business.kj.model.CsvFileCheckMeterLocationBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.DownloadMeterLocationBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.InquiryMeterLocationBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.RegistMeterLocationBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.SearchMeterLocationBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.UpdateMeterLocationBusinessBean;
import jp.co.unisys.enability.cis.common.Exception.SystemException;

/**
 * メータ設置場所ビジネスインターフェース
 *
 * @author "Nihon Unisys, Ltd."
 *
 */
public interface KJ_MeterLocationInformationBusiness {

  /**
   * メータ設置場所照会を行う。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * CRMや低圧CISで、メータ設置場所を特定する場合に使用される。
   * 指定された「地点特定番号」（供給地点特定番号または、受電地点特定番号）で特定された情報を返却する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param inquiryMeterLocationBusinessBean
   *          メータ設置場所照会BusinessBean
   * @return メータ設置場所照会BusinessBean
   */
  public InquiryMeterLocationBusinessBean inquiry(InquiryMeterLocationBusinessBean inquiryMeterLocationBusinessBean);

  /**
   * メータ設置場所登録を行う。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * CRMや低圧CISで、メータ設置場所を特定する場合に使用される。
   * 指定された「地点特定番号」（供給地点特定番号または、受電地点特定番号）で特定された情報を返却する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param registMeterLocationBusinessBean
   *          メータ設置場所登録BusinessBean
   * @return メータ設置場所登録BusinessBean
   */
  public RegistMeterLocationBusinessBean regist(RegistMeterLocationBusinessBean registMeterLocationBusinessBean);

  /**
   * メータ設置場所更新を行う。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * CRMや低圧CISで、メータ設置場所を特定する場合に使用される。
   * 指定された「地点特定番号」（供給地点特定番号または、受電地点特定番号）で特定された情報を返却する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param updateMeterLocationBusinessBean
   *          メータ設置場所更新BusinessBean
   * @return メータ設置場所更新BusinessBean
   */
  public UpdateMeterLocationBusinessBean update(UpdateMeterLocationBusinessBean updateMeterLocationBusinessBean);

  /**
   * ダウンロードファイルの情報を取得する処理を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 1       ダウンロードファイル情報取得のMapperを呼び出し、ダウンロードファイル情報を取得する。
   * 2       CSVファイル名を生成する。
   * 3       DownloadMeterLocationBusinessBeanにダウンロードファイル情報とCSVファイル名を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param DownloadMeterLocationBusinessBean
   *          検索条件
   * @return DownloadMeterLocationBusinessBean ダウンロードファイル情報、CSVファイル名
   * @throws SystemException
   *           予期せぬエラーが発生した場合
   * @see jp.co.unisys.enability.cis.mapper.kj.MeterLocationInformationCommonMapper
   */
  public DownloadMeterLocationBusinessBean download(
      DownloadMeterLocationBusinessBean downloadMeterLocationBusinessBean)
      throws SystemException;

  /**
   * ダウンロードファイルの情報を取得する処理を行う。 （カスタム仕様のダウンロード項目に対応）
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 1       ダウンロードファイル情報取得のMapperを呼び出し、ダウンロードファイル情報を取得する。
   * 2       CSVファイル名を生成する。
   * 3       DownloadMeterLocationBusinessBeanにダウンロードファイル情報とCSVファイル名を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param DownloadMeterLocationBusinessBean
   *          検索条件
   * @return DownloadMeterLocationBusinessBean ダウンロードファイル情報、CSVファイル名
   * @throws SystemException
   *           予期せぬエラーが発生した場合
   * @see jp.co.unisys.enability.cis.mapper.kj.MeterLocationInformationCommonMapper
   */
  public DownloadMeterLocationBusinessBean downloadCustom(
      DownloadMeterLocationBusinessBean downloadMeterLocationBusinessBean)
      throws SystemException;

  /**
   * アップロードファイルのヘッダレコード、データレコードをチェックし、チェックでエラーにならない場合、DB更新用のオブジェクトを返却する。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   *         返却用オブジェクトを生成する。
   * 1       ヘッダレコードチェック処理を行い、入力内容に誤りがある場合、エラー情報を返却用オブジェクトに設定し、処理を終了する。
   * 2       データレコードチェック処理を全てのデータレコード行数分、チェックを行う。
   * 3       入力内容に誤りがある場合、エラー情報を全て返却用オブジェクトに設定し、処理を終了する。
   * 4       入力内容に誤りがない場合、データレコードの情報を返却用オブジェクトに設定し、処理を終了する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param CsvFileCheckMeterLocationBusinessBean
   *          アップロードファイル情報
   * @return CsvFileCheckMeterLocationBusinessBean データレコード情報、エラーリスト情報
   */
  public CsvFileCheckMeterLocationBusinessBean csvFileCheck(
      CsvFileCheckMeterLocationBusinessBean csvFileCheckBusinessBean);

  /**
   * アップロードファイルのヘッダレコード、データレコードをチェックし、チェックでエラーにならない場合、DB更新用のオブジェクトを返却する。 （カスタム仕様のアップロード項目に対応）
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   *         返却用オブジェクトを生成する。
   * 1       ヘッダレコードチェック処理を行い、入力内容に誤りがある場合、エラー情報を返却用オブジェクトに設定し、処理を終了する。
   * 2       データレコードチェック処理を全てのデータレコード行数分、チェックを行う。
   * 3       入力内容に誤りがある場合、エラー情報を全て返却用オブジェクトに設定し、処理を終了する。
   * 4       入力内容に誤りがない場合、データレコードの情報を返却用オブジェクトに設定し、処理を終了する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param CsvFileCheckMeterLocationBusinessBean
   *          アップロードファイル情報
   * @return CsvFileCheckMeterLocationBusinessBean データレコード情報、エラーリスト情報
   */
  public CsvFileCheckMeterLocationBusinessBean csvFileCheckCustom(
      CsvFileCheckMeterLocationBusinessBean csvFileCheckBusinessBean);

  /**
   * メータ設置場所照会を行う。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * CRMや低圧CISで、メータ設置場所を特定する場合に使用される。
   * 指定された「地点特定番号」（供給地点特定番号または、受電地点特定番号）で特定された情報を返却する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param SearchMeterLocationBusinessBean
   *          メータ設置場所照会BusinessBean
   * @return メータ設置場所照会BusinessBean
   */
  public SearchMeterLocationBusinessBean search(SearchMeterLocationBusinessBean searchMeterLocationBusinessBean);

}