package jp.co.unisys.enability.cis.business.kj;

import java.io.File;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.config.PropertiesFactoryBean;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DuplicateKeyException;

import jp.co.unisys.enability.cis.business.common.DateBusiness;
import jp.co.unisys.enability.cis.business.gk.ContractManagementInformationFileHeaderValidator;
import jp.co.unisys.enability.cis.business.gk.Custom_MeterLocationInformationFileRegistValidator;
import jp.co.unisys.enability.cis.business.gk.Custom_MeterLocationInformationFileUpdateValidator;
import jp.co.unisys.enability.cis.business.gk.MeterLocationInformationFileRegistValidator;
import jp.co.unisys.enability.cis.business.gk.MeterLocationInformationFileUpdateValidator;
import jp.co.unisys.enability.cis.business.kj.model.ContractManagementInformationFileConfigCommon;
import jp.co.unisys.enability.cis.business.kj.model.ContractManagementInformationFileConfigMeterLocation;
import jp.co.unisys.enability.cis.business.kj.model.CsvFileCheckMeterLocationBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.Custom_ContractManagementInformationFileConfigMeterLocation;
import jp.co.unisys.enability.cis.business.kj.model.DownloadMeterLocationBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.InquiryMeterLocationBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.RegistMeterLocationBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.SearchMeterLocationBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.UpdateMeterLocationBusinessBean;
import jp.co.unisys.enability.cis.common.Exception.BusinessLogicException;
import jp.co.unisys.enability.cis.common.Exception.SystemException;
import jp.co.unisys.enability.cis.common.util.KJ_CommonUtil;
import jp.co.unisys.enability.cis.common.util.StringConvertUtil;
import jp.co.unisys.enability.cis.common.util.ThreadContext;
import jp.co.unisys.enability.cis.common.util.constants.ECISCodeConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISKJConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISReturnCodeConstants;
import jp.co.unisys.enability.cis.entity.common.AmrcM;
import jp.co.unisys.enability.cis.entity.common.AreaM;
import jp.co.unisys.enability.cis.entity.common.CdWayM;
import jp.co.unisys.enability.cis.entity.common.GlcM;
import jp.co.unisys.enability.cis.entity.common.Ml;
import jp.co.unisys.enability.cis.entity.common.MlExample;
import jp.co.unisys.enability.cis.entity.common.MrDateCatM;
import jp.co.unisys.enability.cis.entity.common.Place;
import jp.co.unisys.enability.cis.entity.common.PlaceExample;
import jp.co.unisys.enability.cis.entity.common.PrefectureM;
import jp.co.unisys.enability.cis.entity.common.PrefectureMExample;
import jp.co.unisys.enability.cis.entity.common.SmCatM;
import jp.co.unisys.enability.cis.entity.common.SmM;
import jp.co.unisys.enability.cis.entity.common.TransmissionCatM;
import jp.co.unisys.enability.cis.entity.kj.KJ_InquiryMeterLocationEntityBean;
import jp.co.unisys.enability.cis.entity.kj.KJ_MeterLocationInformationFileEntityBean;
import jp.co.unisys.enability.cis.entity.kj.KJ_SearchMeterLocationEntityBean;
import jp.co.unisys.enability.cis.mapper.common.AmrcMMapper;
import jp.co.unisys.enability.cis.mapper.common.AreaMMapper;
import jp.co.unisys.enability.cis.mapper.common.CdWayMMapper;
import jp.co.unisys.enability.cis.mapper.common.GlcMMapper;
import jp.co.unisys.enability.cis.mapper.common.MlMapper;
import jp.co.unisys.enability.cis.mapper.common.MrDateCatMMapper;
import jp.co.unisys.enability.cis.mapper.common.PlaceMapper;
import jp.co.unisys.enability.cis.mapper.common.PrefectureMMapper;
import jp.co.unisys.enability.cis.mapper.common.SmCatMMapper;
import jp.co.unisys.enability.cis.mapper.common.SmMMapper;
import jp.co.unisys.enability.cis.mapper.common.TransmissionCatMMapper;
import jp.co.unisys.enability.cis.mapper.kj.MeterLocationInformationCommonMapper;
import jp.sf.orangesignal.csv.Csv;
import jp.sf.orangesignal.csv.handlers.ColumnPositionMapListHandler;

/**
 * メータ設置場所ビジネス
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.kj.KJ_MeterLocationInformationBusiness
 *
 */
public class KJ_MeterLocationInformationBusinessImpl implements
    KJ_MeterLocationInformationBusiness {

  /**
   * メータ設置場所共通Mapper(DI)
   */
  private MeterLocationInformationCommonMapper meterLocationInformationCommonMapper;

  /**
   * エリアマスタMapper(DI)
   */
  private AreaMMapper areaMMapper;

  /**
   * 送受電区分マスタMapper(DI)
   */
  private TransmissionCatMMapper transmissionCatMMapper;

  /**
   * 自家発連携マスタMapper(DI)
   */
  private GlcMMapper glcMMapper;

  /**
   * 供給方式マスタMapper(DI)
   */
  private SmMMapper smMMapper;

  /**
   * 30分値収集可否・自動検針可否マスタMapper(DI)
   */
  private AmrcMMapper amrcMMapper;

  /**
   * スマートメータ区分マスタMapper(DI)
   */
  private SmCatMMapper smcatMMapper;

  /**
   * 契約決定方法マスタMapper(DI)
   */
  private CdWayMMapper cdWayMMapper;

  /**
   * 都道府県マスタMapper(DI)
   */
  private PrefectureMMapper prefectureMMapper;

  /**
   * メータ設置場所Mapper(DI)
   */
  private MlMapper mlMapper;

  /**
   * 需要場所Mapper(DI)
   */
  private PlaceMapper placeMapper;

  /**
   * 検針日区分マスタMapper(DI)
   */
  private MrDateCatMMapper mrDateCatMMapper;

  /**
   * 日付関連共通ビジネス(DI)
   */
  private DateBusiness dateBusiness;

  /**
   * メッセージプロパティ(DI)
   */
  private MessageSource messageSource;

  /**
   * 契約管理情報ファイルヘッダーバリデーター(DI)
   */
  private ContractManagementInformationFileHeaderValidator contractManagementInformationFileHeaderValidator;

  /**
   * メータ設置場所情報ファイル登録バリデーター(DI)
   */
  private MeterLocationInformationFileRegistValidator meterLocationInformationFileRegistValidator;

  /**
   * （カスタム）メータ設置場所情報ファイル登録バリデーター(DI)
   */
  private Custom_MeterLocationInformationFileRegistValidator customMeterLocationInformationFileRegistValidator;

  /**
   * メータ設置場所情報ファイル更新バリデーター(DI)
   */
  private MeterLocationInformationFileUpdateValidator meterLocationInformationFileUpdateValidator;

  /**
   * （カスタム）メータ設置場所情報ファイル更新バリデーター(DI)
   */
  private Custom_MeterLocationInformationFileUpdateValidator customMeterLocationInformationFileUpdateValidator;

  /**
   * プロパティ（DI）
   */
  private PropertiesFactoryBean applicationProperties;

  /**
   * ログマネジャー
   */
  private static Logger logger = LogManager.getLogger();

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.kj.KJ_MeterLocationInformationBusiness
   * #inquiry(jp.co.unisys.enability.cis.business.kj.model.
   * InquiryMeterLocationBusinessBean)
   */
  @Override
  public InquiryMeterLocationBusinessBean inquiry(
      InquiryMeterLocationBusinessBean inquiryMeterLocationBusinessBean) {

    // 変数の定義
    String inquiryPattern = null;
    Integer id = null;
    String no = null;
    String code = null;
    Date date = null;
    // 契約者情報照会条件Map
    Map<String, Object> exampleMap = new HashMap<String, Object>();

    try {
      // 各項目より、照会パターンを設定
      // （《メータ設置場所照会BusinessBean》.契約IDがNULLでない
      // または、《メータ設置場所照会BusinessBean》.契約番号がNULLまたは空文字のいずれでもない）
      // かつ その他の《メータ設置場所照会BusinessBean》項目に値が設定されていない場合、以下を設定する。
      if ((inquiryMeterLocationBusinessBean.getContractId() != null || StringUtils
          .isNotEmpty(inquiryMeterLocationBusinessBean
              .getContractNo()))
          && inquiryMeterLocationBusinessBean.getMeterLocationId() == null
          && StringUtils.isEmpty(inquiryMeterLocationBusinessBean
              .getSpotNo())
          && StringUtils.isEmpty(inquiryMeterLocationBusinessBean
              .getSmartMeterCategoryCode())
          && inquiryMeterLocationBusinessBean
              .getNextMeterReadingScheduledDate() == null) {
        // ID（変数）に《メータ設置場所照会BusinessBean》.契約IDを設定する。
        // 番号（変数）に《メータ設置場所照会BusinessBean》.契約番号を設定する。
        // 照会パターン（変数）に“1”を設定する。
        id = inquiryMeterLocationBusinessBean.getContractId();
        no = inquiryMeterLocationBusinessBean.getContractNo();
        inquiryPattern = ECISKJConstants.INQUIRY_PATTERN_1;
        // 《メータ設置場所照会BusinessBean》.メータ設置場所IDがNULLでない
        // かつ その他の《メータ設置場所照会BusinessBean》項目に値が設定されていない場合、以下を設定する。
      } else if (inquiryMeterLocationBusinessBean.getMeterLocationId() != null
          && inquiryMeterLocationBusinessBean.getContractId() == null
          && StringUtils.isEmpty(inquiryMeterLocationBusinessBean
              .getContractNo())
          && StringUtils.isEmpty(inquiryMeterLocationBusinessBean
              .getSpotNo())
          && StringUtils.isEmpty(inquiryMeterLocationBusinessBean
              .getSmartMeterCategoryCode())
          && inquiryMeterLocationBusinessBean
              .getNextMeterReadingScheduledDate() == null) {
        // ID（変数）に《メータ設置場所照会BusinessBean》.メータ設置場所IDを設定する。
        // 番号（変数）にNULLを設定する。
        // // 照会パターン（変数）に“2”を設定する。
        id = inquiryMeterLocationBusinessBean.getMeterLocationId();
        inquiryPattern = ECISKJConstants.INQUIRY_PATTERN_2;
        // 《メータ設置場所照会BusinessBean》.地点特定番号がNULLまたは空文字のいずれでもない
        // かつ その他の《メータ設置場所照会BusinessBean》項目に値が設定されていない場合、以下を設定する。
      } else if (StringUtils.isNotEmpty(inquiryMeterLocationBusinessBean
          .getSpotNo())
          && inquiryMeterLocationBusinessBean.getContractId() == null
          && StringUtils.isEmpty(inquiryMeterLocationBusinessBean
              .getContractNo())
          && inquiryMeterLocationBusinessBean.getMeterLocationId() == null
          && StringUtils.isEmpty(inquiryMeterLocationBusinessBean
              .getSmartMeterCategoryCode())
          && inquiryMeterLocationBusinessBean
              .getNextMeterReadingScheduledDate() == null) {
        // ID（変数）にNULLを設定する。
        // 番号（変数）に《メータ設置場所照会BusinessBean》.地点特定番号を設定する。
        // 照会パターン（変数）に“3”を設定する。
        no = inquiryMeterLocationBusinessBean.getSpotNo();
        inquiryPattern = ECISKJConstants.INQUIRY_PATTERN_3;
        // 《メータ設置場所照会BusinessBean》.スマートメータ区分コードがNULLまたは空文字のいずれでもない
        // かつ《メータ設置場所照会BusinessBean》.次回検針予定日がNULLでない
        // かつ その他の《メータ設置場所照会BusinessBean》項目に値が設定されていない場合、以下を設定する。
      } else if (StringUtils.isNotEmpty(inquiryMeterLocationBusinessBean
          .getSmartMeterCategoryCode())
          && inquiryMeterLocationBusinessBean
              .getNextMeterReadingScheduledDate() != null
          && inquiryMeterLocationBusinessBean.getContractId() == null
          && StringUtils.isEmpty(inquiryMeterLocationBusinessBean
              .getContractNo())
          && inquiryMeterLocationBusinessBean.getMeterLocationId() == null
          && StringUtils.isEmpty(inquiryMeterLocationBusinessBean
              .getSpotNo())) {
        // コード（変数）に《メータ設置場所照会BusinessBean》.スマートメータ区分コードを設定する。
        // 日付（変数）に《メータ設置場所照会BusinessBean》.次回検針予定日を設定する。
        // 照会パターン（変数）に“4”を設定する。
        code = inquiryMeterLocationBusinessBean
            .getSmartMeterCategoryCode();
        date = inquiryMeterLocationBusinessBean
            .getNextMeterReadingScheduledDate();
        inquiryPattern = ECISKJConstants.INQUIRY_PATTERN_4;
        // 上記以外の場合、《メータ設置場所照会BusinessBean》.リターンコードに（P001）を設定し返却する。
      } else {
        inquiryMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P001);
        inquiryMeterLocationBusinessBean
            .setMessage(getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P001),
                null));
        return inquiryMeterLocationBusinessBean;
      }
      // オンライン処理基準日
      Date onlineDate = this.getOnLineDate();
      // メータ設置場所取得
      exampleMap.put("id", id);
      exampleMap.put("no", no);
      exampleMap.put("code", code);
      exampleMap.put("date", date);
      exampleMap.put("inquiryPattern", inquiryPattern);
      exampleMap.put("onlineDate", onlineDate);
      List<KJ_InquiryMeterLocationEntityBean> meterLocationList = meterLocationInformationCommonMapper
          .selectMeterLocation(exampleMap);
      // 戻り値を設定
      inquiryMeterLocationBusinessBean
          .setMeterLocationList(meterLocationList);
      inquiryMeterLocationBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);
      // 業務例外クラス(データアクセスエラーまたはオンライン処理基準日取得エラー)
    } catch (DataAccessException | BusinessLogicException e) {
      logger.error(messageSource.getMessage("error.E1129", null,
          Locale.getDefault()), e);
      // 《メータ設置場所照会BusinessBean》.リターンコードに（G017）を設定し、処理を終了する。
      inquiryMeterLocationBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      inquiryMeterLocationBusinessBean
          .setMessage(getMessage(
              KJ_CommonUtil
                  .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G017),
              null));
    } catch (NoSuchMessageException nsme) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, nsme);
      inquiryMeterLocationBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      inquiryMeterLocationBusinessBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
    }

    return inquiryMeterLocationBusinessBean;
  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.kj.KJ_MeterLocationInformationBusiness
   * #regist(jp.co.unisys.enability.cis.business.kj.model.
   * RegistMeterLocationBusinessBean)
   */
  @Override
  public RegistMeterLocationBusinessBean regist(
      RegistMeterLocationBusinessBean registMeterLocationBusinessBean) {

    String message = null;
    String smartMeterCategoryCode = null;
    String meterReadingDateCategoryCode = null;

    try {
      // プロパティ取得
      Properties prop = applicationProperties.getObject();

      // エリアコード存在チェック
      if (!doCheckAreaCode(registMeterLocationBusinessBean.getAreaCode())) {
        // 《メータ設置場所登録BusinessBean》.リターンコードに（P014）を設定し処理を終了する。
        registMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P014);
        registMeterLocationBusinessBean
            .setMessage(getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P014),
                null));
        return registMeterLocationBusinessBean;
      }

      // 送受電区分コード存在チェック
      if (!doCheckTransmissionCategoryCode(registMeterLocationBusinessBean
          .getTransmissionCategoryCode())) {
        // 《メータ設置場所登録BusinessBean》.リターンコードに（P015）を設定し処理を終了する。
        registMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P015);
        registMeterLocationBusinessBean
            .setMessage(getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P015),
                null));
        return registMeterLocationBusinessBean;
      }

      // 自家発連携有無コード存在チェック
      if (!doCheckGeneratorLinkageCheckCode(registMeterLocationBusinessBean
          .getGeneratorLinkageCheckCode())) {
        // 《メータ設置場所登録BusinessBean》.リターンコードに（P016）を設定し処理を終了する。
        registMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P016);
        registMeterLocationBusinessBean
            .setMessage(getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P016),
                null));
        return registMeterLocationBusinessBean;
      }

      // 供給方式コード存在チェック
      if (!doCheckSupplyMethodCode(registMeterLocationBusinessBean
          .getMethodCode())) {
        // 《メータ設置場所登録BusinessBean》.リターンコードに（P017）を設定し処理を終了する。
        registMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P017);
        registMeterLocationBusinessBean
            .setMessage(getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P017),
                null));
        return registMeterLocationBusinessBean;
      }

      // 30分値収集可否・自動検針可否コード1存在チェック
      if (!doCheckAutomaticMeterReadingCkeckCode(registMeterLocationBusinessBean
          .getAutomaticMeterReadingCkeckCode1())) {
        // 《メータ設置場所登録BusinessBean》.リターンコードに（P018）を設定する。
        // 《メータ設置場所登録BusinessBean》.メッセージに以下のメッセージ情報を設定する。
        // メッセージID： error.E1082
        // プレースホルダ0： 30分値収集可否・自動検針可否コード1
        message = getMessage(
            KJ_CommonUtil
                .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P018),
            new String[] {prop
                .getProperty("message.str.ml.amrcCode1") });
        registMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P018);
        registMeterLocationBusinessBean.setMessage(message);
        return registMeterLocationBusinessBean;
      }

      // 30分値収集可否・自動検針可否コード2存在チェック
      if (!doCheckAutomaticMeterReadingCkeckCode(registMeterLocationBusinessBean
          .getAutomaticMeterReadingCkeckCode2())) {
        // 《メータ設置場所登録BusinessBean》.リターンコードに（P018）を設定する。
        // 《メータ設置場所登録BusinessBean》.メッセージに以下のメッセージ情報を設定する。
        // メッセージID： error.E1082
        // プレースホルダ0： 30分値収集可否・自動検針可否コード2
        message = getMessage(
            KJ_CommonUtil
                .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P018),
            new String[] {prop
                .getProperty("message.str.ml.amrcCode2") });
        registMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P018);
        registMeterLocationBusinessBean.setMessage(message);
        return registMeterLocationBusinessBean;
      }

      // 30分値収集可否・自動検針可否コード3存在チェック
      if (!doCheckAutomaticMeterReadingCkeckCode(registMeterLocationBusinessBean
          .getAutomaticMeterReadingCkeckCode3())) {
        // 《メータ設置場所登録BusinessBean》.リターンコードに（P018）を設定する。
        // 《メータ設置場所登録BusinessBean》.メッセージに以下のメッセージ情報を設定する。
        // メッセージID： error.E1082
        // プレースホルダ0： 30分値収集可否・自動検針可否コード3
        message = getMessage(
            KJ_CommonUtil
                .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P018),
            new String[] {prop
                .getProperty("message.str.ml.amrcCode3") });
        registMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P018);
        registMeterLocationBusinessBean.setMessage(message);
        return registMeterLocationBusinessBean;
      }

      // 30分値収集可否・自動検針可否コード4存在チェック
      if (!doCheckAutomaticMeterReadingCkeckCode(registMeterLocationBusinessBean
          .getAutomaticMeterReadingCkeckCode4())) {
        // 《メータ設置場所登録BusinessBean》.リターンコードに（P018）を設定する。
        // 《メータ設置場所登録BusinessBean》.メッセージに以下のメッセージ情報を設定する。
        // メッセージID： error.E1082
        // プレースホルダ0： 30分値収集可否・自動検針可否コード4
        message = getMessage(
            KJ_CommonUtil
                .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P018),
            new String[] {prop
                .getProperty("message.str.ml.amrcCode4") });
        registMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P018);
        registMeterLocationBusinessBean.setMessage(message);
        return registMeterLocationBusinessBean;
      }

      // 30分値収集可否・自動検針可否コード5存在チェック
      if (!doCheckAutomaticMeterReadingCkeckCode(registMeterLocationBusinessBean
          .getAutomaticMeterReadingCkeckCode5())) {
        // 《メータ設置場所登録BusinessBean》.リターンコードに（P018）を設定する。
        // 《メータ設置場所登録BusinessBean》.メッセージに以下のメッセージ情報を設定する。
        // メッセージID： error.E1082
        // プレースホルダ0： 30分値収集可否・自動検針可否コード5
        message = getMessage(
            KJ_CommonUtil
                .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P018),
            new String[] {prop
                .getProperty("message.str.ml.amrcCode5") });
        registMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P018);
        registMeterLocationBusinessBean.setMessage(message);
        return registMeterLocationBusinessBean;
      }

      // スマートメータ区分コード存在チェック
      if (!doCheckSmartMeterCategoryCode(registMeterLocationBusinessBean
          .getSmartMeterCategoryCode())) {
        // 《メータ設置場所登録BusinessBean》.リターンコードに（P083）を設定し処理を終了する。
        registMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P083);
        registMeterLocationBusinessBean
            .setMessage(getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P083),
                null));
        return registMeterLocationBusinessBean;
      }

      // 契約決定方法コード存在チェック
      if (!doCheckContractDecisionWayCode(registMeterLocationBusinessBean
          .getContractDecisionWayCode())) {
        // 《メータ設置場所登録BusinessBean》.リターンコードに（P085）を設定し処理を終了する。
        registMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P085);
        registMeterLocationBusinessBean
            .setMessage(getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P085),
                null));
        return registMeterLocationBusinessBean;
      }

      // 検針日区分コード存在チェック
      if (!doCheckMeterReadingDateCategoryCode(registMeterLocationBusinessBean
          .getMeterReadingDateCategoryCode())) {
        // 《メータ設置場所更新BusinessBean》.リターンコードに（P100）を設定し処理を終了する。
        registMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P100);
        registMeterLocationBusinessBean
            .setMessage(getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P100),
                null));
        return registMeterLocationBusinessBean;
      }

      // 地点特定番号重複チェック
      if (!doCheckSpotNo(registMeterLocationBusinessBean.getSpotNo())) {
        // 《メータ設置場所登録BusinessBean》.リターンコードに（D022)を設定して、返却する。
        registMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D022);
        registMeterLocationBusinessBean
            .setMessage(getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D022),
                null));
        return registMeterLocationBusinessBean;
      }

      // システム時刻を取得
      Date sysDate = new Date();
      Timestamp systime = new Timestamp(sysDate.getTime());
      // 需要場所EntityBeanを設定
      // 《メータ設置場所登録BusinessBean》より、《需要場所Entity》に値を設定する。
      Place place = new Place();
      place.setPlaceAddressPostalCode(registMeterLocationBusinessBean
          .getPlaceAddressPostalCode());
      place.setPlaceAddressFull(registMeterLocationBusinessBean
          .getPlaceAddressFull());
      place.setPlaceAddressBuilding(registMeterLocationBusinessBean
          .getPlaceAddressBuilding());
      // 《需要場所Entity》.更新回数に“0”を設定する。
      place.setUpdateCount(0);
      // 《需要場所Entity》.作成日時にシステム日時を設定する。
      place.setCreateTime(systime);
      // 《需要場所Entity》.オンライン更新日時にシステム日時を設定する。
      place.setOnlineUpdateTime(systime);
      // 《需要場所Entity》.オンライン更新ユーザIDにコンテキスト.ユーザIDを設定する。
      place.setOnlineUpdateUserId(ThreadContext.getRequestThreadContext()
          .get(ECISConstants.USER_ID_KEY).toString());
      // 《需要場所Entity》.更新日時にシステム日時を設定する。
      place.setUpdateTime(systime);
      // 《需要場所Entity》.更新モジュールコードにコンテキスト.モジュールコードを設定する。
      place.setUpdateModuleCode(ThreadContext.getRequestThreadContext()
          .get(ECISConstants.CLASS_NAME_KEY).toString());
      // 需要場所登録
      placeMapper.insertBySequence(place);

      // 《メータ設置場所登録BusinessBean》.スマートメータ区分コードがNULLまたは空文字のいずれでもない場合
      if (StringUtils.isNotEmpty(registMeterLocationBusinessBean
          .getSmartMeterCategoryCode())) {
        // スマートメータ区分コード変数に《メータ設置場所登録BusinessBean》.スマートメータ区分コードを設定する
        smartMeterCategoryCode = registMeterLocationBusinessBean
            .getSmartMeterCategoryCode();
        // 《メータ設置場所登録BusinessBean》.スマートメータ区分コードがNULLまたは空文字のいずれかの場合
      } else {
        // 登録時スマートメータ区分判定を呼び出し、返却値をスマートメータ区分コード変数に設定する
        smartMeterCategoryCode = decideSmartMeterCategoryForRegist(registMeterLocationBusinessBean
            .getAutomaticMeterReadingCkeckCode1());
      }

      // 《メータ設置場所登録BusinessBean》.検針日区分コードがNULLでも空文字でもない場合
      if (StringUtils.isNotEmpty(registMeterLocationBusinessBean
          .getMeterReadingDateCategoryCode())) {
        // 変数.検針日区分コードに《メータ設置場所登録BusinessBean》.検針日区分コードを設定する。
        meterReadingDateCategoryCode = registMeterLocationBusinessBean
            .getMeterReadingDateCategoryCode();
        // 《メータ設置場所登録BusinessBean》.検針日区分コードがNULLか空文字の場合
      } else {
        // 変数.検針日区分コードに定数.分散検針:「1」を設定する。
        meterReadingDateCategoryCode = ECISCodeConstants.METER_READING_DATE_CATEGORY_DISPERSION;
      }

      // メータ設置場所EntityBeanを設定
      // 《メータ設置場所登録BusinessBean》より、《メータ設置場所Entity》に値を設定する。
      Ml ml = new Ml();
      ml.setAreaCode(registMeterLocationBusinessBean.getAreaCode());
      ml.setSpotNo(registMeterLocationBusinessBean.getSpotNo());
      ml.setContractorIdn(registMeterLocationBusinessBean
          .getContractorIdentificationNo());
      ml.setTransmissionCatCode(registMeterLocationBusinessBean
          .getTransmissionCategoryCode());
      ml.setBasicMrDate(registMeterLocationBusinessBean
          .getBasicMeterReadingDate());
      ml.setLastTimeMrDate(registMeterLocationBusinessBean
          .getLastTimeMeterReadingDate());
      ml.setNextMrScheduledDate(registMeterLocationBusinessBean
          .getNextMeterReadingScheduledDate());
      ml.setGlcCode(registMeterLocationBusinessBean
          .getGeneratorLinkageCheckCode());
      ml.setSmCode(registMeterLocationBusinessBean.getMethodCode());
      // 契約決定方法コード
      if (registMeterLocationBusinessBean.getContractDecisionWayCode() == null) {
        ml.setContractDecisionWayCode(ECISCodeConstants.CONTRACT_DECISION_WAY_CODE_SYSTEM_MANAGE_NA);
      } else {
        ml.setContractDecisionWayCode(registMeterLocationBusinessBean.getContractDecisionWayCode());
      }
      ml.setMeterIdn1(registMeterLocationBusinessBean
          .getMeterIdentificationNo1());
      ml.setMeterIdn2(registMeterLocationBusinessBean
          .getMeterIdentificationNo2());
      ml.setMeterIdn3(registMeterLocationBusinessBean
          .getMeterIdentificationNo3());
      ml.setMeterIdn4(registMeterLocationBusinessBean
          .getMeterIdentificationNo4());
      ml.setMeterIdn5(registMeterLocationBusinessBean
          .getMeterIdentificationNo5());
      ml.setAmrcCode1(registMeterLocationBusinessBean
          .getAutomaticMeterReadingCkeckCode1());
      ml.setAmrcCode2(registMeterLocationBusinessBean
          .getAutomaticMeterReadingCkeckCode2());
      ml.setAmrcCode3(registMeterLocationBusinessBean
          .getAutomaticMeterReadingCkeckCode3());
      ml.setAmrcCode4(registMeterLocationBusinessBean
          .getAutomaticMeterReadingCkeckCode4());
      ml.setAmrcCode5(registMeterLocationBusinessBean
          .getAutomaticMeterReadingCkeckCode5());
      // 《メータ設置場所Entity》.需要場所IDに《需要場所Entity》.需要場所IDを設定する。
      ml.setPlaceId(place.getPlaceId());
      // 《メータ設置場所Entity》.スマートメータ区分コードにスマートメータ区分コード変数を設定する。
      ml.setSmCatCode(smartMeterCategoryCode);
      // 《メータ設置場所Entity》.検針日区分コードに変数.検針日区分コードを設定する。
      ml.setMrDateCatCode(meterReadingDateCategoryCode);
      // 《メータ設置場所Entity》.更新回数に“0”を設定する。
      ml.setUpdateCount(0);
      // 《メータ設置場所Entity》.作成日時にシステム日時を設定する。
      ml.setCreateTime(systime);
      // 《メータ設置場所Entity》.オンライン更新日時にシステム日時を設定する。
      ml.setOnlineUpdateTime(systime);
      // 《メータ設置場所Entity》.オンライン更新ユーザIDにコンテキスト.ユーザIDを設定する。
      ml.setOnlineUpdateUserId(ThreadContext.getRequestThreadContext()
          .get(ECISConstants.USER_ID_KEY).toString());
      // 《メータ設置場所Entity》.更新日時にシステム日時を設定する。
      ml.setUpdateTime(systime);
      // 《メータ設置場所Entity》.更新モジュールコードにコンテキスト.モジュールコードを設定する。
      ml.setUpdateModuleCode(ThreadContext.getRequestThreadContext()
          .get(ECISConstants.CLASS_NAME_KEY).toString());
      // メータ設置場所登録
      mlMapper.insertBySequence(ml);
      // シーケンスの設定
      // 《メータ設置場所登録BusinessBean》.需要場所IDに《需要場所Entity》.需要場所IDを設定する。
      registMeterLocationBusinessBean.setPlaceId(place.getPlaceId());
      // 《メータ設置場所登録BusinessBean》.メータ設置場所IDに《メータ設置場所Entity》.メータ設置場所IDを設定する。
      registMeterLocationBusinessBean.setMeterLocationId(ml.getMlId());
      registMeterLocationBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);
      // 重複例外クラス
    } catch (DuplicateKeyException de) {
      logger.error(messageSource.getMessage("error.E1129", null,
          Locale.getDefault()), de);
      // 《メータ設置場所登録BusinessBean》.リターンコードに（D023）を設定し、処理を終了する。
      registMeterLocationBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D023);
      registMeterLocationBusinessBean.setMessage(getMessage(KJ_CommonUtil
          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D023),
          null));
      return registMeterLocationBusinessBean;
      // 業務例外クラス
    } catch (DataAccessException | IOException e) {
      logger.error(messageSource.getMessage("error.E1129", null,
          Locale.getDefault()), e);
      // 《メータ設置場所登録BusinessBean》.リターンコードに（G017）を設定し処理を終了する。
      registMeterLocationBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      registMeterLocationBusinessBean.setMessage(getMessage(KJ_CommonUtil
          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G017),
          null));
    } catch (NoSuchMessageException nsme) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, nsme);
      registMeterLocationBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      registMeterLocationBusinessBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
    }

    return registMeterLocationBusinessBean;
  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.kj.KJ_MeterLocationInformationBusiness
   * #update(jp.co.unisys.enability.cis.business.kj.model.
   * UpdateMeterLocationBusinessBean)
   */
  @Override
  public UpdateMeterLocationBusinessBean update(
      UpdateMeterLocationBusinessBean updateMeterLocationBusinessBean) {

    String message = null;
    String smartMeterCategoryCode = null;
    String meterReadingDateCategoryCode = null;
    // プロパティ取得
    Properties prop;
    try {
      prop = applicationProperties.getObject();
    } catch (IOException ioEx) {
      logger.error(messageSource.getMessage("error.E1129", null,
          Locale.getDefault()), ioEx);
      throw new SystemException(ECISKJConstants.IO_EXCEPTION, ioEx);
    }
    try {
      // エリアコード存在チェック
      if (!doCheckAreaCode(updateMeterLocationBusinessBean.getAreaCode())) {
        // 《メータ設置場所更新BusinessBean》.リターンコードに（P014）を設定し処理を終了する。
        updateMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P014);
        updateMeterLocationBusinessBean
            .setMessage(getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P014),
                null));
        return updateMeterLocationBusinessBean;
      }

      // 送受電区分コード存在チェック
      if (!doCheckTransmissionCategoryCode(updateMeterLocationBusinessBean
          .getTransmissionCategoryCode())) {
        // 《メータ設置場所更新BusinessBean》.リターンコードに（P015）を設定し処理を終了する。
        updateMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P015);
        updateMeterLocationBusinessBean
            .setMessage(getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P015),
                null));
        return updateMeterLocationBusinessBean;
      }

      // 自家発連携有無コード存在チェック
      if (!doCheckGeneratorLinkageCheckCode(updateMeterLocationBusinessBean
          .getGeneratorLinkageCheckCode())) {
        // 《メータ設置場所更新BusinessBean》.リターンコードに（P016）を設定し処理を終了する。
        updateMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P016);
        updateMeterLocationBusinessBean
            .setMessage(getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P016),
                null));
        return updateMeterLocationBusinessBean;
      }

      // 供給方式コード存在チェック
      if (!doCheckSupplyMethodCode(updateMeterLocationBusinessBean
          .getMethodCode())) {
        // 《メータ設置場所更新BusinessBean》.リターンコードに（P017）を設定し処理を終了する。
        updateMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P017);
        updateMeterLocationBusinessBean
            .setMessage(getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P017),
                null));
        return updateMeterLocationBusinessBean;
      }

      // 30分値収集可否・自動検針可否コード1存在チェック
      if (!doCheckAutomaticMeterReadingCkeckCode(updateMeterLocationBusinessBean
          .getAutomaticMeterReadingCkeckCode1())) {
        // 《メータ設置場所更新BusinessBean》.リターンコードに（P018）を設定する。
        // 《メータ設置場所更新BusinessBean》.メッセージに以下のメッセージ情報を設定する。
        // メッセージID： error.E1082
        // プレースホルダ0： 30分値収集可否・自動検針可否コード1
        message = getMessage(
            KJ_CommonUtil
                .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P018),
            new String[] {prop
                .getProperty("message.str.ml.amrcCode1") });
        updateMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P018);
        updateMeterLocationBusinessBean.setMessage(message);
        return updateMeterLocationBusinessBean;
      }

      // 30分値収集可否・自動検針可否コード2存在チェック
      if (!doCheckAutomaticMeterReadingCkeckCode(updateMeterLocationBusinessBean
          .getAutomaticMeterReadingCkeckCode2())) {
        // 《メータ設置場所更新BusinessBean》.リターンコードに（P018）を設定する。
        // 《メータ設置場所更新BusinessBean》.メッセージに以下のメッセージ情報を設定する。
        // メッセージID： error.E1082
        // プレースホルダ0： 30分値収集可否・自動検針可否コード2
        message = getMessage(
            KJ_CommonUtil
                .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P018),
            new String[] {prop
                .getProperty("message.str.ml.amrcCode2") });
        updateMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P018);
        updateMeterLocationBusinessBean.setMessage(message);
        return updateMeterLocationBusinessBean;
      }

      // 30分値収集可否・自動検針可否コード3存在チェック
      if (!doCheckAutomaticMeterReadingCkeckCode(updateMeterLocationBusinessBean
          .getAutomaticMeterReadingCkeckCode3())) {
        // 《メータ設置場所更新BusinessBean》.リターンコードに（P018）を設定する。
        // 《メータ設置場所更新BusinessBean》.メッセージに以下のメッセージ情報を設定する。
        // メッセージID： error.E1082
        // プレースホルダ0： 30分値収集可否・自動検針可否コード3
        message = getMessage(
            KJ_CommonUtil
                .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P018),
            new String[] {prop
                .getProperty("message.str.ml.amrcCode3") });
        updateMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P018);
        updateMeterLocationBusinessBean.setMessage(message);
        return updateMeterLocationBusinessBean;
      }

      // 30分値収集可否・自動検針可否コード4存在チェック
      if (!doCheckAutomaticMeterReadingCkeckCode(updateMeterLocationBusinessBean
          .getAutomaticMeterReadingCkeckCode4())) {
        // 《メータ設置場所更新BusinessBean》.リターンコードに（P018）を設定する。
        // 《メータ設置場所更新BusinessBean》.メッセージに以下のメッセージ情報を設定する。
        // メッセージID： error.E1082
        // プレースホルダ0： 30分値収集可否・自動検針可否コード4
        message = getMessage(
            KJ_CommonUtil
                .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P018),
            new String[] {prop
                .getProperty("message.str.ml.amrcCode4") });
        updateMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P018);
        updateMeterLocationBusinessBean.setMessage(message);
        return updateMeterLocationBusinessBean;
      }

      // 30分値収集可否・自動検針可否コード5存在チェック
      if (!doCheckAutomaticMeterReadingCkeckCode(updateMeterLocationBusinessBean
          .getAutomaticMeterReadingCkeckCode5())) {
        // 《メータ設置場所更新BusinessBean》.リターンコードに（P018）を設定する。
        // 《メータ設置場所更新BusinessBean》.メッセージに以下のメッセージ情報を設定する。
        // メッセージID： error.E1082
        // プレースホルダ0： 30分値収集可否・自動検針可否コード5
        message = getMessage(
            KJ_CommonUtil
                .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P018),
            new String[] {prop
                .getProperty("message.str.ml.amrcCode5") });
        updateMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P018);
        updateMeterLocationBusinessBean.setMessage(message);
        return updateMeterLocationBusinessBean;
      }

      // スマートメータ区分コード存在チェック
      if (!doCheckSmartMeterCategoryCode(updateMeterLocationBusinessBean
          .getSmartMeterCategoryCode())) {
        // 《メータ設置場所更新BusinessBean》.リターンコードに（P083）を設定し処理を終了する。
        updateMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P083);
        updateMeterLocationBusinessBean
            .setMessage(getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P083),
                null));
        return updateMeterLocationBusinessBean;
      }
      // 契約決定方法コード存在チェック
      if (!doCheckContractDecisionWayCode(updateMeterLocationBusinessBean
          .getContractDecisionWayCode())) {
        // 《メータ設置場所更新BusinessBean》.リターンコードに（P085）を設定し処理を終了する。
        updateMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P085);
        updateMeterLocationBusinessBean
            .setMessage(getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P085),
                null));
        return updateMeterLocationBusinessBean;
      }
      // 検針日区分コード存在チェック
      if (!doCheckMeterReadingDateCategoryCode(updateMeterLocationBusinessBean
          .getMeterReadingDateCategoryCode())) {
        // 《メータ設置場所更新BusinessBean》.リターンコードに（P100）を設定し処理を終了する。
        updateMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P100);
        updateMeterLocationBusinessBean
            .setMessage(getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P100),
                null));
        return updateMeterLocationBusinessBean;
      }
      // メータ設置場所ID取得
      // 《メータ設置場所照会BusinessBean》の設定
      // 《メータ設置場所照会BusinessBean》.メータ設置場所IDに《メータ設置場所更新BusinessBean》.メータ設置場所IDを設定する。
      InquiryMeterLocationBusinessBean inquiryMeterLocationBusinessBean = new InquiryMeterLocationBusinessBean();
      inquiryMeterLocationBusinessBean
          .setMeterLocationId(updateMeterLocationBusinessBean
              .getMeterLocationId());
      // メータ設置場所照会ビジネスを呼出
      inquiryMeterLocationBusinessBean = inquiry(inquiryMeterLocationBusinessBean);
      // 《メータ設置場所照会BusinessBean》.リターンコードが（0000）以外の場合、業務例外クラスをスローする。
      if (!ECISReturnCodeConstants.RETURN_CODE_0000
          .equals(inquiryMeterLocationBusinessBean.getReturnCode())) {
        // 業務例外クラス
        throw new BusinessLogicException(
            getMessage("error.E1299", null), false);
      }
      // 《メータ設置場所照会BusinessBean》.リターンコードが（0000）かつ、返却値が0件の場合、以下の処理を実行する。
      if (CollectionUtils.isEmpty(inquiryMeterLocationBusinessBean
          .getMeterLocationList())) {
        // 《メータ設置場所更新BusinessBean》.リターンコードにリターンコード（P008）を設定して返却する。
        updateMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P008);
        updateMeterLocationBusinessBean
            .setMessage(getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P008),
                null));
        return updateMeterLocationBusinessBean;

      }
      // 《メータ設置場所更新BusinessBean》.地点特定番号と《メータ設置場所照会BusinessBean》.地点特定番号が異なる場合、以下の処理を行う。
      String spotNo = updateMeterLocationBusinessBean.getSpotNo();
      if (spotNo != null
          && !inquiryMeterLocationBusinessBean.getMeterLocationList()
              .get(0).getSpotNo().equals(spotNo)) {
        // 地点特定番号重複チェック
        if (!doCheckSpotNo(spotNo)) {
          // 《メータ設置場所更新BusinessBean》.リターンコードに（D022)を設定して、返却する。
          updateMeterLocationBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D022);
          updateMeterLocationBusinessBean
              .setMessage(getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D022),
                  null));
          return updateMeterLocationBusinessBean;

        }
      }

      // システム時刻を取得
      Date sysDate = new Date();
      Timestamp systime = new Timestamp(sysDate.getTime());
      // 需要場所EntityBeanを設定
      // 《メータ設置場所更新BusinessBean》をコピーし、《需要場所Entity》とする。
      Place place = new Place();
      place.setPlaceAddressPostalCode(updateMeterLocationBusinessBean
          .getPlaceAddressPostalCode());
      place.setPlaceAddressFull(updateMeterLocationBusinessBean
          .getPlaceAddressFull());
      place.setPlaceAddressBuilding(updateMeterLocationBusinessBean
          .getPlaceAddressBuilding());
      // 《需要場所Entity》.更新回数に《メータ設置場所更新BusinessBean》.更新回数に1加算した値を設定する。
      place.setUpdateCount(updateMeterLocationBusinessBean
          .getUpdateCount() + 1);
      // 《需要場所Entity》.オンライン更新日時にシステム日時を設定する。
      place.setOnlineUpdateTime(systime);
      // 《需要場所Entity》.オンライン更新ユーザIDにコンテキスト.ユーザIDを設定する。
      place.setOnlineUpdateUserId(ThreadContext.getRequestThreadContext()
          .get(ECISConstants.USER_ID_KEY).toString());
      // 《需要場所Entity》.更新日時にシステム日時を設定する。
      place.setUpdateTime(systime);
      // 《需要場所Entity》.更新モジュールコードにコンテキスト.モジュールコードを設定する。
      place.setUpdateModuleCode(ThreadContext.getRequestThreadContext()
          .get(ECISConstants.CLASS_NAME_KEY).toString());
      // メータ設置場所登録条件を設定
      PlaceExample placeExample = new PlaceExample();
      placeExample
          .createCriteria()
          .andPlaceIdEqualTo(
              inquiryMeterLocationBusinessBean
                  .getMeterLocationList().get(0).getPlaceId())
          .andUpdateCountEqualTo(
              updateMeterLocationBusinessBean.getUpdateCount());
      // 需要場所更新
      int placeNum = placeMapper.updateByExampleSelective(place,
          placeExample);
      // 返却値が0件の場合、リターンコード（H001)を返却する。
      if (placeNum == 0) {
        updateMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_H001);
        updateMeterLocationBusinessBean
            .setMessage(getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_H001),
                null));
        return updateMeterLocationBusinessBean;
      }

      // 《メータ設置場所更新BusinessBean》.スマートメータ区分コードがNULLまたは空文字のいずれでもない場合
      if (StringUtils.isNotEmpty(updateMeterLocationBusinessBean
          .getSmartMeterCategoryCode())) {
        // スマートメータ区分コード変数に《メータ設置場所更新BusinessBean》.スマートメータ区分コードを設定する
        smartMeterCategoryCode = updateMeterLocationBusinessBean
            .getSmartMeterCategoryCode();
        // 《メータ設置場所更新BusinessBean》.スマートメータ区分コードがNULLまたは空文字のいずれかの場合
      } else {
        // 更新時スマートメータ区分判定を呼び出し、返却値をスマートメータ区分コード変数に設定する
        smartMeterCategoryCode = decideSmartMeterCategoryForUpdate(
            inquiryMeterLocationBusinessBean
                .getMeterLocationList().get(0).getSmartMeterCategoryCode(),
            updateMeterLocationBusinessBean
                .getAutomaticMeterReadingCkeckCode1());
      }

      // 《メータ設置場所更新BusinessBean》.検針日区分コードがNULLでも空文字でもない場合
      if (StringUtils.isNotEmpty(updateMeterLocationBusinessBean
          .getMeterReadingDateCategoryCode())) {
        // 変数.検針日区分コードに《メータ設置場所更新BusinessBean》.検針日区分コードを設定する。
        meterReadingDateCategoryCode = updateMeterLocationBusinessBean
            .getMeterReadingDateCategoryCode();
      }

      // メータ設置場所EntityBeanを設定
      // 《メータ設置場所更新BusinessBean》をコピーし、《メータ設置場所Entity》とする。
      Ml ml = new Ml();
      ml.setAreaCode(updateMeterLocationBusinessBean.getAreaCode());
      ml.setSpotNo(updateMeterLocationBusinessBean.getSpotNo());
      ml.setContractorIdn(updateMeterLocationBusinessBean
          .getContractorIdentificationNo());
      ml.setTransmissionCatCode(updateMeterLocationBusinessBean
          .getTransmissionCategoryCode());
      ml.setBasicMrDate(updateMeterLocationBusinessBean
          .getBasicMeterReadingDate());
      ml.setNextMrScheduledDate(updateMeterLocationBusinessBean
          .getNextMeterReadingScheduledDate());
      ml.setLastTimeMrDate(updateMeterLocationBusinessBean
          .getLastTimeMeterReadingDate());
      ml.setGlcCode(updateMeterLocationBusinessBean
          .getGeneratorLinkageCheckCode());
      ml.setSmCode(updateMeterLocationBusinessBean.getMethodCode());
      ml.setContractDecisionWayCode(updateMeterLocationBusinessBean.getContractDecisionWayCode());
      ml.setMeterIdn1(updateMeterLocationBusinessBean
          .getMeterIdentificationNo1());
      ml.setMeterIdn2(updateMeterLocationBusinessBean
          .getMeterIdentificationNo2());
      ml.setMeterIdn3(updateMeterLocationBusinessBean
          .getMeterIdentificationNo3());
      ml.setMeterIdn4(updateMeterLocationBusinessBean
          .getMeterIdentificationNo4());
      ml.setMeterIdn5(updateMeterLocationBusinessBean
          .getMeterIdentificationNo5());
      ml.setAmrcCode1(updateMeterLocationBusinessBean
          .getAutomaticMeterReadingCkeckCode1());
      ml.setAmrcCode2(updateMeterLocationBusinessBean
          .getAutomaticMeterReadingCkeckCode2());
      ml.setAmrcCode3(updateMeterLocationBusinessBean
          .getAutomaticMeterReadingCkeckCode3());
      ml.setAmrcCode4(updateMeterLocationBusinessBean
          .getAutomaticMeterReadingCkeckCode4());
      ml.setAmrcCode5(updateMeterLocationBusinessBean
          .getAutomaticMeterReadingCkeckCode5());
      // 《メータ設置場所Entity》.スマートメータ区分コードにスマートメータ区分コード変数を設定する。
      ml.setSmCatCode(smartMeterCategoryCode);
      // 《メータ設置場所Entity》.検針日区分コードに変数.検針日区分コードを設定する。
      ml.setMrDateCatCode(meterReadingDateCategoryCode);
      // 《メータ設置場所Entity》.更新回数に《メータ設置場所更新BusinessBean》.更新回数に1加算した値を設定する。
      ml.setUpdateCount(updateMeterLocationBusinessBean.getUpdateCount() + 1);
      // 《メータ設置場所Entity》.オンライン更新日時にシステム日時を設定する。
      ml.setOnlineUpdateTime(systime);
      // 《メータ設置場所Entity》.オンライン更新ユーザIDにコンテキスト.ユーザIDを設定する。
      ml.setOnlineUpdateUserId(ThreadContext.getRequestThreadContext()
          .get(ECISConstants.USER_ID_KEY).toString());
      // 《メータ設置場所Entity》.更新日時にシステム日時を設定する。
      ml.setUpdateTime(systime);
      // 《メータ設置場所Entity》.更新モジュールコードにコンテキスト.モジュールコードを設定する。
      ml.setUpdateModuleCode(ThreadContext.getRequestThreadContext()
          .get(ECISConstants.CLASS_NAME_KEY).toString());
      // メータ設置場所更新条件を設定
      Map<String, Object> exampleMap = new HashMap<String, Object>();
      exampleMap.put("nextMeterReadingScheduledDateNoUpdFlag",
          updateMeterLocationBusinessBean
              .getNextMeterReadingScheduledDateNoUpdFlag());
      exampleMap.put("lastTimeMeterReadingDateNoUpdFlag",
          updateMeterLocationBusinessBean
              .getLastTimeMeterReadingDateNoUpdFlag());
      exampleMap.put("conditionMeterLocationId",
          inquiryMeterLocationBusinessBean.getMeterLocationId());
      exampleMap.put("conditionUpdateCount",
          updateMeterLocationBusinessBean.getUpdateCount());
      // メータ設置場所更新
      int num = mlMapper.updateByNoUpdFlagSelective(ml, exampleMap);
      // 返却値が0件の場合、リターンコード（H001)を返却する。
      if (num == 0) {
        updateMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_H001);
        updateMeterLocationBusinessBean
            .setMessage(getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_H001),
                null));
        return updateMeterLocationBusinessBean;
      }
      updateMeterLocationBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);
      // 業務例外クラス
    } catch (DataAccessException | BusinessLogicException e) {
      logger.error(messageSource.getMessage("error.E1129", null,
          Locale.getDefault()), e);
      // 《メータ設置場所更新BusinessBean》.リターンコードに（G017）を設定して返却する。
      updateMeterLocationBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      updateMeterLocationBusinessBean.setMessage(getMessage(KJ_CommonUtil
          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G017),
          null));
    } catch (NoSuchMessageException nsme) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, nsme);
      updateMeterLocationBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      updateMeterLocationBusinessBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
    }
    return updateMeterLocationBusinessBean;
  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.kj.KJ_MeterLocationInformationBusiness
   * #download(jp.co.unisys.enability.cis.business.kj.model.
   * DownloadMeterLocationBusinessBean)
   */
  @Override
  public DownloadMeterLocationBusinessBean download(
      DownloadMeterLocationBusinessBean downloadMeterLocationBusinessBean) {
    try {
      // オンライン処理基準日設定
      String onlineDate = StringConvertUtil
          .convertDateToString(
              dateBusiness
                  .getProcessBaseDate(ECISConstants.EXEC_BASE_DATE_ONLINE),
              ECISConstants.FORMAT_DATE_yyyyMMdd);

      Map<String, Object> exampleMap = new HashMap<String, Object>();

      // 地点特定番号
      exampleMap
          .put(ECISKJConstants.S010107_SEARCH_KEY_SPOT_NO,
              downloadMeterLocationBusinessBean
                  .getContractManagementInformationDownloadSearchInformationBean()
                  .getSpotNo());
      // エリアコード
      exampleMap
          .put(ECISKJConstants.S010107_SEARCH_KEY_AREA,
              downloadMeterLocationBusinessBean
                  .getContractManagementInformationDownloadSearchInformationBean()
                  .getArea());
      // 送受電区分コード
      exampleMap
          .put(ECISKJConstants.S010107_SEARCH_KEY_TRANSMISSION_CATEGORY,
              downloadMeterLocationBusinessBean
                  .getContractManagementInformationDownloadSearchInformationBean()
                  .getTransmissionCategory());
      // オンライン処理基準日
      exampleMap
          .put(ECISKJConstants.S010107_SEARCH_KEY_ONLINE_EXECUTE_BASE_DATE,
              onlineDate);

      // メータ設置場所情報ファイルの出力内容取得
      List<KJ_MeterLocationInformationFileEntityBean> meterLocationInformationFileEntityBeanList = meterLocationInformationCommonMapper
          .selectMeterLocationInformationFile(exampleMap);

      // CSVファイル名設定
      StringBuilder fileName = new StringBuilder();
      fileName.append(ECISKJConstants.CONTRACT_MANAGEMENT_INFORMATION_DOWNLOAD_FILE_PREFIX_METER_LOCATION);
      fileName.append(ECISConstants.UNDERLINE);
      fileName.append(onlineDate);
      downloadMeterLocationBusinessBean.setDownloadFileName(fileName
          .toString());

      // メータ設置場所情報ファイルの出力内容設定
      downloadMeterLocationBusinessBean
          .setMeterLocationInformationFileEntityBeanList(meterLocationInformationFileEntityBeanList);
    } catch (Exception e) {
      throw new SystemException(e.getMessage(), e);
    }
    return downloadMeterLocationBusinessBean;
  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.kj.KJ_MeterLocationInformationBusiness
   * #download(jp.co.unisys.enability.cis.business.kj.model.
   * DownloadMeterLocationBusinessBean)
   */
  @Override
  public DownloadMeterLocationBusinessBean downloadCustom(
      DownloadMeterLocationBusinessBean downloadMeterLocationBusinessBean) {
    try {
      // オンライン処理基準日設定
      String onlineDate = StringConvertUtil
          .convertDateToString(
              dateBusiness
                  .getProcessBaseDate(ECISConstants.EXEC_BASE_DATE_ONLINE),
              ECISConstants.FORMAT_DATE_yyyyMMdd);

      Map<String, Object> exampleMap = new HashMap<String, Object>();

      // 地点特定番号
      exampleMap
          .put(ECISKJConstants.S010107_SEARCH_KEY_SPOT_NO,
              downloadMeterLocationBusinessBean
                  .getContractManagementInformationDownloadSearchInformationBean()
                  .getSpotNo());
      // エリアコード
      exampleMap
          .put(ECISKJConstants.S010107_SEARCH_KEY_AREA,
              downloadMeterLocationBusinessBean
                  .getContractManagementInformationDownloadSearchInformationBean()
                  .getArea());
      // 送受電区分コード
      exampleMap
          .put(ECISKJConstants.S010107_SEARCH_KEY_TRANSMISSION_CATEGORY,
              downloadMeterLocationBusinessBean
                  .getContractManagementInformationDownloadSearchInformationBean()
                  .getTransmissionCategory());
      // オンライン処理基準日
      exampleMap
          .put(ECISKJConstants.S010107_SEARCH_KEY_ONLINE_EXECUTE_BASE_DATE,
              onlineDate);

      // メータ設置場所情報ファイルの出力内容取得
      List<KJ_MeterLocationInformationFileEntityBean> meterLocationInformationFileEntityBeanList = meterLocationInformationCommonMapper
          .selectMeterLocationInformationFileCustom(exampleMap);

      // CSVファイル名設定
      StringBuilder fileName = new StringBuilder();
      fileName.append(ECISKJConstants.CONTRACT_MANAGEMENT_INFORMATION_DOWNLOAD_FILE_PREFIX_METER_LOCATION);
      fileName.append(ECISConstants.UNDERLINE);
      fileName.append(onlineDate);
      downloadMeterLocationBusinessBean.setDownloadFileName(fileName
          .toString());

      // メータ設置場所情報ファイルの出力内容設定
      downloadMeterLocationBusinessBean
          .setMeterLocationInformationFileEntityBeanList(meterLocationInformationFileEntityBeanList);
    } catch (Exception e) {
      throw new SystemException(e.getMessage(), e);
    }
    return downloadMeterLocationBusinessBean;
  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.kj.KJ_MeterLocationInformationBusiness
   * #csvFileCheck(jp.co.unisys.enability.cis.business.kj.model.
   * CsvFileCheckMeterLocationBusinessBean)
   */
  @Override
  public CsvFileCheckMeterLocationBusinessBean csvFileCheck(
      CsvFileCheckMeterLocationBusinessBean csvFileCheckBusinessBean) {
    try {
      // 返却用オブジェクト生成
      CsvFileCheckMeterLocationBusinessBean csvResultBean = new CsvFileCheckMeterLocationBusinessBean();

      // エラーリスト
      List<String> errorList = new ArrayList<String>();
      // 登録オブジェクトリスト
      List<Map<Integer, String>> registList = new ArrayList<Map<Integer, String>>();
      // 更新オブジェクトリスト
      List<Map<Integer, String>> updateList = new ArrayList<Map<Integer, String>>();

      // ファイル取得
      File meterLocationFile = csvFileCheckBusinessBean.getUploadFile();
      String fileName = meterLocationFile.getName();

      // ファイル読み込み
      List<Map<Integer, String>> csvMapList = Csv
          .load(meterLocationFile, ECISConstants.ENCODE_TYPE_UTF8,
              ContractManagementInformationFileConfigCommon
                  .getCsvConfig(),
              new ColumnPositionMapListHandler());

      /**
       * ヘッダレコードチェック
       */
      // ファイル構成チェック
      if (ContractManagementInformationFileConfigCommon.UPLOAD_FILE_MINIMUM_LINE_COUNT > csvMapList
          .size()) {
        errorList.add(StringConvertUtil.convertErrorListString(
            fileName,
            null,
            messageSource.getMessage("error.E0028", null,
                Locale.getDefault())));
        csvResultBean.setUploadFileName(fileName);
        csvResultBean.setErrorList(errorList);
        csvResultBean.setRegistList(registList);
        csvResultBean.setUpdateList(updateList);
        return csvResultBean;
      }

      // ヘッダレコード取得
      Map<Integer, String> headerRecord = csvMapList
          .get(ContractManagementInformationFileConfigCommon.ROW_NUMBER_HEADER);
      // 項目数チェック
      if (ContractManagementInformationFileConfigCommon.HEADER_COLUMN_COUNT != headerRecord
          .size()) {
        errorList
            .add(StringConvertUtil.convertErrorListString(
                meterLocationFile.getName(),
                ContractManagementInformationFileConfigCommon.HEADER_START_LINE_NUMBER,
                messageSource.getMessage("error.E0021", null,
                    Locale.getDefault())));
        csvResultBean.setUploadFileName(fileName);
        csvResultBean.setErrorList(errorList);
        csvResultBean.setRegistList(registList);
        csvResultBean.setUpdateList(updateList);
        return csvResultBean;
      }

      // 単項目チェック
      List<String> headerErrorMessageList = contractManagementInformationFileHeaderValidator
          .validate(
              headerRecord,
              ContractManagementInformationFileConfigMeterLocation.HEADER_FILE_KIND_MASK_STRING);
      if (headerErrorMessageList.size() > 0) {
        for (String message : headerErrorMessageList) {
          errorList
              .add(StringConvertUtil
                  .convertErrorListString(
                      fileName,
                      ContractManagementInformationFileConfigCommon.HEADER_START_LINE_NUMBER,
                      message));
        }
        csvResultBean.setUploadFileName(fileName);
        csvResultBean.setErrorList(errorList);
        csvResultBean.setRegistList(registList);
        csvResultBean.setUpdateList(updateList);
        return csvResultBean;
      }

      /**
       * タイトルレコードチェック
       */
      Map<Integer, String> titleRecord = csvMapList
          .get(ContractManagementInformationFileConfigCommon.ROW_NUMBER_TITLE);
      // 項目数チェック
      if (ContractManagementInformationFileConfigMeterLocation.DATA_COLUMN_COUNT != titleRecord
          .size()) {
        // データレコード項目数と一致しない場合、エラー終了
        errorList
            .add(StringConvertUtil
                .convertErrorListString(
                    fileName,
                    ContractManagementInformationFileConfigCommon.TITLE_START_LINE_NUMBER,
                    messageSource.getMessage("error.E0021",
                        null, Locale.getDefault())));
        csvResultBean.setUploadFileName(fileName);
        csvResultBean.setErrorList(errorList);
        csvResultBean.setRegistList(registList);
        csvResultBean.setUpdateList(updateList);
        return csvResultBean;
      }

      // 各項目チェック
      // HashMapだと順番に揃わない可能性があるため、IteratorでKeyを取得
      Iterator<Integer> titleIt = titleRecord.keySet().iterator();
      while (titleIt.hasNext()) {
        // タイトルのカラム番号を取得
        Integer columnNo = titleIt.next();
        // タイトル内容を取得
        String titleValue = titleRecord.get(columnNo);
        // コンフィグの内容を取得
        String configValue = ContractManagementInformationFileConfigMeterLocation.DATA_TITLE_ROW[columnNo
            .intValue()];
        // 一致していない場合、エラー終了
        if (!configValue.equals(titleValue)) {
          errorList
              .add(StringConvertUtil
                  .convertErrorListString(
                      fileName,
                      ContractManagementInformationFileConfigCommon.TITLE_START_LINE_NUMBER,
                      messageSource.getMessage(
                          "error.E0028", null,
                          Locale.getDefault())));
          csvResultBean.setUploadFileName(fileName);
          csvResultBean.setErrorList(errorList);
          csvResultBean.setRegistList(registList);
          csvResultBean.setUpdateList(updateList);
          return csvResultBean;
        }
      }

      /**
       * マスタ情報取得
       */
      // エリアコード
      List<AreaM> areaMasterList = areaMMapper.selectByExample(null);
      // チェック用Setに詰め替え
      Set<String> areaCodeCheckSet = new HashSet<String>();
      for (AreaM areaMaster : areaMasterList) {
        areaCodeCheckSet.add(areaMaster.getAreaCode());
      }
      // エラー用メッセージ設定
      String areaCodeErrorMessageOption = StringUtils.join(
          areaCodeCheckSet, ",");

      // 送受電区分コード
      List<TransmissionCatM> transmissionCategoryMasterList = transmissionCatMMapper
          .selectByExample(null);
      // チェック用Setに詰め替え
      Set<String> transmissionCategoryCodeCheckSet = new HashSet<String>();
      for (TransmissionCatM transmissionCategoryMaster : transmissionCategoryMasterList) {
        transmissionCategoryCodeCheckSet.add(transmissionCategoryMaster
            .getTransmissionCatCode());
      }
      // エラー用メッセージ設定
      String transmissionCategoryCodeErrorMessageOption = StringUtils
          .join(transmissionCategoryCodeCheckSet, ",");

      // 自家発連携有無コード
      List<GlcM> generatorLinkageCheckMasterList = glcMMapper
          .selectByExample(null);
      // チェック用Setに詰め替え
      Set<String> generatorLinkageCheckCodeCheckSet = new HashSet<String>();
      for (GlcM generatorLinkageCheckMaster : generatorLinkageCheckMasterList) {
        generatorLinkageCheckCodeCheckSet
            .add(generatorLinkageCheckMaster.getGlcCode());
      }
      // エラー用メッセージ設定
      String generatorLinkageCheckCodeErrorMessageOption = StringUtils
          .join(generatorLinkageCheckCodeCheckSet, ",");

      // 供給方式コード
      List<SmM> supplyMethodMasterList = smMMapper.selectByExample(null);
      // チェック用Setに詰め替え
      Set<String> supplyMethodCodeCheckSet = new HashSet<String>();
      for (SmM supplyMethodMaster : supplyMethodMasterList) {
        supplyMethodCodeCheckSet.add(supplyMethodMaster.getSmCode());
      }
      // エラー用メッセージ設定
      String supplyMethodCodeErrorMessageOption = StringUtils.join(
          supplyMethodCodeCheckSet, ",");

      // 30分値収集可否・自動検針可否コード
      List<AmrcM> automaticMeterReadingCheckMasterList = amrcMMapper
          .selectByExample(null);
      // チェック用Setに詰め替え
      Set<String> automaticMeterReadingCheckCodeCheckSet = new HashSet<String>();
      for (AmrcM generatorLinkageCheckMaster : automaticMeterReadingCheckMasterList) {
        automaticMeterReadingCheckCodeCheckSet
            .add(generatorLinkageCheckMaster.getAmrcCode());
      }
      // エラー用メッセージ設定
      String automaticMeterReadingCheckCodeErrorMessageOption = StringUtils
          .join(automaticMeterReadingCheckCodeCheckSet, ",");

      // 登録・更新区分エラー用メッセージ設定
      String registUpdateCategoryErrorMessageOption = StringUtils
          .join(new String[] {
              ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER,
              ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_UPDATE },
              ",");

      /**
       * データレコードチェック
       */
      // データレコードの件数分処理を行う
      for (int i = ContractManagementInformationFileConfigCommon.ROW_NUMBER_DATA; i < csvMapList
          .size(); i++) {
        // 出力用行番号設定
        final int outputRowNumber = i + 1;

        // データレコードエラーリスト生成
        List<String> dataRecordErrorList = new ArrayList<String>();

        // データレコード取得
        Map<Integer, String> dataRecord = csvMapList.get(i);

        // 項目数チェック
        if (ContractManagementInformationFileConfigMeterLocation.DATA_COLUMN_COUNT != dataRecord
            .size()) {
          // 項目数が一致しない場合、エラーリストに追加し、処理を終了する
          dataRecordErrorList.add(StringConvertUtil
              .convertErrorListString(fileName, outputRowNumber,
                  messageSource.getMessage("error.E0021",
                      null, Locale.getDefault())));
          errorList.addAll(dataRecordErrorList);

          // 処理を終了する。
          csvResultBean.setUploadFileName(fileName);
          csvResultBean.setErrorList(errorList);
          csvResultBean.setRegistList(registList);
          csvResultBean.setUpdateList(updateList);
          return csvResultBean;
        }

        // スキップ判定
        String registerUpdateCategory = dataRecord
            .get(ContractManagementInformationFileConfigMeterLocation.DATA_REGISTER_UPDATE_CATEGORY_INDEX);
        if (StringUtils.isEmpty(registerUpdateCategory)) {
          continue;
        }

        // 単項目チェック
        // バリデーションエラーメッセージ用リスト生成
        List<String> validationErrorMessageList = new ArrayList<String>();
        // 登録・更新区分の値により、チェックメソッドを分岐
        switch (registerUpdateCategory) {
          case ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER:
            // 登録バリデーション実行
            validationErrorMessageList = meterLocationInformationFileRegistValidator
                .validate(dataRecord);
            break;
          case ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_UPDATE:
            // 更新バリデーション実行
            validationErrorMessageList = meterLocationInformationFileUpdateValidator
                .validate(dataRecord);
            break;
          default:
            // 登録・更新区分が不正な場合、エラーメッセージ設定
            dataRecordErrorList
                .add(StringConvertUtil.convertErrorListString(
                    fileName,
                    outputRowNumber,
                    messageSource
                        .getMessage(
                            "validation.range",
                            new String[] {
                                ContractManagementInformationFileConfigMeterLocation.DATA_REGISTER_UPDATE_CATEGORY_NAME,
                                registUpdateCategoryErrorMessageOption },
                            Locale.getDefault())));
        }

        // バリデーションエラーメッセージにファイル名と行数を追加し、データレコードエラーリストに追加
        for (String validationErrorMessage : validationErrorMessageList) {
          dataRecordErrorList.add(StringConvertUtil
              .convertErrorListString(fileName, outputRowNumber,
                  validationErrorMessage));
        }

        // 登録・更新区分が登録または更新の場合のみチェック
        if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER
            .equals(registerUpdateCategory)
            || ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_UPDATE
                .equals(registerUpdateCategory)) {

          // エリアコードチェック
          if (!areaCodeCheckSet
              .contains(dataRecord
                  .get(ContractManagementInformationFileConfigMeterLocation.DATA_AREA_CODE_INDEX))) {
            dataRecordErrorList
                .add(StringConvertUtil.convertErrorListString(
                    fileName,
                    outputRowNumber,
                    messageSource
                        .getMessage(
                            "validation.range",
                            new String[] {
                                ContractManagementInformationFileConfigMeterLocation.DATA_AREA_CODE_NAME,
                                areaCodeErrorMessageOption },
                            Locale.getDefault())));
          }

          // 送受電区分コードチェック
          if (!transmissionCategoryCodeCheckSet
              .contains(dataRecord
                  .get(ContractManagementInformationFileConfigMeterLocation.DATA_TRANSMISSION_CATEGORY_CODE_INDEX))) {
            dataRecordErrorList
                .add(StringConvertUtil.convertErrorListString(
                    fileName,
                    outputRowNumber,
                    messageSource
                        .getMessage(
                            "validation.range",
                            new String[] {
                                ContractManagementInformationFileConfigMeterLocation.DATA_TRANSMISSION_CATEGORY_CODE_NAME,
                                transmissionCategoryCodeErrorMessageOption },
                            Locale.getDefault())));
          }

          // 自家発連携有無コードチェック
          String generatorLinkageCheckCode = dataRecord
              .get(ContractManagementInformationFileConfigMeterLocation.DATA_GENERATOR_LINKAGE_CHECK_CODE_INDEX);
          if (!generatorLinkageCheckCodeCheckSet
              .contains(generatorLinkageCheckCode)) {
            dataRecordErrorList
                .add(StringConvertUtil.convertErrorListString(
                    fileName,
                    outputRowNumber,
                    messageSource
                        .getMessage(
                            "validation.range",
                            new String[] {
                                ContractManagementInformationFileConfigMeterLocation.DATA_GENERATOR_LINKAGE_CHECK_CODE_NAME,
                                generatorLinkageCheckCodeErrorMessageOption },
                            Locale.getDefault())));
          }

          // 供給方式コードチェック
          String supplyMethodCode = dataRecord
              .get(ContractManagementInformationFileConfigMeterLocation.DATA_SUPPLY_METHOD_CODE_INDEX);
          if (!supplyMethodCodeCheckSet.contains(supplyMethodCode)) {
            dataRecordErrorList
                .add(StringConvertUtil.convertErrorListString(
                    fileName,
                    outputRowNumber,
                    messageSource
                        .getMessage(
                            "validation.range",
                            new String[] {
                                ContractManagementInformationFileConfigMeterLocation.DATA_SUPPLY_METHOD_CODE_NAME,
                                supplyMethodCodeErrorMessageOption },
                            Locale.getDefault())));
          }

          // 30分値収集可否・自動検針可否コード1チェック
          String automaticMeterReadingCheckCode1 = dataRecord
              .get(ContractManagementInformationFileConfigMeterLocation.DATA_AUTOMATIC_METER_READING_CHECK_CODE1_INDEX);
          if (!automaticMeterReadingCheckCodeCheckSet
              .contains(automaticMeterReadingCheckCode1)) {
            dataRecordErrorList
                .add(StringConvertUtil.convertErrorListString(
                    fileName,
                    outputRowNumber,
                    messageSource
                        .getMessage(
                            "validation.range",
                            new String[] {
                                ContractManagementInformationFileConfigMeterLocation.DATA_AUTOMATIC_METER_READING_CHECK_CODE1_NAME,
                                automaticMeterReadingCheckCodeErrorMessageOption },
                            Locale.getDefault())));
          }

          // 30分値収集可否・自動検針可否コード2チェック
          // 入力されている場合のみ判定する
          String automaticMeterReadingCheckCode2 = dataRecord
              .get(ContractManagementInformationFileConfigMeterLocation.DATA_AUTOMATIC_METER_READING_CHECK_CODE2_INDEX);
          if (StringUtils.isNotEmpty(automaticMeterReadingCheckCode2)) {
            if (!automaticMeterReadingCheckCodeCheckSet
                .contains(automaticMeterReadingCheckCode2)) {
              dataRecordErrorList
                  .add(StringConvertUtil
                      .convertErrorListString(
                          fileName,
                          outputRowNumber,
                          messageSource
                              .getMessage(
                                  "validation.range",
                                  new String[] {
                                      ContractManagementInformationFileConfigMeterLocation.DATA_AUTOMATIC_METER_READING_CHECK_CODE2_NAME,
                                      automaticMeterReadingCheckCodeErrorMessageOption },
                                  Locale.getDefault())));
            }
          }

          // 30分値収集可否・自動検針可否コード3チェック
          // 入力されている場合のみ判定する
          String automaticMeterReadingCheckCode3 = dataRecord
              .get(ContractManagementInformationFileConfigMeterLocation.DATA_AUTOMATIC_METER_READING_CHECK_CODE3_INDEX);
          if (StringUtils.isNotEmpty(automaticMeterReadingCheckCode3)) {
            if (!automaticMeterReadingCheckCodeCheckSet
                .contains(automaticMeterReadingCheckCode3)) {
              dataRecordErrorList
                  .add(StringConvertUtil
                      .convertErrorListString(
                          fileName,
                          outputRowNumber,
                          messageSource
                              .getMessage(
                                  "validation.range",
                                  new String[] {
                                      ContractManagementInformationFileConfigMeterLocation.DATA_AUTOMATIC_METER_READING_CHECK_CODE3_NAME,
                                      automaticMeterReadingCheckCodeErrorMessageOption },
                                  Locale.getDefault())));
            }
          }

          // 30分値収集可否・自動検針可否コード4チェック
          // 入力されている場合のみ判定する
          String automaticMeterReadingCheckCode4 = dataRecord
              .get(ContractManagementInformationFileConfigMeterLocation.DATA_AUTOMATIC_METER_READING_CHECK_CODE4_INDEX);
          if (StringUtils.isNotEmpty(automaticMeterReadingCheckCode4)) {
            if (!automaticMeterReadingCheckCodeCheckSet
                .contains(automaticMeterReadingCheckCode4)) {
              dataRecordErrorList
                  .add(StringConvertUtil
                      .convertErrorListString(
                          fileName,
                          outputRowNumber,
                          messageSource
                              .getMessage(
                                  "validation.range",
                                  new String[] {
                                      ContractManagementInformationFileConfigMeterLocation.DATA_AUTOMATIC_METER_READING_CHECK_CODE4_NAME,
                                      automaticMeterReadingCheckCodeErrorMessageOption },
                                  Locale.getDefault())));
            }
          }

          // 30分値収集可否・自動検針可否コード5チェック
          // 入力されている場合のみ判定する
          String automaticMeterReadingCheckCode5 = dataRecord
              .get(ContractManagementInformationFileConfigMeterLocation.DATA_AUTOMATIC_METER_READING_CHECK_CODE5_INDEX);
          if (StringUtils.isNotEmpty(automaticMeterReadingCheckCode5)) {
            if (!automaticMeterReadingCheckCodeCheckSet
                .contains(automaticMeterReadingCheckCode5)) {
              dataRecordErrorList
                  .add(StringConvertUtil
                      .convertErrorListString(
                          fileName,
                          outputRowNumber,
                          messageSource
                              .getMessage(
                                  "validation.range",
                                  new String[] {
                                      ContractManagementInformationFileConfigMeterLocation.DATA_AUTOMATIC_METER_READING_CHECK_CODE5_NAME,
                                      automaticMeterReadingCheckCodeErrorMessageOption },
                                  Locale.getDefault())));
            }
          }
        }

        // データレコードエラーリストチェック
        if (!CollectionUtils.isEmpty(dataRecordErrorList)) {
          // データレコードエラーリストが存在する場合
          // 処理用オブジェクトには格納しない
          errorList.addAll(dataRecordErrorList);
          continue;
        }

        // データレコード振分
        Map<Integer, String> resultDataRecordMap = new HashMap<Integer, String>(
            dataRecord);
        // 行番号設定
        // 実際の行数（インデックス＋１）を設定する
        resultDataRecordMap
            .put(ContractManagementInformationFileConfigCommon.DATA_ROW_NO_INDEX,
                String.valueOf(outputRowNumber));
        // 登録・更新により振分
        if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER
            .equals(registerUpdateCategory)) {
          // 登録の場合、登録オブジェクトリストに追加
          registList.add(resultDataRecordMap);
        } else if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_UPDATE
            .equals(registerUpdateCategory)) {
          // 更新の場合、更新オブジェクトリストに追加
          updateList.add(resultDataRecordMap);
        }
      }

      // オブジェクト返却
      csvResultBean.setUploadFileName(fileName);
      csvResultBean.setErrorList(errorList);
      csvResultBean.setRegistList(registList);
      csvResultBean.setUpdateList(updateList);
      return csvResultBean;
    } catch (Exception e) {
      throw new SystemException(e.getMessage(), e);
    }
  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.kj.KJ_MeterLocationInformationBusiness
   * #csvFileCheck(jp.co.unisys.enability.cis.business.kj.model.
   * CsvFileCheckMeterLocationBusinessBean)
   */
  //	@Override
  public CsvFileCheckMeterLocationBusinessBean csvFileCheckCustom(
      CsvFileCheckMeterLocationBusinessBean csvFileCheckBusinessBean) {
    try {
      // 返却用オブジェクト生成
      CsvFileCheckMeterLocationBusinessBean csvResultBean = new CsvFileCheckMeterLocationBusinessBean();

      // エラーリスト
      List<String> errorList = new ArrayList<String>();
      // 登録オブジェクトリスト
      List<Map<Integer, String>> registList = new ArrayList<Map<Integer, String>>();
      // 更新オブジェクトリスト
      List<Map<Integer, String>> updateList = new ArrayList<Map<Integer, String>>();

      // ファイル取得
      File meterLocationFile = csvFileCheckBusinessBean.getUploadFile();
      String fileName = meterLocationFile.getName();

      // ファイル読み込み
      List<Map<Integer, String>> csvMapList = Csv
          .load(meterLocationFile, ECISConstants.ENCODE_TYPE_UTF8,
              ContractManagementInformationFileConfigCommon
                  .getCsvConfig(),
              new ColumnPositionMapListHandler());

      /**
       * ヘッダレコードチェック
       */
      // ファイル構成チェック
      if (ContractManagementInformationFileConfigCommon.UPLOAD_FILE_MINIMUM_LINE_COUNT > csvMapList
          .size()) {
        errorList.add(StringConvertUtil.convertErrorListString(
            fileName,
            null,
            messageSource.getMessage("error.E0028", null,
                Locale.getDefault())));
        csvResultBean.setUploadFileName(fileName);
        csvResultBean.setErrorList(errorList);
        csvResultBean.setRegistList(registList);
        csvResultBean.setUpdateList(updateList);
        return csvResultBean;
      }

      // ヘッダレコード取得
      Map<Integer, String> headerRecord = csvMapList
          .get(ContractManagementInformationFileConfigCommon.ROW_NUMBER_HEADER);
      // 項目数チェック
      if (ContractManagementInformationFileConfigCommon.HEADER_COLUMN_COUNT != headerRecord
          .size()) {
        errorList
            .add(StringConvertUtil.convertErrorListString(
                meterLocationFile.getName(),
                ContractManagementInformationFileConfigCommon.HEADER_START_LINE_NUMBER,
                messageSource.getMessage("error.E0021", null,
                    Locale.getDefault())));
        csvResultBean.setUploadFileName(fileName);
        csvResultBean.setErrorList(errorList);
        csvResultBean.setRegistList(registList);
        csvResultBean.setUpdateList(updateList);
        return csvResultBean;
      }

      // 単項目チェック
      List<String> headerErrorMessageList = contractManagementInformationFileHeaderValidator
          .validate(
              headerRecord,
              Custom_ContractManagementInformationFileConfigMeterLocation.HEADER_FILE_KIND_MASK_STRING);
      if (headerErrorMessageList.size() > 0) {
        for (String message : headerErrorMessageList) {
          errorList
              .add(StringConvertUtil
                  .convertErrorListString(
                      fileName,
                      ContractManagementInformationFileConfigCommon.HEADER_START_LINE_NUMBER,
                      message));
        }
        csvResultBean.setUploadFileName(fileName);
        csvResultBean.setErrorList(errorList);
        csvResultBean.setRegistList(registList);
        csvResultBean.setUpdateList(updateList);
        return csvResultBean;
      }

      /**
       * タイトルレコードチェック
       */
      Map<Integer, String> titleRecord = csvMapList
          .get(ContractManagementInformationFileConfigCommon.ROW_NUMBER_TITLE);
      // 項目数チェック
      if (Custom_ContractManagementInformationFileConfigMeterLocation.DATA_COLUMN_COUNT != titleRecord
          .size()) {
        // データレコード項目数と一致しない場合、エラー終了
        errorList
            .add(StringConvertUtil
                .convertErrorListString(
                    fileName,
                    ContractManagementInformationFileConfigCommon.TITLE_START_LINE_NUMBER,
                    messageSource.getMessage("error.E0021",
                        null, Locale.getDefault())));
        csvResultBean.setUploadFileName(fileName);
        csvResultBean.setErrorList(errorList);
        csvResultBean.setRegistList(registList);
        csvResultBean.setUpdateList(updateList);
        return csvResultBean;
      }

      // 各項目チェック
      // HashMapだと順番に揃わない可能性があるため、IteratorでKeyを取得
      Iterator<Integer> titleIt = titleRecord.keySet().iterator();
      while (titleIt.hasNext()) {
        // タイトルのカラム番号を取得
        Integer columnNo = titleIt.next();
        // タイトル内容を取得
        String titleValue = titleRecord.get(columnNo);
        // コンフィグの内容を取得
        String configValue = Custom_ContractManagementInformationFileConfigMeterLocation.DATA_TITLE_ROW[columnNo
            .intValue()];
        // 一致していない場合、エラー終了
        if (!configValue.equals(titleValue)) {
          errorList
              .add(StringConvertUtil
                  .convertErrorListString(
                      fileName,
                      ContractManagementInformationFileConfigCommon.TITLE_START_LINE_NUMBER,
                      messageSource.getMessage(
                          "error.E0028", null,
                          Locale.getDefault())));
          csvResultBean.setUploadFileName(fileName);
          csvResultBean.setErrorList(errorList);
          csvResultBean.setRegistList(registList);
          csvResultBean.setUpdateList(updateList);
          return csvResultBean;
        }
      }

      /**
       * マスタ情報取得
       */
      // エリアコード
      List<AreaM> areaMasterList = areaMMapper.selectByExample(null);
      // チェック用Setに詰め替え
      Set<String> areaCodeCheckSet = new HashSet<String>();
      for (AreaM areaMaster : areaMasterList) {
        areaCodeCheckSet.add(areaMaster.getAreaCode());
      }
      // エラー用メッセージ設定
      String areaCodeErrorMessageOption = StringUtils.join(
          areaCodeCheckSet, ",");

      // 送受電区分コード
      List<TransmissionCatM> transmissionCategoryMasterList = transmissionCatMMapper
          .selectByExample(null);
      // チェック用Setに詰め替え
      Set<String> transmissionCategoryCodeCheckSet = new HashSet<String>();
      for (TransmissionCatM transmissionCategoryMaster : transmissionCategoryMasterList) {
        transmissionCategoryCodeCheckSet.add(transmissionCategoryMaster
            .getTransmissionCatCode());
      }
      // エラー用メッセージ設定
      String transmissionCategoryCodeErrorMessageOption = StringUtils
          .join(transmissionCategoryCodeCheckSet, ",");

      // 自家発連携有無コード
      List<GlcM> generatorLinkageCheckMasterList = glcMMapper
          .selectByExample(null);
      // チェック用Setに詰め替え
      Set<String> generatorLinkageCheckCodeCheckSet = new HashSet<String>();
      for (GlcM generatorLinkageCheckMaster : generatorLinkageCheckMasterList) {
        generatorLinkageCheckCodeCheckSet
            .add(generatorLinkageCheckMaster.getGlcCode());
      }
      // エラー用メッセージ設定
      String generatorLinkageCheckCodeErrorMessageOption = StringUtils
          .join(generatorLinkageCheckCodeCheckSet, ",");

      // 供給方式コード
      List<SmM> supplyMethodMasterList = smMMapper.selectByExample(null);
      // チェック用Setに詰め替え
      Set<String> supplyMethodCodeCheckSet = new HashSet<String>();
      for (SmM supplyMethodMaster : supplyMethodMasterList) {
        supplyMethodCodeCheckSet.add(supplyMethodMaster.getSmCode());
      }
      // エラー用メッセージ設定
      String supplyMethodCodeErrorMessageOption = StringUtils.join(
          supplyMethodCodeCheckSet, ",");

      // 30分値収集可否・自動検針可否コード
      List<AmrcM> automaticMeterReadingCheckMasterList = amrcMMapper
          .selectByExample(null);
      // チェック用Setに詰め替え
      Set<String> automaticMeterReadingCheckCodeCheckSet = new HashSet<String>();
      for (AmrcM generatorLinkageCheckMaster : automaticMeterReadingCheckMasterList) {
        automaticMeterReadingCheckCodeCheckSet
            .add(generatorLinkageCheckMaster.getAmrcCode());
      }
      // エラー用メッセージ設定
      String automaticMeterReadingCheckCodeErrorMessageOption = StringUtils
          .join(automaticMeterReadingCheckCodeCheckSet, ",");

      // 都道府県コード
      PrefectureMExample prefectureMExample = new PrefectureMExample();
      prefectureMExample.setOrderByClause(ECISKJConstants.ORDER_BY_PREFECTURE_CODE);
      List<PrefectureM> prefectureMasterList = prefectureMMapper.selectByExample(prefectureMExample);
      // チェック用Setに詰め替え
      LinkedHashSet<String> prefectureCodeCheckSet = new LinkedHashSet<String>();
      for (PrefectureM prefectureMaster : prefectureMasterList) {
        prefectureCodeCheckSet.add(prefectureMaster.getPrefectureCode());
      }
      // エラー用メッセージ設定
      String prefectureCodeErrorMessageOption = StringUtils.join(
          prefectureCodeCheckSet, ",");

      // 検針日区分コード
      List<MrDateCatM> mrDateCatMasterList = mrDateCatMMapper.selectByExample(null);
      // チェック用Setに詰め替え
      Set<String> mrDateCatCodeCheckSet = new HashSet<String>();
      for (MrDateCatM mrDateCatMaster : mrDateCatMasterList) {
        mrDateCatCodeCheckSet.add(mrDateCatMaster.getMrDateCatCode());
      }
      // エラー用メッセージ設定
      String mrDateCatCodeErrorMessageOption = StringUtils.join(
          mrDateCatCodeCheckSet, ",");

      // 登録・更新区分エラー用メッセージ設定
      String registUpdateCategoryErrorMessageOption = StringUtils
          .join(new String[] {
              ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER,
              ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_UPDATE },
              ",");

      /**
       * データレコードチェック
       */
      // データレコードの件数分処理を行う
      for (int i = ContractManagementInformationFileConfigCommon.ROW_NUMBER_DATA; i < csvMapList
          .size(); i++) {
        // 出力用行番号設定
        final int outputRowNumber = i + 1;

        // データレコードエラーリスト生成
        List<String> dataRecordErrorList = new ArrayList<String>();

        // データレコード取得
        Map<Integer, String> dataRecord = csvMapList.get(i);

        // 項目数チェック
        if (Custom_ContractManagementInformationFileConfigMeterLocation.DATA_COLUMN_COUNT != dataRecord
            .size()) {
          // 項目数が一致しない場合、エラーリストに追加し、処理を終了する
          dataRecordErrorList.add(StringConvertUtil
              .convertErrorListString(fileName, outputRowNumber,
                  messageSource.getMessage("error.E0021",
                      null, Locale.getDefault())));
          errorList.addAll(dataRecordErrorList);

          // 処理を終了する。
          csvResultBean.setUploadFileName(fileName);
          csvResultBean.setErrorList(errorList);
          csvResultBean.setRegistList(registList);
          csvResultBean.setUpdateList(updateList);
          return csvResultBean;
        }

        // スキップ判定
        String registerUpdateCategory = dataRecord
            .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_REGISTER_UPDATE_CATEGORY_INDEX);
        if (StringUtils.isEmpty(registerUpdateCategory)) {
          continue;
        }

        // 単項目チェック
        // バリデーションエラーメッセージ用リスト生成
        List<String> validationErrorMessageList = new ArrayList<String>();
        // 登録・更新区分の値により、チェックメソッドを分岐
        switch (registerUpdateCategory) {
          case ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER:
            // 登録バリデーション実行
            validationErrorMessageList = customMeterLocationInformationFileRegistValidator
                .validate(dataRecord);
            break;
          case ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_UPDATE:
            // 更新バリデーション実行
            validationErrorMessageList = customMeterLocationInformationFileUpdateValidator
                .validate(dataRecord);
            break;
          default:
            // 登録・更新区分が不正な場合、エラーメッセージ設定
            dataRecordErrorList
                .add(StringConvertUtil.convertErrorListString(
                    fileName,
                    outputRowNumber,
                    messageSource
                        .getMessage(
                            "validation.range",
                            new String[] {
                                Custom_ContractManagementInformationFileConfigMeterLocation.DATA_REGISTER_UPDATE_CATEGORY_NAME,
                                registUpdateCategoryErrorMessageOption },
                            Locale.getDefault())));
        }

        // バリデーションエラーメッセージにファイル名と行数を追加し、データレコードエラーリストに追加
        for (String validationErrorMessage : validationErrorMessageList) {
          dataRecordErrorList.add(StringConvertUtil
              .convertErrorListString(fileName, outputRowNumber,
                  validationErrorMessage));
        }

        // 登録・更新区分が登録または更新の場合のみチェック
        if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER
            .equals(registerUpdateCategory)
            || ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_UPDATE
                .equals(registerUpdateCategory)) {

          // エリアコードチェック
          if (!areaCodeCheckSet
              .contains(dataRecord
                  .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_AREA_CODE_INDEX))) {
            dataRecordErrorList
                .add(StringConvertUtil.convertErrorListString(
                    fileName,
                    outputRowNumber,
                    messageSource
                        .getMessage(
                            "validation.range",
                            new String[] {
                                Custom_ContractManagementInformationFileConfigMeterLocation.DATA_AREA_CODE_NAME,
                                areaCodeErrorMessageOption },
                            Locale.getDefault())));
          }

          // 送受電区分コードチェック
          if (!transmissionCategoryCodeCheckSet
              .contains(dataRecord
                  .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_TRANSMISSION_CATEGORY_CODE_INDEX))) {
            dataRecordErrorList
                .add(StringConvertUtil.convertErrorListString(
                    fileName,
                    outputRowNumber,
                    messageSource
                        .getMessage(
                            "validation.range",
                            new String[] {
                                Custom_ContractManagementInformationFileConfigMeterLocation.DATA_TRANSMISSION_CATEGORY_CODE_NAME,
                                transmissionCategoryCodeErrorMessageOption },
                            Locale.getDefault())));
          }

          // 自家発連携有無コードチェック
          String generatorLinkageCheckCode = dataRecord
              .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_GENERATOR_LINKAGE_CHECK_CODE_INDEX);
          if (!generatorLinkageCheckCodeCheckSet
              .contains(generatorLinkageCheckCode)) {
            dataRecordErrorList
                .add(StringConvertUtil.convertErrorListString(
                    fileName,
                    outputRowNumber,
                    messageSource
                        .getMessage(
                            "validation.range",
                            new String[] {
                                Custom_ContractManagementInformationFileConfigMeterLocation.DATA_GENERATOR_LINKAGE_CHECK_CODE_NAME,
                                generatorLinkageCheckCodeErrorMessageOption },
                            Locale.getDefault())));
          }

          // 供給方式コードチェック
          String supplyMethodCode = dataRecord
              .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_SUPPLY_METHOD_CODE_INDEX);
          if (!supplyMethodCodeCheckSet.contains(supplyMethodCode)) {
            dataRecordErrorList
                .add(StringConvertUtil.convertErrorListString(
                    fileName,
                    outputRowNumber,
                    messageSource
                        .getMessage(
                            "validation.range",
                            new String[] {
                                Custom_ContractManagementInformationFileConfigMeterLocation.DATA_SUPPLY_METHOD_CODE_NAME,
                                supplyMethodCodeErrorMessageOption },
                            Locale.getDefault())));
          }

          // 30分値収集可否・自動検針可否コード1チェック
          String automaticMeterReadingCheckCode1 = dataRecord
              .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_AUTOMATIC_METER_READING_CHECK_CODE1_INDEX);
          if (!automaticMeterReadingCheckCodeCheckSet
              .contains(automaticMeterReadingCheckCode1)) {
            dataRecordErrorList
                .add(StringConvertUtil.convertErrorListString(
                    fileName,
                    outputRowNumber,
                    messageSource
                        .getMessage(
                            "validation.range",
                            new String[] {
                                Custom_ContractManagementInformationFileConfigMeterLocation.DATA_AUTOMATIC_METER_READING_CHECK_CODE1_NAME,
                                automaticMeterReadingCheckCodeErrorMessageOption },
                            Locale.getDefault())));
          }

          // 30分値収集可否・自動検針可否コード2チェック
          // 入力されている場合のみ判定する
          String automaticMeterReadingCheckCode2 = dataRecord
              .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_AUTOMATIC_METER_READING_CHECK_CODE2_INDEX);
          if (StringUtils.isNotEmpty(automaticMeterReadingCheckCode2)) {
            if (!automaticMeterReadingCheckCodeCheckSet
                .contains(automaticMeterReadingCheckCode2)) {
              dataRecordErrorList
                  .add(StringConvertUtil
                      .convertErrorListString(
                          fileName,
                          outputRowNumber,
                          messageSource
                              .getMessage(
                                  "validation.range",
                                  new String[] {
                                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_AUTOMATIC_METER_READING_CHECK_CODE2_NAME,
                                      automaticMeterReadingCheckCodeErrorMessageOption },
                                  Locale.getDefault())));
            }
          }

          // 30分値収集可否・自動検針可否コード3チェック
          // 入力されている場合のみ判定する
          String automaticMeterReadingCheckCode3 = dataRecord
              .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_AUTOMATIC_METER_READING_CHECK_CODE3_INDEX);
          if (StringUtils.isNotEmpty(automaticMeterReadingCheckCode3)) {
            if (!automaticMeterReadingCheckCodeCheckSet
                .contains(automaticMeterReadingCheckCode3)) {
              dataRecordErrorList
                  .add(StringConvertUtil
                      .convertErrorListString(
                          fileName,
                          outputRowNumber,
                          messageSource
                              .getMessage(
                                  "validation.range",
                                  new String[] {
                                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_AUTOMATIC_METER_READING_CHECK_CODE3_NAME,
                                      automaticMeterReadingCheckCodeErrorMessageOption },
                                  Locale.getDefault())));
            }
          }

          // 30分値収集可否・自動検針可否コード4チェック
          // 入力されている場合のみ判定する
          String automaticMeterReadingCheckCode4 = dataRecord
              .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_AUTOMATIC_METER_READING_CHECK_CODE4_INDEX);
          if (StringUtils.isNotEmpty(automaticMeterReadingCheckCode4)) {
            if (!automaticMeterReadingCheckCodeCheckSet
                .contains(automaticMeterReadingCheckCode4)) {
              dataRecordErrorList
                  .add(StringConvertUtil
                      .convertErrorListString(
                          fileName,
                          outputRowNumber,
                          messageSource
                              .getMessage(
                                  "validation.range",
                                  new String[] {
                                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_AUTOMATIC_METER_READING_CHECK_CODE4_NAME,
                                      automaticMeterReadingCheckCodeErrorMessageOption },
                                  Locale.getDefault())));
            }
          }

          // 30分値収集可否・自動検針可否コード5チェック
          // 入力されている場合のみ判定する
          String automaticMeterReadingCheckCode5 = dataRecord
              .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_AUTOMATIC_METER_READING_CHECK_CODE5_INDEX);
          if (StringUtils.isNotEmpty(automaticMeterReadingCheckCode5)) {
            if (!automaticMeterReadingCheckCodeCheckSet
                .contains(automaticMeterReadingCheckCode5)) {
              dataRecordErrorList
                  .add(StringConvertUtil
                      .convertErrorListString(
                          fileName,
                          outputRowNumber,
                          messageSource
                              .getMessage(
                                  "validation.range",
                                  new String[] {
                                      Custom_ContractManagementInformationFileConfigMeterLocation.DATA_AUTOMATIC_METER_READING_CHECK_CODE5_NAME,
                                      automaticMeterReadingCheckCodeErrorMessageOption },
                                  Locale.getDefault())));
            }
          }

          // 都道府県コードチェック
          if (!prefectureCodeCheckSet
              .contains(dataRecord
                  .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_01_INDEX))) {
            dataRecordErrorList
                .add(StringConvertUtil
                    .convertErrorListString(
                        fileName,
                        outputRowNumber,
                        messageSource
                            .getMessage(
                                "validation.range",
                                new String[] {
                                    Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_01_NAME,
                                    prefectureCodeErrorMessageOption },
                                Locale.getDefault())));
          }

          // 検針日区分コードチェック
          // 入力されている場合のみ判定する
          String meterReadingDateCategoryCode = dataRecord
              .get(Custom_ContractManagementInformationFileConfigMeterLocation.METER_READING_DATE_CATEGORY_CODE_INDEX);
          if (StringUtils.isNotEmpty(meterReadingDateCategoryCode)) {
            if (!mrDateCatCodeCheckSet
                .contains(meterReadingDateCategoryCode)) {
              dataRecordErrorList
                  .add(StringConvertUtil
                      .convertErrorListString(
                          fileName,
                          outputRowNumber,
                          messageSource
                              .getMessage(
                                  "validation.range",
                                  new String[] {
                                      Custom_ContractManagementInformationFileConfigMeterLocation.METER_READING_DATE_CATEGORY_CODE_NAME,
                                      mrDateCatCodeErrorMessageOption },
                                  Locale.getDefault())));
            }
          }

        }

        // データレコードエラーリストチェック
        if (!CollectionUtils.isEmpty(dataRecordErrorList)) {
          // データレコードエラーリストが存在する場合
          // 処理用オブジェクトには格納しない
          errorList.addAll(dataRecordErrorList);
          continue;
        }

        // データレコード振分
        Map<Integer, String> resultDataRecordMap = new HashMap<Integer, String>(
            dataRecord);
        // 行番号設定
        // 実際の行数（インデックス＋１）を設定する
        resultDataRecordMap
            .put(ContractManagementInformationFileConfigCommon.DATA_ROW_NO_INDEX,
                String.valueOf(outputRowNumber));
        // 登録・更新により振分
        if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER
            .equals(registerUpdateCategory)) {
          // 登録の場合、登録オブジェクトリストに追加
          registList.add(resultDataRecordMap);
        } else if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_UPDATE
            .equals(registerUpdateCategory)) {
          // 更新の場合、更新オブジェクトリストに追加
          updateList.add(resultDataRecordMap);
        }
      }

      // オブジェクト返却
      csvResultBean.setUploadFileName(fileName);
      csvResultBean.setErrorList(errorList);
      csvResultBean.setRegistList(registList);
      csvResultBean.setUpdateList(updateList);
      return csvResultBean;
    } catch (Exception e) {
      throw new SystemException(e.getMessage(), e);
    }
  }

  /**
   * エリアコード存在チェック
   *
   * @param areaCode
   *          エリアコード
   * @return true チェック成功 false チェック失敗
   */
  private boolean doCheckAreaCode(String areaCode) {
    // エリアコードがNULLまたは空文字のいずれかでない場合、以下のチェックを行う。
    if (StringUtils.isNotEmpty(areaCode)) {
      // エリアマスタMapper.検索（主キー）を呼び出し。
      // 引数： エリアコード
      AreaM areaM = areaMMapper.selectByPrimaryKey(areaCode);
      // 返却値が0件の場合、チェック失敗。
      if (areaM == null) {
        return false;
      }
    }
    return true;
  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.kj.KJ_MeterLocationInformationBusiness
   * #download(jp.co.unisys.enability.cis.business.kj.model.
   * SearchMeterLocationBusinessBean)
   */
  @Override
  public SearchMeterLocationBusinessBean search(
      SearchMeterLocationBusinessBean searchMeterLocationBusinessBean) {
    String errorMessage = null;

    try {
      errorMessage = getMessage(
          KJ_CommonUtil
              .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G017),
          null);

      Map<String, Object> exampleMap = new HashMap<String, Object>();

      // 地点特定番号
      exampleMap
          .put(ECISKJConstants.S010107_SEARCH_KEY_SPOT_NO,
              searchMeterLocationBusinessBean.getSpotNo());
      // 契約開始日
      exampleMap
          .put(ECISKJConstants.S010107_SEARCH_KEY_CONTRACT_TERM_START_DATE,
              searchMeterLocationBusinessBean.getContractStartDate());

      // メータ設置場所情報ファイルの出力内容取得
      List<KJ_SearchMeterLocationEntityBean> meterLocationInformationFileEntityBeanList = meterLocationInformationCommonMapper
          .searchMeterLocation(exampleMap);
      //メータ設置場所検索BusinessBean.メータ設置場所情報リストを設定する。
      searchMeterLocationBusinessBean.setMeterLocationList(meterLocationInformationFileEntityBeanList);

      //メータ設置場所検索BusinessBean.リターンコードに（0000）を設定し返却する。
      searchMeterLocationBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);

    } catch (DataAccessException e) {
      logger.error(messageSource.getMessage("error.E1129", null,
          Locale.getDefault()), e);
      // 《メータ設置場所照会BusinessBean》.リターンコードに（G017）を設定し、処理を終了する。
      searchMeterLocationBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      searchMeterLocationBusinessBean.setMessage(errorMessage);
    } catch (NoSuchMessageException nsme) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, nsme);
      searchMeterLocationBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      searchMeterLocationBusinessBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
    }

    return searchMeterLocationBusinessBean;
  }

  /**
   * 送受電区分コード存在チェック
   *
   * @param transmissionCategoryCode
   *          送受電区分コード
   * @return true チェック成功 false チェック失敗
   */
  private boolean doCheckTransmissionCategoryCode(
      String transmissionCategoryCode) {
    // 送受電区分コードがNULLまたは空文字のいずれかでない場合、以下のチェックを行う。
    if (StringUtils.isNotEmpty(transmissionCategoryCode)) {
      // 送受電区分マスタMapper.検索（主キー）を呼び出し。
      // 引数： 送受電区分コード
      TransmissionCatM transmissionCatM = transmissionCatMMapper
          .selectByPrimaryKey(transmissionCategoryCode);
      // 返却値が0件の場合、チェック失敗。
      if (transmissionCatM == null) {
        return false;
      }
    }
    return true;
  }

  /**
   * 自家発連携有無コード存在チェック
   *
   * @param generatorLinkageCheckCode
   *          自家発連携有無コード
   * @return true チェック成功 false チェック失敗
   */
  private boolean doCheckGeneratorLinkageCheckCode(
      String generatorLinkageCheckCode) {
    // 自家発連携有無コードがNULLまたは空文字のいずれかでない場合、以下のチェックを行う。
    if (StringUtils.isNotEmpty(generatorLinkageCheckCode)) {
      // 自家発連携有無マスタMapper.検索（主キー）を呼び出し。
      // 引数：.自家発連携有無コード
      GlcM glcM = glcMMapper
          .selectByPrimaryKey(generatorLinkageCheckCode);
      // 返却値が0件の場合、チェック失敗。
      if (glcM == null) {
        return false;
      }
    }
    return true;
  }

  /**
   * 供給方式コード存在チェック
   *
   * @param supplyMethodCode
   *          供給方式コード
   * @return true チェック成功 false チェック失敗
   */
  private boolean doCheckSupplyMethodCode(String supplyMethodCode) {
    // 供給方式コード存在チェック
    // 供給方式コードがNULLまたは空文字のいずれかでない場合、以下のチェックを行う。
    if (StringUtils.isNotEmpty(supplyMethodCode)) {
      // 供給方式マスタMapper.検索（主キー）を呼び出し。
      // 引数： 供給方式コード
      SmM smMM = smMMapper.selectByPrimaryKey(supplyMethodCode);
      // 返却値が0件の場合、チェック失敗。
      if (smMM == null) {
        return false;
      }
    }
    return true;
  }

  /**
   * 30分値収集可否・自動検針可否コード存在チェック
   *
   * @param automaticMeterReadingCkeckCode
   *          30分値収集可否・自動検針可否コード
   * @return true チェック成功 false チェック失敗
   */
  private boolean doCheckAutomaticMeterReadingCkeckCode(
      String automaticMeterReadingCkeckCode) {
    // 30分値収集可否・自動検針可否コードが NULLまたは空文字のいずれかでない場合、以下のチェックを行う。
    if (StringUtils.isNotEmpty(automaticMeterReadingCkeckCode)) {
      // 30分値収集可否・自動検針可否マスタ検索（主キー）を呼び出し。
      // 引数：30分値収集可否・自動検針可否コード
      AmrcM amrcM1 = amrcMMapper
          .selectByPrimaryKey(automaticMeterReadingCkeckCode);
      // 返却値が0件の場合、チェック失敗。
      if (amrcM1 == null) {
        return false;
      }
    }
    return true;
  }

  /**
   * スマートメータ区分コード存在チェック
   *
   * @param smartMeterCategoryCode
   *          スマートメータ区分コード
   * @return true チェック成功 false チェック失敗
   */
  private boolean doCheckSmartMeterCategoryCode(String smartMeterCategoryCode) {
    // スマートメータ区分コード存在チェック
    // スマートメータ区分コードがNULLまたは空文字のいずれかでない場合、以下のチェックを行う。
    if (StringUtils.isNotEmpty(smartMeterCategoryCode)) {
      // スマートメータ区分マスタMapper.検索（主キー）を呼び出し。
      // 引数： スマートメータ区分コード
      SmCatM smcatMM = smcatMMapper.selectByPrimaryKey(smartMeterCategoryCode);
      // 返却値が0件の場合、チェック失敗。
      if (smcatMM == null) {
        return false;
      }
    }
    return true;
  }

  /**
   * 契約決定方法コード存在チェック
   *
   * @param smartMeterCategoryCode
   *          契約決定方法コード
   * @return true チェック成功 false チェック失敗
   */
  private boolean doCheckContractDecisionWayCode(String contractDecisionWayCode) {
    // 契約決定方法コード存在チェック
    // 契約決定方法コードがNULLまたは空文字のいずれかでない場合、以下のチェックを行う。
    if (StringUtils.isNotEmpty(contractDecisionWayCode)) {
      // 契約決定方法マスタMapper.検索（主キー）を呼び出し。
      // 引数： 契約決定方法コード
      CdWayM cdWayMM = cdWayMMapper.selectByPrimaryKey(contractDecisionWayCode);
      // 返却値が0件の場合、チェック失敗。
      if (cdWayMM == null) {
        return false;
      }
    }
    return true;
  }

  /**
   * 検針日区分コード存在チェック
   *
   * @param meterReadingDateCategoryCode
   *          検針日区分コード
   * @return true チェック成功 false チェック失敗
   */
  private boolean doCheckMeterReadingDateCategoryCode(String meterReadingDateCategoryCode) {
    // 検針日区分コード存在チェック
    // 検針日区分コードがNULLまたは空文字のいずれかでない場合、以下のチェックを行う。
    if (StringUtils.isNotEmpty(meterReadingDateCategoryCode)) {
      // 検針日区分マスタMapper.検索（主キー）を呼び出し。
      // 引数： 契約決定方法コード
      MrDateCatM mrDateCatM = mrDateCatMMapper.selectByPrimaryKey(meterReadingDateCategoryCode);
      // 返却値が0件の場合、チェック失敗。
      if (mrDateCatM == null) {
        return false;
      }
    }
    return true;
  }

  /**
   * 地点特定番号重複チェック
   *
   * @param spotNo
   *          地点特定番号
   * @return true チェック成功 false チェック失敗
   */
  private boolean doCheckSpotNo(String spotNo) {
    // 《メータ設置場所Entity》の設定
    // 《メータ設置場所Entity》.地点特定番号に引数.地点特定番号を設定する。
    MlExample mlExample = new MlExample();
    mlExample.createCriteria().andSpotNoEqualTo(spotNo);
    // 地点特定番号の検索（件数）を呼び出し。
    // 引数：《メータ設置場所Entity》
    int count = mlMapper.countByExample(mlExample);
    // 返却値.件数が1件以上の場合、以下の処理を行う。
    if (count >= 1) {
      return false;
    }
    return true;
  }

  /**
   * 共通機能を呼出し、オンライン処理基準日を取得する
   *
   * @return オンライン処理基準日
   * @throws BusinessLogicException
   */
  private Date getOnLineDate() throws BusinessLogicException {

    // オンライン処理基準日変数を定義する
    Date returnDate = null;
    try {
      // オンライン処理基準日を取得する
      returnDate = dateBusiness
          .getProcessBaseDate(ECISConstants.EXEC_BASE_DATE_ONLINE);
      // エラーが発生した場合、
    } catch (SystemException e) {
      throw new BusinessLogicException(messageSource.getMessage(
          "error.E0006", new String[] {"オンライン処理基準日" },
          Locale.getDefault()), false);

    }

    // オンライン処理基準日を返却する
    return returnDate;
  }

  /**
   * 登録時スマートメータ区分判定
   *
   * @param automaticMeterReadingCkeckCode
   *          30分値収集可否・自動検針可否コード
   * @return スマートメータ区分コード
   */
  private String decideSmartMeterCategoryForRegist(
      String automaticMeterReadingCkeckCode) {

    // スマートメータ区分コード変数を定義する
    String smartMeterCategoryCode = null;
    // スマートメータ区分コード変数に従来機器を設定する
    smartMeterCategoryCode = ECISCodeConstants.SMART_METER_CATEGORY_CODE_NOT_REPLACED;
    // 30分値収集可否・自動検針可否コードが30分値収集可 自動検針可または30分値収集可 自動検針不可の場合
    if (ECISCodeConstants.AUTOMATIC_METER_READING_CHECK_CODE_AVAILABLE_AVAILABLE
        .equals(automaticMeterReadingCkeckCode)
        || ECISCodeConstants.AUTOMATIC_METER_READING_CHECK_CODE_AVAILABLE_UNAVAILABLE
            .equals(automaticMeterReadingCkeckCode)) {
      // スマートメータ区分コード変数にスマメ切替済を設定する
      smartMeterCategoryCode = ECISCodeConstants.SMART_METER_CATEGORY_CODE_REPLACED_BEFORE_LAST_METER_READING;
    }

    // スマートメータ区分コードを返却する
    return smartMeterCategoryCode;
  }

  /**
   * 更新時スマートメータ区分判定
   *
   * @param smartMeterCategoryCodeChangeBefore
   *          スマートメータ区分コード（変更前）
   * @param automaticMeterReadingCkeckCode
   *          30分値収集可否・自動検針可否コード
   * @return スマートメータ区分コード（変更後）
   */
  private String decideSmartMeterCategoryForUpdate(
      String smartMeterCategoryCodeChangeBefore,
      String automaticMeterReadingCkeckCode) {

    // スマートメータ区分コード（変更後）変数を定義する
    String smartMeterCategoryCodeChangeAfter = null;
    // スマートメータ区分コード（変更後）にスマートメータ区分コード（変更前）を設定する
    smartMeterCategoryCodeChangeAfter = smartMeterCategoryCodeChangeBefore;
    // 30分値収集可否・自動検針可否コードが30分値収集可 自動検針可または30分値収集可 自動検針不可の場合
    if (ECISCodeConstants.AUTOMATIC_METER_READING_CHECK_CODE_AVAILABLE_AVAILABLE
        .equals(automaticMeterReadingCkeckCode)
        || ECISCodeConstants.AUTOMATIC_METER_READING_CHECK_CODE_AVAILABLE_UNAVAILABLE
            .equals(automaticMeterReadingCkeckCode)) {
      // スマートメータ区分コード（変更前）が従来機器の場合
      if (ECISCodeConstants.SMART_METER_CATEGORY_CODE_NOT_REPLACED
          .equals(smartMeterCategoryCodeChangeBefore)) {
        // スマートメータ区分コード（変更後）に前回検針後にスマメ切替を設定する
        smartMeterCategoryCodeChangeAfter = ECISCodeConstants.SMART_METER_CATEGORY_CODE_REPLACED_AFTER_LAST_METER_READING;
        // スマートメータ区分コード（変更前）が前回検針後にスマメ切替後の場合
      } else if (ECISCodeConstants.SMART_METER_CATEGORY_CODE_REPLACED_AFTER_LAST_METER_READING
          .equals(smartMeterCategoryCodeChangeBefore)) {
        // スマートメータ区分コード（変更後）にスマメ切替済を設定する
        smartMeterCategoryCodeChangeAfter = ECISCodeConstants.SMART_METER_CATEGORY_CODE_REPLACED_BEFORE_LAST_METER_READING;
      }
    }

    // スマートメータ区分コード（変更後）を返却する
    return smartMeterCategoryCodeChangeAfter;
  }

  /**
   * プロパティからメッセージを取得する。 パラメータがある場合はバインドさせたメッセージとなる。
   *
   * @param messageKey
   *          メッセージキー
   * @param params
   *          パラメータ配列
   * @return メッセージ
   */
  public String getMessage(String messageKey, Object[] params) {
    return messageSource
        .getMessage(messageKey, params, Locale.getDefault());
  }

  /**
   * メータ設置場所共通Mapperのsetter
   *
   * @param meterLocationInformationCommonMapper
   *          メータ設置場所共通Mapper
   */
  public void setMeterLocationInformationCommonMapper(
      MeterLocationInformationCommonMapper meterLocationInformationCommonMapper) {
    this.meterLocationInformationCommonMapper = meterLocationInformationCommonMapper;
  }

  /**
   * エリアマスタMapperのsetter(DI)
   *
   * @param areaMMapper
   *          エリアマスタMapper
   */
  public void setAreaMMapper(AreaMMapper areaMMapper) {
    this.areaMMapper = areaMMapper;
  }

  /**
   * 送受電区分マスタMapperのsetter(DI)
   *
   * @param transmissionCatMMapper
   *          送受電区分マスタMapper
   */
  public void setTransmissionCatMMapper(
      TransmissionCatMMapper transmissionCatMMapper) {
    this.transmissionCatMMapper = transmissionCatMMapper;
  }

  /**
   * 需要場所Mapperのsetter(DI)
   *
   * @param placeMapper
   *          需要場所Mapper
   */
  public void setPlaceMapper(PlaceMapper placeMapper) {
    this.placeMapper = placeMapper;
  }

  /**
   * 検針日区分マスタMapperのsetter(DI)
   *
   * @param mrDateCatMMapper
   *          検針日区分マスタMapper
   */
  public void setMrDateCatMMapper(MrDateCatMMapper mrDateCatMMapper) {
    this.mrDateCatMMapper = mrDateCatMMapper;
  }

  /**
   * 自家発連携マスタMapperのsetter(DI)
   *
   * @param glcMMapper
   *          自家発連携マスタMapper
   */
  public void setGlcMMapper(GlcMMapper glcMMapper) {
    this.glcMMapper = glcMMapper;
  }

  /**
   * 供給方式マスタMapperのsetter(DI)
   *
   * @param smMMapper
   *          供給方式マスタMapper
   */
  public void setSmMMapper(SmMMapper smMMapper) {
    this.smMMapper = smMMapper;
  }

  /**
   * 30分値収集可否・自動検針可否マスタMapperのsetter(DI)
   *
   * @param amrcMMapper
   *          30分値収集可否・自動検針可否マスタMapper
   */
  public void setAmrcMMapper(AmrcMMapper amrcMMapper) {
    this.amrcMMapper = amrcMMapper;
  }

  /**
   * スマートメータ区分マスタMapperのsetter(DI)
   *
   * @param smcatMMapper
   *          スマートメータ区分マスタMapper
   */
  public void setSmCatMMapper(SmCatMMapper smcatMMapper) {
    this.smcatMMapper = smcatMMapper;
  }

  /**
   * 契約決定方法マスタMapperのsetter(DI)
   *
   * @param cdWayMMapper
   *          契約決定方法マスタMapper
   */
  public void setCdWayMMapper(CdWayMMapper cdWayMMapper) {
    this.cdWayMMapper = cdWayMMapper;
  }

  /**
   * 都道府県マスタMapperのsetter(DI)
   *
   * @param prefectureMMapper
   *          都道府県マスタMapper
   */
  public void setPrefectureMMapper(PrefectureMMapper prefectureMMapper) {
    this.prefectureMMapper = prefectureMMapper;
  }

  /**
   * メータ設置場所Mapperのsetter(DI)
   *
   * @param mlMapper
   *          メータ設置場所Mapper
   */
  public void setMlMapper(MlMapper mlMapper) {
    this.mlMapper = mlMapper;
  }

  /**
   * 日付関連共通ビジネスのsetter(DI)
   *
   * @param dateBusiness
   *          日付関連共通ビジネス
   */
  public void setDateBusiness(DateBusiness dateBusiness) {
    this.dateBusiness = dateBusiness;
  }

  /**
   * messageSourceのsetter(DI)
   *
   * @param messageSource
   *          メッセージソース
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }

  /**
   * 契約管理情報ファイルヘッダーバリデーターのセッター(DI)
   *
   * @param contractManagementInformationFileHeaderValidator
   *          契約管理情報ファイルヘッダーバリデーター
   *
   */
  public void setContractManagementInformationFileHeaderValidator(
      ContractManagementInformationFileHeaderValidator contractManagementInformationFileHeaderValidator) {
    this.contractManagementInformationFileHeaderValidator = contractManagementInformationFileHeaderValidator;
  }

  /**
   * メータ設置場所情報ファイル登録バリデーターのセッター(DI)
   *
   * @param meterLocationInformationFileRegistValidator
   *          メータ設置場所情報ファイル登録バリデーター
   *
   */
  public void setMeterLocationInformationFileRegistValidator(
      MeterLocationInformationFileRegistValidator meterLocationInformationFileRegistValidator) {
    this.meterLocationInformationFileRegistValidator = meterLocationInformationFileRegistValidator;
  }

  /**
   * メータ設置場所情報ファイル登録バリデーターのセッター(DI) （カスタム）
   * 
   * @param customMeterLocationInformationFileRegistValidator
   *          メータ設置場所情報ファイル登録バリデーター
   *
   */
  public void setCustomMeterLocationInformationFileRegistValidator(
      Custom_MeterLocationInformationFileRegistValidator customMeterLocationInformationFileRegistValidator) {
    this.customMeterLocationInformationFileRegistValidator = customMeterLocationInformationFileRegistValidator;
  }

  /**
   * メータ設置場所情報ファイル更新バリデーターのセッター(DI)
   *
   * @param meterLocationInformationFileUpdateValidator
   *          メータ設置場所情報ファイル更新バリデーター
   *
   */
  public void setMeterLocationInformationFileUpdateValidator(
      MeterLocationInformationFileUpdateValidator meterLocationInformationFileUpdateValidator) {
    this.meterLocationInformationFileUpdateValidator = meterLocationInformationFileUpdateValidator;
  }

  /**
   * メータ設置場所情報ファイル更新バリデーターのセッター(DI) （カスタム）
   * 
   * @param meterLocationInformationFileUpdateValidator
   *          メータ設置場所情報ファイル更新バリデーター
   *
   */
  public void setCustomMeterLocationInformationFileUpdateValidator(
      Custom_MeterLocationInformationFileUpdateValidator customMeterLocationInformationFileUpdateValidator) {
    this.customMeterLocationInformationFileUpdateValidator = customMeterLocationInformationFileUpdateValidator;
  }

  /**
   * プロパティのsetter（DI）
   *
   * @param applicationProperties
   *          プロパティ
   */
  public void setApplicationProperties(
      PropertiesFactoryBean applicationProperties) {
    this.applicationProperties = applicationProperties;
  }
}
