package jp.co.unisys.enability.cis.business.kj.model;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * 契約者情報登録・更新（一括登録）BusinessBean
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * 契約者情報ビジネス
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class Custom_ContractManagementInformationFileConfigContractor {

  /** ファイル名接頭辞 */
  public static final String FILE_NAME_PREFIX = "contractor_";

  // ヘッダレコード定義
  /** ヘッダレコード：ファイル種別-パラメータ */
  public static final String HEADER_FILE_KIND_MASK_STRING = "^1$";

  // データレコード定義
  /** タイトル行：イニシャライザで内容を設定する */
  public static final String[] DATA_TITLE_ROW;
  /** データレコード項目数：項目数 */
  public static final int DATA_COLUMN_COUNT;

  /** データレコード：契約者番号-インデックス */
  public static final int DATA_CONTRACTOR_NO_INDEX = 1;
  /** データレコード：契約者番号-名称 */
  public static final String DATA_CONTRACTOR_NO_NAME = "契約者番号";
  /** データレコード：契約者番号-文字数 */
  public static final int DATA_CONTRACTOR_NO_LENGTH = 25;
  /** データレコード：契約者番号-文字数(文字列) */
  public static final String DATA_CONTRACTOR_NO_LENGTH_STRING = String
      .valueOf(DATA_CONTRACTOR_NO_LENGTH);

  /** データレコード：外部システム契約者番号-インデックス */
  public static final int DATA_EXTERNAL_MANAGE_CONTRACTOR_NO_INDEX = 2;
  /** データレコード：外部システム契約者番号-名称 */
  public static final String DATA_EXTERNAL_MANAGE_CONTRACTOR_NO_NAME = "外部システム契約者番号";
  /** データレコード：外部システム契約者番号-文字数 */
  public static final int DATA_EXTERNAL_MANAGE_CONTRACTOR_NO_LENGTH = 11;
  /** データレコード：外部システム契約者番号-文字数(文字列) */
  public static final String DATA_EXTERNAL_MANAGE_CONTRACTOR_NO_LENGTH_STRING = String
      .valueOf(DATA_EXTERNAL_MANAGE_CONTRACTOR_NO_LENGTH);

  /** データレコード：個人・法人区分コード-インデックス */
  public static final int DATA_INDIVIDUAL_LEGAL_ENTITY_CATEGORY_CODE_INDEX = 3;
  /** データレコード：個人・法人区分コード-名称 */
  public static final String DATA_INDIVIDUAL_LEGAL_ENTITY_CATEGORY_CODE_NAME = "個人・法人区分コード";

  /** データレコード：契約者名1（カナ）-インデックス */
  public static final int DATA_CONTRACTOR_NAME1_KANA_INDEX = 4;
  /** データレコード：契約者名1（カナ）-名称 */
  public static final String DATA_CONTRACTOR_NAME1_KANA_NAME = "契約者名1（カナ）";
  /** データレコード：契約者名1（カナ）-文字数 */
  public static final int DATA_CONTRACTOR_NAME1_KANA_LENGTH = 40;
  /** データレコード：契約者名1（カナ）-文字数(文字列) */
  public static final String DATA_CONTRACTOR_NAME1_KANA_LENGTH_STRING = String
      .valueOf(DATA_CONTRACTOR_NAME1_KANA_LENGTH);
  /** データレコード：契約者名1（カナ）-チェック用文字列 */
  public static final String DATA_CONTRACTOR_NAME1_KANA_MASK_STRING = "^[０-９Ａ-Ｚａ-ｚァ-ヶー（）－　]+$";

  /** データレコード：契約者名1-インデックス */
  public static final int DATA_CONTRACTOR_NAME1_INDEX = 5;
  /** データレコード：契約者名1-名称 */
  public static final String DATA_CONTRACTOR_NAME1_NAME = "契約者名1";
  /** データレコード：契約者名1-文字数 */
  public static final int DATA_CONTRACTOR_NAME1_LENGTH = 35;
  /** データレコード：契約者名1-文字数(文字列) */
  public static final String DATA_CONTRACTOR_NAME1_LENGTH_STRING = String
      .valueOf(DATA_CONTRACTOR_NAME1_LENGTH);

  /** データレコード：契約者名2-インデックス */
  public static final int DATA_CONTRACTOR_NAME2_INDEX = 6;
  /** データレコード：契約者名2-名称 */
  public static final String DATA_CONTRACTOR_NAME2_NAME = "契約者名2";
  /** データレコード：契約者名2-文字数 */
  public static final int DATA_CONTRACTOR_NAME2_LENGTH = 35;
  /** データレコード：契約者名2-文字数(文字列) */
  public static final String DATA_CONTRACTOR_NAME2_LENGTH_STRING = String
      .valueOf(DATA_CONTRACTOR_NAME2_LENGTH);

  /** データレコード：契約者名1（宛名用）-インデックス */
  public static final int DATA_CONTRACTOR_NAME1_MAILING_NAME_INDEX = 7;
  /** データレコード：契約者名1（宛名用）-名称 */
  public static final String DATA_CONTRACTOR_NAME1_MAILING_NAME_NAME = "契約者名1（宛名用）";
  /** データレコード：契約者名1（宛名用）-文字数 */
  public static final int DATA_CONTRACTOR_NAME1_MAILING_NAME_LENGTH = 22;
  /** データレコード：契約者名1（宛名用）-文字数(文字列) */
  public static final String DATA_CONTRACTOR_NAME1_MAILING_NAME_LENGTH_STRING = String
      .valueOf(DATA_CONTRACTOR_NAME1_MAILING_NAME_LENGTH);

  /** データレコード：契約者名2（宛名用）-インデックス */
  public static final int DATA_CONTRACTOR_NAME2_MAILING_NAME_INDEX = 8;
  /** データレコード：契約者名2（宛名用）-名称 */
  public static final String DATA_CONTRACTOR_NAME2_MAILING_NAME_NAME = "契約者名2（宛名用）";
  /** データレコード：契約者名2（宛名用）-文字数 */
  public static final int DATA_CONTRACTOR_NAME2_MAILING_NAME_LENGTH = 27;
  /** データレコード：契約者名2（宛名用）-文字数(文字列) */
  public static final String DATA_CONTRACTOR_NAME2_MAILING_NAME_LENGTH_STRING = String
      .valueOf(DATA_CONTRACTOR_NAME2_MAILING_NAME_LENGTH);

  /** データレコード：敬称-インデックス */
  public static final int DATA_PREFIX_INDEX = 9;
  /** データレコード：敬称-名称 */
  public static final String DATA_PREFIX_NAME = "敬称";
  /** データレコード：敬称-文字数 */
  public static final int DATA_PREFIX_LENGTH = 2;
  /** データレコード：敬称-文字数(文字列) */
  public static final String DATA_PREFIX_LENGTH_STRING = String
      .valueOf(DATA_PREFIX_LENGTH);

  /** データレコード：契約者住所（郵便番号）-インデックス */
  public static final int DATA_CONTRACTOR_ADDRESS_POSTAL_CODE_INDEX = 10;
  /** データレコード：契約者住所（郵便番号）-名称 */
  public static final String DATA_CONTRACTOR_ADDRESS_POSTAL_CODE_NAME = "契約者住所（郵便番号）";
  /** データレコード：契約者住所（郵便番号）-文字数 */
  public static final int DATA_CONTRACTOR_ADDRESS_POSTAL_CODE_LENGTH = 7;
  /** データレコード：契約者住所（郵便番号）-文字数(文字列) */
  public static final String DATA_CONTRACTOR_ADDRESS_POSTAL_CODE_LENGTH_STRING = String
      .valueOf(DATA_CONTRACTOR_ADDRESS_POSTAL_CODE_LENGTH);

  /** データレコード：契約者住所（都道府県名）-インデックス */
  public static final int DATA_CONTRACTOR_ADDRESS_PREFECTURES_INDEX = 11;
  /** データレコード：契約者住所（都道府県名）-名称 */
  public static final String DATA_CONTRACTOR_ADDRESS_PREFECTURES_NAME = "契約者住所（都道府県名）";
  /** データレコード：契約者住所（都道府県名）-文字数 */
  public static final int DATA_CONTRACTOR_ADDRESS_PREFECTURES_LENGTH = 4;
  /** データレコード：契約者住所（都道府県名）-文字数(文字列) */
  public static final String DATA_CONTRACTOR_ADDRESS_PREFECTURES_LENGTH_STRING = String
      .valueOf(DATA_CONTRACTOR_ADDRESS_PREFECTURES_LENGTH);

  /** データレコード：契約者住所（市区郡町村名）-インデックス */
  public static final int DATA_CONTRACTOR_ADDRESS_MUNICIPALITY_INDEX = 12;
  /** データレコード：契約者住所（市区郡町村名）-名称 */
  public static final String DATA_CONTRACTOR_ADDRESS_MUNICIPALITY_NAME = "契約者住所（市区郡町村名）";
  /** データレコード：契約者住所（市区郡町村名）-文字数 */
  public static final int DATA_CONTRACTOR_ADDRESS_MUNICIPALITY_LENGTH = 27;
  /** データレコード：契約者住所（市区郡町村名）-文字数(文字列) */
  public static final String DATA_CONTRACTOR_ADDRESS_MUNICIPALITY_LENGTH_STRING = String
      .valueOf(DATA_CONTRACTOR_ADDRESS_MUNICIPALITY_LENGTH);

  /** データレコード：契約者住所（字名・丁目）-インデックス */
  public static final int DATA_CONTRACTOR_ADDRESS_SECTION_INDEX = 13;
  /** データレコード：契約者住所（字名・丁目）-名称 */
  public static final String DATA_CONTRACTOR_ADDRESS_SECTION_NAME = "契約者住所（字名・丁目）";
  /** データレコード：契約者住所（字名・丁目）-文字数 */
  public static final int DATA_CONTRACTOR_ADDRESS_SECTION_LENGTH = 12;
  /** データレコード：契約者住所（字名・丁目）-文字数(文字列) */
  public static final String DATA_CONTRACTOR_ADDRESS_SECTION_LENGTH_STRING = String
      .valueOf(DATA_CONTRACTOR_ADDRESS_SECTION_LENGTH);

  /** データレコード：契約者住所（番地･号）-インデックス */
  public static final int DATA_CONTRACTOR_ADDRESS_BLOCK_INDEX = 14;
  /** データレコード：契約者住所（番地･号）-名称 */
  public static final String DATA_CONTRACTOR_ADDRESS_BLOCK_NAME = "契約者住所（番地･号）";
  /** データレコード：契約者住所（番地･号）-文字数 */
  public static final int DATA_CONTRACTOR_ADDRESS_BLOCK_LENGTH = 10;
  /** データレコード：契約者住所（番地･号）-文字数(文字列) */
  public static final String DATA_CONTRACTOR_ADDRESS_BLOCK_LENGTH_STRING = String
      .valueOf(DATA_CONTRACTOR_ADDRESS_BLOCK_LENGTH);
  /** データレコード：契約者住所（番地･号）-チェック用文字列 */
  public static final String DATA_CONTRACTOR_ADDRESS_BLOCK_MASK_STRING = "^[a-zA-Z0-9]+(-[a-zA-Z0-9]+)*$";

  /** データレコード：契約者住所（建物名）-インデックス */
  public static final int DATA_CONTRACTOR_ADDRESS_BUILDING_NAME_INDEX = 15;
  /** データレコード：契約者住所（建物名）-名称 */
  public static final String DATA_CONTRACTOR_ADDRESS_BUILDING_NAME_NAME = "契約者住所（建物名）";
  /** データレコード：契約者住所（建物名）-文字数 */
  public static final int DATA_CONTRACTOR_ADDRESS_BUILDING_NAME_LENGTH = 25;
  /** データレコード：契約者住所（建物名）-文字数(文字列) */
  public static final String DATA_CONTRACTOR_ADDRESS_BUILDING_NAME_LENGTH_STRING = String
      .valueOf(DATA_CONTRACTOR_ADDRESS_BUILDING_NAME_LENGTH);

  /** データレコード：契約者住所（部屋名）-インデックス */
  public static final int DATA_CONTRACTOR_ADDRESS_ROOM_INDEX = 16;
  /** データレコード：契約者住所（部屋名）-名称 */
  public static final String DATA_CONTRACTOR_ADDRESS_ROOM_NAME = "契約者住所（部屋名）";
  /** データレコード：契約者住所（部屋名）-文字数 */
  public static final int DATA_CONTRACTOR_ADDRESS_ROOM_LENGTH = 10;
  /** データレコード：契約者住所（部屋名）-文字数(文字列) */
  public static final String DATA_CONTRACTOR_ADDRESS_ROOM_LENGTH_STRING = String
      .valueOf(DATA_CONTRACTOR_ADDRESS_ROOM_LENGTH);

  /** データレコード：契約者電話区分コード1-インデックス */
  public static final int DATA_CONTRACTOR_PHONE_CATEGORY_CODE1_INDEX = 17;
  /** データレコード：契約者電話区分コード1-名称 */
  public static final String DATA_CONTRACTOR_PHONE_CATEGORY_CODE1_NAME = "契約者電話区分コード1";

  /** データレコード：契約者電話1（市外局番）-インデックス */
  public static final int DATA_CONTRACTOR_PHONE_AREA_CODE1_INDEX = 18;
  /** データレコード：契約者電話1（市外局番）-名称 */
  public static final String DATA_CONTRACTOR_PHONE_AREA_CODE1_NAME = "契約者電話1（市外局番）";
  /** データレコード：契約者電話1（市外局番）-文字数 */
  public static final int DATA_CONTRACTOR_PHONE_AREA_CODE1_LENGTH = 6;
  /** データレコード：契約者電話1（市外局番）-文字数(文字列) */
  public static final String DATA_CONTRACTOR_PHONE_AREA_CODE1_LENGTH_STRING = String
      .valueOf(DATA_CONTRACTOR_PHONE_AREA_CODE1_LENGTH);

  /** データレコード：契約者電話1（市内局番）-インデックス */
  public static final int DATA_CONTRACTOR_PHONE_LOCAL_NO_INDEX = 19;
  /** データレコード：契約者電話1（市内局番）-名称 */
  public static final String DATA_CONTRACTOR_PHONE_LOCAL_NO_NAME = "契約者電話1（市内局番）";
  /** データレコード：契約者電話1（市内局番）-文字数 */
  public static final int DATA_CONTRACTOR_PHONE_LOCAL_NO_LENGTH = 4;
  /** データレコード：契約者電話1（市内局番）-文字数(文字列) */
  public static final String DATA_CONTRACTOR_PHONE_LOCAL_NO_LENGTH_STRING = String
      .valueOf(DATA_CONTRACTOR_PHONE_LOCAL_NO_LENGTH);

  /** データレコード：契約者電話1（加入者番号）-インデックス */
  public static final int DATA_CONTRACTOR_PHONE_DIRECTORY_NO_INDEX = 20;
  /** データレコード：契約者電話1（加入者番号）-名称 */
  public static final String DATA_CONTRACTOR_PHONE_DIRECTORY_NO_NAME = "契約者電話1（加入者番号）";
  /** データレコード：契約者電話1（加入者番号）-文字数 */
  public static final int DATA_CONTRACTOR_PHONE_DIRECTORY_NO_LENGTH = 6;
  /** データレコード：契約者電話1（加入者番号）-文字数(文字列) */
  public static final String DATA_CONTRACTOR_PHONE_DIRECTORY_NO_LENGTH_STRING = String
      .valueOf(DATA_CONTRACTOR_PHONE_DIRECTORY_NO_LENGTH);

  /** データレコード：契約者電話区分コード2-インデックス */
  public static final int DATA_CONTRACTOR_PHONE_CATEGORY_CODE2_INDEX = 21;
  /** データレコード：契約者電話区分コード2-名称 */
  public static final String DATA_CONTRACTOR_PHONE_CATEGORY_CODE2_NAME = "契約者電話区分コード2";

  /** データレコード：契約者電話2（市外局番）-インデックス */
  public static final int DATA_CONTRACTOR_PHONE_AREA_CODE2_INDEX = 22;
  /** データレコード：契約者電話2（市外局番）-名称 */
  public static final String DATA_CONTRACTOR_PHONE_AREA_CODE2_NAME = "契約者電話2（市外局番）";
  /** データレコード：契約者電話2（市外局番）-文字数 */
  public static final int DATA_CONTRACTOR_PHONE_AREA_CODE2_LENGTH = 6;
  /** データレコード：契約者電話2（市外局番）-文字数(文字列) */
  public static final String DATA_CONTRACTOR_PHONE_AREA_CODE2_LENGTH_STRING = String
      .valueOf(DATA_CONTRACTOR_PHONE_AREA_CODE2_LENGTH);

  /** データレコード：契約者電話2（市内局番）-インデックス */
  public static final int DATA_CONTRACTOR_PHONE_LOCAL_NO2_INDEX = 23;
  /** データレコード：契約者電話2（市内局番）-名称 */
  public static final String DATA_CONTRACTOR_PHONE_LOCAL_NO2_NAME = "契約者電話2（市内局番）";
  /** データレコード：契約者電話2（市内局番）-文字数 */
  public static final int DATA_CONTRACTOR_PHONE_LOCAL_NO2_LENGTH = 4;
  /** データレコード：契約者電話2（市内局番）-文字数(文字列) */
  public static final String DATA_CONTRACTOR_PHONE_LOCAL_NO2_LENGTH_STRING = String
      .valueOf(DATA_CONTRACTOR_PHONE_LOCAL_NO2_LENGTH);

  /** データレコード：契約者電話2（加入者番号）-インデックス */
  public static final int DATA_CONTRACTOR_PHONE_DIRECTORY_NO2_INDEX = 24;
  /** データレコード：契約者電話2（加入者番号）-名称 */
  public static final String DATA_CONTRACTOR_PHONE_DIRECTORY_NO2_NAME = "契約者電話2（加入者番号）";
  /** データレコード：契約者電話2（加入者番号）-文字数 */
  public static final int DATA_CONTRACTOR_PHONE_DIRECTORY_NO2_LENGTH = 6;
  /** データレコード：契約者電話2（加入者番号）-文字数(文字列) */
  public static final String DATA_CONTRACTOR_PHONE_DIRECTORY_NO2_LENGTH_STRING = String
      .valueOf(DATA_CONTRACTOR_PHONE_DIRECTORY_NO2_LENGTH);

  /** データレコード：契約者メールアドレス1-インデックス */
  public static final int DATA_CONTRACTOR_MAIL_ADDRESS1_INDEX = 25;
  /** データレコード：契約者メールアドレス1-名称 */
  public static final String DATA_CONTRACTOR_MAIL_ADDRESS1_NAME = "契約者メールアドレス1";
  /** データレコード：契約者メールアドレス1-文字数 */
  public static final int DATA_CONTRACTOR_MAIL_ADDRESS1_LENGTH = 50;
  /** データレコード：契約者メールアドレス1-文字数(文字列) */
  public static final String DATA_CONTRACTOR_MAIL_ADDRESS1_LENGTH_STRING = String
      .valueOf(DATA_CONTRACTOR_MAIL_ADDRESS1_LENGTH);
  /** データレコード：契約者メールアドレス1-チェック用文字列 */
  public static final String DATA_CONTRACTOR_MAIL_ADDRESS1_MASK_STRING = "(?:[-!#-'*+/-9=?A-Z^-~]+(?:\\.[-!#-'*+/-9=?A-Z^-~]+)*|\"(?:[!#-\\[\\]-~]|\\\\[\\x09 -~])*\")@[-!#-'*+/-9=?A-Z^-~]+(?:\\.[-!#-'*+/-9=?A-Z^-~]+)*";

  /** データレコード：契約者メールアドレス2-インデックス */
  public static final int DATA_CONTRACTOR_MAIL_ADDRESS2_INDEX = 26;
  /** データレコード：契約者メールアドレス2-名称 */
  public static final String DATA_CONTRACTOR_MAIL_ADDRESS2_NAME = "契約者メールアドレス2";
  /** データレコード：契約者メールアドレス2-文字数 */
  public static final int DATA_CONTRACTOR_MAIL_ADDRESS2_LENGTH = 50;
  /** データレコード：契約者メールアドレス2-文字数(文字列) */
  public static final String DATA_CONTRACTOR_MAIL_ADDRESS2_LENGTH_STRING = String
      .valueOf(DATA_CONTRACTOR_MAIL_ADDRESS2_LENGTH);
  /** データレコード：契約者メールアドレス2-チェック用文字列 */
  public static final String DATA_CONTRACTOR_MAIL_ADDRESS2_MASK_STRING = "(?:[-!#-'*+/-9=?A-Z^-~]+(?:\\.[-!#-'*+/-9=?A-Z^-~]+)*|\"(?:[!#-\\[\\]-~]|\\\\[\\x09 -~])*\")@[-!#-'*+/-9=?A-Z^-~]+(?:\\.[-!#-'*+/-9=?A-Z^-~]+)*";

  /** データレコード：提供モデルコード-インデックス */
  public static final int DATA_PROVIDE_MODEL_CODE_INDEX = 27;
  /** データレコード：提供モデルコード-名称 */
  public static final String DATA_PROVIDE_MODEL_CODE_NAME = "提供モデルコード";

  /** データレコード：提供モデル企業コード-インデックス */
  public static final int DATA_PROVIDE_MODEL_COMPANY_CODE_INDEX = 28;
  /** データレコード：提供モデル企業コード-名称 */
  public static final String DATA_PROVIDE_MODEL_COMPANY_CODE_NAME = "提供モデル企業コード";

  /** データレコード：取引先コード-インデックス */
  public static final int DATA_CUSTOMER_CODE_INDEX = 29;
  /** データレコード：取引先コード-名称 */
  public static final String DATA_CUSTOMER_CODE_NAME = "取引先コード";
  /** データレコード：取引先コード-文字数 */
  public static final int DATA_CUSTOMER_CODE_LENGTH = 4;
  /** データレコード：取引先コード-文字数(文字列) */
  public static final String DATA_CUSTOMER_CODE_LENGTH_STRING = String
      .valueOf(DATA_CUSTOMER_CODE_LENGTH);

  /** データレコード：督促対象外フラグ-インデックス */
  public static final int DATA_URGE_NOT_COVERED_FLAG_INDEX = 30;
  /** データレコード：督促対象外フラグ-名称 */
  public static final String DATA_URGE_NOT_COVERED_FLAG_NAME = "督促対象外フラグ";
  /** データレコード：督促対象外フラグ-最小数 */
  public static final int DATA_URGE_NOT_COVERED_FLAG_RANGE_MIN = 0;
  /** データレコード：督促対象外フラグ-最大数 */
  public static final int DATA_URGE_NOT_COVERED_FLAG_RANGE_MAX = 1;
  /** データレコード：督促対象外フラグ-メッセージ文言 */
  public static final String DATA_URGE_NOT_COVERED_FLAG_MESSAGE = new StringBuilder()
      .append(DATA_URGE_NOT_COVERED_FLAG_RANGE_MIN).append("～")
      .append(DATA_URGE_NOT_COVERED_FLAG_RANGE_MAX).toString();

  /** データレコード：見える化提供フラグ-インデックス */
  public static final int DATA_VISUALIZATION_PROVIDE_FLAG_INDEX = 31;
  /** データレコード：見える化提供フラグ-名称 */
  public static final String DATA_VISUALIZATION_PROVIDE_FLAG_NAME = "見える化提供フラグ";
  /** データレコード：見える化提供フラグ-最小数 */
  public static final int DATA_VISUALIZATION_PROVIDE_FLAG_RANGE_MIN = 0;
  /** データレコード：見える化提供フラグ-最大数 */
  public static final int DATA_VISUALIZATION_PROVIDE_FLAG_RANGE_MAX = 1;
  /** データレコード：見える化提供フラグ-メッセージ文言 */
  public static final String DATA_VISUALIZATION_PROVIDE_FLAG_MESSAGE = new StringBuilder()
      .append(DATA_VISUALIZATION_PROVIDE_FLAG_RANGE_MIN).append("～")
      .append(DATA_VISUALIZATION_PROVIDE_FLAG_RANGE_MAX).toString();

  /** データレコード：備考-インデックス */
  public static final int DATA_NOTE_INDEX = 32;
  /** データレコード：備考-名称 */
  public static final String DATA_NOTE_NAME = "備考";
  /** データレコード：備考-文字数 */
  public static final int DATA_NOTE_LENGTH = 200;
  /** データレコード：備考-文字数(文字列) */
  public static final String DATA_NOTE_LENGTH_STRING = String
      .valueOf(DATA_NOTE_LENGTH);

  /** データレコード：利用不能フラグ-インデックス */
  public static final int DATA_UNAVAILABLE_FLAG_INDEX = 33;
  /** データレコード：利用不能フラグ-名称 */
  public static final String DATA_UNAVAILABLE_FLAG_NAME = "利用不能フラグ";
  /** データレコード：利用不能フラグ-最小数 */
  public static final int DATA_UNAVAILABLE_FLAG_RANGE_MIN = 0;
  /** データレコード：利用不能フラグ-最大数 */
  public static final int DATA_UNAVAILABLE_FLAG_RANGE_MAX = 1;
  /** データレコード：利用不能フラグ-メッセージ文言 */
  public static final String DATA_UNAVAILABLE_FLAG_MESSAGE = new StringBuilder()
      .append(DATA_UNAVAILABLE_FLAG_RANGE_MIN).append("～")
      .append(DATA_UNAVAILABLE_FLAG_RANGE_MAX).toString();

  /** データレコード：卸取次店契約者番号-インデックス */
  public static final int DATA_AGENT_CONTRACTOR_NO_INDEX = 34;
  /** データレコード：卸取次店契約者番号-名称 */
  public static final String DATA_AGENT_CONTRACTOR_NO_NAME = "卸取次店契約者番号";
  /** データレコード：卸取次店契約者番号-文字数 */
  public static final int DATA_AGENT_CONTRACTOR_NO_LENGTH = 25;
  /** データレコード：卸取次店契約者番号-文字数(文字列) */
  public static final String DATA_AGENT_CONTRACTOR_NO_LENGTH_STRING = String
      .valueOf(DATA_AGENT_CONTRACTOR_NO_LENGTH);

  /** データレコード：フリー項目1-インデックス */
  public static final int DATA_FREE_01_INDEX = 35;
  /** データレコード：フリー項目1-名称 */
  public static final String DATA_FREE_01_NAME = "フリー項目1";
  /** データレコード：フリー項目1-文字数 */
  public static final int DATA_FREE_01_LENGTH = 200;
  /** データレコード：フリー項目1-文字数(文字列) */
  public static final String DATA_FREE_01_LENGTH_STRING = String
      .valueOf(DATA_FREE_01_LENGTH);

  /** データレコード：フリー項目2-インデックス */
  public static final int DATA_FREE_02_INDEX = 36;
  /** データレコード：フリー項目2-名称 */
  public static final String DATA_FREE_02_NAME = "フリー項目2";
  /** データレコード：フリー項目2-文字数 */
  public static final int DATA_FREE_02_LENGTH = 200;
  /** データレコード：フリー項目2-文字数(文字列) */
  public static final String DATA_FREE_02_LENGTH_STRING = String
      .valueOf(DATA_FREE_02_LENGTH);

  /** データレコード：フリー項目3-インデックス */
  public static final int DATA_FREE_03_INDEX = 37;
  /** データレコード：フリー項目3-名称 */
  public static final String DATA_FREE_03_NAME = "フリー項目3";
  /** データレコード：フリー項目3-文字数 */
  public static final int DATA_FREE_03_LENGTH = 200;
  /** データレコード：フリー項目3-文字数(文字列) */
  public static final String DATA_FREE_03_LENGTH_STRING = String
      .valueOf(DATA_FREE_03_LENGTH);

  /** データレコード：フリー項目4-インデックス */
  public static final int DATA_FREE_04_INDEX = 38;
  /** データレコード：フリー項目4-名称 */
  public static final String DATA_FREE_04_NAME = "フリー項目4";
  /** データレコード：フリー項目4-文字数 */
  public static final int DATA_FREE_04_LENGTH = 200;
  /** データレコード：フリー項目4-文字数(文字列) */
  public static final String DATA_FREE_04_LENGTH_STRING = String
      .valueOf(DATA_FREE_04_LENGTH);

  /** データレコード：フリー項目5-インデックス */
  public static final int DATA_FREE_05_INDEX = 39;
  /** データレコード：フリー項目5-名称 */
  public static final String DATA_FREE_05_NAME = "フリー項目5";
  /** データレコード：フリー項目5-文字数 */
  public static final int DATA_FREE_05_LENGTH = 200;
  /** データレコード：フリー項目5-文字数(文字列) */
  public static final String DATA_FREE_05_LENGTH_STRING = String
      .valueOf(DATA_FREE_05_LENGTH);

  /** データレコード：フリー項目6-インデックス */
  public static final int DATA_FREE_06_INDEX = 40;
  /** データレコード：フリー項目6-名称 */
  public static final String DATA_FREE_06_NAME = "フリー項目6";
  /** データレコード：フリー項目6-文字数 */
  public static final int DATA_FREE_06_LENGTH = 200;
  /** データレコード：フリー項目6-文字数(文字列) */
  public static final String DATA_FREE_06_LENGTH_STRING = String
      .valueOf(DATA_FREE_06_LENGTH);

  /** データレコード：フリー項目7-インデックス */
  public static final int DATA_FREE_07_INDEX = 41;
  /** データレコード：フリー項目7-名称 */
  public static final String DATA_FREE_07_NAME = "フリー項目7";
  /** データレコード：フリー項目7-文字数 */
  public static final int DATA_FREE_07_LENGTH = 200;
  /** データレコード：フリー項目7-文字数(文字列) */
  public static final String DATA_FREE_07_LENGTH_STRING = String
      .valueOf(DATA_FREE_07_LENGTH);

  /** データレコード：フリー項目8-インデックス */
  public static final int DATA_FREE_08_INDEX = 42;
  /** データレコード：フリー項目8-名称 */
  public static final String DATA_FREE_08_NAME = "フリー項目8";
  /** データレコード：フリー項目8-文字数 */
  public static final int DATA_FREE_08_LENGTH = 200;
  /** データレコード：フリー項目8-文字数(文字列) */
  public static final String DATA_FREE_08_LENGTH_STRING = String
      .valueOf(DATA_FREE_08_LENGTH);

  /** データレコード：フリー項目9-インデックス */
  public static final int DATA_FREE_09_INDEX = 43;
  /** データレコード：フリー項目9-名称 */
  public static final String DATA_FREE_09_NAME = "フリー項目9";
  /** データレコード：フリー項目9-文字数 */
  public static final int DATA_FREE_09_LENGTH = 200;
  /** データレコード：フリー項目9-文字数(文字列) */
  public static final String DATA_FREE_09_LENGTH_STRING = String
      .valueOf(DATA_FREE_09_LENGTH);

  /** データレコード：フリー項目10-インデックス */
  public static final int DATA_FREE_10_INDEX = 44;
  /** データレコード：フリー項目10-名称 */
  public static final String DATA_FREE_10_NAME = "フリー項目10";
  /** データレコード：フリー項目10-文字数 */
  public static final int DATA_FREE_10_LENGTH = 200;
  /** データレコード：フリー項目10-文字数(文字列) */
  public static final String DATA_FREE_10_LENGTH_STRING = String
      .valueOf(DATA_FREE_10_LENGTH);

  /** データレコード：更新回数-インデックス */
  public static final int DATA_UPDATE_COUNT_INDEX = 45;
  /** データレコード：更新回数-名称 */
  public static final String DATA_UPDATE_COUNT_NAME = "更新回数";
  /** データレコード：更新回数-最小数 */
  public static final int DATA_UPDATE_COUNT_RANGE_MIN = 0;
  /** データレコード：更新回数-最大数 */
  public static final int DATA_UPDATE_COUNT_RANGE_MAX = 2147483647;
  /** データレコード：更新回数-メッセージ文言 */
  public static final String DATA_UPDATE_COUNT_MESSAGE = new StringBuilder().append(DATA_UPDATE_COUNT_RANGE_MIN)
      .append("～").append(DATA_UPDATE_COUNT_RANGE_MAX)
      .toString();

  /** 市外局番、市内局番、加入者番号を連結し、かつハイフンを除いた最大桁 */
  public static final int PHONE_MAX = 14;

  /** データレコード：登録・更新区分-インデックス */
  public static final int DATA_REGISTER_UPDATE_CATEGORY_INDEX = 46;
  /** データレコード：登録・更新区分-名称 */
  public static final String DATA_REGISTER_UPDATE_CATEGORY_NAME = "登録・更新区分";

  /**
   * staticイニシャライザ.<br>
   * タイトル行の生成を行う<br>
   * インデックス=タイトル配列のインデックスになるため、番号は自動で設定される<br>
   * カラムの追加・削除があった場合に修正が必要
   */
  static {
    Map<Integer, String> titleMap = new HashMap<Integer, String>();

    // 項目を順番に入れ込んでいく
    // レコード種別は共通のものを使う
    titleMap.put(
        ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_INDEX,
        ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_NAME);

    titleMap.put(DATA_CONTRACTOR_NO_INDEX, DATA_CONTRACTOR_NO_NAME);
    titleMap.put(DATA_EXTERNAL_MANAGE_CONTRACTOR_NO_INDEX, DATA_EXTERNAL_MANAGE_CONTRACTOR_NO_NAME);
    titleMap.put(DATA_INDIVIDUAL_LEGAL_ENTITY_CATEGORY_CODE_INDEX,
        DATA_INDIVIDUAL_LEGAL_ENTITY_CATEGORY_CODE_NAME);
    titleMap.put(DATA_CONTRACTOR_NAME1_KANA_INDEX,
        DATA_CONTRACTOR_NAME1_KANA_NAME);
    titleMap.put(DATA_CONTRACTOR_NAME1_INDEX, DATA_CONTRACTOR_NAME1_NAME);
    titleMap.put(DATA_CONTRACTOR_NAME2_INDEX, DATA_CONTRACTOR_NAME2_NAME);
    titleMap.put(DATA_CONTRACTOR_NAME1_MAILING_NAME_INDEX,
        DATA_CONTRACTOR_NAME1_MAILING_NAME_NAME);
    titleMap.put(DATA_CONTRACTOR_NAME2_MAILING_NAME_INDEX,
        DATA_CONTRACTOR_NAME2_MAILING_NAME_NAME);
    titleMap.put(DATA_PREFIX_INDEX, DATA_PREFIX_NAME);
    titleMap.put(DATA_CONTRACTOR_ADDRESS_POSTAL_CODE_INDEX,
        DATA_CONTRACTOR_ADDRESS_POSTAL_CODE_NAME);
    titleMap.put(DATA_CONTRACTOR_ADDRESS_PREFECTURES_INDEX,
        DATA_CONTRACTOR_ADDRESS_PREFECTURES_NAME);
    titleMap.put(DATA_CONTRACTOR_ADDRESS_MUNICIPALITY_INDEX,
        DATA_CONTRACTOR_ADDRESS_MUNICIPALITY_NAME);
    titleMap.put(DATA_CONTRACTOR_ADDRESS_SECTION_INDEX,
        DATA_CONTRACTOR_ADDRESS_SECTION_NAME);
    titleMap.put(DATA_CONTRACTOR_ADDRESS_BLOCK_INDEX,
        DATA_CONTRACTOR_ADDRESS_BLOCK_NAME);
    titleMap.put(DATA_CONTRACTOR_ADDRESS_BUILDING_NAME_INDEX,
        DATA_CONTRACTOR_ADDRESS_BUILDING_NAME_NAME);
    titleMap.put(DATA_CONTRACTOR_ADDRESS_ROOM_INDEX,
        DATA_CONTRACTOR_ADDRESS_ROOM_NAME);
    titleMap.put(DATA_CONTRACTOR_PHONE_CATEGORY_CODE1_INDEX,
        DATA_CONTRACTOR_PHONE_CATEGORY_CODE1_NAME);
    titleMap.put(DATA_CONTRACTOR_PHONE_AREA_CODE1_INDEX,
        DATA_CONTRACTOR_PHONE_AREA_CODE1_NAME);
    titleMap.put(DATA_CONTRACTOR_PHONE_LOCAL_NO_INDEX,
        DATA_CONTRACTOR_PHONE_LOCAL_NO_NAME);
    titleMap.put(DATA_CONTRACTOR_PHONE_DIRECTORY_NO_INDEX,
        DATA_CONTRACTOR_PHONE_DIRECTORY_NO_NAME);
    titleMap.put(DATA_CONTRACTOR_PHONE_CATEGORY_CODE2_INDEX,
        DATA_CONTRACTOR_PHONE_CATEGORY_CODE2_NAME);
    titleMap.put(DATA_CONTRACTOR_PHONE_AREA_CODE2_INDEX,
        DATA_CONTRACTOR_PHONE_AREA_CODE2_NAME);
    titleMap.put(DATA_CONTRACTOR_PHONE_LOCAL_NO2_INDEX,
        DATA_CONTRACTOR_PHONE_LOCAL_NO2_NAME);
    titleMap.put(DATA_CONTRACTOR_PHONE_DIRECTORY_NO2_INDEX,
        DATA_CONTRACTOR_PHONE_DIRECTORY_NO2_NAME);
    titleMap.put(DATA_CONTRACTOR_MAIL_ADDRESS1_INDEX,
        DATA_CONTRACTOR_MAIL_ADDRESS1_NAME);
    titleMap.put(DATA_CONTRACTOR_MAIL_ADDRESS2_INDEX,
        DATA_CONTRACTOR_MAIL_ADDRESS2_NAME);
    titleMap.put(DATA_PROVIDE_MODEL_CODE_INDEX,
        DATA_PROVIDE_MODEL_CODE_NAME);
    titleMap.put(DATA_PROVIDE_MODEL_COMPANY_CODE_INDEX,
        DATA_PROVIDE_MODEL_COMPANY_CODE_NAME);
    titleMap.put(DATA_CUSTOMER_CODE_INDEX, DATA_CUSTOMER_CODE_NAME);
    titleMap.put(DATA_URGE_NOT_COVERED_FLAG_INDEX,
        DATA_URGE_NOT_COVERED_FLAG_NAME);
    titleMap.put(DATA_VISUALIZATION_PROVIDE_FLAG_INDEX,
        DATA_VISUALIZATION_PROVIDE_FLAG_NAME);
    titleMap.put(DATA_NOTE_INDEX, DATA_NOTE_NAME);
    titleMap.put(DATA_UNAVAILABLE_FLAG_INDEX, DATA_UNAVAILABLE_FLAG_NAME);
    titleMap.put(DATA_AGENT_CONTRACTOR_NO_INDEX, DATA_AGENT_CONTRACTOR_NO_NAME);
    titleMap.put(DATA_FREE_01_INDEX, DATA_FREE_01_NAME);
    titleMap.put(DATA_FREE_02_INDEX, DATA_FREE_02_NAME);
    titleMap.put(DATA_FREE_03_INDEX, DATA_FREE_03_NAME);
    titleMap.put(DATA_FREE_04_INDEX, DATA_FREE_04_NAME);
    titleMap.put(DATA_FREE_05_INDEX, DATA_FREE_05_NAME);
    titleMap.put(DATA_FREE_06_INDEX, DATA_FREE_06_NAME);
    titleMap.put(DATA_FREE_07_INDEX, DATA_FREE_07_NAME);
    titleMap.put(DATA_FREE_08_INDEX, DATA_FREE_08_NAME);
    titleMap.put(DATA_FREE_09_INDEX, DATA_FREE_09_NAME);
    titleMap.put(DATA_FREE_10_INDEX, DATA_FREE_10_NAME);
    titleMap.put(DATA_UPDATE_COUNT_INDEX, DATA_UPDATE_COUNT_NAME);
    titleMap.put(DATA_REGISTER_UPDATE_CATEGORY_INDEX,
        DATA_REGISTER_UPDATE_CATEGORY_NAME);

    Iterator<Integer> it = titleMap.keySet().iterator();
    String[] titleArray = new String[titleMap.size()];
    while (it.hasNext()) {
      Integer key = it.next();
      titleArray[key] = titleMap.get(key);
    }
    DATA_TITLE_ROW = titleArray;
    DATA_COLUMN_COUNT = DATA_TITLE_ROW.length;
  }
}
