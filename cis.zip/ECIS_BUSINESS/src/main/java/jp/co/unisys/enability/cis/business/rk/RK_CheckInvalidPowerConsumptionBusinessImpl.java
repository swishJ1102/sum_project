package jp.co.unisys.enability.cis.business.rk;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.config.PropertiesFactoryBean;

import jp.co.unisys.enability.cis.business.rk.model.RK_UsageLinkageCheckCheckDataBusinessBean;
import jp.co.unisys.enability.cis.business.rk.model.RK_UsageLinkageCheckTermDecisionBusinessBean;
import jp.co.unisys.enability.cis.common.util.RK_PropertyUtil;
import jp.co.unisys.enability.cis.common.util.StringConvertUtil;
import jp.co.unisys.enability.cis.common.util.constants.ECISCodeConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;
import jp.co.unisys.enability.cis.entity.common.CcaUnitM;
import jp.co.unisys.enability.cis.entity.common.CcaUnitMExample;
import jp.co.unisys.enability.cis.entity.common.Contract;
import jp.co.unisys.enability.cis.entity.common.ContractExample;
import jp.co.unisys.enability.cis.entity.common.ContractHist;
import jp.co.unisys.enability.cis.entity.common.ContractHistExample;
import jp.co.unisys.enability.cis.entity.common.DemandResult;
import jp.co.unisys.enability.cis.entity.common.DemandResultExample;
import jp.co.unisys.enability.cis.entity.common.Ml;
import jp.co.unisys.enability.cis.entity.common.MlExample;
import jp.co.unisys.enability.cis.mapper.common.CcaUnitMMapper;
import jp.co.unisys.enability.cis.mapper.common.ContractHistMapper;
import jp.co.unisys.enability.cis.mapper.common.ContractMapper;
import jp.co.unisys.enability.cis.mapper.common.DemandResultMapper;
import jp.co.unisys.enability.cis.mapper.common.MlMapper;

/**
 * 30分電力量異常チェックビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.rk.RK_UsageLinkageCheckBusiness
 * @see jp.co.unisys.enability.cis.business.rk.RK_FixUsageCommonBusiness
 * @see jp.co.unisys.enability.cis.mapper.common.DemandResultMapper
 */
public class RK_CheckInvalidPowerConsumptionBusinessImpl implements
    RK_CheckFixUsageBusiness {

  /** プロパティ(DI) */
  private PropertiesFactoryBean applicationProperties;

  /** 料金計算チェックビジネス(DI) */
  private RK_UsageLinkageCheckBusiness rkUsageLinkageCheckBusiness;

  /** 確定使用量共通ビジネス(DI) */
  private RK_FixUsageCommonBusiness rkFixUsageCommonBusiness;

  /** 需要実績Mapper(DI) */
  private DemandResultMapper demandResultMapper;

  /** 契約Mapper(DI) */
  private ContractMapper contractMapper;

  /** 契約履歴Mapper(DI) */
  private ContractHistMapper contractHistMapper;

  /** 契約容量単位Mapper(DI) */
  private CcaUnitMMapper ccaUnitMMapper;

  /** メーター設置場所MApper(DI) */
  private MlMapper mlMapper;

  /** 30分確定電力量上限値 計算用 */
  private static final BigDecimal BD_THOUSAND = BigDecimal.valueOf(1000);
  private static final BigDecimal BD_HUNDRED = BigDecimal.valueOf(100);
  private static final BigDecimal BD_HALF = BigDecimal.valueOf(2);

  /**
   * 30分電力量異常チェック。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連携された30分確定電力量の中に、既定値を超えているものがないか判定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param checkDataBusinessBean
   *          チェック対象ビジネスBean
   * @param termDecisionBusinessBean
   *          期間判定情報ビジネスBean
   * @return true:処理継続、false:処理終了
   */
  @Override
  public boolean check(
      RK_UsageLinkageCheckCheckDataBusinessBean checkDataBusinessBean,
      RK_UsageLinkageCheckTermDecisionBusinessBean termDecisionBusinessBean) {

    // 継続フラグ
    boolean continuation = true;

    // メーター設置場所Example
    MlExample mlExample = new MlExample();

    // 【メーター設置場所】を取得する条件を設定
    // 地点特定番号
    mlExample.createCriteria().andSpotNoEqualTo(checkDataBusinessBean.getSpotNo());

    // メーター設置場所Mapper.selectByExampleを呼び出す
    List<Ml> mlList = mlMapper.selectByExample(mlExample);

    // メーター設置場所Example.送受電区分を変数.送受電区分に設定
    String voltageCategoryCode = mlList.get(0).getTransmissionCatCode();

    // 30分確定電力量上限値
    BigDecimal upperLimit = null;

    // 送受電区分コードが「受電」の場合
    if (ECISCodeConstants.TRANSMISSION_CATEGORY_CODE_RECEIVING.equals(voltageCategoryCode)) {

      // 「使用量連携チェック　30分電力量上限値」を上限に設定
      upperLimit = StringConvertUtil.stringToBigDecimal(RK_PropertyUtil.getProperty(applicationProperties,
          "usagelinkagecheck.fixusage.upperlimit"));

    } else {

      // 契約Example
      ContractExample contractExample = new ContractExample();

      // 【契約】を取得する条件を設定
      contractExample
          .createCriteria()
          // 契約番号
          .andContractNoEqualTo(
              termDecisionBusinessBean.getContractList().get(0)
                  .getContractNo())
          // 契約開始日
          .andContractSdLessThanOrEqualTo(
              termDecisionBusinessBean.getCoveredTermStartDate())
          // 契約終了日
          .andContractEdGreaterThanOrEqualTo(
              termDecisionBusinessBean.getCoveredTermStartDate());

      List<Contract> contractList = contractMapper
          .selectByExample(contractExample);

      // 契約履歴Example
      ContractHistExample contractHistExample = new ContractHistExample();
      // 【契約履歴】を取得する条件を設定
      contractHistExample
          .createCriteria()
          // 契約ID
          .andContractIdEqualTo(contractList.get(0).getContractId())
          // 適用開始日
          .andApplySdLessThanOrEqualTo(
              termDecisionBusinessBean.getCoveredTermStartDate())
          // 適用終了日
          .andApplyEdGreaterThanOrEqualTo(
              termDecisionBusinessBean.getCoveredTermStartDate());

      List<ContractHist> contractHistList = contractHistMapper
          .selectByExample(contractHistExample);

      // 契約電力決定区分コードが'2'（実量制）の場合、returnする。
      if (ECISCodeConstants.CONTRACT_CAPACITY_DECISION_CATEGORY_CODE_REALQUANTITY.equals(contractHistList.get(0)
          .getCcDecisionCategoryCode())) {
        return continuation;
      }

      // 契約容量単位Example
      CcaUnitMExample ccaUnitMExample = new CcaUnitMExample();
      // 【契約履歴】を取得する条件を設定
      ccaUnitMExample.createCriteria()
          // 契約容量単位コード
          .andCcaUnitCodeEqualTo(ECISCodeConstants.CCA_UNIT_AMPERE);

      List<CcaUnitM> ccaUnitMList = ccaUnitMMapper
          .selectByExample(ccaUnitMExample);

      // 低圧-協議制の場合でも、契約容量がnullの場合がある（関西、中国、四国エリア）
      // 契約容量がNullだったら、returnする
      if (contractHistList.get(0).getCca() == null) {
        return continuation;
      }

      // 契約容量単位判定
      if (ccaUnitMList.get(0).getCcaUnit()
          .equals(contractHistList.get(0).getCcaUnit())) {
        upperLimit = contractHistList.get(0).getCca().multiply(BD_HUNDRED).divide(BD_THOUSAND)
            .divide(BD_HALF);
      } else {
        upperLimit = contractHistList.get(0).getCca().divide(BD_HALF);
      }
    }

    // 需要実績Example
    DemandResultExample demandResultExample = new DemandResultExample();

    // 【需要実績】を取得する条件を設定
    demandResultExample
        .createCriteria()
        // 地点特定番号
        .andSpotNoEqualTo(checkDataBusinessBean.getSpotNo())
        // 確定使用量ファイル名
        .andFuFileNameEqualTo(
            checkDataBusinessBean.getFixUsageFileName())
        // エリアコード
        .andAreaCodeEqualTo(checkDataBusinessBean.getAreaCode());

    // 並び順を設定
    // 確定使用量対象日の昇順
    demandResultExample
        .setOrderByClause(ECISRKConstants.CHECK_INVALID_POWER_CONSUMPTION_DEMAND_RESULT_ORDER_BY_CLAUSE);

    // 【需要実績】を取得
    List<DemandResult> demandResultList = demandResultMapper
        .selectByExample(demandResultExample);

    // 30分確定電力量のリスト
    List<BigDecimal> powerConsumptionList = null;

    // 【需要実績】ごとの繰り返し
    for (DemandResult demandResult : demandResultList) {

      // 【需要実績】から30分確定電力量のリストを取得
      powerConsumptionList = rkFixUsageCommonBusiness
          .demandResultToFixUsageList(demandResult);

      // 30分確定電力量ごとの繰り返し
      for (BigDecimal powerConsumption : powerConsumptionList) {

        // 30分確定電力量で上限値を超えているものがあれば、TODOを登録し、
        // 【月次実績】.月次実績エラー区分コードを"エラー"で更新する
        if (powerConsumption.compareTo(upperLimit) > 0) {

          // TODOメッセージを作成するパラメータ
          String[] params = {
              // 確定使用量ファイル名
              checkDataBusinessBean.getFixUsageFileName(),
              // 地点特定番号
              checkDataBusinessBean.getSpotNo(),
              // エリアコード
              checkDataBusinessBean.getAreaCode(),
              // 処理日
              StringConvertUtil.convertDateToString(
                  checkDataBusinessBean.getExecuteDate(),
                  ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
              // 確定使用量対象日
              StringConvertUtil.convertDateToString(
                  demandResult.getFuCoveredDate(), ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
              // 使用量
              powerConsumption.toString() };

          // TODO登録
          rkUsageLinkageCheckBusiness.registerTodo("todo.T1024", params, null, null, null,
              checkDataBusinessBean.getSpotNo(), null);
              
          // 繰り返し処理を終了する
          break;
        }
      }
    }

    return continuation;
  }

  /**
   * 料金計算チェックビジネスを設定します。(DI)
   *
   * @param rkUsageLinkageCheckBusiness
   *          料金計算チェックビジネス
   */
  public void setRkUsageLinkageCheckBusiness(
      RK_UsageLinkageCheckBusiness rkUsageLinkageCheckBusiness) {
    this.rkUsageLinkageCheckBusiness = rkUsageLinkageCheckBusiness;
  }

  /**
   * 確定使用量共通ビジネスを設定します。(DI)
   *
   * @param rkFixUsageCommonBusiness
   *          確定使用量共通ビジネス
   */
  public void setRkFixUsageCommonBusiness(
      RK_FixUsageCommonBusiness rkFixUsageCommonBusiness) {
    this.rkFixUsageCommonBusiness = rkFixUsageCommonBusiness;
  }

  /**
   * 需要実績Mapperを設定します。(DI)
   *
   * @param demandResultMapper
   *          需要実績Mapper
   */
  public void setDemandResultMapper(DemandResultMapper demandResultMapper) {
    this.demandResultMapper = demandResultMapper;
  }

  /**
   * 契約Mapperを設定する。(DI)
   *
   * @param contractMapper
   *          契約Mapper
   */
  public void setContractMapper(ContractMapper contractMapper) {
    this.contractMapper = contractMapper;
  }

  /**
   * 契約履歴Mapperを設定する。(DI)
   *
   * @param contractHistMapper
   *          契約履歴Mapper
   */
  public void setContractHistMapper(ContractHistMapper contractHistMapper) {
    this.contractHistMapper = contractHistMapper;
  }

  /**
   * 契約容量単位Mapperを設定する。(DI)
   *
   * @param ccaUnitMMapper
   *          契約容量単位Mapper
   */
  public void setCcaUnitMMapper(CcaUnitMMapper ccaUnitMMapper) {
    this.ccaUnitMMapper = ccaUnitMMapper;
  }

  /**
   * メーター設置場所Mapperを設定する。(DI)
   *
   * @param mlMapper
   *          メーター設置場所Mapper
   */
  public void setMlMapper(MlMapper mlMapper) {
    this.mlMapper = mlMapper;
  }

  /**
   * プロパティを設定する。
   *
   * @param applicationProperties
   *          プロパティ
   */
  public void setApplicationProperties(
      PropertiesFactoryBean applicationProperties) {
    this.applicationProperties = applicationProperties;
  }
}
