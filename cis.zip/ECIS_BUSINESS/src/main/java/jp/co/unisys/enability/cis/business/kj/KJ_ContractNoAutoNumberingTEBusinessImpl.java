package jp.co.unisys.enability.cis.business.kj;

import java.sql.Timestamp;
import java.util.List;
import java.util.Locale;

import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.MessageSource;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import jp.co.unisys.enability.cis.business.kj.model.RegistAgentContractBusinessBean;
import jp.co.unisys.enability.cis.common.util.KJ_CommonUtil;
import jp.co.unisys.enability.cis.common.util.ThreadContext;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISReturnCodeConstants;
import jp.co.unisys.enability.cis.entity.common.ContractNumberingTeM;
import jp.co.unisys.enability.cis.entity.common.ContractNumberingTeMExample;
import jp.co.unisys.enability.cis.mapper.common.ContractNumberingTeMMapper;

/**
 * 契約番号自動発番ビジネス【東京エコ独自】
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.kj.KJ_ContractNoAutoNumberingBusiness
 *
 */
public class KJ_ContractNoAutoNumberingTEBusinessImpl implements KJ_ContractNoAutoNumberingBusiness {

  /**
   * メッセージプロパティ(DI)
   */
  private MessageSource messageSource;
  /**
   * ログマネジャー
   */
  private static Logger logger = LogManager.getLogger();
  /**
   * 契約番号自動発番マッパー(東京エコ独自)(DI)
   */
  private ContractNumberingTeMMapper contractNumberingTeMMapper;
  /**
   * トランザクションマネージャー(DI)
   */
  private DataSourceTransactionManager txManager;
  /**
   * 契約番号発番シーケンス上限数
   */
  private static final Integer SEQUENCE_MAX_NO = 999;
  /**
   * ロックフラグ0
   */
  private static final String LOCK_FLG_0 = "0";
  /**
   * ロックフラグ1
   */
  private static final String LOCK_FLG_1 = "1";
  /**
   * スリープタイム
   */
  private static final Integer SLEEP_TIME = 500;
  /**
   * リトライ回数
   */
  private static final Integer RETRY = 5;
  /**
   * 契約番号フォーマット(3桁左0埋め)
   */
  private static final String PADDING_CONTRACT_NO = "%03d";

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.kj.
   * KJ_ContractNoAutoNumberingBusiness #regist(jp.co.unisys.enability.cis
   * .business.kj.model.RegistAgentContractBusinessBean)
   */
  @Override
  public void autoNumbering(RegistAgentContractBusinessBean registAgentContractBusinessBean) {

    // トランザクションの開始。
    DefaultTransactionDefinition def = new DefaultTransactionDefinition();
    def.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
    def.setIsolationLevel(TransactionDefinition.ISOLATION_DEFAULT);
    TransactionStatus status = this.txManager.getTransaction(def);
    boolean commitFlg = false;

    try {
      // 契約番号自動発番テーブル（東京エコ独自）を23区コードと業種コードをキーに検索して連番を取得。
      List<ContractNumberingTeM> contractNumberingTeMList = null;
      ContractNumberingTeMExample contractNumberingTeMExample = new ContractNumberingTeMExample();
      contractNumberingTeMExample.createCriteria().andWardCodeEqualTo(registAgentContractBusinessBean.getFree1())
          .andBusinessTypeCodeEqualTo(registAgentContractBusinessBean.getBusinessTypeCode());
      contractNumberingTeMList = contractNumberingTeMMapper.selectByExample(contractNumberingTeMExample);

      // 取得できなかったら、エラー
      if (CollectionUtils.isEmpty(contractNumberingTeMList)) {
        registAgentContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G053);
        registAgentContractBusinessBean
            .setMessage(messageSource
                .getMessage(KJ_CommonUtil.getMessageId(ECISReturnCodeConstants.RETURN_CODE_G053),
                    new String[] {registAgentContractBusinessBean.getFree1(),
                        registAgentContractBusinessBean.getBusinessTypeCode() },
                    Locale.getDefault()));
        commitFlg = false;
        return;
      }

      // ロックフラグ更新レコード
      Timestamp systemDate = new Timestamp(System.currentTimeMillis());
      ContractNumberingTeM lockFlgRecord = new ContractNumberingTeM();
      lockFlgRecord.setLockFlg(LOCK_FLG_1);
      lockFlgRecord.setOnlineUpdateTime(systemDate);
      lockFlgRecord.setOnlineUpdateUserId(
          ThreadContext.getRequestThreadContext().get(ECISConstants.USER_ID_KEY).toString());
      lockFlgRecord.setUpdateTime(systemDate);
      lockFlgRecord.setUpdateModuleCode(
          ThreadContext.getRequestThreadContext().get(ECISConstants.CLASS_NAME_KEY).toString());
      contractNumberingTeMExample = new ContractNumberingTeMExample();
      contractNumberingTeMExample.createCriteria()
          .andWardCodeEqualTo(
              registAgentContractBusinessBean.getFree1())
          .andBusinessTypeCodeEqualTo(
              registAgentContractBusinessBean.getBusinessTypeCode())
          .andLockFlgEqualTo(LOCK_FLG_0);

      // リトライ回数分繰り返す
      for (int i = 0; i < RETRY + 1; i++) {

        // 契約番号自動発番テーブル（東京エコ独自）を23区コードと業種コードをキーにして、ロックフラグ=0を条件にロックフラグを1に更新
        int updateResult = contractNumberingTeMMapper.updateByExampleSelective(lockFlgRecord,
            contractNumberingTeMExample);

        // 更新かけられなかったら、スリープしてリトライ
        if (updateResult == 0) {
          try {
            Thread.sleep(SLEEP_TIME);
          } catch (InterruptedException e) {
            registAgentContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G052);
            registAgentContractBusinessBean.setMessage(messageSource.getMessage(
                KJ_CommonUtil.getMessageId(ECISReturnCodeConstants.RETURN_CODE_G052), new String[] {},
                Locale.getDefault()));
            logger.info(messageSource.getMessage("error.E1616", null, Locale.getDefault()), e);
            commitFlg = false;
            return;
          }
        } else {
          break;
        }
        // リトライ回数の上限に達した場合エラー
        if (i == RETRY) {
          registAgentContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G052);
          registAgentContractBusinessBean.setMessage(messageSource.getMessage(
              KJ_CommonUtil.getMessageId(ECISReturnCodeConstants.RETURN_CODE_G052), new String[] {},
              Locale.getDefault()));
          commitFlg = false;
          return;
        }
      }

      // 連番をインクリメント
      int incrementContractNo = contractNumberingTeMList.get(0).getSequenceNo() + 1;
      // 契約番号が999を超えた場合
      if (SEQUENCE_MAX_NO < incrementContractNo) {
        // リターンコードに(G051)を設定し返却する。
        registAgentContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G051);
        registAgentContractBusinessBean
            .setMessage(messageSource
                .getMessage(KJ_CommonUtil.getMessageId(ECISReturnCodeConstants.RETURN_CODE_G051),
                    new String[] {registAgentContractBusinessBean.getFree1(),
                        registAgentContractBusinessBean.getBusinessTypeCode() },
                    Locale.getDefault()));
        commitFlg = false;
        return;
      }

      // 3桁になるよう左0埋め
      String formatContractNo = String.format(PADDING_CONTRACT_NO, incrementContractNo);

      // 23区コード+業種コード+契約番号
      String autoNumberingContractNo = registAgentContractBusinessBean.getFree1()
          + registAgentContractBusinessBean.getBusinessTypeCode() + formatContractNo;
      registAgentContractBusinessBean.setContractNo(autoNumberingContractNo);

      // 契約番号自動発番テーブル（東京エコ独自）を23区コードと業種コードをキーにして、ロックフラグ=1を条件にロックフラグを0、連番を更新
      ContractNumberingTeM contractNumberingRecord = new ContractNumberingTeM();
      contractNumberingRecord.setLockFlg(LOCK_FLG_0);
      contractNumberingRecord.setSequenceNo(incrementContractNo);
      contractNumberingRecord.setOnlineUpdateTime(systemDate);
      contractNumberingRecord.setOnlineUpdateUserId(
          ThreadContext.getRequestThreadContext().get(ECISConstants.USER_ID_KEY).toString());
      contractNumberingRecord.setUpdateTime(systemDate);
      contractNumberingRecord.setUpdateModuleCode(
          ThreadContext.getRequestThreadContext().get(ECISConstants.CLASS_NAME_KEY).toString());
      contractNumberingTeMExample = new ContractNumberingTeMExample();
      contractNumberingTeMExample
          .createCriteria().andWardCodeEqualTo(
              registAgentContractBusinessBean.getFree1())
          .andBusinessTypeCodeEqualTo(
              registAgentContractBusinessBean
                  .getBusinessTypeCode())
          .andLockFlgEqualTo(LOCK_FLG_1);
      int updateResult = contractNumberingTeMMapper.updateByExampleSelective(contractNumberingRecord,
          contractNumberingTeMExample);

      // 更新できなかったら、エラー
      if (updateResult == 0) {
        registAgentContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G052);
        registAgentContractBusinessBean.setMessage(
            messageSource.getMessage(KJ_CommonUtil.getMessageId(ECISReturnCodeConstants.RETURN_CODE_G052),
                new String[] {}, Locale.getDefault()));
        commitFlg = false;
        return;
      } else {
        // 更新できた場合、コミットフラグtrue
        commitFlg = true;
      }
    } finally {
      if (commitFlg) {
        // コミットフラグがtrueの場合、コミット
        this.txManager.commit(status);
      } else {
        // コミットフラグがfalseの場合、ロールバック
        this.txManager.rollback(status);
      }
    }
  }

  /**
   * メッセージソースのsetter(DI)
   *
   * @param messageSource
   *          メッセージソース
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }

  /**
   * 契約情報共通マッパーのセッター(DI)
   *
   * @param contractNumberingTeMMapper
   *          契約番号自動発番マッパー
   */
  public void setContractNumberingTeMMapper(
      ContractNumberingTeMMapper contractNumberingTeMMapper) {
    this.contractNumberingTeMMapper = contractNumberingTeMMapper;
  }

  /**
   * トランザクションマネージャを設定する。(DI)
   *
   * @param txManager
   *          トランザクションマネージャ
   */
  public void setTxManager(DataSourceTransactionManager txManager) {
    this.txManager = txManager;
  }
}
