package jp.co.unisys.enability.cis.business.sn.model;

/**
 * 請求依頼データBean. 請求依頼データ情報を格納するBeanクラス
 *
 * @author "Nihon Unisys, Ltd."
 */
public class SN_BillingRequestDataBusinessBean extends SN_CreateCsvBusinessBean {

  /** レコード区分 */
  private String recordCategory;

  /** 委託者コード */
  private String consignerCode;

  /** 請求区分コード */
  private String billingCategoryCode;

  /** 決済予定日 */
  private String settlementScheduledDate;

  /** 請求番号 */
  private String billingNo;

  /** 契約者番号 */
  private String contractorNo;

  /** 宛先郵便番号 */
  private String destinationPostalCode;

  /** 宛先住所 */
  private String address;

  /** 宛先住所（都道府県名） */
  private String addressPrefectures;

  /** 宛先住所（市区郡町村名） */
  private String addressMunicipality;

  /** 宛先住所（字名・丁目） */
  private String addressSection;

  /** 宛先住所（番地・号） */
  private String addressBlock;

  /** 宛先住所（建物名） */
  private String addressBuildingName;

  /** 宛先住所（部屋名） */
  private String addressRoom;

  /** 宛先会社名 */
  private String addressCompanyName;

  /** 宛先部課 */
  private String addressDepartment;

  /** 宛先氏名 */
  private String addressName;

  /** 契約者名1 */
  private String contractorName1;

  /** 契約者名2 */
  private String contractorName2;

  /** 支払期日 */
  private String paymentFixedDate;

  /** ご利用年月 */
  private String usePeriod;

  /** 請求額 */
  private String billingAmount;

  /** 消費税相当額 */
  private String consumptionTaxEquivalent;

  /** ご利用金額 */
  private String useAmount;

  /** 預り金等 */
  private String depositsReceived;

  /** 契約数計 */
  private String totalNumberOfContracts;

  /** アクセスキー */
  private String accessKey;

  /** 振込先金融機関コード */
  private String bankCode;

  /** 振込先金融機関名 */
  private String bankName;

  /** 振込先金融機関支店コード */
  private String bankBranchCode;

  /** 振込先金融機関支店名 */
  private String bankBranchName;

  /** 振込先預金種目コード */
  private String bankTypeOfAccountCode;

  /** 振込先預金種目 */
  private String bankTypeOfAccount;

  /** 振込先口座番号 */
  private String accountNo;

  /** 振込先口座名義 */
  private String accountHolderName;

  /** お知らせ */
  private String notification;

  /** 内訳01・名称 */
  private String breakdown01Name;

  /** 内訳01・金額 */
  private String breakdown01Amount;

  /** 内訳02・名称 */
  private String breakdown02Name;

  /** 内訳02・金額 */
  private String breakdown02Amount;

  /** 内訳03・名称 */
  private String breakdown03Name;

  /** 内訳03・金額 */
  private String breakdown03Amount;

  /** 内訳04・名称 */
  private String breakdown04Name;

  /** 内訳04・金額 */
  private String breakdown04Amount;

  /** 内訳05・名称 */
  private String breakdown05Name;

  /** 内訳05・金額 */
  private String breakdown05Amount;

  /** 内訳06・名称 */
  private String breakdown06Name;

  /** 内訳06・金額 */
  private String breakdown06Amount;

  /** 内訳07・名称 */
  private String breakdown07Name;

  /** 内訳07・金額 */
  private String breakdown07Amount;

  /** 内訳08・名称 */
  private String breakdown08Name;

  /** 内訳08・金額 */
  private String breakdown08Amount;

  /** 内訳09・名称 */
  private String breakdown09Name;

  /** 内訳09・金額 */
  private String breakdown09Amount;

  /** 内訳10・名称 */
  private String breakdown10Name;

  /** 内訳10・金額 */
  private String breakdown10Amount;

  /** 内訳11・名称 */
  private String breakdown11Name;

  /** 内訳11・金額 */
  private String breakdown11Amount;

  /** 内訳12・名称 */
  private String breakdown12Name;

  /** 内訳12・金額 */
  private String breakdown12Amount;

  /** 内訳13・名称 */
  private String breakdown13Name;

  /** 内訳13・金額 */
  private String breakdown13Amount;

  /**
   * レコード区分を設定する。
   *
   * @param recordCategory
   *          レコード区分
   */
  public void setRecordCategory(String recordCategory) {
    this.recordCategory = recordCategory;
  }

  /**
   * レコード区分を取得する。
   *
   * @return レコード区分
   */
  public String getRecordCategory() {
    return this.recordCategory;
  }

  /**
   * 委託者コードを設定する。
   *
   * @param consignerCode
   *          委託者コード
   */
  public void setConsignerCode(String consignerCode) {
    this.consignerCode = consignerCode;
  }

  /**
   * 委託者コードを取得する。
   *
   * @return 委託者コード
   */
  public String getConsignerCode() {
    return this.consignerCode;
  }

  /**
   * 請求区分コードを設定する。
   *
   * @param billingCategoryCode
   *          請求区分コード
   */
  public void setBillingCategoryCode(String billingCategoryCode) {
    this.billingCategoryCode = billingCategoryCode;
  }

  /**
   * 請求区分コードを取得する。
   *
   * @return 請求区分コード
   */
  public String getBillingCategoryCode() {
    return this.billingCategoryCode;
  }

  /**
   * 決済予定日を設定する。
   *
   * @param settlementScheduledDate
   *          決済予定日
   */
  public void setSettlementScheduledDate(String settlementScheduledDate) {
    this.settlementScheduledDate = settlementScheduledDate;
  }

  /**
   * 決済予定日を取得する。
   *
   * @return 決済予定日
   */
  public String getSettlementScheduledDate() {
    return this.settlementScheduledDate;
  }

  /**
   * 請求番号を設定する。
   *
   * @param billingNo
   *          請求番号
   */
  public void setBillingNo(String billingNo) {
    this.billingNo = billingNo;
  }

  /**
   * 請求番号を取得する。
   *
   * @return 請求番号
   */
  public String getBillingNo() {
    return this.billingNo;
  }

  /**
   * 契約者番号を設定する。
   *
   * @param contractorNo
   *          契約者番号
   */
  public void setContractorNo(String contractorNo) {
    this.contractorNo = contractorNo;
  }

  /**
   * 契約者番号を取得する。
   *
   * @return 契約者番号
   */
  public String getContractorNo() {
    return this.contractorNo;
  }

  /**
   * 宛先郵便番号を設定する。
   *
   * @param destinationPostalCode
   *          宛先郵便番号
   */
  public void setDestinationPostalCode(String destinationPostalCode) {
    this.destinationPostalCode = destinationPostalCode;
  }

  /**
   * 宛先郵便番号を取得する。
   *
   * @return 宛先郵便番号
   */
  public String getDestinationPostalCode() {
    return this.destinationPostalCode;
  }

  /**
   * 宛先住所を設定する。
   *
   * @param address
   *          宛先住所
   */
  public void setAddress(String address) {
    this.address = address;
  }

  /**
   * 宛先住所を取得する。
   *
   * @return 宛先住所
   */
  public String getAddress() {
    return this.address;
  }

  /**
   * 宛先住所（都道府県名）を設定する。
   *
   * @param addressPrefectures
   *          宛先住所（都道府県名）
   */
  public void setAddressPrefectures(String addressPrefectures) {
    this.addressPrefectures = addressPrefectures;
  }

  /**
   * 宛先住所（都道府県名）を取得する。
   *
   * @return 宛先住所（都道府県名）
   */
  public String getAddressPrefectures() {
    return this.addressPrefectures;
  }

  /**
   * 宛先住所（市区郡町村名）を設定する。
   *
   * @param addressMunicipality
   *          宛先住所（市区郡町村名）
   */
  public void setAddressMunicipality(String addressMunicipality) {
    this.addressMunicipality = addressMunicipality;
  }

  /**
   * 宛先住所（市区郡町村名）を取得する。
   *
   * @return 宛先住所（市区郡町村名）
   */
  public String getAddressMunicipality() {
    return this.addressMunicipality;
  }

  /**
   * 宛先住所（字名・丁目）を設定する。
   *
   * @param addressSection
   *          宛先住所（字名・丁目）
   */
  public void setAddressSection(String addressSection) {
    this.addressSection = addressSection;
  }

  /**
   * 宛先住所（字名・丁目）を取得する。
   *
   * @return 宛先住所（字名・丁目）
   */
  public String getAddressSection() {
    return this.addressSection;
  }

  /**
   * 宛先住所（番地・号）を設定する。
   *
   * @param addressBlock
   *          宛先住所（番地・号）
   */
  public void setAddressBlock(String addressBlock) {
    this.addressBlock = addressBlock;
  }

  /**
   * 宛先住所（番地・号）を取得する。
   *
   * @return 宛先住所（番地・号）
   */
  public String getAddressBlock() {
    return this.addressBlock;
  }

  /**
   * 宛先住所（建物名）を設定する。
   *
   * @param addressBuildingName
   *          宛先住所（建物名）
   */
  public void setAddressBuildingName(String addressBuildingName) {
    this.addressBuildingName = addressBuildingName;
  }

  /**
   * 宛先住所（建物名）を取得する。
   *
   * @return 宛先住所（建物名）
   */
  public String getAddressBuildingName() {
    return this.addressBuildingName;
  }

  /**
   * 宛先住所（部屋名）を設定する。
   *
   * @param addressRoom
   *          宛先住所（部屋名）
   */
  public void setAddressRoom(String addressRoom) {
    this.addressRoom = addressRoom;
  }

  /**
   * 宛先住所（部屋名）を取得する。
   *
   * @return 宛先住所（部屋名）
   */
  public String getAddressRoom() {
    return this.addressRoom;
  }

  /**
   * 宛先会社名を設定する。
   *
   * @param addressCompanyName
   *          宛先会社名
   */
  public void setAddressCompanyName(String addressCompanyName) {
    this.addressCompanyName = addressCompanyName;
  }

  /**
   * 宛先会社名を取得する。
   *
   * @return 宛先会社名
   */
  public String getAddressCompanyName() {
    return this.addressCompanyName;
  }

  /**
   * 宛先部課を設定する。
   *
   * @param addressDepartment
   *          宛先部課
   */
  public void setAddressDepartment(String addressDepartment) {
    this.addressDepartment = addressDepartment;
  }

  /**
   * 宛先部課を取得する。
   *
   * @return 宛先部課
   */
  public String getAddressDepartment() {
    return this.addressDepartment;
  }

  /**
   * 宛先氏名を設定する。
   *
   * @param addressName
   *          宛先氏名
   */
  public void setAddressName(String addressName) {
    this.addressName = addressName;
  }

  /**
   * 宛先氏名を取得する。
   *
   * @return 宛先氏名
   */
  public String getAddressName() {
    return this.addressName;
  }

  /**
   * 契約者名1を設定する。
   *
   * @param contractorName1
   *          契約者名1
   */
  public void setContractorName1(String contractorName1) {
    this.contractorName1 = contractorName1;
  }

  /**
   * 契約者名1を取得する。
   *
   * @return 契約者名1
   */
  public String getContractorName1() {
    return this.contractorName1;
  }

  /**
   * 契約者名2を設定する。
   *
   * @param contractorName2
   *          契約者名2
   */
  public void setContractorName2(String contractorName2) {
    this.contractorName2 = contractorName2;
  }

  /**
   * 契約者名2を取得する。
   *
   * @return 契約者名2
   */
  public String getContractorName2() {
    return this.contractorName2;
  }

  /**
   * 支払期日を設定する。
   *
   * @param paymentFixedDate
   *          支払期日
   */
  public void setPaymentFixedDate(String paymentFixedDate) {
    this.paymentFixedDate = paymentFixedDate;
  }

  /**
   * 支払期日を取得する。
   *
   * @return 支払期日
   */
  public String getPaymentFixedDate() {
    return this.paymentFixedDate;
  }

  /**
   * ご利用年月を設定する。
   *
   * @param usePeriod
   *          ご利用年月
   */
  public void setUsePeriod(String usePeriod) {
    this.usePeriod = usePeriod;
  }

  /**
   * ご利用年月を取得する。
   *
   * @return ご利用年月
   */
  public String getUsePeriod() {
    return this.usePeriod;
  }

  /**
   * 請求額を設定する。
   *
   * @param billingAmount
   *          請求額
   */
  public void setBillingAmount(String billingAmount) {
    this.billingAmount = billingAmount;
  }

  /**
   * 請求額を取得する。
   *
   * @return 請求額
   */
  public String getBillingAmount() {
    return this.billingAmount;
  }

  /**
   * 消費税相当額を設定する。
   *
   * @param consumptionTaxEquivalent
   *          消費税相当額
   */
  public void setConsumptionTaxEquivalent(String consumptionTaxEquivalent) {
    this.consumptionTaxEquivalent = consumptionTaxEquivalent;
  }

  /**
   * 消費税相当額を取得する。
   *
   * @return 消費税相当額
   */
  public String getConsumptionTaxEquivalent() {
    return this.consumptionTaxEquivalent;
  }

  /**
   * ご利用金額を設定する。
   *
   * @param useAmount
   *          ご利用金額
   */
  public void setUseAmount(String useAmount) {
    this.useAmount = useAmount;
  }

  /**
   * ご利用金額を取得する。
   *
   * @return ご利用金額
   */
  public String getUseAmount() {
    return this.useAmount;
  }

  /**
   * 預り金等を設定する。
   *
   * @param depositsReceived
   *          預り金等
   */
  public void setDepositsReceived(String depositsReceived) {
    this.depositsReceived = depositsReceived;
  }

  /**
   * 預り金等を取得する。
   *
   * @return 預り金等
   */
  public String getDepositsReceived() {
    return this.depositsReceived;
  }

  /**
   * 契約数計を設定する。
   *
   * @param totalNumberOfContracts
   *          契約数計
   */
  public void setTotalNumberOfContracts(String totalNumberOfContracts) {
    this.totalNumberOfContracts = totalNumberOfContracts;
  }

  /**
   * 契約数計を取得する。
   *
   * @return 契約数計
   */
  public String getTotalNumberOfContracts() {
    return this.totalNumberOfContracts;
  }

  /**
   * アクセスキーを設定する。
   *
   * @param accessKey
   *          アクセスキー
   */
  public void setAccessKey(String accessKey) {
    this.accessKey = accessKey;
  }

  /**
   * アクセスキーを取得する。
   *
   * @return アクセスキー
   */
  public String getAccessKey() {
    return this.accessKey;
  }

  /**
   * 振込先金融機関コードを設定する。
   *
   * @param bankCode
   *          振込先金融機関コード
   */
  public void setBankCode(String bankCode) {
    this.bankCode = bankCode;
  }

  /**
   * 振込先金融機関コードを取得する。
   *
   * @return 振込先金融機関コード
   */
  public String getBankCode() {
    return this.bankCode;
  }

  /**
   * 振込先金融機関名を設定する。
   *
   * @param bankName
   *          振込先金融機関名
   */
  public void setBankName(String bankName) {
    this.bankName = bankName;
  }

  /**
   * 振込先金融機関名を取得する。
   *
   * @return 振込先金融機関名
   */
  public String getBankName() {
    return this.bankName;
  }

  /**
   * 振込先金融機関支店コードを設定する。
   *
   * @param bankBranchCode
   *          振込先金融機関支店コード
   */
  public void setBankBranchCode(String bankBranchCode) {
    this.bankBranchCode = bankBranchCode;
  }

  /**
   * 振込先金融機関支店コードを取得する。
   *
   * @return 振込先金融機関支店コード
   */
  public String getBankBranchCode() {
    return this.bankBranchCode;
  }

  /**
   * 振込先金融機関支店名を設定する。
   *
   * @param bankBranchName
   *          振込先金融機関支店名
   */
  public void setBankBranchName(String bankBranchName) {
    this.bankBranchName = bankBranchName;
  }

  /**
   * 振込先金融機関支店名を取得する。
   *
   * @return 振込先金融機関支店名
   */
  public String getBankBranchName() {
    return this.bankBranchName;
  }

  /**
   * 振込先預金種目コードを設定する。
   *
   * @param bankTypeOfAccountCode
   *          振込先預金種目コード
   */
  public void setBankTypeOfAccountCode(String bankTypeOfAccountCode) {
    this.bankTypeOfAccountCode = bankTypeOfAccountCode;
  }

  /**
   * 振込先預金種目コードを取得する。
   *
   * @return 振込先預金種目コード
   */
  public String getBankTypeOfAccountCode() {
    return this.bankTypeOfAccountCode;
  }

  /**
   * 振込先預金種目を設定する。
   *
   * @param bankTypeOfAccount
   *          振込先預金種目
   */
  public void setBankTypeOfAccount(String bankTypeOfAccount) {
    this.bankTypeOfAccount = bankTypeOfAccount;
  }

  /**
   * 振込先預金種目を取得する。
   *
   * @return 振込先預金種目
   */
  public String getBankTypeOfAccount() {
    return this.bankTypeOfAccount;
  }

  /**
   * 振込先口座番号を設定する。
   *
   * @param accountNo
   *          振込先口座番号
   */
  public void setAccountNo(String accountNo) {
    this.accountNo = accountNo;
  }

  /**
   * 振込先口座番号を取得する。
   *
   * @return 振込先口座番号
   */
  public String getAccountNo() {
    return this.accountNo;
  }

  /**
   * 振込先口座名義を設定する。
   *
   * @param accountHolderName
   *          振込先口座名義
   */
  public void setAccountHolderName(String accountHolderName) {
    this.accountHolderName = accountHolderName;
  }

  /**
   * 振込先口座名義を取得する。
   *
   * @return 振込先口座名義
   */
  public String getAccountHolderName() {
    return this.accountHolderName;
  }

  /**
   * お知らせを設定する。
   *
   * @param notification
   *          お知らせ
   */
  public void setNotification(String notification) {
    this.notification = notification;
  }

  /**
   * お知らせを取得する。
   *
   * @return お知らせ
   */
  public String getNotification() {
    return this.notification;
  }

  /**
   * 内訳01・名称を設定する。
   *
   * @param breakdown01Name
   *          内訳01・名称
   */
  public void setBreakdown01Name(String breakdown01Name) {
    this.breakdown01Name = breakdown01Name;
  }

  /**
   * 内訳01・名称を取得する。
   *
   * @return 内訳01・名称
   */
  public String getBreakdown01Name() {
    return this.breakdown01Name;
  }

  /**
   * 内訳01・金額を設定する。
   *
   * @param breakdown01Amount
   *          内訳01・金額
   */
  public void setBreakdown01Amount(String breakdown01Amount) {
    this.breakdown01Amount = breakdown01Amount;
  }

  /**
   * 内訳01・金額を取得する。
   *
   * @return 内訳01・金額
   */
  public String getBreakdown01Amount() {
    return this.breakdown01Amount;
  }

  /**
   * 内訳02・名称を設定する。
   *
   * @param breakdown02Name
   *          内訳02・名称
   */
  public void setBreakdown02Name(String breakdown02Name) {
    this.breakdown02Name = breakdown02Name;
  }

  /**
   * 内訳02・名称を取得する。
   *
   * @return 内訳02・名称
   */
  public String getBreakdown02Name() {
    return this.breakdown02Name;
  }

  /**
   * 内訳02・金額を設定する。
   *
   * @param breakdown02Amount
   *          内訳02・金額
   */
  public void setBreakdown02Amount(String breakdown02Amount) {
    this.breakdown02Amount = breakdown02Amount;
  }

  /**
   * 内訳02・金額を取得する。
   *
   * @return 内訳02・金額
   */
  public String getBreakdown02Amount() {
    return this.breakdown02Amount;
  }

  /**
   * 内訳03・名称を設定する。
   *
   * @param breakdown03Name
   *          内訳03・名称
   */
  public void setBreakdown03Name(String breakdown03Name) {
    this.breakdown03Name = breakdown03Name;
  }

  /**
   * 内訳03・名称を取得する。
   *
   * @return 内訳03・名称
   */
  public String getBreakdown03Name() {
    return this.breakdown03Name;
  }

  /**
   * 内訳03・金額を設定する。
   *
   * @param breakdown03Amount
   *          内訳03・金額
   */
  public void setBreakdown03Amount(String breakdown03Amount) {
    this.breakdown03Amount = breakdown03Amount;
  }

  /**
   * 内訳03・金額を取得する。
   *
   * @return 内訳03・金額
   */
  public String getBreakdown03Amount() {
    return this.breakdown03Amount;
  }

  /**
   * 内訳04・名称を設定する。
   *
   * @param breakdown04Name
   *          内訳04・名称
   */
  public void setBreakdown04Name(String breakdown04Name) {
    this.breakdown04Name = breakdown04Name;
  }

  /**
   * 内訳04・名称を取得する。
   *
   * @return 内訳04・名称
   */
  public String getBreakdown04Name() {
    return this.breakdown04Name;
  }

  /**
   * 内訳04・金額を設定する。
   *
   * @param breakdown04Amount
   *          内訳04・金額
   */
  public void setBreakdown04Amount(String breakdown04Amount) {
    this.breakdown04Amount = breakdown04Amount;
  }

  /**
   * 内訳04・金額を取得する。
   *
   * @return 内訳04・金額
   */
  public String getBreakdown04Amount() {
    return this.breakdown04Amount;
  }

  /**
   * 内訳05・名称を設定する。
   *
   * @param breakdown05Name
   *          内訳05・名称
   */
  public void setBreakdown05Name(String breakdown05Name) {
    this.breakdown05Name = breakdown05Name;
  }

  /**
   * 内訳05・名称を取得する。
   *
   * @return 内訳05・名称
   */
  public String getBreakdown05Name() {
    return this.breakdown05Name;
  }

  /**
   * 内訳05・金額を設定する。
   *
   * @param breakdown05Amount
   *          内訳05・金額
   */
  public void setBreakdown05Amount(String breakdown05Amount) {
    this.breakdown05Amount = breakdown05Amount;
  }

  /**
   * 内訳05・金額を取得する。
   *
   * @return 内訳05・金額
   */
  public String getBreakdown05Amount() {
    return this.breakdown05Amount;
  }

  /**
   * 内訳06・名称を設定する。
   *
   * @param breakdown06Name
   *          内訳06・名称
   */
  public void setBreakdown06Name(String breakdown06Name) {
    this.breakdown06Name = breakdown06Name;
  }

  /**
   * 内訳06・名称を取得する。
   *
   * @return 内訳06・名称
   */
  public String getBreakdown06Name() {
    return this.breakdown06Name;
  }

  /**
   * 内訳06・金額を設定する。
   *
   * @param breakdown06Amount
   *          内訳06・金額
   */
  public void setBreakdown06Amount(String breakdown06Amount) {
    this.breakdown06Amount = breakdown06Amount;
  }

  /**
   * 内訳06・金額を取得する。
   *
   * @return 内訳06・金額
   */
  public String getBreakdown06Amount() {
    return this.breakdown06Amount;
  }

  /**
   * 内訳07・名称を設定する。
   *
   * @param breakdown07Name
   *          内訳07・名称
   */
  public void setBreakdown07Name(String breakdown07Name) {
    this.breakdown07Name = breakdown07Name;
  }

  /**
   * 内訳07・名称を取得する。
   *
   * @return 内訳07・名称
   */
  public String getBreakdown07Name() {
    return this.breakdown07Name;
  }

  /**
   * 内訳07・金額を設定する。
   *
   * @param breakdown07Amount
   *          内訳07・金額
   */
  public void setBreakdown07Amount(String breakdown07Amount) {
    this.breakdown07Amount = breakdown07Amount;
  }

  /**
   * 内訳07・金額を取得する。
   *
   * @return 内訳07・金額
   */
  public String getBreakdown07Amount() {
    return this.breakdown07Amount;
  }

  /**
   * 内訳08・名称を設定する。
   *
   * @param breakdown08Name
   *          内訳08・名称
   */
  public void setBreakdown08Name(String breakdown08Name) {
    this.breakdown08Name = breakdown08Name;
  }

  /**
   * 内訳08・名称を取得する。
   *
   * @return 内訳08・名称
   */
  public String getBreakdown08Name() {
    return this.breakdown08Name;
  }

  /**
   * 内訳08・金額を設定する。
   *
   * @param breakdown08Amount
   *          内訳08・金額
   */
  public void setBreakdown08Amount(String breakdown08Amount) {
    this.breakdown08Amount = breakdown08Amount;
  }

  /**
   * 内訳08・金額を取得する。
   *
   * @return 内訳08・金額
   */
  public String getBreakdown08Amount() {
    return this.breakdown08Amount;
  }

  /**
   * 内訳09・名称を設定する。
   *
   * @param breakdown09Name
   *          内訳09・名称
   */
  public void setBreakdown09Name(String breakdown09Name) {
    this.breakdown09Name = breakdown09Name;
  }

  /**
   * 内訳09・名称を取得する。
   *
   * @return 内訳09・名称
   */
  public String getBreakdown09Name() {
    return this.breakdown09Name;
  }

  /**
   * 内訳09・金額を設定する。
   *
   * @param breakdown09Amount
   *          内訳09・金額
   */
  public void setBreakdown09Amount(String breakdown09Amount) {
    this.breakdown09Amount = breakdown09Amount;
  }

  /**
   * 内訳09・金額を取得する。
   *
   * @return 内訳09・金額
   */
  public String getBreakdown09Amount() {
    return this.breakdown09Amount;
  }

  /**
   * 内訳10・名称を設定する。
   *
   * @param breakdown10Name
   *          内訳10・名称
   */
  public void setBreakdown10Name(String breakdown10Name) {
    this.breakdown10Name = breakdown10Name;
  }

  /**
   * 内訳10・名称を取得する。
   *
   * @return 内訳10・名称
   */
  public String getBreakdown10Name() {
    return this.breakdown10Name;
  }

  /**
   * 内訳10・金額を設定する。
   *
   * @param breakdown10Amount
   *          内訳10・金額
   */
  public void setBreakdown10Amount(String breakdown10Amount) {
    this.breakdown10Amount = breakdown10Amount;
  }

  /**
   * 内訳10・金額を取得する。
   *
   * @return 内訳10・金額
   */
  public String getBreakdown10Amount() {
    return this.breakdown10Amount;
  }

  /**
   * 内訳11・名称を設定する。
   *
   * @param breakdown11Name
   *          内訳11・名称
   */
  public void setBreakdown11Name(String breakdown11Name) {
    this.breakdown11Name = breakdown11Name;
  }

  /**
   * 内訳11・名称を取得する。
   *
   * @return 内訳11・名称
   */
  public String getBreakdown11Name() {
    return this.breakdown11Name;
  }

  /**
   * 内訳11・金額を設定する。
   *
   * @param breakdown11Amount
   *          内訳11・金額
   */
  public void setBreakdown11Amount(String breakdown11Amount) {
    this.breakdown11Amount = breakdown11Amount;
  }

  /**
   * 内訳11・金額を取得する。
   *
   * @return 内訳11・金額
   */
  public String getBreakdown11Amount() {
    return this.breakdown11Amount;
  }

  /**
   * 内訳12・名称を設定する。
   *
   * @param breakdown12Name
   *          内訳12・名称
   */
  public void setBreakdown12Name(String breakdown12Name) {
    this.breakdown12Name = breakdown12Name;
  }

  /**
   * 内訳12・名称を取得する。
   *
   * @return 内訳12・名称
   */
  public String getBreakdown12Name() {
    return this.breakdown12Name;
  }

  /**
   * 内訳12・金額を設定する。
   *
   * @param breakdown12Amount
   *          内訳12・金額
   */
  public void setBreakdown12Amount(String breakdown12Amount) {
    this.breakdown12Amount = breakdown12Amount;
  }

  /**
   * 内訳12・金額を取得する。
   *
   * @return 内訳12・金額
   */
  public String getBreakdown12Amount() {
    return this.breakdown12Amount;
  }

  /**
   * 内訳13・名称を設定する。
   *
   * @param breakdown13Name
   *          内訳13・名称
   */
  public void setBreakdown13Name(String breakdown13Name) {
    this.breakdown13Name = breakdown13Name;
  }

  /**
   * 内訳13・名称を取得する。
   *
   * @return 内訳13・名称
   */
  public String getBreakdown13Name() {
    return this.breakdown13Name;
  }

  /**
   * 内訳13・金額を設定する。
   *
   * @param breakdown13Amount
   *          内訳13・金額
   */
  public void setBreakdown13Amount(String breakdown13Amount) {
    this.breakdown13Amount = breakdown13Amount;
  }

  /**
   * 内訳13・金額を取得する。
   *
   * @return 内訳13・金額
   */
  public String getBreakdown13Amount() {
    return this.breakdown13Amount;
  }

}