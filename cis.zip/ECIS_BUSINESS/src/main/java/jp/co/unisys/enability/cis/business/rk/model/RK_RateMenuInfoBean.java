/*-------------------------------------------------------------------------------
 * All Rights Reserved. Copyright(C) Nihon Unisys, Ltd.
 * vendor : Nihon Unisys, Ltd.
 * create : 2016/04/20
 *-----------------------------------------------------------------------------*/
package jp.co.unisys.enability.cis.business.rk.model;

import java.math.BigDecimal;
import java.util.List;

/**
 * 使用量CSV仕訳ビジネスの料金メニュー毎の情報を保持するBeanクラス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_RateMenuInfoBean {

  /**
   * 料金メニューIDを保有する。
   */
  private String rateMenuId;

  /**
   * 契約容量を保有する。
   */
  private BigDecimal contractCapacity;

  /**
   * 利用年月毎料金計算結果リストを保有する。
   */
  private List<RK_UsePeriodRateMenuInfoBean> UsePeriodRateMenuInfoList;

  /**
   * 料金メニューIDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金メニューIDを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 料金メニューID
   */
  public String getRatemenuid() {
    return rateMenuId;
  }

  /**
   * 料金メニューIDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金メニューIDを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return rateMenuId 料金メニューID
   */
  public void setRatemenuid(String rateMenuId) {
    this.rateMenuId = rateMenuId;

  }

  /**
   * 契約容量のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約容量を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約容量
   */
  public BigDecimal getContractcapacity() {
    return contractCapacity;
  }

  /**
   * 契約容量のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約容量を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return contractCapacity 契約容量
   */
  public void setContractcapacity(BigDecimal contractCapacity) {
    this.contractCapacity = contractCapacity;

  }

  /**
   * 利用年月毎料金計算結果リストのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 利用年月毎料金計算結果リストを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 利用年月毎料金計算結果リスト
   */
  public List<RK_UsePeriodRateMenuInfoBean> getUseperiodratemenuinfolist() {
    return UsePeriodRateMenuInfoList;
  }

  /**
   * 利用年月毎料金計算結果リストのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 利用年月毎料金計算結果リストを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return UsePeriodRateMenuInfoList 利用年月毎料金計算結果リスト
   */
  public void setUseperiodratemenuinfolist(List<RK_UsePeriodRateMenuInfoBean> UsePeriodRateMenuInfoList) {
    this.UsePeriodRateMenuInfoList = UsePeriodRateMenuInfoList;

  }
}
