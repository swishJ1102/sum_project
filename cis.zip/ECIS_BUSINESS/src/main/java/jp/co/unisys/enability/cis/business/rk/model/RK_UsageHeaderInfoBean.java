/*-------------------------------------------------------------------------------
 * All Rights Reserved. Copyright(C) Nihon Unisys, Ltd.
 * vendor : Nihon Unisys, Ltd.
 * create : 2016/04/20
 *-----------------------------------------------------------------------------*/
package jp.co.unisys.enability.cis.business.rk.model;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * 使用量CSV仕訳ビジネスの使用量ヘッダ情報を保持するBeanクラス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_UsageHeaderInfoBean {

  /**
   * 調定年月を保有する。
   */
  private String choteiPeriod;

  /**
   * 検針年月日を保有する。
   */
  private Date fixUsageQuantityMeterReadingDate;

  /**
   * 契約電力を保有する。
   */
  private String contractCapacity;

  /**
   * 力率を保有する。
   */
  private Integer powerFactor;

  /**
   * 使用日数を保有する。
   */
  private Integer useDays;

  /**
   * 使用量を保有する。
   */
  private BigDecimal usageQuantity;

  /**
   * 使用量データ情報リストを保有する。
   */
  private List<RK_UsageDataInfoBean> usageDataInfoList;

  /**
   * 按分フラグを保有する。
   */
  private boolean proportionalDivisionFlag;

  /**
   * 低圧使用量ファイル.調定年月のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 低圧使用量ファイル.調定年月を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 低圧使用量ファイル.調定年月
   */
  public String getChoteiperiod() {
    return choteiPeriod;
  }

  /**
   * 低圧使用量ファイル.調定年月のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 低圧使用量ファイル.調定年月を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return choteiPeriod 低圧使用量ファイル.調定年月
   */
  public void setChoteiperiod(String choteiPeriod) {
    this.choteiPeriod = choteiPeriod;

  }

  /**
   * 低圧使用量ファイル.検針年月日のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 低圧使用量ファイル.検針年月日を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 低圧使用量ファイル.検針年月日
   */
  public Date getFixusagequantitymeterreadingdate() {
    return fixUsageQuantityMeterReadingDate;
  }

  /**
   * 低圧使用量ファイル.検針年月日のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 低圧使用量ファイル.検針年月日を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return fixUsageQuantityMeterReadingDate 低圧使用量ファイル.検針年月日
   */
  public void setFixusagequantitymeterreadingdate(Date fixUsageQuantityMeterReadingDate) {
    this.fixUsageQuantityMeterReadingDate = fixUsageQuantityMeterReadingDate;

  }

  /**
   * 低圧使用量ファイル.契約電力のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 低圧使用量ファイル.契約電力を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 低圧使用量ファイル.契約電力
   */
  public String getContractcapacity() {
    return contractCapacity;
  }

  /**
   * 低圧使用量ファイル.契約電力のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 低圧使用量ファイル.契約電力を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return contractCapacity 低圧使用量ファイル.契約電力
   */
  public void setContractcapacity(String contractCapacity) {
    this.contractCapacity = contractCapacity;

  }

  /**
   * 低圧使用量ファイル.力率のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 低圧使用量ファイル.力率を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 低圧使用量ファイル.力率
   */
  public Integer getPowerfactor() {
    return powerFactor;
  }

  /**
   * 低圧使用量ファイル.力率のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 低圧使用量ファイル.力率を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return powerFactor 低圧使用量ファイル.力率
   */
  public void setPowerfactor(Integer powerFactor) {
    this.powerFactor = powerFactor;

  }

  /**
   * 低圧使用量ファイル.使用日数のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 低圧使用量ファイル.使用日数を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 低圧使用量ファイル.使用日数
   */
  public Integer getUsedays() {
    return useDays;
  }

  /**
   * 低圧使用量ファイル.使用日数のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 低圧使用量ファイル.使用日数を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return useDays 低圧使用量ファイル.使用日数
   */
  public void setUsedays(Integer useDays) {
    this.useDays = useDays;

  }

  /**
   * 低圧使用量ファイル.使用量のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 低圧使用量ファイル.使用量を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 低圧使用量ファイル.使用量
   */
  public BigDecimal getUsagequantity() {
    return usageQuantity;
  }

  /**
   * 低圧使用量ファイル.使用量のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 低圧使用量ファイル.使用量を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return usageQuantity 低圧使用量ファイル.使用量
   */
  public void setUsagequantity(BigDecimal usageQuantity) {
    this.usageQuantity = usageQuantity;

  }

  /**
   * 低圧使用量ファイル.データ部のリストのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 低圧使用量ファイル.データ部のリストを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 低圧使用量ファイル.データ部のリスト
   */
  public List<RK_UsageDataInfoBean> getUsagedatainfolist() {
    return usageDataInfoList;
  }

  /**
   * 低圧使用量ファイル.データ部のリストのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 低圧使用量ファイル.データ部のリストを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return usageDataInfoList 低圧使用量ファイル.データ部のリスト
   */
  public void setUsagedatainfolist(List<RK_UsageDataInfoBean> usageDataInfoList) {
    this.usageDataInfoList = usageDataInfoList;

  }

  /**
   * デフォルト=false 使用量データ情報リスト.使用量リストにnullを含む場合trueのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * デフォルト=false
  使用量データ情報リスト.使用量リストにnullを含む場合trueを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return デフォルト=false 使用量データ情報リスト.使用量リストにnullを含む場合true
   */
  public boolean getProportionaldivisionflag() {
    return proportionalDivisionFlag;
  }

  /**
   * デフォルト=false 使用量データ情報リスト.使用量リストにnullを含む場合trueのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * デフォルト=false
  使用量データ情報リスト.使用量リストにnullを含む場合trueを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return proportionalDivisionFlag デフォルト=false 使用量データ情報リスト.使用量リストにnullを含む場合true
   */
  public void setProportionaldivisionflag(boolean proportionalDivisionFlag) {
    this.proportionalDivisionFlag = proportionalDivisionFlag;

  }
}
