package jp.co.unisys.enability.cis.business.kj;

import jp.co.unisys.enability.cis.business.kj.model.InquiryAgentContractorBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.RegistAgentContractorBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.UpdateAgentContractorBusinessBean;

/**
 * 卸取次店向け契約者情報ビジネスインターフェース。
 *
 * @author "Nihon Unisys, Ltd."
 *
 */
public interface KJ_AgentContractorInformationBusiness {

  /**
   * 契約者情報照会を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * CRMや低圧CISで、【契約者】を特定する場合に、指定された「契約者番号」に紐付く【契約者】の情報を返却する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param inquiryAgentContractorBusinessBean
   *          卸取次店向け契約者情報照会BusinessBean
   * @return 卸取次店向け契約者情報照会BusinessBean
   */
  public InquiryAgentContractorBusinessBean inquiry(
      InquiryAgentContractorBusinessBean inquiryContractorBusinessBean);

  /**
   * 契約者情報登録を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * CRMまたは、低圧CISにて契約者の更新時に利用される。指定された「契約者番号」に該当する【契約者】を登録する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param registAgentContractorBusinessBean
   *          卸取次店向け契約者情報登録BusinessBean
   * @return 卸取次店向け契約者情報登録BusinessBean
   */
  public RegistAgentContractorBusinessBean regist(
      RegistAgentContractorBusinessBean registContractorBusinessBean);

  /**
   * 契約者情報更新を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * CRMまたは、低圧CISにて契約者の更新時に利用される。指定された「契約者番号」に該当する【契約者】を更新する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param updateAgentContractorBusinessBean
   *          卸取次店向け契約者情報更新BusinessBean
   * @return 卸取次店向け契約者情報更新BusinessBean
   */
  public UpdateAgentContractorBusinessBean update(
      UpdateAgentContractorBusinessBean updateContractorBusinessBean);
}