package jp.co.unisys.enability.cis.business.rk;

import java.math.BigDecimal;
import java.util.Locale;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.config.PropertiesFactoryBean;
import org.springframework.context.MessageSource;

import jp.co.unisys.enability.cis.business.rk.model.RK_ConsumptionTaxEquivalentCalcBusinessBean;
import jp.co.unisys.enability.cis.business.rk.model.RK_SaleProceedsRelationItemCalcBusinessBean;
import jp.co.unisys.enability.cis.common.Exception.SystemException;
import jp.co.unisys.enability.cis.common.util.RK_PropertyUtil;
import jp.co.unisys.enability.cis.common.util.constants.ECISCodeConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;
import jp.co.unisys.enability.cis.entity.common.CclM;
import jp.co.unisys.enability.cis.entity.common.DealClassM;
import jp.co.unisys.enability.cis.entity.common.Fcr;
import jp.co.unisys.enability.cis.entity.common.FcrBreakdown;
import jp.co.unisys.enability.cis.entity.common.Rm;
import jp.co.unisys.enability.cis.mapper.common.CclMMapper;
import jp.co.unisys.enability.cis.mapper.common.DealClassMMapper;
import jp.co.unisys.enability.cis.mapper.common.RmMapper;

/**
 * 売上関連項目計算ビジネス
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_SaleProceedsRelationItemCalcBusinessImpl implements
    RK_SaleProceedsRelationItemCalcBusiness {

  /**
   * 消費税等相当額計算ビジネス(DI)
   */
  private RK_ConsumptionTaxEquivalentCalcBusiness consumptionTaxEquivalentCalcBusiness;

  /**
   * 料金メニューMapper(DI)
   */
  private RmMapper rmMapper;

  /**
   * 契約種別マスタMapper(DI)
   */
  private CclMMapper cclMMapper;

  /**
   * 取引種別マスタMapper(DI)
   */
  private DealClassMMapper dealClassMMapper;

  /**
   * メッセージソース(DI)
   */
  private MessageSource messageSource;

  /**
   * プロパティ(DI)
   */
  private PropertiesFactoryBean applicationProperties;

  /*
   * (非 Javadoc)
   * @see jp.co.unisys.enability.cis.business.rk.RK_SaleProceedsRelationItemCalcBusiness#calculate(jp.co.unisys.enability.cis.business.rk.model.RK_SaleProceedsRelationItemCalcBusinessBean)
   */
  public void calculate(RK_SaleProceedsRelationItemCalcBusinessBean saleProceedsRelationItemCalcBusinessBean) {
    // 引数チェック
    this.validateArgs(saleProceedsRelationItemCalcBusinessBean);

    // 料金メニュー取得
    Rm rateMenu = rmMapper.selectByPrimaryKey(saleProceedsRelationItemCalcBusinessBean.getFixChargeResult()
        .getRmId());
    // 取得出来なかった場合、システムエラー
    if (rateMenu == null) {
      throw new SystemException(messageSource.getMessage("error.E0006",
          new String[] {RK_PropertyUtil.getProperty(applicationProperties,
              "business.rk.system.error.get.master.rate.menu") },
          Locale.getDefault()));
    }

    // 契約種別マスタ取得
    CclM cotractClassMaster = cclMMapper.selectByPrimaryKey(rateMenu.getCclCode());
    // 取得出来なかった場合、システムエラー
    if (cotractClassMaster == null) {
      throw new SystemException(messageSource.getMessage("error.E0006",
          new String[] {RK_PropertyUtil.getProperty(applicationProperties,
              "business.rk.system.error.get.master.contract.class") },
          Locale.getDefault()));
    }
    // 最低月額料金フラグ設定
    boolean minimumMonthlyChargeFlag = ECISConstants.FLG_ON.equals(rateMenu.getMmcFlag());

    // 取引種別マスタ取得
    DealClassM dealClassMaster = dealClassMMapper.selectByPrimaryKey(cotractClassMaster.getDealClassCode());
    // 取得出来なかった場合、システムエラー
    if (dealClassMaster == null) {
      throw new SystemException(messageSource.getMessage("error.E0006",
          new String[] {RK_PropertyUtil.getProperty(applicationProperties,
              "business.rk.system.error.get.master.deal.class") },
          Locale.getDefault()));
    }

    // 売上関連項目計算処理実行
    this.rateItemsCalculate(saleProceedsRelationItemCalcBusinessBean,
        minimumMonthlyChargeFlag, dealClassMaster, rateMenu.getSaleCatCode());
  }

  /**
   * 引数チェックを行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 指定された引数に必要な情報が設定されているかをチェックする。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param inputBusinessBean
   *          売上関連項目計算ビジネスBean
   */
  private void validateArgs(RK_SaleProceedsRelationItemCalcBusinessBean inputBusinessBean) {
    // 引数チェック
    // エンティティ取得
    Fcr fcr = inputBusinessBean.getFixChargeResult();
    // 引数が設定されていない場合、システムエラー
    // 確定料金実績ビジネスBean
    if (fcr == null) {
      throw new SystemException(messageSource.getMessage("validation.argumentrequired",
          new String[] {RK_PropertyUtil.getProperty(applicationProperties,
              "validation.error.argumentrequired.charge.result.business.bean") },
          Locale.getDefault()));
    }
    // 確定料金実績内訳ビジネスBeanリスト
    if (CollectionUtils.isEmpty(inputBusinessBean.getFixChargeResultBreakdownList())) {
      throw new SystemException(messageSource.getMessage("validation.argumentrequired",
          new String[] {RK_PropertyUtil.getProperty(applicationProperties,
              "validation.error.argumentrequired.fix.charge.result.breakdown.business.bean.list") },
          Locale.getDefault()));
    }
    // 確定料金実績ビジネスBean.料金メニューID
    if (StringUtils.isEmpty(fcr.getRmId())) {
      throw new SystemException(messageSource.getMessage("validation.argumentrequired",
          new String[] {RK_PropertyUtil.getProperty(applicationProperties,
              "validation.error.argumentrequired.rate.menu.id") },
          Locale.getDefault()));
    }
    // 確定料金実績ビジネスBean.料金算定開始日
    if (fcr.getCcSd() == null) {
      throw new SystemException(messageSource.getMessage("validation.argumentrequired",
          new String[] {RK_PropertyUtil.getProperty(applicationProperties,
              "validation.error.argumentrequired.charge.calculation.start.date") },
          Locale.getDefault()));
    }
    // 確定料金実績ビジネスBean.料金算定終了日
    if (fcr.getCcEd() == null) {
      throw new SystemException(messageSource.getMessage("validation.argumentrequired",
          new String[] {RK_PropertyUtil.getProperty(applicationProperties,
              "validation.error.argumentrequired.charge.calculation.end.date") },
          Locale.getDefault()));
    }
  }

  /**
   * 売上関連項目の計算を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数の情報をもとに、基本料金・従量料金等の売上関連項目の計算処理を行う。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param inputBusinessBean
   *          売上関連項目計算ビジネスBean
   * @param minimumMonthlyChargeFlag
   *          最低月額料金フラグ
   * @param dealClassMaster
   *          取引種別マスタ
   * @param saleCatCode
   *          売買区分コード
   */
  private void rateItemsCalculate(RK_SaleProceedsRelationItemCalcBusinessBean inputBusinessBean,
      boolean minimumMonthlyChargeFlag, DealClassM dealClassMaster, String saleCatCode) {
    /**
     * 変数宣言
     */
    // 基本料金
    BigDecimal basicCharge = ECISRKConstants.BIG_DECIMAL_ZERO_SCALE2;
    // 従量料金
    BigDecimal usageCharge = ECISRKConstants.BIG_DECIMAL_ZERO_SCALE2;
    // 燃料費調整額
    BigDecimal fuelCostAdjustment = ECISRKConstants.BIG_DECIMAL_ZERO_SCALE2;
    // 再エネ賦課金
    BigDecimal renewableEnergyCharge = ECISRKConstants.BIG_DECIMAL_ZERO_SCALE2;
    // 売上1補正金額
    BigDecimal saleProceeds1Correction = ECISRKConstants.BIG_DECIMAL_ZERO_SCALE2;
    // 売上2補正金額
    BigDecimal saleProceeds2Correction = ECISRKConstants.BIG_DECIMAL_ZERO_SCALE2;
    // 売上3補正金額
    BigDecimal saleProceeds3Correction = ECISRKConstants.BIG_DECIMAL_ZERO_SCALE2;
    // 契約超過金
    BigDecimal contractExcessCharge = ECISRKConstants.BIG_DECIMAL_ZERO_SCALE2;

    /**
     * 計算用一時変数宣言
     */
    // 最低料金適用前付帯額
    BigDecimal minAmountAppBeforeSplCharge = ECISRKConstants.BIG_DECIMAL_ZERO_SCALE2;
    // 最低料金適用後付帯額
    BigDecimal minAmountAppAfterSplCharge = ECISRKConstants.BIG_DECIMAL_ZERO_SCALE2;
    // 最低月額料金
    BigDecimal minimumMonthlyCharge = ECISRKConstants.BIG_DECIMAL_ZERO_SCALE2;
    // 最低月額料金設定フラグ
    boolean minimumMonthlyChargeConfigFlg = false;
    // 最低料金
    BigDecimal minimumCharge = ECISRKConstants.BIG_DECIMAL_ZERO_SCALE2;
    // 最低料金設定フラグ
    boolean minimumChargeConfigFlg = false;

    // 確定料金実績内訳の件数分、処理を行う
    for (FcrBreakdown fcrBreakdown : inputBusinessBean.getFixChargeResultBreakdownList()) {
      // 確定料金実績内訳コードにより、処理を分岐する
      switch (fcrBreakdown.getFcrBreakdownCatCode()) {
        // 基本料金
        case ECISCodeConstants.FCR_BREAKDOWN_CATEGORY_CODE_BASIC_CHARGE:
        case ECISCodeConstants.FCR_BREAKDOWN_CATEGORY_CODE_BASIC_CHARGE_RESERVE_LINE:
        case ECISCodeConstants.FCR_BREAKDOWN_CATEGORY_CODE_BASIC_CHARGE_RESERVE_POWER_SUPPLY:
          basicCharge = basicCharge.add(fcrBreakdown.getAmount());
          break;
        // 従量料金
        case ECISCodeConstants.FCR_BREAKDOWN_CATEGORY_CODE_USAGE_CHARGE:
          usageCharge = usageCharge.add(fcrBreakdown.getAmount());
          break;
        // 燃料費調整額の場合、従量料金と燃料費調整額に計上する
        case ECISCodeConstants.FCR_BREAKDOWN_CATEGORY_CODE_FUEL_COST_ADJUSTMENT:
          // 従量料金
          usageCharge = usageCharge.add(fcrBreakdown.getAmount());
          // 燃料費調整額
          fuelCostAdjustment = fuelCostAdjustment.add(fcrBreakdown.getAmount());
          break;
        // 再エネ賦課金
        case ECISCodeConstants.FCR_BREAKDOWN_CATEGORY_CODE_RENEWABLE_ENERGY_CHARGE:
          renewableEnergyCharge = renewableEnergyCharge.add(fcrBreakdown.getAmount());
          break;
        // 最低金額適用前付帯金額
        case ECISCodeConstants.FCR_BREAKDOWN_CATEGORY_CODE_MINIMUM_AMOUNT_APPLICATION_BEFORE_SPL_CHARGE:
          minAmountAppBeforeSplCharge = minAmountAppBeforeSplCharge.add(fcrBreakdown.getAmount());
          break;
        // 最低金額適用後付帯金額
        case ECISCodeConstants.FCR_BREAKDOWN_CATEGORY_CODE_MINIMUM_AMOUNT_APPLICATION_AFTER_SPL_CHARGE:
          minAmountAppAfterSplCharge = minAmountAppAfterSplCharge.add(fcrBreakdown.getAmount());
          break;
        // 最低月額料金の場合、最低月額料金フラグがオンの場合のみ、計上する
        case ECISCodeConstants.FCR_BREAKDOWN_CATEGORY_CODE_MINIMUM_MONTHLY_CHARGE:
          if (minimumMonthlyChargeFlag) {
            minimumMonthlyCharge = minimumMonthlyCharge.add(fcrBreakdown.getAmount());
            // 設定済フラグを立てる
            minimumMonthlyChargeConfigFlg = true;
          }
          break;
        // 最低料金
        case ECISCodeConstants.FCR_BREAKDOWN_CATEGORY_CODE_MINIMUM_CHARGE:
          // 最低料金
          minimumCharge = minimumCharge.add(fcrBreakdown.getAmount());
          // 設定済フラグを立てる
          minimumChargeConfigFlg = true;
          break;
        // 電気料金補正額または制限中止割引額の場合、売上1補正金額に計上する
        case ECISCodeConstants.FCR_BREAKDOWN_CATEGORY_CODE_POWER_RATE_CORRECT_CHARGE:
        case ECISCodeConstants.FCR_BREAKDOWN_CATEGORY_CODE_LIMIT_DISCONTINUED_DISCOUNT:
          saleProceeds1Correction = saleProceeds1Correction.add(fcrBreakdown.getAmount());
          break;
        // 再エネ賦課金補正額の場合、売上2補正金額に計上する
        case ECISCodeConstants.FCR_BREAKDOWN_CATEGORY_CODE_RENEWABLE_ENERGY_CORRECT_CHARGE:
          saleProceeds2Correction = saleProceeds2Correction.add(fcrBreakdown.getAmount());
          break;
        // 契約超過金補正額の場合、売上3補正金額に計上する
        case ECISCodeConstants.FCR_BREAKDOWN_CATEGORY_CODE_CONTRACT_EXCESS_CHARGE:
          saleProceeds3Correction = saleProceeds3Correction.add(fcrBreakdown.getAmount());
          break;
        // 契約超過金の場合、契約超過金に計上する
        case ECISCodeConstants.FCR_BREAKDOWN_CATEGORY_CODE_CONTRACT_EXCEEDED_CHARGE:
          contractExcessCharge = contractExcessCharge.add(fcrBreakdown.getAmount());
          break;
        // 想定外のコード値の場合
        default:
          // マスタコード値のため到達しないはず
          // システムエラーとしておく
          throw new SystemException(null);
      }
    }

    if (CollectionUtils.isNotEmpty(inputBusinessBean.getFixChargeResultBreakdownForCorrectList())) {
      // 確定料金実績内訳（補正用）の件数分、処理を行う
      for (FcrBreakdown fcrBreakdown : inputBusinessBean.getFixChargeResultBreakdownForCorrectList()) {
        // 確定料金実績内訳コードにより、処理を分岐する
        switch (fcrBreakdown.getFcrBreakdownCatCode()) {
          // 電気料金補正額または制限中止割引額の場合、売上1補正金額に計上する
          case ECISCodeConstants.FCR_BREAKDOWN_CATEGORY_CODE_POWER_RATE_CORRECT_CHARGE:
          case ECISCodeConstants.FCR_BREAKDOWN_CATEGORY_CODE_LIMIT_DISCONTINUED_DISCOUNT:
            saleProceeds1Correction = saleProceeds1Correction.add(fcrBreakdown.getAmount());
            break;
          // 再エネ賦課金補正額の場合、売上2補正金額に計上する
          case ECISCodeConstants.FCR_BREAKDOWN_CATEGORY_CODE_RENEWABLE_ENERGY_CORRECT_CHARGE:
            saleProceeds2Correction = saleProceeds2Correction.add(fcrBreakdown.getAmount());
            break;
          // 契約超過金補正額の場合、売上3補正金額に計上する
          case ECISCodeConstants.FCR_BREAKDOWN_CATEGORY_CODE_CONTRACT_EXCESS_CHARGE:
            saleProceeds3Correction = saleProceeds3Correction.add(fcrBreakdown.getAmount());
            break;
          // 想定外のコード値の場合
          default:
            // マスタコード値のため到達しないはず
            // システムエラーとしておく
            throw new SystemException(null);
        }
      }
    }

    /**
     * 最低料金、付帯金額設定処理
     */
    // 基本料金再設定
    // 最低料金が設定されている場合、最低料金を基本料金に設定する
    if (minimumChargeConfigFlg) {
      basicCharge = minimumCharge;
    }

    // 付帯金額
    BigDecimal supplementaryAmount;

    // 最低月額料金処理
    // 最低月額料金が設定されている場合
    if (minimumMonthlyChargeConfigFlg) {
      // 基本料金 + 従量料金 + 最低金額適用前付帯金額を取得する
      BigDecimal checkBaseCharge = basicCharge.add(usageCharge)
          .add(minAmountAppBeforeSplCharge);
      // 上記の計算結果が最低月額料金に満たない場合
      if (checkBaseCharge.compareTo(minimumMonthlyCharge) < 0) {
        // 付帯金額に、最低金額適用後付帯金額のみ設定する
        supplementaryAmount = minAmountAppAfterSplCharge;

        // 料金再設定
        // 最低月額料金 - 従量料金を取得する
        BigDecimal diffMonthlyUsage = minimumMonthlyCharge.subtract(usageCharge);
        // 最低月額料金 - 従量料金がマイナスの場合
        if (diffMonthlyUsage.compareTo(BigDecimal.ZERO) < 0) {
          // 基本料金に0.00を設定する
          basicCharge = ECISRKConstants.BIG_DECIMAL_ZERO_SCALE2;
          // 従量料金に最低月額料金を設定する
          usageCharge = minimumMonthlyCharge;

          // 最低月額料金 - 従量料金が0以上の場合
        } else {
          // 従量料金はそのままで、差値を基本料金に設定する
          basicCharge = diffMonthlyUsage;
        }

        // 最低月額料金以上の場合
      } else {
        // 付帯金額に、最低金額適用前付帯金額 + 最低金額適用後付帯金額を設定する
        supplementaryAmount = minAmountAppBeforeSplCharge.add(minAmountAppAfterSplCharge);
      }

      // 最低月額料金が設定されていない場合
    } else {
      // 付帯金額に、最低金額適用前付帯金額 + 最低金額適用後付帯金額を設定する
      supplementaryAmount = minAmountAppBeforeSplCharge.add(minAmountAppAfterSplCharge);
    }

    /**
     * 月額料金計算
     */
    // 各料金を合算し、月額料金を算出する
    // 基本料金 + 従量料金 + 付帯金額 + 再エネ賦課金 + 売上1補正金額 + 売上2補正金額 + 売上3補正金額 + 契約超過金
    BigDecimal monthlyChargeDecimal = basicCharge
        .add(usageCharge)
        .add(supplementaryAmount)
        .add(renewableEnergyCharge)
        .add(saleProceeds1Correction)
        .add(saleProceeds2Correction)
        .add(saleProceeds3Correction)
        .add(contractExcessCharge);
    // Long値を取得する(小数点以下切捨て)
    long monthlyCharge = monthlyChargeDecimal.longValue();

    // 引数.確定料金実績取得
    Fcr fcr = inputBusinessBean.getFixChargeResult();

    // ここまでで計算した値を確定料金実績に設定する
    // 基本料金
    fcr.setBasicCharge(basicCharge);
    // 従量料金
    fcr.setUsageCharge(usageCharge);
    // 燃料費調整額
    fcr.setFca(fuelCostAdjustment);
    // 再エネ賦課金
    fcr.setRec(renewableEnergyCharge);
    // 付帯金額
    fcr.setSplAmount(supplementaryAmount);
    // 契約超過金
    fcr.setCec(contractExcessCharge);
    // 売上1補正金額
    fcr.setSp1Correction(saleProceeds1Correction);
    // 売上2補正金額
    fcr.setSp2Correction(saleProceeds2Correction);
    // 売上3補正金額
    fcr.setSp3Correction(saleProceeds3Correction);
    // 月額料金
    fcr.setMonthlyCharge(monthlyCharge);

    /**
     * 消費税等相当額計算
     */
    // パラメータ設定
    RK_ConsumptionTaxEquivalentCalcBusinessBean monthlyChargeTaxCalcBusinessInputBean = new RK_ConsumptionTaxEquivalentCalcBusinessBean();
    // 月額料金
    monthlyChargeTaxCalcBusinessInputBean.setAmount(BigDecimal.valueOf(monthlyCharge));
    // 基準日1：料金算定開始日
    monthlyChargeTaxCalcBusinessInputBean.setBaseDate1(fcr.getCcSd());
    // 基準日2：料金算定終了日
    monthlyChargeTaxCalcBusinessInputBean.setBaseDate2(fcr.getCcEd());

    // 消費税相当額等計算実行
    RK_ConsumptionTaxEquivalentCalcBusinessBean monthlyChargeTaxCalcBusinessResultBean = consumptionTaxEquivalentCalcBusiness
        .calculate(monthlyChargeTaxCalcBusinessInputBean);

    // 消費税相当額を設定する
    // 買電の場合、0を設定
    // 売電の場合、消費税相当額等計算の結果を設定
    Integer consumptionTaxEquivalent = 0;
    if (ECISCodeConstants.SALE_CATEGORY_SELLING.equals(saleCatCode)) {
      consumptionTaxEquivalent = monthlyChargeTaxCalcBusinessResultBean.getConsumptionTaxEquivalent();
    }
    // 消費税等相当額を確定料金実績に設定
    fcr.setCtEquivalent(consumptionTaxEquivalent);
    // 消費税率
    fcr.setCtRate(monthlyChargeTaxCalcBusinessResultBean.getConsumptionTaxRate());
    // 消費税科目コード
    fcr.setCtIc(monthlyChargeTaxCalcBusinessResultBean.getConsumptionTaxItemCode());

    /**
     * 売上2金額計算
     */
    // 売上2金額計算
    // 再エネ賦課金 + 売上2補正金額を算出
    BigDecimal totalSaleProceeds2 = renewableEnergyCharge.add(saleProceeds2Correction);

    // 売上2消費税額算出
    // パラメータ設定
    RK_ConsumptionTaxEquivalentCalcBusinessBean sale2TaxCalcBusinessInputBean = new RK_ConsumptionTaxEquivalentCalcBusinessBean();
    // 金額：売上2金額合計
    sale2TaxCalcBusinessInputBean.setAmount(totalSaleProceeds2);
    // 基準日1：料金算定開始日
    sale2TaxCalcBusinessInputBean.setBaseDate1(fcr.getCcSd());
    // 基準日2：料金算定終了日
    sale2TaxCalcBusinessInputBean.setBaseDate2(fcr.getCcEd());

    // 消費税額計算
    RK_ConsumptionTaxEquivalentCalcBusinessBean sale2ChargeTaxCalcBusinessResultBean = consumptionTaxEquivalentCalcBusiness
        .calculate(sale2TaxCalcBusinessInputBean);

    // 売上2金額設定
    BigDecimal saleProceeds2Tax = BigDecimal.valueOf(sale2ChargeTaxCalcBusinessResultBean
        .getConsumptionTaxEquivalent());
    long saleProceeds2 = totalSaleProceeds2.subtract(saleProceeds2Tax).longValue();
    fcr.setSp2(saleProceeds2);

    // 売上2科目コード設定
    fcr.setSpIc2(dealClassMaster.getSpIc2());

    /**
     * 売上3金額計算
     */
    // 売上3金額計算
    // 売上3補正金額 + 契約超過金を算出
    BigDecimal totalSaleProceeds3 = saleProceeds3Correction.add(contractExcessCharge);

    // 売上3消費税額算出
    // パラメータ設定
    RK_ConsumptionTaxEquivalentCalcBusinessBean sale3TaxCalcBusinessInputBean = new RK_ConsumptionTaxEquivalentCalcBusinessBean();
    // 金額：売上3金額合計
    sale3TaxCalcBusinessInputBean.setAmount(totalSaleProceeds3);
    // 基準日1：料金算定開始日
    sale3TaxCalcBusinessInputBean.setBaseDate1(fcr.getCcSd());
    // 基準日2：料金算定終了日
    sale3TaxCalcBusinessInputBean.setBaseDate2(fcr.getCcEd());

    // 消費税額計算
    RK_ConsumptionTaxEquivalentCalcBusinessBean sale3ChargeTaxCalcBusinessResultBean = consumptionTaxEquivalentCalcBusiness
        .calculate(sale3TaxCalcBusinessInputBean);

    // 売上3金額設定
    BigDecimal saleProceeds3Tax = BigDecimal
        .valueOf(sale3ChargeTaxCalcBusinessResultBean
            .getConsumptionTaxEquivalent());
    long saleProceeds3 = totalSaleProceeds3.subtract(saleProceeds3Tax)
        .longValue();
    fcr.setSp3(saleProceeds3);

    // 売上3科目コード設定
    fcr.setSpIc3(dealClassMaster.getSpIc3());

    /**
     * 売上1金額計算
     */
    // 月額料金(税込) - 消費税等相当額 - 売上金額2(税抜) - 売上金額3(税抜)を算出する
    long saleProceeds1 = fcr.getMonthlyCharge().longValue()
        - fcr.getCtEquivalent().longValue()
        - fcr.getSp2().longValue()
        - fcr.getSp3().longValue();
    // 売上1金額設定
    fcr.setSp1(Long.valueOf(saleProceeds1));

    // 売上1科目コード1設定
    fcr.setSpIc1(dealClassMaster.getSpIc1());

    /**
     * 売掛金額計算
     */
    // 売上1金額 + 売上2金額 + 売上3金額 + 消費税等相当額を算出する
    long accountsReceivableAmount = saleProceeds1 + saleProceeds2
        + saleProceeds3 + consumptionTaxEquivalent.intValue();
    // 売掛金額設定
    fcr.setArAmount(Long.valueOf(accountsReceivableAmount));

    // 売掛科目コード設定
    fcr.setArIc(dealClassMaster.getArIc());

    // 計算した確定料金実績エンティティを
    // 引数.売上関連項目計算ビジネスBean.確定料金実績に再設定する
    inputBusinessBean.setFixChargeResult(fcr);
  }

  /**
   * 料金メニューMapper（DI）
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金メニューMapperを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param rmMapper
   *          料金メニューMapper
   */
  public void setRmMapper(RmMapper rmMapper) {
    this.rmMapper = rmMapper;
  }

  /**
   * 消費税等相当額計算ビジネス（DI）
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 消費税等相当額計算ビジネスを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param consumptionTaxEquivalentCalcBusiness
   *          消費税等相当額計算ビジネス
   */
  public void setConsumptionTaxEquivalentCalcBusiness(
      RK_ConsumptionTaxEquivalentCalcBusiness consumptionTaxEquivalentCalcBusiness) {
    this.consumptionTaxEquivalentCalcBusiness = consumptionTaxEquivalentCalcBusiness;
  }

  /**
   * 契約種別マスタMapper（DI）
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約種別マスタMapperを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param cclMMapper
   *          契約種別マスタMapper
   */
  public void setCclMMapper(CclMMapper cclMMapper) {
    this.cclMMapper = cclMMapper;
  }

  /**
   * 取引種別マスタMapper（DI）
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 取引種別マスタMapperを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param dealClassMMapper
   *          取引種別マスタMapper
   */
  public void setDealClassMMapper(DealClassMMapper dealClassMMapper) {
    this.dealClassMMapper = dealClassMMapper;
  }

  /**
   * メッセージソースのsetter（DI）
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージソースを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param messageSource
   *          メッセージソース
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }

  /**
   * プロパティのsetter（DI）
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * プロパティを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param applicationProperties
   *          プロパティ
   */
  public void setApplicationProperties(PropertiesFactoryBean applicationProperties) {
    this.applicationProperties = applicationProperties;
  }

}
