package jp.co.unisys.enability.cis.business.rk.model;

import java.math.BigDecimal;
import java.util.Date;

/**
 * 契約期間等の相関チェックを行うための情報を保持するビジネスBean。
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * 使用量連携チェックビジネス。
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_UsageLinkageCheckInvalidPowerConsumptionBusinessBean {

  /**
   * 確定使用量対象日を保有する。
   */
  private Date fixUsageCoveredDate;

  /**
   * 確定電力量を保有する。
   */
  private BigDecimal fixPowerConsumptionList;

  /**
   * 確定使用量対象日のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 確定使用量対象日を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 確定使用量対象日
   */
  public Date getFixUsageCoveredDate() {
    return this.fixUsageCoveredDate;
  }

  /**
   * 確定使用量対象日のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 確定使用量対象日を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param fixUsageCoveredDate
   *          確定使用量対象日
   */
  public void setFixUsageCoveredDate(Date fixUsageCoveredDate) {
    this.fixUsageCoveredDate = fixUsageCoveredDate;
  }

  /**
   * 確定電力量のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 確定電力量を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 確定電力量
   */
  public BigDecimal getFixPowerConsumptionList() {
    return this.fixPowerConsumptionList;
  }

  /**
   * 確定電力量のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 確定電力量を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param fixPowerConsumptionList
   *          確定電力量
   */
  public void setFixPowerConsumptionList(BigDecimal fixPowerConsumptionList) {
    this.fixPowerConsumptionList = fixPowerConsumptionList;
  }

}
