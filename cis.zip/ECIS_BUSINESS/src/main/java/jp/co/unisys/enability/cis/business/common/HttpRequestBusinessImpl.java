package jp.co.unisys.enability.cis.business.common;

import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.Proxy.Type;
import java.util.Base64;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

import org.apache.commons.lang3.StringUtils;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.http.MediaType;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

public class HttpRequestBusinessImpl implements HttpRequestBusiness {

    private enum Method {
        GET,
        POST
    }

    /** メディアタイプ */
    private MediaType mediaType = null;

    /**  接続タイムアウト値（ミリ秒） */
    private Integer connectTimeout = null;

    /** RestTemplate */
    private RestTemplate restTemplate = null;

    /**  SimpleClientHttpRequestFactory */
    private SimpleClientHttpRequestFactory simpleClientHttpRequestFactory = null;

    /** HttpHeaders */
    private HttpHeaders httpHeaders = null;

    /** ResponseEntity */
    private ResponseEntity<String> responseEntity = null;

    /** Proxy使用有無 */
    private Boolean useProxy = false;
    /** Proxyホスト */
    private String proxyHost = "";
    /** Proxyポート番号 */
    private String proxyPort = "";

    /** Basic認証使用有無 */
    private Boolean useBasicAuthentication = false;
    /** Basic認証ユーザ名 */
    private String basicAuthenticationUserName = "";
    /** Basic認証パスワード */
    private String basicAuthenticationPassword = "";

    /** 送信文字コード */
    private String charset = "";

    /**
     * Proxy設定処理
     * @param host ホスト
     * @param port ポート番号
     */
    public void setProxy(String host, String port) {

        this.proxyHost = host;
        this.proxyPort = port;

        this.useProxy = true;

    }

    /**
     * Proxy設定解除処理
     */
    public void unsetProxy() {

        this.proxyHost = "";
        this.proxyPort = "";

        this.useProxy = false;

    }

    /**
     * Basic認証設定処理
     * @param userName ユーザ名
     * @param password パスワード
     */
    public void setBasicAuthentication(
            String userName,
            String password) {

        this.basicAuthenticationUserName = userName;
        this.basicAuthenticationPassword = password;

        this.useBasicAuthentication = true;

    }

    /**
     * Basic認証設定解除処理
     */
    public void unsetBasicAuthentication() {

        this.basicAuthenticationUserName = "";
        this.basicAuthenticationPassword = "";

        this.useBasicAuthentication = false;

    }

    /**
     * タイムアウト設定処理
     * @param timeout 接続タイムアウト値（ミリ秒）
     */
    public void setConnectTimeout(Integer timeout) {

        this.connectTimeout = timeout;

    }

    /** 文字コード設定処理
     * @param charset 文字コード
     */
    public void setCharset(String charset) {

        this.charset = charset;

    }

    /**
     * POST通信処理
     * @param url 接続先URL
     * @param data 送信データ
     * @return レスポンスボディ
     * @throws Exception
     */
    public String doPost(String url, MultiValueMap<String, Object> data) throws Exception {

        this.mediaType = MediaType.APPLICATION_FORM_URLENCODED;

        return this.send(url, Method.POST, data);

    }

    /**
     * POST通信処理（JSON）
     * @param url 接続先URL
     * @param data 送信データ
     * @return レスポンスボディ
     * @throws Exception
     */
    public String doPostAsJson(String url, MultiValueMap<String, Object> data) throws Exception {

        this.mediaType = MediaType.APPLICATION_JSON;

        return this.send(url, Method.POST, data);

    }

    /**
     * GET通信処理
     * @param url 接続先URL
     * @param data 送信データ
     * @return レスポンスボディ
     * @throws Exception
     */
    public String doGet(String url, MultiValueMap<String, Object> data) throws Exception {

        this.mediaType = null;

        return this.send(url, Method.GET, data);

    }

    /**
     * REST通信処理
     * @param url 接続先URL
     * @param method 通信方式
     * @param data 送信データ
     * @return レスポンスボディ
     * @throws Exception
     */
    private String send(
            String url,
            Method method,
            MultiValueMap<String, Object> data) throws Exception {

        this.simpleClientHttpRequestFactory = new SimpleClientHttpRequestFactory();
        this.httpHeaders = new HttpHeaders();

        // 接続タイムアウト値設定
        this.simpleClientHttpRequestFactory.setConnectTimeout(this.connectTimeout);

        // Proxy使用有無判定
        if (this.useProxy == true) {

            this.simpleClientHttpRequestFactory.setProxy(
                    new Proxy(
                            Type.HTTP,
                            new InetSocketAddress(
                                    this.proxyHost,
                                    Integer.parseInt(this.proxyPort))));

        }

        // Basic認証使用有無判定
        if (this.useBasicAuthentication == true) {

            String auth
            = new String(
                      Base64.getEncoder().encode(
                        (this.basicAuthenticationUserName
                                + ":"
                                + this.basicAuthenticationPassword).getBytes(StandardCharsets.UTF_8)));

            this.httpHeaders.add("Authorization", "Basic " +  auth);

        }

        // 文字コード設定
        if (!StringUtils.isEmpty(this.charset)) {

            this.mediaType = new MediaType(this.mediaType.getType(), this.mediaType.getSubtype(),
                    Charset.forName(this.charset));

        }

        this.restTemplate = new RestTemplate(this.simpleClientHttpRequestFactory);

        String responseBody = null;

        if (Method.POST == method) {

            this.httpHeaders.setContentType(this.mediaType);

            HttpEntity<MultiValueMap<String, Object>> request
            = new HttpEntity<MultiValueMap<String, Object>>(data, this.httpHeaders);

            responseEntity = this.restTemplate.exchange(url, HttpMethod.POST, request, String.class);

        } else {

            responseEntity = this.restTemplate.getForEntity(url, String.class, data);

        }

        responseBody = responseEntity.getBody();

        return responseBody;

    }

}
