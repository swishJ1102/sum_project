package jp.co.unisys.enability.cis.business.gk;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.dao.DataAccessException;

import jp.co.unisys.enability.cis.business.gk.model.Custom_InquiryFuelCostAdjustUnitPriceBusinessBean;
import jp.co.unisys.enability.cis.common.util.KJ_CommonUtil;
import jp.co.unisys.enability.cis.common.util.constants.ECISKJConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISReturnCodeConstants;
import jp.co.unisys.enability.cis.entity.common.ContractHist;
import jp.co.unisys.enability.cis.entity.common.ContractHistExample;
import jp.co.unisys.enability.cis.entity.common.FcaUpM;
import jp.co.unisys.enability.cis.entity.common.FcaUpMExample;
import jp.co.unisys.enability.cis.mapper.common.ContractHistMapper;
import jp.co.unisys.enability.cis.mapper.common.FcaUpMMapper;

/**
 * 燃調単価情報ビジネス_カスタム
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.gk.Custom_FuelCostAdjustUnitPriceInformationBusiness
 *
 *      変更履歴(kg-epj) 2016.02.04 ko 新規作成
 */
public class Custom_FuelCostAdjustUnitPriceInformationBusinessImpl
    implements Custom_FuelCostAdjustUnitPriceInformationBusiness {

  /**
   * 燃調単価マッパー(DI)
   */
  private FcaUpMMapper fcaUpMMapper;

  /**
   * 契約履歴マッパー(DI)
   */
  private ContractHistMapper contractHistMapper;

  /**
   * メッセージプロパティ(DI)
   */
  private MessageSource messageSource;

  /**
   * ログマネジャー
   */
  private static Logger logger = LogManager.getLogger();

  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.business.gk.Custom_FuelCostAdjustUnitPriceInformationBusiness#inquiryFuelCostAdjustUnitPrice(jp.co.unisys.enability.cis.business.gk.model.Custom_InquiryFuelCostAdjustUnitPriceBusinessBean)
   */
  @Override
  public Custom_InquiryFuelCostAdjustUnitPriceBusinessBean inquiryFuelCostAdjustUnitPrice(
      Custom_InquiryFuelCostAdjustUnitPriceBusinessBean businessBean) {

    // エラーメッセージを定義する。
    String errorMessage = null;
    // 返却用ビジネスBeanを生成する。
    Custom_InquiryFuelCostAdjustUnitPriceBusinessBean returnBusinessBean = new Custom_InquiryFuelCostAdjustUnitPriceBusinessBean();

    try {
      // 引数取得
      // エリアコードを取得する
      String areaCode = businessBean.getAreaCode();
      // 取得対象日リストを取得する
      List<Date> targetDateList = businessBean.getTargetDateList();

      // リターンコード(G017)に対応するメッセージを取得する。
      errorMessage = messageSource.getMessage(KJ_CommonUtil.getMessageId(
          ECISReturnCodeConstants.RETURN_CODE_G017), new String[] {},
          Locale.getDefault());

      // パラメータチェック
      // 引数.取得対象日リストがNULLまたは0件の場合、以下の処理を行う
      if (CollectionUtils.isEmpty(targetDateList)) {
        // リターンコード（P001）と対応するメッセージを設定し、返却する。
        returnBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P001);
        returnBusinessBean.setMessage(messageSource.getMessage(KJ_CommonUtil.getMessageId(
            ECISReturnCodeConstants.RETURN_CODE_P001), new String[] {},
            Locale.getDefault()));

        return returnBusinessBean;
      }

      // 戻り値.対象日付単価情報マップを生成する。
      Map<Date, Map<String, FcaUpM>> dateUpMap = new HashMap<Date, Map<String, FcaUpM>>();

      // 引数.取得対象日リストの件数分、以下の処理を行う。
      for (Date targetDate : targetDateList) {
        // 契約履歴Exampleを生成し、以下の検索条件を設定する。
        ContractHistExample contractHistExample = new ContractHistExample();
        // 契約ID、適用開始日、適用終了日の設定
        contractHistExample.createCriteria().andContractIdEqualTo(businessBean.getContractId())
            .andApplySdLessThanOrEqualTo(targetDate)
            .andApplyEdGreaterThanOrEqualTo(targetDate);
        // 契約履歴リストを取得する。
        List<ContractHist> contractHistList = contractHistMapper.selectByExample(contractHistExample);
        // 燃調単価Exampleを生成し、以下の検索条件を設定する。
        FcaUpMExample example = new FcaUpMExample();

        // 燃調単価取得方法区分 = ”算定期間開始日”の場合
        if (ECISRKConstants.FUEL_COST_ADJUST_GET_WAY_CAT_CALC_PERIOD_START.equals(
            businessBean.getFcaUpGetWayCategory())) {
          // エリアコードを判定し、nullまたは空文字の場合、対象日と電圧区分を設定する。
          if (StringUtils.isEmpty(areaCode)) {
            // 対象日と電圧区分を設定する
            example.createCriteria().andUpApplySdLessThanOrEqualTo(targetDate)
                .andUpApplyEdGreaterThanOrEqualTo(targetDate)
                .andVoltageCatCodeEqualTo(contractHistList.get(0).getVoltageCatCode());

            // エリアコードが指定された場合、対象日とエリアコードと電圧区分を設定する。
          } else {
            // 対象日とエリアコードと電圧区分を設定する
            example.createCriteria().andUpApplySdLessThanOrEqualTo(targetDate)
                .andUpApplyEdGreaterThanOrEqualTo(targetDate).andAreaCodeEqualTo(areaCode)
                .andVoltageCatCodeEqualTo(contractHistList.get(0).getVoltageCatCode());
          }
        }
        // 燃調単価取得方法区分 = ”利用年月”の場合
        else {
          // エリアコードを判定し、nullまたは空文字の場合、対象年月と電圧区分を設定する。
          if (StringUtils.isEmpty(areaCode)) {
            // 対象年月と電圧区分を設定する
            example.createCriteria().andUsePeriodEqualTo(businessBean.getUsePeriodMap().get(targetDate))
                .andVoltageCatCodeEqualTo(contractHistList.get(0).getVoltageCatCode());

            // エリアコードが指定された場合、対象年月とエリアコードと電圧区分を設定する。
          } else {
            // 対象年月とエリアコードと電圧区分を設定する
            example.createCriteria().andUsePeriodEqualTo(businessBean.getUsePeriodMap().get(targetDate))
                .andAreaCodeEqualTo(areaCode)
                .andVoltageCatCodeEqualTo(contractHistList.get(0).getVoltageCatCode());
          }
        }

        // 燃調単価情報リストを取得する。
        List<FcaUpM> fcaUpMList = fcaUpMMapper.selectByExample(example);

        // 変数.燃調単価マップを生成する
        Map<String, FcaUpM> fcaUpMMap = new HashMap<String, FcaUpM>();

        // 取得した燃調単価情報リストの件数分、以下の処理を行う。
        for (FcaUpM fcaUpM : fcaUpMList) {
          // 燃調単価情報.エリアコードをキーに、変数.燃調単価マップに燃調単価情報を設定する。
          fcaUpMMap.put(fcaUpM.getAreaCode(), fcaUpM);
        }

        // 処理中の取得対象日をキーに、変数.燃調単価マップを戻り値.対象日付単価情報マップに設定する。
        // ※ 燃調単価の取得条件が「利用年月」の場合でも、戻り値に設定するキーは従来の「取得対象日」のまま。
        dateUpMap.put(targetDate, fcaUpMMap);
      }

      // 戻り値設定
      // 戻り値.対象日付単価情報マップをBusinessBeanに設定する。
      returnBusinessBean.setDateUpMap(dateUpMap);
      // リターンコード(0000)を設定する。
      returnBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);

    } catch (NoSuchMessageException e) {
      // メッセージ検索例外が発生した場合、以下の処理を行う。
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, e);
      returnBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      returnBusinessBean.setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);

    } catch (DataAccessException e) {
      // データアクセスエラーが発生した場合、以下の処理を行う。
      logger.error(errorMessage, e);
      returnBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      returnBusinessBean.setMessage(errorMessage);
    }

    return returnBusinessBean;
  }

  /**
   * 燃調単価マッパーのセッター(DI)
   *
   * @param fcaUpMMapper
   *          燃調単価マッパー
   */
  public void setFcaUpMMapper(FcaUpMMapper fcaUpMMapper) {
    this.fcaUpMMapper = fcaUpMMapper;
  }

  /**
   * 契約履歴マッパーのセッター(DI)
   *
   * @param contractHistMapper
   *          契約履歴マッパー
   */
  public void setContractHistMapper(ContractHistMapper contractHistMapper) {
    this.contractHistMapper = contractHistMapper;
  }

  /**
   * messageSourceのセッター(DI)
   *
   * @param messageSource
   *          メッセージソース
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }
}
