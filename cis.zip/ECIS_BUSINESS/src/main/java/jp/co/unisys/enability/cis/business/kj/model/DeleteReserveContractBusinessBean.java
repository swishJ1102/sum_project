package jp.co.unisys.enability.cis.business.kj.model;

import java.util.Date;

/**
 * 予備契約情報削除で、削除条件を格納するビジネスBean
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * 予備契約情報ビジネス
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class DeleteReserveContractBusinessBean {

  /**
   * 契約IDを保有する。
   */
  private Integer contractId;

  /**
   * 予備契約種別を保有する。
   */
  private Integer reserveContractClass;

  /**
   * 予備契約開始日を保有する。
   */
  private Date reserveContractSd;

  /**
   * 更新回数を保有する。
   */
  private Integer updateCount;

  /**
   * リターンコードを保有する。
   */
  private String returnCode;

  /**
   * メッセージを保有する。
   */
  private String message;

  /**
   * 契約IDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約IDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約ID
   */
  public Integer getContractId() {
    return this.contractId;
  }

  /**
   * 契約IDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約IDを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractId
   *          契約ID
   *
   */
  public void setContractId(Integer contractId) {
    this.contractId = contractId;
  }

  /**
   * 予備契約種別のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 予備契約種別を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 予備契約種別
   */
  public Integer getReserveContractClass() {
    return this.reserveContractClass;
  }

  /**
   * 予備契約種別のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 予備契約種別を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param reserveContractClass
   *          予備契約種別
   *
   */
  public void setReserveContractClass(Integer reserveContractClass) {
    this.reserveContractClass = reserveContractClass;
  }

  /**
   * 予備契約開始日のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 予備契約開始日を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 予備契約開始日
   */
  public Date getReserveContractSd() {
    return this.reserveContractSd;
  }

  /**
   * 予備契約開始日のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 予備契約開始日を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param reserveContractSd
   *          予備契約開始日
   *
   */
  public void setReserveContractSd(Date reserveContractSd) {
    this.reserveContractSd = reserveContractSd;
  }

  /**
   * 更新回数のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 更新回数を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 更新回数
   */
  public Integer getUpdateCount() {
    return this.updateCount;
  }

  /**
   * 更新回数のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 更新回数を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param updateCount
   *          更新回数
   *
   */
  public void setUpdateCount(Integer updateCount) {
    this.updateCount = updateCount;
  }

  /**
   * リターンコードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return リターンコード
   */
  public String getReturnCode() {
    return this.returnCode;
  }

  /**
   * リターンコードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param returnCode
   *          リターンコード
   *
   */
  public void setReturnCode(String returnCode) {
    this.returnCode = returnCode;
  }

  /**
   * メッセージのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return メッセージ
   */
  public String getMessage() {
    return this.message;
  }

  /**
   * メッセージのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param message
   *          メッセージ
   *
   */
  public void setMessage(String message) {
    this.message = message;
  }

}
