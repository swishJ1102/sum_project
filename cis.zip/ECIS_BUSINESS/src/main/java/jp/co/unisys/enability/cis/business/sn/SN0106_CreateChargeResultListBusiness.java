package jp.co.unisys.enability.cis.business.sn;

import java.util.Date;

import jp.co.unisys.enability.cis.business.sn.model.SN0106_CreateChargeResultListBusinessBean;
import jp.co.unisys.enability.cis.entity.common.PmCompanyM;
import jp.co.unisys.enability.cis.entity.common.WorkScheduleMngM;

/**
 * 請求入金共通料金実績一覧作成ビジネスインターフェース。
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.sn.SN_BillingCommonBusiness.createListForCsv
 */
public interface SN0106_CreateChargeResultListBusiness {
  /**
   * 料金実績一覧ファイル出力。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 対象企業の確定料金実績と料金実績内訳を「料金実績一覧ファイル」と「料金実績内訳ファイル」に出力する。
   *
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param batchDate
   *          バッチ処理基準日
   * @param workScheduleMngM
   *          業務日程管理マスタEntityBean
   * @param pmCompanyM
   *          提供モデル企業マスタEntityBean
   * @param monthlyFlag
   *          月次利用フラグ
   * @return SN0106_CreateChargeResultListBusinessBean 料金実績一覧作成ビジネスBean
   */
  SN0106_CreateChargeResultListBusinessBean outputChargeResultListFile(
      Date batchDate, WorkScheduleMngM workScheduleMngM, PmCompanyM pmCompanyM, String monthlyFlag);

}
