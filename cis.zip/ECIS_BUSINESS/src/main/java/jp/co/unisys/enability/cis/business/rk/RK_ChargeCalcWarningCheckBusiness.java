package jp.co.unisys.enability.cis.business.rk;

import jp.co.unisys.enability.cis.business.rk.model.RK_ChargeCalcWarningCheckBusinessBean;

/**
 * 料金計算警告チェックビジネスインターフェース
 *
 * @author "Nihon Unisys, Ltd."
 */
public interface RK_ChargeCalcWarningCheckBusiness {

  /**
   * 料金計算警告チェックのチェック処理。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金計算のチェック処理を行う。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param chargeCalcWarningCheckBean
   *          料金計算警告チェックビジネスBean
   * @return 警告コード(警告があった場合)、警告が無い場合はnull
   */
  public String check(RK_ChargeCalcWarningCheckBusinessBean chargeCalcWarningCheckBean);
}
