package jp.co.unisys.enability.cis.business.gk;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import jp.co.unisys.enability.cis.business.gk.model.CalendarBusinessBean;
import jp.co.unisys.enability.cis.common.util.EMSConstants;
import jp.co.unisys.enability.cis.common.util.EMSMessageResource;
import jp.co.unisys.enability.cis.common.util.KJ_CommonUtil;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISReturnCodeConstants;
import jp.co.unisys.enability.cis.entity.common.CalendarM;
import jp.co.unisys.enability.cis.entity.common.CalendarMExample;
import jp.co.unisys.enability.cis.mapper.common.CalendarMMapper;
import jp.co.unisys.enability.cis.mapper.gk.CalendarCommonMapper;

/**
 * カレンダー関連機能共通処理
 *
 * <pre>
 * <p><b>【仕様詳細】<b><p>
 * カレンダー関連機能の共通処理を実行する。
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class CalendarBusinessImpl implements CalendarBusiness {

  /** カレンダーマスタ共通Mapper (DI) */
  private CalendarCommonMapper calendarCommonMapper;

  /** カレンダーマスタMapper (DI) */
  private CalendarMMapper calendarMMapper;

  /** メッセージプロパティ (DI) */
  private EMSMessageResource emsMessageResource;

  /*
   * @see jp.co.unisys.enability.cis.business.gk.CalendarBusiness#
   * calculateSalesTermNumberOfDays
   * (jp.co.unisys.enability.cis.business.gk.model.CalendarBusinessBean)
   */
  public CalendarBusinessBean calculateSalesTermNumberOfDays(
      CalendarBusinessBean calendarBusinessBean) {

    // 対象期間日数を算出する
    long diff = calendarBusinessBean.getEndDate().getTime()
        - calendarBusinessBean.getBaseDate().getTime();
    diff = diff / EMSConstants.ONE_DAY_MILLI_SECONDS + 1;
    // 対象期間内の日数を【カレンダー】より算出し、取得日数が異なる場合エラーを返却する
    if (diff != calendarCommonMapper.selectTermNumberOfDays(
        calendarBusinessBean.getBaseDate(),
        calendarBusinessBean.getEndDate()).longValue()) {
      calendarBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P059);
      calendarBusinessBean
          .setMessage(emsMessageResource.getMessage(
              KJ_CommonUtil
                  .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P059),
              null));
      return calendarBusinessBean;
    }

    // 営業期間日数を設定し返却する
    calendarBusinessBean.setProcessingResult(calendarCommonMapper
        .selectSalesTermNumberOfDays(
            calendarBusinessBean.getBaseDate(),
            calendarBusinessBean.getEndDate(),
            calendarBusinessBean.getOperatorHolidayCategory()));
    calendarBusinessBean
        .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);

    return calendarBusinessBean;
  }

  /*
   * @see
   * jp.co.unisys.enability.cis.business.gk.CalendarBusiness#calculateSalesDate
   * (jp.co.unisys.enability.cis.business.gk.model.CalendarBusinessBean)
   */
  public CalendarBusinessBean calculateSalesDate(
      CalendarBusinessBean calendarBusinessBean) {
    // 基準日と期間数により対象日付を取得する。
    Calendar cal = Calendar.getInstance();
    cal.setTime(calendarBusinessBean.getBaseDate());
    cal.add(Calendar.DATE, calendarBusinessBean.getTermNumberOfDays());
    // 時分秒を初期化
    cal.set(Calendar.HOUR_OF_DAY, 0);
    cal.set(Calendar.MINUTE, 0);
    cal.set(Calendar.SECOND, 0);
    cal.set(Calendar.MILLISECOND, 0);

    if (calendarBusinessBean.getTermNumberOfDays() >= 0) {
      // 対象日付と【カレンダー】から取得した日付を確認し、差分が存在する場合エラーコードを設定して返却を行う。
      Date maxCalendarDate = calendarCommonMapper.selectMaxCalendarDate(
          calendarBusinessBean.getBaseDate(),
          calendarBusinessBean.getTermNumberOfDays());
      if (maxCalendarDate == null
          || 0 != cal.getTime().compareTo(maxCalendarDate)) {
        calendarBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P060);
        calendarBusinessBean
            .setMessage(emsMessageResource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P060),
                null));
        return calendarBusinessBean;
      }
      // 【カレンダー】より対象日付を取得して返却を行う。
      calendarBusinessBean.setProcessingResult(calendarCommonMapper
          .selectSalesDateAfterBaseDate(
              calendarBusinessBean.getBaseDate(),
              calendarBusinessBean.getOperatorHolidayCategory(),
              calendarBusinessBean.getTermNumberOfDays()));
      calendarBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);
    } else {
      // 対象日付と【カレンダー】から取得した日付を確認し、差分が存在する場合エラーコードを設定して返却を行う。
      Date minCalendarDate = calendarCommonMapper.selectMinCalendarDate(
          calendarBusinessBean.getBaseDate(),
          calendarBusinessBean.getTermNumberOfDays());
      if (minCalendarDate == null
          || 0 != cal.getTime().compareTo(minCalendarDate)) {
        calendarBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P060);
        calendarBusinessBean
            .setMessage(emsMessageResource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P060),
                null));
        return calendarBusinessBean;
      }
      // 【カレンダー】より対象日付を取得して返却を行う。
      calendarBusinessBean.setProcessingResult(calendarCommonMapper
          .selectSalesDateBeforeBaseDate(
              calendarBusinessBean.getBaseDate(),
              calendarBusinessBean.getOperatorHolidayCategory(),
              calendarBusinessBean.getTermNumberOfDays()));
      calendarBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);
    }

    return calendarBusinessBean;
  }

  /*
   * @see
   * jp.co.unisys.enability.cis.business.gk.CalendarBusiness#inquiryPublicHoliday
   * (jp.co.unisys.enability.cis.business.gk.model.CalendarBusinessBean)
   */
  public CalendarBusinessBean inquiryPublicHoliday(
      CalendarBusinessBean calendarBusinessBean) {
    // 基準日を条件に指定して【カレンダー】よりレコードを取得する。
    CalendarMExample example = new CalendarMExample();
    example.createCriteria().andCalendarDateEqualTo(
        calendarBusinessBean.getBaseDate());
    List<CalendarM> resultList = calendarMMapper.selectByExample(example);
    // 対象のレコードが存在しなかった場合、エラーコードを設定し返却を行う。
    if (resultList.isEmpty()) {
      calendarBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G014);
      calendarBusinessBean
          .setMessage(emsMessageResource.getMessage(
              KJ_CommonUtil
                  .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G014),
              null));
      return calendarBusinessBean;
    }
    // 対象レコードより祝祭日フラグを取得し、返却を行う。
    calendarBusinessBean.setProcessingResult(resultList.get(0)
        .getPublicHolidayFlag().toString());
    calendarBusinessBean
        .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);
    return calendarBusinessBean;
  }

  /*
   * @see jp.co.unisys.enability.cis.business.gk.CalendarBusiness#
   * inquiryOperatorHoliday
   * (jp.co.unisys.enability.cis.business.gk.model.CalendarBusinessBean)
   */
  public CalendarBusinessBean inquiryOperatorHoliday(
      CalendarBusinessBean calendarBusinessBean) {
    // 基準日と事業者休日区分を条件に指定して【カレンダー】よりレコードを取得する。
    String tagetFlag = calendarCommonMapper.selectOperatorHolidayFlag(
        calendarBusinessBean.getOperatorHolidayCategory(),
        calendarBusinessBean.getBaseDate());
    // 対象のレコードが存在しなかった場合、エラーコードを設定し返却を行う。
    if (StringUtils.isEmpty(tagetFlag)) {
      calendarBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G015);
      calendarBusinessBean
          .setMessage(emsMessageResource.getMessage(
              KJ_CommonUtil
                  .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G015),
              null));
      return calendarBusinessBean;
    }
    // 取得した事業者休日フラグを設定し、返却を行う。
    calendarBusinessBean.setProcessingResult(tagetFlag);
    calendarBusinessBean
        .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);
    return calendarBusinessBean;
  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.gk.CalendarBusiness#selectCoveredDateList
   * (java.lang.String, java.lang.String, java.util.Date, java.util.Date)
   */
  public List<Date> selectCoveredDateList(String calendarCoveredColumnName,
      String coveredValue, Date ymdStart, Date ymdEnd) {
    // 列名配列
    String[] colName = calendarCoveredColumnName
        .split(ECISConstants.CALENDAR_COVERED_COLUMN_NAME_DELIMITER);
    // 論理演算子
    String[] operator = coveredValue
        .split(ECISConstants.COVERED_VALUE_LOGICAL_OPERATOR_DELIMITER);
    // 対象
    String[] objValue = (operator[1].split(ECISConstants.COVERED_VALUE_DELIMITER));

    int objLength = objValue.length;

    Map<String, String> targetMap = new HashMap<String, String>();

    // 列名配列、対象をマップに設定
    for (int i = 0; i < objLength; i++) {
      targetMap.put(colName[i], objValue[i]);
    }

    // カレンダーExample
    CalendarMExample calendarMExample = new CalendarMExample();

    // 条件を設定
    calendarMExample.createCriteria().andCalendarDateBetween(ymdStart,
        ymdEnd);

    // 【カレンダー】を取得する
    List<HashMap<String, Object>> resultList = calendarMMapper
        .selectByExampleReturnHashMap(calendarMExample);
    // 戻りのリストを生成する
    List<Date> dateList = new ArrayList<Date>();

    // 条件がANDの場合
    if (ECISConstants.OPERATOR_FOR_AND.equals(operator[0].toUpperCase())) {
      // カレンダーの日数分処理する
      for (HashMap<String, Object> calendarMap : resultList) {
        // 追加対象フラグ
        boolean addCoveredFlag = false;

        // キーの数分処理する
        for (Map.Entry<String, String> target : targetMap.entrySet()) {
          // 取得した値と現在処理中の「判定条件Map」の値が一致する場合
          if (((String) calendarMap.get(target.getKey()))
              .equals(target.getValue())) {
            // 「追加対象フラグ」をtrueに設定する
            addCoveredFlag = true;
          } else {
            // 「追加対象フラグ」をfalseに設定する
            addCoveredFlag = false;
            // 繰り返し処理を終了する
            break;
          }
        }
        // 「追加対象フラグ」がtrueの場合
        if (addCoveredFlag) {
          // 日付を格納するリストの追加
          dateList.add((Date) calendarMap.get("calendar_date"));
        }
      }
      // 条件がORの場合
    } else if (ECISConstants.OPERATOR_FOR_OR.equals(operator[0].toUpperCase())) {
      // カレンダーの日数分処理する
      for (HashMap<String, Object> calendarMap : resultList) {
        // 追加対象フラグ
        boolean addCoveredFlag = false;

        // キーの数分処理する
        for (Map.Entry<String, String> target : targetMap.entrySet()) {
          // 取得した値と現在処理中の「判定条件Map」の値が一致する場合
          if (((String) calendarMap.get(target.getKey()))
              .equals(target.getValue())) {
            // 「追加対象フラグ」をtrueに設定する
            addCoveredFlag = true;
            // 繰り返し処理を終了する
            break;
          }
        }
        // 「追加対象フラグ」がtrueの場合
        if (addCoveredFlag) {
          // 日付を格納するリストの追加
          dateList.add((Date) calendarMap.get("calendar_date"));
        }
      }
    }

    // 日付を格納するリストを返却する
    return dateList;
  }

  /**
   * カレンダーマスタ共通Mapparのsetter(DI)
   *
   * @param calendarCommonMapper
   *          カレンダーマスタ共通Mappar
   *
   */
  public void setCalendarCommonMapper(
      CalendarCommonMapper calendarCommonMapper) {
    this.calendarCommonMapper = calendarCommonMapper;
  }

  /**
   * カレンダーマスタMapperのsetter(DI)
   *
   * @param calendarMMapper
   *          カレンダーマスタMappar
   *
   */
  public void setCalendarMMapper(CalendarMMapper calendarMMapper) {
    this.calendarMMapper = calendarMMapper;
  }

  /**
   * メッセージリソースのsetter(DI)
   *
   * @param emsMessageResource
   *          メッセージリソース
   */
  public void setEmsMessageResource(EMSMessageResource emsMessageResource) {
    this.emsMessageResource = emsMessageResource;
  }
}
