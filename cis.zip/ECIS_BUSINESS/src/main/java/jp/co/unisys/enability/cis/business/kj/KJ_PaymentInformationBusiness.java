package jp.co.unisys.enability.cis.business.kj;

import jp.co.unisys.enability.cis.business.kj.model.CsvFileCheckPaymentBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.DeletePaymentBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.DownloadPaymentBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.InquiryPaymentBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.RegistPaymentBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.UpdatePaymentBusinessBean;
import jp.co.unisys.enability.cis.common.Exception.SystemException;

/**
 * 支払情報ビジネスインターフェース。
 *
 * @author "Nihon Unisys, Ltd."
 *
 */
public interface KJ_PaymentInformationBusiness {
  /**
   * 支払情報の照会を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * CRMや低圧CISで、【支払】を特定する場合に、
   * 指定により、現在以降有効な支払情報、または過去を含む全履歴の支払情報を返却する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param inquiryPaymentBusinessBean
   *          支払情報照会BusinessBean
   * @return 支払情報照会BusinessBean
   */
  public InquiryPaymentBusinessBean inquiry(
      InquiryPaymentBusinessBean inquiryPaymentBusinessBean);

  /**
   * 支払情報の登録を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * CRMや低圧CISから、「契約者」に紐付く【支払】を登録する場合に使用する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param registPaymentBusinessBean
   *          支払情報登録BusinessBean
   * @return 支払情報登録BusinessBean
   */
  public RegistPaymentBusinessBean regist(
      RegistPaymentBusinessBean registPaymentBusinessBean);

  /**
   * 支払情報更新を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 指定された支払情報を更新する。確定された請求に使用されているかどうかチェックし、使用されていた場合、更新不可とする。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param updatePaymentBusinessBean
   *          支払情報更新BusinessBean
   * @return 支払情報更新BusinessBean
   */
  public UpdatePaymentBusinessBean update(
      UpdatePaymentBusinessBean updatePaymentBusinessBean);

  /**
   * 支払情報削除を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 指定された支払情報を削除する。確定された請求に使用されているかどうかチェックし、使用されていた場合、削除不可とする。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param deletePaymentBusinessBean
   *          支払情報削除BusinessBean
   * @return 支払情報削除BusinessBean
   */
  public DeletePaymentBusinessBean delete(
      DeletePaymentBusinessBean deletePaymentBusinessBean);

  /**
   * ダウンロードファイルの情報を取得する処理を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * ダウンロードファイル情報取得のMapperを呼び出し、ダウンロードファイル情報を取得する。
   * CSVファイル名を生成する。
   * DownloadPaymentBusinessBeanにダウンロードファイル情報とCSVファイル名を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param DownloadPaymentBusinessBean
   *          検索条件
   * @return DownloadPaymentBusinessBean ダウンロードファイル情報、CSVファイル名
   * @throws SystemException
   *           予期せぬエラーが発生した場合
   */
  public DownloadPaymentBusinessBean download(
      DownloadPaymentBusinessBean downloadBusinessBean)
      throws SystemException;

  /**
   * ダウンロードファイルの情報を取得する処理を行う。 （カスタム仕様のダウンロード項目対応）
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * ダウンロードファイル情報取得のMapperを呼び出し、ダウンロードファイル情報を取得する。
   * CSVファイル名を生成する。
   * DownloadPaymentBusinessBeanにダウンロードファイル情報とCSVファイル名を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param DownloadPaymentBusinessBean
   *          検索条件
   * @return DownloadPaymentBusinessBean ダウンロードファイル情報、CSVファイル名
   * @throws SystemException
   *           予期せぬエラーが発生した場合
   */
  public DownloadPaymentBusinessBean downloadCustom(
      DownloadPaymentBusinessBean downloadBusinessBean)
      throws SystemException;

  /**
   * CSVファイルチェックを行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * アップロードを行うCSVファイルのチェックを行う。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param csvFileCheckPaymentBusinessBean
   *          支払情報CSVファイルチェックBusinessBean
   * @return 支払情報CSVファイルチェックBusinessBean
   */
  public CsvFileCheckPaymentBusinessBean csvFileCheck(
      CsvFileCheckPaymentBusinessBean csvFileCheckPaymentBusinessBean);

  /**
   * CSVファイルチェックを行う。 （カスタム仕様のアップロード項目対応）
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * アップロードを行うCSVファイルのチェックを行う。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param csvFileCheckPaymentBusinessBean
   *          支払情報CSVファイルチェックBusinessBean
   * @return 支払情報CSVファイルチェックBusinessBean
   */
  public CsvFileCheckPaymentBusinessBean csvFileCheckCustom(
      CsvFileCheckPaymentBusinessBean csvFileCheckPaymentBusinessBean);

}
