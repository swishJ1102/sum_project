package jp.co.unisys.enability.cis.business.kj.model;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * 契約情報更新で、更新条件を格納するビジネスBean
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * 契約情報更新ビジネス
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class ForceUpdateContractBusinessBean {

  /** 契約ID */
  private Integer contractId;

  /** 契約番号 */
  private String contractNo;

  /** 選択支払ID */
  private Integer selectPaymentId;

  /** 選択支払番号 */
  private String selectPaymentNo;

  /** 卸取次店契約番号(外部システム契約番号) */
  private String agentContractNo;

  /** 契約開始日 */
  private Date contractStartDate;

  /** 契約終了日 */
  private Date contractEndDate;

  /** 契約終了理由コード */
  private String contractEndReasonCode;

  /** 託送契約容量 */
  private BigDecimal consignmentContractCapacity;

  /** 託送契約容量単位コード */
  private String consignmentcontractCapacityUnitCode;

  /** 託送契約容量判定日 */
  private Date consignmentContractCapacityDecisionDate;

  /** 託送契約容量フラグ */
  private String consignmentContractCapacityFlag;

  /** 託送契約容量判定日フラグ */
  private String consignmentContractCapacityDecisionDateFlag;

  /** 料金チェックフラグ */
  private String chargeCheckFlag;

  /** 契約グループ番号 */
  private String contractGroupNo;

  /** 建物用途 */
  private String contractFree1;

  /** 需要者氏名 */
  private String contractFree2;

  /** 需要者氏名カナ */
  private String contractFree3;

  /** 連絡先個人・法人区分コード */
  private String contactInformationinDividualLegalEntityCategoryCode;

  /** 連絡先氏名（カナ） */
  private String contractInformationNameKana;

  /** 連絡先氏名1 */
  private String contractInformationName1;

  /** 連絡先氏名2 */
  private String contractInformationName2;

  /** 連絡先住所（郵便番号） */
  private String contractInformationAddressPostalCode;

  /** 連絡先住所（住所） */
  private String contractInformationAddressFull;

  /** 連絡先住所（建物・部屋名） */
  private String contractInformationAddressBuilding;

  /** 連絡先電話区分コード */
  private String contractInformationCategoryCode;

  /** 連絡先電話（市外局番） */
  private String contractInformationAreaCode;

  /** 連絡先電話（市内局番） */
  private String contractInformationLocalNo;

  /** 連絡先電話（加入者番号） */
  private String contractInformationDirectoryNo;

  /** 需要者窓口連絡先所属 */
  private String consumerContractAffiliation;

  /** 需要者窓口連絡先氏名 */
  private String consumerContractName;

  /** 需要者窓口連絡先電話番号 */
  private String consumerContractPhoneNo;

  /** 需要者窓口連絡先電話番号（市外局番） */
  private String consumerContractAreaCode;

  /** 需要者窓口連絡先電話番号（市内局番） */
  private String consumerContractLocalNo;

  /** 需要者窓口連絡先電話番号（加入者番号） */
  private String consumerContractDirectoryNo;

  /** 主任技術者連絡先所属 */
  private String chiefEngineerOfficerAffiliation;

  /** 主任技術者連絡先氏名 */
  private String chiefEngineerOfficerName;

  /** 主任技術者連絡先電話番号 */
  private String chiefEngineerOfficerPhoneNo;

  /** 主任技術者連絡先電話番号（市外局番） */
  private String chiefEngineerOfficerAreaCode;

  /** 主任技術者連絡先電話番号（市内局番） */
  private String chiefEngineerOfficerLocalNo;

  /** 主任技術者連絡先電話番号（加入者番号） */
  private String chiefEngineerOfficerDirectoryNo;

  /** 接続送電サービス区分コード */
  private String connectedSupplyServiceCategoryCode;

  /** フリー項目1 */
  private String free1;

  /** フリー項目2 */
  private String free2;

  /** フリー項目3 */
  private String free3;

  /** フリー項目4 */
  private String free4;

  /** フリー項目5 */
  private String free5;

  /** フリー項目6 */
  private String free6;

  /** フリー項目7 */
  private String free7;

  /** フリー項目8 */
  private String free8;

  /** フリー項目9 */
  private String free9;

  /** フリー項目10 */
  private String free10;

  /** フリー項目11 */
  private String free11;

  /** フリー項目12 */
  private String free12;

  /** フリー項目13 */
  private String free13;

  /** フリー項目14 */
  private String free14;

  /** 業種コード */
  private String businessTypeCode;

  /** 営業委託先コード */
  private String salesConsignmentCode;

  /** 契約備考 */
  private String contractNote;

  /** 適用開始日 */
  private Date applyStartDate;

  /** 料金メニューID */
  private String chargeMenuId;

  /** 契約容量 */
  private BigDecimal contractCapacity;

  /** 契約変更理由 */
  private String contractChangeReason;

  /** 委託先使用項目1 */
  private String consignmentUseItem1;

  /** 委託先使用項目2 */
  private String consignmentUseItem2;

  /** 委託先使用項目3 */
  private String consignmentUseItem3;

  /** 自社担当者コード */
  private String ourManagementPersonInChargeCode;

  /** 自社部署コード */
  private String ourManagementDepartmentCode;

  /** 部分供給区分コード */
  private String psInfoCatCode;

  /** 更新回数 */
  private Integer updateCount;

  /** 付帯契約リスト */
  private List<SupplementaryContractInformationBean> supplementaryContractInformationBeanList;

  /** 契約電力決定区分 */
  private String ccDecisionCategoryCode;

  /** 単価設定区分コード */
  private String unitPriceCategoryCode;

  /** 最低月額料金 */
  private BigDecimal minimumMonthlyCharge;

  /** 料金メニュー単価明細情報リスト */
  private List<RmUpDetailBean> rmUpDetailList;

  /** リターンコード */
  private String returnCode;

  /** メッセージ */
  private String message;

  public Integer getContractId() {
    return contractId;
  }

  public void setContractId(Integer contractId) {
    this.contractId = contractId;
  }

  public String getContractNo() {
    return contractNo;
  }

  public void setContractNo(String contractNo) {
    this.contractNo = contractNo;
  }

  public Integer getSelectPaymentId() {
    return selectPaymentId;
  }

  public void setSelectPaymentId(Integer selectPaymentId) {
    this.selectPaymentId = selectPaymentId;
  }

  public String getSelectPaymentNo() {
    return selectPaymentNo;
  }

  public void setSelectPaymentNo(String selectPaymentNo) {
    this.selectPaymentNo = selectPaymentNo;
  }

  public String getAgentContractNo() {
    return agentContractNo;
  }

  public void setAgentContractNo(String agentContractNo) {
    this.agentContractNo = agentContractNo;
  }

  public Date getContractStartDate() {
    return contractStartDate;
  }

  public void setContractStartDate(Date contractStartDate) {
    this.contractStartDate = contractStartDate;
  }

  public Date getContractEndDate() {
    return contractEndDate;
  }

  public void setContractEndDate(Date contractEndDate) {
    this.contractEndDate = contractEndDate;
  }

  public String getContractEndReasonCode() {
    return contractEndReasonCode;
  }

  public void setContractEndReasonCode(String contractEndReasonCode) {
    this.contractEndReasonCode = contractEndReasonCode;
  }

  public BigDecimal getConsignmentContractCapacity() {
    return consignmentContractCapacity;
  }

  public void setConsignmentContractCapacity(BigDecimal consignmentContractCapacity) {
    this.consignmentContractCapacity = consignmentContractCapacity;
  }

  public String getConsignmentcontractCapacityUnitCode() {
    return consignmentcontractCapacityUnitCode;
  }

  public void setConsignmentcontractCapacityUnitCode(String consignmentcontractCapacityUnitCode) {
    this.consignmentcontractCapacityUnitCode = consignmentcontractCapacityUnitCode;
  }

  public Date getConsignmentContractCapacityDecisionDate() {
    return consignmentContractCapacityDecisionDate;
  }

  public void setConsignmentContractCapacityDecisionDate(Date consignmentContractCapacityDecisionDate) {
    this.consignmentContractCapacityDecisionDate = consignmentContractCapacityDecisionDate;
  }

  public String getConsignmentContractCapacityFlag() {
    return consignmentContractCapacityFlag;
  }

  public void setConsignmentContractCapacityFlag(String consignmentContractCapacityFlag) {
    this.consignmentContractCapacityFlag = consignmentContractCapacityFlag;
  }

  public String getConsignmentContractCapacityDecisionDateFlag() {
    return consignmentContractCapacityDecisionDateFlag;
  }

  public void setConsignmentContractCapacityDecisionDateFlag(String consignmentContractCapacityDecisionDateFlag) {
    this.consignmentContractCapacityDecisionDateFlag = consignmentContractCapacityDecisionDateFlag;
  }

  public String getChargeCheckFlag() {
    return chargeCheckFlag;
  }

  public void setChargeCheckFlag(String chargeCheckFlag) {
    this.chargeCheckFlag = chargeCheckFlag;
  }

  public String getContractGroupNo() {
    return contractGroupNo;
  }

  public void setContractGroupNo(String contractGroupNo) {
    this.contractGroupNo = contractGroupNo;
  }

  public String getContractFree1() {
    return contractFree1;
  }

  public void setContractFree1(String contractFree1) {
    this.contractFree1 = contractFree1;
  }

  public String getContractFree2() {
    return contractFree2;
  }

  public void setContractFree2(String contractFree2) {
    this.contractFree2 = contractFree2;
  }

  public String getContractFree3() {
    return contractFree3;
  }

  public void setContractFree3(String contractFree3) {
    this.contractFree3 = contractFree3;
  }

  public String getContactInformationinDividualLegalEntityCategoryCode() {
    return contactInformationinDividualLegalEntityCategoryCode;
  }

  public void setContactInformationinDividualLegalEntityCategoryCode(
      String contactInformationinDividualLegalEntityCategoryCode) {
    this.contactInformationinDividualLegalEntityCategoryCode = contactInformationinDividualLegalEntityCategoryCode;
  }

  public String getContractInformationNameKana() {
    return contractInformationNameKana;
  }

  public void setContractInformationNameKana(String contractInformationNameKana) {
    this.contractInformationNameKana = contractInformationNameKana;
  }

  public String getContractInformationName1() {
    return contractInformationName1;
  }

  public void setContractInformationName1(String contractInformationName1) {
    this.contractInformationName1 = contractInformationName1;
  }

  public String getContractInformationName2() {
    return contractInformationName2;
  }

  public void setContractInformationName2(String contractInformationName2) {
    this.contractInformationName2 = contractInformationName2;
  }

  public String getContractInformationAddressPostalCode() {
    return contractInformationAddressPostalCode;
  }

  public void setContractInformationAddressPostalCode(String contractInformationAddressPostalCode) {
    this.contractInformationAddressPostalCode = contractInformationAddressPostalCode;
  }

  public String getContractInformationAddressFull() {
    return contractInformationAddressFull;
  }

  public void setContractInformationAddressFull(String contractInformationAddressFull) {
    this.contractInformationAddressFull = contractInformationAddressFull;
  }

  public String getContractInformationAddressBuilding() {
    return contractInformationAddressBuilding;
  }

  public void setContractInformationAddressBuilding(String contractInformationAddressBuilding) {
    this.contractInformationAddressBuilding = contractInformationAddressBuilding;
  }

  public String getContractInformationCategoryCode() {
    return contractInformationCategoryCode;
  }

  public void setContractInformationCategoryCode(String contractInformationCategoryCode) {
    this.contractInformationCategoryCode = contractInformationCategoryCode;
  }

  public String getContractInformationAreaCode() {
    return contractInformationAreaCode;
  }

  public void setContractInformationAreaCode(String contractInformationAreaCode) {
    this.contractInformationAreaCode = contractInformationAreaCode;
  }

  public String getContractInformationLocalNo() {
    return contractInformationLocalNo;
  }

  public void setContractInformationLocalNo(String contractInformationLocalNo) {
    this.contractInformationLocalNo = contractInformationLocalNo;
  }

  public String getContractInformationDirectoryNo() {
    return contractInformationDirectoryNo;
  }

  public void setContractInformationDirectoryNo(String contractInformationDirectoryNo) {
    this.contractInformationDirectoryNo = contractInformationDirectoryNo;
  }

  public String getConsumerContractAffiliation() {
    return consumerContractAffiliation;
  }

  public void setConsumerContractAffiliation(String consumerContractAffiliation) {
    this.consumerContractAffiliation = consumerContractAffiliation;
  }

  public String getConsumerContractName() {
    return consumerContractName;
  }

  public void setConsumerContractName(String consumerContractName) {
    this.consumerContractName = consumerContractName;
  }

  public String getConsumerContractPhoneNo() {
    return consumerContractPhoneNo;
  }

  public void setConsumerContractPhoneNo(String consumerContractPhoneNo) {
    this.consumerContractPhoneNo = consumerContractPhoneNo;
  }

  public String getConsumerContractAreaCode() {
    return consumerContractAreaCode;
  }

  public void setConsumerContractAreaCode(String consumerContractAreaCode) {
    this.consumerContractAreaCode = consumerContractAreaCode;
  }

  public String getConsumerContractLocalNo() {
    return consumerContractLocalNo;
  }

  public void setConsumerContractLocalNo(String consumerContractLocalNo) {
    this.consumerContractLocalNo = consumerContractLocalNo;
  }

  public String getConsumerContractDirectoryNo() {
    return consumerContractDirectoryNo;
  }

  public void setConsumerContractDirectoryNo(String consumerContractDirectoryNo) {
    this.consumerContractDirectoryNo = consumerContractDirectoryNo;
  }

  public String getChiefEngineerOfficerAffiliation() {
    return chiefEngineerOfficerAffiliation;
  }

  public void setChiefEngineerOfficerAffiliation(String chiefEngineerOfficerAffiliation) {
    this.chiefEngineerOfficerAffiliation = chiefEngineerOfficerAffiliation;
  }

  public String getChiefEngineerOfficerName() {
    return chiefEngineerOfficerName;
  }

  public void setChiefEngineerOfficerName(String chiefEngineerOfficerName) {
    this.chiefEngineerOfficerName = chiefEngineerOfficerName;
  }

  public String getChiefEngineerOfficerPhoneNo() {
    return chiefEngineerOfficerPhoneNo;
  }

  public void setChiefEngineerOfficerPhoneNo(String chiefEngineerOfficerPhoneNo) {
    this.chiefEngineerOfficerPhoneNo = chiefEngineerOfficerPhoneNo;
  }

  public String getChiefEngineerOfficerAreaCode() {
    return chiefEngineerOfficerAreaCode;
  }

  public void setChiefEngineerOfficerAreaCode(String chiefEngineerOfficerAreaCode) {
    this.chiefEngineerOfficerAreaCode = chiefEngineerOfficerAreaCode;
  }

  public String getChiefEngineerOfficerLocalNo() {
    return chiefEngineerOfficerLocalNo;
  }

  public void setChiefEngineerOfficerLocalNo(String chiefEngineerOfficerLocalNo) {
    this.chiefEngineerOfficerLocalNo = chiefEngineerOfficerLocalNo;
  }

  public String getChiefEngineerOfficerDirectoryNo() {
    return chiefEngineerOfficerDirectoryNo;
  }

  public void setChiefEngineerOfficerDirectoryNo(String chiefEngineerOfficerDirectoryNo) {
    this.chiefEngineerOfficerDirectoryNo = chiefEngineerOfficerDirectoryNo;
  }

  public String getConnectedSupplyServiceCategoryCode() {
    return connectedSupplyServiceCategoryCode;
  }

  public void setConnectedSupplyServiceCategoryCode(String connectedSupplyServiceCategoryCode) {
    this.connectedSupplyServiceCategoryCode = connectedSupplyServiceCategoryCode;
  }

  public String getFree1() {
    return free1;
  }

  public void setFree1(String free1) {
    this.free1 = free1;
  }

  public String getFree2() {
    return free2;
  }

  public void setFree2(String free2) {
    this.free2 = free2;
  }

  public String getFree3() {
    return free3;
  }

  public void setFree3(String free3) {
    this.free3 = free3;
  }

  public String getFree4() {
    return free4;
  }

  public void setFree4(String free4) {
    this.free4 = free4;
  }

  public String getFree5() {
    return free5;
  }

  public void setFree5(String free5) {
    this.free5 = free5;
  }

  public String getFree6() {
    return free6;
  }

  public void setFree6(String free6) {
    this.free6 = free6;
  }

  public String getFree7() {
    return free7;
  }

  public void setFree7(String free7) {
    this.free7 = free7;
  }

  public String getFree8() {
    return free8;
  }

  public void setFree8(String free8) {
    this.free8 = free8;
  }

  public String getFree9() {
    return free9;
  }

  public void setFree9(String free9) {
    this.free9 = free9;
  }

  public String getFree10() {
    return free10;
  }

  public void setFree10(String free10) {
    this.free10 = free10;
  }

  public String getFree11() {
    return free11;
  }

  public void setFree11(String free11) {
    this.free11 = free11;
  }

  public String getFree12() {
    return free12;
  }

  public void setFree12(String free12) {
    this.free12 = free12;
  }

  public String getFree13() {
    return free13;
  }

  public void setFree13(String free13) {
    this.free13 = free13;
  }

  public String getFree14() {
    return free14;
  }

  public void setFree14(String free14) {
    this.free14 = free14;
  }

  public String getBusinessTypeCode() {
    return businessTypeCode;
  }

  public void setBusinessTypeCode(String businessTypeCode) {
    this.businessTypeCode = businessTypeCode;
  }

  public String getSalesConsignmentCode() {
    return salesConsignmentCode;
  }

  public void setSalesConsignmentCode(String salesConsignmentCode) {
    this.salesConsignmentCode = salesConsignmentCode;
  }

  public String getContractNote() {
    return contractNote;
  }

  public void setContractNote(String contractNote) {
    this.contractNote = contractNote;
  }

  public Date getApplyStartDate() {
    return applyStartDate;
  }

  public void setApplyStartDate(Date applyStartDate) {
    this.applyStartDate = applyStartDate;
  }

  public String getChargeMenuId() {
    return chargeMenuId;
  }

  public void setChargeMenuId(String chargeMenuId) {
    this.chargeMenuId = chargeMenuId;
  }

  public BigDecimal getContractCapacity() {
    return contractCapacity;
  }

  public void setContractCapacity(BigDecimal contractCapacity) {
    this.contractCapacity = contractCapacity;
  }

  public String getContractChangeReason() {
    return contractChangeReason;
  }

  public void setContractChangeReason(String contractChangeReason) {
    this.contractChangeReason = contractChangeReason;
  }

  public String getConsignmentUseItem1() {
    return consignmentUseItem1;
  }

  public void setConsignmentUseItem1(String consignmentUseItem1) {
    this.consignmentUseItem1 = consignmentUseItem1;
  }

  public String getConsignmentUseItem2() {
    return consignmentUseItem2;
  }

  public void setConsignmentUseItem2(String consignmentUseItem2) {
    this.consignmentUseItem2 = consignmentUseItem2;
  }

  public String getConsignmentUseItem3() {
    return consignmentUseItem3;
  }

  public void setConsignmentUseItem3(String consignmentUseItem3) {
    this.consignmentUseItem3 = consignmentUseItem3;
  }

  public String getOurManagementPersonInChargeCode() {
    return ourManagementPersonInChargeCode;
  }

  public void setOurManagementPersonInChargeCode(String ourManagementPersonInChargeCode) {
    this.ourManagementPersonInChargeCode = ourManagementPersonInChargeCode;
  }

  public String getOurManagementDepartmentCode() {
    return ourManagementDepartmentCode;
  }

  public void setOurManagementDepartmentCode(String ourManagementDepartmentCode) {
    this.ourManagementDepartmentCode = ourManagementDepartmentCode;
  }

  public String getPsInfoCatCode() {
    return psInfoCatCode;
  }

  public void setPsInfoCatCode(String psInfoCatCode) {
    this.psInfoCatCode = psInfoCatCode;
  }

  public Integer getUpdateCount() {
    return updateCount;
  }

  public void setUpdateCount(Integer updateCount) {
    this.updateCount = updateCount;
  }

  public List<SupplementaryContractInformationBean> getSupplementaryContractInformationBeanList() {
    return supplementaryContractInformationBeanList;
  }

  public void setSupplementaryContractInformationBeanList(
      List<SupplementaryContractInformationBean> supplementaryContractInformationBeanList) {
    this.supplementaryContractInformationBeanList = supplementaryContractInformationBeanList;
  }

  public String getReturnCode() {
    return returnCode;
  }

  public void setReturnCode(String returnCode) {
    this.returnCode = returnCode;
  }

  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  public String getCcDecisionCategoryCode() {
    return ccDecisionCategoryCode;
  }

  public void setCcDecisionCategoryCode(String ccDecisionCategoryCode) {
    this.ccDecisionCategoryCode = ccDecisionCategoryCode;
  }

  public String getUnitPriceCategoryCode() {
    return unitPriceCategoryCode;
  }

  public void setUnitPriceCategoryCode(String unitPriceCategoryCode) {
    this.unitPriceCategoryCode = unitPriceCategoryCode;
  }

  public BigDecimal getMinimumMonthlyCharge() {
    return minimumMonthlyCharge;
  }

  public void setMinimumMonthlyCharge(BigDecimal minimumMonthlyCharge) {
    this.minimumMonthlyCharge = minimumMonthlyCharge;
  }

  public List<RmUpDetailBean> getRmUpDetailList() {
    return rmUpDetailList;
  }

  public void setRmUpDetailList(List<RmUpDetailBean> rmUpDetailList) {
    this.rmUpDetailList = rmUpDetailList;
  }

}
