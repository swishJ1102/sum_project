package jp.co.unisys.enability.cis.business.gk;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import jp.co.unisys.enability.cis.business.kj.model.ContractManagementInformationFileConfigCommon;
import jp.co.unisys.enability.cis.business.kj.model.Custom_ContractManagementInformationFileConfigPayment;
import jp.co.unisys.enability.cis.common.util.CommonValidationUtil;
import jp.co.unisys.enability.cis.common.util.EMSMessageResource;

/**
 * 支払情報ファイル削除バリデーション
 *
 * @author "Nihon Unisys, Ltd."
 */
public class Custom_PaymentInformationFileDeleteValidator {

  /** プロパティクラスを定義 */
  private EMSMessageResource emsMessageResource;

  /**
   * メッセージプロパティキー管理のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージプロパティキー管理を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param emsMessageResource
   *          メッセージプロパティキー管理
   */
  public void setEmsMessageResource(EMSMessageResource emsMessageResource) {
    this.emsMessageResource = emsMessageResource;
  }

  /**
   * 支払情報ファイル削除のバリデーションを実施、チェック結果のメッセージListを返却する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 1 引数のバリデーションを行う。
   * 2 チェック結果がNGの場合、戻り値のメッセージListにエラーメッセージを詰めて返却する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param dataRecordMap
   *          データレコードマップ
   * @return メッセージList
   */
  public List<String> validate(Map<Integer, String> dataRecordMap) {

    List<String> messageList = new ArrayList<String>();

    // データレコード種別：必須チェック
    String dataRecordClass = dataRecordMap
        .get(ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_INDEX);
    if (CommonValidationUtil.isNull(dataRecordClass)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_NAME }));

      // データレコード種別：正規表現チェック
    } else if (dataRecordClass != null
        && !CommonValidationUtil
            .checkByPattern(
                dataRecordClass,
                ContractManagementInformationFileConfigCommon.DATA_KIND_MASK_STRING)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_ITEM_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_NAME }));
    }

    // 支払番号：必須チェック
    String paymentNo = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigPayment.DATA_PAYMENT_NO_INDEX);
    if (CommonValidationUtil.isNull(paymentNo)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_PAYMENT_NO_NAME }));

      // 支払番号：文字種別チェック（半角英数字）
    } else if (paymentNo != null
        && !CommonValidationUtil.isAlphabetNumric(paymentNo)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_ALPHANUMERIC_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_PAYMENT_NO_NAME }));

      // 支払番号：文字種別チェック（半角英数字　低圧CISシステム許容文字）
    } else if (paymentNo != null
        && !CommonValidationUtil.isRangeWordByECIS(paymentNo)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_PAYMENT_NO_NAME,
                      "半角英数字（低圧CISシステム許容文字）" }));

      // 支払番号：文字列最大長チェック
    } else if (paymentNo != null
        && !CommonValidationUtil
            .maxLength(
                paymentNo,
                Custom_ContractManagementInformationFileConfigPayment.DATA_PAYMENT_NO_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_PAYMENT_NO_NAME,
                      Custom_ContractManagementInformationFileConfigPayment.DATA_PAYMENT_NO_LENGTH_STRING }));
    }

    // 支払適用開始日：必須チェック
    String paymentStartDate = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigPayment.DATA_PAYMENT_START_DATE_INDEX);
    if (CommonValidationUtil.isNull(paymentStartDate)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_PAYMENT_START_DATE_NAME }));

      // 支払適用開始日：日付フォーマットチェック
    } else if (paymentStartDate != null
        && !CommonValidationUtil
            .checkDateFormat(
                paymentStartDate,
                Custom_ContractManagementInformationFileConfigPayment.DATA_PAYMENT_START_DATE_FORMAT)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_PAYMENT_START_DATE_NAME,
                      Custom_ContractManagementInformationFileConfigPayment.DATA_PAYMENT_START_DATE_MESSAGE }));
    }
    // 更新回数：必須チェック
    String updateCount = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigPayment.DATA_UPDATE_COUNT_INDEX);
    if (CommonValidationUtil.isNull(updateCount)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_UPDATE_COUNT_NAME }));

      // 更新回数：文字種別チェック（半角数字）
    } else if (updateCount != null
        && !CommonValidationUtil.isNumric(updateCount)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_UPDATE_COUNT_NAME,
                      "半角数字" }));

      // 更新回数：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (updateCount != null
        && !CommonValidationUtil
            .isRangeWordByECIS(updateCount)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_UPDATE_COUNT_NAME,
                      "半角数字（低圧CISシステム許容文字）" }));
      // 更新回数：数値範囲チェック
    } else if (updateCount != null
        && !CommonValidationUtil
            .checkRange(
                updateCount,
                Custom_ContractManagementInformationFileConfigPayment.DATA_UPDATE_COUNT_RANGE_MIN,
                Custom_ContractManagementInformationFileConfigPayment.DATA_UPDATE_COUNT_RANGE_MAX)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_RANGE_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_UPDATE_COUNT_NAME,
                      Custom_ContractManagementInformationFileConfigPayment.DATA_UPDATE_COUNT_MESSAGE }));
    }
    return messageList;
  }
}