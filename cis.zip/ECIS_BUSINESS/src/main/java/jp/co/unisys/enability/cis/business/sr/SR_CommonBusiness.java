package jp.co.unisys.enability.cis.business.sr;

import java.util.List;

/**
 * 他シス連携共通Businessクラス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public interface SR_CommonBusiness {

  /**
   * TODO一覧登録。
   *
   * <pre>
   * <p>
   * <b>【仕様詳細】</b>
   * </p>
   * 備考ヘッダ行＋備考リストの要素を連結して【Todo】備考に設定しTodo登録するが、 登録の際、備考が4000byteを超えないように備考の内容を複数に分けて登録する。
   *
   * @author "Nihon Unisys, Ltd."
   * @param functionId
   *          機能ID
   * @param messageId
   *          メッセージID
   * @param placeHolderArray
   *          プレースホルダ配列
   * @param noteHeader
   *          備考ヘッダ行
   * @param noteList
   *          備考リスト
   */
  public void registTodoList(
      String functionId,
      String messageId,
      String[] placeHolderArray,
      String note,
      List<String> noteList);

  /**
   * ロック有無確認。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 指定された処理IDの【排他制御】.ロックフラグの状態を確認する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param executeId
   *          処理ID
   * @return ロック有無（ロックあり：true、ロックなし：false）
   */
  public boolean existLock(String executeId);

  /**
   * 排他制御ロック。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 指定された処理IDの【排他制御】.ロックフラグをロックする。
   * 処理IDが存在しないか、すでにロック済の場合はロック失敗となる。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param executeId
   *          処理ID
   * @return 更新件数（ロック成功：1）
   */
  public int lock(String executeId);

  /**
   * 排他制御ロック解除。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 指定された処理IDの【排他制御】.ロックフラグを解除する。
   * 処理IDが存在しないか、すでにロック解除済の場合は解除失敗となる。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param executeId
   *          処理ID
   * @return 更新件数（ロック解除成功：1）
   */
  public int unlock(String executeId);

}
