package jp.co.unisys.enability.cis.business.sr.model;

import java.util.List;

import javax.net.ssl.SSLSocket;

/**
 * SSL認証ビジネスBean
 *
 * @author "Nihon Unisys, Ltd."
 */
public class SR_SSLauthenticationBusinessBean {

  /**
   * エリアコードを保有する。
   */
  private String areaCode;

  /**
   * pps区分を保有する。
   */
  private String ppsCat;

  /**
   * 接続先URLを保有する。
   */
  private String accessUrl;

  /**
   * ポート番号を保有する。
   */
  private Integer portNo;

  /**
   * ファイル名を保有する。
   */
  private String fileName;

  /**
   * コネクション情報を保有する。
   */
  private SSLSocket connectionInfo;

  /**
   * 受信コードを保有する。
   */
  private String receptionCode;

  /**
   * 受信可能ファイル一覧リストを保有する。
   */
  private List<String> receivableFileList;

  /**
   * リターンコードを保有する。
   */
  private String returnCode;

  /**
   * メッセージコードを保有する。
   */
  private String messageCode;

  /**
   * エリアコードのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * エリアコードを取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return エリアコード
   */
  public String getAreaCode() {
    return this.areaCode;
  }

  /**
   * エリアコードのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * エリアコードを設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param areaCode
   *          エリアコード
   */
  public void setAreaCode(String areaCode) {
    this.areaCode = areaCode;
  }

  /**
   * pps区分のgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * pps区分を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return pps区分
   */
  public String getPpsCat() {
    return this.ppsCat;
  }

  /**
   * pps区分のsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * pps区分を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param ppsCat
   *          pps区分
   */
  public void setPpsCat(String ppsCat) {
    this.ppsCat = ppsCat;
  }

  /**
   * 接続先URLのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 接続先URLを取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 接続先URL
   */
  public String getAccessUrl() {
    return this.accessUrl;
  }

  /**
   * 接続先URLのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 接続先URLを設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param accessUrl
   *          接続先URL
   */
  public void setAccessUrl(String accessUrl) {
    this.accessUrl = accessUrl;
  }

  /**
   * ポート番号のgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * ポート番号を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return ポート番号
   */
  public Integer getPortNo() {
    return this.portNo;
  }

  /**
   * ポート番号のsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * ポート番号を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param portNo
   *          ポート番号
   */
  public void setPortNo(Integer portNo) {
    this.portNo = portNo;
  }

  /**
   * ファイル名のgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * ファイル名を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return ファイル名
   */
  public String getFileName() {
    return this.fileName;
  }

  /**
   * ファイル名のsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * ファイル名を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param fileName
   *          ファイル名
   */
  public void setFileName(String fileName) {
    this.fileName = fileName;
  }

  /**
   * コネクション情報のgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * コネクション情報を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return コネクション情報
   */
  public SSLSocket getConnectionInfo() {
    return this.connectionInfo;
  }

  /**
   * コネクション情報のsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * コネクション情報を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param connectionInfo
   *          コネクション情報
   */
  public void setConnectionInfo(SSLSocket connectionInfo) {
    this.connectionInfo = connectionInfo;
  }

  /**
   * 受信コードのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 受信コードを取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 受信コード
   */
  public String getReceptionCode() {
    return this.receptionCode;
  }

  /**
   * 受信コードのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 受信コードを設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param receptionCode
   *          受信コード
   */
  public void setReceptionCode(String receptionCode) {
    this.receptionCode = receptionCode;
  }

  /**
   * 受信可能ファイル一覧リストのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 受信可能ファイル一覧リストを取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 受信可能ファイル一覧リスト
   */
  public List<String> getReceivableFileList() {
    return this.receivableFileList;
  }

  /**
   * 受信可能ファイル一覧リストのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 受信可能ファイル一覧リストを設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param receivableFileList
   *          受信可能ファイル一覧リスト
   */
  public void setReceivableFileList(List<String> receivableFileList) {
    this.receivableFileList = receivableFileList;
  }

  /**
   * リターンコードのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * リターンコードを取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return リターンコード
   */
  public String getReturnCode() {
    return this.returnCode;
  }

  /**
   * リターンコードのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * リターンコードを設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param returnCode
   *          リターンコード
   */
  public void setReturnCode(String returnCode) {
    this.returnCode = returnCode;
  }

  /**
   * メッセージコードのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * メッセージコードを取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return メッセージコード
   */
  public String getMessageCode() {
    return this.messageCode;
  }

  /**
   * メッセージコードのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * メッセージコードを設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param messageCode
   *          メッセージコード
   */
  public void setMessageCode(String messageCode) {
    this.messageCode = messageCode;
  }

}
