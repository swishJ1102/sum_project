package jp.co.unisys.enability.cis.business.kj.model;

import java.io.File;
import java.util.List;
import java.util.Map;

/**
 * 契約者情報CSVファイルチェックBusinessBean
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * 契約者情報ビジネス
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class CsvFileCheckContractorBusinessBean {

  /**
   * アップロードファイルを保有する。
   */
  private File uploadFile;

  /**
   * アップロードファイル名を保有する。
   */
  private String uploadFileName;

  /**
   * エラーリストを保有する。
   */
  private List<String> errorList;

  /**
   * 登録オブジェクトリストを保有する。
   */
  private List<Map<Integer, String>> registList;

  /**
   * 更新オブジェクトリストを保有する。
   */
  private List<Map<Integer, String>> updateList;

  /**
   * アップロードファイルのgetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * アップロードファイルを取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return アップロードファイル
   */
  public File getUploadFile() {
    return uploadFile;
  }

  /**
   * アップロードファイルのsetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * アップロードファイルを設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param uploadFile
   *          アップロードファイル
   */
  public void setUploadFile(File uploadFile) {
    this.uploadFile = uploadFile;
  }

  /**
   * アップロードファイル名のgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * アップロードファイル名を取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return アップロードファイル名
   */
  public String getUploadFileName() {
    return this.uploadFileName;
  }

  /**
   * アップロードファイル名のsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * アップロードファイル名を設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param uploadFileName
   *          アップロードファイル名
   */
  public void setUploadFileName(String uploadFileName) {
    this.uploadFileName = uploadFileName;
  }

  /**
   * エラーリストのgetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * エラーリストを取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return エラーリスト
   */
  public List<String> getErrorList() {
    return errorList;
  }

  /**
   * エラーリストのsetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * エラーリストを設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param errorList
   *          エラーリスト
   */
  public void setErrorList(List<String> errorList) {
    this.errorList = errorList;
  }

  /**
   * 登録オブジェクトリストのgetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 登録オブジェクトリストを取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 登録オブジェクトリスト
   */
  public List<Map<Integer, String>> getRegistList() {
    return registList;
  }

  /**
   * 登録オブジェクトリストのsetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 登録オブジェクトリストを設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param registList
   *          登録オブジェクトリスト
   */
  public void setRegistList(List<Map<Integer, String>> registList) {
    this.registList = registList;
  }

  /**
   * 更新オブジェクトリストのgetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 更新オブジェクトリストを取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 更新オブジェクトリスト
   */
  public List<Map<Integer, String>> getUpdateList() {
    return updateList;
  }

  /**
   * 更新オブジェクトリストのsetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 更新オブジェクトリストを設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param updateList
   *          更新オブジェクトリスト
   */
  public void setUpdateList(List<Map<Integer, String>> updateList) {
    this.updateList = updateList;
  }
}
