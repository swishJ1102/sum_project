package jp.co.unisys.enability.cis.business.kj;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang3.time.DateUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.util.CollectionUtils;

import jp.co.unisys.enability.cis.business.kj.model.DeleteReserveContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.InquiryContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.InquiryReserveContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.RegistReserveContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.UpdateReserveContractBusinessBean;
import jp.co.unisys.enability.cis.common.Exception.BusinessLogicException;
import jp.co.unisys.enability.cis.common.util.KJ_CommonUtil;
import jp.co.unisys.enability.cis.common.util.ThreadContext;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISKJConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISReturnCodeConstants;
import jp.co.unisys.enability.cis.entity.common.ReserveContractHist;
import jp.co.unisys.enability.cis.entity.common.ReserveContractHistExample;
import jp.co.unisys.enability.cis.entity.kj.KJ_InquiryContractInformationEntityBean;
import jp.co.unisys.enability.cis.entity.kj.KJ_InquiryReserveContractInformationEntityBean;
import jp.co.unisys.enability.cis.mapper.common.ReserveContractHistMapper;
import jp.co.unisys.enability.cis.mapper.kj.ReserveContractInfomationCommonMapper;
import jp.co.unisys.enability.cis.mapper.rk.FixChargeResultInformationCommonMapper;

/**
 * 予備契約情報ビジネス
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.kj.KJ_ReserveContractInformationBusiness
 *
 */
public class KJ_ReserveContractInformationBusinessImpl implements
    KJ_ReserveContractInformationBusiness {

  /**
   * 契約情報ビジネス(DI)
   */
  private KJ_ContractInformationBusiness kjContractInformationBusiness;

  /**
   * 確定料金実績情報共通マッパー(DI)
   */
  private FixChargeResultInformationCommonMapper fixChargeResultInformationCommonMapper;

  /**
   * 予備契約情報共通マッパー(DI)
   */
  private ReserveContractInfomationCommonMapper reserveContractInfomationCommonMapper;

  /**
   * 予備契約履歴マッパー(DI)
   */
  private ReserveContractHistMapper reserveContractHistMapper;

  /**
   * メッセージソース(DI)
   */
  private MessageSource messageSource;

  /**
   * ログマネジャー
   */
  private static Logger logger = LogManager.getLogger();

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.kj.KJ_ReserveContractInformationBusiness#
   * inquiry
   * (jp.co.unisys.enability.cis.business.kj.model.InquiryReserveContractBusinessBean)
   */
  @Override
  public InquiryReserveContractBusinessBean inquiry(
      InquiryReserveContractBusinessBean inquiryReserveContractBusinessBean) {

    // DataAccessException用エラーメッセージ
    String dataAccessExceptionEMsg = null;

    try {
      // DataAccessException用エラーメッセージ設定
      dataAccessExceptionEMsg = messageSource.getMessage(KJ_CommonUtil.getMessageId(
          ECISReturnCodeConstants.RETURN_CODE_G017), new String[] {}, Locale.getDefault());

      // 条件Map
      Map<String, Object> conditionsMap = new HashMap<String, Object>();

      // 照会パターンの設定
      // 《予備契約情報照会BusinessBean》.契約IDがNULLではない、
      // かつ 《予備契約情報照会BusinessBean》.予備契約種別がNULLではない、
      // かつ 《予備契約情報照会BusinessBean》.照会対象日付がNULLではない場合
      if (inquiryReserveContractBusinessBean.getContractId() != null
          && inquiryReserveContractBusinessBean.getReserveContractClass() != null
          && inquiryReserveContractBusinessBean.getInqCoveredDate() != null) {

        // 条件Map.契約ID
        conditionsMap.put("id", inquiryReserveContractBusinessBean.getContractId());
        // 条件Map.予備契約種別
        conditionsMap.put("class", inquiryReserveContractBusinessBean.getReserveContractClass());
        // 条件Map.日付
        conditionsMap.put("date", inquiryReserveContractBusinessBean.getInqCoveredDate());
        // 条件Map.照会パターン
        conditionsMap.put("selectPatten", ECISKJConstants.INQUIRY_PATTERN_1);

        // 《予備契約情報照会BusinessBean》.契約IDがNULLではない、
        // かつ 《予備契約情報照会BusinessBean》.予備契約種別がNULL、
        // かつ 《予備契約情報照会BusinessBean》.照会対象日付がNULLではない場合
      } else if (inquiryReserveContractBusinessBean.getContractId() != null
          && inquiryReserveContractBusinessBean.getReserveContractClass() == null
          && inquiryReserveContractBusinessBean.getInqCoveredDate() != null) {

        // 条件Map.契約ID
        conditionsMap.put("id", inquiryReserveContractBusinessBean.getContractId());
        // 条件Map.予備契約種別
        conditionsMap.put("class", null);
        // 条件Map.日付
        conditionsMap.put("date", inquiryReserveContractBusinessBean.getInqCoveredDate());
        // 条件Map.照会パターン
        conditionsMap.put("selectPatten", ECISKJConstants.INQUIRY_PATTERN_2);

        // 《予備契約情報照会BusinessBean》.契約IDがNULLではない、
        // かつ 《予備契約情報照会BusinessBean》.予備契約種別がNULL、
        // かつ 《予備契約情報照会BusinessBean》.照会対象日付がNULLの場合
      } else if (inquiryReserveContractBusinessBean.getContractId() != null
          && inquiryReserveContractBusinessBean.getReserveContractClass() == null
          && inquiryReserveContractBusinessBean.getInqCoveredDate() == null) {

        // 条件Map.契約ID
        conditionsMap.put("id", inquiryReserveContractBusinessBean.getContractId());
        // 条件Map.予備契約種別
        conditionsMap.put("class", null);
        // 条件Map.日付
        conditionsMap.put("date", null);
        // 条件Map.照会パターン
        conditionsMap.put("selectPatten", ECISKJConstants.INQUIRY_PATTERN_3);

        // パターン外の場合
      } else {

        inquiryReserveContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P001);
        inquiryReserveContractBusinessBean.setMessage(
            messageSource.getMessage(KJ_CommonUtil.getMessageId(
                ECISReturnCodeConstants.RETURN_CODE_P001), new String[] {}, Locale.getDefault()));

        return inquiryReserveContractBusinessBean;
      }

      // 《予備契約履歴情報共通Mapper》.予備契約履歴情報取得を呼び出す。
      // 照会結果設定
      List<KJ_InquiryReserveContractInformationEntityBean> inquiryReserveContractInformationEntityBeanList = reserveContractInfomationCommonMapper
          .selectReserveContract(conditionsMap);

      inquiryReserveContractBusinessBean.setReserveContractList(inquiryReserveContractInformationEntityBeanList);

      // 正常終了
      inquiryReserveContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);

    } catch (DataAccessException e) {

      // データアクセス例外
      logger.error(messageSource.getMessage("error.E1129", null, Locale.getDefault()), e);

      inquiryReserveContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      inquiryReserveContractBusinessBean.setMessage(dataAccessExceptionEMsg);

    } catch (NoSuchMessageException e) {

      // メッセージ検索例外
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, e);

      inquiryReserveContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      inquiryReserveContractBusinessBean.setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
    }

    return inquiryReserveContractBusinessBean;
  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.kj.KJ_ReserveContractInformationBusiness#
   * inquiry
   * (jp.co.unisys.enability.cis.business.kj.model.RegistReserveContractBusinessBean)
   */
  @Override
  public RegistReserveContractBusinessBean regist(
      RegistReserveContractBusinessBean registReserveContractBusinessBean) {

    // DataAccessException用エラーメッセージ
    String dataAccessExceptionEMsg = null;

    // BusinessLogicException用エラーメッセージ
    String businessLogicExceptionEMsg = null;

    // DuplicateKeyException用エラーメッセージ
    String duplicateKeyExceptionEmsg = null;

    // 契約情報ビジネスBean
    InquiryContractBusinessBean inquiryContractBusinessBean;

    // 契約情報EntityBean
    KJ_InquiryContractInformationEntityBean inquiryContractInformationEntityBean;

    // 予備契約履歴Entity
    ReserveContractHist reserveContractHist;

    // 条件Map
    Map<String, Object> conditionsMap;

    // 予備契約終了日
    Date reserveContractEndDate = null;

    try {

      // DuplicateKeyException用エラーメッセージ設定
      duplicateKeyExceptionEmsg = messageSource.getMessage(KJ_CommonUtil.getMessageId(
          ECISReturnCodeConstants.RETURN_CODE_D023), new String[] {}, Locale.getDefault());

      // BusinessLogicException用エラーメッセージ設定
      businessLogicExceptionEMsg = messageSource.getMessage(KJ_CommonUtil.getMessageId(
          ECISReturnCodeConstants.RETURN_CODE_G017), new String[] {}, Locale.getDefault());

      // DataAccessException用エラーメッセージ設定
      dataAccessExceptionEMsg = messageSource.getMessage(KJ_CommonUtil.getMessageId(
          ECISReturnCodeConstants.RETURN_CODE_G017), new String[] {}, Locale.getDefault());

      // 親契約情報存在チェック
      // 《契約情報照会BusinessBean》を生成する。
      inquiryContractBusinessBean = new InquiryContractBusinessBean();

      // 《契約情報照会BusinessBean》.契約IDに《予備契約情報登録BusinessBean》.契約IDを設定する。
      inquiryContractBusinessBean.setContractId(
          registReserveContractBusinessBean.getContractId());

      // 《契約情報照会BusinessBean》.照会対象日付に《予備契約情報登録BusinessBean》.予備契約開始日を設定する。
      inquiryContractBusinessBean.setInqCoveredDate(
          registReserveContractBusinessBean.getReserveContractSd());

      // 《契約情報Business》.契約情報照会を呼び出す。
      inquiryContractBusinessBean = kjContractInformationBusiness.inquiry(inquiryContractBusinessBean);

      // 《契約情報照会BusinessBean》.リターンコードが“0000”以外の場合
      if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(inquiryContractBusinessBean.getReturnCode())) {

        throw new BusinessLogicException(
            messageSource.getMessage("error.E1285", new String[] {}, Locale.getDefault()), false);
      }

      // 《契約情報照会EntityBean》リストの返却値が0件の場合
      if (CollectionUtils.isEmpty(inquiryContractBusinessBean.getContractInformationList())) {

        registReserveContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D029);
        registReserveContractBusinessBean.setMessage(
            messageSource.getMessage(KJ_CommonUtil.getMessageId(
                ECISReturnCodeConstants.RETURN_CODE_D029), new String[] {}, Locale.getDefault()));

        return registReserveContractBusinessBean;
      }

      // 《契約情報照会BusinessBean》より《契約情報照会EntityBean》リストの1番目を取得する。
      inquiryContractInformationEntityBean = inquiryContractBusinessBean.getContractInformationList().get(0);

      // 契約終了状態判定のため、算定期間チェックを行う。
      conditionsMap = new HashMap<String, Object>();

      // 契約ID
      conditionsMap.put("contractId", inquiryContractInformationEntityBean.getContractId());
      // 対象日
      conditionsMap.put("coveredDate", inquiryContractInformationEntityBean.getContractEndDate());
      // フラグ
      conditionsMap.put("flg", ECISKJConstants.INQUIRY_FIX_CHANGE_RESULT_INFOEMATION_FLG_TWO);

      // 確定料金実績件数取得の結果が1件以上の場合
      if (fixChargeResultInformationCommonMapper.countByFixChargeResult(conditionsMap) >= 1) {

        // コード(D033)を返却する。
        registReserveContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D033);
        registReserveContractBusinessBean.setMessage(
            messageSource.getMessage(KJ_CommonUtil.getMessageId(
                ECISReturnCodeConstants.RETURN_CODE_D033), new String[] {}, Locale.getDefault()));

        return registReserveContractBusinessBean;
      }

      // 日付相関チェック
      // 《予備契約情報登録BusinessBean》.予備契約終了日を取得する。
      reserveContractEndDate = registReserveContractBusinessBean.getReserveContractEd();

      // 《予備契約情報登録BusinessBean》.予備契約終了日がnullの場合
      if (reserveContractEndDate == null) {

        // 予備契約終了日に《契約情報照会BusinessBean》.契約終了日を設定する。
        reserveContractEndDate = inquiryContractInformationEntityBean.getContractEndDate();

        // 戻り値の予備契約情報登録BusinessBeanの予備契約終了日に取得した契約終了日を設定する。
        registReserveContractBusinessBean.setReserveContractEd(reserveContractEndDate);
      }

      // 《契約情報照会BusinessBean》.契約開始日 ＞《予備契約情報登録BusinessBean》.予備契約開始日、または、
      // 《契約情報照会BusinessBean》.契約終了日 ＜《予備契約情報登録BusinessBean》.予備契約終了日、または、
      // 《予備契約情報登録BusinessBean》.予備契約開始日 ＞《予備契約情報登録BusinessBean》.予備契約終了日の場合
      if (DateUtils.truncatedCompareTo(
          inquiryContractInformationEntityBean.getContractStartDate(),
          registReserveContractBusinessBean.getReserveContractSd(),
          Calendar.DAY_OF_MONTH) > 0
          || DateUtils.truncatedCompareTo(
              inquiryContractInformationEntityBean.getContractEndDate(),
              reserveContractEndDate,
              Calendar.DAY_OF_MONTH) < 0
          || DateUtils.truncatedCompareTo(
              registReserveContractBusinessBean.getReserveContractSd(),
              reserveContractEndDate,
              Calendar.DAY_OF_MONTH) > 0) {

        // コード(G055)を返却する。
        registReserveContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G055);
        registReserveContractBusinessBean.setMessage(
            messageSource.getMessage(KJ_CommonUtil.getMessageId(
                ECISReturnCodeConstants.RETURN_CODE_G055), new String[] {}, Locale.getDefault()));

        return registReserveContractBusinessBean;
      }

      // 予備契約情報期間重複チェック
      conditionsMap = new HashMap<String, Object>();

      // 条件Map.契約ID
      conditionsMap.put("id", registReserveContractBusinessBean.getContractId());
      // 条件Map.予備契約種別
      conditionsMap.put("class", registReserveContractBusinessBean.getReserveContractClass());
      // 条件Map.予備契約開始日
      conditionsMap.put("startDate", registReserveContractBusinessBean.getReserveContractSd());
      // 条件Map.予備契約終了日
      conditionsMap.put("endDate", reserveContractEndDate);
      // 条件Map.予備契約開始日除外フラグ
      conditionsMap.put("flag", ECISConstants.FLG_OFF);

      // 《予備契約履歴情報共通Mapper》.予備契約情報期間件数取得の件数が1件以上の場合
      if (reserveContractInfomationCommonMapper.countReserveContractPeriod(conditionsMap) >= 1) {

        // コード(G056)を返却する。
        registReserveContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G056);
        registReserveContractBusinessBean.setMessage(
            messageSource.getMessage(KJ_CommonUtil.getMessageId(
                ECISReturnCodeConstants.RETURN_CODE_G056), new String[] {}, Locale.getDefault()));

        return registReserveContractBusinessBean;
      }

      // 追加可否チェック
      conditionsMap = new HashMap<String, Object>();

      // 条件Map.契約ID
      conditionsMap.put("contractId", registReserveContractBusinessBean.getContractId());
      // 条件Map.対象日
      conditionsMap.put("coveredDate", registReserveContractBusinessBean.getReserveContractSd());
      // 条件Map.フラグ
      conditionsMap.put("flg", ECISKJConstants.INQUIRY_FIX_CHANGE_RESULT_INFOEMATION_FLG_OFF);

      // 《確定料金実績情報共通Mapper》.確定料金実績件数取得の件数が1件以上の場合
      if (fixChargeResultInformationCommonMapper.countByFixChargeResult(conditionsMap) >= 1) {

        // コード(D030)を返却する。
        registReserveContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D030);
        registReserveContractBusinessBean.setMessage(
            messageSource.getMessage(KJ_CommonUtil.getMessageId(
                ECISReturnCodeConstants.RETURN_CODE_D030), new String[] {}, Locale.getDefault()));

        return registReserveContractBusinessBean;
      }

      // 予備契約履歴情報登録
      Timestamp systemDate = new Timestamp(System.currentTimeMillis());

      // 予備契約履歴Entityを生成する。
      reserveContractHist = new ReserveContractHist();

      // 契約ID
      reserveContractHist.setContractId(registReserveContractBusinessBean.getContractId());

      // 予備契約種別
      reserveContractHist.setReserveContractClass(registReserveContractBusinessBean.getReserveContractClass());

      // 予備契約開始日
      reserveContractHist.setReserveContractSd(registReserveContractBusinessBean.getReserveContractSd());

      // 予備契約終了日
      reserveContractHist.setReserveContractEd(reserveContractEndDate);

      // 容量
      reserveContractHist.setCapacity(registReserveContractBusinessBean.getCapacity());

      // 更新回数
      reserveContractHist.setUpdateCount(0);

      // 作成日時
      reserveContractHist.setCreateTime(systemDate);

      // オンライン更新日時
      reserveContractHist.setOnlineUpdateTime(systemDate);

      // オンライン更新ユーザID
      reserveContractHist.setOnlineUpdateUserId(
          ThreadContext.getRequestThreadContext().get(ECISConstants.USER_ID_KEY).toString());

      // 更新日時
      reserveContractHist.setUpdateTime(systemDate);

      // 更新モジュールコード
      reserveContractHist.setUpdateModuleCode(
          ThreadContext.getRequestThreadContext().get(ECISConstants.CLASS_NAME_KEY).toString());

      // 《予備契約履歴共通Dao》.追加
      reserveContractHistMapper.insert(reserveContractHist);

      // 正常終了
      registReserveContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);

    } catch (DuplicateKeyException e) {

      // 重複例外
      logger.error(messageSource.getMessage("error.E1129", null, Locale.getDefault()), e);

      registReserveContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D023);
      registReserveContractBusinessBean.setMessage(duplicateKeyExceptionEmsg);

    } catch (BusinessLogicException e) {

      // 業務例外
      logger.error(messageSource.getMessage("error.E1129", null, Locale.getDefault()), e);

      registReserveContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      registReserveContractBusinessBean.setMessage(businessLogicExceptionEMsg);

    } catch (DataAccessException e) {

      // データアクセス例外
      logger.error(messageSource.getMessage("error.E1129", null, Locale.getDefault()), e);

      registReserveContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      registReserveContractBusinessBean.setMessage(dataAccessExceptionEMsg);

    } catch (NoSuchMessageException e) {

      // メッセージ検索例外
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, e);

      registReserveContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      registReserveContractBusinessBean.setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
    }

    return registReserveContractBusinessBean;
  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.kj.KJ_ReserveContractInformationBusiness#
   * inquiry
   * (jp.co.unisys.enability.cis.business.kj.model.UpdateReserveContractBusinessBean)
   */
  @Override
  public UpdateReserveContractBusinessBean update(
      UpdateReserveContractBusinessBean updateReserveContractBusinessBean) {

    // DataAccessException用エラーメッセージ
    String dataAccessExceptionEMsg = null;

    // BusinessLogicException用エラーメッセージ
    String businessLogicExceptionEMsg = null;

    // 契約情報ビジネスBean
    InquiryContractBusinessBean inquiryContractBusinessBean;

    // 契約情報EntityBean
    KJ_InquiryContractInformationEntityBean inquiryContractInformationEntityBean;

    // 予備契約情報ビジネスBean
    InquiryReserveContractBusinessBean inquiryReserveContractBusinessBean;

    // 予備契約情報照会EntityBean
    KJ_InquiryReserveContractInformationEntityBean inquiryReserveContractInformationEntityBean;

    // 予備契約履歴Entity
    ReserveContractHist reserveContractHist;

    // 予備契約履歴EntityExample
    ReserveContractHistExample reserveContractHistExample;

    // 条件Map
    Map<String, Object> conditionsMap;

    // 予備契約終了日
    Date reserveContractEndDate = null;

    try {

      // BusinessLogicException用エラーメッセージ設定
      businessLogicExceptionEMsg = messageSource.getMessage(KJ_CommonUtil.getMessageId(
          ECISReturnCodeConstants.RETURN_CODE_G017), new String[] {}, Locale.getDefault());

      // DataAccessException用エラーメッセージ設定
      dataAccessExceptionEMsg = messageSource.getMessage(KJ_CommonUtil.getMessageId(
          ECISReturnCodeConstants.RETURN_CODE_G017), new String[] {}, Locale.getDefault());

      // 予備契約情報の存在チェック
      // 《予備契約情報照会BusinessBean》を生成する。
      inquiryReserveContractBusinessBean = new InquiryReserveContractBusinessBean();

      // 契約ID
      inquiryReserveContractBusinessBean.setContractId(
          updateReserveContractBusinessBean.getContractId());

      // 予備契約種別
      inquiryReserveContractBusinessBean.setReserveContractClass(
          updateReserveContractBusinessBean.getReserveContractClass());

      // 照会対象日付
      inquiryReserveContractBusinessBean.setInqCoveredDate(
          updateReserveContractBusinessBean.getReserveContractSd());

      // 予備契約情報照会を呼び出す。
      inquiryReserveContractBusinessBean = inquiry(inquiryReserveContractBusinessBean);

      // 《予備契約情報照会BusinessBean》.リターンコードが“0000”以外の場合
      if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(
          inquiryReserveContractBusinessBean.getReturnCode())) {

        // 業務例外をスローする。
        throw new BusinessLogicException(
            messageSource.getMessage("error.E1735", new String[] {}, Locale.getDefault()), false);
      }

      // 《予備契約情報照会BusinessBean》.予備契約情報リストが0件の場合
      if (CollectionUtils.isEmpty(inquiryReserveContractBusinessBean.getReserveContractList())) {

        // コード(P101)を返却する。
        updateReserveContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P101);
        updateReserveContractBusinessBean.setMessage(
            messageSource.getMessage(KJ_CommonUtil.getMessageId(
                ECISReturnCodeConstants.RETURN_CODE_P101), new String[] {}, Locale.getDefault()));

        return updateReserveContractBusinessBean;
      }

      // 《予備契約情報照会BusinessBean》より《予備契約情報照会EntityBean》リストの1番目を取得する。
      inquiryReserveContractInformationEntityBean = inquiryReserveContractBusinessBean.getReserveContractList()
          .get(0);

      // 親契約情報存在チェック
      // 《契約情報照会BusinessBean》を生成する。
      inquiryContractBusinessBean = new InquiryContractBusinessBean();

      // 《契約情報照会BusinessBean》.契約IDに《予備契約情報照会EntityBean》.契約IDを設定する。
      inquiryContractBusinessBean.setContractId(
          inquiryReserveContractInformationEntityBean.getContractId());

      // 《契約情報照会BusinessBean》.照会対象日付に《予備契約情報照会EntityBean》.予備契約開始日を設定する。
      inquiryContractBusinessBean.setInqCoveredDate(
          inquiryReserveContractInformationEntityBean.getReserveContractSd());

      // 《契約情報Business》.契約情報照会を呼び出す。
      inquiryContractBusinessBean = kjContractInformationBusiness.inquiry(inquiryContractBusinessBean);

      // 《契約情報照会BusinessBean》.リターンコードが“0000”以外の場合
      if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(inquiryContractBusinessBean.getReturnCode())) {

        throw new BusinessLogicException(
            messageSource.getMessage("error.E1285", new String[] {}, Locale.getDefault()), false);
      }

      // 《契約情報照会EntityBean》リストの返却値が0件の場合
      if (CollectionUtils.isEmpty(inquiryContractBusinessBean.getContractInformationList())) {

        updateReserveContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D029);
        updateReserveContractBusinessBean.setMessage(
            messageSource.getMessage(KJ_CommonUtil.getMessageId(
                ECISReturnCodeConstants.RETURN_CODE_D029), new String[] {}, Locale.getDefault()));

        return updateReserveContractBusinessBean;
      }

      // 《契約情報照会BusinessBean》より《契約情報照会EntityBean》リストの1番目を取得する。
      inquiryContractInformationEntityBean = inquiryContractBusinessBean.getContractInformationList().get(0);

      // 契約終了状態判定のため、算定期間チェックを行う。
      conditionsMap = new HashMap<String, Object>();

      // 契約ID
      conditionsMap.put("contractId", inquiryContractInformationEntityBean.getContractId());
      // 対象日
      conditionsMap.put("coveredDate", inquiryContractInformationEntityBean.getContractEndDate());
      // フラグ
      conditionsMap.put("flg", ECISKJConstants.INQUIRY_FIX_CHANGE_RESULT_INFOEMATION_FLG_TWO);

      // 確定料金実績件数取得の結果が1件以上の場合
      if (fixChargeResultInformationCommonMapper.countByFixChargeResult(conditionsMap) >= 1) {

        // コード(D033)を返却する。
        updateReserveContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D033);
        updateReserveContractBusinessBean.setMessage(
            messageSource.getMessage(KJ_CommonUtil.getMessageId(
                ECISReturnCodeConstants.RETURN_CODE_D033), new String[] {}, Locale.getDefault()));

        return updateReserveContractBusinessBean;
      }

      // 予備契約算定期間チェック
      conditionsMap = new HashMap<String, Object>();

      // 契約ID
      conditionsMap.put("contractId", inquiryReserveContractInformationEntityBean.getContractId());
      // 対象日
      conditionsMap.put("coveredDate", inquiryReserveContractInformationEntityBean.getReserveContractEd());
      // フラグ
      conditionsMap.put("flg", ECISKJConstants.INQUIRY_FIX_CHANGE_RESULT_INFOEMATION_FLG_OFF);

      // 確定料金実績件数取得の結果が1件以上の場合
      if (fixChargeResultInformationCommonMapper.countByFixChargeResult(conditionsMap) >= 1) {

        // コード(D031)を返却する。
        updateReserveContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D031);
        updateReserveContractBusinessBean.setMessage(
            messageSource.getMessage(KJ_CommonUtil.getMessageId(
                ECISReturnCodeConstants.RETURN_CODE_D031), new String[] {}, Locale.getDefault()));

        return updateReserveContractBusinessBean;
      }

      // 日付相関チェック
      // 《予備契約情報更新BusinessBean》.予備契約終了日を取得する。
      reserveContractEndDate = updateReserveContractBusinessBean.getReserveContractEd();

      // 《予備契約情報更新BusinessBean》.予備契約終了日がnullの場合
      if (reserveContractEndDate == null) {

        // 予備契約終了日に《契約情報照会BusinessBean》.契約終了日を設定する。
        reserveContractEndDate = inquiryContractInformationEntityBean.getContractEndDate();

        // 戻り値の予備契約情報更新BusinessBeanの予備契約終了日に取得した契約終了日を設定する。
        updateReserveContractBusinessBean.setReserveContractEd(reserveContractEndDate);
      }

      // 主契約との期間チェック
      // 《契約情報照会EntityBean》.契約終了日 ＜《予備契約情報更新BusinessBean》.予備契約終了日、または、
      // 《予備契約情報更新BusinessBean》.予備契約開始日 ＞《契約情報照会EntityBean》.予備契約終了日、または、
      // 《予備契約情報更新BusinessBean》.予備契約開始日 ＞《予備契約情報更新BusinessBean》.予備契約終了日の場合
      if (DateUtils.truncatedCompareTo(
          inquiryContractInformationEntityBean.getContractEndDate(),
          reserveContractEndDate,
          Calendar.DAY_OF_MONTH) < 0
          || DateUtils.truncatedCompareTo(
              updateReserveContractBusinessBean.getReserveContractSd(),
              inquiryContractInformationEntityBean.getContractEndDate(),
              Calendar.DAY_OF_MONTH) > 0
          || DateUtils.truncatedCompareTo(
              updateReserveContractBusinessBean.getReserveContractSd(),
              reserveContractEndDate, Calendar.DAY_OF_MONTH) > 0) {

        // コード(G055)を返却する。
        updateReserveContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G055);
        updateReserveContractBusinessBean.setMessage(
            messageSource.getMessage(KJ_CommonUtil.getMessageId(
                ECISReturnCodeConstants.RETURN_CODE_G055), new String[] {}, Locale.getDefault()));

        return updateReserveContractBusinessBean;
      }

      // 予備契約情報期間重複チェック
      conditionsMap = new HashMap<String, Object>();

      // 契約ID
      conditionsMap.put("id", updateReserveContractBusinessBean.getContractId());
      // 予備契約種別
      conditionsMap.put("class", updateReserveContractBusinessBean.getReserveContractClass());
      // 予備契約開始日
      conditionsMap.put("startDate", updateReserveContractBusinessBean.getReserveContractSd());
      // 予備契約終了日
      conditionsMap.put("endDate", reserveContractEndDate);
      // 予備契約開始日除外フラグ
      conditionsMap.put("flag", ECISConstants.FLG_ON);

      // 《予備契約履歴情報共通Mapper》.予備契約情報期間件数取得の件数が1件以上の場合
      if (reserveContractInfomationCommonMapper.countReserveContractPeriod(conditionsMap) >= 1) {

        // コード(G056)を返却する。
        updateReserveContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G056);
        updateReserveContractBusinessBean.setMessage(
            messageSource.getMessage(KJ_CommonUtil.getMessageId(
                ECISReturnCodeConstants.RETURN_CODE_G056), new String[] {}, Locale.getDefault()));

        return updateReserveContractBusinessBean;
      }

      // 更新可否チェック
      conditionsMap = new HashMap<String, Object>();

      // 契約ID
      conditionsMap.put("contractId", updateReserveContractBusinessBean.getContractId());
      // 対象日
      conditionsMap.put("coveredDate", updateReserveContractBusinessBean.getReserveContractEd());
      // フラグ
      conditionsMap.put("flg", ECISKJConstants.INQUIRY_FIX_CHANGE_RESULT_INFOEMATION_FLG_THREE);

      // 確定料金実績件数取得の結果が1件以上の場合
      if (fixChargeResultInformationCommonMapper.countByFixChargeResult(conditionsMap) >= 1) {

        // コード(D031)を返却する。
        updateReserveContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D031);
        updateReserveContractBusinessBean.setMessage(
            messageSource.getMessage(KJ_CommonUtil.getMessageId(
                ECISReturnCodeConstants.RETURN_CODE_D031), new String[] {}, Locale.getDefault()));

        return updateReserveContractBusinessBean;
      }

      // 予備契約履歴情報更新
      Timestamp systemDate = new Timestamp(System.currentTimeMillis());

      // 予備契約履歴Entityを生成する。
      reserveContractHist = new ReserveContractHist();

      // 予備契約終了日
      reserveContractHist.setReserveContractEd(reserveContractEndDate);

      // 容量
      reserveContractHist.setCapacity(updateReserveContractBusinessBean.getReserveContractCapacity());

      // 契約ID
      reserveContractHist.setContractId(updateReserveContractBusinessBean.getContractId());

      // 予備契約種別
      reserveContractHist.setReserveContractClass(updateReserveContractBusinessBean.getReserveContractClass());

      // 予備契約開始日
      reserveContractHist.setReserveContractSd(updateReserveContractBusinessBean.getReserveContractSd());

      // 更新回数
      reserveContractHist.setUpdateCount(updateReserveContractBusinessBean.getUpdateCount() + 1);

      // オンライン更新日時
      reserveContractHist.setOnlineUpdateTime(systemDate);

      // オンライン更新ユーザID
      reserveContractHist.setOnlineUpdateUserId(
          ThreadContext.getRequestThreadContext().get(ECISConstants.USER_ID_KEY).toString());

      // 更新日時
      reserveContractHist.setUpdateTime(systemDate);

      // 更新モジュールコード
      reserveContractHist.setUpdateModuleCode(
          ThreadContext.getRequestThreadContext().get(ECISConstants.CLASS_NAME_KEY).toString());

      // 予備契約履歴EntityExampleを生成する。
      reserveContractHistExample = new ReserveContractHistExample();

      // 更新条件の設定
      reserveContractHistExample
          .createCriteria()
          .andContractIdEqualTo(
              updateReserveContractBusinessBean.getContractId())
          .andReserveContractClassEqualTo(
              updateReserveContractBusinessBean.getReserveContractClass())
          .andReserveContractSdEqualTo(
              updateReserveContractBusinessBean.getReserveContractSd())
          .andUpdateCountEqualTo(
              updateReserveContractBusinessBean.getUpdateCount());

      // 更新情報（作成日時）の再取得
      List<ReserveContractHist> resultList = reserveContractHistMapper
          .selectByExample(reserveContractHistExample);
      if (resultList.size() > 0) {
        ReserveContractHist updateReserveContract = resultList.get(0);
        // 作成日時
        reserveContractHist.setCreateTime(updateReserveContract.getCreateTime());
      }

      // 《予備契約履歴Mapper》.選択項目更新呼び出しの返却件数が0件の場合
      if (reserveContractHistMapper.updateByExample(
          reserveContractHist, reserveContractHistExample) == 0) {

        // コード(H001)を返却する。
        updateReserveContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_H001);
        updateReserveContractBusinessBean.setMessage(
            messageSource.getMessage(KJ_CommonUtil.getMessageId(
                ECISReturnCodeConstants.RETURN_CODE_H001), new String[] {}, Locale.getDefault()));

        return updateReserveContractBusinessBean;
      }

      // 正常終了
      updateReserveContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);

    } catch (BusinessLogicException e) {

      // 業務例外
      logger.error(messageSource.getMessage("error.E1129", null, Locale.getDefault()), e);

      updateReserveContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      updateReserveContractBusinessBean.setMessage(businessLogicExceptionEMsg);

    } catch (DataAccessException e) {

      // データアクセス例外
      logger.error(messageSource.getMessage("error.E1129", null, Locale.getDefault()), e);

      updateReserveContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      updateReserveContractBusinessBean.setMessage(dataAccessExceptionEMsg);

    } catch (NoSuchMessageException e) {

      // メッセージ検索例外
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, e);

      updateReserveContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      updateReserveContractBusinessBean.setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
    }

    return updateReserveContractBusinessBean;
  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.kj.KJ_ReserveContractInformationBusiness#
   * inquiry
   * (jp.co.unisys.enability.cis.business.kj.model.DeleteReserveContractBusinessBean)
   */
  @Override
  public DeleteReserveContractBusinessBean delete(
      DeleteReserveContractBusinessBean deleteReserveContractBusinessBean) {

    // DataAccessException用エラーメッセージ
    String dataAccessExceptionEMsg = null;

    // BusinessLogicException用エラーメッセージ
    String businessLogicExceptionEMsg = null;

    // 契約情報ビジネスBean
    InquiryContractBusinessBean inquiryContractBusinessBean;

    // 契約情報EntityBean
    KJ_InquiryContractInformationEntityBean inquiryContractInformationEntityBean;

    // 予備契約情報ビジネスBean
    InquiryReserveContractBusinessBean inquiryReserveContractBusinessBean;

    // 予備契約情報照会EntityBean
    KJ_InquiryReserveContractInformationEntityBean inquiryReserveContractInformationEntityBean;

    // 予備契約履歴EntityExample
    ReserveContractHistExample reserveContractHistExample;

    // 条件Map
    Map<String, Object> conditionsMap;

    try {

      // BusinessLogicException用エラーメッセージ設定
      businessLogicExceptionEMsg = messageSource.getMessage(KJ_CommonUtil.getMessageId(
          ECISReturnCodeConstants.RETURN_CODE_G017), new String[] {}, Locale.getDefault());

      // DataAccessException用エラーメッセージ設定
      dataAccessExceptionEMsg = messageSource.getMessage(KJ_CommonUtil.getMessageId(
          ECISReturnCodeConstants.RETURN_CODE_G017), new String[] {}, Locale.getDefault());

      // 予備契約情報の存在チェック
      // 《予備契約情報照会BusinessBean》を生成する。
      inquiryReserveContractBusinessBean = new InquiryReserveContractBusinessBean();

      // 契約ID
      inquiryReserveContractBusinessBean.setContractId(
          deleteReserveContractBusinessBean.getContractId());

      // 予備契約種別
      inquiryReserveContractBusinessBean.setReserveContractClass(
          deleteReserveContractBusinessBean.getReserveContractClass());

      // 照会対象日付
      inquiryReserveContractBusinessBean.setInqCoveredDate(
          deleteReserveContractBusinessBean.getReserveContractSd());

      // 予備契約情報照会を呼び出す。
      inquiryReserveContractBusinessBean = inquiry(inquiryReserveContractBusinessBean);

      // 《予備契約情報照会BusinessBean》.リターンコードが“0000”以外の場合
      if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(
          inquiryReserveContractBusinessBean.getReturnCode())) {

        // 業務例外をスローする。
        throw new BusinessLogicException(
            messageSource.getMessage("error.E1735", new String[] {}, Locale.getDefault()), false);
      }

      // 《予備契約情報照会BusinessBean》.予備契約情報リストが0件の場合
      if (CollectionUtils.isEmpty(inquiryReserveContractBusinessBean.getReserveContractList())) {

        // コード(P101)を返却する。
        deleteReserveContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P101);
        deleteReserveContractBusinessBean.setMessage(
            messageSource.getMessage(KJ_CommonUtil.getMessageId(
                ECISReturnCodeConstants.RETURN_CODE_P101), new String[] {}, Locale.getDefault()));

        return deleteReserveContractBusinessBean;
      }

      // 《予備契約情報照会BusinessBean》より《予備契約情報照会EntityBean》リストの1番目を取得する。
      inquiryReserveContractInformationEntityBean = inquiryReserveContractBusinessBean.getReserveContractList()
          .get(0);

      // 親契約情報存在チェック
      // 《契約情報照会BusinessBean》を生成する。
      inquiryContractBusinessBean = new InquiryContractBusinessBean();

      // 《契約情報照会BusinessBean》.契約IDに《予備契約情報照会EntityBean》.契約IDを設定する。
      inquiryContractBusinessBean.setContractId(
          inquiryReserveContractInformationEntityBean.getContractId());

      // 《契約情報照会BusinessBean》.照会対象日付に《予備契約情報照会EntityBean》.予備契約開始日を設定する。
      inquiryContractBusinessBean.setInqCoveredDate(
          inquiryReserveContractInformationEntityBean.getReserveContractSd());

      // 《契約情報Business》.契約情報照会を呼び出す。
      inquiryContractBusinessBean = kjContractInformationBusiness.inquiry(inquiryContractBusinessBean);

      // 《契約情報照会BusinessBean》.リターンコードが“0000”以外の場合
      if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(inquiryContractBusinessBean.getReturnCode())) {

        throw new BusinessLogicException(
            messageSource.getMessage("error.E1285", new String[] {}, Locale.getDefault()), false);
      }

      // 《契約情報照会EntityBean》リストの返却値が0件の場合
      if (CollectionUtils.isEmpty(inquiryContractBusinessBean.getContractInformationList())) {

        // コード(D029)を返却する。
        deleteReserveContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D029);
        deleteReserveContractBusinessBean.setMessage(
            messageSource.getMessage(KJ_CommonUtil.getMessageId(
                ECISReturnCodeConstants.RETURN_CODE_D029), new String[] {}, Locale.getDefault()));

        return deleteReserveContractBusinessBean;
      }

      // 《契約情報照会BusinessBean》より《契約情報照会EntityBean》リストの1番目を取得する。
      inquiryContractInformationEntityBean = inquiryContractBusinessBean.getContractInformationList().get(0);

      // 契約終了状態判定のため、算定期間チェックを行う。
      conditionsMap = new HashMap<String, Object>();

      // 契約ID
      conditionsMap.put("contractId", inquiryContractInformationEntityBean.getContractId());
      // 対象日
      conditionsMap.put("coveredDate", inquiryContractInformationEntityBean.getContractEndDate());
      // フラグ
      conditionsMap.put("flg", ECISKJConstants.INQUIRY_FIX_CHANGE_RESULT_INFOEMATION_FLG_TWO);

      // 確定料金実績件数取得の結果が1件以上の場合
      if (fixChargeResultInformationCommonMapper.countByFixChargeResult(conditionsMap) >= 1) {

        // コード(D033)を返却する。
        deleteReserveContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D033);
        deleteReserveContractBusinessBean.setMessage(
            messageSource.getMessage(KJ_CommonUtil.getMessageId(
                ECISReturnCodeConstants.RETURN_CODE_D033), new String[] {}, Locale.getDefault()));

        return deleteReserveContractBusinessBean;
      }

      // 削除可否チェック
      // 契約終了状態判定のため、算定期間チェックを行う。
      conditionsMap = new HashMap<String, Object>();

      // 契約ID
      conditionsMap.put("contractId", inquiryReserveContractInformationEntityBean.getContractId());
      // 対象日
      conditionsMap.put("coveredDate", inquiryReserveContractInformationEntityBean.getReserveContractSd());
      // フラグ
      conditionsMap.put("flg", ECISKJConstants.INQUIRY_FIX_CHANGE_RESULT_INFOEMATION_FLG_ON);

      // 確定料金実績件数取得の結果が1件以上の場合
      if (fixChargeResultInformationCommonMapper.countByFixChargeResult(conditionsMap) >= 1) {

        // コード(D028)を返却する。
        deleteReserveContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D028);
        deleteReserveContractBusinessBean.setMessage(
            messageSource.getMessage(KJ_CommonUtil.getMessageId(
                ECISReturnCodeConstants.RETURN_CODE_D028), new String[] {}, Locale.getDefault()));

        return deleteReserveContractBusinessBean;
      }

      // 予備契約履歴削除
      // 予備契約履歴EntityExampleを生成する。
      reserveContractHistExample = new ReserveContractHistExample();

      // 更新条件の設定
      reserveContractHistExample
          .createCriteria()
          .andContractIdEqualTo(
              deleteReserveContractBusinessBean.getContractId())
          .andReserveContractClassEqualTo(
              deleteReserveContractBusinessBean.getReserveContractClass())
          .andReserveContractSdEqualTo(
              deleteReserveContractBusinessBean.getReserveContractSd())
          .andUpdateCountEqualTo(
              deleteReserveContractBusinessBean.getUpdateCount());

      // 《予備契約履歴Dao》.削除の返却値が0件の場合
      if (reserveContractHistMapper.deleteByExample(reserveContractHistExample) == 0) {

        // コード(H001)を返却する。
        deleteReserveContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_H001);
        deleteReserveContractBusinessBean.setMessage(
            messageSource.getMessage(KJ_CommonUtil.getMessageId(
                ECISReturnCodeConstants.RETURN_CODE_H001), new String[] {}, Locale.getDefault()));

        return deleteReserveContractBusinessBean;
      }

      // 正常終了
      deleteReserveContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);

    } catch (BusinessLogicException e) {

      // 業務例外
      logger.error(messageSource.getMessage("error.E1129", null, Locale.getDefault()), e);

      deleteReserveContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      deleteReserveContractBusinessBean.setMessage(businessLogicExceptionEMsg);

    } catch (DataAccessException e) {

      // データアクセス例外
      logger.error(messageSource.getMessage("error.E1129", null, Locale.getDefault()), e);

      deleteReserveContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      deleteReserveContractBusinessBean.setMessage(dataAccessExceptionEMsg);

    } catch (NoSuchMessageException e) {

      // メッセージ検索例外
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, e);

      deleteReserveContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      deleteReserveContractBusinessBean.setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
    }

    return deleteReserveContractBusinessBean;
  }

  /**
   * 契約情報ビジネスのセッター(DI)
   *
   * @param kjContractInformationBusiness
   *          契約情報ビジネス
   *
   */
  public void setKjContractInformationBusiness(
      KJ_ContractInformationBusiness kjContractInformationBusiness) {
    this.kjContractInformationBusiness = kjContractInformationBusiness;
  }

  /**
   * 確定料金実績情報共通マッパーのセッター(DI)
   *
   * @param fixChargeResultInformationCommonMapper
   *          確定料金実績情報共通マッパー
   *
   */
  public void setFixChargeResultInformationCommonMapper(
      FixChargeResultInformationCommonMapper fixChargeResultInformationCommonMapper) {
    this.fixChargeResultInformationCommonMapper = fixChargeResultInformationCommonMapper;
  }

  /**
   * 予備契約情報共通マッパーのセッター(DI)
   *
   * @param reserveContractInfomationCommonMapper
   *          予備契約情報共通マッパー
   *
   */
  public void setReserveContractInfomationCommonMapper(
      ReserveContractInfomationCommonMapper reserveContractInfomationCommonMapper) {
    this.reserveContractInfomationCommonMapper = reserveContractInfomationCommonMapper;
  }

  /**
   * 予備契約履歴マッパーのセッター(DI)
   *
   * @param reserveContractHistMapper
   *          予備契約履歴マッパー
   *
   */
  public void setReserveContractHistMapper(
      ReserveContractHistMapper reserveContractHistMapper) {
    this.reserveContractHistMapper = reserveContractHistMapper;
  }

  /**
   * メッセージソースのセッター(DI)
   *
   * @param messageSource
   *          メッセージソース
   *
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }

}
