package jp.co.unisys.enability.cis.business.gk;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import jp.co.unisys.enability.cis.business.kj.model.ContractManagementInformationFileConfigAccountCreditCard;
import jp.co.unisys.enability.cis.business.kj.model.ContractManagementInformationFileConfigCommon;
import jp.co.unisys.enability.cis.common.util.CommonValidationUtil;
import jp.co.unisys.enability.cis.common.util.EMSMessageResource;

/**
 * 口座クレカ情報ファイル更新チェッククラス
 *
 * @author "Nihon Unisys, Ltd."
 */
public class AccountCreditCardInformationFileRegistValidator {

  /** プロパティクラスを定義 */
  private EMSMessageResource emsMessageResource;

  /**
   * メッセージプロパティキー管理のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージプロパティキー管理を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param emsMessageResource
   *          メッセージプロパティキー管理
   */
  public void setEmsMessageResource(EMSMessageResource emsMessageResource) {
    this.emsMessageResource = emsMessageResource;
  }

  /**
   * 口座クレカ情報ファイルのバリデーションを実施、チェック結果のメッセージListを返却する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 1 引数のバリデーションを行う。
   * 2 チェック結果がNGの場合、戻り値のメッセージListにエラーメッセージを詰めて返却する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param registMap
   *          口座クレカ情報ファイル登録データに対するチェック結果
   * @return メッセージList
   */
  public List<String> validate(Map<Integer, String> registMap) {

    List<String> messageList = new ArrayList<String>();

    // データレコード種別：必須チェック
    if (CommonValidationUtil
        .isNull(registMap
            .get(ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_INDEX))) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_NAME }));

      // データレコード種別：正規表現チェック
    } else if (registMap
        .get(ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_INDEX) != null
        && !CommonValidationUtil
            .checkByPattern(
                registMap
                    .get(ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_INDEX),
                ContractManagementInformationFileConfigCommon.DATA_KIND_MASK_STRING)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_ITEM_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_NAME }));
    }

    // 契約者番号：必須チェック
    if (CommonValidationUtil
        .isNull(registMap
            .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_CONTRACTOR_NO_INDEX))) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigAccountCreditCard.DATA_CONTRACTOR_NO_NAME }));
    }

    // 契約者番号：文字種別チェック（半角英数字）
    if (registMap
        .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_CONTRACTOR_NO_INDEX) != null
        && !CommonValidationUtil
            .isAlphabetNumric(registMap
                .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_CONTRACTOR_NO_INDEX))) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_ALPHANUMERIC_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigAccountCreditCard.DATA_CONTRACTOR_NO_NAME }));

      // 契約者番号：文字種別チェック（半角英数字　低圧CISシステム許容文字）
    } else if (registMap
        .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_CONTRACTOR_NO_INDEX) != null
        && !CommonValidationUtil
            .isRangeWordByECIS(registMap
                .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_CONTRACTOR_NO_INDEX))) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigAccountCreditCard.DATA_CONTRACTOR_NO_NAME,
                      "半角英数字（低圧CISシステム許容文字）" }));

      // 契約者番号：文字列最大長チェック
    } else if (registMap
        .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_CONTRACTOR_NO_INDEX) != null
        && !CommonValidationUtil
            .maxLength(
                registMap
                    .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_CONTRACTOR_NO_INDEX),
                ContractManagementInformationFileConfigAccountCreditCard.DATA_CONTRACTOR_NO_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigAccountCreditCard.DATA_CONTRACTOR_NO_NAME,
                      ContractManagementInformationFileConfigAccountCreditCard.DATA_CONTRACTOR_NO_LENGTH_STRING }));
    }

    // 決済アクセスキー：文字種別チェック（半角英数字）
    if (registMap
        .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_ACCESS_KEY_INDEX) != null
        && !CommonValidationUtil
            .isAlphabetNumric(registMap
                .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_ACCESS_KEY_INDEX))) {
      messageList.add(emsMessageResource.getMessage(
          EMSMessageResource.VALIDATION_ALPHANUMERIC_KEY,
          new String[] {"決済アクセスキー" }));

      // 決済アクセスキー：文字種別チェック（半角英数字　低圧CISシステム許容文字）
    } else if (registMap
        .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_ACCESS_KEY_INDEX) != null
        && !CommonValidationUtil
            .isRangeWordByECIS(registMap
                .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_ACCESS_KEY_INDEX))) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigAccountCreditCard.DATA_ACCESS_KEY_NAME,
                      "半角英数字（低圧CISシステム許容文字）" }));

      // 決済アクセスキー：文字列最大長チェック
    } else if (registMap
        .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_ACCESS_KEY_INDEX) != null
        && !CommonValidationUtil
            .maxLength(
                registMap
                    .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_ACCESS_KEY_INDEX),
                ContractManagementInformationFileConfigAccountCreditCard.DATA_ACCESS_KEY_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigAccountCreditCard.DATA_ACCESS_KEY_NAME,
                      ContractManagementInformationFileConfigAccountCreditCard.DATA_ACCESS_KEY_LENGTH_STRING }));
    }

    // 口座クレカ区分コード：必須チェック
    if (CommonValidationUtil
        .isNull(registMap
            .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_ACCOUNT_CREDIT_CARD_CATEGORY_CODE_INDEX))) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigAccountCreditCard.DATA_ACCOUNT_CREDIT_CARD_CATEGORY_CODE_NAME }));
    }

    // 口座番号：文字種別チェック（半角数字）
    if (registMap
        .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_ACCOUNT_NO_INDEX) != null
        && !CommonValidationUtil
            .isNumric(registMap
                .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_ACCOUNT_NO_INDEX))) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigAccountCreditCard.DATA_ACCOUNT_NO_NAME,
                      "半角数字" }));

      // 口座番号：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (registMap
        .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_ACCOUNT_NO_INDEX) != null
        && !CommonValidationUtil
            .isRangeWordByECIS(registMap
                .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_ACCOUNT_NO_INDEX))) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigAccountCreditCard.DATA_ACCOUNT_NO_NAME,
                      "半角数字（低圧CISシステム許容文字）" }));

      // 口座番号：文字列指定長チェック
    } else if (StringUtils.isNotEmpty(registMap
        .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_ACCOUNT_NO_INDEX))
        && !CommonValidationUtil
            .justLength(
                registMap
                    .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_ACCOUNT_NO_INDEX),
                ContractManagementInformationFileConfigAccountCreditCard.DATA_ACCOUNT_NO_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_STRINGLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigAccountCreditCard.DATA_ACCOUNT_NO_NAME,
                      ContractManagementInformationFileConfigAccountCreditCard.DATA_ACCOUNT_NO_LENGTH_STRING }));
    }

    // 口座名義：文字列最大長チェック
    if (registMap
        .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_ACCOUNT_HOLDER_NAME_INDEX) != null
        && !CommonValidationUtil
            .maxLength(
                registMap
                    .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_ACCOUNT_HOLDER_NAME_INDEX),
                ContractManagementInformationFileConfigAccountCreditCard.DATA_ACCOUNT_HOLDER_NAME_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigAccountCreditCard.DATA_ACCOUNT_HOLDER_NAME_NAME,
                      ContractManagementInformationFileConfigAccountCreditCard.DATA_ACCOUNT_HOLDER_NAME_LENGTH_STRING }));

      // 口座名義：正規表現チェック
    } else if (registMap
        .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_ACCOUNT_HOLDER_NAME_INDEX) != null
        && !CommonValidationUtil
            .checkByPattern(
                registMap
                    .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_ACCOUNT_HOLDER_NAME_INDEX),
                "^([０-９Ａ-Ｚアイウエオ-ヂツ-モヤユヨ-ロワヲ-ヴヷヺ￥ー（）／「」．，　]*)$")) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_ITEM_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigAccountCreditCard.DATA_ACCOUNT_HOLDER_NAME_NAME }));
    }

    // クレカ番号：文字種別チェック（半角数字）
    if (registMap
        .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_CREDIT_CARD_NO_INDEX) != null
        && !CommonValidationUtil
            .isNumric(registMap
                .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_CREDIT_CARD_NO_INDEX))) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigAccountCreditCard.DATA_CREDIT_CARD_NO_NAME,
                      "半角数字" }));

      // クレカ番号：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (registMap
        .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_CREDIT_CARD_NO_INDEX) != null
        && !CommonValidationUtil
            .isRangeWordByECIS(registMap
                .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_CREDIT_CARD_NO_INDEX))) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigAccountCreditCard.DATA_CREDIT_CARD_NO_NAME,
                      "半角数字（低圧CISシステム許容文字）" }));

      // クレカ番号：文字列最大長チェック
    } else if (registMap
        .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_CREDIT_CARD_NO_INDEX) != null
        && !CommonValidationUtil
            .maxLength(
                registMap
                    .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_CREDIT_CARD_NO_INDEX),
                ContractManagementInformationFileConfigAccountCreditCard.DATA_CREDIT_CARD_NO_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigAccountCreditCard.DATA_CREDIT_CARD_NO_NAME,
                      ContractManagementInformationFileConfigAccountCreditCard.DATA_CREDIT_CARD_NO_LENGTH_STRING }));
    }

    // クレカ有効期限：文字列指定長チェック
    if (StringUtils.isNotEmpty(registMap
        .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_CREDIT_CARD_EXPIRATION_DATE_INDEX))
        && !CommonValidationUtil
            .justLength(
                registMap
                    .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_CREDIT_CARD_EXPIRATION_DATE_INDEX),
                ContractManagementInformationFileConfigAccountCreditCard.DATA_CREDIT_CARD_EXPIRATION_DATE_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_STRINGLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigAccountCreditCard.DATA_CREDIT_CARD_EXPIRATION_DATE_NAME,
                      ContractManagementInformationFileConfigAccountCreditCard.DATA_CREDIT_CARD_EXPIRATION_DATE_LENGTH_STRING }));

      // クレカ有効期限：日付フォーマットチェック
    } else if (registMap
        .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_CREDIT_CARD_EXPIRATION_DATE_INDEX) != null
        && !CommonValidationUtil
            .checkDateFormat(
                registMap
                    .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_CREDIT_CARD_EXPIRATION_DATE_INDEX),
                "yyyyMM")) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigAccountCreditCard.DATA_CREDIT_CARD_EXPIRATION_DATE_NAME,
                      "日付形式（yyyyMM）" }));
    }

    // 利用不能フラグ：必須チェック
    if (CommonValidationUtil
        .isNull(registMap
            .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_UNAVAILABLE_FLAG_INDEX))) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigAccountCreditCard.DATA_UNAVAILABLE_FLAG_NAME }));

      // 利用不能フラグ：文字種別チェック（半角数字）
    } else if (registMap
        .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_UNAVAILABLE_FLAG_INDEX) != null
        && !CommonValidationUtil
            .isNumric(registMap
                .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_UNAVAILABLE_FLAG_INDEX))) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigAccountCreditCard.DATA_UNAVAILABLE_FLAG_NAME,
                      "半角数字" }));
      // 利用不能フラグ：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (registMap
        .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_UNAVAILABLE_FLAG_INDEX) != null
        && !CommonValidationUtil
            .isRangeWordByECIS(registMap
                .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_UNAVAILABLE_FLAG_INDEX))) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigAccountCreditCard.DATA_UNAVAILABLE_FLAG_NAME,
                      "半角数字（低圧CISシステム許容文字）" }));
      // 利用不能フラグ：数値範囲チェック
    } else if (registMap
        .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_UNAVAILABLE_FLAG_INDEX) != null
        && !CommonValidationUtil
            .checkRange(
                registMap
                    .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_UNAVAILABLE_FLAG_INDEX),
                0, 1)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_RANGE_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigAccountCreditCard.DATA_UNAVAILABLE_FLAG_NAME,
                      "0～1" }));
    }
    return messageList;
  }
}
