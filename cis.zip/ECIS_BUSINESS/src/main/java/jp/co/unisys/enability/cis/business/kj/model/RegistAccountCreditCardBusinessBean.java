package jp.co.unisys.enability.cis.business.kj.model;

/**
 * 口座クレカ情報登録で、登録条件および登録結果を格納するビジネスBean
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * 口座クレカ情報ビジネス
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RegistAccountCreditCardBusinessBean {

  /**
   * 口座クレカIDを保有する。
   */
  private Integer accountCreditCardId;

  /**
   * 契約者IDを保有する。
   */
  private Integer contractorId;

  /**
   * 契約者番号を保有する。
   */
  private String contractorNo;

  /**
   * 口座クレカ区分コードを保有する。
   */
  private String accountCreditCategoryCode;

  /**
   * 決済アクセスキーを保有する。
   */
  private String accessKey;

  /**
   * 金融機関コードを保有する。
   */
  private String bankCode;

  /**
   * 金融機関支店コードを保有する。
   */
  private String bankBranchCode;

  /**
   * 金融機関預金種目コードを保有する。
   */
  private String bankTypeOfAccountCode;

  /**
   * 口座番号を保有する。
   */
  private String accountNo;

  /**
   * 口座名義を保有する。
   */
  private String accountHolderName;

  /**
   * クレカ番号を保有する。
   */
  private String creditCardNo;

  /**
   * クレカ有効期限を保有する。
   */
  private String creditCardExpirationDate;

  /**
   * クレカブランドコードを保有する。
   */
  private String creditCardBrandCode;

  /**
   * 利用不能フラグを保有する。
   */
  private String unavailableFlag;

  /**
   * リターンコードを保有する。
   */
  private String returnCode;

  /**
   * メッセージを保有する。
   */
  private String message;

  /**
   * 口座クレカIDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 口座クレカIDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 口座クレカID
   */
  public Integer getAccountCreditCardId() {
    return this.accountCreditCardId;
  }

  /**
   * 口座クレカIDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 口座クレカIDを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param accountCreditCardId
   *          口座クレカID
   */
  public void setAccountCreditCardId(Integer accountCreditCardId) {
    this.accountCreditCardId = accountCreditCardId;
  }

  /**
   * 契約者IDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者IDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者ID
   */
  public Integer getContractorId() {
    return this.contractorId;
  }

  /**
   * 契約者IDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者IDを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorId
   *          契約者ID
   */
  public void setContractorId(Integer contractorId) {
    this.contractorId = contractorId;
  }

  /**
   * 契約者番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者番号を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者番号
   */
  public String getContractorNo() {
    return this.contractorNo;
  }

  /**
   * 契約者番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者番号を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorNo
   *          契約者番号
   */
  public void setContractorNo(String contractorNo) {
    this.contractorNo = contractorNo;
  }

  /**
   * 口座クレカ区分コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 口座クレカ区分コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 口座クレカ区分コード
   */
  public String getAccountCreditCategoryCode() {
    return this.accountCreditCategoryCode;
  }

  /**
   * 口座クレカ区分コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 口座クレカ区分コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param accountCreditCategoryCode
   *          口座クレカ区分コード
   */
  public void setAccountCreditCategoryCode(String accountCreditCategoryCode) {
    this.accountCreditCategoryCode = accountCreditCategoryCode;
  }

  /**
   * 決済アクセスキーのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 決済アクセスキーを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 決済アクセスキー
   */
  public String getAccessKey() {
    return this.accessKey;
  }

  /**
   * 決済アクセスキーのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 決済アクセスキーを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param accessKey
   *          決済アクセスキー
   */
  public void setAccessKey(String accessKey) {
    this.accessKey = accessKey;
  }

  /**
   * 金融機関コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 金融機関コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 金融機関コード
   */
  public String getBankCode() {
    return this.bankCode;
  }

  /**
   * 金融機関コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 金融機関コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param bankCode
   *          金融機関コード
   */
  public void setBankCode(String bankCode) {
    this.bankCode = bankCode;
  }

  /**
   * 金融機関支店コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 金融機関支店コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 金融機関支店コード
   */
  public String getBankBranchCode() {
    return this.bankBranchCode;
  }

  /**
   * 金融機関支店コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 金融機関支店コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param bankBranchCode
   *          金融機関支店コード
   */
  public void setBankBranchCode(String bankBranchCode) {
    this.bankBranchCode = bankBranchCode;
  }

  /**
   * 金融機関預金種目コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 金融機関預金種目コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 金融機関預金種目コード
   */
  public String getBankTypeOfAccountCode() {
    return this.bankTypeOfAccountCode;
  }

  /**
   * 金融機関預金種目コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 金融機関預金種目コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param bankTypeOfAccountCode
   *          金融機関預金種目コード
   */
  public void setBankTypeOfAccountCode(String bankTypeOfAccountCode) {
    this.bankTypeOfAccountCode = bankTypeOfAccountCode;
  }

  /**
   * 口座番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 口座番号を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 口座番号
   */
  public String getAccountNo() {
    return this.accountNo;
  }

  /**
   * 口座番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 口座番号を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param accountNo
   *          口座番号
   */
  public void setAccountNo(String accountNo) {
    this.accountNo = accountNo;
  }

  /**
   * 口座名義のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 口座名義を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 口座名義
   */
  public String getAccountHolderName() {
    return this.accountHolderName;
  }

  /**
   * 口座名義のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 口座名義を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param accountHolderName
   *          口座名義
   */
  public void setAccountHolderName(String accountHolderName) {
    this.accountHolderName = accountHolderName;
  }

  /**
   * クレカ番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * クレカ番号を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return クレカ番号
   */
  public String getCreditCardNo() {
    return this.creditCardNo;
  }

  /**
   * クレカ番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * クレカ番号を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param creditCardNo
   *          クレカ番号
   */
  public void setCreditCardNo(String creditCardNo) {
    this.creditCardNo = creditCardNo;
  }

  /**
   * クレカ有効期限のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * クレカ有効期限を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return クレカ有効期限
   */
  public String getCreditCardExpirationDate() {
    return this.creditCardExpirationDate;
  }

  /**
   * クレカ有効期限のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * クレカ有効期限を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param creditCardExpirationDate
   *          クレカ有効期限
   */
  public void setCreditCardExpirationDate(String creditCardExpirationDate) {
    this.creditCardExpirationDate = creditCardExpirationDate;
  }

  /**
   * クレカブランドコードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * クレカブランドコードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return クレカブランドコード
   */
  public String getCreditCardBrandCode() {
    return this.creditCardBrandCode;
  }

  /**
   * クレカブランドコードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * クレカブランドコードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param creditCardBrandCode
   *          クレカブランドコード
   */
  public void setCreditCardBrandCode(String creditCardBrandCode) {
    this.creditCardBrandCode = creditCardBrandCode;
  }

  /**
   * 利用不能フラグのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 利用不能フラグを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 利用不能フラグ
   */
  public String getUnavailableFlag() {
    return this.unavailableFlag;
  }

  /**
   * 利用不能フラグのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 利用不能フラグを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param unavailableFlag
   *          利用不能フラグ
   */
  public void setUnavailableFlag(String unavailableFlag) {
    this.unavailableFlag = unavailableFlag;
  }

  /**
   * リターンコードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return リターンコード
   */
  public String getReturnCode() {
    return this.returnCode;
  }

  /**
   * リターンコードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param returnCode
   *          リターンコード
   */
  public void setReturnCode(String returnCode) {
    this.returnCode = returnCode;
  }

  /**
   * メッセージのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return メッセージ
   */
  public String getMessage() {
    return this.message;
  }

  /**
   * メッセージのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param message
   *          メッセージ
   */
  public void setMessage(String message) {
    this.message = message;
  }

}
