package jp.co.unisys.enability.cis.business.kj.model;

import java.util.Date;

/**
 * メータ設置場所更新で、検索条件および検索結果を格納するビジネスBean
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * メータ設置場所更新ビジネス
 * 契約情報ビジネス
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class UpdateMeterLocationBusinessBean {

  /**
   * メータ設置場所IDを保有する。
   */
  private Integer meterLocationId;

  /**
   * 需要場所IDを保有する。
   */
  private Integer palceId;

  /**
   * 需要場所住所（郵便番号）を保有する。
   */
  private String placeAddressPostalCode;

  /**
   * 需要場所住所（住所）を保有する。
   */
  private String placeAddressFull;

  /**
   * 需要場所住所（建物・部屋名）を保有する。
   */
  private String placeAddressBuilding;

  /**
   * エリアコードを保有する。
   */
  private String areaCode;

  /**
   * 地点特定番号を保有する。
   */
  private String spotNo;

  /**
   * 需要家識別番号を保有する。
   */
  private String contractorIdentificationNo;

  /**
   * 送受電区分コードを保有する。
   */
  private String transmissionCategoryCode;

  /**
   * 基本検針日を保有する。
   */
  private String basicMeterReadingDate;

  /**
   * 次回検針予定日更新対象外フラグを保有する。
   */
  private String nextMeterReadingScheduledDateNoUpdFlag;

  /**
   * 前回検針日更新対象外フラグを保有する。
   */
  private String lastTimeMeterReadingDateNoUpdFlag;

  /**
   * 次回検針予定日を保有する。
   */
  private Date nextMeterReadingScheduledDate;

  /**
   * 前回検針日を保有する。
   */
  private Date lastTimeMeterReadingDate;

  /**
   * 自家発連携有無コードを保有する。
   */
  private String generatorLinkageCheckCode;

  /**
   * 供給方式コードを保有する。
   */
  private String methodCode;

  /**
   * 契約決定方法コードを保有する。
   */
  private String contractDecisionWayCode;

  /**
   * 計器識別番号1を保有する。
   */
  private String meterIdentificationNo1;

  /**
   * 計器識別番号2を保有する。
   */
  private String meterIdentificationNo2;

  /**
   * 計器識別番号3を保有する。
   */
  private String meterIdentificationNo3;

  /**
   * 計器識別番号4を保有する。
   */
  private String meterIdentificationNo4;

  /**
   * 計器識別番号5を保有する。
   */
  private String meterIdentificationNo5;

  /**
   * 30分値収集可否・自動検針可否コード1を保有する。
   */
  private String automaticMeterReadingCkeckCode1;

  /**
   * 30分値収集可否・自動検針可否コード2を保有する。
   */
  private String automaticMeterReadingCkeckCode2;

  /**
   * 30分値収集可否・自動検針可否コード3を保有する。
   */
  private String automaticMeterReadingCkeckCode3;

  /**
   * 30分値収集可否・自動検針可否コード4を保有する。
   */
  private String automaticMeterReadingCkeckCode4;

  /**
   * 30分値収集可否・自動検針可否コード5を保有する。
   */
  private String automaticMeterReadingCkeckCode5;

  /**
   * 検針日区分コードを保有する。
   */
  private String meterReadingDateCategoryCode;

  /**
   * スマートメータ区分コードを保有する。
   */
  private String smartMeterCategoryCode;

  /**
   * 更新回数を保有する。
   */
  private Integer updateCount;

  /**
   * リターンコードを保有する。
   */
  private String returnCode;

  /**
   * メッセージを保有する。
   */
  private String message;

  /**
   * 都道府県コードを保有する。
   */
  private String prefectureCode;

  /**
   * メータ設置場所IDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メータ設置場所IDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return メータ設置場所ID
   */
  public Integer getMeterLocationId() {
    return this.meterLocationId;
  }

  /**
   * メータ設置場所IDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メータ設置場所IDを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param meterLocationId
   *          メータ設置場所ID
   */
  public void setMeterLocationId(Integer meterLocationId) {
    this.meterLocationId = meterLocationId;
  }

  /**
   * 需要場所IDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 需要場所IDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 需要場所ID
   */
  public Integer getPalceId() {
    return palceId;
  }

  /**
   * 需要場所IDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 需要場所IDを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param palceId
   *          需要場所ID
   */
  public void setPalceId(Integer palceId) {
    this.palceId = palceId;
  }

  /**
   * 需要場所住所（郵便番号）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 需要場所住所（郵便番号）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 需要場所住所（郵便番号）
   */
  public String getPlaceAddressPostalCode() {
    return this.placeAddressPostalCode;
  }

  /**
   * 需要場所住所（郵便番号）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 需要場所住所（郵便番号）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param placeAddressPostalCode
   *          需要場所住所（郵便番号）
   */
  public void setPlaceAddressPostalCode(String placeAddressPostalCode) {
    this.placeAddressPostalCode = placeAddressPostalCode;
  }

  /**
   * 需要場所住所（住所）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 需要場所住所（住所）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 需要場所住所（住所）
   */
  public String getPlaceAddressFull() {
    return this.placeAddressFull;
  }

  /**
   * 需要場所住所（住所）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 需要場所住所（住所）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param placeAddressFull
   *          需要場所住所（住所）
   */
  public void setPlaceAddressFull(String placeAddressFull) {
    this.placeAddressFull = placeAddressFull;
  }

  /**
   * 需要場所住所（建物・部屋名）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 需要場所住所（建物・部屋名）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 需要場所住所（建物・部屋名）
   */
  public String getPlaceAddressBuilding() {
    return this.placeAddressBuilding;
  }

  /**
   * 需要場所住所（建物・部屋名）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 需要場所住所（建物・部屋名）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param placeAddressBuilding
   *          需要場所住所（建物・部屋名）
   */
  public void setPlaceAddressBuilding(String placeAddressBuilding) {
    this.placeAddressBuilding = placeAddressBuilding;
  }

  /**
   * エリアコードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * エリアコードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return エリアコード
   */
  public String getAreaCode() {
    return this.areaCode;
  }

  /**
   * エリアコードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * エリアコードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param areaCode
   *          エリアコード
   */
  public void setAreaCode(String areaCode) {
    this.areaCode = areaCode;
  }

  /**
   * 地点特定番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 地点特定番号を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 地点特定番号
   */
  public String getSpotNo() {
    return this.spotNo;
  }

  /**
   * 地点特定番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 地点特定番号を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param spotNo
   *          地点特定番号
   */
  public void setSpotNo(String spotNo) {
    this.spotNo = spotNo;
  }

  /**
   * 需要家識別番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 需要家識別番号を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 需要家識別番号
   */
  public String getContractorIdentificationNo() {
    return this.contractorIdentificationNo;
  }

  /**
   * 需要家識別番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 需要家識別番号を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorIdentificationNo
   *          需要家識別番号
   */
  public void setContractorIdentificationNo(String contractorIdentificationNo) {
    this.contractorIdentificationNo = contractorIdentificationNo;
  }

  /**
   * 送受電区分コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 送受電区分コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 送受電区分コード
   */
  public String getTransmissionCategoryCode() {
    return this.transmissionCategoryCode;
  }

  /**
   * 送受電区分コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 送受電区分コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param transmissionCategoryCode
   *          送受電区分コード
   */
  public void setTransmissionCategoryCode(String transmissionCategoryCode) {
    this.transmissionCategoryCode = transmissionCategoryCode;
  }

  /**
   * 基本検針日のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 基本検針日を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 基本検針日
   */
  public String getBasicMeterReadingDate() {
    return this.basicMeterReadingDate;
  }

  /**
   * 基本検針日のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 基本検針日を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param basicMeterReadingDate
   *          基本検針日
   */
  public void setBasicMeterReadingDate(String basicMeterReadingDate) {
    this.basicMeterReadingDate = basicMeterReadingDate;
  }

  /**
   * 次回検針予定日更新対象外フラグのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 次回検針予定日更新対象外フラグを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 次回検針予定日更新対象外フラグ
   */
  public String getNextMeterReadingScheduledDateNoUpdFlag() {
    return nextMeterReadingScheduledDateNoUpdFlag;
  }

  /**
   * 次回検針予定日更新対象外フラグのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 次回検針予定日更新対象外フラグを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param nextMeterReadingScheduledDateNoUpdFlag
   *          次回検針予定日更新対象外フラグ
   */
  public void setNextMeterReadingScheduledDateNoUpdFlag(
      String nextMeterReadingScheduledDateNoUpdFlag) {
    this.nextMeterReadingScheduledDateNoUpdFlag = nextMeterReadingScheduledDateNoUpdFlag;
  }

  /**
   * 前回検針日更新対象外フラグのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 前回検針日更新対象外フラグを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 前回検針日更新対象外フラグ
   */
  public String getLastTimeMeterReadingDateNoUpdFlag() {
    return lastTimeMeterReadingDateNoUpdFlag;
  }

  /**
   * 前回検針日更新対象外フラグのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 前回検針日更新対象外フラグを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param lastTimeMeterReadingDateNoUpdFlag
   *          前回検針日更新対象外フラグ
   */
  public void setLastTimeMeterReadingDateNoUpdFlag(
      String lastTimeMeterReadingDateNoUpdFlag) {
    this.lastTimeMeterReadingDateNoUpdFlag = lastTimeMeterReadingDateNoUpdFlag;
  }

  /**
   * 次回検針予定日のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 次回検針予定日を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 次回検針予定日
   */
  public Date getNextMeterReadingScheduledDate() {
    return this.nextMeterReadingScheduledDate;
  }

  /**
   * 次回検針予定日のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 次回検針予定日を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param nextMeterReadingScheduledDate
   *          次回検針予定日
   */
  public void setNextMeterReadingScheduledDate(
      Date nextMeterReadingScheduledDate) {
    this.nextMeterReadingScheduledDate = nextMeterReadingScheduledDate;
  }

  /**
   * 前回検針日のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 前回検針日を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 前回検針日
   */
  public Date getLastTimeMeterReadingDate() {
    return this.lastTimeMeterReadingDate;
  }

  /**
   * 前回検針日のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 前回検針日を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param lastTimeMeterReadingDate
   *          前回検針日
   */
  public void setLastTimeMeterReadingDate(Date lastTimeMeterReadingDate) {
    this.lastTimeMeterReadingDate = lastTimeMeterReadingDate;
  }

  /**
   * 自家発連携有無コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 自家発連携有無コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 自家発連携有無コード
   */
  public String getGeneratorLinkageCheckCode() {
    return this.generatorLinkageCheckCode;
  }

  /**
   * 自家発連携有無コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 自家発連携有無コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param generatorLinkageCheckCode
   *          自家発連携有無コード
   */
  public void setGeneratorLinkageCheckCode(String generatorLinkageCheckCode) {
    this.generatorLinkageCheckCode = generatorLinkageCheckCode;
  }

  /**
   * 供給方式コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 供給方式コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 供給方式コード
   */
  public String getMethodCode() {
    return this.methodCode;
  }

  /**
   * 供給方式コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 供給方式コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param methodCode
   *          供給方式コード
   */
  public void setMethodCode(String methodCode) {
    this.methodCode = methodCode;
  }

  /**
   * 契約決定方法コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約決定方法コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約決定方法コード
   */
  public String getContractDecisionWayCode() {
    return contractDecisionWayCode;
  }

  /**
   * 契約決定方法コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約決定方法コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractDecisionWayCode
   *          契約決定方法コード
   */
  public void setContractDecisionWayCode(String contractDecisionWayCode) {
    this.contractDecisionWayCode = contractDecisionWayCode;
  }

  /**
   * 計器識別番号1のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計器識別番号1を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 計器識別番号1
   */
  public String getMeterIdentificationNo1() {
    return this.meterIdentificationNo1;
  }

  /**
   * 計器識別番号1のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計器識別番号1を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param meterIdentificationNo1
   *          計器識別番号1
   */
  public void setMeterIdentificationNo1(String meterIdentificationNo1) {
    this.meterIdentificationNo1 = meterIdentificationNo1;
  }

  /**
   * 計器識別番号2のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計器識別番号2を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 計器識別番号2
   */
  public String getMeterIdentificationNo2() {
    return this.meterIdentificationNo2;
  }

  /**
   * 計器識別番号2のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計器識別番号2を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param meterIdentificationNo2
   *          計器識別番号2
   */
  public void setMeterIdentificationNo2(String meterIdentificationNo2) {
    this.meterIdentificationNo2 = meterIdentificationNo2;
  }

  /**
   * 計器識別番号3のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計器識別番号3を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 計器識別番号3
   */
  public String getMeterIdentificationNo3() {
    return this.meterIdentificationNo3;
  }

  /**
   * 計器識別番号3のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計器識別番号3を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param meterIdentificationNo3
   *          計器識別番号3
   */
  public void setMeterIdentificationNo3(String meterIdentificationNo3) {
    this.meterIdentificationNo3 = meterIdentificationNo3;
  }

  /**
   * 計器識別番号4のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計器識別番号4を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 計器識別番号4
   */
  public String getMeterIdentificationNo4() {
    return this.meterIdentificationNo4;
  }

  /**
   * 計器識別番号4のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計器識別番号4を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param meterIdentificationNo4
   *          計器識別番号4
   */
  public void setMeterIdentificationNo4(String meterIdentificationNo4) {
    this.meterIdentificationNo4 = meterIdentificationNo4;
  }

  /**
   * 計器識別番号5のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計器識別番号5を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 計器識別番号5
   */
  public String getMeterIdentificationNo5() {
    return this.meterIdentificationNo5;
  }

  /**
   * 計器識別番号5のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計器識別番号5を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param meterIdentificationNo5
   *          計器識別番号5
   */
  public void setMeterIdentificationNo5(String meterIdentificationNo5) {
    this.meterIdentificationNo5 = meterIdentificationNo5;
  }

  /**
   * 30分値収集可否・自動検針可否コード1のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 30分値収集可否・自動検針可否コード1を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 30分値収集可否・自動検針可否コード1
   */
  public String getAutomaticMeterReadingCkeckCode1() {
    return this.automaticMeterReadingCkeckCode1;
  }

  /**
   * 30分値収集可否・自動検針可否コード1のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 30分値収集可否・自動検針可否コード1を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param automaticMeterReadingCkeckCode1
   *          30分値収集可否・自動検針可否コード1
   */
  public void setAutomaticMeterReadingCkeckCode1(
      String automaticMeterReadingCkeckCode1) {
    this.automaticMeterReadingCkeckCode1 = automaticMeterReadingCkeckCode1;
  }

  /**
   * 30分値収集可否・自動検針可否コード2のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 30分値収集可否・自動検針可否コード2を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 30分値収集可否・自動検針可否コード2
   */
  public String getAutomaticMeterReadingCkeckCode2() {
    return this.automaticMeterReadingCkeckCode2;
  }

  /**
   * 30分値収集可否・自動検針可否コード2のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 30分値収集可否・自動検針可否コード2を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param automaticMeterReadingCkeckCode2
   *          30分値収集可否・自動検針可否コード2
   */
  public void setAutomaticMeterReadingCkeckCode2(
      String automaticMeterReadingCkeckCode2) {
    this.automaticMeterReadingCkeckCode2 = automaticMeterReadingCkeckCode2;
  }

  /**
   * 30分値収集可否・自動検針可否コード3のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 30分値収集可否・自動検針可否コード3を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 30分値収集可否・自動検針可否コード3
   */
  public String getAutomaticMeterReadingCkeckCode3() {
    return this.automaticMeterReadingCkeckCode3;
  }

  /**
   * 30分値収集可否・自動検針可否コード3のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 30分値収集可否・自動検針可否コード3を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param automaticMeterReadingCkeckCode3
   *          30分値収集可否・自動検針可否コード3
   */
  public void setAutomaticMeterReadingCkeckCode3(
      String automaticMeterReadingCkeckCode3) {
    this.automaticMeterReadingCkeckCode3 = automaticMeterReadingCkeckCode3;
  }

  /**
   * 30分値収集可否・自動検針可否コード4のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 30分値収集可否・自動検針可否コード4を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 30分値収集可否・自動検針可否コード4
   */
  public String getAutomaticMeterReadingCkeckCode4() {
    return this.automaticMeterReadingCkeckCode4;
  }

  /**
   * 30分値収集可否・自動検針可否コード4のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 30分値収集可否・自動検針可否コード4を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param automaticMeterReadingCkeckCode4
   *          30分値収集可否・自動検針可否コード4
   */
  public void setAutomaticMeterReadingCkeckCode4(
      String automaticMeterReadingCkeckCode4) {
    this.automaticMeterReadingCkeckCode4 = automaticMeterReadingCkeckCode4;
  }

  /**
   * 30分値収集可否・自動検針可否コード5のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 30分値収集可否・自動検針可否コード5を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 30分値収集可否・自動検針可否コード5
   */
  public String getAutomaticMeterReadingCkeckCode5() {
    return this.automaticMeterReadingCkeckCode5;
  }

  /**
   * 30分値収集可否・自動検針可否コード5のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 30分値収集可否・自動検針可否コード5を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param automaticMeterReadingCkeckCode5
   *          30分値収集可否・自動検針可否コード5
   */
  public void setAutomaticMeterReadingCkeckCode5(
      String automaticMeterReadingCkeckCode5) {
    this.automaticMeterReadingCkeckCode5 = automaticMeterReadingCkeckCode5;
  }

  /**
   * スマートメータ区分コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * スマートメータ区分コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return スマートメータ区分コード
   */
  public String getSmartMeterCategoryCode() {
    return smartMeterCategoryCode;
  }

  /**
   * スマートメータ区分コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * スマートメータ区分コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param smartMeterCategoryCode
   *          スマートメータ区分コード
   */
  public void setSmartMeterCategoryCode(String smartMeterCategoryCode) {
    this.smartMeterCategoryCode = smartMeterCategoryCode;
  }

  /**
   * 検針日区分コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 検針日区分コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 検針日区分コード
   */
  public String getMeterReadingDateCategoryCode() {
    return meterReadingDateCategoryCode;
  }

  /**
   * 検針日区分コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 検針日区分コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param meterReadingDateCategoryCode
   *          検針日区分コード
   */
  public void setMeterReadingDateCategoryCode(String meterReadingDateCategoryCode) {
    this.meterReadingDateCategoryCode = meterReadingDateCategoryCode;
  }

  /**
   * 更新回数のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 更新回数を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 更新回数
   */
  public Integer getUpdateCount() {
    return this.updateCount;
  }

  /**
   * 更新回数のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 更新回数を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param updateCount
   *          更新回数
   */
  public void setUpdateCount(Integer updateCount) {
    this.updateCount = updateCount;
  }

  /**
   * リターンコードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return リターンコード
   */
  public String getReturnCode() {
    return this.returnCode;
  }

  /**
   * リターンコードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param returnCode
   *          リターンコード
   */
  public void setReturnCode(String returnCode) {
    this.returnCode = returnCode;
  }

  /**
   * メッセージのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return メッセージ
   */
  public String getMessage() {
    return this.message;
  }

  /**
   * メッセージのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param message
   *          メッセージ
   */
  public void setMessage(String message) {
    this.message = message;
  }

  /**
   * 都道府県コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 都道府県コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 都道府県コード
   */
  public String getPrefectureCode() {
    return this.prefectureCode;
  }

  /**
   * 都道府県コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 都道府県コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param prefectureCode
   *          都道府県コード
   */
  public void setPrefectureCode(String prefectureCode) {
    this.prefectureCode = prefectureCode;
  }
}
