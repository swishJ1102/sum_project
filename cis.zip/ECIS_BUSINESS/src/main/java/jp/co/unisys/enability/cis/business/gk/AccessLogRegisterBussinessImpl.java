package jp.co.unisys.enability.cis.business.gk;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.concurrent.atomic.AtomicReference;

import javax.sql.DataSource;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.core.Appender;
import org.apache.logging.log4j.core.LoggerContext;
import org.apache.logging.log4j.core.appender.db.jdbc.ColumnConfig;
import org.apache.logging.log4j.core.appender.db.jdbc.ConnectionSource;
import org.apache.logging.log4j.core.appender.db.jdbc.JdbcAppender;
import org.apache.logging.log4j.core.config.AppenderRef;
import org.apache.logging.log4j.core.config.Configuration;
import org.apache.logging.log4j.core.config.LoggerConfig;
import org.apache.logging.log4j.message.StringMapMessage;
import org.springframework.beans.factory.annotation.Autowired;

import jp.co.unisys.enability.cis.common.Exception.SystemException;
import jp.co.unisys.enability.cis.common.util.constants.ECISGKConstants;

/**
 * アクセスログ出力ビジネス処理
 *
 * <pre>
 * <p><b>【仕様詳細】</b></p>
 * アクセスログ出力を行う。
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class AccessLogRegisterBussinessImpl implements
    AccessLogRegisterBussiness {

  /** ロガー */
  private static final Logger logger = LogManager.getLogger(AccessLogRegisterBussinessImpl.class.getName());

  /** データソース */
  @Autowired
  private DataSource dataSource;

  /**
   * log4jにJDBCAppnderを追加
   *
   * <pre>
   * CISのaccess_logテーブルにログを出力するappenderを追加します
   *
   * コネクションはSpringで管理されているコネクションプールから取得しているため
   * Spring初期化後でないとlog4jに設定できない、log4j.xmlには指定できないため注意
   *
   * また、各ビジネスロジックと同じトランザクションで実行してはいけない為
   * （ログはトランザクションにかかわらず必ず出力したい）
   * コネクションはログモジュール側で取得する作りとなっている
   *
   * なお本関数を実行するトリガの定義としてBean定義にinit-method="init"が必要
   * </pre>
   */
  public void init() {

    final LoggerContext ctx = (LoggerContext) LogManager.getContext(false);
    final Configuration config = ctx.getConfiguration();

    ColumnConfig[] cc = {
        ColumnConfig.newBuilder()
            .setConfiguration(config)
            .setName("log_time")
            .setEventTimestamp(true)
            .setUnicode(false)
            .build(),
        ColumnConfig.newBuilder()
            .setConfiguration(config)
            .setName("user_id")
            .setPattern("%K{USER_ID}")
            .setUnicode(false)
            .build(),
        ColumnConfig.newBuilder()
            .setConfiguration(config)
            .setName("screen_id")
            .setPattern("%K{SCREEN_ID}")
            .setUnicode(false)
            .build(),
        ColumnConfig.newBuilder()
            .setConfiguration(config)
            .setName("action_id")
            .setPattern("%K{ACTION_ID}")
            .setUnicode(false)
            .build(),
        ColumnConfig.newBuilder()
            .setConfiguration(config)
            .setName("log_value")
            .setPattern("%K{LOG_VALUE}")
            .setUnicode(false)
            .build(),
    };
    Appender appender = JdbcAppender.newBuilder()
        .setName("databaseAppender")
        .setIgnoreExceptions(true)
        .setConnectionSource(new Connect(dataSource))
        .setBufferSize(0)
        .setTableName("access_log")
        .setColumnConfigs(cc)
        .build();

    appender.start();

    AppenderRef ref = AppenderRef.createAppenderRef("databaseAppender", Level.INFO, null);
    AppenderRef[] refs = new AppenderRef[] {ref };
    LoggerConfig loggerConfig = LoggerConfig.createLogger(false, Level.INFO,
        AccessLogRegisterBussinessImpl.class.getName(), "false", refs, null, config, null);

    loggerConfig.addAppender(appender, Level.INFO, null);
    config.addLogger(AccessLogRegisterBussinessImpl.class.getName(), loggerConfig);
    ctx.updateLoggers();

  }

  /**
   * データソースの取得
   *
   * @return データソース
   */
  public DataSource getDataSource() {
    return dataSource;
  }

  /**
   * データソースの設定
   *
   * @param dataSource
   *          データソース
   */
  public void setDataSource(DataSource dataSource) {
    this.dataSource = dataSource;
  }

  /*
   * @see
   * jp.co.unisys.enability.cis.business.gk.AccessLogRegisterBussiness#
   * accessLogRegister(java.lang.String, java.lang.String, java.lang.String,
   * java.lang.String)
   */
  @Override
  public void accessLogRegister(String userId, String dispId,
      String actionId, String value) {
    try {

      //nullの場合から文字に置換する
      if (StringUtils.isEmpty(userId)) {
        userId = ECISGKConstants.EMPTY_STRING;
      }

      if (StringUtils.isEmpty(dispId)) {
        dispId = ECISGKConstants.EMPTY_STRING;
      }

      if (StringUtils.isEmpty(actionId)) {
        actionId = ECISGKConstants.EMPTY_STRING;
      }

      if (StringUtils.isEmpty(value)) {
        value = ECISGKConstants.EMPTY_STRING;
      }

      logger.info(new StringMapMessage()
          .with("USER_ID", userId)
          .with("SCREEN_ID", dispId)
          .with("ACTION_ID", actionId)
          .with("LOG_VALUE", value));

    } catch (Exception e) {
      throw new SystemException(e.getMessage(), e);
    }

  }

  //inner class
  class Connect implements ConnectionSource {
    private DataSource dsource;

    AtomicReference<State> state = new AtomicReference<>(State.INITIALIZING);

    public Connect(DataSource dsource) {
      this.dsource = dsource;
    }

    @Override
    public Connection getConnection() throws SQLException {
      return this.dsource.getConnection();
    }

    @Override
    public State getState() {
      return state.get();
    }

    @Override
    public void initialize() {
      this.state.set(State.INITIALIZED);
    }

    @Override
    public void start() {
      this.state.set(State.STARTED);
    }

    @Override
    public void stop() {
      this.state.set(State.STOPPED);
    }

    @Override
    public boolean isStarted() {
      return state.get().equals(State.STARTED);
    }

    @Override
    public boolean isStopped() {
      return state.get().equals(State.STOPPED);
    }

  }
}
