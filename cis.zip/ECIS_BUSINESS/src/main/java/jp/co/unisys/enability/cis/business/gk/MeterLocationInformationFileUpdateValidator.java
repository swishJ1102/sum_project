package jp.co.unisys.enability.cis.business.gk;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import jp.co.unisys.enability.cis.business.kj.model.ContractManagementInformationFileConfigCommon;
import jp.co.unisys.enability.cis.business.kj.model.ContractManagementInformationFileConfigMeterLocation;
import jp.co.unisys.enability.cis.common.util.CommonValidationUtil;
import jp.co.unisys.enability.cis.common.util.EMSMessageResource;

/**
 * メータ設置場所情報ファイル更新バリデーション
 *
 * @author "Nihon Unisys, Ltd."
 */
public class MeterLocationInformationFileUpdateValidator {

  /** プロパティクラスを定義 */
  private EMSMessageResource emsMessageResource;

  /**
   * メッセージプロパティキー管理のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージプロパティキー管理を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param emsMessageResource
   *          メッセージプロパティキー管理
   */
  public void setEmsMessageResource(EMSMessageResource emsMessageResource) {
    this.emsMessageResource = emsMessageResource;
  }

  /**
   * メータ設置場所情報ファイル更新のバリデーションを実施、チェック結果のメッセージListを返却する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 1 引数のバリデーションを行う。
   * 2 チェック結果がNGの場合、戻り値のメッセージListにエラーメッセージを詰めて返却する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param dataRecordMap
   *          データレコードマップ
   * @return メッセージList
   */
  public List<String> validate(Map<Integer, String> dataRecordMap) {

    List<String> messageList = new ArrayList<String>();

    // データレコード種別：必須チェック
    String dataRecordClass = dataRecordMap
        .get(ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_INDEX);
    if (CommonValidationUtil.isNull(dataRecordClass)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_NAME }));

      // データレコード種別：正規表現チェック
    } else if (dataRecordClass != null
        && !CommonValidationUtil
            .checkByPattern(
                dataRecordClass,
                ContractManagementInformationFileConfigCommon.DATA_KIND_MASK_STRING)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_ITEM_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_NAME }));
    }

    // メータ設置場所ID：必須チェック
    String meterLocationId = dataRecordMap
        .get(ContractManagementInformationFileConfigMeterLocation.DATA_METER_LOCATION_ID_INDEX);
    if (CommonValidationUtil.isNull(meterLocationId)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_METER_LOCATION_ID_NAME }));

      // メータ設置場所ID：文字種別チェック（半角数字）
    } else if (meterLocationId != null
        && !CommonValidationUtil.isNumric(meterLocationId)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_METER_LOCATION_ID_NAME,
                      "半角数字" }));

      // メータ設置場所ID：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (meterLocationId != null
        && !CommonValidationUtil
            .isRangeWordByECIS(meterLocationId)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_METER_LOCATION_ID_NAME,
                      "半角数字（低圧CISシステム許容文字）" }));
      // メータ設置場所ID：数値範囲チェック
    } else if (meterLocationId != null
        && !CommonValidationUtil
            .checkRange(
                meterLocationId,
                ContractManagementInformationFileConfigMeterLocation.DATA_METER_LOCATION_ID_RANGE_MIN,
                ContractManagementInformationFileConfigMeterLocation.DATA_METER_LOCATION_ID_RANGE_MAX)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_RANGE_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_METER_LOCATION_ID_NAME,
                      ContractManagementInformationFileConfigMeterLocation.DATA_METER_LOCATION_ID_MESSAGE }));
    }

    // 需要場所住所（郵便番号）：必須チェック
    String placeAddressPostalCode = dataRecordMap
        .get(ContractManagementInformationFileConfigMeterLocation.DATA_PLACE_ADDRESS_POSTAL_CODE_INDEX);
    if (CommonValidationUtil.isNull(placeAddressPostalCode)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_PLACE_ADDRESS_POSTAL_CODE_NAME }));

      // 需要場所住所（郵便番号）：文字種別チェック（半角数字）
    } else if (placeAddressPostalCode != null
        && !CommonValidationUtil.isNumric(placeAddressPostalCode)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_PLACE_ADDRESS_POSTAL_CODE_NAME,
                      "半角数字" }));

      // 需要場所住所（郵便番号）：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (placeAddressPostalCode != null
        && !CommonValidationUtil
            .isRangeWordByECIS(placeAddressPostalCode)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_PLACE_ADDRESS_POSTAL_CODE_NAME,
                      "半角数字（低圧CISシステム許容文字）" }));

      // 需要場所住所（郵便番号）：文字列指定長チェック
    } else if (placeAddressPostalCode != null
        && !CommonValidationUtil
            .justLength(
                placeAddressPostalCode,
                ContractManagementInformationFileConfigMeterLocation.DATA_PLACE_ADDRESS_POSTAL_CODE_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_STRINGLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_PLACE_ADDRESS_POSTAL_CODE_NAME,
                      ContractManagementInformationFileConfigMeterLocation.DATA_PLACE_ADDRESS_POSTAL_CODE_LENGTH_STRING }));
    }

    // 需要場所住所（住所）：必須チェック
    String placeAddressFull = dataRecordMap
        .get(ContractManagementInformationFileConfigMeterLocation.DATA_PLACE_ADDRESS_FULL_INDEX);
    if (CommonValidationUtil.isNull(placeAddressFull)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_PLACE_ADDRESS_FULL_NAME }));

      // 需要場所住所（住所）：文字列最大長チェック
    } else if (placeAddressFull != null
        && !CommonValidationUtil
            .maxLength(
                placeAddressFull,
                ContractManagementInformationFileConfigMeterLocation.DATA_PLACE_ADDRESS_FULL_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_PLACE_ADDRESS_FULL_NAME,
                      ContractManagementInformationFileConfigMeterLocation.DATA_PLACE_ADDRESS_FULL_LENGTH_STRING }));

      // 需要場所住所（住所）：文字種別チェック（低圧CISシステム許容文字）
    } else if (placeAddressFull != null
        && !CommonValidationUtil.isRangeWordByECIS(placeAddressFull)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_PLACE_ADDRESS_FULL_NAME,
                      "低圧CISシステム許容文字" }));
    }

    // 需要場所住所（建物・部屋名）：文字種別チェック（全角）
    String placeAddressBuilding = dataRecordMap
        .get(ContractManagementInformationFileConfigMeterLocation.DATA_PLACE_ADDRESS_BUILDING_INDEX);
    if (placeAddressBuilding != null
        && !CommonValidationUtil.isZenkakuType(placeAddressBuilding)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_PLACE_ADDRESS_BUILDING_NAME }));

      // 需要場所住所（建物・部屋名）：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (placeAddressBuilding != null
        && !CommonValidationUtil
            .isRangeWordByECIS(placeAddressBuilding)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_PLACE_ADDRESS_BUILDING_NAME,
                      "全角（低圧CISシステム許容文字）" }));

      // 需要場所住所（建物・部屋名）：文字列最大長チェック
    } else if (placeAddressBuilding != null
        && !CommonValidationUtil
            .maxLength(
                placeAddressBuilding,
                ContractManagementInformationFileConfigMeterLocation.DATA_PLACE_ADDRESS_BUILDING_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_PLACE_ADDRESS_BUILDING_NAME,
                      ContractManagementInformationFileConfigMeterLocation.DATA_PLACE_ADDRESS_BUILDING_LENGTH_STRING }));
    }

    // 地点特定番号：必須チェック
    String spotNo = dataRecordMap
        .get(ContractManagementInformationFileConfigMeterLocation.DATA_SPOT_NO_INDEX);
    if (CommonValidationUtil.isNull(spotNo)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_SPOT_NO_NAME }));

      // 地点特定番号：文字種別チェック（半角英数字）
    } else if (spotNo != null
        && !CommonValidationUtil.isAlphabetNumric(spotNo)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_ALPHANUMERIC_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_SPOT_NO_NAME }));

      // 地点特定番号：文字種別チェック（半角英数字　低圧CISシステム許容文字）
    } else if (spotNo != null
        && !CommonValidationUtil.isRangeWordByECIS(spotNo)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_SPOT_NO_NAME,
                      "半角英数字（低圧CISシステム許容文字）" }));

      // 地点特定番号：文字列最大長チェック
    } else if (spotNo != null
        && !CommonValidationUtil
            .maxLength(
                spotNo,
                ContractManagementInformationFileConfigMeterLocation.DATA_SPOT_NO_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_SPOT_NO_NAME,
                      ContractManagementInformationFileConfigMeterLocation.DATA_SPOT_NO_LENGTH_STRING }));
    }

    // 需要家識別番号：文字種別チェック（半角英数字）
    String contractorIdentificationNo = dataRecordMap
        .get(ContractManagementInformationFileConfigMeterLocation.DATA_CONTRACTOR_IDENTIFICATION_NO_INDEX);
    if (contractorIdentificationNo != null
        && !CommonValidationUtil
            .isAlphabetNumric(contractorIdentificationNo)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_ALPHANUMERIC_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_CONTRACTOR_IDENTIFICATION_NO_NAME }));

      // 需要家識別番号：文字種別チェック（半角英数字　低圧CISシステム許容文字）
    } else if (contractorIdentificationNo != null
        && !CommonValidationUtil
            .isRangeWordByECIS(contractorIdentificationNo)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_CONTRACTOR_IDENTIFICATION_NO_NAME,
                      "半角英数字（低圧CISシステム許容文字）" }));

      // 需要家識別番号：文字列最大長チェック
    } else if (contractorIdentificationNo != null
        && !CommonValidationUtil
            .maxLength(
                contractorIdentificationNo,
                ContractManagementInformationFileConfigMeterLocation.DATA_CONTRACTOR_IDENTIFICATION_NO_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_CONTRACTOR_IDENTIFICATION_NO_NAME,
                      ContractManagementInformationFileConfigMeterLocation.DATA_CONTRACTOR_IDENTIFICATION_NO_LENGTH_STRING }));
    }

    // エリアコード：必須チェック
    String areaCode = dataRecordMap
        .get(ContractManagementInformationFileConfigMeterLocation.DATA_AREA_CODE_INDEX);
    if (CommonValidationUtil.isNull(areaCode)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_AREA_CODE_NAME }));
    }

    // 基本検針日：必須チェック
    String basicMeterReadingDate = dataRecordMap
        .get(ContractManagementInformationFileConfigMeterLocation.DATA_BASIC_METER_READING_DATE_INDEX);
    if (CommonValidationUtil.isNull(basicMeterReadingDate)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_BASIC_METER_READING_DATE_NAME }));

      // 基本検針日：文字種別チェック（半角数字）
    } else if (basicMeterReadingDate != null
        && !CommonValidationUtil.isNumric(basicMeterReadingDate)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_BASIC_METER_READING_DATE_NAME,
                      "半角数字" }));

      // 基本検針日：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (basicMeterReadingDate != null
        && !CommonValidationUtil
            .isRangeWordByECIS(basicMeterReadingDate)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_BASIC_METER_READING_DATE_NAME,
                      "半角数字（低圧CISシステム許容文字）" }));
      // 基本検針日：数値範囲チェック
    } else if (basicMeterReadingDate != null
        && !CommonValidationUtil
            .checkRange(
                basicMeterReadingDate,
                ContractManagementInformationFileConfigMeterLocation.DATA_BASIC_METER_READING_DATE_RANGE_MIN,
                ContractManagementInformationFileConfigMeterLocation.DATA_BASIC_METER_READING_DATE_RANGE_MAX)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_RANGE_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_BASIC_METER_READING_DATE_NAME,
                      ContractManagementInformationFileConfigMeterLocation.DATA_BASIC_METER_READING_DATE_MESSAGE }));
    }

    // 次回検針予定日：必須チェック
    String nextMeterReadingScheduledDate = dataRecordMap
        .get(ContractManagementInformationFileConfigMeterLocation.DATA_NEXT_METER_READING_SCHEDULED_DATE_INDEX);
    if (CommonValidationUtil.isNull(nextMeterReadingScheduledDate)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_NEXT_METER_READING_SCHEDULED_DATE_NAME }));

      // 次回検針予定日：日付フォーマットチェック
    } else if (nextMeterReadingScheduledDate != null
        && !CommonValidationUtil
            .checkDateFormat(
                nextMeterReadingScheduledDate,
                ContractManagementInformationFileConfigMeterLocation.DATA_NEXT_METER_READING_SCHEDULED_DATE_FORMAT)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_NEXT_METER_READING_SCHEDULED_DATE_NAME,
                      ContractManagementInformationFileConfigMeterLocation.DATA_NEXT_METER_READING_SCHEDULED_DATE_MESSAGE }));
    }

    // 前回検針日：日付フォーマットチェック
    String lastTimeMeterReadingDate = dataRecordMap
        .get(ContractManagementInformationFileConfigMeterLocation.DATA_LAST_TIME_METER_READING_DATE_INDEX);
    if (lastTimeMeterReadingDate != null
        && !CommonValidationUtil
            .checkDateFormat(
                lastTimeMeterReadingDate,
                ContractManagementInformationFileConfigMeterLocation.DATA_LAST_TIME_METER_READING_DATE_FORMAT)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_LAST_TIME_METER_READING_DATE_NAME,
                      ContractManagementInformationFileConfigMeterLocation.DATA_LAST_TIME_METER_READING_DATE_MESSAGE }));
    }

    // 送受電区分コード：必須チェック
    String transmissionCategoryCode = dataRecordMap
        .get(ContractManagementInformationFileConfigMeterLocation.DATA_TRANSMISSION_CATEGORY_CODE_INDEX);
    if (CommonValidationUtil.isNull(transmissionCategoryCode)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_TRANSMISSION_CATEGORY_CODE_NAME }));
    }

    // 自家発連携有無コード：必須チェック
    String generatorLinkageCheckCode = dataRecordMap
        .get(ContractManagementInformationFileConfigMeterLocation.DATA_GENERATOR_LINKAGE_CHECK_CODE_INDEX);
    if (CommonValidationUtil.isNull(generatorLinkageCheckCode)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_GENERATOR_LINKAGE_CHECK_CODE_NAME }));
    }

    // 供給方式コード：必須チェック
    String supplyMethodCode = dataRecordMap
        .get(ContractManagementInformationFileConfigMeterLocation.DATA_SUPPLY_METHOD_CODE_INDEX);
    if (CommonValidationUtil.isNull(supplyMethodCode)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_SUPPLY_METHOD_CODE_NAME }));
    }

    // 計器識別番号1：必須チェック
    String meterIdentificationNo1 = dataRecordMap
        .get(ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO1_INDEX);
    if (CommonValidationUtil.isNull(meterIdentificationNo1)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO1_NAME }));

      // 計器識別番号1：文字種別チェック（半角英数字）
    } else if (meterIdentificationNo1 != null
        && !CommonValidationUtil
            .isAlphabetNumric(meterIdentificationNo1)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_ALPHANUMERIC_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO1_NAME }));

      // 計器識別番号1：文字種別チェック（半角英数字　低圧CISシステム許容文字）
    } else if (meterIdentificationNo1 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(meterIdentificationNo1)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO1_NAME,
                      "半角英数字（低圧CISシステム許容文字）" }));

      // 計器識別番号1：文字列最大長チェック
    } else if (meterIdentificationNo1 != null
        && !CommonValidationUtil
            .maxLength(
                meterIdentificationNo1,
                ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO1_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO1_NAME,
                      ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO1_LENGTH_STRING }));
    }

    // 計器識別番号2：文字種別チェック（半角英数字）
    String meterIdentificationNo2 = dataRecordMap
        .get(ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO2_INDEX);
    if (meterIdentificationNo2 != null
        && !CommonValidationUtil
            .isAlphabetNumric(meterIdentificationNo2)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_ALPHANUMERIC_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO2_NAME }));

      // 計器識別番号2：文字種別チェック（半角英数字　低圧CISシステム許容文字）
    } else if (meterIdentificationNo2 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(meterIdentificationNo2)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO2_NAME,
                      "半角英数字（低圧CISシステム許容文字）" }));

      // 計器識別番号2：文字列最大長チェック
    } else if (meterIdentificationNo2 != null
        && !CommonValidationUtil
            .maxLength(
                meterIdentificationNo2,
                ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO2_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO2_NAME,
                      ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO2_LENGTH_STRING }));
    }

    // 計器識別番号3：文字種別チェック（半角英数字）
    String meterIdentificationNo3 = dataRecordMap
        .get(ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO3_INDEX);
    if (meterIdentificationNo3 != null
        && !CommonValidationUtil
            .isAlphabetNumric(meterIdentificationNo3)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_ALPHANUMERIC_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO3_NAME }));

      // 計器識別番号3：文字種別チェック（半角英数字　低圧CISシステム許容文字）
    } else if (meterIdentificationNo3 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(meterIdentificationNo3)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO3_NAME,
                      "半角英数字（低圧CISシステム許容文字）" }));

      // 計器識別番号3：文字列最大長チェック
    } else if (meterIdentificationNo3 != null
        && !CommonValidationUtil
            .maxLength(
                meterIdentificationNo3,
                ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO3_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO3_NAME,
                      ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO3_LENGTH_STRING }));
    }

    // 計器識別番号4：文字種別チェック（半角英数字）
    String meterIdentificationNo4 = dataRecordMap
        .get(ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO4_INDEX);
    if (meterIdentificationNo4 != null
        && !CommonValidationUtil
            .isAlphabetNumric(meterIdentificationNo4)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_ALPHANUMERIC_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO4_NAME }));

      // 計器識別番号4：文字種別チェック（半角英数字　低圧CISシステム許容文字）
    } else if (meterIdentificationNo4 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(meterIdentificationNo4)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO4_NAME,
                      "半角英数字（低圧CISシステム許容文字）" }));

      // 計器識別番号4：文字列最大長チェック
    } else if (meterIdentificationNo4 != null
        && !CommonValidationUtil
            .maxLength(
                meterIdentificationNo4,
                ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO4_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO4_NAME,
                      ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO4_LENGTH_STRING }));
    }

    // 計器識別番号5：文字種別チェック（半角英数字）
    String meterIdentificationNo5 = dataRecordMap
        .get(ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO5_INDEX);
    if (meterIdentificationNo5 != null
        && !CommonValidationUtil
            .isAlphabetNumric(meterIdentificationNo5)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_ALPHANUMERIC_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO5_NAME }));

      // 計器識別番号5：文字種別チェック（半角英数字　低圧CISシステム許容文字）
    } else if (meterIdentificationNo5 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(meterIdentificationNo5)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO5_NAME,
                      "半角英数字（低圧CISシステム許容文字）" }));

      // 計器識別番号5：文字列最大長チェック
    } else if (meterIdentificationNo5 != null
        && !CommonValidationUtil
            .maxLength(
                meterIdentificationNo5,
                ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO5_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO5_NAME,
                      ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO5_LENGTH_STRING }));
    }

    // 30分値収集可否・自動検針可否コード1：必須チェック
    String automaticMeterReadingCkeckCode1 = dataRecordMap
        .get(ContractManagementInformationFileConfigMeterLocation.DATA_AUTOMATIC_METER_READING_CHECK_CODE1_INDEX);
    if (CommonValidationUtil.isNull(automaticMeterReadingCkeckCode1)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_AUTOMATIC_METER_READING_CHECK_CODE1_NAME }));
    }

    // 更新回数：必須チェック
    String updateCount = dataRecordMap
        .get(ContractManagementInformationFileConfigMeterLocation.DATA_UPDATE_COUNT_INDEX);
    if (CommonValidationUtil.isNull(updateCount)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_UPDATE_COUNT_NAME }));

      // 更新回数：文字種別チェック（半角数字）
    } else if (updateCount != null
        && !CommonValidationUtil.isNumric(updateCount)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_UPDATE_COUNT_NAME,
                      "半角数字" }));

      // 更新回数：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (updateCount != null
        && !CommonValidationUtil
            .isRangeWordByECIS(updateCount)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_UPDATE_COUNT_NAME,
                      "半角数字（低圧CISシステム許容文字）" }));
      // 更新回数：数値範囲チェック
    } else if (updateCount != null
        && !CommonValidationUtil
            .checkRange(
                updateCount,
                ContractManagementInformationFileConfigMeterLocation.DATA_UPDATE_COUNT_RANGE_MIN,
                ContractManagementInformationFileConfigMeterLocation.DATA_UPDATE_COUNT_RANGE_MAX)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_RANGE_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigMeterLocation.DATA_UPDATE_COUNT_NAME,
                      ContractManagementInformationFileConfigMeterLocation.DATA_UPDATE_COUNT_MESSAGE }));
    }
    return messageList;
  }
}
