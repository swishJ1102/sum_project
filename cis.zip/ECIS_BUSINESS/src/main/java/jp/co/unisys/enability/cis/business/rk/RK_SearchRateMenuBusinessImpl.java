package jp.co.unisys.enability.cis.business.rk;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.springframework.context.MessageSource;
import org.springframework.dao.DataAccessException;

import jp.co.unisys.enability.cis.business.rk.model.RK_SearchRateMenuBasicChargeUPDetailBusinessBean;
import jp.co.unisys.enability.cis.business.rk.model.RK_SearchRateMenuRateMenuAreaBusinessBean;
import jp.co.unisys.enability.cis.business.rk.model.RK_SearchRateMenuRateMenuBusinessBean;
import jp.co.unisys.enability.cis.business.rk.model.RK_SearchRateMenuRateMenuConditionsBusinessBean;
import jp.co.unisys.enability.cis.business.rk.model.RK_SearchRateMenuRateMenuUPBusinessBean;
import jp.co.unisys.enability.cis.business.rk.model.RK_SearchRateMenuSupplementaryMenuBusinessBean;
import jp.co.unisys.enability.cis.business.rk.model.RK_SearchRateMenuSupplementaryMenuConditionsBusinessBean;
import jp.co.unisys.enability.cis.business.rk.model.RK_SearchRateMenuSupplementaryMenuUPBusinessBean;
import jp.co.unisys.enability.cis.business.rk.model.RK_SearchRateMenuUsageChargeUPDetailBusinessBean;
import jp.co.unisys.enability.cis.common.util.constants.ECISReturnCodeConstants;
import jp.co.unisys.enability.cis.dao.rk.RK_SearchRateMenuDao;
import jp.co.unisys.enability.cis.entity.rk.RK_SearchRateMenuBasicChargeUPDetailEntityBean;
import jp.co.unisys.enability.cis.entity.rk.RK_SearchRateMenuRateMenuConditionsEntityBean;
import jp.co.unisys.enability.cis.entity.rk.RK_SearchRateMenuRateMenuEntityBean;
import jp.co.unisys.enability.cis.entity.rk.RK_SearchRateMenuRateMenuUPEntityBean;
import jp.co.unisys.enability.cis.entity.rk.RK_SearchRateMenuSearchRateMenuAreaEntityBean;
import jp.co.unisys.enability.cis.entity.rk.RK_SearchRateMenuSupplementaryMenuConditionsEntityBean;
import jp.co.unisys.enability.cis.entity.rk.RK_SearchRateMenuSupplementaryMenuEntityBean;
import jp.co.unisys.enability.cis.entity.rk.RK_SearchRateMenuSupplementaryMenuUPEntityBean;
import jp.co.unisys.enability.cis.entity.rk.RK_SearchRateMenuUsageChargeUPDetailEntityBean;

/**
 * 料金メニュー検索APIビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_SearchRateMenuBusinessImpl implements RK_SearchRateMenuBusiness {

  /** 料金メニュー検索DAO（DI） */
  private RK_SearchRateMenuDao rkSearchRateMenuDao;

  /** メッセージソース(DI) */
  private MessageSource messageSource;

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.rk.RK_SearchRateMenuBusiness#
   * selectRateMenu(jp.co.unisys.enability.cis.business.rk.model.
   * RK_SearchRateMenuRateMenuConditionsBusinessBean)
   */
  @Override
  public RK_SearchRateMenuRateMenuConditionsBusinessBean selectRateMenu(
      RK_SearchRateMenuRateMenuConditionsBusinessBean rKSearchRateMenuRateMenuConditionsBusinessBean) {

    RK_SearchRateMenuRateMenuConditionsBusinessBean response = new RK_SearchRateMenuRateMenuConditionsBusinessBean();
    try {
      // 《料金メニュー検索条件EntityBean》のインスタンスを生成
      RK_SearchRateMenuRateMenuConditionsEntityBean searchConditionsEntity = new RK_SearchRateMenuRateMenuConditionsEntityBean();

      // Beanコピー
      // 売買区分コード
      searchConditionsEntity
          .setSaleCategoryCode(rKSearchRateMenuRateMenuConditionsBusinessBean
              .getSaleCategoryCode());
      // 基準日_自
      searchConditionsEntity
          .setBaseDateStart(rKSearchRateMenuRateMenuConditionsBusinessBean
              .getBaseDateStart());
      // 基準日_至
      searchConditionsEntity
          .setBaseDateEnd(rKSearchRateMenuRateMenuConditionsBusinessBean
              .getBaseDateEnd());
      // エリアコード
      searchConditionsEntity
          .setAreaCode(rKSearchRateMenuRateMenuConditionsBusinessBean
              .getAreaCode());
      // 提供モデルコード
      searchConditionsEntity
          .setProvideModelCode(rKSearchRateMenuRateMenuConditionsBusinessBean
              .getProvideModelCode());
      // 提供モデル企業コード
      searchConditionsEntity
          .setProvideModelCompanyCode(rKSearchRateMenuRateMenuConditionsBusinessBean
              .getProvideModelCompanyCode());
      // 電圧区分コード
      searchConditionsEntity.setVoltageCatCode(rKSearchRateMenuRateMenuConditionsBusinessBean
          .getVoltageCatCode());
      // 契約電力決定区分コード
      searchConditionsEntity.setCcDecisionCategoryCode(rKSearchRateMenuRateMenuConditionsBusinessBean
          .getCcDecisionCategoryCode());

      // 料金メニュー検索Dao.料金メニュー検索の呼び出し
      List<RK_SearchRateMenuSearchRateMenuAreaEntityBean> searchRateMenuAreaEntityBeanList = rkSearchRateMenuDao
          .selectRateMenu(searchConditionsEntity);

      // 検索結果のコピー
      response.setRateMenuAreaList(this
          .copyBeanEntityToBusinessSearchRateMenuArea(searchRateMenuAreaEntityBeanList));

      // ※↓の処理はBeanコピー処理内で実施
      // ---------------------------------------------------
      // 取得したリストの各要素（《料金メニュービジネスBean》）に対して、以下の処理を行う
      // 《料金メニュービジネスBean》.容量選択可能範囲を応答用の形式（カンマ区切り）に変換
      // 料金計算共通ユーティリティクラス.容量選択可能範囲分解を呼び出す。
      // 引数：《料金メニュービジネスBean》.容量選択可能範囲
      // ---------------------------------------------------

      // 《料金メニュー検索条件ビジネスBean》.リターンコードに（0000）を設定
      // メッセージは返却しない
      response.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);

    } catch (DataAccessException e) {
      // 《料金メニュー検索条件ビジネスBean》.リターンコードに（G017）を設定し、処理を終了する。
      response.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      response.setMessage(messageSource.getMessage("error.E1129", null, Locale.getDefault()));

    }

    // 結果を返却
    return response;
  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.rk.RK_SearchRateMenuBusiness#
   * selectSupplementaryMenu(jp.co.unisys.enability.cis.business.rk.model.
   * RK_SearchRateMenuSupplementaryMenuConditionsBusinessBean)
   */
  @Override
  public RK_SearchRateMenuSupplementaryMenuConditionsBusinessBean selectSupplementaryMenu(
      RK_SearchRateMenuSupplementaryMenuConditionsBusinessBean rKSearchRateMenuSupplementaryMenuConditionsBusinessBean) {

    RK_SearchRateMenuSupplementaryMenuConditionsBusinessBean response = new RK_SearchRateMenuSupplementaryMenuConditionsBusinessBean();
    try {

      // 《付帯メニュー検索条件EntityBean》のインスタンスを作成
      RK_SearchRateMenuSupplementaryMenuConditionsEntityBean searchConditionsEntity = new RK_SearchRateMenuSupplementaryMenuConditionsEntityBean();

      // Beanコピー
      // 売買区分コード
      searchConditionsEntity
          .setSaleCategoryCode(rKSearchRateMenuSupplementaryMenuConditionsBusinessBean
              .getSaleCategoryCode());
      // 基準日_自
      searchConditionsEntity
          .setBaseDateStart(rKSearchRateMenuSupplementaryMenuConditionsBusinessBean
              .getBaseDateStart());
      // 基準日_至
      searchConditionsEntity
          .setBaseDateEnd(rKSearchRateMenuSupplementaryMenuConditionsBusinessBean
              .getBaseDateEnd());
      // 提供モデルコード
      searchConditionsEntity
          .setProvideModelCode(rKSearchRateMenuSupplementaryMenuConditionsBusinessBean
              .getProvideModelCode());
      // 提供モデル企業コード
      searchConditionsEntity
          .setProvideModelCompanyCode(rKSearchRateMenuSupplementaryMenuConditionsBusinessBean
              .getProvideModelCompanyCode());

      // 料金メニュー検索Dao.付帯メニュー検索の呼び出し
      List<RK_SearchRateMenuSupplementaryMenuEntityBean> searchRateMenuSupplementaryMenuEntityBeanList = rkSearchRateMenuDao
          .selectSupplementaryMenu(searchConditionsEntity);

      // 結果のコピー
      response.setSupplementaryMenuList(this
          .copyBeanEntityToBusinessSupplementaryMenu(searchRateMenuSupplementaryMenuEntityBeanList));

      // 《料金メニュー検索条件ビジネスBean》.リターンコードに（0000）を設定
      response.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);

    } catch (DataAccessException e) {
      // 《料金メニュー検索条件ビジネスBean》.リターンコードに（G017）を設定し、処理を終了する。
      response.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      response.setMessage(messageSource.getMessage("error.E1129", null, Locale.getDefault()));

    }

    // 結果を返却
    return response;
  }

  /**
   * 料金メニュー検索DAOのsetter（DI）
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金メニュー検索DAOを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param searchRateMenuDao
   *          料金メニュー検索DAO
   */
  public void setRkSearchRateMenuDao(RK_SearchRateMenuDao searchRateMenuDao) {
    this.rkSearchRateMenuDao = searchRateMenuDao;
  }

  /**
   * メッセージソースを設定します。(DI)
   *
   * @param messageSource
   *          メッセージソース
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }

  /**
   * 料金メニューエリアエンティティBeanの内容をビジネスBeanへコピーする。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金メニューエリアエンティティBeanの内容をビジネスBeanへコピーする。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param searchRateMenuAreaEntityBeanList
   *          料金メニューエリアエンティティBean
   * @return 料金メニューエリアビジネスBean
   */
  private List<RK_SearchRateMenuRateMenuAreaBusinessBean> copyBeanEntityToBusinessSearchRateMenuArea(
      List<RK_SearchRateMenuSearchRateMenuAreaEntityBean> searchRateMenuAreaEntityBeanList) {

    List<RK_SearchRateMenuRateMenuAreaBusinessBean> retList = new ArrayList<RK_SearchRateMenuRateMenuAreaBusinessBean>(
        searchRateMenuAreaEntityBeanList.size());

    for (int i = 0; i < searchRateMenuAreaEntityBeanList.size(); i++) {
      RK_SearchRateMenuSearchRateMenuAreaEntityBean entityBean = searchRateMenuAreaEntityBeanList.get(i);
      RK_SearchRateMenuRateMenuAreaBusinessBean businessBean = new RK_SearchRateMenuRateMenuAreaBusinessBean();

      businessBean.setAreaCode(entityBean.getAreaCode());
      businessBean.setAreaName(entityBean.getAreaName());
      businessBean.setRateMenuList(this.copyBeanEntityToBusinessRateMenu(entityBean.getRateMenuList()));

      // リストに追加
      retList.add(businessBean);
    }
    return retList;
  }

  /**
   * 料金メニューエンティティBeanの内容をビジネスBeanへコピーする。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金メニューエンティティBeanの内容をビジネスBeanへコピーする。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param rateMenuList
   *          料金メニューエンティティBean
   * @return 料金メニュービジネスBean
   */
  private List<RK_SearchRateMenuRateMenuBusinessBean> copyBeanEntityToBusinessRateMenu(
      List<RK_SearchRateMenuRateMenuEntityBean> rateMenuList) {

    List<RK_SearchRateMenuRateMenuBusinessBean> retList = new ArrayList<RK_SearchRateMenuRateMenuBusinessBean>(
        rateMenuList.size());

    for (int i = 0; i < rateMenuList.size(); i++) {
      RK_SearchRateMenuRateMenuEntityBean entityBean = rateMenuList.get(i);
      RK_SearchRateMenuRateMenuBusinessBean businessBean = new RK_SearchRateMenuRateMenuBusinessBean();
      businessBean.setApplySd(entityBean.getApplySd());
      businessBean.setApplyed(entityBean.getApplyed());
      businessBean.setRateMenuId(entityBean.getRateMenuId());
      businessBean.setRateMenu(entityBean.getRateMenu());
      businessBean.setDisplayName(entityBean.getDisplayName());
      businessBean.setElLightAndPowerCatCode(entityBean.getElLightAndPowerCatCode());
      businessBean.setVoltageCategoryCode(entityBean.getVoltageCategoryCode());
      businessBean.setVoltageCategory(entityBean.getVoltageCategory());
      businessBean.setSaleCategoryCode(entityBean.getSaleCategoryCode());
      businessBean.setSaleCategory(entityBean.getSaleCategory());
      businessBean.setContractCapacityUnit(entityBean.getContractCapacityUnit());
      businessBean.setMmcFlag(entityBean.getMmcFlag());
      businessBean.setCapacitySelectableRange(entityBean.getCapacitySelectableRange());
      businessBean.setDisplayOrder(entityBean.getDisplayOrder());
      businessBean.setRateMenuUPList(this.copyBeanEntityToBusinessRateMenuUP(entityBean.getRateMenuUPList()));

      // リストに追加
      retList.add(businessBean);
    }
    return retList;
  }

  /**
   * 料金メニュー単価エンティティBeanの内容をビジネスBeanへコピーする。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金メニュー単価エンティティBeanの内容をビジネスBeanへコピーする。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param rateMenuUPList
   *          料金メニュー単価エンティティBean
   * @return 料金メニュー単価ビジネスBean
   */
  private List<RK_SearchRateMenuRateMenuUPBusinessBean> copyBeanEntityToBusinessRateMenuUP(
      List<RK_SearchRateMenuRateMenuUPEntityBean> rateMenuUPList) {

    List<RK_SearchRateMenuRateMenuUPBusinessBean> retList = new ArrayList<RK_SearchRateMenuRateMenuUPBusinessBean>(
        rateMenuUPList.size());

    for (int i = 0; i < rateMenuUPList.size(); i++) {
      RK_SearchRateMenuRateMenuUPEntityBean entityBean = rateMenuUPList.get(i);
      RK_SearchRateMenuRateMenuUPBusinessBean businessBean = new RK_SearchRateMenuRateMenuUPBusinessBean();

      businessBean.setMinimumMonthlyCharge(entityBean.getMinimumMonthlyCharge());
      businessBean.setApplyStartDate(entityBean.getApplyStartDate());
      businessBean.setApplyEndDate(entityBean.getApplyEndDate());
      businessBean.setBasicChargeUPDetailList(this.copyBeanEntityToBusinessBasicChargeUPDetail(
          entityBean.getBasicChargeUPDetailList()));
      businessBean.setUsageChargeUPDetailList(this.copyBeanEntityToBusinessUsageChargeUPDetail(
          entityBean.getUsageChargeUPDetailList()));

      // リストに追加
      retList.add(businessBean);
    }
    return retList;
  }

  /**
   * 料金単価明細エンティティBeanの内容をビジネスBeanへコピーする。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金単価明細エンティティBeanの内容をビジネスBeanへコピーする。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param basicChargeUPDetailList
   *          料金単価明細エンティティBean
   * @return 料金単価明細ビジネスBean
   */
  private List<RK_SearchRateMenuBasicChargeUPDetailBusinessBean> copyBeanEntityToBusinessBasicChargeUPDetail(
      List<RK_SearchRateMenuBasicChargeUPDetailEntityBean> basicChargeUPDetailList) {

    List<RK_SearchRateMenuBasicChargeUPDetailBusinessBean> retList = new ArrayList<RK_SearchRateMenuBasicChargeUPDetailBusinessBean>(
        basicChargeUPDetailList.size());

    for (int i = 0; i < basicChargeUPDetailList.size(); i++) {
      RK_SearchRateMenuBasicChargeUPDetailEntityBean entityBean = basicChargeUPDetailList.get(i);
      RK_SearchRateMenuBasicChargeUPDetailBusinessBean businessBean = new RK_SearchRateMenuBasicChargeUPDetailBusinessBean();

      businessBean.setContractCapacityThreshold(entityBean.getContractCapacityThreshold());
      businessBean.setUPMinCharge(entityBean.getUPMinCharge());
      businessBean.setDisplayName1(entityBean.getDisplayName1());
      businessBean.setDisplayName2(entityBean.getDisplayName2());
      businessBean.setDetailOutputOrder(entityBean.getDetailOutputOrder());
      businessBean.setBrandNo(entityBean.getBrandNo());
      businessBean.setTsCode(entityBean.getTsCode());
      businessBean.setThresholdName(entityBean.getThresholdName());
      businessBean.setDisplayOrder(entityBean.getDisplayOrder());
      businessBean.setDcecCatCode(entityBean.getDcecCatCode());

      // リストに追加
      retList.add(businessBean);
    }
    return retList;
  }

  /**
   * 従量料金単価明細エンティティBeanの内容をビジネスBeanへコピーする。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 従量料金単価明細エンティティBeanの内容をビジネスBeanへコピーする。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param usageChargeUPDetailList
   *          従量料金単価明細エンティティBean
   * @return 従量料金単価明細ビジネスBean
   */
  private List<RK_SearchRateMenuUsageChargeUPDetailBusinessBean> copyBeanEntityToBusinessUsageChargeUPDetail(
      List<RK_SearchRateMenuUsageChargeUPDetailEntityBean> usageChargeUPDetailList) {

    List<RK_SearchRateMenuUsageChargeUPDetailBusinessBean> retList = new ArrayList<RK_SearchRateMenuUsageChargeUPDetailBusinessBean>(
        usageChargeUPDetailList.size());

    for (int i = 0; i < usageChargeUPDetailList.size(); i++) {
      RK_SearchRateMenuUsageChargeUPDetailEntityBean entityBean = usageChargeUPDetailList.get(i);
      RK_SearchRateMenuUsageChargeUPDetailBusinessBean businessBean = new RK_SearchRateMenuUsageChargeUPDetailBusinessBean();

      businessBean.setThreshold(entityBean.getThreshold());
      businessBean.setUnitPrice(entityBean.getUnitPrice());
      businessBean.setDisplayName1(entityBean.getDisplayName1());
      businessBean.setDisplayName2(entityBean.getDisplayName2());
      businessBean.setDetailOutputOrder(entityBean.getDetailOutputOrder());
      businessBean.setBrandNo(entityBean.getBrandNo());
      businessBean.setTsCode(entityBean.getTsCode());
      businessBean.setThresholdName(entityBean.getThresholdName());
      businessBean.setDisplayOrder(entityBean.getDisplayOrder());
      businessBean.setDcecCatCode(entityBean.getDcecCatCode());

      // リストに追加
      retList.add(businessBean);
    }
    return retList;
  }

  /**
   * 付帯メニューエンティティBeanの内容をビジネスBeanへコピーする。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 付帯メニューエンティティBeanの内容をビジネスBeanへコピーする。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param searchRateMenuSupplementaryMenuEntityBeanList
   *          付帯メニューエンティティBean
   * @return 付帯メニュービジネスBean
   */
  private List<RK_SearchRateMenuSupplementaryMenuBusinessBean> copyBeanEntityToBusinessSupplementaryMenu(
      List<RK_SearchRateMenuSupplementaryMenuEntityBean> searchRateMenuSupplementaryMenuEntityBeanList) {

    List<RK_SearchRateMenuSupplementaryMenuBusinessBean> retList = new ArrayList<RK_SearchRateMenuSupplementaryMenuBusinessBean>(
        searchRateMenuSupplementaryMenuEntityBeanList.size());

    for (int i = 0; i < searchRateMenuSupplementaryMenuEntityBeanList.size(); i++) {
      RK_SearchRateMenuSupplementaryMenuEntityBean entityBean = searchRateMenuSupplementaryMenuEntityBeanList
          .get(i);
      RK_SearchRateMenuSupplementaryMenuBusinessBean businessBean = new RK_SearchRateMenuSupplementaryMenuBusinessBean();

      businessBean.setSupplementaryMenuId(entityBean.getSupplementaryMenuId());
      businessBean.setSupplementaryMenu(entityBean.getSupplementaryMenu());
      businessBean.setDisplayName(entityBean.getDisplayName());
      businessBean.setSupplementaryClassCode(entityBean.getSupplementaryClassCode());
      businessBean.setSupplementaryClass(entityBean.getSupplementaryClass());
      businessBean.setSupplementaryCoveredCategoryCode(entityBean.getSupplementaryCoveredCategoryCode());
      businessBean.setSupplementaryCoveredCategory(entityBean.getSupplementaryCoveredCategory());
      businessBean.setDiscountCategoryCode(entityBean.getDiscountCategoryCode());
      businessBean.setDiscountSurchargeCategory(entityBean.getDiscountSurchargeCategory());
      businessBean.setIndividualSettingFlag(entityBean.getIndividualSettingFlag());
      businessBean.setSaleCategoryCode(entityBean.getSaleCategoryCode());
      businessBean.setSaleCategory(entityBean.getSaleCategory());
      businessBean.setDisplayOrder(entityBean.getDisplayOrder());
      businessBean.setSupplementaryMenuUPList(this.copyBeanEntityToBusinessSupplementaryMenuUP(entityBean
          .getSupplementaryMenuUPList()));

      // リストに追加
      retList.add(businessBean);
    }
    return retList;
  }

  /**
   * 付帯メニュー単価エンティティBeanの内容をビジネスBeanへコピーする。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 付帯メニュー単価エンティティBeanの内容をビジネスBeanへコピーする。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param supplementaryMenuUPList
   *          付帯メニュー単価エンティティBean
   * @return 付帯メニュー単価ビジネスBean
   */
  private List<RK_SearchRateMenuSupplementaryMenuUPBusinessBean> copyBeanEntityToBusinessSupplementaryMenuUP(
      List<RK_SearchRateMenuSupplementaryMenuUPEntityBean> supplementaryMenuUPList) {

    List<RK_SearchRateMenuSupplementaryMenuUPBusinessBean> retList = new ArrayList<RK_SearchRateMenuSupplementaryMenuUPBusinessBean>(
        supplementaryMenuUPList.size());

    for (int i = 0; i < supplementaryMenuUPList.size(); i++) {
      RK_SearchRateMenuSupplementaryMenuUPEntityBean entityBean = supplementaryMenuUPList.get(i);
      RK_SearchRateMenuSupplementaryMenuUPBusinessBean businessBean = new RK_SearchRateMenuSupplementaryMenuUPBusinessBean();

      businessBean.setAmountOrRate(entityBean.getAmountOrRate());
      businessBean.setMaximumAmount(entityBean.getMaximumAmount());
      businessBean.setMinimumAmount(entityBean.getMinimumAmount());
      businessBean.setApplyStartDate(entityBean.getApplyStartDate());
      businessBean.setApplyEndDate(entityBean.getApplyEndDate());

      // リストに追加
      retList.add(businessBean);
    }
    return retList;
  }

}
