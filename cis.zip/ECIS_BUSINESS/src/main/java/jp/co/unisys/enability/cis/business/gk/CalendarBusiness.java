package jp.co.unisys.enability.cis.business.gk;

import java.util.Date;
import java.util.List;

import jp.co.unisys.enability.cis.business.gk.model.CalendarBusinessBean;

/**
 * カレンダー関連機能共通処理
 *
 * <pre>
 * <p><b>【仕様詳細】<b><p>
 * カレンダー関連機能の共通処理を実行する。
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public interface CalendarBusiness {

  /**
   * 営業期間数計算
   *
   * <pre>
   * <p><b>【仕様詳細】<b><p>
   * 1.カレンダー日付存在チェックを行う。
   *   対象期間日数を算出し、【カレンダー】より算出した日数との相違ないことを確認する。
   * 2.対象期間内の営業日数を【カレンダー】より算出する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param CalendarBusinessBean
   *          カレンダー関連機能BusinessBean カレンダー関連機能BusinessBean.事業者休日区分には以下の値が指定される。 00：事業者休日 01：金融機関休日 10：北海道エリア休日 11：東北エリア休日
   *          12：東京エリア休日 13：中部エリア休日 14：北陸エリア休日 15：関西エリア休日 16：中国エリア休日 17：四国エリア休日 18：九州エリア休日 19：沖縄エリア休日
   *
   * @return カレンダー関連機能BusinessBean
   */
  public CalendarBusinessBean calculateSalesTermNumberOfDays(
      CalendarBusinessBean requestBean);

  /**
   * 営業日付算出
   *
   * <pre>
   * <p><b>【仕様詳細】<b><p>
   * 1.カレンダー日付算出
   * 1.1.基準日と期間数より目的の日付を算出する。
   * 1.2.期間数の値によりSQLの制御行い目的の日付を【カレンダー】より算出する。
   * 2.目的の営業日付を【カレンダー】より算出を行う。
   * </pre>
   *
   * @param calendarBusinessBean
   *          カレンダー関連機能BusinessBean
   * @return カレンダー関連機能BusinessBean
   */
  public CalendarBusinessBean calculateSalesDate(
      CalendarBusinessBean requestBean);

  /**
   * 祝祭日照会
   *
   * <pre>
   * <p><b>【仕様詳細】<b><p>
   * 1.【カレンダー】より祝祭日フラグの取得を行い、その結果の返却を行う。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param CalendarBusinessBean
   *          カレンダー関連機能BusinessBean カレンダー関連機能BusinessBean.事業者休日区分には以下の値が指定される。 00：事業者休日 01：金融機関休日 10：北海道エリア休日 11：東北エリア休日
   *          12：東京エリア休日 13：中部エリア休日 14：北陸エリア休日 15：関西エリア休日 16：中国エリア休日 17：四国エリア休日 18：九州エリア休日 19：沖縄エリア休日
   * @return カレンダー関連機能BusinessBean
   */
  public CalendarBusinessBean inquiryPublicHoliday(
      CalendarBusinessBean requestBean);

  /**
   * 事業者休日照会
   *
   * <pre>
   * <p><b>【仕様詳細】<b><p>
   * 1.【カレンダー】より事業者休日フラグの取得を行い、その値の返却を行う。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param CalendarBusinessBean
   *          カレンダー関連機能BusinessBean カレンダー関連機能BusinessBean.事業者休日区分には以下の値が指定される。 00：事業者休日 01：金融機関休日 10：北海道エリア休日 11：東北エリア休日
   *          12：東京エリア休日 13：中部エリア休日 14：北陸エリア休日 15：関西エリア休日 16：中国エリア休日 17：四国エリア休日 18：九州エリア休日 19：沖縄エリア休日
   * @return カレンダー関連機能BusinessBean
   */
  public CalendarBusinessBean inquiryOperatorHoliday(
      CalendarBusinessBean requestBean);

  /**
   * 対象日リスト取得
   *
   * <pre>
   * <p><b>【仕様詳細】<b><p>
   * 1.対象日リストの取得を行い、その値の返却を行う。
   * </pre>
   *
   * @param calendarCoveredColumnName
   *          カレンダー対象列名
   * @param coveredValue
   *          対象
   * @param ymdStart
   *          年月日_自
   * @param ymdEnd
   *          年月日_至
   * @return 対象日リスト
   */
  public List<Date> selectCoveredDateList(String calendarCoveredColumnName,
      String objName, Date ymdStart, Date ymdEnd);

}
