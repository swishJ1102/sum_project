package jp.co.unisys.enability.cis.business.rk;

import jp.co.unisys.enability.cis.business.rk.model.RK_UsageLinkageCheckCheckDataBusinessBean;
import jp.co.unisys.enability.cis.business.rk.model.RK_UsageLinkageCheckTermDecisionBusinessBean;
import jp.co.unisys.enability.cis.common.util.StringConvertUtil;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;

/**
 * 地点特定番号不明チェックビジネスクラス。
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.rk.RK_UsageLinkageCheckBusiness
 */
public class RK_CheckUnknownSpotNoBusinessImpl implements
    RK_CheckFixUsageBusiness {

  /** 料金計算チェックビジネス(DI) */
  private RK_UsageLinkageCheckBusiness rkUsageLinkageCheckBusiness;

  /**
   * 地点特定番号不明チェック。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 対象の確定使用量メッセージの地点特定番号が、CISで管理されていない番号かを判定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param checkDataBusinessBean
   *          チェック対象ビジネスBean
   * @param termDecisionBusinessBean
   *          期間判定情報ビジネスBean
   * @return true:処理継続、false:処理終了
   */
  @Override
  public boolean check(
      RK_UsageLinkageCheckCheckDataBusinessBean checkDataBusinessBean,
      RK_UsageLinkageCheckTermDecisionBusinessBean termDecisionBusinessBean) {

    // 継続フラグ
    boolean continuation = true;

    // 地点特定番号が無効の場合は、TODOを登録し、【月次実績】.月次実績エラー区分コードを"エラー"で更新する
    if (ECISConstants.FLG_OFF.equals(checkDataBusinessBean.getSpotNoEffectiveFlag())) {

      // TODOメッセージを作成するパラメータ
      String[] params = {
          // 確定使用量ファイル名
          checkDataBusinessBean.getFixUsageFileName(),
          // 地点特定番号
          checkDataBusinessBean.getSpotNo(),
          // エリアコード
          checkDataBusinessBean.getAreaCode(),
          // 処理日
          StringConvertUtil.convertDateToString(
              checkDataBusinessBean.getExecuteDate(), ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
          // 検針日
          StringConvertUtil.convertDateToString(
              checkDataBusinessBean.getMeterReadingDate(), ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH) };

      // TODO登録
      rkUsageLinkageCheckBusiness.registerTodo("todo.T1020", params, null, null, null,
          checkDataBusinessBean.getSpotNo(), null);

      // 月次実績エラー区分コードをエラーで更新
      rkUsageLinkageCheckBusiness
          .updateMonthlyUsageResultError(checkDataBusinessBean);

      // 処理を継続しない
      continuation = false;
    }

    return continuation;
  }

  /**
   * 料金計算チェックビジネスを設定します。(DI)
   *
   * @param rkUsageLinkageCheckBusiness
   *          料金計算チェックビジネス
   */
  public void setRkUsageLinkageCheckBusiness(
      RK_UsageLinkageCheckBusiness rkUsageLinkageCheckBusiness) {
    this.rkUsageLinkageCheckBusiness = rkUsageLinkageCheckBusiness;
  }

}
