package jp.co.unisys.enability.cis.business.kj;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.DuplicateKeyException;

import jp.co.unisys.enability.cis.business.common.DateBusiness;
import jp.co.unisys.enability.cis.business.kj.model.AddAgentContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.AddSupplementaryContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.DeleteAgentContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.InquiryAgentContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.InquiryAgentContractorBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.InquiryAgentMeterLocationBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.InquiryPaymentBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.InquiryReserveContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.InquirySupplementaryContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.RegistAgentContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.RegistAgentMeterLocationBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.UpdateAgentContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.UpdateAgentMeterLocationBusinessBean;
import jp.co.unisys.enability.cis.common.Exception.BusinessLogicException;
import jp.co.unisys.enability.cis.common.Exception.SystemException;
import jp.co.unisys.enability.cis.common.util.DateCalculateUtil;
import jp.co.unisys.enability.cis.common.util.KJ_CommonUtil;
import jp.co.unisys.enability.cis.common.util.RK_CommonUtil;
import jp.co.unisys.enability.cis.common.util.StringConvertUtil;
import jp.co.unisys.enability.cis.common.util.ThreadContext;
import jp.co.unisys.enability.cis.common.util.constants.ECISCodeConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISKJConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISReturnCodeConstants;
import jp.co.unisys.enability.cis.entity.common.CcaUnitM;
import jp.co.unisys.enability.cis.entity.common.CcdCategoryM;
import jp.co.unisys.enability.cis.entity.common.Contract;
import jp.co.unisys.enability.cis.entity.common.ContractAddInfo;
import jp.co.unisys.enability.cis.entity.common.ContractAddInfoExample;
import jp.co.unisys.enability.cis.entity.common.ContractEndReasonM;
import jp.co.unisys.enability.cis.entity.common.ContractExample;
import jp.co.unisys.enability.cis.entity.common.ContractHist;
import jp.co.unisys.enability.cis.entity.common.ContractHistExample;
import jp.co.unisys.enability.cis.entity.common.CssCatM;
import jp.co.unisys.enability.cis.entity.common.IlcM;
import jp.co.unisys.enability.cis.entity.common.MlContractHist;
import jp.co.unisys.enability.cis.entity.common.MlContractHistExample;
import jp.co.unisys.enability.cis.entity.common.Payment;
import jp.co.unisys.enability.cis.entity.common.PhoneNoCatM;
import jp.co.unisys.enability.cis.entity.common.PsInfoCatM;
import jp.co.unisys.enability.cis.entity.common.ReserveContractHist;
import jp.co.unisys.enability.cis.entity.common.ReserveContractHistExample;
import jp.co.unisys.enability.cis.entity.common.Rm;
import jp.co.unisys.enability.cis.entity.common.RmMByPmCompany;
import jp.co.unisys.enability.cis.entity.common.RmMByPmCompanyKey;
import jp.co.unisys.enability.cis.entity.common.RmUp;
import jp.co.unisys.enability.cis.entity.common.RmUpDetail;
import jp.co.unisys.enability.cis.entity.common.RmUpDetailExample;
import jp.co.unisys.enability.cis.entity.common.RmUpExample;
import jp.co.unisys.enability.cis.entity.common.ScM;
import jp.co.unisys.enability.cis.entity.common.SplContract;
import jp.co.unisys.enability.cis.entity.common.SplContractExample;
import jp.co.unisys.enability.cis.entity.common.UpsCategoryM;
import jp.co.unisys.enability.cis.entity.common.VoltageCatM;
import jp.co.unisys.enability.cis.entity.kj.KJ_AgentContractHistoryInformationEntityBean;
import jp.co.unisys.enability.cis.entity.kj.KJ_AgentUrgeManagementInformationEntityBean;
import jp.co.unisys.enability.cis.entity.kj.KJ_ContractHistoryUpdateCountEntityBean;
import jp.co.unisys.enability.cis.entity.kj.KJ_InquiryAgentContractInformationEntityBean;
import jp.co.unisys.enability.cis.entity.kj.KJ_InquiryAgentContractorInformationEntityBean;
import jp.co.unisys.enability.cis.entity.kj.KJ_InquiryAgentMeterLocationEntityBean;
import jp.co.unisys.enability.cis.entity.kj.KJ_InquiryPaymentInformationEntityBean;
import jp.co.unisys.enability.cis.entity.kj.KJ_InquiryReserveContractInformationEntityBean;
import jp.co.unisys.enability.cis.entity.kj.KJ_SupplementaryContractBean;
import jp.co.unisys.enability.cis.entity.kj.KJ_SupplementaryContractInformationEntityBean;
import jp.co.unisys.enability.cis.entity.kj.KJ_UnitPriceDetailInformationEntityBean;
import jp.co.unisys.enability.cis.mapper.common.CcaUnitMMapper;
import jp.co.unisys.enability.cis.mapper.common.CcdCategoryMMapper;
import jp.co.unisys.enability.cis.mapper.common.ContractAddInfoMapper;
import jp.co.unisys.enability.cis.mapper.common.ContractEndReasonMMapper;
import jp.co.unisys.enability.cis.mapper.common.ContractHistMapper;
import jp.co.unisys.enability.cis.mapper.common.ContractMapper;
import jp.co.unisys.enability.cis.mapper.common.CssCatMMapper;
import jp.co.unisys.enability.cis.mapper.common.IlcMMapper;
import jp.co.unisys.enability.cis.mapper.common.MlContractHistMapper;
import jp.co.unisys.enability.cis.mapper.common.PaymentMapper;
import jp.co.unisys.enability.cis.mapper.common.PhoneNoCatMMapper;
import jp.co.unisys.enability.cis.mapper.common.PsInfoCatMMapper;
import jp.co.unisys.enability.cis.mapper.common.ReserveContractHistMapper;
import jp.co.unisys.enability.cis.mapper.common.RmMByPmCompanyMapper;
import jp.co.unisys.enability.cis.mapper.common.RmMapper;
import jp.co.unisys.enability.cis.mapper.common.RmUpDetailMapper;
import jp.co.unisys.enability.cis.mapper.common.RmUpMapper;
import jp.co.unisys.enability.cis.mapper.common.ScMMapper;
import jp.co.unisys.enability.cis.mapper.common.SplContractMapper;
import jp.co.unisys.enability.cis.mapper.common.UpsCategoryMMapper;
import jp.co.unisys.enability.cis.mapper.common.VoltageCatMMapper;
import jp.co.unisys.enability.cis.mapper.kj.AgentContractInformationCommonMapper;
import jp.co.unisys.enability.cis.mapper.kj.ContractInformationCommonMapper;
import jp.co.unisys.enability.cis.mapper.kj.MeterLocationInformationCommonMapper;
import jp.co.unisys.enability.cis.mapper.kj.PaymentInformationCommonMapper;
import jp.co.unisys.enability.cis.mapper.rk.AgentFixChargeResultInformationCommonMapper;

/**
 * 卸取次店向け契約情報ビジネス
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.kj.KJ_AgentContractInformationBusiness
 *
 *      変更履歴(kg-epj) 2016.05.23 T.Hori 障害対応JTS-117
 */
public class KJ_AgentContractInformationBusinessImpl implements
    KJ_AgentContractInformationBusiness {

  /**
   * メッセージプロパティ(DI)
   */
  private MessageSource messageSource;
  /**
   * 契約マッパー(DI)
   */
  private ContractMapper contractMapper;
  /**
   * 卸取次店向け契約情報共通マッパー(DI)
   */
  private AgentContractInformationCommonMapper contractInformationCommonMapper;
  /**
   * 契約情報共通マッパー(DI)
   */
  private ContractInformationCommonMapper contractInformationMapper;
  /**
   * 確定料金共通マッパー(DI)
   */
  private AgentFixChargeResultInformationCommonMapper fixChargeResultInformationCommonMapper;
  /**
   * 支払情報共通マッパー(DI)
   */
  private PaymentInformationCommonMapper paymentInformationCommonMapper;
  /**
   * 契約履歴マッパー(DI)
   */
  private ContractHistMapper contractHistMapper;
  /**
   * メーター設置場所契約履歴マッパー(DI)
   */
  private MlContractHistMapper mlContractHistMapper;
  /**
   * 電話番号区分マッパー(DI)
   */
  private PhoneNoCatMMapper phoneNoCatMMapper;
  /**
   * 接続送電サービス区分マスタマッパー(DI)
   */
  private CssCatMMapper cssCatMMapper;
  /**
   * 契約終了理由マスタマッパー(DI)
   */
  private ContractEndReasonMMapper contractEndReasonMMapper;
  /**
   * 契約容量単位マスタマッパー(DI)
   */
  private CcaUnitMMapper ccaUnitMMapper;
  /**
   * 個人・法人区分マスタマッパー(DI)
   */
  private IlcMMapper ilcMMapper;
  /**
   * 営業委託先マスタマッパー(DI)
   */
  private ScMMapper scMMapper;
  /**
   * 契約電力決定区分マスタマッパー(DI)
   */
  private CcdCategoryMMapper ccdCategoryMMapper;
  /**
   * 電圧区分マスタマッパー(DI)
   */
  private VoltageCatMMapper voltageCatMMapper;
  /**
   * 料金メニューマッパー(DI)
   */
  private RmMapper rmMapper;
  /**
   * 付帯契約情報マッパー(DI)
   */
  private SplContractMapper splContractMapper;
  /**
   * 提供モデル企業別料金メニューマスタマッパー(DI)
   */
  private RmMByPmCompanyMapper rmMByPmCompanyMapper;
  /**
   * 契約付加情報マッパー(DI)
   */
  private ContractAddInfoMapper contractAddInfoMapper;
  /**
   * 料金メニュー単価マスタマッパー(DI)
   */
  private RmUpMapper rmUpMapper;
  /**
   * 料金メニュー単価明細マッパー(DI)
   */
  private RmUpDetailMapper rmUpDetailMapper;
  /**
   * 料金メニュー単価マッパー(DI)
   */
  private UpsCategoryMMapper upsCategoryMMapper;
  /**
   * 支払マッパー(DI)
   */
  private PaymentMapper paymentMapper;
  /**
   * 予備契約履歴マッパー(DI)
   */
  private ReserveContractHistMapper reserveContractHistMapper;
  /**
   * 部分供給区分マスタマッパー(DI)
   */
  private PsInfoCatMMapper psInfoCatMMapper;

  /**
   * 契約者情報ビジネス(DI)
   */
  private KJ_AgentContractorInformationBusiness kjContractorInfomationBusiness;
  /**
   * メータ設置場所ビジネス(DI)
   */
  private KJ_AgentMeterLocationInformationBusiness kjMeterLocationInformationBusiness;
  /**
   * 支払情報ビジネス(DI)
   */
  private KJ_PaymentInformationBusiness kjPaymentInformationBusiness;
  /**
   * 付帯契約情報ビジネス(DI)
   */
  private KJ_SupplementaryContractInformationBusiness kjSupplementaryContractInformationBusiness;
  /**
   * 日付関連共通ビジネス(DI)
   */
  private DateBusiness dateBusiness;
  /**
   * 契約番号自動発番ビジネス(DI)
   */
  private KJ_ContractNoAutoNumberingBusiness kjContractNoAutoNumberingBusiness;
  /**
   * 予備契約情報ビジネス(DI)
   */
  private KJ_ReserveContractInformationBusiness kjReserveContractInformationBusiness;
  /**
   * ログマネジャー
   */
  private static Logger logger = LogManager.getLogger();

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.kj.
   * KJ_AgentContractInformationBusiness #inquiry(jp.co.unisys.enability.cis
   * .business.kj.model.InquiryAgentContractBusinessBean)
   */
  @Override
  public InquiryAgentContractBusinessBean inquiry(
      InquiryAgentContractBusinessBean inquiryContractBusinessBean) {

    String errorMessage = null;

    Integer id = null;
    String num = null;
    Date date = null;
    String pattern = null;

    // 契約情報照会BusinessBeanの値を取得
    Integer contractId = inquiryContractBusinessBean.getContractId();
    Integer contractorId = inquiryContractBusinessBean.getContractorId();
    Integer paymentId = inquiryContractBusinessBean.getPaymentId();
    String contractNo = inquiryContractBusinessBean.getContractNo();
    String contractorNo = inquiryContractBusinessBean.getContractorNo();
    String paymentNo = inquiryContractBusinessBean.getPaymentNo();
    Date targetDate = inquiryContractBusinessBean.getInqCoveredDate();

    try {

      errorMessage = messageSource.getMessage(KJ_CommonUtil
          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G017),
          new String[] {}, Locale.getDefault());

      // 契約者ID or 契約者番号 照会対象日付に値がある場合
      if ((contractorId != null || StringUtils.isNotEmpty(contractorNo))
          && targetDate != null && contractId == null
          && StringUtils.isEmpty(contractNo) && paymentId == null
          && StringUtils.isEmpty(paymentNo)) {

        id = contractorId;
        num = contractorNo;
        date = targetDate;
        pattern = ECISKJConstants.INQUIRY_PATTERN_1;

        // 契約者ID or 契約者番号に値がある場合
      } else if ((contractorId != null || StringUtils
          .isNotEmpty(contractorNo))
          && contractId == null
          && StringUtils.isEmpty(contractNo)
          && paymentId == null
          && StringUtils.isEmpty(paymentNo) && targetDate == null) {

        id = contractorId;
        num = contractorNo;
        pattern = ECISKJConstants.INQUIRY_PATTERN_2;
        date = dateBusiness
            .getProcessBaseDate(ECISConstants.EXEC_BASE_DATE_ONLINE);

        // 契約ID or 契約番号に値がある場合
      } else if ((contractId != null || StringUtils
          .isNotEmpty(contractNo))
          && contractorId == null
          && StringUtils.isEmpty(contractorNo)
          && paymentId == null
          && StringUtils.isEmpty(paymentNo) && targetDate == null) {

        id = contractId;
        num = contractNo;
        pattern = ECISKJConstants.INQUIRY_PATTERN_3;

        // 契約ID or 契約番号 照会対象日付に値がある場合
      } else if ((contractId != null || StringUtils
          .isNotEmpty(contractNo))
          && targetDate != null
          && contractorId == null
          && StringUtils.isEmpty(contractorNo)
          && paymentId == null
          && StringUtils.isEmpty(paymentNo)) {

        id = contractId;
        num = contractNo;
        date = targetDate;
        pattern = ECISKJConstants.INQUIRY_PATTERN_4;

        // 支払ID or 支払番号に値がある場合
      } else if ((paymentId != null || StringUtils.isNotEmpty(paymentNo))
          && contractorId == null
          && StringUtils.isEmpty(contractorNo) && contractId == null
          && StringUtils.isEmpty(contractNo) && targetDate == null) {

        id = paymentId;
        num = paymentNo;
        pattern = ECISKJConstants.INQUIRY_PATTERN_5;
        date = dateBusiness
            .getProcessBaseDate(ECISConstants.EXEC_BASE_DATE_ONLINE);

      } else {
        // その他の場合はリターンコードに（P001）を設定し返却する。
        inquiryContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P001);
        inquiryContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P001),
                new String[] {}, Locale.getDefault()));

        return inquiryContractBusinessBean;
      }
      // 《契約情報共通Mapper》.契約情報取得を呼び出す。
      // 引数のキーと値をMapに関連付ける。
      Map<String, Object> selectParam = new HashMap<String, Object>();
      selectParam.put("id", id);
      selectParam.put("num", num);
      selectParam.put("targetDate", date);
      selectParam.put("inquiryPattern", pattern);

      List<KJ_InquiryAgentContractInformationEntityBean> contractInformationList = contractInformationCommonMapper
          .selectContract(selectParam);

      if (CollectionUtils.isEmpty(contractInformationList)) {
        inquiryContractBusinessBean
            .setAgentContractInformationList(contractInformationList);
        // 正常終了 リターンコードに（0000）を設定し返却する。
        inquiryContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);
        return inquiryContractBusinessBean;
      }

      // 契約IDから契約履歴を取得
      List<Integer> contractIdList = new ArrayList<Integer>();
      for (KJ_InquiryAgentContractInformationEntityBean contract : contractInformationList) {
        contractIdList.add(contract.getContractId());
      }
      Map<String, Object> histParam = new HashMap<String, Object>();
      histParam.put("targetDate", date);
      histParam.put("contractIdList", contractIdList);
      histParam.put("inquiryPattern", pattern);

      List<KJ_AgentContractHistoryInformationEntityBean> histList = contractInformationCommonMapper
          .selectHist(histParam);

      Map<String, Object> urgeParam = new HashMap<String, Object>();
      urgeParam.put("contractIdList", contractIdList);
      // 督促管理を取得
      List<KJ_AgentUrgeManagementInformationEntityBean> urgeList = contractInformationCommonMapper
          .selectUrge(urgeParam);

      // 契約IDから契約履歴を取得
      List<String> contractIdList1 = new ArrayList<String>();
      for (KJ_InquiryAgentContractInformationEntityBean contract : contractInformationList) {
        contractIdList1.add(contract.getContractId().toString());
      }
      Map<String, Object> rateMenuParam = new HashMap<String, Object>();
      rateMenuParam.put("contractIdList", contractIdList1);
      // 料金単価明細情報を取得
      List<KJ_UnitPriceDetailInformationEntityBean> rateMenuList = contractInformationCommonMapper
          .selectIndivUpDtl(rateMenuParam);

      int contractListSize = contractInformationList.size();
      int histSize = histList.size();
      int urgeSize = urgeList.size();
      int rateMenuSize = rateMenuList.size();
      // 契約に契約履歴と督促情報を契約IDで紐付け
      for (int i = 0; i < contractListSize; i++) {
        KJ_InquiryAgentContractInformationEntityBean contract = contractInformationList
            .get(i);
        List<KJ_AgentContractHistoryInformationEntityBean> histIntoContract = new ArrayList<KJ_AgentContractHistoryInformationEntityBean>();
        List<KJ_AgentUrgeManagementInformationEntityBean> urgeIntoContract = new ArrayList<KJ_AgentUrgeManagementInformationEntityBean>();
        for (int t = 0; t < histSize; t++) {
          KJ_AgentContractHistoryInformationEntityBean hist = histList
              .get(t);
          if (contract.getContractId().equals(hist.getContractId())) {
            histIntoContract.add(hist);
          }
          List<KJ_UnitPriceDetailInformationEntityBean> rateMenuIntoContract = new ArrayList<KJ_UnitPriceDetailInformationEntityBean>();
          if (!ECISConstants.UNIT_PRICE_SETTING_CATEGORY_DEF.equals(hist.getUnitPriceSetCategoryCode())) {
            hist.setUnitPriceSetCategoryCode(ECISConstants.UNIT_PRICE_SETTING_CATEGORY_INDIV);
            for (int j = 0; j < rateMenuSize; j++) {
              KJ_UnitPriceDetailInformationEntityBean rateMenu = rateMenuList.get(j);
              if (rateMenu.getContractId().intValue() == hist.getContractId().intValue()
                  && rateMenu.getApplyStartDate().compareTo(hist.getApplyStartDate()) == 0
                  && rateMenu.getRateMenuId().equals(hist.getRateMenuId())) {
                rateMenuIntoContract.add(rateMenu);
              }
            }
          }
          hist.setUnitPriceDetailInformationList(rateMenuIntoContract);
        }
        contract.setAgentContractHistoryInformationList(histIntoContract);
        for (int k = 0; k < urgeSize; k++) {
          KJ_AgentUrgeManagementInformationEntityBean urge = urgeList
              .get(k);
          if (contract.getContractId().equals(urge.getContractId())) {
            urgeIntoContract.add(urge);
          }
        }
        contract.setAgentUrgeManagementInformationList(urgeIntoContract);
      }

      inquiryContractBusinessBean
          .setAgentContractInformationList(contractInformationList);
      // 正常終了 リターンコードに（0000）を設定し返却する。
      inquiryContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);
    } catch (NoSuchMessageException ioe) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, ioe);
      inquiryContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      inquiryContractBusinessBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
    } catch (DataAccessException e) {
      logger.error(
          messageSource.getMessage("error.E1129", null,
              Locale.getDefault()),
          e);
      // 例外が起きた場合はリターンコードに（G017）を設定し、処理を終了する。
      inquiryContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      inquiryContractBusinessBean.setMessage(errorMessage);
    }

    return inquiryContractBusinessBean;
  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.kj.
   * KJ_AgentContractInformationBusiness #regist(jp.co.unisys.enability.cis
   * .business.kj.model.RegistAgentContractBusinessBean)
   */
  @Override
  public RegistAgentContractBusinessBean regist(
      RegistAgentContractBusinessBean registContractBusinessBean) {

    String systemErrorMessage = null;
    String duplicateKeyMessage = null;

    try {
      // システムエラーメッセージ
      systemErrorMessage = messageSource.getMessage(KJ_CommonUtil
          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G017),
          new String[] {}, Locale.getDefault());
      // // 重複エラーメッセージ
      duplicateKeyMessage = messageSource.getMessage(KJ_CommonUtil
          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D023),
          new String[] {}, Locale.getDefault());

      Integer contractorId = registContractBusinessBean.getContractorId();
      Integer paymentId = registContractBusinessBean.getPaymentId();
      String contractorNo = registContractBusinessBean.getContractorNo();
      String paymentNo = registContractBusinessBean.getPaymentNo();
      // 契約開始日
      Date contractStartDate = registContractBusinessBean
          .getContractStartDate();
      // 契約終了日
      Date contractEndDate = registContractBusinessBean
          .getContractEndDate();
      // 契約終了理由コード
      String contractEndReasonCode = registContractBusinessBean
          .getContractEndReasonCode();
      // 託送契約容量単位コード
      String consignmentcontractCapacityUnitCode = registContractBusinessBean
          .getConsignmentcontractCapacityUnitCode();
      // 連絡先個人・法人区分コード
      String contactInformationinDividualLegalEntityCategoryCode = registContractBusinessBean
          .getContactInformationinDividualLegalEntityCategoryCode();
      // 連絡先電話区分コード
      String contractInformationCategoryCode = registContractBusinessBean
          .getContractInformationCategoryCode();
      // 接続送電サービス区分コード
      String connectedSupplyServiceCategoryCode = registContractBusinessBean
          .getConnectedSupplyServiceCategoryCode();
      // 営業委託先コード
      String salesConsignmentCode = registContractBusinessBean
          .getSalesConsignmentCode();
      // 電圧区分コード
      String voltageCatCode = registContractBusinessBean
          .getVoltageCatCode();
      // 契約電力決定区分コード
      String ccDecisionCategoryCode = registContractBusinessBean
          .getCcDecisionCategoryCode();
      // 部分供給区分コード
      String partialSupplyInformationCategoryCode = registContractBusinessBean
          .getPartialSupplyInformationCategoryCode();
      // 最大日付
      Date maxDate = StringConvertUtil.stringToDate(
          ECISKJConstants.APPLY_END_DATE_MAX, null);

      // コード存在チェック

      // 契約終了日がNULLでないかつ契約終了理由コードがNULLまたは空文字のいずれかでない場合
      if (contractEndDate != null
          && StringUtils.isNotEmpty(contractEndReasonCode)) {

        ContractEndReasonM endReasonResult = contractEndReasonMMapper
            .selectByPrimaryKey(contractEndReasonCode);
        // 返却値が0件の場合リターンコードに（P020）を設定し返却する。
        if (endReasonResult == null) {

          registContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P020);
          registContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P020),
                  new String[] {}, Locale.getDefault()));
          return registContractBusinessBean;
        }
        // 契約終了日が"99991231"の場合契約終了理由コードがNULLまたは空文字のいずれかでない場合リターンコード（P070）を設定する。
        if (contractEndDate.compareTo(maxDate) == 0
            && StringUtils.isNotEmpty(contractEndReasonCode)) {

          registContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P070);
          registContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P070),
                  new String[] {}, Locale.getDefault()));
          return registContractBusinessBean;
        }

      }
      // 託送契約容量単位コードがNULLまたは空文字のいずれかでない場合
      if (StringUtils.isNotEmpty(consignmentcontractCapacityUnitCode)) {

        CcaUnitM capacityUnitResult = ccaUnitMMapper
            .selectByPrimaryKey(consignmentcontractCapacityUnitCode);
        // 返却値が0件の場合リターンコードに（P028）を設定し返却する。
        if (capacityUnitResult == null) {
          registContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P028);
          registContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P028),
                  new String[] {}, Locale.getDefault()));
          return registContractBusinessBean;
        }
      }
      // 連絡先個人・法人区分コードがNULLまたは空文字のいずれかでない場合
      if (StringUtils
          .isNotEmpty(contactInformationinDividualLegalEntityCategoryCode)) {

        IlcM legalResult = ilcMMapper
            .selectByPrimaryKey(contactInformationinDividualLegalEntityCategoryCode);
        // 返却値が0件の場合リターンコードに（P021）を設定し返却する。
        if (legalResult == null) {

          registContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P021);
          registContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P021),
                  new String[] {}, Locale.getDefault()));
          return registContractBusinessBean;
        }
      }
      // 連絡先電話区分コードがNULLまたは空文字のいずれかでない場合
      if (StringUtils.isNotEmpty(contractInformationCategoryCode)) {

        PhoneNoCatM phoneResult = phoneNoCatMMapper
            .selectByPrimaryKey(contractInformationCategoryCode);
        // 返却値が0件の場合リターンコードに（P019）を設定し返却する。
        if (phoneResult == null) {

          registContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P019);
          registContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P019),
                  new String[] {}, Locale.getDefault()));
          return registContractBusinessBean;
        }
      }
      // 接続送電サービス区分コードがNULLまたは空文字のいずれかでない場合
      if (StringUtils.isNotEmpty(connectedSupplyServiceCategoryCode)) {

        CssCatM resultCssCatM = cssCatMMapper
            .selectByPrimaryKey(connectedSupplyServiceCategoryCode);
        // 返却値が0件の場合リターンコードに（P026）を設定し返却する。
        if (resultCssCatM == null) {

          registContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P027);
          registContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P027),
                  new String[] {}, Locale.getDefault()));
          return registContractBusinessBean;
        }
      }
      // 営業委託先コードがNULLまたは空文字のいずれかでない場合
      if (StringUtils.isNotEmpty(salesConsignmentCode)) {

        ScM salesConsignmentResult = scMMapper
            .selectByPrimaryKey(salesConsignmentCode);
        // 返却値が0件の場合リターンコードに（P026）を設定し返却する。
        if (salesConsignmentResult == null) {

          registContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P026);
          registContractBusinessBean.setMessage(salesConsignmentCode);
          registContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P026),
                  new String[] {}, Locale.getDefault()));
          return registContractBusinessBean;
        }
      }

      // 電圧区分コード存在チェック
      if (!checkVoltageCat(voltageCatCode)) {
        registContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P093);
        registContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P093),
                new String[] {}, Locale.getDefault()));
        return registContractBusinessBean;
      }
      // 契約電力決定区分コード存在チェック
      if (!checkCcdCategory(ccDecisionCategoryCode)) {

        registContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P094);
        registContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P094),
                new String[] {}, Locale.getDefault()));
        return registContractBusinessBean;

      }
      // 部分供給区分コード
      // 電圧区分コードが設定済かつ低圧以外の場合
      if (!StringUtils.isEmpty(voltageCatCode)
          && !ECISCodeConstants.CUSTOM_VOLTAGE_CAT_CODE_LOW_TENSION.equals(voltageCatCode)) {
        // 部分供給区分コード存在チェック
        if (!checkPsInfoCatCode(partialSupplyInformationCategoryCode)) {
          // エラーの場合、リターンコードに（P106）を設定し返却する。
          registContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P106);
          registContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P106),
                  new String[] {}, Locale.getDefault()));
          return registContractBusinessBean;
        }
        // 部分供給区分コードが未設定の場合、仕訳なしを設定
        if (StringUtils.isEmpty(partialSupplyInformationCategoryCode)) {
          registContractBusinessBean
              .setPartialSupplyInformationCategoryCode(ECISCodeConstants.PS_INFO_CAT_CODE_NOT_CATEGORIZE);
        }

      } else {
        // 電圧区分コードが未設定か低圧、または部分供給区分コードが未設定の場合、仕訳なしを設定
        registContractBusinessBean
            .setPartialSupplyInformationCategoryCode(ECISCodeConstants.PS_INFO_CAT_CODE_NOT_CATEGORIZE);
      }

      // 親エンティティ存在チェック

      // 契約者情報照会BusinessBean
      InquiryAgentContractorBusinessBean contractorBean = new InquiryAgentContractorBusinessBean();
      contractorBean.setContractorId(contractorId);
      contractorBean.setContractorNo(contractorNo);

      // 契約者情報照会
      InquiryAgentContractorBusinessBean resultContractorBean = kjContractorInfomationBusiness
          .inquiry(contractorBean);

      String contractorBeanReturnCode = resultContractorBean
          .getReturnCode();

      List<KJ_InquiryAgentContractorInformationEntityBean> contractorList = resultContractorBean
          .getAgentContractorInformationList();
      // リターンコードが“0000”以外の場合、業務例外クラスをスローする。
      if (!ECISReturnCodeConstants.RETURN_CODE_0000
          .equals(contractorBeanReturnCode)) {

        throw new BusinessLogicException(messageSource.getMessage(
            "error.E1281", new String[] {}, Locale.getDefault()),
            false);
      }
      // リターンコードが“0000”かつ返却値が0件の場合リターンコードに（D014）を設定し返却する。
      if (CollectionUtils.isEmpty(contractorList)) {

        registContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D014);
        registContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D014),
                new String[] {}, Locale.getDefault()));
        return registContractBusinessBean;
      }

      // 契約者利用不能チェック

      // 利用不能フラグが“ON”の場合（D013）を設定し返却する。
      if (checkUnavailableFlag(contractorList)) {

        registContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D013);
        registContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D013),
                new String[] {}, Locale.getDefault()));
        return registContractBusinessBean;
      }

      // メータ設置場所照会

      InquiryAgentMeterLocationBusinessBean meterLocationBean = new InquiryAgentMeterLocationBusinessBean();
      meterLocationBean.setMeterLocationId(registContractBusinessBean
          .getMeterLocationId());

      InquiryAgentMeterLocationBusinessBean resultMeterLocationBean = kjMeterLocationInformationBusiness
          .inquiry(meterLocationBean);

      List<KJ_InquiryAgentMeterLocationEntityBean> returnMlBeanList = resultMeterLocationBean
          .getMeterLocationList();
      String meterLocationBeanReturnCode = resultMeterLocationBean
          .getReturnCode();

      // リターンコードが“0000”以外の場合、業務例外クラスをスローする。
      if (!ECISReturnCodeConstants.RETURN_CODE_0000
          .equals(meterLocationBeanReturnCode)) {
        throw new BusinessLogicException(messageSource.getMessage(
            "error.E1299", new String[] {}, Locale.getDefault()),
            false);
      }
      // リターンコードが“0000”かつ返却値が0件の場合リターンコードに（P008）を設定し返却する。
      if (CollectionUtils.isEmpty(returnMlBeanList)) {
        registContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P008);
        registContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P008),
                new String[] {}, Locale.getDefault()));
        return registContractBusinessBean;
      }

      // 支払情報
      InquiryPaymentBusinessBean paymentBean = new InquiryPaymentBusinessBean();
      paymentBean.setPaymentId(paymentId);
      paymentBean.setPaymentNo(paymentNo);

      // 支払情報照会
      InquiryPaymentBusinessBean resultPayment = kjPaymentInformationBusiness
          .inquiry(paymentBean);
      String paymentBeanReturnCode = resultPayment.getReturnCode();

      List<KJ_InquiryPaymentInformationEntityBean> paymentList = resultPayment
          .getPaymentInformationList();

      // リターンコードが“0000”以外の場合、業務例外クラスをスローする。
      if (!ECISReturnCodeConstants.RETURN_CODE_0000
          .equals(paymentBeanReturnCode)) {
        throw new BusinessLogicException(messageSource.getMessage(
            "error.E1288", new String[] {}, Locale.getDefault()),
            false);
      }

      // リターンコードが“0000”かつ返却値が0件の場合リターンコードに（D018）を設定し返却する。
      if (CollectionUtils.isEmpty(paymentList)) {

        registContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D018);
        registContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D018),
                new String[] {}, Locale.getDefault()));
        return registContractBusinessBean;
      }

      // 支払情報照会した際の契約者IDチェック
      if (!contractorList.get(0).getContractorId().equals(paymentList.get(0).getContractorId())) {
        registContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D018);
        registContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D018),
                new String[] {}, Locale.getDefault()));
        return registContractBusinessBean;
      }

      // 支払有効期間チェック
      // paymentStartDate <= contractStartDate <= paymentEndDate
      if (!checkContractStartDate(paymentList, contractStartDate)) {
        // リターンコードに（G028）を設定し返却する。
        registContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G028);
        registContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G028),
                new String[] {}, Locale.getDefault()));
        return registContractBusinessBean;
      }

      // 《メータ設置場所照会EntityBean》一件目を取得する。
      KJ_InquiryAgentMeterLocationEntityBean inquiryMeterLocationEntityBean = returnMlBeanList
          .get(0);

      // 《メータ設置場所照会EntityBean》.送受電区分コードを取得する。
      String transmissionCategoryCode = inquiryMeterLocationEntityBean
          .getTransmissionCategoryCode();

      // オンライン処理基準日取得
      Date onlineDate = dateBusiness.getProcessBaseDate(ECISConstants.EXEC_BASE_DATE_ONLINE);

      // 支払方法送受電区分一致チェック
      if (!checkPaymentWayTransmissionCatCodeMatch(paymentList, contractStartDate, onlineDate, transmissionCategoryCode)) {
        // リターンコードに（G058）を設定し返却する。
        registContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G058);
        registContractBusinessBean.setMessage(messageSource.getMessage(
            KJ_CommonUtil.getMessageId(ECISReturnCodeConstants.RETURN_CODE_G058),
            new String[] {}, Locale.getDefault()));
        return registContractBusinessBean;
      }

      // 料金メニューチェック
      // 《契約情報登録BusinessBean》.料金メニューIDを取得する
      String rateMenuId = registContractBusinessBean.getChargeMenuId();

      // 提供モデルと提供モデル企業の判定
      RmMByPmCompanyKey keyExample = new RmMByPmCompanyKey();
      // 《契約情報登録BusinessBean》.料金メニューIDを設定する
      keyExample.setRmId(rateMenuId);
      // 《契約者情報照会EntityBean》.提供モデルコードを設定する
      keyExample.setPmCode(contractorList.get(0).getProvideModelCode());
      // 《契約者情報照会EntityBean》.提供モデル企業コードを設定する。
      keyExample.setPmCompanyCode(contractorList.get(0)
          .getProvideModelCompanyCode());
      // 提供モデル企業別料金メニューマスタ情報を検索する。
      RmMByPmCompany rmMByPmCompany = rmMByPmCompanyMapper
          .selectByPrimaryKey(keyExample);

      // 取得結果判定、返却結果がNULLの場合、リターンコード（G038）を返却する。
      if (rmMByPmCompany == null) {
        registContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G038);
        registContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G038),
                new String[] {}, Locale.getDefault()));
        return registContractBusinessBean;
      }

      // 料金メニュー取得
      Rm rateMenu = rmMapper.selectByPrimaryKey(rateMenuId);
      // 返却値が0件の場合リターンコードに（D003）を設定し返却する。
      if (rateMenu == null) {
        registContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D003);
        registContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D003),
                new String[] {}, Locale.getDefault()));
        return registContractBusinessBean;
      }

      // 電圧区分と料金メニュー整合性チェック
      if (!checkRmAndVoltageCat(voltageCatCode, ccDecisionCategoryCode, rateMenuId)) {
        registContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P095);
        registContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P095),
                new String[] {rateMenuId, voltageCatCode, ccDecisionCategoryCode },
                Locale.getDefault()));
        return registContractBusinessBean;
      }

      // 単価設定区分のチェック及び、単価明細のチェック
      String upCatCode = registContractBusinessBean.getUpCatCode();
      // 単価設定区分コード存在チェック
      if (!checkUpCat(upCatCode)) {
        registContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P092);
        registContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P092),
                new String[] {}, Locale.getDefault()));
        return registContractBusinessBean;
      }
      // 料金メニュー単価明細存在チェック
      Date contractSd = registContractBusinessBean.getContractStartDate();
      // 料金メニュー単価明細リスト
      List<RmUpDetail> rmUpdetail = registContractBusinessBean.getRmUpDetailList();
      List<String> checkRmUpDetail = checkRmUpDetail(upCatCode, rateMenuId, contractSd, rmUpdetail);
      if (checkRmUpDetail.size() != 0) {
        String[] params = {
            // 料金メニューID
            rateMenuId,
            // DCEC区分
            checkRmUpDetail.get(0),
            // 時間帯コード
            checkRmUpDetail.get(1),
            // 枝番
            checkRmUpDetail.get(2),
        };
        registContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P091);
        registContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P091),
                params, Locale.getDefault()));
        return registContractBusinessBean;
      }

      // エリアコードチェック
      // 《メータ設置場所照会EntityBean》.エリアコードが《料金メニュー》.エリアコードと一致しない場合、
      // リターンコードに（G036）を設定し返却する。
      if (!inquiryMeterLocationEntityBean.getAreaCode().equals(
          rateMenu.getAreaCode())) {
        registContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G036);
        registContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G036),
                new String[] {}, Locale.getDefault()));
        return registContractBusinessBean;
      }

      // 売買区分コードチェック
      // 《料金メニュー》.売買区分コードを取得する。
      String saleCatCode = rateMenu.getSaleCatCode();

      // 送受電区分コードが"1:送電" かつ 売買区分コードが"2:買電"場合、
      // または 送受電区分コードが"2:受電" かつ 売買区分コードが"1:売電"場合、
      // リターンコードに（G037）を設定し返却する。
      if ((ECISCodeConstants.TRANSMISSION_CATEGORY_CODE_TRANSMISSION
          .equals(transmissionCategoryCode)
          && ECISCodeConstants.SALE_CATEGORY_PURCHASING
              .equals(saleCatCode))
          || (ECISCodeConstants.TRANSMISSION_CATEGORY_CODE_RECEIVING
              .equals(transmissionCategoryCode)
              && ECISCodeConstants.SALE_CATEGORY_SELLING
                  .equals(saleCatCode))) {
        registContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G037);
        registContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G037),
                new String[] {}, Locale.getDefault()));
        return registContractBusinessBean;
      }

      // 適用期間チェック
      // 《契約情報登録BusinessBean》.契約開始日が《料金メニュー》.適用終了日より後の場合、
      // リターンコードに（G039）を設定し返却する。
      if (registContractBusinessBean.getContractStartDate().after(
          rateMenu.getApplyEd())) {
        registContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G039);
        registContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G039),
                new String[] {}, Locale.getDefault()));
        return registContractBusinessBean;
      }
      // 《契約情報登録BusinessBean》.契約終了日がNULLではない
      // かつ 《契約情報登録BusinessBean》.契約終了日が《料金メニュー》.適用開始日より前の場合、
      // リターンコードに（G039）を設定し返却する。
      if (registContractBusinessBean.getContractEndDate() != null
          && registContractBusinessBean.getContractEndDate().before(
              rateMenu.getApplySd())) {
        registContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G039);
        registContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G039),
                new String[] {}, Locale.getDefault()));
        return registContractBusinessBean;
      }

      // 契約電力決定区分がNULLまだは協議制の場合（APIから来た場合はNULL）
      if (ccDecisionCategoryCode == null
          || ECISCodeConstants.CONTRACT_CAPACITY_DECISION_CATEGORY_CODE_DISCUSSIONS.equals(
              ccDecisionCategoryCode)) {
        // 契約容量チェック
        String capacityUnit = rateMenu.getCcaUnit();
        BigDecimal capacity = registContractBusinessBean.getContractCapacity();

        // 契約容量単位がNULLまたは空文字いずれかでない場合
        if (StringUtils.isNotEmpty(capacityUnit) && capacity == null) {
          // 契約容量がNULLの場合リターンコードにに（P065）を設定し返却する。

          registContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P065);
          registContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P065),
                  new String[] {}, Locale.getDefault()));
          return registContractBusinessBean;

        }
        // 契約容量単位がNULLまたは空文字の場合
        if (StringUtils.isEmpty(capacityUnit) && capacity != null) {
          // 契約容量がNULLでない場合リターンこードにに（P064）を設定し返却する。

          registContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P064);
          registContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P064),
                  new String[] {}, Locale.getDefault()));
          return registContractBusinessBean;

        }

        // 契約容量選択可能範囲チェック
        if (capacity != null) {
          boolean result = RK_CommonUtil.checkContractCapacity(
              String.valueOf(capacity),
              rateMenu.getCapacitySelectableRange());
          // 返却値が“false”の場合リターンコードに（G006）を設定し返却する。
          if (!result) {

            registContractBusinessBean
                .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G006);
            registContractBusinessBean
                .setMessage(messageSource.getMessage(
                    KJ_CommonUtil
                        .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G006),
                    new String[] {}, Locale.getDefault()));
            return registContractBusinessBean;
          }
        }
      }
      // メータ設置場所契約履歴情報重複チェック

      Map<String, Object> meterLocationHistRegistMap = new HashMap<String, Object>();

      meterLocationHistRegistMap.put("meterLocationId",
          registContractBusinessBean.getMeterLocationId());
      meterLocationHistRegistMap.put("coveredDate", contractStartDate);

      int meterLocationHistCount = contractInformationCommonMapper
          .countByMeterLocationContractHistory(meterLocationHistRegistMap);

      // 返却値が1件以上の場合リターンコードに（D024）を設定し返却する。
      if (meterLocationHistCount >= 1) {

        registContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D024);
        registContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D024),
                new String[] {}, Locale.getDefault()));
        return registContractBusinessBean;
      }

      // 実量歴必須フラグ
      if (StringUtils.isEmpty(registContractBusinessBean.getRealQuantityNeed())) {
        registContractBusinessBean.setRealQuantityNeed(ECISCodeConstants.ACTUAL_RECORD_REQUIRED_FLAG_OFF);
      }

      // 実量歴取込済フラグ
      if (StringUtils.isEmpty(registContractBusinessBean.getRealQuantityImportCompleteFlag())) {
        registContractBusinessBean.setRealQuantityImportCompleteFlag(
            ECISKJConstants.ACTUAL_RECORD_IMPORT_FLAG_OFF);
      }
      // 電圧区分コード
      if (StringUtils.isEmpty(registContractBusinessBean.getVoltageCatCode())) {
        registContractBusinessBean.setVoltageCatCode(
            ECISCodeConstants.CUSTOM_VOLTAGE_CAT_CODE_LOW_TENSION);
      }

      // 契約電力決定区分コード
      if (StringUtils.isEmpty(registContractBusinessBean.getCcDecisionCategoryCode())) {
        registContractBusinessBean.setCcDecisionCategoryCode(
            ECISCodeConstants.CONTRACT_CAPACITY_DECISION_CATEGORY_CODE_DISCUSSIONS);
      }

      // 単価設定区分コード
      if (StringUtils.isEmpty(registContractBusinessBean.getUpCatCode())) {
        registContractBusinessBean.setUpCatCode(ECISConstants.UNIT_PRICE_SETTING_CATEGORY_DEF);
      }

      // コンテキスト・ユーザID
      String contextUserId = ThreadContext.getRequestThreadContext()
          .get(ECISConstants.USER_ID_KEY).toString();
      // コンテキスト.モジュールコード
      String contextModuleCode = ThreadContext.getRequestThreadContext()
          .get(ECISConstants.CLASS_NAME_KEY).toString();
      // 契約番号自動発番ビジネスを呼び出す。
      kjContractNoAutoNumberingBusiness.autoNumbering(registContractBusinessBean);
      // リターンコードチェック
      if (!StringUtils.isEmpty(registContractBusinessBean.getReturnCode())) {
        // リターンコードが空かNULLでない場合、返却する。
        return registContractBusinessBean;
      }
      Contract contract = createRegistContract(
          registContractBusinessBean, contractorList.get(0)
              .getContractorId(),
          paymentList.get(0)
              .getPaymentId(),
          maxDate, contextUserId,
          contextModuleCode);
      // 契約登録 新しい契約IDを取得
      contractMapper.insertBySequence(contract);
      Integer newContractId = contract.getContractId();

      // 契約付加情報登録
      ContractAddInfo contractAddInfo = createRegistContractAddInfo(
          registContractBusinessBean, newContractId, contextUserId,
          contextModuleCode);
      // 契約付加登録
      contractAddInfoMapper.insert(contractAddInfo);

      // 契約履歴登録
      ContractHist history = createContractHistory(
          registContractBusinessBean, newContractId, maxDate,
          rateMenu.getCcaUnit(), rateMenu.getRmId(), contextUserId,
          contextModuleCode);
      contractHistMapper.insert(history);

      // メータ設置場所契約履歴情報登録
      MlContractHist mlHistory = new MlContractHist();
      // 契約ID
      mlHistory.setContractId(newContractId);
      // 適用開始日
      mlHistory.setApplySd(contractStartDate);
      Timestamp systemTime = new Timestamp(System.currentTimeMillis());

      mlHistory.setMlId(registContractBusinessBean.getMeterLocationId());
      mlHistory.setUpdateCount(0);
      mlHistory.setCreateTime(systemTime);
      mlHistory.setOnlineUpdateTime(systemTime);
      mlHistory.setOnlineUpdateUserId(contextUserId);
      mlHistory.setOnlineUpdateTime(systemTime);
      mlHistory.setUpdateTime(systemTime);
      mlHistory.setUpdateModuleCode(contextModuleCode);
      mlContractHistMapper.insert(mlHistory);

      // 単価設定区分コードが"indiv"(定数.単価設定区分コード：個別単価)の場合、料金メニュー単価と料金メニュー単価明細を登録する。
      if (ECISConstants.UNIT_PRICE_SETTING_CATEGORY_INDIV.equals(upCatCode)) {

        // 料金メニュー単価を登録する。
        RmUp rmUp = createRmUp(
            registContractBusinessBean,
            contextUserId,
            newContractId,
            contextModuleCode,
            rateMenu.getRmId());
        rmUpMapper.insert(rmUp);

        // 料金メニュー単価明細を登録する。
        List<RmUpDetail> rmUpdetailList = registContractBusinessBean.getRmUpDetailList();
        for (RmUpDetail upCatMap : rmUpdetailList) {

          RmUpDetail rmUpDetail = createRmUpDetail(
              registContractBusinessBean,
              contextUserId,
              newContractId,
              contextModuleCode,
              upCatMap,
              rateMenu.getRmId());

          rmUpDetailMapper.insert(rmUpDetail);
        }

      }
      registContractBusinessBean.setContractId(newContractId);
      // 正常終了
      registContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);
    } catch (DuplicateKeyException duplicateKeyException) {
      logger.error(
          messageSource.getMessage("error.E1129", null,
              Locale.getDefault()),
          duplicateKeyException);
      // 重複例外クラス
      registContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D023);
      registContractBusinessBean.setMessage(duplicateKeyMessage);
    } catch (DataIntegrityViolationException dataIntegrityViolationException) {
      logger.error(
          messageSource.getMessage("error.E1129", null,
              Locale.getDefault()),
          dataIntegrityViolationException);
      // 制約違反例外クラス
      registContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D023);
      registContractBusinessBean.setMessage(duplicateKeyMessage);
    } catch (BusinessLogicException businessLogicException) {
      logger.error(
          messageSource.getMessage("error.E1129", null,
              Locale.getDefault()),
          businessLogicException);
      // 業務例外クラス
      registContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      registContractBusinessBean.setMessage(systemErrorMessage);
    } catch (NoSuchMessageException ioe) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, ioe);
      registContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      registContractBusinessBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
    } catch (DataAccessException e) {
      logger.error(
          messageSource.getMessage("error.E1129", null,
              Locale.getDefault()),
          e);
      registContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      registContractBusinessBean.setMessage(systemErrorMessage);
    }
    return registContractBusinessBean;
  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.kj.
   * KJ_AgentContractInformationBusiness #update(jp.co.unisys.enability.cis
   * .business.kj.model.UpdateAgentContractBusinessBean)
   */
  @Override
  public UpdateAgentContractBusinessBean update(
      UpdateAgentContractBusinessBean updateContractBusinessBean) {

    final int CONTRACT_CANCEL_FLAG_ON = 1;
    final int CONTRACT_CANCEL_FLAG_OFF = 0;

    String errorMessage = null;

    try {

      errorMessage = messageSource.getMessage(KJ_CommonUtil
          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G017),
          new String[] {}, Locale.getDefault());
      // 最大日付
      Date maxDate = StringConvertUtil.stringToDate(
          ECISKJConstants.APPLY_END_DATE_MAX, null);
      // オンライン処理基準日
      Date onlineDate = dateBusiness
          .getProcessBaseDate(ECISConstants.EXEC_BASE_DATE_ONLINE);

      // コンテキスト・ユーザID
      String contextUserId = ThreadContext.getRequestThreadContext()
          .get(ECISConstants.USER_ID_KEY).toString();
      // コンテキスト.モジュールコード
      String contextModuleCode = ThreadContext.getRequestThreadContext()
          .get(ECISConstants.CLASS_NAME_KEY).toString();

      Integer contractId = updateContractBusinessBean.getContractId();
      String contractNo = updateContractBusinessBean.getContractNo();
      String chargeMenuId = updateContractBusinessBean.getChargeMenuId();

      // 適用開始日
      Date applyStartDate = updateContractBusinessBean
          .getApplyStartDate();
      // 契約終了日
      Date contractEndDate = updateContractBusinessBean
          .getContractEndDate();
      // 契約終了理由コード
      String contractEndReasonCode = updateContractBusinessBean
          .getContractEndReasonCode();
      // 連絡先個人・法人区分コード
      String contactInformationinDividualLegalEntityCategoryCode = updateContractBusinessBean
          .getContactInformationinDividualLegalEntityCategoryCode();
      // 連絡先電話区分コード
      String informationCategoryCode = updateContractBusinessBean
          .getContractInformationCategoryCode();
      // 接続送電サービス区分コード
      String connectedSupplyServiceCategoryCode = updateContractBusinessBean
          .getConnectedSupplyServiceCategoryCode();
      // 託送契約容量単位コード
      String consignmentcontractCapacityUnitCode = updateContractBusinessBean
          .getConsignmentcontractCapacityUnitCode();
      // 営業委託先コード
      String salesConsignmentCode = updateContractBusinessBean
          .getSalesConsignmentCode();
      // 電圧区分コード
      String voltageCatCode = updateContractBusinessBean
          .getVoltageCatCode();
      // 契約電力決定区分コード
      String ccDecisionCategoryCode = updateContractBusinessBean
          .getCcDecisionCategoryCode();
      // 単価設定区分コード
      String upCatCode = updateContractBusinessBean.getUpCatCode();
      // 部分供給区分コード
      String partialSupplyInformationCategoryCode = updateContractBusinessBean
          .getPartialSupplyInformationCategoryCode();

      // コード存在チェック

      // 契約終了日がNULLでなく"99991231"以外であり契約終了理由コードがNULLまたは空文字のいずれかでない場合
      if (contractEndDate != null
          && contractEndDate.compareTo(maxDate) != 0
          && StringUtils.isNotEmpty(contractEndReasonCode)) {

        ContractEndReasonM endReasonResult = contractEndReasonMMapper
            .selectByPrimaryKey(contractEndReasonCode);
        // 返却値が0件の場合リターンコードに（P020）を設定し返却する。
        if (endReasonResult == null) {

          updateContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P020);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P020),
                  new String[] {}, Locale.getDefault()));
          return updateContractBusinessBean;
        }
      }
      // 連絡先個人・法人区分コードがNULLまたは空文字のいずれかでない場合
      if (StringUtils
          .isNotEmpty(contactInformationinDividualLegalEntityCategoryCode)) {

        IlcM legalResult = ilcMMapper
            .selectByPrimaryKey(contactInformationinDividualLegalEntityCategoryCode);
        // 返却値が0件の場合リターンコードに（P021）を設定し返却する。
        if (legalResult == null) {

          updateContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P021);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P021),
                  new String[] {}, Locale.getDefault()));
          return updateContractBusinessBean;
        }
      }
      // 連絡先電話区分コードがNULLまたは空文字のいずれかでない場合
      if (StringUtils.isNotEmpty(informationCategoryCode)) {

        PhoneNoCatM phoneResult = phoneNoCatMMapper
            .selectByPrimaryKey(informationCategoryCode);
        // 返却値が0件の場合リターンコードに（P019）を設定し返却する。
        if (phoneResult == null) {

          updateContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P019);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P019),
                  new String[] {}, Locale.getDefault()));
          return updateContractBusinessBean;
        }
      }
      // 接続送電サービス区分コードがNULLまたは空文字のいずれかでない場合
      if (StringUtils.isNotEmpty(connectedSupplyServiceCategoryCode)) {

        CssCatM cssCatMResult = cssCatMMapper
            .selectByPrimaryKey(connectedSupplyServiceCategoryCode);
        // 返却値が0件の場合リターンコードに（P027）を設定し返却する。
        if (cssCatMResult == null) {

          updateContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P027);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P027),
                  new String[] {}, Locale.getDefault()));
          return updateContractBusinessBean;
        }
      }
      CcaUnitM consignmentCapacityUnitResult = null;
      // 託送契約容量単位コードが空文字の場合空文字の場合空文字を入れる
      String consignmentCapacityUnit = null;
      if (ECISKJConstants.EMPTY_STRING
          .equals(consignmentcontractCapacityUnitCode)) {
        consignmentCapacityUnit = ECISKJConstants.EMPTY_STRING;
      }
      if (StringUtils.isNotEmpty(consignmentcontractCapacityUnitCode)) {
        // 託送契約容量単位コードがNULLまたは空文字のいずれかでない場合
        consignmentCapacityUnitResult = ccaUnitMMapper
            .selectByPrimaryKey(consignmentcontractCapacityUnitCode);
        if (consignmentCapacityUnitResult == null) {
          // 返却値が0件の場合リターンコードに（P028）を設定し返却する。
          updateContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P028);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P028),
                  new String[] {}, Locale.getDefault()));
          return updateContractBusinessBean;
        }
        consignmentCapacityUnit = consignmentCapacityUnitResult
            .getCcaUnitCode();
      }
      if (StringUtils.isNotEmpty(salesConsignmentCode)) {
        // 営業委託先コードがNULLまたは空文字のいずれかでない場合
        ScM salesConsignmentResult = scMMapper
            .selectByPrimaryKey(salesConsignmentCode);
        if (salesConsignmentResult == null) {
          // 返却値が0件の場合リターンコードに（P026）を設定し返却する。
          updateContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P026);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P026),
                  new String[] {}, Locale.getDefault()));
          return updateContractBusinessBean;
        }
      }
      // 電圧区分コード存在チェック
      if (!checkVoltageCat(voltageCatCode)) {
        updateContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P093);
        updateContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P093),
                new String[] {}, Locale.getDefault()));
        return updateContractBusinessBean;

      }
      // 契約電力決定区分コード存在チェック
      if (!checkCcdCategory(ccDecisionCategoryCode)) {
        updateContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P094);
        updateContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P094),
                new String[] {}, Locale.getDefault()));
        return updateContractBusinessBean;

      }
      // 部分供給区分コード
      // 電圧区分が低圧以外（電圧区分が未設定含む）の場合
      if (!ECISCodeConstants.CUSTOM_VOLTAGE_CAT_CODE_LOW_TENSION.equals(voltageCatCode)) {
        // 部分供給区分コード存在チェック
        if (!checkPsInfoCatCode(partialSupplyInformationCategoryCode)) {
          // エラーの場合、リターンコードに（P106）を設定し返却する。
          updateContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P106);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P106),
                  new String[] {}, Locale.getDefault()));
          return updateContractBusinessBean;
        }
      } else {
        // 電圧区分が低圧の場合、固定で仕訳なしを設定
        updateContractBusinessBean
            .setPartialSupplyInformationCategoryCode(ECISCodeConstants.PS_INFO_CAT_CODE_NOT_CATEGORIZE);
      }
      // 契約情報存在チェック
      InquiryAgentContractBusinessBean param = new InquiryAgentContractBusinessBean();

      param.setContractId(contractId);
      param.setContractNo(contractNo);

      InquiryAgentContractBusinessBean inquryContractResult = inquiry(param);
      String contractReturnCode = inquryContractResult.getReturnCode();

      List<KJ_InquiryAgentContractInformationEntityBean> inquryContractList = inquryContractResult
          .getAgentContractInformationList();

      // リターンコードが“0000”以外の場合、業務例外クラスをスローする
      if (!ECISReturnCodeConstants.RETURN_CODE_0000
          .equals(contractReturnCode)) {
        throw new BusinessLogicException(messageSource.getMessage(
            "error.E1285", new String[] {}, Locale.getDefault()),
            false);
      }
      // リターンコードが“0000”かつ返却値が0件の場合リターンコードに（P005）を設定し返却する。
      if (CollectionUtils.isEmpty(inquryContractList)) {

        updateContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P005);
        updateContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P005),
                new String[] {}, Locale.getDefault()));
        return updateContractBusinessBean;
      }

      // 電圧区分変更チェック
      if (!checkChangeVoltageCat(voltageCatCode, inquryContractList.get(0)
          .getContractId())) {
        updateContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P107);
        updateContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P107),
                new String[] {}, Locale.getDefault()));
        return updateContractBusinessBean;

      }

      // 契約終了状態判定のため、算定期間チェックを行う。
      Map<String, Object> exampleMap = new HashMap<String, Object>();
      exampleMap.put("contractId", inquryContractList.get(0)
          .getContractId());
      exampleMap.put("coveredDate", inquryContractList.get(0)
          .getContractEndDate());
      exampleMap
          .put("flg",
              ECISKJConstants.INQUIRY_FIX_CHANGE_RESULT_INFOEMATION_FLG_TWO);
      int resultCount = fixChargeResultInformationCommonMapper
          .countByFixChargeResult(exampleMap);
      // 結果が1件以上の場合リターンコードに（D025）を設定し返却する
      if (resultCount >= 1) {
        updateContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D025);
        updateContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D025),
                new String[] {}, Locale.getDefault()));
        return updateContractBusinessBean;
      }

      // 適用開始日のリスト中に適用開始日より未来日が存在した場合リターンコードに（G001）を設定し返却する
      if (isFeature(inquryContractList, applyStartDate)) {

        updateContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G001);
        updateContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G001),
                new String[] {}, Locale.getDefault()));
        return updateContractBusinessBean;
      }

      // 最新情報を取得
      KJ_AgentContractHistoryInformationEntityBean kjAgentContractHistInfoEntityBean = inquryContractList.get(0)
          .getAgentContractHistoryInformationList().get(0);

      // 適用開始日リストの最新
      Date latestApplyDate = kjAgentContractHistInfoEntityBean.getApplyStartDate();

      // 変数.履歴更新フラグにfalseを指定。
      boolean histUpdateFlag = false;

      // 《契約情報照会BusinessBean》.適用開始日リストの最新日と、《契約情報更新BusinessBean》.適用開始日が同日の場合、
      // 以下のチェックを実行する。
      if (latestApplyDate.compareTo(updateContractBusinessBean.getApplyStartDate()) == 0) {

        // 《契約情報更新BusinessBean》.料金メニューIDが更新対象かつ《契約履歴情報EntityBean》.料金メニューIDと一致しない場合、
        // 変数.履歴情報更新フラグにtrueを設定する。
        if (updateContractBusinessBean.getChargeMenuId() != null
            && !updateContractBusinessBean.getChargeMenuId().equals(
                StringUtils.defaultString(kjAgentContractHistInfoEntityBean.getRateMenuId()))) {
          histUpdateFlag = true;
        }
        // 《契約情報更新BusinessBean》.契約容量が更新対象かつ《契約履歴情報EntityBean》.契約容量が一致しない場合、
        // 変数.履歴情報更新フラグにtrueを設定する。
        if (ECISConstants.FLG_OFF.equals(updateContractBusinessBean.getContractCapacityNoUpdFlag())) {
          // 契約容量がnullまたはnot nullで判定を変更する。
          if (updateContractBusinessBean.getContractCapacity() == null
              && kjAgentContractHistInfoEntityBean.getContractCapacity() != null) {
            histUpdateFlag = true;
          }
          if (updateContractBusinessBean.getContractCapacity() != null
              && kjAgentContractHistInfoEntityBean.getContractCapacity() == null) {
            histUpdateFlag = true;
          } else if (updateContractBusinessBean.getContractCapacity() != null
              && updateContractBusinessBean.getContractCapacity().compareTo(
                  kjAgentContractHistInfoEntityBean.getContractCapacity()) != 0) {
            histUpdateFlag = true;
          }
        }
        // 《契約情報更新BusinessBean》.契約変更理由が更新対象かつ《契約履歴情報EntityBean》.契約変更理由が一致しない場合、
        // 変数.履歴情報更新フラグにtrueを設定する。
        if (updateContractBusinessBean.getContractChangeReason() != null
            && !updateContractBusinessBean.getContractChangeReason().equals(
                StringUtils
                    .defaultString(kjAgentContractHistInfoEntityBean.getContractChangeReason()))) {
          histUpdateFlag = true;
        }

        // 変数.履歴情報更新フラグがfalse、かつ《契約情報更新BusinessBean》.単価設定区分コードが設定されている場合、以下の処理を行う。
        if (histUpdateFlag == false && updateContractBusinessBean.getUpCatCode() != null) {

          // 《契約履歴情報EntityBean》.単価設定区分コードが一致しない場合、変数.履歴情報更新フラグにtrueを設定する。
          if (!updateContractBusinessBean.getUpCatCode().equals(
              kjAgentContractHistInfoEntityBean.getUnitPriceSetCategoryCode())) {
            histUpdateFlag = true;

          } else if (ECISConstants.UNIT_PRICE_SETTING_CATEGORY_INDIV.equals(
              updateContractBusinessBean.getUpCatCode())) {
            // 《契約情報更新BusinessBean》.単価設定区分コードが個別単価である場合、単価の変更有無を判定する。

            // 変更前料金単価明細情報リスト
            List<KJ_UnitPriceDetailInformationEntityBean> beforeRmUpDetailList = kjAgentContractHistInfoEntityBean
                .getUnitPriceDetailInformationList();

            // 変更後料金単価
            RmUp updateRmUp = updateContractBusinessBean.getRmUp();

            /*
             *  《契約履歴情報EntityBean》.《料金メニュー単価》.最低料金単価が設定されている、
             *  かつ契約履歴情報EntityBean.料金単価明細情報リストの1件目の要素.最低料金単価が一致しない場合、
             *  変数.履歴情報更新フラグにtrueを設定する。
             */
            if (updateRmUp.getMmc() != null
                && !updateRmUp.getMmc().equals(beforeRmUpDetailList.get(0).getMmc())) {
              histUpdateFlag = true;

            } else {
              // 上記以外の場合、他の単価の変更有無を判定する。

              // 契約情報更新BusinessBean.料金メニュー単価明細リストの要素数分繰り返し
              for (RmUpDetail updateRmUpDetail : updateContractBusinessBean.getRmUpDetailList()) {

                // 契約履歴情報EntityBean.料金単価明細情報リストの要素数分繰り返し
                for (KJ_UnitPriceDetailInformationEntityBean beforeRmUpDetail : beforeRmUpDetailList) {

                  if (updateRmUpDetail.getRmId().equals(beforeRmUpDetail.getRateMenuId())
                      && updateRmUpDetail.getUpApplySd().equals(beforeRmUpDetail.getUpApplySd())
                      && updateRmUpDetail.getDcecCatCode()
                          .equals(beforeRmUpDetail.getDcecCatCode())
                      && updateRmUpDetail.getTsCode().equals(beforeRmUpDetail.getTsCode())
                      && updateRmUpDetail.getBranchNo().intValue() == beforeRmUpDetail
                          .getBranchNo().intValue()) {

                    if (updateRmUpDetail.getUp().compareTo(beforeRmUpDetail.getUp()) != 0) {
                      /*
                       * 以下の項目が一致、かつ単価が不一致である場合、変数.履歴情報更新フラグにtrueを設定する。
                       *  ・料金メニューID
                       *  ・適用開始日
                       *  ・DCEC区分コード
                       *  ・時間帯コード
                       *  ・枝番
                       */
                      histUpdateFlag = true;
                      break;

                    } else {
                      // 上記の全ての項目が一致した場合、次の料金メニュー単価明細リストの要素に移る。
                      break;
                    }
                  }
                }

                // 変数.履歴情報更新フラグにtrueが設定されている場合、繰り返し処理終了
                if (histUpdateFlag) {
                  break;
                }
              }
            }
          }
        }
      }

      // 最新＋1日
      Date latestApplyDateNextDay = DateCalculateUtil.calculateDate(
          latestApplyDate, 0, 0, 1);
      if (latestApplyDateNextDay.compareTo(updateContractBusinessBean
          .getApplyStartDate()) == 0) {
        // 《契約情報照会BusinessBean》.適用開始日リストの最新＋1日と、《契約情報更新BusinessBean》.適用開始日が同日の場合、
        // 《契約情報更新BusinessBean》.リターンコードに（G032）を設定し返却する。
        updateContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G032);
        updateContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G032),
                new String[] {}, Locale.getDefault()));
        return updateContractBusinessBean;
      }

      // 《契約情報照会BusinessBean》.契約終了日と《契約情報更新BusinessBean》.適用開始日が同日の場合、
      // 《契約情報更新BusinessBean》.リターンコードに（G043）を設定し返却する。
      if (updateContractBusinessBean.getApplyStartDate().compareTo(
          inquryContractList.get(0).getContractEndDate()) >= 0) {
        updateContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G043);
        updateContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G043),
                new String[] {}, Locale.getDefault()));
        return updateContractBusinessBean;
      }

      // 親エンティティ存在チェック
      Integer contractorId = inquryContractResult
          .getAgentContractInformationList().get(0).getContractorId();

      InquiryAgentContractorBusinessBean contractorBean = new InquiryAgentContractorBusinessBean();
      contractorBean.setContractorId(contractorId);

      // 契約者情報照会
      InquiryAgentContractorBusinessBean resultContractorBean = kjContractorInfomationBusiness
          .inquiry(contractorBean);

      String contractorBeanReturnCode = resultContractorBean
          .getReturnCode();

      List<KJ_InquiryAgentContractorInformationEntityBean> contractorList = resultContractorBean
          .getAgentContractorInformationList();
      // リターンコードが“0000”以外の場合、業務例外クラスをスローする。
      if (!ECISReturnCodeConstants.RETURN_CODE_0000
          .equals(contractorBeanReturnCode)) {

        throw new BusinessLogicException(messageSource.getMessage(
            "error.E1281", new String[] {}, Locale.getDefault()),
            false);
      }
      // リターンコードが“0000”かつ返却値が0件の場合リターンコードに（D014）を設定し返却する。
      if (CollectionUtils.isEmpty(contractorList)) {

        updateContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D014);
        updateContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D014),
                new String[] {}, Locale.getDefault()));
        return updateContractBusinessBean;
      }

      // 契約者利用不能チェック
      // 利用不能フラグが“ON”の場合（D013）を設定し返却する。
      if (checkUnavailableFlag(contractorList)) {

        updateContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D013);
        updateContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D013),
                new String[] {}, Locale.getDefault()));
        return updateContractBusinessBean;
      }

      Integer paymentId = updateContractBusinessBean.getPaymentId();
      String paymentNo = updateContractBusinessBean.getPaymentNo();
      // 契約開始日
      Date contractStartDate = inquryContractList.get(0)
          .getContractStartDate();
      List<KJ_InquiryPaymentInformationEntityBean> paymentList = null;
      // 支払IDがNULLでないまたは支払番号がNULLまたは空文字のいずれでもない場合
      if (paymentId != null || StringUtils.isNotEmpty(paymentNo)) {

        InquiryPaymentBusinessBean paymentParam = new InquiryPaymentBusinessBean();
        paymentParam.setPaymentId(paymentId);
        paymentParam.setPaymentNo(paymentNo);
        // 支払存在チェック
        InquiryPaymentBusinessBean resultPayment = kjPaymentInformationBusiness
            .inquiry(paymentParam);
        String paymentReturnCode = resultPayment.getReturnCode();
        paymentList = resultPayment.getPaymentInformationList();

        // リターンコードが“0000”以外の場合、業務例外クラスをスローする。
        if (!ECISReturnCodeConstants.RETURN_CODE_0000
            .equals(paymentReturnCode)) {

          throw new BusinessLogicException(
              messageSource.getMessage("error.E1288",
                  new String[] {}, Locale.getDefault()),
              false);
        }
        // “0000”かつ返却値が0件の場合リターンコードに（D018）を設定し返却する。
        if (CollectionUtils.isEmpty(paymentList)) {

          updateContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D018);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D018),
                  new String[] {}, Locale.getDefault()));
          return updateContractBusinessBean;
        }

        // 支払情報照会した際の契約者IDチェック
        if (!contractorList.get(0).getContractorId().equals(paymentList.get(0).getContractorId())) {
          updateContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D018);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D018),
                  new String[] {}, Locale.getDefault()));
          return updateContractBusinessBean;
        }

        int paymentIndex = 0;
        String paymentIndexReturnCode = null;
        int paymentListSize = paymentList.size();
        // 契約開始日≦「オンライン処理日付」≦ 契約終了日(引数の契約終了日がNULLの場合は取得した契約終了日と比較する

        Date tmpContractEd = contractEndDate == null ? inquryContractList
            .get(0).getContractEndDate() : contractEndDate;

        if (contractStartDate.compareTo(onlineDate) <= 0
            && onlineDate.compareTo(tmpContractEd) <= 0) {

          for (int i = 0; i < paymentListSize; i++) {
            KJ_InquiryPaymentInformationEntityBean payment = paymentList
                .get(i);
            Date startDate = payment.getPaymentStartDate();
            Date endDate = payment.getPaymentEndDate();

            // 《支払情報照会BusinessBean》.支払適用開始日≦オンライン処理日付
            // ≦《支払情報照会BusinessBean》.支払適用終了日の場合
            if (startDate.compareTo(onlineDate) <= 0
                && onlineDate.compareTo(endDate) <= 0) {

              paymentIndex++;
            }
          }
          if (paymentIndex == 0) {
            paymentIndexReturnCode = ECISReturnCodeConstants.RETURN_CODE_G027;
          }
        }

        // 「オンライン処理日付」< 契約開始日の場合
        if (onlineDate.before(contractStartDate)) {

          for (int i = 0; i < paymentListSize; i++) {
            KJ_InquiryPaymentInformationEntityBean payment = paymentList
                .get(i);
            Date startDate = payment.getPaymentStartDate();
            Date endDate = payment.getPaymentEndDate();
            // 《支払情報照会BusinessBean》.支払適用開始日≦ 契約開始日
            // ≦《支払情報照会BusinessBean》.支払適用終了日の場合
            if (startDate.compareTo(contractStartDate) <= 0
                && contractStartDate.compareTo(endDate) <= 0) {
              paymentIndex++;
            }
          }
          if (paymentIndex == 0) {
            paymentIndexReturnCode = ECISReturnCodeConstants.RETURN_CODE_G028;
          }
        }
        // リターンコードがNULLでない場合リターンコードに（G027またはG028）を設定し返却する
        if (paymentIndexReturnCode != null) {

          updateContractBusinessBean
              .setReturnCode(paymentIndexReturnCode);
          updateContractBusinessBean.setMessage(messageSource
              .getMessage(KJ_CommonUtil
                  .getMessageId(paymentIndexReturnCode),
                  new String[] {}, Locale.getDefault()));
          return updateContractBusinessBean;
        }
      }

      // 《契約情報更新BusinessBean》.契約終了日がNULLまたは空文字のいずれかでない場合、以下の処理を行う。
      if (contractEndDate != null) {
        // 契約期間チェック
        // 契約終了日が契約開始日以前の日付の場合リターンコードに（G005）を設定し返却する。
        if (contractEndDate.compareTo(contractStartDate) <= 0) {

          updateContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G005);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G005),
                  new String[] {}, Locale.getDefault()));
          return updateContractBusinessBean;
        }

        // 《契約情報更新BusinessBean》.契約終了日が、《契約情報照会BusinessBean》.適用開始日リストの最新の適用開始日
        // 以前の場合リターンコードに（G031）を設定し返却する。
        if (updateContractBusinessBean.getContractEndDate().before(
            latestApplyDate)) {
          updateContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G031);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G031),
                  new String[] {}, Locale.getDefault()));
          return updateContractBusinessBean;
        }
      }

      BigDecimal capacity = updateContractBusinessBean
          .getContractCapacity();
      // 料金メニューIDがNULLかつ契約容量がNULLの場合
      if (chargeMenuId == null
          && capacity == null
          && StringUtils.isNotEmpty(updateContractBusinessBean
              .getContractChangeReason())) {
        // 契約変更理由がNULLまたは空文字のいずれでもない場合リターンコードに（P069）を設定し返却する。

        updateContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P069);
        updateContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P069),
                new String[] {}, Locale.getDefault()));
        return updateContractBusinessBean;
      }

      // メータ設置場所照会
      InquiryAgentMeterLocationBusinessBean inquiryMeterLocationBusinessBean = new InquiryAgentMeterLocationBusinessBean();
      inquiryMeterLocationBusinessBean.setContractId(inquryContractList
          .get(0).getContractId());
      InquiryAgentMeterLocationBusinessBean resulMl = kjMeterLocationInformationBusiness
          .inquiry(inquiryMeterLocationBusinessBean);

      List<KJ_InquiryAgentMeterLocationEntityBean> mlList = resulMl
          .getMeterLocationList();
      // リターンコードが“0000”以外の場合、業務例外クラスをスローする。
      if (!ECISReturnCodeConstants.RETURN_CODE_0000
          .equals(resulMl.getReturnCode())) {
        throw new BusinessLogicException(messageSource.getMessage(
            "error.E1299", new String[] {}, Locale.getDefault()),
            false);
      }
      // 呼び出しの戻り値が0件の場合、業務例外クラスをスローする
      if (CollectionUtils.isEmpty(mlList)) {

        throw new BusinessLogicException(resulMl.getMessage(), false);
      }

      // エリアコードリストを生成する。
      List<String> areaCodeList = new ArrayList<String>();
      // 送受電区分コードリストを生成する。
      List<String> tranCatCodeList = new ArrayList<String>();
      // メータ設置場所情報リストの件数分より、以下の処理を行う。
      for (KJ_InquiryAgentMeterLocationEntityBean entity : mlList) {
        // エリアコードリストに《メータ設置場所EntityBean》.エリアコードを追加する。
        areaCodeList.add(entity.getAreaCode());
        // 送受電区分コードリストに《メータ設置場所EntityBean》.送受電区分コードを追加する。
        tranCatCodeList.add(entity.getTransmissionCategoryCode());
      }

      Rm rateMenu = null;
      // 料金メニュー存在チェック
      if (StringUtils.isNotEmpty(chargeMenuId)) {

        // 提供モデルと提供モデル企業の判定
        RmMByPmCompanyKey keyExample = new RmMByPmCompanyKey();
        // 《契約情報更新BusinessBean》.料金メニューIDを設定する。
        keyExample.setRmId(chargeMenuId);
        // 《契約者情報照会EntityBean》.提供モデルコードを設定する
        keyExample.setPmCode(contractorList.get(0)
            .getProvideModelCode());
        // 《契約者情報照会EntityBean》.提供モデル企業コードを設定する。
        keyExample.setPmCompanyCode(contractorList.get(0)
            .getProvideModelCompanyCode());
        // 提供モデル企業別料金メニューマスタ情報を検索する。
        RmMByPmCompany rmMByPmCompany = rmMByPmCompanyMapper
            .selectByPrimaryKey(keyExample);

        // 取得結果判定、返却結果がNULLの場合、リターンコード（G038）を返却する。
        if (rmMByPmCompany == null) {
          updateContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G038);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G038),
                  new String[] {}, Locale.getDefault()));
          return updateContractBusinessBean;
        }

        // 料金メニュー取得
        rateMenu = rmMapper.selectByPrimaryKey(chargeMenuId);
        // 取得結果判定、返却結果がNULLの場合、リターンコード（D003）を返却する。
        if (rateMenu == null) {
          updateContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D003);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D003),
                  new String[] {}, Locale.getDefault()));
          return updateContractBusinessBean;
        }

        // エリアコードチェック
        // エリアコードリスト（変数）に《料金メニューEntity》.エリアコードが存在しない場合、
        // リターンコードに（G036）を設定し返却する。
        if (!areaCodeList.contains(rateMenu.getAreaCode())) {
          updateContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G036);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G036),
                  new String[] {}, Locale.getDefault()));
          return updateContractBusinessBean;
        }

        // 売買区分コードチェック
        // 《料金メニューEntity》.売買区分コードが"1:売電" かつ 送受電区分コードリスト（変数）に"1:送電"が存在しない
        // または、
        // 《料金メニューEntity》.売買区分コードが"2:買電" かつ
        // 送受電区分コードリスト（変数）に"2:受電"が存在しない場合、
        // リターンコードに（G037）を設定し返却する。
        if ((ECISCodeConstants.SALE_CATEGORY_SELLING.equals(rateMenu
            .getSaleCatCode())
            && !tranCatCodeList
                .contains(ECISCodeConstants.TRANSMISSION_CATEGORY_CODE_TRANSMISSION))
            || (ECISCodeConstants.SALE_CATEGORY_PURCHASING
                .equals(rateMenu.getSaleCatCode())
                && !tranCatCodeList
                    .contains(ECISCodeConstants.TRANSMISSION_CATEGORY_CODE_RECEIVING))) {
          updateContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G037);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G037),
                  new String[] {}, Locale.getDefault()));
          return updateContractBusinessBean;
        }
        // 電圧区分と料金メニュー整合性チェック
        if (!checkRmAndVoltageCat(voltageCatCode, ccDecisionCategoryCode, chargeMenuId)) {
          updateContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P095);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P095),
                  new String[] {chargeMenuId, voltageCatCode, ccDecisionCategoryCode },
                  Locale.getDefault()));
          return updateContractBusinessBean;
        }
        // 単価設定区分のチェック及び、単価明細のチェック
        // 単価設定区分コード存在チェック
        if (!checkUpCat(upCatCode)) {
          updateContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P092);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P092),
                  new String[] {}, Locale.getDefault()));
          return updateContractBusinessBean;

        }
        // 料金メニュー単価明細存在チェック
        // 料金メニュー単価明細リスト
        Date applySd = updateContractBusinessBean.getApplyStartDate();
        List<RmUpDetail> rmUpdetail = updateContractBusinessBean.getRmUpDetailList();
        List<String> checkRmUpDetail = checkRmUpDetail(upCatCode, chargeMenuId, applySd, rmUpdetail);
        if (checkRmUpDetail.size() != 0) {
          String[] params = {
              // 料金メニューID
              chargeMenuId,
              // DCEC区分
              checkRmUpDetail.get(0),
              // 時間帯コード
              checkRmUpDetail.get(1),
              // 枝番
              checkRmUpDetail.get(2),
          };
          updateContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P091);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P091),
                  params, Locale.getDefault()));
          return updateContractBusinessBean;

        }
        // 適用期間チェック
        // 《契約情報更新BusinessBean》.適用開始日が《料金メニュー》.適用終了日より後の場合、
        // リターンコードに（G039）を設定し返却する。
        if (updateContractBusinessBean.getApplyStartDate().after(
            rateMenu.getApplyEd())) {
          updateContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G039);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G039),
                  new String[] {}, Locale.getDefault()));
          return updateContractBusinessBean;
        }
        // 《契約情報更新BusinessBean》.契約終了日がNULLではない
        // かつ 《契約情報更新BusinessBean》.契約終了日が《料金メニュー》.適用開始日より前の場合、
        // リターンコードに（G039）を設定し返却する。
        if (updateContractBusinessBean.getContractEndDate() != null
            && updateContractBusinessBean.getContractEndDate()
                .before(rateMenu.getApplySd())) {
          updateContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G039);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G039),
                  new String[] {}, Locale.getDefault()));
          return updateContractBusinessBean;
        }
        // 《契約情報更新BusinessBean》.契約終了日がNULL
        // かつ 《契約情報照会BusinessBean》.契約終了日が《料金メニュー》.適用開始日より前の場合、
        // リターンコードに（G039）を設定し返却する。
        if (updateContractBusinessBean.getContractEndDate() == null
            && inquryContractList.get(0).getContractEndDate()
                .before(rateMenu.getApplySd())) {
          updateContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G039);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G039),
                  new String[] {}, Locale.getDefault()));
          return updateContractBusinessBean;
        }
        // 契約電力決定区分が協議制の場合
        if (ECISCodeConstants.CONTRACT_CAPACITY_DECISION_CATEGORY_CODE_DISCUSSIONS.equals(
            ccDecisionCategoryCode)) {

          // 契約容量チェック
          String capacitynit = rateMenu.getCcaUnit();
          // 契約容量単位がNULLまたは空文字いずれかでない場
          if (StringUtils.isNotEmpty(capacitynit) && capacity == null) {
            // 契約容量がNULLの場合リターンコードに（P065）を設定し返却する。

            updateContractBusinessBean
                .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P065);
            updateContractBusinessBean
                .setMessage(messageSource.getMessage(
                    KJ_CommonUtil
                        .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P065),
                    new String[] {}, Locale.getDefault()));
            return updateContractBusinessBean;
          }
          // 契約容量単位がNULLまたは空文字の場合
          if (StringUtils.isEmpty(capacitynit) && capacity != null) {
            // 契約容量がNULLではない場合リターンコードに（P064）を設定し返却する。

            updateContractBusinessBean
                .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P064);
            updateContractBusinessBean
                .setMessage(messageSource.getMessage(
                    KJ_CommonUtil
                        .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P064),
                    new String[] {}, Locale.getDefault()));
            return updateContractBusinessBean;

          }
          // 契約容量選択可能範囲チェック
          if (capacity != null) {
            boolean resultCapaCheck = RK_CommonUtil
                .checkContractCapacity(String.valueOf(capacity),
                    rateMenu.getCapacitySelectableRange());
            if (!resultCapaCheck) {
              updateContractBusinessBean
                  .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G006);
              updateContractBusinessBean
                  .setMessage(messageSource.getMessage(
                      KJ_CommonUtil
                          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G006),
                      new String[] {}, Locale.getDefault()));
              return updateContractBusinessBean;
            }
          }
        }
      }

      List<KJ_AgentContractHistoryInformationEntityBean> historyList = inquryContractList
          .get(0).getAgentContractHistoryInformationList();
      Date contractApplyStartDate = historyList.get(0)
          .getApplyStartDate();
      // 《契約情報照会BusinessBean》.適用開始日と《契約情報更新BusinessBean》.適用開始日が同日でない
      //または、
      //《契約情報照会BusinessBean》.適用開始日と《契約情報更新BusinessBean》.適用開始日が同日かつ
      // 変数.履歴更新フラグがtrueの場合
      if (contractApplyStartDate.compareTo(applyStartDate) != 0
          || (contractApplyStartDate.compareTo(applyStartDate) == 0
              && histUpdateFlag)) {

        Map<String, Object> fixParamMap = new HashMap<String, Object>();
        fixParamMap.put("contractId", inquryContractList.get(0)
            .getContractId());
        fixParamMap.put("coveredDate", applyStartDate);
        fixParamMap
            .put("flg",
                ECISKJConstants.INQUIRY_FIX_CHANGE_RESULT_INFOEMATION_FLG_ON);
        // 確定料金チェック
        int fixChargeCount = fixChargeResultInformationCommonMapper
            .countByFixChargeResult(fixParamMap);

        // 結果が1件以上の場合リターンコードに（D009）を設定し返却する。
        if (fixChargeCount >= 1) {

          updateContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D009);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D009),
                  new String[] {}, Locale.getDefault()));
          return updateContractBusinessBean;
        }
      }

      List<KJ_SupplementaryContractInformationEntityBean> supplementryContractList = null;

      // 予備契約情報Entityリスト
      List<KJ_InquiryReserveContractInformationEntityBean> reserveContractList = null;

      // 契約終了分確定使用量連携済フラグ更新フラグ
      String contractEndFuSentFlag = null;

      // 付帯契約存在チェック
      if (contractEndDate != null) {

        InquirySupplementaryContractBusinessBean supplementBean = new InquirySupplementaryContractBusinessBean();
        supplementBean.setContractId(inquryContractList.get(0)
            .getContractId());
        supplementBean.setInqCoveredDate(contractEndDate);
        InquirySupplementaryContractBusinessBean resultSupplementryContract = kjSupplementaryContractInformationBusiness
            .inquiry(supplementBean);
        supplementryContractList = resultSupplementryContract
            .getSupplementaryContractList();
        String returnCodeSpplement = resultSupplementryContract
            .getReturnCode();
        // リターンコードが'0000'以外の場合、業務例外クラスをスローする
        if (!ECISReturnCodeConstants.RETURN_CODE_0000
            .equals(returnCodeSpplement)) {

          throw new BusinessLogicException(
              messageSource.getMessage("error.E1284",
                  new String[] {}, Locale.getDefault()),
              false);
        }

        int size = supplementryContractList.size();
        for (int i = 0; i < size; i++) {
          KJ_SupplementaryContractInformationEntityBean supplement = supplementryContractList
              .get(i);
          Date suppleStartDate = supplement
              .getSupplementaryContractStartDate();
          // 付帯契約開始日 ≧ 契約終了日の場合リターンコードに（G029）を設定し返却する。
          if (suppleStartDate.compareTo(contractEndDate) >= 0) {

            updateContractBusinessBean
                .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G029);
            updateContractBusinessBean
                .setMessage(messageSource.getMessage(
                    KJ_CommonUtil
                        .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G029),
                    new String[] {}, Locale.getDefault()));
            return updateContractBusinessBean;
          }
        }

        // 予備契約存在チェック
        InquiryReserveContractBusinessBean inquiryReserveContractBusinessBean = new InquiryReserveContractBusinessBean();

        // 契約IDに《契約情報照会BusinessBean》.契約IDを設定する。
        inquiryReserveContractBusinessBean.setContractId(inquryContractList.get(0).getContractId());

        // 照会対象日付に《契約情報更新BusinessBean》.契約終了日を設定する。
        inquiryReserveContractBusinessBean.setInqCoveredDate(contractEndDate);

        // 照会処理を呼び出す。
        kjReserveContractInformationBusiness.inquiry(inquiryReserveContractBusinessBean);

        // リターンコードが“0000”以外の場合
        if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(
            inquiryReserveContractBusinessBean.getReturnCode())) {

          // 業務例外クラスをスローする。
          throw new BusinessLogicException(
              messageSource.getMessage("error.E1735", new String[] {}, Locale.getDefault()), false);
        }

        // 予備契約のリストを取得する。
        reserveContractList = inquiryReserveContractBusinessBean.getReserveContractList();

        // 取得した予備契約履歴の件数分ループ処理を行う。
        int reserveContractListSize = reserveContractList.size();
        for (int i = 0; i < reserveContractListSize; i++) {

          KJ_InquiryReserveContractInformationEntityBean reserve = reserveContractList.get(i);
          Date reserveStartDate = reserve.getReserveContractSd();

          // 《予備契約情報照会BusinessBean》.予備契約開始日 ＞《契約情報更新BusinessBean》.契約終了日の場合
          if (reserveStartDate.compareTo(contractEndDate) > 0) {
            // リターンコード(G50)を返す。
            updateContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G054);
            updateContractBusinessBean.setMessage(messageSource.getMessage(KJ_CommonUtil.getMessageId(
                ECISReturnCodeConstants.RETURN_CODE_G054), new String[] {}, Locale.getDefault()));

            return updateContractBusinessBean;
          }
        }

        // 算定期間チェック
        Map<String, Object> fixParamMap = new HashMap<String, Object>();
        fixParamMap.put("contractId", inquryContractList.get(0)
            .getContractId());
        fixParamMap.put("coveredDate", contractEndDate);
        fixParamMap
            .put("flg",
                ECISKJConstants.INQUIRY_FIX_CHANGE_RESULT_INFOEMATION_FLG_THREE);

        int fixChargeEndCount = fixChargeResultInformationCommonMapper
            .countByFixChargeResult(fixParamMap);
        // 結果が1件以上の場合リターンコードに（D019）を設定し返却する
        if (fixChargeEndCount >= 1) {

          updateContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D019);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D019),
                  new String[] {}, Locale.getDefault()));
          return updateContractBusinessBean;
        }

        // 算定終了日チェック
        // 契約終了分確定使用量連携済フラグに“0”を設定する。
        contractEndFuSentFlag = ECISKJConstants.CONTRACT_END_FIX_USAGE_SENT_FLAG_NON_LINKAGE;

        // 確定料金実績件数取得条件を設定する。
        fixParamMap = new HashMap<String, Object>();
        // 契約ID
        fixParamMap.put("contractId", inquryContractList.get(0).getContractId());
        // 日付
        fixParamMap.put("coveredDate", contractEndDate);
        // 照会パターン
        fixParamMap.put("flg", ECISKJConstants.INQUIRY_FIX_CHANGE_RESULT_INFOEMATION_FLG_TWO);

        // 確定料金実績件数を取得する。
        fixChargeEndCount = fixChargeResultInformationCommonMapper.countByFixChargeResult(fixParamMap);

        // 結果が1件以上の場合
        if (fixChargeEndCount >= 1) {

          // 契約終了分確定使用量連携済フラグに“1”を設定する。
          contractEndFuSentFlag = ECISKJConstants.CONTRACT_END_FIX_USAGE_SENT_FLAG_LINKAGE_COMPLETED;
        }
      }

      // 契約終了取り消しフラグ
      int contractEndCancelFlag = CONTRACT_CANCEL_FLAG_OFF;
      // 契約終了理由コード
      String contractEndReasonCodeOfContract = inquryContractList.get(0)
          .getContractEndReasonCode();
      // 《契約情報更新BusinessBean》.契約終了日が"99991231"かつ、《契約情報照会BusinessBean》.契約終了理由コードがNULLまたは空文字
      // のいずれかでない場合、かつ《契約情報更新BusinessBean》.契約終了理由コードが
      // NULLまたは空文字のいずれかの場合、以下の処理を行う。
      Integer meterLocationId = mlList.get(0).getMeterLocationId();

      if (contractEndDate != null
          && (contractEndDate.compareTo(maxDate) == 0
              && StringUtils
                  .isNotEmpty(contractEndReasonCodeOfContract)
              && StringUtils
                  .isEmpty(contractEndReasonCode))) {

        // 契約情報履歴件数取得
        Map<String, Object> countHistoryMap = new HashMap<String, Object>();
        countHistoryMap.put("meterLocationId", meterLocationId);
        countHistoryMap.put("contractId", inquryContractList.get(0)
            .getContractId());
        countHistoryMap.put("startDate", inquryContractList.get(0)
            .getContractStartDate());
        countHistoryMap.put("flag", ECISConstants.FLG_OFF);
        int historyCount = contractInformationCommonMapper
            .countByContractHistory(countHistoryMap);

        // 結果が1件以上の場合リターンコードに（G026）を設定し返却する
        if (historyCount >= 1) {

          updateContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G026);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G026),
                  new String[] {}, Locale.getDefault()));
          return updateContractBusinessBean;
        }
        contractEndCancelFlag = CONTRACT_CANCEL_FLAG_ON;
      }

      // 《契約情報更新BusinessBean》.契約終了日がNULLまたは空文字のいずれかでない
      // かつ《契約情報更新BusinessBean》.契約終了日が“99991231”でない
      // かつ《契約情報更新BusinessBean》.契約終了理由コードがNULLまたは空文字のいずれかでない場合、以下の処理を行う。
      if (contractEndDate != null
          && contractEndDate.compareTo(maxDate) != 0
          && StringUtils.isNotEmpty(contractEndReasonCode)) {
        // 契約情報履歴件数取得
        Map<String, Object> countHistoryMap = new HashMap<String, Object>();
        countHistoryMap.put("meterLocationId", meterLocationId);
        countHistoryMap.put("contractId", inquryContractList.get(0)
            .getContractId());
        countHistoryMap.put("startDate", inquryContractList.get(0).getContractStartDate());
        countHistoryMap.put("endDate", contractEndDate);
        countHistoryMap.put("flag", ECISConstants.FLG_ON);
        int historyCount = contractInformationCommonMapper
            .countByContractHistory(countHistoryMap);

        // 結果が1件以上の場合リターンコードに（G026）を設定し返却する
        if (historyCount >= 1) {
          updateContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G026);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G026),
                  new String[] {}, Locale.getDefault()));
          return updateContractBusinessBean;
        }
      }

      // 付帯契約Exampleリスト
      List<SplContractExample> supplementExampleList = new ArrayList<SplContractExample>();
      // 付帯契約更新用リスト
      List<SplContract> supplementryUpdateList = new ArrayList<SplContract>();
      // 契約終了日がNULLでないかつ 契約終了日が“99991231”でないかつ付帯契約がNULLではない
      if (contractEndDate != null
          && contractEndDate.compareTo(maxDate) != 0) {

        int size = supplementryContractList.size();
        for (int i = 0; i < size; i++) {

          KJ_SupplementaryContractInformationEntityBean supplement = supplementryContractList
              .get(i);
          Date supplementEndDate = supplement
              .getSupplementaryContractEndDate();

          // 付帯契約終了日 > 契約終了日
          if (supplementEndDate.after(contractEndDate)) {
            SplContractExample tmpExample = createSupplementaryContractExample(supplement);
            SplContract tmpSuppleyment = createSupplementaryContract(
                supplement, contextUserId, contextModuleCode);
            supplementExampleList.add(tmpExample);
            supplementryUpdateList.add(tmpSuppleyment);
          }
        }
      }

      // 契約履歴情報取得
      Map<String, Object> searchContractHistoryParam = new HashMap<String, Object>();
      searchContractHistoryParam.put("contractId", inquryContractList
          .get(0).getContractId());
      searchContractHistoryParam.put("applyStartDate", applyStartDate);

      KJ_ContractHistoryUpdateCountEntityBean contractHistoryUpdateCount = contractInformationCommonMapper
          .searchContractHistory(searchContractHistoryParam);
      Integer inquryPamentId = (CollectionUtils.isEmpty(paymentList)) ? null
          : paymentList.get(0).getPaymentId();
      // 契約情報更新
      Contract contract = createUpdateContract(
          updateContractBusinessBean, consignmentCapacityUnit,
          inquryPamentId, contextUserId, contextModuleCode);
      // 契約終了取り消しフラグ（変数）が"1"の場合契約終了理由コードに空文字を設定する。
      if (contractEndCancelFlag == CONTRACT_CANCEL_FLAG_ON) {
        contract.setContractEndReasonCode(ECISKJConstants.EMPTY_STRING);
      }

      // 契約終了分確定使用量連携済フラグ更新フラグ(変数)が"1"の場合
      if (Objects.equals(contractEndFuSentFlag, ECISKJConstants.CONTRACT_END_FIX_USAGE_SENT_FLAG_LINKAGE_COMPLETED)) {

        //《契約Entity》.契約終了分確定使用量連携済フラグに「"1"：連携済」を設定する。
        contract.setContractEndFuSentFlag(ECISKJConstants.CONTRACT_END_FIX_USAGE_SENT_FLAG_LINKAGE_COMPLETED);
      }

      // consignmentContractCapacityNoUpdFlag 託送契約容量
      // consignmentContractCapacityDecisionDateNoUpdFlag 託送契約容量判定日
      // conditionContractId 契約ID 更新条件
      // conditionUpdateCount 更新回数 更新条件
      Map<String, Object> contractExample = new HashMap<String, Object>();

      contractExample.put("consignmentContractCapacityNoUpdFlag",
          updateContractBusinessBean
              .getConsignmentContractCapacityNoUpdFlag());
      contractExample
          .put("consignmentContractCapacityDecisionDateNoUpdFlag",
              updateContractBusinessBean
                  .getConsignmentContractCapacityDecisionDateNoUpdFlag());
      contractExample.put("conditionContractId", inquryContractList
          .get(0).getContractId());
      contractExample.put("conditionUpdateCount",
          updateContractBusinessBean.getUpdateCount());

      int updateContractCount = contractMapper
          .updateByNoUpdFlagSelective(contract, contractExample);

      // 契約情報更新結果が0件の場合リターンコードに（H001）を設定し返却する
      if (updateContractCount == 0) {
        updateContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_H001);
        updateContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_H001),
                new String[] {}, Locale.getDefault()));
        return updateContractBusinessBean;
      }

      // 支払IDがNULLでないまたは支払番号がNULLまたは空文字のいずれでない場合
      if (paymentId != null || StringUtils.isNotEmpty(paymentNo)) {

        List<Integer> paymentIdList = new ArrayList<Integer>();
        // 更新前の支払ID
        paymentIdList.add(inquryContractResult.getAgentContractInformationList().get(0).getPaymentId());
        // 更新後の支払ID
        paymentIdList.add(paymentList.get(0).getPaymentId());
        Map<String, Object> paymentParam = new HashMap<String, Object>();
        paymentParam.put("paymentIdList", paymentIdList);
        // 対象支払で支払テーブルのロックを取得し、支払更新対象の支払へ読み取りをさせないようにする
        paymentInformationCommonMapper.lockPaymentForUpdatePayment(paymentParam);

        // 請求合算チェック
        // 《支払Mapper》.検索（主キー）を取得呼び出し
        //更新前の支払情報取得
        Payment oldPayment = paymentMapper
            .selectByPrimaryKey(
                inquryContractResult.getAgentContractInformationList().get(0).getPaymentId());

        //更新後の支払情報取得
        Payment newPayment = paymentMapper
            .selectByPrimaryKey(paymentList.get(0).getPaymentId());

        // 更新前の前月請求合算フラグと更新後の前月請求合算フラグが異なる場合
        if (!oldPayment.getPreviousBlAddUpFlag().equals(
            newPayment.getPreviousBlAddUpFlag())) {
          updateContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G050);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G050),
                  new String[] {}, Locale.getDefault()));
          return updateContractBusinessBean;
        }
      }

      // [kg-epj:JTS-117]<i-start>
      // 契約付加情報取得
      ContractAddInfo contractAddInfoUpdateCountEntity = contractAddInfoMapper
          .selectByPrimaryKey(inquryContractList.get(0).getContractId());
      // [kg-epj:JTS-117]<i-end>

      // 契約付加情報更新件数
      int updateContractAddInfoCount = 0;

      if (contractAddInfoUpdateCountEntity != null) {
        // 契約付加情報の更新
        ContractAddInfo contractAddInfo = createUpdateContractAddInfo(
            updateContractBusinessBean, contextUserId,
            contextModuleCode, contractAddInfoUpdateCountEntity.getUpdateCount());

        if (contractAddInfo.getContractId() == null) {
          // 更新条件となる契約IDが設定されていない場合は契約IDを設定
          contractAddInfo.setContractId(inquryContractList.get(0).getContractId());
        }

        updateContractAddInfoCount = contractAddInfoMapper.updateByPrimaryKeySelective(contractAddInfo);
      }

      // 契約情報更新結果が0件の場合リターンコードに（H001）を設定し返却する
      if (updateContractAddInfoCount == 0) {
        updateContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_H001);
        updateContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_H001),
                new String[] {}, Locale.getDefault()));
        return updateContractBusinessBean;
      }

      // 《契約履歴更新回数EntityBean》.適用開始日
      Date historyApplyStartDate = contractHistoryUpdateCount
          .getApplyStartDate();

      // 適用終了日の設定
      // 引数.契約終了日がNULLではない場合、引数.契約終了日を設定し、
      // 引数.契約終了日がNULLの場合、《契約情報照会BusinessBean》.契約終了日を設定する。
      Date applyEd = contractEndDate != null ? contractEndDate
          : inquryContractList.get(0).getContractEndDate();

      // 《契約情報更新BusinessBean》.適用開始日より《契約履歴更新回数EntityBean》.適用開始日が過去日の場合
      if (historyApplyStartDate.before(applyStartDate)) {

        // 契約履歴情報登録
        ContractHist contractHistory = createInsertContractHistory(
            updateContractBusinessBean, inquryContractResult, inquryContractList.get(0),
            rateMenu, applyEd, contextUserId, contextModuleCode);
        contractHistMapper.insertSelective(contractHistory);
        // システム日時
        Timestamp systemTime = new Timestamp(System.currentTimeMillis());
        // メータ設置場所契約履歴情報登録
        MlContractHist mlContractHistory = new MlContractHist();
        mlContractHistory.setMlId(meterLocationId);
        mlContractHistory.setApplySd(applyStartDate);
        mlContractHistory.setContractId(inquryContractList.get(0)
            .getContractId());
        mlContractHistory.setCreateTime(systemTime);
        mlContractHistory.setOnlineUpdateTime(systemTime);
        mlContractHistory.setOnlineUpdateUserId(contextUserId);
        mlContractHistory.setUpdateModuleCode(contextModuleCode);
        mlContractHistory.setUpdateTime(systemTime);
        mlContractHistory.setUpdateCount(0);
        mlContractHistMapper.insertSelective(mlContractHistory);

        // 単価設定区分コードが"indiv"(定数.単価設定区分コード：個別単価)の場合、
        // 契約ID
        String contractID = StringConvertUtil.integerToString(inquryContractList.get(0).getContractId());
        upCatCode = updateContractBusinessBean.getUpCatCode();
        if (ECISConstants.UNIT_PRICE_SETTING_CATEGORY_INDIV.equals(upCatCode)) {
          String rateMenuId = null;
          if (StringUtils.isEmpty(updateContractBusinessBean.getChargeMenuId())) {
            rateMenuId = inquryContractList.get(0).getAgentContractHistoryInformationList().get(0)
                .getRateMenuId();
          } else {
            rateMenuId = rateMenu.getRmId();
          }

          // 料金メニュー単価を登録する。
          RmUp rmUp = insertRmUp(
              contractID,
              updateContractBusinessBean,
              contextUserId,
              contextModuleCode,
              rateMenuId);
          rmUpMapper.insert(rmUp);
          // 料金メニュー単価明細を登録する。
          List<RmUpDetail> rmUpdetailList = updateContractBusinessBean.getRmUpDetailList();
          for (RmUpDetail upCatMap : rmUpdetailList) {

            RmUpDetail rmUpDetail = insertRmUpDetail(
                contractID,
                updateContractBusinessBean,
                contextUserId,
                contextModuleCode,
                upCatMap,
                rateMenuId);

            rmUpDetailMapper.insert(rmUpDetail);
          }
        }
        // 前回契約履歴情報更新
        ContractHist lastContractHistory = createUpdateContractEndHistory(
            updateContractBusinessBean,
            (contractHistoryUpdateCount.getUpdateCount() + 1),
            contextUserId, contextModuleCode);

        ContractHistExample lastHistExample = new ContractHistExample();
        lastHistExample
            .createCriteria()
            .andContractIdEqualTo(
                inquryContractList.get(0).getContractId())
            .andApplySdEqualTo(historyApplyStartDate)
            .andUpdateCountEqualTo(
                contractHistoryUpdateCount.getUpdateCount());

        int result = contractHistMapper.updateByExampleSelective(
            lastContractHistory, lastHistExample);
        if (result == 0) {
          // 更新結果が0件の場合リターンコードに（H001）を設定し返却する
          updateContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_H001);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_H001),
                  new String[] {}, Locale.getDefault()));
          return updateContractBusinessBean;
        }

        // 前回料金メニュー単価更新
        // 単価設定区分が個別単価の場合
        if (ECISConstants.UNIT_PRICE_SETTING_CATEGORY_INDIV.equals(
            kjAgentContractHistInfoEntityBean.getUnitPriceSetCategoryCode())) {
          // 料金メニュー単価Entity
          RmUp rmup = createUpdateRmUp(
              updateContractBusinessBean,
              (kjAgentContractHistInfoEntityBean.getUnitPriceDetailInformationList().get(0)
                  .getUpdateCount() + 1),
              contextUserId, contextModuleCode);

          // 料金メニュー単価Example
          RmUpExample rmUpExample = new RmUpExample();
          // 料金メニューID
          // 適用開始日
          // 更新回数
          rmUpExample.createCriteria().andRmIdEqualTo(kjAgentContractHistInfoEntityBean.getRateMenuId())
              .andUpApplySdEqualTo(kjAgentContractHistInfoEntityBean.getApplyStartDate())
              .andUpCatCodeEqualTo(kjAgentContractHistInfoEntityBean.getContractId().toString())
              .andUpdateCountEqualTo(kjAgentContractHistInfoEntityBean.getUnitPriceDetailInformationList()
                  .get(0).getUpdateCount());
          // 料金メニュー単価更新呼び出し
          int countResult = rmUpMapper.updateByExampleSelective(rmup, rmUpExample);
          if (countResult == 0) {
            // 更新結果が0件の場合リターンコードに（H001）を設定し返却する
            updateContractBusinessBean
                .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_H001);
            updateContractBusinessBean
                .setMessage(messageSource.getMessage(
                    KJ_CommonUtil
                        .getMessageId(ECISReturnCodeConstants.RETURN_CODE_H001),
                    new String[] {}, Locale.getDefault()));
            return updateContractBusinessBean;
          }
        }
      }
      // 《契約情報更新BusinessBean》.適用開始日と《契約履歴更新回数EntityBean》.適用開始日が同日の場合
      if (historyApplyStartDate.compareTo(applyStartDate) == 0) {

        // 契約履歴で更新対象の適用開始日、更新後の更新回数を退避
        Date bufTargetApplyStartDate = historyApplyStartDate;
        Integer bufUpdateCnt = contractHistoryUpdateCount.getUpdateCount() + 1;

        // 契約履歴更新データ作成
        ContractHist contractHistory = createUpdateContractHistory(
            updateContractBusinessBean, inquryContractList.get(0),
            rateMenu, applyEd, contractHistoryUpdateCount.getUpdateCount() + 1, contextUserId,
            contextModuleCode);

        // 《契約履歴Example》の設定
        // contractCapacityNoUpdFlag 契約容量更新対象外フラグ
        // conditionApplyStartDate 適用開始日
        // conditionContractId 契約ID 更新条件
        // conditionUpdateCount 更新回数 更新条件
        Map<String, Object> histExample = new HashMap<String, Object>();

        histExample.put("contractCapacityNoUpdFlag",
            updateContractBusinessBean
                .getContractCapacityNoUpdFlag());
        histExample.put("conditionContractId", inquryContractList
            .get(0).getContractId());
        histExample.put("conditionApplyStartDate", historyApplyStartDate);
        histExample.put("conditionUpdateCount",
            contractHistoryUpdateCount.getUpdateCount());

        // 契約履歴更新
        int result = contractHistMapper.updateByNoUpdFlagSelective(
            contractHistory, histExample);

        // 更新結果が0件の場合リターンコードに（H001）を設定し返却する
        if (result == 0) {
          updateContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_H001);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_H001),
                  new String[] {}, Locale.getDefault()));
          return updateContractBusinessBean;
        }

        // 料金メニュー単価
        if (histUpdateFlag) {
          // 変数.履歴更新フラグがtrueである場合（変更予約の場合）

          // 契約ID
          String contractID = StringConvertUtil.integerToString(inquryContractList.get(0).getContractId());

          if (ECISConstants.UNIT_PRICE_SETTING_CATEGORY_INDIV.equals(
              kjAgentContractHistInfoEntityBean.getUnitPriceSetCategoryCode())) {

            // 更新前の単価設定区分が個別単価の場合、料金メニュー単価の削除を行う。
            RmUpExample rmUpExample = new RmUpExample();
            rmUpExample
                .createCriteria()
                .andRmIdEqualTo(kjAgentContractHistInfoEntityBean.getRateMenuId())
                .andUpApplySdEqualTo(historyApplyStartDate)
                .andUpCatCodeEqualTo(
                    kjAgentContractHistInfoEntityBean
                        .getUnitPriceDetailInformationList()
                        .get(0).getUnitPriceCategoryCode())
                .andUpdateCountEqualTo(
                    kjAgentContractHistInfoEntityBean
                        .getUnitPriceDetailInformationList()
                        .get(0).getUpdateCount());

            int rmUpDeleteCount = rmUpMapper.deleteByExample(rmUpExample);
            // 返却値が0件の場合リターンコードに（H001）を設定し返却する
            if (rmUpDeleteCount == 0) {
              updateContractBusinessBean
                  .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_H001);

              updateContractBusinessBean
                  .setMessage(messageSource.getMessage(
                      KJ_CommonUtil
                          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_H001),
                      new String[] {}, Locale.getDefault()));
              return updateContractBusinessBean;
            }

            // 料金メニュー単価明細の削除
            RmUpDetailExample rmUpDetailExample = new RmUpDetailExample();
            rmUpDetailExample
                .createCriteria()
                .andRmIdEqualTo(kjAgentContractHistInfoEntityBean.getRateMenuId())
                .andUpApplySdEqualTo(historyApplyStartDate)
                .andUpCatCodeEqualTo(
                    kjAgentContractHistInfoEntityBean
                        .getUnitPriceDetailInformationList()
                        .get(0).getUnitPriceCategoryCode());

            int rmUpDetailDeleteCount = rmUpDetailMapper.deleteByExample(rmUpDetailExample);
            // 返却値が0件の場合リターンコードに（H001）を設定し返却する
            if (rmUpDetailDeleteCount == 0) {
              updateContractBusinessBean
                  .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_H001);

              updateContractBusinessBean
                  .setMessage(messageSource.getMessage(
                      KJ_CommonUtil
                          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_H001),
                      new String[] {}, Locale.getDefault()));
              return updateContractBusinessBean;
            }
          }

          // 卸取次店向け契約情報更新BusinessBean.単価設定区分が個別単価の場合
          if (ECISConstants.UNIT_PRICE_SETTING_CATEGORY_INDIV.equals(
              updateContractBusinessBean.getUpCatCode())) {

            // 料金メニュー単価を登録する。
            RmUp rmUp = insertRmUp(
                contractID,
                updateContractBusinessBean,
                contextUserId,
                contextModuleCode,
                chargeMenuId);
            rmUpMapper.insert(rmUp);

            // 料金メニュー単価明細を登録する。
            List<RmUpDetail> rmUpdetailList = updateContractBusinessBean.getRmUpDetailList();
            for (RmUpDetail upCatMap : rmUpdetailList) {

              RmUpDetail rmUpDetail = insertRmUpDetail(
                  contractID,
                  updateContractBusinessBean,
                  contextUserId,
                  contextModuleCode,
                  upCatMap,
                  chargeMenuId);

              rmUpDetailMapper.insert(rmUpDetail);
            }
          }
        } else {

          // 契約終了日がNULLでない かつ 契約終了日が“99991231でない場合、以下の処理を行う。
          if (contractEndDate != null && contractEndDate.compareTo(maxDate) != 0) {

            // 単価設定区分コードがメニュー単価でない場合、料金メニュー単価の更新を行う。
            if (!ECISConstants.UNIT_PRICE_SETTING_CATEGORY_DEF.equals(
                kjAgentContractHistInfoEntityBean.getUnitPriceSetCategoryCode())) {

              // 料金メニュー単価Entity
              RmUp rmup = createUpdateEndRmUp(
                  updateContractBusinessBean,
                  (kjAgentContractHistInfoEntityBean.getUnitPriceDetailInformationList().get(0)
                      .getUpdateCount() + 1),
                  contextUserId, contextModuleCode);

              // 料金メニュー単価Example
              RmUpExample rmUpExample = new RmUpExample();
              rmUpExample
                  .createCriteria()
                  .andRmIdEqualTo(
                      kjAgentContractHistInfoEntityBean
                          .getRateMenuId())
                  .andUpApplySdEqualTo(
                      kjAgentContractHistInfoEntityBean
                          .getApplyStartDate())
                  .andUpCatCodeEqualTo(
                      kjAgentContractHistInfoEntityBean
                          .getContractId().toString())
                  .andUpdateCountEqualTo(
                      kjAgentContractHistInfoEntityBean
                          .getUnitPriceDetailInformationList()
                          .get(0).getUpdateCount());

              // 料金メニュー単価更新呼び出し
              int countResult = rmUpMapper.updateByExampleSelective(rmup, rmUpExample);
              if (countResult == 0) {
                // 更新結果が0件の場合リターンコードに（H001）を設定し返却する
                updateContractBusinessBean
                    .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_H001);
                updateContractBusinessBean
                    .setMessage(messageSource.getMessage(
                        KJ_CommonUtil
                            .getMessageId(ECISReturnCodeConstants.RETURN_CODE_H001),
                        new String[] {}, Locale.getDefault()));
                return updateContractBusinessBean;
              }
            }

            // 付帯契約Exampleリストが空でない場合は、付帯契約情報更新を行う。
            // ※付帯契約Exampleリストには、付帯契約終了日が契約終了日後の付帯契約が設定される。
            if (!CollectionUtils.isEmpty(supplementExampleList)) {
              int size = supplementExampleList.size();
              for (int i = 0; i < size; i++) {
                // 付帯契約更新
                SplContract record = supplementryUpdateList.get(i);
                SplContractExample example = supplementExampleList.get(i);
                // 付帯契約終了日に契約終了日を入れる
                record.setSplContractEd(contractEndDate);
                int supplyUpdateCount = splContractMapper
                    .updateByExampleSelective(record, example);
                if (supplyUpdateCount == 0) {
                  // リターンコードに（H001）を設定し返却する
                  updateContractBusinessBean
                      .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_H001);
                  return updateContractBusinessBean;
                }
              }
            }

            // 《卸取次店向け契約情報更新BusinessBean》.契約終了日がNULLでない
            // かつ《卸取次店向け契約情報更新BusinessBean》.契約終了日が“99991231”でない場合
            if (contractEndDate != null
                && contractEndDate.compareTo(maxDate) != 0) {

              // 《予備契約情報照会BusinessBean》の件数分、以下のループ処理を行う。
              int size = reserveContractList.size();
              for (int i = 0; i < size; i++) {

                // 予備契約情報を取得する。
                KJ_InquiryReserveContractInformationEntityBean reserve = reserveContractList.get(i);

                // 予備契約情報の更新情報を設定する。
                ReserveContractHist record = createReserveContract(reserve, contractEndDate,
                    contextUserId, contextModuleCode);

                // 予備契約情報の更新条件を設定する。
                ReserveContractHistExample example = createReserveContractExample(reserve);

                // 予備契約更新呼び出し
                int reserveUpdateCount = reserveContractHistMapper.updateByExampleSelective(record,
                    example);

                // 予備契約更新結果が0件の場合
                if (reserveUpdateCount == 0) {

                  // リターンコードに（H001）を設定し返却する
                  updateContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_H001);
                  updateContractBusinessBean
                      .setMessage(messageSource.getMessage(
                          KJ_CommonUtil
                              .getMessageId(ECISReturnCodeConstants.RETURN_CODE_H001),
                          new String[] {}, Locale.getDefault()));
                  return updateContractBusinessBean;
                }
              }
            }
          }
        }

        if (updateContractBusinessBean.getContractStartDate() != null) {

          Date updateHistoryApplyStartDate = null;
          int updateCount = 0;

          // 更新対象の契約履歴を取得する。
          KJ_InquiryAgentContractInformationEntityBean bean = inquryContractList.get(0);
          int cnt = bean.getAgentContractHistoryInformationList().size();

          KJ_AgentContractHistoryInformationEntityBean histBean = bean
              .getAgentContractHistoryInformationList().get(cnt - 1);

          updateHistoryApplyStartDate = histBean.getApplyStartDate();
          updateCount = histBean.getUpdateCount();

          // 契約履歴更新
          ContractHist contractHistoryForUpdate = createUpdateContractStartHistory(
              updateContractBusinessBean,
              (updateCount + 1),
              contextUserId, contextModuleCode);

          // 更新済みの契約履歴を更新する場合、更新回数はカウントアップしない
          if (updateHistoryApplyStartDate.compareTo(bufTargetApplyStartDate) == 0) {
            contractHistoryForUpdate.setUpdateCount(bufUpdateCnt);
            updateCount = bufUpdateCnt;
          }

          ContractHistExample contractHistExample = new ContractHistExample();

          contractHistExample
              .createCriteria()
              .andContractIdEqualTo(
                  inquryContractList.get(0).getContractId())
              .andApplySdEqualTo(updateHistoryApplyStartDate)
              .andUpdateCountEqualTo(
                  updateCount);

          result = contractHistMapper.updateByExampleSelective(
              contractHistoryForUpdate, contractHistExample);
          // 更新結果が0件の場合リターンコードに（H001）を設定し返却する
          if (result == 0) {
            updateContractBusinessBean
                .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_H001);
            updateContractBusinessBean
                .setMessage(messageSource.getMessage(
                    KJ_CommonUtil
                        .getMessageId(ECISReturnCodeConstants.RETURN_CODE_H001),
                    new String[] {}, Locale.getDefault()));
            return updateContractBusinessBean;
          }

          // メータ設置場所契約履歴更新
          MlContractHist mlContractHistory = createUpdateMLContractStartHistory(
              updateContractBusinessBean,
              contextUserId, contextModuleCode);

          MlContractHistExample mlHistExample = new MlContractHistExample();

          mlHistExample
              .createCriteria()
              .andContractIdEqualTo(
                  inquryContractList.get(0).getContractId())
              .andApplySdEqualTo(updateHistoryApplyStartDate);

          result = mlContractHistMapper.updateByExampleSelective(
              mlContractHistory, mlHistExample);
          // 更新結果が0件の場合リターンコードに（H001）を設定し返却する
          if (result == 0) {
            updateContractBusinessBean
                .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_H001);
            updateContractBusinessBean
                .setMessage(messageSource.getMessage(
                    KJ_CommonUtil
                        .getMessageId(ECISReturnCodeConstants.RETURN_CODE_H001),
                    new String[] {}, Locale.getDefault()));
            return updateContractBusinessBean;
          }

          // 料金メニュー単価
          // 単価設定区分が個別単価の場合
          if (ECISConstants.UNIT_PRICE_SETTING_CATEGORY_INDIV.equals(
              histBean.getUnitPriceSetCategoryCode())) {

            if (histBean.getUnitPriceDetailInformationList().size() == 0) {
              // 取得結果が0件の場合、システムエラーとする
              throw new BusinessLogicException(errorMessage);
            }
            // 料金メニュー単価Entity
            RmUp rmup = createUpdateStartRmUp(
                updateContractBusinessBean,
                (histBean.getUnitPriceDetailInformationList().get(0).getUpdateCount() + 1),
                contextUserId, contextModuleCode);

            // 料金メニュー単価Example
            RmUpExample rmUpExample = new RmUpExample();

            rmUpExample
                .createCriteria()
                .andRmIdEqualTo(
                    histBean
                        .getRateMenuId())
                .andUpApplySdEqualTo(
                    updateHistoryApplyStartDate)
                .andUpCatCodeEqualTo(
                    histBean
                        .getContractId().toString())
                .andUpdateCountEqualTo(
                    histBean
                        .getUnitPriceDetailInformationList()
                        .get(0).getUpdateCount());

            // 料金メニュー単価更新呼び出し
            int countResult = rmUpMapper.updateByExampleSelective(rmup, rmUpExample);
            if (countResult == 0) {
              // 更新結果が0件の場合リターンコードに（H001）を設定し返却する
              updateContractBusinessBean
                  .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_H001);
              updateContractBusinessBean
                  .setMessage(messageSource.getMessage(
                      KJ_CommonUtil
                          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_H001),
                      new String[] {}, Locale.getDefault()));
              return updateContractBusinessBean;
            }

            // 料金メニュー単価明細Entity
            RmUpDetail rmUpDetail = createUpdateStartRmUpDetail(
                updateContractBusinessBean,
                contextUserId, contextModuleCode);

            // 料金メニュー単価明細Example
            RmUpDetailExample rmUpDetailExample = new RmUpDetailExample();
            rmUpDetailExample
                .createCriteria()
                .andRmIdEqualTo(histBean
                    .getRateMenuId())
                .andUpApplySdEqualTo(
                    updateHistoryApplyStartDate)
                .andUpCatCodeEqualTo(
                    histBean
                        .getContractId().toString());

            int rmUpDetailDeleteCount = rmUpDetailMapper.updateByExampleSelective(rmUpDetail,
                rmUpDetailExample);
            // 返却値が0件の場合リターンコードに（H001）を設定し返却する
            if (rmUpDetailDeleteCount == 0) {
              updateContractBusinessBean
                  .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_H001);

              updateContractBusinessBean
                  .setMessage(messageSource.getMessage(
                      KJ_CommonUtil
                          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_H001),
                      new String[] {}, Locale.getDefault()));
              return updateContractBusinessBean;
            }
          }
        }
      }
      updateContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);
      // 契約IDを返す
      updateContractBusinessBean
          .setContractId(inquryContractList.get(0).getContractId());

    } catch (BusinessLogicException businessLogicException) {
      logger.error(
          messageSource.getMessage("error.E1129", null,
              Locale.getDefault()),
          businessLogicException);
      // 業務例外クラス
      updateContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      updateContractBusinessBean.setMessage(errorMessage);
    } catch (DataAccessException exception) {
      logger.error(
          messageSource.getMessage("error.E1129", null,
              Locale.getDefault()),
          exception);
      updateContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      updateContractBusinessBean.setMessage(errorMessage);
    } catch (NoSuchMessageException ioe) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, ioe);
      updateContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      updateContractBusinessBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
    } catch (SystemException se) {
      logger.error(
          messageSource.getMessage("error.E1129", null,
              Locale.getDefault()),
          se);
      updateContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      updateContractBusinessBean.setMessage(errorMessage);
    }
    return updateContractBusinessBean;
  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.kj.
   * KJ_AgentContractInformationBusiness #delete(jp.co.unisys.enability.cis
   * .business.kj.model.DeleteAgentContractBusinessBean)
   */
  @Override
  public DeleteAgentContractBusinessBean delete(
      DeleteAgentContractBusinessBean deleteContractBusinessBean) {

    String errorMessage = null;

    try {

      errorMessage = messageSource.getMessage(KJ_CommonUtil
          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G017),
          new String[] {}, Locale.getDefault());
      // 契約情報存在チェック
      InquiryAgentContractBusinessBean inquiryContractBusinessBean = new InquiryAgentContractBusinessBean();

      Integer deleteContractId = deleteContractBusinessBean
          .getContractId();
      String deleteContractNo = deleteContractBusinessBean
          .getContractNo();
      Date deleteContractApplyStartDate = deleteContractBusinessBean
          .getApplyStartDate();

      inquiryContractBusinessBean.setContractId(deleteContractId);
      inquiryContractBusinessBean.setContractNo(deleteContractNo);

      InquiryAgentContractBusinessBean resultInquiry = inquiry(inquiryContractBusinessBean);
      String inquiryReturnCode = resultInquiry.getReturnCode();
      List<KJ_InquiryAgentContractInformationEntityBean> inquryList = resultInquiry
          .getAgentContractInformationList();
      // リターンコードが'0000'以外の場合、業務例外クラスをスローする。
      if (!ECISReturnCodeConstants.RETURN_CODE_0000
          .equals(inquiryReturnCode)) {

        throw new BusinessLogicException(messageSource.getMessage(
            "error.E1285", new String[] {}, Locale.getDefault()),
            false);
      }
      // リターンコードが'0000'かつ返却値が0件の場合リターンコードに(P005)を設定し返却する
      if (CollectionUtils.isEmpty(inquryList)) {

        deleteContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P005);
        deleteContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P005),
                new String[] {}, Locale.getDefault()));
        return deleteContractBusinessBean;
      }

      // 契約終了状態判定のため、算定期間チェックを行う。
      Map<String, Object> exampleMap = new HashMap<String, Object>();
      exampleMap.put("contractId", inquryList.get(0).getContractId());
      exampleMap.put("coveredDate", inquryList.get(0)
          .getContractEndDate());
      exampleMap
          .put("flg",
              ECISKJConstants.INQUIRY_FIX_CHANGE_RESULT_INFOEMATION_FLG_TWO);
      int resultCount = fixChargeResultInformationCommonMapper
          .countByFixChargeResult(exampleMap);
      // 結果が1件以上の場合リターンコードに（D025）を設定し返却する
      if (resultCount >= 1) {
        deleteContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D025);
        deleteContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D025),
                new String[] {}, Locale.getDefault()));
        return deleteContractBusinessBean;
      }

      List<KJ_AgentContractHistoryInformationEntityBean> contractHistList = inquryList
          .get(0).getAgentContractHistoryInformationList();

      // 《契約情報照会EntityBean》（最新）
      KJ_AgentContractHistoryInformationEntityBean contractHistNew = contractHistList
          .get(0);

      KJ_AgentContractHistoryInformationEntityBean contractHistLast = null;
      // 契約情報リストが2件以上の場合《契約情報照会EntityBean》（前回）に契約情報リストの二件目を設定する。
      if (contractHistList.size() >= 2) {
        contractHistLast = contractHistList.get(1);
      }

      Date newContractApplyStartDate = contractHistNew
          .getApplyStartDate();
      // 《契約情報照会EntityBean》（最新）.適用開始日と《契約情報削除BusinessBean》.適用開始日が一致しない場合、G001
      if (deleteContractApplyStartDate
          .compareTo(newContractApplyStartDate) != 0) {

        deleteContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G001);
        deleteContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G001),
                new String[] {}, Locale.getDefault()));
        return deleteContractBusinessBean;
      }

      Integer newContractId = contractHistNew.getContractId();

      Map<String, Object> fixParamMap = new HashMap<String, Object>();
      fixParamMap.put("contractId", newContractId);
      fixParamMap.put("coveredDate", deleteContractApplyStartDate);
      fixParamMap
          .put("flg",
              ECISKJConstants.INQUIRY_FIX_CHANGE_RESULT_INFOEMATION_FLG_ON);

      // 確定料金チェック
      Integer fixChargeResultCount = fixChargeResultInformationCommonMapper
          .countByFixChargeResult(fixParamMap);
      // 結果が1件以上の場合リターンコードに（D009）を設定し返却する。
      if (fixChargeResultCount >= 1) {

        deleteContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D009);
        deleteContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D009),
                new String[] {}, Locale.getDefault()));
        return deleteContractBusinessBean;
      }
      // 付帯契約情報存在チェック
      if (contractHistLast == null) {
        // 《契約情報照会EntityBean》(前回)がNULLの場合
        InquirySupplementaryContractBusinessBean inquirySupplementaryContractBusinessBean = new InquirySupplementaryContractBusinessBean();
        inquirySupplementaryContractBusinessBean
            .setContractId(newContractId);

        InquirySupplementaryContractBusinessBean resultSupplementryContract = kjSupplementaryContractInformationBusiness
            .inquiry(inquirySupplementaryContractBusinessBean);
        List<KJ_SupplementaryContractInformationEntityBean> supplementryContractList = resultSupplementryContract
            .getSupplementaryContractList();
        String supplementReturnCode = resultSupplementryContract
            .getReturnCode();

        // リターンコードが'0000'以外の場合、業務例外クラスをスローする。
        if (!ECISReturnCodeConstants.RETURN_CODE_0000
            .equals(supplementReturnCode)) {

          throw new BusinessLogicException(
              messageSource.getMessage("error.E1284",
                  new String[] {}, Locale.getDefault()),
              false);
        }

        // リターンコードが'0000'かつ返却値が1件以上の場合リターンコードに（D001）を設定し返却する。
        if (!CollectionUtils.isEmpty(supplementryContractList)) {

          deleteContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D001);
          deleteContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D001),
                  new String[] {}, Locale.getDefault()));
          return deleteContractBusinessBean;
        }

        // 予備契約情報存在チェック
        InquiryReserveContractBusinessBean inquiryReserveContractBusinessBean = new InquiryReserveContractBusinessBean();

        inquiryReserveContractBusinessBean.setContractId(newContractId);

        InquiryReserveContractBusinessBean resultReserveContract = kjReserveContractInformationBusiness
            .inquiry(inquiryReserveContractBusinessBean);

        List<KJ_InquiryReserveContractInformationEntityBean> reserveContractList = resultReserveContract
            .getReserveContractList();

        String reserveReturnCode = resultReserveContract.getReturnCode();

        // リターンコードが'0000'以外の場合、業務例外クラスをスローする。
        if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(reserveReturnCode)) {

          throw new BusinessLogicException(
              messageSource.getMessage("error.E1735", new String[] {}, Locale.getDefault()), false);
        }

        // リターンコードが'0000'かつ返却値が1件以上の場合リターンコードに（D027）を設定し返却する。
        if (CollectionUtils.isNotEmpty(reserveContractList)) {

          deleteContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D027);
          deleteContractBusinessBean.setMessage(messageSource.getMessage(KJ_CommonUtil.getMessageId(
              ECISReturnCodeConstants.RETURN_CODE_D027), new String[] {}, Locale.getDefault()));

          return deleteContractBusinessBean;
        }

        // 制限中止割引情報存在チェック
        Map<String, Object> restrictionMap = new HashMap<String, Object>();

        // 契約ID
        restrictionMap.put("id", newContractId);

        int restrictionReturnCount = contractInformationMapper.countByRestrictionDiscountInfo(restrictionMap);

        // 返却値が1件以上の場合リターンコードに（D032）を設定し返却する。
        if (restrictionReturnCount >= 1) {

          deleteContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D032);
          deleteContractBusinessBean.setMessage(messageSource.getMessage(KJ_CommonUtil.getMessageId(
              ECISReturnCodeConstants.RETURN_CODE_D032), new String[] {}, Locale.getDefault()));

          return deleteContractBusinessBean;
        }
      }

      // 契約履歴情報取得
      // 引数のキーと値をMapに関連付ける。
      Map<String, Object> contractHistoryParam = new HashMap<String, Object>();
      contractHistoryParam.put("contractId", newContractId);
      contractHistoryParam.put("applyStartDate",
          deleteContractApplyStartDate);

      KJ_ContractHistoryUpdateCountEntityBean resultHistoryBean = contractInformationCommonMapper
          .searchContractHistory(contractHistoryParam);
      // 取得した契約履歴更新回数情報が０件の場合、業務例外クラスをスローする。
      if (resultHistoryBean == null) {
        throw new BusinessLogicException(errorMessage, false);
      }

      // 契約削除
      // 《契約情報照会EntityBean》(前回)がNULLの場合
      if (contractHistLast == null) {

        // 契約削除
        ContractExample deleteLastContractExample = new ContractExample();
        Integer deleteContractUpdateCount = deleteContractBusinessBean
            .getUpdateCount();

        deleteLastContractExample.createCriteria()
            .andContractIdEqualTo(newContractId)
            .andUpdateCountEqualTo(deleteContractUpdateCount);

        // 《契約Mapper》.削除（選択項目）呼び出し
        int deleteCount = contractMapper
            .deleteByExample(deleteLastContractExample);
        // 返却値が0件の場合リターンコードに（H001）を設定し返却する。
        if (deleteCount == 0) {
          deleteContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_H001);

          deleteContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_H001),
                  new String[] {}, Locale.getDefault()));
          return deleteContractBusinessBean;
        }

        // 契約付加削除
        ContractAddInfoExample deleteLastContractAddInfoExample = new ContractAddInfoExample();
        Integer deleteLastContractAddInfoUpdateCount = deleteContractBusinessBean
            .getUpdateCount();

        deleteLastContractAddInfoExample.createCriteria()
            .andContractIdEqualTo(newContractId)
            .andUpdateCountEqualTo(deleteLastContractAddInfoUpdateCount);

        // 《契約Mapper》.削除（選択項目）呼び出し
        int deleteContractAddInfoCount = contractAddInfoMapper
            .deleteByExample(deleteLastContractAddInfoExample);
        // 返却値が0件の場合リターンコードに（H001）を設定し返却する。
        if (deleteContractAddInfoCount == 0) {
          deleteContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_H001);

          deleteContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_H001),
                  new String[] {}, Locale.getDefault()));
          return deleteContractBusinessBean;
        }
      }

      // コンテキスト・ユーザID
      String contextUserId = ThreadContext.getRequestThreadContext()
          .get(ECISConstants.USER_ID_KEY).toString();
      // コンテキスト.モジュールコード
      String contextModuleCode = ThreadContext.getRequestThreadContext()
          .get(ECISConstants.CLASS_NAME_KEY).toString();
      Integer deleteContractUpdateCount = deleteContractBusinessBean
          .getUpdateCount();
      // 更新
      // 《契約情報照会EntityBean》(前回)がNULLではない場合
      if (contractHistLast != null) {

        // 契約更新
        Contract updateContract = new Contract();
        // 更新回数に《契約情報削除BusinessBean》.更新回数に1加算した値を設定する
        Integer updateCount = deleteContractUpdateCount + 1;
        // システム日時
        Timestamp sysetmTime = new Timestamp(System.currentTimeMillis());
        updateContract.setUpdateCount(updateCount);
        updateContract.setOnlineUpdateTime(sysetmTime);
        updateContract.setOnlineUpdateUserId(contextUserId);
        updateContract.setUpdateTime(sysetmTime);
        updateContract.setUpdateModuleCode(contextModuleCode);

        ContractExample contractExample = new ContractExample();
        contractExample.createCriteria()
            .andContractIdEqualTo(newContractId)
            .andUpdateCountEqualTo(deleteContractUpdateCount);

        int updateContractCount = contractMapper
            .updateByExampleSelective(updateContract,
                contractExample);
        // 返却値が0件の場合リターンコードに（H001）を設定し返却する。
        if (updateContractCount == 0) {
          deleteContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_H001);
          deleteContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_H001),
                  new String[] {}, Locale.getDefault()));
          return deleteContractBusinessBean;
        }

        // 契約付加更新
        ContractAddInfo updateContractAddInfo = new ContractAddInfo();
        // システム日時
        updateContractAddInfo.setUpdateCount(updateCount);
        updateContractAddInfo.setOnlineUpdateTime(sysetmTime);
        updateContractAddInfo.setOnlineUpdateUserId(contextUserId);
        updateContractAddInfo.setUpdateTime(sysetmTime);
        updateContractAddInfo.setUpdateModuleCode(contextModuleCode);

        ContractAddInfoExample contractAddIfoExample = new ContractAddInfoExample();
        contractAddIfoExample.createCriteria()
            .andContractIdEqualTo(newContractId)
            .andUpdateCountEqualTo(deleteContractUpdateCount);

        int updateContractAddInfoCount = contractAddInfoMapper
            .updateByExampleSelective(updateContractAddInfo,
                contractAddIfoExample);
        // 返却値が0件の場合リターンコードに（H001）を設定し返却する。
        if (updateContractAddInfoCount == 0) {
          deleteContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_H001);
          deleteContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_H001),
                  new String[] {}, Locale.getDefault()));
          return deleteContractBusinessBean;
        }
      }

      // 契約履歴削除
      ContractHistExample contractHistoryExample = new ContractHistExample();
      contractHistoryExample.createCriteria()
          .andContractIdEqualTo(newContractId)
          .andApplySdEqualTo(deleteContractApplyStartDate)
          .andUpdateCountEqualTo(resultHistoryBean.getUpdateCount());

      int contractHistoryDeleteCount = contractHistMapper
          .deleteByExample(contractHistoryExample);
      // 返却値が0件の場合リターンコードに（H001）を設定し返却する
      if (contractHistoryDeleteCount == 0) {
        deleteContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_H001);

        deleteContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_H001),
                new String[] {}, Locale.getDefault()));
        return deleteContractBusinessBean;
      }

      // 料金メニュー単価と料金メニュー単価明細削除
      if (!ECISConstants.UNIT_PRICE_SETTING_CATEGORY_DEF
          .equals(contractHistNew.getUnitPriceSetCategoryCode())) {
        // 料金メニュー単価の削除
        RmUpExample rmUpExample = new RmUpExample();
        rmUpExample
            .createCriteria()
            .andRmIdEqualTo(contractHistNew.getRateMenuId())
            .andUpApplySdEqualTo(deleteContractApplyStartDate)
            .andUpCatCodeEqualTo(
                contractHistNew
                    .getUnitPriceDetailInformationList()
                    .get(0).getUnitPriceCategoryCode())
            .andUpdateCountEqualTo(
                contractHistNew
                    .getUnitPriceDetailInformationList()
                    .get(0).getUpdateCount());

        int rmUpDeleteCount = rmUpMapper.deleteByExample(rmUpExample);
        // 返却値が0件の場合リターンコードに（H001）を設定し返却する
        if (rmUpDeleteCount == 0) {
          deleteContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_H001);

          deleteContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_H001),
                  new String[] {}, Locale.getDefault()));
          return deleteContractBusinessBean;
        }
        // 料金メニュー単価明細の削除
        RmUpDetailExample rmUpDetailExample = new RmUpDetailExample();
        rmUpDetailExample
            .createCriteria()
            .andRmIdEqualTo(contractHistNew.getRateMenuId())
            .andUpApplySdEqualTo(deleteContractApplyStartDate)
            .andUpCatCodeEqualTo(
                contractHistNew
                    .getUnitPriceDetailInformationList()
                    .get(0).getUnitPriceCategoryCode());

        int rmUpDetailDeleteCount = rmUpDetailMapper.deleteByExample(rmUpDetailExample);
        // 返却値が0件の場合リターンコードに（H001）を設定し返却する
        if (rmUpDetailDeleteCount == 0) {
          deleteContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_H001);

          deleteContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_H001),
                  new String[] {}, Locale.getDefault()));
          return deleteContractBusinessBean;
        }

      }

      // メータ設置場所契約履歴削除
      MlContractHistExample mlHistory = new MlContractHistExample();
      mlHistory.createCriteria().andContractIdEqualTo(newContractId)
          .andApplySdEqualTo(deleteContractApplyStartDate)
          .andUpdateCountEqualTo(0);

      int mlDeleteCount = mlContractHistMapper.deleteByExample(mlHistory);
      // 返却値が0件の場合リターンコードに（H001）を設定し返却する。
      if (mlDeleteCount == 0) {

        deleteContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_H001);

        deleteContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_H001),
                new String[] {}, Locale.getDefault()));
        return deleteContractBusinessBean;
      }
      // 《契約情報照会EntityBean》(前回)がNULLではない場合
      if (contractHistLast != null) {

        // 契約履歴更新
        Integer lastContractId = contractHistLast.getContractId();
        Integer lastContractUpdateCount = contractHistLast
            .getUpdateCount();
        Date newApplyEndDate = inquryList.get(0).getContractEndDate();
        int updateCount = lastContractUpdateCount + 1;
        // システム日時
        Timestamp sysetmTime = new Timestamp(System.currentTimeMillis());
        ContractHist contractHistory = new ContractHist();
        contractHistory.setApplyEd(newApplyEndDate);
        contractHistory.setUpdateCount(updateCount);
        contractHistory.setOnlineUpdateTime(sysetmTime);
        contractHistory.setOnlineUpdateUserId(contextUserId);
        contractHistory.setUpdateTime(sysetmTime);
        contractHistory.setUpdateModuleCode(contextModuleCode);

        ContractHistExample lastContractHistExample = new ContractHistExample();
        // (前回).契約IDを設定する。
        // (前回).適用開始日を設定する。
        // (前回).更新回数を設定する。
        lastContractHistExample
            .createCriteria()
            .andContractIdEqualTo(lastContractId)
            .andApplySdEqualTo(contractHistLast.getApplyStartDate())
            .andUpdateCountEqualTo(lastContractUpdateCount);

        int updateLastContractCount = contractHistMapper
            .updateByExampleSelective(contractHistory,
                lastContractHistExample);

        // 返却値が0件の場合リターンコードに（H001）を設定し返却する。
        if (updateLastContractCount == 0) {

          deleteContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_H001);
          deleteContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_H001),
                  new String[] {}, Locale.getDefault()));
          return deleteContractBusinessBean;
        }

        // 前回料金メニュー単価更新
        if (!ECISConstants.UNIT_PRICE_SETTING_CATEGORY_DEF
            .equals(contractHistLast.getUnitPriceSetCategoryCode())) {
          // システム日時
          sysetmTime = new Timestamp(System.currentTimeMillis());
          RmUp rmUp = new RmUp();
          rmUp.setUpApplyEd(inquryList.get(0).getContractEndDate());
          rmUp.setUpdateCount(contractHistLast
              .getUnitPriceDetailInformationList().get(0)
              .getUpdateCount() + 1);
          rmUp.setOnlineUpdateTime(sysetmTime);
          rmUp.setOnlineUpdateUserId(contextUserId);
          rmUp.setUpdateTime(sysetmTime);
          rmUp.setUpdateModuleCode(contextModuleCode);

          RmUpExample lastrmUpExample = new RmUpExample();
          // (前回).料金メニューIDを設定する。
          // (前回).適用開始日を設定する。
          // (前回).単価設定区分コードを設定する。
          // (前回).更新回数を設定する。
          lastrmUpExample
              .createCriteria()
              .andRmIdEqualTo(contractHistLast.getRateMenuId())
              .andUpApplySdEqualTo(
                  contractHistLast.getApplyStartDate())
              .andUpCatCodeEqualTo(
                  contractHistLast
                      .getUnitPriceDetailInformationList()
                      .get(0).getUnitPriceCategoryCode())
              .andUpdateCountEqualTo(
                  contractHistLast
                      .getUnitPriceDetailInformationList()
                      .get(0).getUpdateCount());

          int updateLastrmUpCount = rmUpMapper
              .updateByExampleSelective(rmUp, lastrmUpExample);

          // 返却値が0件の場合リターンコードに（H001）を設定し返却する。
          if (updateLastrmUpCount == 0) {

            deleteContractBusinessBean
                .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_H001);
            deleteContractBusinessBean
                .setMessage(messageSource.getMessage(
                    KJ_CommonUtil
                        .getMessageId(ECISReturnCodeConstants.RETURN_CODE_H001),
                    new String[] {}, Locale.getDefault()));
            return deleteContractBusinessBean;
          }
        }
      }

      // 正常終了
      deleteContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);
      deleteContractBusinessBean
          .setContractId(newContractId);

    } catch (BusinessLogicException businessLosicException) {
      logger.error(
          messageSource.getMessage("error.E1129", null,
              Locale.getDefault()),
          businessLosicException);
      // リターンコードに（G017）を設定し返却する。
      deleteContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      deleteContractBusinessBean.setMessage(errorMessage);
    } catch (NoSuchMessageException ioe) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, ioe);
      deleteContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      deleteContractBusinessBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
    } catch (DataAccessException e) {
      logger.error(
          messageSource.getMessage("error.E1129", null,
              Locale.getDefault()),
          e);
      deleteContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      deleteContractBusinessBean.setMessage(errorMessage);
    }

    return deleteContractBusinessBean;
  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.kj.
   * KJ_AgentContractInformationBusiness #add(jp.co.unisys.enability.cis
   * .business.kj.model.AddAgentContractBusinessBean)
   */
  @Override
  public AddAgentContractBusinessBean add(
      AddAgentContractBusinessBean addContractBusinessBean) {

    String errorMessage = null;
    try {
      errorMessage = messageSource.getMessage(KJ_CommonUtil
          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G017),
          new String[] {}, Locale.getDefault());

      Integer meterLocationId = addContractBusinessBean
          .getMeterLocationId();
      InquiryAgentMeterLocationBusinessBean inquiryMeterLocationBusinessBean = new InquiryAgentMeterLocationBusinessBean();
      String contractNo = addContractBusinessBean.getContractNo();
      // メータ設置場所IDがNULLでない場合
      if (meterLocationId != null) {
        // メータ設置場所照会
        inquiryMeterLocationBusinessBean
            .setMeterLocationId(meterLocationId);
        InquiryAgentMeterLocationBusinessBean meterLocationResult = kjMeterLocationInformationBusiness
            .inquiry(inquiryMeterLocationBusinessBean);

        List<KJ_InquiryAgentMeterLocationEntityBean> resultMlBeanList = meterLocationResult
            .getMeterLocationList();
        String meterLocationReturnCode = meterLocationResult
            .getReturnCode();

        // リターンコードが“0000”以外の場合
        if (!ECISReturnCodeConstants.RETURN_CODE_0000
            .equals(meterLocationReturnCode)) {

          // 《契約情報追加BusinessBean》.リターンコードに《メータ設置場所照会BusinessBean》.リターンコードを設定し返却する。
          addContractBusinessBean
              .setReturnCode(meterLocationReturnCode);
          addContractBusinessBean.setMessage(meterLocationResult
              .getMessage());
          return addContractBusinessBean;
        }
        // リターンコードが“0000”かつ返却値が0件の場合リターンコード（P008）を設定し返却する。
        if (CollectionUtils.isEmpty(resultMlBeanList)) {

          addContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P008);
          addContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P008),
                  new String[] {}, Locale.getDefault()));
          return addContractBusinessBean;
        }

        // メータ設置場所更新
        UpdateAgentMeterLocationBusinessBean updateMlBean = createUpdateAgentMeterLocationBusinessBean(
            addContractBusinessBean);

        UpdateAgentMeterLocationBusinessBean returnUpdateMl = kjMeterLocationInformationBusiness
            .update(updateMlBean);
        String returnCodeUpdateMl = returnUpdateMl.getReturnCode();
        // リターンコードが“0000”以外の場合《契約情報追加BusinessBean》.リターンコードに《メータ設置場所更新BusinessBean》.リターンコードを設定し返却する。
        if (!ECISReturnCodeConstants.RETURN_CODE_0000
            .equals(returnCodeUpdateMl)) {
          addContractBusinessBean.setReturnCode(returnCodeUpdateMl);
          addContractBusinessBean.setMessage(returnUpdateMl
              .getMessage());
          return addContractBusinessBean;
        }
        addContractBusinessBean.setPlaceId(meterLocationResult
            .getMeterLocationList().get(0).getPlaceId());
      } else {
        // メータ設置場所IDがNULLの場合

        // 次回検針予定日判定
        Date nextMeterReadingScheduledDate = addContractBusinessBean
            .getNextMeterReadingScheduledDate();
        Date contractStartDate = addContractBusinessBean
            .getContractStartDate();
        // 次回検針予定日 < 契約開始日の場合
        if (nextMeterReadingScheduledDate.before(contractStartDate)) {

          // 《契約情報追加BusinessBean》.次回検針予定日に 契約開始日 +
          // 外部ファイル.次回検針予定日加算日数を設定する
          Date externalNextSucheduleDate = dateBusiness
              .calcWorkDate(
                  contractStartDate,
                  ECISCodeConstants.WORK_DAYS_FOR_NEXT_METER_READING_SCHEDULED_DATE_ADD_DAYS);

          addContractBusinessBean
              .setNextMeterReadingScheduledDate(externalNextSucheduleDate);
        }

        // メータ設置場所登録
        RegistAgentMeterLocationBusinessBean registerMlBean = createRegistMeterLocationBusinessBean(
            addContractBusinessBean);
        RegistAgentMeterLocationBusinessBean returnRegisterMlBean = kjMeterLocationInformationBusiness
            .regist(registerMlBean);
        String returnCodeRegister = returnRegisterMlBean
            .getReturnCode();
        // リターンコードが“0000”以外の場合《契約情報追加BusinessBean》.リターンコードに《メータ設置場所登録BusinessBean》.リターンコードを設定し返却する。
        if (!ECISReturnCodeConstants.RETURN_CODE_0000
            .equals(returnCodeRegister)) {
          addContractBusinessBean.setReturnCode(returnCodeRegister);
          addContractBusinessBean.setMessage(returnRegisterMlBean
              .getMessage());
          return addContractBusinessBean;
        }
        // ID設定
        addContractBusinessBean.setPlaceId(returnRegisterMlBean
            .getPlaceId());
        addContractBusinessBean.setMeterLocationId(returnRegisterMlBean
            .getMeterLocationId());
      }
      // 契約登録
      RegistAgentContractBusinessBean registerContractBean = createRegistAgentContractBusinessBean(
          addContractBusinessBean);
      RegistAgentContractBusinessBean resultRegisterContractBean = regist(registerContractBean);
      String returnCodeRegisterContract = resultRegisterContractBean
          .getReturnCode();

      // リターンコードが“0000”以外の場合《契約情報追加BusinessBean》.リターンコードにregistBean.リターンコードを設定し返却する
      if (!ECISReturnCodeConstants.RETURN_CODE_0000
          .equals(returnCodeRegisterContract)) {
        addContractBusinessBean
            .setReturnCode(returnCodeRegisterContract);
        addContractBusinessBean.setMessage(resultRegisterContractBean
            .getMessage());
        return addContractBusinessBean;
      }

      addContractBusinessBean.setContractId(registerContractBean
          .getContractId());
      List<KJ_SupplementaryContractBean> sContractSupplementList = addContractBusinessBean
          .getSupplementaryContractList();

      // 《契約情報追加BusinessBean》.付帯契約情報リスト分、以下の処理を繰り返す。
      if (sContractSupplementList != null) {
        // Beanに渡す用の付帯契約IDリスト
        List<Integer> supplementIdList = new ArrayList<Integer>();

        Integer contractId = registerContractBean.getContractId();

        for (KJ_SupplementaryContractBean supplement : sContractSupplementList) {
          // 付帯契約情報追加
          AddSupplementaryContractBusinessBean addSupplementBean = new AddSupplementaryContractBusinessBean();

          // 額・率
          addSupplementBean.setAmountOrRate(supplement
              .getAmountOrRate());
          // 契約ID
          addSupplementBean.setContractId(contractId);
          // 契約番号
          addSupplementBean.setContractNo(contractNo);
          // 付帯契約終了日
          addSupplementBean
              .setSupplementaryContractEndDate(supplement
                  .getSupplementaryContractEndDate());

          // 付帯メニューID
          addSupplementBean.setSupplementaryMenuId(supplement
              .getSupplementaryMenuId());
          // 付帯契約開始日
          addSupplementBean
              .setSupplementaryContractStartDate(supplement
                  .getSupplementaryContractStartDate());

          AddSupplementaryContractBusinessBean resultAddSupple = kjSupplementaryContractInformationBusiness
              .add(addSupplementBean);
          String returnCodeAddSBean = resultAddSupple.getReturnCode();
          if (!ECISReturnCodeConstants.RETURN_CODE_0000
              .equals(returnCodeAddSBean)) {
            // リターンコードが“0000”以外の場合リターンコードに《付帯契約情報追加BusinessBean》.リターンコードを設定し返却する
            addContractBusinessBean
                .setReturnCode(returnCodeAddSBean);
            addContractBusinessBean.setMessage(resultAddSupple
                .getMessage());
            return addContractBusinessBean;
          }
          // 付帯契約リスト.付帯契約IDに付帯契約IDを設定する
          Integer supplementaryContractId = resultAddSupple
              .getSupplementaryContractId();
          supplementIdList.add(supplementaryContractId);
        }
        // 《契約情報追加BusinessBean》.付帯契約IDリストに付帯契約IDリストを設定する
        addContractBusinessBean
            .setSupplementaryContractIdList(supplementIdList);
      }
      addContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);
    } catch (DataAccessException e) {
      logger.error(
          messageSource.getMessage("error.E1129", null,
              Locale.getDefault()),
          e);
      // リターンコードに（G017）を設定し処理を終了する。
      addContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      addContractBusinessBean.setMessage(errorMessage);
    } catch (NoSuchMessageException ioe) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, ioe);
      addContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      addContractBusinessBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
    } catch (SystemException se) {
      logger.error(
          messageSource.getMessage("error.E1129", null,
              Locale.getDefault()),
          se);
      addContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      addContractBusinessBean.setMessage(errorMessage);
    }
    return addContractBusinessBean;
  }

  /**
   * 契約履歴リストの適用開始日のリスト中に適用開始日より未来日が存在した場合TRUE
   *
   * @param contractList
   *          契約情報照会List
   * @param applyStartDate
   *          適用開始日
   * @return Boolean
   */
  private boolean isFeature(
      List<KJ_InquiryAgentContractInformationEntityBean> contractList,
      Date applyStartDate) {
    int size = contractList.size();
    for (int i = 0; i < size; i++) {
      KJ_InquiryAgentContractInformationEntityBean contract = contractList
          .get(i);
      // 契約情報リストから契約履歴リストを取得
      List<KJ_AgentContractHistoryInformationEntityBean> contractHistoryList = contract
          .getAgentContractHistoryInformationList();
      if (CollectionUtils.isEmpty(contractHistoryList)) {
        continue;
      }
      int hSize = contractHistoryList.size();
      for (int t = 0; t < hSize; t++) {
        KJ_AgentContractHistoryInformationEntityBean contractHistory = contractHistoryList
            .get(t);
        // 契約履歴リストから適用開始日を取得して比較
        Date historyApplyStartDate = contractHistory
            .getApplyStartDate();

        if (historyApplyStartDate.after(applyStartDate)) {
          return true;
        }
      }
    }
    return false;
  }

  /**
   * 契約登録BusinessBeanを返す
   *
   * @param AddAgentContractBusinessBean
   *          契約情報追加BusinessBean
   * @return RegistAgentContractBusinessBean 契約情報登録BusinessBean
   */
  private RegistAgentContractBusinessBean createRegistAgentContractBusinessBean(
      AddAgentContractBusinessBean addContractBusinessBean) {

    RegistAgentContractBusinessBean registContractBusinessBean = new RegistAgentContractBusinessBean();

    // 契約番号
    registContractBusinessBean.setContractNo(addContractBusinessBean
        .getContractNo());

    // 契約者ID
    registContractBusinessBean.setContractorId(addContractBusinessBean
        .getContractorId());

    // 契約者番号
    registContractBusinessBean.setContractorNo(addContractBusinessBean
        .getContractorNo());

    // 支払ID
    registContractBusinessBean.setPaymentId(addContractBusinessBean
        .getPaymentId());

    // 支払番号
    registContractBusinessBean.setPaymentNo(addContractBusinessBean
        .getPaymentNo());

    // メータ設置場所ID
    registContractBusinessBean.setMeterLocationId(addContractBusinessBean
        .getMeterLocationId());

    // 契約開始日
    registContractBusinessBean.setContractStartDate(addContractBusinessBean
        .getContractStartDate());

    // 契約終了日
    registContractBusinessBean.setContractEndDate(addContractBusinessBean
        .getContractEndDate());

    // 契約終了理由コード
    registContractBusinessBean
        .setContractEndReasonCode(addContractBusinessBean
            .getContractEndReasonCode());

    // 託送契約容量
    registContractBusinessBean
        .setConsignmentContractCapacity(addContractBusinessBean
            .getConsignmentContractCapacity());

    // 託送契約容量単位コード
    registContractBusinessBean
        .setConsignmentcontractCapacityUnitCode(addContractBusinessBean
            .getConsignmentcontractCapacityUnitCode());

    // 託送契約容量判定日
    registContractBusinessBean
        .setConsignmentContractCapacityDecisionDate(addContractBusinessBean
            .getConsignmentContractCapacityDecisionDate());

    // 料金チェックフラグ
    registContractBusinessBean.setChargeCheckFlag(addContractBusinessBean
        .getChargeCheckFlag());

    // 契約グループ番号
    registContractBusinessBean.setContractGroupNo(addContractBusinessBean
        .getContractGroupNo());

    // 連絡先個人・法人区分コード
    registContractBusinessBean
        .setContactInformationinDividualLegalEntityCategoryCode(addContractBusinessBean
            .getContactInformationindividualLegalEntityCategoryCode());

    // 連絡先氏名（カナ）
    registContractBusinessBean
        .setContractInformationNameKana(addContractBusinessBean
            .getContractInformationNameKana());

    // 連絡先氏名1
    registContractBusinessBean
        .setContractInformationName1(addContractBusinessBean
            .getContractInformationName1());

    // 連絡先氏名2
    registContractBusinessBean
        .setContractInformationName2(addContractBusinessBean
            .getContractInformationName2());

    // 連絡先住所（郵便番号）
    registContractBusinessBean
        .setContractInformationAddressPostalCode(addContractBusinessBean
            .getContractInformationAddressPostalCode());

    // 連絡先住所（住所）
    registContractBusinessBean
        .setContractInformationAddressFull(addContractBusinessBean
            .getContractInformationAddressFull());

    // 連絡先住所（建物・部屋名）
    registContractBusinessBean
        .setContractInformationAddressBuilding(addContractBusinessBean
            .getContractInformationAddressBuilding());

    // 連絡先電話区分コード
    registContractBusinessBean
        .setContractInformationCategoryCode(addContractBusinessBean
            .getContractInformationCategoryCode());

    // 連絡先電話（市外局番）
    registContractBusinessBean
        .setContractInformationAreaCode(addContractBusinessBean
            .getContractInformationAreaCode());

    // 連絡先電話（市内局番）
    registContractBusinessBean
        .setContractInformationLocalNo(addContractBusinessBean
            .getContractInformationLocalNo());

    // 連絡先電話（加入者番号）
    registContractBusinessBean
        .setContractInformationDirectoryNo(addContractBusinessBean
            .getContractInformationDirectoryNo());

    // 需要者窓口連絡先所属
    registContractBusinessBean
        .setConsumerContractAffiliation(addContractBusinessBean
            .getConsumerContractAffiliation());

    // 需要者窓口連絡先氏名
    registContractBusinessBean
        .setConsumerContractName(addContractBusinessBean
            .getConsumerContractName());
    // 需要者窓口電話番号（市外局番）
    registContractBusinessBean
        .setConsumerContractAreaCode(addContractBusinessBean
            .getConsumerContractAreaCode());

    // 需要者窓口電話番号（市内局番）
    registContractBusinessBean
        .setConsumerContractLocalNo(addContractBusinessBean
            .getConsumerContractLocalNo());

    // 需要者窓口電話番号（加入者番号）
    registContractBusinessBean
        .setConsumerContractDirectoryNo(addContractBusinessBean
            .getConsumerContractDirectoryNo());

    // 主任技術者連絡先所属
    registContractBusinessBean
        .setChiefEngineerOfficerAffiliation(addContractBusinessBean
            .getChiefEngineerOfficerAffiliation());

    //主任技術者連絡先氏名
    registContractBusinessBean
        .setChiefEngineerOfficerName(addContractBusinessBean
            .getChiefEngineerOfficerName());
    // 主任技術者電話番号（市外局番）
    registContractBusinessBean
        .setChiefEngineerOfficerAreaCode(addContractBusinessBean
            .getChiefEngineerOfficerAreaCode());

    // 主任技術者電話番号（市内局番）
    registContractBusinessBean
        .setChiefEngineerOfficerLocalNo(addContractBusinessBean
            .getChiefEngineerOfficerLocalNo());

    // 主任技術者電話番号（加入者番号）
    registContractBusinessBean
        .setChiefEngineerOfficerDirectoryNo(addContractBusinessBean
            .getChiefEngineerOfficerDirectoryNo());

    // 接続送電サービス区分コード
    registContractBusinessBean
        .setConnectedSupplyServiceCategoryCode(addContractBusinessBean
            .getConnectedSupplyServiceCategoryCode());

    // フリー項目1 再エネ電源種別コード
    registContractBusinessBean.setFree1(addContractBusinessBean
        .getRenewableEnergyPowerSourceClassCode());

    // フリー項目2 再エネ設備容量
    registContractBusinessBean.setFree2(addContractBusinessBean
        .getRenewableEnergyFcltCapacity());

    // フリー項目3 再エネ設備認定年度
    registContractBusinessBean.setFree3(addContractBusinessBean
        .getRenewableEnergyFcltAprvFiscalYear());

    // フリー項目4 振込先金融機関コード
    registContractBusinessBean.setFree4(addContractBusinessBean
        .getTransferBankCode());

    // フリー項目5 振込先金融機関支店コード
    registContractBusinessBean.setFree5(addContractBusinessBean
        .getTransferBankBranchCode());

    // フリー項目6 振込先預金種目コード
    registContractBusinessBean.setFree6(addContractBusinessBean
        .getTransferTypeOfAccountCode());

    // フリー項目7 振込先口座番号
    registContractBusinessBean.setFree7(addContractBusinessBean
        .getTransferAccountNo());

    // フリー項目8 振込先口座名義（カナ）
    registContractBusinessBean.setFree8(addContractBusinessBean
        .getTransferAccountHolderNameKana());

    // フリー項目9 設備ID
    registContractBusinessBean.setFree9(addContractBusinessBean
        .getFree9());

    // フリー項目10 申込日
    registContractBusinessBean.setFree10(addContractBusinessBean
        .getEntryDate());

    // フリー項目11 調達開始年月
    registContractBusinessBean.setFree11(addContractBusinessBean
        .getSupplyStartPeriod());

    // フリー項目12 事業税算定対象フラグ
    registContractBusinessBean.setFree12(addContractBusinessBean
        .getBizTaxCalculationCoveredFlag());

    // フリー項目13 振込先金融機関名称（カナ）
    registContractBusinessBean.setFree13(addContractBusinessBean
        .getTransferBankNameKana());

    // フリー項目14 振込先金融機関支店名称（カナ）
    registContractBusinessBean.setFree14(addContractBusinessBean
        .getTransferBankBranchNameKana());

    // 業種コード
    registContractBusinessBean.setBusinessTypeCode(addContractBusinessBean
        .getBusinessTypeCode());

    // 営業委託先コード
    registContractBusinessBean
        .setSalesConsignmentCode(addContractBusinessBean
            .getSalesConsignmentCode());

    // 部分供給区分コード
    registContractBusinessBean.setPartialSupplyInformationCategoryCode(addContractBusinessBean
        .getPartialSupplyInformationCategoryCode());

    // 契約備考
    registContractBusinessBean.setContractNote(addContractBusinessBean
        .getContractNote());

    // 料金メニューID
    registContractBusinessBean.setChargeMenuId(addContractBusinessBean
        .getChargeMenuId());

    // 契約容量
    registContractBusinessBean.setContractCapacity(addContractBusinessBean
        .getContractCapacity());

    // 委託先使用項目1
    registContractBusinessBean
        .setConsignmentUseItem1(addContractBusinessBean
            .getConsignmentUseItem1());

    // 委託先使用項目2
    registContractBusinessBean
        .setConsignmentUseItem2(addContractBusinessBean
            .getConsignmentUseItem2());

    // 委託先使用項目3
    registContractBusinessBean
        .setConsignmentUseItem3(addContractBusinessBean
            .getConsignmentUseItem3());

    // 自社担当者コード
    registContractBusinessBean
        .setOurManagementPersonInChargeCode(addContractBusinessBean
            .getOurManagementPersonInChargeCode());

    // 自社部署コード
    registContractBusinessBean
        .setOurManagementDepartmentCode(addContractBusinessBean
            .getOurManagementDepartmentCode());

    // 卸取次店契約番号
    registContractBusinessBean.setAgentContractNo(addContractBusinessBean
        .getAgentContractNo());

    // 契約フリー項目1
    registContractBusinessBean.setContractFree1(addContractBusinessBean
        .getContractFree1());

    // 契約フリー項目2
    registContractBusinessBean.setContractFree2(addContractBusinessBean
        .getContractFree2());

    // 契約フリー項目3
    registContractBusinessBean.setContractFree3(addContractBusinessBean
        .getContractFree3());

    // 契約フリー項目4
    registContractBusinessBean.setContractFree4(addContractBusinessBean
        .getContractFree4());

    // 契約フリー項目5
    registContractBusinessBean.setContractFree5(addContractBusinessBean
        .getContractFree5());

    // 契約フリー項目6
    registContractBusinessBean.setContractFree6(addContractBusinessBean
        .getContractFree6());

    // 契約フリー項目7
    registContractBusinessBean.setContractFree7(addContractBusinessBean
        .getContractFree7());

    // 契約フリー項目8
    registContractBusinessBean.setContractFree8(addContractBusinessBean
        .getContractFree8());

    // 契約フリー項目9
    registContractBusinessBean.setContractFree9(addContractBusinessBean
        .getContractFree9());

    // 契約フリー項目10
    registContractBusinessBean.setContractFree10(addContractBusinessBean
        .getContractFree10());
    // 実量歴必須フラグ
    registContractBusinessBean.setRealQuantityNeed(addContractBusinessBean
        .getRealQuantityNeed());
    // 実量歴必須フラグ
    registContractBusinessBean.setRealQuantityImportCompleteFlag(addContractBusinessBean
        .getRealQuantityImportCompleteFlag());
    // 料金メニュー単価
    registContractBusinessBean.setRmUp(addContractBusinessBean
        .getRmUp());
    // 料金メニュー単価
    registContractBusinessBean.setRmUpDetailList(addContractBusinessBean
        .getRmUpDetailList());
    // 電圧区分コード
    registContractBusinessBean.setVoltageCatCode(addContractBusinessBean
        .getVoltageCatCode());
    // 契約電力決定区分コード
    registContractBusinessBean.setCcDecisionCategoryCode(addContractBusinessBean
        .getCcDecisionCategoryCode());
    // 単価設定区分コード
    registContractBusinessBean.setUpCatCode(addContractBusinessBean
        .getUpCatCode());

    return registContractBusinessBean;
  }

  /**
   * メーター設置場所更新BusinessBeanに値をセットして返す
   *
   * @param AddAgentContractBusinessBean
   *          契約情報追加BusinessBean
   *
   * @return UpdateAgentMeterLocationBusinessBean メータ設置場所更新BusinessBean
   */
  private UpdateAgentMeterLocationBusinessBean createUpdateAgentMeterLocationBusinessBean(
      AddAgentContractBusinessBean addContractBusinessBean) {

    UpdateAgentMeterLocationBusinessBean meterLocationBean = new UpdateAgentMeterLocationBusinessBean();

    // メータ設置場所ID
    meterLocationBean.setMeterLocationId(addContractBusinessBean
        .getMeterLocationId());

    // 需要場所住所（郵便番号）
    meterLocationBean.setPlaceAddressPostalCode(addContractBusinessBean
        .getPlaceAddressPostalCode());

    // 需要場所住所（住所）
    meterLocationBean.setPlaceAddressFull(addContractBusinessBean
        .getPlaceAddressFull());

    // 需要場所住所（建物・部屋名）
    meterLocationBean.setPlaceAddressBuilding(addContractBusinessBean
        .getPlaceAddressBuilding());

    // エリアコード
    meterLocationBean.setAreaCode(addContractBusinessBean.getAreaCode());

    // 地点特定番号
    meterLocationBean.setSpotNo(addContractBusinessBean.getSpotNo());

    // 需要家識別番号
    meterLocationBean.setContractorIdentificationNo(addContractBusinessBean
        .getContractorIdentificationNo());

    // 送受電区分コード
    meterLocationBean.setTransmissionCategoryCode(addContractBusinessBean
        .getTransmissionCategoryCode());

    // 基本検針日
    meterLocationBean.setBasicMeterReadingDate(addContractBusinessBean
        .getBasicMeterReadingDate());

    // 次回検針予定日
    meterLocationBean
        .setNextMeterReadingScheduledDate(addContractBusinessBean
            .getNextMeterReadingScheduledDate());

    // 次回検針予定日更新対象外フラグ
    meterLocationBean
        .setNextMeterReadingScheduledDateNoUpdFlag(ECISConstants.FLG_OFF);

    // 前回検針日
    meterLocationBean.setLastTimeMeterReadingDate(addContractBusinessBean
        .getLastTimeMeterReadingDate());

    // 前回検針日更新対象外フラグ
    meterLocationBean
        .setLastTimeMeterReadingDateNoUpdFlag(ECISConstants.FLG_ON);

    // 自家発連携有無コード
    meterLocationBean.setGeneratorLinkageCheckCode(addContractBusinessBean
        .getGeneratorLinkageCheckCode());

    // 供給方式コード
    meterLocationBean.setMethodCode(addContractBusinessBean
        .getSupplyMethodCode());

    // 計器識別番号1
    meterLocationBean.setMeterIdentificationNo1(addContractBusinessBean
        .getMeterIdentificationNo1());

    // 計器識別番号2
    meterLocationBean.setMeterIdentificationNo2(addContractBusinessBean
        .getMeterIdentificationNo2());

    // 計器識別番号3
    meterLocationBean.setMeterIdentificationNo3(addContractBusinessBean
        .getMeterIdentificationNo3());

    // 計器識別番号4
    meterLocationBean.setMeterIdentificationNo4(addContractBusinessBean
        .getMeterIdentificationNo4());

    // 計器識別番号5
    meterLocationBean.setMeterIdentificationNo5(addContractBusinessBean
        .getMeterIdentificationNo5());

    // 30分値収集可否・自動検針可否コード1
    meterLocationBean
        .setAutomaticMeterReadingCkeckCode1(addContractBusinessBean
            .getAutomaticMeterReadingCkeckCode1());

    // 30分値収集可否・自動検針可否コード2
    meterLocationBean
        .setAutomaticMeterReadingCkeckCode2(addContractBusinessBean
            .getAutomaticMeterReadingCkeckCode2());

    // 30分値収集可否・自動検針可否コード3
    meterLocationBean
        .setAutomaticMeterReadingCkeckCode3(addContractBusinessBean
            .getAutomaticMeterReadingCkeckCode3());

    // 30分値収集可否・自動検針可否コード4
    meterLocationBean
        .setAutomaticMeterReadingCkeckCode4(addContractBusinessBean
            .getAutomaticMeterReadingCkeckCode4());

    // 30分値収集可否・自動検針可否コード5
    meterLocationBean
        .setAutomaticMeterReadingCkeckCode5(addContractBusinessBean
            .getAutomaticMeterReadingCkeckCode5());

    // メータ設置場所フリー項目1
    meterLocationBean.setMeterLocationFree1(addContractBusinessBean
        .getMeterLocationFree1());

    // メータ設置場所フリー項目2
    meterLocationBean.setMeterLocationFree2(addContractBusinessBean
        .getMeterLocationFree2());

    // メータ設置場所フリー項目3
    meterLocationBean.setMeterLocationFree3(addContractBusinessBean
        .getMeterLocationFree3());

    // メータ設置場所フリー項目4
    meterLocationBean.setMeterLocationFree4(addContractBusinessBean
        .getMeterLocationFree4());

    // メータ設置場所フリー項目5
    meterLocationBean.setMeterLocationFree5(addContractBusinessBean
        .getMeterLocationFree5());

    // メータ設置場所フリー項目6
    meterLocationBean.setMeterLocationFree6(addContractBusinessBean
        .getMeterLocationFree6());

    // メータ設置場所フリー項目7
    meterLocationBean.setMeterLocationFree7(addContractBusinessBean
        .getMeterLocationFree7());

    // メータ設置場所フリー項目8
    meterLocationBean.setMeterLocationFree8(addContractBusinessBean
        .getMeterLocationFree8());

    // メータ設置場所フリー項目9
    meterLocationBean.setMeterLocationFree9(addContractBusinessBean
        .getMeterLocationFree9());

    // メータ設置場所フリー項目10
    meterLocationBean.setMeterLocationFree10(addContractBusinessBean
        .getMeterLocationFree10());

    // 検針日区分コード
    meterLocationBean.setMeterReadingDateCategoryCode(
        addContractBusinessBean.getMrDateCatCode());

    // 更新回数
    meterLocationBean.setUpdateCount(addContractBusinessBean
        .getUpdateCount());
    return meterLocationBean;
  }

  /**
   * メータ設置場所登録BusinessBeanに値をセットして返す
   *
   * @param AddAgentContractBusinessBean
   *          契約情報追加BusinessBean
   * @return UpdateAgentMeterLocationBusinessBean メータ設置場所登録BusinessBean
   */
  private RegistAgentMeterLocationBusinessBean createRegistMeterLocationBusinessBean(
      AddAgentContractBusinessBean addContractBusinessBean) {
    RegistAgentMeterLocationBusinessBean meterLocationBean = new RegistAgentMeterLocationBusinessBean();

    // 需要場所住所（郵便番号）
    meterLocationBean.setPlaceAddressPostalCode(addContractBusinessBean
        .getPlaceAddressPostalCode());

    // 需要場所住所（住所）
    meterLocationBean.setPlaceAddressFull(addContractBusinessBean
        .getPlaceAddressFull());

    // 需要場所住所（建物・部屋名）
    meterLocationBean.setPlaceAddressBuilding(addContractBusinessBean
        .getPlaceAddressBuilding());

    // エリアコード
    meterLocationBean.setAreaCode(addContractBusinessBean.getAreaCode());

    // 地点特定番号
    meterLocationBean.setSpotNo(addContractBusinessBean.getSpotNo());

    // 需要家識別番号
    meterLocationBean.setContractorIdentificationNo(addContractBusinessBean
        .getContractorIdentificationNo());

    // 送受電区分コード
    meterLocationBean.setTransmissionCategoryCode(addContractBusinessBean
        .getTransmissionCategoryCode());

    // 基本検針日
    meterLocationBean.setBasicMeterReadingDate(addContractBusinessBean
        .getBasicMeterReadingDate());

    // 次回検針予定日
    meterLocationBean
        .setNextMeterReadingScheduledDate(addContractBusinessBean
            .getNextMeterReadingScheduledDate());

    // 前回検針日
    meterLocationBean.setLastTimeMeterReadingDate(null);

    // 自家発連携有無コード
    meterLocationBean.setGeneratorLinkageCheckCode(addContractBusinessBean
        .getGeneratorLinkageCheckCode());

    // 供給方式コード
    meterLocationBean.setMethodCode(addContractBusinessBean
        .getSupplyMethodCode());

    // 計器識別番号1
    meterLocationBean.setMeterIdentificationNo1(addContractBusinessBean
        .getMeterIdentificationNo1());

    // 計器識別番号2
    meterLocationBean.setMeterIdentificationNo2(addContractBusinessBean
        .getMeterIdentificationNo2());

    // 計器識別番号3
    meterLocationBean.setMeterIdentificationNo3(addContractBusinessBean
        .getMeterIdentificationNo3());

    // 計器識別番号4
    meterLocationBean.setMeterIdentificationNo4(addContractBusinessBean
        .getMeterIdentificationNo4());

    // 計器識別番号5
    meterLocationBean.setMeterIdentificationNo5(addContractBusinessBean
        .getMeterIdentificationNo5());

    // 30分値収集可否・自動検針可否コード1
    meterLocationBean
        .setAutomaticMeterReadingCkeckCode1(addContractBusinessBean
            .getAutomaticMeterReadingCkeckCode1());

    // 30分値収集可否・自動検針可否コード2
    meterLocationBean
        .setAutomaticMeterReadingCkeckCode2(addContractBusinessBean
            .getAutomaticMeterReadingCkeckCode2());

    // 30分値収集可否・自動検針可否コード3
    meterLocationBean
        .setAutomaticMeterReadingCkeckCode3(addContractBusinessBean
            .getAutomaticMeterReadingCkeckCode3());

    // 30分値収集可否・自動検針可否コード4
    meterLocationBean
        .setAutomaticMeterReadingCkeckCode4(addContractBusinessBean
            .getAutomaticMeterReadingCkeckCode4());

    // 30分値収集可否・自動検針可否コード5
    meterLocationBean
        .setAutomaticMeterReadingCkeckCode5(addContractBusinessBean
            .getAutomaticMeterReadingCkeckCode5());

    // メータ設置場所フリー項目1
    meterLocationBean.setMeterLocationFree1(addContractBusinessBean
        .getMeterLocationFree1());

    // メータ設置場所フリー項目2
    meterLocationBean.setMeterLocationFree2(addContractBusinessBean
        .getMeterLocationFree2());

    // メータ設置場所フリー項目3
    meterLocationBean.setMeterLocationFree3(addContractBusinessBean
        .getMeterLocationFree3());

    // メータ設置場所フリー項目4
    meterLocationBean.setMeterLocationFree4(addContractBusinessBean
        .getMeterLocationFree4());

    // メータ設置場所フリー項目5
    meterLocationBean.setMeterLocationFree5(addContractBusinessBean
        .getMeterLocationFree5());

    // メータ設置場所フリー項目6
    meterLocationBean.setMeterLocationFree6(addContractBusinessBean
        .getMeterLocationFree6());

    // メータ設置場所フリー項目7
    meterLocationBean.setMeterLocationFree7(addContractBusinessBean
        .getMeterLocationFree7());

    // メータ設置場所フリー項目8
    meterLocationBean.setMeterLocationFree8(addContractBusinessBean
        .getMeterLocationFree8());

    // メータ設置場所フリー項目9
    meterLocationBean.setMeterLocationFree9(addContractBusinessBean
        .getMeterLocationFree9());

    // メータ設置場所フリー項目10
    meterLocationBean.setMeterLocationFree10(addContractBusinessBean
        .getMeterLocationFree10());

    // 検針日区分コード
    meterLocationBean.setMeterReadingDateCategoryCode(addContractBusinessBean
        .getMrDateCatCode());

    return meterLocationBean;
  }

  /**
   * 契約(更新)エンティティ取得
   *
   * @param updateContractBusinessBean
   * @param consignmentCapacityUnit
   * @param paymentId
   * @param contextUserId
   * @param contextModuleCode
   * @return
   */
  private Contract createUpdateContract(
      UpdateAgentContractBusinessBean updateContractBusinessBean,
      String consignmentCapacityUnit, Integer paymentId,
      String contextUserId, String contextModuleCode) {

    Contract contract = new Contract();

    // 支払ID
    contract.setPaymentId(paymentId);

    // 契約開始日
    contract.setContractSd(updateContractBusinessBean.getContractStartDate());

    // 契約終了日
    contract.setContractEd(updateContractBusinessBean.getContractEndDate());

    // 契約終了理由コード
    contract.setContractEndReasonCode(updateContractBusinessBean
        .getContractEndReasonCode());

    // 料金チェックフラグ
    contract.setChargeCheckFlag(updateContractBusinessBean
        .getChargeCheckFlag());

    // 営業委託先コード
    contract.setScCode(updateContractBusinessBean.getSalesConsignmentCode());

    // 契約グループ番号
    contract.setContractGroupNo(updateContractBusinessBean
        .getContractGroupNo());

    // 個人・法人区分コード
    contract.setIlcCode(updateContractBusinessBean
        .getContactInformationinDividualLegalEntityCategoryCode());

    // 連絡先氏名（カナ）
    contract.setCiNameKana(updateContractBusinessBean
        .getContractInformationNameKana());

    // 連絡先氏名1
    contract.setCiName1(updateContractBusinessBean
        .getContractInformationName1());

    // 連絡先氏名2
    contract.setCiName2(updateContractBusinessBean
        .getContractInformationName2());

    // 連絡先住所（郵便番号）
    contract.setCiAddressPostalCode(updateContractBusinessBean
        .getContractInformationAddressPostalCode());

    // 連絡先住所（住所）
    contract.setCiAddressFull(updateContractBusinessBean
        .getContractInformationAddressFull());

    // 連絡先住所（建物・部屋名）
    contract.setCiAddressBuilding(updateContractBusinessBean
        .getContractInformationAddressBuilding());

    // 電話番号
    String telAreaNo = updateContractBusinessBean
        .getContractInformationAreaCode();
    String telLocalNo = updateContractBusinessBean
        .getContractInformationLocalNo();
    String telDirNo = updateContractBusinessBean
        .getContractInformationDirectoryNo();

    if (StringUtils.isNotEmpty(telAreaNo)
        && StringUtils.isNotEmpty(telLocalNo)
        && StringUtils.isNotEmpty(telDirNo)) {

      StringBuilder phoneStrBuilder = new StringBuilder();

      phoneStrBuilder.append(telAreaNo);
      phoneStrBuilder.append(ECISConstants.HYPHEN);
      phoneStrBuilder.append(telLocalNo);
      phoneStrBuilder.append(ECISConstants.HYPHEN);
      phoneStrBuilder.append(telDirNo);
      contract.setCiPhoneNo(phoneStrBuilder.toString());

    }
    if (ECISKJConstants.EMPTY_STRING.equals(telAreaNo)
        || ECISKJConstants.EMPTY_STRING.equals(telLocalNo)
        || ECISKJConstants.EMPTY_STRING.equals(telDirNo)) {

      contract.setCiPhoneNo(ECISKJConstants.EMPTY_STRING);

    }
    // 連絡先電話番号

    // 連絡先電話（市外局番）
    contract.setCiAreaCode(telAreaNo);

    // 連絡先電話（市内局番）
    contract.setCiLocalNo(telLocalNo);

    // 連絡先電話（加入者番号）
    contract.setCiDirectoryNo(telDirNo);
    // 連絡先電話区分コード
    contract.setCiCatCode(updateContractBusinessBean
        .getContractInformationCategoryCode());

    // 需要者窓口連絡先所属
    contract.setCcAffiliation(updateContractBusinessBean
        .getConsumerContractAffiliation());

    // 需要者窓口連絡先氏名
    contract.setCcName(updateContractBusinessBean
        .getConsumerContractName());

    // 需要者窓口連絡先電話番号
    String ccAreaNo = updateContractBusinessBean
        .getConsumerContractAreaCode();
    String ccLocalNo = updateContractBusinessBean
        .getConsumerContractLocalNo();
    String ccDirNo = updateContractBusinessBean
        .getConsumerContractDirectoryNo();

    if (StringUtils.isNotEmpty(ccAreaNo)
        && StringUtils.isNotEmpty(ccLocalNo)
        && StringUtils.isNotEmpty(ccDirNo)) {

      StringBuilder ccPhoneStrBuilder = new StringBuilder();

      ccPhoneStrBuilder.append(ccAreaNo);
      ccPhoneStrBuilder.append(ECISConstants.HYPHEN);
      ccPhoneStrBuilder.append(ccLocalNo);
      ccPhoneStrBuilder.append(ECISConstants.HYPHEN);
      ccPhoneStrBuilder.append(ccDirNo);
      contract.setCcPhoneNo(ccPhoneStrBuilder.toString());

    }
    if (ECISKJConstants.EMPTY_STRING.equals(ccAreaNo)
        || ECISKJConstants.EMPTY_STRING.equals(ccLocalNo)
        || ECISKJConstants.EMPTY_STRING.equals(ccDirNo)) {

      contract.setCcPhoneNo(ECISKJConstants.EMPTY_STRING);

    }
    // 需要者窓口連絡先電話番号

    // 需要者窓口連絡先電話番号（市外局番）
    contract.setCcAreaCode(ccAreaNo);

    // 需要者窓口連絡先電話番号（市内局番）
    contract.setCcLocalNo(ccLocalNo);

    // 需要者窓口連絡先電話番号（加入者番号）
    contract.setCcDirectoryNo(ccDirNo);

    // 主任技術者連絡先所属
    contract.setCeoAffiliation(updateContractBusinessBean
        .getChiefEngineerOfficerAffiliation());

    // 主任技術者連絡先氏名
    contract.setCeoName(updateContractBusinessBean
        .getChiefEngineerOfficerName());

    // 主任技術者連絡先電話番号
    String ceoAreaNo = updateContractBusinessBean
        .getChiefEngineerOfficerAreaCode();
    String ceoLocalNo = updateContractBusinessBean
        .getChiefEngineerOfficerLocalNo();
    String ceoDirNo = updateContractBusinessBean
        .getChiefEngineerOfficerDirectoryNo();

    if (StringUtils.isNotEmpty(ceoAreaNo)
        && StringUtils.isNotEmpty(ceoLocalNo)
        && StringUtils.isNotEmpty(ceoDirNo)) {

      StringBuilder ceoPhoneStrBuilder = new StringBuilder();

      ceoPhoneStrBuilder.append(ceoAreaNo);
      ceoPhoneStrBuilder.append(ECISConstants.HYPHEN);
      ceoPhoneStrBuilder.append(ceoLocalNo);
      ceoPhoneStrBuilder.append(ECISConstants.HYPHEN);
      ceoPhoneStrBuilder.append(ceoDirNo);
      contract.setCeoPhoneNo(ceoPhoneStrBuilder.toString());

    }
    if (ECISKJConstants.EMPTY_STRING.equals(ceoAreaNo)
        || ECISKJConstants.EMPTY_STRING.equals(ceoLocalNo)
        || ECISKJConstants.EMPTY_STRING.equals(ceoDirNo)) {

      contract.setCeoPhoneNo(ECISKJConstants.EMPTY_STRING);

    }
    // 主任技術者連絡先電話番号

    // 主任技術者連絡先電話番号（市外局番）
    contract.setCeoAreaCode(ceoAreaNo);

    // 主任技術者連絡先電話番号（市内局番）
    contract.setCeoLocalNo(ceoLocalNo);

    // 主任技術者連絡先電話番号（加入者番号）
    contract.setCeoDirectoryNo(ceoDirNo);

    // 業種コード
    contract.setBusinessTypeCode(updateContractBusinessBean
        .getBusinessTypeCode());

    // 接続送電サービス区分コード
    contract.setCssCatCode(updateContractBusinessBean
        .getConnectedSupplyServiceCategoryCode());

    // 託送契約容量
    contract.setConsignmentCca(updateContractBusinessBean
        .getConsignmentContractCapacity());
    // 託送契約容量単位
    contract.setConsignmentCcaUnit(consignmentCapacityUnit);

    // 託送契約容量判定日
    contract.setConsignmentCcaDecisionDate(updateContractBusinessBean
        .getConsignmentContractCapacityDecisionDate());

    // 備考
    contract.setNote(updateContractBusinessBean.getContractNote());

    // フリー項目1
    contract.setFree1(updateContractBusinessBean.getFree1());

    // フリー項目2
    contract.setFree2(updateContractBusinessBean.getFree2());

    // フリー項目3
    contract.setFree3(updateContractBusinessBean.getFree3());

    // フリー項目4
    contract.setFree4(updateContractBusinessBean.getFree4());

    // フリー項目5
    contract.setFree5(updateContractBusinessBean.getFree5());

    // フリー項目6
    contract.setFree6(updateContractBusinessBean.getFree6());

    // フリー項目7
    contract.setFree7(updateContractBusinessBean.getFree7());

    // フリー項目8
    contract.setFree8(updateContractBusinessBean.getFree8());

    // フリー項目9
    contract.setFree9(updateContractBusinessBean.getFree9());

    // フリー項目10
    contract.setFree10(updateContractBusinessBean.getFree10());

    // フリー項目11
    contract.setFree11(updateContractBusinessBean.getFree11());

    // フリー項目12
    contract.setFree12(updateContractBusinessBean.getFree12());

    // フリー項目13
    contract.setFree13(updateContractBusinessBean.getFree13());

    // フリー項目14
    contract.setFree14(updateContractBusinessBean.getFree14());

    // 委託先使用項目1
    contract.setConsignmentUseItem1(updateContractBusinessBean
        .getConsignmentUseItem1());

    // 委託先使用項目2
    contract.setConsignmentUseItem2(updateContractBusinessBean
        .getConsignmentUseItem2());

    // 委託先使用項目3
    contract.setConsignmentUseItem3(updateContractBusinessBean
        .getConsignmentUseItem3());

    // 自社担当者コード
    contract.setOurMngPersonInChargeCode(updateContractBusinessBean
        .getOurManagementPersonInChargeCode());

    // 自社部署コード
    contract.setOurMngDepartmentCode(updateContractBusinessBean
        .getOurManagementDepartmentCode());

    // 部分供給区分コード
    contract.setPsInfoCatCode(updateContractBusinessBean.getPartialSupplyInformationCategoryCode());

    // 更新回数
    contract.setUpdateCount(updateContractBusinessBean.getUpdateCount() + 1);

    Timestamp systemTime = new Timestamp(System.currentTimeMillis());

    // オンライン更新日時
    contract.setOnlineUpdateTime(systemTime);

    // オンライン更新ユーザID
    contract.setOnlineUpdateUserId(contextUserId);

    // 更新モジュールコード
    contract.setUpdateModuleCode(contextModuleCode);

    // 更新日時
    contract.setUpdateTime(systemTime);

    // 実量歴必須フラグ
    contract.setRealQuantityNeedFlag(updateContractBusinessBean.getRealQuantityNeed());

    // 実量歴取込済フラグ
    contract.setRealQuantityImportCompleteFlag(updateContractBusinessBean.getRealQuantityImportCompleteFlag());

    return contract;
  }

  /**
   * registBeanより《契約履歴Entity》に値を設定する
   *
   * @param businessBean
   *          契約情報登録BusinessBean
   * @param contractorId
   *          契約者ID
   * @param paymentId
   *          支払ID
   * @param maxDate
   *          最大日付
   * @param contextUserId
   *          コンテキストユーザID
   * @param contextModuleCode
   *          コンテキストモジュールコード
   * @return 契約Entity
   */
  private Contract createRegistContract(
      RegistAgentContractBusinessBean businessBean, Integer contractorId,
      Integer paymentId, Date maxDate, String contextUserId,
      String contextModuleCode) {

    Contract contract = new Contract();

    // 契約番号
    contract.setContractNo(businessBean.getContractNo());

    // 契約者ID
    contract.setContractorId(contractorId);

    // 支払ID
    contract.setPaymentId(paymentId);

    // 契約開始日
    contract.setContractSd(businessBean.getContractStartDate());

    // 契約終了日 NULLの場合“99991231”を設定
    Date contractEndDate = businessBean.getContractEndDate() == null ? maxDate
        : businessBean.getContractEndDate();
    contract.setContractEd(contractEndDate);

    // 契約終了理由コード
    contract.setContractEndReasonCode(businessBean
        .getContractEndReasonCode());

    // 託送契約容量
    contract.setConsignmentCca(businessBean
        .getConsignmentContractCapacity());

    // 託送契約容量単位
    contract.setConsignmentCcaUnit(businessBean
        .getConsignmentcontractCapacityUnitCode());

    // 託送契約容量判定日
    contract.setConsignmentCcaDecisionDate(businessBean
        .getConsignmentContractCapacityDecisionDate());

    // 料金チェックフラグ NULLまたは空文字のいずれかの場合“0”を設定
    String chargeCheckFlag = StringUtils.isEmpty(businessBean
        .getChargeCheckFlag()) ? ECISKJConstants.CHARGE_CHECK_FLAG_CORRECTION_OFF
            : businessBean.getChargeCheckFlag();
    contract.setChargeCheckFlag(chargeCheckFlag);

    // 契約グループ番号
    contract.setContractGroupNo(businessBean.getContractGroupNo());

    // 個人・法人区分コード
    contract.setIlcCode(businessBean
        .getContactInformationinDividualLegalEntityCategoryCode());

    // 連絡先氏名（カナ）
    contract.setCiNameKana(businessBean.getContractInformationNameKana());

    // 連絡先氏名1
    contract.setCiName1(businessBean.getContractInformationName1());

    // 連絡先氏名2
    contract.setCiName2(businessBean.getContractInformationName2());

    // 連絡先住所（郵便番号）
    contract.setCiAddressPostalCode(businessBean
        .getContractInformationAddressPostalCode());

    // 連絡先住所（住所）
    contract.setCiAddressFull(businessBean
        .getContractInformationAddressFull());

    // 連絡先住所（建物・部屋名）
    contract.setCiAddressBuilding(businessBean
        .getContractInformationAddressBuilding());

    // 電話番号
    String telAreaNo = businessBean.getContractInformationAreaCode();
    String telLocalNo = businessBean.getContractInformationLocalNo();
    String telDirNo = businessBean.getContractInformationDirectoryNo();
    if (StringUtils.isNotEmpty(telAreaNo)
        && StringUtils.isNotEmpty(telLocalNo)
        && StringUtils.isNotEmpty(telDirNo)) {
      StringBuilder phoneStrBuilder = new StringBuilder();

      phoneStrBuilder.append(telAreaNo);
      phoneStrBuilder.append(ECISConstants.HYPHEN);
      phoneStrBuilder.append(telLocalNo);
      phoneStrBuilder.append(ECISConstants.HYPHEN);
      phoneStrBuilder.append(telDirNo);

      // 連絡先電話番号
      contract.setCiPhoneNo(phoneStrBuilder.toString());

    }

    // 連絡先電話（市外局番）
    contract.setCiAreaCode(telAreaNo);

    // 連絡先電話（市内局番）
    contract.setCiLocalNo(telLocalNo);

    // 連絡先電話（加入者番号）
    contract.setCiDirectoryNo(telDirNo);

    // 連絡先電話区分コード
    contract.setCiCatCode(businessBean.getContractInformationCategoryCode());

    // 需要者窓口連絡先所属
    contract.setCcAffiliation(businessBean.getConsumerContractAffiliation());

    // 需要者窓口連絡先氏名
    contract.setCcName(businessBean.getConsumerContractName());

    // 需要者窓口連絡先電話番号
    String ccAreaNo = businessBean.getConsumerContractAreaCode();
    String ccLocalNo = businessBean.getConsumerContractLocalNo();
    String ccDirNo = businessBean.getConsumerContractDirectoryNo();
    if (StringUtils.isNotEmpty(ccAreaNo)
        && StringUtils.isNotEmpty(ccLocalNo)
        && StringUtils.isNotEmpty(ccDirNo)) {

      StringBuilder ccPhoneStrBuilder = new StringBuilder();

      ccPhoneStrBuilder.append(ccAreaNo);
      ccPhoneStrBuilder.append(ECISConstants.HYPHEN);
      ccPhoneStrBuilder.append(ccLocalNo);
      ccPhoneStrBuilder.append(ECISConstants.HYPHEN);
      ccPhoneStrBuilder.append(ccDirNo);

      // 需要者窓口連絡先電話番号
      contract.setCcPhoneNo(ccPhoneStrBuilder.toString());

    }

    // 需要者窓口連絡先電話番号（市外局番）
    contract.setCcAreaCode(ccAreaNo);

    // 需要者窓口連絡先電話番号（市内局番）
    contract.setCcLocalNo(ccLocalNo);

    // 需要者窓口連絡先電話番号（加入者番号）
    contract.setCcDirectoryNo(ccDirNo);

    // 主任技術者連絡先所属
    contract.setCeoAffiliation(businessBean.getChiefEngineerOfficerAffiliation());

    // 主任技術者連絡先氏名
    contract.setCeoName(businessBean.getChiefEngineerOfficerName());

    // 主任技術者連絡先電話番号
    String ceoAreaNo = businessBean.getChiefEngineerOfficerAreaCode();
    String ceoLocalNo = businessBean.getChiefEngineerOfficerLocalNo();
    String ceoDirNo = businessBean.getChiefEngineerOfficerDirectoryNo();
    if (StringUtils.isNotEmpty(ceoAreaNo)
        && StringUtils.isNotEmpty(ceoLocalNo)
        && StringUtils.isNotEmpty(ceoDirNo)) {

      StringBuilder ceoPhoneStrBuilder = new StringBuilder();

      ceoPhoneStrBuilder.append(ceoAreaNo);
      ceoPhoneStrBuilder.append(ECISConstants.HYPHEN);
      ceoPhoneStrBuilder.append(ceoLocalNo);
      ceoPhoneStrBuilder.append(ECISConstants.HYPHEN);
      ceoPhoneStrBuilder.append(ceoDirNo);

      // 主任技術者連絡先電話番号
      contract.setCeoPhoneNo(ceoPhoneStrBuilder.toString());

    }

    // 主任技術者連絡先電話番号（市外局番）
    contract.setCeoAreaCode(ceoAreaNo);

    // 主任技術者連絡先電話番号（市内局番）
    contract.setCeoLocalNo(ceoLocalNo);

    // 主任技術者連絡先電話番号（加入者番号）
    contract.setCeoDirectoryNo(ceoDirNo);

    // 接続送電サービス区分コード
    contract.setCssCatCode(businessBean
        .getConnectedSupplyServiceCategoryCode());

    // フリー項目1
    contract.setFree1(businessBean.getFree1());

    // フリー項目2
    contract.setFree2(businessBean.getFree2());

    // フリー項目3
    contract.setFree3(businessBean.getFree3());

    // フリー項目4
    contract.setFree4(businessBean.getFree4());

    // フリー項目5
    contract.setFree5(businessBean.getFree5());

    // フリー項目6
    contract.setFree6(businessBean.getFree6());

    // フリー項目7
    contract.setFree7(businessBean.getFree7());

    // フリー項目8
    contract.setFree8(businessBean.getFree8());

    // フリー項目9
    contract.setFree9(businessBean.getFree9());

    // フリー項目10
    contract.setFree10(businessBean.getFree10());

    // フリー項目11
    contract.setFree11(businessBean.getFree11());

    // フリー項目12
    contract.setFree12(businessBean.getFree12());

    // フリー項目13
    contract.setFree13(businessBean.getFree13());

    // フリー項目14
    contract.setFree14(businessBean.getFree14());

    // 業種コード
    contract.setBusinessTypeCode(businessBean.getBusinessTypeCode());

    // 営業委託先コード
    contract.setScCode(businessBean.getSalesConsignmentCode());

    // 備考
    contract.setNote(businessBean.getContractNote());

    // 委託先使用項目1
    contract.setConsignmentUseItem1(businessBean.getConsignmentUseItem1());

    // 委託先使用項目2
    contract.setConsignmentUseItem2(businessBean.getConsignmentUseItem2());

    // 委託先使用項目3
    contract.setConsignmentUseItem3(businessBean.getConsignmentUseItem3());

    // 自社担当者コード
    contract.setOurMngPersonInChargeCode(businessBean
        .getOurManagementPersonInChargeCode());

    // 自社部署コード
    contract.setOurMngDepartmentCode(businessBean
        .getOurManagementDepartmentCode());

    // 契約終了分確定使用量連携済フラグに“0”を設定
    contract.setContractEndFuSentFlag(ECISKJConstants.CONTRACT_END_FIX_USAGE_SENT_FLAG_NON_LINKAGE);

    // 部分供給区分コード
    contract.setPsInfoCatCode(businessBean.getPartialSupplyInformationCategoryCode());

    Timestamp systemTime = new Timestamp(System.currentTimeMillis());

    // 更新回数
    contract.setUpdateCount(0);

    // 作成日時
    contract.setCreateTime(systemTime);

    // オンライン更新日時
    contract.setOnlineUpdateTime(systemTime);

    // オンライン更新ユーザID
    contract.setOnlineUpdateUserId(contextUserId);

    // 更新モジュールコード
    contract.setUpdateModuleCode(contextModuleCode);

    // 更新日時
    contract.setUpdateTime(systemTime);

    // 実量歴必須フラグ
    contract.setRealQuantityNeedFlag(businessBean.getRealQuantityNeed());

    // 実量歴取込済フラグ
    contract.setRealQuantityImportCompleteFlag(businessBean.getRealQuantityImportCompleteFlag());
    return contract;
  }

  /**
   * registBeanより《契約履歴Entity》に値を設定する
   *
   * @param businessBean
   *          契約情報登録BusinessBean
   * @param contractId
   *          契約ID
   * @param maxDate
   *          最大日付
   * @param ccaUnit
   *          契約容量単位
   * @param rmId
   *          料金メニューID
   * @param contextUserId
   *          コンテキストユーザID
   * @param contextModuleCode
   *          コンテキストモジュールコード
   * @return 契約履歴Entity
   */
  private ContractHist createContractHistory(
      RegistAgentContractBusinessBean businessBean, Integer contractId,
      Date maxDate, String ccaUnit, String rmId, String contextUserId,
      String contextModuleCode) {

    ContractHist contractHistory = new ContractHist();

    // 契約ID
    contractHistory.setContractId(contractId);

    // 適用開始日
    contractHistory.setApplySd(businessBean.getContractStartDate());

    // 契約終了日がNULLの場合適用終了日に“99991231”
    Date applyEndDate = businessBean.getContractEndDate() == null ? maxDate
        : businessBean.getContractEndDate();
    contractHistory.setApplyEd(applyEndDate);

    // 契約容量
    contractHistory.setCca(businessBean.getContractCapacity());

    // 契約容量単位
    contractHistory.setCcaUnit(ccaUnit);

    // 料金メニューID
    contractHistory.setRmId(rmId);

    // 更新回数
    contractHistory.setUpdateCount(0);

    Timestamp systemTime = new Timestamp(System.currentTimeMillis());

    contractHistory.setCreateTime(systemTime);

    contractHistory.setOnlineUpdateTime(systemTime);

    contractHistory.setOnlineUpdateUserId(contextUserId);

    contractHistory.setUpdateModuleCode(contextModuleCode);

    contractHistory.setUpdateTime(systemTime);

    // 電圧区分コード
    if (StringUtils.isNotEmpty(businessBean.getVoltageCatCode())) {
      contractHistory.setVoltageCatCode(businessBean.getVoltageCatCode());
    }
    // 契約電力決定区分コード
    if (StringUtils.isNotEmpty(businessBean.getCcDecisionCategoryCode())) {
      contractHistory.setCcDecisionCategoryCode(businessBean.getCcDecisionCategoryCode());
    }
    // 単価設定区分コード
    if (ECISConstants.UNIT_PRICE_SETTING_CATEGORY_INDIV.equals(
        businessBean.getUpCatCode())) {
      contractHistory.setUpCatCode(contractId.toString());
    } else {
      contractHistory.setUpCatCode(ECISConstants.UNIT_PRICE_SETTING_CATEGORY_DEF);
    }
    return contractHistory;
  }

  /**
   * registBeanより《料金メニュー単価Entity》に値を設定する
   *
   * @param businessBean
   *          契約情報登録BusinessBean
   * @param contextUserId
   *          コンテキストユーザID
   * @param contextModuleCode
   *          コンテキストモジュールコード
   * @param rmId
   *          料金メニューID
   * @return 料金メニュー単価Entity
   */
  private RmUp createRmUp(
      RegistAgentContractBusinessBean businessBean,
      String contextUserId,
      Integer newContractId,
      String contextModuleCode,
      String rmId) {

    RmUp rmUp = new RmUp();

    // 料金メニューID
    rmUp.setRmId(rmId);

    // 単価設定区分コード
    rmUp.setUpCatCode(newContractId.toString());

    // 最低月額料金
    rmUp.setMmc(businessBean.getRmUp().getMmc());

    // 備考
    rmUp.setNote(businessBean.getRmUp().getNote());

    // 単価適用開始日
    rmUp.setUpApplySd(businessBean.getContractStartDate());

    // 単価適用終了日
    rmUp.setUpApplyEd(StringConvertUtil.stringToDate(
        ECISKJConstants.APPLY_END_DATE_MAX, null));

    // 更新回数
    rmUp.setUpdateCount(0);

    Timestamp systemTime = new Timestamp(System.currentTimeMillis());

    rmUp.setCreateTime(systemTime);

    rmUp.setOnlineUpdateTime(systemTime);

    rmUp.setOnlineUpdateUserId(contextUserId);

    rmUp.setUpdateModuleCode(contextModuleCode);

    rmUp.setUpdateTime(systemTime);

    return rmUp;
  }

  /**
   * registBeanより《料金メニュー単価明細Entity》に値を設定する
   *
   * @param businessBean
   *          契約情報登録BusinessBean
   * @param contextUserId
   *          コンテキストユーザID
   * @param contextModuleCode
   *          コンテキストモジュールコード
   * @param detail
   *          料金メニュー単価明細
   * @param rmId
   *          料金メニューID
   * @return 料金メニュー単価明細Entity
   */
  private RmUpDetail createRmUpDetail(
      RegistAgentContractBusinessBean businessBean,
      String contextUserId,
      Integer newContractId,
      String contextModuleCode,
      RmUpDetail detail,
      String rmId) {

    RmUpDetail reUpDetail = new RmUpDetail();

    // 料金メニューID
    reUpDetail.setRmId(rmId);
    // 単価設定区分コード
    reUpDetail.setUpCatCode(newContractId.toString());
    // 単価適用開始日
    reUpDetail.setUpApplySd(businessBean.getContractStartDate());
    // DCEC区分コード
    reUpDetail.setDcecCatCode(detail.getDcecCatCode());
    // 時間帯コード
    reUpDetail.setTsCode(detail.getTsCode());
    // 枝番
    reUpDetail.setBranchNo(detail.getBranchNo());
    // 表示名称1
    reUpDetail.setDisplayName1(detail.getDisplayName1());
    // 表示名称2
    reUpDetail.setDisplayName2(detail.getDisplayName2());
    // 閾値
    reUpDetail.setThreshold(detail.getThreshold());
    // 閾値名称
    reUpDetail.setThresholdName(detail.getThresholdName());
    // 単価
    reUpDetail.setUp(detail.getUp());
    // 表示順
    reUpDetail.setDisplayOrder(detail.getDisplayOrder());
    // 明細出力順
    reUpDetail.setDetailOutputOrder(detail.getDetailOutputOrder());
    // 更新回数
    reUpDetail.setUpdateCount(0);

    Timestamp systemTime = new Timestamp(System.currentTimeMillis());

    reUpDetail.setCreateTime(systemTime);

    reUpDetail.setOnlineUpdateTime(systemTime);

    reUpDetail.setOnlineUpdateUserId(contextUserId);

    reUpDetail.setUpdateModuleCode(contextModuleCode);

    reUpDetail.setUpdateTime(systemTime);

    return reUpDetail;
  }

  /**
   * 《契約情報更新BusinessBean》より《契約履歴Entity》に値を設定する（登録用）
   *
   * @param businessBean
   *          契約情報更新BusinessBean
   * @param contractId
   *          契約ID
   * @param rateMenuId
   *          料金メニューID
   * @param capaUnit
   *          契約容量単位
   * @param applyEd
   *          適用終了日
   * @param contextUserId
   *          コンテキストユーザID
   * @param contextModuleCode
   *          コンテキストモジュールコード
   * @return 契約履歴Entity
   */
  private ContractHist createInsertContractHistory(
      UpdateAgentContractBusinessBean businessBean,
      InquiryAgentContractBusinessBean inquryContractResult,
      KJ_InquiryAgentContractInformationEntityBean contractBean,
      Rm rateMenu, Date applyEd, String contextUserId,
      String contextModuleCode) {

    ContractHist contractHistory = new ContractHist();
    // システム日時
    Timestamp systemTime = new Timestamp(System.currentTimeMillis());

    KJ_AgentContractHistoryInformationEntityBean history = contractBean
        .getAgentContractHistoryInformationList().get(0);

    contractHistory.setContractId(contractBean.getContractId());
    // 以下4つは値がなければ履歴からとる
    // 料金メニューID rate_menu_id
    // 契約容量 contract_capacity
    // 契約容量単位 contract_capacity_unit
    // 契約変更理由 contract_change_reason
    String rateMenuId = null;
    String capaUnit = null;

    BigDecimal cca = null;
    // 料金メニューIDがNULLまたは空文字の場合は履歴から
    if (StringUtils.isEmpty(businessBean.getChargeMenuId())) {
      rateMenuId = history.getRateMenuId();
      capaUnit = history.getContractCapacityUnit();
      cca = history.getContractCapacity();
    } else {
      // NULLでも空文字でもない場合は料金メニューから
      rateMenuId = rateMenu.getRmId();
      capaUnit = rateMenu.getCcaUnit();

      // 料金メニューの契約容量単位と容量選択可能範囲項目がどちらもnullの場合、従量電灯Aとなる。
      // このチェックで従量電灯Aの場合は、契約容量はnull（未設定）としてください
      if (rateMenu.getCcaUnit() == null
          && rateMenu.getCapacitySelectableRange() == null) {
        cca = null;
      } else {
        cca = businessBean.getContractCapacity();
      }
    }

    contractHistory.setCca(cca);
    contractHistory.setRmId(rateMenuId);
    contractHistory.setCcaUnit(capaUnit);

    String contractChangeReason = null;
    if (businessBean.getContractChangeReason() != null) {
      contractChangeReason = businessBean.getContractChangeReason();
    } else {
      contractChangeReason = history.getContractChangeReason();
    }
    contractHistory.setContractChangeReason(contractChangeReason);

    // 契約履歴登録データ作成準備
    // 《卸取次店向け契約情報更新BusinessBean》.単価設定区分コードがNULL（APIから呼ばれた場合）の場合
    if (StringUtils.isEmpty(businessBean.getUpCatCode())) {
      // 《卸取次店向け契約履歴情報EntityBean》
      KJ_AgentContractHistoryInformationEntityBean kjAgentContractHistoryInformationEntityBean = inquryContractResult
          .getAgentContractInformationList().get(0)
          .getAgentContractHistoryInformationList().get(0);

      // 《卸取次店向け契約情報更新BusinessBean》.料金メニューIDがNULLの場合、
      // または、《卸取次店向け契約履歴情報EntityBean》.料金メニューIDと《卸取次店向け契約情報更新BusinessBean》.料金メニューIDが同じ場合
      if (StringUtils.isEmpty(businessBean.getChargeMenuId())
          || kjAgentContractHistoryInformationEntityBean
              .getRateMenuId().equals(
                  businessBean.getChargeMenuId())) {

        // ①《卸取次店向け契約情報更新BusinessBean》.単価設定区分コードに《卸取次店向け契約履歴情報EntityBean》.単価設定区分コードを設定する。
        businessBean
            .setUpCatCode(kjAgentContractHistoryInformationEntityBean
                .getUnitPriceSetCategoryCode());

        // ②《卸取次店向け契約情報更新BusinessBean》.単価設定区分コードが定数.単価設定区分コード：個別単価の場合
        if (ECISConstants.UNIT_PRICE_SETTING_CATEGORY_INDIV
            .equals(businessBean.getUpCatCode())) {
          // 料金メニュー単価明細の取得
          RmUpDetailExample rmUpDetailExample = new RmUpDetailExample();

          // 《料金メニュー単価明細Example》.料金メニューID ＝ 《卸取次店向け契約履歴情報EntityBean》.料金メニューID
          // 料金メニュー単価明細Example》.単価設定区分コード ＝ 《卸取次店向け契約情報更新BusinessBean》.単価設定区分コード
          // 《料金メニュー単価明細Example》.適用開始日 ＝ 《卸取次店向け契約履歴情報EntityBean》.適用開始日
          rmUpDetailExample
              .createCriteria()
              .andRmIdEqualTo(
                  kjAgentContractHistoryInformationEntityBean
                      .getRateMenuId())
              .andUpCatCodeEqualTo(StringConvertUtil.integerToString(contractBean.getContractId()))
              .andUpApplySdEqualTo(
                  kjAgentContractHistoryInformationEntityBean
                      .getApplyStartDate());

          List<RmUpDetail> rmUpDetailList = rmUpDetailMapper
              .selectByExample(rmUpDetailExample);

          // ③《卸取次店向け契約情報更新BusinessBean》.料金メニュー単価明細リストに②で取得した結果を設定する。
          businessBean.setRmUpDetailList(rmUpDetailList);

          RmUp rmUp = new RmUp();

          // 最低月額料金
          rmUp.setMmc(kjAgentContractHistoryInformationEntityBean
              .getUnitPriceDetailInformationList().get(0).getMmc());

          // 備考
          rmUp.setNote(kjAgentContractHistoryInformationEntityBean
              .getUnitPriceDetailInformationList().get(0).getNote());

          businessBean.setRmUp(rmUp);
        }
      } else {
        // ※《卸取次店向け契約履歴情報EntityBean》.料金メニューIDと《卸取次店向け契約情報更新BusinessBean》.料金メニューIDが異なる
        if (!kjAgentContractHistoryInformationEntityBean
            .getRateMenuId().equals(businessBean.getChargeMenuId())) {
          // 《卸取次店向け契約情報更新BusinessBean》.単価設定区分コードに"def"(定数.単価設定区分コード：メニュー毎単価)を設定する。
          businessBean
              .setUpCatCode(ECISConstants.UNIT_PRICE_SETTING_CATEGORY_DEF);
        }
      }
    }

    contractHistory.setApplySd(businessBean.getApplyStartDate());
    contractHistory.setApplyEd(applyEd);

    contractHistory.setUpdateCount(0);

    contractHistory.setCreateTime(systemTime);

    contractHistory.setOnlineUpdateTime(systemTime);

    contractHistory.setOnlineUpdateUserId(contextUserId);

    contractHistory.setUpdateModuleCode(contextModuleCode);

    contractHistory.setUpdateTime(systemTime);
    // 電圧区分コード
    if (StringUtils.isNotEmpty(businessBean.getVoltageCatCode())) {
      contractHistory.setVoltageCatCode(businessBean.getVoltageCatCode());
    } else {
      contractHistory.setVoltageCatCode(inquryContractResult
          .getAgentContractInformationList().get(0)
          .getAgentContractHistoryInformationList().get(0)
          .getVoltageCatCode());
    }

    // 契約電力決定区分コード
    if (StringUtils.isNotEmpty(businessBean.getCcDecisionCategoryCode())) {
      contractHistory.setCcDecisionCategoryCode(businessBean
          .getCcDecisionCategoryCode());
    } else {
      contractHistory.setCcDecisionCategoryCode(inquryContractResult
          .getAgentContractInformationList().get(0)
          .getAgentContractHistoryInformationList().get(0)
          .getCcDecisionCategoryCode());
    }

    // 単価設定区分コード
    if (ECISConstants.UNIT_PRICE_SETTING_CATEGORY_INDIV.equals(businessBean
        .getUpCatCode())) {
      contractHistory.setUpCatCode(contractBean.getContractId().toString());
    } else {
      contractHistory
          .setUpCatCode(ECISConstants.UNIT_PRICE_SETTING_CATEGORY_DEF);
    }

    return contractHistory;
  }

  /**
   * 《契約情報更新BusinessBean》より《契約履歴Entity》に値を設定する(適用終了日更新）
   *
   * @param businessBean
   *          契約情報更新BusinessBean
   * @param updateCount
   *          更新回数
   * @param contextUserId
   *          コンテキストユーザID
   * @param contextModuleCode
   *          コンテキストモジュールコード
   * @return 契約履歴Entity
   */
  private ContractHist createUpdateContractEndHistory(
      UpdateAgentContractBusinessBean businessBean, Integer updateCount,
      String contextUserId, String contextModuleCode) {

    ContractHist contractHistory = new ContractHist();
    // システム日時
    Timestamp systemTime = new Timestamp(System.currentTimeMillis());

    Date applyEd = DateCalculateUtil.calculateDate(
        businessBean.getApplyStartDate(), 0, 0, -1);
    // 適用開始日の一日前
    contractHistory.setApplyEd(applyEd);

    contractHistory.setUpdateCount(updateCount);

    contractHistory.setOnlineUpdateTime(systemTime);

    contractHistory.setOnlineUpdateUserId(contextUserId);

    contractHistory.setUpdateModuleCode(contextModuleCode);

    contractHistory.setUpdateTime(systemTime);

    return contractHistory;
  }

  /**
   * 《契約情報更新BusinessBean》より《料金メニュー単価Entity》に値を設定する(更新用）
   *
   * @param businessBean
   *          契約情報更新BusinessBean
   * @param updateCount
   *          更新回数
   * @param contextUserId
   *          コンテキストユーザID
   * @param contextModuleCode
   *          コンテキストモジュールコード
   * @return 料金メニュー単価Entity
   */
  private RmUp createUpdateRmUp(
      UpdateAgentContractBusinessBean businessBean,
      Integer updateCount,
      String contextUserId,
      String contextModuleCode) {

    RmUp rmup = new RmUp();
    // システム日時
    Timestamp systemTime = new Timestamp(System.currentTimeMillis());

    Date applyEd = DateCalculateUtil.calculateDate(
        businessBean.getApplyStartDate(), 0, 0, -1);
    // 適用開始日の一日前
    rmup.setUpApplyEd(applyEd);

    rmup.setUpdateCount(updateCount);

    rmup.setOnlineUpdateTime(systemTime);

    rmup.setOnlineUpdateUserId(contextUserId);

    rmup.setUpdateModuleCode(contextModuleCode);

    rmup.setUpdateTime(systemTime);

    return rmup;
  }

  /**
   * 《契約情報更新BusinessBean》より《契約履歴Entity》に値を設定する(更新用）
   *
   * @param businessBean
   *          契約情報更新BusinessBean
   * @param contractBean
   *          契約情報照会情報EntityBean
   * @param rateMenu
   *          料金メニューEntityBean
   * @param applyEd
   *          適用終了日
   * @param updateCount
   *          更新回数
   * @param contextUserId
   *          コンテキストユーザID
   * @param contextModuleCode
   *          コンテキストモジュールコード
   * @return 契約履歴Entity
   */
  private ContractHist createUpdateContractHistory(
      UpdateAgentContractBusinessBean businessBean, KJ_InquiryAgentContractInformationEntityBean contractBean,
      Rm rateMenu, Date applyEd, Integer updateCount,
      String contextUserId, String contextModuleCode) {

    ContractHist contractHistory = new ContractHist();
    // システム日時
    Timestamp systemTime = new Timestamp(System.currentTimeMillis());
    KJ_AgentContractHistoryInformationEntityBean history = contractBean
        .getAgentContractHistoryInformationList().get(0);

    contractHistory.setContractId(contractBean.getContractId());
    // 以下4つは値がなければ履歴からとる
    // 料金メニューID rate_menu_id
    // 契約容量 contract_capacity
    // 契約容量単位 contract_capacity_unit
    // 契約変更理由 contract_change_reason
    String rateMenuId = null;
    String capaUnit = null;

    BigDecimal cca = null;
    // 料金メニューIDがNULLまたは空文字の場合は履歴から
    if (StringUtils.isEmpty(businessBean.getChargeMenuId())) {
      rateMenuId = history.getRateMenuId();
      capaUnit = history.getContractCapacityUnit();
      cca = history.getContractCapacity();
    } else {
      // NULLでも空文字でもない場合は料金メニューから
      rateMenuId = rateMenu.getRmId();
      capaUnit = rateMenu.getCcaUnit();

      // 料金メニューの契約容量単位と容量選択可能範囲項目がどちらもnullの場合、従量電灯Aとなる。
      // このチェックで従量電灯Aの場合は、契約容量はnull（未設定）としてください
      if (rateMenu.getCcaUnit() == null
          && rateMenu.getCapacitySelectableRange() == null) {
        cca = null;
      } else {
        cca = businessBean.getContractCapacity();
      }
    }

    contractHistory.setCca(cca);
    contractHistory.setRmId(rateMenuId);
    contractHistory.setCcaUnit(capaUnit);

    String contractChangeReason = null;
    if (businessBean.getContractChangeReason() != null) {
      contractChangeReason = businessBean.getContractChangeReason();
    } else {
      contractChangeReason = history.getContractChangeReason();
    }
    contractHistory.setContractChangeReason(contractChangeReason);

    // 契約履歴登録データ作成準備
    // 《卸取次店向け契約情報更新BusinessBean》.単価設定区分コードがNULL（APIから呼ばれた場合）の場合
    if (StringUtils.isEmpty(businessBean.getUpCatCode())) {
      // 《卸取次店向け契約履歴情報EntityBean》
      KJ_AgentContractHistoryInformationEntityBean kjAgentContractHistoryInformationEntityBean = contractBean
          .getAgentContractHistoryInformationList().get(0);

      // 《卸取次店向け契約情報更新BusinessBean》.料金メニューIDがNULLの場合、
      // または、《卸取次店向け契約履歴情報EntityBean》.料金メニューIDと《卸取次店向け契約情報更新BusinessBean》.料金メニューIDが同じ場合
      if (StringUtils.isEmpty(businessBean.getChargeMenuId())
          || kjAgentContractHistoryInformationEntityBean
              .getRateMenuId().equals(
                  businessBean.getChargeMenuId())) {

        // ①《卸取次店向け契約情報更新BusinessBean》.単価設定区分コードに《卸取次店向け契約履歴情報EntityBean》.単価設定区分コードを設定する。
        businessBean
            .setUpCatCode(kjAgentContractHistoryInformationEntityBean
                .getUnitPriceSetCategoryCode());

        // ②《卸取次店向け契約情報更新BusinessBean》.単価設定区分コードが定数.単価設定区分コード：個別単価の場合
        if (ECISConstants.UNIT_PRICE_SETTING_CATEGORY_INDIV
            .equals(businessBean.getUpCatCode())) {
          // 料金メニュー単価明細の取得
          RmUpDetailExample rmUpDetailExample = new RmUpDetailExample();

          // 《料金メニュー単価明細Example》.料金メニューID ＝ 《卸取次店向け契約履歴情報EntityBean》.料金メニューID
          // 料金メニュー単価明細Example》.単価設定区分コード ＝ 《卸取次店向け契約情報更新BusinessBean》.単価設定区分コード
          // 《料金メニュー単価明細Example》.適用開始日 ＝ 《卸取次店向け契約履歴情報EntityBean》.適用開始日
          rmUpDetailExample
              .createCriteria()
              .andRmIdEqualTo(
                  kjAgentContractHistoryInformationEntityBean
                      .getRateMenuId())
              .andUpCatCodeEqualTo(StringConvertUtil.integerToString(contractBean.getContractId()))
              .andUpApplySdEqualTo(
                  kjAgentContractHistoryInformationEntityBean
                      .getApplyStartDate());

          List<RmUpDetail> rmUpDetailList = rmUpDetailMapper
              .selectByExample(rmUpDetailExample);

          // ③《卸取次店向け契約情報更新BusinessBean》.料金メニュー単価明細リストに②で取得した結果を設定する。
          businessBean.setRmUpDetailList(rmUpDetailList);

          RmUp rmUp = new RmUp();

          // 最低月額料金
          rmUp.setMmc(kjAgentContractHistoryInformationEntityBean
              .getUnitPriceDetailInformationList().get(0).getMmc());

          // 備考
          rmUp.setNote(kjAgentContractHistoryInformationEntityBean
              .getUnitPriceDetailInformationList().get(0).getNote());

          businessBean.setRmUp(rmUp);
        }
      } else {
        // ※《卸取次店向け契約履歴情報EntityBean》.料金メニューIDと《卸取次店向け契約情報更新BusinessBean》.料金メニューIDが異なる
        if (!kjAgentContractHistoryInformationEntityBean
            .getRateMenuId().equals(businessBean.getChargeMenuId())) {
          // 《卸取次店向け契約情報更新BusinessBean》.単価設定区分コードに"def"(定数.単価設定区分コード：メニュー毎単価)を設定する。
          businessBean
              .setUpCatCode(ECISConstants.UNIT_PRICE_SETTING_CATEGORY_DEF);
        }
      }
    }

    contractHistory.setApplySd(businessBean.getApplyStartDate());

    contractHistory.setApplyEd(applyEd);

    // 電圧区分コード
    if (StringUtils.isNotEmpty(businessBean.getVoltageCatCode())) {
      contractHistory.setVoltageCatCode(businessBean.getVoltageCatCode());
    }

    // 契約電力決定区分
    if (StringUtils.isNotEmpty(businessBean.getCcDecisionCategoryCode())) {
      contractHistory.setCcDecisionCategoryCode(businessBean.getCcDecisionCategoryCode());
    }

    // 単価設定区分
    if (ECISConstants.UNIT_PRICE_SETTING_CATEGORY_INDIV.equals(businessBean.getUpCatCode())) {
      // 個別単価の場合、契約IDを設定する。
      contractHistory.setUpCatCode(contractBean.getContractId().toString());

    } else if (ECISConstants.UNIT_PRICE_SETTING_CATEGORY_DEF.equals(businessBean.getUpCatCode())) {
      // メニュー毎単価の場合、定数を設定する。
      contractHistory.setUpCatCode(ECISConstants.UNIT_PRICE_SETTING_CATEGORY_DEF);
    }

    contractHistory.setUpdateCount(updateCount);

    contractHistory.setOnlineUpdateTime(systemTime);

    contractHistory.setOnlineUpdateUserId(contextUserId);

    contractHistory.setUpdateModuleCode(contextModuleCode);

    contractHistory.setUpdateTime(systemTime);

    return contractHistory;
  }

  /**
   * 《契約情報更新BusinessBean》より《契約履歴Entity》に値を設定する(更新用）
   *
   * @param businessBean
   *          契約情報更新BusinessBean
   * @param updateCount
   *          更新回数
   * @param contextUserId
   *          コンテキストユーザID
   * @param contextModuleCode
   *          コンテキストモジュールコード
   * @return 契約履歴Entity
   */
  private ContractHist createUpdateContractStartHistory(
      UpdateAgentContractBusinessBean businessBean, Integer updateCount,
      String contextUserId, String contextModuleCode) {

    ContractHist contractHistory = new ContractHist();
    // システム日時
    Timestamp systemTime = new Timestamp(System.currentTimeMillis());

    contractHistory.setApplySd(businessBean.getContractStartDate());

    contractHistory.setUpdateCount(updateCount);

    contractHistory.setOnlineUpdateTime(systemTime);

    contractHistory.setOnlineUpdateUserId(contextUserId);

    contractHistory.setUpdateModuleCode(contextModuleCode);

    contractHistory.setUpdateTime(systemTime);

    return contractHistory;
  }

  /**
   * 《契約情報更新BusinessBean》より《メータ設置場所契約履歴Entity》に値を設定する(更新用）
   *
   * @param businessBean
   *          契約情報更新BusinessBean
   * @param updateCount
   *          更新回数
   * @param contextUserId
   *          コンテキストユーザID
   * @param contextModuleCode
   *          コンテキストモジュールコード
   * @return メータ設置場所契約履歴Entity
   */
  private MlContractHist createUpdateMLContractStartHistory(
      UpdateAgentContractBusinessBean businessBean,
      String contextUserId, String contextModuleCode) {

    MlContractHist mlContractHistory = new MlContractHist();
    // システム日時
    Timestamp systemTime = new Timestamp(System.currentTimeMillis());

    mlContractHistory.setApplySd(businessBean.getContractStartDate());

    mlContractHistory.setOnlineUpdateTime(systemTime);

    mlContractHistory.setOnlineUpdateUserId(contextUserId);

    mlContractHistory.setUpdateModuleCode(contextModuleCode);

    mlContractHistory.setUpdateTime(systemTime);

    return mlContractHistory;
  }

  /**
   * 《契約情報更新BusinessBean》より《料金メニュー単価Entity》に値を設定する(更新用）
   *
   * @param businessBean
   *          契約情報更新BusinessBean
   * @param updateCount
   *          更新回数
   * @param contextUserId
   *          コンテキストユーザID
   * @param contextModuleCode
   *          コンテキストモジュールコード
   * @return 料金メニュー単価Entity
   */
  private RmUp createUpdateEndRmUp(
      UpdateAgentContractBusinessBean businessBean,
      Integer updateCount,
      String contextUserId,
      String contextModuleCode) {

    RmUp rmup = new RmUp();
    // システム日時
    Timestamp systemTime = new Timestamp(System.currentTimeMillis());

    rmup.setUpApplyEd(businessBean.getContractEndDate());

    rmup.setUpdateCount(updateCount);

    rmup.setOnlineUpdateTime(systemTime);

    rmup.setOnlineUpdateUserId(contextUserId);

    rmup.setUpdateModuleCode(contextModuleCode);

    rmup.setUpdateTime(systemTime);

    return rmup;
  }

  /**
   * 《契約情報更新BusinessBean》より《料金メニュー単価Entity》に値を設定する(更新用）
   *
   * @param businessBean
   *          契約情報更新BusinessBean
   * @param updateCount
   *          更新回数
   * @param contextUserId
   *          コンテキストユーザID
   * @param contextModuleCode
   *          コンテキストモジュールコード
   * @return 料金メニュー単価Entity
   */
  private RmUp createUpdateStartRmUp(
      UpdateAgentContractBusinessBean businessBean,
      Integer updateCount,
      String contextUserId,
      String contextModuleCode) {

    RmUp rmup = new RmUp();
    // システム日時
    Timestamp systemTime = new Timestamp(System.currentTimeMillis());

    rmup.setUpApplySd(businessBean.getContractStartDate());

    rmup.setUpdateCount(updateCount);

    rmup.setOnlineUpdateTime(systemTime);

    rmup.setOnlineUpdateUserId(contextUserId);

    rmup.setUpdateModuleCode(contextModuleCode);

    rmup.setUpdateTime(systemTime);

    return rmup;
  }

  /**
   * 《契約情報更新BusinessBean》より《料金メニュー単価明細Entity》に値を設定する(更新用）
   *
   * @param businessBean
   *          契約情報更新BusinessBean
   * @param contextUserId
   *          コンテキストユーザID
   * @param contextModuleCode
   *          コンテキストモジュールコード
   * @return 料金メニュー単価明細Entity
   */
  private RmUpDetail createUpdateStartRmUpDetail(
      UpdateAgentContractBusinessBean businessBean,
      String contextUserId,
      String contextModuleCode) {

    RmUpDetail rmUpDetail = new RmUpDetail();
    // システム日時
    Timestamp systemTime = new Timestamp(System.currentTimeMillis());

    rmUpDetail.setUpApplySd(businessBean.getContractStartDate());

    rmUpDetail.setOnlineUpdateTime(systemTime);

    rmUpDetail.setOnlineUpdateUserId(contextUserId);

    rmUpDetail.setUpdateModuleCode(contextModuleCode);

    rmUpDetail.setUpdateTime(systemTime);

    return rmUpDetail;
  }

  /**
   * updateBeanより《料金メニュー単価Entity》に値を設定する
   *
   * @param upCatCode
   *          単価設定区分コード
   * @param businessBean
   *          卸取次店向け契約情報更新BusinessBean
   * @param contextUserId
   *          コンテキストユーザID
   * @param contextModuleCode
   *          コンテキストモジュールコード
   * @param rmId
   *          料金メニューID
   * @return 料金メニュー単価Entity
   */
  private RmUp insertRmUp(
      String upCatCode,
      UpdateAgentContractBusinessBean businessBean,
      String contextUserId,
      String contextModuleCode,
      String rmId) {

    RmUp rmUp = new RmUp();

    // 料金メニューID
    rmUp.setRmId(rmId);

    // 単価設定区分コード
    rmUp.setUpCatCode(upCatCode);

    // 最低月額料金
    rmUp.setMmc(businessBean.getRmUp().getMmc());

    // 備考
    rmUp.setNote(businessBean.getRmUp().getNote());

    // 単価適用開始日
    rmUp.setUpApplySd(businessBean.getApplyStartDate());

    // 単価適用終了日
    rmUp.setUpApplyEd(StringConvertUtil.stringToDate(
        ECISKJConstants.APPLY_END_DATE_MAX, null));

    // 更新回数
    rmUp.setUpdateCount(0);

    Timestamp systemTime = new Timestamp(System.currentTimeMillis());

    rmUp.setCreateTime(systemTime);

    rmUp.setOnlineUpdateTime(systemTime);

    rmUp.setOnlineUpdateUserId(contextUserId);

    rmUp.setUpdateModuleCode(contextModuleCode);

    rmUp.setUpdateTime(systemTime);

    return rmUp;
  }

  /**
   * updateBeanより《料金メニュー単価明細Entity》に値を設定する
   *
   * @param upCatCode
   *          単価設定区分コード
   * @param businessBean
   *          卸取次店向け契約情報更新BusinessBean
   * @param contextUserId
   *          コンテキストユーザID
   * @param contextModuleCode
   *          コンテキストモジュールコード
   * @param detail
   *          料金メニュー単価明細
   * @param rmId
   *          料金メニューID
   * @return 料金メニュー単価明細Entity
   */
  private RmUpDetail insertRmUpDetail(
      String upCatCode,
      UpdateAgentContractBusinessBean businessBean,
      String contextUserId,
      String contextModuleCode,
      RmUpDetail detail,
      String rmId) {

    RmUpDetail reUpDetail = new RmUpDetail();

    // 料金メニューID
    reUpDetail.setRmId(rmId);
    // 単価設定区分コード
    reUpDetail.setUpCatCode(upCatCode);
    // 単価適用開始日
    reUpDetail.setUpApplySd(businessBean.getApplyStartDate());
    // DCEC区分コード
    reUpDetail.setDcecCatCode(detail.getDcecCatCode());
    // 時間帯コード
    reUpDetail.setTsCode(detail.getTsCode());
    // 枝番
    reUpDetail.setBranchNo(detail.getBranchNo());
    // 表示名称1
    reUpDetail.setDisplayName1(detail.getDisplayName1());
    // 表示名称2
    reUpDetail.setDisplayName2(detail.getDisplayName2());
    // 閾値
    reUpDetail.setThreshold(detail.getThreshold());
    // 閾値名称
    reUpDetail.setThresholdName(detail.getThresholdName());
    // 単価
    reUpDetail.setUp(detail.getUp());
    // 表示順
    reUpDetail.setDisplayOrder(detail.getDisplayOrder());
    // 明細出力順
    reUpDetail.setDetailOutputOrder(detail.getDetailOutputOrder());
    // 更新回数
    reUpDetail.setUpdateCount(0);

    Timestamp systemTime = new Timestamp(System.currentTimeMillis());

    reUpDetail.setCreateTime(systemTime);

    reUpDetail.setOnlineUpdateTime(systemTime);

    reUpDetail.setOnlineUpdateUserId(contextUserId);

    reUpDetail.setUpdateModuleCode(contextModuleCode);

    reUpDetail.setUpdateTime(systemTime);

    return reUpDetail;
  }

  /**
   * 利用不可の契約者がいた場合はTRUEを返す
   *
   * @param contractorList
   *          契約者リスト
   * @return Boolean
   */
  private boolean checkUnavailableFlag(
      List<KJ_InquiryAgentContractorInformationEntityBean> contractorList) {

    int size = contractorList.size();

    for (int i = 0; i < size; i++) {

      KJ_InquiryAgentContractorInformationEntityBean contractor = contractorList
          .get(i);
      if (ECISKJConstants.UNAVAILABLE_FLAG_USE_IMPOSSIBLE
          .equals(contractor.getUnavailableFlag())) {
        return true;
      }
    }
    return false;

  }

  /**
   * paymentStartDate >= contractStartDate && paymentEndDate <= contractStartDateのときにTRUE
   *
   * @param paymentList
   *          支払情報リスト
   * @param contractStartDate
   *          契約開始日
   * @return Boolean
   */
  private boolean checkContractStartDate(
      List<KJ_InquiryPaymentInformationEntityBean> paymentList,
      Date contractStartDate) {

    // 支払有効期間チェック
    // 支払情報リスト分実施
    boolean resultFlg = false;
    for (KJ_InquiryPaymentInformationEntityBean paymentHist : paymentList) {
      if (contractStartDate.compareTo(paymentHist.getPaymentStartDate()) >= 0
          && contractStartDate.compareTo(paymentHist.getPaymentEndDate()) <= 0) {
        // 契約開始日に対して有効な支払情報が存在する場合はtrue
        // （支払適用開始日 <= 契約開始日 <= 支払い適用終了日）
        resultFlg = true;
        break;
      }
    }

    return resultFlg;
  }

  /**
   * 支払方法送受電区分一致チェック
   *
   * @param paymentList
   *          支払情報リスト（選択された支払の履歴リスト）
   * @param contractStartDate
   *          契約開始日
   * @param baseDate
   *          処理基準日
   * @param transmissionCatCode
   *          送受電区分区分コード
   * @return チェック結果（true：OK、false：NG）
   */
  private boolean checkPaymentWayTransmissionCatCodeMatch(List<KJ_InquiryPaymentInformationEntityBean> paymentList,
      Date contractStartDate, Date baseDate, String transmissionCatCode) {

    boolean chkFlag = true;
    // 支払情報リストの件数分実施
    for (KJ_InquiryPaymentInformationEntityBean payment : paymentList) {
      Date paymentStartDate = payment.getPaymentStartDate();
      Date paymentEndDate = payment.getPaymentEndDate();
      // (支払適用開始日・終了日の期間内に契約開始日が存在、または支払適用開始日が契約開始日より未来)
      // かつ (支払適用開始日・終了日の期間内に処理基準日が存在、または支払適用開始日が処理基準日より未来)の場合
      if (((contractStartDate.compareTo(paymentStartDate) >= 0 && contractStartDate.compareTo(paymentEndDate) <= 0)
          || contractStartDate.compareTo(paymentStartDate) < 0)
          && ((baseDate.compareTo(paymentStartDate) >= 0 && baseDate.compareTo(paymentEndDate) <= 0) || baseDate.compareTo(paymentStartDate) < 0)) {
        // 受電の場合
        if (ECISCodeConstants.TRANSMISSION_CATEGORY_CODE_RECEIVING.equals(transmissionCatCode)) {
          // 対象支払履歴の送金口座IDが未設定の場合
          if (StringUtils.isEmpty(payment.getRemittanceAccountId())) {
            chkFlag = false;
            break;
          }
        } else if (ECISCodeConstants.PAYMENT_WAY_CODE_REMITTANCE.equals(payment.getPaymentWayCode())) {
          // 送電で支払方法コードが「9:送金」の場合
          chkFlag = false;
          break;
        }
      }
    }
    return chkFlag;
  }

  /**
   * 付帯契約情報の更新情報を返す
   *
   * @param supplement
   *          付帯契約情報
   * @param onlineUpdateUserId
   *          オンライン更新ユーザID
   * @param updateModuleCode
   *          更新モジュールコード
   * @return 付帯契約Entity
   */
  private SplContract createSupplementaryContract(
      KJ_SupplementaryContractInformationEntityBean supplement,
      String onlineUpdateUserId, String updateModuleCode) {

    SplContract supplementaryContract = new SplContract();

    supplementaryContract.setAmountOrRate(supplement.getAmountOrRate());

    supplementaryContract.setContractId(supplement.getContractId());

    supplementaryContract.setSplContractEd(supplement
        .getSupplementaryContractEndDate());

    supplementaryContract.setSplContractSd(supplement
        .getSupplementaryContractStartDate());

    supplementaryContract.setSpmId(supplement.getSupplementaryMenuId());

    // 更新回数
    supplementaryContract.setUpdateCount(supplement.getUpdateCount() + 1);
    Timestamp systemTime = new Timestamp(System.currentTimeMillis());
    // オンライン更新日時
    supplementaryContract.setOnlineUpdateTime(systemTime);
    // オンライン更新ユーザID
    supplementaryContract.setOnlineUpdateUserId(onlineUpdateUserId);
    // 更新日時
    supplementaryContract.setUpdateTime(systemTime);
    // 更新モジュールコード
    supplementaryContract.setUpdateModuleCode(updateModuleCode);

    return supplementaryContract;
  }

  /**
   * 付帯契約情報の更新条件を返す
   *
   * @param supplement
   *          付帯契約情報
   * @return 付帯契約Example
   */
  private SplContractExample createSupplementaryContractExample(
      KJ_SupplementaryContractInformationEntityBean supplement) {

    SplContractExample tmpExample = new SplContractExample();

    Integer supplementContractId = supplement.getSupplementaryContractId();

    Integer supplementUpdateCount = supplement.getUpdateCount();

    tmpExample.createCriteria()
        .andSplContractIdEqualTo(supplementContractId)
        .andUpdateCountEqualTo(supplementUpdateCount);

    return tmpExample;
  }

  /**
   * 予備契約の更新情報を返す
   *
   * @param reserve
   *          予備契約情報
   * @param contractEd
   *          契約終了日
   * @param onlineUpdateUserId
   *          オンライン更新ユーザID
   * @param updateModuleCode
   *          更新モジュールコード
   * @return 予備契約情報Entity
   */
  ReserveContractHist createReserveContract(
      KJ_InquiryReserveContractInformationEntityBean reserve,
      Date contractEd,
      String onlineUpdateUserId,
      String updateModuleCode) {

    ReserveContractHist reserveContractHist = new ReserveContractHist();

    Timestamp systemTime = new Timestamp(System.currentTimeMillis());

    // 契約ID
    reserveContractHist.setContractId(reserve.getContractId());
    // 予備契約種別
    reserveContractHist.setReserveContractClass(reserve.getReserveContractClass());
    // 予備契約開始日
    reserveContractHist.setReserveContractSd(reserve.getReserveContractSd());
    // 予備契約終了日
    reserveContractHist.setReserveContractEd(contractEd);
    // 更新回数
    reserveContractHist.setUpdateCount(reserve.getUpdateCount() + 1);

    // オンライン更新日時
    reserveContractHist.setOnlineUpdateTime(systemTime);
    // オンライン更新ユーザID
    reserveContractHist.setOnlineUpdateUserId(onlineUpdateUserId);
    // 更新日時
    reserveContractHist.setUpdateTime(systemTime);
    // 更新モジュールコード
    reserveContractHist.setUpdateModuleCode(updateModuleCode);

    return reserveContractHist;
  }

  /**
   * 予備契約の更新条件を返す
   *
   * @param reserve
   *          予備契約情報
   * @return 予備契約情報Example
   */
  ReserveContractHistExample createReserveContractExample(
      KJ_InquiryReserveContractInformationEntityBean reserve) {

    // 予備契約情報Example
    ReserveContractHistExample example = new ReserveContractHistExample();

    // 更新条件の設定
    example.createCriteria()
        .andContractIdEqualTo(
            reserve.getContractId())
        .andReserveContractClassEqualTo(
            reserve.getReserveContractClass())
        .andReserveContractSdEqualTo(
            reserve.getReserveContractSd())
        .andUpdateCountEqualTo(
            reserve.getUpdateCount());

    return example;
  }

  /**
   * registBeanより《契約付加Entity》に値を設定する
   *
   * @param businessBean
   * @param contractId
   * @param contextUserId
   * @param contextModuleCode
   * @return 契約付加Entity
   */
  private ContractAddInfo createRegistContractAddInfo(
      RegistAgentContractBusinessBean businessBean, Integer contractId,
      String contextUserId, String contextModuleCode) {

    ContractAddInfo ｃontractAddInfo = new ContractAddInfo();

    // 契約ID
    ｃontractAddInfo.setContractId(contractId);

    // 卸取次店契約番号
    ｃontractAddInfo.setAgentContractNo(businessBean.getAgentContractNo());

    // 契約フリー項目1
    ｃontractAddInfo.setFree1(businessBean.getContractFree1());

    // 契約フリー項目2
    ｃontractAddInfo.setFree2(businessBean.getContractFree2());

    // 契約フリー項目3
    ｃontractAddInfo.setFree3(businessBean.getContractFree3());

    // 契約フリー項目4
    ｃontractAddInfo.setFree4(businessBean.getContractFree4());

    // 契約フリー項目5
    ｃontractAddInfo.setFree5(businessBean.getContractFree5());

    // 契約フリー項目6
    ｃontractAddInfo.setFree6(businessBean.getContractFree6());

    // 契約フリー項目7
    ｃontractAddInfo.setFree7(businessBean.getContractFree7());

    // 契約フリー項目8
    ｃontractAddInfo.setFree8(businessBean.getContractFree8());

    // 契約フリー項目9
    ｃontractAddInfo.setFree9(businessBean.getContractFree9());

    // 契約フリー項目10
    ｃontractAddInfo.setFree10(businessBean.getContractFree10());

    Timestamp systemTime = new Timestamp(System.currentTimeMillis());

    // 更新回数
    ｃontractAddInfo.setUpdateCount(0);

    // 作成日時
    ｃontractAddInfo.setCreateTime(systemTime);

    // オンライン更新日時
    ｃontractAddInfo.setOnlineUpdateTime(systemTime);

    // オンライン更新ユーザID
    ｃontractAddInfo.setOnlineUpdateUserId(contextUserId);

    // 更新モジュールコード
    ｃontractAddInfo.setUpdateModuleCode(contextModuleCode);

    // 更新日時
    ｃontractAddInfo.setUpdateTime(systemTime);

    return ｃontractAddInfo;
  }

  /**
   * 契約付加情報設定
   *
   * @param updateContractBusinessBean
   * @param consignmentCapacityUnit
   * @param paymentId
   * @param contextUserId
   * @param contextModuleCode
   * @param updateCount
   * @return
   */
  private ContractAddInfo createUpdateContractAddInfo(
      UpdateAgentContractBusinessBean updateContractBusinessBean,
      String contextUserId, String contextModuleCode, Integer updateCount) {

    ContractAddInfo contractAddInfo = new ContractAddInfo();

    // 契約ID
    contractAddInfo.setContractId(updateContractBusinessBean
        .getContractId());

    // 卸取次店契約番号
    contractAddInfo.setAgentContractNo(updateContractBusinessBean
        .getAgentContractNo());

    // 契約フリー項目1
    contractAddInfo.setFree1(updateContractBusinessBean.getContractFree1());

    // 契約フリー項目2
    contractAddInfo.setFree2(updateContractBusinessBean.getContractFree2());

    // 契約フリー項目3
    contractAddInfo.setFree3(updateContractBusinessBean.getContractFree3());

    // 契約フリー項目4
    contractAddInfo.setFree4(updateContractBusinessBean.getContractFree4());

    // 契約フリー項目5
    contractAddInfo.setFree5(updateContractBusinessBean.getContractFree5());

    // 契約フリー項目6
    contractAddInfo.setFree6(updateContractBusinessBean.getContractFree6());

    // 契約フリー項目7
    contractAddInfo.setFree7(updateContractBusinessBean.getContractFree7());

    // 契約フリー項目8
    contractAddInfo.setFree8(updateContractBusinessBean.getContractFree8());

    // 契約フリー項目9
    contractAddInfo.setFree9(updateContractBusinessBean.getContractFree9());

    // 契約フリー項目10
    contractAddInfo.setFree10(updateContractBusinessBean.getContractFree10());

    // 更新回数
    contractAddInfo.setUpdateCount(updateCount.intValue() + 1);

    Timestamp systemTime = new Timestamp(System.currentTimeMillis());

    // オンライン更新日時
    contractAddInfo.setOnlineUpdateTime(systemTime);

    // オンライン更新ユーザID
    contractAddInfo.setOnlineUpdateUserId(contextUserId);

    // 更新モジュールコード
    contractAddInfo.setUpdateModuleCode(contextModuleCode);

    // 更新日時
    contractAddInfo.setUpdateTime(systemTime);

    return contractAddInfo;
  }

  /**
   * 電圧区分と料金メニュー整合性チェック<br>
   *
   * @param voltageCatCode
   *          電圧区分コード
   * @param ccDecisionCategoryCode
   *          契約電力決定区分
   * @param chargeMenuId
   *          料金メニューID
   * @return true チェックOK false チェックNG
   */
  private boolean checkRmAndVoltageCat(String voltageCatCode,
      String ccDecisionCategoryCode,
      String rateMenuId) {
    Map<String, Object> rmCheckBean = new HashMap<String, Object>();
    if (StringUtils.isNotEmpty(voltageCatCode)) {
      rmCheckBean.put("rmId", rateMenuId);
      rmCheckBean.put("voltageCatCode", voltageCatCode);

      // 契約電力決定区分が”実量制”の場合
      if (ECISCodeConstants.CONTRACT_CAPACITY_DECISION_CATEGORY_CODE_REALQUANTITY.equals(
          ccDecisionCategoryCode)) {
        rmCheckBean.put("elLightAndPowerCatCode",
            ECISCodeConstants.ELECTRIC_LIGHT_AND_POWER_CATEGORY_CODE_POWER);

      }
      int returnCount = contractInformationCommonMapper.selectCountRm(rmCheckBean);
      //返却値が0件の場合falseを返却する。
      if (returnCount == 0) {
        return false;
      }
    }
    return true;
  }

  /**
   * 電圧区分コード存在チェック<br>
   *
   * @param voltageCatCode
   *          電圧区分コード
   * @return true チェックOK false チェックNG
   */
  private boolean checkVoltageCat(String voltageCatCode) {
    if (StringUtils.isNotEmpty(voltageCatCode)) {
      VoltageCatM voltageCatResult = voltageCatMMapper
          .selectByPrimaryKey(voltageCatCode);
      //返却値が0件の場合falseを返却する。
      if (voltageCatResult == null) {
        return false;
      }
    }
    return true;
  }

  /**
   * 契約電力決定区分コード存在チェック<br>
   *
   * @param ccDecisionCategoryCode
   *          契約電力決定区分コード
   * @return true チェックOK false チェックNG
   */
  private boolean checkCcdCategory(String ccDecisionCategoryCode) {
    if (StringUtils.isNotEmpty(ccDecisionCategoryCode)) {
      CcdCategoryM ccDecisionCatResult = ccdCategoryMMapper
          .selectByPrimaryKey(ccDecisionCategoryCode);
      //返却値が0件の場合falseを返却する。
      if (ccDecisionCatResult == null) {
        return false;
      }
    }
    return true;
  }

  /**
   * 単価設定区分存在チェック<br>
   *
   * @param upCatCode
   *          単価設定区分
   * @return true チェックOK false チェックNG
   */
  private boolean checkUpCat(String upCatCode) {
    if (StringUtils.isNotEmpty(upCatCode)) {
      // 契約電力決定区分マスタ.検索（主キー）を呼び出し。
      UpsCategoryM upsCategoryM = upsCategoryMMapper.selectByPrimaryKey(upCatCode);
      //返却値が0件の場合falseを返却する。
      if (upsCategoryM == null) {
        return false;
      }
    }
    return true;
  }

  /**
   * 料金メニュー単価明細存在チェック<br>
   *
   * @param upCatCode
   *          単価設定区分
   * @param rateMenuId
   *          料金メニューID
   * @param onlineDate
   *          適用開始日
   * @param rmUpdetailList
   *          料金メニュー単価明細リスト
   * @return List チェックエラーの料金メニュー単価明細キー
   */
  private List<String> checkRmUpDetail(String upCatCode, String rateMenuId,
      Date contractStartDate, List<RmUpDetail> rmUpdetailList) {

    // 単価設定区分コードが「単価設定区分コード:個別設定」の場合
    List<String> params = new ArrayList<String>();
    Map<String, Object> upcatParam = new HashMap<String, Object>();
    if (ECISConstants.UNIT_PRICE_SETTING_CATEGORY_INDIV.equals(upCatCode)) {
      // 料金メニュー単価明細Exampleを生成
      upcatParam.put("rateMenuId", rateMenuId);
      upcatParam.put("unitPriceCategoryCode", ECISConstants.UNIT_PRICE_SETTING_CATEGORY_DEF);
      upcatParam.put("upApplySd", contractStartDate);
      upcatParam.put("upApplyEd", contractStartDate);
      // 料金メニュー単価明細リストの件数分繰り返し処理を行う。
      for (RmUpDetail upcatmap : rmUpdetailList) {
        upcatParam.put("dcecCatCode", upcatmap.getDcecCatCode());
        upcatParam.put("tsCode", upcatmap.getTsCode());
        upcatParam.put("branchNo", upcatmap.getBranchNo());
        // 料金メニュー単価明細.検索（主キー）を呼び出し
        int returnCountRmupdetail = contractInformationCommonMapper.selectCountRmUpDetail(upcatParam);
        //返却値が0件の場合falseを返却する。
        if (returnCountRmupdetail == 0) {
          params.add(upcatmap.getDcecCatCode());
          params.add(upcatmap.getTsCode());
          params.add(upcatmap.getBranchNo().toString());
          return params;
        }

      }
    }
    return params;
  }

  /**
   * 電圧区分コード変更チェック<br>
   *
   * @param voltageCatCode
   *          電圧区分コード
   * @param contractId
   *          契約ID
   * @return true チェックOK false チェックNG
   */
  private boolean checkChangeVoltageCat(String voltageCatCode,
      Integer contractId) {
    if (StringUtils.isNotEmpty(voltageCatCode)) {

      // 電圧区分コード変更チェック
      Map<String, Object> selectMap = new HashMap<String, Object>();

      // 契約ID
      selectMap.put("id", contractId);
      // 電圧区分コード
      selectMap.put("voltageCatCode", voltageCatCode);
      int cntResult = contractInformationCommonMapper
          .selectCountVoltageCatCode(selectMap);
      // 返却値が0件の場合falseを返却する。
      if (cntResult == 0) {
        return false;
      }
    }
    return true;
  }

  /**
   * 部分供給区分コード存在チェック<br>
   *
   * @param psInfoCatCode
   *          部分供給区分コード
   * @return true チェックOK false チェックNG
   */
  private boolean checkPsInfoCatCode(String psInfoCatCode) {
    // 部分供給区分コードがNULLまたは空文字のいずれでもない場合
    if (StringUtils.isNotEmpty(psInfoCatCode)) {
      // 部分供給区分マスタ.検索(主キー)実行
      PsInfoCatM psInfoCatResult = psInfoCatMMapper.selectByPrimaryKey(psInfoCatCode);
      // 返却値が0件の場合falseを返却する。
      if (psInfoCatResult == null) {
        return false;
      }
    }
    return true;
  }

  /**
   * 契約マッパーのセッター(DI)
   *
   * @param contractMapper
   *          契約マッパー
   */
  public void setContractMapper(ContractMapper contractMapper) {
    this.contractMapper = contractMapper;
  }

  /**
   * 卸取次店向け契約情報共通マッパーのセッター(DI)
   *
   * @param contractInformationCommonMapper
   *          卸取次店向け契約情報共通マッパー
   */
  public void setAgentContractInformationCommonMapper(
      AgentContractInformationCommonMapper contractInformationCommonMapper) {
    this.contractInformationCommonMapper = contractInformationCommonMapper;
  }

  /**
   * 契約情報共通マッパーのセッター(DI)
   *
   * @param contractInformationMapper
   *          契約情報共通マッパー
   */
  public void setContractInformationMapper(
      ContractInformationCommonMapper contractInformationMapper) {
    this.contractInformationMapper = contractInformationMapper;
  }

  /**
   * 確定料金共通マッパーのセッター(DI)
   *
   * @param fixChargeResultInformationCommonMapper
   *          確定料金共通マッパー
   */
  public void setAgentFixChargeResultInformationCommonMapper(
      AgentFixChargeResultInformationCommonMapper fixChargeResultInformationCommonMapper) {
    this.fixChargeResultInformationCommonMapper = fixChargeResultInformationCommonMapper;
  }

  /**
   * 支払情報共通マッパーのセッター(DI)
   *
   * @param paymentInformationCommonMapper
   *          支払情報共通マッパー
   */
  public void setPaymentInformationCommonMapper(
      PaymentInformationCommonMapper paymentInformationCommonMapper) {
    this.paymentInformationCommonMapper = paymentInformationCommonMapper;
  }

  /**
   * 契約履歴マッパーのセッター(DI)
   *
   * @param contractHistMapper
   *          契約履歴マッパー
   */
  public void setContractHistMapper(ContractHistMapper contractHistMapper) {
    this.contractHistMapper = contractHistMapper;
  }

  /**
   * メーター設置場所契約履歴マッパーのセッター(DI)
   *
   * @param mlContractHistMapper
   *          メータ設置場所履歴マッパー
   */
  public void setMlContractHistMapper(
      MlContractHistMapper mlContractHistMapper) {
    this.mlContractHistMapper = mlContractHistMapper;
  }

  /**
   * 電話番号区分マッパーのセッター(DI)
   *
   * @param phoneNoCatMMapper
   *          電話番号区分マッパー
   */
  public void setPhoneNoCatMMapper(PhoneNoCatMMapper phoneNoCatMMapper) {
    this.phoneNoCatMMapper = phoneNoCatMMapper;
  }

  /**
   * 接続送電サービス区分マスタマッパーのセッター(DI)
   *
   * @param cssCatMMapper
   *          接続送電サービス区分マスタマッパー
   */
  public void setCssCatMMapper(CssCatMMapper cssCatMMapper) {
    this.cssCatMMapper = cssCatMMapper;
  }

  /**
   * 契約終了理由マスタマッパーのセッター(DI)
   *
   * @param contractEndReasonMMapper
   *          契約終了理由マスタマッパー
   */
  public void setContractEndReasonMMapper(
      ContractEndReasonMMapper contractEndReasonMMapper) {
    this.contractEndReasonMMapper = contractEndReasonMMapper;
  }

  /**
   * 契約容量単位マスタマッパーのセッター(DI)
   *
   * @param ccaUnitMMapper
   *          契約容量単位マスタマッパー
   */
  public void setCcaUnitMMapper(CcaUnitMMapper ccaUnitMMapper) {
    this.ccaUnitMMapper = ccaUnitMMapper;
  }

  /**
   * 個人・法人区分マスタマッパーのセッター(DI)
   *
   * @param ilcMMapper
   *          個人・法人区分マスタマッパー
   */
  public void setIlcMMapper(IlcMMapper ilcMMapper) {
    this.ilcMMapper = ilcMMapper;
  }

  /**
   * 営業委託先マスタマッパーのセッター(DI)
   *
   * @param scMMapper
   *          営業委託先マスタマッパー
   */
  public void setScMMapper(ScMMapper scMMapper) {
    this.scMMapper = scMMapper;
  }

  /**
   * 契約電力決定区分マスタマッパーのセッター(DI)
   *
   * @param scMMapper
   *          契約電力決定区分
   */
  public void setCcdCategoryMMapper(CcdCategoryMMapper ccdCategoryMMapper) {
    this.ccdCategoryMMapper = ccdCategoryMMapper;
  }

  /**
   * 電圧区分マスタマッパーのセッター(DI)
   *
   * @param voltageCatMMapper
   *          電圧区分マスタマッパー
   */
  public void setVoltageCatMMapper(VoltageCatMMapper voltageCatMMapper) {
    this.voltageCatMMapper = voltageCatMMapper;
  }

  /**
   * 料金メニューマッパーのセッター(DI)
   *
   * @param rmMapper
   *          料金メニューマッパー
   */
  public void setRmMapper(RmMapper rmMapper) {
    this.rmMapper = rmMapper;
  }

  /**
   * 付帯契約情報マッパーのセッター(DI)
   *
   * @param splContractMapper
   *          付帯契約情報マッパー
   */
  public void setSplContractMapper(SplContractMapper splContractMapper) {
    this.splContractMapper = splContractMapper;
  }

  /**
   * 契約付加情報マッパーのセッター(DI)
   *
   * @param contractAddInfoMapper
   *          契約付加情報マッパー
   */
  public void setContractAddInfoMapper(ContractAddInfoMapper contractAddInfoMapper) {
    this.contractAddInfoMapper = contractAddInfoMapper;
  }

  /**
   * 提供モデル企業別料金メニューマスタマッパーのセッター(DI)
   *
   * @param rmMByPmCompanyMapper
   *          提供モデル企業別料金メニューマスタマッパー
   */
  public void setRmMByPmCompanyMapper(
      RmMByPmCompanyMapper rmMByPmCompanyMapper) {
    this.rmMByPmCompanyMapper = rmMByPmCompanyMapper;
  }

  /**
   * 料金メニュー単価明細マスタマッパーのセッター(DI)
   *
   * @param rmUpDetailMapper
   *          料金メニュー単価明細マスタマッパー
   */
  public void setRmUpDetailMapper(RmUpDetailMapper rmUpDetailMapper) {
    this.rmUpDetailMapper = rmUpDetailMapper;
  }

  /**
   * 料金メニュー単価マスタマッパーのセッター(DI)
   *
   * @param rmUpDetailMapper
   *          料金メニュー単価マスタマッパー
   */
  public void setUpsCategoryMMapper(UpsCategoryMMapper upsCategoryMMapper) {
    this.upsCategoryMMapper = upsCategoryMMapper;
  }

  /**
   * 料金メニュー単価マスタマッパーのセッター(DI)
   *
   * @param rmUpMapper
   *          料金メニュー単価マスタマッパー
   */
  public void setRmUpMapper(RmUpMapper rmUpMapper) {
    this.rmUpMapper = rmUpMapper;
  }

  /**
   * 支払マッパーのセッター(DI)
   *
   * @param paymentMapper
   *          支払マッパー
   *
   */
  public void setPaymentMapper(PaymentMapper paymentMapper) {
    this.paymentMapper = paymentMapper;
  }

  /**
   * 予備契約履歴マッパーのセッター(DI)
   *
   * @param reserveContractHistMapper
   *          予備契約履歴マッパー
   *
   */
  public void setReserveContractHistMapper(
      ReserveContractHistMapper reserveContractHistMapper) {
    this.reserveContractHistMapper = reserveContractHistMapper;
  }

  /**
   * 日付関連共通ビジネスのセッター(DI)
   *
   * @param dateBusiness
   *          日付関連共通ビジネス
   */
  public void setDateBusiness(DateBusiness dateBusiness) {
    this.dateBusiness = dateBusiness;
  }

  /**
   * messageSourceのセッター(DI)
   *
   * @param messageSource
   *          メッセージソース
   *
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }

  /**
   * メータ設置場所情報共通マッパーのセッター(DI)
   *
   * @param meterLocationInformationCommonMapper
   *          メータ設置場所情報共通マッパー
   */
  public void setMeterLocationInformationCommonMapper(
      MeterLocationInformationCommonMapper meterLocationInformationCommonMapper) {
  }

  /**
   * 契約者情報共通ビジネスのセッター(DI)
   *
   * @param kjContractorInfomationBusiness
   *          契約者情報共通ビジネス
   */
  public void setKjContractorInfomationBusiness(
      KJ_AgentContractorInformationBusiness kjContractorInfomationBusiness) {
    this.kjContractorInfomationBusiness = kjContractorInfomationBusiness;
  }

  /**
   * メータ設置場所情報共通ビジネスのセッター(DI)
   *
   * @param kjMeterLocationInformationBusiness
   *          メータ設置場所情報共通ビジネス
   */
  public void setKjMeterLocationInformationBusiness(
      KJ_AgentMeterLocationInformationBusiness kjMeterLocationInformationBusiness) {
    this.kjMeterLocationInformationBusiness = kjMeterLocationInformationBusiness;
  }

  /**
   * 支払情報共通ビジネスのセッター(DI)
   *
   * @param kjPaymentInformationBusiness
   *          支払情報共通ビジネス
   */
  public void setKjPaymentInformationBusiness(
      KJ_PaymentInformationBusiness kjPaymentInformationBusiness) {
    this.kjPaymentInformationBusiness = kjPaymentInformationBusiness;
  }

  /**
   * 付帯契約情報共通ビジネスのセッター(DI)
   *
   * @param kjSupplementaryContractInformationBusiness
   *          付帯契約情報共通ビジネス
   */
  public void setKjSupplementaryContractInformationBusiness(
      KJ_SupplementaryContractInformationBusiness kjSupplementaryContractInformationBusiness) {
    this.kjSupplementaryContractInformationBusiness = kjSupplementaryContractInformationBusiness;
  }

  /**
   * 契約番号自動発番ビジネスのセッター(DI)
   *
   * @param kjContractNoAutoNumberingBusiness
   *          契約番号自動発番ビジネス
   */
  public void setKjContractNoAutoNumberingBusiness(
      KJ_ContractNoAutoNumberingBusiness kjContractNoAutoNumberingBusiness) {
    this.kjContractNoAutoNumberingBusiness = kjContractNoAutoNumberingBusiness;
  }

  /**
   * 予備契約情報ビジネスのセッター(DI)
   *
   * @param kjReserveContractInformationBusiness
   *          予備契約情報ビジネス
   */
  public void setKjReserveContractInformationBusiness(
      KJ_ReserveContractInformationBusiness kjReserveContractInformationBusiness) {
    this.kjReserveContractInformationBusiness = kjReserveContractInformationBusiness;
  }

  /**
   * 部分供給区分マスタマッパーのセッター(DI)
   *
   * @param psInfoCatMMapper
   *          部分供給区分マスタマッパー
   */
  public void setPsInfoCatMMapper(PsInfoCatMMapper psInfoCatMMapper) {
    this.psInfoCatMMapper = psInfoCatMMapper;
  }
}
