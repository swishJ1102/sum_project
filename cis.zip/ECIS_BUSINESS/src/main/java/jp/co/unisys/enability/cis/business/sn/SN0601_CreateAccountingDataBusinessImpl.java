package jp.co.unisys.enability.cis.business.sn;

import java.io.IOException;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.config.PropertiesFactoryBean;
import org.springframework.context.MessageSource;

import jp.co.unisys.enability.cis.business.sn.model.SN0601_AccountingDataFileNameBusinessBean;
import jp.co.unisys.enability.cis.common.Exception.SystemException;
import jp.co.unisys.enability.cis.common.util.constants.ECISCodeConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.entity.common.WorkScheduleMngM;
import jp.co.unisys.enability.cis.entity.common.WorkScheduleMngMKey;
import jp.co.unisys.enability.cis.mapper.common.WorkScheduleMngMMapper;

/**
 * 請求入金共通経理データ作成ビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.mapper.common.WorkScheduleMngMMapper
 */
public class SN0601_CreateAccountingDataBusinessImpl implements SN0601_CreateAccountingDataBusiness {

  /** 業務日程管理マスタMapper（DI） */
  private WorkScheduleMngMMapper workScheduleMngMMapper;

  /** メッセージソース（DI） */
  private MessageSource messageSource;

  /** プロパティ定義クラス（DI） */
  private PropertiesFactoryBean applicationProperties;

  /*
   * (非 Javadoc)
   * @see jp.co.unisys.enability.cis.business.sn.SN0601_CreateAccountingDataBusiness#
   * getAccountingDataFileName(java.lang.String, java.lang.String, java.lang.String, java.util.Date, java.lang.String)
   */
  @Override
  public SN0601_AccountingDataFileNameBusinessBean getAccountingDataFileName(String accountingDataOutputDirKey,
      String accountingDataFileLogicalNameKey, String accountingDataFilePhysicalNameKey, Date bacthBaseDate,
      Date coveredEndDate) {

    // 対象終了日（取得後）
    Date selectCoveredEndDate = null;
    // 日付フォーマット（YYYY/MM/DD）
    SimpleDateFormat sdfYmdSlash = new SimpleDateFormat(ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH);
    // 日付フォーマット（YYYYMMDD）
    SimpleDateFormat sdfYmd = new SimpleDateFormat(ECISConstants.FORMAT_DATE_yyyyMMdd);
    // 日時フォーマット（YYYYMMDDHHMMSS）
    SimpleDateFormat sdfYmdHms = new SimpleDateFormat(ECISConstants.FORMAT_DATE_yyyyMMddHHmmss);

    // 【業務日程管理マスタ】の取得
    if (coveredEndDate == null) {
      // 引数.対象終了日がNULL（未設定）である場合、以下の処理を行う。
      // 業務日程管理マスタMapper.selectByPrimaryKeyを呼び出し、【業務日程管理マスタ】を取得する。
      WorkScheduleMngMKey workScheduleMngMKey = new WorkScheduleMngMKey();
      workScheduleMngMKey.setWorkScheduleCatCode(
          ECISCodeConstants.WORK_SCHEDULE_CATEGORY_CODE_ACCOUNT_DATA_CREATE_DATE);
      workScheduleMngMKey.setWorkScheduleDate(bacthBaseDate);

      WorkScheduleMngM workScheduleMngM = workScheduleMngMMapper.selectByPrimaryKey(
          workScheduleMngMKey);

      if (workScheduleMngM == null || workScheduleMngM.getTargetEd() == null) {
        // 【業務日程管理マスタ】.対象終了日が取得できなかった場合は、システム例外をスローする。
        throw new SystemException(messageSource.getMessage("error.E1358", new Object[] {
            bacthBaseDate != null ? sdfYmdSlash.format(bacthBaseDate) : null,
            ECISCodeConstants.WORK_SCHEDULE_CATEGORY_CODE_ACCOUNT_DATA_CREATE_DATE },
            Locale.getDefault()));
      }
      // 上記以外の場合は、取得した《業務日程管理マスタEntityBean》.対象終了日を「対象終了日」とする。
      selectCoveredEndDate = workScheduleMngM.getTargetEd();

    } else {
      // 上記以外の場合、引数.対象終了日を「対象終了日」とする。
      selectCoveredEndDate = coveredEndDate;
    }

    // パラメータ取得
    // 経理データ出力ディレクトリ
    String accntDataOutputDir = null;
    // 経理データ論理ファイル名
    String accntDataFileLgclName = null;
    // 経理データ物理ファイル名
    String accntDataFilePysclName = null;

    // 引数の取得キーをもとに、外部ファイルから各項目を取得する。
    try {
      Properties prop = applicationProperties.getObject();
      accntDataOutputDir = prop.getProperty(accountingDataOutputDirKey);
      accntDataFileLgclName = prop.getProperty(accountingDataFileLogicalNameKey);
      accntDataFilePysclName = prop.getProperty(accountingDataFilePhysicalNameKey);

    } catch (IOException e) {
      // プロパティファイルの読み込みに失敗した場合、以下のメッセージを設定し、システム例外をスローする。
      throw new SystemException(messageSource.getMessage("error.E1278", null, Locale.getDefault()), e);
    }

    if (StringUtils.isEmpty(accntDataOutputDir)
        || StringUtils.isEmpty(accntDataFileLgclName)
        || StringUtils.isEmpty(accntDataFilePysclName)) {
      // プロパティファイルの読み込みに失敗した場合、以下のメッセージを設定し、システム例外をスローする。
      throw new SystemException(messageSource.getMessage("error.E1278", null, Locale.getDefault()));
    }

    // YYYY/MM/DDのフォーマットを「/」で分割する。
    Object[] coveredEndDateStrArray = sdfYmdSlash.format(selectCoveredEndDate).split(ECISConstants.SLASH);
    // YYYYMMDDのフォーマットに変換する。
    String coveredEndDateStr = sdfYmd.format(selectCoveredEndDate);
    // ファイル作成年月日時分秒(YYYYMMDDHHMMSS)を取得
    String fileCreateTimestamp = sdfYmdHms.format(new Date());

    // ファイルパス、および論理ファイル名の編集を行う。
    accntDataFileLgclName = MessageFormat.format(accntDataFileLgclName, coveredEndDateStrArray);
    accntDataFilePysclName = MessageFormat.format(
        accntDataFilePysclName, coveredEndDateStr, fileCreateTimestamp);

    // 経理データファイルパスを作成する。
    String accountingDataFilePath = new StringBuilder(accntDataOutputDir).append(accntDataFilePysclName).toString();

    // 《経理データファイル名ビジネスBean》を生成し、項目を設定する。
    SN0601_AccountingDataFileNameBusinessBean businessBean = new SN0601_AccountingDataFileNameBusinessBean();
    businessBean.setAccountingDataFilePath(accountingDataFilePath);
    businessBean.setAccountingDataLogicalFileName(accntDataFileLgclName);

    // 生成した《経理データファイル名ビジネスBean》を返却する。
    return businessBean;
  }

  /**
   * 業務日程管理マスタMapperを設定する。（DI）
   *
   * @param workScheduleMngMMapper
   *          業務日程管理マスタMapper
   */
  public void setWorkScheduleMngMMapper(WorkScheduleMngMMapper workScheduleMngMMapper) {
    this.workScheduleMngMMapper = workScheduleMngMMapper;
  }

  /**
   * プロパティ定義クラスを設定する。（DI）
   *
   * @param applicationProperties
   *          プロパティ定義クラス
   */
  public void setApplicationProperties(PropertiesFactoryBean applicationProperties) {
    this.applicationProperties = applicationProperties;
  }

  /**
   * メッセージソースを設定する。（DI）
   *
   * @param messageSource
   *          メッセージソース
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }
}
