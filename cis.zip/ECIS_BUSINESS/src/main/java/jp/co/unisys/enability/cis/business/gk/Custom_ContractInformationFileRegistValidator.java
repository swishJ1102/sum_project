package jp.co.unisys.enability.cis.business.gk;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.context.MessageSource;

import jp.co.unisys.enability.cis.business.kj.model.ContractManagementInformationFileConfigCommon;
import jp.co.unisys.enability.cis.business.kj.model.Custom_ContractManagementInformationFileConfigContract;
import jp.co.unisys.enability.cis.common.util.CommonValidationUtil;
import jp.co.unisys.enability.cis.common.util.EMSMessageResource;
import jp.co.unisys.enability.cis.common.util.constants.ECISCodeConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;

/**
 * （カスタム）契約情報ファイル登録チェッククラス
 *
 * @author "Nihon Unisys, Ltd."
 */
public class Custom_ContractInformationFileRegistValidator {

  /** プロパティクラスを定義 */
  private MessageSource messageSource;

  /**
   * メッセージプロパティキー管理のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージプロパティキー管理を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param messageSource
   *          メッセージプロパティキー管理
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }

  /**
   * 契約情報ファイル登録のバリデーションを実施、チェック結果のメッセージListを返却する。 （カスタム仕様の追加項目対応）
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 1 引数のバリデーションを行う。
   * 2 チェック結果がNGの場合、戻り値のメッセージListにエラーメッセージを詰めて返却する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param args
   *          バッチ引数
   * @return メッセージList
   */
  public List<String> validate(Map<Integer, String> dataRecode) {

    List<String> messageList = new ArrayList<String>();

    String dataRecordClass = dataRecode
        .get(ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_INDEX);
    // データレコード種別：必須チェック
    if (CommonValidationUtil.isNull(dataRecordClass)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_NAME },
                  Locale.getDefault()));

      // データレコード種別：正規表現チェック
    } else if (dataRecordClass != null
        && !CommonValidationUtil
            .checkByPattern(
                dataRecordClass,
                ContractManagementInformationFileConfigCommon.DATA_KIND_MASK_STRING)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_ITEM_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_NAME },
                  Locale.getDefault()));
    }

    String contractNo = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_NO_INDEX);
    // 契約番号：必須チェック
    if (CommonValidationUtil.isNull(contractNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_NO_NAME },
                  Locale.getDefault()));

      // 契約番号：文字種別チェック（半角英数字）
    } else if (contractNo != null
        && !CommonValidationUtil.isAlphabetNumric(contractNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_ALPHANUMERIC_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_NO_NAME },
                  Locale.getDefault()));

      // 契約番号：文字種別チェック（半角英数字　低圧CISシステム許容文字）
    } else if (contractNo != null
        && !CommonValidationUtil.isRangeWordByECIS(contractNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_NO_NAME,
                      "半角英数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 契約番号：文字列最大長チェック
    } else if (contractNo != null
        && !CommonValidationUtil
            .maxLength(
                contractNo,
                Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_NO_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_NO_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_NO_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String contractorNo = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACTOR_NO_INDEX);
    // 契約者番号：必須チェック
    if (CommonValidationUtil.isNull(contractorNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACTOR_NO_NAME },
                  Locale.getDefault()));

      // 契約者番号：文字種別チェック（半角英数字）
    } else if (contractorNo != null
        && !CommonValidationUtil.isAlphabetNumric(contractorNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_ALPHANUMERIC_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACTOR_NO_NAME },
                  Locale.getDefault()));

      // 契約者番号：文字種別チェック（半角英数字　低圧CISシステム許容文字）
    } else if (contractorNo != null
        && !CommonValidationUtil.isRangeWordByECIS(contractorNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACTOR_NO_NAME,
                      "半角英数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 契約者番号：文字列最大長チェック
    } else if (contractorNo != null
        && !CommonValidationUtil
            .maxLength(
                contractorNo,
                Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACTOR_NO_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACTOR_NO_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACTOR_NO_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String paymentNo = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_PAYMENT_NO_INDEX);
    // 支払番号：必須チェック
    if (CommonValidationUtil.isNull(paymentNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_PAYMENT_NO_NAME },
                  Locale.getDefault()));

      // 支払番号：文字種別チェック（半角英数字）
    } else if (paymentNo != null
        && !CommonValidationUtil.isAlphabetNumric(paymentNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_ALPHANUMERIC_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_PAYMENT_NO_NAME },
                  Locale.getDefault()));

      // 支払番号：文字種別チェック（半角英数字　低圧CISシステム許容文字）
    } else if (paymentNo != null
        && !CommonValidationUtil.isRangeWordByECIS(paymentNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_PAYMENT_NO_NAME,
                      "半角英数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 支払番号：文字列最大長チェック
    } else if (paymentNo != null
        && !CommonValidationUtil
            .maxLength(
                paymentNo,
                Custom_ContractManagementInformationFileConfigContract.DATA_PAYMENT_NO_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_PAYMENT_NO_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_PAYMENT_NO_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String meterLocationId = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_METER_LOCATION_ID_INDEX);
    // メータ設置場所ID：必須チェック
    if (CommonValidationUtil.isNull(meterLocationId)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_METER_LOCATION_ID_NAME },
                  Locale.getDefault()));

      // メータ設置場所ID：文字種別チェック（半角数字）
    } else if (meterLocationId != null
        && !CommonValidationUtil
            .isNumric(meterLocationId)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_METER_LOCATION_ID_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // メータ設置場所ID：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (meterLocationId != null
        && !CommonValidationUtil
            .isRangeWordByECIS(meterLocationId)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_METER_LOCATION_ID_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // メータ設置場所ID：数値範囲チェック
    } else if (meterLocationId != null
        && !CommonValidationUtil.checkRange(meterLocationId, 1,
            2147483647)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_RANGE_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_METER_LOCATION_ID_NAME,
                      "1～2147483647" },
                  Locale.getDefault()));
    }

    String contractGroupNo = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_GROUP_NO_INDEX);
    // 契約グループ番号：文字種別チェック（半角英数字）
    if (contractGroupNo != null
        && !CommonValidationUtil.isAlphabetNumric(contractGroupNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_ALPHANUMERIC_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_GROUP_NO_NAME },
                  Locale.getDefault()));

      // 契約グループ番号：文字種別チェック（半角英数字　低圧CISシステム許容文字）
    } else if (contractGroupNo != null
        && !CommonValidationUtil.isRangeWordByECIS(contractGroupNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_GROUP_NO_NAME,
                      "半角英数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 契約グループ番号：文字列最大長チェック
    } else if (contractGroupNo != null
        && !CommonValidationUtil
            .maxLength(
                contractGroupNo,
                Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_GROUP_NO_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_GROUP_NO_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_GROUP_NO_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String contractStartDate = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_START_DATE_INDEX);
    // 契約開始日：必須チェック
    if (CommonValidationUtil.isNull(contractStartDate)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_START_DATE_NAME },
                  Locale.getDefault()));

      // 契約開始日：日付フォーマットチェック
    } else if (contractStartDate != null
        && !CommonValidationUtil.checkDateFormat(contractStartDate,
            "yyyy/MM/dd")) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_START_DATE_NAME,
                      "日付形式（yyyy/MM/dd）" },
                  Locale.getDefault()));
    }

    String contractEndDate = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_END_DATE_INDEX);
    // 契約終了日：日付フォーマットチェック
    if (contractEndDate != null
        && !CommonValidationUtil.checkDateFormat(contractEndDate,
            "yyyy/MM/dd")) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_END_DATE_NAME,
                      "日付形式（yyyy/MM/dd）" },
                  Locale.getDefault()));
    }

    String consignmentContractCapacity = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_CONTRACT_CAPACITY_INDEX);
    // 託送契約容量：数値フォーマットチェック
    if (consignmentContractCapacity != null
        && !CommonValidationUtil.checkByPattern(
            consignmentContractCapacity,
            "^(([1-9][0-9]*|0){1}(\\.[0-9]+)?)?$")) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_CONTRACT_CAPACITY_NAME,
                      "数値形式（マイナス符号：否、カンマ：否、小数：可）" },
                  Locale.getDefault()));

      // 託送契約容量：数値桁数チェック
    } else if (consignmentContractCapacity != null
        && !CommonValidationUtil
            .checkBigDecimalDigit(
                consignmentContractCapacity,
                Custom_ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_CONTRACT_CAPACITY_DIGIT_INTEGER,
                Custom_ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_CONTRACT_CAPACITY_DIGIT_FLOAT)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MONEYRANGE,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_CONTRACT_CAPACITY_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_CONTRACT_CAPACITY_DIGIT_INTEGER_STRING,
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_CONTRACT_CAPACITY_DIGIT_FLOAT_STRING },
                  Locale.getDefault()));
    }

    String consignmentContractCapacityDecisionDate = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_CONTRACT_CAPACITY_DECISION_DATE_INDEX);
    // 託送契約容量判定日：日付フォーマットチェック
    if (consignmentContractCapacityDecisionDate != null
        && !CommonValidationUtil.checkDateFormat(
            consignmentContractCapacityDecisionDate, "yyyy/MM/dd")) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_CONTRACT_CAPACITY_DECISION_DATE_NAME,
                      "日付形式（yyyy/MM/dd）" },
                  Locale.getDefault()));
    }

    String chargeCheckFlag = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_CHARGE_CHECK_FLAG_INDEX);
    // 料金チェックフラグ：必須チェック
    if (CommonValidationUtil.isNull(chargeCheckFlag)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CHARGE_CHECK_FLAG_NAME },
                  Locale.getDefault()));

      // 料金チェックフラグ：文字種別チェック（半角数字）
    } else if (chargeCheckFlag != null
        && !CommonValidationUtil
            .isNumric(chargeCheckFlag)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CHARGE_CHECK_FLAG_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 料金チェックフラグ：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (chargeCheckFlag != null
        && !CommonValidationUtil
            .isRangeWordByECIS(chargeCheckFlag)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CHARGE_CHECK_FLAG_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 料金チェックフラグ：数値範囲チェック
    } else if (chargeCheckFlag != null
        && !CommonValidationUtil.checkRange(chargeCheckFlag, 0, 1)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_RANGE_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CHARGE_CHECK_FLAG_NAME,
                      "0～1" },
                  Locale.getDefault()));
    }

    String contractInformationNameKana = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_NAME_KANA_INDEX);
    // 連絡先氏名（カナ）：文字列最大長チェック
    if (contractInformationNameKana != null
        && !CommonValidationUtil
            .maxLength(
                contractInformationNameKana,
                Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_NAME_KANA_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_NAME_KANA_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_NAME_KANA_LENGTH_STRING },
                  Locale.getDefault()));

      // 連絡先氏名（カナ）：正規表現チェック
    } else if (contractInformationNameKana != null
        && !CommonValidationUtil.checkByPattern(
            contractInformationNameKana, "^[０-９Ａ-Ｚａ-ｚァ-ヶー（）－　]+$")) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_ITEM_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_NAME_KANA_NAME },
                  Locale.getDefault()));
    }

    String contractInformationName1 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_NAME1_INDEX);
    // 連絡先氏名1：文字種別チェック（全角）
    if (contractInformationName1 != null
        && !CommonValidationUtil
            .isZenkakuType(contractInformationName1)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_NAME1_NAME },
                  Locale.getDefault()));

      // 連絡先氏名1：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (contractInformationName1 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(contractInformationName1)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_NAME1_NAME,
                      "全角（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 連絡先氏名1：文字列最大長チェック
    } else if (contractInformationName1 != null
        && !CommonValidationUtil
            .maxLength(
                contractInformationName1,
                Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_NAME1_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_NAME1_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_NAME1_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String contractInformationName2 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_NAME2_INDEX);
    // 連絡先氏名2：文字種別チェック（全角）
    if (contractInformationName2 != null
        && !CommonValidationUtil
            .isZenkakuType(contractInformationName2)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_NAME2_NAME },
                  Locale.getDefault()));

      // 連絡先氏名2：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (contractInformationName2 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(contractInformationName2)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_NAME2_NAME,
                      "全角（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 連絡先氏名2：文字列最大長チェック
    } else if (contractInformationName2 != null
        && !CommonValidationUtil
            .maxLength(
                contractInformationName2,
                Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_NAME2_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_NAME2_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_NAME2_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String contractInformationAddressPostalCode = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_ADDRESS_POSTAL_CODE_INDEX);
    // 連絡先住所（郵便番号）：文字種別チェック（半角数字）
    if (contractInformationAddressPostalCode != null
        && !CommonValidationUtil
            .isNumric(contractInformationAddressPostalCode)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_ADDRESS_POSTAL_CODE_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 連絡先住所（郵便番号）：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (contractInformationAddressPostalCode != null
        && !CommonValidationUtil
            .isRangeWordByECIS(contractInformationAddressPostalCode)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_ADDRESS_POSTAL_CODE_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 連絡先住所（郵便番号）：文字列指定長チェック
    } else if (StringUtils.isNotEmpty(contractInformationAddressPostalCode)
        && !CommonValidationUtil
            .justLength(
                contractInformationAddressPostalCode,
                Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_ADDRESS_POSTAL_CODE_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_STRINGLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_ADDRESS_POSTAL_CODE_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_ADDRESS_POSTAL_CODE_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String contractInformationAddressFull = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_ADDRESS_FULL_INDEX);
    // 連絡先住所（住所）：文字種別チェック（低圧CISシステム許容文字）
    if (contractInformationAddressFull != null
        && !CommonValidationUtil
            .isRangeWordByECIS(contractInformationAddressFull)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_ADDRESS_FULL_NAME,
                      "低圧CISシステム許容文字" },
                  Locale.getDefault()));
      // 連絡先住所（住所）：文字列最大長チェック
    } else if (contractInformationAddressFull != null
        && !CommonValidationUtil
            .maxLength(
                contractInformationAddressFull,
                Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_ADDRESS_FULL_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_ADDRESS_FULL_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_ADDRESS_FULL_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String contractInformationAddressBuilding = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_ADDRESS_BUILDING_INDEX);
    // 連絡先住所（建物・部屋名）：文字種別チェック（全角）
    if (contractInformationAddressBuilding != null
        && !CommonValidationUtil
            .isZenkakuType(contractInformationAddressBuilding)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_ADDRESS_BUILDING_NAME },
                  Locale.getDefault()));

      // 連絡先住所（建物・部屋名）：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (contractInformationAddressBuilding != null
        && !CommonValidationUtil
            .isRangeWordByECIS(contractInformationAddressBuilding)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_ADDRESS_BUILDING_NAME,
                      "全角（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 連絡先住所（建物・部屋名）：文字列最大長チェック
    } else if (contractInformationAddressBuilding != null
        && !CommonValidationUtil
            .maxLength(
                contractInformationAddressBuilding,
                Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_ADDRESS_BUILDING_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_ADDRESS_BUILDING_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_ADDRESS_BUILDING_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String contractInformationAreaCode = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_AREA_CODE_INDEX);
    // 連絡先電話（市外局番）：文字種別チェック（半角数字）
    if (contractInformationAreaCode != null
        && !CommonValidationUtil.isNumric(contractInformationAreaCode)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_AREA_CODE_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 連絡先電話（市外局番）：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (contractInformationAreaCode != null
        && !CommonValidationUtil
            .isRangeWordByECIS(contractInformationAreaCode)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_AREA_CODE_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 連絡先電話（市外局番）：文字列最大長チェック
    } else if (contractInformationAreaCode != null
        && !CommonValidationUtil
            .maxLength(
                contractInformationAreaCode,
                Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_AREA_CODE_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_AREA_CODE_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_AREA_CODE_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String contractInformationLocalNo = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_LOCAL_NO_INDEX);
    // 連絡先電話（市内局番）：文字種別チェック（半角数字）
    if (contractInformationLocalNo != null
        && !CommonValidationUtil.isNumric(contractInformationLocalNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_LOCAL_NO_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 連絡先電話（市内局番）：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (contractInformationLocalNo != null
        && !CommonValidationUtil
            .isRangeWordByECIS(contractInformationLocalNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_LOCAL_NO_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 連絡先電話（市内局番）：文字列最大長チェック
    } else if (contractInformationLocalNo != null
        && !CommonValidationUtil
            .maxLength(
                contractInformationLocalNo,
                Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_LOCAL_NO_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_LOCAL_NO_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_LOCAL_NO_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String contractInformationDirectoryNo = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_DIRECTORY_NO_INDEX);
    // 連絡先電話（加入者番号）：文字種別チェック（半角数字）
    if (contractInformationDirectoryNo != null
        && !CommonValidationUtil
            .isNumric(contractInformationDirectoryNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_DIRECTORY_NO_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 連絡先電話（加入者番号）：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (contractInformationDirectoryNo != null
        && !CommonValidationUtil
            .isRangeWordByECIS(contractInformationDirectoryNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_DIRECTORY_NO_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 連絡先電話（加入者番号）：文字列最大長チェック
    } else if (contractInformationDirectoryNo != null
        && !CommonValidationUtil
            .maxLength(
                contractInformationDirectoryNo,
                Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_DIRECTORY_NO_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_DIRECTORY_NO_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_DIRECTORY_NO_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String consumerContractAffiliation = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_AFFILIATION_INDEX);
    // 需要者窓口連絡先所属：文字種別チェック（全角）
    if (consumerContractAffiliation != null
        && !CommonValidationUtil
            .isZenkakuType(consumerContractAffiliation)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_AFFILIATION_NAME },
                  Locale.getDefault()));

      // 需要者窓口連絡先所属：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (consumerContractAffiliation != null
        && !CommonValidationUtil
            .isRangeWordByECIS(consumerContractAffiliation)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_AFFILIATION_NAME,
                      "全角（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 需要者窓口連絡先所属：文字列最大長チェック
    } else if (consumerContractAffiliation != null
        && !CommonValidationUtil
            .maxLength(
                consumerContractAffiliation,
                Custom_ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_AFFILIATION_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_AFFILIATION_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_AFFILIATION_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String consumerContractName = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_NAME_INDEX);
    // 需要者窓口連絡先氏名：文字種別チェック（全角）
    if (consumerContractName != null
        && !CommonValidationUtil
            .isZenkakuType(consumerContractName)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_NAME_NAME },
                  Locale.getDefault()));

      // 需要者窓口連絡先氏名：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (consumerContractName != null
        && !CommonValidationUtil
            .isRangeWordByECIS(consumerContractName)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_NAME_NAME,
                      "全角（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 需要者窓口連絡先氏名：文字列最大長チェック
    } else if (consumerContractName != null
        && !CommonValidationUtil
            .maxLength(
                consumerContractName,
                Custom_ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_NAME_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_NAME_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_NAME_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String consumerContractAreaCode = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_AREA_CODE_INDEX);
    // 需要者窓口電話番号（市外局番）：文字種別チェック（半角数字）
    if (consumerContractAreaCode != null
        && !CommonValidationUtil.isNumric(consumerContractAreaCode)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_AREA_CODE_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 需要者窓口電話番号（市外局番）：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (consumerContractAreaCode != null
        && !CommonValidationUtil
            .isRangeWordByECIS(consumerContractAreaCode)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_AREA_CODE_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 需要者窓口電話番号（市外局番）：文字列最大長チェック
    } else if (consumerContractAreaCode != null
        && !CommonValidationUtil
            .maxLength(
                consumerContractAreaCode,
                Custom_ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_AREA_CODE_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_AREA_CODE_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_AREA_CODE_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String consumerContractLocalNo = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_LOCAL_NO_INDEX);
    // 需要者窓口電話番号（市内局番）：文字種別チェック（半角数字）
    if (consumerContractLocalNo != null
        && !CommonValidationUtil.isNumric(consumerContractLocalNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_LOCAL_NO_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 需要者窓口電話番号（市内局番）：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (consumerContractLocalNo != null
        && !CommonValidationUtil
            .isRangeWordByECIS(consumerContractLocalNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_LOCAL_NO_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 需要者窓口電話番号（市内局番）：文字列最大長チェック
    } else if (consumerContractLocalNo != null
        && !CommonValidationUtil
            .maxLength(
                consumerContractLocalNo,
                Custom_ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_LOCAL_NO_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_LOCAL_NO_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_LOCAL_NO_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String consumerContractDirectoryNo = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_DIRECTORY_NO_INDEX);
    // 需要者窓口電話番号（加入者番号）：文字種別チェック（半角数字）
    if (consumerContractDirectoryNo != null
        && !CommonValidationUtil
            .isNumric(consumerContractDirectoryNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_DIRECTORY_NO_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 需要者窓口電話番号（加入者番号）：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (consumerContractDirectoryNo != null
        && !CommonValidationUtil
            .isRangeWordByECIS(consumerContractDirectoryNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_DIRECTORY_NO_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 需要者窓口電話番号（加入者番号）：文字列最大長チェック
    } else if (consumerContractDirectoryNo != null
        && !CommonValidationUtil
            .maxLength(
                consumerContractDirectoryNo,
                Custom_ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_DIRECTORY_NO_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_DIRECTORY_NO_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_DIRECTORY_NO_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String chiefEngineerOfficerAffiliation = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_AFFILIATION_INDEX);
    // 主任技術者連絡先所属：文字種別チェック（全角）
    if (chiefEngineerOfficerAffiliation != null
        && !CommonValidationUtil
            .isZenkakuType(chiefEngineerOfficerAffiliation)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_AFFILIATION_NAME },
                  Locale.getDefault()));

      // 主任技術者連絡先所属：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (chiefEngineerOfficerAffiliation != null
        && !CommonValidationUtil
            .isRangeWordByECIS(chiefEngineerOfficerAffiliation)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_AFFILIATION_NAME,
                      "全角（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 主任技術者連絡先所属：文字列最大長チェック
    } else if (chiefEngineerOfficerAffiliation != null
        && !CommonValidationUtil
            .maxLength(
                chiefEngineerOfficerAffiliation,
                Custom_ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_AFFILIATION_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_AFFILIATION_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_AFFILIATION_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String chiefEngineerOfficerName = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_NAME_INDEX);
    // 主任技術者連絡先氏名：文字種別チェック（全角）
    if (chiefEngineerOfficerName != null
        && !CommonValidationUtil
            .isZenkakuType(chiefEngineerOfficerName)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_NAME_NAME },
                  Locale.getDefault()));

      // 主任技術者連絡先氏名：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (chiefEngineerOfficerName != null
        && !CommonValidationUtil
            .isRangeWordByECIS(chiefEngineerOfficerName)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_NAME_NAME,
                      "全角（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 主任技術者連絡先氏名：文字列最大長チェック
    } else if (chiefEngineerOfficerName != null
        && !CommonValidationUtil
            .maxLength(
                chiefEngineerOfficerName,
                Custom_ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_NAME_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_NAME_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_NAME_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String chiefEngineerOfficerAreaCode = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_AREA_CODE_INDEX);
    // 主任技術者電話番号（市外局番）：文字種別チェック（半角数字）
    if (chiefEngineerOfficerAreaCode != null
        && !CommonValidationUtil.isNumric(chiefEngineerOfficerAreaCode)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_AREA_CODE_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 主任技術者電話番号（市外局番）：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (chiefEngineerOfficerAreaCode != null
        && !CommonValidationUtil
            .isRangeWordByECIS(chiefEngineerOfficerAreaCode)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_AREA_CODE_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 主任技術者電話番号（市外局番）：文字列最大長チェック
    } else if (chiefEngineerOfficerAreaCode != null
        && !CommonValidationUtil
            .maxLength(
                chiefEngineerOfficerAreaCode,
                Custom_ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_AREA_CODE_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_AREA_CODE_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_AREA_CODE_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String chiefEngineerOfficerLocalNo = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_LOCAL_NO_INDEX);
    // 主任技術者電話番号（市内局番）：文字種別チェック（半角数字）
    if (chiefEngineerOfficerLocalNo != null
        && !CommonValidationUtil.isNumric(chiefEngineerOfficerLocalNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_LOCAL_NO_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 主任技術者電話番号（市内局番）：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (chiefEngineerOfficerLocalNo != null
        && !CommonValidationUtil
            .isRangeWordByECIS(chiefEngineerOfficerLocalNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_LOCAL_NO_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 主任技術者電話番号（市内局番）：文字列最大長チェック
    } else if (chiefEngineerOfficerLocalNo != null
        && !CommonValidationUtil
            .maxLength(
                chiefEngineerOfficerLocalNo,
                Custom_ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_LOCAL_NO_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_LOCAL_NO_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_LOCAL_NO_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String chiefEngineerOfficerDirectoryNo = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_DIRECTORY_NO_INDEX);
    // 主任技術者電話番号（加入者番号）：文字種別チェック（半角数字）
    if (chiefEngineerOfficerDirectoryNo != null
        && !CommonValidationUtil
            .isNumric(chiefEngineerOfficerDirectoryNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_DIRECTORY_NO_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 主任技術者電話番号（加入者番号）：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (chiefEngineerOfficerDirectoryNo != null
        && !CommonValidationUtil
            .isRangeWordByECIS(chiefEngineerOfficerDirectoryNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_DIRECTORY_NO_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 主任技術者電話番号（加入者番号）：文字列最大長チェック
    } else if (chiefEngineerOfficerDirectoryNo != null
        && !CommonValidationUtil
            .maxLength(
                chiefEngineerOfficerDirectoryNo,
                Custom_ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_DIRECTORY_NO_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_DIRECTORY_NO_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_DIRECTORY_NO_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String note = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_NOTE_INDEX);
    // 備考：文字種別チェック（低圧CISシステム許容文字）
    if (note != null
        && !CommonValidationUtil
            .isRangeWordByECIS(note)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_NOTE_NAME,
                      "低圧CISシステム許容文字" },
                  Locale.getDefault()));
      // 備考：文字列最大長チェック
    } else if (note != null
        && !CommonValidationUtil
            .maxLength(
                note,
                Custom_ContractManagementInformationFileConfigContract.DATA_NOTE_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_NOTE_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_NOTE_LENGTH_STRING },
                  Locale.getDefault()));
    }

    // 実量歴必須フラグ
    String realQuantityNeed = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_REAL_QUANTITY_NEED_FLAG_INDEX);
    // 実量歴必須フラグ：必須チェック
    if (CommonValidationUtil.isNull(realQuantityNeed)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_REAL_QUANTITY_NEED_FLAG_NAME },
                  Locale.getDefault()));
      // 実量歴必須フラグ：文字種別チェック（半角数字）
    } else if (realQuantityNeed != null
        && !CommonValidationUtil.isNumric(realQuantityNeed)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_REAL_QUANTITY_NEED_FLAG_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 実量歴必須フラグ：文字種別チェック 半角数字（低圧CISシステム許容文字）
    } else if (realQuantityNeed != null
        && !CommonValidationUtil.isRangeWordByECIS(realQuantityNeed)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_REAL_QUANTITY_NEED_FLAG_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));
    }

    String free1 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_FREE1_INDEX);
    // フリー項目1：文字種別チェック（低圧CISシステム許容文字）
    if (free1 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(free1)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_FREE1_NAME,
                      "低圧CISシステム許容文字" },
                  Locale.getDefault()));
      // フリー項目1：文字列最大長チェック
    } else if (free1 != null
        && !CommonValidationUtil
            .maxLength(
                free1,
                Custom_ContractManagementInformationFileConfigContract.DATA_FREE1_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_FREE1_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_FREE1_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String free2 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_FREE2_INDEX);
    // フリー項目2：文字種別チェック（低圧CISシステム許容文字）
    if (free2 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(free2)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_FREE2_NAME,
                      "低圧CISシステム許容文字" },
                  Locale.getDefault()));
      // フリー項目2：文字列最大長チェック
    } else if (free2 != null
        && !CommonValidationUtil
            .maxLength(
                free2,
                Custom_ContractManagementInformationFileConfigContract.DATA_FREE2_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_FREE2_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_FREE2_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String free3 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_FREE3_INDEX);
    // フリー項目3：文字種別チェック（低圧CISシステム許容文字）
    if (free3 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(free3)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_FREE3_NAME,
                      "低圧CISシステム許容文字" },
                  Locale.getDefault()));
      // フリー項目3：文字列最大長チェック
    } else if (free3 != null
        && !CommonValidationUtil
            .maxLength(
                free3,
                Custom_ContractManagementInformationFileConfigContract.DATA_FREE3_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_FREE3_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_FREE3_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String free4 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_FREE4_INDEX);
    // フリー項目4：文字種別チェック（低圧CISシステム許容文字）
    if (free4 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(free4)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_FREE4_NAME,
                      "低圧CISシステム許容文字" },
                  Locale.getDefault()));
      // フリー項目4：文字列最大長チェック
    } else if (free4 != null
        && !CommonValidationUtil
            .maxLength(
                free4,
                Custom_ContractManagementInformationFileConfigContract.DATA_FREE4_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_FREE4_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_FREE4_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String free5 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_FREE5_INDEX);
    // フリー項目5：文字種別チェック（低圧CISシステム許容文字）
    if (free5 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(free5)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_FREE5_NAME,
                      "低圧CISシステム許容文字" },
                  Locale.getDefault()));
      // フリー項目5：文字列最大長チェック
    } else if (free5 != null
        && !CommonValidationUtil
            .maxLength(
                free5,
                Custom_ContractManagementInformationFileConfigContract.DATA_FREE5_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_FREE5_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_FREE5_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String free6 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_FREE6_INDEX);
    // フリー項目6：文字種別チェック（低圧CISシステム許容文字）
    if (free6 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(free6)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_FREE6_NAME,
                      "低圧CISシステム許容文字" },
                  Locale.getDefault()));
      // フリー項目6：文字列最大長チェック
    } else if (free6 != null
        && !CommonValidationUtil
            .maxLength(
                free6,
                Custom_ContractManagementInformationFileConfigContract.DATA_FREE6_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_FREE6_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_FREE6_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String free7 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_FREE7_INDEX);
    // フリー項目7：文字種別チェック（低圧CISシステム許容文字）
    if (free7 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(free7)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_FREE7_NAME,
                      "低圧CISシステム許容文字" },
                  Locale.getDefault()));
      // フリー項目7：文字列最大長チェック
    } else if (free7 != null
        && !CommonValidationUtil
            .maxLength(
                free7,
                Custom_ContractManagementInformationFileConfigContract.DATA_FREE7_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_FREE7_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_FREE7_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String free8 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_FREE8_INDEX);
    // フリー項目8：文字種別チェック（低圧CISシステム許容文字）
    if (free8 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(free8)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_FREE8_NAME,
                      "低圧CISシステム許容文字" },
                  Locale.getDefault()));
      // フリー項目8：文字列最大長チェック
    } else if (free8 != null
        && !CommonValidationUtil
            .maxLength(
                free8,
                Custom_ContractManagementInformationFileConfigContract.DATA_FREE8_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_FREE8_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_FREE8_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String free9 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_FREE9_INDEX);
    // フリー項目9：文字種別チェック（低圧CISシステム許容文字）
    if (free9 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(free9)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_FREE9_NAME,
                      "低圧CISシステム許容文字" },
                  Locale.getDefault()));
      // フリー項目9：文字列最大長チェック
    } else if (free9 != null
        && !CommonValidationUtil
            .maxLength(
                free9,
                Custom_ContractManagementInformationFileConfigContract.DATA_FREE9_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_FREE9_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_FREE9_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String free10 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_FREE10_INDEX);
    // フリー項目10：文字種別チェック（低圧CISシステム許容文字）
    if (free10 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(free10)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_FREE10_NAME,
                      "低圧CISシステム許容文字" },
                  Locale.getDefault()));
      // フリー項目10：文字列最大長チェック
    } else if (free10 != null
        && !CommonValidationUtil
            .maxLength(
                free10,
                Custom_ContractManagementInformationFileConfigContract.DATA_FREE10_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_FREE10_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_FREE10_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String free11 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_FREE11_INDEX);
    // フリー項目11：文字種別チェック（低圧CISシステム許容文字）
    if (free11 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(free11)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_FREE11_NAME,
                      "低圧CISシステム許容文字" },
                  Locale.getDefault()));
      // フリー項目11：文字列最大長チェック
    } else if (free11 != null
        && !CommonValidationUtil
            .maxLength(
                free11,
                Custom_ContractManagementInformationFileConfigContract.DATA_FREE11_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_FREE11_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_FREE11_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String free12 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_FREE12_INDEX);
    // フリー項目12：文字種別チェック（低圧CISシステム許容文字）
    if (free12 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(free12)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_FREE12_NAME,
                      "低圧CISシステム許容文字" },
                  Locale.getDefault()));
      // フリー項目12：文字列最大長チェック
    } else if (free12 != null
        && !CommonValidationUtil
            .maxLength(
                free12,
                Custom_ContractManagementInformationFileConfigContract.DATA_FREE12_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_FREE12_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_FREE12_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String free13 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_FREE13_INDEX);
    // フリー項目13：文字種別チェック（低圧CISシステム許容文字）
    if (free13 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(free13)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_FREE13_NAME,
                      "低圧CISシステム許容文字" },
                  Locale.getDefault()));
      // フリー項目13：文字列最大長チェック
    } else if (free13 != null
        && !CommonValidationUtil
            .maxLength(
                free13,
                Custom_ContractManagementInformationFileConfigContract.DATA_FREE13_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_FREE13_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_FREE13_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String free14 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_FREE14_INDEX);
    // フリー項目14：文字種別チェック（低圧CISシステム許容文字）
    if (free14 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(free14)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_FREE14_NAME,
                      "低圧CISシステム許容文字" },
                  Locale.getDefault()));
      // フリー項目14：文字列最大長チェック
    } else if (free14 != null
        && !CommonValidationUtil
            .maxLength(
                free14,
                Custom_ContractManagementInformationFileConfigContract.DATA_FREE14_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_FREE14_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_FREE14_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String consignmentUseItem1 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_USE_ITEM1_INDEX);
    // 委託先使用項目1：文字種別チェック（低圧CISシステム許容文字）
    if (consignmentUseItem1 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(consignmentUseItem1)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_USE_ITEM1_NAME,
                      "低圧CISシステム許容文字" },
                  Locale.getDefault()));
      // 委託先使用項目1：文字列最大長チェック
    } else if (consignmentUseItem1 != null
        && !CommonValidationUtil
            .maxLength(
                consignmentUseItem1,
                Custom_ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_USE_ITEM1_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_USE_ITEM1_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_USE_ITEM1_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String consignmentUseItem2 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_USE_ITEM2_INDEX);
    // 委託先使用項目2：文字種別チェック（低圧CISシステム許容文字）
    if (consignmentUseItem2 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(consignmentUseItem2)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_USE_ITEM2_NAME,
                      "低圧CISシステム許容文字" },
                  Locale.getDefault()));
      // 委託先使用項目2：文字列最大長チェック
    } else if (consignmentUseItem2 != null
        && !CommonValidationUtil
            .maxLength(
                consignmentUseItem2,
                Custom_ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_USE_ITEM2_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_USE_ITEM2_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_USE_ITEM2_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String consignmentUseItem3 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_USE_ITEM3_INDEX);
    // 委託先使用項目3：文字種別チェック（低圧CISシステム許容文字）
    if (consignmentUseItem3 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(consignmentUseItem3)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_USE_ITEM3_NAME,
                      "低圧CISシステム許容文字" },
                  Locale.getDefault()));
      // 委託先使用項目3：文字列最大長チェック
    } else if (consignmentUseItem3 != null
        && !CommonValidationUtil
            .maxLength(
                consignmentUseItem3,
                Custom_ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_USE_ITEM3_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_USE_ITEM3_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_USE_ITEM3_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String ourManagementPersonInChargeCode = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_OUR_MANAGEMENT_PERSON_IN_CHARGE_CODE_INDEX);
    // 自社担当者コード：文字種別チェック（半角英数字）
    if (ourManagementPersonInChargeCode != null
        && !CommonValidationUtil
            .isAlphabetNumric(ourManagementPersonInChargeCode)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_ALPHANUMERIC_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_OUR_MANAGEMENT_PERSON_IN_CHARGE_CODE_NAME },
                  Locale.getDefault()));

      // 自社担当者コード：文字種別チェック（半角英数字　低圧CISシステム許容文字）
    } else if (ourManagementPersonInChargeCode != null
        && !CommonValidationUtil
            .isRangeWordByECIS(ourManagementPersonInChargeCode)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_OUR_MANAGEMENT_PERSON_IN_CHARGE_CODE_NAME,
                      "半角英数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 自社担当者コード：文字列最大長チェック
    } else if (ourManagementPersonInChargeCode != null
        && !CommonValidationUtil
            .maxLength(
                ourManagementPersonInChargeCode,
                Custom_ContractManagementInformationFileConfigContract.DATA_OUR_MANAGEMENT_PERSON_IN_CHARGE_CODE_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_OUR_MANAGEMENT_PERSON_IN_CHARGE_CODE_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_OUR_MANAGEMENT_PERSON_IN_CHARGE_CODE_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String ourManagementDepartmentCode = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_OUR_MANAGEMENT_DEPARTMENT_CODE_INDEX);
    // 自社部署コード：文字種別チェック（半角英数字）
    if (ourManagementDepartmentCode != null
        && !CommonValidationUtil
            .isAlphabetNumric(ourManagementDepartmentCode)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_ALPHANUMERIC_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_OUR_MANAGEMENT_DEPARTMENT_CODE_NAME },
                  Locale.getDefault()));

      // 自社部署コード：文字種別チェック（半角英数字　低圧CISシステム許容文字）
    } else if (ourManagementDepartmentCode != null
        && !CommonValidationUtil
            .isRangeWordByECIS(ourManagementDepartmentCode)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_OUR_MANAGEMENT_DEPARTMENT_CODE_NAME,
                      "半角英数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 自社部署コード：文字列最大長チェック
    } else if (ourManagementDepartmentCode != null
        && !CommonValidationUtil
            .maxLength(
                ourManagementDepartmentCode,
                Custom_ContractManagementInformationFileConfigContract.DATA_OUR_MANAGEMENT_DEPARTMENT_CODE_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_OUR_MANAGEMENT_DEPARTMENT_CODE_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_OUR_MANAGEMENT_DEPARTMENT_CODE_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String businessTypeCode = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_BUSINESS_TYPE_CODE_INDEX);
    // 業種コード：文字種別チェック（半角英数字）
    if (businessTypeCode != null
        && !CommonValidationUtil.isAlphabetNumric(businessTypeCode)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_ALPHANUMERIC_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_BUSINESS_TYPE_CODE_NAME },
                  Locale.getDefault()));

      // 業種コード：文字種別チェック（半角英数字　低圧CISシステム許容文字）
    } else if (businessTypeCode != null
        && !CommonValidationUtil.isRangeWordByECIS(businessTypeCode)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_BUSINESS_TYPE_CODE_NAME,
                      "半角英数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 業種コード：文字列最大長チェック
    } else if (businessTypeCode != null
        && !CommonValidationUtil
            .maxLength(
                businessTypeCode,
                Custom_ContractManagementInformationFileConfigContract.DATA_BUSINESS_TYPE_CODE_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_BUSINESS_TYPE_CODE_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_BUSINESS_TYPE_CODE_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String salesDepartmentCd = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_SALES_DEPARTMENT_CODE_INDEX);
    // 営業担当者・組織コード：文字種別チェック（半角英数字）
    if (salesDepartmentCd != null
        && !CommonValidationUtil.isAlphabetNumric(salesDepartmentCd)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_ALPHANUMERIC_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_SALES_DEPARTMENT_CODE_NAME },
                  Locale.getDefault()));

      // 営業担当者・組織コード：文字種別チェック（半角英数字　低圧CISシステム許容文字）
    } else if (salesDepartmentCd != null
        && !CommonValidationUtil.isRangeWordByECIS(salesDepartmentCd)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_SALES_DEPARTMENT_CODE_NAME,
                      "半角英数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 営業担当者・組織コード：文字列最大長チェック
    } else if (salesDepartmentCd != null
        && !CommonValidationUtil
            .maxLength(
                salesDepartmentCd,
                Custom_ContractManagementInformationFileConfigContract.DATA_SALES_DEPARTMENT_CODE_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_SALES_DEPARTMENT_CODE_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_SALES_DEPARTMENT_CODE_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String contactCd = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_SALES_CONTACT_CODE_INDEX);
    // 問い合わせ先コード：文字種別チェック（半角英数字）
    if (contactCd != null
        && !CommonValidationUtil.isAlphabetNumric(contactCd)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_ALPHANUMERIC_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_SALES_CONTACT_CODE_NAME },
                  Locale.getDefault()));

      // 問い合わせ先コード：文字種別チェック（半角英数字　低圧CISシステム許容文字）
    } else if (contactCd != null
        && !CommonValidationUtil.isRangeWordByECIS(contactCd)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_SALES_CONTACT_CODE_NAME,
                      "半角英数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 問い合わせ先コード：文字列最大長チェック
    } else if (contactCd != null
        && !CommonValidationUtil
            .maxLength(
                contactCd,
                Custom_ContractManagementInformationFileConfigContract.DATA_SALES_CONTACT_CODE_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_SALES_CONTACT_CODE_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_SALES_CONTACT_CODE_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String rateMenuId = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_RATE_MENU_ID_INDEX);
    // 料金メニューID：必須チェック
    if (CommonValidationUtil.isNull(rateMenuId)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_RATE_MENU_ID_NAME },
                  Locale.getDefault()));
    }

    String contractCapacity = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_CAPACITY_INDEX);
    // 契約容量：数値フォーマットチェック
    if (contractCapacity != null
        && !CommonValidationUtil.checkByPattern(contractCapacity,
            "^(([1-9][0-9]*|0){1}(\\.[0-9]+)?)?$")) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_CAPACITY_NAME,
                      "数値形式（マイナス符号：否、カンマ：否、小数：可）" },
                  Locale.getDefault()));

      // 契約容量：数値桁数チェック
    } else if (contractCapacity != null
        && !CommonValidationUtil
            .checkBigDecimalDigit(
                contractCapacity,
                Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_CAPACITY_DIGIT_INTEGER,
                Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_CAPACITY_DIGIT_FLOAT)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MONEYRANGE,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_CAPACITY_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_CAPACITY_DIGIT_INTEGER_STRING,
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_CAPACITY_DIGIT_FLOAT_STRING },
                  Locale.getDefault()));
    }

    // 電圧区分
    String voltageCatCode = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_VOLTAGE_CAT_CODE_INDEX);
    // 電圧区分：必須チェック
    if (CommonValidationUtil.isNull(voltageCatCode)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_VOLTAGE_CAT_CODE_NAME },
                  Locale.getDefault()));
      // 電圧区分：文字種別チェック（半角英数字ハイフン）
    } else if (voltageCatCode != null
        && !CommonValidationUtil.isAlphabetNumricHyphen(voltageCatCode)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_ALPHANUMERICHYPHEN_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_VOLTAGE_CAT_CODE_NAME },
                  Locale.getDefault()));

      // 電圧区分：文字種別チェック（半角英数字　低圧CISシステム許容文字）
    } else if (voltageCatCode != null
        && !CommonValidationUtil.isRangeWordByECIS(voltageCatCode)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_VOLTAGE_CAT_CODE_NAME,
                      "半角英数字ハイフン（低圧CISシステム許容文字）" },
                  Locale.getDefault()));
    }

    // 契約電力決定区分
    String ccDecisionCategoryCode = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_CCDECISION_CATEGORY_CODE_INDEX);
    // 契約電力決定区分：必須チェック
    if (CommonValidationUtil.isNull(ccDecisionCategoryCode)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CCDECISION_CATEGORY_CODE_NAME },
                  Locale.getDefault()));
      // 契約電力決定区分：文字種別チェック（半角英数字ハイフン）
    } else if (ccDecisionCategoryCode != null
        && !CommonValidationUtil.isAlphabetNumricHyphen(ccDecisionCategoryCode)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_ALPHANUMERICHYPHEN_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CCDECISION_CATEGORY_CODE_NAME },
                  Locale.getDefault()));

      // 契約電力決定区分：文字種別チェック（半角英数字　低圧CISシステム許容文字）
    } else if (ccDecisionCategoryCode != null
        && !CommonValidationUtil.isRangeWordByECIS(ccDecisionCategoryCode)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CCDECISION_CATEGORY_CODE_NAME,
                      "半角英数字ハイフン（低圧CISシステム許容文字）" },
                  Locale.getDefault()));
    }

    // 単価設定区分
    String upCatCode = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_UP_CAT_CODE_INDEX);
    // 単価設定区分：必須チェック
    if (CommonValidationUtil.isNull(upCatCode)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP_CAT_CODE_NAME },
                  Locale.getDefault()));
      // 単価設定区分：文字種別チェック（半角英数字ハイフン）
    } else if (upCatCode != null
        && !CommonValidationUtil.isAlphabetNumricHyphen(upCatCode)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_ALPHANUMERICHYPHEN_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP_CAT_CODE_NAME },
                  Locale.getDefault()));

      // 単価設定区分：文字種別チェック（半角英数字　低圧CISシステム許容文字）
    } else if (upCatCode != null
        && !CommonValidationUtil.isRangeWordByECIS(upCatCode)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP_CAT_CODE_NAME,
                      "半角英数字ハイフン（低圧CISシステム許容文字）" },
                  Locale.getDefault()));
    }

    // 最低月額料金
    String mmc = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_MMC_INDEX);
    // 最低月額料金：数値フォーマットチェック
    if (mmc != null
        && !CommonValidationUtil.checkByPattern(mmc,
            "^(([1-9][0-9]*|0){1}(\\.[0-9]+)?)?$")) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_MMC_NAME,
                      "数値形式（マイナス符号：否、カンマ：否、小数：可）" },
                  Locale.getDefault()));

      // 最低月額料金：数値桁数チェック
    } else if (mmc != null
        && !CommonValidationUtil
            .checkBigDecimalDigit(
                mmc,
                Custom_ContractManagementInformationFileConfigContract.DATA_MMC_INTEGER,
                Custom_ContractManagementInformationFileConfigContract.DATA_MMC_FLOAT)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MONEYRANGE,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_MMC_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_MMCT_INTEGER_STRING,
                      Custom_ContractManagementInformationFileConfigContract.DATA_MMC_FLOAT_STRING },
                  Locale.getDefault()));
    }

    // DCEC区分コード１
    String dcecCatCode1 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE1_INDEX);
    // DCEC区分コード１：文字種別チェック（半角数字）
    if (dcecCatCode1 != null
        && !CommonValidationUtil.isNumric(dcecCatCode1)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE1_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // DCEC区分コード１：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (dcecCatCode1 != null
        && !CommonValidationUtil.isRangeWordByECIS(dcecCatCode1)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE1_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));
    }

    // 時間帯コード１
    String tsCode1 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE1_INDEX);
    // 時間帯コード１：文字種別チェック（半角数字ハイフン）
    if (tsCode1 != null
        && !CommonValidationUtil.isNumric(tsCode1)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE1_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 時間帯コード１：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (tsCode1 != null
        && !CommonValidationUtil.isRangeWordByECIS(tsCode1)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE1_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));
    }

    // 枝番１
    String branchNo1 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO1_INDEX);
    // 枝番１：文字種別チェック（半角英数字ハイフン）
    if (branchNo1 != null
        && !CommonValidationUtil.isNumric(branchNo1)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO1_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 枝番１：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (branchNo1 != null
        && !CommonValidationUtil.isRangeWordByECIS(branchNo1)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO1_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));
    }

    // 単価明細金額１
    String up1 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_UP1_INDEX);
    // 単価明細金額１：数値フォーマットチェック
    if (up1 != null
        && !CommonValidationUtil.checkByPattern(up1,
            "^(([1-9][0-9]*|0){1}(\\.[0-9]+)?)?$")) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP1_NAME,
                      "数値形式（マイナス符号：否、カンマ：否、小数：可）" },
                  Locale.getDefault()));

      // 単価明細金額１：数値桁数チェック
    } else if (up1 != null
        && !CommonValidationUtil
            .checkBigDecimalDigit(
                up1,
                Custom_ContractManagementInformationFileConfigContract.DATA_UP1_INTEGER,
                Custom_ContractManagementInformationFileConfigContract.DATA_UP1_FLOAT)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MONEYRANGE,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP1_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP1_INTEGER_STRING,
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP1_FLOAT_STRING },
                  Locale.getDefault()));
    }

    // DCEC区分コード2
    String dcecCatCode2 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE2_INDEX);
    // DCEC区分コード2：文字種別チェック（半角数字ハイフン）
    if (dcecCatCode2 != null
        && !CommonValidationUtil.isNumric(dcecCatCode2)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE2_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // DCEC区分コード2：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (dcecCatCode2 != null
        && !CommonValidationUtil.isRangeWordByECIS(dcecCatCode2)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE2_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));
    }

    // 時間帯コード2
    String tsCode2 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE2_INDEX);
    // 時間帯コード2：文字種別チェック（半角数字）
    if (tsCode2 != null
        && !CommonValidationUtil.isNumric(tsCode2)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE2_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 時間帯コード2：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (tsCode2 != null
        && !CommonValidationUtil.isRangeWordByECIS(tsCode2)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE2_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));
    }

    // 枝番2
    String branchNo2 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO2_INDEX);
    // 枝番2：文字種別チェック（半角数字）
    if (branchNo2 != null
        && !CommonValidationUtil.isNumric(branchNo2)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO2_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 枝番2：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (branchNo2 != null
        && !CommonValidationUtil.isRangeWordByECIS(branchNo2)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO2_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));
    }

    // 単価明細金額2
    String up2 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_UP2_INDEX);
    // 単価明細金額2：数値フォーマットチェック
    if (up2 != null
        && !CommonValidationUtil.checkByPattern(up2,
            "^(([1-9][0-9]*|0){1}(\\.[0-9]+)?)?$")) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP2_NAME,
                      "数値形式（マイナス符号：否、カンマ：否、小数：可）" },
                  Locale.getDefault()));

      // 単価明細金額2：数値桁数チェック
    } else if (up2 != null
        && !CommonValidationUtil
            .checkBigDecimalDigit(
                up2,
                Custom_ContractManagementInformationFileConfigContract.DATA_UP2_INTEGER,
                Custom_ContractManagementInformationFileConfigContract.DATA_UP2_FLOAT)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MONEYRANGE,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP2_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP2_INTEGER_STRING,
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP2_FLOAT_STRING },
                  Locale.getDefault()));
    }

    // DCEC区分コード3
    String dcecCatCode3 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE3_INDEX);
    // DCEC区分コード3：文字種別チェック（半角数字）
    if (dcecCatCode3 != null
        && !CommonValidationUtil.isNumric(dcecCatCode3)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE3_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // DCEC区分コード3：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (dcecCatCode3 != null
        && !CommonValidationUtil.isRangeWordByECIS(dcecCatCode3)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE3_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));
    }

    // 時間帯コード3
    String tsCode3 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE3_INDEX);
    // 時間帯コード3：文字種別チェック（半角数字）
    if (tsCode3 != null
        && !CommonValidationUtil.isNumric(tsCode3)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE3_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 時間帯コード3：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (tsCode3 != null
        && !CommonValidationUtil.isRangeWordByECIS(tsCode3)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE3_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));
    }

    // 枝番3
    String branchNo3 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO3_INDEX);
    // 枝番3：文字種別チェック（半角数字）
    if (branchNo3 != null
        && !CommonValidationUtil.isNumric(branchNo3)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO3_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 枝番3：文字種別チェック（半角英数字　低圧CISシステム許容文字）
    } else if (branchNo3 != null
        && !CommonValidationUtil.isRangeWordByECIS(branchNo3)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO3_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));
    }

    // 単価明細金額3
    String up3 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_UP3_INDEX);
    // 単価明細金額3：数値フォーマットチェック
    if (up3 != null
        && !CommonValidationUtil.checkByPattern(up3,
            "^(([1-9][0-9]*|0){1}(\\.[0-9]+)?)?$")) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP3_NAME,
                      "数値形式（マイナス符号：否、カンマ：否、小数：可）" },
                  Locale.getDefault()));

      // 単価明細金額3：数値桁数チェック
    } else if (up3 != null
        && !CommonValidationUtil
            .checkBigDecimalDigit(
                up3,
                Custom_ContractManagementInformationFileConfigContract.DATA_UP3_INTEGER,
                Custom_ContractManagementInformationFileConfigContract.DATA_UP3_FLOAT)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MONEYRANGE,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP3_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP3_INTEGER_STRING,
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP3_FLOAT_STRING },
                  Locale.getDefault()));
    }

    // DCEC区分コード4
    String dcecCatCode4 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE4_INDEX);
    // DCEC区分コード4：文字種別チェック（半角数字ハイフン）
    if (dcecCatCode4 != null
        && !CommonValidationUtil.isNumric(dcecCatCode4)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE4_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // DCEC区分コード4：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (dcecCatCode4 != null
        && !CommonValidationUtil.isRangeWordByECIS(dcecCatCode4)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE4_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));
    }

    // 時間帯コード4
    String tsCode4 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE4_INDEX);
    // 時間帯コード4：文字種別チェック（半角数字）
    if (tsCode4 != null
        && !CommonValidationUtil.isNumric(tsCode4)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE4_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 時間帯コード4：文字種別チェック（半角英数字　低圧CISシステム許容文字）
    } else if (tsCode4 != null
        && !CommonValidationUtil.isRangeWordByECIS(tsCode4)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE4_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));
    }

    // 枝番4
    String branchNo4 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO4_INDEX);
    // 枝番4：文字種別チェック（半角数字）
    if (branchNo4 != null
        && !CommonValidationUtil.isNumric(branchNo4)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO4_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 枝番4：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (branchNo4 != null
        && !CommonValidationUtil.isRangeWordByECIS(branchNo4)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO4_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));
    }

    // 単価明細金額4
    String up4 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_UP4_INDEX);
    // 単価明細金額4：数値フォーマットチェック
    if (up4 != null
        && !CommonValidationUtil.checkByPattern(up4,
            "^(([1-9][0-9]*|0){1}(\\.[0-9]+)?)?$")) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP4_NAME,
                      "数値形式（マイナス符号：否、カンマ：否、小数：可）" },
                  Locale.getDefault()));

      // 単価明細金額4：数値桁数チェック
    } else if (up4 != null
        && !CommonValidationUtil
            .checkBigDecimalDigit(
                up4,
                Custom_ContractManagementInformationFileConfigContract.DATA_UP4_INTEGER,
                Custom_ContractManagementInformationFileConfigContract.DATA_UP4_FLOAT)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MONEYRANGE,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP4_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP4_INTEGER_STRING,
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP4_FLOAT_STRING },
                  Locale.getDefault()));
    }

    // DCEC区分コード5
    String dcecCatCode5 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE5_INDEX);
    // DCEC区分コード5：文字種別チェック（半角数字）
    if (dcecCatCode5 != null
        && !CommonValidationUtil.isNumric(dcecCatCode5)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE5_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // DCEC区分コード5：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (dcecCatCode5 != null
        && !CommonValidationUtil.isRangeWordByECIS(dcecCatCode5)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE5_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));
    }

    // 時間帯コード5
    String tsCode5 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE5_INDEX);
    // 時間帯コード5：文字種別チェック（半角数字）
    if (tsCode5 != null
        && !CommonValidationUtil.isNumric(tsCode5)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE5_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 時間帯コード5：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (tsCode5 != null
        && !CommonValidationUtil.isRangeWordByECIS(tsCode5)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE5_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));
    }

    // 枝番5
    String branchNo5 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO5_INDEX);
    // 枝番5：文字種別チェック（半角数字）
    if (branchNo5 != null
        && !CommonValidationUtil.isNumric(branchNo5)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO5_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 枝番5：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (branchNo5 != null
        && !CommonValidationUtil.isRangeWordByECIS(branchNo5)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO5_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));
    }

    // 単価明細金額5
    String up5 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_UP5_INDEX);
    // 単価明細金額5：数値フォーマットチェック
    if (up5 != null
        && !CommonValidationUtil.checkByPattern(up5,
            "^(([1-9][0-9]*|0){1}(\\.[0-9]+)?)?$")) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP5_NAME,
                      "数値形式（マイナス符号：否、カンマ：否、小数：可）" },
                  Locale.getDefault()));

      // 単価明細金額5：数値桁数チェック
    } else if (up5 != null
        && !CommonValidationUtil
            .checkBigDecimalDigit(
                up5,
                Custom_ContractManagementInformationFileConfigContract.DATA_UP5_INTEGER,
                Custom_ContractManagementInformationFileConfigContract.DATA_UP5_FLOAT)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MONEYRANGE,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP5_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP5_INTEGER_STRING,
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP5_FLOAT_STRING },
                  Locale.getDefault()));
    }

    // DCEC区分コード6
    String dcecCatCode6 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE6_INDEX);
    // DCEC区分コード6：文字種別チェック（半角数字）
    if (dcecCatCode6 != null
        && !CommonValidationUtil.isNumric(dcecCatCode6)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE6_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // DCEC区分コード6：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (dcecCatCode6 != null
        && !CommonValidationUtil.isRangeWordByECIS(dcecCatCode6)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE6_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));
    }

    // 時間帯コード6
    String tsCode6 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE6_INDEX);
    // 時間帯コード6：文字種別チェック（半角数字）
    if (tsCode6 != null
        && !CommonValidationUtil.isNumric(tsCode6)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE6_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 時間帯コード6：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (tsCode6 != null
        && !CommonValidationUtil.isRangeWordByECIS(tsCode6)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE6_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));
    }

    // 枝番6
    String branchNo6 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO6_INDEX);
    // 枝番6：文字種別チェック（半角数字）
    if (branchNo6 != null
        && !CommonValidationUtil.isNumric(branchNo6)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO6_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 枝番6：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (branchNo6 != null
        && !CommonValidationUtil.isRangeWordByECIS(branchNo6)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO6_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));
    }

    // 単価明細金額6
    String up6 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_UP6_INDEX);
    // 単価明細金額6：数値フォーマットチェック
    if (up6 != null
        && !CommonValidationUtil.checkByPattern(up6,
            "^(([1-9][0-9]*|0){1}(\\.[0-9]+)?)?$")) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP6_NAME,
                      "数値形式（マイナス符号：否、カンマ：否、小数：可）" },
                  Locale.getDefault()));

      // 単価明細金額6：数値桁数チェック
    } else if (up6 != null
        && !CommonValidationUtil
            .checkBigDecimalDigit(
                up6,
                Custom_ContractManagementInformationFileConfigContract.DATA_UP6_INTEGER,
                Custom_ContractManagementInformationFileConfigContract.DATA_UP6_FLOAT)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MONEYRANGE,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP6_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP6_INTEGER_STRING,
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP6_FLOAT_STRING },
                  Locale.getDefault()));
    }

    // DCEC区分コード7
    String dcecCatCode7 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE7_INDEX);
    // DCEC区分コード7：文字種別チェック（半角数字）
    if (dcecCatCode7 != null
        && !CommonValidationUtil.isNumric(dcecCatCode7)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE7_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // DCEC区分コード7：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (dcecCatCode7 != null
        && !CommonValidationUtil.isRangeWordByECIS(dcecCatCode7)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE7_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));
    }

    // 時間帯コード7
    String tsCode7 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE7_INDEX);
    // 時間帯コード7：文字種別チェック（半角数字）
    if (tsCode7 != null
        && !CommonValidationUtil.isNumric(tsCode7)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE7_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 時間帯コード7：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (tsCode7 != null
        && !CommonValidationUtil.isRangeWordByECIS(tsCode7)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE7_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));
    }

    // 枝番7
    String branchNo7 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO7_INDEX);
    // 枝番7：文字種別チェック（半角数字）
    if (branchNo7 != null
        && !CommonValidationUtil.isNumric(branchNo7)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO7_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 枝番7：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (branchNo7 != null
        && !CommonValidationUtil.isRangeWordByECIS(branchNo7)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO7_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));
    }

    // 単価明細金額7
    String up7 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_UP7_INDEX);
    // 単価明細金額7：数値フォーマットチェック
    if (up7 != null
        && !CommonValidationUtil.checkByPattern(up7,
            "^(([1-9][0-9]*|0){1}(\\.[0-9]+)?)?$")) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP7_NAME,
                      "数値形式（マイナス符号：否、カンマ：否、小数：可）" },
                  Locale.getDefault()));

      // 単価明細金額7：数値桁数チェック
    } else if (up7 != null
        && !CommonValidationUtil
            .checkBigDecimalDigit(
                up7,
                Custom_ContractManagementInformationFileConfigContract.DATA_UP7_INTEGER,
                Custom_ContractManagementInformationFileConfigContract.DATA_UP7_FLOAT)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MONEYRANGE,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP7_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP7_INTEGER_STRING,
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP7_FLOAT_STRING },
                  Locale.getDefault()));
    }

    // DCEC区分コード8
    String dcecCatCode8 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE8_INDEX);
    // DCEC区分コード8：文字種別チェック（半角数字）
    if (dcecCatCode8 != null
        && !CommonValidationUtil.isNumric(dcecCatCode8)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE8_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // DCEC区分コード8：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (dcecCatCode8 != null
        && !CommonValidationUtil.isRangeWordByECIS(dcecCatCode8)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE8_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));
    }

    // 時間帯コード8
    String tsCode8 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE8_INDEX);
    // 時間帯コード8：文字種別チェック（半角数字）
    if (tsCode8 != null
        && !CommonValidationUtil.isNumric(tsCode8)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE8_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 時間帯コード8：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (tsCode8 != null
        && !CommonValidationUtil.isRangeWordByECIS(tsCode8)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE8_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));
    }

    // 枝番8
    String branchNo8 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO8_INDEX);
    // 枝番8：文字種別チェック（半角数字）
    if (branchNo8 != null
        && !CommonValidationUtil.isNumric(branchNo8)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO8_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 枝番8：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (branchNo8 != null
        && !CommonValidationUtil.isRangeWordByECIS(branchNo8)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO8_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));
    }

    // 単価明細金額8
    String up8 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_UP8_INDEX);
    // 単価明細金額8：数値フォーマットチェック
    if (up8 != null
        && !CommonValidationUtil.checkByPattern(up8,
            "^(([1-9][0-9]*|0){1}(\\.[0-9]+)?)?$")) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP8_NAME,
                      "数値形式（マイナス符号：否、カンマ：否、小数：可）" },
                  Locale.getDefault()));

      // 単価明細金額8：数値桁数チェック
    } else if (up8 != null
        && !CommonValidationUtil
            .checkBigDecimalDigit(
                up8,
                Custom_ContractManagementInformationFileConfigContract.DATA_UP8_INTEGER,
                Custom_ContractManagementInformationFileConfigContract.DATA_UP8_FLOAT)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MONEYRANGE,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP8_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP8_INTEGER_STRING,
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP8_FLOAT_STRING },
                  Locale.getDefault()));
    }

    // DCEC区分コード９
    String dcecCatCode9 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE9_INDEX);
    // DCEC区分コード９：文字種別チェック（半角数字）
    if (dcecCatCode9 != null
        && !CommonValidationUtil.isNumric(dcecCatCode9)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE9_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // DCEC区分コード９：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (dcecCatCode9 != null
        && !CommonValidationUtil.isRangeWordByECIS(dcecCatCode9)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE9_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));
    }

    // 時間帯コード９
    String tsCode9 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE9_INDEX);
    // 時間帯コード９：文字種別チェック（半角数字ハイフン）
    if (tsCode9 != null
        && !CommonValidationUtil.isNumric(tsCode9)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE9_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 時間帯コード９：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (tsCode9 != null
        && !CommonValidationUtil.isRangeWordByECIS(tsCode9)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE9_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));
    }

    // 枝番９
    String branchNo9 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO9_INDEX);
    // 枝番９：文字種別チェック（半角英数字ハイフン）
    if (branchNo9 != null
        && !CommonValidationUtil.isNumric(branchNo9)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO9_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 枝番９：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (branchNo9 != null
        && !CommonValidationUtil.isRangeWordByECIS(branchNo9)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO9_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));
    }

    // 単価明細金額９
    String up9 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_UP9_INDEX);
    // 単価明細金額９：数値フォーマットチェック
    if (up9 != null
        && !CommonValidationUtil.checkByPattern(up9,
            "^(([1-9][0-9]*|0){1}(\\.[0-9]+)?)?$")) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP9_NAME,
                      "数値形式（マイナス符号：否、カンマ：否、小数：可）" },
                  Locale.getDefault()));

      // 単価明細金額９：数値桁数チェック
    } else if (up9 != null
        && !CommonValidationUtil
            .checkBigDecimalDigit(
                up9,
                Custom_ContractManagementInformationFileConfigContract.DATA_UP9_INTEGER,
                Custom_ContractManagementInformationFileConfigContract.DATA_UP9_FLOAT)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MONEYRANGE,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP9_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP9_INTEGER_STRING,
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP9_FLOAT_STRING },
                  Locale.getDefault()));
    }

    // DCEC区分コード１０
    String dcecCatCode10 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE10_INDEX);
    // DCEC区分コード１０：文字種別チェック（半角数字）
    if (dcecCatCode10 != null
        && !CommonValidationUtil.isNumric(dcecCatCode10)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE10_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // DCEC区分コード１０：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (dcecCatCode10 != null
        && !CommonValidationUtil.isRangeWordByECIS(dcecCatCode10)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE10_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));
    }

    // 時間帯コード１０
    String tsCode10 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE10_INDEX);
    // 時間帯コード１０：文字種別チェック（半角数字ハイフン）
    if (tsCode10 != null
        && !CommonValidationUtil.isNumric(tsCode10)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE10_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 時間帯コード１０：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (tsCode10 != null
        && !CommonValidationUtil.isRangeWordByECIS(tsCode10)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE10_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));
    }

    // 枝番１０
    String branchNo10 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO10_INDEX);
    // 枝番１０：文字種別チェック（半角英数字ハイフン）
    if (branchNo10 != null
        && !CommonValidationUtil.isNumric(branchNo10)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO10_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 枝番１０：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (branchNo10 != null
        && !CommonValidationUtil.isRangeWordByECIS(branchNo10)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO10_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));
    }

    // 単価明細金額１０
    String up10 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_UP10_INDEX);
    // 単価明細金額１０：数値フォーマットチェック
    if (up10 != null
        && !CommonValidationUtil.checkByPattern(up10,
            "^(([1-9][0-9]*|0){1}(\\.[0-9]+)?)?$")) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP10_NAME,
                      "数値形式（マイナス符号：否、カンマ：否、小数：可）" },
                  Locale.getDefault()));

      // 単価明細金額１０：数値桁数チェック
    } else if (up10 != null
        && !CommonValidationUtil
            .checkBigDecimalDigit(
                up10,
                Custom_ContractManagementInformationFileConfigContract.DATA_UP10_INTEGER,
                Custom_ContractManagementInformationFileConfigContract.DATA_UP10_FLOAT)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MONEYRANGE,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP10_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP10_INTEGER_STRING,
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP10_FLOAT_STRING },
                  Locale.getDefault()));
    }

    // DCEC区分コード１１
    String dcecCatCode11 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE11_INDEX);
    // DCEC区分コード１１：文字種別チェック（半角数字）
    if (dcecCatCode11 != null
        && !CommonValidationUtil.isNumric(dcecCatCode11)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE11_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // DCEC区分コード１１：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (dcecCatCode11 != null
        && !CommonValidationUtil.isRangeWordByECIS(dcecCatCode11)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE11_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));
    }

    // 時間帯コード１１
    String tsCode11 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE11_INDEX);
    // 時間帯コード１１：文字種別チェック（半角数字ハイフン）
    if (tsCode11 != null
        && !CommonValidationUtil.isNumric(tsCode11)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE11_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 時間帯コード１１：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (tsCode11 != null
        && !CommonValidationUtil.isRangeWordByECIS(tsCode11)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE11_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));
    }

    // 枝番１１
    String branchNo11 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO11_INDEX);
    // 枝番１１：文字種別チェック（半角英数字ハイフン）
    if (branchNo11 != null
        && !CommonValidationUtil.isNumric(branchNo11)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO11_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 枝番１１：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (branchNo11 != null
        && !CommonValidationUtil.isRangeWordByECIS(branchNo11)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO11_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));
    }

    // 単価明細金額１１
    String up11 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_UP11_INDEX);
    // 単価明細金額１１：数値フォーマットチェック
    if (up11 != null
        && !CommonValidationUtil.checkByPattern(up11,
            "^(([1-9][0-9]*|0){1}(\\.[0-9]+)?)?$")) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP11_NAME,
                      "数値形式（マイナス符号：否、カンマ：否、小数：可）" },
                  Locale.getDefault()));

      // 単価明細金額１１：数値桁数チェック
    } else if (up11 != null
        && !CommonValidationUtil
            .checkBigDecimalDigit(
                up11,
                Custom_ContractManagementInformationFileConfigContract.DATA_UP11_INTEGER,
                Custom_ContractManagementInformationFileConfigContract.DATA_UP11_FLOAT)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MONEYRANGE,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP11_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP11_INTEGER_STRING,
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP11_FLOAT_STRING },
                  Locale.getDefault()));
    }

    // DCEC区分コード１２
    String dcecCatCode12 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE12_INDEX);
    // DCEC区分コード１２：文字種別チェック（半角数字）
    if (dcecCatCode12 != null
        && !CommonValidationUtil.isNumric(dcecCatCode12)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE12_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // DCEC区分コード１２：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (dcecCatCode12 != null
        && !CommonValidationUtil.isRangeWordByECIS(dcecCatCode12)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE12_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));
    }

    // 時間帯コード１２
    String tsCode12 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE12_INDEX);
    // 時間帯コード１２：文字種別チェック（半角数字ハイフン）
    if (tsCode12 != null
        && !CommonValidationUtil.isNumric(tsCode12)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE12_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 時間帯コード１２：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (tsCode12 != null
        && !CommonValidationUtil.isRangeWordByECIS(tsCode12)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE12_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));
    }

    // 枝番１２
    String branchNo12 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO12_INDEX);
    // 枝番１２：文字種別チェック（半角英数字ハイフン）
    if (branchNo12 != null
        && !CommonValidationUtil.isNumric(branchNo12)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO12_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 枝番１２：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (branchNo12 != null
        && !CommonValidationUtil.isRangeWordByECIS(branchNo12)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO12_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));
    }

    // 単価明細金額１２
    String up12 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_UP12_INDEX);
    // 単価明細金額１２：数値フォーマットチェック
    if (up12 != null
        && !CommonValidationUtil.checkByPattern(up12,
            "^(([1-9][0-9]*|0){1}(\\.[0-9]+)?)?$")) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP12_NAME,
                      "数値形式（マイナス符号：否、カンマ：否、小数：可）" },
                  Locale.getDefault()));

      // 単価明細金額１２：数値桁数チェック
    } else if (up12 != null
        && !CommonValidationUtil
            .checkBigDecimalDigit(
                up12,
                Custom_ContractManagementInformationFileConfigContract.DATA_UP12_INTEGER,
                Custom_ContractManagementInformationFileConfigContract.DATA_UP12_FLOAT)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MONEYRANGE,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP12_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP12_INTEGER_STRING,
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP12_FLOAT_STRING },
                  Locale.getDefault()));
    }

    // DCEC区分コード１３
    String dcecCatCode13 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE13_INDEX);
    // DCEC区分コード１３：文字種別チェック（半角数字）
    if (dcecCatCode13 != null
        && !CommonValidationUtil.isNumric(dcecCatCode13)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE13_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // DCEC区分コード１３：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (dcecCatCode13 != null
        && !CommonValidationUtil.isRangeWordByECIS(dcecCatCode13)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE13_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));
    }

    // 時間帯コード１３
    String tsCode13 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE13_INDEX);
    // 時間帯コード１３：文字種別チェック（半角数字ハイフン）
    if (tsCode13 != null
        && !CommonValidationUtil.isNumric(tsCode13)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE13_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 時間帯コード１３：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (tsCode13 != null
        && !CommonValidationUtil.isRangeWordByECIS(tsCode13)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE13_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));
    }

    // 枝番１３
    String branchNo13 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO13_INDEX);
    // 枝番１３：文字種別チェック（半角英数字ハイフン）
    if (branchNo13 != null
        && !CommonValidationUtil.isNumric(branchNo13)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO13_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 枝番１３：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (branchNo13 != null
        && !CommonValidationUtil.isRangeWordByECIS(branchNo13)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO13_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));
    }

    // 単価明細金額１３
    String up13 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_UP13_INDEX);
    // 単価明細金額１３：数値フォーマットチェック
    if (up13 != null
        && !CommonValidationUtil.checkByPattern(up13,
            "^(([1-9][0-9]*|0){1}(\\.[0-9]+)?)?$")) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP13_NAME,
                      "数値形式（マイナス符号：否、カンマ：否、小数：可）" },
                  Locale.getDefault()));

      // 単価明細金額１３：数値桁数チェック
    } else if (up13 != null
        && !CommonValidationUtil
            .checkBigDecimalDigit(
                up13,
                Custom_ContractManagementInformationFileConfigContract.DATA_UP13_INTEGER,
                Custom_ContractManagementInformationFileConfigContract.DATA_UP13_FLOAT)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MONEYRANGE,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP13_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP13_INTEGER_STRING,
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP13_FLOAT_STRING },
                  Locale.getDefault()));
    }

    // DCEC区分コード１４
    String dcecCatCode14 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE14_INDEX);
    // DCEC区分コード１４：文字種別チェック（半角数字）
    if (dcecCatCode14 != null
        && !CommonValidationUtil.isNumric(dcecCatCode14)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE14_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // DCEC区分コード１４：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (dcecCatCode14 != null
        && !CommonValidationUtil.isRangeWordByECIS(dcecCatCode14)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE14_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));
    }

    // 時間帯コード１４
    String tsCode14 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE14_INDEX);
    // 時間帯コード１４：文字種別チェック（半角数字ハイフン）
    if (tsCode14 != null
        && !CommonValidationUtil.isNumric(tsCode14)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE14_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 時間帯コード１４：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (tsCode14 != null
        && !CommonValidationUtil.isRangeWordByECIS(tsCode14)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE14_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));
    }

    // 枝番１４
    String branchNo14 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO14_INDEX);
    // 枝番１４：文字種別チェック（半角英数字ハイフン）
    if (branchNo14 != null
        && !CommonValidationUtil.isNumric(branchNo14)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO14_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 枝番１４：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (branchNo14 != null
        && !CommonValidationUtil.isRangeWordByECIS(branchNo14)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO14_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));
    }

    // 単価明細金額１４
    String up14 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_UP14_INDEX);
    // 単価明細金額１４：数値フォーマットチェック
    if (up14 != null
        && !CommonValidationUtil.checkByPattern(up14,
            "^(([1-9][0-9]*|0){1}(\\.[0-9]+)?)?$")) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP14_NAME,
                      "数値形式（マイナス符号：否、カンマ：否、小数：可）" },
                  Locale.getDefault()));

      // 単価明細金額１４：数値桁数チェック
    } else if (up14 != null
        && !CommonValidationUtil
            .checkBigDecimalDigit(
                up14,
                Custom_ContractManagementInformationFileConfigContract.DATA_UP14_INTEGER,
                Custom_ContractManagementInformationFileConfigContract.DATA_UP14_FLOAT)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MONEYRANGE,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP14_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP14_INTEGER_STRING,
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP14_FLOAT_STRING },
                  Locale.getDefault()));
    }

    // DCEC区分コード１５
    String dcecCatCode15 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE15_INDEX);
    // DCEC区分コード１５：文字種別チェック（半角数字）
    if (dcecCatCode15 != null
        && !CommonValidationUtil.isNumric(dcecCatCode15)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE15_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // DCEC区分コード１５：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (dcecCatCode15 != null
        && !CommonValidationUtil.isRangeWordByECIS(dcecCatCode15)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE15_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));
    }

    // 時間帯コード１５
    String tsCode15 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE15_INDEX);
    // 時間帯コード１５：文字種別チェック（半角数字ハイフン）
    if (tsCode15 != null
        && !CommonValidationUtil.isNumric(tsCode15)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE15_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 時間帯コード１５：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (tsCode15 != null
        && !CommonValidationUtil.isRangeWordByECIS(tsCode15)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE15_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));
    }

    // 枝番１５
    String branchNo15 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO15_INDEX);
    // 枝番１５：文字種別チェック（半角英数字ハイフン）
    if (branchNo15 != null
        && !CommonValidationUtil.isNumric(branchNo15)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO15_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 枝番１５：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (branchNo15 != null
        && !CommonValidationUtil.isRangeWordByECIS(branchNo15)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO15_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));
    }

    // 単価明細金額１５
    String up15 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_UP15_INDEX);
    // 単価明細金額１５：数値フォーマットチェック
    if (up15 != null
        && !CommonValidationUtil.checkByPattern(up15,
            "^(([1-9][0-9]*|0){1}(\\.[0-9]+)?)?$")) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP15_NAME,
                      "数値形式（マイナス符号：否、カンマ：否、小数：可）" },
                  Locale.getDefault()));

      // 単価明細金額１５：数値桁数チェック
    } else if (up15 != null
        && !CommonValidationUtil
            .checkBigDecimalDigit(
                up15,
                Custom_ContractManagementInformationFileConfigContract.DATA_UP15_INTEGER,
                Custom_ContractManagementInformationFileConfigContract.DATA_UP15_FLOAT)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MONEYRANGE,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP15_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP15_INTEGER_STRING,
                      Custom_ContractManagementInformationFileConfigContract.DATA_UP15_FLOAT_STRING },
                  Locale.getDefault()));
    }

    String agentContractNo = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_AGENT_CONTRACT_NO_INDEX);
    // 卸取次店契約番号：文字種別チェック（半角英数字ハイフン）
    if (agentContractNo != null
        && !CommonValidationUtil.isAlphabetNumricHyphen(agentContractNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_ALPHANUMERICHYPHEN_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_AGENT_CONTRACT_NO_NAME },
                  Locale.getDefault()));

      // 卸取次店契約番号：文字種別チェック（半角英数字　低圧CISシステム許容文字）
    } else if (agentContractNo != null
        && !CommonValidationUtil.isRangeWordByECIS(agentContractNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_AGENT_CONTRACT_NO_NAME,
                      "半角英数字ハイフン（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 卸取次店契約番号：文字列最大長チェック
    } else if (agentContractNo != null
        && !CommonValidationUtil
            .maxLength(
                agentContractNo,
                Custom_ContractManagementInformationFileConfigContract.DATA_AGENT_CONTRACT_NO_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_AGENT_CONTRACT_NO_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_AGENT_CONTRACT_NO_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String addInfoFree01 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_01_INDEX);
    // 契約付加情報フリー項目1：文字種別チェック（低圧CISシステム許容文字）
    if (addInfoFree01 != null
        && !CommonValidationUtil.isRangeWordByECIS(addInfoFree01)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_01_NAME,
                      "低圧CISシステム許容文字" },
                  Locale.getDefault()));

      // 契約付加情報フリー項目1：文字列最大長チェック
    } else if (addInfoFree01 != null
        && !CommonValidationUtil
            .maxLength(
                addInfoFree01,
                Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_01_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_01_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_01_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String addInfoFree02 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_02_INDEX);
    // 契約付加情報フリー項目2：文字種別チェック（低圧CISシステム許容文字）
    if (addInfoFree02 != null
        && !CommonValidationUtil.isRangeWordByECIS(addInfoFree02)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_02_NAME,
                      "低圧CISシステム許容文字" },
                  Locale.getDefault()));

      // 契約付加情報フリー項目2：文字列最大長チェック
    } else if (addInfoFree02 != null
        && !CommonValidationUtil
            .maxLength(
                addInfoFree02,
                Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_02_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_02_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_02_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String addInfoFree03 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_03_INDEX);
    // 契約付加情報フリー項目3：文字種別チェック（低圧CISシステム許容文字）
    if (addInfoFree03 != null
        && !CommonValidationUtil.isRangeWordByECIS(addInfoFree03)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_03_NAME,
                      "低圧CISシステム許容文字" },
                  Locale.getDefault()));

      // 契約付加情報フリー項目3：文字列最大長チェック
    } else if (addInfoFree03 != null
        && !CommonValidationUtil
            .maxLength(
                addInfoFree03,
                Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_03_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_03_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_03_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String addInfoFree04 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_04_INDEX);
    // 契約付加情報フリー項目4：文字種別チェック（低圧CISシステム許容文字）
    if (addInfoFree04 != null
        && !CommonValidationUtil.isRangeWordByECIS(addInfoFree04)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_04_NAME,
                      "低圧CISシステム許容文字" },
                  Locale.getDefault()));

      // 契約付加情報フリー項目4：文字列最大長チェック
    } else if (addInfoFree04 != null
        && !CommonValidationUtil
            .maxLength(
                addInfoFree04,
                Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_04_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_04_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_04_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String addInfoFree05 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_05_INDEX);
    // 契約付加情報フリー項目5：文字種別チェック（低圧CISシステム許容文字）
    if (addInfoFree05 != null
        && !CommonValidationUtil.isRangeWordByECIS(addInfoFree05)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_05_NAME,
                      "低圧CISシステム許容文字" },
                  Locale.getDefault()));

      // 契約付加情報フリー項目5：文字列最大長チェック
    } else if (addInfoFree05 != null
        && !CommonValidationUtil
            .maxLength(
                addInfoFree05,
                Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_05_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_05_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_05_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String addInfoFree06 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_06_INDEX);
    // 契約付加情報フリー項目6：文字種別チェック（低圧CISシステム許容文字）
    if (addInfoFree06 != null
        && !CommonValidationUtil.isRangeWordByECIS(addInfoFree06)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_06_NAME,
                      "低圧CISシステム許容文字" },
                  Locale.getDefault()));

      // 契約付加情報フリー項目6：文字列最大長チェック
    } else if (addInfoFree06 != null
        && !CommonValidationUtil
            .maxLength(
                addInfoFree06,
                Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_06_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_06_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_06_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String addInfoFree07 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_07_INDEX);
    // 契約付加情報フリー項目7：文字種別チェック（低圧CISシステム許容文字）
    if (addInfoFree07 != null
        && !CommonValidationUtil.isRangeWordByECIS(addInfoFree07)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_07_NAME,
                      "低圧CISシステム許容文字" },
                  Locale.getDefault()));

      // 契約付加情報フリー項目7：文字列最大長チェック
    } else if (addInfoFree07 != null
        && !CommonValidationUtil
            .maxLength(
                addInfoFree07,
                Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_07_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_07_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_07_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String addInfoFree08 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_08_INDEX);
    // 契約付加情報フリー項目8：文字種別チェック（低圧CISシステム許容文字）
    if (addInfoFree08 != null
        && !CommonValidationUtil.isRangeWordByECIS(addInfoFree08)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_08_NAME,
                      "低圧CISシステム許容文字" },
                  Locale.getDefault()));

      // 契約付加情報フリー項目8：文字列最大長チェック
    } else if (addInfoFree08 != null
        && !CommonValidationUtil
            .maxLength(
                addInfoFree08,
                Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_08_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_08_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_08_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String addInfoFree09 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_09_INDEX);
    // 契約付加情報フリー項目9：文字種別チェック（低圧CISシステム許容文字）
    if (addInfoFree09 != null
        && !CommonValidationUtil.isRangeWordByECIS(addInfoFree09)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_09_NAME,
                      "低圧CISシステム許容文字" },
                  Locale.getDefault()));

      // 契約付加情報フリー項目9：文字列最大長チェック
    } else if (addInfoFree09 != null
        && !CommonValidationUtil
            .maxLength(
                addInfoFree09,
                Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_09_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_09_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_09_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String addInfoFree10 = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_10_INDEX);
    // 契約付加情報フリー項目10：文字種別チェック（低圧CISシステム許容文字）
    if (addInfoFree10 != null
        && !CommonValidationUtil.isRangeWordByECIS(addInfoFree10)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_10_NAME,
                      "低圧CISシステム許容文字" },
                  Locale.getDefault()));

      // 契約付加情報フリー項目10：文字列最大長チェック
    } else if (addInfoFree10 != null
        && !CommonValidationUtil
            .maxLength(
                addInfoFree10,
                Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_10_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_10_NAME,
                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_10_LENGTH_STRING },
                  Locale.getDefault()));
    }

    // 部分供給区分コードの妥当性チェック
    // 部分供給区分コード取得
    String psInfoCatCode = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_PS_INFO_CODE_INDEX);
    // 電圧区分コード取得
    String volCatCode = dataRecode
        .get(Custom_ContractManagementInformationFileConfigContract.DATA_VOLTAGE_CAT_CODE_INDEX);
    // 電圧区分が低圧：1の場合
    if (ECISCodeConstants.CUSTOM_VOLTAGE_CAT_CODE_LOW_TENSION.equals(volCatCode)) {

      // 部分供給区分コード：文字種別チェック（半角数字）
      if (psInfoCatCode != null
          && !CommonValidationUtil.isNumric(psInfoCatCode)) {
        messageList
            .add(messageSource
                .getMessage(
                    EMSMessageResource.VALIDATION_REGEX_KEY,
                    new String[] {
                        Custom_ContractManagementInformationFileConfigContract.DATA_PS_INFO_CODE_INDEX_NAME,
                        "半角数字" },
                    Locale.getDefault()));

        // 部分供給区分コード：文字列最大長チェック
      } else if (psInfoCatCode != null
          && !CommonValidationUtil
              .maxLength(
                  psInfoCatCode,
                  Custom_ContractManagementInformationFileConfigContract.DATA_PS_INFO_CODE_INDEX_LENGTH)) {
        messageList
            .add(messageSource
                .getMessage(
                    EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                    new String[] {
                        Custom_ContractManagementInformationFileConfigContract.DATA_PS_INFO_CODE_INDEX_NAME,
                        Custom_ContractManagementInformationFileConfigContract.DATA_PS_INFO_CODE_INDEX_STRING },
                    Locale.getDefault()));
      }
    } else {
      // 電圧区分が低圧：1ではない場合（高圧、特高の場合）

      // 部分供給区分コード：必須チェック
      if (CommonValidationUtil.isNull(psInfoCatCode)) {
        messageList
            .add(messageSource
                .getMessage(
                    EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                    new String[] {
                        Custom_ContractManagementInformationFileConfigContract.DATA_PS_INFO_CODE_INDEX_NAME },
                    Locale.getDefault()));

        // 部分供給区分コード：文字種別チェック（半角数字）
      } else if (psInfoCatCode != null
          && !CommonValidationUtil.isNumric(psInfoCatCode)) {
        messageList
            .add(messageSource
                .getMessage(
                    EMSMessageResource.VALIDATION_REGEX_KEY,
                    new String[] {
                        Custom_ContractManagementInformationFileConfigContract.DATA_PS_INFO_CODE_INDEX_NAME,
                        "半角数字" },
                    Locale.getDefault()));

        // 部分供給区分コード：文字列最大長チェック
      } else if (psInfoCatCode != null
          && !CommonValidationUtil
              .maxLength(
                  psInfoCatCode,
                  Custom_ContractManagementInformationFileConfigContract.DATA_PS_INFO_CODE_INDEX_LENGTH)) {
        messageList
            .add(messageSource
                .getMessage(
                    EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                    new String[] {
                        Custom_ContractManagementInformationFileConfigContract.DATA_PS_INFO_CODE_INDEX_NAME,
                        Custom_ContractManagementInformationFileConfigContract.DATA_PS_INFO_CODE_INDEX_STRING },
                    Locale.getDefault()));
      }
    }

    // 予備線契約開始日
    int index = Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_LINE_CONTRACT_START_DATE_INDEX;
    String name = Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_LINE_CONTRACT_START_DATE_NAME;
    String value = dataRecode.get(index);
    if (StringUtils.isNotEmpty(value)) {
      // 日付フォーマットチェック
      if (!CommonValidationUtil.checkDateFormat(value, ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH)) {
        messageList.add(messageSource.getMessage(
            EMSMessageResource.VALIDATION_REGEX_KEY,
            new String[] {name, "日付形式（" + ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH + "）" },
            Locale.getDefault()));
      }
    }

    // 予備線契約終了日
    index = Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_LINE_CONTRACT_END_DATE_INDEX;
    name = Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_LINE_CONTRACT_END_DATE_NAME;
    value = dataRecode.get(index);
    if (StringUtils.isNotEmpty(value)) {
      // 日付フォーマットチェック
      if (!CommonValidationUtil.checkDateFormat(value, ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH)) {
        messageList.add(messageSource.getMessage(
            EMSMessageResource.VALIDATION_REGEX_KEY,
            new String[] {name, "日付形式（" + ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH + "）" },
            Locale.getDefault()));
      }
    }

    // 予備線容量
    index = Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_LINE_CONTRACT_CAPACITY_INDEX;
    name = Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_LINE_CONTRACT_CAPACITY_NAME;
    value = dataRecode.get(index);
    int digInt = Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_LINE_CONTRACT_CAPACITY_DIGIT_INTEGER;
    int digFlt = Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_LINE_CONTRACT_CAPACITY_DIGIT_FLOAT;
    String strDigInt = Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_LINE_CONTRACT_CAPACITY_DIGIT_INTEGER_STRING;
    String strDigFlt = Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_LINE_CONTRACT_CAPACITY_DIGIT_FLOAT_STRING;
    if (StringUtils.isNotEmpty(value)) {
      // 数値フォーマットチェック
      if (!CommonValidationUtil.checkByPattern(value, "^(([1-9][0-9]*|0){1}(\\.[0-9]+)?)?$")) {
        messageList.add(messageSource.getMessage(
            EMSMessageResource.VALIDATION_REGEX_KEY,
            new String[] {name, "数値形式（マイナス符号：否、カンマ：否、小数：可）" },
            Locale.getDefault()));
        // 数値桁数チェック
      } else if (!CommonValidationUtil.checkBigDecimalDigit(value, digInt, digFlt)) {
        messageList
            .add(messageSource
                .getMessage(
                    EMSMessageResource.VALIDATION_MONEYRANGE,
                    new String[] {name, strDigInt, strDigFlt },
                    Locale.getDefault()));
      }
    }

    // 予備電源契約開始日
    index = Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_POWER_CONTRACT_START_DATE_INDEX;
    name = Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_POWER_CONTRACT_START_DATE_NAME;
    value = dataRecode.get(index);
    if (StringUtils.isNotEmpty(value)) {
      // 日付フォーマットチェック
      if (!CommonValidationUtil.checkDateFormat(value, ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH)) {
        messageList.add(messageSource.getMessage(
            EMSMessageResource.VALIDATION_REGEX_KEY,
            new String[] {name, "日付形式（" + ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH + "）" },
            Locale.getDefault()));
      }
    }

    // 予備電源契約終了日
    index = Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_POWER_CONTRACT_END_DATE_INDEX;
    name = Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_POWER_CONTRACT_END_DATE_NAME;
    value = dataRecode.get(index);
    if (StringUtils.isNotEmpty(value)) {
      // 日付フォーマットチェック
      if (!CommonValidationUtil.checkDateFormat(value, ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH)) {
        messageList.add(messageSource.getMessage(
            EMSMessageResource.VALIDATION_REGEX_KEY,
            new String[] {name, "日付形式（" + ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH + "）" },
            Locale.getDefault()));
      }
    }

    // 予備電源容量
    index = Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_POWER_CONTRACT_CAPACITY_INDEX;
    name = Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_POWER_CONTRACT_CAPACITY_NAME;
    value = dataRecode.get(index);
    digInt = Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_POWER_CONTRACT_CAPACITY_DIGIT_INTEGER;
    digFlt = Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_POWER_CONTRACT_CAPACITY_DIGIT_FLOAT;
    strDigInt = Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_POWER_CONTRACT_CAPACITY_DIGIT_INTEGER_STRING;
    strDigFlt = Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_POWER_CONTRACT_CAPACITY_DIGIT_FLOAT_STRING;
    if (StringUtils.isNotEmpty(value)) {
      // 数値フォーマットチェック
      if (!CommonValidationUtil.checkByPattern(value, "^(([1-9][0-9]*|0){1}(\\.[0-9]+)?)?$")) {
        messageList.add(messageSource.getMessage(
            EMSMessageResource.VALIDATION_REGEX_KEY,
            new String[] {name, "数値形式（マイナス符号：否、カンマ：否、小数：可）" },
            Locale.getDefault()));
        // 数値桁数チェック
      } else if (!CommonValidationUtil.checkBigDecimalDigit(value, digInt, digFlt)) {
        messageList
            .add(messageSource
                .getMessage(
                    EMSMessageResource.VALIDATION_MONEYRANGE,
                    new String[] {name, strDigInt, strDigFlt },
                    Locale.getDefault()));
      }
    }

    return messageList;
  }
}