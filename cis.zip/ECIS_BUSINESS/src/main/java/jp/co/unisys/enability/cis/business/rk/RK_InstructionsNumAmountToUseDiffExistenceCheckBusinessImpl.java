package jp.co.unisys.enability.cis.business.rk;

import java.math.BigDecimal;

import jp.co.unisys.enability.cis.business.rk.model.RK_ChargeCalcWarningCheckBusinessBean;
import jp.co.unisys.enability.cis.common.util.constants.ECISCodeConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;

/**
 * BRK0103-03指示数使用量差異有無チェックビジネス
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_InstructionsNumAmountToUseDiffExistenceCheckBusinessImpl implements RK_ChargeCalcWarningCheckBusiness {

  /**
   * 指示数使用量差異有無チェック
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 指示数より算出した使用量と30分値の合計から算出した使用量に差異がないかチェックを行う。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param chargeCalcWarningCheckBean
   *          《料金計算警告チェックビジネスBean》
   * @return 警告コード
   */
  @Override
  public String check(
      RK_ChargeCalcWarningCheckBusinessBean chargeCalcWarningCheckBean) {
    // 部分供給区分コードが0（仕分けなし）以外の場合は当チェックは実施しない
    if (!ECISCodeConstants.PS_INFO_CAT_CODE_NOT_CATEGORIZE.equals(chargeCalcWarningCheckBean.getPsInfoCatCode())) {
      return null;
    }

    // 指示数算出使用量取得
    BigDecimal indicationNoCalclulationUsage = chargeCalcWarningCheckBean
        .getIndicationNoCalculationUsage();
    // 指示数算出使用量がnullではなく、合計使用量と一致しない場合、
    // 又は、指示数使用量差異フラグが"ON"の場合、指示数使用量差異警告
    if ((indicationNoCalclulationUsage != null && indicationNoCalclulationUsage
        .compareTo(chargeCalcWarningCheckBean.getTotalUsage()) != 0)
        || ECISConstants.FLG_ON.equals(chargeCalcWarningCheckBean
            .getFixInUsageDiffFlag())) {
      return ECISRKConstants.WARNING_CLASS_MASTER_INDICATION_NO_USAGE_NOT_EQUAL;
    }

    return null;
  }
}
