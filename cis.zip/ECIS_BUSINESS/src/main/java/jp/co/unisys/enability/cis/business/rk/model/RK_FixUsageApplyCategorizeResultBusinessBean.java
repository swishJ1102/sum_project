package jp.co.unisys.enability.cis.business.rk.model;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * 日割別使用量の仕訳結果を保持するビジネスBean。
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * 確定使用量情報反映ビジネス。
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_FixUsageApplyCategorizeResultBusinessBean {

  /**
   * 日割開始日を保有する。
   */
  private Date dateSlotStartDate;

  /**
   * 日割終了日を保有する。
   */
  private Date dateSlotEndDate;

  /**
   * 仕訳後使用量を保有する。
   */
  private BigDecimal categorizedUsage;

  /**
   * 契約容量を保有する。
   */
  private BigDecimal contractCapacity;

  /**
   * 仕訳結果時間帯リストを保有する。
   */
  private List<RK_FixUsageApplyTimeCategorizeResultBusinessBean> fixUsageApplyTimeCategorizeResultList;

  /**
   * 日割開始日のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 日割開始日を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 日割開始日
   */
  public Date getDateSlotStartDate() {
    return dateSlotStartDate;
  }

  /**
   * 日割開始日のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 日割開始日を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param dateSlotStartDate
   *          日割開始日
   */
  public void setDateSlotStartDate(Date dateSlotStartDate) {
    this.dateSlotStartDate = dateSlotStartDate;
  }

  /**
   * 日割終了日のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 日割終了日を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 日割終了日
   */
  public Date getDateSlotEndDate() {
    return dateSlotEndDate;
  }

  /**
   * 日割終了日のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 日割終了日を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param dateSlotEndDate
   *          日割終了日
   */
  public void setDateSlotEndDate(Date dateSlotEndDate) {
    this.dateSlotEndDate = dateSlotEndDate;
  }

  /**
   * 仕訳後使用量のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 仕訳後使用量を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 仕訳後使用量
   */
  public BigDecimal getCategorizedUsage() {
    return this.categorizedUsage;
  }

  /**
   * 仕訳後使用量のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 仕訳後使用量を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param categorizedUsage
   *          仕訳後使用量
   */
  public void setCategorizedUsage(BigDecimal categorizedUsage) {
    this.categorizedUsage = categorizedUsage;
  }

  /**
   * 契約容量のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約容量を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約容量
   */
  public BigDecimal getContractCapacity() {
    return contractCapacity;
  }

  /**
   * 契約容量のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約容量を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractCapacity
   *          契約容量
   */
  public void setContractCapacity(BigDecimal contractCapacity) {
    this.contractCapacity = contractCapacity;
  }

  /**
   * 仕訳結果時間帯リストのgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 仕訳結果時間帯リストを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 仕訳結果時間帯リスト
   */
  public List<RK_FixUsageApplyTimeCategorizeResultBusinessBean> getFixUsageApplyTimeCategorizeResultList() {
    return fixUsageApplyTimeCategorizeResultList;
  }

  /**
   * 仕訳結果時間帯リストのsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 仕訳結果時間帯リストを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param fixUsageApplyTimeCategorizeResultList
   *          仕訳結果時間帯リスト
   */
  public void setFixUsageApplyTimeCategorizeResultList(
      List<RK_FixUsageApplyTimeCategorizeResultBusinessBean> fixUsageApplyTimeCategorizeResultList) {
    this.fixUsageApplyTimeCategorizeResultList = fixUsageApplyTimeCategorizeResultList;
  }

}
