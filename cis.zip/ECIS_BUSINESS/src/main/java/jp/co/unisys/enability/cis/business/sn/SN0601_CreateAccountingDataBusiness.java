package jp.co.unisys.enability.cis.business.sn;

import java.util.Date;

import jp.co.unisys.enability.cis.business.sn.model.SN0601_AccountingDataFileNameBusinessBean;

/**
 * 請求入金共通経理データ作成ビジネスインターフェース。
 *
 * @author "Nihon Unisys, Ltd."
 */
public interface SN0601_CreateAccountingDataBusiness {

  /**
   * 経理データファイル名取得。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数.対象終了日が設定されていない場合、【業務日程管理マスタ】より、対象終了日を取得する。
   * 引数を基に外部ファイルより出力ディレクトリ、ファイル論理名、ファイル物理名を取得し、
   * 対象ファイルのファイルパス、論理ファイル名を編集する。
   * 編集したファイルパスと論理ファイル名を返却する。
   *
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param accountingDataOutputDirKey
   *          経理データ出力ディレクトリ取得キー
   * @param accountingDataFileLogicalNameKey
   *          経理データ論理ファイル名取得キー
   * @param accountingDataFilePhysicalNameKey
   *          経理データ物理ファイル名取得キー
   * @param bacthBaseDate
   *          バッチ処理基準日
   * @param coveredEndDate
   *          対象終了日
   * @return 経理データファイル名ビジネスBean
   */
  public SN0601_AccountingDataFileNameBusinessBean getAccountingDataFileName(String accountingDataOutputDirKey,
      String accountingDataFileLogicalNameKey, String accountingDataFilePhysicalNameKey, Date bacthBaseDate,
      Date coveredEndDate);

}
