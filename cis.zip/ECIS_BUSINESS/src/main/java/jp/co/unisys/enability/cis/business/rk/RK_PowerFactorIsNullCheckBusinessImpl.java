package jp.co.unisys.enability.cis.business.rk;

import java.util.ArrayList;
import java.util.List;

import jp.co.unisys.enability.cis.business.rk.model.RK_ChargeCalcWarningCheckBusinessBean;
import jp.co.unisys.enability.cis.common.util.constants.ECISCodeConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;
import jp.co.unisys.enability.cis.dao.rk.RK_ChargeCalcWarningCheckDao;
import jp.co.unisys.enability.cis.entity.common.CalculatingUsage;
import jp.co.unisys.enability.cis.entity.common.CclM;
import jp.co.unisys.enability.cis.entity.common.CclMExample;
import jp.co.unisys.enability.cis.entity.common.Rm;
import jp.co.unisys.enability.cis.mapper.common.CclMMapper;

/**
 * BRK0103-03力率NULLチェックチェックビジネス
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.mapper.common.CclMMapper
 * @see jp.co.unisys.enability.cis.dao.rk.RK_ChargeCalcWarningCheckDao
 */
public class RK_PowerFactorIsNullCheckBusinessImpl implements RK_ChargeCalcWarningCheckBusiness {

  /**
   * 契約種別マスタMapper(DI)
   */
  private CclMMapper cclMMaper;

  /**
   * 料金計算警告共通DAO(DI)
   */
  private RK_ChargeCalcWarningCheckDao rkChargeCalcWarningCheckDao;

  /**
   * 力率NULLチェック
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約種別コードと力率により力率NULLチェックを行う。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param chargeCalcWarningCheckBean
   *          《料金計算警告チェックビジネスBean》
   * @return 警告コード
   * @see jp.co.unisys.enability.cis.mapper.common.CclMMapper
   * @see jp.co.unisys.enability.cis.dao.rk.RK_ChargeCalcWarningCheckDao
   */
  @Override
  public String check(RK_ChargeCalcWarningCheckBusinessBean chargeCalcWarningCheckBean) {
    // 変数設定
    Integer contractId = chargeCalcWarningCheckBean.getContractId();
    String usePeriod = chargeCalcWarningCheckBean.getUsePeriod();

    // 契約種別情報取得
    // 契約種別が格納された料金メニューマスタを取得する
    Rm rm = chargeCalcWarningCheckBean.getRm();
    if (rm == null) {
      rm = rkChargeCalcWarningCheckDao.selectContractClassInfo(contractId, usePeriod);
    }

    CalculatingUsage calcUsage = chargeCalcWarningCheckBean.getCalculatingUsage();
    if (calcUsage == null) {
      // 力率情報取得
      // 力率が設定された計算用使用量を取得する
      calcUsage = rkChargeCalcWarningCheckDao.selectPowerFactorInfo(contractId, usePeriod);
    }

    // 契約種別マスタリスト取得
    // 電灯電力区分コードが電力の一覧を取得する
    CclMExample cclMExample = new CclMExample();
    cclMExample.createCriteria().andElLightAndPowerCatCodeEqualTo(
        ECISCodeConstants.ELECTRIC_LIGHT_AND_POWER_CATEGORY_CODE_POWER);

    List<CclM> cclMList = cclMMaper.selectByExample(cclMExample);

    // 電圧区分コード
    String voltageCatCode = null;
    // 契約種別コードリストに変換する
    List<String> cclCodeList = new ArrayList<String>(cclMList.size());
    for (CclM cclM : cclMList) {
      cclCodeList.add(cclM.getCclCode());

      // 電圧区分コードを取得する。
      if (rm.getCclCode().equals(cclM.getCclCode())) {
        voltageCatCode = cclM.getVoltageCatCode();
      }
    }

    // 力率NULLチェック
    // 契約種別が低圧電力で、かつ電圧区分コード ＜＞ "低圧"かつ力率がNULLの場合、力率未設定警告を返却する
    if (cclCodeList.contains(rm.getCclCode())
        && !ECISCodeConstants.CUSTOM_VOLTAGE_CAT_CODE_LOW_TENSION.equals(voltageCatCode)
        && calcUsage.getPowerFactor() == null) {
      return ECISRKConstants.WARNING_CLASS_MASTER_POWER_FACTOR_NOT_SETTING;
    }

    return null;
  }

  /**
   * 契約種別マスタMapperのsetter（DI）
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約種別マスタMapperを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param cclMMaper
   *          契約種別マスタMapper
   */
  public void setCclMMaper(CclMMapper cclMMaper) {
    this.cclMMaper = cclMMaper;
  }

  /**
   * 料金計算警告共通DAOのsetter（DI）
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金計算警告共通DAOを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param rkChargeCalcWarningCheckDao
   *          料金計算警告共通DAO
   */
  public void setRkChargeCalcWarningCheckDao(RK_ChargeCalcWarningCheckDao rkChargeCalcWarningCheckDao) {
    this.rkChargeCalcWarningCheckDao = rkChargeCalcWarningCheckDao;
  }
}
