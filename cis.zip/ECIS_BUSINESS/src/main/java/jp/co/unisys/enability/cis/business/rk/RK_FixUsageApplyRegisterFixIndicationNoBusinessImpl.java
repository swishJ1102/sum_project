package jp.co.unisys.enability.cis.business.rk;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.springframework.beans.factory.config.PropertiesFactoryBean;
import org.springframework.context.MessageSource;

import jp.co.unisys.enability.cis.business.common.TodoBusiness;
import jp.co.unisys.enability.cis.business.common.model.TodoBusinessBean;
import jp.co.unisys.enability.cis.business.rk.model.RK_FixUsageApplyDataBusinessBean;
import jp.co.unisys.enability.cis.common.util.RK_PropertyUtil;
import jp.co.unisys.enability.cis.common.util.ThreadContext;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISTodoConstants;
import jp.co.unisys.enability.cis.entity.common.FixIn;
import jp.co.unisys.enability.cis.entity.common.InResult;
import jp.co.unisys.enability.cis.entity.common.InResultExample;
import jp.co.unisys.enability.cis.entity.common.Ml;
import jp.co.unisys.enability.cis.entity.common.MlExample;
import jp.co.unisys.enability.cis.mapper.common.FixInMapper;
import jp.co.unisys.enability.cis.mapper.common.InResultMapper;
import jp.co.unisys.enability.cis.mapper.common.MlMapper;

/**
 * 確定指示数登録ビジネスクラス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_FixUsageApplyRegisterFixIndicationNoBusinessImpl implements
    RK_FixUsageApplyRegisterFixIndicationNoBusiness {

  /** 確定使用量共通ビジネス(DI) */
  private RK_FixUsageCommonBusiness rkFixUsageCommonBusiness;

  /** 指示数実績Mapper(DI) */
  private InResultMapper inResultMapper;

  /** 確定指示数Mapper(DI) */
  private FixInMapper fixInMapper;

  /** メータ設置場所Mapper(DI) */
  private MlMapper mlMapper;

  /** TODOビジネス(DI) */
  private TodoBusiness todoBusiness;

  /** メッセージリソース(DI) */
  private MessageSource messageSource;

  /** プロパティ定義クラス(DI) */
  private PropertiesFactoryBean applicationProperties;

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.rk.
   * RK_FixUsageApplyRegisterFixIndicationNoBusiness
   * #register(jp.co.unisys.enability
   * .cis.business.rk.model.RK_FixUsageApplyDataBusinessBean)
   */
  @Override
  public void register(RK_FixUsageApplyDataBusinessBean applyDataBusinessBean) {

    // 更新用のシステム日付・モジュールコードを取得
    Timestamp timestamp = new Timestamp(new Date().getTime());
    String moduleCode = (String) ThreadContext.getRequestThreadContext()
        .get(ECISConstants.CLASS_NAME_KEY);

    // 指示数実績Example
    InResultExample inResultExample = new InResultExample();

    // 【指示数実績】の取得条件を設定
    inResultExample
        .createCriteria()
        // 地点特定番号
        .andSpotNoEqualTo(applyDataBusinessBean.getSpotNo())
        // 確定使用量ファイル名
        .andFuFileNameEqualTo(
            applyDataBusinessBean.getFixUsageFileName())
        // エリアコード
        .andAreaCodeEqualTo(applyDataBusinessBean.getAreaCode())
        // 計器区分コード：全量
        .andMeterCatCodeEqualTo(
            ECISRKConstants.METER_CATEGORY_CODE_FOR_IN_COMMON);

    // 【指示数実績】を取得
    List<InResult> indicationNoResultList = inResultMapper
        .selectByExample(inResultExample);

    // 計器識別番号
    String meterIdentificationNo = null;

    // 確定指示数Entity
    FixIn fixIn = new FixIn();

    // 指示数実績の要素数を取得
    int indicationNoResulCount = indicationNoResultList.size();

    // 指示数実績の最初の要素を取得
    InResult firstIndicationNoResult = indicationNoResultList.get(0);

    // 全日指示数不正フラグ
    boolean invalidIndicationNo = false;

    // プロパティ.全日電力量指示数算出使用量登録値を取得
    String calculationUsageRegistration = RK_PropertyUtil.getProperty(applicationProperties,
        "calculation.usage.registration");

    // 変数定義
    BigDecimal calcUsage = null;

    // 当月全日指示数01及び、前月全日指示数01以外に指示数が設定されているかチェック
    for (InResult indicationNoResult : indicationNoResultList) {
      if (indicationNoResult.getCurrentIn02() != null
          || indicationNoResult.getCurrentIn03() != null
          || indicationNoResult.getCurrentIn04() != null
          || indicationNoResult.getCurrentIn05() != null
          || indicationNoResult.getCurrentIn06() != null
          || indicationNoResult.getCurrentIn07() != null
          || indicationNoResult.getCurrentIn08() != null
          || indicationNoResult.getCurrentIn09() != null
          || indicationNoResult.getCurrentIn10() != null
          || indicationNoResult.getPreviousIn02() != null
          || indicationNoResult.getPreviousIn03() != null
          || indicationNoResult.getPreviousIn04() != null
          || indicationNoResult.getPreviousIn05() != null
          || indicationNoResult.getPreviousIn06() != null
          || indicationNoResult.getPreviousIn07() != null
          || indicationNoResult.getPreviousIn08() != null
          || indicationNoResult.getPreviousIn09() != null
          || indicationNoResult.getPreviousIn10() != null) {

        // 全日指示数が不正
        invalidIndicationNo = true;

        // 繰り返し処理を終了する
        break;
      }
    }

    if (indicationNoResulCount == 1
        && firstIndicationNoResult.getCurrentIn01() != null
        && firstIndicationNoResult.getPreviousIn01() != null
        && !invalidIndicationNo) {
      // 指示数実績が1件かつ、前月指示数01と当月指示数01がnullでなく、全日指示数が不正でない場合

      // 指示数差の計算
      // 全日電力量指示数差
      BigDecimal diff = calcDiffIn(
          firstIndicationNoResult.getCurrentIn01(),
          firstIndicationNoResult.getPreviousIn01(),
          applyDataBusinessBean.getUsePeriod(),
          applyDataBusinessBean.getContractNo(),
          applyDataBusinessBean.getSpotNo());
      // 力測有効電力量指示数差
      BigDecimal ediff = calcDiffIn(
          firstIndicationNoResult.getEffectiveCurrentIn(),
          firstIndicationNoResult.getEffectivePreviousIn(),
          applyDataBusinessBean.getUsePeriod(),
          applyDataBusinessBean.getContractNo(),
          applyDataBusinessBean.getSpotNo());
      // 力測無効電力量指示数差
      BigDecimal rdiff = calcDiffIn(
          firstIndicationNoResult.getReactiveCurrentIn(),
          firstIndicationNoResult.getReactivePreviousIn(),
          applyDataBusinessBean.getUsePeriod(),
          applyDataBusinessBean.getContractNo(),
          applyDataBusinessBean.getSpotNo());

      // 乗率がnullの場合は乗率を1に設定する
      if (firstIndicationNoResult.getMultiplyingFactor() == null) {

        firstIndicationNoResult
            .setMultiplyingFactor(ECISRKConstants.MULTIPLYING_FACTOR_NO_CT);
      }

      // 損失補正率の計算
      // 電力量損失補正率
      BigDecimal correctionRate = BigDecimal.ZERO;

      // 電力量損失補正率がnullの場合は1を設定する
      if (firstIndicationNoResult.getKwhDisadvantageFactor() == null) {
        correctionRate = BigDecimal.ONE;
      } else {
        // 電力量損失補正率がnullでない場合は電力量損失補正率 / 100 + 1 を設定する
        correctionRate = firstIndicationNoResult.getKwhDisadvantageFactor()
            .divide(new BigDecimal("100")).add(BigDecimal.ONE);
      }

      // 機能制御用プロパティの全日電力量指示数算出使用量登録値が"1"(合計使用量)の場合
      if (ECISRKConstants.CALCULATION_USAGE_REGISTRATION_TOTAL_1.equals(calculationUsageRegistration)) {
        // 全日電力量指示数算出使用量に使用量全量を設定する
        calcUsage = applyDataBusinessBean.getUsageQuantity();
      } else {
        // 全日電力量指示数差に乗率、電力量損失補正率を乗じることで、全日電力量指示数算出使用量を取得する
        calcUsage = diff.multiply(new BigDecimal(String
            .valueOf(firstIndicationNoResult.getMultiplyingFactor()))
                .multiply(correctionRate));

        // 全日電力量指示数算出使用量の丸め（小数部第１位を四捨五入）
        calcUsage = rkFixUsageCommonBusiness.roundUsage(calcUsage);
      }

      // 力測有効電力量指示数差に乗率、電力量損失補正率を乗じることで、力測有効電力量指示数算出使用量を取得する
      BigDecimal eCalcUsage = ediff.multiply(new BigDecimal(String
          .valueOf(firstIndicationNoResult.getMultiplyingFactor()))
              .multiply(correctionRate));

      // 力測有効電力量指示数算出使用量の丸め（小数部第１位を四捨五入）
      eCalcUsage = rkFixUsageCommonBusiness.roundUsage(eCalcUsage);

      // 力測無効電力量指示数差に乗率、電力量損失補正率を乗じることで、力測無効電力量指示数算出使用量を取得する
      BigDecimal rCalcUsage = rdiff.multiply(new BigDecimal(String
          .valueOf(firstIndicationNoResult.getMultiplyingFactor()))
              .multiply(correctionRate));

      // 力測無効電力量指示数算出使用量の丸め（小数部第１位を四捨五入）
      rCalcUsage = rkFixUsageCommonBusiness.roundUsage(rCalcUsage);

      // 【確定指示数】に登録する値を設定
      // 確定使用量ID
      fixIn.setFuId(applyDataBusinessBean.getFixUsageId());
      // 計器区分コード
      fixIn.setMeterCatCode(ECISRKConstants.METER_CATEGORY_CODE_FOR_IN_COMMON);
      // 全日電力量当月指示数
      fixIn.setFtuCurrentIn(firstIndicationNoResult.getCurrentIn01());
      // 全日電力量前月指示数
      fixIn.setFtuPreviousIn(firstIndicationNoResult.getPreviousIn01());
      // 全日電力量指示数差
      fixIn.setInDifference(diff);
      // 乗率
      fixIn.setMultiplyingFactor(firstIndicationNoResult
          .getMultiplyingFactor());
      // 損失補正率
      fixIn.setKwhDisadvantageFactor(correctionRate);
      // 全日電力量指示数算出使用量
      fixIn.setInCalculationUsage(calcUsage);
      // 力測有効電力量当月指示数
      fixIn.setEffectiveCurrentIndicationNo(firstIndicationNoResult
          .getEffectiveCurrentIn());
      // 力測有効電力量前月指示数
      fixIn.setEffectivePreviousIndicationNo(firstIndicationNoResult
          .getEffectivePreviousIn());
      // 力測有効電力量指示数差
      fixIn.setEffectiveIndicationNoDifference(ediff);
      // 力測有効電力量指示数算出使用量
      fixIn.setEffectiveIndicationNoCalculationUsage(eCalcUsage);
      // 力測無効電力量当月指示数
      fixIn.setReactiveCurrentIndicationNo(firstIndicationNoResult
          .getReactiveCurrentIn());
      // 力測無効電力量前月指示数
      fixIn.setReactivePreviousIndicationNo(firstIndicationNoResult
          .getReactivePreviousIn());
      // 力測無効電力量指示数差
      fixIn.setReactiveIndicationNoDifference(rdiff);
      // 力測無効電力量指示数算出使用量
      fixIn.setReactiveIndicationNoCalculationUsage(rCalcUsage);
      // 計器交換フラグ
      fixIn.setMeterReplacementFlag(ECISConstants.FLG_OFF);
      // 計器識別番号
      fixIn.setMeterIdn(firstIndicationNoResult.getMeterIdn());
      // 指示数使用量差異フラグ
      fixIn.setFixInUsageDiffFlag(ECISConstants.FLG_OFF);
      // 更新回数
      fixIn.setUpdateCount(0);
      // 作成日時
      fixIn.setCreateTime(timestamp);
      // 更新日時
      fixIn.setUpdateTime(timestamp);
      // 更新モジュールコード
      fixIn.setUpdateModuleCode(moduleCode);

      // 【確定指示数】登録
      fixInMapper.insert(fixIn);

      // 登録した計器識別番号を変数に保持
      meterIdentificationNo = firstIndicationNoResult.getMeterIdn();
    } else {
      // 【指示数実績】が2件以上存在するか、前月指示数01と当月指示数01のいずれかがnullか、全日指示数不正の場合

      // 指示数使用量差異フラグ
      String fixInUsageDiffFlag = ECISConstants.FLG_OFF;

      if (indicationNoResulCount == 1) {
        // 【指示数実績】が1件の場合

        // 計器識別番号を変数に保持
        meterIdentificationNo = firstIndicationNoResult.getMeterIdn();

        // 指示数使用量差異の警告を登録する必要があるか判定
        if (!invalidIndicationNo
            && (firstIndicationNoResult.getCurrentIn01() == null || firstIndicationNoResult
                .getPreviousIn01() == null)) {
          // 指示数使用量差異フラグを"ON"に設定
          fixInUsageDiffFlag = ECISConstants.FLG_ON;
        }
      } else if (indicationNoResulCount == 2) {
        // 【指示数実績】が2件の場合には、交換後の計器識別番号を判別する
        // 3件以上存在する場合は判別不可

        // 1件目と2件目の指示数実績を取得
        InResult indicationNoResult1, indicationNoResult2;
        indicationNoResult1 = indicationNoResultList.get(0);
        indicationNoResult2 = indicationNoResultList.get(1);

        // 2件の【指示数実績】のどちらか一方が、現在の計器識別番号と同じ計器識別番号を持つ場合、
        // もう一方の【指示数実績】の計器識別番号を交換後の計器識別番号と判断する。
        if (applyDataBusinessBean.getMeterIdentificationNo1().equals(
            indicationNoResult1.getMeterIdn())) {
          meterIdentificationNo = indicationNoResult2.getMeterIdn();

        } else if (applyDataBusinessBean.getMeterIdentificationNo1()
            .equals(indicationNoResult2.getMeterIdn())) {
          meterIdentificationNo = indicationNoResult1.getMeterIdn();
        }

        // プロパティ.計量器交換情報反映フラグを取得
        String exchangeFlg = RK_PropertyUtil.getProperty(applicationProperties, "meter.change.reflect");

        // 機能制御用プロパティの計量器交換情報反映フラグが"1"(有効)の場合
        // 複数計器情報から指示数値の登録を行なう。
        if (ECISRKConstants.METER_CHANGE_REFLECT_EFFECTIVE_1.equals(exchangeFlg)) {

          // 【指示数実績】の1件目に、全日電力量当月指示数が設定されている場合、
          // 且つ【指示数実績】の2件目に、全日電力量前月指示数が設定されている場合
          if (indicationNoResult1.getCurrentIn01() != null
              && indicationNoResult2.getPreviousIn01() != null) {
            // 1件目に当月指示数が設定されている前提
            // 全日電力量当月指示数
            fixIn.setFtuCurrentIn(indicationNoResult1.getCurrentIn01());
            // 全日電力量前月指示数
            fixIn.setFtuPreviousIn(indicationNoResult2.getPreviousIn01());
            // 力測有効電力量当月指示数
            fixIn.setEffectiveCurrentIndicationNo(indicationNoResult1.getEffectiveCurrentIn());
            // 力測有効電力量前月指示数
            fixIn.setEffectivePreviousIndicationNo(indicationNoResult2.getEffectivePreviousIn());
            // 力測無効電力量当月指示数
            fixIn.setReactiveCurrentIndicationNo(indicationNoResult1.getReactiveCurrentIn());
            // 力測無効電力量前月指示数
            fixIn.setReactivePreviousIndicationNo(indicationNoResult2.getReactivePreviousIn());

          } else {
            // 上記以外の場合は、2件目に当月指示数が設定されている前提
            // 全日電力量当月指示数
            fixIn.setFtuCurrentIn(indicationNoResult2.getCurrentIn01());
            // 全日電力量前月指示数
            fixIn.setFtuPreviousIn(indicationNoResult1.getPreviousIn01());
            // 力測有効電力量当月指示数
            fixIn.setEffectiveCurrentIndicationNo(indicationNoResult2.getEffectiveCurrentIn());
            // 力測有効電力量前月指示数
            fixIn.setEffectivePreviousIndicationNo(indicationNoResult1.getEffectivePreviousIn());
            // 力測無効電力量当月指示数
            fixIn.setReactiveCurrentIndicationNo(indicationNoResult2.getReactiveCurrentIn());
            // 力測無効電力量前月指示数
            fixIn.setReactivePreviousIndicationNo(indicationNoResult1.getReactivePreviousIn());

          }
        }
      }

      // 【確定指示数】に登録する値を設定
      // ※【指示数実績】が複数件存在するか指示数がnullの場合、指示数差の取得ができないため、
      // 　指示数に関わる項目は未設定とする
      // 確定使用量ID
      fixIn.setFuId(applyDataBusinessBean.getFixUsageId());
      // 計器区分コード
      fixIn.setMeterCatCode(ECISRKConstants.METER_CATEGORY_CODE_FOR_IN_COMMON);
      // 計器交換フラグ()
      fixIn.setMeterReplacementFlag(indicationNoResulCount == 1 ? ECISConstants.FLG_OFF
          : ECISConstants.FLG_ON);
      // 計器識別番号
      fixIn.setMeterIdn(meterIdentificationNo);
      // 指示数使用量差異フラグ
      fixIn.setFixInUsageDiffFlag(fixInUsageDiffFlag);
      // 更新回数
      fixIn.setUpdateCount(0);
      // 作成日時
      fixIn.setCreateTime(timestamp);
      // 更新日時
      fixIn.setUpdateTime(timestamp);
      // 更新モジュールコード
      fixIn.setUpdateModuleCode(moduleCode);

      // 【確定指示数】登録
      fixInMapper.insert(fixIn);
    }

    // 計器識別番号を特定できた場合は、【メータ設置場所】を更新する
    if (meterIdentificationNo != null) {

      // メータ設置場所Entity
      Ml ml = new Ml();

      // メータ設置場所Example
      MlExample mlExample = new MlExample();

      // 【メータ設置場所】.計器識別番号1に更新する値を設定する
      // 計器識別番号1
      ml.setMeterIdn1(meterIdentificationNo);
      // 更新日時
      ml.setUpdateTime(timestamp);
      // 更新モジュールコード
      ml.setUpdateModuleCode(moduleCode);

      // 更新条件を設定
      // メータ設置場所ID
      mlExample.createCriteria().andMlIdEqualTo(
          applyDataBusinessBean.getMeterLocationId());

      // 【メータ設置場所】の更新
      mlMapper.updateByExampleSelective(ml, mlExample);
    }
  }

  /**
   * 指示数差補正メソッド<br>
   * 指示数差がマイナスの場合にメータ一周加算値を加算して、指示数差を補正する
   *
   * @param base
   *          当月指示数
   * @param previous
   *          前月指示数
   * @param usePeriod
   *          利用年月
   * @param contractNo
   *          契約番号
   * @param spotNo
   *          地点特定番号
   * @return メータ一周加算値を加算した指示数差
   */
  private BigDecimal calcDiffIn(BigDecimal base, BigDecimal previous,
      String usePeriod, String contractNo, String spotNo) {

    // 当月指示数、前月指示数がどちらもnullの場合、0を返す
    if (base == null && previous == null) {
      return BigDecimal.ZERO;
    }

    // 当月指示数、前月指示数のどちらかがnullの場合
    if (base == null || previous == null) {

      // 当月指示数がnullの場合、0を設定する。
      if (base == null) {
        base = BigDecimal.ZERO;
      }
      // 前月指示数がnullの場合、0を設定する。
      if (previous == null) {
        previous = BigDecimal.ZERO;
      }

      // TODOのパラメータ
      Object[] params = {
          // 利用年月
          usePeriod,
          // 契約番号
          contractNo,
          // 地点特定番号
          spotNo };

      // TODOビジネスBean
      TodoBusinessBean todoBean = new TodoBusinessBean();
      // サブシステムID
      todoBean.setSubsystemId(ECISConstants.SUBSYSTEM_ID_RK);
      // 機能ID
      todoBean.setFunctionId(ECISTodoConstants.TODO_FUNCTION_ID.RK0101
          .toString());
      // メッセージID
      todoBean.setMessageId("todo.T1059");
      // メッセージ
      todoBean.setMessage(messageSource.getMessage(
          todoBean.getMessageId(), params, Locale.getDefault()));
      // 契約番号
      todoBean.setContractNo(contractNo);
      // 地点特定番号
      todoBean.setSpotNo(spotNo);

      // TODO登録
      todoBusiness.registTodo(todoBean);

    }

    // 当月指示数から前月指示数を引いた値を指示数差に設定
    BigDecimal dif = base.subtract(previous);
    // 指示数差がマイナスの場合には、メータが一周している状態のため、
    // メータ一周加算値を加算して、指示数差を補正する
    if (dif.compareTo(BigDecimal.ZERO) < 0) {

      // TODOのパラメータ
      Object[] params = {
          // 利用年月
          usePeriod,
          // 契約番号
          contractNo,
          // 地点特定番号
          spotNo };

      // TODOビジネスBean
      TodoBusinessBean todoBean = new TodoBusinessBean();
      // サブシステムID
      todoBean.setSubsystemId(ECISConstants.SUBSYSTEM_ID_RK);
      // 機能ID
      todoBean.setFunctionId(ECISTodoConstants.TODO_FUNCTION_ID.RK0101
          .toString());
      // メッセージID
      todoBean.setMessageId("todo.T1060");
      // メッセージ
      todoBean.setMessage(messageSource.getMessage(
          todoBean.getMessageId(), params, Locale.getDefault()));
      // 契約番号
      todoBean.setContractNo(contractNo);
      // 地点特定番号
      todoBean.setSpotNo(spotNo);

      // TODO登録
      todoBusiness.registTodo(todoBean);

      // 絶対値をとり、小数点以下を切り捨て
      long value = previous.abs().setScale(0, BigDecimal.ROUND_DOWN)
          .longValue();

      // 加算値、デフォルトは10
      long addVal = 10;

      // 整数値を10で割れるだけ繰り返す
      while ((value /= 10) != 0) {
        // 加算値を10倍
        addVal *= 10;
      }

      // メータ一周加算値を指示数差に加算して返す
      return dif.add(new BigDecimal(addVal));
    } else {
      return dif;
    }

  }

  /**
   * 確定使用量共通ビジネスを設定します。(DI)
   *
   * @param rkFixUsageCommonBusiness
   *          確定使用量共通ビジネス
   */
  public void setRkFixUsageCommonBusiness(
      RK_FixUsageCommonBusiness rkFixUsageCommonBusiness) {
    this.rkFixUsageCommonBusiness = rkFixUsageCommonBusiness;
  }

  /**
   * 指示数実績Mapperを設定します。(DI)
   *
   * @param inResultMapper
   *          指示数実績Mapper
   */
  public void setInResultMapper(InResultMapper inResultMapper) {
    this.inResultMapper = inResultMapper;
  }

  /**
   * 確定指示数Mapperを設定します。(DI)
   *
   * @param fixInMapper
   *          確定指示数Mapper
   */
  public void setFixInMapper(FixInMapper fixInMapper) {
    this.fixInMapper = fixInMapper;
  }

  /**
   * メータ設置場所Mapperを設定します。(DI)
   *
   * @param mlMapper
   *          メータ設置場所Mapper
   */
  public void setMlMapper(MlMapper mlMapper) {
    this.mlMapper = mlMapper;
  }

  /**
   * TODOビジネスを設定します。(DI)
   *
   * @param todoBusiness
   *          TODOビジネス
   */
  public void setTodoBusiness(TodoBusiness todoBusiness) {
    this.todoBusiness = todoBusiness;
  }

  /**
   * メッセージリソースを設定します。(DI)
   *
   * @param messageSource
   *          メッセージリソース
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }

  /**
   * プロパティ定義クラス(DI)を設定します。
   *
   * @param applicationProperties
   *          プロパティ定義クラス(DI)
   */
  public void setApplicationProperties(
      PropertiesFactoryBean applicationProperties) {
    this.applicationProperties = applicationProperties;
  }

}
