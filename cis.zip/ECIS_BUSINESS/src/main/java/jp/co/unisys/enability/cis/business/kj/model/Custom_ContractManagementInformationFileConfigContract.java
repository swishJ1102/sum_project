package jp.co.unisys.enability.cis.business.kj.model;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * 契約情報登録・更新（一括登録）BusinessBean
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * 契約情報ビジネス
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class Custom_ContractManagementInformationFileConfigContract {

  /** ファイル名接頭辞 */
  public static final String FILE_NAME_PREFIX = "contract_";

  // ヘッダレコード定義
  /** ヘッダレコード：ファイル種別-パラメータ */
  public static final String HEADER_FILE_KIND_PARAM = "4";

  public static final String DATA_FILE_KIND_MASK_STRING = "^" + HEADER_FILE_KIND_PARAM + "$";

  // データレコード定義
  public static final String[] DATA_TITLE_ROW;
  /** データレコード：項目数 */
  public static final int DATA_COLUMN_COUNT;

  // 契約番号
  /** データレコード：契約番号-インデックス */
  public static final int DATA_CONTRACT_NO_INDEX = 1;
  /** データレコード：契約番号-名称 */
  public static final String DATA_CONTRACT_NO_NAME = "契約番号";
  /** データレコード：契約番号-文字数 */
  public static final int DATA_CONTRACT_NO_LENGTH = 25;
  /** データレコード：契約番号-文字数（文字列） */
  public static final String DATA_CONTRACT_NO_LENGTH_STRING = String.valueOf(DATA_CONTRACT_NO_LENGTH);

  // 契約者番号
  /** データレコード：契約者番号-インデックス */
  public static final int DATA_CONTRACTOR_NO_INDEX = 2;
  /** データレコード：契約者番号-名称 */
  public static final String DATA_CONTRACTOR_NO_NAME = "契約者番号";
  /** データレコード：契約者番号-文字数 */
  public static final int DATA_CONTRACTOR_NO_LENGTH = 25;
  /** データレコード：契約者番号-文字数（文字列） */
  public static final String DATA_CONTRACTOR_NO_LENGTH_STRING = String.valueOf(DATA_CONTRACTOR_NO_LENGTH);

  // 支払番号
  /** データレコード：支払番号-インデックス */
  public static final int DATA_PAYMENT_NO_INDEX = 3;
  /** データレコード：支払番号-名称 */
  public static final String DATA_PAYMENT_NO_NAME = "支払番号";
  /** データレコード：支払番号-文字数 */
  public static final int DATA_PAYMENT_NO_LENGTH = 25;
  /** データレコード：支払番号-文字数（文字列） */
  public static final String DATA_PAYMENT_NO_LENGTH_STRING = String.valueOf(DATA_PAYMENT_NO_LENGTH);

  // メータ設置場所ID
  /** データレコード：メータ設置場所ID-インデックス */
  public static final int DATA_METER_LOCATION_ID_INDEX = 4;
  /** データレコード：メータ設置場所ID-名称 */
  public static final String DATA_METER_LOCATION_ID_NAME = "メータ設置場所ID";
  /** データレコード：メータ設置場所ID-文字数 */
  public static final int DATA_METER_LOCATION_ID_LENGTH = 10;
  /** データレコード：メータ設置場所ID-文字数（文字列） */
  public static final String DATA_METER_LOCATION_ID_LENGTH_STRING = String.valueOf(DATA_METER_LOCATION_ID_LENGTH);

  // 契約グループ番号
  /** データレコード：契約グループ番号-インデックス */
  public static final int DATA_CONTRACT_GROUP_NO_INDEX = 5;
  /** データレコード：契約グループ番号-名称 */
  public static final String DATA_CONTRACT_GROUP_NO_NAME = "契約グループ番号";
  /** データレコード：契約グループ番号-文字数 */
  public static final int DATA_CONTRACT_GROUP_NO_LENGTH = 25;
  /** データレコード：契約グループ番号-文字数（文字列） */
  public static final String DATA_CONTRACT_GROUP_NO_LENGTH_STRING = String.valueOf(DATA_CONTRACT_GROUP_NO_LENGTH);

  // 契約開始日
  /** データレコード：契約開始日-インデックス */
  public static final int DATA_CONTRACT_START_DATE_INDEX = 6;
  /** データレコード：契約開始日-名称 */
  public static final String DATA_CONTRACT_START_DATE_NAME = "契約開始日";
  /** データレコード：契約開始日-文字数 */
  public static final int DATA_CONTRACT_START_DATE_LENGTH = 10;
  /** データレコード：契約開始日-文字数（文字列） */
  public static final String DATA_CONTRACT_START_DATE_LENGTH_STRING = String.valueOf(DATA_CONTRACT_START_DATE_LENGTH);

  // 契約終了日
  /** データレコード：契約終了日-インデックス */
  public static final int DATA_CONTRACT_END_DATE_INDEX = 7;
  /** データレコード：契約終了日-名称 */
  public static final String DATA_CONTRACT_END_DATE_NAME = "契約終了日";
  /** データレコード：契約終了日-文字数 */
  public static final int DATA_CONTRACT_END_DATE_LENGTH = 10;
  /** データレコード：契約終了日-文字数（文字列） */
  public static final String DATA_CONTRACT_END_DATE_LENGTH_STRING = String.valueOf(DATA_CONTRACT_END_DATE_LENGTH);

  // 契約終了理由コード
  /** データレコード：契約終了理由コード-インデックス */
  public static final int DATA_CONTRACT_END_REASON_CODE_INDEX = 8;
  /** データレコード：契約終了理由コード-名称 */
  public static final String DATA_CONTRACT_END_REASON_CODE_NAME = "契約終了理由コード";
  /** データレコード：契約終了理由コード-文字数 */
  public static final int DATA_CONTRACT_END_REASON_CODE_LENGTH = 1;
  /** データレコード：契約終了理由コード-文字数（文字列） */
  public static final String DATA_CONTRACT_END_REASON_CODE_LENGTH_STRING = String
      .valueOf(DATA_CONTRACT_END_REASON_CODE_LENGTH);

  // 託送契約容量
  /** データレコード：託送契約容量-インデックス */
  public static final int DATA_CONSIGNMENT_CONTRACT_CAPACITY_INDEX = 9;
  /** データレコード：託送契約容量-名称 */
  public static final String DATA_CONSIGNMENT_CONTRACT_CAPACITY_NAME = "託送契約容量";
  /** データレコード：託送契約容量-整数部桁数上限 */
  public static final int DATA_CONSIGNMENT_CONTRACT_CAPACITY_DIGIT_INTEGER = 6;
  /** データレコード：託送契約容量-小数部桁数 */
  public static final int DATA_CONSIGNMENT_CONTRACT_CAPACITY_DIGIT_FLOAT = 2;
  /** データレコード：託送契約容量-整数部桁数上限（文字列） */
  public static final String DATA_CONSIGNMENT_CONTRACT_CAPACITY_DIGIT_INTEGER_STRING = String
      .valueOf(DATA_CONSIGNMENT_CONTRACT_CAPACITY_DIGIT_INTEGER);
  /** データレコード：託送契約容量-小数部桁数（文字列） */
  public static final String DATA_CONSIGNMENT_CONTRACT_CAPACITY_DIGIT_FLOAT_STRING = String
      .valueOf(DATA_CONSIGNMENT_CONTRACT_CAPACITY_DIGIT_FLOAT);

  // 託送契約容量単位
  /** データレコード：託送契約容量単位-インデックス */
  public static final int DATA_CONSIGNMENT_CONTRACT_CAPACITY_UNIT_INDEX = 10;
  /** データレコード：託送契約容量単位-名称 */
  public static final String DATA_CONSIGNMENT_CONTRACT_CAPACITY_UNIT_NAME = "託送契約容量単位";
  /** データレコード：託送契約容量単位-文字数 */
  public static final int DATA_CONSIGNMENT_CONTRACT_CAPACITY_UNIT_LENGTH = 1;
  /** データレコード：託送契約容量単位-文字数（文字列） */
  public static final String DATA_CONSIGNMENT_CONTRACT_CAPACITY_UNIT_LENGTH_STRING = String
      .valueOf(DATA_CONSIGNMENT_CONTRACT_CAPACITY_UNIT_LENGTH);

  // 託送契約容量判定日
  /** データレコード：託送契約容量判定日-インデックス */
  public static final int DATA_CONSIGNMENT_CONTRACT_CAPACITY_DECISION_DATE_INDEX = 11;
  /** データレコード：託送契約容量判定日-名称 */
  public static final String DATA_CONSIGNMENT_CONTRACT_CAPACITY_DECISION_DATE_NAME = "託送契約容量判定日";
  /** データレコード：託送契約容量判定日-文字数 */
  public static final int DATA_CONSIGNMENT_CONTRACT_CAPACITY_DECISION_DATE_LENGTH = 10;
  /** データレコード：託送契約容量判定日-文字数（文字列） */
  public static final String DATA_CONSIGNMENT_CONTRACT_CAPACITY_DECISION_DATE_LENGTH_STRING = String
      .valueOf(DATA_CONSIGNMENT_CONTRACT_CAPACITY_DECISION_DATE_LENGTH);

  // 料金チェックフラグ
  /** データレコード：料金チェックフラグ-インデックス */
  public static final int DATA_CHARGE_CHECK_FLAG_INDEX = 12;
  /** データレコード：料金チェックフラグ-名称 */
  public static final String DATA_CHARGE_CHECK_FLAG_NAME = "料金チェックフラグ";
  /** データレコード：料金チェックフラグ-文字数 */
  public static final int DATA_CHARGE_CHECK_FLAG_LENGTH = 1;
  /** データレコード：料金チェックフラグ-文字数（文字列） */
  public static final String DATA_CHARGE_CHECK_FLAG_LENGTH_STRING = String.valueOf(DATA_CHARGE_CHECK_FLAG_LENGTH);

  // 個人・法人区分コード
  /** データレコード：個人・法人区分コード-インデックス */
  public static final int DATA_INDIVIDUAL_LEGAL_ENTITY_CATEGORY_CODE_INDEX = 13;
  /** データレコード：個人・法人区分コード-名称 */
  public static final String DATA_INDIVIDUAL_LEGAL_ENTITY_CATEGORY_CODE_NAME = "個人・法人区分コード";
  /** データレコード：個人・法人区分コード-文字数 */
  public static final int DATA_INDIVIDUAL_LEGAL_ENTITY_CATEGORY_CODE_LENGTH = 1;
  /** データレコード：個人・法人区分コード-文字数（文字列） */
  public static final String DATA_INDIVIDUAL_LEGAL_ENTITY_CATEGORY_CODE_LENGTH_STRING = String
      .valueOf(DATA_INDIVIDUAL_LEGAL_ENTITY_CATEGORY_CODE_LENGTH);

  // 連絡先氏名（カナ）
  /** データレコード：連絡先氏名（カナ）-インデックス */
  public static final int DATA_CONTRACT_INFORMATION_NAME_KANA_INDEX = 14;
  /** データレコード：連絡先氏名（カナ）-名称 */
  public static final String DATA_CONTRACT_INFORMATION_NAME_KANA_NAME = "連絡先氏名（カナ）";
  /** データレコード：連絡先氏名（カナ）-文字数 */
  public static final int DATA_CONTRACT_INFORMATION_NAME_KANA_LENGTH = 40;
  /** データレコード：連絡先氏名（カナ）-文字数（文字列） */
  public static final String DATA_CONTRACT_INFORMATION_NAME_KANA_LENGTH_STRING = String
      .valueOf(DATA_CONTRACT_INFORMATION_NAME_KANA_LENGTH);

  // 連絡先氏名1
  /** データレコード：連絡先氏名1-インデックス */
  public static final int DATA_CONTRACT_INFORMATION_NAME1_INDEX = 15;
  /** データレコード：連絡先氏名1-名称 */
  public static final String DATA_CONTRACT_INFORMATION_NAME1_NAME = "連絡先氏名1";
  /** データレコード：連絡先氏名1-文字数 */
  public static final int DATA_CONTRACT_INFORMATION_NAME1_LENGTH = 35;
  /** データレコード：連絡先氏名1-文字数（文字列） */
  public static final String DATA_CONTRACT_INFORMATION_NAME1_LENGTH_STRING = String
      .valueOf(DATA_CONTRACT_INFORMATION_NAME1_LENGTH);

  // 連絡先氏名2
  /** データレコード：連絡先氏名2-インデックス */
  public static final int DATA_CONTRACT_INFORMATION_NAME2_INDEX = 16;
  /** データレコード：連絡先氏名2-名称 */
  public static final String DATA_CONTRACT_INFORMATION_NAME2_NAME = "連絡先氏名2";
  /** データレコード：連絡先氏名2-文字数 */
  public static final int DATA_CONTRACT_INFORMATION_NAME2_LENGTH = 27;
  /** データレコード：連絡先氏名2-文字数（文字列） */
  public static final String DATA_CONTRACT_INFORMATION_NAME2_LENGTH_STRING = String
      .valueOf(DATA_CONTRACT_INFORMATION_NAME2_LENGTH);

  // 連絡先住所（郵便番号）
  /** データレコード：連絡先住所（郵便番号）-インデックス */
  public static final int DATA_CONTRACT_INFORMATION_ADDRESS_POSTAL_CODE_INDEX = 17;
  /** データレコード：連絡先住所（郵便番号）-名称 */
  public static final String DATA_CONTRACT_INFORMATION_ADDRESS_POSTAL_CODE_NAME = "連絡先住所（郵便番号）";
  /** データレコード：連絡先住所（郵便番号）-文字数 */
  public static final int DATA_CONTRACT_INFORMATION_ADDRESS_POSTAL_CODE_LENGTH = 7;
  /** データレコード：連絡先住所（郵便番号）-文字数（文字列） */
  public static final String DATA_CONTRACT_INFORMATION_ADDRESS_POSTAL_CODE_LENGTH_STRING = String
      .valueOf(DATA_CONTRACT_INFORMATION_ADDRESS_POSTAL_CODE_LENGTH);

  // 連絡先住所（住所）
  /** データレコード：連絡先住所（住所）-インデックス */
  public static final int DATA_CONTRACT_INFORMATION_ADDRESS_FULL_INDEX = 18;
  /** データレコード：連絡先住所（住所）-名称 */
  public static final String DATA_CONTRACT_INFORMATION_ADDRESS_FULL_NAME = "連絡先住所（住所）";
  /** データレコード：連絡先住所（住所）-文字数 */
  public static final int DATA_CONTRACT_INFORMATION_ADDRESS_FULL_LENGTH = 60;
  /** データレコード：連絡先住所（住所）-文字数（文字列） */
  public static final String DATA_CONTRACT_INFORMATION_ADDRESS_FULL_LENGTH_STRING = String
      .valueOf(DATA_CONTRACT_INFORMATION_ADDRESS_FULL_LENGTH);

  // 連絡先住所（建物・部屋名）
  /** データレコード：連絡先住所（建物・部屋名）-インデックス */
  public static final int DATA_CONTRACT_INFORMATION_ADDRESS_BUILDING_INDEX = 19;
  /** データレコード：連絡先住所（建物・部屋名）-名称 */
  public static final String DATA_CONTRACT_INFORMATION_ADDRESS_BUILDING_NAME = "連絡先住所（建物・部屋名）";
  /** データレコード：連絡先住所（建物・部屋名）-文字数 */
  public static final int DATA_CONTRACT_INFORMATION_ADDRESS_BUILDING_LENGTH = 36;
  /** データレコード：連絡先住所（建物・部屋名）-文字数（文字列） */
  public static final String DATA_CONTRACT_INFORMATION_ADDRESS_BUILDING_LENGTH_STRING = String
      .valueOf(DATA_CONTRACT_INFORMATION_ADDRESS_BUILDING_LENGTH);

  // 連絡先電話区分コード
  /** データレコード：連絡先電話区分コード-インデックス */
  public static final int DATA_CONTRACT_INFORMATION_CATEGORY_CODE_INDEX = 20;
  /** データレコード：連絡先電話区分コード-名称 */
  public static final String DATA_CONTRACT_INFORMATION_CATEGORY_CODE_NAME = "連絡先電話区分コード";
  /** データレコード：連絡先電話区分コード-文字数 */
  public static final int DATA_CONTRACT_INFORMATION_CATEGORY_CODE_LENGTH = 1;
  /** データレコード：連絡先電話区分コード-文字数（文字列） */
  public static final String DATA_CONTRACT_INFORMATION_CATEGORY_CODE_LENGTH_STRING = String
      .valueOf(DATA_CONTRACT_INFORMATION_CATEGORY_CODE_LENGTH);

  // 連絡先電話（市外局番）
  /** データレコード：連絡先電話（市外局番）-インデックス */
  public static final int DATA_CONTRACT_INFORMATION_AREA_CODE_INDEX = 21;
  /** データレコード：連絡先電話（市外局番）-名称 */
  public static final String DATA_CONTRACT_INFORMATION_AREA_CODE_NAME = "連絡先電話（市外局番）";
  /** データレコード：連絡先電話（市外局番）-文字数 */
  public static final int DATA_CONTRACT_INFORMATION_AREA_CODE_LENGTH = 6;
  /** データレコード：連絡先電話（市外局番）-文字数（文字列） */
  public static final String DATA_CONTRACT_INFORMATION_AREA_CODE_LENGTH_STRING = String
      .valueOf(DATA_CONTRACT_INFORMATION_AREA_CODE_LENGTH);

  // 連絡先電話（市内局番）
  /** データレコード：連絡先電話（市内局番）-インデックス */
  public static final int DATA_CONTRACT_INFORMATION_LOCAL_NO_INDEX = 22;
  /** データレコード：連絡先電話（市内局番）-名称 */
  public static final String DATA_CONTRACT_INFORMATION_LOCAL_NO_NAME = "連絡先電話（市内局番）";
  /** データレコード：連絡先電話（市内局番）-文字数 */
  public static final int DATA_CONTRACT_INFORMATION_LOCAL_NO_LENGTH = 4;
  /** データレコード：連絡先電話（市内局番）-文字数（文字列） */
  public static final String DATA_CONTRACT_INFORMATION_LOCAL_NO_LENGTH_STRING = String
      .valueOf(DATA_CONTRACT_INFORMATION_LOCAL_NO_LENGTH);

  // 連絡先電話（加入者番号）
  /** データレコード：連絡先電話（加入者番号）-インデックス */
  public static final int DATA_CONTRACT_INFORMATION_DIRECTORY_NO_INDEX = 23;
  /** データレコード：連絡先電話（加入者番号）-名称 */
  public static final String DATA_CONTRACT_INFORMATION_DIRECTORY_NO_NAME = "連絡先電話（加入者番号）";
  /** データレコード：連絡先電話（加入者番号）-文字数 */
  public static final int DATA_CONTRACT_INFORMATION_DIRECTORY_NO_LENGTH = 6;
  /** データレコード：連絡先電話（加入者番号）-文字数（文字列） */
  public static final String DATA_CONTRACT_INFORMATION_DIRECTORY_NO_LENGTH_STRING = String
      .valueOf(DATA_CONTRACT_INFORMATION_DIRECTORY_NO_LENGTH);

  // 需要者窓口連絡先所属
  /** データレコード：需要者窓口連絡先所属-インデックス */
  public static final int DATA_CONSUMER_CONTRACT_AFFILIATION_INDEX = 24;
  /** データレコード：需要者窓口連絡先所属-名称 */
  public static final String DATA_CONSUMER_CONTRACT_AFFILIATION_NAME = "需要者窓口連絡先所属";
  /** データレコード：需要者窓口連絡先所属-文字数 */
  public static final int DATA_CONSUMER_CONTRACT_AFFILIATION_LENGTH = 55;
  /** データレコード：需要者窓口連絡先所属-文字数（文字列） */
  public static final String DATA_CONSUMER_CONTRACT_AFFILIATION_LENGTH_STRING = String
      .valueOf(DATA_CONSUMER_CONTRACT_AFFILIATION_LENGTH);

  // 需要者窓口連絡先氏名
  /** データレコード：需要者窓口連絡先氏名-インデックス */
  public static final int DATA_CONSUMER_CONTRACT_NAME_INDEX = 25;
  /** データレコード：需要者窓口連絡先氏名-名称 */
  public static final String DATA_CONSUMER_CONTRACT_NAME_NAME = "需要者窓口連絡先氏名";
  /** データレコード：需要者窓口連絡先氏名-文字数 */
  public static final int DATA_CONSUMER_CONTRACT_NAME_LENGTH = 55;
  /** データレコード：需要者窓口連絡先氏名-文字数（文字列） */
  public static final String DATA_CONSUMER_CONTRACT_NAME_LENGTH_STRING = String
      .valueOf(DATA_CONSUMER_CONTRACT_NAME_LENGTH);

  // 需要者窓口連絡先電話番号（市外局番）
  /** データレコード：需要者窓口連絡先電話（市外局番）-インデックス */
  public static final int DATA_CONSUMER_CONTRACT_AREA_CODE_INDEX = 26;
  /** データレコード：需要者窓口連絡先電話（市外局番）-名称 */
  public static final String DATA_CONSUMER_CONTRACT_AREA_CODE_NAME = "需要者窓口連絡先電話番号（市外局番）";
  /** データレコード：需要者窓口連絡先電話（市外局番）-文字数 */
  public static final int DATA_CONSUMER_CONTRACT_AREA_CODE_LENGTH = 6;
  /** データレコード：需要者窓口連絡先電話（市外局番）-文字数（文字列） */
  public static final String DATA_CONSUMER_CONTRACT_AREA_CODE_LENGTH_STRING = String
      .valueOf(DATA_CONSUMER_CONTRACT_AREA_CODE_LENGTH);

  // 需要者窓口連絡先電話番号（市内局番）
  /** データレコード：需要者窓口連絡先電話（市内局番）-インデックス */
  public static final int DATA_CONSUMER_CONTRACT_LOCAL_NO_INDEX = 27;
  /** データレコード：需要者窓口連絡先電話（市内局番）-名称 */
  public static final String DATA_CONSUMER_CONTRACT_LOCAL_NO_NAME = "需要者窓口連絡先電話番号（市内局番）";
  /** データレコード：需要者窓口連絡先電話（市内局番）-文字数 */
  public static final int DATA_CONSUMER_CONTRACT_LOCAL_NO_LENGTH = 4;
  /** データレコード：需要者窓口連絡先電話（市内局番）-文字数（文字列） */
  public static final String DATA_CONSUMER_CONTRACT_LOCAL_NO_LENGTH_STRING = String
      .valueOf(DATA_CONSUMER_CONTRACT_LOCAL_NO_LENGTH);

  // 需要者窓口連絡先電話番号（加入者番号）
  /** データレコード：需要者窓口連絡先電話（加入者番号）-インデックス */
  public static final int DATA_CONSUMER_CONTRACT_DIRECTORY_NO_INDEX = 28;
  /** データレコード：需要者窓口連絡先電話（加入者番号）-名称 */
  public static final String DATA_CONSUMER_CONTRACT_DIRECTORY_NO_NAME = "需要者窓口連絡先電話番号（加入者番号）";
  /** データレコード：需要者窓口連絡先電話（加入者番号）-文字数 */
  public static final int DATA_CONSUMER_CONTRACT_DIRECTORY_NO_LENGTH = 4;
  /** データレコード：需要者窓口連絡先電話（加入者番号）-文字数（文字列） */
  public static final String DATA_CONSUMER_CONTRACT_DIRECTORY_NO_LENGTH_STRING = String
      .valueOf(DATA_CONSUMER_CONTRACT_DIRECTORY_NO_LENGTH);

  // 主任技術者連絡先所属
  /** データレコード：主任技術者連絡先所属-インデックス */
  public static final int DATA_CHIEF_ENGINEER_OFFICER_AFFILIATION_INDEX = 29;
  /** データレコード：主任技術者連絡先所属-名称 */
  public static final String DATA_CHIEF_ENGINEER_OFFICER_AFFILIATION_NAME = "主任技術者連絡先所属";
  /** データレコード：主任技術者連絡先所属-文字数 */
  public static final int DATA_CHIEF_ENGINEER_OFFICER_AFFILIATION_LENGTH = 55;
  /** データレコード：主任技術者連絡先所属-文字数（文字列） */
  public static final String DATA_CHIEF_ENGINEER_OFFICER_AFFILIATION_LENGTH_STRING = String
      .valueOf(DATA_CHIEF_ENGINEER_OFFICER_AFFILIATION_LENGTH);

  // 主任技術者連絡先氏名
  /** データレコード：主任技術者連絡先氏名-インデックス */
  public static final int DATA_CHIEF_ENGINEER_OFFICER_NAME_INDEX = 30;
  /** データレコード：主任技術者連絡先氏名-名称 */
  public static final String DATA_CHIEF_ENGINEER_OFFICER_NAME_NAME = "主任技術者連絡先氏名";
  /** データレコード：主任技術者連絡先氏名-文字数 */
  public static final int DATA_CHIEF_ENGINEER_OFFICER_NAME_LENGTH = 55;
  /** データレコード：主任技術者連絡先氏名-文字数（文字列） */
  public static final String DATA_CHIEF_ENGINEER_OFFICER_NAME_LENGTH_STRING = String
      .valueOf(DATA_CHIEF_ENGINEER_OFFICER_NAME_LENGTH);

  // 主任技術者連絡先電話番号（市外局番）
  /** データレコード：主任技術者連絡先電話（市外局番）-インデックス */
  public static final int DATA_CHIEF_ENGINEER_OFFICER_AREA_CODE_INDEX = 31;
  /** データレコード：主任技術者連絡先電話（市外局番）-名称 */
  public static final String DATA_CHIEF_ENGINEER_OFFICER_AREA_CODE_NAME = "主任技術者連絡先電話番号（市外局番）";
  /** データレコード：主任技術者連絡先電話（市外局番）-文字数 */
  public static final int DATA_CHIEF_ENGINEER_OFFICER_AREA_CODE_LENGTH = 6;
  /** データレコード：主任技術者連絡先電話（市外局番）-文字数（文字列） */
  public static final String DATA_CHIEF_ENGINEER_OFFICER_AREA_CODE_LENGTH_STRING = String
      .valueOf(DATA_CHIEF_ENGINEER_OFFICER_AREA_CODE_LENGTH);

  // 主任技術者連絡先電話番号（市内局番）
  /** データレコード：主任技術者連絡先電話（市内局番）-インデックス */
  public static final int DATA_CHIEF_ENGINEER_OFFICER_LOCAL_NO_INDEX = 32;
  /** データレコード：主任技術者連絡先電話（市内局番）-名称 */
  public static final String DATA_CHIEF_ENGINEER_OFFICER_LOCAL_NO_NAME = "主任技術者連絡先電話番号（市内局番）";
  /** データレコード：主任技術者連絡先電話（市内局番）-文字数 */
  public static final int DATA_CHIEF_ENGINEER_OFFICER_LOCAL_NO_LENGTH = 4;
  /** データレコード：主任技術者連絡先電話（市内局番）-文字数（文字列） */
  public static final String DATA_CHIEF_ENGINEER_OFFICER_LOCAL_NO_LENGTH_STRING = String
      .valueOf(DATA_CHIEF_ENGINEER_OFFICER_LOCAL_NO_LENGTH);

  // 主任技術者連絡先電話番号（加入者番号）
  /** データレコード：主任技術者連絡先電話（加入者番号）-インデックス */
  public static final int DATA_CHIEF_ENGINEER_OFFICER_DIRECTORY_NO_INDEX = 33;
  /** データレコード：主任技術者連絡先電話（加入者番号）-名称 */
  public static final String DATA_CHIEF_ENGINEER_OFFICER_DIRECTORY_NO_NAME = "主任技術者連絡先電話番号（加入者番号）";
  /** データレコード：主任技術者連絡先電話（加入者番号）-文字数 */
  public static final int DATA_CHIEF_ENGINEER_OFFICER_DIRECTORY_NO_LENGTH = 4;
  /** データレコード：主任技術者連絡先電話（加入者番号）-文字数（文字列） */
  public static final String DATA_CHIEF_ENGINEER_OFFICER_DIRECTORY_NO_LENGTH_STRING = String
      .valueOf(DATA_CHIEF_ENGINEER_OFFICER_DIRECTORY_NO_LENGTH);

  // 接続送電サービス区分コード
  /** データレコード：接続送電サービス区分コード-インデックス */
  public static final int DATA_CONNECTED_SUPPLY_SERVICE_CATEGORY_CODE_INDEX = 34;
  /** データレコード：接続送電サービス区分コード-名称 */
  public static final String DATA_CONNECTED_SUPPLY_SERVICE_CATEGORY_CODE_NAME = "接続送電サービス区分コード";
  /** データレコード：接続送電サービス区分コード-文字数 */
  public static final int DATA_CONNECTED_SUPPLY_SERVICE_CATEGORY_CODE_LENGTH = 5;
  /** データレコード：接続送電サービス区分コード-文字数（文字列） */
  public static final String DATA_CONNECTED_SUPPLY_SERVICE_CATEGORY_CODE_LENGTH_STRING = String
      .valueOf(DATA_CONNECTED_SUPPLY_SERVICE_CATEGORY_CODE_LENGTH);

  /** データレコード：部分供給区分コード-インデックス */
  public static final int DATA_PS_INFO_CODE_INDEX = 35;
  /** データレコード：部分供給区分コード-名称 */
  public static final String DATA_PS_INFO_CODE_INDEX_NAME = "部分供給区分コード";
  /** データレコード：部分供給区分コード-文字数 */
  public static final int DATA_PS_INFO_CODE_INDEX_LENGTH = 1;
  /** データレコード：部分供給区分コード-文字数(文字列) */
  public static final String DATA_PS_INFO_CODE_INDEX_STRING = String
      .valueOf(DATA_PS_INFO_CODE_INDEX_LENGTH);

  // 備考
  /** データレコード：備考-インデックス */
  public static final int DATA_NOTE_INDEX = 36;
  /** データレコード：備考-名称 */
  public static final String DATA_NOTE_NAME = "備考";
  /** データレコード：備考-文字数 */
  public static final int DATA_NOTE_LENGTH = 200;
  /** データレコード：備考-文字数（文字列） */
  public static final String DATA_NOTE_LENGTH_STRING = String.valueOf(DATA_NOTE_LENGTH);

  // 実量歴必須フラグ
  /** データレコード：実量歴必須フラグ-インデックス */
  public static final int DATA_REAL_QUANTITY_NEED_FLAG_INDEX = 37;
  /** データレコード：実量歴必須フラグ-名称 */
  public static final String DATA_REAL_QUANTITY_NEED_FLAG_NAME = "実量歴必須フラグ";
  /** データレコード：実量歴必須フラグ-文字数 */
  public static final int DATA_REAL_QUANTITY_NEED_FLAG_LENGTH = 1;
  /** データレコード：実量歴必須フラグ-文字数（文字列） */
  public static final String DATA_REAL_QUANTITY_NEED_FLAG_LENGTH_STRING = String
      .valueOf(DATA_REAL_QUANTITY_NEED_FLAG_NAME);

  // フリー項目1
  /** データレコード：フリー項目1-インデックス */
  public static final int DATA_FREE1_INDEX = 38;
  /** データレコード：フリー項目1-名称 */
  public static final String DATA_FREE1_NAME = "フリー項目1";
  /** データレコード：フリー項目1-文字数 */
  public static final int DATA_FREE1_LENGTH = 100;
  /** データレコード：フリー項目1-文字数（文字列） */
  public static final String DATA_FREE1_LENGTH_STRING = String.valueOf(DATA_FREE1_LENGTH);

  // フリー項目2
  /** データレコード：フリー項目2-インデックス */
  public static final int DATA_FREE2_INDEX = 39;
  /** データレコード：フリー項目2-名称 */
  public static final String DATA_FREE2_NAME = "フリー項目2";
  /** データレコード：フリー項目2-文字数 */
  public static final int DATA_FREE2_LENGTH = 100;
  /** データレコード：フリー項目2-文字数（文字列） */
  public static final String DATA_FREE2_LENGTH_STRING = String.valueOf(DATA_FREE2_LENGTH);

  // フリー項目3
  /** データレコード：フリー項目3-インデックス */
  public static final int DATA_FREE3_INDEX = 40;
  /** データレコード：フリー項目3-名称 */
  public static final String DATA_FREE3_NAME = "フリー項目3";
  /** データレコード：フリー項目3-文字数 */
  public static final int DATA_FREE3_LENGTH = 100;
  /** データレコード：フリー項目3-文字数（文字列） */
  public static final String DATA_FREE3_LENGTH_STRING = String.valueOf(DATA_FREE3_LENGTH);

  // フリー項目4
  /** データレコード：フリー項目4-インデックス */
  public static final int DATA_FREE4_INDEX = 41;
  /** データレコード：フリー項目4-名称 */
  public static final String DATA_FREE4_NAME = "フリー項目4";
  /** データレコード：フリー項目4-文字数 */
  public static final int DATA_FREE4_LENGTH = 100;
  /** データレコード：フリー項目4-文字数（文字列） */
  public static final String DATA_FREE4_LENGTH_STRING = String.valueOf(DATA_FREE4_LENGTH);

  // フリー項目5
  /** データレコード：フリー項目5-インデックス */
  public static final int DATA_FREE5_INDEX = 42;
  /** データレコード：フリー項目5-名称 */
  public static final String DATA_FREE5_NAME = "フリー項目5";
  /** データレコード：フリー項目5-文字数 */
  public static final int DATA_FREE5_LENGTH = 100;
  /** データレコード：フリー項目5-文字数（文字列） */
  public static final String DATA_FREE5_LENGTH_STRING = String.valueOf(DATA_FREE5_LENGTH);

  // フリー項目6
  /** データレコード：フリー項目6-インデックス */
  public static final int DATA_FREE6_INDEX = 43;
  /** データレコード：フリー項目6-名称 */
  public static final String DATA_FREE6_NAME = "フリー項目6";
  /** データレコード：フリー項目6-文字数 */
  public static final int DATA_FREE6_LENGTH = 100;
  /** データレコード：フリー項目6-文字数（文字列） */
  public static final String DATA_FREE6_LENGTH_STRING = String.valueOf(DATA_FREE6_LENGTH);

  // フリー項目7
  /** データレコード：フリー項目7-インデックス */
  public static final int DATA_FREE7_INDEX = 44;
  /** データレコード：フリー項目7-名称 */
  public static final String DATA_FREE7_NAME = "フリー項目7";
  /** データレコード：フリー項目7-文字数 */
  public static final int DATA_FREE7_LENGTH = 100;
  /** データレコード：フリー項目7-文字数（文字列） */
  public static final String DATA_FREE7_LENGTH_STRING = String.valueOf(DATA_FREE7_LENGTH);

  // フリー項目8
  /** データレコード：フリー項目8-インデックス */
  public static final int DATA_FREE8_INDEX = 45;
  /** データレコード：フリー項目8-名称 */
  public static final String DATA_FREE8_NAME = "フリー項目8";
  /** データレコード：フリー項目8-文字数 */
  public static final int DATA_FREE8_LENGTH = 100;
  /** データレコード：フリー項目8-文字数（文字列） */
  public static final String DATA_FREE8_LENGTH_STRING = String.valueOf(DATA_FREE8_LENGTH);

  // 設備ID
  /** データレコード：設備ID-インデックス */
  public static final int DATA_FREE9_INDEX = 46;
  /** データレコード：設備ID-名称 */
  public static final String DATA_FREE9_NAME = "設備ID";
  /** データレコード：設備ID-文字数 */
  public static final int DATA_FREE9_LENGTH = 10;
  /** データレコード：設備ID-文字数（文字列） */
  public static final String DATA_FREE9_LENGTH_STRING = String.valueOf(DATA_FREE9_LENGTH);

  // フリー項目10
  /** データレコード：フリー項目10-インデックス */
  public static final int DATA_FREE10_INDEX = 47;
  /** データレコード：フリー項目10-名称 */
  public static final String DATA_FREE10_NAME = "フリー項目10";
  /** データレコード：フリー項目10-文字数 */
  public static final int DATA_FREE10_LENGTH = 100;
  /** データレコード：フリー項目10-文字数（文字列） */
  public static final String DATA_FREE10_LENGTH_STRING = String.valueOf(DATA_FREE10_LENGTH);

  // フリー項目11
  /** データレコード：フリー項目11-インデックス */
  public static final int DATA_FREE11_INDEX = 48;
  /** データレコード：フリー項目11-名称 */
  public static final String DATA_FREE11_NAME = "フリー項目11";
  /** データレコード：フリー項目11-文字数 */
  public static final int DATA_FREE11_LENGTH = 100;
  /** データレコード：フリー項目11-文字数（文字列） */
  public static final String DATA_FREE11_LENGTH_STRING = String.valueOf(DATA_FREE11_LENGTH);

  // フリー項目12
  /** データレコード：フリー項目12-インデックス */
  public static final int DATA_FREE12_INDEX = 49;
  /** データレコード：フリー項目12-名称 */
  public static final String DATA_FREE12_NAME = "フリー項目12";
  /** データレコード：フリー項目12-文字数 */
  public static final int DATA_FREE12_LENGTH = 100;
  /** データレコード：フリー項目12-文字数（文字列） */
  public static final String DATA_FREE12_LENGTH_STRING = String.valueOf(DATA_FREE12_LENGTH);

  // フリー項目13
  /** データレコード：フリー項目13-インデックス */
  public static final int DATA_FREE13_INDEX = 50;
  /** データレコード：フリー項目13-名称 */
  public static final String DATA_FREE13_NAME = "フリー項目13";
  /** データレコード：フリー項目13-文字数 */
  public static final int DATA_FREE13_LENGTH = 100;
  /** データレコード：フリー項目13-文字数（文字列） */
  public static final String DATA_FREE13_LENGTH_STRING = String.valueOf(DATA_FREE13_LENGTH);

  // フリー項目14
  /** データレコード：フリー項目14-インデックス */
  public static final int DATA_FREE14_INDEX = 51;
  /** データレコード：フリー項目14-名称 */
  public static final String DATA_FREE14_NAME = "フリー項目14";
  /** データレコード：フリー項目14-文字数 */
  public static final int DATA_FREE14_LENGTH = 100;
  /** データレコード：フリー項目14-文字数（文字列） */
  public static final String DATA_FREE14_LENGTH_STRING = String.valueOf(DATA_FREE14_LENGTH);

  // 委託先使用項目1
  /** データレコード：委託先使用項目1-インデックス */
  public static final int DATA_CONSIGNMENT_USE_ITEM1_INDEX = 52;
  /** データレコード：委託先使用項目1-名称 */
  public static final String DATA_CONSIGNMENT_USE_ITEM1_NAME = "委託先使用項目1";
  /** データレコード：委託先使用項目1-文字数 */
  public static final int DATA_CONSIGNMENT_USE_ITEM1_LENGTH = 128;
  /** データレコード：委託先使用項目1-文字数（文字列） */
  public static final String DATA_CONSIGNMENT_USE_ITEM1_LENGTH_STRING = String
      .valueOf(DATA_CONSIGNMENT_USE_ITEM1_LENGTH);

  // 委託先使用項目2
  /** データレコード：委託先使用項目2-インデックス */
  public static final int DATA_CONSIGNMENT_USE_ITEM2_INDEX = 53;
  /** データレコード：委託先使用項目2-名称 */
  public static final String DATA_CONSIGNMENT_USE_ITEM2_NAME = "委託先使用項目2";
  /** データレコード：委託先使用項目2-文字数 */
  public static final int DATA_CONSIGNMENT_USE_ITEM2_LENGTH = 128;
  /** データレコード：委託先使用項目2-文字数（文字列） */
  public static final String DATA_CONSIGNMENT_USE_ITEM2_LENGTH_STRING = String
      .valueOf(DATA_CONSIGNMENT_USE_ITEM2_LENGTH);

  // 委託先使用項目3
  /** データレコード：委託先使用項目3-インデックス */
  public static final int DATA_CONSIGNMENT_USE_ITEM3_INDEX = 54;
  /** データレコード：委託先使用項目3-名称 */
  public static final String DATA_CONSIGNMENT_USE_ITEM3_NAME = "委託先使用項目3";
  /** データレコード：委託先使用項目3-文字数 */
  public static final int DATA_CONSIGNMENT_USE_ITEM3_LENGTH = 128;
  /** データレコード：委託先使用項目3-文字数（文字列） */
  public static final String DATA_CONSIGNMENT_USE_ITEM3_LENGTH_STRING = String
      .valueOf(DATA_CONSIGNMENT_USE_ITEM3_LENGTH);

  // 自社担当者コード
  /** データレコード：自社担当者コード-インデックス */
  public static final int DATA_OUR_MANAGEMENT_PERSON_IN_CHARGE_CODE_INDEX = 55;
  /** データレコード：自社担当者コード-名称 */
  public static final String DATA_OUR_MANAGEMENT_PERSON_IN_CHARGE_CODE_NAME = "自社担当者コード";
  /** データレコード：自社担当者コード-文字数 */
  public static final int DATA_OUR_MANAGEMENT_PERSON_IN_CHARGE_CODE_LENGTH = 20;
  /** データレコード：自社担当者コード-文字数（文字列） */
  public static final String DATA_OUR_MANAGEMENT_PERSON_IN_CHARGE_CODE_LENGTH_STRING = String
      .valueOf(DATA_OUR_MANAGEMENT_PERSON_IN_CHARGE_CODE_LENGTH);

  // 自社部署コード
  /** データレコード：自社部署コード-インデックス */
  public static final int DATA_OUR_MANAGEMENT_DEPARTMENT_CODE_INDEX = 56;
  /** データレコード：自社部署コード-名称 */
  public static final String DATA_OUR_MANAGEMENT_DEPARTMENT_CODE_NAME = "自社部署コード";
  /** データレコード：自社部署コード-文字数 */
  public static final int DATA_OUR_MANAGEMENT_DEPARTMENT_CODE_LENGTH = 10;
  /** データレコード：自社部署コード-文字数（文字列） */
  public static final String DATA_OUR_MANAGEMENT_DEPARTMENT_CODE_LENGTH_STRING = String
      .valueOf(DATA_OUR_MANAGEMENT_DEPARTMENT_CODE_LENGTH);

  // 業種コード
  /** データレコード：業種コード-インデックス */
  public static final int DATA_BUSINESS_TYPE_CODE_INDEX = 57;
  /** データレコード：業種コード-名称 */
  public static final String DATA_BUSINESS_TYPE_CODE_NAME = "業種コード";
  /** データレコード：業種コード-文字数 */
  public static final int DATA_BUSINESS_TYPE_CODE_LENGTH = 3;
  /** データレコード：業種コード-文字数（文字列） */
  public static final String DATA_BUSINESS_TYPE_CODE_LENGTH_STRING = String.valueOf(DATA_BUSINESS_TYPE_CODE_LENGTH);

  // 営業委託先コード
  /** データレコード：営業委託先コード-インデックス */
  public static final int DATA_SALES_CONSIGNMENT_CODE_INDEX = 58;
  /** データレコード：営業委託先コード-名称 */
  public static final String DATA_SALES_CONSIGNMENT_CODE_NAME = "営業委託先コード";
  /** データレコード：営業委託先コード-文字数 */
  public static final int DATA_SALES_CONSIGNMENT_CODE_LENGTH = 9;
  /** データレコード：営業委託先コード-文字数（文字列） */
  public static final String DATA_SALES_CONSIGNMENT_CODE_LENGTH_STRING = String
      .valueOf(DATA_SALES_CONSIGNMENT_CODE_LENGTH);

  // 営業担当者・組織コード
  /** データレコード：営業担当者・組織コード-インデックス */
  public static final int DATA_SALES_DEPARTMENT_CODE_INDEX = 59;
  /** データレコード：営業担当者・組織コード-名称 */
  public static final String DATA_SALES_DEPARTMENT_CODE_NAME = "営業担当者・組織コード";
  /** データレコード：営業担当者・組織コード-文字数 */
  public static final int DATA_SALES_DEPARTMENT_CODE_LENGTH = 8;
  /** データレコード：営業担当者・組織コード-文字数（文字列） */
  public static final String DATA_SALES_DEPARTMENT_CODE_LENGTH_STRING = String
      .valueOf(DATA_SALES_DEPARTMENT_CODE_LENGTH);

  // 問合わせ先コード
  /** データレコード：問合わせ先コード-インデックス */
  public static final int DATA_SALES_CONTACT_CODE_INDEX = 60;
  /** データレコード：問合わせ先コード-名称 */
  public static final String DATA_SALES_CONTACT_CODE_NAME = "問合わせ先コード";
  /** データレコード：問合わせ先コード-文字数 */
  public static final int DATA_SALES_CONTACT_CODE_LENGTH = 3;
  /** データレコード：問合わせ先コード-文字数（文字列） */
  public static final String DATA_SALES_CONTACT_CODE_LENGTH_STRING = String
      .valueOf(DATA_SALES_CONTACT_CODE_LENGTH);

  // 適用開始日
  /** データレコード：適用開始日-インデックス */
  public static final int DATA_APPLY_START_DATE_INDEX = 61;
  /** データレコード：適用開始日-名称 */
  public static final String DATA_APPLY_START_DATE_NAME = "適用開始日";
  /** データレコード：適用開始日-文字数 */
  public static final int DATA_APPLY_START_DATE_LENGTH = 10;
  /** データレコード：適用開始日-文字数（文字列） */
  public static final String DATA_APPLY_START_DATE_LENGTH_STRING = String.valueOf(DATA_APPLY_START_DATE_LENGTH);

  // 料金メニューID
  /** データレコード：料金メニューID-インデックス */
  public static final int DATA_RATE_MENU_ID_INDEX = 62;
  /** データレコード：料金メニューID-名称 */
  public static final String DATA_RATE_MENU_ID_NAME = "料金メニューID";
  /** データレコード：料金メニューID-文字数 */
  public static final int DATA_RATE_MENU_ID_LENGTH = 8;
  /** データレコード：料金メニューID-文字数（文字列） */
  public static final String DATA_RATE_MENU_ID_LENGTH_STRING = String.valueOf(DATA_RATE_MENU_ID_LENGTH);

  // 契約容量
  /** データレコード：契約容量-インデックス */
  public static final int DATA_CONTRACT_CAPACITY_INDEX = 63;
  /** データレコード：契約容量-名称 */
  public static final String DATA_CONTRACT_CAPACITY_NAME = "契約容量";
  /** データレコード：契約容量-整数部桁数上限 */
  public static final int DATA_CONTRACT_CAPACITY_DIGIT_INTEGER = 6;
  /** データレコード：契約容量-小数部桁数 */
  public static final int DATA_CONTRACT_CAPACITY_DIGIT_FLOAT = 2;
  /** データレコード：契約容量-整数部桁数上限（文字列） */
  public static final String DATA_CONTRACT_CAPACITY_DIGIT_INTEGER_STRING = String
      .valueOf(DATA_CONTRACT_CAPACITY_DIGIT_INTEGER);
  /** データレコード：契約容量-小数部桁数（文字列） */
  public static final String DATA_CONTRACT_CAPACITY_DIGIT_FLOAT_STRING = String
      .valueOf(DATA_CONTRACT_CAPACITY_DIGIT_FLOAT);

  // 契約変更理由
  /** データレコード：契約変更理由-インデックス */
  public static final int DATA_CONTRACT_CHANGE_REASON_INDEX = 64;
  /** データレコード：契約変更理由-名称 */
  public static final String DATA_CONTRACT_CHANGE_REASON_NAME = "契約変更理由";
  /** データレコード：契約変更理由-文字数 */
  public static final int DATA_CONTRACT_CHANGE_REASON_LENGTH = 200;
  /** データレコード：契約変更理由-文字数（文字列） */
  public static final String DATA_CONTRACT_CHANGE_REASON_LENGTH_STRING = String
      .valueOf(DATA_CONTRACT_CHANGE_REASON_LENGTH);

  // 電圧区分
  /** データレコード：電圧区分-インデックス */
  public static final int DATA_VOLTAGE_CAT_CODE_INDEX = 65;
  /** データレコード：電圧区分-名称 */
  public static final String DATA_VOLTAGE_CAT_CODE_NAME = "電圧区分";
  /** データレコード：電圧区分-文字数 */
  public static final int DATA_VOLTAGE_CAT_CODE_LENGTH = 1;
  /** データレコード：電圧区分-文字数（文字列） */
  public static final String DATA_VOLTAGE_CAT_CODE_LENGTH_STRING = String
      .valueOf(DATA_VOLTAGE_CAT_CODE_LENGTH);

  // 契約電力決定区分
  /** データレコード：契約電力決定区分-インデックス */
  public static final int DATA_CCDECISION_CATEGORY_CODE_INDEX = 66;
  /** データレコード：契約電力決定区分-名称 */
  public static final String DATA_CCDECISION_CATEGORY_CODE_NAME = "契約電力決定区分";
  /** データレコード：契約電力決定区分-文字数 */
  public static final int DATA_CCDECISION_CATEGORY_CODE_LENGTH = 1;
  /** データレコード：契約電力決定区分-文字数（文字列） */
  public static final String DATA_CCDECISION_CATEGORY_CODE_LENGTH_STRING = String
      .valueOf(DATA_CCDECISION_CATEGORY_CODE_LENGTH);

  // 単価設定区分
  /** データレコード：単価設定区分-インデックス */
  public static final int DATA_UP_CAT_CODE_INDEX = 67;
  /** データレコード：単価設定区分-名称 */
  public static final String DATA_UP_CAT_CODE_NAME = "単価設定区分";
  /** データレコード：単価設定区分-文字数 */
  public static final int DATA_UP_CAT_CODE_LENGTH = 1;
  /** データレコード：単価設定区分-文字数（文字列） */
  public static final String DATA_UP_CAT_CODE_LENGTH_STRING = String
      .valueOf(DATA_UP_CAT_CODE_LENGTH);

  // 最低月額料金
  /** データレコード：最低月額料金-インデックス */
  public static final int DATA_MMC_INDEX = 68;
  /** データレコード：最低月額料金-名称 */
  public static final String DATA_MMC_NAME = "最低月額料金";
  /** データレコード：最低月額料金-整数部桁数上限 */
  public static final int DATA_MMC_INTEGER = 5;
  /** データレコード：最低月額料金-小数部桁数 */
  public static final int DATA_MMC_FLOAT = 2;
  /** データレコード：最低月額料金-整数部桁数上限（文字列） */
  public static final String DATA_MMCT_INTEGER_STRING = String
      .valueOf(DATA_MMC_INTEGER);
  /** データレコード：最低月額料金-小数部桁数（文字列） */
  public static final String DATA_MMC_FLOAT_STRING = String
      .valueOf(DATA_MMC_FLOAT);

  // DCEC区分コード１
  /** データレコード：DCEC区分コード１-インデックス */
  public static final int DATA_DCEC_CAT_CODE1_INDEX = 69;
  /** データレコード：DCEC区分コード１-名称 */
  public static final String DATA_DCEC_CAT_CODE1_NAME = "DCEC区分コード１";
  /** データレコード：DCEC区分コード１-文字数 */
  public static final int DATA_DCEC_CAT_CODE1_LENGTH = 1;
  /** データレコード：DCEC区分コード１-文字数（文字列） */
  public static final String DATA_DCEC_CAT_CODE1_LENGTH_STRING = String
      .valueOf(DATA_DCEC_CAT_CODE1_LENGTH);

  // 時間帯コード１
  /** データレコード：時間帯コード１-インデックス */
  public static final int DATA_TS_CODE1_INDEX = 70;
  /** データレコード：時間帯コード１-名称 */
  public static final String DATA_TS_CODE1_NAME = "時間帯コード１";
  /** データレコード：時間帯コード１-文字数 */
  public static final int DATA_TS_CODE1_LENGTH = 1;
  /** データレコード：時間帯コード１-文字数（文字列） */
  public static final String DATA_TS_CODE1_LENGTH_STRING = String
      .valueOf(DATA_TS_CODE1_LENGTH);

  // 枝番１
  /** データレコード：枝番１-インデックス */
  public static final int DATA_BRANCH_NO1_INDEX = 71;
  /** データレコード：枝番１-名称 */
  public static final String DATA_BRANCH_NO1_NAME = "枝番１";
  /** データレコード：枝番１-文字数 */
  public static final int DATA_BRANCH_NO1_LENGTH = 1;
  /** データレコード：枝番１-文字数（文字列） */
  public static final String DATA_BRANCH_NO1_LENGTH_STRING = String
      .valueOf(DATA_BRANCH_NO1_LENGTH);

  // 単価明細金額１
  /** データレコード：単価明細金額１-インデックス */
  public static final int DATA_UP1_INDEX = 72;
  /** データレコード：単価明細金額１-名称 */
  public static final String DATA_UP1_NAME = "単価明細金額１";
  /** データレコード：単価明細金額１-整数部桁数上限 */
  public static final int DATA_UP1_INTEGER = 5;
  /** データレコード：単価明細金額１-小数部桁数 */
  public static final int DATA_UP1_FLOAT = 2;
  /** データレコード：単価明細金額１-整数部桁数上限（文字列） */
  public static final String DATA_UP1_INTEGER_STRING = String
      .valueOf(DATA_UP1_INTEGER);
  /** データレコード：単価明細金額１-小数部桁数（文字列） */
  public static final String DATA_UP1_FLOAT_STRING = String
      .valueOf(DATA_UP1_FLOAT);

  // DCEC区分コード２
  /** データレコード：DCEC区分コード２-インデックス */
  public static final int DATA_DCEC_CAT_CODE2_INDEX = 73;
  /** データレコード：DCEC区分コード２-名称 */
  public static final String DATA_DCEC_CAT_CODE2_NAME = "DCEC区分コード２";
  /** データレコード：DCEC区分コード２-文字数 */
  public static final int DATA_DCEC_CAT_CODE2_LENGTH = 1;
  /** データレコード：DCEC区分コード２-文字数（文字列） */
  public static final String DATA_DCEC_CAT_CODE2_LENGTH_STRING = String
      .valueOf(DATA_DCEC_CAT_CODE2_LENGTH);

  // 時間帯コード２
  /** データレコード：時間帯コード２-インデックス */
  public static final int DATA_TS_CODE2_INDEX = 74;
  /** データレコード：時間帯コード２-名称 */
  public static final String DATA_TS_CODE2_NAME = "時間帯コード２";
  /** データレコード：時間帯コード２-文字数 */
  public static final int DATA_TS_CODE2_LENGTH = 1;
  /** データレコード：時間帯コード２-文字数（文字列） */
  public static final String DATA_TS_CODE2_LENGTH_STRING = String
      .valueOf(DATA_TS_CODE2_LENGTH);

  // 枝番２
  /** データレコード：枝番２-インデックス */
  public static final int DATA_BRANCH_NO2_INDEX = 75;
  /** データレコード：枝番２-名称 */
  public static final String DATA_BRANCH_NO2_NAME = "枝番２";
  /** データレコード：枝番２-文字数 */
  public static final int DATA_BRANCH_NO2_LENGTH = 1;
  /** データレコード：枝番２-文字数（文字列） */
  public static final String DATA_BRANCH_NO2_LENGTH_STRING = String
      .valueOf(DATA_BRANCH_NO2_LENGTH);

  // 単価明細金額２
  /** データレコード：単価明細金額２-インデックス */
  public static final int DATA_UP2_INDEX = 76;
  /** データレコード：単価明細金額２-名称 */
  public static final String DATA_UP2_NAME = "単価明細金額２";
  /** データレコード：単価明細金額２-整数部桁数上限 */
  public static final int DATA_UP2_INTEGER = 5;
  /** データレコード：単価明細金額２-小数部桁数 */
  public static final int DATA_UP2_FLOAT = 2;
  /** データレコード：単価明細金額２-整数部桁数上限（文字列） */
  public static final String DATA_UP2_INTEGER_STRING = String
      .valueOf(DATA_UP2_INTEGER);
  /** データレコード：単価明細金額２-小数部桁数（文字列） */
  public static final String DATA_UP2_FLOAT_STRING = String
      .valueOf(DATA_UP2_FLOAT);

  // DCEC区分コード３
  /** データレコード：DCEC区分コード３-インデックス */
  public static final int DATA_DCEC_CAT_CODE3_INDEX = 77;
  /** データレコード：DCEC区分コード３-名称 */
  public static final String DATA_DCEC_CAT_CODE3_NAME = "DCEC区分コード３";
  /** データレコード：DCEC区分コード３-文字数 */
  public static final int DATA_DCEC_CAT_CODE3_LENGTH = 1;
  /** データレコード：DCEC区分コード３-文字数（文字列） */
  public static final String DATA_DCEC_CAT_CODE3_LENGTH_STRING = String
      .valueOf(DATA_DCEC_CAT_CODE3_LENGTH);

  // 時間帯コード３
  /** データレコード：時間帯コード３-インデックス */
  public static final int DATA_TS_CODE3_INDEX = 78;
  /** データレコード：時間帯コード３-名称 */
  public static final String DATA_TS_CODE3_NAME = "時間帯コード３";
  /** データレコード：時間帯コード３-文字数 */
  public static final int DATA_TS_CODE3_LENGTH = 1;
  /** データレコード：時間帯コード３-文字数（文字列） */
  public static final String DATA_TS_CODE3_LENGTH_STRING = String
      .valueOf(DATA_TS_CODE3_LENGTH);

  // 枝番３
  /** データレコード：枝番３-インデックス */
  public static final int DATA_BRANCH_NO3_INDEX = 79;
  /** データレコード：枝番３-名称 */
  public static final String DATA_BRANCH_NO3_NAME = "枝番３";
  /** データレコード：枝番３-文字数 */
  public static final int DATA_BRANCH_NO3_LENGTH = 1;
  /** データレコード：枝番３-文字数（文字列） */
  public static final String DATA_BRANCH_NO3_LENGTH_STRING = String
      .valueOf(DATA_BRANCH_NO3_LENGTH);

  // 単価明細金額３
  /** データレコード：単価明細金額３-インデックス */
  public static final int DATA_UP3_INDEX = 80;
  /** データレコード：単価明細金額３-名称 */
  public static final String DATA_UP3_NAME = "単価明細金額３";
  /** データレコード：単価明細金額３-整数部桁数上限 */
  public static final int DATA_UP3_INTEGER = 5;
  /** データレコード：単価明細金額３-小数部桁数 */
  public static final int DATA_UP3_FLOAT = 2;
  /** データレコード：単価明細金額３-整数部桁数上限（文字列） */
  public static final String DATA_UP3_INTEGER_STRING = String
      .valueOf(DATA_UP3_INTEGER);
  /** データレコード：単価明細金額３-小数部桁数（文字列） */
  public static final String DATA_UP3_FLOAT_STRING = String
      .valueOf(DATA_UP3_FLOAT);

  // DCEC区分コード４
  /** データレコード：DCEC区分コード４-インデックス */
  public static final int DATA_DCEC_CAT_CODE4_INDEX = 81;
  /** データレコード：DCEC区分コード４-名称 */
  public static final String DATA_DCEC_CAT_CODE4_NAME = "DCEC区分コード４";
  /** データレコード：DCEC区分コード４-文字数 */
  public static final int DATA_DCEC_CAT_CODE4_LENGTH = 1;
  /** データレコード：DCEC区分コード４-文字数（文字列） */
  public static final String DATA_DCEC_CAT_CODE4_LENGTH_STRING = String
      .valueOf(DATA_DCEC_CAT_CODE4_LENGTH);

  // 時間帯コード４
  /** データレコード：時間帯コード４-インデックス */
  public static final int DATA_TS_CODE4_INDEX = 82;
  /** データレコード：時間帯コード４-名称 */
  public static final String DATA_TS_CODE4_NAME = "時間帯コード４";
  /** データレコード：時間帯コード４-文字数 */
  public static final int DATA_TS_CODE4_LENGTH = 1;
  /** データレコード：時間帯コード４-文字数（文字列） */
  public static final String DATA_TS_CODE4_LENGTH_STRING = String
      .valueOf(DATA_TS_CODE4_LENGTH);

  // 枝番４
  /** データレコード：枝番４-インデックス */
  public static final int DATA_BRANCH_NO4_INDEX = 83;
  /** データレコード：枝番４-名称 */
  public static final String DATA_BRANCH_NO4_NAME = "枝番４";
  /** データレコード：枝番４-文字数 */
  public static final int DATA_BRANCH_NO4_LENGTH = 1;
  /** データレコード：枝番４-文字数（文字列） */
  public static final String DATA_BRANCH_NO4_LENGTH_STRING = String
      .valueOf(DATA_BRANCH_NO4_LENGTH);

  // 単価明細金額４
  /** データレコード：単価明細金額４-インデックス */
  public static final int DATA_UP4_INDEX = 84;
  /** データレコード：単価明細金額４-名称 */
  public static final String DATA_UP4_NAME = "単価明細金額４";
  /** データレコード：単価明細金額４-整数部桁数上限 */
  public static final int DATA_UP4_INTEGER = 5;
  /** データレコード：単価明細金額４-小数部桁数 */
  public static final int DATA_UP4_FLOAT = 2;
  /** データレコード：単価明細金額４-整数部桁数上限（文字列） */
  public static final String DATA_UP4_INTEGER_STRING = String
      .valueOf(DATA_UP4_INTEGER);
  /** データレコード：単価明細金額４-小数部桁数（文字列） */
  public static final String DATA_UP4_FLOAT_STRING = String
      .valueOf(DATA_UP4_FLOAT);

  // DCEC区分コード５
  /** データレコード：DCEC区分コード５-インデックス */
  public static final int DATA_DCEC_CAT_CODE5_INDEX = 85;
  /** データレコード：DCEC区分コード５-名称 */
  public static final String DATA_DCEC_CAT_CODE5_NAME = "DCEC区分コード５";
  /** データレコード：DCEC区分コード５-文字数 */
  public static final int DATA_DCEC_CAT_CODE5_LENGTH = 1;
  /** データレコード：DCEC区分コード５-文字数（文字列） */
  public static final String DATA_DCEC_CAT_CODE5_LENGTH_STRING = String
      .valueOf(DATA_DCEC_CAT_CODE5_LENGTH);

  // 時間帯コード５
  /** データレコード：時間帯コード５-インデックス */
  public static final int DATA_TS_CODE5_INDEX = 86;
  /** データレコード：時間帯コード５-名称 */
  public static final String DATA_TS_CODE5_NAME = "時間帯コード５";
  /** データレコード：時間帯コード５-文字数 */
  public static final int DATA_TS_CODE5_LENGTH = 1;
  /** データレコード：時間帯コード５-文字数（文字列） */
  public static final String DATA_TS_CODE5_LENGTH_STRING = String
      .valueOf(DATA_TS_CODE5_LENGTH);

  // 枝番５
  /** データレコード：枝番５-インデックス */
  public static final int DATA_BRANCH_NO5_INDEX = 87;
  /** データレコード：枝番５-名称 */
  public static final String DATA_BRANCH_NO5_NAME = "枝番５";
  /** データレコード：枝番５-文字数 */
  public static final int DATA_BRANCH_NO5_LENGTH = 1;
  /** データレコード：枝番５-文字数（文字列） */
  public static final String DATA_BRANCH_NO5_LENGTH_STRING = String
      .valueOf(DATA_BRANCH_NO5_LENGTH);

  // 単価明細金額５
  /** データレコード：単価明細金額５-インデックス */
  public static final int DATA_UP5_INDEX = 88;
  /** データレコード：単価明細金額５-名称 */
  public static final String DATA_UP5_NAME = "単価明細金額５";
  /** データレコード：単価明細金額５-整数部桁数上限 */
  public static final int DATA_UP5_INTEGER = 5;
  /** データレコード：単価明細金額５-小数部桁数 */
  public static final int DATA_UP5_FLOAT = 2;
  /** データレコード：単価明細金額５-整数部桁数上限（文字列） */
  public static final String DATA_UP5_INTEGER_STRING = String
      .valueOf(DATA_UP5_INTEGER);
  /** データレコード：単価明細金額５-小数部桁数（文字列） */
  public static final String DATA_UP5_FLOAT_STRING = String
      .valueOf(DATA_UP5_FLOAT);

  // DCEC区分コード６
  /** データレコード：DCEC区分コード６-インデックス */
  public static final int DATA_DCEC_CAT_CODE6_INDEX = 89;
  /** データレコード：DCEC区分コード６-名称 */
  public static final String DATA_DCEC_CAT_CODE6_NAME = "DCEC区分コード６";
  /** データレコード：DCEC区分コード６-文字数 */
  public static final int DATA_DCEC_CAT_CODE6_LENGTH = 1;
  /** データレコード：DCEC区分コード６-文字数（文字列） */
  public static final String DATA_DCEC_CAT_CODE6_LENGTH_STRING = String
      .valueOf(DATA_DCEC_CAT_CODE6_LENGTH);

  // 時間帯コード６
  /** データレコード：時間帯コード６-インデックス */
  public static final int DATA_TS_CODE6_INDEX = 90;
  /** データレコード：時間帯コード６-名称 */
  public static final String DATA_TS_CODE6_NAME = "時間帯コード６";
  /** データレコード：時間帯コード６-文字数 */
  public static final int DATA_TS_CODE6_LENGTH = 1;
  /** データレコード：時間帯コード６-文字数（文字列） */
  public static final String DATA_TS_CODE6_LENGTH_STRING = String
      .valueOf(DATA_TS_CODE6_LENGTH);

  // 枝番６
  /** データレコード：枝番６-インデックス */
  public static final int DATA_BRANCH_NO6_INDEX = 91;
  /** データレコード：枝番６-名称 */
  public static final String DATA_BRANCH_NO6_NAME = "枝番６";
  /** データレコード：枝番６-文字数 */
  public static final int DATA_BRANCH_NO6_LENGTH = 1;
  /** データレコード：枝番６-文字数（文字列） */
  public static final String DATA_BRANCH_NO6_LENGTH_STRING = String
      .valueOf(DATA_BRANCH_NO6_LENGTH);

  // 単価明細金額６
  /** データレコード：単価明細金額６-インデックス */
  public static final int DATA_UP6_INDEX = 92;
  /** データレコード：単価明細金額６-名称 */
  public static final String DATA_UP6_NAME = "単価明細金額６";
  /** データレコード：単価明細金額６-整数部桁数上限 */
  public static final int DATA_UP6_INTEGER = 5;
  /** データレコード：単価明細金額６-小数部桁数 */
  public static final int DATA_UP6_FLOAT = 2;
  /** データレコード：単価明細金額６-整数部桁数上限（文字列） */
  public static final String DATA_UP6_INTEGER_STRING = String
      .valueOf(DATA_UP6_INTEGER);
  /** データレコード：単価明細金額６-小数部桁数（文字列） */
  public static final String DATA_UP6_FLOAT_STRING = String
      .valueOf(DATA_UP6_FLOAT);

  // DCEC区分コード７
  /** データレコード：DCEC区分コード７-インデックス */
  public static final int DATA_DCEC_CAT_CODE7_INDEX = 93;
  /** データレコード：DCEC区分コード７-名称 */
  public static final String DATA_DCEC_CAT_CODE7_NAME = "DCEC区分コード７";
  /** データレコード：DCEC区分コード７-文字数 */
  public static final int DATA_DCEC_CAT_CODE7_LENGTH = 1;
  /** データレコード：DCEC区分コード７-文字数（文字列） */
  public static final String DATA_DCEC_CAT_CODE7_LENGTH_STRING = String
      .valueOf(DATA_DCEC_CAT_CODE7_LENGTH);

  // 時間帯コード７
  /** データレコード：時間帯コード７-インデックス */
  public static final int DATA_TS_CODE7_INDEX = 94;
  /** データレコード：時間帯コード７-名称 */
  public static final String DATA_TS_CODE7_NAME = "時間帯コード７";
  /** データレコード：時間帯コード７-文字数 */
  public static final int DATA_TS_CODE7_LENGTH = 1;
  /** データレコード：時間帯コード７-文字数（文字列） */
  public static final String DATA_TS_CODE7_LENGTH_STRING = String
      .valueOf(DATA_TS_CODE7_LENGTH);

  // 枝番７
  /** データレコード：枝番７-インデックス */
  public static final int DATA_BRANCH_NO7_INDEX = 95;
  /** データレコード：枝番７-名称 */
  public static final String DATA_BRANCH_NO7_NAME = "枝番７";
  /** データレコード：枝番７-文字数 */
  public static final int DATA_BRANCH_NO7_LENGTH = 1;
  /** データレコード：枝番７-文字数（文字列） */
  public static final String DATA_BRANCH_NO7_LENGTH_STRING = String
      .valueOf(DATA_BRANCH_NO7_LENGTH);

  // 単価明細金額７
  /** データレコード：単価明細金額７-インデックス */
  public static final int DATA_UP7_INDEX = 96;
  /** データレコード：単価明細金額７-名称 */
  public static final String DATA_UP7_NAME = "単価明細金額７";
  /** データレコード：単価明細金額７-整数部桁数上限 */
  public static final int DATA_UP7_INTEGER = 5;
  /** データレコード：単価明細金額７-小数部桁数 */
  public static final int DATA_UP7_FLOAT = 2;
  /** データレコード：単価明細金額７-整数部桁数上限（文字列） */
  public static final String DATA_UP7_INTEGER_STRING = String
      .valueOf(DATA_UP7_INTEGER);
  /** データレコード：単価明細金額７-小数部桁数（文字列） */
  public static final String DATA_UP7_FLOAT_STRING = String
      .valueOf(DATA_UP7_FLOAT);

  // DCEC区分コード８
  /** データレコード：DCEC区分コード８-インデックス */
  public static final int DATA_DCEC_CAT_CODE8_INDEX = 97;
  /** データレコード：DCEC区分コード８-名称 */
  public static final String DATA_DCEC_CAT_CODE8_NAME = "DCEC区分コード８";
  /** データレコード：DCEC区分コード８-文字数 */
  public static final int DATA_DCEC_CAT_CODE8_LENGTH = 1;
  /** データレコード：DCEC区分コード８-文字数（文字列） */
  public static final String DATA_DCEC_CAT_CODE8_LENGTH_STRING = String
      .valueOf(DATA_DCEC_CAT_CODE8_LENGTH);

  // 時間帯コード８
  /** データレコード：時間帯コード８-インデックス */
  public static final int DATA_TS_CODE8_INDEX = 98;
  /** データレコード：時間帯コード８-名称 */
  public static final String DATA_TS_CODE8_NAME = "時間帯コード８";
  /** データレコード：時間帯コード８-文字数 */
  public static final int DATA_TS_CODE8_LENGTH = 1;
  /** データレコード：時間帯コード８-文字数（文字列） */
  public static final String DATA_TS_CODE8_LENGTH_STRING = String
      .valueOf(DATA_TS_CODE8_LENGTH);

  // 枝番８
  /** データレコード：枝番８-インデックス */
  public static final int DATA_BRANCH_NO8_INDEX = 99;
  /** データレコード：枝番８-名称 */
  public static final String DATA_BRANCH_NO8_NAME = "枝番８";
  /** データレコード：枝番８-文字数 */
  public static final int DATA_BRANCH_NO8_LENGTH = 1;
  /** データレコード：枝番８-文字数（文字列） */
  public static final String DATA_BRANCH_NO8_LENGTH_STRING = String
      .valueOf(DATA_BRANCH_NO8_LENGTH);

  // 単価明細金額８
  /** データレコード：単価明細金額８-インデックス */
  public static final int DATA_UP8_INDEX = 100;
  /** データレコード：単価明細金額８-名称 */
  public static final String DATA_UP8_NAME = "単価明細金額８";
  /** データレコード：単価明細金額８-整数部桁数上限 */
  public static final int DATA_UP8_INTEGER = 5;
  /** データレコード：単価明細金額８-小数部桁数 */
  public static final int DATA_UP8_FLOAT = 2;
  /** データレコード：単価明細金額８-整数部桁数上限（文字列） */
  public static final String DATA_UP8_INTEGER_STRING = String
      .valueOf(DATA_UP8_INTEGER);
  /** データレコード：単価明細金額８-小数部桁数（文字列） */
  public static final String DATA_UP8_FLOAT_STRING = String
      .valueOf(DATA_UP8_FLOAT);

  // DCEC区分コード９
  /** データレコード：DCEC区分コード９-インデックス */
  public static final int DATA_DCEC_CAT_CODE9_INDEX = 101;
  /** データレコード：DCEC区分コード９-名称 */
  public static final String DATA_DCEC_CAT_CODE9_NAME = "DCEC区分コード９";
  /** データレコード：DCEC区分コード９-文字数 */
  public static final int DATA_DCEC_CAT_CODE9_LENGTH = 1;
  /** データレコード：DCEC区分コード９-文字数（文字列） */
  public static final String DATA_DCEC_CAT_CODE9_LENGTH_STRING = String
      .valueOf(DATA_DCEC_CAT_CODE9_LENGTH);

  // 時間帯コード９
  /** データレコード：時間帯コード９-インデックス */
  public static final int DATA_TS_CODE9_INDEX = 102;
  /** データレコード：時間帯コード９-名称 */
  public static final String DATA_TS_CODE9_NAME = "時間帯コード９";
  /** データレコード：時間帯コード９-文字数 */
  public static final int DATA_TS_CODE9_LENGTH = 1;
  /** データレコード：時間帯コード９-文字数（文字列） */
  public static final String DATA_TS_CODE9_LENGTH_STRING = String
      .valueOf(DATA_TS_CODE9_LENGTH);

  // 枝番９
  /** データレコード：枝番９-インデックス */
  public static final int DATA_BRANCH_NO9_INDEX = 103;
  /** データレコード：枝番９-名称 */
  public static final String DATA_BRANCH_NO9_NAME = "枝番９";
  /** データレコード：枝番９-文字数 */
  public static final int DATA_BRANCH_NO9_LENGTH = 1;
  /** データレコード：枝番９-文字数（文字列） */
  public static final String DATA_BRANCH_NO9_LENGTH_STRING = String
      .valueOf(DATA_BRANCH_NO9_LENGTH);

  // 単価明細金額９
  /** データレコード：単価明細金額９-インデックス */
  public static final int DATA_UP9_INDEX = 104;
  /** データレコード：単価明細金額９-名称 */
  public static final String DATA_UP9_NAME = "単価明細金額９";
  /** データレコード：単価明細金額９-整数部桁数上限 */
  public static final int DATA_UP9_INTEGER = 5;
  /** データレコード：単価明細金額９-小数部桁数 */
  public static final int DATA_UP9_FLOAT = 2;
  /** データレコード：単価明細金額９-整数部桁数上限（文字列） */
  public static final String DATA_UP9_INTEGER_STRING = String
      .valueOf(DATA_UP9_INTEGER);
  /** データレコード：単価明細金額９-小数部桁数（文字列） */
  public static final String DATA_UP9_FLOAT_STRING = String
      .valueOf(DATA_UP9_FLOAT);

  // DCEC区分コード１０
  /** データレコード：DCEC区分コード１０-インデックス */
  public static final int DATA_DCEC_CAT_CODE10_INDEX = 105;
  /** データレコード：DCEC区分コード１０-名称 */
  public static final String DATA_DCEC_CAT_CODE10_NAME = "DCEC区分コード１０";
  /** データレコード：DCEC区分コード１０-文字数 */
  public static final int DATA_DCEC_CAT_CODE10_LENGTH = 1;
  /** データレコード：DCEC区分コード１０-文字数（文字列） */
  public static final String DATA_DCEC_CAT_CODE10_LENGTH_STRING = String
      .valueOf(DATA_DCEC_CAT_CODE10_LENGTH);

  // 時間帯コード１０
  /** データレコード：時間帯コード１０-インデックス */
  public static final int DATA_TS_CODE10_INDEX = 106;
  /** データレコード：時間帯コード１０-名称 */
  public static final String DATA_TS_CODE10_NAME = "時間帯コード１０";
  /** データレコード：時間帯コード１０-文字数 */
  public static final int DATA_TS_CODE10_LENGTH = 1;
  /** データレコード：時間帯コード１０-文字数（文字列） */
  public static final String DATA_TS_CODE10_LENGTH_STRING = String
      .valueOf(DATA_TS_CODE10_LENGTH);

  // 枝番１０
  /** データレコード：枝番１０-インデックス */
  public static final int DATA_BRANCH_NO10_INDEX = 107;
  /** データレコード：枝番１０-名称 */
  public static final String DATA_BRANCH_NO10_NAME = "枝番１０";
  /** データレコード：枝番１０-文字数 */
  public static final int DATA_BRANCH_NO10_LENGTH = 1;
  /** データレコード：枝番１０-文字数（文字列） */
  public static final String DATA_BRANCH_NO10_LENGTH_STRING = String
      .valueOf(DATA_BRANCH_NO10_LENGTH);

  // 単価明細金額１０
  /** データレコード：単価明細金額１０-インデックス */
  public static final int DATA_UP10_INDEX = 108;
  /** データレコード：単価明細金額１０-名称 */
  public static final String DATA_UP10_NAME = "単価明細金額１０";
  /** データレコード：単価明細金額１０-整数部桁数上限 */
  public static final int DATA_UP10_INTEGER = 5;
  /** データレコード：単価明細金額１０-小数部桁数 */
  public static final int DATA_UP10_FLOAT = 2;
  /** データレコード：単価明細金額１０-整数部桁数上限（文字列） */
  public static final String DATA_UP10_INTEGER_STRING = String
      .valueOf(DATA_UP10_INTEGER);
  /** データレコード：単価明細金額１０-小数部桁数（文字列） */
  public static final String DATA_UP10_FLOAT_STRING = String
      .valueOf(DATA_UP10_FLOAT);

  // DCEC区分コード１１
  /** データレコード：DCEC区分コード１１-インデックス */
  public static final int DATA_DCEC_CAT_CODE11_INDEX = 109;
  /** データレコード：DCEC区分コード１１-名称 */
  public static final String DATA_DCEC_CAT_CODE11_NAME = "DCEC区分コード１１";
  /** データレコード：DCEC区分コード１１-文字数 */
  public static final int DATA_DCEC_CAT_CODE11_LENGTH = 1;
  /** データレコード：DCEC区分コード１１-文字数（文字列） */
  public static final String DATA_DCEC_CAT_CODE11_LENGTH_STRING = String
      .valueOf(DATA_DCEC_CAT_CODE11_LENGTH);

  // 時間帯コード１１
  /** データレコード：時間帯コード１１-インデックス */
  public static final int DATA_TS_CODE11_INDEX = 110;
  /** データレコード：時間帯コード１１-名称 */
  public static final String DATA_TS_CODE11_NAME = "時間帯コード１１";
  /** データレコード：時間帯コード１１-文字数 */
  public static final int DATA_TS_CODE11_LENGTH = 1;
  /** データレコード：時間帯コード１１-文字数（文字列） */
  public static final String DATA_TS_CODE11_LENGTH_STRING = String
      .valueOf(DATA_TS_CODE11_LENGTH);

  // 枝番１１
  /** データレコード：枝番１１-インデックス */
  public static final int DATA_BRANCH_NO11_INDEX = 111;
  /** データレコード：枝番１１-名称 */
  public static final String DATA_BRANCH_NO11_NAME = "枝番１１";
  /** データレコード：枝番１１-文字数 */
  public static final int DATA_BRANCH_NO11_LENGTH = 1;
  /** データレコード：枝番１１-文字数（文字列） */
  public static final String DATA_BRANCH_NO11_LENGTH_STRING = String
      .valueOf(DATA_BRANCH_NO11_LENGTH);

  // 単価明細金額１１
  /** データレコード：単価明細金額１１-インデックス */
  public static final int DATA_UP11_INDEX = 112;
  /** データレコード：単価明細金額１１-名称 */
  public static final String DATA_UP11_NAME = "単価明細金額１１";
  /** データレコード：単価明細金額１１-整数部桁数上限 */
  public static final int DATA_UP11_INTEGER = 5;
  /** データレコード：単価明細金額１１-小数部桁数 */
  public static final int DATA_UP11_FLOAT = 2;
  /** データレコード：単価明細金額１１-整数部桁数上限（文字列） */
  public static final String DATA_UP11_INTEGER_STRING = String
      .valueOf(DATA_UP11_INTEGER);
  /** データレコード：単価明細金額１１-小数部桁数（文字列） */
  public static final String DATA_UP11_FLOAT_STRING = String
      .valueOf(DATA_UP11_FLOAT);

  // DCEC区分コード１２
  /** データレコード：DCEC区分コード１２-インデックス */
  public static final int DATA_DCEC_CAT_CODE12_INDEX = 113;
  /** データレコード：DCEC区分コード１２-名称 */
  public static final String DATA_DCEC_CAT_CODE12_NAME = "DCEC区分コード１２";
  /** データレコード：DCEC区分コード１２-文字数 */
  public static final int DATA_DCEC_CAT_CODE12_LENGTH = 1;
  /** データレコード：DCEC区分コード１２-文字数（文字列） */
  public static final String DATA_DCEC_CAT_CODE12_LENGTH_STRING = String
      .valueOf(DATA_DCEC_CAT_CODE12_LENGTH);

  // 時間帯コード１２
  /** データレコード：時間帯コード１２-インデックス */
  public static final int DATA_TS_CODE12_INDEX = 114;
  /** データレコード：時間帯コード１２-名称 */
  public static final String DATA_TS_CODE12_NAME = "時間帯コード１２";
  /** データレコード：時間帯コード１２-文字数 */
  public static final int DATA_TS_CODE12_LENGTH = 1;
  /** データレコード：時間帯コード１２-文字数（文字列） */
  public static final String DATA_TS_CODE12_LENGTH_STRING = String
      .valueOf(DATA_TS_CODE12_LENGTH);

  // 枝番１２
  /** データレコード：枝番１２-インデックス */
  public static final int DATA_BRANCH_NO12_INDEX = 115;
  /** データレコード：枝番１２-名称 */
  public static final String DATA_BRANCH_NO12_NAME = "枝番１２";
  /** データレコード：枝番１２-文字数 */
  public static final int DATA_BRANCH_NO12_LENGTH = 1;
  /** データレコード：枝番１２-文字数（文字列） */
  public static final String DATA_BRANCH_NO12_LENGTH_STRING = String
      .valueOf(DATA_BRANCH_NO12_LENGTH);

  // 単価明細金額１２
  /** データレコード：単価明細金額１２-インデックス */
  public static final int DATA_UP12_INDEX = 116;
  /** データレコード：単価明細金額１２-名称 */
  public static final String DATA_UP12_NAME = "単価明細金額１２";
  /** データレコード：単価明細金額１２-整数部桁数上限 */
  public static final int DATA_UP12_INTEGER = 5;
  /** データレコード：単価明細金額１２-小数部桁数 */
  public static final int DATA_UP12_FLOAT = 2;
  /** データレコード：単価明細金額１２-整数部桁数上限（文字列） */
  public static final String DATA_UP12_INTEGER_STRING = String
      .valueOf(DATA_UP12_INTEGER);
  /** データレコード：単価明細金額１２-小数部桁数（文字列） */
  public static final String DATA_UP12_FLOAT_STRING = String
      .valueOf(DATA_UP12_FLOAT);

  // DCEC区分コード１３
  /** データレコード：DCEC区分コード１３-インデックス */
  public static final int DATA_DCEC_CAT_CODE13_INDEX = 117;
  /** データレコード：DCEC区分コード１３-名称 */
  public static final String DATA_DCEC_CAT_CODE13_NAME = "DCEC区分コード１３";
  /** データレコード：DCEC区分コード１３-文字数 */
  public static final int DATA_DCEC_CAT_CODE13_LENGTH = 1;
  /** データレコード：DCEC区分コード１３-文字数（文字列） */
  public static final String DATA_DCEC_CAT_CODE13_LENGTH_STRING = String
      .valueOf(DATA_DCEC_CAT_CODE13_LENGTH);

  // 時間帯コード１３
  /** データレコード：時間帯コード１３-インデックス */
  public static final int DATA_TS_CODE13_INDEX = 118;
  /** データレコード：時間帯コード１３-名称 */
  public static final String DATA_TS_CODE13_NAME = "時間帯コード１３";
  /** データレコード：時間帯コード１３-文字数 */
  public static final int DATA_TS_CODE13_LENGTH = 1;
  /** データレコード：時間帯コード１３-文字数（文字列） */
  public static final String DATA_TS_CODE13_LENGTH_STRING = String
      .valueOf(DATA_TS_CODE13_LENGTH);

  // 枝番１３
  /** データレコード：枝番１３-インデックス */
  public static final int DATA_BRANCH_NO13_INDEX = 119;
  /** データレコード：枝番１３-名称 */
  public static final String DATA_BRANCH_NO13_NAME = "枝番１３";
  /** データレコード：枝番１３-文字数 */
  public static final int DATA_BRANCH_NO13_LENGTH = 1;
  /** データレコード：枝番１３-文字数（文字列） */
  public static final String DATA_BRANCH_NO13_LENGTH_STRING = String
      .valueOf(DATA_BRANCH_NO13_LENGTH);

  // 単価明細金額１３
  /** データレコード：単価明細金額１３-インデックス */
  public static final int DATA_UP13_INDEX = 120;
  /** データレコード：単価明細金額１３-名称 */
  public static final String DATA_UP13_NAME = "単価明細金額１３";
  /** データレコード：単価明細金額１３-整数部桁数上限 */
  public static final int DATA_UP13_INTEGER = 5;
  /** データレコード：単価明細金額１３-小数部桁数 */
  public static final int DATA_UP13_FLOAT = 2;
  /** データレコード：単価明細金額１３-整数部桁数上限（文字列） */
  public static final String DATA_UP13_INTEGER_STRING = String
      .valueOf(DATA_UP13_INTEGER);
  /** データレコード：単価明細金額１３-小数部桁数（文字列） */
  public static final String DATA_UP13_FLOAT_STRING = String
      .valueOf(DATA_UP13_FLOAT);

  // DCEC区分コード１４
  /** データレコード：DCEC区分コード１４-インデックス */
  public static final int DATA_DCEC_CAT_CODE14_INDEX = 121;
  /** データレコード：DCEC区分コード１４-名称 */
  public static final String DATA_DCEC_CAT_CODE14_NAME = "DCEC区分コード１４";
  /** データレコード：DCEC区分コード１４-文字数 */
  public static final int DATA_DCEC_CAT_CODE14_LENGTH = 1;
  /** データレコード：DCEC区分コード１４-文字数（文字列） */
  public static final String DATA_DCEC_CAT_CODE14_LENGTH_STRING = String
      .valueOf(DATA_DCEC_CAT_CODE14_LENGTH);

  // 時間帯コード１４
  /** データレコード：時間帯コード１４-インデックス */
  public static final int DATA_TS_CODE14_INDEX = 122;
  /** データレコード：時間帯コード１４-名称 */
  public static final String DATA_TS_CODE14_NAME = "時間帯コード１４";
  /** データレコード：時間帯コード１４-文字数 */
  public static final int DATA_TS_CODE14_LENGTH = 1;
  /** データレコード：時間帯コード１４-文字数（文字列） */
  public static final String DATA_TS_CODE14_LENGTH_STRING = String
      .valueOf(DATA_TS_CODE14_LENGTH);

  // 枝番１４
  /** データレコード：枝番１４-インデックス */
  public static final int DATA_BRANCH_NO14_INDEX = 123;
  /** データレコード：枝番１４-名称 */
  public static final String DATA_BRANCH_NO14_NAME = "枝番１４";
  /** データレコード：枝番１４-文字数 */
  public static final int DATA_BRANCH_NO14_LENGTH = 1;
  /** データレコード：枝番１４-文字数（文字列） */
  public static final String DATA_BRANCH_NO14_LENGTH_STRING = String
      .valueOf(DATA_BRANCH_NO14_LENGTH);

  // 単価明細金額１４
  /** データレコード：単価明細金額１４-インデックス */
  public static final int DATA_UP14_INDEX = 124;
  /** データレコード：単価明細金額１４-名称 */
  public static final String DATA_UP14_NAME = "単価明細金額１４";
  /** データレコード：単価明細金額１４-整数部桁数上限 */
  public static final int DATA_UP14_INTEGER = 5;
  /** データレコード：単価明細金額１４-小数部桁数 */
  public static final int DATA_UP14_FLOAT = 2;
  /** データレコード：単価明細金額１４-整数部桁数上限（文字列） */
  public static final String DATA_UP14_INTEGER_STRING = String
      .valueOf(DATA_UP14_INTEGER);
  /** データレコード：単価明細金額１４-小数部桁数（文字列） */
  public static final String DATA_UP14_FLOAT_STRING = String
      .valueOf(DATA_UP14_FLOAT);

  // DCEC区分コード１５
  /** データレコード：DCEC区分コード１５-インデックス */
  public static final int DATA_DCEC_CAT_CODE15_INDEX = 125;
  /** データレコード：DCEC区分コード１５-名称 */
  public static final String DATA_DCEC_CAT_CODE15_NAME = "DCEC区分コード１５";
  /** データレコード：DCEC区分コード１５-文字数 */
  public static final int DATA_DCEC_CAT_CODE15_LENGTH = 1;
  /** データレコード：DCEC区分コード１５-文字数（文字列） */
  public static final String DATA_DCEC_CAT_CODE15_LENGTH_STRING = String
      .valueOf(DATA_DCEC_CAT_CODE15_LENGTH);

  // 時間帯コード１５
  /** データレコード：時間帯コード１５-インデックス */
  public static final int DATA_TS_CODE15_INDEX = 126;
  /** データレコード：時間帯コード１５-名称 */
  public static final String DATA_TS_CODE15_NAME = "時間帯コード１５";
  /** データレコード：時間帯コード１５-文字数 */
  public static final int DATA_TS_CODE15_LENGTH = 1;
  /** データレコード：時間帯コード１５-文字数（文字列） */
  public static final String DATA_TS_CODE15_LENGTH_STRING = String
      .valueOf(DATA_TS_CODE15_LENGTH);

  // 枝番１５
  /** データレコード：枝番１５-インデックス */
  public static final int DATA_BRANCH_NO15_INDEX = 127;
  /** データレコード：枝番１５-名称 */
  public static final String DATA_BRANCH_NO15_NAME = "枝番１５";
  /** データレコード：枝番１５-文字数 */
  public static final int DATA_BRANCH_NO15_LENGTH = 1;
  /** データレコード：枝番１５-文字数（文字列） */
  public static final String DATA_BRANCH_NO15_LENGTH_STRING = String
      .valueOf(DATA_BRANCH_NO15_LENGTH);

  // 単価明細金額１５
  /** データレコード：単価明細金額１５-インデックス */
  public static final int DATA_UP15_INDEX = 128;
  /** データレコード：単価明細金額１５-名称 */
  public static final String DATA_UP15_NAME = "単価明細金額１５";
  /** データレコード：単価明細金額１５-整数部桁数上限 */
  public static final int DATA_UP15_INTEGER = 5;
  /** データレコード：単価明細金額１５-小数部桁数 */
  public static final int DATA_UP15_FLOAT = 2;
  /** データレコード：単価明細金額１５-整数部桁数上限（文字列） */
  public static final String DATA_UP15_INTEGER_STRING = String
      .valueOf(DATA_UP15_INTEGER);
  /** データレコード：単価明細金額１５-小数部桁数（文字列） */
  public static final String DATA_UP15_FLOAT_STRING = String
      .valueOf(DATA_UP15_FLOAT);

  /** データレコード：卸取次店契約番号-インデックス */
  public static final int DATA_AGENT_CONTRACT_NO_INDEX = 129;
  /** データレコード：卸取次店契約番号-名称 */
  public static final String DATA_AGENT_CONTRACT_NO_NAME = "卸取次店契約番号";
  /** データレコード：卸取次店契約番号-文字数 */
  public static final int DATA_AGENT_CONTRACT_NO_LENGTH = 25;
  /** データレコード：卸取次店契約番号-文字数(文字列) */
  public static final String DATA_AGENT_CONTRACT_NO_LENGTH_STRING = String
      .valueOf(DATA_AGENT_CONTRACT_NO_LENGTH);
  /** データレコード：卸取次店契約番号-チェック用文字列 */
  //public static final String DATA_AGENT_CONTRACTOR_NO_MASK_STRING = "^[a-zA-Z0-9]+(-[a-zA-Z0-9]+)*$";

  /** データレコード：契約付加情報フリー項目1-インデックス */
  public static final int DATA_CONTRACT_ADDINFO_FREE_01_INDEX = 130;
  /** データレコード：契約付加情報フリー項目1-名称 */
  public static final String DATA_CONTRACT_ADDINFO_FREE_01_NAME = "契約付加情報フリー項目1";
  /** データレコード：契約付加情報フリー項目1-文字数 */
  public static final int DATA_CONTRACT_ADDINFO_FREE_01_LENGTH = 200;
  /** データレコード：契約付加情報フリー項目1-文字数(文字列) */
  public static final String DATA_CONTRACT_ADDINFO_FREE_01_LENGTH_STRING = String
      .valueOf(DATA_CONTRACT_ADDINFO_FREE_01_LENGTH);

  /** データレコード：契約付加情報フリー項目2-インデックス */
  public static final int DATA_CONTRACT_ADDINFO_FREE_02_INDEX = 131;
  /** データレコード：契約付加情報フリー項目2-名称 */
  public static final String DATA_CONTRACT_ADDINFO_FREE_02_NAME = "契約付加情報フリー項目2";
  /** データレコード：契約付加情報フリー項目2-文字数 */
  public static final int DATA_CONTRACT_ADDINFO_FREE_02_LENGTH = 200;
  /** データレコード：契約付加情報フリー項目2-文字数(文字列) */
  public static final String DATA_CONTRACT_ADDINFO_FREE_02_LENGTH_STRING = String
      .valueOf(DATA_CONTRACT_ADDINFO_FREE_02_LENGTH);

  /** データレコード：契約付加情報フリー項目3-インデックス */
  public static final int DATA_CONTRACT_ADDINFO_FREE_03_INDEX = 132;
  /** データレコード：契約付加情報フリー項目3-名称 */
  public static final String DATA_CONTRACT_ADDINFO_FREE_03_NAME = "契約付加情報フリー項目3";
  /** データレコード：契約付加情報フリー項目3-文字数 */
  public static final int DATA_CONTRACT_ADDINFO_FREE_03_LENGTH = 200;
  /** データレコード：契約付加情報フリー項目3-文字数(文字列) */
  public static final String DATA_CONTRACT_ADDINFO_FREE_03_LENGTH_STRING = String
      .valueOf(DATA_CONTRACT_ADDINFO_FREE_03_LENGTH);

  /** データレコード：契約付加情報フリー項目4-インデックス */
  public static final int DATA_CONTRACT_ADDINFO_FREE_04_INDEX = 133;
  /** データレコード：契約付加情報フリー項目4-名称 */
  public static final String DATA_CONTRACT_ADDINFO_FREE_04_NAME = "契約付加情報フリー項目4";
  /** データレコード：契約付加情報フリー項目4-文字数 */
  public static final int DATA_CONTRACT_ADDINFO_FREE_04_LENGTH = 200;
  /** データレコード：契約付加情報フリー項目4-文字数(文字列) */
  public static final String DATA_CONTRACT_ADDINFO_FREE_04_LENGTH_STRING = String
      .valueOf(DATA_CONTRACT_ADDINFO_FREE_04_LENGTH);

  /** データレコード：契約付加情報フリー項目5-インデックス */
  public static final int DATA_CONTRACT_ADDINFO_FREE_05_INDEX = 134;
  /** データレコード：契約付加情報フリー項目5-名称 */
  public static final String DATA_CONTRACT_ADDINFO_FREE_05_NAME = "契約付加情報フリー項目5";
  /** データレコード：契約付加情報フリー項目5-文字数 */
  public static final int DATA_CONTRACT_ADDINFO_FREE_05_LENGTH = 200;
  /** データレコード：契約付加情報フリー項目5-文字数(文字列) */
  public static final String DATA_CONTRACT_ADDINFO_FREE_05_LENGTH_STRING = String
      .valueOf(DATA_CONTRACT_ADDINFO_FREE_05_LENGTH);

  /** データレコード：契約付加情報フリー項目6-インデックス */
  public static final int DATA_CONTRACT_ADDINFO_FREE_06_INDEX = 135;
  /** データレコード：契約付加情報フリー項目6-名称 */
  public static final String DATA_CONTRACT_ADDINFO_FREE_06_NAME = "契約付加情報フリー項目6";
  /** データレコード：契約付加情報フリー項目6-文字数 */
  public static final int DATA_CONTRACT_ADDINFO_FREE_06_LENGTH = 200;
  /** データレコード：契約付加情報フリー項目6-文字数(文字列) */
  public static final String DATA_CONTRACT_ADDINFO_FREE_06_LENGTH_STRING = String
      .valueOf(DATA_CONTRACT_ADDINFO_FREE_06_LENGTH);

  /** データレコード：契約付加情報フリー項目7-インデックス */
  public static final int DATA_CONTRACT_ADDINFO_FREE_07_INDEX = 136;
  /** データレコード：契約付加情報フリー項目7-名称 */
  public static final String DATA_CONTRACT_ADDINFO_FREE_07_NAME = "契約付加情報フリー項目7";
  /** データレコード：契約付加情報フリー項目7-文字数 */
  public static final int DATA_CONTRACT_ADDINFO_FREE_07_LENGTH = 200;
  /** データレコード：契約付加情報フリー項目7-文字数(文字列) */
  public static final String DATA_CONTRACT_ADDINFO_FREE_07_LENGTH_STRING = String
      .valueOf(DATA_CONTRACT_ADDINFO_FREE_07_LENGTH);

  /** データレコード：契約付加情報フリー項目8-インデックス */
  public static final int DATA_CONTRACT_ADDINFO_FREE_08_INDEX = 137;
  /** データレコード：契約付加情報フリー項目8-名称 */
  public static final String DATA_CONTRACT_ADDINFO_FREE_08_NAME = "契約付加情報フリー項目8";
  /** データレコード：契約付加情報フリー項目8-文字数 */
  public static final int DATA_CONTRACT_ADDINFO_FREE_08_LENGTH = 200;
  /** データレコード：契約付加情報フリー項目8-文字数(文字列) */
  public static final String DATA_CONTRACT_ADDINFO_FREE_08_LENGTH_STRING = String
      .valueOf(DATA_CONTRACT_ADDINFO_FREE_08_LENGTH);

  /** データレコード：契約付加情報フリー項目9-インデックス */
  public static final int DATA_CONTRACT_ADDINFO_FREE_09_INDEX = 138;
  /** データレコード：契約付加情報フリー項目9-名称 */
  public static final String DATA_CONTRACT_ADDINFO_FREE_09_NAME = "契約付加情報フリー項目9";
  /** データレコード：契約付加情報フリー項目9-文字数 */
  public static final int DATA_CONTRACT_ADDINFO_FREE_09_LENGTH = 200;
  /** データレコード：契約付加情報フリー項目9-文字数(文字列) */
  public static final String DATA_CONTRACT_ADDINFO_FREE_09_LENGTH_STRING = String
      .valueOf(DATA_CONTRACT_ADDINFO_FREE_09_LENGTH);

  /** データレコード：契約付加情報フリー項目10-インデックス */
  public static final int DATA_CONTRACT_ADDINFO_FREE_10_INDEX = 139;
  /** データレコード：契約付加情報フリー項目10-名称 */
  public static final String DATA_CONTRACT_ADDINFO_FREE_10_NAME = "契約付加情報フリー項目10";
  /** データレコード：契約付加情報フリー項目10-文字数 */
  public static final int DATA_CONTRACT_ADDINFO_FREE_10_LENGTH = 200;
  /** データレコード：契約付加情報フリー項目10-文字数(文字列) */
  public static final String DATA_CONTRACT_ADDINFO_FREE_10_LENGTH_STRING = String
      .valueOf(DATA_CONTRACT_ADDINFO_FREE_10_LENGTH);

  // 更新回数
  /** データレコード：更新回数-インデックス */
  public static final int DATA_UPDATE_COUNT_INDEX = 140;
  /** データレコード：更新回数-名称 */
  public static final String DATA_UPDATE_COUNT_NAME = "更新回数";
  /** データレコード：更新回数-文字数 */
  public static final int DATA_UPDATE_COUNT_LENGTH = 10;
  /** データレコード：更新回数-文字数（文字列） */
  public static final String DATA_UPDATE_COUNT_LENGTH_STRING = String.valueOf(DATA_UPDATE_COUNT_LENGTH);

  // 登録・更新・削除区分
  /** データレコード：登録・更新・削除区分-インデックス */
  public static final int DATA_REGISTER_UPDATE_DELETE_CATEGORY_INDEX = 141;
  /** データレコード：登録・更新・削除区分-名称 */
  public static final String DATA_REGISTER_UPDATE_DELETE_CATEGORY_NAME = "登録・更新・削除区分";
  /** データレコード：登録・更新・削除区分-文字数 */
  public static final int DATA_REGISTER_UPDATE_DELETE_CATEGORY_LENGTH = 1;
  /** データレコード：登録・更新・削除区分-文字数（文字列） */
  public static final String DATA_REGISTER_UPDATE_DELETE_CATEGORY_LENGTH_STRING = String
      .valueOf(DATA_REGISTER_UPDATE_DELETE_CATEGORY_LENGTH);

  // 予備線契約開始日
  /** データレコード：予備線契約開始日-インデックス */
  public static final int DATA_RESERVE_LINE_CONTRACT_START_DATE_INDEX = 142;
  /** データレコード：予備線契約開始日-名称 */
  public static final String DATA_RESERVE_LINE_CONTRACT_START_DATE_NAME = "予備線契約開始日";

  // 予備線契約終了日
  /** データレコード：予備線契約終了日-インデックス */
  public static final int DATA_RESERVE_LINE_CONTRACT_END_DATE_INDEX = 143;
  /** データレコード：予備線契約終了日-名称 */
  public static final String DATA_RESERVE_LINE_CONTRACT_END_DATE_NAME = "予備線契約終了日";

  // 予備線容量
  /** データレコード：予備線容量-インデックス */
  public static final int DATA_RESERVE_LINE_CONTRACT_CAPACITY_INDEX = 144;
  /** データレコード：予備線容量-名称 */
  public static final String DATA_RESERVE_LINE_CONTRACT_CAPACITY_NAME = "予備線容量";
  /** データレコード：予備線容量-整数部桁数上限 */
  public static final int DATA_RESERVE_LINE_CONTRACT_CAPACITY_DIGIT_INTEGER = 6;
  /** データレコード：予備線容量-小数部桁数 */
  public static final int DATA_RESERVE_LINE_CONTRACT_CAPACITY_DIGIT_FLOAT = 2;
  /** データレコード：予備線容量-整数部桁数上限（文字列） */
  public static final String DATA_RESERVE_LINE_CONTRACT_CAPACITY_DIGIT_INTEGER_STRING = "6";
  /** データレコード：予備線容量-小数部桁数（文字列） */
  public static final String DATA_RESERVE_LINE_CONTRACT_CAPACITY_DIGIT_FLOAT_STRING = "2";

  // 予備線更新回数
  /** データレコード：予備線更新回数-インデックス */
  public static final int DATA_RESERVE_LINE_UPDATE_COUNT_INDEX = 145;
  /** データレコード：予備線更新回数-名称 */
  public static final String DATA_RESERVE_LINE_UPDATE_COUNT_NAME = "予備線更新回数";

  // 予備線登録・更新・削除区分
  /** データレコード：予備線登録・更新・削除区分-インデックス */
  public static final int DATA_RESERVE_LINE_REGISTER_UPDATE_DELETE_INDEX = 146;
  /** データレコード：予備線登録・更新・削除区分-名称 */
  public static final String DATA_RESERVE_LINE_REGISTER_UPDATE_DELETE_NAME = "予備線登録・更新・削除区分";

  // 予備電源契約開始日
  /** データレコード：予備電源契約開始日-インデックス */
  public static final int DATA_RESERVE_POWER_CONTRACT_START_DATE_INDEX = 147;
  /** データレコード：予備電源契約開始日-名称 */
  public static final String DATA_RESERVE_POWER_CONTRACT_START_DATE_NAME = "予備電源契約開始日";
  /** データレコード：予備電源契約開始日-文字数 */

  // 予備電源契約終了日
  /** データレコード：予備電源契約終了日-インデックス */
  public static final int DATA_RESERVE_POWER_CONTRACT_END_DATE_INDEX = 148;
  /** データレコード：予備電源契約終了日-名称 */
  public static final String DATA_RESERVE_POWER_CONTRACT_END_DATE_NAME = "予備電源契約終了日";

  // 予備電源容量
  /** データレコード：予備電源容量-インデックス */
  public static final int DATA_RESERVE_POWER_CONTRACT_CAPACITY_INDEX = 149;
  /** データレコード：予備電源容量-名称 */
  public static final String DATA_RESERVE_POWER_CONTRACT_CAPACITY_NAME = "予備電源容量";
  /** データレコード：予備線容量-整数部桁数上限 */
  public static final int DATA_RESERVE_POWER_CONTRACT_CAPACITY_DIGIT_INTEGER = 6;
  /** データレコード：予備線容量-小数部桁数 */
  public static final int DATA_RESERVE_POWER_CONTRACT_CAPACITY_DIGIT_FLOAT = 2;
  /** データレコード：予備線容量-整数部桁数上限（文字列） */
  public static final String DATA_RESERVE_POWER_CONTRACT_CAPACITY_DIGIT_INTEGER_STRING = "6";
  /** データレコード：予備線容量-小数部桁数（文字列） */
  public static final String DATA_RESERVE_POWER_CONTRACT_CAPACITY_DIGIT_FLOAT_STRING = "2";

  // 予備電源更新回数
  /** データレコード：予備電源更新回数-インデックス */
  public static final int DATA_RESERVE_POWER_UPDATE_COUNT_INDEX = 150;
  /** データレコード：予備電源更新回数-名称 */
  public static final String DATA_RESERVE_POWER_UPDATE_COUNT_NAME = "予備電源更新回数";

  // 予備電源登録・更新・削除区分
  /** データレコード：予備電源登録・更新・削除区分-インデックス */
  public static final int DATA_RESERVE_POWER_REGISTER_UPDATE_DELETE_INDEX = 151;
  /** データレコード：予備電源登録・更新・削除区分-名称 */
  public static final String DATA_RESERVE_POWER_REGISTER_UPDATE_DELETE_NAME = "予備電源登録・更新・削除区分";

  /** 市外局番、市内局番、加入者番号を連結し、かつハイフンを除いた最大桁 */
  public static final int PHONE_MAX = 14;

  /**
   * staticイニシャライザ.<br>
   * タイトル行の生成を行う<br>
   * インデックス=タイトル配列のインデックスになるため、番号は自動で設定される<br>
   * カラムの追加・削除があった場合に修正が必要
   */
  static {
    Map<Integer, String> titleMap = new HashMap<Integer, String>();

    // 項目を順番に入れ込んでいく
    // レコード種別は共通のものを使う
    titleMap.put(ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_INDEX,
        ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_NAME);

    titleMap.put(DATA_CONTRACT_NO_INDEX, DATA_CONTRACT_NO_NAME);
    titleMap.put(DATA_CONTRACTOR_NO_INDEX, DATA_CONTRACTOR_NO_NAME);
    titleMap.put(DATA_PAYMENT_NO_INDEX, DATA_PAYMENT_NO_NAME);
    titleMap.put(DATA_METER_LOCATION_ID_INDEX, DATA_METER_LOCATION_ID_NAME);
    titleMap.put(DATA_CONTRACT_GROUP_NO_INDEX, DATA_CONTRACT_GROUP_NO_NAME);
    titleMap.put(DATA_CONTRACT_START_DATE_INDEX,
        DATA_CONTRACT_START_DATE_NAME);
    titleMap.put(DATA_CONTRACT_END_DATE_INDEX, DATA_CONTRACT_END_DATE_NAME);
    titleMap.put(DATA_CONTRACT_END_REASON_CODE_INDEX,
        DATA_CONTRACT_END_REASON_CODE_NAME);
    titleMap.put(DATA_CONSIGNMENT_CONTRACT_CAPACITY_INDEX,
        DATA_CONSIGNMENT_CONTRACT_CAPACITY_NAME);
    titleMap.put(DATA_CONSIGNMENT_CONTRACT_CAPACITY_UNIT_INDEX,
        DATA_CONSIGNMENT_CONTRACT_CAPACITY_UNIT_NAME);
    titleMap.put(DATA_CONSIGNMENT_CONTRACT_CAPACITY_DECISION_DATE_INDEX,
        DATA_CONSIGNMENT_CONTRACT_CAPACITY_DECISION_DATE_NAME);
    titleMap.put(DATA_CHARGE_CHECK_FLAG_INDEX, DATA_CHARGE_CHECK_FLAG_NAME);
    titleMap.put(DATA_INDIVIDUAL_LEGAL_ENTITY_CATEGORY_CODE_INDEX,
        DATA_INDIVIDUAL_LEGAL_ENTITY_CATEGORY_CODE_NAME);
    titleMap.put(DATA_CONTRACT_INFORMATION_NAME_KANA_INDEX,
        DATA_CONTRACT_INFORMATION_NAME_KANA_NAME);
    titleMap.put(DATA_CONTRACT_INFORMATION_NAME1_INDEX,
        DATA_CONTRACT_INFORMATION_NAME1_NAME);
    titleMap.put(DATA_CONTRACT_INFORMATION_NAME2_INDEX,
        DATA_CONTRACT_INFORMATION_NAME2_NAME);
    titleMap.put(DATA_CONTRACT_INFORMATION_ADDRESS_POSTAL_CODE_INDEX,
        DATA_CONTRACT_INFORMATION_ADDRESS_POSTAL_CODE_NAME);
    titleMap.put(DATA_CONTRACT_INFORMATION_ADDRESS_FULL_INDEX,
        DATA_CONTRACT_INFORMATION_ADDRESS_FULL_NAME);
    titleMap.put(DATA_CONTRACT_INFORMATION_ADDRESS_BUILDING_INDEX,
        DATA_CONTRACT_INFORMATION_ADDRESS_BUILDING_NAME);
    titleMap.put(DATA_CONTRACT_INFORMATION_CATEGORY_CODE_INDEX,
        DATA_CONTRACT_INFORMATION_CATEGORY_CODE_NAME);
    titleMap.put(DATA_CONTRACT_INFORMATION_AREA_CODE_INDEX,
        DATA_CONTRACT_INFORMATION_AREA_CODE_NAME);
    titleMap.put(DATA_CONTRACT_INFORMATION_LOCAL_NO_INDEX,
        DATA_CONTRACT_INFORMATION_LOCAL_NO_NAME);
    titleMap.put(DATA_CONTRACT_INFORMATION_DIRECTORY_NO_INDEX,
        DATA_CONTRACT_INFORMATION_DIRECTORY_NO_NAME);
    titleMap.put(DATA_CONSUMER_CONTRACT_AFFILIATION_INDEX,
        DATA_CONSUMER_CONTRACT_AFFILIATION_NAME);
    titleMap.put(DATA_CONSUMER_CONTRACT_NAME_INDEX,
        DATA_CONSUMER_CONTRACT_NAME_NAME);
    titleMap.put(DATA_CONSUMER_CONTRACT_AREA_CODE_INDEX,
        DATA_CONSUMER_CONTRACT_AREA_CODE_NAME);
    titleMap.put(DATA_CONSUMER_CONTRACT_LOCAL_NO_INDEX,
        DATA_CONSUMER_CONTRACT_LOCAL_NO_NAME);
    titleMap.put(DATA_CONSUMER_CONTRACT_DIRECTORY_NO_INDEX,
        DATA_CONSUMER_CONTRACT_DIRECTORY_NO_NAME);
    titleMap.put(DATA_CHIEF_ENGINEER_OFFICER_AFFILIATION_INDEX,
        DATA_CHIEF_ENGINEER_OFFICER_AFFILIATION_NAME);
    titleMap.put(DATA_CHIEF_ENGINEER_OFFICER_NAME_INDEX,
        DATA_CHIEF_ENGINEER_OFFICER_NAME_NAME);
    titleMap.put(DATA_CHIEF_ENGINEER_OFFICER_AREA_CODE_INDEX,
        DATA_CHIEF_ENGINEER_OFFICER_AREA_CODE_NAME);
    titleMap.put(DATA_CHIEF_ENGINEER_OFFICER_LOCAL_NO_INDEX,
        DATA_CHIEF_ENGINEER_OFFICER_LOCAL_NO_NAME);
    titleMap.put(DATA_CHIEF_ENGINEER_OFFICER_DIRECTORY_NO_INDEX,
        DATA_CHIEF_ENGINEER_OFFICER_DIRECTORY_NO_NAME);
    titleMap.put(DATA_CONNECTED_SUPPLY_SERVICE_CATEGORY_CODE_INDEX,
        DATA_CONNECTED_SUPPLY_SERVICE_CATEGORY_CODE_NAME);
    titleMap.put(DATA_PS_INFO_CODE_INDEX, DATA_PS_INFO_CODE_INDEX_NAME);
    titleMap.put(DATA_NOTE_INDEX, DATA_NOTE_NAME);
    titleMap.put(DATA_REAL_QUANTITY_NEED_FLAG_INDEX,
        DATA_REAL_QUANTITY_NEED_FLAG_NAME);
    titleMap.put(DATA_FREE1_INDEX, DATA_FREE1_NAME);
    titleMap.put(DATA_FREE2_INDEX, DATA_FREE2_NAME);
    titleMap.put(DATA_FREE3_INDEX, DATA_FREE3_NAME);
    titleMap.put(DATA_FREE4_INDEX, DATA_FREE4_NAME);
    titleMap.put(DATA_FREE5_INDEX, DATA_FREE5_NAME);
    titleMap.put(DATA_FREE6_INDEX, DATA_FREE6_NAME);
    titleMap.put(DATA_FREE7_INDEX, DATA_FREE7_NAME);
    titleMap.put(DATA_FREE8_INDEX, DATA_FREE8_NAME);
    titleMap.put(DATA_FREE9_INDEX, DATA_FREE9_NAME);
    titleMap.put(DATA_FREE10_INDEX, DATA_FREE10_NAME);
    titleMap.put(DATA_FREE11_INDEX, DATA_FREE11_NAME);
    titleMap.put(DATA_FREE12_INDEX, DATA_FREE12_NAME);
    titleMap.put(DATA_FREE13_INDEX, DATA_FREE13_NAME);
    titleMap.put(DATA_FREE14_INDEX, DATA_FREE14_NAME);
    titleMap.put(DATA_CONSIGNMENT_USE_ITEM1_INDEX,
        DATA_CONSIGNMENT_USE_ITEM1_NAME);
    titleMap.put(DATA_CONSIGNMENT_USE_ITEM2_INDEX,
        DATA_CONSIGNMENT_USE_ITEM2_NAME);
    titleMap.put(DATA_CONSIGNMENT_USE_ITEM3_INDEX,
        DATA_CONSIGNMENT_USE_ITEM3_NAME);
    titleMap.put(DATA_OUR_MANAGEMENT_PERSON_IN_CHARGE_CODE_INDEX,
        DATA_OUR_MANAGEMENT_PERSON_IN_CHARGE_CODE_NAME);
    titleMap.put(DATA_OUR_MANAGEMENT_DEPARTMENT_CODE_INDEX,
        DATA_OUR_MANAGEMENT_DEPARTMENT_CODE_NAME);
    titleMap.put(DATA_BUSINESS_TYPE_CODE_INDEX,
        DATA_BUSINESS_TYPE_CODE_NAME);
    titleMap.put(DATA_SALES_CONSIGNMENT_CODE_INDEX,
        DATA_SALES_CONSIGNMENT_CODE_NAME);
    titleMap.put(DATA_SALES_DEPARTMENT_CODE_INDEX, DATA_SALES_DEPARTMENT_CODE_NAME);
    titleMap.put(DATA_SALES_CONTACT_CODE_INDEX, DATA_SALES_CONTACT_CODE_NAME);
    titleMap.put(DATA_APPLY_START_DATE_INDEX, DATA_APPLY_START_DATE_NAME);
    titleMap.put(DATA_RATE_MENU_ID_INDEX, DATA_RATE_MENU_ID_NAME);
    titleMap.put(DATA_CONTRACT_CAPACITY_INDEX, DATA_CONTRACT_CAPACITY_NAME);
    titleMap.put(DATA_CONTRACT_CHANGE_REASON_INDEX,
        DATA_CONTRACT_CHANGE_REASON_NAME);
    titleMap.put(DATA_VOLTAGE_CAT_CODE_INDEX,
        DATA_VOLTAGE_CAT_CODE_NAME);
    titleMap.put(DATA_CCDECISION_CATEGORY_CODE_INDEX,
        DATA_CCDECISION_CATEGORY_CODE_NAME);
    titleMap.put(DATA_UP_CAT_CODE_INDEX,
        DATA_UP_CAT_CODE_NAME);
    titleMap.put(DATA_MMC_INDEX,
        DATA_MMC_NAME);
    titleMap.put(DATA_DCEC_CAT_CODE1_INDEX, DATA_DCEC_CAT_CODE1_NAME);
    titleMap.put(DATA_TS_CODE1_INDEX, DATA_TS_CODE1_NAME);
    titleMap.put(DATA_BRANCH_NO1_INDEX, DATA_BRANCH_NO1_NAME);
    titleMap.put(DATA_UP1_INDEX, DATA_UP1_NAME);
    titleMap.put(DATA_DCEC_CAT_CODE2_INDEX, DATA_DCEC_CAT_CODE2_NAME);
    titleMap.put(DATA_TS_CODE2_INDEX, DATA_TS_CODE2_NAME);
    titleMap.put(DATA_BRANCH_NO2_INDEX, DATA_BRANCH_NO2_NAME);
    titleMap.put(DATA_UP2_INDEX, DATA_UP2_NAME);
    titleMap.put(DATA_DCEC_CAT_CODE3_INDEX, DATA_DCEC_CAT_CODE3_NAME);
    titleMap.put(DATA_TS_CODE3_INDEX, DATA_TS_CODE3_NAME);
    titleMap.put(DATA_BRANCH_NO3_INDEX, DATA_BRANCH_NO3_NAME);
    titleMap.put(DATA_UP3_INDEX, DATA_UP3_NAME);
    titleMap.put(DATA_DCEC_CAT_CODE4_INDEX, DATA_DCEC_CAT_CODE4_NAME);
    titleMap.put(DATA_TS_CODE4_INDEX, DATA_TS_CODE4_NAME);
    titleMap.put(DATA_BRANCH_NO4_INDEX, DATA_BRANCH_NO4_NAME);
    titleMap.put(DATA_UP4_INDEX, DATA_UP4_NAME);
    titleMap.put(DATA_DCEC_CAT_CODE5_INDEX, DATA_DCEC_CAT_CODE5_NAME);
    titleMap.put(DATA_TS_CODE5_INDEX, DATA_TS_CODE5_NAME);
    titleMap.put(DATA_BRANCH_NO5_INDEX, DATA_BRANCH_NO5_NAME);
    titleMap.put(DATA_UP5_INDEX, DATA_UP5_NAME);
    titleMap.put(DATA_DCEC_CAT_CODE6_INDEX, DATA_DCEC_CAT_CODE6_NAME);
    titleMap.put(DATA_TS_CODE6_INDEX, DATA_TS_CODE6_NAME);
    titleMap.put(DATA_BRANCH_NO6_INDEX, DATA_BRANCH_NO6_NAME);
    titleMap.put(DATA_UP6_INDEX, DATA_UP6_NAME);
    titleMap.put(DATA_DCEC_CAT_CODE7_INDEX, DATA_DCEC_CAT_CODE7_NAME);
    titleMap.put(DATA_TS_CODE7_INDEX, DATA_TS_CODE7_NAME);
    titleMap.put(DATA_BRANCH_NO7_INDEX, DATA_BRANCH_NO7_NAME);
    titleMap.put(DATA_UP7_INDEX, DATA_UP7_NAME);
    titleMap.put(DATA_DCEC_CAT_CODE8_INDEX, DATA_DCEC_CAT_CODE8_NAME);
    titleMap.put(DATA_TS_CODE8_INDEX, DATA_TS_CODE8_NAME);
    titleMap.put(DATA_BRANCH_NO8_INDEX, DATA_BRANCH_NO8_NAME);
    titleMap.put(DATA_UP8_INDEX, DATA_UP8_NAME);
    titleMap.put(DATA_DCEC_CAT_CODE9_INDEX, DATA_DCEC_CAT_CODE9_NAME);
    titleMap.put(DATA_TS_CODE9_INDEX, DATA_TS_CODE9_NAME);
    titleMap.put(DATA_BRANCH_NO9_INDEX, DATA_BRANCH_NO9_NAME);
    titleMap.put(DATA_UP9_INDEX, DATA_UP9_NAME);
    titleMap.put(DATA_DCEC_CAT_CODE10_INDEX, DATA_DCEC_CAT_CODE10_NAME);
    titleMap.put(DATA_TS_CODE10_INDEX, DATA_TS_CODE10_NAME);
    titleMap.put(DATA_BRANCH_NO10_INDEX, DATA_BRANCH_NO10_NAME);
    titleMap.put(DATA_UP10_INDEX, DATA_UP10_NAME);
    titleMap.put(DATA_DCEC_CAT_CODE11_INDEX, DATA_DCEC_CAT_CODE11_NAME);
    titleMap.put(DATA_TS_CODE11_INDEX, DATA_TS_CODE11_NAME);
    titleMap.put(DATA_BRANCH_NO11_INDEX, DATA_BRANCH_NO11_NAME);
    titleMap.put(DATA_UP11_INDEX, DATA_UP11_NAME);
    titleMap.put(DATA_DCEC_CAT_CODE12_INDEX, DATA_DCEC_CAT_CODE12_NAME);
    titleMap.put(DATA_TS_CODE12_INDEX, DATA_TS_CODE12_NAME);
    titleMap.put(DATA_BRANCH_NO12_INDEX, DATA_BRANCH_NO12_NAME);
    titleMap.put(DATA_UP12_INDEX, DATA_UP12_NAME);
    titleMap.put(DATA_DCEC_CAT_CODE13_INDEX, DATA_DCEC_CAT_CODE13_NAME);
    titleMap.put(DATA_TS_CODE13_INDEX, DATA_TS_CODE13_NAME);
    titleMap.put(DATA_BRANCH_NO13_INDEX, DATA_BRANCH_NO13_NAME);
    titleMap.put(DATA_UP13_INDEX, DATA_UP13_NAME);
    titleMap.put(DATA_DCEC_CAT_CODE14_INDEX, DATA_DCEC_CAT_CODE14_NAME);
    titleMap.put(DATA_TS_CODE14_INDEX, DATA_TS_CODE14_NAME);
    titleMap.put(DATA_BRANCH_NO14_INDEX, DATA_BRANCH_NO14_NAME);
    titleMap.put(DATA_UP14_INDEX, DATA_UP14_NAME);
    titleMap.put(DATA_DCEC_CAT_CODE15_INDEX, DATA_DCEC_CAT_CODE15_NAME);
    titleMap.put(DATA_TS_CODE15_INDEX, DATA_TS_CODE15_NAME);
    titleMap.put(DATA_BRANCH_NO15_INDEX, DATA_BRANCH_NO15_NAME);
    titleMap.put(DATA_UP15_INDEX, DATA_UP15_NAME);
    titleMap.put(DATA_AGENT_CONTRACT_NO_INDEX, DATA_AGENT_CONTRACT_NO_NAME);
    titleMap.put(DATA_CONTRACT_ADDINFO_FREE_01_INDEX, DATA_CONTRACT_ADDINFO_FREE_01_NAME);
    titleMap.put(DATA_CONTRACT_ADDINFO_FREE_02_INDEX, DATA_CONTRACT_ADDINFO_FREE_02_NAME);
    titleMap.put(DATA_CONTRACT_ADDINFO_FREE_03_INDEX, DATA_CONTRACT_ADDINFO_FREE_03_NAME);
    titleMap.put(DATA_CONTRACT_ADDINFO_FREE_04_INDEX, DATA_CONTRACT_ADDINFO_FREE_04_NAME);
    titleMap.put(DATA_CONTRACT_ADDINFO_FREE_05_INDEX, DATA_CONTRACT_ADDINFO_FREE_05_NAME);
    titleMap.put(DATA_CONTRACT_ADDINFO_FREE_06_INDEX, DATA_CONTRACT_ADDINFO_FREE_06_NAME);
    titleMap.put(DATA_CONTRACT_ADDINFO_FREE_07_INDEX, DATA_CONTRACT_ADDINFO_FREE_07_NAME);
    titleMap.put(DATA_CONTRACT_ADDINFO_FREE_08_INDEX, DATA_CONTRACT_ADDINFO_FREE_08_NAME);
    titleMap.put(DATA_CONTRACT_ADDINFO_FREE_09_INDEX, DATA_CONTRACT_ADDINFO_FREE_09_NAME);
    titleMap.put(DATA_CONTRACT_ADDINFO_FREE_10_INDEX, DATA_CONTRACT_ADDINFO_FREE_10_NAME);
    titleMap.put(DATA_UPDATE_COUNT_INDEX, DATA_UPDATE_COUNT_NAME);
    titleMap.put(DATA_REGISTER_UPDATE_DELETE_CATEGORY_INDEX,
        DATA_REGISTER_UPDATE_DELETE_CATEGORY_NAME);
    titleMap.put(DATA_RESERVE_LINE_CONTRACT_START_DATE_INDEX, DATA_RESERVE_LINE_CONTRACT_START_DATE_NAME);
    titleMap.put(DATA_RESERVE_LINE_CONTRACT_END_DATE_INDEX, DATA_RESERVE_LINE_CONTRACT_END_DATE_NAME);
    titleMap.put(DATA_RESERVE_LINE_CONTRACT_CAPACITY_INDEX, DATA_RESERVE_LINE_CONTRACT_CAPACITY_NAME);
    titleMap.put(DATA_RESERVE_LINE_UPDATE_COUNT_INDEX, DATA_RESERVE_LINE_UPDATE_COUNT_NAME);
    titleMap.put(DATA_RESERVE_LINE_REGISTER_UPDATE_DELETE_INDEX, DATA_RESERVE_LINE_REGISTER_UPDATE_DELETE_NAME);
    titleMap.put(DATA_RESERVE_POWER_CONTRACT_START_DATE_INDEX, DATA_RESERVE_POWER_CONTRACT_START_DATE_NAME);
    titleMap.put(DATA_RESERVE_POWER_CONTRACT_END_DATE_INDEX, DATA_RESERVE_POWER_CONTRACT_END_DATE_NAME);
    titleMap.put(DATA_RESERVE_POWER_CONTRACT_CAPACITY_INDEX, DATA_RESERVE_POWER_CONTRACT_CAPACITY_NAME);
    titleMap.put(DATA_RESERVE_POWER_UPDATE_COUNT_INDEX, DATA_RESERVE_POWER_UPDATE_COUNT_NAME);
    titleMap.put(DATA_RESERVE_POWER_REGISTER_UPDATE_DELETE_INDEX, DATA_RESERVE_POWER_REGISTER_UPDATE_DELETE_NAME);

    // タイトル文字列に書き換える
    Iterator<Integer> it = titleMap.keySet().iterator();
    String[] titleArray = new String[titleMap.size()];
    while (it.hasNext()) {
      Integer key = it.next();
      titleArray[key] = titleMap.get(key);
    }

    DATA_TITLE_ROW = titleArray;
    DATA_COLUMN_COUNT = DATA_TITLE_ROW.length;
  }

}
