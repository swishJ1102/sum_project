package jp.co.unisys.enability.cis.business.kj.model;

import java.math.BigDecimal;
import java.util.List;

import jp.co.unisys.enability.cis.entity.common.Rqh;

/**
 * 実量歴管理照会と更新で、条件および結果を格納するビジネスBean
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * 実量歴管理ビジネス
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RealQuantityHistoryBusinessBean {

  /**
   * 契約IDを保有する。
   */
  private Integer contractId;

  /**
   * 対象年月を保有する。
   */
  private String coveredPeriod;

  /**
   * 最大電力（手入力）を保有する。
   */
  private BigDecimal pkwManual;

  /**
   * 最大電力を保有する。
   */
  private BigDecimal pkw;

  /**
   * 更新回数を保有する。
   */
  private Integer updateCount;

  /**
   * 減設フラグを保有する。
   */
  private String rccFlg;

  /**
   * 実量歴管理リストを保有する。
   */
  private List<Rqh> realQuantityHistoryList;

  /**
   * 料金ステータスコードを保有する。
   */
  private String csCode;

  /**
   * リターンコードを保有する。
   */
  private String returnCode;

  /**
   * メッセージを保有する。
   */
  private String message;

  /**
   * 契約IDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約IDを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約ID
   */
  public Integer getContractId() {
    return this.contractId;
  }

  /**
   * 契約IDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約IDを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractId
   *          契約ID
   */
  public void setContractId(Integer contractId) {
    this.contractId = contractId;
  }

  /**
   * 対象年月のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 対象年月を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 対象年月
   */
  public String getCoveredPeriod() {
    return this.coveredPeriod;
  }

  /**
   * 対象年月のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 対象年月を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param coveredPeriod
   *          対象年月
   */
  public void setCoveredPeriod(String coveredPeriod) {
    this.coveredPeriod = coveredPeriod;
  }

  /**
   * 最大電力（手入力）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 最大電力（手入力）を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 最大電力（手入力）
   */
  public BigDecimal getPkwManual() {
    return this.pkwManual;
  }

  /**
   * 最大電力（手入力）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 最大電力（手入力）を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param pkwManual
   *          最大電力（手入力）
   */
  public void setPkwManual(BigDecimal pkwManual) {
    this.pkwManual = pkwManual;
  }

  /**
   * 最大電力のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 最大電力を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 最大電力
   */
  public BigDecimal getPkw() {
    return this.pkw;
  }

  /**
   * 最大電力のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 最大電力を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param pkw
   *          最大電力
   */
  public void setPkw(BigDecimal pkw) {
    this.pkw = pkw;
  }

  /**
   * 更新回数のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 更新回数を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 更新回数
   */
  public Integer getUpdateCount() {
    return this.updateCount;
  }

  /**
   * 更新回数のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 更新回数を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param updateCount
   *          更新回数
   */
  public void setUpdateCount(Integer updateCount) {
    this.updateCount = updateCount;
  }

  /**
   * 減設フラグのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 減設フラグを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 減設フラグ
   */
  public String getRccFlg() {
    return this.rccFlg;
  }

  /**
   * 減設フラグのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 減設フラグを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param rccFlg
   *          減設フラグ
   */
  public void setRccFlg(String rccFlg) {
    this.rccFlg = rccFlg;
  }

  /**
   * 実量歴管理リストのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 実量歴管理リストを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 実量歴管理リスト
   */
  public List<Rqh> getRealQuantityHistoryList() {
    return this.realQuantityHistoryList;
  }

  /**
   * 実量歴管理リストのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 実量歴管理リストを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param realQuantityHistoryList
   *          実量歴管理リスト
   */
  public void setRealQuantityHistoryList(List<Rqh> realQuantityHistoryList) {
    this.realQuantityHistoryList = realQuantityHistoryList;
  }

  /**
   * 料金ステータスコードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金ステータスコードを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 料金ステータスコード
   */
  public String getCsCode() {
    return this.csCode;
  }

  /**
   * 料金ステータスコードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金ステータスコードを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param csCode
   *          料金ステータスコード
   */
  public void setCsCode(String csCode) {
    this.csCode = csCode;
  }

  /**
   * リターンコードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return リターンコード
   */
  public String getReturnCode() {
    return this.returnCode;
  }

  /**
   * リターンコードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param returnCode
   *          リターンコード
   */
  public void setReturnCode(String returnCode) {
    this.returnCode = returnCode;
  }

  /**
   * メッセージのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return メッセージ
   */
  public String getMessage() {
    return this.message;
  }

  /**
   * メッセージのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param message
   *          メッセージ
   */
  public void setMessage(String message) {
    this.message = message;
  }

}
