/*-------------------------------------------------------------------------------
 * All Rights Reserved. Copyright(C) Nihon Unisys, Ltd.
 * vendor : Nihon Unisys, Ltd.
 * create : 2016/04/20
 *-----------------------------------------------------------------------------*/
package jp.co.unisys.enability.cis.business.rk.model;

import java.util.List;

/**
 * 使用量CSV仕訳ビジネスの使用量ファイル情報を保持するBeanクラス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_LowPowerUsageQuantityBean {

  /**
   * 供給地点特定番号を保有する。
   */
  private String spotNo;

  /**
   * 使用量ヘッダ情報リストを保有する。
   */
  private List<RK_UsageHeaderInfoBean> usageHeaderInfoList;

  /**
   * 低圧使用量ファイル.供給地点特定番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 低圧使用量ファイル.供給地点特定番号を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 低圧使用量ファイル.供給地点特定番号
   */
  public String getSpotno() {
    return spotNo;
  }

  /**
   * 低圧使用量ファイル.供給地点特定番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 低圧使用量ファイル.供給地点特定番号を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return spotNo 低圧使用量ファイル.供給地点特定番号
   */
  public void setSpotno(String spotNo) {
    this.spotNo = spotNo;

  }

  /**
   * 低圧使用量ファイル.ヘッダのリストのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 低圧使用量ファイル.ヘッダのリストを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 低圧使用量ファイル.ヘッダのリスト
   */
  public List<RK_UsageHeaderInfoBean> getUsageheaderinfolist() {
    return usageHeaderInfoList;
  }

  /**
   * 低圧使用量ファイル.ヘッダのリストのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 低圧使用量ファイル.ヘッダのリストを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return usageHeaderInfoList 低圧使用量ファイル.ヘッダのリスト
   */
  public void setUsageheaderinfolist(List<RK_UsageHeaderInfoBean> usageHeaderInfoList) {
    this.usageHeaderInfoList = usageHeaderInfoList;

  }
}
