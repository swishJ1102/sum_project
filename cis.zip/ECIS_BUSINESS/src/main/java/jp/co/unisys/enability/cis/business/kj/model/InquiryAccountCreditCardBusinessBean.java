package jp.co.unisys.enability.cis.business.kj.model;

import java.util.List;

import jp.co.unisys.enability.cis.entity.kj.KJ_InquiryAccountCreditCardInformationEntityBean;

/**
 * 口座クレカ情報一覧照会で、照会結果を格納するビジネスBean
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * 口座クレカ情報ビジネス
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class InquiryAccountCreditCardBusinessBean {

  /**
   * 契約者IDを保有する。
   */
  private Integer contractorId;

  /**
   * 契約番号を保有する。
   */
  private String contractorNo;

  /**
   * 口座クレカ利用状況を保有する。
   */
  private String accountCreditCategoryUseSts;

  /**
   * 口座クレカIDを保有する。
   */
  private Integer accountCreditId;

  /**
   * 決済アクセスキーを保有する。
   */
  private String accessKey;

  /**
   * 口座クレカ情報リストを保有する。
   */
  private List<KJ_InquiryAccountCreditCardInformationEntityBean> accountCreditCardInformationList;

  /**
   * リターンコードを保有する。
   */
  private String returnCode;

  /**
   * メッセージを保有する。
   */
  private String message;

  /**
   * 契約者IDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者IDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者ID
   */
  public Integer getContractorId() {
    return this.contractorId;
  }

  /**
   * 契約者IDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者IDを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorId
   *          契約者ID
   */
  public void setContractorId(Integer contractorId) {
    this.contractorId = contractorId;
  }

  /**
   * 契約番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約番号を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約番号
   */
  public String getContractorNo() {
    return this.contractorNo;
  }

  /**
   * 契約番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約番号を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorNo
   *          契約番号
   */
  public void setContractorNo(String contractorNo) {
    this.contractorNo = contractorNo;
  }

  /**
   * 口座クレカ利用状況のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 口座クレカ利用状況を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 口座クレカ利用状況
   */
  public String getAccountCreditCategoryUseSts() {
    return this.accountCreditCategoryUseSts;
  }

  /**
   * 口座クレカ利用状況のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 口座クレカ利用状況を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param accountCreditCategoryUseSts
   *          口座クレカ利用状況
   */
  public void setAccountCreditCategoryUseSts(
      String accountCreditCategoryUseSts) {
    this.accountCreditCategoryUseSts = accountCreditCategoryUseSts;
  }

  /**
   * 口座クレカIDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 口座クレカIDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 口座クレカID
   */
  public Integer getAccountCreditId() {
    return this.accountCreditId;
  }

  /**
   * 口座クレカIDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 口座クレカIDを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param accountCreditId
   *          口座クレカID
   */
  public void setAccountCreditId(Integer accountCreditId) {
    this.accountCreditId = accountCreditId;
  }

  /**
   * 決済アクセスキーのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 決済アクセスキーを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 決済アクセスキー
   */
  public String getAccessKey() {
    return this.accessKey;
  }

  /**
   * 決済アクセスキーのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 決済アクセスキーを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param accessKey
   *          決済アクセスキー
   */
  public void setAccessKey(String accessKey) {
    this.accessKey = accessKey;
  }

  /**
   * 口座クレカ情報リストのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 口座クレカ情報リストを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 口座クレカ情報リスト
   */
  public List<KJ_InquiryAccountCreditCardInformationEntityBean> getAccountCreditCardInformationList() {
    return this.accountCreditCardInformationList;
  }

  /**
   * 口座クレカ情報リストのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 口座クレカ情報リストを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param AccountCreditCardInformationList
   *          口座クレカ情報リスト
   */
  public void setAccountCreditCardInformationList(
      List<KJ_InquiryAccountCreditCardInformationEntityBean> accountCreditCardInformationList) {
    this.accountCreditCardInformationList = accountCreditCardInformationList;
  }

  /**
   * リターンコードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return リターンコード
   */
  public String getReturnCode() {
    return this.returnCode;
  }

  /**
   * リターンコードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param returnCode
   *          リターンコード
   */
  public void setReturnCode(String returnCode) {
    this.returnCode = returnCode;
  }

  /**
   * メッセージのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return メッセージ
   */
  public String getMessage() {
    return this.message;
  }

  /**
   * メッセージのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param message
   *          メッセージ
   */
  public void setMessage(String message) {
    this.message = message;
  }

}
