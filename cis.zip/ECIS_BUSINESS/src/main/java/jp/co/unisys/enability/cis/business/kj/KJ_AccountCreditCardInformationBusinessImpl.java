package jp.co.unisys.enability.cis.business.kj;

import java.io.File;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DuplicateKeyException;

import jp.co.unisys.enability.cis.business.common.DateBusiness;
import jp.co.unisys.enability.cis.business.gk.AccountCreditCardInformationFileRegistValidator;
import jp.co.unisys.enability.cis.business.gk.ContractManagementInformationFileHeaderValidator;
import jp.co.unisys.enability.cis.business.kj.model.ContractManagementInformationFileConfigAccountCreditCard;
import jp.co.unisys.enability.cis.business.kj.model.ContractManagementInformationFileConfigCommon;
import jp.co.unisys.enability.cis.business.kj.model.CsvFileCheckAccountCreditCardBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.DeleteAccountCreditCardBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.DownloadAccountCreditCardBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.InquiryAccountCreditCardBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.InquiryContractorBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.RegistAccountCreditCardBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.UpdateAccountCreditCardBusinessBean;
import jp.co.unisys.enability.cis.common.Exception.BusinessLogicException;
import jp.co.unisys.enability.cis.common.Exception.SystemException;
import jp.co.unisys.enability.cis.common.util.KJ_CommonUtil;
import jp.co.unisys.enability.cis.common.util.StringConvertUtil;
import jp.co.unisys.enability.cis.common.util.ThreadContext;
import jp.co.unisys.enability.cis.common.util.constants.ECISCodeConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISKJConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISReturnCodeConstants;
import jp.co.unisys.enability.cis.entity.common.AcCatM;
import jp.co.unisys.enability.cis.entity.common.AcInformation;
import jp.co.unisys.enability.cis.entity.common.AcInformationExample;
import jp.co.unisys.enability.cis.entity.common.BtOfAccountM;
import jp.co.unisys.enability.cis.entity.common.BtOfAccountMExample;
import jp.co.unisys.enability.cis.entity.common.CreBrandM;
import jp.co.unisys.enability.cis.entity.common.OurMngBankM;
import jp.co.unisys.enability.cis.entity.common.OurMngBankMExample;
import jp.co.unisys.enability.cis.entity.common.OurMngBankMKey;
import jp.co.unisys.enability.cis.entity.kj.KJ_AccountCreditCardInformationFileEntityBean;
import jp.co.unisys.enability.cis.entity.kj.KJ_InquiryAccountCreditCardInformationEntityBean;
import jp.co.unisys.enability.cis.mapper.common.AcCatMMapper;
import jp.co.unisys.enability.cis.mapper.common.AcInformationMapper;
import jp.co.unisys.enability.cis.mapper.common.BtOfAccountMMapper;
import jp.co.unisys.enability.cis.mapper.common.CreBrandMMapper;
import jp.co.unisys.enability.cis.mapper.common.OurMngBankMMapper;
import jp.co.unisys.enability.cis.mapper.kj.AccountCreditCardInformationCommonMapper;
import jp.co.unisys.enability.cis.mapper.kj.Custom_PaymentInformationCommonMapper;
import jp.sf.orangesignal.csv.Csv;
import jp.sf.orangesignal.csv.handlers.ColumnPositionMapListHandler;

/**
 * 口座クレカ情報ビジネス
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.kj.KJ_AccountCreditCardInformationBusiness
 */
public class KJ_AccountCreditCardInformationBusinessImpl implements
    KJ_AccountCreditCardInformationBusiness {

  /**
   * メッセージプロパティ(DI)
   */
  private MessageSource messageSource;

  /**
   * 口座クレカ情報一覧共通マッパー(DI)
   */
  private AccountCreditCardInformationCommonMapper accountCreditCardInformationCommonMapper;

  /**
   * 口座クレカ情報マッパー(DI)
   */
  private AcInformationMapper acInformationMapper;

  /**
   * 支払情報共通マッパー_カスタム(DI)
   */
  private Custom_PaymentInformationCommonMapper customPaymentInformationCommonMapper;

  /**
   * 口座クレカ区分マスタマッパー(DI)
   */
  private AcCatMMapper acCatMMapper;

  /**
   * クレカブランドマスタマッパー(DI)
   */
  private CreBrandMMapper creBrandMMapper;

  /**
   * 自社金融機関マスタマッパー(DI)
   */
  private OurMngBankMMapper ourMngBankMMapper;

  /**
   * 金融機関預金種目マスタマッパー(DI)
   */
  private BtOfAccountMMapper btOfAccountMMapper;

  /**
   * 契約者情報共通ビジネス(DI)
   */
  private KJ_ContractorInformationBusiness kjContractorInformationBusiness;

  /**
   * 日付関連共通ビジネス(DI)
   */
  private DateBusiness dateBusiness;

  /**
   * 契約管理情報ファイルヘッダーバリデーター(DI)
   */
  private ContractManagementInformationFileHeaderValidator contractManagementInformationFileHeaderValidator;

  /**
   * 口座クレカ情報登録バリデーション(DI)
   */
  private AccountCreditCardInformationFileRegistValidator accountCreditCardInformationFileRegistValidator;

  /**
   * ログマネジャー
   */
  private static Logger logger = LogManager.getLogger();

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.kj.
   * KJ_AccountCreditCardInformationBusiness
   * #inquiry(jp.co.unisys.enability.cis
   * .business.kj.model.InquiryAccountCreditCardBusinessBean)
   */
  @Override
  public InquiryAccountCreditCardBusinessBean inquiry(
      InquiryAccountCreditCardBusinessBean inquiryAccountCreditCardBusinessBean) {

    String errMsg = null;
    try {
      // システムエラーメッセージを取得
      errMsg = messageSource.getMessage(KJ_CommonUtil
          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G017),
          null, Locale.getDefault());

      // 《口座クレカ情報共通マッパー》.口座クレカ情報一覧取得を呼び出す。
      Map<String, Object> exampleMap = new HashMap<String, Object>();
      // 引数1： 《口座クレカ情報照会BusinessBean》.契約者ID
      exampleMap.put("contractorId",
          inquiryAccountCreditCardBusinessBean.getContractorId());
      // 引数2： 《口座クレカ情報照会BusinessBean》.契約者番号
      exampleMap.put("contractorNo",
          inquiryAccountCreditCardBusinessBean.getContractorNo());
      // 引数3： 《口座クレカ情報照会BusinessBean》.口座クレカ利用状況
      exampleMap.put("accountCreditCategoryUseSts",
          inquiryAccountCreditCardBusinessBean
              .getAccountCreditCategoryUseSts());
      // 引数4： 《口座クレカ情報照会BusinessBean》.口座クレカID
      exampleMap.put("accountCreditId",
          inquiryAccountCreditCardBusinessBean.getAccountCreditId());
      // 引数5： 《口座クレカ情報照会BusinessBean》.決済アクセスキー
      exampleMap.put("accessKey",
          inquiryAccountCreditCardBusinessBean.getAccessKey());
      List<KJ_InquiryAccountCreditCardInformationEntityBean> accountCreditCardInformationList = accountCreditCardInformationCommonMapper
          .selectAccountCreditCardInformation(exampleMap);

      // 照会結果設定
      inquiryAccountCreditCardBusinessBean
          .setAccountCreditCardInformationList(accountCreditCardInformationList);

      // 正常終了
      inquiryAccountCreditCardBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);

    } catch (DataAccessException e) {
      logger.error(messageSource.getMessage("error.E1129", null,
          Locale.getDefault()), e);
      // 口座クレカ情報一覧照会BusinessBean.リターンコードに（G017）を設定し処理を終了する。
      inquiryAccountCreditCardBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      inquiryAccountCreditCardBusinessBean.setMessage(errMsg);
    } catch (NoSuchMessageException e) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, e);
      inquiryAccountCreditCardBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      inquiryAccountCreditCardBusinessBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
    }
    return inquiryAccountCreditCardBusinessBean;
  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.kj.
   * KJ_AccountCreditCardInformationBusiness
   * #regist(jp.co.unisys.enability.cis.
   * business.kj.model.RegistAccountCreditCardBusinessBean)
   */
  @Override
  public RegistAccountCreditCardBusinessBean regist(
      RegistAccountCreditCardBusinessBean registAccountCreditCardBusinessBean) {

    String errMsg = null;
    String duplicateKeyMsg = null;
    try {
      // システムエラーメッセージを取得
      errMsg = messageSource.getMessage(KJ_CommonUtil
          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G017),
          null, Locale.getDefault());
      duplicateKeyMsg = messageSource.getMessage(KJ_CommonUtil
          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D023),
          null, Locale.getDefault());

      // コード存在チェック
      String accountCreditCatCode = registAccountCreditCardBusinessBean
          .getAccountCreditCategoryCode();
      // 《口座クレカ情報登録BusinessBean》.口座クレカ区分コードの存在チェックを行う。
      if (StringUtils.isNotEmpty(accountCreditCatCode)) {

        // 《口座クレカ区分マスタマッパー》.検索(主キー）を呼び出し。
        // 引数：《口座クレカ情報登録BusinessBean》.口座クレカ区分コード
        AcCatM accountCreditCategory = acCatMMapper
            .selectByPrimaryKey(accountCreditCatCode);

        // 返却値が0件の場合
        if (accountCreditCategory == null) {

          // 《口座クレカ情報登録BusinessBean》.リターンコードにP022を設定し、返却する。
          registAccountCreditCardBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P022);
          registAccountCreditCardBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P022),
                  null, Locale.getDefault()));
          return registAccountCreditCardBusinessBean;
        }
      }

      // 《口座クレカ情報登録BusinessBean》.クレカブランドコードがNULLまたは空文字のいずれかでない場合、以下の処理を行う。
      String creditCardBrandCode = registAccountCreditCardBusinessBean
          .getCreditCardBrandCode();
      if (StringUtils.isNotEmpty(creditCardBrandCode)) {
        // 《クレカブランドマスタマッパー》.検索(主キー）を呼び出し。
        // 引数：《口座クレカ情報登録BusinessBean》.クレカブランドコード
        CreBrandM creditCardBrand = creBrandMMapper
            .selectByPrimaryKey(creditCardBrandCode);
        // 返却値が0件の場合、
        if (creditCardBrand == null) {
          // 《《口座クレカ情報登録BusinessBean》.リターンコードにP023を設定し、返却する。
          registAccountCreditCardBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P023);
          registAccountCreditCardBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P023),
                  null, Locale.getDefault()));
          return registAccountCreditCardBusinessBean;
        }
      }

      // 《口座クレカ情報登録BusinessBean》.金融機関コードがNULLまたは空文字のいずれかでなく、
      // かつ《口座クレカ情報登録BusinessBean》.金融機関支店コードがNULLまたは空文字のいずれかでない場合、以下の処理を行う。
      String bankCode = registAccountCreditCardBusinessBean.getBankCode();
      String bankBranchCode = registAccountCreditCardBusinessBean
          .getBankBranchCode();
      if (StringUtils.isNotEmpty(bankCode)
          && StringUtils.isNotEmpty(bankBranchCode)) {

        // 《自社金融機関マスタマッパー》.検索(主キー）を呼び出し。
        OurMngBankMKey ourMngBankMKey = new OurMngBankMKey();
        // 引数1：《口座クレカ情報登録BusinessBean》.金融機関コード
        ourMngBankMKey.setBankCode(bankCode);
        // 引数2：《口座クレカ情報登録BusinessBean》.金融機関支店コード
        ourMngBankMKey.setBankBranchCode(bankBranchCode);

        OurMngBankM ourManagementBank = ourMngBankMMapper
            .selectByPrimaryKey(ourMngBankMKey);
        // 返却値が0件の場合、
        if (ourManagementBank == null) {
          // 《口座クレカ情報登録BusinessBean》.リターンコードにP024を設定し、返却する。
          registAccountCreditCardBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P024);
          registAccountCreditCardBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P024),
                  null, Locale.getDefault()));
          return registAccountCreditCardBusinessBean;
        }
      }

      // 《口座クレカ情報登録BusinessBean》.金融機関預金種目コードがNULLまたは空文字のいずれかでない場合、以下の処理を行う。
      String bankTypeOfAccountCode = registAccountCreditCardBusinessBean
          .getBankTypeOfAccountCode();
      if (StringUtils.isNotEmpty(bankTypeOfAccountCode)) {
        // 《金融機関預金種目マスタマッパー》.検索(主キー）を呼び出し。
        // 引数：《口座クレカ情報登録BusinessBean》.金融機関預金種目コード
        BtOfAccountM bankTypeOfAccount = btOfAccountMMapper
            .selectByPrimaryKey(bankTypeOfAccountCode);
        // 返却値が0件の場合、
        if (bankTypeOfAccount == null) {
          // 《口座クレカ情報登録BusinessBean》.リターンコードにP025を設定し、返却する。
          registAccountCreditCardBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P025);
          registAccountCreditCardBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P025),
                  null, Locale.getDefault()));
          return registAccountCreditCardBusinessBean;

        }
      }

      // 親エンティティ存在チェック
      // 契約者情報照会ビジネス呼び出し
      // 《口座クレカ情報登録BusinessBean》をコピーし、《契約者情報照会BusinessBean》とする。
      InquiryContractorBusinessBean inquiryContractorBusinessBean = new InquiryContractorBusinessBean();
      // 契約者ID
      inquiryContractorBusinessBean
          .setContractorId(registAccountCreditCardBusinessBean
              .getContractorId());
      // 契約者番号
      inquiryContractorBusinessBean
          .setContractorNo(registAccountCreditCardBusinessBean
              .getContractorNo());
      // ビジネスクラスの呼び出し
      // 引数：《契約者情報照会BusinessBean》
      inquiryContractorBusinessBean = kjContractorInformationBusiness
          .inquiry(inquiryContractorBusinessBean);

      // 返却値の《契約者情報照会BusinessBean》.リターンコードが'0000'以外の場合、業務例外クラスをスローする。
      if (!ECISReturnCodeConstants.RETURN_CODE_0000
          .equals(inquiryContractorBusinessBean.getReturnCode())) {
        throw new BusinessLogicException(messageSource.getMessage(
            "error.E1281", null, Locale.getDefault()));
      }

      // 契約者情報リストが0件の場合、
      if (inquiryContractorBusinessBean.getContractorInformationList()
          .isEmpty()) {
        // 《口座クレカ情報登録BusinessBean》.リターンコードにD014を設定し、返却する。
        registAccountCreditCardBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D014);
        registAccountCreditCardBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D014),
                null, Locale.getDefault()));
        return registAccountCreditCardBusinessBean;
      }

      // 《契約者情報照会BusinessBean》.利用不能フラグが"ON"の場合、
      if (ECISKJConstants.UNAVAILABLE_FLAG_USE_IMPOSSIBLE
          .equals(inquiryContractorBusinessBean
              .getContractorInformationList().get(0)
              .getUnavailableFlag())) {
        // 《口座クレカ情報登録BusinessBean》.リターンコードにD013を設定し、返却する。
        registAccountCreditCardBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D013);
        registAccountCreditCardBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D013),
                null, Locale.getDefault()));
        return registAccountCreditCardBusinessBean;
      }

      // 口座クレカ情報登録
      // システム日時取得
      Timestamp sysTime = new Timestamp(System.currentTimeMillis());
      // 《口座クレカ情報登録BusinessBean》より《口座クレカ情報Entity》に値を設定する。
      // 契約者IDチェック
      Integer contractor = inquiryContractorBusinessBean
          .getContractorInformationList().get(0).getContractorId();
      AcInformation acInformation = new AcInformation();
      // 契約者ID
      acInformation.setContractorId(contractor);
      // 決済アクセスキー
      acInformation.setAccessKey(registAccountCreditCardBusinessBean
          .getAccessKey());
      // 口座クレカ区分コード
      acInformation.setAcCatCode(registAccountCreditCardBusinessBean
          .getAccountCreditCategoryCode());
      // 金融機関コード
      acInformation.setBankCode(registAccountCreditCardBusinessBean
          .getBankCode());
      // 金融機関支店コード
      acInformation.setBankBranchCode(registAccountCreditCardBusinessBean
          .getBankBranchCode());
      // 金融機関預金種目コード
      acInformation
          .setBtOfAccountCode(registAccountCreditCardBusinessBean
              .getBankTypeOfAccountCode());
      // 口座番号
      acInformation.setAccountNo(registAccountCreditCardBusinessBean
          .getAccountNo());
      // 口座名義
      acInformation
          .setAccountHolderName(registAccountCreditCardBusinessBean
              .getAccountHolderName());
      // クレカブランドコード
      acInformation.setCreBrandCode(registAccountCreditCardBusinessBean
          .getCreditCardBrandCode());
      // クレカ番号
      acInformation.setCreNo(registAccountCreditCardBusinessBean
          .getCreditCardNo());
      // クレカ有効期限
      acInformation
          .setCreExpirationDate(registAccountCreditCardBusinessBean
              .getCreditCardExpirationDate());
      // 利用不能フラグ
      acInformation
          .setUnavailableFlag(registAccountCreditCardBusinessBean
              .getUnavailableFlag());
      // 更新回数に“0”を設定する。
      acInformation.setUpdateCount(0);
      // 作成日時にシステム日時を設定する。
      acInformation.setCreateTime(sysTime);
      // オンライン更新日時にシステム日時を設定する。
      acInformation.setOnlineUpdateTime(sysTime);
      // オンライン更新ユーザIDにコンテキスト.ユーザIDを設定する。
      acInformation.setOnlineUpdateUserId(ThreadContext
          .getRequestThreadContext().get(ECISConstants.USER_ID_KEY)
          .toString());
      // 更新日時にシステム日時を設定する。
      acInformation.setUpdateTime(sysTime);
      // 更新モジュールコードにコンテキスト.モジュールコードを設定する。
      acInformation.setUpdateModuleCode(ThreadContext
          .getRequestThreadContext()
          .get(ECISConstants.CLASS_NAME_KEY).toString());

      // 《口座クレカ情報共通マッパー》.シーケンス登録呼び出し
      // 引数：《口座クレカ情報Entity》
      acInformationMapper.insertBySequence(acInformation);

      // 口座クレカID設定
      // 《口座クレカ情報登録BusinessBean》.口座クレカIDに《口座クレカ情報Entity》.口座クレカIDを設定する。
      registAccountCreditCardBusinessBean
          .setAccountCreditCardId(acInformation.getAccountCreId());

      // 正常終了
      registAccountCreditCardBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);

    } catch (DuplicateKeyException e) {
      logger.error(messageSource.getMessage("error.E1129", null,
          Locale.getDefault()), e);
      // 《口座クレカ情報登録BusinessBean》.リターンコードにD023を設定し、返却する。
      registAccountCreditCardBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D023);
      registAccountCreditCardBusinessBean.setMessage(duplicateKeyMsg);

    } catch (DataAccessException | BusinessLogicException e) {
      logger.error(messageSource.getMessage("error.E1129", null,
          Locale.getDefault()), e);
      // 《口座クレカ情報登録BusinessBean》.リターンコードにG017を設定し、返却する。
      registAccountCreditCardBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      registAccountCreditCardBusinessBean.setMessage(errMsg);

    } catch (NoSuchMessageException e) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, e);
      // 《口座クレカ情報登録BusinessBean》.リターンコードにG017を設定し、返却する。
      registAccountCreditCardBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      registAccountCreditCardBusinessBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
    }
    return registAccountCreditCardBusinessBean;
  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.kj.
   * KJ_AccountCreditCardInformationBusiness
   * #download(jp.co.unisys.enability.cis
   * .business.kj.model.DownloadAccountCreditCardBusinessBean)
   */
  @Override
  public DownloadAccountCreditCardBusinessBean download(
      DownloadAccountCreditCardBusinessBean downloadAccountCreditCardBusinessBean) {
    Map<String, Object> exampleMap = new HashMap<String, Object>();
    try {
      // 契約者番号
      exampleMap
          .put(ECISKJConstants.S010107_SEARCH_KEY_CONTRACTOR_NO,
              downloadAccountCreditCardBusinessBean
                  .getContractManagementInformationDownloadSearchInformationBean()
                  .getContractorNo());
      // 提供モデルコード
      exampleMap
          .put(ECISKJConstants.S010107_SEARCH_KEY_PROVIDE_MODEL,
              downloadAccountCreditCardBusinessBean
                  .getContractManagementInformationDownloadSearchInformationBean()
                  .getProvideModel());
      // 提供モデル企業コード
      exampleMap
          .put(ECISKJConstants.S010107_SEARCH_KEY_PROVIDE_MODEL_COMPANY,
              downloadAccountCreditCardBusinessBean
                  .getContractManagementInformationDownloadSearchInformationBean()
                  .getProvideModelCompany());
      // 支払番号
      exampleMap
          .put(ECISKJConstants.S010107_SEARCH_KEY_PAYMENT_NO,
              downloadAccountCreditCardBusinessBean
                  .getContractManagementInformationDownloadSearchInformationBean()
                  .getPaymentNo());
      // 支払方法
      exampleMap
          .put(ECISKJConstants.S010107_SEARCH_KEY_ACCOUNT_CREDIT_CATEGORY_PAYMENT_WAY,
              downloadAccountCreditCardBusinessBean
                  .getContractManagementInformationDownloadSearchInformationBean()
                  .getAccountCreditCategoryPaymentWay());

      // 口座クレカ情報ファイルの出力内容取得
      List<KJ_AccountCreditCardInformationFileEntityBean> accountCreditCardInformationFileEntityBeanList = accountCreditCardInformationCommonMapper
          .selectAccountCreditCardInformationFile(exampleMap);

      // オンライン処理基準日取得
      String onlineDate = StringConvertUtil
          .convertDateToString(
              dateBusiness
                  .getProcessBaseDate(ECISConstants.EXEC_BASE_DATE_ONLINE),
              ECISConstants.FORMAT_DATE_yyyyMMdd);

      // CSVファイル名設定
      StringBuilder fileName = new StringBuilder();
      fileName.append(ECISKJConstants.CONTRACT_MANAGEMENT_INFORMATION_DOWNLOAD_FILE_PREFIX_ACCOUNT_CREDIT_CARD);
      fileName.append(ECISConstants.UNDERLINE);
      fileName.append(onlineDate);
      downloadAccountCreditCardBusinessBean.setDownloadFileName(fileName
          .toString());

      // 口座クレカ情報ファイルの出力内容設定
      downloadAccountCreditCardBusinessBean
          .setAccountCreditCardInformationFileEntityBeanList(accountCreditCardInformationFileEntityBeanList);
    } catch (Exception e) {
      throw new SystemException(e.getMessage(), e);
    }
    return downloadAccountCreditCardBusinessBean;
  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.kj.
   * KJ_AccountCreditCardInformationBusiness
   * #csvFileCheck(jp.co.unisys.enability.cis
   * .business.kj.model.CsvFileCheckAccountCreditCardBusinessBean)
   */
  @Override
  public CsvFileCheckAccountCreditCardBusinessBean csvFileCheck(
      CsvFileCheckAccountCreditCardBusinessBean csvFileCheckBusinessBean) {
    try {
      /* 返却用オブジェクトの生成 */
      CsvFileCheckAccountCreditCardBusinessBean csvResultBean = new CsvFileCheckAccountCreditCardBusinessBean();
      List<String> errorList = new ArrayList<String>();
      List<Map<Integer, String>> registList = new ArrayList<Map<Integer, String>>();

      /* ファイルオブジェクトの取得 */
      File csvFile = csvFileCheckBusinessBean.getUploadFile();

      /* ヘッダレコードのチェック */
      // アップロードファイルMap生成
      List<Map<Integer, String>> csvList = null;

      csvList = Csv.load(csvFile, ECISConstants.ENCODE_TYPE_UTF8,
          ContractManagementInformationFileConfigCommon.getCsvConfig(),
          new ColumnPositionMapListHandler());
      // ファイル構成チェック
      if (ContractManagementInformationFileConfigCommon.UPLOAD_FILE_MINIMUM_LINE_COUNT > csvList
          .size()) {
        // エラーリストへ格納
        errorList.add(StringConvertUtil.convertErrorListString(
            csvFile.getName(),
            null,
            messageSource.getMessage("error.E0028", null,
                Locale.getDefault())));

        // 処理を終了する。
        csvResultBean.setUploadFileName(csvFile.getName());
        csvResultBean.setErrorList(errorList);
        csvResultBean.setRegistList(registList);

        return csvResultBean;
      }
      // 項目数チェック
      Map<Integer, String> header = csvList
          .get(ContractManagementInformationFileConfigCommon.ROW_NUMBER_HEADER);
      if (ContractManagementInformationFileConfigCommon.HEADER_COLUMN_COUNT != header
          .size()) {
        // エラーリストへ格納
        errorList
            .add(StringConvertUtil.convertErrorListString(
                csvFile.getName(),
                ContractManagementInformationFileConfigCommon.HEADER_START_LINE_NUMBER,
                messageSource.getMessage("error.E0021", null,
                    Locale.getDefault())));

        // 処理を終了する。
        csvResultBean.setUploadFileName(csvFile.getName());
        csvResultBean.setErrorList(errorList);
        csvResultBean.setRegistList(registList);

        return csvResultBean;
      }

      // 単項目チェック
      List<String> headerErrorMessageList = contractManagementInformationFileHeaderValidator
          .validate(
              header,
              ContractManagementInformationFileConfigAccountCreditCard.DATA_FILE_KIND_MASK_STRING);
      if (headerErrorMessageList.size() > 0) {
        for (String errorMessage : headerErrorMessageList) {
          errorList
              .add(StringConvertUtil.convertErrorListString(
                  csvFile.getName(),
                  ContractManagementInformationFileConfigCommon.HEADER_START_LINE_NUMBER,
                  errorMessage));
        }
        // 処理を終了する。
        csvResultBean.setUploadFileName(csvFile.getName());
        csvResultBean.setErrorList(errorList);
        csvResultBean.setRegistList(registList);
      }

      /* タイトル行チェック */
      // 項目数チェック
      Map<Integer, String> title = csvList
          .get(ContractManagementInformationFileConfigCommon.ROW_NUMBER_TITLE);
      if (ContractManagementInformationFileConfigAccountCreditCard.DATA_COLUMN_COUNT != title
          .size()) {
        // エラーリストへ格納
        errorList
            .add(StringConvertUtil.convertErrorListString(
                csvFile.getName(),
                ContractManagementInformationFileConfigCommon.TITLE_START_LINE_NUMBER,
                messageSource.getMessage("error.E0021", null,
                    Locale.getDefault())));

        // 処理を終了する。
        csvResultBean.setUploadFileName(csvFile.getName());
        csvResultBean.setErrorList(errorList);
        csvResultBean.setRegistList(registList);

        return csvResultBean;
      }

      // タイトル内容チェック
      // HashMapだと順番に揃わない可能性があるため、IteratorでKeyを取得
      Iterator<Integer> titleIt = title.keySet().iterator();
      while (titleIt.hasNext()) {
        // タイトルのカラム番号を取得
        Integer columnNo = titleIt.next();
        // タイトル内容を取得
        String titleValue = title.get(columnNo);
        // コンフィグの内容を取得
        String configValue = ContractManagementInformationFileConfigAccountCreditCard.DATA_TITLE_ROW[columnNo
            .intValue()];
        // 一致していない場合、エラー終了
        if (!configValue.equals(titleValue)) {
          errorList
              .add(StringConvertUtil.convertErrorListString(
                  csvFile.getName(),
                  ContractManagementInformationFileConfigCommon.TITLE_START_LINE_NUMBER,
                  messageSource.getMessage("error.E0028", null,
                      Locale.getDefault())));
          csvResultBean.setUploadFileName(csvFile.getName());
          csvResultBean.setErrorList(errorList);
          csvResultBean.setRegistList(registList);
          return csvResultBean;
        }
      }

      /* マスタ情報取得 */
      // 口座クレカ区分コード
      List<AcCatM> acCatMList = acCatMMapper.selectByExample(null);
      Set<String> acCatMSet = new HashSet<String>();
      Iterator<AcCatM> acCatIt = acCatMList.iterator();
      // 口座クレカ区分コードをSetに格納
      while (acCatIt.hasNext()) {
        AcCatM mst = acCatIt.next();
        acCatMSet.add(mst.getAcCatCode());
      }

      // クレカブランドコード
      List<CreBrandM> creBrandMList = creBrandMMapper.selectByExample(null);
      Set<String> creBrandMSet = new HashSet<String>();
      Iterator<CreBrandM> creBrandMIt = creBrandMList.iterator();
      // クレカブランドコードをSetに格納
      while (creBrandMIt.hasNext()) {
        CreBrandM mst = creBrandMIt.next();
        creBrandMSet.add(mst.getCreBrandCode());
      }

      /* データレコードチェック */
      // データレコードエラーリスト生成
      List<String> dataRecordErrorList = new ArrayList<String>();

      // データレコードの数だけ処理を行う
      for (int i = ContractManagementInformationFileConfigCommon.ROW_NUMBER_DATA; i < csvList
          .size(); i++) {
        // 初期化
        dataRecordErrorList.clear();

        Map<Integer, String> dataRecordMap = csvList.get(i);

        // 項目数チェック
        if (dataRecordMap
            .size() != ContractManagementInformationFileConfigAccountCreditCard.DATA_COLUMN_COUNT) {
          // エラーリストへ格納
          dataRecordErrorList.add(StringConvertUtil
              .convertErrorListString(csvFile.getName(), i + 1,
                  messageSource.getMessage("error.E0021", null,
                      Locale.getDefault())));
          errorList.addAll(dataRecordErrorList);

          // 処理を終了する。
          csvResultBean.setUploadFileName(csvFile.getName());
          csvResultBean.setErrorList(errorList);
          csvResultBean.setRegistList(registList);

          return csvResultBean;

        }

        // 登録区分
        String registCategory = dataRecordMap
            .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_REGISTER_CATEGORY_INDEX);

        // 登録区分チェック
        if (StringUtils.isEmpty(registCategory)) {
          // 次の行の処理を行う
          continue;
        }

        // バリデーションエラーメッセージ用リスト生成
        List<String> validationErrorMessageList = new ArrayList<String>();
        // 登録区分が登録・更新・削除区分(登録)と一致する場合、単項目チェックを行う
        if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER
            .equals(registCategory)) {
          // 単項目チェック
          validationErrorMessageList = accountCreditCardInformationFileRegistValidator
              .validate(dataRecordMap);
          // 一致しない場合は、エラーリストにメッセージを設定
        } else {
          dataRecordErrorList
              .add(StringConvertUtil.convertErrorListString(
                  csvFile.getName(),
                  i + 1,
                  messageSource
                      .getMessage(
                          "validation.range",
                          new String[] {
                              ContractManagementInformationFileConfigAccountCreditCard.DATA_REGISTER_CATEGORY_NAME,
                              ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER },
                          Locale.getDefault())));

        }

        // バリデーションエラーメッセージにファイル名と行数を追加し、データレコードエラーリストに追加
        for (String validationErrorMessage : validationErrorMessageList) {
          dataRecordErrorList.add(StringConvertUtil
              .convertErrorListString(csvFile.getName(), i + 1,
                  validationErrorMessage));
        }

        // 口座クレカ区分コード
        String creditCardCategory = dataRecordMap
            .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_ACCOUNT_CREDIT_CARD_CATEGORY_CODE_INDEX);
        // 金融機関コード
        String bankCode = dataRecordMap
            .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_BANK_CODE_INDEX);
        // 金融機関支店コード
        String bankBranchCode = dataRecordMap
            .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_BANK_BRANCH_CODE_INDEX);
        // 金融機関預金種目コード
        String bankTypeAccountCode = dataRecordMap
            .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_BANK_TYPE_OF_ACCOUNT_CODE_INDEX);
        // クレカブランドコード
        String creditCardBrand = dataRecordMap
            .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_CREDIT_CARD_BRAND_CODE_INDEX);
        // 決済アクセスキー
        String accessKey = dataRecordMap
            .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_ACCESS_KEY_INDEX);
        // クレカ番号
        String creditCardNo = dataRecordMap
            .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_CREDIT_CARD_NO_INDEX);
        // クレカ有効期限
        String creditCardExpDate = dataRecordMap
            .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_CREDIT_CARD_EXPIRATION_DATE_INDEX);
        // 口座番号
        String accountNo = dataRecordMap
            .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_ACCOUNT_NO_INDEX);
        // 口座名義
        String accountHolderName = dataRecordMap
            .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_ACCOUNT_HOLDER_NAME_INDEX);

        // コード存在チェック
        // 口座クレカ区分コード判定

        // マスタに当該コードが存在しない場合は、エラーリストにメッセージを格納
        if (!acCatMSet.contains(creditCardCategory)) {
          dataRecordErrorList
              .add(StringConvertUtil.convertErrorListString(csvFile
                  .getName(), i + 1,
                  messageSource.getMessage(
                      "validation.range",
                      new String[] {
                          ContractManagementInformationFileConfigAccountCreditCard.DATA_ACCOUNT_CREDIT_CARD_CATEGORY_CODE_NAME,
                          StringUtils.join(acCatMSet, ",") },
                      Locale.getDefault())));

        }

        // 金融機関コード、金融機関支店コードがNULLおよび空文字でない場合、自社金融機関マスタの件数を取得する。
        if (StringUtils.isNotEmpty(bankCode)
            && StringUtils.isNotEmpty(bankBranchCode)) {
          OurMngBankMExample example = new OurMngBankMExample();
          example.createCriteria().andBankCodeEqualTo(bankCode)
              .andBankBranchCodeEqualTo(bankBranchCode);
          int ourBankResult = ourMngBankMMapper.countByExample(example);
          // 自社金融機関マスタの検索結果が0件の場合は、エラーリストにメッセージを格納
          if (ourBankResult == 0) {
            dataRecordErrorList
                .add(StringConvertUtil.convertErrorListString(
                    csvFile.getName(),
                    i + 1,
                    messageSource
                        .getMessage(
                            "validation.regexitem",
                            new String[] {
                                ContractManagementInformationFileConfigAccountCreditCard.DATA_BANK_CODE_OR_BANK_BRANCH_CODE_NAME },
                            Locale.getDefault())));

          }
        }

        // 金融機関預金種目コードがNULLおよび空文字でない場合、金融機関預金種目マスタの件数を取得する。

        if (StringUtils.isNotEmpty(bankTypeAccountCode)) {
          BtOfAccountMExample example = new BtOfAccountMExample();
          example.createCriteria().andBtOfAccountCodeEqualTo(
              bankTypeAccountCode);
          int btOfAccountResult = btOfAccountMMapper
              .countByExample(example);
          // 金融機関預金種目マスタの検索結果が0件の場合は、エラーリストにメッセージを格納
          if (btOfAccountResult == 0) {
            dataRecordErrorList.add(StringConvertUtil
                .convertErrorListString(csvFile.getName(), i + 1,
                    messageSource.getMessage(
                        "validation.regexitem",
                        new String[] {
                            ContractManagementInformationFileConfigAccountCreditCard.DATA_BANK_TYPE_OF_ACCOUNT_CODE_NAME },
                        Locale.getDefault())));
          }
        }

        // クレカブランドコード判定
        // クレカブランドコードがNULLおよび空文字でない場合、クレカブランドコード存在チェックを行う。
        // マスタに当該コードが存在しない場合は、エラーリストにメッセージを格納
        if (StringUtils.isNotEmpty(creditCardBrand)) {
          if (!creBrandMSet.contains(creditCardBrand)) {
            dataRecordErrorList
                .add(StringConvertUtil.convertErrorListString(
                    csvFile.getName(),
                    i + 1,
                    messageSource.getMessage(
                        "validation.range",
                        new String[] {
                            ContractManagementInformationFileConfigAccountCreditCard.DATA_CREDIT_CARD_BRAND_CODE_NAME,
                            StringUtils.join(
                                creBrandMSet, ",") },
                        Locale.getDefault())));
          }
        }

        // 口座クレカ区分コードが"クレジットカード払い"の場合、以下のチェックを行う
        if (ECISCodeConstants.ACCOUNT_CREDIT_CATEGORY_CODE_CREDIT
            .equals(creditCardCategory)) {

          // 決済アクセスキー、クレカ番号、クレカ有効期限のいずれかがNULLまたは空文字の場合、エラーリストにメッセージを格納
          if (StringUtils.isEmpty(accessKey)
              || StringUtils.isEmpty(creditCardNo)
              || StringUtils.isEmpty(creditCardExpDate)) {
            dataRecordErrorList.add(StringConvertUtil
                .convertErrorListString(csvFile.getName(), i + 1,
                    messageSource.getMessage("error.E1159",
                        new String[] {
                            ContractManagementInformationFileConfigAccountCreditCard.DATA_CREDIT_CARD_PAYMENT_NAME },
                        Locale.getDefault())));
          }

          // 口座番号、金融機関コード、金融機関支店コード、金融機関預金種目コード、口座名義のいずれかがNULLまたは空文字でない場合、エラーリストにメッセージを格納
          if (StringUtils.isNotEmpty(accountNo)
              || StringUtils.isNotEmpty(bankCode)
              || StringUtils.isNotEmpty(bankBranchCode)
              || StringUtils.isNotEmpty(bankTypeAccountCode)
              || StringUtils.isNotEmpty(accountHolderName)) {
            dataRecordErrorList.add(StringConvertUtil
                .convertErrorListString(csvFile.getName(), i + 1,
                    messageSource.getMessage("error.E1160",
                        new String[] {
                            ContractManagementInformationFileConfigAccountCreditCard.DATA_CREDIT_CARD_PAYMENT_NAME },
                        Locale.getDefault())));
          }
          // 口座クレカ区分コードが"口座振替"の場合、以下のチェックを行う
        } else if (ECISCodeConstants.ACCOUNT_CREDIT_CATEGORY_CODE_ACCOUNT
            .equals(creditCardCategory)) {
          // 決済アクセスキー、口座番号のいずれかがNULLまたは空文字の場合、エラーリストにメッセージを格納
          if (StringUtils.isEmpty(accessKey)
              || StringUtils.isEmpty(accountNo)) {
            dataRecordErrorList.add(StringConvertUtil
                .convertErrorListString(csvFile.getName(), i + 1,
                    messageSource.getMessage("error.E1161",
                        new String[] {
                            ContractManagementInformationFileConfigAccountCreditCard.DATA_ACCOUNT_TRANSFER_NAME },
                        Locale.getDefault())));
          }

          // クレカ番号、クレカ有効期限、クレカブランドコードのいずれかがNULLまたは空文字でない場合、エラーリストにメッセージを格納
          if (StringUtils.isNotEmpty(creditCardNo)
              || StringUtils.isNotEmpty(creditCardExpDate)
              || StringUtils.isNotEmpty(creditCardBrand)) {
            dataRecordErrorList.add(StringConvertUtil
                .convertErrorListString(csvFile.getName(), i + 1,
                    messageSource.getMessage("error.E1162",
                        new String[] {
                            ContractManagementInformationFileConfigAccountCreditCard.DATA_ACCOUNT_TRANSFER_NAME },
                        Locale.getDefault())));
          }

          // 金融機関コード、金融機関支店コード、金融機関預金種目コード、口座名義の全てがNULLまたは空文字が設定されているかチェックする
          if (StringUtils.isNotEmpty(bankCode)
              || StringUtils.isNotEmpty(bankBranchCode)
              || StringUtils.isNotEmpty(bankTypeAccountCode)
              || StringUtils.isNotEmpty(accountHolderName)) {

            // 一つでもNULLまたは空文字が設定されている項目があった場合、全項目がNULLまたは空文字かチェックする
            // 上記を満たさない場合、エラーリストにメッセージを格納
            if (StringUtils.isEmpty(bankCode)
                || StringUtils.isEmpty(bankBranchCode)
                || StringUtils.isEmpty(bankTypeAccountCode)
                || StringUtils.isEmpty(accountHolderName)) {
              dataRecordErrorList.add(StringConvertUtil
                  .convertErrorListString(csvFile.getName(),
                      i + 1, messageSource.getMessage(
                          "error.E1163", null,
                          Locale.getDefault())));
            }

          }
          // 口座クレカ区分コードが"請求時振込先（自社口座）"または、"口座クレカ区分コード(購入時振込先)"の場合、以下のチェックを行う
        } else if (ECISCodeConstants.ACCOUNT_CREDIT_CATEGORY_CODE_TRANSFER
            .equals(creditCardCategory)
            || ECISCodeConstants.ACCOUNT_CREDIT_CATEGORY_CODE_TRANSFER_BUY
                .equals(creditCardCategory)) {
          // 口座番号、金融機関コード、金融機関支店コード、金融期間預金種目コード、口座名義のいずれかがNULLまたは空文字の場合、エラーリストにメッセージを格納
          if (StringUtils.isEmpty(accountNo)
              || StringUtils.isEmpty(bankCode)
              || StringUtils.isEmpty(bankBranchCode)
              || StringUtils.isEmpty(bankTypeAccountCode)
              || StringUtils.isEmpty(accountHolderName)) {
            dataRecordErrorList.add(StringConvertUtil
                .convertErrorListString(csvFile.getName(), i + 1,
                    messageSource.getMessage("error.E1164",
                        new String[] {
                            ContractManagementInformationFileConfigAccountCreditCard.DATA_BILLING_TIME_TRANSFER_OR_PURCHASE_TIME_TRANSFER_NAME },
                        Locale.getDefault())));
          }

          // 決済アクセスキー、クレカ番号、クレカ有効期限、クレカブランドコードのいずれかがNULLまたは空文字でない場合、エラーリストにメッセージを格納
          if (StringUtils.isNotEmpty(accessKey)
              || StringUtils.isNotEmpty(creditCardNo)
              || StringUtils.isNotEmpty(creditCardExpDate)
              || StringUtils.isNotEmpty(creditCardBrand)) {
            dataRecordErrorList.add(StringConvertUtil
                .convertErrorListString(csvFile.getName(), i + 1,
                    messageSource.getMessage("error.E1165",
                        new String[] {
                            ContractManagementInformationFileConfigAccountCreditCard.DATA_BILLING_TIME_TRANSFER_OR_PURCHASE_TIME_TRANSFER_NAME },
                        Locale.getDefault())));
          }
        }

        // エラー出力状況確認
        if (!dataRecordErrorList.isEmpty()) {
          errorList.addAll(dataRecordErrorList);
          continue;
        }

        // 行番号を設定しておく
        dataRecordMap
            .put(Integer
                .valueOf(ContractManagementInformationFileConfigCommon.DATA_ROW_NO_INDEX),
                String.valueOf(i + 1));

        // 登録区分が登録・更新・削除区分(登録)と一致する場合、登録オブジェクトリストにデータレコードを追加する
        if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER
            .equals(registCategory)) {
          registList.add(dataRecordMap);
        }
      }

      // 返却
      csvResultBean.setUploadFileName(csvFile.getName());
      csvResultBean.setErrorList(errorList);
      csvResultBean.setRegistList(registList);

      return csvResultBean;

    } catch (Exception e) {
      throw new SystemException(e.getMessage(), e);
    }

  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.kj.KJ_AccountCreditCardInformationBusiness#
   * update
   * (jp.co.unisys.enability.cis.business.kj.model.UpdateAccountCreditCardBusinessBean)
   */
  @Override
  public UpdateAccountCreditCardBusinessBean update(UpdateAccountCreditCardBusinessBean updateBusinessBean) {

    // エラーメッセージ
    String errMsg = null;

    try {
      // システムエラーメッセージを取得
      errMsg = getPropertiesMesseage(ECISReturnCodeConstants.RETURN_CODE_G017);

      // 口座クレカ情報の存在チェック
      // 《口座クレカ情報照会BusinessBean》の設定
      InquiryAccountCreditCardBusinessBean inquiryBusinessBean = new InquiryAccountCreditCardBusinessBean();
      // 口座クレカID：《口座クレカ情報更新BusinessBean》.口座クレカID
      inquiryBusinessBean.setAccountCreditId(updateBusinessBean.getAccountCreditCardId());
      // 口座クレカ利用状況：定数.利用状況_利用不可含む(1)
      inquiryBusinessBean.setAccountCreditCategoryUseSts(ECISKJConstants.USAGE_SITUSTION_UNSABLE_INCLUDE);

      // 《口座クレカ情報ビジネス》.照会を呼び出す。
      inquiryBusinessBean = inquiry(inquiryBusinessBean);

      // 《口座クレカ情報ビジネス》.照会の結果判定
      // 《口座クレカ情報照会BusinessBean》.リターンコードが'0000'以外の場合
      if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(inquiryBusinessBean.getReturnCode())) {
        throw new BusinessLogicException(messageSource.getMessage(
            "error.E1653", new String[] {}, Locale.getDefault()));
      }

      // 《口座クレカ情報照会BusinessBean》.口座クレカ情報リストが0件の場合
      if (inquiryBusinessBean.getAccountCreditCardInformationList().isEmpty()) {
        setMessageAndReturnCodeUpd(updateBusinessBean, ECISReturnCodeConstants.RETURN_CODE_P012);

        return updateBusinessBean;
      }

      // 口座クレカ情報更新
      Timestamp systemDate = new Timestamp(System.currentTimeMillis());
      // 《口座クレカEntity》の設定
      AcInformation acInformation = new AcInformation();
      // 利用不能フラグ：《口座クレカ情報更新BusinessBean》.利用状況
      acInformation.setUnavailableFlag(updateBusinessBean.getAccountCreditCategoryUseSts());
      // 更新回数：《口座クレカ情報更新BusinessBean》.更新回数に１加算した値
      acInformation.setUpdateCount(updateBusinessBean.getUpdateCount() + 1);
      // オンライン更新日時：システム日時
      acInformation.setOnlineUpdateTime(systemDate);
      // オンライン更新ユーザID：コンテキスト.ユーザID
      acInformation.setOnlineUpdateUserId(ThreadContext.getRequestThreadContext()
          .get(ECISConstants.USER_ID_KEY).toString());
      // 更新日時：システム日時
      acInformation.setUpdateTime(systemDate);
      // 更新モジュールコード：コンテキスト.モジュールコード
      acInformation.setUpdateModuleCode(ThreadContext.getRequestThreadContext()
          .get(ECISConstants.CLASS_NAME_KEY).toString());

      // 《口座クレカExample》の設定
      AcInformationExample acInformationExample = new AcInformationExample();
      // AND 口座クレカID：《口座クレカ情報更新BusinessBean》.口座クレカID
      // AND 更新回数    ：《口座クレカ情報更新BusinessBean》.更新回数
      acInformationExample.createCriteria()
          .andAccountCreIdEqualTo(updateBusinessBean.getAccountCreditCardId())
          .andUpdateCountEqualTo(updateBusinessBean.getUpdateCount());
      // 《口座クレカMapper》.選択項目更新（主キー・更新回数）を呼び出す。
      int updateByExampleCnt = acInformationMapper.updateByExampleSelective(acInformation, acInformationExample);

      // 《口座クレカMapper》.選択項目更新（主キー・更新回数）の結果判定
      // 返却値が0件の場合
      if (updateByExampleCnt == 0) {
        setMessageAndReturnCodeUpd(updateBusinessBean, ECISReturnCodeConstants.RETURN_CODE_H001);

        return updateBusinessBean;
      }

      // リターンコード
      updateBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);

      return updateBusinessBean;

    } catch (DataAccessException | BusinessLogicException e) {
      logger.error(messageSource.getMessage("error.E1129", null, Locale.getDefault()), e);
      // データアクセス例外（DataAccessException）または業務例外（BusinessLogicException）
      updateBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      updateBusinessBean.setMessage(errMsg);

      return updateBusinessBean;

    } catch (NoSuchMessageException e) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, e);
      // メッセージプロパティ不在
      updateBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      updateBusinessBean.setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);

      return updateBusinessBean;
    }
  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.kj.KJ_AccountCreditCardInformationBusiness#
   * delete
   * (jp.co.unisys.enability.cis.business.kj.model.DeleteAccountCreditCardBusinessBean)
   */
  @Override
  public DeleteAccountCreditCardBusinessBean delete(DeleteAccountCreditCardBusinessBean deleteBusinessBean) {

    // エラーメッセージ
    String errMsg = null;

    try {
      // システムエラーメッセージを取得
      errMsg = getPropertiesMesseage(ECISReturnCodeConstants.RETURN_CODE_G017);

      // 口座クレカ情報の存在チェック
      // 《口座クレカ情報照会BusinessBean》の設定
      InquiryAccountCreditCardBusinessBean inquiryBusinessBean = new InquiryAccountCreditCardBusinessBean();
      // 口座クレカID：《口座クレカ情報削除BusinessBean》.口座クレカID
      inquiryBusinessBean.setAccountCreditId(deleteBusinessBean.getAccountCreditCardId());
      // 口座クレカ利用状況：定数.利用状況_利用不可含む(1)
      inquiryBusinessBean.setAccountCreditCategoryUseSts(ECISKJConstants.USAGE_SITUSTION_UNSABLE_INCLUDE);

      // 《口座クレカ情報ビジネス》.照会を呼び出す。
      inquiryBusinessBean = inquiry(inquiryBusinessBean);

      // 《口座クレカ情報ビジネス》.照会の結果判定
      // 《口座クレカ情報照会BusinessBean》.リターンコードが'0000'以外の場合
      if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(inquiryBusinessBean.getReturnCode())) {
        throw new BusinessLogicException(messageSource.getMessage(
            "error.E1653", new String[] {}, Locale.getDefault()));
      }

      // 《口座クレカ情報照会BusinessBean》.口座クレカ情報リストが0件の場合
      if (inquiryBusinessBean.getAccountCreditCardInformationList().isEmpty()) {
        setMessageAndReturnCodeDel(deleteBusinessBean, ECISReturnCodeConstants.RETURN_CODE_P012);

        return deleteBusinessBean;
      }

      // 口座クレカ情報の紐付きチェック
      // 検索条件を条件Mapに設定する。
      Map<String, Object> conditionsMap = new HashMap<String, Object>();
      // 口座クレカID：《口座クレカ情報削除BusinessBean》.口座クレカID
      conditionsMap.put("accountCreditId", deleteBusinessBean.getAccountCreditCardId());
      // 《支払情報共通Mapperクラス_カスタム》.支払履歴件数取得を呼び出す。
      int paymentHistResultCount = customPaymentInformationCommonMapper.countByPaymentHistory(conditionsMap);

      // 《支払情報共通Mapperクラス_カスタム》.支払履歴件数取得の結果判定
      // 返却件数が0件以外の場合
      if (paymentHistResultCount != 0) {
        setMessageAndReturnCodeDel(deleteBusinessBean, ECISReturnCodeConstants.RETURN_CODE_G057);

        return deleteBusinessBean;
      }

      // 口座クレカ情報削除
      // 《口座クレカExample》の設定
      AcInformationExample acInformationExample = new AcInformationExample();
      // AND 口座クレカID：《口座クレカ情報削除BusinessBean》.口座クレカID
      // AND 更新回数    ：《口座クレカ情報削除BusinessBean》.更新回数
      acInformationExample.createCriteria()
          .andAccountCreIdEqualTo(deleteBusinessBean.getAccountCreditCardId())
          .andUpdateCountEqualTo(deleteBusinessBean.getUpdateCount());
      // 《口座クレカMapper》.削除を呼び出す。
      int deleteByExampleCnt = acInformationMapper.deleteByExample(acInformationExample);

      // 《口座クレカMapper》.削除の結果判定
      // 返却値が0件の場合
      if (deleteByExampleCnt == 0) {
        setMessageAndReturnCodeDel(deleteBusinessBean, ECISReturnCodeConstants.RETURN_CODE_H001);

        return deleteBusinessBean;
      }

      // リターンコード
      deleteBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);

      return deleteBusinessBean;

    } catch (DataAccessException | BusinessLogicException e) {
      logger.error(messageSource.getMessage("error.E1129", null, Locale.getDefault()), e);
      // データアクセス例外（DataAccessException）または業務例外（BusinessLogicException）
      deleteBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      deleteBusinessBean.setMessage(errMsg);

      return deleteBusinessBean;

    } catch (NoSuchMessageException e) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, e);
      // メッセージプロパティ不在
      deleteBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      deleteBusinessBean.setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);

      return deleteBusinessBean;
    }
  }

  /**
   * 口座クレカ情報共通マッパーのsetter(DI)
   *
   * @param accountCreditCardInformationCommonMapper
   *          口座クレカ情報共通マッパー
   */
  public void setAccountCreditCardInformationCommonMapper(
      AccountCreditCardInformationCommonMapper accountCreditCardInformationCommonMapper) {
    this.accountCreditCardInformationCommonMapper = accountCreditCardInformationCommonMapper;
  }

  /**
   * 日付関連共通ビジネスのsetter(DI)
   *
   * @param dateBusiness
   *          日付関連共通ビジネス
   */
  public void setDateBusiness(DateBusiness dateBusiness) {
    this.dateBusiness = dateBusiness;
  }

  /**
   * メッセージプロパティのsetter(DI)
   *
   * @param messageSource
   *          メッセージプロパティ
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }

  /**
   * 口座クレカ情報マッパーのsetter(DI)
   *
   * @param acInformationMapper
   *          口座クレカ情報マッパー
   */
  public void setAcInformationMapper(AcInformationMapper acInformationMapper) {
    this.acInformationMapper = acInformationMapper;
  }

  /**
   * 支払情報共通マッパー_カスタムのsetter(DI)
   *
   * @param customPaymentInformationCommonMapper
   *          支払情報共通マッパー_カスタム
   */
  public void setCustomPaymentInformationCommonMapper(
      Custom_PaymentInformationCommonMapper customPaymentInformationCommonMapper) {
    this.customPaymentInformationCommonMapper = customPaymentInformationCommonMapper;
  }

  /**
   * 口座クレカ区分マスタマッパーのsetter(DI)
   *
   * @param acCatMMapper
   *          口座クレカ区分マスタマッパー
   */
  public void setAcCatMMapper(AcCatMMapper acCatMMapper) {
    this.acCatMMapper = acCatMMapper;
  }

  /**
   * クレカブランドマスタマッパーのsetter(DI)
   *
   * @param creBrandMMapper
   *          クレカブランドマスタマッパー
   */
  public void setCreBrandMMapper(CreBrandMMapper creBrandMMapper) {
    this.creBrandMMapper = creBrandMMapper;
  }

  /**
   * 自社金融機関マスタマッパーのsetter(DI)
   *
   * @param ourMngBankMMapper
   *          自社金融機関マスタマッパー
   */
  public void setOurMngBankMMapper(OurMngBankMMapper ourMngBankMMapper) {
    this.ourMngBankMMapper = ourMngBankMMapper;
  }

  /**
   * 金融機関預金種目マスタマッパーのsetter(DI)
   *
   * @param btOfAccountMMapper
   *          金融機関預金種目マスタマッパー
   */
  public void setBtOfAccountMMapper(BtOfAccountMMapper btOfAccountMMapper) {
    this.btOfAccountMMapper = btOfAccountMMapper;
  }

  /**
   * 契約者情報共通ビジネスのsetter(DI)
   *
   * @param contractorInformationBusiness
   *          契約者情報共通ビジネス
   */
  public void setKjContractorInformationBusiness(
      KJ_ContractorInformationBusiness kjContractorInformationBusiness) {
    this.kjContractorInformationBusiness = kjContractorInformationBusiness;
  }

  /**
   * 契約管理情報ファイルヘッダーバリデーターのセッター(DI)
   *
   * @param contractManagementInformationFileHeaderValidator
   *          契約管理情報ファイルヘッダーバリデーター
   *
   */
  public void setContractManagementInformationFileHeaderValidator(
      ContractManagementInformationFileHeaderValidator contractManagementInformationFileHeaderValidator) {
    this.contractManagementInformationFileHeaderValidator = contractManagementInformationFileHeaderValidator;
  }

  /**
   * 口座クレカ情報登録バリデーションのセッター(DI)
   *
   * @param accountCreditCardInformationFileRegistValidator
   *          口座クレカ情報登録バリデーション(DI)
   */
  public void setAccountCreditCardInformationFileRegistValidator(
      AccountCreditCardInformationFileRegistValidator accountCreditCardInformationFileRegistValidator) {
    this.accountCreditCardInformationFileRegistValidator = accountCreditCardInformationFileRegistValidator;
  }

  /**
   * プロパティからリターンコードに対応するメッセージを取得する
   *
   * @param prop
   *          プロパティ
   * @param returnCode
   *          リターンコード
   * @return
   */
  private String getPropertiesMesseage(String returnCode)
      throws NoSuchMessageException {
    return messageSource.getMessage(KJ_CommonUtil.getMessageId(returnCode),
        new String[] {}, Locale.getDefault());
  }

  /**
   * 口座クレカ情報更新ビジネスビーンのリターンコードとメッセージを設定する。
   *
   * @param bean
   *          口座クレカ情報更新ビジネスビーン
   * @param returnCode
   *          リターンコード
   */
  private void setMessageAndReturnCodeUpd(UpdateAccountCreditCardBusinessBean bean, String returnCode)
      throws NoSuchMessageException {

    bean.setReturnCode(returnCode);
    bean.setMessage(getPropertiesMesseage(returnCode));

  }

  /**
   * 口座クレカ情報削除ビジネスビーンのリターンコードとメッセージを設定する。
   *
   * @param bean
   *          口座クレカ情報削除ビジネスビーン
   * @param returnCode
   *          リターンコード
   */
  private void setMessageAndReturnCodeDel(DeleteAccountCreditCardBusinessBean bean, String returnCode)
      throws NoSuchMessageException {

    bean.setReturnCode(returnCode);
    bean.setMessage(getPropertiesMesseage(returnCode));

  }
}
