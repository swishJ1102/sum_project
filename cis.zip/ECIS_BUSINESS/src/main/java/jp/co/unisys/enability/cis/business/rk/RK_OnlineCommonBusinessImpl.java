package jp.co.unisys.enability.cis.business.rk;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.config.PropertiesFactoryBean;
import org.springframework.context.MessageSource;

import jp.co.unisys.enability.cis.business.common.DateBusiness;
import jp.co.unisys.enability.cis.business.kj.KJ_RealQuantityHistoryBusiness;
import jp.co.unisys.enability.cis.business.kj.model.RealQuantityHistoryBusinessBean;
import jp.co.unisys.enability.cis.business.rk.model.RK_ChargeCalcWarningCheckBusinessBean;
import jp.co.unisys.enability.cis.business.rk.model.RK_OnlineCommonBusinessBean;
import jp.co.unisys.enability.cis.business.rk.model.RK_SaleProceedsRelationItemCalcBusinessBean;
import jp.co.unisys.enability.cis.common.Exception.BusinessLogicException;
import jp.co.unisys.enability.cis.common.Exception.SystemException;
import jp.co.unisys.enability.cis.common.util.StringConvertUtil;
import jp.co.unisys.enability.cis.common.util.constants.ECISCodeConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISReturnCodeConstants;
import jp.co.unisys.enability.cis.entity.common.CalculatingDsUsage;
import jp.co.unisys.enability.cis.entity.common.CalculatingFixIn;
import jp.co.unisys.enability.cis.entity.common.CalculatingTsUsage;
import jp.co.unisys.enability.cis.entity.common.CalculatingUsage;
import jp.co.unisys.enability.cis.entity.common.CclM;
import jp.co.unisys.enability.cis.entity.common.Contract;
import jp.co.unisys.enability.cis.entity.common.ContractAddInfo;
import jp.co.unisys.enability.cis.entity.common.ContractHist;
import jp.co.unisys.enability.cis.entity.common.ContractHistExample;
import jp.co.unisys.enability.cis.entity.common.DsUsage;
import jp.co.unisys.enability.cis.entity.common.DsUsageExample;
import jp.co.unisys.enability.cis.entity.common.Fcr;
import jp.co.unisys.enability.cis.entity.common.FcrBreakdown;
import jp.co.unisys.enability.cis.entity.common.FcrBreakdownExample;
import jp.co.unisys.enability.cis.entity.common.FcrExample;
import jp.co.unisys.enability.cis.entity.common.FcrWarningData;
import jp.co.unisys.enability.cis.entity.common.FcrWarningDataExample;
import jp.co.unisys.enability.cis.entity.common.FixIn;
import jp.co.unisys.enability.cis.entity.common.FixInExample;
import jp.co.unisys.enability.cis.entity.common.Fu;
import jp.co.unisys.enability.cis.entity.common.FuExample;
import jp.co.unisys.enability.cis.entity.common.Rm;
import jp.co.unisys.enability.cis.entity.common.Rqh;
import jp.co.unisys.enability.cis.entity.common.Spm;
import jp.co.unisys.enability.cis.entity.common.TsUsage;
import jp.co.unisys.enability.cis.entity.common.WarningClassM;
import jp.co.unisys.enability.cis.mapper.common.CclMMapper;
import jp.co.unisys.enability.cis.mapper.common.ContractAddInfoMapper;
import jp.co.unisys.enability.cis.mapper.common.ContractHistMapper;
import jp.co.unisys.enability.cis.mapper.common.ContractMapper;
import jp.co.unisys.enability.cis.mapper.common.DsUsageMapper;
import jp.co.unisys.enability.cis.mapper.common.FcrBreakdownMapper;
import jp.co.unisys.enability.cis.mapper.common.FcrMapper;
import jp.co.unisys.enability.cis.mapper.common.FcrWarningDataMapper;
import jp.co.unisys.enability.cis.mapper.common.FixInMapper;
import jp.co.unisys.enability.cis.mapper.common.FuMapper;
import jp.co.unisys.enability.cis.mapper.common.RmMapper;
import jp.co.unisys.enability.cis.mapper.rk.RK_OnlineCommonMapper;
import jp.co.unisys.enability.cis.rate_engine.business.RateEngineBusiness;
import jp.co.unisys.enability.cis.rate_engine.model.RateEngineBusinessBean;

/**
 * 料金計算オンライン共通ビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.rk.RK_OnlineCommonBusiness
 */
public class RK_OnlineCommonBusinessImpl implements RK_OnlineCommonBusiness {

  /**
   * 確定料金実績Mapper(DI)
   */
  private FcrMapper fixChargeResultMapper;

  /**
   * 契約Mapper(DI)
   */
  private ContractMapper contractMapper;

  /**
   * 契約付加情報Mapper(DI)
   */
  private ContractAddInfoMapper contractAddInfoMapper;

  /**
   * 料金メニューMapper(DI)
   */
  private RmMapper rateMenuMapper;

  /**
   * 確定料金実績警告データMapper(DI)
   */
  private FcrWarningDataMapper fixChargeResultWarningDataMapper;

  /**
   * 料金計算オンライン共通Mapper(DI)
   */
  private RK_OnlineCommonMapper rKOnlineCommonMapper;

  /**
   * 確定料金実績内訳Mapper(DI)
   */
  private FcrBreakdownMapper fixChargeResultBreakdownMapper;

  /**
   * 確定使用量Mapper(DI)
   */
  private FuMapper fixUsageMapper;

  /**
   * 確定指示数Mapper(DI)
   */
  private FixInMapper fixIndicationNoMapper;

  /**
   * 契約履歴Mapper(DI)
   */
  private ContractHistMapper contractHistMapper;

  /**
   * 実量歴管理ビジネス(DI)
   */
  private KJ_RealQuantityHistoryBusiness kjRealQuantityHistoryBusiness;

  /**
   * 契約種別マスタMapper(DI)
   */
  private CclMMapper cclMMapper;

  /**
   * 日割別使用量Mapper(DI)
   */
  private DsUsageMapper dsUsageMapper;

  /**
   * コード定義プロパティ(DI)
   */
  private PropertiesFactoryBean applicationProperties;

  /**
   * 料金計算エンジンビジネス(DI)
   */
  private RateEngineBusiness rateEngineBusiness;

  /**
   * 料金計算警告データチェックビジネスリスト(DI)
   */
  private List<RK_ChargeCalcWarningCheckBusiness> checkBusinessList;

  /**
   * 売上関連項目計算ビジネス(DI)
   */
  private RK_SaleProceedsRelationItemCalcBusiness rkSaleProceedsRelationItemCalcBusiness;

  /**
   * 日付関連共通ビジネス(DI)
   */
  private DateBusiness dateBusiness;

  /** メッセージソース（DI） */
  private MessageSource messageSource;

  /**
   * 制限中止割引率計算用
   */
  private static final Double PERCENT_CALCULATE = 100.00;

  /**
   * 制限中止割引率計算用（使用量ゼロ時の基本料金割合）
   */
  private static final BigDecimal PERCENT_HARF = BigDecimal.valueOf(0.5);

  /**
   * 単位：日
   */
  private static final String UNIT_DAY = "日";

  /**
   * 単位：時間
   */
  private static final String UNIT_TIME = "時間";

  /**
   * 力率のデフォルト値
   */
  private static final int DEFAULT_POWER_FACTOR = 85;

  /**
   * ログマネジャー
   */
  private static Logger logger = LogManager.getLogger();

  /**
   * 当月最大電力
   */
  private static final BigDecimal PKW = BigDecimal.ZERO;

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.rk.RK_OnlineCommonBusiness#
   * selectFixChargeResult
   * (jp.co.unisys.enability.cis.business.rk.model.RK_OnlineCommonBusinessBean
   * )
   */
  public void selectFixChargeResult(RK_OnlineCommonBusinessBean businessBean)
      throws BusinessLogicException {

    // ===================================================
    // 【確定料金実績】取得
    // ===================================================
    List<Fcr> fixChargeResultList = new ArrayList<Fcr>();
    if (businessBean.getFixChargeResultId() != null) {
      // DBから取得
      Fcr fixChargeResult = fixChargeResultMapper
          .selectByPrimaryKey(businessBean.getFixChargeResultId());

      if (fixChargeResult != null) {
        fixChargeResultList.add(fixChargeResult);
      }

      // 指定された条件で該当するデータが存在しない場合
      if (CollectionUtils.isEmpty(fixChargeResultList)) {
        throw new BusinessLogicException("info.I0002");
      }
    } else {
      FcrExample fixChargeResultExample = new FcrExample();
      FcrExample.Criteria fixChargeResultCriteria = fixChargeResultExample
          .createCriteria();

      // 契約ID
      fixChargeResultCriteria.andContractIdEqualTo(businessBean
          .getContractId());
      // 利用年月
      fixChargeResultCriteria.andUsePeriodEqualTo(businessBean
          .getUsePeriod());
      // 料金ステータスコード
      fixChargeResultCriteria
          .andCsCodeEqualTo(ECISCodeConstants.CHARGE_STATUS_CODE_FIX);

      // 上記検索条件をもとにDBから取得
      fixChargeResultList = fixChargeResultMapper
          .selectByExample(fixChargeResultExample);

      // 指定された条件で該当するデータが存在しない場合
      if (CollectionUtils.isEmpty(fixChargeResultList)) {
        throw new BusinessLogicException("info.I0002");
      }

      // 契約容量を設定
      businessBean.setContractCapacity(fixChargeResultList.get(0).getCca());
    }

    // ===================================================
    // 【契約】取得
    // ===================================================
    Contract contract = contractMapper
        .selectByPrimaryKey(fixChargeResultList.get(0).getContractId());

    // ===================================================
    // 【契約付加情報】取得
    // ===================================================
    ContractAddInfo contractAddInfo = contractAddInfoMapper
        .selectByPrimaryKey(fixChargeResultList.get(0).getContractId());

    // ===================================================
    // 【料金メニュー】取得
    // ===================================================
    Rm rateMenu = rateMenuMapper.selectByPrimaryKey(fixChargeResultList
        .get(0).getRmId());

    // ===================================================
    // 【実量歴一覧】取得
    // ===================================================
    // 《実量歴管理BusinessBean》を設定する。
    RealQuantityHistoryBusinessBean realQuantityHistoryBusinessBean = new RealQuantityHistoryBusinessBean();

    // 契約IDを設定する。
    realQuantityHistoryBusinessBean.setContractId(fixChargeResultList
        .get(0).getContractId());
    // 対象年月を設定する。
    realQuantityHistoryBusinessBean.setCoveredPeriod(fixChargeResultList
        .get(0).getUsePeriod());
    //
    // 実量歴管理ビジネス.実量歴管理照会を呼び出し、実量歴管理情報を取得する。
    RealQuantityHistoryBusinessBean returnRealQuantityHistoryBusinessBean = kjRealQuantityHistoryBusiness
        .inquiry(realQuantityHistoryBusinessBean);

    // 実量歴管理照会結果判定
    if (!ECISReturnCodeConstants.RETURN_CODE_0000
        .equals(returnRealQuantityHistoryBusinessBean.getReturnCode())) {
      // リターンコードが"0000"以外の場合、システム例外をスローする。
      throw new SystemException(
          returnRealQuantityHistoryBusinessBean.getMessage());
    }

    // 実量歴一覧
    List<Rqh> rqhList = returnRealQuantityHistoryBusinessBean.getRealQuantityHistoryList();

    // ===================================================
    // 【契約種別マスタ】取得
    // ===================================================
    CclM cclM = new CclM();
    if (rateMenu != null) {
      cclM = cclMMapper.selectByPrimaryKey(rateMenu.getCclCode());
    }

    // ===================================================
    // 【確定料金実績警告データ】取得
    // ===================================================
    FcrWarningDataExample fixChargeResultWarningDataExample = new FcrWarningDataExample();
    // 確定料金実績ID
    fixChargeResultWarningDataExample.createCriteria().andFcrIdEqualTo(
        fixChargeResultList.get(0).getFcrId());

    // 上記検索条件をもとにDBから取得
    List<FcrWarningData> fixChargeResultWarningDataList = fixChargeResultWarningDataMapper
        .selectByExample(fixChargeResultWarningDataExample);

    // 検索結果を保持
    List<WarningClassM> warningClassMasterList = null;
    // 対応フラグ
    String tempDealFlag = ECISConstants.FLG_OFF;

    // 警告種別リストが0件でなかった場合
    if (!CollectionUtils.isEmpty(fixChargeResultWarningDataList)) {
      // 警告種別をリストに設定
      List<String> warningClassCodeList = new ArrayList<String>();
      for (FcrWarningData fcrWarningData : fixChargeResultWarningDataList) {
        warningClassCodeList.add(fcrWarningData.getWarningClassCode());
      }

      // 上記検索条件をもとにDBから取得
      warningClassMasterList = rKOnlineCommonMapper
          .selectWarningClass(warningClassCodeList);

      // 《警告種別マスタEntityBean》リストより、対応フラグが“1：要”のデータ存在チェック
      for (WarningClassM warningClassM : warningClassMasterList) {
        // “1：要”の場合
        if (ECISConstants.FLG_ON
            .equals(warningClassM.getDealNeedFlag())) {
          tempDealFlag = ECISConstants.FLG_ON;
          break;
        }
      }
    }

    // ===================================================
    // 【確定料金実績内訳】取得
    // ===================================================
    FcrBreakdownExample fixChargeResultBreakdownExample = new FcrBreakdownExample();
    // 確定料金実績ID
    fixChargeResultBreakdownExample.createCriteria().andFcrIdEqualTo(
        fixChargeResultList.get(0).getFcrId());
    // 表示順、明細出力順
    fixChargeResultBreakdownExample
        .setOrderByClause(ECISRKConstants.RK_ONLINE_COMMON_FCRBREAKDOWN_ORDER_BY_CLAUSE);

    // 上記検索条件をもとにDBから取得
    List<FcrBreakdown> fixChargeResultBreakdownList = fixChargeResultBreakdownMapper
        .selectByExample(fixChargeResultBreakdownExample);

    // ===================================================
    // 【付帯メニュー】取得
    // ===================================================
    // 付帯契約IDのリストを生成
    List<Integer> supplementaryContractIdList = new ArrayList<Integer>();
    for (FcrBreakdown fcrBreakdown : fixChargeResultBreakdownList) {
      if (fcrBreakdown.getSplContractId() != null) {
        supplementaryContractIdList
            .add(fcrBreakdown.getSplContractId());
      }
    }

    // 上記検索条件をもとにDBから付帯メニュー取得
    List<Spm> supplementaryMenuList = new ArrayList<Spm>();
    if (!CollectionUtils.isEmpty(supplementaryContractIdList)) {
      supplementaryMenuList = rKOnlineCommonMapper
          .selectSupplementaryMenu(supplementaryContractIdList);
    }

    // ===================================================
    // 使用量取得
    // ===================================================
    // 使用量を取得するための検索条件を設定
    RK_OnlineCommonBusinessBean tempOnlineCommonBusinessBean = new RK_OnlineCommonBusinessBean();
    // 確定使用量ID
    tempOnlineCommonBusinessBean.setFixUsageId(fixChargeResultList.get(0)
        .getFuId());
    // 料金メニュー
    tempOnlineCommonBusinessBean.setRateMenu(rateMenu);

    // 上記検索条件をもとにDBから取得
    selectUsageQuantity(tempOnlineCommonBusinessBean);

    // ===================================================
    // 最新使用量取得
    // ===================================================
    // 使用量を取得するための検索条件を設定
    RK_OnlineCommonBusinessBean newOnlineCommonBusinessBean = new RK_OnlineCommonBusinessBean();
    // 契約ID
    newOnlineCommonBusinessBean.setContractId(fixChargeResultList.get(0)
        .getContractId());
    // 利用年月
    newOnlineCommonBusinessBean.setUsePeriod(fixChargeResultList.get(0)
        .getUsePeriod());
    // 料金メニュー
    newOnlineCommonBusinessBean.setRateMenu(rateMenu);

    // 上記検索条件をもとにDBから取得
    selectUsageQuantity(newOnlineCommonBusinessBean);

    // --- Beanに設定 ---
    // 契約
    businessBean.setContract(contract);
    // 契約付加情報
    businessBean.setContractAddInfo(contractAddInfo);
    // 料金メニュー
    businessBean.setRateMenu(rateMenu);
    // 付帯メニュー
    businessBean.setSupplementaryMenuList(supplementaryMenuList);
    // 確定使用量
    businessBean.setFixUsage(tempOnlineCommonBusinessBean.getFixUsage());
    // 確定指示数
    businessBean.setFixIndicationNo(tempOnlineCommonBusinessBean
        .getFixIndicationNo());
    // 日割別使用量
    businessBean.setDateSlotUsageList(tempOnlineCommonBusinessBean
        .getDateSlotUsageList());
    // 時間帯別使用量
    businessBean.setTimeSlotUsageList(tempOnlineCommonBusinessBean
        .getTimeSlotUsageList());
    // 確定使用量（最新）
    businessBean.setFixUsageLatest(newOnlineCommonBusinessBean
        .getFixUsage());
    // 確定指示数（最新）
    businessBean.setFixIndicationNoLatest(newOnlineCommonBusinessBean
        .getFixIndicationNo());
    // 日割別使用量（最新）
    businessBean.setDateSlotUsageLatestList(newOnlineCommonBusinessBean
        .getDateSlotUsageList());
    // 時間帯別使用量（最新）
    businessBean.setTimeSlotUsageLatestList(newOnlineCommonBusinessBean
        .getTimeSlotUsageList());
    // 確定料金実績
    businessBean.setFixChargeResult(fixChargeResultList.get(0));

    // 確定料金実績内訳と確定料金実績内訳（補正）
    List<FcrBreakdown> tempFixChargeResultBreakdownList = new ArrayList<FcrBreakdown>();
    List<FcrBreakdown> crtFixChargeResultBreakdownList = new ArrayList<FcrBreakdown>();

    // 取得した《確定料金実績内訳EntityBean》リストを処理
    for (FcrBreakdown fcrBreakdown : fixChargeResultBreakdownList) {
      // 確定料金実績内訳区分コードが“901：電気料金補正額”および“902：再エネ賦課金補正額”および“903：契約超過金補正額”以外のデータ
      if (!ECISRKConstants.FIX_CHARGE_RESULT_BREAKDOWN_CATEGORY_CODE_FOR_ELEC_CHARGE_CRT_AMOUNT
          .equals(fcrBreakdown.getFcrBreakdownCatCode())
          && !ECISRKConstants.FIX_CHARGE_RESULT_BREAKDOWN_CATEGORY_CODE_FOR_RENEWABLE_ENERGY_CHARGE_CRT_AMOUNT
              .equals(fcrBreakdown.getFcrBreakdownCatCode())
          && !ECISRKConstants.FIX_CHARGE_RESULT_BREAKDOWN_CATEGORY_CODE_FOR_CONTRACT_EXCEEDED_AMOUNT
              .equals(fcrBreakdown.getFcrBreakdownCatCode())) {
        // リストに追加
        tempFixChargeResultBreakdownList.add(fcrBreakdown);
      } else {
        // リストに追加
        crtFixChargeResultBreakdownList.add(fcrBreakdown);
      }
    }
    businessBean
        .setFixChargeResultBreakdownList(tempFixChargeResultBreakdownList);
    businessBean
        .setFixChargeResultBreakdownCrtList(crtFixChargeResultBreakdownList);

    // 確定料金実績警告データ
    businessBean
        .setFixChargeResultWarningDataList(fixChargeResultWarningDataList);

    // 警告種別マスタ
    if (warningClassMasterList != null) {
      businessBean.setWarningClassMasterList(warningClassMasterList);
    }

    // 対応フラグ
    businessBean.setDealFlag(tempDealFlag);

    // ===================================================
    // 【契約履歴】取得
    // ===================================================
    ContractHistExample contractHistExample = new ContractHistExample();

    // 【契約履歴】.適用開始日
    // 【契約履歴】.適用終了日
    // 【契約履歴】.契約ID

    // 日割有無によって取得条件変更
    // 日割山の数
    int dateSlotCount = businessBean.getDateSlotUsageList().size();
    if (dateSlotCount == 1) {
      contractHistExample
          .createCriteria()
          .andApplySdLessThanOrEqualTo(
              fixChargeResultList.get(0).getCcSd())
          .andApplyEdGreaterThanOrEqualTo(
              fixChargeResultList.get(0).getCcSd())
          .andContractIdEqualTo(
              fixChargeResultList.get(0).getContractId());
    } else {
      contractHistExample
          .createCriteria()
          .andApplySdLessThanOrEqualTo(
              fixChargeResultList.get(0).getCcEd())
          .andApplyEdGreaterThanOrEqualTo(
              fixChargeResultList.get(0).getCcEd())
          .andContractIdEqualTo(
              fixChargeResultList.get(0).getContractId());
    }

    // 契約履歴Mapper.selectByExampleを呼び出す。
    List<ContractHist> contractHistList = contractHistMapper
        .selectByExample(contractHistExample);

    // 指定された条件で該当するデータが存在しない場合
    if (CollectionUtils.isEmpty(contractHistList)) {
      throw new BusinessLogicException("info.I0002");
    }

    // 契約履歴
    businessBean.setContractHist(contractHistList.get(0));

    // 実量歴一覧
    businessBean.setRqhList(rqhList);

    // 契約種別マスタ
    businessBean.setCclM(cclM);
  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.rk.RK_OnlineCommonBusiness#
   * selectUsageQuantity
   * (jp.co.unisys.enability.cis.business.rk.model.RK_OnlineCommonBusinessBean
   * )
   */
  public void selectUsageQuantity(RK_OnlineCommonBusinessBean businessBean)
      throws BusinessLogicException {

    // ===================================================
    // 【確定使用量】取得
    // ===================================================
    List<Fu> fixUsageList = new ArrayList<Fu>();

    // 引数.《料金計算オンライン共通ビジネスBean》.確定使用量IDがNULLでない場合
    if (businessBean.getFixUsageId() != null) {

      // 条件
      // 確定使用量ID：引数.《料金計算オンライン共通ビジネスBean》.確定使用量ID

      // DBから取得
      Fu fixUsage = fixUsageMapper.selectByPrimaryKey(businessBean
          .getFixUsageId());
      if (fixUsage != null) {
        fixUsageList.add(fixUsage);
      }
    } else {
      // 条件
      FuExample fixUsageExample = new FuExample();
      // 契約ID、利用年月
      fixUsageExample.createCriteria()
          .andContractIdEqualTo(businessBean.getContractId())
          .andUsePeriodEqualTo(businessBean.getUsePeriod());
      // 並び順
      fixUsageExample.setOrderByClause(ECISRKConstants.RK_ONLINE_COMMON_FU_ORDER_BY_CLAUSE);

      // 上記検索条件をもとにDBから取得
      fixUsageList = fixUsageMapper.selectByExample(fixUsageExample);
    }

    // 指定された条件で該当するデータが存在しない場合
    if (CollectionUtils.isEmpty(fixUsageList)) {
      throw new BusinessLogicException("info.I0002");
    }

    // ===================================================
    // 【確定指示数】取得
    // ===================================================
    // 条件
    FixInExample fixIndicationNoExample = new FixInExample();
    // 確定使用量ID、計器区分コード：“1：常用”
    fixIndicationNoExample
        .createCriteria()
        .andFuIdEqualTo(fixUsageList.get(0).getFuId())
        .andMeterCatCodeEqualTo(
            ECISRKConstants.METER_CATEGORY_CODE_FOR_IN_COMMON);

    // 上記検索条件をもとにDBから取得
    List<FixIn> fixIndicationNoList = fixIndicationNoMapper
        .selectByExample(fixIndicationNoExample);

    // ===================================================
    // 【日割別使用量】取得
    // ===================================================
    DsUsageExample dsUsageExample = new DsUsageExample();
    // 確定使用量ID
    dsUsageExample.createCriteria().andFuIdEqualTo(fixUsageList.get(0).getFuId());
    final List<DsUsage> dsUsageList = dsUsageMapper.selectByExample(dsUsageExample);

    // 日割別使用量＝取得した《日割別使用量EntityBean》リスト
    businessBean.setDateSlotUsageList(dsUsageList);

    // ===================================================
    // 【時間帯別使用量】取得
    // ===================================================
    // 条件Map
    Map<String, Object> paramMap = new HashMap<String, Object>();

    // 確定使用量ID
    paramMap.put("fixUsageId", fixUsageList.get(0).getFuId());
    // 料金メニューID
    if (businessBean.getRateMenu() != null) {
      paramMap.put("rateMenuId", businessBean.getRateMenu().getRmId());
    }

    // 上記検索条件をもとにDBから取得
    List<TsUsage> timeSlotUsageList = rKOnlineCommonMapper
        .selectTimeSlotUsage(paramMap);

    // --- Beanに設定 ---
    // 確定使用量＝取得した《確定使用量EntityBean》[0]
    businessBean.setFixUsage(fixUsageList.get(0));

    // 確定指示数＝取得した《確定指示数EntityBean》[0]
    if (!CollectionUtils.isEmpty(fixIndicationNoList)) {
      businessBean.setFixIndicationNo(fixIndicationNoList.get(0));
    }

    // 時間帯別使用量＝取得した《時間帯別使用量EntityBean》リスト
    businessBean.setTimeSlotUsageList(timeSlotUsageList);
  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.rk.RK_OnlineCommonBusiness#
   * calculateRetryRate
   * (jp.co.unisys.enability.cis.business.rk.model.RK_OnlineCommonBusinessBean
   * )
   */
  public void calculateRetryRate(RK_OnlineCommonBusinessBean businessBean) {

    // Beanを生成
    RateEngineBusinessBean rateEngineBusinessBean = new RateEngineBusinessBean();
    // ===================================================
    // 料金計算の前準備
    // ===================================================

    // 引数.《料金計算オンライン共通ビジネスBean》から《料金計算エンジンビジネスBean》へ詰め替え
    // 計算用使用量コピー
    CalculatingUsage calculatingUsage = new CalculatingUsage();

    if (businessBean.getFixUsageLatest() != null) {

      // 引数.《料金計算オンライン共通ビジネスBean》.確定使用量（最新）.契約ID
      // →《料金計算エンジンビジネスBean》.計算用使用量.契約ID
      calculatingUsage.setContractId(businessBean.getFixUsageLatest()
          .getContractId());

      // 引数.《料金計算オンライン共通ビジネスBean》.確定使用量（最新）.利用年月
      // →《料金計算エンジンビジネスBean》.計算用使用量.利用年月
      calculatingUsage.setUsePeriod(businessBean.getFixUsageLatest()
          .getUsePeriod());

      // 引数.《料金計算オンライン共通ビジネスBean》.確定使用量（最新）.確定使用量ID
      // →《料金計算エンジンビジネスBean》.計算用使用量.確定使用量ID
      calculatingUsage
          .setFuId(businessBean.getFixUsageLatest().getFuId());

      // 引数.《料金計算オンライン共通ビジネスBean》.確定使用量（最新）.使用量
      // →《料金計算エンジンビジネスBean》.計算用使用量.使用量合計
      calculatingUsage.setTotalUsage(businessBean.getFixUsageLatest()
          .getUsageQuantity());

      // 引数.《料金計算オンライン共通ビジネスBean》.確定使用量（最新）.使用開始日
      // →《料金計算エンジンビジネスBean》.計算用使用量.料金算定開始日
      calculatingUsage.setCcSd(businessBean.getFixUsageLatest()
          .getUsageSd());

      // 引数.《料金計算オンライン共通ビジネスBean》.確定使用量（最新）.使用終了日
      // →《料金計算エンジンビジネスBean》.計算用使用量.料金算定終了日
      calculatingUsage.setCcEd(businessBean.getFixUsageLatest()
          .getUsageEd());

      // 引数.《料金計算オンライン共通ビジネスBean》.確定使用量（最新）.料金算定日数
      // →《料金計算エンジンビジネスBean》.計算用使用量.料金算定日数
      calculatingUsage.setCcDays(businessBean.getFixUsageLatest()
          .getCcDays());

      // 引数.《料金計算オンライン共通ビジネスBean》.確定使用量（最新）.検針日数
      // →《料金計算エンジンビジネスBean》.計算用使用量.日割日数
      calculatingUsage.setProratedBasisDays(businessBean.getFixUsageLatest().getMrDays());

      // 引数.《料金計算オンライン共通ビジネスBean》.確定使用量（最新）.力率
      // →《料金計算エンジンビジネスBean》.計算用使用量.力率
      calculatingUsage.setPowerFactor(businessBean.getFixUsageLatest()
          .getPowerFactor());

    }

    // 引数.《料金計算オンライン共通ビジネスBean》.契約容量
    // →《料金計算エンジンビジネスBean》.計算用使用量.契約容量
    calculatingUsage.setCca(businessBean.getContractCapacity());

    if (businessBean.getRateMenu() != null) {

      // 引数.《料金計算オンライン共通ビジネスBean》.料金メニュー.料金メニューID
      // →《料金計算エンジンビジネスBean》.計算用使用量.料金メニューID
      calculatingUsage.setRmId(businessBean.getRateMenu().getRmId());

    }

    // 引数.《料金計算オンライン共通ビジネスBean》.契約電力決定区分コード
    // →《料金計算エンジンビジネスBean》.契約電力決定区分コード
    calculatingUsage.setCcDecisionCategoryCode(businessBean.getContractCapacityDecisionCategoryCode());

    // 引数.《料金計算オンライン共通ビジネスBean》.当月最大電力
    // →《料金計算エンジンビジネスBean》.当月最大電力
    calculatingUsage.setPkw(businessBean.getPeakKw());

    // メンバに設定
    rateEngineBusinessBean.setCalculatingUsage(calculatingUsage);

    // 引数.《料金計算オンライン共通ビジネスBean》.日割別使用量（最新）の件数分、
    // 《料金計算エンジンビジネスBean》.計算用日割別使用量へ内容をコピーし、リストに追加する。

    // 契約履歴EntityBeanを取得する
    // 契約履歴Example
    ContractHistExample contractHistExample = null;

    List<CalculatingDsUsage> calculatingDateSlotUsageeBusinessBeanList = new ArrayList<CalculatingDsUsage>();
    CalculatingDsUsage calculatingDateSlotUsageeBusinessBean = null;
    int dsUsageSize = businessBean.getDateSlotUsageLatestList().size();
    // 計算用日割別使用量の数分、処理を行う
    if (businessBean.getDateSlotUsageLatestList() != null) {
      for (DsUsage dsUsage : businessBean.getDateSlotUsageLatestList()) {

        contractHistExample = new ContractHistExample();

        // 【契約履歴】を取得する条件を設定
        contractHistExample
            .createCriteria()
            // 契約ID
            .andContractIdEqualTo(businessBean.getFixUsageLatest().getContractId())
            // 適用終了日
            .andApplyEdGreaterThanOrEqualTo(dsUsage.getDsSd());

        // 【契約履歴】取得
        List<ContractHist> contractHistList = contractHistMapper.selectByExample(contractHistExample);

        // 日割終了日から日割開始日の時刻（ミリ秒）を引いた値を求める
        long diffTimeDs = dsUsage.getDsEd().getTime() - dsUsage.getDsSd().getTime();
        // 日割日数
        short dsDays = (short) (diffTimeDs / ECISConstants.ONE_DAY_MILLI_SECONDS + 1);

        // Beanを生成
        calculatingDateSlotUsageeBusinessBean = new CalculatingDsUsage();

        // 引数.《料金計算オンライン共通ビジネスBean》.確定使用量（最新）.契約ID
        // →《計算用日割別使用量》.契約ID
        calculatingDateSlotUsageeBusinessBean.setContractId(businessBean.getFixUsageLatest().getContractId());

        // 引数.《料金計算オンライン共通ビジネスBean》.確定使用量（最新）.利用年月
        // →《計算用日割別使用量》.利用年月
        calculatingDateSlotUsageeBusinessBean.setUsePeriod(businessBean.getFixUsageLatest().getUsePeriod());

        // 引数.《料金計算オンライン共通ビジネスBean》.日割別使用量（最新）.日割開始日
        // →《計算用日割別使用量》.日割開始日
        calculatingDateSlotUsageeBusinessBean.setDsSd(dsUsage.getDsSd());

        // 引数.《料金計算オンライン共通ビジネスBean》.日割別使用量（最新）.日割終了日
        // →《計算用日割別使用量》.日割終了日
        calculatingDateSlotUsageeBusinessBean.setDsEd(dsUsage.getDsEd());

        // 引数.《料金計算オンライン共通ビジネスBean》.日割別使用量（最新）.時間帯コード
        // →《計算用日割別使用量》.日割日数
        calculatingDateSlotUsageeBusinessBean.setProratedBasisDays(dsDays);

        // 引数.《料金計算オンライン共通ビジネスBean》.日割別使用量（最新）.使用量
        // →《計算用日割別使用量》.使用量
        calculatingDateSlotUsageeBusinessBean.setUsageQuantity(dsUsage.getUsageQuantity());

        // 引数.《料金計算オンライン共通ビジネスBean》.日割別使用量（最新）.契約容量
        // →《計算用日割別使用量》.契約容量
        calculatingDateSlotUsageeBusinessBean.setCca(dsUsage.getCca());

        if (contractHistList != null) {
          for (ContractHist contractHist : contractHistList) {
            if (contractHist.getApplySd().compareTo(dsUsage.getDsSd()) <= 0
                && contractHist.getApplyEd().compareTo(dsUsage.getDsSd()) >= 0) {
              // 《契約履歴》.料金メニューID
              // →《計算用日割別使用量》.料金メニューID
              calculatingDateSlotUsageeBusinessBean.setRmId(contractHist.getRmId());

              if (dsUsageSize > 1) {
                // 日割山が複数の場合
                // 《契約履歴》.契約容量
                // →《計算用日割別使用量》.契約容量
                calculatingDateSlotUsageeBusinessBean.setCca(contractHist.getCca());
              }
            }
          }
        }

        // リストに追加
        calculatingDateSlotUsageeBusinessBeanList
            .add(calculatingDateSlotUsageeBusinessBean);
      }
    }
    rateEngineBusinessBean.setCalculatingDateSlotUsage(calculatingDateSlotUsageeBusinessBeanList);

    // 引数.《料金計算オンライン共通ビジネスBean》.時間帯別使用量（最新）の件数分、
    // 《料金計算エンジンビジネスBean》.計算用時間帯別使用量へ内容をコピーし、リストに追加する。
    List<CalculatingTsUsage> calculatingTimeSlotUsageeBusinessBeanList = new ArrayList<CalculatingTsUsage>();
    CalculatingTsUsage calculatingTimeSlotUsageeBusinessBean = null;
    // 計算用時間帯別使用量の数分、処理を行う
    if (businessBean.getTimeSlotUsageLatestList() != null) {
      for (TsUsage tsUsage : businessBean.getTimeSlotUsageLatestList()) {
        // Beanを生成
        calculatingTimeSlotUsageeBusinessBean = new CalculatingTsUsage();

        // 引数.《料金計算オンライン共通ビジネスBean》.確定使用量（最新）.契約ID
        // →《計算用時間帯別使用量》.契約ID
        calculatingTimeSlotUsageeBusinessBean
            .setContractId(businessBean.getFixUsageLatest()
                .getContractId());

        // 引数.《料金計算オンライン共通ビジネスBean》.確定使用量（最新）.利用年月
        // →《計算用時間帯別使用量》.利用年月
        calculatingTimeSlotUsageeBusinessBean.setUsePeriod(businessBean
            .getFixUsageLatest().getUsePeriod());

        // 引数.《料金計算オンライン共通ビジネスBean》.時間帯別使用量（最新）.日割開始日
        // →《計算用時間帯別使用量》.日割開始日
        calculatingTimeSlotUsageeBusinessBean.setDsSd(tsUsage
            .getDsSd());

        // 引数.《料金計算オンライン共通ビジネスBean》.時間帯別使用量（最新）.時間帯コード
        // →《計算用時間帯別使用量》.時間帯コード
        calculatingTimeSlotUsageeBusinessBean.setTsCode(tsUsage
            .getTsCode());

        // 引数.《料金計算オンライン共通ビジネスBean》.時間帯別使用量（最新）.時間帯名称
        // →《計算用時間帯別使用量》.時間帯名称
        calculatingTimeSlotUsageeBusinessBean.setTsName(tsUsage
            .getTsName());

        // 引数.《料金計算オンライン共通ビジネスBean》.時間帯別使用量（最新）.使用量
        // →《計算用時間帯別使用量》.使用量
        calculatingTimeSlotUsageeBusinessBean.setUsageQuantity(tsUsage
            .getUsageQuantity());

        // リストに追加
        calculatingTimeSlotUsageeBusinessBeanList
            .add(calculatingTimeSlotUsageeBusinessBean);
      }
    }
    rateEngineBusinessBean
        .setCalculatingTimeSlotUsage(calculatingTimeSlotUsageeBusinessBeanList);

    // 計算用指示数
    CalculatingFixIn calculatingFixIn = new CalculatingFixIn();
    calculatingFixIn.setContractId(businessBean.getFixUsageLatest().getContractId());
    calculatingFixIn.setUsePeriod(businessBean.getFixUsageLatest().getUsePeriod());
    calculatingFixIn.setInCalculationUsage(businessBean.getFixIndicationNoLatest().getInCalculationUsage());
    calculatingFixIn.setMeterCatCode(businessBean.getFixIndicationNoLatest().getMeterCatCode());
    rateEngineBusinessBean.setCalculatingFixIn(calculatingFixIn);

    // ===================================================
    // 料金計算エンジンビジネス.料金計算処理を呼び出し
    // ===================================================
    // 引数1 ：引数.《料金計算オンライン共通ビジネスBean》.確定使用量（最新）.契約ID
    // 引数2 ：引数.《料金計算オンライン共通ビジネスBean》.確定使用量（最新）.利用年月
    // 引数3 ：《料金計算エンジンビジネスBean》
    // 戻り値：なし
    rateEngineBusiness.calculateOnline(businessBean.getFixUsageLatest()
        .getContractId(),
        businessBean.getFixUsageLatest()
            .getUsePeriod(),
        rateEngineBusinessBean);
    // --- 結果をBean設定 ---
    setCalculateRetryRateReturnBean(businessBean, rateEngineBusinessBean);
  }

  /**
   * 料金計算エンジン呼び出し後のBeanの設定
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金計算エンジン呼び出し後のBeanを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param businessBean
   *          料金計算オンライン共通ビジネスBean
   * @param rateEngineBusinessBean
   *          料金計算エンジンビジネスBean
   */
  private void setCalculateRetryRateReturnBean(
      RK_OnlineCommonBusinessBean businessBean,
      RateEngineBusinessBean rateEngineBusinessBean) {

    // --- 確定料金実績内訳 ---
    List<FcrBreakdown> fixChargeResultBreakdownList = new ArrayList<FcrBreakdown>();
    FcrBreakdown fixChargeResultBreakdown = null;

    // 確定料金実績内訳の数分、以下の処理を行う
    for (FcrBreakdown fcrBreakdown : rateEngineBusinessBean
        .getFcrBreakdowns()) {
      // Beanを生成
      fixChargeResultBreakdown = new FcrBreakdown();
      // 表示順
      // ＝《料金計算エンジンビジネスBean》.確定料金実績内訳.表示順
      fixChargeResultBreakdown.setDisplayOrder(fcrBreakdown
          .getDisplayOrder());

      // 明細出力順
      // ＝《料金計算エンジンビジネスBean》.確定料金実績内訳.明細出力順
      fixChargeResultBreakdown.setDetailOutputOrder(fcrBreakdown
          .getDetailOutputOrder());

      // 表示名称1
      // ＝《料金計算エンジンビジネスBean》.確定料金実績内訳.表示名称1
      fixChargeResultBreakdown.setDisplayName1(fcrBreakdown
          .getDisplayName1());

      // 表示名称2
      // ＝《料金計算エンジンビジネスBean》.確定料金実績内訳.表示名称2
      fixChargeResultBreakdown.setDisplayName2(fcrBreakdown
          .getDisplayName2());

      // 容量・使用量
      // ＝《料金計算エンジンビジネスBean》.確定料金実績内訳.容量・使用量
      fixChargeResultBreakdown.setCapacityOrUsage(fcrBreakdown
          .getCapacityOrUsage());

      // 単価
      // ＝《料金計算エンジンビジネスBean》.確定料金実績内訳.単価
      fixChargeResultBreakdown.setUp(fcrBreakdown.getUp());

      // 金額
      // ＝《料金計算エンジンビジネスBean》.確定料金実績内訳.金額
      fixChargeResultBreakdown.setAmount(fcrBreakdown.getAmount());

      // 付帯契約ID
      // ＝《料金計算エンジンビジネスBean》.確定料金実績内訳.付帯契約ID
      fixChargeResultBreakdown.setSplContractId(fcrBreakdown
          .getSplContractId());

      // 付帯率
      // ＝《料金計算エンジンビジネスBean》.確定料金実績内訳.付帯率
      fixChargeResultBreakdown.setSplRate(fcrBreakdown.getSplRate());

      // 付帯対象区分コード
      // ＝《料金計算エンジンビジネスBean》.確定料金実績内訳.付帯対象区分コード
      fixChargeResultBreakdown.setSplCoveredCatCode(fcrBreakdown
          .getSplCoveredCatCode());

      // 確定料金実績内訳区分コード
      // ＝《料金計算エンジンビジネスBean》.確定料金実績内訳.確定料金実績内訳区分コード
      fixChargeResultBreakdown.setFcrBreakdownCatCode(fcrBreakdown
          .getFcrBreakdownCatCode());

      // リストに追加
      fixChargeResultBreakdownList.add(fixChargeResultBreakdown);
    }

    // 返却値の項目に設定
    businessBean
        .setFixChargeResultBreakdownList(fixChargeResultBreakdownList);

    /**
     * 売上関連項目計算処理
     */
    // 情報設定
    RK_SaleProceedsRelationItemCalcBusinessBean saleProceedsRelationItemCalcBusinessBean = new RK_SaleProceedsRelationItemCalcBusinessBean();
    // 確定料金実績作成
    Fcr fcr = new Fcr();
    // 料金メニューID
    fcr.setRmId(rateEngineBusinessBean.getFixChargeResult().getRmId());
    // 料金算定開始日
    fcr.setCcSd(rateEngineBusinessBean.getFixChargeResult().getCcSd());
    // 料金算定終了日
    fcr.setCcEd(rateEngineBusinessBean.getFixChargeResult().getCcEd());
    // 確定料金実績設定
    saleProceedsRelationItemCalcBusinessBean.setFixChargeResult(fcr);

    // 確定料金実績内訳情報設定
    List<FcrBreakdown> fcrBreakdownList = new ArrayList<FcrBreakdown>(businessBean
        .getFixChargeResultBreakdownList().size());
    // 計算結果内訳情報の件数分、確定料金実績内訳情報に設定
    for (FcrBreakdown targetBreakdown : businessBean.getFixChargeResultBreakdownList()) {
      FcrBreakdown fcrBreakdown = new FcrBreakdown();
      // 金額
      fcrBreakdown.setAmount(targetBreakdown.getAmount());
      // 付帯対象区分コード
      fcrBreakdown.setSplCoveredCatCode(targetBreakdown.getSplCoveredCatCode());
      // 確定料金実績内訳区分コード
      fcrBreakdown.setFcrBreakdownCatCode(targetBreakdown.getFcrBreakdownCatCode());

      fcrBreakdownList.add(fcrBreakdown);
    }

    saleProceedsRelationItemCalcBusinessBean.setFixChargeResultBreakdownList(fcrBreakdownList);

    // 売上関連項目計算実行
    rkSaleProceedsRelationItemCalcBusiness.calculate(saleProceedsRelationItemCalcBusinessBean);

    // --- 計算結果を確定料金実績へ反映 ---
    Fcr fixChargeResult = new Fcr();

    // 料金計算エンジンビジネスの結果
    Fcr fixChargeResultData = saleProceedsRelationItemCalcBusinessBean.getFixChargeResult();

    // 料金メニューID
    fixChargeResult.setRmId(fixChargeResultData.getRmId());

    // 算定期間開始日
    fixChargeResult.setCcSd(fixChargeResultData.getCcSd());

    // 算定期間終了日
    fixChargeResult.setCcEd(fixChargeResultData.getCcEd());

    // 計算用力率
    fixChargeResult.setCalculatingPowerFactor(fixChargeResultData
        .getCalculatingPowerFactor());

    // 月額料金
    fixChargeResult
        .setMonthlyCharge(fixChargeResultData.getMonthlyCharge());

    // 消費税等相当額
    fixChargeResult.setCtEquivalent(fixChargeResultData.getCtEquivalent());

    // 基本料金
    fixChargeResult.setBasicCharge(fixChargeResultData.getBasicCharge());

    // 従量料金
    fixChargeResult.setUsageCharge(fixChargeResultData.getUsageCharge());

    // 燃料費調整額
    fixChargeResult.setFca(fixChargeResultData.getFca());

    // 再エネ賦課金
    fixChargeResult.setRec(fixChargeResultData.getRec());

    // 付帯金額
    fixChargeResult.setSplAmount(fixChargeResultData.getSplAmount());

    // 契約超過金
    fixChargeResult.setCec(fixChargeResultData.getCec());

    // 売上1補正金額
    fixChargeResult
        .setSp1Correction(fixChargeResultData.getSp1Correction());

    // 売上2補正金額
    fixChargeResult
        .setSp2Correction(fixChargeResultData.getSp2Correction());

    // 売上3補正金額
    fixChargeResult
        .setSp3Correction(fixChargeResultData.getSp3Correction());

    // 売上1金額
    fixChargeResult.setSp1(fixChargeResultData.getSp1());

    // 売上2金額
    fixChargeResult.setSp2(fixChargeResultData.getSp2());

    // 売上3金額
    fixChargeResult.setSp3(fixChargeResultData.getSp3());

    // 託送料金相当額（売上関連項目計算では計算されないため）
    fixChargeResult.setConsignmentChargeEquivalent(rateEngineBusinessBean.getFixChargeResult()
        .getConsignmentChargeEquivalent());

    // 返却値の項目に設定
    businessBean.setFixChargeResult(fixChargeResult);

    /**
     * 料金計算警告チェック処理
     */
    // チェック条件設定
    RK_ChargeCalcWarningCheckBusinessBean chargeCalcWarningCheckBusinessBean = new RK_ChargeCalcWarningCheckBusinessBean();
    // 契約ID
    chargeCalcWarningCheckBusinessBean.setContractId(rateEngineBusinessBean.getFixChargeResult().getContractId());
    // 利用年月
    chargeCalcWarningCheckBusinessBean.setUsePeriod(rateEngineBusinessBean.getFixChargeResult().getUsePeriod());
    // 確定使用量ID
    chargeCalcWarningCheckBusinessBean.setFuId(businessBean.getFixUsageLatest().getFuId());
    // 月額料金
    chargeCalcWarningCheckBusinessBean.setMonthlyCharge(saleProceedsRelationItemCalcBusinessBean
        .getFixChargeResult().getMonthlyCharge());
    // 指示数算出使用量
    chargeCalcWarningCheckBusinessBean.setIndicationNoCalculationUsage(rateEngineBusinessBean.getCalculatingFixIn()
        .getInCalculationUsage());
    // 使用量合計
    chargeCalcWarningCheckBusinessBean.setTotalUsage(rateEngineBusinessBean.getCalculatingUsage().getTotalUsage());

    // オンライン処理基準日取得
    Date onlineDate = dateBusiness.getProcessBaseDate(ECISConstants.EXEC_BASE_DATE_ONLINE);

    // チェック基準日
    chargeCalcWarningCheckBusinessBean.setCheckBaseDate(onlineDate);
    // 料金算定開始日
    chargeCalcWarningCheckBusinessBean.setChargeCalculationStartDate(rateEngineBusinessBean.getCalculatingUsage()
        .getCcSd());

    // 計算用使用量
    chargeCalcWarningCheckBusinessBean.setCalculatingUsage(rateEngineBusinessBean.getCalculatingUsage());

    // 料金メニュー
    chargeCalcWarningCheckBusinessBean.setRm(rateEngineBusinessBean.getRm());

    // 検針日数
    chargeCalcWarningCheckBusinessBean.setMeterReadingDays(Integer.valueOf(businessBean.getFixUsageLatest()
        .getMrDays()));

    // 置換前検針日数
    chargeCalcWarningCheckBusinessBean.setBeforeReplacementMeterReadingDays(Integer.valueOf(businessBean
        .getFixUsageLatest().getBeforeReplacementMrDays()));

    // 警告リスト作成
    List<String> warningCodeList = new ArrayList<String>();
    // コンテキストに定義されたビジネスを順にチェックする
    for (RK_ChargeCalcWarningCheckBusiness checkBusiness : checkBusinessList) {
      String warningCode = checkBusiness.check(chargeCalcWarningCheckBusinessBean);
      // 警告コードが返却された場合、警告リストに追加する
      if (StringUtils.isNotEmpty(warningCode)) {
        warningCodeList.add(warningCode);
      }
    }

    /**
     * 確定料金実績警告データ登録
     */
    // 警告チェックビジネスのエラー分、データを登録する
    List<FcrWarningData> fixChargeResultWarningDataList = new ArrayList<FcrWarningData>();
    for (String warningCode : warningCodeList) {
      // 登録情報設定
      FcrWarningData fcrWarningData = new FcrWarningData();
      // 確定料金実績ID
      fcrWarningData.setFcrId(rateEngineBusinessBean.getFixChargeResult().getFcrId());
      // 警告種別コード
      fcrWarningData.setWarningClassCode(warningCode);

      fixChargeResultWarningDataList.add(fcrWarningData);
    }

    // 返却値の項目に設定
    businessBean
        .setFixChargeResultWarningDataList(fixChargeResultWarningDataList);

    // 処理結果の登録
    businessBean
        .setExecuteResult(rateEngineBusinessBean.getExecuteResult());

    //表示順と明細出力順でソートする（昇順）
    businessBean.getFixChargeResultBreakdownList().sort(Comparator.comparing(
        FcrBreakdown::getDisplayOrder).thenComparing(
            FcrBreakdown::getDetailOutputOrder));

  }

  // 商品化追加開発：料金シミュレーション ykomoto 2016/04/20 Edit Start
  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.rk.RK_OnlineCommonBusiness#
   * calculateSimlation
   * (jp.co.unisys.enability.cis.business.rk.model.RK_OnlineCommonBusinessBean
   * )
   */
  @Override
  public void rateSimulation(RK_OnlineCommonBusinessBean businessBean, Date upBaseDate) {

    // Beanを生成
    RateEngineBusinessBean rateEngineBusinessBean = new RateEngineBusinessBean();
    // ===================================================
    // 料金計算の前準備
    // ===================================================

    // 料金シミュレーションは日割り計算を考慮しないため、検針日数に算定日数を設定する。
    businessBean.getFixUsageLatest().setMrDays(businessBean.getFixUsageLatest().getCcDays());
    businessBean.getFixUsageLatest().setBeforeReplacementMrDays(businessBean.getFixUsageLatest().getCcDays());

    // 引数.《料金計算オンライン共通ビジネスBean》から《料金計算エンジンビジネスBean》へ詰め替え
    // 計算用使用量コピー
    CalculatingUsage calculatingUsage = new CalculatingUsage();

    // 引数.《料金計算オンライン共通ビジネスBean》.確定使用量（最新）.契約ID
    // →《料金計算エンジンビジネスBean》.計算用使用量.契約ID
    calculatingUsage.setContractId(businessBean.getFixUsageLatest()
        .getContractId());

    // 引数.《料金計算オンライン共通ビジネスBean》.確定使用量（最新）.利用年月
    // →《料金計算エンジンビジネスBean》.計算用使用量.利用年月
    calculatingUsage.setUsePeriod(businessBean.getFixUsageLatest()
        .getUsePeriod());

    // 引数.《料金計算オンライン共通ビジネスBean》.確定使用量（最新）.確定使用量ID
    // →《料金計算エンジンビジネスBean》.計算用使用量.確定使用量ID
    calculatingUsage.setFuId(businessBean.getFixUsageLatest().getFuId());

    // 引数.《料金計算オンライン共通ビジネスBean》.確定使用量（最新）.使用量
    // →《料金計算エンジンビジネスBean》.計算用使用量.使用量合計
    calculatingUsage.setTotalUsage(businessBean.getFixUsageLatest()
        .getUsageQuantity());

    // 引数.《料金計算オンライン共通ビジネスBean》.確定使用量（最新）.使用開始日
    // →《料金計算エンジンビジネスBean》.計算用使用量.料金算定開始日
    calculatingUsage.setCcSd(businessBean.getFixUsageLatest().getUsageSd());

    // 引数.《料金計算オンライン共通ビジネスBean》.確定使用量（最新）.使用終了日
    // →《料金計算エンジンビジネスBean》.計算用使用量.料金算定終了日
    calculatingUsage.setCcEd(businessBean.getFixUsageLatest().getUsageEd());

    // 引数.《料金計算オンライン共通ビジネスBean》.確定使用量（最新）.料金算定日数
    // →《料金計算エンジンビジネスBean》.計算用使用量.料金算定日数
    calculatingUsage
        .setCcDays(businessBean.getFixUsageLatest().getCcDays());

    // 引数.《料金計算オンライン共通ビジネスBean》.確定使用量（最新）.検針日数
    // →《料金計算エンジンビジネスBean》.計算用使用量.日割日数
    calculatingUsage.setProratedBasisDays(businessBean.getFixUsageLatest()
        .getMrDays());

    // 引数.《料金計算オンライン共通ビジネスBean》.確定使用量（最新）.力率
    // →《料金計算エンジンビジネスBean》.計算用使用量.力率
    calculatingUsage.setPowerFactor(businessBean.getFixUsageLatest()
        .getPowerFactor());

    // 引数.《料金計算オンライン共通ビジネスBean》.契約容量
    // →《料金計算エンジンビジネスBean》.計算用使用量.契約容量
    calculatingUsage.setCca(businessBean.getContractCapacity());

    if (businessBean.getRateMenu() != null) {

      // 引数.《料金計算オンライン共通ビジネスBean》.料金メニュー.料金メニューID
      // →《料金計算エンジンビジネスBean》.計算用使用量.料金メニューID
      calculatingUsage.setRmId(businessBean.getRateMenu().getRmId());
    }

    // 引数.《料金計算オンライン共通ビジネスBean》.契約電力決定区分コード
    // →《料金計算エンジンビジネスBean》.契約電力決定区分コード
    calculatingUsage.setCcDecisionCategoryCode(ECISCodeConstants.CONTRACT_CAPACITY_DECISION_CATEGORY_CODE_DISCUSSIONS);

    // 引数.《料金計算オンライン共通ビジネスBean》.当月最大電力
    // →《料金計算エンジンビジネスBean》.当月最大電力
    calculatingUsage.setPkw(PKW);

    // メンバに設定
    rateEngineBusinessBean.setCalculatingUsage(calculatingUsage);

    // 引数.《料金計算オンライン共通ビジネスBean》.時間帯別使用量（最新）の件数分、
    // 《料金計算エンジンビジネスBean》.計算用時間帯別使用量へ内容をコピーし、リストに追加する。
    List<CalculatingTsUsage> calculatingTimeSlotUsageeBusinessBeanList = new ArrayList<CalculatingTsUsage>();
    CalculatingTsUsage calculatingTimeSlotUsageeBusinessBean = null;
    // 計算用時間帯別使用量の数分、処理を行う
    if (businessBean.getTimeSlotUsageLatestList() != null) {
      for (TsUsage tsUsage : businessBean.getTimeSlotUsageLatestList()) {
        // Beanを生成
        calculatingTimeSlotUsageeBusinessBean = new CalculatingTsUsage();

        // 引数.《料金計算オンライン共通ビジネスBean》.確定使用量（最新）.契約ID
        // →《計算用時間帯別使用量》.契約ID
        calculatingTimeSlotUsageeBusinessBean
            .setContractId(businessBean.getFixUsageLatest()
                .getContractId());

        // 引数.《料金計算オンライン共通ビジネスBean》.確定使用量（最新）.利用年月
        // →《計算用時間帯別使用量》.利用年月
        calculatingTimeSlotUsageeBusinessBean.setUsePeriod(businessBean
            .getFixUsageLatest().getUsePeriod());

        // 引数.《料金計算オンライン共通ビジネスBean》.確定使用量（最新）.使用開始日
        // →《計算用時間帯別使用量》.日割開始日
        calculatingTimeSlotUsageeBusinessBean.setDsSd(businessBean
            .getFixUsageLatest().getUsageSd());

        // 引数.《料金計算オンライン共通ビジネスBean》.時間帯別使用量（最新）.時間帯コード
        // →《計算用時間帯別使用量》.時間帯コード
        calculatingTimeSlotUsageeBusinessBean.setTsCode(tsUsage
            .getTsCode());

        // 引数.《料金計算オンライン共通ビジネスBean》.時間帯別使用量（最新）.時間帯名称
        // →《計算用時間帯別使用量》.時間帯名称
        calculatingTimeSlotUsageeBusinessBean.setTsName(tsUsage
            .getTsName());

        // 引数.《料金計算オンライン共通ビジネスBean》.時間帯別使用量（最新）.使用量
        // →《計算用時間帯別使用量》.使用量
        calculatingTimeSlotUsageeBusinessBean.setUsageQuantity(tsUsage
            .getUsageQuantity());

        // リストに追加
        calculatingTimeSlotUsageeBusinessBeanList
            .add(calculatingTimeSlotUsageeBusinessBean);
      }
    }
    rateEngineBusinessBean
        .setCalculatingTimeSlotUsage(calculatingTimeSlotUsageeBusinessBeanList);

    //《料金計算エンジンビジネスBean》.計算用日割別使用量へ内容をコピーし、リストに追加する。
    //《計算用日割別使用量》を生成する
    CalculatingDsUsage calculatingDsUsage = new CalculatingDsUsage();

    // 引数.《料金計算オンライン共通ビジネスBean》.確定使用量（最新）.契約ID
    // →《計算用日割別使用量》.契約ID
    calculatingDsUsage.setContractId(businessBean.getFixUsageLatest().getContractId());

    // 引数.《料金計算オンライン共通ビジネスBean》.確定使用量（最新）.利用年月
    // →《計算用日割別使用量》.利用年月
    calculatingDsUsage.setUsePeriod(businessBean.getFixUsageLatest().getUsePeriod());

    // 引数.《料金計算オンライン共通ビジネスBean》.確定使用量（最新）.使用開始日
    // →《計算用日割別使用量》.日割開始日
    calculatingDsUsage.setDsSd(businessBean.getFixUsageLatest().getUsageSd());

    // 引数.《料金計算オンライン共通ビジネスBean》.確定使用量（最新）.使用終了日
    // →《計算用日割別使用量》.日割終了日
    calculatingDsUsage.setDsEd(businessBean.getFixUsageLatest().getUsageEd());

    // (引数.《料金計算オンライン共通ビジネスBean》.確定使用量（最新）.使用終了日
    // －引数.《料金計算オンライン共通ビジネスBean》.確定使用量（最新）.使用開始日）＋１ の計算した日数
    // →《計算用日割別使用量》.日割日数
    long diff = (businessBean.getFixUsageLatest().getUsageEd().getTime()
        - businessBean.getFixUsageLatest().getUsageSd().getTime());
    short days = (short) (diff / ECISConstants.ONE_DAY_MILLI_SECONDS + 1);
    calculatingDsUsage.setProratedBasisDays(days);

    // 引数.《料金計算オンライン共通ビジネスBean》.確定使用量（最新）.使用量
    // →《計算用日割別使用量》.使用量
    calculatingDsUsage.setUsageQuantity(businessBean.getFixUsageLatest().getUsageQuantity());

    // 引数.《料金計算オンライン共通ビジネスBean》.契約容量
    // →《計算用日割別使用量》.契約容量
    calculatingDsUsage.setCca(businessBean.getContractCapacity());

    // 引数.《料金計算オンライン共通ビジネスBean》.料金メニュー.料金メニューIDがNULLでない場合、
    // 引数.《料金計算オンライン共通ビジネスBean》.料金メニュー.料金メニューID
    // →《計算用日割別使用量》.料金メニューID

    if (businessBean.getRateMenu() != null && businessBean.getRateMenu().getRmId() != null) {
      calculatingDsUsage.setRmId(businessBean.getRateMenu().getRmId());
    }
    // 《料金計算エンジンビジネスBean》.計算用日割別使用量へ追加する。
    List<CalculatingDsUsage> calculatingDsUsageList = new ArrayList<>();
    calculatingDsUsageList.add(calculatingDsUsage);
    rateEngineBusinessBean.setCalculatingDateSlotUsage(calculatingDsUsageList);

    // 計算用指示数
    CalculatingFixIn calculatingFixIn = new CalculatingFixIn();
    calculatingFixIn.setContractId(businessBean.getFixUsageLatest().getContractId());
    calculatingFixIn.setUsePeriod(businessBean.getFixUsageLatest().getUsePeriod());
    calculatingFixIn.setInCalculationUsage(businessBean.getFixIndicationNoLatest().getInCalculationUsage());
    calculatingFixIn.setMeterCatCode(businessBean.getFixIndicationNoLatest().getMeterCatCode());
    rateEngineBusinessBean.setCalculatingFixIn(calculatingFixIn);

    // ===================================================
    // 料金計算エンジンビジネス.料金計算処理を呼び出し
    // ===================================================
    // 引数1 ：引数.《料金計算オンライン共通ビジネスBean》.確定使用量（最新）.契約ID
    // 引数2 ：引数.《料金計算オンライン共通ビジネスBean》.確定使用量（最新）.利用年月
    // 引数3 ：《料金計算エンジンビジネスBean》
    // 戻り値：なし
    // 2016/07/01 料金シミュレーション不具合対応 Mod Start
    //		rateEngineBusiness.rateSimulation(businessBean.getFixUsageLatest()
    //				.getContractId(), businessBean.getFixUsageLatest()
    //				.getUsePeriod(), rateEngineBusinessBean);

    rateEngineBusiness.rateSimulation(businessBean.getFixUsageLatest()
        .getContractId(),
        businessBean.getFixUsageLatest()
            .getUsePeriod(),
        rateEngineBusinessBean, upBaseDate);
    // 2016/07/01 料金シミュレーション不具合対応 Mod End

    // エンジン失敗の場合処理を終了する。
    if (ECISRKConstants.EXECUTE_RESULT_ONE.equals(rateEngineBusinessBean.getExecuteResult())) {
      businessBean.setExecuteResult(rateEngineBusinessBean.getExecuteResult());
      return;
    }

    // --- 結果をBean設定 ---
    setCalculateRetryRateReturnBean(businessBean, rateEngineBusinessBean);
  }

  // 商品化追加開発：料金シミュレーション ykomoto 2016/04/20 Edit End

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.rk.RK_OnlineCommonBusiness#
   * discountCalculate
   * (jp.co.unisys.enability.cis.business.rk.model.RK_OnlineCommonBusinessBean
   * )
   */
  @Override
  public void limitingDiscontinuedDiscountCalculate(RK_OnlineCommonBusinessBean businessBean)
      throws BusinessLogicException {
    // プロパティ取得
    Properties prop;
    try {
      prop = applicationProperties.getObject();
    } catch (IOException ioe) {
      throw new SystemException(messageSource.getMessage("error.E1129",
          null, Locale.getDefault()), ioe);
    }

    // 制限中止割引に必要な対象月の基本料金を取得する。
    // 確定料金実績取得
    FcrExample fixChargeResultExample = new FcrExample();
    FcrExample.Criteria fixChargeResultCriteria = fixChargeResultExample
        .createCriteria();

    // 契約ID
    fixChargeResultCriteria.andContractIdEqualTo(businessBean
        .getContractId());
    // 利用年月
    fixChargeResultCriteria.andUsePeriodEqualTo(businessBean
        .getCoveredPeriod());

    // 上記検索条件をもとにDBから取得
    List<Fcr> fixChargeResultList = fixChargeResultMapper
        .selectByExample(fixChargeResultExample);

    if (CollectionUtils.isEmpty(fixChargeResultList)) {
      throw new BusinessLogicException("error.E1589", businessBean
          .getCoveredPeriod());
    }

    // 割引対象コードより基本料金の確定料金実績内訳区分コードを判断
    // 確定料金実績内訳区分コード = 101（基本料金）
    String fcrBreakdownCatCode = ECISCodeConstants.FCR_BREAKDOWN_CATEGORY_CODE_BASIC_CHARGE;
    if (ECISCodeConstants.D_COVERED_CODE_RESERVE_A.equals(businessBean.getDiscountCoveredCode())) {
      // 確定料金実績内訳区分コード = 103（基本料金(予備線)）
      fcrBreakdownCatCode = ECISCodeConstants.FCR_BREAKDOWN_CATEGORY_CODE_BASIC_CHARGE_RESERVE_LINE;
    } else if (ECISCodeConstants.D_COVERED_CODE_RESERVE_B.equals(businessBean.getDiscountCoveredCode())) {
      // 確定料金実績内訳区分コード = 104（基本料金(予備電源)）
      fcrBreakdownCatCode = ECISCodeConstants.FCR_BREAKDOWN_CATEGORY_CODE_BASIC_CHARGE_RESERVE_POWER_SUPPLY;
    }

    // 確定料金実績内訳取得
    FcrBreakdownExample fixChargeResultBreakdownExample = new FcrBreakdownExample();
    fixChargeResultBreakdownExample.createCriteria().
    // 確定料金実績内訳区分コード
        andFcrBreakdownCatCodeEqualTo(fcrBreakdownCatCode).
        // 確定料金実績ID
        andFcrIdEqualTo(fixChargeResultList.get(0).getFcrId());
    // 上記検索条件をもとにDBから取得
    List<FcrBreakdown> fixChargeResultBreakdownList = fixChargeResultBreakdownMapper
        .selectByExample(fixChargeResultBreakdownExample);

    // 基本料金の単価・金額を取得
    BigDecimal unitPrice = BigDecimal.ZERO;
    BigDecimal amount = BigDecimal.ZERO;
    if (fixChargeResultBreakdownList.size() > 0) {
      unitPrice = fixChargeResultBreakdownList.get(0).getUp();
      amount = fixChargeResultBreakdownList.get(0).getAmount();
    }

    // 当月の制限中止割引であるかの判定が不要になった(ここにたどり着く前に当月分は排除)
    // 取得した確定料金実績リストから力率、契約容量を設定する。
    // 力率
    int powerFactor = fixChargeResultList.get(0).getCalculatingPowerFactor() == null
        ? DEFAULT_POWER_FACTOR
        : fixChargeResultList.get(0).getCalculatingPowerFactor();
    // 契約容量
    BigDecimal contractCurrentCapacityPower = fixChargeResultList.get(0).getCca();

    // 計算後力率
    int powerFactorAft = DEFAULT_POWER_FACTOR - powerFactor;

    // 計算後基本料金
    BigDecimal baseChargeAft = BigDecimal.ZERO;
    if (ECISCodeConstants.FCR_BREAKDOWN_CATEGORY_CODE_BASIC_CHARGE.equals(fcrBreakdownCatCode)) {
      // 主契約
      baseChargeAft = contractCurrentCapacityPower
          .multiply(unitPrice)
          .multiply(new BigDecimal("1")
              .add(new BigDecimal(String.valueOf(powerFactorAft))
                  .divide(new BigDecimal(PERCENT_CALCULATE))));

      // 使用量がゼロの場合、基本料金は50%で計算する
      if (BigDecimal.ZERO.equals(businessBean.getTotalUsageQuantity())) {
        baseChargeAft = baseChargeAft.multiply(PERCENT_HARF);
      }
    } else {
      // 予備契約
      baseChargeAft = amount;
    }

    BigDecimal discountrate;
    String limitDateWithUnit;
    // 制限中止割引率を取得する。
    // 引数.《料金計算オンライン共通ビジネスBean》.電圧区分コードが高圧、かつ引数.《料金計算オンライン共通ビジネスBean》.契約電力決定区分コードが協議制の場合、
    if (ECISCodeConstants.CUSTOM_VOLTAGE_CAT_CODE_SPECIALLY_HIGH.equals(businessBean.getVoltageCategoryCode())
        || (ECISCodeConstants.CUSTOM_VOLTAGE_CAT_CODE_HIGH_TENSION
            .equals(businessBean.getVoltageCategoryCode())
            && ECISCodeConstants.CONTRACT_CAPACITY_DECISION_CATEGORY_CODE_DISCUSSIONS
                .equals(businessBean.getContractCapacityDecisionCategoryCode()))) {
      // 引数.《料金計算オンライン共通ビジネスBean》.エリアコードで、外部ファイルから、
      // #制限中止割引率(高圧協議制)_(01～10)の該当制限中止割引率を取得し変数.制限中止割引率に設定する。
      String strDiscountrate = prop.getProperty(MessageFormat.format(
          "limit.suspend.discountrate.hightension.discussions.no{0}",
          businessBean.getAreaCode()));

      discountrate = StringConvertUtil
          .stringToBigDecimal(strDiscountrate);
      // 単位：時間
      limitDateWithUnit = businessBean.getLimitDate().concat(UNIT_TIME);
    } else {
      // それ以外の場合、引数.《料金計算オンライン共通ビジネスBean》.エリアコードで、外部ファイルから、
      // #制限中止割引率(高圧実量制)_(01～10)の該当制限中止割引率を取得し変数.制限中止割引率に設定する。
      String strDiscountrate = prop.getProperty(MessageFormat.format(
          "limit.suspend.discountrate.hightension.realquantity.no{0}",
          businessBean.getAreaCode()));

      discountrate = StringConvertUtil
          .stringToBigDecimal(strDiscountrate);
      // 単位：日
      limitDateWithUnit = businessBean.getLimitDate().concat(UNIT_DAY);
    }

    // 補正額計算
    // 補正額（円）: 引数.《料金計算オンライン共通ビジネスBean》.基本料金×制限中止割引率/100×引数.《料金計算オンライン共通ビジネスBean》.制限中止期間
    Double amountChgDouble = baseChargeAft.doubleValue()
        * (discountrate.doubleValue() / PERCENT_CALCULATE)
        * Double.valueOf(businessBean.getLimitDate()) * -1;
    Double amountChgDoubleChk = amountChgDouble * -1;
    // 頭打ち判定（補正額＞基本料金の場合、基本料金を補正額とする）
    if ((amountChgDoubleChk).compareTo(amount.doubleValue()) > 0) {
      amountChgDouble = amount.doubleValue() * -1;
    }
    String strAmountChg = StringConvertUtil.convertBigDecimalToString(
        BigDecimal.valueOf(amountChgDouble).setScale(2,
            RoundingMode.HALF_UP),
        null);
    logger.info(
        "計算後基本料金:{} 制限中止割引率:{} 補正額計算:{} 計算後力率:{} 契約容量:{} 単価:{} 制限中止期間:{}",
        baseChargeAft, discountrate, amountChgDouble, powerFactorAft,
        contractCurrentCapacityPower,
        unitPrice,
        businessBean.getLimitDate());
    // 変数.補正分類 : “901：電気料金補正額”
    String strCCategoy = ECISRKConstants.FIX_CHARGE_RESULT_BREAKDOWN_CATEGORY_CODE_FOR_ELEC_CHARGE_CRT_AMOUNT;

    // 引数.《料金計算オンライン共通ビジネスBean》.対象年月に入力された値をyyyy年M月の形に編集する
    String strCoveredPeriod = StringConvertUtil.convertDateObjectToString(
        businessBean.getCoveredPeriod(),
        ECISConstants.FORMAT_DATE_yyyyMM,
        ECISConstants.FORMAT_DATE_yyyyM_CHINESE);

    // 変数.項目名称
    String strDisplayName = MessageFormat.format(
        prop.getProperty("limit.suspend.discount.correct.projectname"),
        strCoveredPeriod, limitDateWithUnit);

    // Bean設定
    // 補正分類
    businessBean.setCorrectionCategoy(strCCategoy);

    // 補正額（円）
    businessBean.setAmountChg(strAmountChg);

    // 項目名称
    businessBean.setDisplayName(strDisplayName);
  }

  /**
   * 確定料金実績Mapperのsetter(DI)
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 確定料金実績Mapperを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param fixChargeResultMapper
   *          確定料金実績Mapper
   */
  public void setFixChargeResultMapper(FcrMapper fixChargeResultMapper) {
    this.fixChargeResultMapper = fixChargeResultMapper;
  }

  /**
   * 契約Mapperのsetter(DI)
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約Mapperを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractMapper
   *          契約Mapper
   */
  public void setContractMapper(ContractMapper contractMapper) {
    this.contractMapper = contractMapper;
  }

  /**
   * 契約付加情報Mapperのsetter(DI)
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約付加情報Mapperを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractAddInfoMapper
   *          契約付加情報Mapper
   */
  public void setContractAddInfoMapper(ContractAddInfoMapper contractAddInfoMapper) {
    this.contractAddInfoMapper = contractAddInfoMapper;
  }

  /**
   * 料金メニューMapperのsetter(DI)
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金メニューMapperを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param rateMenuMapper
   *          料金メニューMapper
   */
  public void setRateMenuMapper(RmMapper rateMenuMapper) {
    this.rateMenuMapper = rateMenuMapper;
  }

  /**
   * 確定料金実績警告データMapperのsetter(DI)
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 確定料金実績警告データMapperを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param fixChargeResultWarningDataMapper
   *          確定料金実績警告データMapper
   */
  public void setFixChargeResultWarningDataMapper(
      FcrWarningDataMapper fixChargeResultWarningDataMapper) {
    this.fixChargeResultWarningDataMapper = fixChargeResultWarningDataMapper;
  }

  /**
   * 料金計算オンライン共通Mapperのsetter(DI)
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金計算オンライン共通Mapperを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param rKOnlineCommonMapper
   *          料金計算オンライン共通Mapper
   */
  public void setRKOnlineCommonMapper(
      RK_OnlineCommonMapper onlineCommonMapper) {
    this.rKOnlineCommonMapper = onlineCommonMapper;
  }

  /**
   * 確定料金実績内訳Mapperのsetter(DI)
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 確定料金実績内訳Mapperを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param fixChargeResultBreakdownMapper
   *          確定料金実績内訳Mapper
   */
  public void setFixChargeResultBreakdownMapper(
      FcrBreakdownMapper fixChargeResultBreakdownMapper) {
    this.fixChargeResultBreakdownMapper = fixChargeResultBreakdownMapper;
  }

  /**
   * 確定使用量Mapperのsetter(DI)
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 確定使用量Mapperを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param fixUsageMapper
   *          確定使用量Mapper
   */
  public void setFixUsageMapper(FuMapper fixUsageMapper) {
    this.fixUsageMapper = fixUsageMapper;
  }

  /**
   * 確定指示数Mapperのsetter(DI)
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 確定指示数Mapperを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param fixIndicationNoMapper
   *          確定指示数Mapper
   */
  public void setFixIndicationNoMapper(FixInMapper fixIndicationNoMapper) {
    this.fixIndicationNoMapper = fixIndicationNoMapper;
  }

  /**
   * 契約履歴Mapperのsetter(DI)
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約履歴Mapperを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractHistMapper
   *          契約履歴Mapper
   */
  public void setContractHistMapper(ContractHistMapper contractHistMapper) {
    this.contractHistMapper = contractHistMapper;
  }

  /**
   * 実量歴管理ビジネスのsetter(DI)
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 実量歴管理ビジネスを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param kjRealQuantityHistoryBusiness
   *          実量歴管理ビジネス
   */
  public void setKjRealQuantityHistoryBusiness(
      KJ_RealQuantityHistoryBusiness kjRealQuantityHistoryBusiness) {
    this.kjRealQuantityHistoryBusiness = kjRealQuantityHistoryBusiness;
  }

  /**
   * 契約種別マスタMapperのsetter(DI)
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約種別マスタMapperを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param cclMMapper
   *          契約種別マスタMapper
   */
  public void setCclMMapper(CclMMapper cclMMapper) {
    this.cclMMapper = cclMMapper;
  }

  /**
   * 日割別使用量Mapperのsetter(DI)
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 日割別使用量Mapperを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param dsUsageMapper
   *          日割別使用量Mapper
   */
  public void setDsUsageMapper(DsUsageMapper dsUsageMapper) {
    this.dsUsageMapper = dsUsageMapper;
  }

  /**
   * コード定義プロパティのsetter(DI)
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * コード定義プロパティを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param applicationProperties
   *          コード定義プロパティ
   */
  public void setApplicationProperties(
      PropertiesFactoryBean applicationProperties) {
    this.applicationProperties = applicationProperties;
  }

  /**
   * 料金計算エンジンビジネスのsetter(DI)
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金計算エンジンビジネスを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param rateEngineBusiness
   *          料金計算エンジンビジネス
   */
  public void setRateEngineBusiness(RateEngineBusiness rateEngineBusiness) {
    this.rateEngineBusiness = rateEngineBusiness;
  }

  /**
   * 料金計算警告データチェックビジネスリストのsetter（DI）
   *
   * @param checkBusinessList
   *          料金計算警告データチェックビジネスリスト
   */
  public void setCheckBusinessList(List<RK_ChargeCalcWarningCheckBusiness> checkBusinessList) {
    this.checkBusinessList = checkBusinessList;
  }

  /**
   * 売上関連項目計算ビジネスのsetter（DI）
   *
   * @param rkSaleProceedsRelationItemCalcBusiness
   *          売上関連項目計算ビジネス
   */
  public void setRkSaleProceedsRelationItemCalcBusiness(
      RK_SaleProceedsRelationItemCalcBusiness rkSaleProceedsRelationItemCalcBusiness) {
    this.rkSaleProceedsRelationItemCalcBusiness = rkSaleProceedsRelationItemCalcBusiness;
  }

  /**
   * 日付関連共通ビジネスのsetter(DI)
   *
   * @param dateBusiness
   *          日付関連共通ビジネス
   */
  public void setDateBusiness(DateBusiness dateBusiness) {
    this.dateBusiness = dateBusiness;
  }

  /**
   * メッセージソースのsetter（DI）
   *
   * @param messageSource
   *          メッセーソース
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }

}
