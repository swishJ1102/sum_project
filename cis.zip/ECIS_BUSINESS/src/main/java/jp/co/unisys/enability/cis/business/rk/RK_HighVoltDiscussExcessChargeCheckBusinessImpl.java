package jp.co.unisys.enability.cis.business.rk;

import java.math.BigDecimal;

import jp.co.unisys.enability.cis.business.rk.model.RK_ChargeCalcWarningCheckBusinessBean;
import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;

public class RK_HighVoltDiscussExcessChargeCheckBusinessImpl implements
    RK_ChargeCalcWarningCheckBusiness {

  /**
   * 高圧協議制の契約超過金発生チェックビジネス
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param chargeCalcWarningCheckBean
   *          《料金計算警告チェックビジネスBean》
   * @return 警告コード
   * @see jp.co.unisys.enability.cis.dao.rk.RK_ChargeCalcWarningCheckDao
   */
  @Override
  public String check(
      RK_ChargeCalcWarningCheckBusinessBean chargeCalcWarningCheckBean) {

    BigDecimal contractExcessCharge = null;
    if (chargeCalcWarningCheckBean.getContractExcessCharge() == null) {
      return null;
    } else {
      contractExcessCharge = chargeCalcWarningCheckBean.getContractExcessCharge();
    }

    /**
     * チェックの判断を行う。
     */
    // 契約超過金 ＞ 0 の場合
    if (contractExcessCharge.compareTo(BigDecimal.ZERO) > 0) {
      return ECISRKConstants.WARNING_CLASS_MASTER_HIGH_VOLT_DISCUSS_EXCESS_CHARGE;
    }
    // 戻り値にnullを設定する。
    return null;
  }

}
