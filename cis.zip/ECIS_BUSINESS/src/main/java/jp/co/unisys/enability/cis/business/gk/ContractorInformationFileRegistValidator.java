package jp.co.unisys.enability.cis.business.gk;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import jp.co.unisys.enability.cis.business.kj.model.ContractManagementInformationFileConfigCommon;
import jp.co.unisys.enability.cis.business.kj.model.ContractManagementInformationFileConfigContractor;
import jp.co.unisys.enability.cis.common.util.CommonValidationUtil;
import jp.co.unisys.enability.cis.common.util.EMSMessageResource;

/**
 * 契約者情報ファイル登録チェッククラス
 *
 * @author "Nihon Unisys, Ltd."
 */
public class ContractorInformationFileRegistValidator {

  /** プロパティクラスを定義 */
  private EMSMessageResource emsMessageResource;

  /**
   * メッセージプロパティキー管理のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージプロパティキー管理を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param emsMessageResource
   *          メッセージプロパティキー管理
   */
  public void setEmsMessageResource(EMSMessageResource emsMessageResource) {
    this.emsMessageResource = emsMessageResource;
  }

  /**
   * 契約者情報ファイル登録のバリデーションを実施、チェック結果のメッセージListを返却する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 1 引数のバリデーションを行う。
   * 2 チェック結果がNGの場合、戻り値のメッセージListにエラーメッセージを詰めて返却する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param dataRecordMap
   *          データレコードマップ
   * @return メッセージList
   */
  public List<String> validate(Map<Integer, String> dataRecordMap) {

    List<String> messageList = new ArrayList<String>();

    // データレコード種別：必須チェック
    String dataRecordClass = dataRecordMap
        .get(ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_INDEX);
    if (CommonValidationUtil.isNull(dataRecordClass)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_NAME }));

      // データレコード種別：正規表現チェック
    } else if (dataRecordClass != null
        && !CommonValidationUtil
            .checkByPattern(
                dataRecordClass,
                ContractManagementInformationFileConfigCommon.DATA_KIND_MASK_STRING)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_ITEM_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_NAME }));
    }

    // 契約者番号：必須チェック
    String contractorNo = dataRecordMap
        .get(ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NO_INDEX);
    if (CommonValidationUtil.isNull(contractorNo)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NO_NAME }));

      // 契約者番号：文字種別チェック（半角英数字）
    } else if (contractorNo != null
        && !CommonValidationUtil.isAlphabetNumric(contractorNo)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_ALPHANUMERIC_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NO_NAME }));

      // 契約者番号：文字種別チェック（半角英数字　低圧CISシステム許容文字）
    } else if (contractorNo != null
        && !CommonValidationUtil.isRangeWordByECIS(contractorNo)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NO_NAME,
                      "半角英数字（低圧CISシステム許容文字）" }));

      // 契約者番号：文字列最大長チェック
    } else if (contractorNo != null
        && !CommonValidationUtil
            .maxLength(
                contractorNo,
                ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NO_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NO_NAME,
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NO_LENGTH_STRING }));
    }

    // 個人・法人区分コード：必須チェック
    String individualLegalEntityCategoryCode = dataRecordMap
        .get(ContractManagementInformationFileConfigContractor.DATA_INDIVIDUAL_LEGAL_ENTITY_CATEGORY_CODE_INDEX);
    if (CommonValidationUtil.isNull(individualLegalEntityCategoryCode)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_INDIVIDUAL_LEGAL_ENTITY_CATEGORY_CODE_NAME }));
    }

    // 契約者名1（カナ）：必須チェック
    String contractorName1Kana = dataRecordMap
        .get(ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME1_KANA_INDEX);
    if (CommonValidationUtil.isNull(contractorName1Kana)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME1_KANA_NAME }));

      // 契約者名1（カナ）：文字列最大長チェック
    } else if (contractorName1Kana != null
        && !CommonValidationUtil
            .maxLength(
                contractorName1Kana,
                ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME1_KANA_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME1_KANA_NAME,
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME1_KANA_LENGTH_STRING }));

      // 契約者名1（カナ）：正規表現チェック
    } else if (contractorName1Kana != null
        && !CommonValidationUtil
            .checkByPattern(
                contractorName1Kana,
                ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME1_KANA_MASK_STRING)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_ITEM_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME1_KANA_NAME }));
    }

    // 契約者名1：必須チェック
    String contractorName1 = dataRecordMap
        .get(ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME1_INDEX);
    if (CommonValidationUtil.isNull(contractorName1)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME1_NAME }));

      // 契約者名1：文字種別チェック（全角）
    } else if (contractorName1 != null
        && !CommonValidationUtil.isZenkakuType(contractorName1)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME1_NAME }));

      // 契約者名1：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (contractorName1 != null
        && !CommonValidationUtil.isRangeWordByECIS(contractorName1)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME1_NAME,
                      "全角（低圧CISシステム許容文字）" }));

      // 契約者名1：文字列最大長チェック
    } else if (contractorName1 != null
        && !CommonValidationUtil
            .maxLength(
                contractorName1,
                ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME1_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME1_NAME,
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME1_LENGTH_STRING }));
    }

    // 契約者名2：文字種別チェック（全角）
    String contractorName2 = dataRecordMap
        .get(ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME2_INDEX);
    if (contractorName2 != null
        && !CommonValidationUtil.isZenkakuType(contractorName2)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME2_NAME }));

      // 契約者名2：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (contractorName2 != null
        && !CommonValidationUtil.isRangeWordByECIS(contractorName2)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME2_NAME,
                      "全角（低圧CISシステム許容文字）" }));

      // 契約者名2：文字列最大長チェック
    } else if (contractorName2 != null
        && !CommonValidationUtil
            .maxLength(
                contractorName2,
                ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME2_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME2_NAME,
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME2_LENGTH_STRING }));
    }

    // 契約者名1（宛名用）：文字種別チェック（全角）
    String contractorName1MailingName = dataRecordMap
        .get(ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME1_MAILING_NAME_INDEX);
    if (contractorName1MailingName != null
        && !CommonValidationUtil
            .isZenkakuType(contractorName1MailingName)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME1_MAILING_NAME_NAME }));

      // 契約者名1（宛名用）：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (contractorName1MailingName != null
        && !CommonValidationUtil
            .isRangeWordByECIS(contractorName1MailingName)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME1_MAILING_NAME_NAME,
                      "全角（低圧CISシステム許容文字）" }));

      // 契約者名1（宛名用）：文字列最大長チェック
    } else if (contractorName1MailingName != null
        && !CommonValidationUtil
            .maxLength(
                contractorName1MailingName,
                ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME1_MAILING_NAME_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME1_MAILING_NAME_NAME,
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME1_MAILING_NAME_LENGTH_STRING }));
    }

    // 契約者名2（宛名用）：文字種別チェック（全角）
    String contractorName2MailingName = dataRecordMap
        .get(ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME2_MAILING_NAME_INDEX);
    if (contractorName2MailingName != null
        && !CommonValidationUtil
            .isZenkakuType(contractorName2MailingName)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME2_MAILING_NAME_NAME }));

      // 契約者名2（宛名用）：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (contractorName2MailingName != null
        && !CommonValidationUtil
            .isRangeWordByECIS(contractorName2MailingName)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME2_MAILING_NAME_NAME,
                      "全角（低圧CISシステム許容文字）" }));

      // 契約者名2（宛名用）：文字列最大長チェック
    } else if (contractorName2MailingName != null
        && !CommonValidationUtil
            .maxLength(
                contractorName2MailingName,
                ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME2_MAILING_NAME_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME2_MAILING_NAME_NAME,
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME2_MAILING_NAME_LENGTH_STRING }));
    }

    // 敬称：必須チェック
    String prefix = dataRecordMap
        .get(ContractManagementInformationFileConfigContractor.DATA_PREFIX_INDEX);
    if (CommonValidationUtil.isNull(prefix)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_PREFIX_NAME }));

      // 敬称：文字種別チェック（全角）
    } else if (prefix != null
        && !CommonValidationUtil.isZenkakuType(prefix)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_PREFIX_NAME }));

      // 敬称：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (prefix != null
        && !CommonValidationUtil.isRangeWordByECIS(prefix)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_PREFIX_NAME,
                      "全角（低圧CISシステム許容文字）" }));

      // 敬称：文字列最大長チェック
    } else if (prefix != null
        && !CommonValidationUtil
            .maxLength(
                prefix,
                ContractManagementInformationFileConfigContractor.DATA_PREFIX_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_PREFIX_NAME,
                      ContractManagementInformationFileConfigContractor.DATA_PREFIX_LENGTH_STRING }));
    }

    // 契約者住所（郵便番号）：必須チェック
    String contractorAddressPostalCode = dataRecordMap
        .get(ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_POSTAL_CODE_INDEX);
    if (CommonValidationUtil.isNull(contractorAddressPostalCode)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_POSTAL_CODE_NAME }));

      // 契約者住所（郵便番号）：文字種別チェック（半角数字）
    } else if (contractorAddressPostalCode != null
        && !CommonValidationUtil.isNumric(contractorAddressPostalCode)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_POSTAL_CODE_NAME,
                      "半角数字" }));

      // 契約者住所（郵便番号）：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (contractorAddressPostalCode != null
        && !CommonValidationUtil
            .isRangeWordByECIS(contractorAddressPostalCode)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_POSTAL_CODE_NAME,
                      "半角数字（低圧CISシステム許容文字）" }));

      // 契約者住所（郵便番号）：文字列指定長チェック
    } else if (contractorAddressPostalCode != null
        && !CommonValidationUtil
            .justLength(
                contractorAddressPostalCode,
                ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_POSTAL_CODE_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_STRINGLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_POSTAL_CODE_NAME,
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_POSTAL_CODE_LENGTH_STRING }));
    }

    // 契約者住所（都道府県名）：必須チェック
    String contractorAddressPrefectures = dataRecordMap
        .get(ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_PREFECTURES_INDEX);
    if (CommonValidationUtil.isNull(contractorAddressPrefectures)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_PREFECTURES_NAME }));

      // 契約者住所（都道府県名）：文字種別チェック（全角）
    } else if (contractorAddressPrefectures != null
        && !CommonValidationUtil
            .isZenkakuType(contractorAddressPrefectures)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_PREFECTURES_NAME }));

      // 契約者住所（都道府県名）：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (contractorAddressPrefectures != null
        && !CommonValidationUtil
            .isRangeWordByECIS(contractorAddressPrefectures)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_PREFECTURES_NAME,
                      "全角（低圧CISシステム許容文字）" }));

      // 契約者住所（都道府県名）：文字列最大長チェック
    } else if (contractorAddressPrefectures != null
        && !CommonValidationUtil
            .maxLength(
                contractorAddressPrefectures,
                ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_PREFECTURES_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_PREFECTURES_NAME,
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_PREFECTURES_LENGTH_STRING }));
    }

    // 契約者住所（市区郡町村名）：必須チェック
    String contractorAddressMunicipality = dataRecordMap
        .get(ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_MUNICIPALITY_INDEX);
    if (CommonValidationUtil.isNull(contractorAddressMunicipality)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_MUNICIPALITY_NAME }));

      // 契約者住所（市区郡町村名）：文字種別チェック（全角）
    } else if (contractorAddressMunicipality != null
        && !CommonValidationUtil
            .isZenkakuType(contractorAddressMunicipality)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_MUNICIPALITY_NAME }));

      // 契約者住所（市区郡町村名）：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (contractorAddressMunicipality != null
        && !CommonValidationUtil
            .isRangeWordByECIS(contractorAddressMunicipality)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_MUNICIPALITY_NAME,
                      "全角（低圧CISシステム許容文字）" }));

      // 契約者住所（市区郡町村名）：文字列最大長チェック
    } else if (contractorAddressMunicipality != null
        && !CommonValidationUtil
            .maxLength(
                contractorAddressMunicipality,
                ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_MUNICIPALITY_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_MUNICIPALITY_NAME,
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_MUNICIPALITY_LENGTH_STRING }));
    }

    // 契約者住所（字名・丁目）：文字種別チェック（全角）
    String contractorAddressSection = dataRecordMap
        .get(ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_SECTION_INDEX);
    if (contractorAddressSection != null
        && !CommonValidationUtil
            .isZenkakuType(contractorAddressSection)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_SECTION_NAME }));

      // 契約者住所（字名・丁目）：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (contractorAddressSection != null
        && !CommonValidationUtil
            .isRangeWordByECIS(contractorAddressSection)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_SECTION_NAME,
                      "全角（低圧CISシステム許容文字）" }));

      // 契約者住所（字名・丁目）：文字列最大長チェック
    } else if (contractorAddressSection != null
        && !CommonValidationUtil
            .maxLength(
                contractorAddressSection,
                ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_SECTION_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_SECTION_NAME,
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_SECTION_LENGTH_STRING }));
    }

    // 契約者住所（番地･号）：文字列最大長チェック
    String contractorAddressBlock = dataRecordMap
        .get(ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_BLOCK_INDEX);
    if (contractorAddressBlock != null
        && !CommonValidationUtil
            .maxLength(
                contractorAddressBlock,
                ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_BLOCK_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_BLOCK_NAME,
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_BLOCK_LENGTH_STRING }));

      // 契約者住所（番地･号）：正規表現チェック
    } else if (contractorAddressBlock != null
        && !CommonValidationUtil
            .checkByPattern(
                contractorAddressBlock,
                ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_BLOCK_MASK_STRING)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_ITEM_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_BLOCK_NAME }));
    }

    // 契約者住所（建物名）：文字種別チェック（全角）
    String contractorAddressBuildingName = dataRecordMap
        .get(ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_BUILDING_NAME_INDEX);
    if (contractorAddressBuildingName != null
        && !CommonValidationUtil
            .isZenkakuType(contractorAddressBuildingName)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_BUILDING_NAME_NAME }));

      // 契約者住所（建物名）：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (contractorAddressBuildingName != null
        && !CommonValidationUtil
            .isRangeWordByECIS(contractorAddressBuildingName)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_BUILDING_NAME_NAME,
                      "全角（低圧CISシステム許容文字）" }));

      // 契約者住所（建物名）：文字列最大長チェック
    } else if (contractorAddressBuildingName != null
        && !CommonValidationUtil
            .maxLength(
                contractorAddressBuildingName,
                ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_BUILDING_NAME_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_BUILDING_NAME_NAME,
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_BUILDING_NAME_LENGTH_STRING }));
    }

    // 契約者住所（部屋名）：文字種別チェック（全角）
    String contractorAddressRoom = dataRecordMap
        .get(ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_ROOM_INDEX);
    if (contractorAddressRoom != null
        && !CommonValidationUtil
            .isZenkakuType(contractorAddressRoom)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_ROOM_NAME }));

      // 契約者住所（部屋名）：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (contractorAddressRoom != null
        && !CommonValidationUtil
            .isRangeWordByECIS(contractorAddressRoom)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_ROOM_NAME,
                      "全角（低圧CISシステム許容文字）" }));

      // 契約者住所（部屋名）：文字列最大長チェック
    } else if (contractorAddressRoom != null
        && !CommonValidationUtil
            .maxLength(
                contractorAddressRoom,
                ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_ROOM_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_ROOM_NAME,
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_ROOM_LENGTH_STRING }));
    }

    // 契約者電話区分コード1：必須チェック
    String contractorPhoneCategoryCode1 = dataRecordMap
        .get(ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_CATEGORY_CODE1_INDEX);
    if (CommonValidationUtil.isNull(contractorPhoneCategoryCode1)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_CATEGORY_CODE1_NAME }));
    }

    // 契約者電話1（市外局番）：必須チェック
    String contractorPhoneAreaCode1 = dataRecordMap
        .get(ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_AREA_CODE1_INDEX);
    if (CommonValidationUtil.isNull(contractorPhoneAreaCode1)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_AREA_CODE1_NAME }));

      // 契約者電話1（市外局番）：文字種別チェック（半角数字）
    } else if (contractorPhoneAreaCode1 != null
        && !CommonValidationUtil.isNumric(contractorPhoneAreaCode1)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_AREA_CODE1_NAME,
                      "半角数字" }));

      // 契約者電話1（市外局番）：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (contractorPhoneAreaCode1 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(contractorPhoneAreaCode1)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_AREA_CODE1_NAME,
                      "半角数字（低圧CISシステム許容文字）" }));

      // 契約者電話1（市外局番）：文字列最大長チェック
    } else if (contractorPhoneAreaCode1 != null
        && !CommonValidationUtil
            .maxLength(
                contractorPhoneAreaCode1,
                ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_AREA_CODE1_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_AREA_CODE1_NAME,
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_AREA_CODE1_LENGTH_STRING }));
    }

    // 契約者電話1（市内局番）：必須チェック
    String contractorPhoneLocalNo = dataRecordMap
        .get(ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_LOCAL_NO_INDEX);
    if (CommonValidationUtil.isNull(contractorPhoneLocalNo)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_LOCAL_NO_NAME }));

      // 契約者電話1（市内局番）：文字種別チェック（半角数字）
    } else if (contractorPhoneLocalNo != null
        && !CommonValidationUtil.isNumric(contractorPhoneLocalNo)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_LOCAL_NO_NAME,
                      "半角数字" }));

      // 契約者電話1（市内局番）：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (contractorPhoneLocalNo != null
        && !CommonValidationUtil
            .isRangeWordByECIS(contractorPhoneLocalNo)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_LOCAL_NO_NAME,
                      "半角数字（低圧CISシステム許容文字）" }));

      // 契約者電話1（市内局番）：文字列最大長チェック
    } else if (contractorPhoneLocalNo != null
        && !CommonValidationUtil
            .maxLength(
                contractorPhoneLocalNo,
                ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_LOCAL_NO_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_LOCAL_NO_NAME,
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_LOCAL_NO_LENGTH_STRING }));
    }

    // 契約者電話1（加入者番号）：必須チェック
    String contractorPhoneDirectoryNo = dataRecordMap
        .get(ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_DIRECTORY_NO_INDEX);
    if (CommonValidationUtil.isNull(contractorPhoneDirectoryNo)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_DIRECTORY_NO_NAME }));

      // 契約者電話1（加入者番号）：文字種別チェック（半角数字）
    } else if (contractorPhoneDirectoryNo != null
        && !CommonValidationUtil.isNumric(contractorPhoneDirectoryNo)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_DIRECTORY_NO_NAME,
                      "半角数字" }));

      // 契約者電話1（加入者番号）：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (contractorPhoneDirectoryNo != null
        && !CommonValidationUtil
            .isRangeWordByECIS(contractorPhoneDirectoryNo)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_DIRECTORY_NO_NAME,
                      "半角数字（低圧CISシステム許容文字）" }));

      // 契約者電話1（加入者番号）：文字列最大長チェック
    } else if (contractorPhoneDirectoryNo != null
        && !CommonValidationUtil
            .maxLength(
                contractorPhoneDirectoryNo,
                ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_DIRECTORY_NO_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_DIRECTORY_NO_NAME,
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_DIRECTORY_NO_LENGTH_STRING }));
    }

    // 契約者電話2（市外局番）：文字種別チェック（半角数字）
    String contractorPhoneAreaCode2 = dataRecordMap
        .get(ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_AREA_CODE2_INDEX);
    if (contractorPhoneAreaCode2 != null
        && !CommonValidationUtil.isNumric(contractorPhoneAreaCode2)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_AREA_CODE2_NAME,
                      "半角数字" }));

      // 契約者電話2（市外局番）：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (contractorPhoneAreaCode2 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(contractorPhoneAreaCode2)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_AREA_CODE2_NAME,
                      "半角数字（低圧CISシステム許容文字）" }));

      // 契約者電話2（市外局番）：文字列最大長チェック
    } else if (contractorPhoneAreaCode2 != null
        && !CommonValidationUtil
            .maxLength(
                contractorPhoneAreaCode2,
                ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_AREA_CODE2_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_AREA_CODE2_NAME,
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_AREA_CODE2_LENGTH_STRING }));
    }

    // 契約者電話2（市内局番）：文字種別チェック（半角数字）
    String contractorPhoneLocalNo2 = dataRecordMap
        .get(ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_LOCAL_NO2_INDEX);
    if (contractorPhoneLocalNo2 != null
        && !CommonValidationUtil.isNumric(contractorPhoneLocalNo2)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_LOCAL_NO2_NAME,
                      "半角数字" }));

      // 契約者電話2（市内局番）：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (contractorPhoneLocalNo2 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(contractorPhoneLocalNo2)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_LOCAL_NO2_NAME,
                      "半角数字（低圧CISシステム許容文字）" }));

      // 契約者電話2（市内局番）：文字列最大長チェック
    } else if (contractorPhoneLocalNo2 != null
        && !CommonValidationUtil
            .maxLength(
                contractorPhoneLocalNo2,
                ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_LOCAL_NO2_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_LOCAL_NO2_NAME,
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_LOCAL_NO2_LENGTH_STRING }));
    }

    // 契約者電話2（加入者番号）：文字種別チェック（半角数字）
    String contractorPhoneDirectoryNo2 = dataRecordMap
        .get(ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_DIRECTORY_NO2_INDEX);
    if (contractorPhoneDirectoryNo2 != null
        && !CommonValidationUtil.isNumric(contractorPhoneDirectoryNo2)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_DIRECTORY_NO2_NAME,
                      "半角数字" }));

      // 契約者電話2（加入者番号）：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (contractorPhoneDirectoryNo2 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(contractorPhoneDirectoryNo2)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_DIRECTORY_NO2_NAME,
                      "半角数字（低圧CISシステム許容文字）" }));

      // 契約者電話2（加入者番号）：文字列最大長チェック
    } else if (contractorPhoneDirectoryNo2 != null
        && !CommonValidationUtil
            .maxLength(
                contractorPhoneDirectoryNo2,
                ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_DIRECTORY_NO2_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_DIRECTORY_NO2_NAME,
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_DIRECTORY_NO2_LENGTH_STRING }));
    }

    // 契約者メールアドレス1：文字列最大長チェック
    String contractorMailAddress1 = dataRecordMap
        .get(ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_MAIL_ADDRESS1_INDEX);
    if (contractorMailAddress1 != null
        && !CommonValidationUtil
            .maxLength(
                contractorMailAddress1,
                ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_MAIL_ADDRESS1_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_MAIL_ADDRESS1_NAME,
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_MAIL_ADDRESS1_LENGTH_STRING }));

      // 契約者メールアドレス1：正規表現チェック
    } else if (contractorMailAddress1 != null
        && !CommonValidationUtil
            .checkByPattern(
                contractorMailAddress1,
                ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_MAIL_ADDRESS1_MASK_STRING)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_ITEM_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_MAIL_ADDRESS1_NAME }));
    }

    // 契約者メールアドレス2：文字列最大長チェック
    String contractorMailAddress2 = dataRecordMap
        .get(ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_MAIL_ADDRESS2_INDEX);
    if (contractorMailAddress2 != null
        && !CommonValidationUtil
            .maxLength(
                contractorMailAddress2,
                ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_MAIL_ADDRESS2_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_MAIL_ADDRESS2_NAME,
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_MAIL_ADDRESS2_LENGTH_STRING }));

      // 契約者メールアドレス2：正規表現チェック
    } else if (contractorMailAddress2 != null
        && !CommonValidationUtil
            .checkByPattern(
                contractorMailAddress2,
                ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_MAIL_ADDRESS2_MASK_STRING)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_ITEM_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_MAIL_ADDRESS2_NAME }));
    }

    // 提供モデルコード：必須チェック
    String provideModelCode = dataRecordMap
        .get(ContractManagementInformationFileConfigContractor.DATA_PROVIDE_MODEL_CODE_INDEX);
    if (CommonValidationUtil.isNull(provideModelCode)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_PROVIDE_MODEL_CODE_NAME }));
    }

    // 提供モデル企業コード：必須チェック
    String provideModelCompanyCode = dataRecordMap
        .get(ContractManagementInformationFileConfigContractor.DATA_PROVIDE_MODEL_COMPANY_CODE_INDEX);
    if (CommonValidationUtil.isNull(provideModelCompanyCode)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_PROVIDE_MODEL_COMPANY_CODE_NAME }));
    }

    // 取引先コード：文字種別チェック（半角英数字）
    String customerCode = dataRecordMap
        .get(ContractManagementInformationFileConfigContractor.DATA_CUSTOMER_CODE_INDEX);
    if (customerCode != null
        && !CommonValidationUtil.isAlphabetNumric(customerCode)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_ALPHANUMERIC_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CUSTOMER_CODE_NAME }));

      // 取引先コード：文字種別チェック（半角英数字　低圧CISシステム許容文字）
    } else if (customerCode != null
        && !CommonValidationUtil.isRangeWordByECIS(customerCode)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CUSTOMER_CODE_NAME,
                      "半角英数字（低圧CISシステム許容文字）" }));

      // 取引先コード：文字列最大長チェック
    } else if (customerCode != null
        && !CommonValidationUtil
            .maxLength(
                customerCode,
                ContractManagementInformationFileConfigContractor.DATA_CUSTOMER_CODE_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_CUSTOMER_CODE_NAME,
                      ContractManagementInformationFileConfigContractor.DATA_CUSTOMER_CODE_LENGTH_STRING }));
    }

    // 督促対象外フラグ：必須チェック
    String urgeNotCoveredFlag = dataRecordMap
        .get(ContractManagementInformationFileConfigContractor.DATA_URGE_NOT_COVERED_FLAG_INDEX);
    if (CommonValidationUtil.isNull(urgeNotCoveredFlag)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_URGE_NOT_COVERED_FLAG_NAME }));
      // 督促対象外フラグ：文字種別チェック（半角数字）
    } else if (urgeNotCoveredFlag != null
        && !CommonValidationUtil.isNumric(urgeNotCoveredFlag)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_URGE_NOT_COVERED_FLAG_NAME,
                      "半角数字" }));

      // 督促対象外フラグ：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (urgeNotCoveredFlag != null
        && !CommonValidationUtil
            .isRangeWordByECIS(urgeNotCoveredFlag)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_URGE_NOT_COVERED_FLAG_NAME,
                      "半角数字（低圧CISシステム許容文字）" }));
      // 督促対象外フラグ：数値範囲チェック
    } else if (urgeNotCoveredFlag != null
        && !CommonValidationUtil
            .checkRange(
                urgeNotCoveredFlag,
                ContractManagementInformationFileConfigContractor.DATA_URGE_NOT_COVERED_FLAG_RANGE_MIN,
                ContractManagementInformationFileConfigContractor.DATA_URGE_NOT_COVERED_FLAG_RANGE_MAX)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_RANGE_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_URGE_NOT_COVERED_FLAG_NAME,
                      ContractManagementInformationFileConfigContractor.DATA_URGE_NOT_COVERED_FLAG_MESSAGE }));
    }

    // 見える化提供フラグ：必須チェック
    String visualizationProvideFlag = dataRecordMap
        .get(ContractManagementInformationFileConfigContractor.DATA_VISUALIZATION_PROVIDE_FLAG_INDEX);
    if (CommonValidationUtil.isNull(visualizationProvideFlag)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_VISUALIZATION_PROVIDE_FLAG_NAME }));

      // 見える化提供フラグ：文字種別チェック（半角数字）
    } else if (visualizationProvideFlag != null
        && !CommonValidationUtil.isNumric(visualizationProvideFlag)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_VISUALIZATION_PROVIDE_FLAG_NAME,
                      "半角数字" }));

      // 見える化提供フラグ：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (visualizationProvideFlag != null
        && !CommonValidationUtil
            .isRangeWordByECIS(visualizationProvideFlag)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_VISUALIZATION_PROVIDE_FLAG_NAME,
                      "半角数字（低圧CISシステム許容文字）" }));
      // 見える化提供フラグ：数値範囲チェック
    } else if (visualizationProvideFlag != null
        && !CommonValidationUtil
            .checkRange(
                visualizationProvideFlag,
                ContractManagementInformationFileConfigContractor.DATA_VISUALIZATION_PROVIDE_FLAG_RANGE_MIN,
                ContractManagementInformationFileConfigContractor.DATA_VISUALIZATION_PROVIDE_FLAG_RANGE_MAX)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_RANGE_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_VISUALIZATION_PROVIDE_FLAG_NAME,
                      ContractManagementInformationFileConfigContractor.DATA_VISUALIZATION_PROVIDE_FLAG_MESSAGE }));
    }

    // 備考：文字列最大長チェック
    String note = dataRecordMap
        .get(ContractManagementInformationFileConfigContractor.DATA_NOTE_INDEX);
    if (note != null
        && !CommonValidationUtil
            .maxLength(
                note,
                ContractManagementInformationFileConfigContractor.DATA_NOTE_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_NOTE_NAME,
                      ContractManagementInformationFileConfigContractor.DATA_NOTE_LENGTH_STRING }));
      // 備考：文字種別チェック（低圧CISシステム許容文字）
    } else if (note != null
        && !CommonValidationUtil
            .isRangeWordByECIS(note)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_NOTE_NAME,
                      "低圧CISシステム許容文字" }));
    }

    // 利用不能フラグ：必須チェック
    String unavailableFlag = dataRecordMap
        .get(ContractManagementInformationFileConfigContractor.DATA_UNAVAILABLE_FLAG_INDEX);
    if (CommonValidationUtil.isNull(unavailableFlag)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_UNAVAILABLE_FLAG_NAME }));
      // 利用不能フラグ：文字種別チェック（半角数字）
    } else if (unavailableFlag != null
        && !CommonValidationUtil.isNumric(unavailableFlag)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_UNAVAILABLE_FLAG_NAME,
                      "半角数字" }));

      // 利用不能フラグ：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (unavailableFlag != null
        && !CommonValidationUtil
            .isRangeWordByECIS(unavailableFlag)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_UNAVAILABLE_FLAG_NAME,
                      "半角数字（低圧CISシステム許容文字）" }));
      // 利用不能フラグ：数値範囲チェック
    } else if (unavailableFlag != null
        && !CommonValidationUtil
            .checkRange(
                unavailableFlag,
                ContractManagementInformationFileConfigContractor.DATA_UNAVAILABLE_FLAG_RANGE_MIN,
                ContractManagementInformationFileConfigContractor.DATA_UNAVAILABLE_FLAG_RANGE_MAX)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_RANGE_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContractor.DATA_UNAVAILABLE_FLAG_NAME,
                      ContractManagementInformationFileConfigContractor.DATA_UNAVAILABLE_FLAG_MESSAGE }));
    }

    return messageList;
  }
}
