package jp.co.unisys.enability.cis.business.kj;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.dao.DataAccessException;

import jp.co.unisys.enability.cis.business.common.DateBusiness;
import jp.co.unisys.enability.cis.business.kj.model.InquiryProvideModelCompanyBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.InquirySalesConsignmentCompanyBusinessBean;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISKJConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISReturnCodeConstants;
import jp.co.unisys.enability.cis.entity.kj.KJ_InquiryProvideModelEntityBean;
import jp.co.unisys.enability.cis.entity.kj.KJ_SalesConsignmentCompanyEntityBean;
import jp.co.unisys.enability.cis.mapper.kj.ProvideModelCompanyInformationCommonMapper;
import jp.co.unisys.enability.cis.mapper.kj.SalesConsignmentCompanyInformationCommonMapper;

/**
 * マスタ情報ビジネス
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.kj.KJ_MasterInformationBusiness
 *
 */
public class KJ_MasterInformationBusinessImpl implements
    KJ_MasterInformationBusiness {

  /**
   * 日付関連共通ビジネス(DI)
   */
  private DateBusiness dateBusiness;

  /**
   * 提供モデル企業情報共通マッパー(DI)
   */
  private ProvideModelCompanyInformationCommonMapper provideModelCompanyInformationCommonMapper;

  /**
   * 営業委託先企業情報共通マッパー(DI)
   */
  private SalesConsignmentCompanyInformationCommonMapper salesConsignmentCompanyInformationCommonMapper;

  /**
   * メッセージソース(DI)
   */
  private MessageSource messageSource;

  /**
   * ログマネジャー
   */
  private static Logger logger = LogManager.getLogger();

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.kj.KJ_MasterInformationBusiness#
   * inquiryProvideModelCompany(jp.co.unisys.enability.cis.business.kj.model.
   * InquiryProvideModelCompanyBusinessBean)
   */
  @Override
  public InquiryProvideModelCompanyBusinessBean inquiryProvideModelCompany(
      InquiryProvideModelCompanyBusinessBean inquiryProvideModelCompanyBusinessBean) {

    // エラーメッセージ変数を定義する
    String errMsg = null;
    try {
      // エラーメッセージを取得する
      errMsg = messageSource.getMessage("error.E1129", new String[] {},
          Locale.getDefault());

      // 検索条件格納用mapを生成、条件を設定する
      Map<String, Object> exampleMap = new HashMap<String, Object>();
      // 提供モデルコードを設定する
      exampleMap.put("provideModelCode",
          inquiryProvideModelCompanyBusinessBean
              .getProvideModelCode());
      // 提供モデル企業コードを設定
      exampleMap.put("provideModelCompanyCode",
          inquiryProvideModelCompanyBusinessBean
              .getProvideModelCompanyCode());
      // 提供モデル企業有効フラグを設定
      exampleMap.put("provideModelCompanyEffectiveFlag",
          inquiryProvideModelCompanyBusinessBean
              .getProvideModelCompanyEffectiveFlag());
      // オンライン処理基準日を取得し、設定する
      exampleMap.put("onlineExecuteBaseDate", dateBusiness
          .getProcessBaseDate(ECISConstants.EXEC_BASE_DATE_ONLINE));

      // 提供モデル企業一覧情報を取得する
      List<KJ_InquiryProvideModelEntityBean> provideModelCompanyList = provideModelCompanyInformationCommonMapper
          .selectProvideModelCompany(exampleMap);

      // 返却した結果をBusinessBeanに格納する
      inquiryProvideModelCompanyBusinessBean
          .setProvideModelList(provideModelCompanyList);

      // リターンコード（0000）を設定する
      inquiryProvideModelCompanyBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);

      // データアクセスエラーまたはオンライン処理基準日取得エラーが発生した場合、
    } catch (DataAccessException e) {
      logger.error(messageSource.getMessage("error.E1129", null,
          Locale.getDefault()), e);
      // リターンコード（G017）を設定する
      inquiryProvideModelCompanyBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      // 返却したメッセージを設定する
      inquiryProvideModelCompanyBusinessBean.setMessage(errMsg);

      // メッセージの取得に失敗した場合、
    } catch (NoSuchMessageException e) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, e);
      // リターンコード（G017）を設定する
      inquiryProvideModelCompanyBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      // メッセージを設定する
      inquiryProvideModelCompanyBusinessBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
    }

    // BusinessBeanを返却する
    return inquiryProvideModelCompanyBusinessBean;
  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.kj.KJ_MasterInformationBusiness#
   * inquirySalesConsignmentCompany
   * (jp.co.unisys.enability.cis.business.kj.model
   * .InquirySalesConsignmentCompanyBusinessBean)
   */
  @Override
  public InquirySalesConsignmentCompanyBusinessBean inquirySalesConsignmentCompany(
      InquirySalesConsignmentCompanyBusinessBean inquirySalesConsignmentCompanyBusinessBean) {

    // エラーメッセージ変数を定義する
    String errMsg = null;
    try {
      // エラーメッセージを取得する
      errMsg = messageSource.getMessage("error.E1129", new String[] {},
          Locale.getDefault());

      // 検索条件格納用mapを生成、条件を設定する
      Map<String, Object> exampleMap = new HashMap<String, Object>();
      // 営業委託先コードを設定する
      exampleMap.put("salesConsignmentCode",
          inquirySalesConsignmentCompanyBusinessBean
              .getSalesConsignmentCode());
      // 営業委託先企業有効フラグを設定する
      exampleMap.put("salesConsignmentCompanyEffectiveFlag",
          inquirySalesConsignmentCompanyBusinessBean
              .getSalesConsignmentCompanyEffectiveFlag());
      // オンライン処理基準日を取得し、設定する。
      exampleMap.put("onlineExecuteBaseDate", dateBusiness
          .getProcessBaseDate(ECISConstants.EXEC_BASE_DATE_ONLINE));

      // 営業委託先企業一覧を取得する
      List<KJ_SalesConsignmentCompanyEntityBean> salesConsignmentCompanyList = salesConsignmentCompanyInformationCommonMapper
          .selectSalesConsignmentCompany(exampleMap);

      // 返却した結果をBusinessBeanに格納する
      inquirySalesConsignmentCompanyBusinessBean
          .setSalesConsignmentCompanyList(salesConsignmentCompanyList);

      // リターンコード（0000）を設定する
      inquirySalesConsignmentCompanyBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);

      // データアクセスエラーが発生した場合、
    } catch (DataAccessException e) {
      logger.error(messageSource.getMessage("error.E1129", null,
          Locale.getDefault()), e);
      // リターンコード（G017）を設定する
      inquirySalesConsignmentCompanyBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      // メッセージを設定する
      inquirySalesConsignmentCompanyBusinessBean.setMessage(errMsg);

      // メッセージの取得に失敗した場合、
    } catch (NoSuchMessageException e) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, e);
      // リターンコード（G017）を設定する
      inquirySalesConsignmentCompanyBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      // メッセージを設定する
      inquirySalesConsignmentCompanyBusinessBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
    }

    // BusinessBeanを返却する
    return inquirySalesConsignmentCompanyBusinessBean;
  }

  /**
   * 日付関連共通ビジネスのsetter(DI)
   *
   * @param dateBusiness
   *          日付関連共通ビジネス
   */
  public void setDateBusiness(DateBusiness dateBusiness) {
    this.dateBusiness = dateBusiness;
  }

  /**
   * 提供モデル企業情報共通マッパーのsetter(DI)
   *
   * @param provideModelCompanyInformationCommonMapper
   *          提供モデル企業情報共通マッパー
   */
  public void setProvideModelCompanyInformationCommonMapper(
      ProvideModelCompanyInformationCommonMapper provideModelCompanyInformationCommonMapper) {
    this.provideModelCompanyInformationCommonMapper = provideModelCompanyInformationCommonMapper;
  }

  /**
   * 営業委託先企業情報共通マッパーのsetter(DI)
   *
   * @param salesConsignmentCompanyInformationCommonMapper
   *          営業委託先企業情報共通マッパー
   */
  public void setSalesConsignmentCompanyInformationCommonMapper(
      SalesConsignmentCompanyInformationCommonMapper salesConsignmentCompanyInformationCommonMapper) {
    this.salesConsignmentCompanyInformationCommonMapper = salesConsignmentCompanyInformationCommonMapper;
  }

  /**
   * メッセージソースのsetter(DI)
   *
   * @param messageSource
   *          メッセージソース
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }
}
