package jp.co.unisys.enability.cis.business.common;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import jp.co.unisys.enability.cis.business.common.model.MailManagementBusinessBean;
import jp.co.unisys.enability.cis.common.Exception.SystemException;
import jp.co.unisys.enability.cis.common.util.EMSConstants;
import jp.co.unisys.enability.cis.common.util.EMSMessageResource;
import jp.co.unisys.enability.cis.common.util.ThreadContext;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.entity.common.MailMng;
import jp.co.unisys.enability.cis.mapper.common.MailMngMapper;

/**
 * メール管理共通ビジネスクラス。
 *
 * <pre>
 * <p><b>【仕様詳細】<b><p>
 * メール管理への登録を行う。
 * </pre>
 *
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.mapper.common.MailMngMapper
 * @see jp.co.unisys.enability.cis.common.util.EMSMessageResource
 */
public class MailManagementBusinessImpl implements MailManagementBusiness {

  /** メール管理マッパー */
  private MailMngMapper mailMngMapper;

  /** メッセージ */
  private EMSMessageResource emsMessageResource;

  /** ロガー */
  private Logger logger = LogManager.getLogger();

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.common.MailManagementBusiness#
   * registMailManagement
   * (jp.co.unisys.enability.cis.business.common.model.MailManagementBusinessBean
   * )
   */
  @Override
  public void registMailManagement(MailManagementBusinessBean bean) {

    MailMng mailEntity = new MailMng();

    List<String> addressToList = bean.getAddressTo();
    List<String> addressCcList = bean.getAddressCc();
    List<String> addressBccList = bean.getAddressBcc();

    // オンラインフラグの取得
    String onlineFlg = ThreadContext.getRequestThreadContext()
        .get(ECISConstants.ONLINE_FLAG_KEY).toString();

    // セミコロン区切りで文字列連結する。
    String addressTo = StringUtils.join(addressToList, ";");
    String addressCc = StringUtils.join(addressCcList, ";");
    String addressBcc = StringUtils.join(addressBccList, ";");

    // 宛先全てが空の場合は、登録せずに処理終了
    if (StringUtils.isEmpty(StringUtils.replace(addressTo, ";", ""))
        && StringUtils.isEmpty(StringUtils.replace(addressCc, ";", ""))
        && StringUtils
            .isEmpty(StringUtils.replace(addressBcc, ";", ""))) {
      // INFOログを出力
      logger.info(emsMessageResource.getMessage("info.I1022", null));

      return;
    }

    // 件名の入力チェック
    if (StringUtils.isEmpty(bean.getSubject())) {
      throw new SystemException(
          emsMessageResource.getMessage("validation.requiredstring", new String[] {"件名" }));
    }

    // 本文の入力チェック
    if (StringUtils.isEmpty(bean.getMailBody())) {
      throw new SystemException(
          emsMessageResource.getMessage("validation.requiredstring", new String[] {"本文" }));
    }

    // 宛先（To）
    mailEntity.setAddressTo(StringUtils.isNotEmpty(StringUtils.replace(
        addressTo, ";", "")) ? addressTo : null);
    // 宛先（Cc）
    mailEntity.setAddressCc(StringUtils.isNotEmpty(StringUtils.replace(
        addressCc, ";", "")) ? addressCc : null);
    // 宛先（Bcc）
    mailEntity.setAddressBcc(StringUtils.isNotEmpty(StringUtils.replace(
        addressBcc, ";", "")) ? addressBcc : null);

    // 件名
    mailEntity.setSubject(bean.getSubject());

    // シーケンスからメールIDを取得
    int mailId = mailMngMapper.nextId();

    // メールID
    mailEntity.setMailId(mailId);
    // 本文に改行2つとメールID（シーケンス）を付与する。
    mailEntity.setMailBody(bean.getMailBody() == null ? ""
        : bean
            .getMailBody()
            + EMSConstants.ENTER_CODE
            + EMSConstants.ENTER_CODE
            + EMSConstants.ENTER_CODE
            + mailId);

    // 本文
    mailEntity.setSendStatusCode(ECISConstants.SEND_STATUS_CODE_UNSENT);
    Date sysDate = new Date();
    Timestamp systime = new Timestamp(sysDate.getTime());

    // 作成日時
    mailEntity.setCreateTime(systime);
    // 更新回数
    mailEntity.setUpdateCount(0);

    // オンラインフラグがオンラインの場合のみ更新する
    if (ECISConstants.ONLINE_FLAG_ONLINE.equals(onlineFlg)) {
      // オンライン更新ユーザID
      mailEntity.setOnlineUpdateUserId(ThreadContext
          .getRequestThreadContext().get(ECISConstants.USER_ID_KEY)
          .toString());
      // オンライン更新日時
      mailEntity.setOnlineUpdateTime(systime);
    }
    // 更新日時
    mailEntity.setUpdateTime(systime);
    // 更新モジュールコード
    mailEntity.setUpdateModuleCode(ThreadContext.getRequestThreadContext()
        .get(ECISConstants.CLASS_NAME_KEY).toString());

    mailMngMapper.insert(mailEntity);

  }

  public void setMailMngMapper(MailMngMapper mailMngMapper) {
    this.mailMngMapper = mailMngMapper;
  }

  public void setEmsMessageResource(EMSMessageResource emsMessageResource) {
    this.emsMessageResource = emsMessageResource;
  }

}
