package jp.co.unisys.enability.cis.business.gk;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import jp.co.unisys.enability.cis.business.kj.model.ContractManagementInformationFileConfigCommon;
import jp.co.unisys.enability.cis.business.kj.model.ContractManagementInformationFileConfigPayment;
import jp.co.unisys.enability.cis.common.util.CommonValidationUtil;
import jp.co.unisys.enability.cis.common.util.EMSMessageResource;

/**
 * 支払情報ファイル登録バリデーション
 *
 * @author "Nihon Unisys, Ltd."
 */
public class PaymentInformationFileRegistValidator {

  /** プロパティクラスを定義 */
  private EMSMessageResource emsMessageResource;

  /**
   * メッセージプロパティキー管理のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージプロパティキー管理を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param emsMessageResource
   *          メッセージプロパティキー管理
   */
  public void setEmsMessageResource(EMSMessageResource emsMessageResource) {
    this.emsMessageResource = emsMessageResource;
  }

  /**
   * 支払情報ファイル登録のバリデーションを実施、チェック結果のメッセージListを返却する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 1 引数のバリデーションを行う。
   * 2 チェック結果がNGの場合、戻り値のメッセージListにエラーメッセージを詰めて返却する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param dataRecordMap
   *          データレコードマップ
   * @return メッセージList
   */
  public List<String> validate(Map<Integer, String> dataRecordMap) {

    List<String> messageList = new ArrayList<String>();

    // データレコード種別：必須チェック
    String dataRecordClass = dataRecordMap
        .get(ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_INDEX);
    if (CommonValidationUtil.isNull(dataRecordClass)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_NAME }));

      // データレコード種別：正規表現チェック
    } else if (dataRecordClass != null
        && !CommonValidationUtil
            .checkByPattern(
                dataRecordClass,
                ContractManagementInformationFileConfigCommon.DATA_KIND_MASK_STRING)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_ITEM_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_NAME }));
    }

    // 契約者番号：必須チェック
    String contractorNo = dataRecordMap
        .get(ContractManagementInformationFileConfigPayment.DATA_CONTRACTOR_NO_INDEX);
    if (CommonValidationUtil.isNull(contractorNo)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigPayment.DATA_CONTRACTOR_NO_NAME }));

      // 契約者番号：文字種別チェック（半角英数字）
    } else if (contractorNo != null
        && !CommonValidationUtil.isAlphabetNumric(contractorNo)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_ALPHANUMERIC_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigPayment.DATA_CONTRACTOR_NO_NAME }));

      // 契約者番号：文字種別チェック（半角英数字　低圧CISシステム許容文字）
    } else if (contractorNo != null
        && !CommonValidationUtil.isRangeWordByECIS(contractorNo)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigPayment.DATA_CONTRACTOR_NO_NAME,
                      "半角英数字（低圧CISシステム許容文字）" }));

      // 契約者番号：文字列最大長チェック
    } else if (contractorNo != null
        && !CommonValidationUtil
            .maxLength(
                contractorNo,
                ContractManagementInformationFileConfigPayment.DATA_CONTRACTOR_NO_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigPayment.DATA_CONTRACTOR_NO_NAME,
                      ContractManagementInformationFileConfigPayment.DATA_CONTRACTOR_NO_LENGTH_STRING }));
    }

    // 口振クレカ翌月請求フラグ：文字種別チェック（半角数字）
    String directDebitCreditCardNextMonthBillingFlag = dataRecordMap
        .get(ContractManagementInformationFileConfigPayment.DATA_DIRECT_DEBIT_CREDIT_CARD_NEXT_MONTH_BILLING_FLAG_INDEX);
    if (directDebitCreditCardNextMonthBillingFlag != null
        && !CommonValidationUtil.isNumric(directDebitCreditCardNextMonthBillingFlag)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigPayment.DATA_DIRECT_DEBIT_CREDIT_CARD_NEXT_MONTH_BILLING_FLAG_NAME,
                      "半角数字" }));

      // 口振クレカ翌月請求フラグ：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (directDebitCreditCardNextMonthBillingFlag != null
        && !CommonValidationUtil
            .isRangeWordByECIS(directDebitCreditCardNextMonthBillingFlag)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigPayment.DATA_DIRECT_DEBIT_CREDIT_CARD_NEXT_MONTH_BILLING_FLAG_NAME,
                      "半角数字（低圧CISシステム許容文字）" }));
      // 口振クレカ翌月請求フラグ：数値範囲チェック
    } else if (directDebitCreditCardNextMonthBillingFlag != null
        && !CommonValidationUtil
            .checkRange(
                directDebitCreditCardNextMonthBillingFlag,
                ContractManagementInformationFileConfigPayment.DATA_DIRECT_DEBIT_CREDIT_CARD_NEXT_MONTH_BILLING_FLAG_RANGE_MIN,
                ContractManagementInformationFileConfigPayment.DATA_DIRECT_DEBIT_CREDIT_CARD_NEXT_MONTH_BILLING_FLAG_RANGE_MAX)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_RANGE_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigPayment.DATA_DIRECT_DEBIT_CREDIT_CARD_NEXT_MONTH_BILLING_FLAG_NAME,
                      ContractManagementInformationFileConfigPayment.DATA_DIRECT_DEBIT_CREDIT_CARD_NEXT_MONTH_BILLING_FLAG_MESSAGE }));
    }

    // 口座クレカID：文字種別チェック（半角数字）
    String accountCreditCardId = dataRecordMap
        .get(ContractManagementInformationFileConfigPayment.DATA_ACCOUNT_CREDIT_CARD_ID_INDEX);
    if (accountCreditCardId != null
        && !CommonValidationUtil.isNumric(accountCreditCardId)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigPayment.DATA_ACCOUNT_CREDIT_CARD_ID_NAME,
                      "半角数字" }));

      // 口座クレカID：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (accountCreditCardId != null
        && !CommonValidationUtil
            .isRangeWordByECIS(accountCreditCardId)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigPayment.DATA_ACCOUNT_CREDIT_CARD_ID_NAME,
                      "半角数字（低圧CISシステム許容文字）" }));
      // 口座クレカID：数値範囲チェック
    } else if (accountCreditCardId != null
        && !CommonValidationUtil
            .checkRange(
                accountCreditCardId,
                ContractManagementInformationFileConfigPayment.DATA_ACCOUNT_CREDIT_CARD_ID_RANGE_MIN,
                ContractManagementInformationFileConfigPayment.DATA_ACCOUNT_CREDIT_CARD_ID_RANGE_MAX)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_RANGE_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigPayment.DATA_ACCOUNT_CREDIT_CARD_ID_NAME,
                      ContractManagementInformationFileConfigPayment.DATA_ACCOUNT_CREDIT_CARD_ID_MESSAGE }));
    }

    // 支払適用開始日：必須チェック
    String paymentStartDate = dataRecordMap
        .get(ContractManagementInformationFileConfigPayment.DATA_PAYMENT_START_DATE_INDEX);
    if (CommonValidationUtil.isNull(paymentStartDate)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigPayment.DATA_PAYMENT_START_DATE_NAME }));

      // 支払適用開始日：日付フォーマットチェック
    } else if (paymentStartDate != null
        && !CommonValidationUtil
            .checkDateFormat(
                paymentStartDate,
                ContractManagementInformationFileConfigPayment.DATA_PAYMENT_START_DATE_FORMAT)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigPayment.DATA_PAYMENT_START_DATE_NAME,
                      ContractManagementInformationFileConfigPayment.DATA_PAYMENT_START_DATE_MESSAGE }));
    }

    // 請求先氏名1：文字種別チェック（全角）
    String billingName1 = dataRecordMap
        .get(ContractManagementInformationFileConfigPayment.DATA_BILLING_NAME1_INDEX);
    if (billingName1 != null
        && !CommonValidationUtil.isZenkakuType(billingName1)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigPayment.DATA_BILLING_NAME1_NAME }));

      // 請求先氏名1：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (billingName1 != null
        && !CommonValidationUtil.isRangeWordByECIS(billingName1)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigPayment.DATA_BILLING_NAME1_NAME,
                      "全角（低圧CISシステム許容文字）" }));

      // 請求先氏名1：文字列最大長チェック
    } else if (billingName1 != null
        && !CommonValidationUtil
            .maxLength(
                billingName1,
                ContractManagementInformationFileConfigPayment.DATA_BILLING_NAME1_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigPayment.DATA_BILLING_NAME1_NAME,
                      ContractManagementInformationFileConfigPayment.DATA_BILLING_NAME1_LENGTH_STRING }));
    }

    // 請求先氏名2：文字種別チェック（全角）
    String billingName2 = dataRecordMap
        .get(ContractManagementInformationFileConfigPayment.DATA_BILLING_NAME2_INDEX);
    if (billingName2 != null
        && !CommonValidationUtil.isZenkakuType(billingName2)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigPayment.DATA_BILLING_NAME2_NAME }));

      // 請求先氏名2：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (billingName2 != null
        && !CommonValidationUtil.isRangeWordByECIS(billingName2)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigPayment.DATA_BILLING_NAME2_NAME,
                      "全角（低圧CISシステム許容文字）" }));

      // 請求先氏名2：文字列最大長チェック
    } else if (billingName2 != null
        && !CommonValidationUtil
            .maxLength(
                billingName2,
                ContractManagementInformationFileConfigPayment.DATA_BILLING_NAME2_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigPayment.DATA_BILLING_NAME2_NAME,
                      ContractManagementInformationFileConfigPayment.DATA_BILLING_NAME2_LENGTH_STRING }));
    }

    // 敬称：文字種別チェック（全角）
    String prefix = dataRecordMap
        .get(ContractManagementInformationFileConfigPayment.DATA_PREFIX_INDEX);
    if (prefix != null && !CommonValidationUtil.isZenkakuType(prefix)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {ContractManagementInformationFileConfigPayment.DATA_PREFIX_NAME }));

      // 敬称：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (prefix != null
        && !CommonValidationUtil.isRangeWordByECIS(prefix)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigPayment.DATA_PREFIX_NAME,
                      "全角（低圧CISシステム許容文字）" }));

      // 敬称：文字列最大長チェック
    } else if (prefix != null
        && !CommonValidationUtil
            .maxLength(
                prefix,
                ContractManagementInformationFileConfigPayment.DATA_PREFIX_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigPayment.DATA_PREFIX_NAME,
                      ContractManagementInformationFileConfigPayment.DATA_PREFIX_LENGTH_STRING }));
    }

    // 請求先住所（郵便番号）：文字種別チェック（半角数字）
    String billingAddressPostalCode = dataRecordMap
        .get(ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_POSTAL_CODE_INDEX);
    if (billingAddressPostalCode != null
        && !CommonValidationUtil.isNumric(billingAddressPostalCode)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_POSTAL_CODE_NAME,
                      "半角数字" }));

      // 請求先住所（郵便番号）：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (billingAddressPostalCode != null
        && !CommonValidationUtil
            .isRangeWordByECIS(billingAddressPostalCode)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_POSTAL_CODE_NAME,
                      "半角数字（低圧CISシステム許容文字）" }));

      // 請求先住所（郵便番号）：文字列指定長チェック
    } else if (StringUtils.isNotEmpty(billingAddressPostalCode)
        && !CommonValidationUtil
            .justLength(
                billingAddressPostalCode,
                ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_POSTAL_CODE_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_STRINGLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_POSTAL_CODE_NAME,
                      ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_POSTAL_CODE_LENGTH_STRING }));
    }

    // 請求先住所（都道府県名）：文字種別チェック（全角）
    String billingAddressPrefectures = dataRecordMap
        .get(ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_PREFECTURES_INDEX);
    if (billingAddressPrefectures != null
        && !CommonValidationUtil
            .isZenkakuType(billingAddressPrefectures)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_PREFECTURES_NAME }));

      // 請求先住所（都道府県名）：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (billingAddressPrefectures != null
        && !CommonValidationUtil
            .isRangeWordByECIS(billingAddressPrefectures)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_PREFECTURES_NAME,
                      "全角（低圧CISシステム許容文字）" }));

      // 請求先住所（都道府県名）：文字列最大長チェック
    } else if (billingAddressPrefectures != null
        && !CommonValidationUtil
            .maxLength(
                billingAddressPrefectures,
                ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_PREFECTURES_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_PREFECTURES_NAME,
                      ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_PREFECTURES_LENGTH_STRING }));
    }

    // 請求先住所（市区郡町村名）：文字種別チェック（全角）
    String billingAddressMunicipality = dataRecordMap
        .get(ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_MUNICIPALITY_INDEX);
    if (billingAddressMunicipality != null
        && !CommonValidationUtil
            .isZenkakuType(billingAddressMunicipality)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_MUNICIPALITY_NAME }));

      // 請求先住所（市区郡町村名）：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (billingAddressMunicipality != null
        && !CommonValidationUtil
            .isRangeWordByECIS(billingAddressMunicipality)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_MUNICIPALITY_NAME,
                      "全角（低圧CISシステム許容文字）" }));

      // 請求先住所（市区郡町村名）：文字列最大長チェック
    } else if (billingAddressMunicipality != null
        && !CommonValidationUtil
            .maxLength(
                billingAddressMunicipality,
                ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_MUNICIPALITY_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_MUNICIPALITY_NAME,
                      ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_MUNICIPALITY_LENGTH_STRING }));
    }

    // 請求先住所（字名・丁目）：文字種別チェック（全角）
    String billingAddressSection = dataRecordMap
        .get(ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_SECTION_INDEX);
    if (billingAddressSection != null
        && !CommonValidationUtil.isZenkakuType(billingAddressSection)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_SECTION_NAME }));

      // 請求先住所（字名・丁目）：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (billingAddressSection != null
        && !CommonValidationUtil
            .isRangeWordByECIS(billingAddressSection)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_SECTION_NAME,
                      "全角（低圧CISシステム許容文字）" }));

      // 請求先住所（字名・丁目）：文字列最大長チェック
    } else if (billingAddressSection != null
        && !CommonValidationUtil
            .maxLength(
                billingAddressSection,
                ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_SECTION_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_SECTION_NAME,
                      ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_SECTION_LENGTH_STRING }));
    }

    // 請求先住所（番地･号）：文字列最大長チェック
    String billingAddressBlock = dataRecordMap
        .get(ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_BLOCK_INDEX);
    if (billingAddressBlock != null
        && !CommonValidationUtil
            .maxLength(
                billingAddressBlock,
                ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_BLOCK_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_BLOCK_NAME,
                      ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_BLOCK_LENGTH_STRING }));

      // 請求先住所（番地･号）：正規表現チェック
    } else if (billingAddressBlock != null
        && !CommonValidationUtil
            .checkByPattern(
                billingAddressBlock,
                ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_BLOCK_MASK_STRING)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_ITEM_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_BLOCK_NAME }));
    }

    // 請求先住所（建物名）：文字種別チェック（全角）
    String billingAddressBuildingName = dataRecordMap
        .get(ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_BUILDING_NAME_INDEX);
    if (billingAddressBuildingName != null
        && !CommonValidationUtil
            .isZenkakuType(billingAddressBuildingName)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_BUILDING_NAME_NAME }));

      // 請求先住所（建物名）：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (billingAddressBuildingName != null
        && !CommonValidationUtil
            .isRangeWordByECIS(billingAddressBuildingName)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_BUILDING_NAME_NAME,
                      "全角（低圧CISシステム許容文字）" }));

      // 請求先住所（建物名）：文字列最大長チェック
    } else if (billingAddressBuildingName != null
        && !CommonValidationUtil
            .maxLength(
                billingAddressBuildingName,
                ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_BUILDING_NAME_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_BUILDING_NAME_NAME,
                      ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_BUILDING_NAME_LENGTH_STRING }));
    }

    // 請求先住所（部屋名）：文字種別チェック（全角）
    String billingAddressRoom = dataRecordMap
        .get(ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_ROOM_INDEX);
    if (billingAddressRoom != null
        && !CommonValidationUtil.isZenkakuType(billingAddressRoom)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_ROOM_NAME }));

      // 請求先住所（部屋名）：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (billingAddressRoom != null
        && !CommonValidationUtil.isRangeWordByECIS(billingAddressRoom)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_ROOM_NAME,
                      "全角（低圧CISシステム許容文字）" }));

      // 請求先住所（部屋名）：文字列最大長チェック
    } else if (billingAddressRoom != null
        && !CommonValidationUtil
            .maxLength(
                billingAddressRoom,
                ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_ROOM_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_ROOM_NAME,
                      ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_ROOM_LENGTH_STRING }));
    }

    // 請求先電話番号：文字列最大長チェック
    String billingPhoneNo = dataRecordMap
        .get(ContractManagementInformationFileConfigPayment.DATA_BILLING_PHONE_NO_INDEX);
    if (billingPhoneNo != null
        && !CommonValidationUtil
            .maxLength(
                billingPhoneNo,
                ContractManagementInformationFileConfigPayment.DATA_BILLING_PHONE_NO_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigPayment.DATA_BILLING_PHONE_NO_NAME,
                      ContractManagementInformationFileConfigPayment.DATA_BILLING_PHONE_NO_LENGTH_STRING }));

      // 請求先電話番号：正規表現チェック
    } else if (billingPhoneNo != null
        && !CommonValidationUtil
            .checkByPattern(
                billingPhoneNo,
                ContractManagementInformationFileConfigPayment.DATA_BILLING_PHONE_NO_MASK_STRING)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_ITEM_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigPayment.DATA_BILLING_PHONE_NO_NAME }));
    }

    // 請求先メールアドレス1：文字列最大長チェック
    String billingMailAddress1 = dataRecordMap
        .get(ContractManagementInformationFileConfigPayment.DATA_BILLING_MAIL_ADDRESS1_INDEX);
    if (billingMailAddress1 != null
        && !CommonValidationUtil
            .maxLength(
                billingMailAddress1,
                ContractManagementInformationFileConfigPayment.DATA_BILLING_MAIL_ADDRESS1_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigPayment.DATA_BILLING_MAIL_ADDRESS1_NAME,
                      ContractManagementInformationFileConfigPayment.DATA_BILLING_MAIL_ADDRESS1_LENGTH_STRING }));

      // 請求先メールアドレス1：正規表現チェック
    } else if (billingMailAddress1 != null
        && !CommonValidationUtil
            .checkByPattern(
                billingMailAddress1,
                ContractManagementInformationFileConfigPayment.DATA_BILLING_MAIL_ADDRESS1_MASK_STRING)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_ITEM_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigPayment.DATA_BILLING_MAIL_ADDRESS1_NAME }));
    }

    // 請求先メールアドレス2：文字列最大長チェック
    String billingMailAddress2 = dataRecordMap
        .get(ContractManagementInformationFileConfigPayment.DATA_BILLING_MAIL_ADDRESS2_INDEX);
    if (billingMailAddress2 != null
        && !CommonValidationUtil
            .maxLength(
                billingMailAddress2,
                ContractManagementInformationFileConfigPayment.DATA_BILLING_MAIL_ADDRESS2_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigPayment.DATA_BILLING_MAIL_ADDRESS2_NAME,
                      ContractManagementInformationFileConfigPayment.DATA_BILLING_MAIL_ADDRESS2_LENGTH_STRING }));

      // 請求先メールアドレス2：正規表現チェック
    } else if (billingMailAddress2 != null
        && !CommonValidationUtil
            .checkByPattern(
                billingMailAddress2,
                ContractManagementInformationFileConfigPayment.DATA_BILLING_MAIL_ADDRESS2_MASK_STRING)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_ITEM_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigPayment.DATA_BILLING_MAIL_ADDRESS2_NAME }));
    }
    return messageList;
  }
}
