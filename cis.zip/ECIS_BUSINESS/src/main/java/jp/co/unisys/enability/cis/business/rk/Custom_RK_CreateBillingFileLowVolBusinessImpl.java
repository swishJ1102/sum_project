package jp.co.unisys.enability.cis.business.rk;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.config.PropertiesFactoryBean;
import org.springframework.context.MessageSource;

import jp.co.unisys.enability.cis.business.gk.GK_WorkCommonBusiness;
import jp.co.unisys.enability.cis.business.gk.model.GK_RegistDownloadManageBusinessBean;
import jp.co.unisys.enability.cis.common.Exception.BusinessLogicException;
import jp.co.unisys.enability.cis.common.Exception.SystemException;
import jp.co.unisys.enability.cis.common.util.Custom_DateCalculateUtil;
import jp.co.unisys.enability.cis.common.util.StringConvertUtil;
import jp.co.unisys.enability.cis.common.util.constants.ECISCodeConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISFunctionIdConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;
import jp.co.unisys.enability.cis.entity.rk.Custom_RK_CreateBillingFileLowVolEntityBean;
import jp.co.unisys.enability.cis.mapper.rk.Custom_RK_CreateBillingFileLowVolMapper;
import jp.sf.orangesignal.csv.Csv;
import jp.sf.orangesignal.csv.CsvConfig;
import jp.sf.orangesignal.csv.handlers.StringArrayListHandler;

/**
 * 請求データファイル出力（低圧）ビジネス_カスタムクラス
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.gk.GK_WorkCommonBusiness
 * @see jp.co.unisys.enability.cis.mapper.rk.Custom_RK_CreateBillingFileLowVolMapper
 *
 *      変更履歴(kg-epj) 2016.02.26 T.Hori 新規作成 2016.05.26 T.Hori JTS-132
 */
public class Custom_RK_CreateBillingFileLowVolBusinessImpl implements Custom_RK_CreateBillingFileLowVolBusiness {

  /**
   * 支払期限までの日数
   */
  private static final int PAYMENT_EXPIRATION_DATE_DAYS = 50;

  /**
   * 検針修正区分(廃止時)
   */
  private static final String METER_READING_CATEGORY_ABOLITION = "02";

  // [kg-epj:JTS-132]<i-start>
  /**
   * 支払方法区分と合算指示区分の出力値のマッピング定義
   */
  private static final Map<String, String> PW_CODE_ADD_UP_INDICATION_CONVERT_MAP = new HashMap<String, String>() {
    {
      // ガス合算の場合：A⇒1
      this.put(ECISCodeConstants.CUSTOM_ADD_UP_INDICATION_CATEGORY_CODE_GAS_ADD_UP, "1");
      // 電気単独の場合：B⇒2
      this.put(ECISCodeConstants.CUSTOM_ADD_UP_INDICATION_CATEGORY_CODE_ELECTRIC_SINGLE, "2");
    }
  };
  // [kg-epj:JTS-132]<i-end>

  /**
   * 使用量丸め桁数
   */
  private static final int METER_USAGE_ROUND_RANGE = 1;

  /**
   * 請求データファイル（低圧）作成Mapper_カスタム(DI)
   */
  private Custom_RK_CreateBillingFileLowVolMapper customRKCreateBillingFileLowVolMapper;

  /**
   * 業務共通ビジネス(DI)
   */
  private GK_WorkCommonBusiness gkWorkCommonBusiness;

  /**
   * プロパティ(DI)
   */
  private PropertiesFactoryBean applicationProperties;

  /**
   * メッセージプロパティ(DI)
   */
  private MessageSource messageSource;

  /*
   * (非 Javadoc)
   * @see jp.co.unisys.enability.cis.business.rk.Custom_RK_CreateBillingFileLowVolBusiness#creatingBillingFileForLowVoltage(java.util.Date)
   */
  @Override
  public void creatingBillingFileForLowVoltage(Date batchExecuteDate) throws BusinessLogicException {

    // バッチ実行日が設定されていない場合、システム例外
    if (batchExecuteDate == null) {
      throw new SystemException(messageSource.getMessage("error.E1411", null, Locale.getDefault()));
    }

    // 条件Map作成
    Map<String, Object> exampleMap = new HashMap<String, Object>();
    exampleMap.put("batchExecuteDate", batchExecuteDate);

    // 請求データ取得
    List<Custom_RK_CreateBillingFileLowVolEntityBean> billingDataList = customRKCreateBillingFileLowVolMapper
        .selectCreateBillingFileForLowVoltageInfo(exampleMap);

    // 取得結果が0件の場合、処理終了
    if (CollectionUtils.isEmpty(billingDataList)) {
      return;
    }

    // プロパティ取得
    Properties prop;
    try {
      prop = applicationProperties.getObject();
    } catch (IOException ioe) {
      throw new SystemException(messageSource.getMessage("error.E1129", null,
          Locale.getDefault()), ioe);
    }

    // ファイル出力先ディレクトリ作成
    String outputBaseDir = prop.getProperty("custom.batch.rk.billingfileforlowvoltage.output.dir");
    String batchExecuteDateStr = StringConvertUtil.convertDateToString(
        batchExecuteDate, ECISConstants.FORMAT_DATE_yyyyMMdd);
    // 出力先パス設定
    String outputFolderPath = new StringBuilder()
        .append(outputBaseDir)
        .append(batchExecuteDateStr)
        .append(ECISConstants.SLASH)
        .toString();

    File outputDir = new File(outputFolderPath);
    // ディレクトリが存在しない場合、再帰作成
    // 再帰作成に失敗した場合、排他エラーで業務例外
    if (!outputDir.exists()
        && !outputDir.mkdirs()) {
      throw new BusinessLogicException(messageSource.getMessage(
          "error.E0039", null, Locale.getDefault()), false);
    }

    // CSV情報作成
    List<String[]> csvDateList = this.createCsvData(billingDataList, prop);

    // CSV設定
    CsvConfig csvconfig = new CsvConfig();
    // 行の区切り：CRLF
    csvconfig.setLineSeparator(ECISConstants.ENTER_CODE);
    // 囲み文字無効
    csvconfig.setQuoteDisabled(true);
    // 空行スキップ設定
    csvconfig.setIgnoreEmptyLines(true);

    // ファイル名設定
    String fileNameTemplate = prop.getProperty("custom.batch.rk.billingfileforlowvoltage");
    String fileName = MessageFormat.format(fileNameTemplate, batchExecuteDateStr);
    String outputFileFullPath = outputFolderPath + fileName;
    File outputFile = new File(outputFileFullPath);

    // CSVファイル作成
    try {
      Csv.save(csvDateList, outputFile, ECISConstants.CUSTOM_ENCODE_TYPE_ASCII, csvconfig,
          new StringArrayListHandler());
    } catch (IOException ioe) {
      throw new SystemException(ioe.getMessage(), ioe);
    }

    // ダウンロード管理登録
    GK_RegistDownloadManageBusinessBean downloadManageBean = new GK_RegistDownloadManageBusinessBean();
    // サブシステムID
    downloadManageBean.setSubsystemId(ECISConstants.SUBSYSTEM_ID_RK);
    // 機能ID
    downloadManageBean.setFunctionId(ECISFunctionIdConstants.FUNCTION_ID.RKC114.toString());
    // ファイル分類コード
    downloadManageBean
        .setFileCategoryCode(ECISCodeConstants.CUSTOM_FILE_CATEGORY_CODE_BILLING_DATA);
    // 論理ファイル名
    downloadManageBean.setLogicalFileName(outputFile.getName());
    // ファイルパス
    downloadManageBean.setFilePath(outputFileFullPath);
    // ダウンロード期限日数取得キー
    downloadManageBean
        .setDownloadExpirationDateCountKey("custom.batch.rk.billingfileforlowvoltage.download.expiration.date");
    // 処理基準日をDate型に変換してから設定する
    downloadManageBean.setExecuteBaseDate(batchExecuteDate);

    // 出力したファイルの情報を【ダウンロード管理】に登録する。
    gkWorkCommonBusiness.registDownloadManage(downloadManageBean);
  }

  /**
   * CSVファイルの情報を作成する
   * 
   * @param billingDataList
   *          請求データエンティティリスト
   * @param prop
   *          プロパティ
   * @return CSVファイル情報リスト
   */
  private List<String[]> createCsvData(
      List<Custom_RK_CreateBillingFileLowVolEntityBean> billingDataList, Properties prop) {
    // プロパティから必要な値を取得
    // 取引種別詳細
    String dealClassDetail = prop.getProperty("custom.batch.rk.dealclassdetail");
    // 最終項目サイン
    String lastItemSign = prop.getProperty("custom.batch.rk.lastitemsign");

    // CSV情報リスト作成
    List<String[]> csvDataList = new ArrayList<String[]>();

    // エンティティの件数分、処理を行う
    for (Custom_RK_CreateBillingFileLowVolEntityBean data : billingDataList) {

      // 必要な値の設定
      // 合算指示区分(支払方法区分)
      String addUpIndicationCategoryCode = data.getPwCode();

      // 支払期限年月日
      Date meterReadingDate = data.getMeterReadingDate();
      Date paymentExpirationDate = null;
      // 合算指示区分が電気単独の場合のみ設定する
      // 検針日+規定日数(50日)
      if (ECISCodeConstants.CUSTOM_ADD_UP_INDICATION_CATEGORY_CODE_ELECTRIC_SINGLE.equals(
          addUpIndicationCategoryCode)) {
        paymentExpirationDate = DateUtils.addDays(meterReadingDate, PAYMENT_EXPIRATION_DATE_DAYS);
      }

      // 日数計算
      // 料金算定開始日取得
      Date chargeCalcStartDate = data.getChargeCalculationStartDate();
      Date chargeCalcEndDate = data.getChargeCalculationEndDate();
      // 差分日数取得
      int dateDiff = Custom_DateCalculateUtil.getDifferenceDate(chargeCalcEndDate, chargeCalcStartDate);
      // 差分日数+1が日数(期間)になる
      String days = StringConvertUtil.integerToString(dateDiff + 1);

      // あとの項目は設定時に判断
      // データレコード設定
      String[] dataRecord = new String[CsvRecordConfig.getCount()];
      // 合算指示区分
      // [kg-epj:JTS-132]<d-start>
      //			dataRecord[CsvRecordConfig.ADD_UP_INDICATION_CAT_CD.getIndex()] = addUpIndicationCategoryCode;
      // [kg-epj:JTS-132]<d-end>
      // [kg-epj:JTS-132]<i-start>
      // 定義外の値の場合は空で出力する
      dataRecord[CsvRecordConfig.ADD_UP_INDICATION_CAT_CD.getIndex()] = PW_CODE_ADD_UP_INDICATION_CONVERT_MAP
          .get(addUpIndicationCategoryCode);
      // [kg-epj:JTS-132]<i-end>
      // お客さま番号
      dataRecord[CsvRecordConfig.CUSTOMER_NO.getIndex()] = data.getGasCustomerNo();
      // 需給契約番号
      // 合算指示区分がガス合算の場合のみ設定
      if (ECISCodeConstants.CUSTOM_ADD_UP_INDICATION_CATEGORY_CODE_GAS_ADD_UP.equals(
          addUpIndicationCategoryCode)) {
        dataRecord[CsvRecordConfig.SUPPLY_CONTRACT_NO.getIndex()] = data.getGasSupplyContractNo();
      }
      // 支払番号
      // 合算指示区分が電気単独の場合のみ設定
      if (ECISCodeConstants.CUSTOM_ADD_UP_INDICATION_CATEGORY_CODE_ELECTRIC_SINGLE.equals(
          addUpIndicationCategoryCode)) {
        dataRecord[CsvRecordConfig.PAYMENT_NO.getIndex()] = data.getGasPaymentNo();
      }
      // 取引発生年月日
      // 検針日(yyyy/MM/dd)
      dataRecord[CsvRecordConfig.DEAL_ACCRUAL_DATE.getIndex()] = StringConvertUtil
          .convertDateToString(meterReadingDate, ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH);
      // 取引種別詳細
      // 固定値
      dataRecord[CsvRecordConfig.DEAL_CLASS_DETAIL.getIndex()] = dealClassDetail;
      // 取引金額（税込）
      // 区切りや単位は付けない数値のみ
      dataRecord[CsvRecordConfig.DEAL_AMOUNT_INCLUDING_TAX.getIndex()] = StringConvertUtil
          .convertBigDecimalToString(data.getMonthlyCharge(), null);
      // 取引消費税
      // 区切りや単位は付けない数値のみ
      dataRecord[CsvRecordConfig.DEAL_CONSUMPTION_TAX.getIndex()] = StringConvertUtil
          .convertBigDecimalToString(data.getConsumptionTaxEquivalent(), null);
      // 消費税率
      // 100で割って小数点以下3桁にした数値で出力
      Integer taxRate = data.getConsumptionTaxRate();
      if (taxRate != null) {
        BigDecimal calcTaxRate = new BigDecimal(taxRate.intValue());
        // 100で割る
        calcTaxRate = calcTaxRate.divide(ECISRKConstants.RATE_DIVIDE_VAL, 3, BigDecimal.ROUND_DOWN);
        // 消費税率にセット
        dataRecord[CsvRecordConfig.CONSUMPTION_TAX_RATE.getIndex()] = calcTaxRate.toString();
      }
      // 支払期限年月日(yyyy/MM/dd)
      dataRecord[CsvRecordConfig.PAYMENT_EXPIRATION_DATE.getIndex()] = StringConvertUtil
          .convertDateToString(paymentExpirationDate, ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH);

      // 日数
      dataRecord[CsvRecordConfig.DAYS.getIndex()] = days;
      // メーター使用量
      // 小数点以下第2位を切り捨てた値を出力する
      // 使用量にはnullは入ってこないため、考慮しない
      BigDecimal meterUsage = data.getUsageQuantity().setScale(METER_USAGE_ROUND_RANGE, RoundingMode.DOWN);
      dataRecord[CsvRecordConfig.METER_USAGE.getIndex()] = StringConvertUtil.convertBigDecimalToString(meterUsage,
          ECISConstants.FORMAT_DECIMAL_SCALE_1_1);
      // 検針修正区分
      // 廃止または解約時のみ、固定値
      String meterReadingReasonCode = data.getMeterReadingReasonCode();
      if (ECISCodeConstants.METER_READING_REASON_CODE_ABOLITION.equals(meterReadingReasonCode)
          || ECISCodeConstants.METER_READING_REASON_CODE_CANCELLATION.equals(meterReadingReasonCode)) {
        dataRecord[CsvRecordConfig.METER_READING_CATEGORY.getIndex()] = METER_READING_CATEGORY_ABOLITION;
      }
      // 営業担当者・組織コード
      dataRecord[CsvRecordConfig.SALES_DEPARTMENT_CD.getIndex()] = data.getSalesDepartmentCd();
      // 問合わせ先コード
      dataRecord[CsvRecordConfig.CONTACT_CD.getIndex()] = data.getContactCd();

      // 最終項目サイン
      dataRecord[CsvRecordConfig.LAST_ITEM_SIGN.getIndex()] = lastItemSign;

      // データレコードをcsv情報リストに追加
      csvDataList.add(dataRecord);
    }
    return csvDataList;
  }

  /**
   * ローカル列挙体：CSVデータレコード情報<br>
   * インデックス、名称、項目数を持つ
   */
  private enum CsvRecordConfig {
    /** 合算指示区分 */
    ADD_UP_INDICATION_CAT_CD(0, "合算指示区分"),
    /** お客さま番号 */
    CUSTOMER_NO(1, "お客さま番号"),
    /** 需給契約番号 */
    SUPPLY_CONTRACT_NO(2, "需給契約番号"),
    /** 支払番号 */
    PAYMENT_NO(3, "支払番号"),
    /** 取引発生年月日 */
    DEAL_ACCRUAL_DATE(4, "取引発生年月日"),
    /** 取引種別詳細 */
    DEAL_CLASS_DETAIL(5, "取引種別詳細"),
    /** 取引金額（税込） */
    DEAL_AMOUNT_INCLUDING_TAX(6, "取引金額（税込）"),
    /** 取引消費税 */
    DEAL_CONSUMPTION_TAX(7, "取引消費税"),
    /** 消費税率 */
    CONSUMPTION_TAX_RATE(8, "消費税率"),
    /** 支払期限年月日 */
    PAYMENT_EXPIRATION_DATE(9, "支払期限年月日"),
    /** 口座振替年月日 */
    ACCOUNT_TRANSFER_DATE(10, "口座振替年月日"),
    /** 立替確定年月日 */
    TRANSFER_FIXED_DATE(11, "立替確定年月日"),
    /** 延滞利息算定元取引発生日 */
    DELAY_INTEREST_CALC_BASED_TRADE_OCCURED_DATE(12, "延滞利息算定元取引発生日"),
    /** 日数 */
    DAYS(13, "日数"),
    /** メーター使用量 */
    METER_USAGE(14, "メーター使用量"),
    /** 検針修正区分 */
    METER_READING_CATEGORY(15, "検針修正区分"),
    /** 営業担当者・組織コード */
    SALES_DEPARTMENT_CD(16, "営業担当者・組織コード"),
    /** 営業担当者コード */
    SALES_PERSON_CD(17, "営業担当者コード"),
    /** 問合わせ先コード */
    CONTACT_CD(18, "問合わせ先コード"),
    /** 備考１ */
    NOTE_1(19, "備考１"),
    /** 備考２ */
    NOTE_2(20, "備考２"),
    /** 払込用紙お知らせ１行目 */
    INFORMATION_1(21, "払込用紙お知らせ１行目"),
    /** 払込用紙お知らせ２行目 */
    INFORMATION_2(22, "払込用紙お知らせ２行目"),
    /** 払込用紙お知らせ３行目 */
    INFORMATION_3(23, "払込用紙お知らせ３行目"),
    /** 払込用紙お知らせ４行目 */
    INFORMATION_4(24, "払込用紙お知らせ４行目"),
    /** 払込用紙お知らせ５行目 */
    INFORMATION_5(25, "払込用紙お知らせ５行目"),
    /** 払込用紙お知らせ６行目 */
    INFORMATION_6(26, "払込用紙お知らせ６行目"),
    /** 払込用紙お知らせ７行目 */
    INFORMATION_7(27, "払込用紙お知らせ７行目"),
    /** 払込用紙お知らせ８行目 */
    INFORMATION_8(28, "払込用紙お知らせ８行目"),
    /** 払込用紙お知らせ９行目 */
    INFORMATION_9(29, "払込用紙お知らせ９行目"),
    /** 払込用紙お知らせ１０行目 */
    INFORMATION_10(30, "払込用紙お知らせ１０行目"),
    /** 最終項目サイン */
    LAST_ITEM_SIGN(31, "最終項目サイン"),
    ;

    private int index;
    private String name;
    private final static int count = values().length;

    /**
     * インデックスと名称を引数に持つコンストラクタ
     * 
     * @param index
     *          csvの順番
     * @param name
     *          csvの出力名称
     */
    private CsvRecordConfig(int index, String name) {
      this.index = index;
      this.name = name;
    }

    public int getIndex() {
      return this.index;
    }

    public String getName() {
      return this.name;
    }

    /**
     * 項目数を返す
     * 
     * @return 定義された項目の項目数
     */
    public static int getCount() {
      return count;
    }
  }

  /**
   * 請求データファイル（低圧）作成Mapper_カスタムのセッター(DI)
   *
   * @param customRKCreateBillingFileLowVolMapper
   *          請求データファイル（低圧）作成Mapper_カスタム
   */
  public void setCustomRKCreateBillingFileLowVolMapper(
      Custom_RK_CreateBillingFileLowVolMapper customRKCreateBillingFileLowVolMapper) {
    this.customRKCreateBillingFileLowVolMapper = customRKCreateBillingFileLowVolMapper;
  }

  /**
   * 業務共通ビジネスのセッター(DI)
   *
   * @param gkWorkCommonBusiness
   *          業務共通ビジネス
   */
  public void setGkWorkCommonBusiness(GK_WorkCommonBusiness gkWorkCommonBusiness) {
    this.gkWorkCommonBusiness = gkWorkCommonBusiness;
  }

  /**
   * プロパティのセッター(DI)
   *
   * @param applicationProperties
   *          プロパティ
   */
  public void setApplicationProperties(PropertiesFactoryBean applicationProperties) {
    this.applicationProperties = applicationProperties;
  }

  /**
   * メッセージプロパティのセッター(DI)
   *
   * @param messageSource
   *          メッセージプロパティ
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }

}
