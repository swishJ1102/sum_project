package jp.co.unisys.enability.cis.business.gk.model;

import java.util.Date;

/**
 * カレンダービジネスBean
 *
 * @author "Nihon Unisys, Ltd."
 */
public class CalendarBusinessBean {

  /**
   * 事業者休日区分を保有する。
   */
  private String operatorHolidayCategory;

  /**
   * 基準日を保有する。
   */
  private Date baseDate;

  /**
   * 終了日を保有する。
   */
  private Date endDate;

  /**
   * 期間数を保有する。
   */
  private Integer termNumberOfDays;

  /**
   * 処理結果を保有する。
   */
  private String processingResult;

  /**
   * リターンコードを保有する。
   */
  private String returnCode;

  /**
   * メッセージを保有する。
   */
  private String message;

  /**
   * 事業者休日区分のgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 事業者休日区分を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 事業者休日区分
   */
  public String getOperatorHolidayCategory() {
    return this.operatorHolidayCategory;
  }

  /**
   * 事業者休日区分のsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 事業者休日区分を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param operatorHolidayCategory
   *          事業者休日区分
   */
  public void setOperatorHolidayCategory(String operatorHolidayCategory) {
    this.operatorHolidayCategory = operatorHolidayCategory;
  }

  /**
   * 基準日のgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 基準日を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 基準日
   */
  public Date getBaseDate() {
    return this.baseDate;
  }

  /**
   * 基準日のsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 基準日を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param baseDate
   *          基準日
   */
  public void setBaseDate(Date baseDate) {
    this.baseDate = baseDate;
  }

  /**
   * 終了日のgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 終了日を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 終了日
   */
  public Date getEndDate() {
    return this.endDate;
  }

  /**
   * 終了日のsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 終了日を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param endDate
   *          終了日
   */
  public void setEndDate(Date endDate) {
    this.endDate = endDate;
  }

  /**
   * 期間数のgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 期間数を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 期間数
   */
  public Integer getTermNumberOfDays() {
    return this.termNumberOfDays;
  }

  /**
   * 期間数のsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 期間数を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param termNumberOfDays
   *          期間数
   */
  public void setTermNumberOfDays(Integer termNumberOfDays) {
    this.termNumberOfDays = termNumberOfDays;
  }

  /**
   * 処理結果のgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 処理結果を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 処理結果
   */
  public String getProcessingResult() {
    return this.processingResult;
  }

  /**
   * 処理結果のsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 処理結果を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param processingResult
   *          処理結果
   */
  public void setProcessingResult(String processingResult) {
    this.processingResult = processingResult;
  }

  /**
   * リターンコードのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * リターンコードを取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return リターンコード
   */
  public String getReturnCode() {
    return this.returnCode;
  }

  /**
   * リターンコードのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * リターンコードを設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param returnCode
   *          リターンコード
   */
  public void setReturnCode(String returnCode) {
    this.returnCode = returnCode;
  }

  /**
   * メッセージのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * メッセージを取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return メッセージ
   */
  public String getMessage() {
    return this.message;
  }

  /**
   * メッセージのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * メッセージを設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param message
   *          メッセージ
   */
  public void setMessage(String message) {
    this.message = message;
  }

}
