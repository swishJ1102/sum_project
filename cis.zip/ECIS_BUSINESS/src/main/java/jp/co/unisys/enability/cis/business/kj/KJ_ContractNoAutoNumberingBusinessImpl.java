package jp.co.unisys.enability.cis.business.kj;

import jp.co.unisys.enability.cis.business.kj.model.RegistAgentContractBusinessBean;

/**
 * 契約番号自動発番ビジネス
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.kj.KJ_ContractNoAutoNumberingBusiness
 *
 */
public class KJ_ContractNoAutoNumberingBusinessImpl implements KJ_ContractNoAutoNumberingBusiness {

  @Override
  public void autoNumbering(RegistAgentContractBusinessBean registAgentContractBusinessBean) {

  }
}
