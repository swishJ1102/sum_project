package jp.co.unisys.enability.cis.business.gk;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import jp.co.unisys.enability.cis.business.kj.model.ContractManagementInformationFileConfigCommon;
import jp.co.unisys.enability.cis.business.kj.model.Custom_ContractManagementInformationFileConfigPayment;
import jp.co.unisys.enability.cis.common.util.CommonValidationUtil;
import jp.co.unisys.enability.cis.common.util.EMSMessageResource;

/**
 * （カスタム）支払情報ファイル登録バリデーション
 *
 * @author "Nihon Unisys, Ltd."
 */
public class Custom_PaymentInformationFileRegistValidator {

  /** プロパティクラスを定義 */
  private EMSMessageResource emsMessageResource;

  /**
   * メッセージプロパティキー管理のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージプロパティキー管理を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param emsMessageResource
   *          メッセージプロパティキー管理
   */
  public void setEmsMessageResource(EMSMessageResource emsMessageResource) {
    this.emsMessageResource = emsMessageResource;
  }

  /**
   * 支払情報ファイル登録のバリデーションを実施、チェック結果のメッセージListを返却する。 （カスタム仕様の追加項目対応）
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 1 引数のバリデーションを行う。
   * 2 チェック結果がNGの場合、戻り値のメッセージListにエラーメッセージを詰めて返却する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param dataRecordMap
   *          データレコードマップ
   * @return メッセージList
   */
  public List<String> validate(Map<Integer, String> dataRecordMap) {

    List<String> messageList = new ArrayList<String>();

    // データレコード種別：必須チェック
    String dataRecordClass = dataRecordMap
        .get(ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_INDEX);
    if (CommonValidationUtil.isNull(dataRecordClass)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_NAME }));

      // データレコード種別：正規表現チェック
    } else if (dataRecordClass != null
        && !CommonValidationUtil
            .checkByPattern(
                dataRecordClass,
                ContractManagementInformationFileConfigCommon.DATA_KIND_MASK_STRING)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_ITEM_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_NAME }));
    }

    // 契約者番号：必須チェック
    String contractorNo = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigPayment.DATA_CONTRACTOR_NO_INDEX);
    if (CommonValidationUtil.isNull(contractorNo)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_CONTRACTOR_NO_NAME }));

      // 契約者番号：文字種別チェック（半角英数字）
    } else if (contractorNo != null
        && !CommonValidationUtil.isAlphabetNumric(contractorNo)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_ALPHANUMERIC_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_CONTRACTOR_NO_NAME }));

      // 契約者番号：文字種別チェック（半角英数字　低圧CISシステム許容文字）
    } else if (contractorNo != null
        && !CommonValidationUtil.isRangeWordByECIS(contractorNo)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_CONTRACTOR_NO_NAME,
                      "半角英数字（低圧CISシステム許容文字）" }));

      // 契約者番号：文字列最大長チェック
    } else if (contractorNo != null
        && !CommonValidationUtil
            .maxLength(
                contractorNo,
                Custom_ContractManagementInformationFileConfigPayment.DATA_CONTRACTOR_NO_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_CONTRACTOR_NO_NAME,
                      Custom_ContractManagementInformationFileConfigPayment.DATA_CONTRACTOR_NO_LENGTH_STRING }));
    }

    // 外部システム契約番号：文字種別チェック（半角英数ハイフン）
    String externalManageContractNo = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigPayment.DATA_EXTERNAL_MANAGE_CONTRACT_NO_INDEX);
    if (externalManageContractNo != null
        && !CommonValidationUtil
            .isAlphabetNumricHyphen(externalManageContractNo)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_ALPHANUMERICHYPHEN_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_EXTERNAL_MANAGE_CONTRACT_NO_NAME }));
      // 外部システム契約番号：文字種別チェック（低圧CISシステム許容文字）
    } else if (externalManageContractNo != null
        && !CommonValidationUtil
            .isRangeWordByECIS(externalManageContractNo)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_EXTERNAL_MANAGE_CONTRACT_NO_NAME,
                      "半角英数字ハイフン（低圧CISシステム許容文字）" }));
      // 外部システム契約番号：文字列最大長チェック
    } else if (externalManageContractNo != null
        && !CommonValidationUtil
            .maxLength(
                externalManageContractNo,
                Custom_ContractManagementInformationFileConfigPayment.DATA_EXTERNAL_MANAGE_CONTRACT_NO_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_EXTERNAL_MANAGE_CONTRACT_NO_NAME,
                      Custom_ContractManagementInformationFileConfigPayment.DATA_EXTERNAL_MANAGE_CONTRACT_NO_LENGTH_STRING }));
    }
    // 外部システム支払番号：文字種別チェック（半角英数ハイフン）
    String externalManagePaymentNo = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigPayment.DATA_EXTERNAL_MANAGE_PAYMENT_NO_INDEX);
    if (externalManagePaymentNo != null
        && !CommonValidationUtil
            .isAlphabetNumricHyphen(externalManagePaymentNo)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_ALPHANUMERICHYPHEN_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_EXTERNAL_MANAGE_PAYMENT_NO_NAME }));
      // 外部システム支払番号：文字種別チェック（低圧CISシステム許容文字）
    } else if (externalManagePaymentNo != null
        && !CommonValidationUtil
            .isRangeWordByECIS(externalManagePaymentNo)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_EXTERNAL_MANAGE_PAYMENT_NO_NAME,
                      "半角英数字ハイフン（低圧CISシステム許容文字）" }));
      // 外部システム支払番号：文字列最大長チェック
    } else if (externalManagePaymentNo != null
        && !CommonValidationUtil
            .maxLength(
                externalManagePaymentNo,
                Custom_ContractManagementInformationFileConfigPayment.DATA_EXTERNAL_MANAGE_PAYMENT_NO_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_EXTERNAL_MANAGE_PAYMENT_NO_NAME,
                      Custom_ContractManagementInformationFileConfigPayment.DATA_EXTERNAL_MANAGE_PAYMENT_NO_LENGTH_STRING }));
    }

    // 口振クレカ翌月請求フラグ：文字種別チェック（半角数字）
    String directDebitCreditCardNextMonthBillingFlag = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigPayment.DATA_DIRECT_DEBIT_CREDIT_CARD_NEXT_MONTH_BILLING_FLAG_INDEX);
    if (directDebitCreditCardNextMonthBillingFlag != null
        && !CommonValidationUtil
            .isNumric(directDebitCreditCardNextMonthBillingFlag)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_DIRECT_DEBIT_CREDIT_CARD_NEXT_MONTH_BILLING_FLAG_NAME,
                      "半角数字" }));

      // 口振クレカ翌月請求フラグ：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (directDebitCreditCardNextMonthBillingFlag != null
        && !CommonValidationUtil
            .isRangeWordByECIS(directDebitCreditCardNextMonthBillingFlag)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_DIRECT_DEBIT_CREDIT_CARD_NEXT_MONTH_BILLING_FLAG_NAME,
                      "半角数字（低圧CISシステム許容文字）" }));
      // 口振クレカ翌月請求フラグ：数値範囲チェック
    } else if (directDebitCreditCardNextMonthBillingFlag != null
        && !CommonValidationUtil
            .checkRange(
                directDebitCreditCardNextMonthBillingFlag,
                Custom_ContractManagementInformationFileConfigPayment.DATA_DIRECT_DEBIT_CREDIT_CARD_NEXT_MONTH_BILLING_FLAG_RANGE_MIN,
                Custom_ContractManagementInformationFileConfigPayment.DATA_DIRECT_DEBIT_CREDIT_CARD_NEXT_MONTH_BILLING_FLAG_RANGE_MAX)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_RANGE_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_DIRECT_DEBIT_CREDIT_CARD_NEXT_MONTH_BILLING_FLAG_NAME,
                      Custom_ContractManagementInformationFileConfigPayment.DATA_DIRECT_DEBIT_CREDIT_CARD_NEXT_MONTH_BILLING_FLAG_MESSAGE }));
    }
    // 支払期限区分：必須チェック
    String paymentExpirationCategory = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigPayment.DATA_PAYMENT_EXPIRATION_CATEGORY_INDEX);
    if (CommonValidationUtil.isNull(paymentExpirationCategory)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_PAYMENT_EXPIRATION_CATEGORY_NAME }));

      // 支払期限区分：文字種別チェック（半角数字）
    } else if (paymentExpirationCategory != null
        && !CommonValidationUtil.isNumric(paymentExpirationCategory)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_PAYMENT_EXPIRATION_CATEGORY_NAME,
                      "半角数字" }));

      // 支払期限区分：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (paymentExpirationCategory != null
        && !CommonValidationUtil
            .isRangeWordByECIS(paymentExpirationCategory)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_PAYMENT_EXPIRATION_CATEGORY_NAME,
                      "半角数字（低圧CISシステム許容文字）" }));
      // 支払期限区分：数値範囲チェック
    } else if (paymentExpirationCategory != null
        && !CommonValidationUtil
            .checkRange(
                paymentExpirationCategory,
                Custom_ContractManagementInformationFileConfigPayment.DATA_PAYMENT_EXPIRATION_CATEGORY_RANGE_MIN,
                Custom_ContractManagementInformationFileConfigPayment.DATA_PAYMENT_EXPIRATION_CATEGORY_RANGE_MAX)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_RANGE_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_PAYMENT_EXPIRATION_CATEGORY_NAME,
                      Custom_ContractManagementInformationFileConfigPayment.DATA_PAYMENT_EXPIRATION_CATEGORY_MESSAGE }));
    }

    // 個別支払期限（月数）：文字種別チェック（半角数字）
    String individualPaymentExpirationMonths = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigPayment.DATA_INDIVIDUAL_PAYMENT_EXPIRATION_MONTHS_INDEX);
    if (individualPaymentExpirationMonths != null
        && !CommonValidationUtil
            .isNumric(individualPaymentExpirationMonths)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_INDIVIDUAL_PAYMENT_EXPIRATION_MONTHS_NAME,
                      "半角数字" }));

      // 個別支払期限（月数）：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (individualPaymentExpirationMonths != null
        && !CommonValidationUtil
            .isRangeWordByECIS(individualPaymentExpirationMonths)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_INDIVIDUAL_PAYMENT_EXPIRATION_MONTHS_NAME,
                      "半角数字（低圧CISシステム許容文字）" }));
      // 個別支払期限（月数）：正規表現チェック
    } else if (individualPaymentExpirationMonths != null
        && !CommonValidationUtil
            .checkByPattern(
                individualPaymentExpirationMonths,
                Custom_ContractManagementInformationFileConfigPayment.DATA_INDIVIDUAL_PAYMENT_EXPIRATION_MONTHS_MASK_STRING)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_ITEM_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_INDIVIDUAL_PAYMENT_EXPIRATION_MONTHS_NAME }));
    }

    // 個別支払期限（日）：文字種別チェック（半角数字）
    String individualPaymentExpirationDate = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigPayment.DATA_INDIVIDUAL_PAYMENT_EXPIRATION_DATE_INDEX);
    if (individualPaymentExpirationDate != null
        && !CommonValidationUtil
            .isNumric(individualPaymentExpirationDate)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_INDIVIDUAL_PAYMENT_EXPIRATION_DATE_NAME,
                      "半角数字" }));
      // 個別支払期限（日）：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (individualPaymentExpirationDate != null
        && !CommonValidationUtil
            .isRangeWordByECIS(individualPaymentExpirationDate)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_INDIVIDUAL_PAYMENT_EXPIRATION_DATE_NAME,
                      "半角数字（低圧CISシステム許容文字）" }));
      // 個別支払期限（日）：正規表現チェック
    } else if (individualPaymentExpirationDate != null
        && !CommonValidationUtil
            .checkByPattern(
                individualPaymentExpirationDate,
                Custom_ContractManagementInformationFileConfigPayment.DATA_INDIVIDUAL_PAYMENT_EXPIRATION_DATE_MASK_STRING)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_ITEM_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_INDIVIDUAL_PAYMENT_EXPIRATION_DATE_NAME }));
    }

    // 請求合算フラグ：必須チェック
    String billingAddUpFlag = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADD_UP_FLAG_INDEX);
    if (CommonValidationUtil.isNull(billingAddUpFlag)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADD_UP_FLAG_NAME }));
      // 請求合算フラグ：文字種別チェック（半角数字）
    } else if (billingAddUpFlag != null
        && !CommonValidationUtil.isNumric(billingAddUpFlag)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADD_UP_FLAG_NAME,
                      "半角数字" }));
      // 請求合算フラグ：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (billingAddUpFlag != null
        && !CommonValidationUtil.isRangeWordByECIS(billingAddUpFlag)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADD_UP_FLAG_NAME,
                      "半角数字（低圧CISシステム許容文字）" }));
      // 請求合算フラグ：数値範囲チェック
    } else if (billingAddUpFlag != null
        && !CommonValidationUtil
            .checkRange(
                billingAddUpFlag,
                Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADD_UP_FLAG_RANGE_MIN,
                Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADD_UP_FLAG_RANGE_MAX)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_RANGE_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADD_UP_FLAG_NAME,
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADD_UP_FLAG_MESSAGE }));
    }

    // 口座クレカID：文字種別チェック（半角数字）
    String accountCreditCardId = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigPayment.DATA_ACCOUNT_CREDIT_CARD_ID_INDEX);
    if (accountCreditCardId != null
        && !CommonValidationUtil.isNumric(accountCreditCardId)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_ACCOUNT_CREDIT_CARD_ID_NAME,
                      "半角数字" }));

      // 口座クレカID：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (accountCreditCardId != null
        && !CommonValidationUtil.isRangeWordByECIS(accountCreditCardId)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_ACCOUNT_CREDIT_CARD_ID_NAME,
                      "半角数字（低圧CISシステム許容文字）" }));
      // 口座クレカID：数値範囲チェック
    } else if (accountCreditCardId != null
        && !CommonValidationUtil
            .checkRange(
                accountCreditCardId,
                Custom_ContractManagementInformationFileConfigPayment.DATA_ACCOUNT_CREDIT_CARD_ID_RANGE_MIN,
                Custom_ContractManagementInformationFileConfigPayment.DATA_ACCOUNT_CREDIT_CARD_ID_RANGE_MAX)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_RANGE_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_ACCOUNT_CREDIT_CARD_ID_NAME,
                      Custom_ContractManagementInformationFileConfigPayment.DATA_ACCOUNT_CREDIT_CARD_ID_MESSAGE }));
    }

    // 支払適用開始日：必須チェック
    String paymentStartDate = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigPayment.DATA_PAYMENT_START_DATE_INDEX);
    if (CommonValidationUtil.isNull(paymentStartDate)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_PAYMENT_START_DATE_NAME }));

      // 支払適用開始日：日付フォーマットチェック
    } else if (paymentStartDate != null
        && !CommonValidationUtil
            .checkDateFormat(
                paymentStartDate,
                Custom_ContractManagementInformationFileConfigPayment.DATA_PAYMENT_START_DATE_FORMAT)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_PAYMENT_START_DATE_NAME,
                      Custom_ContractManagementInformationFileConfigPayment.DATA_PAYMENT_START_DATE_MESSAGE }));
    }

    // 請求先氏名1：文字種別チェック（全角）
    String billingName1 = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_NAME1_INDEX);
    if (billingName1 != null
        && !CommonValidationUtil.isZenkakuType(billingName1)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_NAME1_NAME }));

      // 請求先氏名1：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (billingName1 != null
        && !CommonValidationUtil.isRangeWordByECIS(billingName1)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_NAME1_NAME,
                      "全角（低圧CISシステム許容文字）" }));

      // 請求先氏名1：文字列最大長チェック
    } else if (billingName1 != null
        && !CommonValidationUtil
            .maxLength(
                billingName1,
                Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_NAME1_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_NAME1_NAME,
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_NAME1_LENGTH_STRING }));
    }

    // 請求先氏名2：文字種別チェック（全角）
    String billingName2 = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_NAME2_INDEX);
    if (billingName2 != null
        && !CommonValidationUtil.isZenkakuType(billingName2)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_NAME2_NAME }));

      // 請求先氏名2：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (billingName2 != null
        && !CommonValidationUtil.isRangeWordByECIS(billingName2)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_NAME2_NAME,
                      "全角（低圧CISシステム許容文字）" }));

      // 請求先氏名2：文字列最大長チェック
    } else if (billingName2 != null
        && !CommonValidationUtil
            .maxLength(
                billingName2,
                Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_NAME2_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_NAME2_NAME,
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_NAME2_LENGTH_STRING }));
    }

    // 敬称：文字種別チェック（全角）
    String prefix = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigPayment.DATA_PREFIX_INDEX);
    if (prefix != null && !CommonValidationUtil.isZenkakuType(prefix)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_PREFIX_NAME }));

      // 敬称：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (prefix != null
        && !CommonValidationUtil.isRangeWordByECIS(prefix)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_PREFIX_NAME,
                      "全角（低圧CISシステム許容文字）" }));

      // 敬称：文字列最大長チェック
    } else if (prefix != null
        && !CommonValidationUtil
            .maxLength(
                prefix,
                Custom_ContractManagementInformationFileConfigPayment.DATA_PREFIX_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_PREFIX_NAME,
                      Custom_ContractManagementInformationFileConfigPayment.DATA_PREFIX_LENGTH_STRING }));
    }

    // 請求先住所（郵便番号）：文字種別チェック（半角数字）
    String billingAddressPostalCode = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_POSTAL_CODE_INDEX);
    if (billingAddressPostalCode != null
        && !CommonValidationUtil.isNumric(billingAddressPostalCode)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_POSTAL_CODE_NAME,
                      "半角数字" }));

      // 請求先住所（郵便番号）：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (billingAddressPostalCode != null
        && !CommonValidationUtil
            .isRangeWordByECIS(billingAddressPostalCode)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_POSTAL_CODE_NAME,
                      "半角数字（低圧CISシステム許容文字）" }));

      // 請求先住所（郵便番号）：文字列指定長チェック
    } else if (StringUtils.isNotEmpty(billingAddressPostalCode)
        && !CommonValidationUtil
            .justLength(
                billingAddressPostalCode,
                Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_POSTAL_CODE_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_STRINGLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_POSTAL_CODE_NAME,
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_POSTAL_CODE_LENGTH_STRING }));
    }

    // 請求先住所（都道府県名）：文字種別チェック（全角）
    String billingAddressPrefectures = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_PREFECTURES_INDEX);
    if (billingAddressPrefectures != null
        && !CommonValidationUtil
            .isZenkakuType(billingAddressPrefectures)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_PREFECTURES_NAME }));

      // 請求先住所（都道府県名）：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (billingAddressPrefectures != null
        && !CommonValidationUtil
            .isRangeWordByECIS(billingAddressPrefectures)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_PREFECTURES_NAME,
                      "全角（低圧CISシステム許容文字）" }));

      // 請求先住所（都道府県名）：文字列最大長チェック
    } else if (billingAddressPrefectures != null
        && !CommonValidationUtil
            .maxLength(
                billingAddressPrefectures,
                Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_PREFECTURES_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_PREFECTURES_NAME,
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_PREFECTURES_LENGTH_STRING }));
    }

    // 請求先住所（市区郡町村名）：文字種別チェック（全角）
    String billingAddressMunicipality = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_MUNICIPALITY_INDEX);
    if (billingAddressMunicipality != null
        && !CommonValidationUtil
            .isZenkakuType(billingAddressMunicipality)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_MUNICIPALITY_NAME }));

      // 請求先住所（市区郡町村名）：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (billingAddressMunicipality != null
        && !CommonValidationUtil
            .isRangeWordByECIS(billingAddressMunicipality)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_MUNICIPALITY_NAME,
                      "全角（低圧CISシステム許容文字）" }));

      // 請求先住所（市区郡町村名）：文字列最大長チェック
    } else if (billingAddressMunicipality != null
        && !CommonValidationUtil
            .maxLength(
                billingAddressMunicipality,
                Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_MUNICIPALITY_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_MUNICIPALITY_NAME,
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_MUNICIPALITY_LENGTH_STRING }));
    }

    // 請求先住所（字名・丁目）：文字種別チェック（全角）
    String billingAddressSection = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_SECTION_INDEX);
    if (billingAddressSection != null
        && !CommonValidationUtil.isZenkakuType(billingAddressSection)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_SECTION_NAME }));

      // 請求先住所（字名・丁目）：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (billingAddressSection != null
        && !CommonValidationUtil
            .isRangeWordByECIS(billingAddressSection)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_SECTION_NAME,
                      "全角（低圧CISシステム許容文字）" }));

      // 請求先住所（字名・丁目）：文字列最大長チェック
    } else if (billingAddressSection != null
        && !CommonValidationUtil
            .maxLength(
                billingAddressSection,
                Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_SECTION_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_SECTION_NAME,
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_SECTION_LENGTH_STRING }));
    }

    // 請求先住所（番地･号）：文字列最大長チェック
    String billingAddressBlock = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_BLOCK_INDEX);
    if (billingAddressBlock != null
        && !CommonValidationUtil
            .maxLength(
                billingAddressBlock,
                Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_BLOCK_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_BLOCK_NAME,
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_BLOCK_LENGTH_STRING }));

      // 請求先住所（番地･号）：正規表現チェック
    } else if (billingAddressBlock != null
        && !CommonValidationUtil
            .checkByPattern(
                billingAddressBlock,
                Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_BLOCK_MASK_STRING)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_ITEM_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_BLOCK_NAME }));
    }

    // 請求先住所（建物名）：文字種別チェック（全角）
    String billingAddressBuildingName = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_BUILDING_NAME_INDEX);
    if (billingAddressBuildingName != null
        && !CommonValidationUtil
            .isZenkakuType(billingAddressBuildingName)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_BUILDING_NAME_NAME }));

      // 請求先住所（建物名）：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (billingAddressBuildingName != null
        && !CommonValidationUtil
            .isRangeWordByECIS(billingAddressBuildingName)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_BUILDING_NAME_NAME,
                      "全角（低圧CISシステム許容文字）" }));

      // 請求先住所（建物名）：文字列最大長チェック
    } else if (billingAddressBuildingName != null
        && !CommonValidationUtil
            .maxLength(
                billingAddressBuildingName,
                Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_BUILDING_NAME_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_BUILDING_NAME_NAME,
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_BUILDING_NAME_LENGTH_STRING }));
    }

    // 請求先住所（部屋名）：文字種別チェック（全角）
    String billingAddressRoom = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_ROOM_INDEX);
    if (billingAddressRoom != null
        && !CommonValidationUtil.isZenkakuType(billingAddressRoom)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_ROOM_NAME }));

      // 請求先住所（部屋名）：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (billingAddressRoom != null
        && !CommonValidationUtil.isRangeWordByECIS(billingAddressRoom)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_ROOM_NAME,
                      "全角（低圧CISシステム許容文字）" }));

      // 請求先住所（部屋名）：文字列最大長チェック
    } else if (billingAddressRoom != null
        && !CommonValidationUtil
            .maxLength(
                billingAddressRoom,
                Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_ROOM_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_ROOM_NAME,
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_ROOM_LENGTH_STRING }));
    }

    // 請求先電話番号：文字列最大長チェック
    String billingPhoneNo = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_PHONE_NO_INDEX);
    if (billingPhoneNo != null
        && !CommonValidationUtil
            .maxLength(
                billingPhoneNo,
                Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_PHONE_NO_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_PHONE_NO_NAME,
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_PHONE_NO_LENGTH_STRING }));

      // 請求先電話番号：正規表現チェック
    } else if (billingPhoneNo != null
        && !CommonValidationUtil
            .checkByPattern(
                billingPhoneNo,
                Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_PHONE_NO_MASK_STRING)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_ITEM_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_PHONE_NO_NAME }));
    }

    // 請求先メールアドレス1：文字列最大長チェック
    String billingMailAddress1 = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_MAIL_ADDRESS1_INDEX);
    if (billingMailAddress1 != null
        && !CommonValidationUtil
            .maxLength(
                billingMailAddress1,
                Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_MAIL_ADDRESS1_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_MAIL_ADDRESS1_NAME,
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_MAIL_ADDRESS1_LENGTH_STRING }));

      // 請求先メールアドレス1：正規表現チェック
    } else if (billingMailAddress1 != null
        && !CommonValidationUtil
            .checkByPattern(
                billingMailAddress1,
                Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_MAIL_ADDRESS1_MASK_STRING)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_ITEM_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_MAIL_ADDRESS1_NAME }));
    }

    // 請求先メールアドレス2：文字列最大長チェック
    String billingMailAddress2 = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_MAIL_ADDRESS2_INDEX);
    if (billingMailAddress2 != null
        && !CommonValidationUtil
            .maxLength(
                billingMailAddress2,
                Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_MAIL_ADDRESS2_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_MAIL_ADDRESS2_NAME,
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_MAIL_ADDRESS2_LENGTH_STRING }));

      // 請求先メールアドレス2：正規表現チェック
    } else if (billingMailAddress2 != null
        && !CommonValidationUtil
            .checkByPattern(
                billingMailAddress2,
                Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_MAIL_ADDRESS2_MASK_STRING)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_ITEM_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_MAIL_ADDRESS2_NAME }));
    }

    // フリー項目1：文字種別チェック（全角）
    String free1 = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_FREE1_INDEX);
    if (free1 != null && !CommonValidationUtil.isZenkakuType(free1)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_FREE1_NAME }));

      // フリー項目1：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (free1 != null
        && !CommonValidationUtil.isRangeWordByECIS(free1)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_FREE1_NAME,
                      "全角（低圧CISシステム許容文字）" }));

      // フリー項目1：文字列最大長チェック
    } else if (free1 != null
        && !CommonValidationUtil
            .maxLength(
                free1,
                Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_FREE1_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_FREE1_NAME,
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_FREE1_LENGTH_STRING }));
    }

    // フリー項目2：文字種別チェック（全角）
    String free2 = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_FREE2_INDEX);
    if (billingAddressRoom != null
        && !CommonValidationUtil.isZenkakuType(free2)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_FREE2_NAME }));

      // フリー項目2：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (free2 != null
        && !CommonValidationUtil.isRangeWordByECIS(free2)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_FREE2_NAME,
                      "全角（低圧CISシステム許容文字）" }));

      // フリー項目2：文字列最大長チェック
    } else if (free2 != null
        && !CommonValidationUtil
            .maxLength(
                free2,
                Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_FREE2_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_FREE2_NAME,
                      Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_FREE2_LENGTH_STRING }));
    }
    return messageList;
  }
}
