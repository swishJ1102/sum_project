package jp.co.unisys.enability.cis.business.rk;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.config.PropertiesFactoryBean;
import org.springframework.context.MessageSource;

import jp.co.unisys.enability.cis.business.rk.model.RK_FixUsageApplyCategorizeResultBusinessBean;
import jp.co.unisys.enability.cis.business.rk.model.RK_FixUsageApplyTimeCategorizeResultBusinessBean;
import jp.co.unisys.enability.cis.business.rk.model.RK_FixUsageApplyUsageBusinessBean;
import jp.co.unisys.enability.cis.business.rk.model.RK_LowPowerUsageQuantityBean;
import jp.co.unisys.enability.cis.business.rk.model.RK_RateMenuInfoBean;
import jp.co.unisys.enability.cis.business.rk.model.RK_UsageCsvCalculateBusinessBean;
import jp.co.unisys.enability.cis.business.rk.model.RK_UsageDataInfoBean;
import jp.co.unisys.enability.cis.business.rk.model.RK_UsageHeaderInfoBean;
import jp.co.unisys.enability.cis.business.rk.model.RK_UsePeriodRateMenuInfoBean;
import jp.co.unisys.enability.cis.common.util.KJ_CommonUtil;
import jp.co.unisys.enability.cis.common.util.RK_PropertyUtil;
import jp.co.unisys.enability.cis.common.util.StringConvertUtil;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISReturnCodeConstants;
import jp.co.unisys.enability.cis.entity.common.ContractHist;
import jp.co.unisys.enability.cis.entity.common.FixIn;
import jp.co.unisys.enability.cis.entity.common.Fu;
import jp.co.unisys.enability.cis.entity.common.TsUsage;

/**
 * 使用量CSV仕訳ビジネス
 *
 * @author "Nihon Unisys, Ltd."
 *
 */
public class RK_UsageCsvCalculateBusinessImpl implements
    RK_UsageCsvCalculateBusiness {

  /** ロガー */
  private static final Logger LOGGER = LogManager.getLogger();

  /**
   * メッセージプロパティ(DI)
   */
  private MessageSource messageSource;

  /**
   * プロパティ(DI)
   */
  private PropertiesFactoryBean applicationProperties;

  /**
   * 使用量仕訳ビジネス(DI)
   */
  private RK_FixUsageApplyUsageCategorizeBusiness rkFixUsageApplyUsageCategorizeBusiness;

  /**
   * 使用量しわ取りビジネス(DI)
   */
  private RK_FixUsageApplyUsageCorrectionBusiness rkFixUsageApplyUsageCorrectionBusiness;

  /**
   * 配列のインデックス定義。
   *
   * @author "Nihon Unisys, Ltd."
   */
  enum ArrayIndex {
    /** インデックス：0 */
    ZERO,
    /** インデックス：1 */
    ONE,
    /** インデックス：2 */
    TWO,
    /** インデックス：3 */
    THREE,
    /** インデックス：4 */
    FOUR,
    /** インデックス：5 */
    FIVE;
  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.rk.UsageCsvCalculateBusiness#calculate
   * (
   * jp.co.unisys.enability.cis.business.rk.model.UsageCsvCalculateBusinessBean
   * )
   */
  @Override
  public RK_UsageCsvCalculateBusinessBean calculate(
      RK_UsageCsvCalculateBusinessBean usageCsvCalculateBusinessBean) {

    // 低圧使用量Bean
    RK_LowPowerUsageQuantityBean lowPowerUsageQuantityBean = new RK_LowPowerUsageQuantityBean();

    try {
      lowPowerUsageQuantityBean = this
          .usageInfoFileToBean(usageCsvCalculateBusinessBean
              .getUsagefile());

    } catch (IOException | NumberFormatException e) {
      usageCsvCalculateBusinessBean
          .setReturncode(ECISReturnCodeConstants.RETURN_CODE_G017);
      usageCsvCalculateBusinessBean
          .setMessage(messageSource.getMessage(
              KJ_CommonUtil
                  .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G017),
              null, Locale.getDefault()));

      return usageCsvCalculateBusinessBean;
    }

    LOGGER.debug("RK_UsageCsvCalculateBusiness.calculate メニュー数:{}",
        usageCsvCalculateBusinessBean.getRatemenuinfolist().size());

    // 使用量仕訳を行う。
    this.categorizeUsage(
        lowPowerUsageQuantityBean.getUsageheaderinfolist(),
        usageCsvCalculateBusinessBean.getRatemenuinfolist(),
        usageCsvCalculateBusinessBean.getRatecalculationbasedate());

    usageCsvCalculateBusinessBean
        .setReturncode(ECISReturnCodeConstants.RETURN_CODE_0000);

    return usageCsvCalculateBusinessBean;
  }

  /**
   * 使用量情報変換
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 低圧使用量ファイルから使用量リストに変換します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param InputStream
   *          低圧使用量ファイル
   * @return 使用量CSV仕訳ビジネスBean
   * @throws IOException
   *           入出力例外
   */
  private RK_LowPowerUsageQuantityBean usageInfoFileToBean(InputStream file)
      throws IOException, NumberFormatException {
    // 低圧使用量Bean
    RK_LowPowerUsageQuantityBean lowPowerUsageQuantityBean = new RK_LowPowerUsageQuantityBean();

    // 使用量ヘッダ情報
    RK_UsageHeaderInfoBean usageHeaderInfoBean = null;

    // 使用量データ情報
    RK_UsageDataInfoBean usageDataInfoBean;

    // 使用量リスト
    List<BigDecimal> usageQuantityList = new ArrayList<>();

    // 使用量ヘッダ情報リスト
    List<RK_UsageHeaderInfoBean> usageHeaderInfoBeanList = new ArrayList<>();

    // 使用量データ情報リスト
    List<RK_UsageDataInfoBean> usageDataInfoBeanList = null;

    // 低圧使用量ファイル(引数)から使用量リスト(引数)にコピーする。
    BufferedReader reader = new BufferedReader(new InputStreamReader(file));

    // 複数計器(並行)判定用のリスト
    List<String> workUsageDateList = new ArrayList<>();
    //

    String line;
    while ((line = reader.readLine()) != null) {
      // 行処理
      String[] textStrings = line.split(ECISConstants.CSV_FILE_DELIMITER,
          -1);
      if (textStrings.length == ECISRKConstants.USAGE_FILE_SPOT_NO_LINE) {
        // 供給地点特定番号
        lowPowerUsageQuantityBean.setSpotno(textStrings[ArrayIndex.ZERO
            .ordinal()]);
        lowPowerUsageQuantityBean
            .setUsageheaderinfolist(usageHeaderInfoBeanList);
      } else if (textStrings.length == ECISRKConstants.USAGE_FILE_HEDDER_LINE) {
        // 使用量ヘッダ情報
        usageHeaderInfoBean = new RK_UsageHeaderInfoBean();

        // 調定年月
        usageHeaderInfoBean.setChoteiperiod(textStrings[ArrayIndex.ZERO
            .ordinal()]);

        // 検針年月日
        usageHeaderInfoBean
            .setFixusagequantitymeterreadingdate(StringConvertUtil
                .stringToDate(
                    textStrings[ArrayIndex.ONE.ordinal()],
                    ECISConstants.FORMAT_DATE_yyyyMMdd));

        // 契約電力
        usageHeaderInfoBean
            .setContractcapacity(textStrings[ArrayIndex.TWO
                .ordinal()]);

        // 力率
        usageHeaderInfoBean.setPowerfactor(Integer
            .getInteger(textStrings[ArrayIndex.THREE.ordinal()]));

        // 使用日数
        usageHeaderInfoBean
            .setUsedays(StringConvertUtil
                .stringToInteger(textStrings[ArrayIndex.FOUR
                    .ordinal()]));

        // 使用量
        usageHeaderInfoBean.setUsagequantity(StringConvertUtil
            .stringToBigDecimal(textStrings[ArrayIndex.FIVE
                .ordinal()]));

        // 按分フラグ
        usageHeaderInfoBean.setProportionaldivisionflag(false);

        // データ情報リスト
        usageDataInfoBeanList = new ArrayList<>();
        usageHeaderInfoBean.setUsagedatainfolist(usageDataInfoBeanList);

        lowPowerUsageQuantityBean.getUsageheaderinfolist().add(
            usageHeaderInfoBean);

        workUsageDateList = new ArrayList<>();

      } else {
        // 使用量データ情報
        usageDataInfoBean = new RK_UsageDataInfoBean();

        // 計器番号
        usageDataInfoBean.setMeterno(textStrings[ArrayIndex.ZERO
            .ordinal()]);

        // 対象年月日
        usageDataInfoBean.setUsagedate(StringConvertUtil.stringToDate(
            textStrings[ArrayIndex.ONE.ordinal()],
            ECISConstants.FORMAT_DATE_yyyyMMdd));

        if (!workUsageDateList.contains(textStrings[ArrayIndex.ONE
            .ordinal()])) {
          workUsageDateList
              .add(textStrings[ArrayIndex.ONE.ordinal()]);
        } else {
          usageHeaderInfoBean.setProportionaldivisionflag(true);
        }

        usageQuantityList = new ArrayList<>();

        for (int index = ECISRKConstants.USAGE_FILE_USAGE_QUANTITY_LIST_START; index < ECISRKConstants.USAGEQUANTITY_COUNT
            + ECISRKConstants.USAGE_FILE_USAGE_QUANTITY_LIST_START; index++) {
          if (StringUtils.isEmpty(textStrings[index])) {
            usageHeaderInfoBean.setProportionaldivisionflag(true);
            usageQuantityList.add(BigDecimal.ZERO);
          } else {
            usageQuantityList
                .add(new BigDecimal(textStrings[index]));
          }
        }

        usageDataInfoBean.setUsagequantitylist(usageQuantityList);
        usageHeaderInfoBean.getUsagedatainfolist().add(
            usageDataInfoBean);

      }

    }

    // 結果をソート
    lowPowerUsageQuantityBean.getUsageheaderinfolist().sort(
        Comparator.comparing(RK_UsageHeaderInfoBean::getChoteiperiod));

    return lowPowerUsageQuantityBean;
  }

  /**
   * 使用量仕訳
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 使用量仕訳を行います。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param usageHeaderInfoList
   *          使用量ヘッダ情報Beanリスト
   * @param rateMenuInfoList
   *          料金メニュー毎情報Beanリスト
   * @param baseDate
   *          料金計算基準日
   */
  private void categorizeUsage(
      List<RK_UsageHeaderInfoBean> usageHeaderInfoList,
      List<RK_RateMenuInfoBean> rateMenuInfoList, Date baseDate) {
    // 2016/07/07 料金シミュレーション不具合対応 Del Start
    //		// 利用年月毎料金計算結果Beanリスト
    //		List<RK_UsePeriodRateMenuInfoBean> usePeriodRateMenuInfoBeanList = new ArrayList<>();
    //
    //		// 利用年月毎料金計算結果Beanリストを作成する。
    //		usePeriodRateMenuInfoBeanList = createUsePeriodRateMenuInfoBean(usageHeaderInfoList);
    // 2016/07/07 料金シミュレーション不具合対応 Del End

    // 仕訳結果ビジネスBeanリスト
    List<RK_FixUsageApplyCategorizeResultBusinessBean> rkFixUsageApplyCategorizeResultBusinessBeanList;

    if (rateMenuInfoList == null) {
      return;
    }

    for (int index1 = 0; index1 < rateMenuInfoList.size(); index1++) {
      // 2016/07/07 料金シミュレーション不具合対応 Add Start
      // 利用年月毎料金計算結果Beanリスト
      List<RK_UsePeriodRateMenuInfoBean> usePeriodRateMenuInfoBeanList = createUsePeriodRateMenuInfoBean(
          usageHeaderInfoList);
      // 2016/07/07 料金シミュレーション不具合対応 Add End

      for (int index2 = 0; index2 < usePeriodRateMenuInfoBeanList.size(); index2++) {

        // 契約履歴リストを作成する（日割考慮が不要であり、適用開始日、料金メニューID以外は後続処理で利用されない）。
        ContractHist ch = new ContractHist();
        ch.setApplySd(usePeriodRateMenuInfoBeanList.get(index2).getFixusage().getUsageSd());
        ch.setApplyEd(usePeriodRateMenuInfoBeanList.get(index2).getFixusage().getUsageEd());
        ch.setCca(BigDecimal.ZERO);
        ch.setRmId(rateMenuInfoList.get(index1).getRatemenuid());
        List<ContractHist> chList = new ArrayList<ContractHist>();
        chList.add(ch);

        // 確定使用量反映ビジネス.使用量仕訳を呼び出す。
        rkFixUsageApplyCategorizeResultBusinessBeanList = rkFixUsageApplyUsageCategorizeBusiness.categorize(
            chList, usePeriodRateMenuInfoBeanList.get(index2).getFixusageapplyusagebusinessbeanlist());

        // 使用量しわ取りビジネス.使用量しわ取りを呼び出す。
        rkFixUsageApplyUsageCorrectionBusiness.correct(usePeriodRateMenuInfoBeanList.get(index2).getFixusage()
            .getUsageQuantity(), rkFixUsageApplyCategorizeResultBusinessBeanList);

        List<TsUsage> tsuList = new ArrayList<>();
        for (RK_FixUsageApplyTimeCategorizeResultBusinessBean item : rkFixUsageApplyCategorizeResultBusinessBeanList
            .get(0).getFixUsageApplyTimeCategorizeResultList()) {
          TsUsage tsUsage = new TsUsage();

          tsUsage.setFuId(ECISRKConstants.USAGE_CSV_CALCULATE_DUMMY_VALUE);
          tsUsage.setTsCode(item.getTimeSlotCode());
          tsUsage.setTsName(item.getTimeSlotName());
          tsUsage.setUsageQuantity(item.getCategorizedUsage());

          tsuList.add(tsUsage);
        }

        // 《仕訳結果ビジネスBeanリスト》を時間帯別使用量リストに設定する。
        usePeriodRateMenuInfoBeanList.get(index2).setTimeslotusagenewestlist(tsuList);

      }

      // 仕訳結果を追加する。
      rateMenuInfoList.get(index1).setUseperiodratemenuinfolist(usePeriodRateMenuInfoBeanList);
    }

  }

  /**
   * 利用年月毎料金計算結果Beanリスト作成
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 利用年月毎料金計算結果Beanリストを作成します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param usageHeaderInfoList
   *          《使用量ヘッダ情報Beanリスト》
   * @return 利用年月毎料金計算結果Beanリスト
   */
  private List<RK_UsePeriodRateMenuInfoBean> createUsePeriodRateMenuInfoBean(
      List<RK_UsageHeaderInfoBean> usageHeaderInfoList) {
    // 利用年月毎料金計算結果Beanリスト
    List<RK_UsePeriodRateMenuInfoBean> usePeriodRateMenuInfoBeanList = new ArrayList<>();

    // 利用年月毎料金計算結果Bean
    RK_UsePeriodRateMenuInfoBean usePeriodRateMenuInfoBean;

    // 使用量ビジネスBeanリスト
    List<RK_FixUsageApplyUsageBusinessBean> rkFixUsageApplyUsageBusinessBeanList;

    // 確定使用量
    Fu fu;

    // 確定指示数
    FixIn fixIn;

    if (usageHeaderInfoList == null) {
      return usePeriodRateMenuInfoBeanList;
    }

    for (int index = 0; index < usageHeaderInfoList.size(); index++) {
      rkFixUsageApplyUsageBusinessBeanList = new ArrayList<>();

      // 利用年月毎の《使用量ビジネスBeanリスト》を作成する。
      rkFixUsageApplyUsageBusinessBeanList = createUsageBusinessBean(
          usageHeaderInfoList.get(index)
              .getProportionaldivisionflag(),
          usageHeaderInfoList
              .get(index).getUsedays(),
          usageHeaderInfoList.get(index).getUsagequantity(),
          usageHeaderInfoList.get(index).getUsagedatainfolist());

      // 確定使用量(変数)の設定をする
      fu = new Fu();
      fu.setContractId(ECISRKConstants.USAGE_CSV_CALCULATE_DUMMY_VALUE);
      fu.setUsePeriod(usageHeaderInfoList.get(index).getChoteiperiod());
      fu.setFuId(ECISRKConstants.USAGE_CSV_CALCULATE_DUMMY_VALUE);
      fu.setUsageQuantity(usageHeaderInfoList.get(index)
          .getUsagequantity());
      fu.setUsageSd(usageHeaderInfoList.get(index).getUsagedatainfolist()
          .get(ECISRKConstants.USAGE_CSV_CALCULATE_DUMMY_VALUE)
          .getUsagedate());
      fu.setUsageEd(usageHeaderInfoList
          .get(index)
          .getUsagedatainfolist()
          .get(usageHeaderInfoList.get(index).getUsagedatainfolist()
              .size() - 1)
          .getUsagedate());
      fu.setCcDays(usageHeaderInfoList.get(index).getUsedays()
          .shortValue());

      // 確定指示数(変数)の設定をする
      fixIn = new FixIn();
      fixIn.setFuId(ECISRKConstants.USAGE_CSV_CALCULATE_DUMMY_VALUE);
      fixIn.setMeterCatCode(ECISRKConstants.METER_CATEGORY_CODE_FOR_IN_COMMON);
      fixIn.setInCalculationUsage(usageHeaderInfoList.get(index)
          .getUsagequantity());

      // 利用年月毎料金計算結果Bean(変数)を作成する。kei
      usePeriodRateMenuInfoBean = new RK_UsePeriodRateMenuInfoBean();
      usePeriodRateMenuInfoBean.setUseperiod(usageHeaderInfoList.get(
          index).getChoteiperiod());
      usePeriodRateMenuInfoBean.setFixusage(fu);
      usePeriodRateMenuInfoBean.setFixin(fixIn);

      usePeriodRateMenuInfoBeanList.add(usePeriodRateMenuInfoBean);
      usePeriodRateMenuInfoBean
          .setFixusageapplyusagebusinessbeanlist(rkFixUsageApplyUsageBusinessBeanList);
    }

    return usePeriodRateMenuInfoBeanList;
  }

  /**
   * 使用量仕訳
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 使用量仕訳を行います。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param isDivision
   *          按分フラグ
   * @param useDays
   *          使用日数
   * @param usageQuantity
   *          使用量
   * @param usageDataInfoList
   *          使用量データリスト
   * @return 確定使用量情報リスト
   */
  private List<RK_FixUsageApplyUsageBusinessBean> createUsageBusinessBean(
      boolean isDivision, Integer useDays, BigDecimal usageQuantity,
      List<RK_UsageDataInfoBean> usageDataInfoList) {

    // 使用量ビジネスBeanリスト
    List<RK_FixUsageApplyUsageBusinessBean> rkFixUsageApplyUsageBusinessBeanList = new ArrayList<>();

    // 使用量ビジネスBean
    RK_FixUsageApplyUsageBusinessBean tempRKFixUsageApplyUsageBusinessBean;

    if (isDivision) {
      // 使用量を按分する。
      rkFixUsageApplyUsageBusinessBeanList = this
          .usageProportionalDivision(usageQuantity, useDays,
              usageDataInfoList);
    } else {
      // 使用量ビジネスBeanを生成し、使用量ビジネスBeanリストに設定する
      for (int index = 0; index < usageDataInfoList.size(); index++) {

        tempRKFixUsageApplyUsageBusinessBean = new RK_FixUsageApplyUsageBusinessBean();
        tempRKFixUsageApplyUsageBusinessBean
            .setUsageDate(usageDataInfoList.get(index)
                .getUsagedate());
        tempRKFixUsageApplyUsageBusinessBean
            .setUsageList(new ArrayList<>(usageDataInfoList.get(
                index).getUsagequantitylist()));

        rkFixUsageApplyUsageBusinessBeanList
            .add(tempRKFixUsageApplyUsageBusinessBean);
      }
    }

    // 《使用量ビジネスBeanリスト》を返却する。
    return rkFixUsageApplyUsageBusinessBeanList;
  }

  /**
   * 使用量按分
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 使用量按分を行います。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param usageQuantity
   *          仕訳用使用量
   * @param useDays
   *          使用日数
   * @param usageDataInfoList
   *          使用量データ情報リスト
   * @return 確定使用量情報リスト
   */
  private List<RK_FixUsageApplyUsageBusinessBean> usageProportionalDivision(
      BigDecimal usageQuantity, Integer useDays,
      List<RK_UsageDataInfoBean> usageDataInfoList) {

    // 使用量ビジネスBeanリスト
    List<RK_FixUsageApplyUsageBusinessBean> rkFixUsageApplyUsageBusinessBeanList = new ArrayList<>();

    // 使用量ビジネスBean
    RK_FixUsageApplyUsageBusinessBean tempRKFixUsageApplyUsageBusinessBean;

    // 按分用切捨桁数
    // Propaertiesオブジェクト取得
    Properties prop = RK_PropertyUtil
        .getPropertiesFactory(applicationProperties);

    // 仕訳コード正常値取得
    int scale = StringConvertUtil.stringToInteger(prop
        .getProperty("business.rk.proportional.division.scale"));

    // 計算日数
    BigDecimal calcDays = new BigDecimal(useDays);

    // 仕訳用使用量
    BigDecimal journalUsageQuantity = usageQuantity;

    // 30分毎使用量
    BigDecimal thrityMinsUsageQuantity = journalUsageQuantity.divide(
        BigDecimal.valueOf(ECISRKConstants.USAGEQUANTITY_COUNT)
            .multiply(calcDays),
        scale, BigDecimal.ROUND_DOWN);

    // 合計使用量
    BigDecimal totalUsageQuantity = new BigDecimal("0");
    totalUsageQuantity.setScale(scale);

    // リスト追加判定用Map
    Map<String, String> flgMap = new HashMap<>();

    for (RK_UsageDataInfoBean usageDataInfo : usageDataInfoList) {
      flgMap.put(
          StringConvertUtil.convertDateToString(
              usageDataInfo.getUsagedate(), null),
          ECISConstants.FLG_OFF);
    }

    // 合計使用量フラグ
    boolean isTotalUsageQuantity = false;

    // 按分補正値
    BigDecimal correctionValue = BigDecimal.ONE;
    for (int i = 0; i < scale; i++) {
      correctionValue = correctionValue.divide(BigDecimal.TEN);
    }

    for (int dataListCnt = 0; dataListCnt < useDays; dataListCnt++) {
      if (ECISConstants.FLG_OFF.equals(flgMap.get(StringConvertUtil
          .convertDateToString(usageDataInfoList.get(dataListCnt)
              .getUsagedate(), null)))) {
        tempRKFixUsageApplyUsageBusinessBean = new RK_FixUsageApplyUsageBusinessBean();
        tempRKFixUsageApplyUsageBusinessBean
            .setUsageList(new ArrayList<>());

        tempRKFixUsageApplyUsageBusinessBean
            .setUsageDate(usageDataInfoList.get(dataListCnt)
                .getUsagedate());

        // 30分単位で48コマあり
        for (int usageListCnt = 0; usageListCnt < ECISRKConstants.USAGEQUANTITY_COUNT; usageListCnt++) {
          tempRKFixUsageApplyUsageBusinessBean.getUsageList().add(
              thrityMinsUsageQuantity);
          totalUsageQuantity = totalUsageQuantity
              .add(thrityMinsUsageQuantity);
        }

        rkFixUsageApplyUsageBusinessBeanList
            .add(tempRKFixUsageApplyUsageBusinessBean);

        flgMap.put(StringConvertUtil
            .convertDateToString(usageDataInfoList.get(dataListCnt)
                .getUsagedate(), null),
            ECISConstants.FLG_ON);
      }
    }

    // 合計使用量(変数)が仕訳用使用量(引数)未満の間、以下の処理を行う。
    while (totalUsageQuantity.compareTo(usageQuantity) < 0) {
      for (RK_FixUsageApplyUsageBusinessBean usageList : rkFixUsageApplyUsageBusinessBeanList) {

        for (int index = 0; index < usageList.getUsageList().size(); index++) {
          usageList.getUsageList().set(
              index,
              usageList.getUsageList().get(index)
                  .add(correctionValue));

          totalUsageQuantity = totalUsageQuantity
              .add(correctionValue);

          if (totalUsageQuantity.compareTo(usageQuantity) == 0) {
            isTotalUsageQuantity = true;
            break;
          }
        }

        if (isTotalUsageQuantity) {
          break;
        }
      }
    }

    // 使用量ビジネスBeanリスト(変数)を返却する。
    return rkFixUsageApplyUsageBusinessBeanList;
  }

  /**
   * メッセージプロパティのsetter(DI)
   *
   * @param messageSource
   *          メッセージプロパティ
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }

  /**
   * 使用量仕訳ビジネスのsetter(DI)
   *
   * @param rkFixUsageApplyUsageCategorizeBusiness
   *          使用量仕訳ビジネス
   */
  public void setRkFixUsageApplyUsageCategorizeBusiness(
      RK_FixUsageApplyUsageCategorizeBusiness rkFixUsageApplyUsageCategorizeBusiness) {
    this.rkFixUsageApplyUsageCategorizeBusiness = rkFixUsageApplyUsageCategorizeBusiness;
  }

  /**
   * 使用量しわ取りビジネスのsetter(DI)
   *
   * @param rkFixUsageApplyUsageCorrectionBusiness
   *          使用量しわ取りビジネス
   */
  public void setRkFixUsageApplyUsageCorrectionBusiness(
      RK_FixUsageApplyUsageCorrectionBusiness rkFixUsageApplyUsageCorrectionBusiness) {
    this.rkFixUsageApplyUsageCorrectionBusiness = rkFixUsageApplyUsageCorrectionBusiness;
  }

  /**
   * プロパティのsetter（DI）
   *
   * @param applicationProperties
   *          プロパティ
   */
  public void setApplicationProperties(
      PropertiesFactoryBean applicationProperties) {
    this.applicationProperties = applicationProperties;
  }
}
