package jp.co.unisys.enability.cis.business.rk;

import java.math.BigDecimal;
import java.util.List;

import jp.co.unisys.enability.cis.business.rk.model.RK_FixUsageApplyCategorizeResultBusinessBean;

/**
 * 使用量しわ取りビジネスインターフェース。
 *
 * @author "Nihon Unisys, Ltd."
 */
public interface RK_FixUsageApplyUsageCorrectionBusiness {

  /**
   * 使用量全量と仕訳結果の合計値が異なる場合に、仕訳結果の補正を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 仕訳結果の合計値が使用量全量と同じ値になるよう、
   * 各時間帯ごとの仕訳結果に対して補正を行う。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param totalUsage
   *          使用量全量
   * @param categorizeResultBusinessBeanList
   *          仕訳結果を保持するBeanのリスト
   * @return チェック用データのリスト
   */
  public abstract void correct(
      BigDecimal totalUsage,
      List<RK_FixUsageApplyCategorizeResultBusinessBean> categorizeResultBusinessBeanList);
}
