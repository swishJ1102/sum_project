package jp.co.unisys.enability.cis.business.kj;

import jp.co.unisys.enability.cis.business.kj.model.Custom_AgentSearchContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.SearchContractListBusinessBean;

/**
 * 卸取次店向け契約情報検索ビジネス_カスタムインターフェース
 *
 * @author "Nihon Unisys, Ltd."
 *
 *         変更履歴(kg-epj) 2016.03.01 芦垣 新規作成
 */
// [kg-epj]<d-start>
// public interface KJ_AgentContractSearchInformationBusiness {
// [kg-epj]<d-end>
// [kg-epj]<i-start>
public interface Custom_KJ_AgentContractSearchInformationBusiness {
  // [kg-epj]<i-end>

  /**
   * 卸取次店向け契約情報の検索を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * CRMや低圧CISからのオーダーにより、契約者および契約を特定するように検索し、検索結果を返却する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param searchContractBusinessn
   *          卸取次店向け契約情報検索BusinessBean_カスタム
   * @return 卸取次店向け契約情報検索BusinessBean_カスタム
   */
  // [kg-epj]<d-start>
  //	public AgentSearchContractBusinessBean search(AgentSearchContractBusinessBean searchContractBusiness);
  // [kg-epj]<d-end>
  // [kg-epj]<i-start>
  public Custom_AgentSearchContractBusinessBean search(Custom_AgentSearchContractBusinessBean searchContractBusiness);
  // [kg-epj]<i-end>

  /**
   * 契約情報リストの検索を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * Portal会員に紐づいた契約者番号の契約情報をまとめて取得するために使用する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param searchContractListBusiness
   *          契約リスト検索BusinessBean
   * @return 契約リスト検索BusinessBean
   */
  public SearchContractListBusinessBean searchContractList(SearchContractListBusinessBean searchContractListBusiness);
}
