package jp.co.unisys.enability.cis.business.sn;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.dao.DataAccessException;

import jp.co.unisys.enability.cis.business.sn.model.InquiryBillingDepositBusinessBean;
import jp.co.unisys.enability.cis.common.util.KJ_CommonUtil;
import jp.co.unisys.enability.cis.common.util.constants.ECISKJConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISReturnCodeConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISSNConstants;
import jp.co.unisys.enability.cis.entity.sn.SN_InquiryBillingDepositInformationEntityBean;
import jp.co.unisys.enability.cis.mapper.sn.BillingInformationCommonMapper;

/**
 * 請求入金情報ビジネス
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.sn.SN_BillingDepositInfomationBusiness
 */
public class SN_BillingDepositInfomationBusinessImpl implements
    SN_BillingDepositInfomationBusiness {
  /**
   * 請求情報共通Mapper(DI)
   */
  private BillingInformationCommonMapper billingInformationCommonMapper;

  /**
   * メッセージプロパティ(DI)
   */
  private MessageSource messageSource;

  /**
   * ログマネジャー
   */
  private static Logger logger = LogManager.getLogger();

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.sn.SN_BillingDepositInfomationBusiness
   * #inquiry(jp.co.unisys.enability.cis.business.kj.model.
   * InquiryBillingDepositBusinessBean)
   */
  @Override
  public InquiryBillingDepositBusinessBean inquiry(
      InquiryBillingDepositBusinessBean inquiryBillingDepositBusinessBean) {

    try {
      // 利用年月チェック
      // ご利用年月FROM
      String strUsePeriodFrom = inquiryBillingDepositBusinessBean
          .getUsePeriodFrom();
      // ご利用年月TO
      String strUsePeriodTo = inquiryBillingDepositBusinessBean
          .getUsePeriodTo();

      // 利用年月FROMがNULLまたは空文字のいずれでもない場合、以下の処理を行う。
      if (StringUtils.isNotEmpty(strUsePeriodFrom)) {
        // 利用年月TOがNULLまたは空文字のいずれでもない場合、以下の処理を行う。
        if (StringUtils.isNotEmpty(strUsePeriodTo)) {
          if (strUsePeriodFrom.length() == ECISSNConstants.LENGTH_DATE_YYYY) {
            StringBuilder sb = new StringBuilder();
            sb.append(strUsePeriodFrom);
            sb.append(ECISSNConstants.USE_PERIOD_AFTER_FROM);
            inquiryBillingDepositBusinessBean.setUsePeriodFrom(sb
                .toString());
          }
          if (strUsePeriodTo.length() == ECISSNConstants.LENGTH_DATE_YYYY) {
            StringBuilder sb = new StringBuilder();
            sb.append(strUsePeriodTo);
            sb.append(ECISSNConstants.USE_PERIOD_AFTER_TO);
            inquiryBillingDepositBusinessBean.setUsePeriodTo(sb
                .toString());
          }

          // 利用年月TOが、NULLまたは空文字のいずれかの場合、以下の処理を行う。
        } else if (StringUtils.isEmpty(strUsePeriodTo)) {
          if (strUsePeriodFrom.length() == ECISSNConstants.LENGTH_DATE_YYYY) {
            StringBuilder sb1 = new StringBuilder();
            sb1.append(strUsePeriodFrom);
            sb1.append(ECISSNConstants.USE_PERIOD_AFTER_FROM);
            inquiryBillingDepositBusinessBean.setUsePeriodFrom(sb1
                .toString());
            StringBuilder sb2 = new StringBuilder();
            sb2.append(strUsePeriodFrom);
            sb2.append(ECISSNConstants.USE_PERIOD_AFTER_TO);
            inquiryBillingDepositBusinessBean.setUsePeriodTo(sb2
                .toString());
          } else {
            inquiryBillingDepositBusinessBean.setUsePeriodTo(strUsePeriodFrom);
          }
        }
        // 《請求入金情報照会BusinessBean》.利用年月FROM >
        // 《請求入金情報照会BusinessBean》.利用年月TOの場合以下の処理を行う。
        if (inquiryBillingDepositBusinessBean.getUsePeriodFrom()
            .compareTo(
                inquiryBillingDepositBusinessBean
                    .getUsePeriodTo()) > 0) {
          inquiryBillingDepositBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P056);
          inquiryBillingDepositBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P056),
                  new String[] {}, Locale.getDefault()));
          return inquiryBillingDepositBusinessBean;
        }
      }

      // 照会パターンチェック
      // 請求ID
      Integer billingId = inquiryBillingDepositBusinessBean
          .getBillingId();
      // 請求番号
      String billingNo = inquiryBillingDepositBusinessBean.getBillingNo();
      // 契約者ID
      Integer contractorId = inquiryBillingDepositBusinessBean
          .getContractorId();
      // 契約者番号
      String contractorNo = inquiryBillingDepositBusinessBean
          .getContractorNo();
      // ご利用年月FROM
      String usePeriodFrom = inquiryBillingDepositBusinessBean
          .getUsePeriodFrom();
      // ご利用年月TO
      String usePeriodTo = inquiryBillingDepositBusinessBean
          .getUsePeriodTo();

      // ≪請求情報共通Mapper≫クラスを呼び出す。
      List<SN_InquiryBillingDepositInformationEntityBean> billingDepositInformationList;
      Map<String, Object> map = new LinkedHashMap<String, Object>();
      if ((contractorId != null || StringUtils.isNotEmpty(contractorNo))
          && billingId == null && StringUtils.isEmpty(billingNo)
          && StringUtils.isEmpty(usePeriodFrom)
          && StringUtils.isEmpty(usePeriodTo)) {

        // 請求入金一覧（KEY：契約者）取得
        map.put("contractorId", contractorId);
        map.put("contractorNo", contractorNo);
        billingDepositInformationList = billingInformationCommonMapper
            .selectBillingDepositListKeyContractor(map);

        // 照会結果設定
        inquiryBillingDepositBusinessBean
            .setBillingDepositInformationList(billingDepositInformationList);
        inquiryBillingDepositBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);

      } else if ((contractorId != null || StringUtils
          .isNotEmpty(contractorNo))
          && billingId == null
          && StringUtils.isEmpty(billingNo)
          && StringUtils.isNotEmpty(usePeriodFrom)
          && StringUtils.isNotEmpty(usePeriodTo)) {

        // 請求入金一覧（KEY：契約者と日付）取得
        map.put("contractorId", contractorId);
        map.put("contractorNo", contractorNo);
        map.put("usePeriodFrom", usePeriodFrom);
        map.put("usePeriodTo", usePeriodTo);
        billingDepositInformationList = billingInformationCommonMapper
            .selectBillingDepositListKeyContractorAndDate(map);

        // 照会結果設定
        inquiryBillingDepositBusinessBean
            .setBillingDepositInformationList(billingDepositInformationList);
        inquiryBillingDepositBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);

      } else if ((billingId != null || StringUtils.isNotEmpty(billingNo))
          && contractorId == null
          && StringUtils.isEmpty(contractorNo)
          && StringUtils.isEmpty(usePeriodFrom)
          && StringUtils.isEmpty(usePeriodTo)) {

        // 請求入金一覧（KEY：請求）取得
        map.put("billingId", billingId);
        map.put("billingNo", billingNo);
        billingDepositInformationList = billingInformationCommonMapper
            .selectBillingDepositListKeyBilling(map);

        // 照会結果設定
        inquiryBillingDepositBusinessBean
            .setBillingDepositInformationList(billingDepositInformationList);
        inquiryBillingDepositBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);
      } else {
        // 照会結果設定
        inquiryBillingDepositBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P001);
        inquiryBillingDepositBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P001),
                new String[] {}, Locale.getDefault()));
      }
    } catch (DataAccessException e) {
      logger.error(messageSource.getMessage("error.E1129", null,
          Locale.getDefault()), e);
      // 照会結果設定
      inquiryBillingDepositBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      inquiryBillingDepositBusinessBean
          .setMessage(messageSource.getMessage(
              KJ_CommonUtil
                  .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G017),
              new String[] {}, Locale.getDefault()));
    } catch (NoSuchMessageException e) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, e);
      // 照会結果設定
      inquiryBillingDepositBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      inquiryBillingDepositBusinessBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
    }
    return inquiryBillingDepositBusinessBean;
  }

  /**
   * 請求情報共通Mapperのセッター(DI)
   *
   * @param billingInformationCommonMapper
   *          セットする billingInformationCommonMapper
   */
  public void setBillingInformationCommonMapper(
      BillingInformationCommonMapper billingInformationCommonMapper) {
    this.billingInformationCommonMapper = billingInformationCommonMapper;
  }

  /**
   * メッセージプロパティのセッター(DI)
   *
   * @param messageSource
   *          セットする messageSource
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }
}
