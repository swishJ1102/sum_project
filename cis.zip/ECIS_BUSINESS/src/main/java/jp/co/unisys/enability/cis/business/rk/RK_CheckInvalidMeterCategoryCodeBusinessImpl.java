package jp.co.unisys.enability.cis.business.rk;

import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import org.springframework.beans.factory.config.PropertiesFactoryBean;

import jp.co.unisys.enability.cis.business.rk.model.RK_UsageLinkageCheckCheckDataBusinessBean;
import jp.co.unisys.enability.cis.business.rk.model.RK_UsageLinkageCheckTermDecisionBusinessBean;
import jp.co.unisys.enability.cis.common.util.RK_PropertyUtil;
import jp.co.unisys.enability.cis.common.util.StringConvertUtil;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;
import jp.co.unisys.enability.cis.entity.common.InResult;
import jp.co.unisys.enability.cis.entity.common.InResultExample;
import jp.co.unisys.enability.cis.mapper.common.InResultMapper;

/**
 * 計器区分コード不正チェックビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.rk.RK_UsageLinkageCheckBusiness
 */
public class RK_CheckInvalidMeterCategoryCodeBusinessImpl implements
    RK_CheckFixUsageBusiness {

  /** 計器区分コード正常値プロパティキー */
  private static final String VALID_CODES = "usagelinkagecheck.metercategorycode.validcodes";

  /** 料金計算チェックビジネス(DI) */
  private RK_UsageLinkageCheckBusiness rkUsageLinkageCheckBusiness;

  /** 指示数実績Mapper(DI) */
  private InResultMapper inResultMapper;

  /** プロパティファクトリー(DI) */
  private PropertiesFactoryBean applicationProperties;

  /**
   * 計器区分コード不正チェック。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 確定使用量メッセージの計器区分コードが、取り込み不可能なコードでないか判定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param checkDataBusinessBean
   *          チェック対象ビジネスBean
   * @param termDecisionBusinessBean
   *          期間判定情報ビジネスBean
   * @return true:処理継続、false:処理終了
   */
  @Override
  public boolean check(
      RK_UsageLinkageCheckCheckDataBusinessBean checkDataBusinessBean,
      RK_UsageLinkageCheckTermDecisionBusinessBean termDecisionBusinessBean) {

    // 継続フラグ
    boolean continuation = true;

    // Propaertiesオブジェクト取得
    Properties prop = RK_PropertyUtil.getPropertiesFactory(applicationProperties);

    // 計器区分コード正常値取得
    String[] validCodes = prop.getProperty(VALID_CODES)
        .split(ECISRKConstants.DELIMITER_METER_CATEGORY_CODE_COMMA);

    // 配列からリストを生成
    List<String> validCodeList = Arrays.asList(validCodes);

    // 正常フラグ
    boolean validation = false;

    // 指示数実績Example
    InResultExample inResultExample = new InResultExample();

    // 【指示数実績】を取得する条件を設定
    inResultExample
        .createCriteria()
        .andSpotNoEqualTo(checkDataBusinessBean.getSpotNo())
        .andFuFileNameEqualTo(
            checkDataBusinessBean.getFixUsageFileName())
        .andAreaCodeEqualTo(checkDataBusinessBean.getAreaCode());

    // 【指示数実績】を取得する
    List<InResult> inResultList = inResultMapper
        .selectByExample(inResultExample);

    // 計器区分コード
    String meterCategorizeCode = null;

    // 【指示数実績】ごとに繰り返し
    for (InResult inResult : inResultList) {

      meterCategorizeCode = inResult.getMeterCatCode();

      // 計器区分コード正常値ごとに繰り返し
      for (String code : validCodeList) {

        // 正常値のリストと確定使用量メッセージで連携された計器区分コードを比較
        if (code.trim().equals(meterCategorizeCode)) {

          // 正常値と一致した場合は、正常フラグをtrueに設定
          validation = true;

          // 正常値ごとの繰り返し処理を終了する
          break;
        }
      }

      // 正常でない場合はTODOを登録し、【月次実績】.月次実績エラー区分コードを"エラー"で更新する
      if (!validation) {

        // TODOメッセージを作成するパラメータ
        String[] params = {
            // 確定使用量ファイル名
            checkDataBusinessBean.getFixUsageFileName(),
            // 地点特定番号
            checkDataBusinessBean.getSpotNo(),
            // エリアコード
            checkDataBusinessBean.getAreaCode(),
            // 処理日
            StringConvertUtil.convertDateToString(
                checkDataBusinessBean.getExecuteDate(), ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
            // 計器区分コード
            meterCategorizeCode };

        // TODO登録
        rkUsageLinkageCheckBusiness.registerTodo("todo.T1026", params, null, null, null,
            checkDataBusinessBean.getSpotNo(), null);

        // 月次実績エラー区分コードをエラーで更新
        rkUsageLinkageCheckBusiness
            .updateMonthlyUsageResultError(checkDataBusinessBean);

        // 処理を継続しない
        continuation = false;

        // 【指示数実績】ごとの繰り返しを処理を終了する
        break;
      }

      validation = false;
    }

    return continuation;
  }

  /**
   * 料金計算チェックビジネスを設定します。(DI)
   *
   * @param rkUsageLinkageCheckBusiness
   *          料金計算チェックビジネス
   */
  public void setRkUsageLinkageCheckBusiness(
      RK_UsageLinkageCheckBusiness rkUsageLinkageCheckBusiness) {
    this.rkUsageLinkageCheckBusiness = rkUsageLinkageCheckBusiness;
  }

  /**
   * 指示数実績Mapperを設定します。(DI)
   *
   * @param inResultMapper
   *          指示数実績Mapper
   */
  public void setInResultMapper(InResultMapper inResultMapper) {
    this.inResultMapper = inResultMapper;
  }

  /**
   * プロパティファクトリーを設定します。(DI)
   *
   * @param applicationProperties
   *          プロパティファクトリー
   */
  public void setApplicationProperties(
      PropertiesFactoryBean applicationProperties) {
    this.applicationProperties = applicationProperties;
  }

}
