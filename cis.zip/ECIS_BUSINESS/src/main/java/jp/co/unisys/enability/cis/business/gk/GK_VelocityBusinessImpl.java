package jp.co.unisys.enability.cis.business.gk;

import java.io.StringWriter;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.Properties;

import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.runtime.RuntimeConstants;
import org.springframework.context.MessageSource;

import jp.co.unisys.enability.cis.business.sn.model.SN_CreateMailBusinessBean;
import jp.co.unisys.enability.cis.common.Exception.SystemException;
import jp.co.unisys.enability.cis.common.util.EMSConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISGKConstants;

/**
 * Velocityビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 *
 */
public class GK_VelocityBusinessImpl implements GK_VelocityBusiness {

  /** メッセージプロパティ(DI) */
  private MessageSource messageSource;

  /** VelocityEngine. */
  private VelocityEngine engine;

  /**
   * コンストラクタ.
   * 
   * @throws Exception
   */
  public GK_VelocityBusinessImpl() throws Exception {

    // Velocityを生成する。
    this.engine = new VelocityEngine();

    // Velocityを初期化する。
    Properties p = new Properties();
    // Velocityのログ出力をオフにする
    p.setProperty(VelocityEngine.RUNTIME_LOG_LOGSYSTEM_CLASS,
        "org.apache.velocity.runtime.log.NullLogSystem");
    // プロパティの設定。
    p.setProperty(RuntimeConstants.RESOURCE_LOADER, "class");
    // クラスパス内からテンプレートを取得する際のリソースローダ設定
    p.setProperty("class.resource.loader.class",
        "org.apache.velocity.runtime.resource.loader."
            + "ClasspathResourceLoader");
    this.engine.init(p);

  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.gk.GK_VelocityBusiness
   * #mailTextMaker(String, jp.co.unisys.enability.cis.business.sn.model.SN_CreateMailBusinessBean)
   */
  @Override
  public String mailTextMaker(String mailTemplate, SN_CreateMailBusinessBean bean) {

    StringWriter sw = new StringWriter();

    try {
      // コンテキストの生成・編集をする。
      VelocityContext ctx = new VelocityContext();
      // 置き換え用のbean
      ctx.put("bean", bean);
      // Date型⇒String用の日付フォーマット(yyyyMMdd)
      ctx.put("Sdf", new SimpleDateFormat(EMSConstants.FORMAT_DATE_yyyyMMdd));
      // Date型⇒String用の日付フォーマット(yyyy/MM/dd)
      ctx.put("SdfSlashYmd", new SimpleDateFormat(EMSConstants.FORMAT_DATE_yyyyMMdd_SLASH));
      // Date型⇒String用の日付フォーマット(yyyy'年'MM'月'dd'日')
      ctx.put("SdfChinese", new SimpleDateFormat(ECISConstants.FORMAT_DATE_yyyyMMdd_CHINESE));
      // カンマ編集用のナンバーフォーマット
      ctx.put("NumberFormatter", NumberFormat.getNumberInstance());
      // コンテキスト＋テンプレートをマージする。
      Template template = this.engine.getTemplate(mailTemplate,
          EMSConstants.ENCODE_TYPE_UTF8);
      template.merge(ctx, sw);

    } catch (Exception e) {
      SystemException se = new SystemException(
          messageSource.getMessage("error.E1298",
              null, Locale.getDefault()),
          e);
      throw se;
    }

    // テキストを返却する。
    return sw.toString();
  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.gk.GK_VelocityBusiness
   * #mailTextMaker(String, jp.co.unisys.enability.cis.business.sn.model.SN_CreateMailBusinessBean)
   */
  @Override
  public String evaluateStringVelocity(String stringFormat, SN_CreateMailBusinessBean bean) {

    StringWriter sw = new StringWriter();

    try {
      // コンテキストの生成・編集をする。
      VelocityContext ctx = new VelocityContext();
      // 置き換え用のbean
      ctx.put("bean", bean);
      // Date型⇒String用の日付フォーマット(yyyyMMdd)
      ctx.put("Sdf", new SimpleDateFormat(EMSConstants.FORMAT_DATE_yyyyMMdd));
      // Date型⇒String用の日付フォーマット(yyyy/MM/dd)
      ctx.put("SdfSlashYmd", new SimpleDateFormat(EMSConstants.FORMAT_DATE_yyyyMMdd_SLASH));
      // Date型⇒String用の日付フォーマット(yyyy'年'MM'月'dd'日')
      ctx.put("SdfChinese", new SimpleDateFormat(ECISConstants.FORMAT_DATE_yyyyMMdd_CHINESE));
      // カンマ編集用のナンバーフォーマット
      ctx.put("NumberFormatter", NumberFormat.getNumberInstance());

      // 文字列フォーマットを置き換える（該当beanの値がnullの場合は変換されない）
      this.engine.evaluate(ctx, sw, "", stringFormat);

    } catch (Exception e) {
      SystemException se = new SystemException(
          messageSource.getMessage("error.E1371",
              null, Locale.getDefault()),
          e);
      throw se;
    }

    // 置換文字列削除
    return this.deleteReplacementString(sw.toString());
  }

  /**
   * 置換文字列削除
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * Velocityの置換文字列を削除する。
   * </pre>
   *
   * @param target
   *          対象文字列
   * @return String 置換文字列削除後の文字列
   */
  private String deleteReplacementString(String target) {

    int start;
    // 対象文字列に存在する置換文字列を全て削除する。
    while ((start = target.indexOf(ECISGKConstants.REPLACEMENT_STRING_START)) >= 0) {
      StringBuilder sw = new StringBuilder(target);
      sw = sw.delete(start, target.indexOf(ECISGKConstants.REPLACEMENT_STRING_END) + 1);
      target = sw.toString();
    }

    return target;
  }

  /**
   * メッセージプロパティを設定する。(DI)
   *
   * @param messageSource
   *          メッセージプロパティ
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }

}
