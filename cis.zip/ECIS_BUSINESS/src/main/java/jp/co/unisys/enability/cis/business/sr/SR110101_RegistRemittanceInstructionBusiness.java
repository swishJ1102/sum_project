package jp.co.unisys.enability.cis.business.sr;

import java.util.Date;
import java.util.List;
import java.util.Map;

import jp.co.unisys.enability.cis.entity.common.Contractor;

/**
 * 送金指示登録Businessインタフェースクラス
 *
 * @author "Nihon Unisys, Ltd."
 */
public interface SR110101_RegistRemittanceInstructionBusiness {

    /**
     * 送金指示登録対象取得
     * @author "Nihon Unisys, Ltd."
     * @param batchBaseDate バッチ処理基準日
     * @param settlementScheduledDate バッチ処理基準日+2金融営業日
     * @return 送金指示登録対象レコードリスト
     */
    List<Map<String, Object>> selectRemittanceInstructionTarget(Date batchBaseDate,Date settlementScheduledDate) throws Exception;

    /**
     * 契約者取得
     * @author "Nihon Unisys, Ltd."
     * @param contractorId 契約者ID
     * @return 契約者Entityリスト
     */
    List<Contractor> selectContractor(String contractorId);

    /**
     * 支払履歴取得
     * @author "Nihon Unisys, Ltd."
     * @param accountId 口座ID
     * @param remitCreateDate 送金作成日
     * @return 送金先レコードリスト
     */
    List<Map<String, Object>> selectPaymentHistory(String accountId, Date remitCreateDate) throws Exception;

    /**
     * 送金ステータス更新
     * @author "Nihon Unisys, Ltd."
     * @param remitId 送金ID
     * @param remitStatusCode 送金ステータスコード
     * @param updateCount 更新回数
     * @return 更新結果件数
     */
    Integer updateRemittanceStatusCode(String remitId, String remitStatusCode, Integer updateCount);

    /**
     * API連携
     * @author "Nihon Unisys, Ltd."
     * @param url 接続先URL
     * @param timeout タイムアウト値（ミリ秒）
     * @param useProxy Proxy使用有無
     * @param proxyHost Proxyホスト
     * @param proxyPort Proxyポート番号
     * @param useBasicAuthentication Basic認証使用有無
     * @param basicAuthenticationUser Basic認証ユーザ
     * @param basicAuthenticationPassword Basic認証パスワード
     * @param shopId ショップID
     * @param shopPassword ショップパスワード
     * @param processingDivision 処理区分
     * @param depositId 入金ID
     * @param accountId 口座ID
     * @param receiptAmount 入金金額
     * @return レスポンスボディ
     */
    String callAPI(
            String url,
            Integer timeout,
            Boolean useProxy,
            String proxyHost,
            String proxyPort,
            Boolean useBasicAuthentication,
            String basicAuthenticationUser,
            String basicAuthenticationPassword,
            String shopId,
            String shopPassword,
            String processingDivision,
            String depositId,
            String accountId,
            Long receiptAmount) throws Exception;

    /**
     * TODO登録
     * @author "Nihon Unisys, Ltd."
     * @param ssysId サブシステムID
     * @param functionId 機能ID
     * @param messageId メッセージID
     * @param todoSearchKey TODO検索キー
     * @param message メッセージ
     * @param todoStatusCode TODOステータスコード
     * @return 登録結果件数
     */
    Integer insertTodo(
            String ssysId,
            String functionId,
            String messageId,
            String todoSearchKey,
            String message,
            String todoStatusCode);
}
