package jp.co.unisys.enability.cis.business.sn;

import java.util.List;
import java.util.Map;

import jp.co.unisys.enability.cis.business.sn.model.SN_CreateCsvBusinessBean;
import jp.co.unisys.enability.cis.business.sn.model.SN_ScreenBillingInfoBusinessBean;
import jp.co.unisys.enability.cis.common.Exception.BusinessLogicException;
import jp.co.unisys.enability.cis.entity.sn.SN_BillingContractorBean;

/**
 * 請求入金共通ビジネスインタフェース。
 * 
 * @author "Nihon Unisys, Ltd."
 *
 */
public interface SN_BillingCommonBusiness {

  /**
   * 未収および債権回収依頼対象登録処理
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求ステータスコードを未収に更新する。
   * また、「廃止」または「解約」された契約への最後の請求分が"未収"となった場合に、
   * 対象の【確定料金実績】を「債権回収依頼対象」に更新する。
   * 業務例外の場合はログ出力は行わず、呼び出し元へ発生例外をスローする。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param billingBean
   *          請求Bean
   * @return 請求・契約者Bean
   * @throws BusinessLogicException
   *           予期せぬエラーが発生した場合
   */
  public SN_BillingContractorBean updateUncollectedRevenue(Integer billingId)
      throws BusinessLogicException;

  /**
   * 画面表示請求情報取得。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数の請求IDを引数にDaoを呼び出し、請求情報を取得する。
   * 請求情報が取得できなかった場合はシステム例外をスローする。
   * 請求番号編集処理を呼び出し、取得した請求番号を編集する。
   * 取得した請求ステータスコード、督促ステータスコードの名称をマスタから取得する。
   * 取得、または編集した請求情報を返却する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param billingId
   *          請求ID
   * @return 請求入金画面表示請求情報ビジネスBean
   * @throws BusinessLogicException
   *           予期せぬエラーが発生した場合
   */
  public SN_ScreenBillingInfoBusinessBean getScreenBillingInfo(Integer billingId) throws BusinessLogicException;

  /**
   * 請求番号採番処理。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * シーケンス番号を採番する。
   * チェックディジットの算出を行う。
   * 12桁の請求番号に編集し、返却する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param batchBaseDate
   *          バッチ処理基準日
   * @return 請求番号
   * @throws BusinessLogicException
   *           予期せぬエラーが発生した場合
   */
  public String getBillingNumbering(String batchBaseDate) throws BusinessLogicException;

  /**
   * 未収請求フラグクリア。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求IDをもとに、【確定料金・請求連携】【確定料金実績】より情報を取得し、
   * 合算要否フラグと債権回収依頼対象フラグのクリアを行う。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param batchBaseDate
   *          バッチ処理基準日
   * @return 請求番号
   * @throws BusinessLogicException
   *           予期せぬエラーが発生した場合
   */
  public void clearUncollectedBillingFlg(Integer billingId) throws BusinessLogicException;

  /**
   * プロパティファイル取得処理。
   *
   * <pre>
   * 【仕様詳細】
   * プロパテイファイル取得
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param fileName
   *          プロパティファイル名
   * @return Map<String, String> プロパティ情報マップ
   * @throws BusinessLogicException
   *           予期せぬエラーが発生した場合
   */
  public Map<String, String> getPropertiesData(String fileName) throws BusinessLogicException;

  /**
   * CSV出力用配列の生成処理。
   *
   * <pre>
   * 【仕様詳細】
   * CSV出力用配列の生成
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param bean
   *          CSV作成用ビジネスBean
   * @param map
   *          CSVファイルレコード設定情報マップ
   * @param csvCategory
   *          CSVファイル区分
   * @return List<String> CSV出力用配列
   * @throws BusinessLogicException
   *           予期せぬエラーが発生した場合
   */
  public List<String> createListForCsv(SN_CreateCsvBusinessBean bean, Map<String, String> map, String csvCategory);

  /**
   *
   * <pre>
   * 【仕様詳細】
   * 入金の金額合計と預り金等の金額合計を合算した値を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   *
   * @param billingNo
   *          請求番号
   * @return 合計金額
   * @throws BusinessLogicException
   *           予期せぬエラーが発生した場合
   */
  public Long getSumDepositAppropriation(String billingNo) throws BusinessLogicException;

  /**
   *
   * <pre>
   * 【仕様詳細】
   * 未収に伴う更新処理。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   *
   * @param blId
   *          請求ID
   * @param blNo
   *          請求番号
   * @param contractorNo
   *          契約者番号
   * @param paymentId
   *          支払ID
   * @param usePeriod
   *          利用年月
   * @param previousBlAddUpFlag
   *          前月請求合算フラグ
   * @param receivablesFlag
   *          債権回収依頼フラグ
   * @param functionId
   *          機能ID
   *
   */
  public void updateReceiptRelation(Integer blId, String blNo, String contractorNo,
      Integer paymentId, String usePeriod, String previousBlAddUpFlag,
      String receivablesFlag, String functionId)
      throws BusinessLogicException;

}
