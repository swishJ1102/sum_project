package jp.co.unisys.enability.cis.business.kj.model;

import java.util.List;

//[kg-epj]<d-start>
//import jp.co.unisys.enability.cis.entity.kj.KJ_ContractorInformationSearchEntityBean;
//[kg-epj]<d-end>
//[kg-epj]<i-start>
import jp.co.unisys.enability.cis.entity.kj.Custom_KJ_ContractorInformationSearchEntityBean;

//[kg-epj]<i-end>
/**
 * 契約情報で検索条件および検索結果を格納するBusinessBean
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 *  契約情報検索ビジネス_カスタム
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 *
 *         変更履歴 2016.02.16 芦垣 新規作成
 *
 */
//[kg-epj]<d-start>
//public class SearchContractBusinessBean {
//[kg-epj]<d-end>
//[kg-epj]<i-start>
public class Custom_SearchContractBusinessBean {
  //[kg-epj]<i-end>
  /**
   * 契約者IDを保有する。
   */
  private Integer contractorId;

  /**
   * 契約者番号を保有する。
   */
  private String contractorNo;

  /**
   * 契約IDを保有する。
   */
  private Integer contractId;

  /**
   * 契約番号を保有する。
   */
  private String contractNo;

  /**
   * 請求IDを保有する。
   */
  private Integer billingId;

  /**
   * 請求番号を保有する。
   */
  private String billingNo;

  /**
   * 個人・法人区分コードを保有する。
   */
  private String individualLegalEntityCategoryCode;

  /**
   * 契約者名（カナ）を保有する。
   */
  private String contractorNameKana;

  /**
   * 契約者名（漢字）を保有する。
   */
  private String contractorNameKanji;

  /**
   * 契約者住所を保有する。
   */
  private String contractorAddress;

  /**
   * 契約者電話番号を保有する。
   */
  private String contractorPhoneNo;

  /**
   * 契約者メールアドレスを保有する。
   */
  private String contractorMailAddress;

  /**
   * 提供モデルコードを保有する。
   */
  private String provideModelCode;

  /**
   * 提供モデル企業コードを保有する。
   */
  private String provideModelCompanyCode;

  /**
   * メータ設置場所IDを保有する。
   */
  private Integer meterLocationId;

  /**
   * 地点特定番号を保有する。
   */
  private String spotNo;

  /**
   * 送受電区分コードを保有する。
   */
  private String transmissionCategoryCode;

  /**
   * 需要場所住所を保有する。
   */
  private String placeAddress;

  /**
   * 契約終了状況を保有する。
   */
  private String contractEndSts;

  /**
   * 契約者利用状況を保有する。
   */
  private String contractorUseSts;

  /**
   * 営業委託先コードを保有する。
   */
  private String salesConsignmentCode;

  /**
   * 最大検索結果件数を保有する。
   */
  private Integer maxSearchResultCount;

  //[kg-epj]<i-start>
  /**
   * 外部システム契約者番号を保有する。
   */
  private String gasCustomerNo;

  /**
   * 外部システム契約番号を保有する。
   */
  private String gasSupplyContractNo;

  /**
   * 外部システム支払番号を保有する。
   */
  private String gasPaymentNo;

  /**
   * 電圧区分コードを保有する。
   */
  private String voltageCategoryCode;

  /**
   * 契約電力決定区分コードを保有する。
   */
  private String contractCapacityDecisionCategoryCode;

  //[kg-epj]<i-end>
  /**
   * 検索結果件数を保有する。
   */
  private Integer searchResultCount;

  /**
   * 契約者情報検索結果エンティティリストを保有する。
   */
  //[kg-epj]<d-start>
  //private List<KJ_ContractorInformationSearchEntityBean> serchContractorEntityList;
  //[kg-epj]<d-end>
  //[kg-epj]<i-start>
  private List<Custom_KJ_ContractorInformationSearchEntityBean> serchContractorEntityList;
  //[kg-epj]<i-end>
  /**
   * 最大検索数を保有する。
   */
  private Integer maxSearchCount;

  /**
   * ページ内一覧表示件数を保有する。
   */
  private Integer pageDisplayCount;

  /**
   * リターンコードを保有する。
   */
  private String returnCode;

  /**
   * メッセージを保有する。
   */
  private String message;

  /**
   * 契約者IDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者IDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者ID
   */
  public Integer getContractorId() {
    return this.contractorId;
  }

  /**
   * 契約者IDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者IDを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorId
   *          契約者ID
   */
  public void setContractorId(Integer contractorId) {
    this.contractorId = contractorId;
  }

  /**
   * 契約者番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者番号を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者番号
   */
  public String getContractorNo() {
    return this.contractorNo;
  }

  /**
   * 契約者番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者番号を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorNo
   *          契約者番号
   */
  public void setContractorNo(String contractorNo) {
    this.contractorNo = contractorNo;
  }

  /**
   * 契約IDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約IDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約ID
   */
  public Integer getContractId() {
    return this.contractId;
  }

  /**
   * 契約IDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約IDを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractId
   *          契約ID
   */
  public void setContractId(Integer contractId) {
    this.contractId = contractId;
  }

  /**
   * 契約番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約番号を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約番号
   */
  public String getContractNo() {
    return this.contractNo;
  }

  /**
   * 契約番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約番号を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractNo
   *          契約番号
   */
  public void setContractNo(String contractNo) {
    this.contractNo = contractNo;
  }

  /**
   * 請求IDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求IDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 請求ID
   */
  public Integer getBillingId() {
    return this.billingId;
  }

  /**
   * 請求IDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求IDを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param billingId
   *          請求ID
   */
  public void setBillingId(Integer billingId) {
    this.billingId = billingId;
  }

  /**
   * 請求番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求番号を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 請求番号
   */
  public String getBillingNo() {
    return this.billingNo;
  }

  /**
   * 請求番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求番号を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param billingNo
   *          請求番号
   */
  public void setBillingNo(String billingNo) {
    this.billingNo = billingNo;
  }

  /**
   * 個人・法人区分コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 個人・法人区分コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 個人・法人区分コード
   */
  public String getIndividualLegalEntityCategoryCode() {
    return this.individualLegalEntityCategoryCode;
  }

  /**
   * 個人・法人区分コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 個人・法人区分コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param individualLegalEntityCategoryCode
   *          個人・法人区分コード
   */
  public void setIndividualLegalEntityCategoryCode(
      String individualLegalEntityCategoryCode) {
    this.individualLegalEntityCategoryCode = individualLegalEntityCategoryCode;
  }

  /**
   * 契約者名（カナ）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者名（カナ）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者名（カナ）
   */
  public String getContractorNameKana() {
    return this.contractorNameKana;
  }

  /**
   * 契約者名（カナ）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者名（カナ）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorNameKana
   *          契約者名（カナ）
   */
  public void setContractorNameKana(String contractorNameKana) {
    this.contractorNameKana = contractorNameKana;
  }

  /**
   * 契約者名（漢字）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者名（漢字）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者名（漢字）
   */
  public String getContractorNameKanji() {
    return this.contractorNameKanji;
  }

  /**
   * 契約者名（漢字）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者名（漢字）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorNameKanji
   *          契約者名（漢字）
   */
  public void setContractorNameKanji(String contractorNameKanji) {
    this.contractorNameKanji = contractorNameKanji;
  }

  /**
   * 契約者住所のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者住所を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者住所
   */
  public String getContractorAddress() {
    return this.contractorAddress;
  }

  /**
   * 契約者住所のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者住所を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorAddress
   *          契約者住所
   */
  public void setContractorAddress(String contractorAddress) {
    this.contractorAddress = contractorAddress;
  }

  /**
   * 契約者電話番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者電話番号を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者電話番号
   */
  public String getContractorPhoneNo() {
    return this.contractorPhoneNo;
  }

  /**
   * 契約者電話番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者電話番号を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorPhoneNo
   *          契約者電話番号
   */
  public void setContractorPhoneNo(String contractorPhoneNo) {
    this.contractorPhoneNo = contractorPhoneNo;
  }

  /**
   * 契約者メールアドレスのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者メールアドレスを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者メールアドレス
   */
  public String getContractorMailAddress() {
    return this.contractorMailAddress;
  }

  /**
   * 契約者メールアドレスのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者メールアドレスを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorMailAddress
   *          契約者メールアドレス
   */
  public void setContractorMailAddress(String contractorMailAddress) {
    this.contractorMailAddress = contractorMailAddress;
  }

  /**
   * 提供モデルコードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 提供モデルコードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 提供モデルコード
   */
  public String getProvideModelCode() {
    return this.provideModelCode;
  }

  /**
   * 提供モデルコードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 提供モデルコードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param provideModelCode
   *          提供モデルコード
   */
  public void setProvideModelCode(String provideModelCode) {
    this.provideModelCode = provideModelCode;
  }

  /**
   * 提供モデル企業コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 提供モデル企業コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 提供モデル企業コード
   */
  public String getProvideModelCompanyCode() {
    return this.provideModelCompanyCode;
  }

  /**
   * 提供モデル企業コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 提供モデル企業コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param provideModelCompanyCode
   *          提供モデル企業コード
   */
  public void setProvideModelCompanyCode(String provideModelCompanyCode) {
    this.provideModelCompanyCode = provideModelCompanyCode;
  }

  /**
   * メータ設置場所IDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メータ設置場所IDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return メータ設置場所ID
   */
  public Integer getMeterLocationId() {
    return this.meterLocationId;
  }

  /**
   * メータ設置場所IDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メータ設置場所IDを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param meterLocationId
   *          メータ設置場所ID
   */
  public void setMeterLocationId(Integer meterLocationId) {
    this.meterLocationId = meterLocationId;
  }

  /**
   * 地点特定番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 地点特定番号を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 地点特定番号
   */
  public String getSpotNo() {
    return this.spotNo;
  }

  /**
   * 地点特定番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 地点特定番号を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param spotNo
   *          地点特定番号
   */
  public void setSpotNo(String spotNo) {
    this.spotNo = spotNo;
  }

  /**
   * 送受電区分コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 送受電区分コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 送受電区分コード
   */
  public String getTransmissionCategoryCode() {
    return this.transmissionCategoryCode;
  }

  /**
   * 送受電区分コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 送受電区分コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param transmissionCategoryCode
   *          送受電区分コード
   */
  public void setTransmissionCategoryCode(String transmissionCategoryCode) {
    this.transmissionCategoryCode = transmissionCategoryCode;
  }

  /**
   * 需要場所住所のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 需要場所住所を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 需要場所住所
   */
  public String getPlaceAddress() {
    return this.placeAddress;
  }

  /**
   * 需要場所住所のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 需要場所住所を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param placeAddress
   *          需要場所住所
   */
  public void setPlaceAddress(String placeAddress) {
    this.placeAddress = placeAddress;
  }

  /**
   * 契約終了状況のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約終了状況を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約終了状況
   */
  public String getContractEndSts() {
    return this.contractEndSts;
  }

  /**
   * 契約終了状況のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約終了状況を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractEndSts
   *          契約終了状況
   */
  public void setContractEndSts(String contractEndSts) {
    this.contractEndSts = contractEndSts;
  }

  /**
   * 契約者利用状況のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者利用状況を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者利用状況
   */
  public String getContractorUseSts() {
    return this.contractorUseSts;
  }

  /**
   * 契約者利用状況のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者利用状況を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorUseSts
   *          契約者利用状況
   */
  public void setContractorUseSts(String contractorUseSts) {
    this.contractorUseSts = contractorUseSts;
  }

  /**
   * 営業委託先コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 営業委託先コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 営業委託先コード
   */
  public String getSalesConsignmentCode() {
    return this.salesConsignmentCode;
  }

  /**
   * 営業委託先コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 営業委託先コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param salesConsignmentCode
   *          営業委託先コード
   */
  public void setSalesConsignmentCode(String salesConsignmentCode) {
    this.salesConsignmentCode = salesConsignmentCode;
  }

  /**
   * 最大検索結果件数のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 最大検索結果件数を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 最大検索結果件数
   */
  public Integer getMaxSearchResultCount() {
    return this.maxSearchResultCount;
  }

  /**
   * 最大検索結果件数のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 最大検索結果件数を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param maxSearchResultCount
   *          最大検索結果件数
   */
  public void setMaxSearchResultCount(Integer maxSearchResultCount) {
    this.maxSearchResultCount = maxSearchResultCount;
  }

  //[kg-epj]<d-start>
  /**
   * 外部システム契約者番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 外部システム契約者番号を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 外部システム契約者番号
   */
  public String getGasCustomerNo() {
    return this.gasCustomerNo;
  }

  /**
   * 外部システム契約者番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 外部システム契約者番号を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param gasCustomerNo
   *          外部システム契約者番号
   */
  public void setGasCustomerNo(String gasCustomerNo) {
    this.gasCustomerNo = gasCustomerNo;
  }

  /**
   * 外部システム契約番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 外部システム契約番号を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 外部システム契約番号
   */
  public String getGasSupplyContractNo() {
    return this.gasSupplyContractNo;
  }

  /**
   * 外部システム契約番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 外部システム契約番号を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param gasSupplyContractNo
   *          外部システム契約番号
   */
  public void setGasSupplyContractNo(String gasSupplyContractNo) {
    this.gasSupplyContractNo = gasSupplyContractNo;
  }

  /**
   * 外部システム支払番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 外部システム支払番号を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 外部システム支払番号
   */
  public String getGasPaymentNo() {
    return this.gasPaymentNo;
  }

  /**
   * 外部システム支払番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 外部システム支払番号を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param gasPaymentNo
   *          外部システム支払番号
   */
  public void setGasPaymentNo(String gasPaymentNo) {
    this.gasPaymentNo = gasPaymentNo;
  }

  /**
   * 電圧区分コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 電圧区分コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 電圧区分コード
   */
  public String getVoltageCategoryCode() {
    return voltageCategoryCode;
  }

  /**
   * 電圧区分コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 電圧区分コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param voltageCategoryCode
   *          電圧区分コード
   */
  public void setVoltageCategoryCode(String voltageCategoryCode) {
    this.voltageCategoryCode = voltageCategoryCode;
  }

  /**
   * 契約電力決定区分コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約電力決定区分コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約電力決定区分コード
   */
  public String getContractCapacityDecisionCategoryCode() {
    return contractCapacityDecisionCategoryCode;
  }

  /**
   * 契約電力決定区分コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約電力決定区分コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractCapacityDecisionCategoryCode
   *          契約電力決定区分コード
   */
  public void setContractCapacityDecisionCategoryCode(
      String contractCapacityDecisionCategoryCode) {
    this.contractCapacityDecisionCategoryCode = contractCapacityDecisionCategoryCode;
  }

  //[kg-epj]<d-end>
  /**
   * 検索結果件数のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 検索結果件数を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 検索結果件数
   */
  public Integer getSearchResultCount() {
    return this.searchResultCount;
  }

  /**
   * 検索結果件数のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 検索結果件数を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param searchResultCount
   *          検索結果件数
   */
  public void setSearchResultCount(Integer searchResultCount) {
    this.searchResultCount = searchResultCount;
  }

  /**
   * 契約者情報検索結果エンティティリストのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者情報検索結果エンティティリストを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者情報検索結果エンティティリスト
   */
  //[kg-epj]<d-start>
  //public List<KJ_ContractorInformationSearchEntityBean> getSerchContractorEntityList() {
  //    return this.serchContractorEntityList;
  //[kg-epj]<d-end>
  //[kg-epj]<i-start>
  public List<Custom_KJ_ContractorInformationSearchEntityBean> getSerchContractorEntityList() {
    return this.serchContractorEntityList;
    //[kg-epj]<i-end>
  }

  /**
   * 契約者情報検索結果エンティティリストのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者情報検索結果エンティティリストを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param serchContractorEntityList
   *          契約者情報検索結果エンティティリスト
   */
  public void setSerchContractorEntityList(
      //[kg-epj]<d-start>
      //List<KJ_ContractorInformationSearchEntityBean> serchContractorEntityList) {
      //[kg-epj]<d-end>
      //[kg-epj]<i-start>
      List<Custom_KJ_ContractorInformationSearchEntityBean> serchContractorEntityList) {
    //[kg-epj]<i-end>
    this.serchContractorEntityList = serchContractorEntityList;
  }

  /**
   * 最大検索数のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 最大検索数を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 最大検索数
   */
  public Integer getMaxSearchCount() {
    return this.maxSearchCount;
  }

  /**
   * 最大検索数のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 最大検索数を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param maxSearchCount
   *          最大検索数
   */
  public void setMaxSearchCount(Integer maxSearchCount) {
    this.maxSearchCount = maxSearchCount;
  }

  /**
   * ページ内一覧表示件数のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * ページ内一覧表示件数を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return ページ内一覧表示件数
   */
  public Integer getPageDisplayCount() {
    return this.pageDisplayCount;
  }

  /**
   * ページ内一覧表示件数のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * ページ内一覧表示件数を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param pageDisplayCount
   *          ページ内一覧表示件数
   */
  public void setPageDisplayCount(Integer pageDisplayCount) {
    this.pageDisplayCount = pageDisplayCount;
  }

  /**
   * リターンコードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return リターンコード
   */
  public String getReturnCode() {
    return this.returnCode;
  }

  /**
   * リターンコードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param returnCode
   *          リターンコード
   */
  public void setReturnCode(String returnCode) {
    this.returnCode = returnCode;
  }

  /**
   * メッセージのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return メッセージ
   */
  public String getMessage() {
    return this.message;
  }

  /**
   * メッセージのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param message
   *          メッセージ
   */
  public void setMessage(String message) {
    this.message = message;
  }

}
