package jp.co.unisys.enability.cis.business.gk;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.config.PropertiesFactoryBean;
import org.springframework.context.MessageSource;

import jp.co.unisys.enability.cis.business.gk.model.GK_RegistDownloadManageBusinessBean;
import jp.co.unisys.enability.cis.business.sn.model.SN_CreateMailBusinessBean;
import jp.co.unisys.enability.cis.common.Exception.SystemException;
import jp.co.unisys.enability.cis.common.util.EMSConstants;
import jp.co.unisys.enability.cis.common.util.StringConvertUtil;
import jp.co.unisys.enability.cis.common.util.ThreadContext;
import jp.co.unisys.enability.cis.common.util.constants.ECISCodeConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISSNConstants;
import jp.co.unisys.enability.cis.entity.common.DlMng;
import jp.co.unisys.enability.cis.entity.common.WorkScheduleMngM;
import jp.co.unisys.enability.cis.entity.common.WorkScheduleMngMExample;
import jp.co.unisys.enability.cis.mapper.common.DlMngMapper;
import jp.co.unisys.enability.cis.mapper.common.WorkScheduleMngMMapper;
import jp.co.unisys.enability.cis.mapper.gk.GK_WorkCommonMapper;
import jp.sf.orangesignal.csv.CsvConfig;
import jp.sf.orangesignal.csv.CsvWriter;

/**
 * 業務共通共通ビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.mapper.common.WorkScheduleMngMMapper
 * @see jp.co.unisys.enability.cis.mapper.common.DlMngMapper
 * @see jp.co.unisys.enability.cis.mapper.gk.GK_WorkCommonMapper
 * @see jp.co.unisys.enability.cis.business.gk.GK_VelocityBusiness
 */
public class GK_WorkCommonBusinessImpl implements GK_WorkCommonBusiness {

  /** YMD桁数 */
  private static final int YYYYMMDD_NUMBER = 8;

  /** 請求番号ハイフン挿入箇所：3桁目 */
  private static final int BILLING_NO_HYPHEN_LOCATION_3 = 3;

  /** 請求番号ハイフン挿入箇所：8桁目 */
  private static final int BILLING_NO_HYPHEN_LOCATION_8 = 8;

  /** 請求番号桁数 */
  private static final int BILLING_NO_LENGTH = 12;

  /** 編集後請求番号桁数 */
  private static final int BILLING_NO_LENGTH_EDIT = 14;

  /** 業務日程管理マスタマッパー(DI) */
  private WorkScheduleMngMMapper workScheduleMngMMapper;

  /** ダウンロード管理マッパー(DI) */
  private DlMngMapper dlMngMapper;

  /** コード定義プロパティ(DI) */
  private PropertiesFactoryBean applicationProperties;

  /** 業務共通共通Mapper(DI) */
  private GK_WorkCommonMapper gkWorkCommonMapper;

  /** メッセージプロパティ(DI) */
  private MessageSource messageSource;

  /** Velocityビジネス(DI) */
  private GK_VelocityBusiness gkVelocityBusiness;

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.gk.GK_WorkCommonBusiness#getRecordedDate(Date, Date)
   */
  @Override
  public Date getRecordedDate(Date baseDate, Date executeDate) {

    // 引数の計上基準年月日から年月を取得する。
    SimpleDateFormat formatYYYYMM = new SimpleDateFormat(EMSConstants.FORMAT_DATE_YYYYMM);
    String baseDateYM = formatYYYYMM.format(baseDate);

    WorkScheduleMngMExample workScheduleMngM = new WorkScheduleMngMExample();
    // 業務年月
    // 業務日程区分 経理データ締切日を設定
    workScheduleMngM.createCriteria().andWorkSchedulePointEqualTo(
        baseDateYM)
        .andWorkScheduleCatCodeEqualTo(ECISCodeConstants.WORK_SCHEDULE_CATEGORY_CODE_ACCOUNTING_DATA_LIMIT);

    // 月次締め日を取得
    List<WorkScheduleMngM> resultList = workScheduleMngMMapper
        .selectByExample(workScheduleMngM);

    if (resultList.isEmpty()) {
      throw new SystemException(
          messageSource.getMessage("error.E1324", null, Locale.getDefault()));
    }

    // 引数の処理日 ＜＝ 月次締め日の場合
    if (executeDate.compareTo(resultList.get(0).getWorkScheduleDate()) <= 0) {
      // 引数の計上基準日を計上年月日とする。
      return baseDate;
    } else {
      // 引数の処理日が属する年月の「1日」を計上年月日とする。
      String executeDateYM = formatYYYYMM.format(executeDate);
      StringBuffer executeDateYMStrBffr = new StringBuffer(YYYYMMDD_NUMBER);
      executeDateYMStrBffr.append(executeDateYM);
      executeDateYMStrBffr.append(ECISConstants.DATE_FIRST);
      Date resultDate = null;
      resultDate = StringConvertUtil.stringToDate(executeDateYMStrBffr.toString(),
          EMSConstants.FORMAT_DATE_yyyyMMdd);
      return resultDate;
    }
  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.gk.GK_WorkCommonBusiness#
   * outputCsvFile(List<String[]>, String, File , String)
   */
  @Override
  public void outputCsvFile(List<String[]> fileOutputList,
      String csvCategory, File file, String header) {

    // 引数.ヘッダ文字列が設定されている場合。
    // ヘッダ文字列をカンマ（「,」）で分割し、引数.CSVファイル出力リストの先頭に挿入する。
    if (StringUtils.isNotEmpty(header)) {
      // ヘッダ文字列をカンマ（「,」）で分割
      String[] splitHeader = header.split(EMSConstants.COMMA, -1);
      fileOutputList.add(0, splitHeader);
    }

    // CsvConfig、エンコード設定
    CsvConfig cfg = new CsvConfig();
    String encode = createConfig(csvCategory, cfg);

    // Csvファイル出力
    try (CsvWriter csvWriter = new CsvWriter(new OutputStreamWriter(
        new FileOutputStream(file), encode), cfg)) {
      // 1行分のデータをList<String>に詰め直して書き出し
      for (String[] writeArg : fileOutputList) {
        List<String> writeList = new ArrayList<String>();
        if (writeArg != null) {
          for (String writeStr : writeArg) {
            // 空文字の場合はダブルクォートで囲まないのでnullに置き換え
            if (StringUtils.isEmpty(writeStr)) {
              writeList.add(null);
            } else {
              // 改行コードを半角スペースに置換
              writeStr = writeStr.replaceAll(
                  ECISConstants.REPLACEMENT_TARGET_ENTER_CODE_CSV_FILE_DOWNLOAD,
                  ECISConstants.SPACE_HANKAKU);
              if (EMSConstants.ENCODE_TYPE_SJIS.equals(encode)) {
                // 文字コードがSJISの場合はSJISに変換して書き込み
                writeList.add(StringConvertUtil.utf8ToSjis(writeStr));
              } else {
                // そうでない場合はUTF8なのでそのまま書き込み
                writeList.add(writeStr);
              }
            }
          }
        }
        csvWriter.writeValues(writeList);
      }
      csvWriter.close();
    } catch (FileNotFoundException e) {
      throw new SystemException(messageSource.getMessage("error.E1297", null, Locale.getDefault()), e);
    } catch (IOException e) {
      throw new SystemException(
          messageSource.getMessage("error.E1301", null, Locale.getDefault()), e);
    }

  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.gk.GK_WorkCommonBusiness#createCsvWriter(String, File, String)
   */
  @Override
  public CsvWriter createCsvWriter(String csvCategory, File file,
      String header) {

    // CsvConfig、エンコード設定
    CsvConfig cfg = new CsvConfig();
    String encode = createConfig(csvCategory, cfg);

    // 設定した情報を元に、「CsvWriterオブジェクト」を生成する。
    CsvWriter returnCsvWriter = null;
    try {
      returnCsvWriter = new CsvWriter(new OutputStreamWriter(
          new FileOutputStream(file), encode), cfg);
    } catch (UnsupportedEncodingException | FileNotFoundException e) {
      throw new SystemException(messageSource.getMessage("error.E1297", null, Locale.getDefault()), e);
    }

    // 引数.ヘッダ文字列が設定されている場合、以下の処理を行う。
    if (StringUtils.isNotEmpty(header)) {
      // 引数.ヘッダ文字列をカンマ区切り分割する。
      String[] headerSplit = header.split(EMSConstants.COMMA, -1);
      List<String> headerSplitList = new ArrayList<String>();

      try {
        for (String headerStr : headerSplit) {
          // 空文字の場合はダブルクォートで囲まないのでnullに置き換え
          if (StringUtils.isEmpty(headerStr)) {
            headerSplitList.add(null);
          } else {
            // 文字コード指定がSJISの場合はSJISに変換
            if (EMSConstants.ENCODE_TYPE_SJIS.equals(encode)) {
              headerSplitList.add(StringConvertUtil.utf8ToSjis(headerStr));
            } else {
              headerSplitList.add(headerStr);
            }
          }
        }
        // CsvWriterオブジェクト.writeValuesメソッドを呼び出し、分割した「ヘッダ文字列」を出力する。
        returnCsvWriter.writeValues(headerSplitList);
      } catch (IOException e) {
        throw new SystemException(
            messageSource.getMessage("error.E1301", null, Locale.getDefault()), e);
      }
    }

    // 作成したCsvWriterオブジェクトを返却する。
    return returnCsvWriter;
  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.gk.GK_WorkCommonBusiness#
   * registDownloadManage(jp.co.unisys.enability.cis.business.gk.model.GK_RegistDownloadManageBusinessBean)
   */
  @Override
  public void registDownloadManage(
      GK_RegistDownloadManageBusinessBean businessBean) {
    // 引数.《業務共通ダウンロード管理登録ビジネスBean》.ダウンロード期限日数取得キーを元に
    // プロパティよりダウンロード期限日数を取得する。
    Properties prop = null;
    try {
      prop = applicationProperties.getObject();
    } catch (IOException e) {
      throw new SystemException(messageSource.getMessage("error.E1265", null, Locale.getDefault()), e);
    }
    String dlExpirationTerm = prop.getProperty(businessBean
        .getDownloadExpirationDateCountKey());

    // システム日時取得
    Timestamp timestamp = new Timestamp(System.currentTimeMillis());

    // 《ダウンロード管理EntityBean》を生成し、値を設定する。
    DlMng dlMng = new DlMng();
    // ダウンロード管理ID - 自動採番
    // 取得条件Mapを作成する。
    Map<String, Object> dlIdMap = new HashMap<String, Object>();
    // ダウンロードIDシーケンステーブル名を設定する。
    dlIdMap.put("sqName", ECISConstants.SEQUENCE_NAME_DL_MNGMNT_ID);
    dlMng.setDlMngId(gkWorkCommonMapper.selectSequenceId(dlIdMap));
    // ファイル作成日時 - システム日時
    dlMng.setFileCreateTime(timestamp);
    // サブシステムID - 引数.《業務共通ダウンロード管理登録Bean》.サブシステムID
    dlMng.setSsysId(businessBean.getSubsystemId());
    // 機能ID - 引数.《業務共通ダウンロード管理登録Bean》.機能ID
    dlMng.setFunctionId(businessBean.getFunctionId());
    // ファイル分類コード - 引数.《業務共通ダウンロード管理登録Bean》.ファイル分類コード
    dlMng.setFileCatCode(businessBean.getFileCategoryCode());
    // 論理ファイル名 - 引数.《業務共通ダウンロード管理登録Bean》.論理ファイル名
    dlMng.setLogicalFileName(businessBean.getLogicalFileName());
    // ファイルパス - 引数.《業務共通ダウンロード管理登録Bean》.ファイルパス
    dlMng.setFilePath(businessBean.getFilePath());
    // ダウンロード期限 - 引数.バッチ処理基準日 ＋ 取得したダウンロード期限日数
    Calendar cal = Calendar.getInstance();
    cal.setTime(businessBean.getExecuteBaseDate());
    cal.add(Calendar.DATE, Integer.parseInt(dlExpirationTerm));
    dlMng.setDlExpirationDate(cal.getTime());
    // 更新回数 - 0
    dlMng.setUpdateCount(0);
    // 作成日時 - システム日時
    dlMng.setCreateTime(timestamp);
    // オンライン更新日時 - "1. コンテキスト.オンラインフラグが“ON”の場合
    if (ThreadContext.getRequestThreadContext()
        .get(ECISConstants.ONLINE_FLAG_KEY).toString()
        .equals(ECISConstants.ONLINE_FLAG_ONLINE)) {
      // システム日時を設定する。
      dlMng.setOnlineUpdateTime(timestamp);
      // コンテキスト.ユーザIDを設定する。
      dlMng.setOnlineUpdateUserId(ThreadContext.getRequestThreadContext()
          .get(ECISConstants.USER_ID_KEY).toString());
    }
    // 更新日時 - システム日時
    dlMng.setUpdateTime(timestamp);
    // 更新モジュールコード - コンテキスト.更新モジュールコード
    dlMng.setUpdateModuleCode(ThreadContext.getRequestThreadContext()
        .get(ECISConstants.CLASS_NAME_KEY).toString());

    // 【ダウンロード管理】を登録する。
    try {
      dlMngMapper.insertSelective(dlMng);
    } catch (Exception e) {
      throw new SystemException(messageSource.getMessage("error.E1273", null, Locale.getDefault()), e);
    }
  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.gk.GK_WorkCommonBusiness#editBillingNo(String)
   */
  @Override
  public String editBillingNo(String billingNo) {

    // 引数の請求番号がNULLの場合空文字を返却する。
    if (StringUtils.isEmpty(billingNo)) {
      return "";
    }

    // 引数の請求番号が半角でない場合空文字を返却する。
    if (!billingNo.matches(ECISConstants.HALF_WIDTH)) {
      return "";
    }

    // 引数の請求番号が12桁でない場合空文字を返却する。
    if (billingNo.length() != BILLING_NO_LENGTH) {
      return "";
    }

    // 引数の請求番号の4桁目、および9桁目に「-」（半角ハイフン）を挿入し、編集する。
    StringBuffer strBffr = new StringBuffer(BILLING_NO_LENGTH_EDIT);
    strBffr.append(billingNo.substring(0, BILLING_NO_HYPHEN_LOCATION_3));
    strBffr.append(ECISConstants.HYPHEN);
    strBffr.append(billingNo.substring(BILLING_NO_HYPHEN_LOCATION_3,
        BILLING_NO_HYPHEN_LOCATION_8));
    strBffr.append(ECISConstants.HYPHEN);
    strBffr.append(billingNo.substring(BILLING_NO_HYPHEN_LOCATION_8,
        BILLING_NO_LENGTH));

    // 編集した請求番号を返却する。
    return strBffr.toString();
  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.gk.GK_WorkCommonBusiness
   * #mailTextMaker(String, jp.co.unisys.enability.cis.business.sn.model.SN_CreateMailBusinessBean)
   */
  @Override
  public String mailTextMaker(String mailTemplate, SN_CreateMailBusinessBean bean) {

    // Velocityビジネスクラスのメールテンプレート編集を呼び出す。
    return this.gkVelocityBusiness.mailTextMaker(mailTemplate, bean);
  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.gk.GK_WorkCommonBusiness
   * #mailTextMaker(String, jp.co.unisys.enability.cis.business.sn.model.SN_CreateMailBusinessBean)
   */
  @Override
  public String evaluateStringVelocity(String stringFormat, SN_CreateMailBusinessBean bean) {

    // Velocityビジネスクラスの文字列フォーマット編集を呼び出す。
    return this.gkVelocityBusiness.evaluateStringVelocity(stringFormat, bean);
  }

  /**
   * CsvConfig設定
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * ファイル区分にあわせたCsvConfig設定を行い、
   * エンコードタイプを返却する。
   * </pre>
   *
   * @param csvCategory
   *          ファイル区分
   * @param cfg
   *          CsvConfig
   * @return String エンコードタイプ
   */
  private String createConfig(String csvCategory, CsvConfig cfg) {

    // エンコード設定
    String encode = null;
    // 引数.CSVファイル区分が“決済代行連携CSVファイル”の場合
    if (ECISSNConstants.SETTLEMENT_AGENCY_LINKAGE_CSV_FILE
        .equals(csvCategory)) {
      // ・囲み文字 ← 「"」
      cfg.setQuoteDisabled(false);
      cfg.setQuote(CsvConfig.DEFAULT_QUOTE);
      // ・改行コード ← 「LF」
      cfg.setLineSeparator(ECISConstants.ENTER_CODE_LF);
      // エスケープなし 値内にダブルクォーテーションを含む場合は、CsvWriter.writeValuesでIOException発生
      cfg.setEscapeDisabled(true);
      // 値がないことを示す文字列 ← なし
      cfg.setNullString(null);
      // エンコード ← UTF8
      encode = EMSConstants.ENCODE_TYPE_UTF8;

      // 引数.CSVファイル区分が“その他ファイル”の場合
    } else if (ECISSNConstants.OTHER_CSV_FILE.equals(csvCategory)) {
      // ・囲み文字 ← 「"」
      cfg.setQuoteDisabled(false);
      cfg.setQuote(CsvConfig.DEFAULT_QUOTE);
      // ・改行コード ← 「CRLF」
      cfg.setLineSeparator(EMSConstants.ENTER_CODE);
      // ダブルクォーテーション2重化
      cfg.setEscape(CsvConfig.DEFAULT_QUOTE);
      cfg.setEscapeDisabled(false);
      // 値がないことを示す文字列 ← なし
      cfg.setNullString(null);
      // エンコード ← SJIS
      encode = EMSConstants.ENCODE_TYPE_SJIS;
    } else {
      // 上記以外の場合
      // システム例外をスローする。
      throw new SystemException(
          messageSource.getMessage("error.E1300", null, Locale.getDefault()));
    }
    // エンコード設定返却
    return encode;
  }

  /**
   * 業務日程管理マスタマッパーを設定する。(DI)
   *
   * @param workScheduleMngMMapper
   *          業務日程管理マスタマッパー
   */
  public void setWorkScheduleMngMMapper(
      WorkScheduleMngMMapper workScheduleMngMMapper) {
    this.workScheduleMngMMapper = workScheduleMngMMapper;
  }

  /**
   * ダウンロード管理マッパーを設定する。(DI)
   *
   * @param dlMngMapper
   *          ダウンロード管理マッパー
   */
  public void setDlMngMapper(DlMngMapper dlMngMapper) {
    this.dlMngMapper = dlMngMapper;
  }

  /**
   * コード定義プロパティを設定する。(DI)
   *
   * @param applicationProperties
   *          コード定義プロパティ
   */
  public void setApplicationProperties(
      PropertiesFactoryBean applicationProperties) {
    this.applicationProperties = applicationProperties;
  }

  /**
   * 業務共通共通マッパーを設定する。(DI)
   *
   * @param gkWorkCommonMapper
   *          業務共通共通マッパー
   */
  public void setGkWorkCommonMapper(
      GK_WorkCommonMapper gkWorkCommonMapper) {
    this.gkWorkCommonMapper = gkWorkCommonMapper;
  }

  /**
   * メッセージプロパティを設定する。(DI)
   *
   * @param messageSource
   *          メッセージプロパティ
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }

  /**
   * Velocityビジネスを設定する。（DI）
   *
   * @param gkVelocityBusiness
   *          Velocityビジネス
   */
  public void setGkVelocityBusiness(
      GK_VelocityBusiness gkVelocityBusiness) {
    this.gkVelocityBusiness = gkVelocityBusiness;
  }

}
