package jp.co.unisys.enability.cis.business.kj;

import java.sql.Timestamp;
import java.util.List;
import java.util.Locale;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.util.CollectionUtils;

import jp.co.unisys.enability.cis.business.kj.model.Custom_InquiryCustomContractorBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.Custom_RegistCustomContractorBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.Custom_UpdateCustomContractorBusinessBean;
import jp.co.unisys.enability.cis.common.Exception.BusinessLogicException;
import jp.co.unisys.enability.cis.common.Exception.SystemException;
import jp.co.unisys.enability.cis.common.util.KJ_CommonUtil;
import jp.co.unisys.enability.cis.common.util.ThreadContext;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISKJConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISReturnCodeConstants;
import jp.co.unisys.enability.cis.entity.common.CContractor;
import jp.co.unisys.enability.cis.entity.common.CContractorExample;
import jp.co.unisys.enability.cis.mapper.common.CContractorMapper;

/**
 * カスタム契約者情報ビジネス
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.kj.Custom_KJ_CustomContractorInformationBusiness
 *
 *      変更履歴(kg-epj) 2016.02.15 liu 新規作成
 *
 */
public class Custom_KJ_CustomContractorInformationBusinessImpl implements
    Custom_KJ_CustomContractorInformationBusiness {

  /**
   * カスタム契約者情報マッパー(DI)
   */
  private CContractorMapper cContractorMapper;

  /**
   * メッセージプロパティ(DI)
   */
  private MessageSource messageSource;

  /**
   * ログマネジャー
   */
  private static Logger logger = LogManager.getLogger();

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.kj.Custom_KJ_CustomContractorInformationBusiness
   * #inquiry
   * (jp.co.unisys.enability.cis.business.kj.model.Custom_InquiryCustomContractorBusinessBean
   * )
   */
  @Override
  public Custom_InquiryCustomContractorBusinessBean inquiry(
      Custom_InquiryCustomContractorBusinessBean inquiryBean) {

    // DataAccessException用エラーメッセージ
    String dataAccessExceptionEMsg = null;

    try {

      dataAccessExceptionEMsg = messageSource.getMessage(
          KJ_CommonUtil.getMessageId(ECISReturnCodeConstants.RETURN_CODE_G017),
          new String[] {}, Locale.getDefault());

      //《カスタム契約者Mapper》.検索（主キー)呼び出し
      // 照会結果設定
      // 条件Map.契約者ID
      Integer contractorId = inquiryBean.getContractorId();

      CContractorExample example = new CContractorExample();
      example.createCriteria().andContractorIdEqualTo(contractorId);
      List<CContractor> inquiryCustomContractorInformationEntityBeanList = cContractorMapper
          .selectByExample(example);

      inquiryBean.setCustomContractorInformationList(inquiryCustomContractorInformationEntityBeanList);
      // 正常終了
      inquiryBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);

    } catch (DataAccessException e) {
      // [kg-epj]<d-start>
      //logger.error(messageSource.getMessage("error.E1129", null,
      //		Locale.getDefault()), e);
      // [kg-epj]<d-end>
      // [kg-epj]<i-start>
      logger.error(dataAccessExceptionEMsg, e);
      // [kg-epj]<i-end>
      // catch 業務例外クラス
      inquiryBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      inquiryBean.setMessage(dataAccessExceptionEMsg);

    } catch (NoSuchMessageException e) {
      // [kg-epj]<d-start>
      //logger.error(messageSource.getMessage("error.E1129", null,
      //		Locale.getDefault()), e);
      // [kg-epj]<d-end>
      // [kg-epj]<i-start>
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, e);
      // [kg-epj]<i-end>
      inquiryBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      inquiryBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
    }
    return inquiryBean;
  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.kj.Custom_KJ_CustomContractorInformationBusiness
   * #regist
   * (jp.co.unisys.enability.cis.business.kj.model.Custom_RegistCustomContractorBusinessBean
   * )
   */
  @Override
  public Custom_RegistCustomContractorBusinessBean regist(
      Custom_RegistCustomContractorBusinessBean registContractorBusinessBean) {

    // エラーメッセージを定義する。
    String errorMessageG017 = null;
    String errorMessageD023 = null;

    // 契約者Entity
    CContractor cContractor;

    try {

      // リターンコード(D023)に対応するメッセージを取得する
      errorMessageD023 = messageSource.getMessage(KJ_CommonUtil
          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D023),
          new String[] {}, Locale.getDefault());

      // リターンコード(G017)に対応するメッセージを取得する。
      errorMessageG017 = messageSource.getMessage(KJ_CommonUtil.getMessageId(
          ECISReturnCodeConstants.RETURN_CODE_G017), new String[] {},
          Locale.getDefault());

      // DB登録
      Timestamp systemDate = new Timestamp(System.currentTimeMillis());
      cContractor = new CContractor();
      // 契約者ID
      cContractor.setContractorId(registContractorBusinessBean.getContractorId());
      // 外部システム契約者番号
      cContractor.setGasCustomerNo(registContractorBusinessBean.getGasCustomerNo());
      // 更新回数
      cContractor.setUpdateCount(0);
      // 作成日時
      cContractor.setCreateTime(systemDate);
      // オンライン更新日時
      cContractor.setOnlineUpdateTime(systemDate);
      // オンライン更新ユーザID
      cContractor.setOnlineUpdateUserId(ThreadContext
          .getRequestThreadContext().get(ECISConstants.USER_ID_KEY)
          .toString());
      // 更新日時
      cContractor.setUpdateTime(systemDate);
      // 更新モジュールコード
      cContractor.setUpdateModuleCode(ThreadContext
          .getRequestThreadContext()
          .get(ECISConstants.CLASS_NAME_KEY).toString());
      // 《契約者情報共通Dao》.契約者情報登録を呼び出す。
      cContractorMapper.insert(cContractor);
      // 正常終了
      registContractorBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);

    } catch (DuplicateKeyException e) {
      logger.error(errorMessageD023, e);
      // 重複例外クラス
      registContractorBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D023);
      registContractorBusinessBean.setMessage(errorMessageD023);
    } catch (DataIntegrityViolationException dataIntegrityViolationException) {
      logger.error(errorMessageD023, dataIntegrityViolationException);
      // 制約違反例外クラス
      registContractorBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D023);
      registContractorBusinessBean.setMessage(errorMessageD023);
    } catch (NoSuchMessageException e) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, e);
      registContractorBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      registContractorBusinessBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
    } catch (DataAccessException e) {
      logger.error(errorMessageG017, e);
      registContractorBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      registContractorBusinessBean.setMessage(errorMessageG017);
    }
    return registContractorBusinessBean;
  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.kj.Custom_KJ_CustomContractorInformationBusiness
   * #update
   * (jp.co.unisys.enability.cis.business.kj.model.Custom_UpdateCustomContractorBusinessBean
   * )
   */
  @Override
  public Custom_UpdateCustomContractorBusinessBean update(
      Custom_UpdateCustomContractorBusinessBean updateContractorBusinessBean) {

    // エラーメッセージを定義する。
    String errorMessage = null;

    // オンライン処理基準日取得エラー用エラーメッセージ
    String getProcessBaseDateErrorEMsg = null;

    // カスタム契約者情報照会BusinessBean
    Custom_InquiryCustomContractorBusinessBean customInquiryCustomContractorBusinessBean;

    // カスタム契約者情報照会EntityBean
    CContractor inquiryContractorInformationEntityBean;

    // カスタム契約者Entity
    CContractor ccontractor;

    // カスタム契約者EntityExample
    CContractorExample ccontractorExample;

    try {

      // リターンコード(G017)に対応するメッセージを取得する。
      errorMessage = messageSource.getMessage(KJ_CommonUtil
          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G017),
          new String[] {}, Locale.getDefault());
      getProcessBaseDateErrorEMsg = messageSource.getMessage("error.E1286", new String[] {}, Locale.getDefault());

      // DB存在チェック
      customInquiryCustomContractorBusinessBean = new Custom_InquiryCustomContractorBusinessBean();
      // 《カスタム契約者情報更新BusinessBean》.契約者IDを設定する。
      customInquiryCustomContractorBusinessBean
          .setContractorId(updateContractorBusinessBean
              .getContractorId());
      // カスタム契約者情報照会呼び出し
      customInquiryCustomContractorBusinessBean = inquiry(customInquiryCustomContractorBusinessBean);
      // 《契約者情報照会BusinessBean》.リターンコードが'0000'以外の場合
      if (!ECISReturnCodeConstants.RETURN_CODE_0000
          .equals(customInquiryCustomContractorBusinessBean.getReturnCode())) {

        throw new BusinessLogicException(messageSource.getMessage(
            "error.E1281", new String[] {}, Locale.getDefault()), false);
      }
      // 《契約者情報照会EntityBean》リストが0件の場合
      if (CollectionUtils
          .isEmpty(customInquiryCustomContractorBusinessBean.getCustomContractorInformationList())) {

        updateContractorBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P003);
        updateContractorBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P003),
                new String[] {}, Locale.getDefault()));
        return updateContractorBusinessBean;

      }
      inquiryContractorInformationEntityBean = customInquiryCustomContractorBusinessBean
          .getCustomContractorInformationList().get(0);

      // DB更新
      Timestamp systemDate = new Timestamp(System.currentTimeMillis());
      ccontractor = new CContractor();
      ccontractorExample = new CContractorExample();
      // 契約者ID
      ccontractor.setContractorId(inquiryContractorInformationEntityBean
          .getContractorId());
      // 外部システム契約者番号
      ccontractor.setGasCustomerNo(updateContractorBusinessBean.getGasCustomerNo());
      // 更新回数
      ccontractor.setUpdateCount(inquiryContractorInformationEntityBean
          .getUpdateCount() + 1);
      // オンライン更新日時
      ccontractor.setOnlineUpdateTime(systemDate);
      // オンライン更新ユーザID
      ccontractor.setOnlineUpdateUserId(ThreadContext
          .getRequestThreadContext().get(ECISConstants.USER_ID_KEY)
          .toString());
      // 更新日時
      ccontractor.setUpdateTime(systemDate);
      // 更新モジュールコード
      ccontractor.setUpdateModuleCode(ThreadContext
          .getRequestThreadContext()
          .get(ECISConstants.CLASS_NAME_KEY).toString());
      // Example設定
      ccontractorExample
          .createCriteria()
          .andContractorIdEqualTo(
              inquiryContractorInformationEntityBean
                  .getContractorId());
      // 《契約者情報共通Dao》.契約者情報更新の返却値が0件の場合
      if (cContractorMapper.updateByExampleSelective(ccontractor,
          ccontractorExample) == 0) {

        updateContractorBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_H001);
        updateContractorBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_H001),
                new String[] {}, Locale.getDefault()));
        return updateContractorBusinessBean;

      }
      // 正常終了
      updateContractorBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);

    } catch (BusinessLogicException e) {
      logger.error(errorMessage, e);
      // catch 業務例外クラス
      updateContractorBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      updateContractorBusinessBean.setMessage(errorMessage);

    } catch (NoSuchMessageException e) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, e);
      updateContractorBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      updateContractorBusinessBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
    } catch (SystemException e) {
      logger.error(errorMessage, e);
      updateContractorBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      updateContractorBusinessBean
          .setMessage(getProcessBaseDateErrorEMsg);
    }
    return updateContractorBusinessBean;
  }

  /**
   * カスタム契約者情報マッパーのセッター(DI)
   *
   * @param cContractorMapper
   *          カスタム契約者情報マッパー
   */
  public void setCContractorMapper(CContractorMapper cContractorMapper) {
    this.cContractorMapper = cContractorMapper;
  }

  /**
   * messageSourceのセッター(DI)
   *
   * @param messageSource
   *          メッセージソース
   *
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }
}
