package jp.co.unisys.enability.cis.business.common.model;

import java.util.List;

/**
 * メール管理共通で、登録条件を格納するビジネスBean
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * メール管理共通ビジネス
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class MailManagementBusinessBean {

  /** 宛先（To） */
  private List<String> addressTo;

  /** 宛先（CC） */
  private List<String> addressCc;

  /** 宛先（BCC） */
  private List<String> addressBcc;

  /** 件名 */
  private String subject;

  /** 本文 */
  private String mailBody;

  public List<String> getAddressTo() {
    return addressTo;
  }

  public void setAddressTo(List<String> addressTo) {
    this.addressTo = addressTo;
  }

  public List<String> getAddressCc() {
    return addressCc;
  }

  public void setAddressCc(List<String> addressCc) {
    this.addressCc = addressCc;
  }

  public List<String> getAddressBcc() {
    return addressBcc;
  }

  public void setAddressBcc(List<String> addressBcc) {
    this.addressBcc = addressBcc;
  }

  public String getSubject() {
    return subject;
  }

  public void setSubject(String subject) {
    this.subject = subject;
  }

  public String getMailBody() {
    return mailBody;
  }

  public void setMailBody(String mailBody) {
    this.mailBody = mailBody;
  }

}
