package jp.co.unisys.enability.cis.business.gk;

import java.nio.file.Path;

import jp.co.unisys.enability.cis.common.Exception.BusinessLogicException;

/**
 * PDF作成共通ビジネス_カスタムインターフェース<br>
 *
 * このクラスはApache License, Version 2.0 のライセンスで<br>
 * 配布されている成果物を利用しています。<br>
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @author "Nihon Unisys, Ltd."
 *
 *         変更履歴(kg-epj) 2016.02.23 T.Hori 新規作成
 */
public interface Custom_CreatePdfBusiness {

  /**
   * PDFファイル作成
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数に指定されたパスのファイルを読み込み、以下の処理を行う。
   * ・xmlファイルの内容を取得
   * ・xsltファイルにマージ
   * ・pdfファイルに出力
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param pdfFilePath
   *          出力するPDFファイルのパス
   * @param xsltFilePath
   *          レイアウトテンプレートファイルのパス
   * @param xmlFilePath
   *          XMLファイルパス
   */
  public void create(Path pdfFilePath, Path xsltFilePath, Path xmlFilePath)
      throws BusinessLogicException;

}
