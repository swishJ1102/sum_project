package jp.co.unisys.enability.cis.business.kj.model;

import java.util.Date;

/**
 * 支払情報照会で、登録情報を格納するビジネスBean
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * 支払情報ビジネス
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RegistPaymentBusinessBean {

  /**
   * 支払IDを保有する。
   */
  private Integer paymentId;

  /**
   * 支払番号を保有する。
   */
  private String paymentNo;

  /**
   * 契約者IDを保有する。
   */
  private Integer contractorId;

  /**
   * 契約者番号を保有する。
   */
  private String contractorNo;

  /**
   * 口座クレカIDを保有する。
   */
  private Integer accountCreditCardId;

  /**
   * 口振クレカ翌月請求フラグを保有する。
   */
  private String directDebitCreditCardNextMonthBillingFlag;

  /**
   * 支払適用開始日を保有する。
   */
  private Date paymentStartDate;

  /**
   * 支払方法コードを保有する。
   */
  private String paymentWayCode;

  /**
   * 支払期限個別設定フラグを保有する。
   */
  private String paymentExpirationIndividualSettingFlag;

  /**
   * 支払期限加算月数を保有する。
   */
  private Integer paymentExpirationAddMonths;

  /**
   * 支払期限日を保有する。
   */
  private Integer paymentExpirationDate;

  /**
   * 前月請求合算を保有する。
   */
  private String previousBillingAddUpFlag;

  /**
   * 個人・法人区分コードを保有する。
   */
  private String individualLegalEntityCategoryCode;

  /**
   * 請求先氏名1を保有する。
   */
  private String billingName1;

  /**
   * 請求先氏名2を保有する。
   */
  private String billingName2;

  /**
   * 敬称を保有する。
   */
  private String prefix;

  /**
   * 請求先住所（郵便番号）を保有する。
   */
  private String billingAddressPostalCode;

  /**
   * 請求先住所（都道府県名）を保有する。
   */
  private String billingAddressPrefectures;

  /**
   * 請求先住所（市区郡町村名）を保有する。
   */
  private String billingAddressMunicipality;

  /**
   * 請求先住所（字名・丁目）を保有する。
   */
  private String billingAddressSection;

  /**
   * 請求先住所（番地･号）を保有する。
   */
  private String billingAddressBlock;

  /**
   * 請求先住所（建物名）を保有する。
   */
  private String billingAddressBuildingName;

  /**
   * 請求先住所（部屋名）を保有する。
   */
  private String billingAddressRoom;

  /**
   * 請求先電話番号を保有する。
   */
  private String billingPhoneNo;

  /**
   * 請求先電話区分コードを保有する。
   */
  private String billingPhoneCategoryCode;

  /**
   * 請求先メールアドレス1を保有する。
   */
  private String billingMailAddress1;

  /**
   * 請求先メールアドレス2を保有する。
   */
  private String billingMailAddress2;

  /**
   * 送金口座IDを保有する。
   */
  private String remittanceAccountId;

  /**
   * 送金口座金融機関コードを保有する。
   */
  private String remittanceAccountBankCode;

  /**
   * : 送金口座支店コードを保有する。
   */
  private String remittanceAccountBankBranchCode;

  /**
   * 送金口座預金種目を保有する。
   */
  private String remittanceAccountBankTypeOfAccountCode;

  /**
   * 送金口座口座番号を保有する。
   */
  private String remittanceAccountAccountNo;

  /**
   * 送金口座口座名義を保有する。
   */
  private String remittanceAccountAccountHolderName;

  /**
   * 送金口座記号を保有する。
   */
  private String remittanceAccountSymbol;

  /**
   * 送金口座番号を保有する。
   */
  private String remittanceAccountNo;

  /**
   * フリー項目1を保有する。
   */
  private String free1;

  /**
   * フリー項目2を保有する。
   */
  private String free2;

  /**
   * リターンコードを保有する。
   */
  private String returnCode;

  /**
   * メッセージを保有する。
   */
  private String message;

  /**
   * 口座クレカID更新対象外フラグを保有する。
   */
  private String accountCreditCardIdNoUpdFlag;

  /**
   * 更新回数を保有する。
   */
  private Integer updateCount;

  /**
   * 支払IDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 支払IDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 支払ID
   */
  public Integer getPaymentId() {
    return this.paymentId;
  }

  /**
   * 支払IDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 支払IDを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param paymentId
   *          支払ID
   */
  public void setPaymentId(Integer paymentId) {
    this.paymentId = paymentId;
  }

  /**
   * 支払番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 支払番号を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 支払番号
   */
  public String getPaymentNo() {
    return this.paymentNo;
  }

  /**
   * 支払番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 支払番号を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param paymentNo
   *          支払番号
   */
  public void setPaymentNo(String paymentNo) {
    this.paymentNo = paymentNo;
  }

  /**
   * 契約者IDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者IDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者ID
   */
  public Integer getContractorId() {
    return this.contractorId;
  }

  /**
   * 契約者IDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者IDを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorId
   *          契約者ID
   */
  public void setContractorId(Integer contractorId) {
    this.contractorId = contractorId;
  }

  /**
   * 契約者番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者番号を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者番号
   */
  public String getContractorNo() {
    return this.contractorNo;
  }

  /**
   * 契約者番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者番号を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorNo
   *          契約者番号
   */
  public void setContractorNo(String contractorNo) {
    this.contractorNo = contractorNo;
  }

  /**
   * 口座クレカIDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 口座クレカIDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 口座クレカID
   */
  public Integer getAccountCreditCardId() {
    return this.accountCreditCardId;
  }

  /**
   * 口座クレカIDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 口座クレカIDを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param accountCreditCardId
   *          口座クレカID
   */
  public void setAccountCreditCardId(Integer accountCreditCardId) {
    this.accountCreditCardId = accountCreditCardId;
  }

  /**
   * 口振クレカ翌月請求フラグのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 口振クレカ翌月請求フラグを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 口振クレカ翌月請求フラグ
   */
  public String getDirectDebitCreditCardNextMonthBillingFlag() {
    return this.directDebitCreditCardNextMonthBillingFlag;
  }

  /**
   * 口振クレカ翌月請求フラグのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 口振クレカ翌月請求フラグを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param directDebitCreditCardNextMonthBillingFlag
   *          口振クレカ翌月請求フラグ
   */
  public void setDirectDebitCreditCardNextMonthBillingFlag(
      String directDebitCreditCardNextMonthBillingFlag) {
    this.directDebitCreditCardNextMonthBillingFlag = directDebitCreditCardNextMonthBillingFlag;
  }

  /**
   * 支払適用開始日のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 支払適用開始日を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 支払適用開始日
   */
  public Date getPaymentStartDate() {
    return this.paymentStartDate;
  }

  /**
   * 支払適用開始日のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 支払適用開始日を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param paymentStartDate
   *          支払適用開始日
   */
  public void setPaymentStartDate(Date paymentStartDate) {
    this.paymentStartDate = paymentStartDate;
  }

  /**
   * 支払方法コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 支払方法コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 支払方法コード
   */
  public String getPaymentWayCode() {
    return this.paymentWayCode;
  }

  /**
   * 支払方法コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 支払方法コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param paymentWayCode
   *          支払方法コード
   */
  public void setPaymentWayCode(String paymentWayCode) {
    this.paymentWayCode = paymentWayCode;
  }

  /**
   * 支払期限個別設定フラグを取得する。
   * 
   * @return 支払期限個別設定フラを保有する。
   */
  public String getPaymentExpirationIndividualSettingFlag() {
    return paymentExpirationIndividualSettingFlag;
  }

  /**
   * 支払期限個別設定フラグを設定する。
   * 
   * @param paymentExpirationIndividualSettingFlag
   */
  public void setPaymentExpirationIndividualSettingFlag(
      String paymentExpirationIndividualSettingFlag) {
    this.paymentExpirationIndividualSettingFlag = paymentExpirationIndividualSettingFlag;
  }

  /**
   * 支払期限加算月数を取得する
   * 
   * @return 支払期限加算月数を保有する。
   */
  public Integer getPaymentExpirationAddMonths() {
    return paymentExpirationAddMonths;
  }

  /**
   * 支払期限加算月数を設定する。
   * 
   * @param paymentExpirationDateAddMonth
   *          支払期限加算月数を保有する。
   */
  public void setPaymentExpirationAddMonths(Integer paymentExpirationAddMonths) {
    this.paymentExpirationAddMonths = paymentExpirationAddMonths;
  }

  /**
   * 支払期限日を取得する
   * 
   * @return
   */
  public Integer getPaymentExpirationDate() {
    return paymentExpirationDate;
  }

  /**
   * 支払期限日を設定する。
   * 
   * @param paymentExpirattonDate
   */
  public void setPaymentExpirationDate(Integer paymentExpirationDate) {
    this.paymentExpirationDate = paymentExpirationDate;
  }

  /**
   * 前月請求合算取得します。
   * 
   * @return 前月請求合算を保有する。
   */
  public String getPreviousBillingAddUpFlag() {
    return previousBillingAddUpFlag;
  }

  /**
   * 前月請求合算を設定します。
   * 
   * @param previousBillingAddUp
   */
  public void setPreviousBillingAddUpFlag(String previousBillingAddUpFlag) {
    this.previousBillingAddUpFlag = previousBillingAddUpFlag;
  }

  /**
   * 個人・法人区分コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 個人・法人区分コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 個人・法人区分コード
   */
  public String getIndividualLegalEntityCategoryCode() {
    return this.individualLegalEntityCategoryCode;
  }

  /**
   * 個人・法人区分コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 個人・法人区分コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param individualLegalEntityCategoryCode
   *          個人・法人区分コード
   */
  public void setIndividualLegalEntityCategoryCode(
      String individualLegalEntityCategoryCode) {
    this.individualLegalEntityCategoryCode = individualLegalEntityCategoryCode;
  }

  /**
   * 請求先氏名1のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先氏名1を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 請求先氏名1
   */
  public String getBillingName1() {
    return this.billingName1;
  }

  /**
   * 請求先氏名1のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先氏名1を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param billingName1
   *          請求先氏名1
   */
  public void setBillingName1(String billingName1) {
    this.billingName1 = billingName1;
  }

  /**
   * 請求先氏名2のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先氏名2を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 請求先氏名2
   */
  public String getBillingName2() {
    return this.billingName2;
  }

  /**
   * 請求先氏名2のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先氏名2を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param billingName2
   *          請求先氏名2
   */
  public void setBillingName2(String billingName2) {
    this.billingName2 = billingName2;
  }

  /**
   * 敬称のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 敬称を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 敬称
   */
  public String getPrefix() {
    return this.prefix;
  }

  /**
   * 敬称のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 敬称を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param prefix
   *          敬称
   */
  public void setPrefix(String prefix) {
    this.prefix = prefix;
  }

  /**
   * 請求先住所（郵便番号）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先住所（郵便番号）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 請求先住所（郵便番号）
   */
  public String getBillingAddressPostalCode() {
    return this.billingAddressPostalCode;
  }

  /**
   * 請求先住所（郵便番号）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先住所（郵便番号）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param billingAddressPostalCode
   *          請求先住所（郵便番号）
   */
  public void setBillingAddressPostalCode(String billingAddressPostalCode) {
    this.billingAddressPostalCode = billingAddressPostalCode;
  }

  /**
   * 請求先住所（都道府県名）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先住所（都道府県名）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 請求先住所（都道府県名）
   */
  public String getBillingAddressPrefectures() {
    return this.billingAddressPrefectures;
  }

  /**
   * 請求先住所（都道府県名）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先住所（都道府県名）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param billingAddressPrefectures
   *          請求先住所（都道府県名）
   */
  public void setBillingAddressPrefectures(String billingAddressPrefectures) {
    this.billingAddressPrefectures = billingAddressPrefectures;
  }

  /**
   * 請求先住所（市区郡町村名）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先住所（市区郡町村名）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 請求先住所（市区郡町村名）
   */
  public String getBillingAddressMunicipality() {
    return this.billingAddressMunicipality;
  }

  /**
   * 請求先住所（市区郡町村名）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先住所（市区郡町村名）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param billingAddressMunicipality
   *          請求先住所（市区郡町村名）
   */
  public void setBillingAddressMunicipality(String billingAddressMunicipality) {
    this.billingAddressMunicipality = billingAddressMunicipality;
  }

  /**
   * 請求先住所（字名・丁目）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先住所（字名・丁目）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 請求先住所（字名・丁目）
   */
  public String getBillingAddressSection() {
    return this.billingAddressSection;
  }

  /**
   * 請求先住所（字名・丁目）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先住所（字名・丁目）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param billingAddressSection
   *          請求先住所（字名・丁目）
   */
  public void setBillingAddressSection(String billingAddressSection) {
    this.billingAddressSection = billingAddressSection;
  }

  /**
   * 請求先住所（番地･号）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先住所（番地･号）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 請求先住所（番地･号）
   */
  public String getBillingAddressBlock() {
    return this.billingAddressBlock;
  }

  /**
   * 請求先住所（番地･号）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先住所（番地･号）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param billingAddressBlock
   *          請求先住所（番地･号）
   */
  public void setBillingAddressBlock(String billingAddressBlock) {
    this.billingAddressBlock = billingAddressBlock;
  }

  /**
   * 請求先住所（建物名）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先住所（建物名）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 請求先住所（建物名）
   */
  public String getBillingAddressBuildingName() {
    return this.billingAddressBuildingName;
  }

  /**
   * 請求先住所（建物名）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先住所（建物名）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param billingAddressBuildingName
   *          請求先住所（建物名）
   */
  public void setBillingAddressBuildingName(String billingAddressBuildingName) {
    this.billingAddressBuildingName = billingAddressBuildingName;
  }

  /**
   * 請求先住所（部屋名）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先住所（部屋名）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 請求先住所（部屋名）
   */
  public String getBillingAddressRoom() {
    return this.billingAddressRoom;
  }

  /**
   * 請求先住所（部屋名）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先住所（部屋名）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param billingAddressRoom
   *          請求先住所（部屋名）
   */
  public void setBillingAddressRoom(String billingAddressRoom) {
    this.billingAddressRoom = billingAddressRoom;
  }

  /**
   * 請求先電話番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先電話番号を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 請求先電話番号
   */
  public String getBillingPhoneNo() {
    return this.billingPhoneNo;
  }

  /**
   * 請求先電話番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先電話番号を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param billingPhoneNo
   *          請求先電話番号
   */
  public void setBillingPhoneNo(String billingPhoneNo) {
    this.billingPhoneNo = billingPhoneNo;
  }

  /**
   * 請求先電話区分コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先電話区分コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 請求先電話区分コード
   */
  public String getBillingPhoneCategoryCode() {
    return this.billingPhoneCategoryCode;
  }

  /**
   * 請求先電話区分コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先電話区分コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param billingPhoneCategoryCode
   *          請求先電話区分コード
   */
  public void setBillingPhoneCategoryCode(String billingPhoneCategoryCode) {
    this.billingPhoneCategoryCode = billingPhoneCategoryCode;
  }

  /**
   * 請求先メールアドレス1のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先メールアドレス1を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 請求先メールアドレス1
   */
  public String getBillingMailAddress1() {
    return this.billingMailAddress1;
  }

  /**
   * 請求先メールアドレス1のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先メールアドレス1を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param billingMailAddress1
   *          請求先メールアドレス1
   */
  public void setBillingMailAddress1(String billingMailAddress1) {
    this.billingMailAddress1 = billingMailAddress1;
  }

  /**
   * 請求先メールアドレス2のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先メールアドレス2を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 請求先メールアドレス2
   */
  public String getBillingMailAddress2() {
    return this.billingMailAddress2;
  }

  /**
   * 請求先メールアドレス2のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先メールアドレス2を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param billingMailAddress2
   *          請求先メールアドレス2
   */
  public void setBillingMailAddress2(String billingMailAddress2) {
    this.billingMailAddress2 = billingMailAddress2;
  }

  /**
   * 送金口座IDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 送金口座IDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 送金口座ID
   */
  public String getRemittanceAccountId() {
    return remittanceAccountId;
  }

  /**
   * 送金口座IDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 送金口座IDを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   */
  public void setRemittanceAccountId(String remittanceAccountId) {
    this.remittanceAccountId = remittanceAccountId;
  }

  /**
   * 送金口座金融機関コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 送金口座金融機関コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 送金口座金融機関コード
   */
  public String getRemittanceAccountBankCode() {
    return remittanceAccountBankCode;
  }

  /**
   * 送金口座金融機関コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 送金口座金融機関コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   */
  public void setRemittanceAccountBankCode(String remittanceAccountBankCode) {
    this.remittanceAccountBankCode = remittanceAccountBankCode;
  }

  /**
   * 送金口座支店コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 送金口座支店コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 送金口座支店コード
   */
  public String getRemittanceAccountBankBranchCode() {
    return remittanceAccountBankBranchCode;
  }

  /**
   * 送金口座支店コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 送金口座支店コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   */
  public void setRemittanceAccountBankBranchCode(String remittanceAccountBankBranchCode) {
    this.remittanceAccountBankBranchCode = remittanceAccountBankBranchCode;
  }

  /**
   * 送金口座預金種目のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 送金口座預金種目を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 送金口座預金種目
   */
  public String getRemittanceAccountBankTypeOfAccountCode() {
    return remittanceAccountBankTypeOfAccountCode;
  }

  /**
   * 送金口座預金種目のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 送金口座預金種目を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   */
  public void setRemittanceAccountBankTypeOfAccountCode(String remittanceAccountBankTypeOfAccountCode) {
    this.remittanceAccountBankTypeOfAccountCode = remittanceAccountBankTypeOfAccountCode;
  }

  /**
   * 送金口座口座番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 送金口座口座番号を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 送金口座口座番号
   */
  public String getRemittanceAccountAccountNo() {
    return remittanceAccountAccountNo;
  }

  /**
   * 送金口座口座番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 送金口座口座番号を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   */
  public void setRemittanceAccountAccountNo(String remittanceAccountAccountNo) {
    this.remittanceAccountAccountNo = remittanceAccountAccountNo;
  }

  /**
   * 送金口座口座名義のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 送金口座口座名義を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 送金口座口座名義
   */
  public String getRemittanceAccountAccountHolderName() {
    return remittanceAccountAccountHolderName;
  }

  /**
   * 送金口座口座名義のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 送金口座口座名義を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   */
  public void setRemittanceAccountAccountHolderName(String remittanceAccountAccountHolderName) {
    this.remittanceAccountAccountHolderName = remittanceAccountAccountHolderName;
  }

  /**
   * 送金口座記号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 送金口座記号を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 送金口座記号
   */
  public String getRemittanceAccountSymbol() {
    return remittanceAccountSymbol;
  }

  /**
   * 送金口座記号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 送金口座記号を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   */
  public void setRemittanceAccountSymbol(String remittanceAccountSymbol) {
    this.remittanceAccountSymbol = remittanceAccountSymbol;
  }

  /**
   * 送金口座番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 送金口座番号を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 送金口座番号
   */
  public String getRemittanceAccountNo() {
    return remittanceAccountNo;
  }

  /**
   * 送金口座番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 送金口座番号を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   */
  public void setRemittanceAccountNo(String remittanceAccountNo) {
    this.remittanceAccountNo = remittanceAccountNo;
  }

  /**
   * フリー項目1のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * フリー項目1を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return フリー項目1
   */
  public String getFree1() {
    return this.free1;
  }

  /**
   * フリー項目1のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * フリー項目1を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param free1
   *          フリー項目1
   */
  public void setFree1(String free1) {
    this.free1 = free1;
  }

  /**
   * フリー項目2のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * フリー項目2を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return フリー項目2
   */
  public String getFree2() {
    return this.free2;
  }

  /**
   * フリー項目2のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * フリー項目2を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param free2
   *          フリー項目2
   */
  public void setFree2(String free2) {
    this.free2 = free2;
  }

  /**
   * リターンコードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return リターンコード
   */
  public String getReturnCode() {
    return this.returnCode;
  }

  /**
   * リターンコードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param returnCode
   *          リターンコード
   */
  public void setReturnCode(String returnCode) {
    this.returnCode = returnCode;
  }

  /**
   * メッセージのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return メッセージ
   */
  public String getMessage() {
    return this.message;
  }

  /**
   * メッセージのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param message
   *          メッセージ
   */
  public void setMessage(String message) {
    this.message = message;
  }

  /**
   * 口座クレカID更新対象外フラグのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 口座クレカID更新対象外フラグを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 口座クレカID更新対象外フラグ
   */
  public String getAccountCreditCardIdNoUpdFlag() {
    return this.accountCreditCardIdNoUpdFlag;
  }

  /**
   * 口座クレカID更新対象外フラグのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 口座クレカID更新対象外フラグを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param accountCreditCardIdNoUpdFlag
   *          口座クレカID更新対象外フラグ
   */
  public void setAccountCreditCardIdNoUpdFlag(
      String accountCreditCardIdNoUpdFlag) {
    this.accountCreditCardIdNoUpdFlag = accountCreditCardIdNoUpdFlag;
  }

  /**
   * 更新回数のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 更新回数を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 更新回数
   */
  public Integer getUpdateCount() {
    return this.updateCount;
  }

  /**
   * 更新回数のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 更新回数を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param updateCount
   *          更新回数
   */
  public void setUpdateCount(Integer updateCount) {
    this.updateCount = updateCount;
  }

}
