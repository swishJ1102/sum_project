package jp.co.unisys.enability.cis.business.rk.model;

import java.util.List;

/**
 * 料金メニュー検索APIの検索結果で、供給エリアの情報を保持するビジネスクラス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_SearchRateMenuRateMenuAreaBusinessBean {

  /**
   * エリアコードを保有する。
   */
  private String areaCode;

  /**
   * エリア名称を保有する。
   */
  private String areaName;

  /**
   * 料金メニューリストを保有する。
   */
  private List<RK_SearchRateMenuRateMenuBusinessBean> rateMenuList;

  /**
   * エリアコードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * エリアコードを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return エリアコード
   */
  public String getAreaCode() {
    return this.areaCode;
  }

  /**
   * エリアコードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * エリアコードを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param areaCode
   *          エリアコード
   */
  public void setAreaCode(String areaCode) {
    this.areaCode = areaCode;
  }

  /**
   * エリア名称のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * エリア名称を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return エリア名称
   */
  public String getAreaName() {
    return this.areaName;
  }

  /**
   * エリア名称のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * エリア名称を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param areaName
   *          エリア名称
   */
  public void setAreaName(String areaName) {
    this.areaName = areaName;
  }

  /**
   * 料金メニューリストのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金メニューリストを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 料金メニューリスト
   */
  public List<RK_SearchRateMenuRateMenuBusinessBean> getRateMenuList() {
    return this.rateMenuList;
  }

  /**
   * 料金メニューリストのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金メニューリストを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param rateMenuList
   *          料金メニューリスト
   */
  public void setRateMenuList(
      List<RK_SearchRateMenuRateMenuBusinessBean> rateMenuList) {
    this.rateMenuList = rateMenuList;
  }

}
