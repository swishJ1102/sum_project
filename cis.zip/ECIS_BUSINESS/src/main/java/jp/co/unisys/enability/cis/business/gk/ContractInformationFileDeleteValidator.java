package jp.co.unisys.enability.cis.business.gk;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.springframework.context.MessageSource;

import jp.co.unisys.enability.cis.business.kj.model.ContractManagementInformationFileConfigCommon;
import jp.co.unisys.enability.cis.business.kj.model.ContractManagementInformationFileConfigContract;
import jp.co.unisys.enability.cis.common.util.CommonValidationUtil;
import jp.co.unisys.enability.cis.common.util.EMSMessageResource;

/**
 * バリデーション
 *
 * @author "Nihon Unisys, Ltd."
 */
public class ContractInformationFileDeleteValidator {

  /** プロパティクラスを定義 */
  private MessageSource messageSource;

  /**
   * メッセージプロパティキー管理のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージプロパティキー管理を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param messageSource
   *          メッセージプロパティキー管理
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }

  /**
   * のバリデーションを実施、チェック結果のメッセージListを返却する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 1 引数のバリデーションを行う。
   * 2 チェック結果がNGの場合、戻り値のメッセージListにエラーメッセージを詰めて返却する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param args
   *          バッチ引数
   * @return メッセージList
   */
  public List<String> validate(Map<Integer, String> dataRecode) {

    List<String> messageList = new ArrayList<String>();

    String dataRecordClass = dataRecode
        .get(ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_INDEX);
    // データレコード種別：必須チェック
    if (CommonValidationUtil.isNull(dataRecordClass)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_NAME },
                  Locale.getDefault()));

      // データレコード種別：正規表現チェック
    } else if (dataRecordClass != null
        && !CommonValidationUtil
            .checkByPattern(
                dataRecordClass,
                ContractManagementInformationFileConfigCommon.DATA_KIND_MASK_STRING)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_ITEM_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_NAME },
                  Locale.getDefault()));
    }

    String contractNo = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_CONTRACT_NO_INDEX);
    // 契約番号：必須チェック
    if (CommonValidationUtil.isNull(contractNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_NO_NAME },
                  Locale.getDefault()));

      // 契約番号：文字種別チェック（半角英数字）
    } else if (contractNo != null
        && !CommonValidationUtil.isAlphabetNumric(contractNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_ALPHANUMERIC_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_NO_NAME },
                  Locale.getDefault()));

      // 契約番号：文字種別チェック（半角英数字　低圧CISシステム許容文字）
    } else if (contractNo != null
        && !CommonValidationUtil.isRangeWordByECIS(contractNo)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_NO_NAME,
                      "半角英数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 契約番号：文字列最大長チェック
    } else if (contractNo != null
        && !CommonValidationUtil
            .maxLength(
                contractNo,
                ContractManagementInformationFileConfigContract.DATA_CONTRACT_NO_LENGTH)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_NO_NAME,
                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_NO_LENGTH_STRING },
                  Locale.getDefault()));
    }

    String paymentStartDate = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_APPLY_START_DATE_INDEX);
    // 適用開始日：必須チェック
    if (CommonValidationUtil.isNull(paymentStartDate)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_APPLY_START_DATE_NAME },
                  Locale.getDefault()));

      // 適用開始日：日付フォーマットチェック
    } else if (paymentStartDate != null
        && !CommonValidationUtil.checkDateFormat(paymentStartDate,
            "yyyy/MM/dd")) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_APPLY_START_DATE_NAME,
                      "日付形式（yyyy/MM/dd）" },
                  Locale.getDefault()));
    }

    String updateCount = dataRecode
        .get(ContractManagementInformationFileConfigContract.DATA_UPDATE_COUNT_INDEX);
    // 更新回数：必須チェック
    if (CommonValidationUtil.isNull(updateCount)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_UPDATE_COUNT_NAME },
                  Locale.getDefault()));
      // 更新回数：文字種別チェック（半角数字）
    } else if (updateCount != null
        && !CommonValidationUtil
            .isNumric(updateCount)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_UPDATE_COUNT_NAME,
                      "半角数字" },
                  Locale.getDefault()));

      // 更新回数：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (updateCount != null
        && !CommonValidationUtil
            .isRangeWordByECIS(updateCount)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_UPDATE_COUNT_NAME,
                      "半角数字（低圧CISシステム許容文字）" },
                  Locale.getDefault()));

      // 更新回数：数値範囲チェック
    } else if (updateCount != null
        && !CommonValidationUtil.checkRange(updateCount, 0, 2147483647)) {
      messageList
          .add(messageSource
              .getMessage(
                  EMSMessageResource.VALIDATION_RANGE_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigContract.DATA_UPDATE_COUNT_NAME,
                      "0～2147483647" },
                  Locale.getDefault()));
    }
    return messageList;
  }

}
