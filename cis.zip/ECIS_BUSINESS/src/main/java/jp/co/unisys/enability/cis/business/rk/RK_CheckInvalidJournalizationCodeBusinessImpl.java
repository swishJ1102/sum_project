package jp.co.unisys.enability.cis.business.rk;

import java.util.Properties;

import org.springframework.beans.factory.config.PropertiesFactoryBean;

import jp.co.unisys.enability.cis.business.rk.model.RK_UsageLinkageCheckCheckDataBusinessBean;
import jp.co.unisys.enability.cis.business.rk.model.RK_UsageLinkageCheckTermDecisionBusinessBean;
import jp.co.unisys.enability.cis.common.util.RK_PropertyUtil;
import jp.co.unisys.enability.cis.common.util.StringConvertUtil;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;

/**
 * 仕訳コード不正チェックビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.rk.RK_UsageLinkageCheckBusiness
 */
public class RK_CheckInvalidJournalizationCodeBusinessImpl implements
    RK_CheckFixUsageBusiness {

  /** 仕訳コード1:仕訳なし（全量） */
  private static final String TOTAL_AMOUT_CODE = "usagelinkagecheck.journalizationcode.totalAmount";

  /** 仕訳コード6:自家補別契約（常時） */
  private static final String SELF_ALWAYS_CODE = "usagelinkagecheck.journalizationcode.selfAlways";

  /** 仕訳コード7:自家補別契約（自家補） */
  private static final String SELF_TEMPORARY_CODE = "usagelinkagecheck.journalizationcode.selfTemporary";

  /** 電圧区分：低圧 */
  private static final String VOLTAGE_CATEGORY_NAME_LOW = "usagelinkagecheck.voltageCategoryName.low";

  /** 料金計算チェックビジネス(DI) */
  private RK_UsageLinkageCheckBusiness rkUsageLinkageCheckBusiness;

  /** プロパティファクトリー(DI) */
  private PropertiesFactoryBean applicationProperties;

  /**
   * 仕訳コード不正チェック。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 確定使用量メッセージの仕訳コードが“低圧”かつ“仕訳なし（全量）”以外、または、“低圧”以外かつ"自家補別契約（常時）"または"家補別契約（自家補）でないか判定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param checkDataBusinessBean
   *          チェック対象ビジネスBean
   * @param termDecisionBusinessBean
   *          期間判定情報ビジネスBean
   * @return true:処理継続、false:処理終了
   */
  @Override
  public boolean check(
      RK_UsageLinkageCheckCheckDataBusinessBean checkDataBusinessBean,
      RK_UsageLinkageCheckTermDecisionBusinessBean termDecisionBusinessBean) {

    // 継続フラグ
    boolean continuation = true;

    // Propaertiesオブジェクト取得
    Properties prop = RK_PropertyUtil.getPropertiesFactory(applicationProperties);

    // 仕訳コード1:仕訳なし（全量）
    String totalAmountCode = prop.getProperty(TOTAL_AMOUT_CODE);

    // 仕訳コード6:自家補別契約（常時）
    String selfAlwaysCode = prop.getProperty(SELF_ALWAYS_CODE);

    // 仕訳コード7:自家補別契約（自家補）
    String selfTemporaryCode = prop.getProperty(SELF_TEMPORARY_CODE);

    // 電圧区分：低圧
    String voltageCategoryNameLow = prop.getProperty(VOLTAGE_CATEGORY_NAME_LOW);

    // 仕訳コード
    String categorizeCode = checkDataBusinessBean.getCategorizeCode();

    // 電圧区分
    String voltageCategoryName = checkDataBusinessBean.getVoltageCategoryName();

    //「引数.《チェック対象ビジネスBean》.電圧区分が“低圧”、かつ、引数.《チェック対象ビジネスBean》.仕訳コードが"1:仕訳なし（全量）"以外」、または、
    //「引数.《チェック対象ビジネスBean》.電圧区分が“低圧”以外、かつ、引数.《チェック対象ビジネスBean》.仕訳コードが"6:自家補別契約（常時）"または、"7:家補別契約（自家補）」
    // の場合、TODOを登録し、【月次実績】.月次実績エラー区分コードを"エラー"で更新する
    if (voltageCategoryName.equals(voltageCategoryNameLow.trim())
        && !(categorizeCode.equals(totalAmountCode.trim()))
        || (!voltageCategoryName.equals(voltageCategoryNameLow.trim()))
            && (categorizeCode.equals(selfAlwaysCode.trim())
                || categorizeCode.equals(selfTemporaryCode.trim()))) {

      // TODOメッセージを作成するパラメータ
      Object[] params = {
          // 確定使用量ファイル名
          checkDataBusinessBean.getFixUsageFileName(),
          // 地点特定番号
          checkDataBusinessBean.getSpotNo(),
          // エリアコード
          checkDataBusinessBean.getAreaCode(),
          // 処理日
          StringConvertUtil.convertDateToString(checkDataBusinessBean.getExecuteDate(),
              ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
          // 仕訳コード
          categorizeCode,
          // 電圧区分
          checkDataBusinessBean.getVoltageCategoryName() };

      // TODO登録
      rkUsageLinkageCheckBusiness.registerTodo("todo.T1025", params, null, null, null,
          checkDataBusinessBean.getSpotNo(), null);

      // 月次実績エラー区分コードをエラーで更新
      rkUsageLinkageCheckBusiness
          .updateMonthlyUsageResultError(checkDataBusinessBean);

      // 処理を継続しない
      continuation = false;
    }

    return continuation;
  }

  /**
   * 料金計算チェックビジネスを設定します。(DI)
   *
   * @param rkUsageLinkageCheckBusiness
   *          料金計算チェックビジネス
   */
  public void setRkUsageLinkageCheckBusiness(
      RK_UsageLinkageCheckBusiness rkUsageLinkageCheckBusiness) {
    this.rkUsageLinkageCheckBusiness = rkUsageLinkageCheckBusiness;
  }

  /**
   * プロパティファクトリーを設定します。(DI)
   *
   * @param applicationProperties
   *          プロパティファクトリー
   */
  public void setApplicationProperties(
      PropertiesFactoryBean applicationProperties) {
    this.applicationProperties = applicationProperties;
  }

}
