package jp.co.unisys.enability.cis.business.rk;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.config.PropertiesFactoryBean;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.dao.DataAccessException;

import jp.co.unisys.enability.cis.business.gk.Custom_FuelCostAdjustUnitPriceInformationBusiness;
import jp.co.unisys.enability.cis.business.gk.Custom_RenewableEnergyChargeUnitPriceInformationBusiness;
import jp.co.unisys.enability.cis.business.gk.model.Custom_InquiryFuelCostAdjustUnitPriceBusinessBean;
import jp.co.unisys.enability.cis.business.gk.model.Custom_InquiryRenewableEnergyChargeUnitPriceBusinessBean;
import jp.co.unisys.enability.cis.business.kj.Custom_KJ_CustomContractorInformationBusiness;
import jp.co.unisys.enability.cis.business.kj.KJ_ContractorInformationBusiness;
import jp.co.unisys.enability.cis.business.kj.KJ_MeterLocationInformationBusiness;
import jp.co.unisys.enability.cis.business.kj.KJ_RealQuantityHistoryBusiness;
import jp.co.unisys.enability.cis.business.kj.model.Custom_InquiryCustomContractorBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.InquiryContractorBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.InquiryMeterLocationBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.RealQuantityHistoryBusinessBean;
import jp.co.unisys.enability.cis.business.rk.model.Custom_InquiryFixChargeResultDetailInformationBusinessBean;
import jp.co.unisys.enability.cis.business.rk.model.InquiryFixChargeResultBusinessBean;
import jp.co.unisys.enability.cis.common.Exception.SystemException;
import jp.co.unisys.enability.cis.common.util.KJ_CommonUtil;
import jp.co.unisys.enability.cis.common.util.RK_PropertyUtil;
import jp.co.unisys.enability.cis.common.util.StringConvertUtil;
import jp.co.unisys.enability.cis.common.util.constants.ECISCodeConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISKJConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISReturnCodeConstants;
import jp.co.unisys.enability.cis.entity.common.FcaUpM;
import jp.co.unisys.enability.cis.entity.common.RecUpM;
import jp.co.unisys.enability.cis.entity.common.Rqh;
import jp.co.unisys.enability.cis.entity.rk.RK_FixChargeResultBreakdownEntityBean;
import jp.co.unisys.enability.cis.entity.rk.RK_FixIndicationNoEntityBean;
import jp.co.unisys.enability.cis.entity.rk.RK_InquiryFixChargeResultEntityBean;
import jp.co.unisys.enability.cis.mapper.rk.Custom_InquiryFixChargeResultDetailInformationMapper;

/**
 * 確定料金実績明細情報ビジネス_カスタム
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.rk.Custom_InquiryFixChargeResultDetailInformationBusiness
 *
 *      変更履歴(kg-epj) 2016.02.05 ko 新規作成
 */
public class Custom_InquiryFixChargeResultDetailInformationBusinessImpl
    implements Custom_InquiryFixChargeResultDetailInformationBusiness {

  /**
   * 確定料金実績情報ビジネス(DI)
   */
  private RK_FixChargeResultInfomationBusiness rkFixChargeResultInfomationBusiness;

  /**
   * 契約者情報ビジネス(DI)
   */
  private KJ_ContractorInformationBusiness kjContractorInformationBusiness;

  /**
   * カスタム契約者情報ビジネス(DI)
   */
  private Custom_KJ_CustomContractorInformationBusiness customKjCustomContractorInformationBusiness;

  /**
   * メータ設置場所情報ビジネス(DI)
   */
  private KJ_MeterLocationInformationBusiness kjMeterLocationInformationBusiness;

  /**
   * 燃調単価情報ビジネス_カスタム(DI)
   */
  private Custom_FuelCostAdjustUnitPriceInformationBusiness customFuelCostAdjustUnitPriceInformationBusiness;

  /**
   * 再エネ単価情報ビジネス_カスタム(DI)
   */
  private Custom_RenewableEnergyChargeUnitPriceInformationBusiness customRenewableEnergyChargeUnitPriceInformationBusiness;

  /**
   * 確定料金実績明細情報マッパー_カスタム(DI)
   */
  private Custom_InquiryFixChargeResultDetailInformationMapper customInquiryFixChargeResultDetailInformationMapper;

  /**
   * 実量歴管理ビジネス(DI)
   */
  private KJ_RealQuantityHistoryBusiness kjRealQuantityHistoryBusiness;

  /**
   * プロパティ(DI)
   */
  private PropertiesFactoryBean applicationProperties;

  /**
   * メッセージプロパティ(DI)
   */
  private MessageSource messageSource;

  /**
   * ログマネジャー
   */
  private static Logger logger = LogManager.getLogger();

  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.business.rk.Custom_InquiryFixChargeResultDetailInformationBusiness#inquiryFixChargeResultDetail(jp.co.unisys.enability.cis.business.rk.model.Custom_InquiryFixChargeResultDetailInformationBusinessBean)
   */
  @Override
  public Custom_InquiryFixChargeResultDetailInformationBusinessBean inquiryFixChargeResultDetail(
      Custom_InquiryFixChargeResultDetailInformationBusinessBean businessBean) {

    // エラーメッセージを定義する。
    String errorMessage = null;
    // 返却用ビジネスBeanを生成する。
    Custom_InquiryFixChargeResultDetailInformationBusinessBean returnBusinessBean = new Custom_InquiryFixChargeResultDetailInformationBusinessBean();

    try {
      // 引数.契約IDを取得する。
      Integer contractId = businessBean.getContractId();
      // 引数.契約番号を取得する。
      String contractNo = businessBean.getContractNo();
      // 引数.利用年月を取得する。
      String usePeriod = businessBean.getUsePeriod();
      // プロパティを取得する
      Properties prop = applicationProperties.getObject();

      // リターンコード(G017)に対応するメッセージを取得する。
      errorMessage = messageSource.getMessage(KJ_CommonUtil.getMessageId(
          ECISReturnCodeConstants.RETURN_CODE_G017), new String[] {},
          Locale.getDefault());

      // パラメータチェック
      // 引数.利用年月がNULLまたは空文字、または引数.契約IDと引数.契約番号の両方がNULLの場合、以下の処理を行う。
      if (StringUtils.isEmpty(usePeriod) || (contractId == null && StringUtils.isEmpty(contractNo))) {
        // リターンコード（P001）と対応するメッセージを設定し、返却する。
        returnBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P001);
        returnBusinessBean.setMessage(messageSource.getMessage(
            KJ_CommonUtil.getMessageId(ECISReturnCodeConstants.RETURN_CODE_P001),
            new String[] {}, Locale.getDefault()));

        return returnBusinessBean;
      }

      // 確定料金実績明細情報取得
      // 《確定料金実績照会BusinessBean》を生成し、以下の引数を設定する。
      InquiryFixChargeResultBusinessBean inqFixChaBusBean = new InquiryFixChargeResultBusinessBean();
      // 引数.契約IDを設定する。
      inqFixChaBusBean.setContractId(contractId);
      // 引数.契約番号を設定する。
      inqFixChaBusBean.setContractNo(contractNo);
      // 引数.利用年月をご利用年月FROMに設定する。
      inqFixChaBusBean.setUsePeriodFrom(usePeriod);

      // 確定料金実績情報ビジネス.照会呼び出し
      InquiryFixChargeResultBusinessBean reFixChaBusBean = rkFixChargeResultInfomationBusiness
          .inquiry(inqFixChaBusBean);

      // 照会結果判定
      // リターンコードが正常終了（0000）でない場合、以下の処理を行う。
      if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(reFixChaBusBean.getReturnCode())) {
        // リターンコード(GC001)と対応するメッセージを設定する。
        returnBusinessBean.setReturnCode(ECISReturnCodeConstants.CUSTOM_RETURN_CODE_GC001);
        returnBusinessBean.setMessage(messageSource.getMessage(
            KJ_CommonUtil.getMessageId(ECISReturnCodeConstants.CUSTOM_RETURN_CODE_GC001),
            new String[] {prop.getProperty("custom.message.str.inquiryfixchargeresult"),
                reFixChaBusBean.getMessage() },
            Locale.getDefault()));

        return returnBusinessBean;
      }

      // 《確定料金実績情報照会BusinessBean》.確定料金実績情報リストを取得し、変数.確定料金実績情報リストに設定する。
      List<RK_InquiryFixChargeResultEntityBean> fixChargeResultList = reFixChaBusBean.getFixChargeResultList();

      // リターンコードが正常終了（0000）かつ、返却値が0件の場合、以下の処理を行う。
      if (CollectionUtils.isEmpty(fixChargeResultList)) {
        // リターンコード(GC001)と対応するメッセージを設定する。
        returnBusinessBean.setReturnCode(ECISReturnCodeConstants.CUSTOM_RETURN_CODE_GC001);
        // メッセージ(error.E0016)を取得する。
        String messageE0016 = messageSource.getMessage("error.E0016",
            new String[] {prop.getProperty("message.str.fixchargeresult") },
            Locale.getDefault());
        returnBusinessBean.setMessage(messageSource.getMessage(
            KJ_CommonUtil.getMessageId(ECISReturnCodeConstants.CUSTOM_RETURN_CODE_GC001),
            new String[] {prop.getProperty("custom.message.str.inquiryfixchargeresult"), messageE0016 },
            Locale.getDefault()));

        return returnBusinessBean;
      }

      // 《確定料金実績照会BusinessBean》.確定料金実績情報リストの1件目を取得し、変数.確定料金実績情報に設定する。
      RK_InquiryFixChargeResultEntityBean fixChargeResultEntityBean = fixChargeResultList.get(0);
      // 変数.確定料金実績情報.確定指示数リストを取得し、変数.確定指示数リストに設定する。
      List<RK_FixIndicationNoEntityBean> fixIndicationNoList = fixChargeResultEntityBean.getFixIndicationNoList();

      // 契約番号でビジネスを実行した場合を考慮し
      // 確定料金実績情報から契約IDを再設定する
      contractId = fixChargeResultEntityBean.getContractId();

      // 変数.確定指示数リストが空の場合、以下の処理を行う。
      if (CollectionUtils.isEmpty(fixIndicationNoList)) {
        // NullPointerException発生を防ぐため、変数.確定指示数リストを生成する。
        fixIndicationNoList = new ArrayList<RK_FixIndicationNoEntityBean>();
      }

      // 変数.編集用確定指示数リストを生成する。
      List<RK_FixIndicationNoEntityBean> fixIndicationNoNewList = new ArrayList<RK_FixIndicationNoEntityBean>();
      // 変数.確定指示数リストの件数分、以下の処理を行う。
      for (RK_FixIndicationNoEntityBean fixEntityBean : fixIndicationNoList) {
        // 確定指示数.計器区分コードが常用でない場合、次のレコードの処理を行う。
        if (!ECISCodeConstants.METER_CATEGORY_CODE_FOR_IN_COMMON.equals(fixEntityBean.getMeterCategoryCode())) {
          continue;
        }
        // 取得した確定指示数を変数.編集用確定指示数リストに追加する。
        fixIndicationNoNewList.add(fixEntityBean);
        // ブレークする。
        break;
      }

      // 変数.編集用確定指示数リストをチェックし、空の場合、以下の処理を行う。
      if (CollectionUtils.isEmpty(fixIndicationNoNewList)) {
        // リターンコード(GC001)と対応するメッセージを設定する。
        returnBusinessBean.setReturnCode(ECISReturnCodeConstants.CUSTOM_RETURN_CODE_GC001);
        String messageE0016 = messageSource.getMessage("error.E0016",
            new String[] {prop.getProperty("custom.message.str.fixindicationno") },
            Locale.getDefault());
        returnBusinessBean.setMessage(messageSource.getMessage(
            KJ_CommonUtil.getMessageId(ECISReturnCodeConstants.CUSTOM_RETURN_CODE_GC001),
            new String[] {prop.getProperty("custom.message.str.inquiryfixchargeresult"), messageE0016 },
            Locale.getDefault()));

        return returnBusinessBean;

        // 空でない場合、変数.編集用確定指示数リストを変数.確定料金実績情報.確定指示数リストに設定する。
      } else {
        fixChargeResultEntityBean.setFixIndicationNoList(fixIndicationNoNewList);
      }

      // 変数.最低月額料金表示順をInteger.最低値で初期化する。
      Integer minDisplayOrder = Integer.MIN_VALUE;
      // 変数.確定料金実績情報.確定料金実績内訳EntityBeanリストを取得し、変数.確定料金実績内訳EntityBeanリストに設定する。
      List<RK_FixChargeResultBreakdownEntityBean> fixChargeResultBreakdownList = fixChargeResultEntityBean
          .getFixChargeResultBreakdownList();
      // 変数.確定料金実績内訳EntityBeanリストの件数分、以下の処理を行う。
      for (RK_FixChargeResultBreakdownEntityBean fixEntityBean : fixChargeResultBreakdownList) {
        // 確定料金実績内訳EntityBean.内訳区分コードが最低月額料金の場合、以下の処理を行う。
        if (ECISCodeConstants.FCR_BREAKDOWN_CATEGORY_CODE_MINIMUM_MONTHLY_CHARGE
            .equals(fixEntityBean.getFixChargeResultBreakdownCategoryCode())) {
          // 変数.最低月額料金表示順に確定料金実績内訳EntityBean.表示順を設定する。
          minDisplayOrder = fixEntityBean.getDisplayOrder();
          // ブレークする。
          break;
        }
      }

      // 変数.確定料金実績内訳リストを新規作成する。
      List<RK_FixChargeResultBreakdownEntityBean> fixChargeResultBreakdownNewList = new ArrayList<RK_FixChargeResultBreakdownEntityBean>();
      // 変数.確定料金実績内訳EntityBeanリストの件数分、以下の処理を行う。
      for (RK_FixChargeResultBreakdownEntityBean fixEntityBean : fixChargeResultBreakdownList) {
        // 確定料金実績内訳EntityBean.表示順が変数.最低月額料金表示順未満の場合、次のレコードの処理を行う。
        if (minDisplayOrder.compareTo(fixEntityBean.getDisplayOrder()) > 0) {
          continue;
        }

        // 変数.確定料金実績内訳リストに 確定料金実績内訳EntityBeanを追加する。
        fixChargeResultBreakdownNewList.add(fixEntityBean);
      }
      // 変数.確定料金実績情報.確定料金実績内訳EntityBeanリストに 変数.確定料金実績内訳リストを再設定する。
      fixChargeResultEntityBean.setFixChargeResultBreakdownList(fixChargeResultBreakdownNewList);

      // 契約者情報取得
      // 《契約者情報照会BusinessBean》を生成し、以下の引数を設定する。
      InquiryContractorBusinessBean inqContractorBusBean = new InquiryContractorBusinessBean();
      // 契約者IDを設定する。
      inqContractorBusBean.setContractorId(fixChargeResultEntityBean.getContractorId());
      // 契約者情報ビジネス.照会呼び出し
      InquiryContractorBusinessBean reContractorBusBean = kjContractorInformationBusiness
          .inquiry(inqContractorBusBean);

      // 照会結果判定
      // リターンコードが正常終了（0000）でない場合、以下の処理を行う。
      if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(reContractorBusBean.getReturnCode())) {
        // リターンコード(GC001)と対応するメッセージを設定する。
        returnBusinessBean.setReturnCode(ECISReturnCodeConstants.CUSTOM_RETURN_CODE_GC001);
        returnBusinessBean.setMessage(messageSource.getMessage(
            KJ_CommonUtil.getMessageId(ECISReturnCodeConstants.CUSTOM_RETURN_CODE_GC001),
            new String[] {prop.getProperty("custom.message.str.inquirycontractor"),
                reContractorBusBean.getMessage() },
            Locale.getDefault()));

        return returnBusinessBean;
      }

      // リターンコードが正常終了（0000）かつ、返却値が0件の場合、以下の処理を行う。
      if (CollectionUtils.isEmpty(reContractorBusBean.getContractorInformationList())) {
        // リターンコード(GC001)と対応するメッセージを設定する。
        returnBusinessBean.setReturnCode(ECISReturnCodeConstants.CUSTOM_RETURN_CODE_GC001);
        String messageE0016 = messageSource.getMessage("error.E0016",
            new String[] {prop.getProperty("check.target.contractor") }, Locale.getDefault());
        returnBusinessBean.setMessage(messageSource.getMessage(
            KJ_CommonUtil.getMessageId(ECISReturnCodeConstants.CUSTOM_RETURN_CODE_GC001),
            new String[] {prop.getProperty("custom.message.str.inquirycontractor"), messageE0016 },
            Locale.getDefault()));

        return returnBusinessBean;
      }

      // カスタム契約者情報取得
      // 《カスタム契約者情報照会BusinessBean》を生成し、以下の引数を設定する。
      Custom_InquiryCustomContractorBusinessBean inqCusConBusBean = new Custom_InquiryCustomContractorBusinessBean();
      // 契約者IDを設定する。
      inqCusConBusBean.setContractorId(fixChargeResultEntityBean.getContractorId());
      // カスタム契約者情報ビジネス.照会呼び出し
      Custom_InquiryCustomContractorBusinessBean reCusConBusBean = customKjCustomContractorInformationBusiness
          .inquiry(inqCusConBusBean);

      // 照会結果判定
      // リターンコードが正常終了（0000）でない場合、以下の処理を行う。
      if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(reCusConBusBean.getReturnCode())) {
        // リターンコード(GC001)と対応するメッセージを設定する。
        returnBusinessBean.setReturnCode(ECISReturnCodeConstants.CUSTOM_RETURN_CODE_GC001);
        returnBusinessBean.setMessage(messageSource.getMessage(
            KJ_CommonUtil.getMessageId(ECISReturnCodeConstants.CUSTOM_RETURN_CODE_GC001),
            new String[] {prop.getProperty("custom.message.str.inquirycustomcontractor"),
                reCusConBusBean.getMessage() },
            Locale.getDefault()));

        return returnBusinessBean;
      }

      // リターンコードが正常終了（0000）かつ、返却値が0件の場合、以下の処理を行う。
      if (CollectionUtils.isEmpty(reCusConBusBean.getCustomContractorInformationList())) {
        // リターンコード(GC001)と対応するメッセージを設定する。
        returnBusinessBean.setReturnCode(ECISReturnCodeConstants.CUSTOM_RETURN_CODE_GC001);
        String messageE0016 = messageSource.getMessage("error.E0016",
            new String[] {prop.getProperty("custom.check.target.custom.contractor") },
            Locale.getDefault());
        returnBusinessBean.setMessage(messageSource.getMessage(
            KJ_CommonUtil.getMessageId(ECISReturnCodeConstants.CUSTOM_RETURN_CODE_GC001),
            new String[] {prop.getProperty("custom.message.str.inquirycustomcontractor"), messageE0016 },
            Locale.getDefault()));

        return returnBusinessBean;
      }

      // メータ設置場所情報取得
      // 《メータ設置場所照会BusinessBean》を生成し、以下の引数を設定する。
      InquiryMeterLocationBusinessBean inqMeterBusBean = new InquiryMeterLocationBusinessBean();
      // メータ設置場所IDを設定する。
      inqMeterBusBean.setMeterLocationId(fixChargeResultEntityBean.getMeterLocationId());
      // メータ設置場所ビジネス.照会呼び出し
      InquiryMeterLocationBusinessBean reMeterBusBean = kjMeterLocationInformationBusiness
          .inquiry(inqMeterBusBean);

      // 照会結果判定
      // リターンコードが正常終了（0000）でない場合、以下の処理を行う。
      if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(reMeterBusBean.getReturnCode())) {
        // リターンコード(GC001)と対応するメッセージを設定する。
        returnBusinessBean.setReturnCode(ECISReturnCodeConstants.CUSTOM_RETURN_CODE_GC001);
        returnBusinessBean.setMessage(messageSource.getMessage(
            KJ_CommonUtil.getMessageId(ECISReturnCodeConstants.CUSTOM_RETURN_CODE_GC001),
            new String[] {prop.getProperty("custom.message.str.inquiryml"), reMeterBusBean.getMessage() },
            Locale.getDefault()));

        return returnBusinessBean;
      }

      // リターンコードが正常終了（0000）かつ、返却値が0件の場合、以下の処理を行う。
      if (CollectionUtils.isEmpty(reMeterBusBean.getMeterLocationList())) {
        // リターンコード(GC001)と対応するメッセージを設定する。
        returnBusinessBean.setReturnCode(ECISReturnCodeConstants.CUSTOM_RETURN_CODE_GC001);
        String messageE0016 = messageSource.getMessage("error.E0016",
            new String[] {prop.getProperty("check.target.ml") },
            Locale.getDefault());
        returnBusinessBean.setMessage(messageSource.getMessage(
            KJ_CommonUtil.getMessageId(ECISReturnCodeConstants.CUSTOM_RETURN_CODE_GC001),
            new String[] {prop.getProperty("custom.message.str.inquiryml"), messageE0016 },
            Locale.getDefault()));

        return returnBusinessBean;
      }

      // 契約解約情報判定
      // 変数.契約解約フラグをfalseで初期化する。
      boolean contractCancelFlag = false;
      // 変数.確定料金実績情報.検針理由コードが 廃止 または 解約 の場合、以下の処理を行う。
      if (ECISCodeConstants.METER_READING_REASON_CODE_ABOLITION
          .equals(fixChargeResultEntityBean.getMeterReadingReasonCode())
          || ECISCodeConstants.METER_READING_REASON_CODE_CANCELLATION
              .equals(fixChargeResultEntityBean.getMeterReadingReasonCode())) {
        // 変数.契約解約フラグにtrueを設定する。
        contractCancelFlag = true;
      }

      // 燃調単価情報取得
      // 変数.確定料金実績情報.エリアコードを取得する。
      String areaCode = fixChargeResultEntityBean.getAreaCode();
      // 変数.確定料金実績情報.料金算定開始日を取得する。
      Date chargeCalculationStartDate = fixChargeResultEntityBean.getChargeCalculationStartDate();
      // 変数.確定料金実績情報.料金算定終了日 + 1日を取得し、変数.料金算定終了日の翌日に設定する。
      Date nextChargeCalculationEndDate = DateUtils
          .addDays(fixChargeResultEntityBean.getChargeCalculationEndDate(), 1);

      // 《燃調単価情報BusinessBean_カスタム》を生成し、以下の引数を設定する。
      Custom_InquiryFuelCostAdjustUnitPriceBusinessBean inqCustomFcaUpBusBean = new Custom_InquiryFuelCostAdjustUnitPriceBusinessBean();
      // エリアコードを設定する
      inqCustomFcaUpBusBean.setAreaCode(areaCode);
      // 契約IDを設定する
      inqCustomFcaUpBusBean.setContractId(contractId);
      // 変数.取得対象日リストを生成し、料金算定開始日と料金算定終了日の翌日を追加する。
      List<Date> targetDateList = new ArrayList<Date>();
      // 変数.料金算定開始日を追加する。
      targetDateList.add(chargeCalculationStartDate);

      if (contractCancelFlag == false) {
        // 変数.契約解約フラグがfalseである場合、変数.料金算定終了日の翌日を追加する。
        targetDateList.add(nextChargeCalculationEndDate);
      }

      // 変数.取得対象日リストを《燃調単価情報BusinessBean_カスタム》.取得対象日リストに設定する。
      inqCustomFcaUpBusBean.setTargetDateList(targetDateList);

      Custom_InquiryFuelCostAdjustUnitPriceBusinessBean reCustomFcaUpBusBean = new Custom_InquiryFuelCostAdjustUnitPriceBusinessBean();

      // プロパティ.燃調単価取得方法区分を取得
      String fcaGetWayCat = RK_PropertyUtil.getProperty(applicationProperties, "fuelcostadjust.get.way.category");
      // 変数.燃調単価取得方法区分を《燃調単価情報BusinessBean_カスタム》.燃調単価取得方法区分に設定する。
      inqCustomFcaUpBusBean.setFcaUpGetWayCategory(fcaGetWayCat);

      // 確定料金実績情報.利用年月を取得し、変数.利用年月に設定する。
      String currentUsePeriod = fixChargeResultEntityBean.getUsePeriod();
      // 変数.利用年月の翌月を取得する。
      Date nextUsePeriodDate = DateUtils.addMonths(
          StringConvertUtil.stringToDate(currentUsePeriod, ECISConstants.FORMAT_DATE_yyyyMM), 1);
      String nextUsePeriod = StringConvertUtil.convertDateToString(nextUsePeriodDate,
          ECISConstants.FORMAT_DATE_yyyyMM);

      // 燃調単価取得方法区分 = ”算定期間開始日”の場合
      if (ECISRKConstants.FUEL_COST_ADJUST_GET_WAY_CAT_CALC_PERIOD_START.equals(fcaGetWayCat)) {
        // 燃調単価情報ビジネス_カスタム.照会呼び出し
        reCustomFcaUpBusBean = customFuelCostAdjustUnitPriceInformationBusiness
            .inquiryFuelCostAdjustUnitPrice(inqCustomFcaUpBusBean);
      }
      // 燃調単価取得方法区分 = ”利用年月”の場合
      else {
        // 利用年月マップを作成
        Map<Date, String> usePeriodMap = new HashMap<Date, String>();
        // 当月を設定
        usePeriodMap.put(chargeCalculationStartDate, currentUsePeriod);

        if (contractCancelFlag == false) {
          // 変数.契約解約フラグがfalseである場合、翌月を設定
          usePeriodMap.put(nextChargeCalculationEndDate, nextUsePeriod);
        }

        // 利用年月マップを《燃調単価情報BusinessBean_カスタム》.利用年月マップに設定する。
        inqCustomFcaUpBusBean.setUsePeriodMap(usePeriodMap);

        // 燃調単価情報ビジネス_カスタム.照会呼び出し
        reCustomFcaUpBusBean = customFuelCostAdjustUnitPriceInformationBusiness
            .inquiryFuelCostAdjustUnitPrice(inqCustomFcaUpBusBean);
      }

      // 照会結果判定
      // リターンコードが正常終了（0000）でない場合、以下の処理を行う。
      if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(reCustomFcaUpBusBean.getReturnCode())) {
        // リターンコード(GC001)と対応するメッセージを設定する。
        returnBusinessBean.setReturnCode(ECISReturnCodeConstants.CUSTOM_RETURN_CODE_GC001);
        returnBusinessBean.setMessage(messageSource.getMessage(
            KJ_CommonUtil.getMessageId(ECISReturnCodeConstants.CUSTOM_RETURN_CODE_GC001),
            new String[] {prop.getProperty("custom.message.str.fuelcostadjustunitpriceinfo"),
                reCustomFcaUpBusBean.getMessage() },
            Locale.getDefault()));

        return returnBusinessBean;
      }

      // 《燃調単価情報BusinessBean_カスタム》.対象日付単価情報マップを取得する。
      Map<Date, Map<String, FcaUpM>> dateUpMap = reCustomFcaUpBusBean.getDateUpMap();
      // 変数.確定料金実績情報.料金算定開始日をキーに、当月の燃調単価EntityMapを取得する。
      FcaUpM currentFcaUpM = dateUpMap.get(chargeCalculationStartDate).get(areaCode);
      // 当月燃調単価情報が取得できない場合、以下の処理を行う。
      if (currentFcaUpM == null) {
        // リターンコード(GC001)と対応するメッセージを設定する。
        returnBusinessBean.setReturnCode(ECISReturnCodeConstants.CUSTOM_RETURN_CODE_GC001);
        String messageE0016 = messageSource.getMessage("error.E0016",
            new String[] {prop.getProperty("custom.message.str.currentfuelcostunitprice") },
            Locale.getDefault());
        returnBusinessBean.setMessage(messageSource.getMessage(
            KJ_CommonUtil.getMessageId(ECISReturnCodeConstants.CUSTOM_RETURN_CODE_GC001),
            new String[] {prop.getProperty("custom.message.str.fuelcostadjustunitpriceinfo"),
                messageE0016 },
            Locale.getDefault()));

        return returnBusinessBean;
      }

      // 当月燃調単価を取得する。
      BigDecimal currentFuelCostUnitPrice = currentFcaUpM.getUp();
      // 変数.翌月燃調単価を定義する。
      BigDecimal nextFuelCostUnitPrice = null;
      // 変数.燃調単価差額を定義する。
      BigDecimal diffFuelCostUnitPrice = null;

      // 変数.契約解約フラグがfalseの場合、翌月燃調単価と燃調単価差額を取得する。
      if (!contractCancelFlag) {
        // 変数.料金算定終了日の翌日をキーに、翌月の燃調単価Entityを取得する。
        FcaUpM nextFcaUpM = dateUpMap.get(nextChargeCalculationEndDate).get(areaCode);
        // 翌月の燃調単価Entityがnullでない場合、以下の処理を行う。
        if (nextFcaUpM != null) {
          // 翌月燃調単価を取得する。
          nextFuelCostUnitPrice = nextFcaUpM.getUp();
          // 変数.翌月燃調単価 - 変数.当月燃調単価を、変数.燃調単価差額に設定する。
          diffFuelCostUnitPrice = nextFuelCostUnitPrice.subtract(currentFuelCostUnitPrice);
        }
      }

      // 再エネ単価情報取得
      // 《再エネ単価情報BusinessBean_カスタム》を生成し、以下の引数を設定する。
      Custom_InquiryRenewableEnergyChargeUnitPriceBusinessBean inqCustomRecUpBusBean = new Custom_InquiryRenewableEnergyChargeUnitPriceBusinessBean();
      // エリアコードを設定する。
      inqCustomRecUpBusBean.setAreaCode(areaCode);
      // 取得対象年月リストを生成し、確定料金実績情報.利用年月と利用年月の翌月を追加する。
      List<String> targetPeriodList = new ArrayList<String>();
      // 変数.利用年月を追加する。
      targetPeriodList.add(currentUsePeriod);

      if (contractCancelFlag == false) {
        // 変数.契約解約フラグがfalseである場合、変数.利用年月の翌月を追加する。
        targetPeriodList.add(nextUsePeriod);
      }

      // 取得対象年月リストを《再エネ単価情報BusinessBean_カスタム》.取得対象年月リストに設定する。
      inqCustomRecUpBusBean.setTargetPeriodList(targetPeriodList);

      // 再エネ単価情報ビジネス_カスタム.照会呼び出し
      Custom_InquiryRenewableEnergyChargeUnitPriceBusinessBean reCustomRecUpBusBean = customRenewableEnergyChargeUnitPriceInformationBusiness
          .inquiryRenewableEnergyChargeUnitPrice(inqCustomRecUpBusBean);

      // 照会結果判定
      // リターンコードが正常終了（0000）でない場合、以下の処理を行う。
      if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(reCustomRecUpBusBean.getReturnCode())) {
        // リターンコード(GC001)と対応するメッセージを設定する。
        returnBusinessBean.setReturnCode(ECISReturnCodeConstants.CUSTOM_RETURN_CODE_GC001);
        returnBusinessBean.setMessage(messageSource.getMessage(
            KJ_CommonUtil.getMessageId(ECISReturnCodeConstants.CUSTOM_RETURN_CODE_GC001),
            new String[] {prop.getProperty("custom.message.str.renewableenergychargeunitpriceinfo"),
                reCustomRecUpBusBean.getMessage() },
            Locale.getDefault()));

        return returnBusinessBean;
      }

      // 《再エネ単価情報BusinessBean_カスタム》.年月単価情報マップを取得する。
      Map<String, Map<String, RecUpM>> periodUpMap = reCustomRecUpBusBean.getPeriodUpMap();
      // 変数.利用年月をキーに、当月再エネ単価Entityを取得する。
      RecUpM currentRecUpM = periodUpMap.get(currentUsePeriod).get(areaCode);
      // 当月再エネ単価情報が取得できない場合、以下の処理を行う。
      if (currentRecUpM == null) {
        // リターンコード(GC001)と対応するメッセージを設定する。
        returnBusinessBean.setReturnCode(ECISReturnCodeConstants.CUSTOM_RETURN_CODE_GC001);
        String messageE0016 = messageSource.getMessage("error.E0016",
            new String[] {prop.getProperty("custom.message.str.currentrenewableenergyunitprice") },
            Locale.getDefault());
        returnBusinessBean.setMessage(messageSource.getMessage(
            KJ_CommonUtil.getMessageId(ECISReturnCodeConstants.CUSTOM_RETURN_CODE_GC001), new String[] {
                prop.getProperty("custom.message.str.renewableenergychargeunitpriceinfo"),
                messageE0016 },
            Locale.getDefault()));

        return returnBusinessBean;
      }

      // 当月再エネ単価を取得する。
      BigDecimal currentRenewableEnergyUnitPrice = currentRecUpM.getUp();
      // 翌月再エネ単価を定義する。
      BigDecimal nextRenewableEnergyUnitPrice = null;

      // 変数.契約解約フラグがfalseの場合、翌月再エネ単価情報を取得する。
      if (!contractCancelFlag) {
        // 変数.利用年月の翌月をキーに、翌月再エネ単価Enitityを取得する。
        RecUpM nextRecUpM = periodUpMap.get(nextUsePeriod).get(areaCode);
        // 翌月再エネ単価Enitityがnullでない場合、翌月再エネ単価を取得する。
        if (nextRecUpM != null) {
          nextRenewableEnergyUnitPrice = nextRecUpM.getUp();
        }
      }

      // 実量歴管理情報取得
      // 《実量歴管理ビジネスBusinessBean》を生成し、以下の引数を設定する。
      RealQuantityHistoryBusinessBean rqhBusinessBean = new RealQuantityHistoryBusinessBean();
      // 契約IDを設定する。
      rqhBusinessBean.setContractId(contractId);
      // 対象年月を設定する。
      rqhBusinessBean.setCoveredPeriod(currentUsePeriod);
      // 実量歴管理ビジネス.照会呼び出し
      RealQuantityHistoryBusinessBean resRqhBusinessBean = kjRealQuantityHistoryBusiness
          .inquiry(rqhBusinessBean);
      // 実量暦管理情報リスト
      List<Rqh> realQuantityHistoryInformation = new ArrayList<Rqh>();
      // 基準年月
      String baseDate = currentUsePeriod;
      // 《実量歴管理BusinessBean》.実量歴管理リストサイズ
      int size = resRqhBusinessBean.getRealQuantityHistoryList().size();
      // リストサイズが12になるまで下記処理を繰り返す。
      for (int i = 0; i < 12; i++) {
        // 実量暦管理EntityBeanのインスタンスを生成する。
        Rqh rqh = new Rqh();
        if (i < size) {
          // 実量暦管理EntityBeanに《実量歴管理BusinessBean》.実量歴管理リストを追加する。
          rqh = resRqhBusinessBean.getRealQuantityHistoryList().get(i);
        } else {
          // リストサイズ < 12の場合
          // 対象年月に基準年月 - リストサイズを設定する。
          rqh.setCoveredPeriod(StringConvertUtil.calcMonth(baseDate, -size, ECISConstants.FORMAT_DATE_yyyyMM));
          // 最大電力にnullを設定する。
          rqh.setPkw(null);
          size++;
        }
        // 実量暦管理情報リストに実量暦管理EntityBeanを設定する。
        realQuantityHistoryInformation.add(rqh);
      }
      // 《実量歴管理BusinessBean》.実量歴管理リストに実量暦管理情報リストを設定する。
      resRqhBusinessBean.setRealQuantityHistoryList(realQuantityHistoryInformation);

      // 戻り値の設定
      // 戻り値.確定料金実績情報を設定する。
      returnBusinessBean.setFixChargeResultInformation(fixChargeResultEntityBean);
      // 契約者情報を設定する
      returnBusinessBean.setContractorInformation(reContractorBusBean.getContractorInformationList().get(0));
      // カスタム契約者情報を設定する。
      returnBusinessBean
          .setCustomContractorInformation(reCusConBusBean.getCustomContractorInformationList().get(0));
      // メータ設置場所情報
      returnBusinessBean.setMeterLocationInformation(reMeterBusBean.getMeterLocationList().get(0));
      // 当月燃調単価
      returnBusinessBean.setCurrentFuelCostUnitPrice(currentFuelCostUnitPrice);
      // 翌月燃調単価
      returnBusinessBean.setNextFuelCostUnitPrice(nextFuelCostUnitPrice);
      // 燃調単価差額
      returnBusinessBean.setDiffFuelCostUnitPrice(diffFuelCostUnitPrice);
      // 当月再エネ単価
      returnBusinessBean.setCurrentRenewableEnergyUnitPrice(currentRenewableEnergyUnitPrice);
      // 翌月再エネ単価
      returnBusinessBean.setNextRenewableEnergyUnitPrice(nextRenewableEnergyUnitPrice);
      // 実量歴管理情報
      returnBusinessBean.setRealQuantityHistoryInformation(resRqhBusinessBean);

      // リターンコード(0000)を設定する
      returnBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);

    } catch (NoSuchMessageException e) {
      // メッセージ検索例外が発生した場合、以下の処理を行う。
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, e);
      returnBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      returnBusinessBean.setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);

    } catch (DataAccessException | IOException e) {
      // データアクセスエラーが発生した場合、以下の処理を行う。
      logger.error(errorMessage, e);
      returnBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      returnBusinessBean.setMessage(errorMessage);
    } catch (ParseException e) {
      throw new SystemException(messageSource.getMessage("error.E1294", null, Locale.getDefault()), e);
    }

    return returnBusinessBean;
  }

  /**
   * 条件をもとに、年間最大需要電力を取得する。
   *
   * @param contractId
   *          契約ID
   * @param usePeriod
   *          利用年月
   * @return 年間最大需要電力
   */
  private Integer selectYearPeakDemand(Integer contractId, String usePeriod) {
    // 引数.利用年月 - 11月を取得し、変数.利用年月(始)を設定する。
    Calendar calendar = Calendar.getInstance();
    calendar.setTime(StringConvertUtil.stringToDate(usePeriod, ECISConstants.FORMAT_DATE_yyyyMM));
    calendar.add(Calendar.MONTH, -11);
    String usePeriodStart = StringConvertUtil.convertDateToString(calendar.getTime(),
        ECISConstants.FORMAT_DATE_yyyyMM);

    // 条件Mapを生成し、以下の検索条件を設定する。
    Map<String, Object> exampleMap = new HashMap<String, Object>();
    // 契約IDを設定する。
    exampleMap.put("contractId", contractId);
    // 利用年月(始)を設定する
    exampleMap.put("usePeriodStart", usePeriodStart);
    // 利用年月を設定する
    exampleMap.put("usePeriod", usePeriod);

    // 確定料金実績明細情報Mapper_カスタム.年間最大需要電力取得を呼び出し、取得した年間最大需要電力を返却する。
    return customInquiryFixChargeResultDetailInformationMapper.selectYearPeakDemand(exampleMap);
  }

  /**
   * 確定料金実績情報ビジネスのセッター(DI)
   *
   * @param rkFixChargeResultInfomationBusiness
   *          確定料金実績情報ビジネス
   */
  public void setRkFixChargeResultInfomationBusiness(
      RK_FixChargeResultInfomationBusiness rkFixChargeResultInfomationBusiness) {
    this.rkFixChargeResultInfomationBusiness = rkFixChargeResultInfomationBusiness;
  }

  /**
   * 契約者情報ビジネスのセッター(DI)
   *
   * @param kjContractorInformationBusiness
   *          契約者情報ビジネス
   */
  public void setKjContractorInformationBusiness(KJ_ContractorInformationBusiness kjContractorInformationBusiness) {
    this.kjContractorInformationBusiness = kjContractorInformationBusiness;
  }

  /**
   * カスタム契約者情報ビジネスのセッター(DI)
   *
   * @param customKjCustomContractorInformationBusiness
   *          カスタム契約者情報ビジネス
   */
  public void setCustomKjCustomContractorInformationBusiness(
      Custom_KJ_CustomContractorInformationBusiness customKjCustomContractorInformationBusiness) {
    this.customKjCustomContractorInformationBusiness = customKjCustomContractorInformationBusiness;
  }

  /**
   * メータ設置場所情報ビジネスのセッター(DI)
   *
   * @param kjMeterLocationInformationBusiness
   *          メータ設置場所情報ビジネス
   */
  public void setKjMeterLocationInformationBusiness(
      KJ_MeterLocationInformationBusiness kjMeterLocationInformationBusiness) {
    this.kjMeterLocationInformationBusiness = kjMeterLocationInformationBusiness;
  }

  /**
   * 燃調単価情報ビジネス_カスタムのセッター(DI)
   *
   * @param customFuelCostAdjustUnitPriceInformationBusiness
   *          燃調単価情報ビジネス_カスタム
   */
  public void setCustomFuelCostAdjustUnitPriceInformationBusiness(
      Custom_FuelCostAdjustUnitPriceInformationBusiness customFuelCostAdjustUnitPriceInformationBusiness) {
    this.customFuelCostAdjustUnitPriceInformationBusiness = customFuelCostAdjustUnitPriceInformationBusiness;
  }

  /**
   * 再エネ単価情報ビジネス_カスタムのセッター(DI)
   *
   * @param customRenewableEnergyChargeUnitPriceInformationBusiness
   *          再エネ単価情報ビジネス_カスタム
   */
  public void setCustomRenewableEnergyChargeUnitPriceInformationBusiness(
      Custom_RenewableEnergyChargeUnitPriceInformationBusiness customRenewableEnergyChargeUnitPriceInformationBusiness) {
    this.customRenewableEnergyChargeUnitPriceInformationBusiness = customRenewableEnergyChargeUnitPriceInformationBusiness;
  }

  /**
   * 確定料金実績明細情報マッパー_カスタムのセッター(DI)
   *
   * @param customInquiryFixChargeResultDetailInformationMapper
   *          確定料金実績明細情報マッパー_カスタム
   */
  public void setCustomInquiryFixChargeResultDetailInformationMapper(
      Custom_InquiryFixChargeResultDetailInformationMapper customInquiryFixChargeResultDetailInformationMapper) {
    this.customInquiryFixChargeResultDetailInformationMapper = customInquiryFixChargeResultDetailInformationMapper;
  }

  /**
   * 実量歴管理ビジネスのセッター(DI)
   *
   * @param kjRealQuantityHistoryBusiness
   *          実量歴管理ビジネス
   */
  public void setkjRealQuantityHistoryBusiness(
      KJ_RealQuantityHistoryBusiness kjRealQuantityHistoryBusiness) {
    this.kjRealQuantityHistoryBusiness = kjRealQuantityHistoryBusiness;
  }

  /**
   * プロパティのセッター(DI)
   *
   * @param applicationProperties
   *          プロパティ
   */
  public void setApplicationProperties(PropertiesFactoryBean applicationProperties) {
    this.applicationProperties = applicationProperties;
  }

  /**
   * メッセージプロパティのセッター(DI)
   *
   * @param messageSource
   *          メッセージプロパティ
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }
}