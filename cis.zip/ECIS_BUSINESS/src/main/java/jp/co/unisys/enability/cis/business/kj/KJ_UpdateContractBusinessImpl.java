package jp.co.unisys.enability.cis.business.kj;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import jp.co.unisys.enability.cis.business.kj.model.ForceUpdateContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.InquiryContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.InquiryContractorBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.InquiryMeterLocationBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.RmUpDetailBean;
import jp.co.unisys.enability.cis.business.kj.model.SupplementaryContractInformationBean;
import jp.co.unisys.enability.cis.common.Exception.BusinessLogicException;
import jp.co.unisys.enability.cis.common.Exception.SystemException;
import jp.co.unisys.enability.cis.common.util.KJ_CommonUtil;
import jp.co.unisys.enability.cis.common.util.RK_CommonUtil;
import jp.co.unisys.enability.cis.common.util.StringConvertUtil;
import jp.co.unisys.enability.cis.common.util.ThreadContext;
import jp.co.unisys.enability.cis.common.util.constants.ECISCodeConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISKJConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISReturnCodeConstants;
import jp.co.unisys.enability.cis.entity.common.CcaUnitM;
import jp.co.unisys.enability.cis.entity.common.CcdCategoryM;
import jp.co.unisys.enability.cis.entity.common.Contract;
import jp.co.unisys.enability.cis.entity.common.ContractAddInfo;
import jp.co.unisys.enability.cis.entity.common.ContractAddInfoExample;
import jp.co.unisys.enability.cis.entity.common.ContractEndReasonM;
import jp.co.unisys.enability.cis.entity.common.ContractExample;
import jp.co.unisys.enability.cis.entity.common.ContractHist;
import jp.co.unisys.enability.cis.entity.common.ContractHistExample;
import jp.co.unisys.enability.cis.entity.common.CssCatM;
import jp.co.unisys.enability.cis.entity.common.IlcM;
import jp.co.unisys.enability.cis.entity.common.MlContractHist;
import jp.co.unisys.enability.cis.entity.common.MlContractHistExample;
import jp.co.unisys.enability.cis.entity.common.PhoneNoCatM;
import jp.co.unisys.enability.cis.entity.common.Rm;
import jp.co.unisys.enability.cis.entity.common.RmMByPmCompany;
import jp.co.unisys.enability.cis.entity.common.RmMByPmCompanyKey;
import jp.co.unisys.enability.cis.entity.common.RmUp;
import jp.co.unisys.enability.cis.entity.common.RmUpDetail;
import jp.co.unisys.enability.cis.entity.common.RmUpDetailExample;
import jp.co.unisys.enability.cis.entity.common.RmUpKey;
import jp.co.unisys.enability.cis.entity.common.ScM;
import jp.co.unisys.enability.cis.entity.common.SplContract;
import jp.co.unisys.enability.cis.entity.common.SplContractExample;
import jp.co.unisys.enability.cis.entity.common.UpsCategoryM;
import jp.co.unisys.enability.cis.entity.kj.KJ_ContractHistoryInformationEntityBean;
import jp.co.unisys.enability.cis.entity.kj.KJ_InquiryContractInformationEntityBean;
import jp.co.unisys.enability.cis.entity.kj.KJ_InquiryContractorInformationEntityBean;
import jp.co.unisys.enability.cis.entity.kj.KJ_InquiryMeterLocationEntityBean;
import jp.co.unisys.enability.cis.mapper.common.CcaUnitMMapper;
import jp.co.unisys.enability.cis.mapper.common.CcdCategoryMMapper;
import jp.co.unisys.enability.cis.mapper.common.ContractAddInfoMapper;
import jp.co.unisys.enability.cis.mapper.common.ContractEndReasonMMapper;
import jp.co.unisys.enability.cis.mapper.common.ContractHistMapper;
import jp.co.unisys.enability.cis.mapper.common.ContractMapper;
import jp.co.unisys.enability.cis.mapper.common.CssCatMMapper;
import jp.co.unisys.enability.cis.mapper.common.IlcMMapper;
import jp.co.unisys.enability.cis.mapper.common.MlContractHistMapper;
import jp.co.unisys.enability.cis.mapper.common.PhoneNoCatMMapper;
import jp.co.unisys.enability.cis.mapper.common.RmMByPmCompanyMapper;
import jp.co.unisys.enability.cis.mapper.common.RmMapper;
import jp.co.unisys.enability.cis.mapper.common.RmUpDetailMapper;
import jp.co.unisys.enability.cis.mapper.common.RmUpMapper;
import jp.co.unisys.enability.cis.mapper.common.ScMMapper;
import jp.co.unisys.enability.cis.mapper.common.SplContractMapper;
import jp.co.unisys.enability.cis.mapper.common.UpsCategoryMMapper;
import jp.co.unisys.enability.cis.mapper.kj.AgentContractInformationCommonMapper;
import jp.co.unisys.enability.cis.mapper.kj.MeterLocationInformationCommonMapper;
import jp.co.unisys.enability.cis.mapper.rk.FixChargeResultInformationCommonMapper;

/**
 * 契約情報更新ビジネス
 *
 * @author "Nihon Unisys, Ltd."
 *
 */
public class KJ_UpdateContractBusinessImpl implements KJ_UpdateContractBusiness {

  /**
   * メッセージプロパティ(DI)
   */
  private MessageSource messageSource;
  /**
   * 契約マッパー(DI)
   */
  private ContractMapper contractMapper;
  /**
   * 契約マッパー(DI)
   */
  private ContractAddInfoMapper contractAddInfoMapper;
  /**
   * 確定料金共通マッパー(DI)
   */
  private FixChargeResultInformationCommonMapper fixChargeResultInformationCommonMapper;
  /**
   * 契約履歴マッパー(DI)
   */
  private ContractHistMapper contractHistMapper;
  /**
   * 電話番号区分マッパー(DI)
   */
  private PhoneNoCatMMapper phoneNoCatMMapper;
  /**
   * 接続送電サービス区分マスタマッパー(DI)
   */
  private CssCatMMapper cssCatMMapper;
  /**
   * 契約終了理由マスタマッパー(DI)
   */
  private ContractEndReasonMMapper contractEndReasonMMapper;
  /**
   * 契約容量単位マスタマッパー(DI)
   */
  private CcaUnitMMapper ccaUnitMMapper;
  /**
   * 個人・法人区分マスタマッパー(DI)
   */
  private IlcMMapper ilcMMapper;
  /**
   * 営業委託先マスタマッパー(DI)
   */
  private ScMMapper scMMapper;
  /**
   * 料金メニューマッパー(DI)
   */
  private RmMapper rmMapper;
  /**
   * 付帯契約情報マッパー(DI)
   */
  private SplContractMapper splContractMapper;
  /**
   * 提供モデル企業別料金メニューマスタマッパー(DI)
   */
  private RmMByPmCompanyMapper rmMByPmCompanyMapper;
  /**
   * メーター設置場所契約履歴マッパー(DI)
   */
  private MlContractHistMapper mlContractHistMapper;
  /**
   * 契約者情報ビジネス(DI)
   */
  private KJ_ContractorInformationBusiness kjContractorInfomationBusiness;
  /**
   * 契約情報ビジネス(DI)
   */
  private KJ_ContractInformationBusiness kjContractInfomationBusiness;
  /**
   * メータ設置場所ビジネス(DI)
   */
  private KJ_MeterLocationInformationBusiness kjMeterLocationInformationBusiness;
  /**
   * 料金メニュー単価マスタマッパー(DI)
   */
  private RmUpMapper rmUpMapper;
  /**
   * 料金メニュー単価明細マッパー(DI)
   */
  private RmUpDetailMapper rmUpDetailMapper;
  /**
   * 料金メニュー単価マッパー(DI)
   */
  private UpsCategoryMMapper upsCategoryMMapper;
  /**
   * 契約電力決定区分マスタマッパー(DI)
   */
  private CcdCategoryMMapper ccdCategoryMMapper;
  /**
   * 卸取次店向け契約情報共通マッパー(DI)
   */
  private AgentContractInformationCommonMapper contractInformationCommonMapper;

  /**
   * トランザクションマネージャー(DI)
   */
  private DataSourceTransactionManager txManager;

  /**
   * ログマネジャー
   */
  private static Logger logger = LogManager.getLogger();

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.kj.
   * KJ_UpdateContractBusiness #update(jp.co.unisys.enability.cis
   * .business.kj.model.ForceUpdateContractBusinessBean)
   */
  @Override
  public ForceUpdateContractBusinessBean update(
      ForceUpdateContractBusinessBean forceUpdateContractBusinessBean) {

    try {

      UpdateContractContext context = new UpdateContractContext();
      context.setResult(Pair.of(ECISReturnCodeConstants.RETURN_CODE_0000, null));

      // チェックと契約情報、契約者情報取得
      context = checkAndSearchInputBean(context, forceUpdateContractBusinessBean);
      if (!StringUtils.equals(ECISReturnCodeConstants.RETURN_CODE_0000, context.getResult().getLeft())) {
        forceUpdateContractBusinessBean.setReturnCode(context.getResult().getLeft());
        forceUpdateContractBusinessBean.setMessage(context.getResult().getRight());
        return forceUpdateContractBusinessBean;
      }

      // 契約、契約履歴、付帯契約更新
      forceUpdateContract(context, forceUpdateContractBusinessBean);

      forceUpdateContractBusinessBean.setReturnCode(context.getResult().getLeft());
      forceUpdateContractBusinessBean.setMessage(context.getResult().getRight());

    } catch (BusinessLogicException e) {
      logger.error(e.getMessage(), e);
      // catch 業務例外クラス
      forceUpdateContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      forceUpdateContractBusinessBean.setMessage(messageSource.getMessage(
          ECISReturnCodeConstants.RETURN_CODE_G017, null, Locale.getDefault()));
    } catch (NoSuchMessageException e) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, e);
      forceUpdateContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      forceUpdateContractBusinessBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
    } catch (SystemException e) {
      logger.error(messageSource.getMessage("error.E1129", null,
          Locale.getDefault()), e);
      forceUpdateContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      forceUpdateContractBusinessBean.setMessage(messageSource.getMessage(
          ECISReturnCodeConstants.RETURN_CODE_G017, null, Locale.getDefault()));
    }

    return forceUpdateContractBusinessBean;
  }

  /**
   * 契約、契約履歴、付帯契約更新
   *
   * @param context
   * @param forceUpdateContractBusinessBean
   */
  private void forceUpdateContract(UpdateContractContext context,
      ForceUpdateContractBusinessBean forceUpdateContractBusinessBean) {

    boolean commitStatus = false;
    DefaultTransactionDefinition def = new DefaultTransactionDefinition();
    def.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
    def.setIsolationLevel(TransactionDefinition.ISOLATION_DEFAULT);
    TransactionStatus status = this.txManager.getTransaction(def);

    try {

      // 契約情報更新
      contractUpdate(context, forceUpdateContractBusinessBean);
      if (!StringUtils.equals(ECISReturnCodeConstants.RETURN_CODE_0000, context.getResult().getLeft())) {
        return;
      }

      //個別料金更新
      rmUpUpdate(context, forceUpdateContractBusinessBean);
      if (!StringUtils.equals(ECISReturnCodeConstants.RETURN_CODE_0000, context.getResult().getLeft())) {
        return;
      }

      // 契約履歴更新
      contractHistUpdate(context, forceUpdateContractBusinessBean);
      if (!StringUtils.equals(ECISReturnCodeConstants.RETURN_CODE_0000, context.getResult().getLeft())) {
        return;
      }

      // 付帯契約更新
      splContractUpdate(context, forceUpdateContractBusinessBean);
      if (!StringUtils.equals(ECISReturnCodeConstants.RETURN_CODE_0000, context.getResult().getLeft())) {
        return;
      }

      commitStatus = true;
    } finally {
      if (commitStatus) {
        // コミットフラグがtrueの場合、コミット
        this.txManager.commit(status);
      } else {
        // コミットフラグがfalseの場合、ロールバック
        this.txManager.rollback(status);
      }
    }

  }

  /**
   * 個別料金更新
   *
   * @param context
   * @param forceUpdateContractBusinessBean
   */
  private void rmUpUpdate(UpdateContractContext context,
      ForceUpdateContractBusinessBean forceUpdateContractBusinessBean) {

    logger.info("CIS0027 rmUpUpdate start");

    KJ_ContractHistoryInformationEntityBean hist = context.getContract()
        .getContractHistoryInformationList().stream().findFirst().get();

    RmUp rmUp = createRmUp(
        forceUpdateContractBusinessBean,
        context,
        context.getRm().getRmId());
    RmUpKey rmUpKey = new RmUpKey();

    rmUpKey.setRmId(hist.getRateMenuId());
    rmUpKey.setUpApplySd(hist.getApplyStartDate());
    rmUpKey.setUpCatCode(hist.getContractId().toString());

    RmUp searchRmUp = this.rmUpMapper.selectByPrimaryKey(rmUpKey);

    // 料金メニュー単価を登録する
    int resultCount = 0;
    if (Objects.nonNull(searchRmUp)) {
      resultCount = this.rmUpMapper.deleteByPrimaryKey(rmUpKey);
      if (resultCount != 1) {
        logger.error("料金メニュー単価 deleteByPrimaryKey H001");
        context.setResult(createResult(ECISReturnCodeConstants.RETURN_CODE_H001, null));
        return;
      }
    }

    // 単価設定区分コードが"indiv"(定数.単価設定区分コード：個単価)の場合、料金メニュー単価と料金メニュー単価明細を登録する。
    if (ECISConstants.UNIT_PRICE_SETTING_CATEGORY_INDIV.equals(
        forceUpdateContractBusinessBean.getUnitPriceCategoryCode())) {

      resultCount = this.rmUpMapper.insert(rmUp);
      if (resultCount != 1) {
        logger.error("料金メニュー単価 insert H001");
        context.setResult(createResult(ECISReturnCodeConstants.RETURN_CODE_H001, null));
        return;
      }
    }

    // 料金メニュー単価明細削除
    RmUpDetailExample rmUpDetailExample = new RmUpDetailExample();
    rmUpDetailExample.createCriteria()
        .andRmIdEqualTo(hist.getRateMenuId())
        .andUpApplySdEqualTo(hist.getApplyStartDate())
        .andUpCatCodeEqualTo(hist.getContractId().toString());
    rmUpDetailMapper.deleteByExample(rmUpDetailExample);

    // 単価設定区分コードが"indiv"(定数.単価設定区分コード：個単価)の場合、料金メニュー単価と料金メニュー単価明細を登録する。
    if (ECISConstants.UNIT_PRICE_SETTING_CATEGORY_INDIV.equals(
        forceUpdateContractBusinessBean.getUnitPriceCategoryCode())) {
      // 料金メニュー単価明細を登録する。
      List<RmUpDetailBean> rmUpdetailList = forceUpdateContractBusinessBean.getRmUpDetailList();
      for (RmUpDetailBean upCatMap : rmUpdetailList) {

        RmUpDetail rmUpDetail = createRmUpDetail(
            forceUpdateContractBusinessBean,
            upCatMap,
            context.getRm().getRmId());

        rmUpDetailMapper.insert(rmUpDetail);
      }
    }

    logger.info("CIS0027 rmUpUpdate end");

  }

  /**
   * registBeanより《料金メニュー単価Entity》に値を設定する
   *
   * @param businessBean
   *          契約情報登録BusinessBean
   * @param contextUserId
   *          コンテキストユーザID
   * @param contextModuleCode
   *          コンテキストモジュールコード
   * @param rmId
   *          料金メニューID
   * @return 料金メニュー単価Entity
   */
  private RmUp createRmUp(
      ForceUpdateContractBusinessBean businessBean,
      UpdateContractContext context,
      String rmId) {

    RmUp rmUp = new RmUp();

    // 料金メニューID
    rmUp.setRmId(rmId);

    // 単価設定区分コード
    rmUp.setUpCatCode(businessBean.getContractId().toString());

    // 最低月額料金
    rmUp.setMmc(businessBean.getMinimumMonthlyCharge());

    // 単価適用開始日
    rmUp.setUpApplySd(businessBean.getContractStartDate());

    // 単価適用終了日
    rmUp.setUpApplyEd(StringConvertUtil.stringToDate(
        ECISKJConstants.APPLY_END_DATE_MAX, null));

    // 更新回数
    rmUp.setUpdateCount(0);

    Timestamp systemTime = new Timestamp(System.currentTimeMillis());

    rmUp.setCreateTime(systemTime);

    rmUp.setOnlineUpdateTime(systemTime);

    // オンライン更新ユーザID
    rmUp.setOnlineUpdateUserId(ThreadContext.getRequestThreadContext()
        .get(ECISConstants.USER_ID_KEY).toString());
    // 更新モジュールコード
    rmUp.setUpdateModuleCode(ThreadContext.getRequestThreadContext()
        .get(ECISConstants.CLASS_NAME_KEY).toString());

    rmUp.setUpdateTime(systemTime);

    return rmUp;
  }

  /**
   * registBeanより《料金メニュー単価明細Entity》に値を設定する
   *
   * @param businessBean
   *          契約情報登録BusinessBean
   * @param contextUserId
   *          コンテキストユーザID
   * @param contextModuleCode
   *          コンテキストモジュールコード
   * @param detail
   *          料金メニュー単価明細
   * @param rmId
   *          料金メニューID
   * @return 料金メニュー単価明細Entity
   */
  private RmUpDetail createRmUpDetail(
      ForceUpdateContractBusinessBean businessBean,
      RmUpDetailBean detail,
      String rmId) {

    RmUpDetail reUpDetail = new RmUpDetail();

    // 料金メニューID
    reUpDetail.setRmId(rmId);
    // 単価設定区分コード
    reUpDetail.setUpCatCode(businessBean.getContractId().toString());
    // 単価適用開始日
    reUpDetail.setUpApplySd(businessBean.getContractStartDate());
    // DCEC区分コード
    reUpDetail.setDcecCatCode(detail.getDcecCategoryCode());
    // 時間帯コード
    reUpDetail.setTsCode(detail.getTimeSlotCode());
    // 枝番
    reUpDetail.setBranchNo(detail.getBranchNo());
    // 表示名称1
    reUpDetail.setDisplayName1(detail.getDisplayName1());
    // 表示名称2
    reUpDetail.setDisplayName2(detail.getDisplayName2());
    // 閾値
    reUpDetail.setThreshold(detail.getThreshold());
    // 閾値名称
    reUpDetail.setThresholdName(detail.getThresholdName());
    // 単価
    reUpDetail.setUp(detail.getUnitPrice());
    // 表示順
    reUpDetail.setDisplayOrder(detail.getDisplayOrder());
    // 明細出力順
    reUpDetail.setDetailOutputOrder(detail.getDetailOutputOrder());
    // 更新回数
    reUpDetail.setUpdateCount(0);

    Timestamp systemTime = new Timestamp(System.currentTimeMillis());

    reUpDetail.setCreateTime(systemTime);

    reUpDetail.setOnlineUpdateTime(systemTime);

    // オンライン更新ユーザID
    reUpDetail.setOnlineUpdateUserId(ThreadContext.getRequestThreadContext()
        .get(ECISConstants.USER_ID_KEY).toString());
    // 更新モジュールコード
    reUpDetail.setUpdateModuleCode(ThreadContext.getRequestThreadContext()
        .get(ECISConstants.CLASS_NAME_KEY).toString());

    reUpDetail.setUpdateTime(systemTime);

    return reUpDetail;
  }

  /**
   * 付帯契約情報更新
   *
   * @param context
   * @param forceUpdateContractBusinessBean
   */
  private void splContractUpdate(UpdateContractContext context,
      ForceUpdateContractBusinessBean forceUpdateContractBusinessBean) {

    if (Objects.nonNull(forceUpdateContractBusinessBean.getContractEndDate())) {

      // 削除新規を行う
      SplContractExample delContractExample = new SplContractExample();
      delContractExample.createCriteria()
          .andContractIdEqualTo(forceUpdateContractBusinessBean.getContractId());
      this.splContractMapper.deleteByExample(delContractExample);

      if (!CollectionUtils.isEmpty(forceUpdateContractBusinessBean
          .getSupplementaryContractInformationBeanList())) {

        for (SupplementaryContractInformationBean suppBean : forceUpdateContractBusinessBean
            .getSupplementaryContractInformationBeanList()) {

          // フラグがONのデータのみ取り扱う
          if (StringUtils.equals(ECISConstants.FLG_ON, suppBean.getUpdateFlagSupplementaryContract())) {
            // 追加

            SplContract splContract = convertEntity(forceUpdateContractBusinessBean).apply(
                suppBean);
            int updateCount = this.splContractMapper.insertBySequence(splContract);
            if (updateCount != 1) {
              logger.error("付帯契約 insertBySequence H001");
              context.setResult(createResult(ECISReturnCodeConstants.RETURN_CODE_H001, null));
              return;
            }
          }
        }

      }
    }
  }

  /**
   * 契約履歴更新
   *
   * @param context
   * @param forceUpdateContractBusinessBean
   */
  private void contractHistUpdate(UpdateContractContext context,
      ForceUpdateContractBusinessBean forceUpdateContractBusinessBean) {
    // 契約履歴検索
    KJ_ContractHistoryInformationEntityBean updateTarget = context.getContract()
        .getContractHistoryInformationList().stream().findFirst().get();
    ContractHistExample histExample = new ContractHistExample();
    histExample.createCriteria()
        .andContractIdEqualTo(forceUpdateContractBusinessBean.getContractId())
        .andApplySdEqualTo(updateTarget.getApplyStartDate())
        .andUpdateCountEqualTo(updateTarget.getUpdateCount());

    List<ContractHist> contractHistList = contractHistMapper.selectByExample(histExample);
    if (CollectionUtils.isEmpty(contractHistList)) {
      logger.error("契約履歴 selectByExample H001");
      context.setResult(createResult(ECISReturnCodeConstants.RETURN_CODE_H001, null));
      return;
    }

    // 料金メニュー取得

    // 契約履歴情報更新
    ContractHist oldContractHist = contractHistList.stream().findFirst().get();
    ContractHist newHistRecord = convertEntity(context, oldContractHist).apply(forceUpdateContractBusinessBean);
    int updateCount = contractHistMapper.updateByExampleSelective(newHistRecord, histExample);
    if (updateCount != 1) {
      logger.error("契約履歴 updateByExampleSelective H001");
      context.setResult(createResult(ECISReturnCodeConstants.RETURN_CODE_H001, null));
      return;
    }

    // 契約履歴を更新したときメーター設置場所契約履歴も更新する
    // メータ契約履歴検索
    MlContractHistExample mlHistExample = new MlContractHistExample();
    mlHistExample.createCriteria()
        .andContractIdEqualTo(forceUpdateContractBusinessBean.getContractId())
        .andApplySdEqualTo(updateTarget.getApplyStartDate());

    List<MlContractHist> mlContractHistList = this.mlContractHistMapper.selectByExample(mlHistExample);
    if (CollectionUtils.isEmpty(mlContractHistList)) {
      logger.error("メータ設置場所契約履歴 selectByExample H001");
      context.setResult(createResult(ECISReturnCodeConstants.RETURN_CODE_H001, null));
      return;
    }

    MlContractHist oldMlContractHist = mlContractHistList.stream().findFirst().get();
    MlContractHist neMlContractHist = convertEntity(oldMlContractHist).apply(forceUpdateContractBusinessBean);

    int mlUpdateCount = this.mlContractHistMapper.updateByExampleSelective(neMlContractHist, mlHistExample);
    if (mlUpdateCount != 1) {
      logger.error("メータ設置場所契約履歴 updateByExampleSelective H001");
      context.setResult(createResult(ECISReturnCodeConstants.RETURN_CODE_H001, null));
      return;
    }

  }

  /**
   * 契約情報更新
   *
   * @param context
   * @param forceUpdateContractBusinessBean
   */
  private void contractUpdate(UpdateContractContext context,
      ForceUpdateContractBusinessBean forceUpdateContractBusinessBean) {
    // 契約情報検索
    ContractExample example = new ContractExample();
    example.createCriteria()
        .andContractIdEqualTo(forceUpdateContractBusinessBean.getContractId())
        .andUpdateCountEqualTo(forceUpdateContractBusinessBean.getUpdateCount());
    List<Contract> contractList = contractMapper.selectByExample(example);
    if (CollectionUtils.isEmpty(contractList)) {
      logger.error("契約情報 selectByExample H001");
      context.setResult(createResult(ECISReturnCodeConstants.RETURN_CODE_H001, null));
      return;
    }

    // 契約情報更新
    Contract oldContract = contractList.stream().findFirst().get();
    Contract newRecord = convertEntity(oldContract).apply(forceUpdateContractBusinessBean);

    Map<String, Object> updExample = new HashMap<>();
    updExample.put("consignmentContractCapacityNoUpdFlag",
        forceUpdateContractBusinessBean.getConsignmentContractCapacityFlag());
    updExample.put("consignmentContractCapacityDecisionDateNoUpdFlag",
        forceUpdateContractBusinessBean.getConsignmentContractCapacityDecisionDateFlag());
    updExample.put("conditionContractId", forceUpdateContractBusinessBean.getContractId());
    updExample.put("conditionUpdateCount", forceUpdateContractBusinessBean.getUpdateCount());

    int updateCount = contractMapper.updateByNoUpdFlagSelective(newRecord, updExample);
    if (updateCount != 1) {
      logger.error("契約情報 updateByNoUpdFlagSelective H001");
      context.setResult(createResult(ECISReturnCodeConstants.RETURN_CODE_H001, null));
      return;
    }

    // 外部システム契約番号更新
    ContractAddInfoExample addInfoExample = new ContractAddInfoExample();
    addInfoExample.createCriteria()
        .andContractIdEqualTo(forceUpdateContractBusinessBean.getContractId());
    List<ContractAddInfo> addInfoList = this.contractAddInfoMapper.selectByExample(addInfoExample);
    if (CollectionUtils.isEmpty(addInfoList)) {
      logger.error("契約付加情報 selectByExample H001");
      context.setResult(createResult(ECISReturnCodeConstants.RETURN_CODE_H001, null));
      return;
    }

    ContractAddInfo addInfo = addInfoList.stream().findFirst().get();
    addInfo.setAgentContractNo(forceUpdateContractBusinessBean.getAgentContractNo());
    addInfo.setFree1(forceUpdateContractBusinessBean.getContractFree1());
    addInfo.setFree2(forceUpdateContractBusinessBean.getContractFree2());
    addInfo.setFree3(forceUpdateContractBusinessBean.getContractFree3());
    addInfo.setUpdateCount(addInfo.getUpdateCount() + 1);
    Timestamp systemTime = new Timestamp(System.currentTimeMillis());
    // オンライン更新日時
    addInfo.setOnlineUpdateTime(systemTime);
    // オンライン更新ユーザID
    addInfo.setOnlineUpdateUserId(ThreadContext.getRequestThreadContext()
        .get(ECISConstants.USER_ID_KEY).toString());
    // 更新モジュールコード
    addInfo.setUpdateModuleCode(ThreadContext.getRequestThreadContext()
        .get(ECISConstants.CLASS_NAME_KEY).toString());
    // 更新日時
    addInfo.setUpdateTime(systemTime);

    updateCount = this.contractAddInfoMapper.updateByExample(addInfo, addInfoExample);
    if (updateCount != 1) {
      logger.error("契約付加情報 updateByExample H001");
      context.setResult(createResult(ECISReturnCodeConstants.RETURN_CODE_H001, null));
      return;
    }

  }

  /**
   * 入力チェック
   *
   * @param context
   * @param forceUpdateContractBusinessBean
   * @return left:resultCode right:message
   * @throws BusinessLogicException
   */
  private UpdateContractContext checkAndSearchInputBean(
      UpdateContractContext context,
      ForceUpdateContractBusinessBean forceUpdateContractBusinessBean)
      throws BusinessLogicException {

    // コードチェック
    Pair<String, String> result = checkCode(forceUpdateContractBusinessBean);
    if (!StringUtils.equals(ECISReturnCodeConstants.RETURN_CODE_0000, result.getLeft())) {
      context.setResult(result);
      return context;
    }

    // 契約情報チェック(契約者情報チェックも内包)
    context = checkAndSearchContract(context, forceUpdateContractBusinessBean);
    return context;
  }

  /**
   * 契約者情報チェック
   *
   * @param context
   *          契約情報更新コンテキスト
   * @param checkBean
   *          チェック対象Bean
   * @param contractBean
   *          契約情報Bean
   * @return 契約情報更新コンテキスト
   * @throws BusinessLogicException
   */
  private UpdateContractContext checkAndSearchContractor(
      UpdateContractContext context,
      ForceUpdateContractBusinessBean checkBean,
      KJ_InquiryContractInformationEntityBean contractBean) throws BusinessLogicException {

    InquiryContractorBusinessBean inquiryContractorBusinessBean = new InquiryContractorBusinessBean();
    inquiryContractorBusinessBean.setContractorId(contractBean.getContractorId());
    InquiryContractorBusinessBean result = this.kjContractorInfomationBusiness
        .inquiry(inquiryContractorBusinessBean);

    // 《契約者情報照会BusinessBean》.リターンコードが“0000”以外の場合、業務例外クラスをスローする。
    if (!StringUtils.equals(ECISReturnCodeConstants.RETURN_CODE_0000, result.getReturnCode())) {
      //メッセージID：error.E1281
      throw new BusinessLogicException(messageSource.getMessage(
          "error.E1281", null, Locale.getDefault()), false);
    }

    //《契約者情報照会BusinessBean》.リターンコードが“0000”かつ返却値が0件の場合
    if (CollectionUtils.isEmpty(result.getContractorInformationList())) {
      context.setResult(createResult(ECISReturnCodeConstants.RETURN_CODE_D014,
          null));
      return context;
    }

    KJ_InquiryContractorInformationEntityBean contractorInf = result.getContractorInformationList()
        .stream()
        .findFirst()
        .get();

    // 契約者利用不能チェック
    if (StringUtils.equals(ECISConstants.FLG_ON, contractorInf.getUnavailableFlag())) {
      context.setResult(createResult(ECISReturnCodeConstants.RETURN_CODE_D013,
          new String[] {}));
      return context;
    }

    context.setResult(Pair.of(ECISReturnCodeConstants.RETURN_CODE_0000, ""));
    context.setContractor(contractorInf);

    return context;
  }

  /**
   * 契約情報チェック
   *
   * @param context
   * @param checkBean
   * @return
   * @throws BusinessLogicException
   * @throws NoSuchMessageException
   */
  private UpdateContractContext checkAndSearchContract(
      UpdateContractContext context,
      ForceUpdateContractBusinessBean checkBean)
      throws BusinessLogicException {

    InquiryContractBusinessBean inquiryContractBusinessBean = new InquiryContractBusinessBean();
    inquiryContractBusinessBean.setContractId(checkBean.getContractId());
    inquiryContractBusinessBean.setContractNo(checkBean.getContractNo());

    InquiryContractBusinessBean result = this.kjContractInfomationBusiness
        .inquiry(inquiryContractBusinessBean);

    // 《契約情報照会BusinessBean》.リターンコードが“0000”以外の場合、業務例外クラスをスローする。
    if (!StringUtils.equals(ECISReturnCodeConstants.RETURN_CODE_0000, result.getReturnCode())) {
      //メッセージID：error.E1285
      throw new BusinessLogicException(messageSource.getMessage(
          "error.E1285", null, Locale.getDefault()), false);
    }

    //《契約情報照会BusinessBean》.リターンコードが“0000”かつ返却値が0件の場合
    if (CollectionUtils.isEmpty(result.getContractInformationList())) {
      context.setResult(createResult(ECISReturnCodeConstants.RETURN_CODE_P005,
          new String[] {}));
      return context;
    }

    // 先頭取得
    KJ_InquiryContractInformationEntityBean contractInf = result.getContractInformationList()
        .stream().findFirst().get();

    // 契約終了状況チェック
    int resultCount = countByFixChargeResult(contractInf.getContractId(),
        contractInf.getContractEndDate(), ECISKJConstants.INQUIRY_FIX_CHANGE_RESULT_INFOEMATION_FLG_TWO);
    // 結果が1件以上の場合リターンコードに（D025）を設定し返却する
    if (resultCount >= 1) {
      context.setResult(createResult(ECISReturnCodeConstants.RETURN_CODE_D025, null));
      return context;
    }

    // 契約者情報チェック
    context = checkAndSearchContractor(context, checkBean, contractInf);
    if (!StringUtils.equals(ECISReturnCodeConstants.RETURN_CODE_0000, context.getResult().getLeft())) {
      return context;
    }

    // 以降の処理用にデータ取得
    KJ_InquiryContractorInformationEntityBean contractorInf = context.getContractor();
    KJ_ContractHistoryInformationEntityBean histInf = contractInf.getContractHistoryInformationList()
        .stream()
        .findFirst()
        .get();

    // 契約期間チェック
    if (Objects.nonNull(checkBean.getContractEndDate())) {

      //《契約情報更新BusinessBean》.契約終了日が《契約情報照会BusinessBean》.契約開始日以前の日付ではないこと。
      if (checkBean.getContractEndDate().compareTo(contractInf.getContractStartDate()) <= 0) {
        context.setResult(createResult(ECISReturnCodeConstants.RETURN_CODE_G005, null));
        return context;
      }

      //《契約情報更新BusinessBean》.契約終了日が、《契約情報照会BusinessBean》.適用開始日リストの最新の適用開始日
      // 以前の日付ではないこと。
      if (checkBean.getContractEndDate().compareTo(histInf.getApplyStartDate()) <= 0) {
        context.setResult(createResult(ECISReturnCodeConstants.RETURN_CODE_G031, null));
        return context;
      }
    }

    // 《契約情報更新BusinessBean》.料金メニューIDがNULLまたは空文字のいずれかでない場合
    if (StringUtils.isNotEmpty(checkBean.getChargeMenuId())) {

      //提供モデルと提供モデル企業の判定
      RmMByPmCompanyKey rmMByPmCompanyKey = new RmMByPmCompanyKey();
      rmMByPmCompanyKey.setPmCode(contractorInf.getProvideModelCode());
      rmMByPmCompanyKey.setPmCompanyCode(contractorInf.getProvideModelCompanyCode());
      rmMByPmCompanyKey.setRmId(checkBean.getChargeMenuId());

      RmMByPmCompany rmMByPmCompany = this.rmMByPmCompanyMapper.selectByPrimaryKey(rmMByPmCompanyKey);
      if (Objects.isNull(rmMByPmCompany)) {
        context.setResult(createResult(ECISReturnCodeConstants.RETURN_CODE_G038, null));
        return context;
      }

      // 料金メニュー存在チェック
      Rm rm = this.rmMapper.selectByPrimaryKey(checkBean.getChargeMenuId());
      if (Objects.isNull(rm)) {
        context.setResult(createResult(ECISReturnCodeConstants.RETURN_CODE_D003, null));
        return context;
      }
      context.setRm(rm);

      // メータ設置場所照会
      InquiryMeterLocationBusinessBean meterLocationBean = new InquiryMeterLocationBusinessBean();
      meterLocationBean.setContractId(checkBean.getContractId());

      InquiryMeterLocationBusinessBean resultMeterLocationBean = kjMeterLocationInformationBusiness
          .inquiry(meterLocationBean);
      if (!ECISReturnCodeConstants.RETURN_CODE_0000
          .equals(resultMeterLocationBean.getReturnCode())
          || CollectionUtils.isEmpty(resultMeterLocationBean.getMeterLocationList())) {
        throw new BusinessLogicException(messageSource.getMessage(
            "error.E1299", new String[] {}, Locale.getDefault()),
            false);
      }

      KJ_InquiryMeterLocationEntityBean returnMlBean = resultMeterLocationBean
          .getMeterLocationList().stream().findFirst().get();

      // 料金メニュー情報チェック
      // (1)エリアコードチェック
      if (!StringUtils.equals(returnMlBean.getAreaCode(), rm.getAreaCode())) {
        context.setResult(createResult(ECISReturnCodeConstants.RETURN_CODE_G036, null));
        return context;
      }

      // (2)売買区分コードチェック
      // 売買区分コードチェック
      // 《メータ設置場所照会EntityBean》.送受電区分コードを取得する。
      String transmissionCategoryCode = returnMlBean.getTransmissionCategoryCode();
      // 《料金メニュー》.売買区分コードを取得する。
      String saleCatCode = rm.getSaleCatCode();

      // 送受電区分コードが"1:送電" かつ 売買区分コードが"2:買電"場合、
      // または 送受電区分コードが"2:受電" かつ 売買区分コードが"1:売電"場合、
      // リターンコードに（G037）を設定し返却する。
      if ((ECISCodeConstants.TRANSMISSION_CATEGORY_CODE_TRANSMISSION.equals(transmissionCategoryCode)
          && ECISCodeConstants.SALE_CATEGORY_PURCHASING.equals(saleCatCode))
          || (ECISCodeConstants.TRANSMISSION_CATEGORY_CODE_RECEIVING.equals(transmissionCategoryCode)
              && ECISCodeConstants.SALE_CATEGORY_SELLING.equals(saleCatCode))) {
        context.setResult(createResult(ECISReturnCodeConstants.RETURN_CODE_G037, null));
        return context;
      }

      // 契約電力決定区分が協議制の場合
      if (ECISCodeConstants.CONTRACT_CAPACITY_DECISION_CATEGORY_CODE_DISCUSSIONS
          .equals(checkBean.getCcDecisionCategoryCode())) {

        // 契約容量チェック
        //《料金メニューEntity》.契約容量単位がNULLまたは空文字いずれかでない場合
        if (StringUtils.isNotEmpty(rm.getCcaUnit())) {
          //《契約情報更新BusinessBean》.契約容量がNULLの場合
          if (Objects.isNull(checkBean.getContractCapacity())) {
            context.setResult(createResult(ECISReturnCodeConstants.RETURN_CODE_P065, null));
            return context;
          }
        } else {
          if (Objects.nonNull(checkBean.getContractCapacity())) {
            context.setResult(createResult(ECISReturnCodeConstants.RETURN_CODE_P064, null));
            return context;
          }

        }

        //《契約情報更新BusinessBean》.契約容量がNULLでない場合
        if (Objects.nonNull(checkBean.getContractCapacity())) {
          // 契約容量選択可能範囲チェック
          boolean checkCapacty = RK_CommonUtil.checkContractCapacity(
              String.valueOf(checkBean.getContractCapacity()),
              rm.getCapacitySelectableRange());
          if (!checkCapacty) {
            // 返却値が“false”の場合リターンコードに（G006）を設定し返却する。
            context.setResult(createResult(ECISReturnCodeConstants.RETURN_CODE_G006, null));
            return context;
          }
        }
      }
    } else {
      //《契約情報更新BusinessBean》.料金メニューIDがNULLまたは空文字の場合

      //最新履歴の料金メニューIDをチェック
      Rm rm = this.rmMapper.selectByPrimaryKey(histInf.getRateMenuId());
      if (Objects.isNull(rm)) {
        context.setResult(createResult(ECISReturnCodeConstants.RETURN_CODE_D003, null));
        return context;
      }
      context.setRm(rm);
    }

    //適用期間チェック
    //《契約情報更新BusinessBean》.適用開始日が《料金メニュー》.適用開始日と《料金メニュー》.適用終了日の期間外
    if (Objects.isNull(checkBean.getContractEndDate())) {
      checkBean.setContractEndDate(contractInf.getContractEndDate());
    }
    if ((checkBean.getApplyStartDate().compareTo(context.getRm().getApplySd()) < 0
        || checkBean.getApplyStartDate().compareTo(context.getRm().getApplyEd()) > 0)
        ||
        (checkBean.getContractEndDate().compareTo(context.getRm().getApplySd()) < 0
            || checkBean.getContractEndDate().compareTo(context.getRm().getApplyEd()) > 0)) {
      context.setResult(createResult(ECISReturnCodeConstants.RETURN_CODE_G039, null));
      return context;
    }

    int rateSearchCount = countByFixChargeResult(contractInf.getContractId(),
        checkBean.getContractEndDate(), 0);
    // 結果が1件以上の場合リターンコードに（D019）を設定し返却する
    if (rateSearchCount >= 1) {
      context.setResult(createResult(ECISReturnCodeConstants.RETURN_CODE_D019, null));
      return context;
    }

    context.setResult(Pair.of(ECISReturnCodeConstants.RETURN_CODE_0000, ""));
    context.setContract(contractInf);
    return context;
  }

  /**
   * 確定料金実績件数取得
   *
   * @param contractId
   * @param contractEndDate
   * @return
   */
  private int countByFixChargeResult(Integer contractId, Date contractEndDate, int flg) {
    Map<String, Object> exampleMap = new HashMap<String, Object>();
    exampleMap.put("contractId", contractId);
    exampleMap.put("coveredDate", contractEndDate);
    exampleMap.put("flg", flg);
    return this.fixChargeResultInformationCommonMapper.countByFixChargeResult(exampleMap);
  }

  /**
   * コードチェック
   *
   * @param checkBean
   * @return
   */
  private Pair<String, String> checkCode(ForceUpdateContractBusinessBean checkBean) {

    // 《契約情報更新BusinessBean》.契約終了日がNULLでなく、
    // かつ《契約情報更新BusinessBean》.契約終了日が"99991231"以外であり、
    // かつ《契約情報更新BusinessBean》.契約終了理由コードがNULLまたは空文字のいずれかでない場合
    if (Objects.nonNull(checkBean.getContractEndDate())
        && !StringUtils.equals(ECISKJConstants.APPLY_END_DATE_MAX,
            StringConvertUtil.convertDateToString(checkBean.getContractEndDate(),
                ECISConstants.FORMAT_DATE_yyyyMMdd))
        && StringUtils.isNotEmpty(checkBean.getContractEndReasonCode())) {

      // コード存在チェック
      if (!existsContractEndReason(checkBean.getContractEndReasonCode())) {
        return createResult(ECISReturnCodeConstants.RETURN_CODE_P020,
            new String[] {checkBean.getContractEndReasonCode() });
      }

    }

    //《契約情報更新BusinessBean》.連絡先個人・法人区分コードがNULLまたは空文字のいずれかでない場合
    if (StringUtils.isNotEmpty(checkBean.getContactInformationinDividualLegalEntityCategoryCode())) {

      // コード存在チェック
      if (!existsDividualLegalCategoryCode(checkBean.getContactInformationinDividualLegalEntityCategoryCode())) {
        return createResult(ECISReturnCodeConstants.RETURN_CODE_P021,
            new String[] {checkBean.getContactInformationinDividualLegalEntityCategoryCode() });
      }
    }

    //《契約情報更新BusinessBean》.連絡先電話区分コードがNULLまたは空文字のいずれかでない場合
    if (StringUtils.isNotEmpty(checkBean.getContractInformationCategoryCode())) {

      // コード存在チェック
      if (!existsContractInformationCategoryCode(checkBean.getContractInformationCategoryCode())) {
        return createResult(ECISReturnCodeConstants.RETURN_CODE_P019,
            new String[] {checkBean.getContractInformationCategoryCode() });
      }

    }

    //《契約情報更新BusinessBean》.接続送電サービス区分コードがNULLまたは空文字のいずれかでない場合、
    if (StringUtils.isNotEmpty(checkBean.getConnectedSupplyServiceCategoryCode())) {

      // コード存在チェック
      if (!existsConnectedSupplyServiceCategoryCode(checkBean.getConnectedSupplyServiceCategoryCode())) {
        return createResult(ECISReturnCodeConstants.RETURN_CODE_P027,
            new String[] {checkBean.getConnectedSupplyServiceCategoryCode() });
      }

    }

    //《契約情報更新BusinessBean》.託送契約容量単位コードがNULLまたは空文字のいずれかでない場合
    if (StringUtils.isNotEmpty(checkBean.getConsignmentcontractCapacityUnitCode())) {

      // コード存在チェック
      if (!existsConsignmentcontractCapacityUnitCode(checkBean.getConsignmentcontractCapacityUnitCode())) {
        return createResult(ECISReturnCodeConstants.RETURN_CODE_P028,
            new String[] {checkBean.getConsignmentcontractCapacityUnitCode() });
      }

    }

    //《契約情報更新BusinessBean》.営業委託先コードがNULLまたは空文字のいずれかでない場合
    if (StringUtils.isNotEmpty(checkBean.getSalesConsignmentCode())) {

      // コード存在チェック
      if (!existsSalesConsignmentCode(checkBean.getSalesConsignmentCode())) {
        return createResult(ECISReturnCodeConstants.RETURN_CODE_P026,
            new String[] {checkBean.getSalesConsignmentCode() });
      }
    }

    // 契約電力決定区分コード存在チェック
    if (StringUtils.isNotEmpty(checkBean.getCcDecisionCategoryCode())) {
      if (!existsCcdCategory(checkBean.getCcDecisionCategoryCode())) {
        return createResult(ECISReturnCodeConstants.RETURN_CODE_P094,
            new String[] {checkBean.getCcDecisionCategoryCode() });
      }
    }

    // 単価設定区分のチェック及び、単価明細のチェック
    String upCatCode = checkBean.getUnitPriceCategoryCode();
    // 単価設定区分コード存在チェック
    if (StringUtils.isNotEmpty(upCatCode)) {
      if (!existsUpCat(upCatCode)) {
        return createResult(ECISReturnCodeConstants.RETURN_CODE_P092,
            new String[] {checkBean.getUnitPriceCategoryCode() });
      }
    }
    // 料金メニュー単価明細存在チェック
    Date contractSd = checkBean.getContractStartDate();
    // 料金メニュー単価明細リスト
    List<RmUpDetailBean> rmUpdetail = checkBean.getRmUpDetailList();
    List<String> checkRmUpDetail = checkRmUpDetail(upCatCode, checkBean.getChargeMenuId(), contractSd, rmUpdetail);
    if (checkRmUpDetail.size() != 0) {
      String[] params = {
          // 料金メニューID
          checkBean.getChargeMenuId(),
          // DCEC区分
          checkRmUpDetail.get(0),
          // 時間帯コード
          checkRmUpDetail.get(1),
          // 枝番
          checkRmUpDetail.get(2),
      };
      return createResult(ECISReturnCodeConstants.RETURN_CODE_P091,
          params);
    }
    return Pair.of(ECISReturnCodeConstants.RETURN_CODE_0000, "");
  }

  /**
   * 料金メニュー単価明細存在チェック<br>
   *
   * @param upCatCode
   *          単価設定区分
   * @param rateMenuId
   *          料金メニューID
   * @param onlineDate
   *          適用開始日
   * @param rmUpdetailList
   *          料金メニュー単価明細リスト
   * @return List チェックエラーの料金メニュー単価明細キー
   */
  private List<String> checkRmUpDetail(String upCatCode, String rateMenuId,
      Date contractStartDate, List<RmUpDetailBean> rmUpdetailList) {

    // 単価設定区分コードが「単価設定区分コード:個別設定」の場合
    List<String> params = new ArrayList<String>();
    Map<String, Object> upcatParam = new HashMap<String, Object>();
    if (ECISConstants.UNIT_PRICE_SETTING_CATEGORY_INDIV.equals(upCatCode)) {
      // 料金メニュー単価明細Exampleを生成
      upcatParam.put("rateMenuId", rateMenuId);
      upcatParam.put("unitPriceCategoryCode", ECISConstants.UNIT_PRICE_SETTING_CATEGORY_DEF);
      upcatParam.put("upApplySd", contractStartDate);
      upcatParam.put("upApplyEd", contractStartDate);
      // 料金メニュー単価明細リストの件数分繰り返し処理を行う。
      for (RmUpDetailBean upcatmap : rmUpdetailList) {
        upcatParam.put("dcecCatCode", upcatmap.getDcecCategoryCode());
        upcatParam.put("tsCode", upcatmap.getTimeSlotCode());
        upcatParam.put("branchNo", upcatmap.getBranchNo());
        // 料金メニュー単価明細.検索（主キー）を呼び出し
        int returnCountRmupdetail = contractInformationCommonMapper.selectCountRmUpDetail(upcatParam);
        //返却値が0件の場合falseを返却する。
        if (returnCountRmupdetail == 0) {
          params.add(upcatmap.getDcecCategoryCode());
          params.add(upcatmap.getTimeSlotCode());
          params.add(upcatmap.getBranchNo().toString());
          return params;
        }

      }
    }
    return params;
  }

  /**
   * レコード変換
   *
   * @param splContract
   * @return
   */
  private Function<SupplementaryContractInformationBean, SplContract> convertEntity(
      ForceUpdateContractBusinessBean checkBean) {
    return in -> {
      SplContract newSplContract = new SplContract();

      // 契約ID
      newSplContract.setContractId(checkBean.getContractId());
      // 付帯メニューID
      newSplContract.setSpmId(in.getSupplementaryMenuId());
      //付帯契約開始日
      newSplContract.setSplContractSd(in.getSupplementaryContractStartDate());
      //付帯契約終了日
      newSplContract.setSplContractEd(in.getSupplementaryContractEndDate());
      //額・率
      newSplContract.setAmountOrRate(in.getAmountOrRate());
      //更新回数
      newSplContract.setUpdateCount(Integer.valueOf(0));
      Timestamp systemTime = new Timestamp(System.currentTimeMillis());

      newSplContract.setCreateTime(systemTime);

      // オンライン更新日時
      newSplContract.setOnlineUpdateTime(systemTime);

      // オンライン更新ユーザID
      newSplContract.setOnlineUpdateUserId(ThreadContext.getRequestThreadContext()
          .get(ECISConstants.USER_ID_KEY).toString());

      // 更新モジュールコード
      newSplContract.setUpdateModuleCode(ThreadContext.getRequestThreadContext()
          .get(ECISConstants.CLASS_NAME_KEY).toString());

      // 更新日時
      newSplContract.setUpdateTime(systemTime);

      return newSplContract;
    };
  }

  /**
   * レコード変換
   *
   * @param contract
   * @return
   */
  private Function<ForceUpdateContractBusinessBean, ContractHist> convertEntity(UpdateContractContext context,
      ContractHist contractHist) {
    return in -> {
      ContractHist newHist = new ContractHist();

      //契約ID
      newHist.setContractId(in.getContractId());
      //適用開始日
      newHist.setApplySd(in.getContractStartDate());
      //適用終了日
      newHist.setApplyEd(contractHist.getApplyEd());
      //料金メニューID
      newHist.setRmId(in.getChargeMenuId());
      //契約容量
      newHist.setCca(in.getContractCapacity());
      //契約容量単位
      if (Objects.nonNull(context.getRm())) {
        newHist.setCcaUnit(context.getRm().getCcaUnit());
      }
      //契約変更理由
      newHist.setContractChangeReason(contractHist.getContractChangeReason());
      //契約電力決定区分コード
      newHist.setCcDecisionCategoryCode(contractHist.getCcDecisionCategoryCode());
      //電圧区分コード
      newHist.setVoltageCatCode(contractHist.getVoltageCatCode());
      //単価設定区分コード
      if (ECISConstants.UNIT_PRICE_SETTING_CATEGORY_INDIV.equals(in.getUnitPriceCategoryCode())) {
        newHist.setUpCatCode(in.getContractId().toString());
      } else {
        newHist.setUpCatCode(ECISConstants.UNIT_PRICE_SETTING_CATEGORY_DEF);
      }
      // 更新回数
      newHist.setUpdateCount(contractHist.getUpdateCount() + 1);

      Timestamp systemTime = new Timestamp(System.currentTimeMillis());

      // オンライン更新日時
      newHist.setOnlineUpdateTime(systemTime);

      // オンライン更新ユーザID
      newHist.setOnlineUpdateUserId(ThreadContext.getRequestThreadContext()
          .get(ECISConstants.USER_ID_KEY).toString());

      // 更新モジュールコード
      newHist.setUpdateModuleCode(ThreadContext.getRequestThreadContext()
          .get(ECISConstants.CLASS_NAME_KEY).toString());

      // 更新日時
      newHist.setUpdateTime(systemTime);

      return newHist;
    };
  }

  /**
   * レコード変換
   *
   * @param contract
   * @return
   */
  private Function<ForceUpdateContractBusinessBean, MlContractHist> convertEntity(MlContractHist oldMlContractHist) {
    return in -> {
      MlContractHist mlContractHist = new MlContractHist();

      // 適用開始日
      mlContractHist.setApplySd(in.getContractStartDate());
      //更新回数
      mlContractHist.setUpdateCount(oldMlContractHist.getUpdateCount() + 1);

      Timestamp systemTime = new Timestamp(System.currentTimeMillis());

      // オンライン更新日時
      mlContractHist.setOnlineUpdateTime(systemTime);

      // オンライン更新ユーザID
      mlContractHist.setOnlineUpdateUserId(ThreadContext.getRequestThreadContext()
          .get(ECISConstants.USER_ID_KEY).toString());

      // 更新モジュールコード
      mlContractHist.setUpdateModuleCode(ThreadContext.getRequestThreadContext()
          .get(ECISConstants.CLASS_NAME_KEY).toString());

      // 更新日時
      mlContractHist.setUpdateTime(systemTime);

      return mlContractHist;
    };
  }

  /**
   * レコード変換
   *
   * @param contract
   * @return
   */
  private Function<ForceUpdateContractBusinessBean, Contract> convertEntity(Contract contract) {
    return in -> {
      // 契約番号
      contract.setContractNo(in.getContractNo());
      // 支払ID
      contract.setPaymentId(in.getSelectPaymentId());
      // 契約開始日
      contract.setContractSd(in.getContractStartDate());
      // 契約終了日
      contract.setContractEd(in.getContractEndDate());
      // 契約終了理由コード
      contract.setContractEndReasonCode(in.getContractEndReasonCode());
      // 託送契約容量
      contract.setConsignmentCca(in.getConsignmentContractCapacity());
      // 託送契約容量単位コード
      contract.setConsignmentCcaUnit(in.getConsignmentcontractCapacityUnitCode());
      // 託送契約容量判定日
      contract.setConsignmentCcaDecisionDate(in.getConsignmentContractCapacityDecisionDate());
      // 料金チェックフラグ
      contract.setChargeCheckFlag(in.getChargeCheckFlag());
      // 契約グループ番号
      contract.setContractGroupNo(in.getContractGroupNo());
      // 連絡先個人・法人区分コード
      contract.setIlcCode(in.getContactInformationinDividualLegalEntityCategoryCode());
      // 連絡先氏名（カナ）
      contract.setCiNameKana(in.getContractInformationNameKana());
      // 連絡先氏名1
      contract.setCiName1(in.getContractInformationName1());
      // 連絡先氏名2
      contract.setCiName2(in.getContractInformationName2());
      // 連絡先住所（郵便番号）
      contract.setCiAddressPostalCode(in.getContractInformationAddressPostalCode());
      // 連絡先住所（住所）
      contract.setCiAddressFull(in.getContractInformationAddressFull());
      // 連絡先住所（建物・部屋名）
      contract.setCiAddressBuilding(in.getContractInformationAddressBuilding());
      //連絡先電話番号
      if (StringUtils.isNotEmpty(in.getContractInformationAreaCode())
          && StringUtils.isNotEmpty(in.getContractInformationLocalNo())
          && StringUtils.isNotEmpty(in.getContractInformationDirectoryNo())) {
        StringBuilder sb = new StringBuilder();
        sb.append(in.getContractInformationAreaCode()).append("-")
            .append(in.getContractInformationLocalNo()).append("-")
            .append(in.getContractInformationDirectoryNo());
        contract.setCiPhoneNo(sb.toString());
      }
      // 連絡先電話区分コード
      contract.setCiCatCode(in.getContractInformationCategoryCode());
      // 連絡先電話（市外局番）
      contract.setCiAreaCode(in.getContractInformationAreaCode());
      // 連絡先電話（市内局番）
      contract.setCiLocalNo(in.getContractInformationLocalNo());
      // 連絡先電話（加入者番号）
      contract.setCiDirectoryNo(in.getContractInformationDirectoryNo());
      // 需要者窓口連絡先所属
      contract.setCcAffiliation(in.getConsumerContractAffiliation());
      // 需要者窓口連絡先氏名
      contract.setCcName(in.getConsumerContractName());
      // 需要者窓口連絡先電話番号
      contract.setCcPhoneNo(in.getConsumerContractPhoneNo());
      // 需要者窓口連絡先電話番号（市外局番）
      contract.setCcAreaCode(in.getConsumerContractAreaCode());
      // 需要者窓口連絡先電話番号（市内局番）
      contract.setCcLocalNo(in.getConsumerContractLocalNo());
      // 需要者窓口連絡先電話番号（加入者番号）
      contract.setCcDirectoryNo(in.getConsumerContractDirectoryNo());
      // 主任技術者連絡先所属
      contract.setCeoAffiliation(in.getChiefEngineerOfficerAffiliation());
      // 主任技術者連絡先氏名
      contract.setCeoName(in.getChiefEngineerOfficerName());
      // 主任技術者連絡先電話番号
      contract.setCeoPhoneNo(in.getChiefEngineerOfficerPhoneNo());
      // 主任技術者連絡先電話番号（市外局番）
      contract.setCeoAreaCode(in.getChiefEngineerOfficerAreaCode());
      // 主任技術者連絡先電話番号（市内局番）
      contract.setCeoLocalNo(in.getChiefEngineerOfficerLocalNo());
      // 主任技術者連絡先電話番号（加入者番号）
      contract.setCeoDirectoryNo(in.getChiefEngineerOfficerDirectoryNo());
      // 接続送電サービス区分コード
      contract.setCssCatCode(in.getConnectedSupplyServiceCategoryCode());
      // フリー項目1
      contract.setFree1(in.getFree1());
      // フリー項目2
      contract.setFree2(in.getFree2());
      // フリー項目3
      contract.setFree3(in.getFree3());
      // フリー項目4
      contract.setFree4(in.getFree4());
      // フリー項目5
      contract.setFree5(in.getFree5());
      // フリー項目6
      contract.setFree6(in.getFree6());
      // フリー項目7
      contract.setFree7(in.getFree7());
      // フリー項目8
      contract.setFree8(in.getFree8());
      // フリー項目9
      contract.setFree9(in.getFree9());
      // フリー項目10
      contract.setFree10(in.getFree10());
      // フリー項目11
      contract.setFree11(in.getFree11());
      // フリー項目12
      contract.setFree12(in.getFree12());
      // フリー項目13
      contract.setFree13(in.getFree13());
      // フリー項目14
      contract.setFree14(in.getFree14());
      // 業種コード
      contract.setBusinessTypeCode(in.getBusinessTypeCode());
      // 営業委託先コード
      contract.setScCode(in.getSalesConsignmentCode());
      // 契約備考
      contract.setNote(in.getContractNote());
      // 適用開始日
      // 料金メニューID
      // 契約変更理由
      // 委託先使用項目1
      contract.setConsignmentUseItem1(in.getConsignmentUseItem1());
      // 委託先使用項目2
      contract.setConsignmentUseItem2(in.getConsignmentUseItem2());
      // 委託先使用項目3
      contract.setConsignmentUseItem3(in.getConsignmentUseItem3());
      // 自社担当者コード
      contract.setOurMngPersonInChargeCode(in.getOurManagementPersonInChargeCode());
      // 自社部署コード
      contract.setOurMngDepartmentCode(in.getOurManagementDepartmentCode());
      // 部分供給区分コード
      contract.setPsInfoCatCode(in.getPsInfoCatCode());
      // 更新回数
      contract.setUpdateCount(in.getUpdateCount() + 1);

      Timestamp systemTime = new Timestamp(System.currentTimeMillis());

      // オンライン更新日時
      contract.setOnlineUpdateTime(systemTime);

      // オンライン更新ユーザID
      contract.setOnlineUpdateUserId(ThreadContext.getRequestThreadContext()
          .get(ECISConstants.USER_ID_KEY).toString());

      // 更新モジュールコード
      contract.setUpdateModuleCode(ThreadContext.getRequestThreadContext()
          .get(ECISConstants.CLASS_NAME_KEY).toString());

      // 更新日時
      contract.setUpdateTime(systemTime);

      return contract;
    };

  }

  /**
   * 単価設定区分存在チェック<br>
   *
   * @param upCatCode
   *          単価設定区分
   * @return true チェックOK false チェックNG
   */
  private boolean existsUpCat(String upCatCode) {
    // 契約電力決定区分マスタ.検索（主キー）を呼び出し。
    UpsCategoryM upsCategoryM = upsCategoryMMapper.selectByPrimaryKey(upCatCode);
    return Objects.nonNull(upsCategoryM);
  }

  /**
   * 契約電力決定区分コード存在チェック<br>
   *
   * @param ccDecisionCategoryCode
   *          契約電力決定区分コード
   * @return true チェックOK false チェックNG
   */
  private boolean existsCcdCategory(String ccDecisionCategoryCode) {
    CcdCategoryM ccDecisionCatResult = ccdCategoryMMapper
        .selectByPrimaryKey(ccDecisionCategoryCode);
    return Objects.nonNull(ccDecisionCatResult);
  }

  /**
   * 営業委託先コード
   *
   * @param scCode
   * @return
   */
  private boolean existsSalesConsignmentCode(String scCode) {
    ScM result = this.scMMapper.selectByPrimaryKey(scCode);
    return Objects.nonNull(result);
  }

  /**
   * 契約容量単位マスタ
   *
   * @param ccaUnitCode
   * @return
   */
  private boolean existsConsignmentcontractCapacityUnitCode(String ccaUnitCode) {
    CcaUnitM result = this.ccaUnitMMapper.selectByPrimaryKey(ccaUnitCode);
    return Objects.nonNull(result);
  }

  /***
   * 接続送電サービス区分
   *
   * @param cssCatCode
   * @return
   */
  private boolean existsConnectedSupplyServiceCategoryCode(String cssCatCode) {
    CssCatM result = this.cssCatMMapper.selectByPrimaryKey(cssCatCode);
    return Objects.nonNull(result);
  }

  /**
   * 電話番号区分コード
   *
   * @param phoneNoCatCode
   * @return
   */
  private boolean existsContractInformationCategoryCode(String phoneNoCatCode) {
    PhoneNoCatM result = this.phoneNoCatMMapper.selectByPrimaryKey(phoneNoCatCode);
    return Objects.nonNull(result);
  }

  /**
   * 個人法人区分コード
   *
   * @param categoryCode
   * @return
   */
  private boolean existsDividualLegalCategoryCode(String categoryCode) {
    IlcM result = this.ilcMMapper.selectByPrimaryKey(categoryCode);
    return Objects.nonNull(result);
  }

  /**
   * 契約終了理由コード
   *
   * @param reasonCode
   * @return
   */
  private boolean existsContractEndReason(String reasonCode) {
    ContractEndReasonM result = this.contractEndReasonMMapper.selectByPrimaryKey(reasonCode);
    return Objects.nonNull(result);
  }

  /**
   * 戻り値作成
   *
   * @param id
   * @param value
   * @return
   */
  private Pair<String, String> createResult(String id, String[] value) {
    return Pair.of(id, messageSource.getMessage(KJ_CommonUtil.getMessageId(id), value, Locale.getDefault()));
  }

  /**
   * 契約マッパーのセッター(DI)
   *
   * @param contractMapper
   *          契約マッパー
   */
  public void setContractMapper(ContractMapper contractMapper) {
    this.contractMapper = contractMapper;
  }

  /**
   * 契約ℍ付加情報マッパーのセッター(DI)
   *
   * @param contractMapper
   *          契約マッパー
   */
  public void setContractAddInfoMapper(ContractAddInfoMapper contractAddInfoMapper) {
    this.contractAddInfoMapper = contractAddInfoMapper;
  }

  /**
   * 確定料金共通マッパーのセッター(DI)
   *
   * @param fixChargeResultInformationCommonMapper
   *          確定料金共通マッパー
   */
  public void setFixChargeResultInformationCommonMapper(
      FixChargeResultInformationCommonMapper fixChargeResultInformationCommonMapper) {
    this.fixChargeResultInformationCommonMapper = fixChargeResultInformationCommonMapper;
  }

  /**
   * 契約履歴マッパーのセッター(DI)
   *
   * @param contractHistMapper
   *          契約履歴マッパー
   */
  public void setContractHistMapper(ContractHistMapper contractHistMapper) {
    this.contractHistMapper = contractHistMapper;
  }

  /**
   * 電話番号区分マッパーのセッター(DI)
   *
   * @param phoneNoCatMMapper
   *          電話番号区分マッパー
   */
  public void setPhoneNoCatMMapper(PhoneNoCatMMapper phoneNoCatMMapper) {
    this.phoneNoCatMMapper = phoneNoCatMMapper;
  }

  /**
   * 接続送電サービス区分マスタマッパーのセッター(DI)
   *
   * @param cssCatMMapper
   *          接続送電サービス区分マスタマッパー
   */
  public void setCssCatMMapper(CssCatMMapper cssCatMMapper) {
    this.cssCatMMapper = cssCatMMapper;
  }

  /**
   * 契約終了理由マスタマッパーのセッター(DI)
   *
   * @param contractEndReasonMMapper
   *          契約終了理由マスタマッパー
   */
  public void setContractEndReasonMMapper(
      ContractEndReasonMMapper contractEndReasonMMapper) {
    this.contractEndReasonMMapper = contractEndReasonMMapper;
  }

  /**
   * 契約容量単位マスタマッパーのセッター(DI)
   *
   * @param ccaUnitMMapper
   *          契約容量単位マスタマッパー
   */
  public void setCcaUnitMMapper(CcaUnitMMapper ccaUnitMMapper) {
    this.ccaUnitMMapper = ccaUnitMMapper;
  }

  /**
   * 個人・法人区分マスタマッパーのセッター(DI)
   *
   * @param ilcMMapper
   *          個人・法人区分マスタマッパー
   */
  public void setIlcMMapper(IlcMMapper ilcMMapper) {
    this.ilcMMapper = ilcMMapper;
  }

  /**
   * 営業委託先マスタマッパーのセッター(DI)
   *
   * @param scMMapper
   *          営業委託先マスタマッパー
   */
  public void setScMMapper(ScMMapper scMMapper) {
    this.scMMapper = scMMapper;
  }

  /**
   * 料金メニューマッパーのセッター(DI)
   *
   * @param rmMapper
   *          料金メニューマッパー
   */
  public void setRmMapper(RmMapper rmMapper) {
    this.rmMapper = rmMapper;
  }

  /**
   * 提供モデル企業別料金メニューマスタマッパーのセッター(DI)
   *
   * @param rmMByPmCompanyMapper
   *          提供モデル企業別料金メニューマスタマッパー
   */
  public void setRmMByPmCompanyMapper(RmMByPmCompanyMapper rmMByPmCompanyMapper) {
    this.rmMByPmCompanyMapper = rmMByPmCompanyMapper;
  }

  /**
   * messageSourceのセッター(DI)
   *
   * @param messageSource
   *          メッセージソース
   *
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }

  /**
   * メータ設置場所情報共通マッパーのセッター(DI)
   *
   * @param meterLocationInformationCommonMapper
   *          メータ設置場所情報共通マッパー
   */
  public void setMeterLocationInformationCommonMapper(
      MeterLocationInformationCommonMapper meterLocationInformationCommonMapper) {
  }

  /**
   * 契約者情報共通ビジネスのセッター(DI)
   *
   * @param kjContractorInfomationBusiness
   *          契約者情報共通ビジネス
   */
  public void setKjContractorInfomationBusiness(
      KJ_ContractorInformationBusiness kjContractorInfomationBusiness) {
    this.kjContractorInfomationBusiness = kjContractorInfomationBusiness;
  }

  /**
   * 契約情報ビジネス(DI)
   */
  public void setKjContractInfomationBusiness(
      KJ_ContractInformationBusiness kjContractInfomationBusiness) {
    this.kjContractInfomationBusiness = kjContractInfomationBusiness;
  }

  /**
   * メータ設置場所情報共通ビジネスのセッター(DI)
   *
   * @param kjMeterLocationInformationBusiness
   *          メータ設置場所情報共通ビジネス
   */
  public void setKjMeterLocationInformationBusiness(
      KJ_MeterLocationInformationBusiness kjMeterLocationInformationBusiness) {
    this.kjMeterLocationInformationBusiness = kjMeterLocationInformationBusiness;
  }

  /**
   * 付帯契約情報マッパーのセッター(DI)
   *
   * @param splContractMapper
   *          付帯契約情報マッパー
   */
  public void setSplContractMapper(SplContractMapper splContractMapper) {
    this.splContractMapper = splContractMapper;
  }

  /**
   * 料金メニュー単価マスタマッパー(DI)
   *
   * @param rmUpMapper
   *          料金メニュー単価マスタマッパー
   */
  public void setRmUpMapper(RmUpMapper rmUpMapper) {
    this.rmUpMapper = rmUpMapper;
  }

  /**
   * 料金メニュー単価明細マッパー(DI)
   *
   * @param rmUpDetailMapper
   *          料金メニュー単価明細マッパー
   */
  public void setRmUpDetailMapper(RmUpDetailMapper rmUpDetailMapper) {
    this.rmUpDetailMapper = rmUpDetailMapper;
  }

  /**
   * 料金メニュー単価マッパー(DI)
   *
   * @param upsCategoryMMapper
   *          料金メニュー単価マッパー
   */
  public void setUpsCategoryMMapper(UpsCategoryMMapper upsCategoryMMapper) {
    this.upsCategoryMMapper = upsCategoryMMapper;
  }

  /**
   * 契約電力決定区分マスタマッパー(DI)
   */
  public void setCcdCategoryMMapper(CcdCategoryMMapper ccdCategoryMMapper) {
    this.ccdCategoryMMapper = ccdCategoryMMapper;
  }

  /**
   * メータ設置場所契約履歴マッパー(DI)
   *
   * @param mlContractHistMapper
   */
  public void setMlContractHistMapper(MlContractHistMapper mlContractHistMapper) {
    this.mlContractHistMapper = mlContractHistMapper;
  }

  /**
   * 卸取次店向け契約情報共通マッパー(DI)
   */
  public void setAgentContractInformationCommonMapper(
      AgentContractInformationCommonMapper contractInformationCommonMapper) {
    this.contractInformationCommonMapper = contractInformationCommonMapper;
  }

  /**
   * トランザクションマネージャを設定する。(DI)
   *
   * @param txManager
   *          トランザクションマネージャ
   */
  public void setTxManager(DataSourceTransactionManager txManager) {
    this.txManager = txManager;
  }

  /**
   * 契約情報更新コンテキスト
   */
  class UpdateContractContext {

    /** オンライン処理基準日 */
    Date onlineDate;

    /** 結果コード */
    Pair<String, String> result;

    /** 契約照会情報 */
    KJ_InquiryContractInformationEntityBean contract;

    /** 契約者照会情報 */
    KJ_InquiryContractorInformationEntityBean contractor;

    /** 料金メニュー */
    Rm rm;

    public Rm getRm() {
      return rm;
    }

    public void setRm(Rm rm) {
      this.rm = rm;
    }

    public Pair<String, String> getResult() {
      return result;
    }

    public void setResult(Pair<String, String> result) {
      this.result = result;
    }

    public KJ_InquiryContractInformationEntityBean getContract() {
      return contract;
    }

    public void setContract(KJ_InquiryContractInformationEntityBean contract) {
      this.contract = contract;
    }

    public KJ_InquiryContractorInformationEntityBean getContractor() {
      return contractor;
    }

    public void setContractor(KJ_InquiryContractorInformationEntityBean contractor) {
      this.contractor = contractor;
    }

  }

}
