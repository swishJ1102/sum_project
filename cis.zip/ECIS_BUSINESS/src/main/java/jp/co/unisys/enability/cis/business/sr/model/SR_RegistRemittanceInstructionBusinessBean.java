package jp.co.unisys.enability.cis.business.sr.model;

import jp.co.unisys.enability.cis.business.sn.model.SN_CreateMailBusinessBean;

/**
 * 送金指示登録BusinessBean
 *
 * @author "Nihon Unisys, Ltd."
 */
public class SR_RegistRemittanceInstructionBusinessBean  extends SN_CreateMailBusinessBean {

    /** 利用年月 */
    private String usePeriod;

    /** 請求額 */
    private Long blAmount;

    /** 支払期日 */
    private String pfd;

    /** 決済予定日 */
    private String settlementScheduledDate;

    /** メール送信日 */
    private String mailSendDate;

    /**
     * 利用年月を取得する。
     *
     * @return 利用年月
     */
    public String getUsePeriod() {
        return usePeriod;
    }

    /**
     * 利用年月を設定する。
     *
     * @param usePeriod 利用年月
     */
    public void setUsePeriod(String usePeriod) {
        this.usePeriod = usePeriod;
    }

    /**
     * 請求額を取得する。
     *
     * @return 請求額
     */
    public Long getBlAmount() {
        return blAmount;
    }

    /**
     * 請求額を設定する。
     *
     * @param blAmount 請求額
     */
    public void setBlAmount(Long blAmount) {
        this.blAmount = blAmount;
    }

    /**
     * 支払期日を取得する。
     *
     * @return 支払期日
     */
    public String getPfd() {
        return pfd;
    }

    /**
     * 支払期日を設定する。
     *
     * @param pfd 支払期日
     */
    public void setPfd(String pfd) {
        this.pfd = pfd;
    }

    /**
     * メール送信日を取得する。
     *
     * @return メール送信日
     */
    public String getMailSendDate() {
        return mailSendDate;
    }

    /**
     * メール送信日を設定する。
     *
     * @param mailSendDate メール送信日
     */
    public void setMailSendDate(String mailSendDate) {
        this.mailSendDate = mailSendDate;
    }

    /**
     * 決済予定日を取得する。
     *
     * @return 決済予定日
     */
    public String getSettlementScheduledDate() {
        return settlementScheduledDate;
    }

    /**
     * 決済予定日を設定する。
     *
     * @param settlementScheduledDate 決済予定日
     */
    public void setSettlementScheduledDate(String settlementScheduledDate) {
        this.settlementScheduledDate = settlementScheduledDate;
    }

}
