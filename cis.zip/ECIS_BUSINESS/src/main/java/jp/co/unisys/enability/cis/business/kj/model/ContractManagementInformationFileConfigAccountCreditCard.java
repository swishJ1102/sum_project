package jp.co.unisys.enability.cis.business.kj.model;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * 口座クレカ情報登録・更新（一括登録）BusinessBean
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * 口座クレカ情報ビジネス
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class ContractManagementInformationFileConfigAccountCreditCard {

  /** ファイル名接頭辞 */
  public static final String FILE_NAME_PREFIX = "accountCreditCard_";

  // ヘッダレコード定義
  /** ヘッダレコード：ファイル種別-パラメータ */
  public static final String HEADER_FILE_KIND_PARAM = "3";

  public static final String DATA_FILE_KIND_MASK_STRING = "^"
      + HEADER_FILE_KIND_PARAM + "$";

  // データレコード定義
  public static final String[] DATA_TITLE_ROW;
  /** データレコード：項目数 */
  public static final int DATA_COLUMN_COUNT;

  // 契約者番号
  /** データレコード：契約者番号-インデックス */
  public static final int DATA_CONTRACTOR_NO_INDEX = 1;
  /** データレコード：契約者番号-名称 */
  public static final String DATA_CONTRACTOR_NO_NAME = "契約者番号";
  /** データレコード：契約者番号-文字数 */
  public static final int DATA_CONTRACTOR_NO_LENGTH = 25;
  /** データレコード：契約者番号-文字数（文字列） */
  public static final String DATA_CONTRACTOR_NO_LENGTH_STRING = String
      .valueOf(DATA_CONTRACTOR_NO_LENGTH);

  // 口座クレカID
  /** データレコード：口座クレカID-インデックス */
  public static final int DATA_ACCOUNT_CREDIT_CARD_ID_INDEX = 2;
  /** データレコード：口座クレカID-名称 */
  public static final String DATA_ACCOUNT_CREDIT_CARD_ID_NAME = "口座クレカID";

  // 決済アクセスキー
  /** データレコード：決済アクセスキー-インデックス */
  public static final int DATA_ACCESS_KEY_INDEX = 3;
  /** データレコード：決済アクセスキー-名称 */
  public static final String DATA_ACCESS_KEY_NAME = "決済アクセスキー";
  /** データレコード：決済アクセスキー-文字数 */
  public static final int DATA_ACCESS_KEY_LENGTH = 24;
  /** データレコード：決済アクセスキー-文字数（文字列） */
  public static final String DATA_ACCESS_KEY_LENGTH_STRING = String
      .valueOf(DATA_ACCESS_KEY_LENGTH);

  // 口座クレカ区分コード
  /** データレコード：口座クレカ区分コード-インデックス */
  public static final int DATA_ACCOUNT_CREDIT_CARD_CATEGORY_CODE_INDEX = 4;
  /** データレコード：口座クレカ区分コード-名称 */
  public static final String DATA_ACCOUNT_CREDIT_CARD_CATEGORY_CODE_NAME = "口座クレカ区分コード";
  /** データレコード：口座クレカ区分コード-文字数 */
  public static final int DATA_ACCOUNT_CREDIT_CARD_CATEGORY_CODE_LENGTH = 1;
  /** データレコード：口座クレカ区分コード-文字数（文字列） */
  public static final String DATA_ACCOUNT_CREDIT_CARD_CATEGORY_CODE_LENGTH_STRING = String
      .valueOf(DATA_ACCOUNT_CREDIT_CARD_CATEGORY_CODE_LENGTH);

  // 金融機関コード
  /** データレコード：金融機関コード-インデックス */
  public static final int DATA_BANK_CODE_INDEX = 5;
  /** データレコード：金融機関コード-名称 */
  public static final String DATA_BANK_CODE_NAME = "金融機関コード";
  /** データレコード：金融機関コード-文字数 */
  public static final int DATA_BANK_CODE_LENGTH = 4;
  /** データレコード：金融機関コード-文字数（文字列） */
  public static final String DATA_BANK_CODE_LENGTH_STRING = String
      .valueOf(DATA_BANK_CODE_LENGTH);

  // 金融機関支店コード
  /** データレコード：金融機関支店コード-インデックス */
  public static final int DATA_BANK_BRANCH_CODE_INDEX = 6;
  /** データレコード：金融機関支店コード-名称 */
  public static final String DATA_BANK_BRANCH_CODE_NAME = "金融機関支店コード";
  /** データレコード：金融機関支店コード-文字数 */
  public static final int DATA_BANK_BRANCH_CODE_LENGTH = 3;
  /** データレコード：金融機関支店コード-文字数（文字列） */
  public static final String DATA_BANK_BRANCH_CODE_LENGTH_STRING = String
      .valueOf(DATA_BANK_BRANCH_CODE_LENGTH);

  // 金融機関預金種目コード
  /** データレコード：金融機関預金種目コード-インデックス */
  public static final int DATA_BANK_TYPE_OF_ACCOUNT_CODE_INDEX = 7;
  /** データレコード：金融機関預金種目コード-名称 */
  public static final String DATA_BANK_TYPE_OF_ACCOUNT_CODE_NAME = "金融機関預金種目コード";
  /** データレコード：金融機関預金種目コード-文字数 */
  public static final int DATA_BANK_TYPE_OF_ACCOUNT_CODE_LENGTH = 1;
  /** データレコード：金融機関預金種目コード-文字数（文字列） */
  public static final String DATA_BANK_TYPE_OF_ACCOUNT_CODE_LENGTH_STRING = String
      .valueOf(DATA_BANK_TYPE_OF_ACCOUNT_CODE_LENGTH);

  // 口座番号
  /** データレコード：口座番号-インデックス */
  public static final int DATA_ACCOUNT_NO_INDEX = 8;
  /** データレコード：口座番号-名称 */
  public static final String DATA_ACCOUNT_NO_NAME = "口座番号";
  /** データレコード：口座番号-文字数 */
  public static final int DATA_ACCOUNT_NO_LENGTH = 7;
  /** データレコード：口座番号-文字数（文字列） */
  public static final String DATA_ACCOUNT_NO_LENGTH_STRING = String
      .valueOf(DATA_ACCOUNT_NO_LENGTH);

  // 口座名義
  /** データレコード：口座名義-インデックス */
  public static final int DATA_ACCOUNT_HOLDER_NAME_INDEX = 9;
  /** データレコード：口座名義-名称 */
  public static final String DATA_ACCOUNT_HOLDER_NAME_NAME = "口座名義";
  /** データレコード：口座名義-文字数 */
  public static final int DATA_ACCOUNT_HOLDER_NAME_LENGTH = 30;
  /** データレコード：口座名義-文字数（文字列） */
  public static final String DATA_ACCOUNT_HOLDER_NAME_LENGTH_STRING = String
      .valueOf(DATA_ACCOUNT_HOLDER_NAME_LENGTH);

  // クレカ番号
  /** データレコード：クレカ番号-インデックス */
  public static final int DATA_CREDIT_CARD_NO_INDEX = 10;
  /** データレコード：クレカ番号-名称 */
  public static final String DATA_CREDIT_CARD_NO_NAME = "クレカ番号";
  /** データレコード：クレカ番号-文字数 */
  public static final int DATA_CREDIT_CARD_NO_LENGTH = 4;
  /** データレコード：クレカ番号-文字数（文字列） */
  public static final String DATA_CREDIT_CARD_NO_LENGTH_STRING = String
      .valueOf(DATA_CREDIT_CARD_NO_LENGTH);

  // クレカ有効期限
  /** データレコード：クレカ有効期限-インデックス */
  public static final int DATA_CREDIT_CARD_EXPIRATION_DATE_INDEX = 11;
  /** データレコード：クレカ有効期限-名称 */
  public static final String DATA_CREDIT_CARD_EXPIRATION_DATE_NAME = "クレカ有効期限";
  /** データレコード：クレカ有効期限-文字数 */
  public static final int DATA_CREDIT_CARD_EXPIRATION_DATE_LENGTH = 6;
  /** データレコード：クレカ有効期限-文字数（文字列） */
  public static final String DATA_CREDIT_CARD_EXPIRATION_DATE_LENGTH_STRING = String
      .valueOf(DATA_CREDIT_CARD_EXPIRATION_DATE_LENGTH);

  // クレカブランドコード
  /** データレコード：クレカブランドコード-インデックス */
  public static final int DATA_CREDIT_CARD_BRAND_CODE_INDEX = 12;
  /** データレコード：クレカブランドコード-名称 */
  public static final String DATA_CREDIT_CARD_BRAND_CODE_NAME = "クレカブランドコード";
  /** データレコード：クレカブランドコード-文字数 */
  public static final int DATA_CREDIT_CARD_BRAND_CODE_LENGTH = 1;
  /** データレコード：クレカブランドコード-文字数（文字列） */
  public static final String DATA_CREDIT_CARD_BRAND_CODE_LENGTH_STRING = String
      .valueOf(DATA_CREDIT_CARD_BRAND_CODE_LENGTH);

  // 利用不能フラグ
  /** データレコード：利用不能フラグ-インデックス */
  public static final int DATA_UNAVAILABLE_FLAG_INDEX = 13;
  /** データレコード：利用不能フラグ-名称 */
  public static final String DATA_UNAVAILABLE_FLAG_NAME = "利用不能フラグ";
  /** データレコード：利用不能フラグ-文字数 */
  public static final int DATA_UNAVAILABLE_FLAG_LENGTH = 1;
  /** データレコード：利用不能フラグ-文字数（文字列） */
  public static final String DATA_UNAVAILABLE_FLAG_LENGTH_STRING = String
      .valueOf(DATA_UNAVAILABLE_FLAG_LENGTH);

  // 登録区分
  /** データレコード：登録区分-インデックス */
  public static final int DATA_REGISTER_CATEGORY_INDEX = 14;
  /** データレコード：登録区分-名称 */
  public static final String DATA_REGISTER_CATEGORY_NAME = "登録区分";
  /** データレコード：登録区分-文字数 */
  public static final int DATA_REGISTER_CATEGORY_LENGTH = 1;
  /** データレコード：登録区分-文字数（文字列） */
  public static final String DATA_REGISTER_CATEGORY_LENGTH_STRING = String
      .valueOf(DATA_REGISTER_CATEGORY_LENGTH);

  // エラーメッセージ出力用文言
  /** 金融機関コードまたは金融機関支店コード */
  public static final String DATA_BANK_CODE_OR_BANK_BRANCH_CODE_NAME = "金融機関コードまたは金融機関支店コード";
  /** クレジットカード払い */
  public static final String DATA_CREDIT_CARD_PAYMENT_NAME = "クレジットカード払い";
  /** 口座振替 */
  public static final String DATA_ACCOUNT_TRANSFER_NAME = "口座振替";
  /** 請求時振込先（自社口座）もしくは購入時振込先 */
  public static final String DATA_BILLING_TIME_TRANSFER_OR_PURCHASE_TIME_TRANSFER_NAME = "請求時振込先（自社口座）もしくは購入時振込先";

  /**
   * staticイニシャライザ.<br>
   * タイトル行の生成を行う<br>
   * インデックス=タイトル配列のインデックスになるため、番号は自動で設定される<br>
   * カラムの追加・削除があった場合に修正が必要
   */
  static {
    Map<Integer, String> titleMap = new HashMap<Integer, String>();

    // 項目を順番に入れ込んでいく
    // レコード種別は共通のものを使う
    titleMap.put(
        ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_INDEX,
        ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_NAME);

    titleMap.put(DATA_CONTRACTOR_NO_INDEX, DATA_CONTRACTOR_NO_NAME);
    titleMap.put(DATA_ACCOUNT_CREDIT_CARD_ID_INDEX,
        DATA_ACCOUNT_CREDIT_CARD_ID_NAME);
    titleMap.put(DATA_ACCESS_KEY_INDEX, DATA_ACCESS_KEY_NAME);
    titleMap.put(DATA_ACCOUNT_CREDIT_CARD_CATEGORY_CODE_INDEX,
        DATA_ACCOUNT_CREDIT_CARD_CATEGORY_CODE_NAME);
    titleMap.put(DATA_BANK_CODE_INDEX, DATA_BANK_CODE_NAME);
    titleMap.put(DATA_BANK_BRANCH_CODE_INDEX, DATA_BANK_BRANCH_CODE_NAME);
    titleMap.put(DATA_BANK_TYPE_OF_ACCOUNT_CODE_INDEX,
        DATA_BANK_TYPE_OF_ACCOUNT_CODE_NAME);
    titleMap.put(DATA_ACCOUNT_NO_INDEX, DATA_ACCOUNT_NO_NAME);
    titleMap.put(DATA_ACCOUNT_HOLDER_NAME_INDEX,
        DATA_ACCOUNT_HOLDER_NAME_NAME);
    titleMap.put(DATA_CREDIT_CARD_NO_INDEX, DATA_CREDIT_CARD_NO_NAME);
    titleMap.put(DATA_CREDIT_CARD_EXPIRATION_DATE_INDEX,
        DATA_CREDIT_CARD_EXPIRATION_DATE_NAME);
    titleMap.put(DATA_CREDIT_CARD_BRAND_CODE_INDEX,
        DATA_CREDIT_CARD_BRAND_CODE_NAME);
    titleMap.put(DATA_UNAVAILABLE_FLAG_INDEX, DATA_UNAVAILABLE_FLAG_NAME);
    titleMap.put(DATA_REGISTER_CATEGORY_INDEX, DATA_REGISTER_CATEGORY_NAME);

    // タイトル文字列に書き換える
    Iterator<Integer> it = titleMap.keySet().iterator();
    String[] titleArray = new String[titleMap.size()];
    while (it.hasNext()) {
      Integer key = it.next();
      titleArray[key] = titleMap.get(key);
    }

    DATA_TITLE_ROW = titleArray;
    DATA_COLUMN_COUNT = DATA_TITLE_ROW.length;
  }

}
