package jp.co.unisys.enability.cis.business.kj.model;

/**
 * 契約管理情報アップロード画面で、アップロードファイル情報とThreadContextの情報を保持するクラス
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * 契約管理情報アップロードビジネス
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class S010101_ContractManagementInformationUploadBusinessBean {

  /**
   * アップロードファイル保存フォルダパスを保有する。
   */
  private String uploadFilePath;

  /**
   * コンテキスト情報：ユーザIDを保有する。
   */
  private String userId;

  /**
   * コンテキスト情報：モジュールコードを保有する。
   */
  private String moduleCode;

  /**
   * コンテキスト情報：セッションIDを保有する。
   */
  private String sessionId;

  /**
   * コンテキスト情報：オンラインフラグを保有する。
   */
  private String onlineFlag;

  /**
   * アップロードファイル保存フォルダパスのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * アップロードファイル保存フォルダパスを設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   */
  public String getUploadFilePath() {
    return uploadFilePath;
  }

  /**
   * アップロードファイル保存フォルダパスのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * アップロードファイル保存フォルダパスを設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param uploadFilePath
   *          アップロードファイル保存フォルダパス
   */
  public void setUploadFilePath(String uploadFilePath) {
    this.uploadFilePath = uploadFilePath;
  }

  /**
   * ユーザIDのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * ユーザIDを取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return ユーザID
   */
  public String getUserId() {
    return this.userId;
  }

  /**
   * ユーザIDのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * ユーザIDを設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param userId
   *          ユーザID
   */
  public void setUserId(String userId) {
    this.userId = userId;
  }

  /**
   * モジュールコードのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * モジュールコードを取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return モジュールコード
   */
  public String getModuleCode() {
    return moduleCode;
  }

  /**
   * モジュールコードのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * モジュールコードを設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param moduleCode
   *          モジュールコード
   */
  public void setModuleCode(String moduleCode) {
    this.moduleCode = moduleCode;
  }

  /**
   * セッションIDのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * セッションIDを取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return セッションID
   */
  public String getSessionId() {
    return sessionId;
  }

  /**
   * セッションIDのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * セッションIDを設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param sessionId
   *          セッションID
   */
  public void setSessionId(String sessionId) {
    this.sessionId = sessionId;
  }

  /**
   * オンラインフラグのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * オンラインフラグを取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return オンラインフラグ
   */
  public String getOnlineFlag() {
    return onlineFlag;
  }

  /**
   * オンラインフラグのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * オンラインフラグを設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param onlineFlag
   *          オンラインフラグ
   */
  public void setOnlineFlag(String onlineFlag) {
    this.onlineFlag = onlineFlag;
  }

}
