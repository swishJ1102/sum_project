package jp.co.unisys.enability.cis.business.kj.model;

import java.util.Date;
import java.util.List;

import jp.co.unisys.enability.cis.entity.kj.KJ_InquiryAgentContractInformationEntityBean;

/**
 * 契約情報照会で、検索条件および検索結果を格納するビジネスBean
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * 契約者情報ビジネス
 * 契約情報照会ビジネス
 * 支払情報ビジネス
 * 付帯契約情報ビジネス
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class InquiryAgentContractBusinessBean {

  /**
   * 契約IDを保有する。
   */
  private Integer contractId;

  /**
   * 契約番号を保有する。
   */
  private String contractNo;

  /**
   * 契約者IDを保有する。
   */
  private Integer contractorId;

  /**
   * 契約者番号を保有する。
   */
  private String contractorNo;

  /**
   * 支払IDを保有する。
   */
  private Integer paymentId;

  /**
   * 支払番号を保有する。
   */
  private String paymentNo;

  /**
   * 照会対象日付を保有する。
   */
  private Date inqCoveredDate;

  /**
   * 契約情報リストを保有する。
   */
  private List<KJ_InquiryAgentContractInformationEntityBean> agentContractInformationList;

  /**
   * リターンコードを保有する。
   */
  private String returnCode;

  /**
   * メッセージを保有する。
   */
  private String message;

  /**
   * 契約IDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約IDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約ID
   */
  public Integer getContractId() {
    return this.contractId;
  }

  /**
   * 契約IDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約IDを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractId
   *          契約ID
   */
  public void setContractId(Integer contractId) {
    this.contractId = contractId;
  }

  /**
   * 契約番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約番号を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約番号
   */
  public String getContractNo() {
    return this.contractNo;
  }

  /**
   * 契約番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約番号を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractNo
   *          契約番号
   */
  public void setContractNo(String contractNo) {
    this.contractNo = contractNo;
  }

  /**
   * 契約者IDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者IDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者ID
   */
  public Integer getContractorId() {
    return this.contractorId;
  }

  /**
   * 契約者IDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者IDを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorId
   *          契約者ID
   */
  public void setContractorId(Integer contractorId) {
    this.contractorId = contractorId;
  }

  /**
   * 契約者番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者番号を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者番号
   */
  public String getContractorNo() {
    return this.contractorNo;
  }

  /**
   * 契約者番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者番号を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorNo
   *          契約者番号
   */
  public void setContractorNo(String contractorNo) {
    this.contractorNo = contractorNo;
  }

  /**
   * 支払IDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 支払IDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 支払ID
   */
  public Integer getPaymentId() {
    return this.paymentId;
  }

  /**
   * 支払IDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 支払IDを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param paymentId
   *          支払ID
   */
  public void setPaymentId(Integer paymentId) {
    this.paymentId = paymentId;
  }

  /**
   * 支払番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 支払番号を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 支払番号
   */
  public String getPaymentNo() {
    return this.paymentNo;
  }

  /**
   * 支払番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 支払番号を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param paymentNo
   *          支払番号
   */
  public void setPaymentNo(String paymentNo) {
    this.paymentNo = paymentNo;
  }

  /**
   * 照会対象日付のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 照会対象日付を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 照会対象日付
   */
  public Date getInqCoveredDate() {
    return this.inqCoveredDate;
  }

  /**
   * 照会対象日付のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 照会対象日付を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param inqCoveredDate
   *          照会対象日付
   */
  public void setInqCoveredDate(Date inqCoveredDate) {
    this.inqCoveredDate = inqCoveredDate;
  }

  /**
   * 契約情報リストのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約情報リストを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約情報リスト
   */
  public List<KJ_InquiryAgentContractInformationEntityBean> getAgentContractInformationList() {
    return this.agentContractInformationList;
  }

  /**
   * 契約情報リストのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約情報リストを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param agentContractInformationList
   *          契約情報リスト
   */
  public void setAgentContractInformationList(
      List<KJ_InquiryAgentContractInformationEntityBean> agentContractInformationList) {
    this.agentContractInformationList = agentContractInformationList;
  }

  /**
   * リターンコードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return リターンコード
   */
  public String getReturnCode() {
    return this.returnCode;
  }

  /**
   * リターンコードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param returnCode
   *          リターンコード
   */
  public void setReturnCode(String returnCode) {
    this.returnCode = returnCode;
  }

  /**
   * メッセージのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return メッセージ
   */
  public String getMessage() {
    return this.message;
  }

  /**
   * メッセージのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param message
   *          メッセージ
   */
  public void setMessage(String message) {
    this.message = message;
  }

}
