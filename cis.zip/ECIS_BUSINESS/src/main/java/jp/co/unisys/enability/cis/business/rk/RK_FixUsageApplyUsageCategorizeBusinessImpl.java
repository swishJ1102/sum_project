package jp.co.unisys.enability.cis.business.rk;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import jp.co.unisys.enability.cis.business.gk.CalendarBusiness;
import jp.co.unisys.enability.cis.business.rk.model.RK_FixUsageApplyCategorizeResultBusinessBean;
import jp.co.unisys.enability.cis.business.rk.model.RK_FixUsageApplyTimeCategorizeResultBusinessBean;
import jp.co.unisys.enability.cis.business.rk.model.RK_FixUsageApplyUsageBusinessBean;
import jp.co.unisys.enability.cis.dao.rk.RK_FixUsageApplyDao;
import jp.co.unisys.enability.cis.entity.common.ContractHist;
import jp.co.unisys.enability.cis.entity.rk.RK_FixUsageApplyRateMenuTimeSlotEntityBean;

/**
 * 使用量仕訳ビジネスクラス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_FixUsageApplyUsageCategorizeBusinessImpl implements
    RK_FixUsageApplyUsageCategorizeBusiness {

  /** 日付を月日(MMdd)でフォーマットする文字列 */
  private static final String FORMAT_DATE_MMDD = "MMdd";

  /** カレンダービジネス(DI) */
  private CalendarBusiness calendarBusiness;

  /** 確定使用量情報反映Dao(DI) */
  private RK_FixUsageApplyDao rkFixUsageApplyDao;

  /** 確定使用量共通ビジネス(DI) */
  private RK_FixUsageCommonBusiness rkFixUsageCommonBusiness;

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.rk.
   * RK_FixUsageApplyUsageCategorizeBusiness#categorize(java.lang.String,
   * java.util.List)
   */
  @Override
  public List<RK_FixUsageApplyCategorizeResultBusinessBean> categorize(
      List<ContractHist> contractHistList,
      List<RK_FixUsageApplyUsageBusinessBean> usageBusinessBeanList) {

    // 仕訳を行う時間帯の情報を取得
    List<RK_FixUsageApplyRateMenuTimeSlotEntityBean> timeSlotList = rkFixUsageApplyDao
        .selectRateMenuTimeSlot(contractHistList.get(0).getRmId());

    // 引数のリストを年月日の昇順でソートする
    usageBusinessBeanList.sort(Comparator
        .comparing(RK_FixUsageApplyUsageBusinessBean::getUsageDate));

    // 算定期間開始日・終了日の取得
    // リストを日付順でソートしてあるため、最初と最後の項目がそれぞれ開始日・終了日となる
    Date startUsageDate = usageBusinessBeanList.get(0).getUsageDate();
    Date endUsageDate = usageBusinessBeanList.get(
        usageBusinessBeanList.size() - 1).getUsageDate();

    // 結果のリストを作成
    List<RK_FixUsageApplyCategorizeResultBusinessBean> resultList = new ArrayList<RK_FixUsageApplyCategorizeResultBusinessBean>();

    // 日付のフォーマット（MMdd）
    SimpleDateFormat dateFormat = new SimpleDateFormat(FORMAT_DATE_MMDD);

    RK_FixUsageApplyCategorizeResultBusinessBean newResult = null;

    // 契約履歴毎に繰り返し
    for (ContractHist contractHist : contractHistList) {
      // ループの初回か、グループ(日割開始日)が変わった場合に、仕訳結果を格納するBeanを生成する
      if (newResult == null
          || (!newResult.getDateSlotStartDate().equals(
              contractHist.getApplySd()))) {

        // Beanを生成し、時間帯の情報を設定する
        newResult = new RK_FixUsageApplyCategorizeResultBusinessBean();
        // 日割開始日
        newResult.setDateSlotStartDate(contractHist.getApplySd());
        // 日割終了日
        newResult.setDateSlotEndDate(contractHist.getApplyEd());
        // 契約容量
        newResult.setContractCapacity(contractHist.getCca());
        // 仕訳後使用量
        newResult.setCategorizedUsage(BigDecimal.ZERO);
        // 仕訳結果時間帯リスト
        newResult.setFixUsageApplyTimeCategorizeResultList(
            new ArrayList<RK_FixUsageApplyTimeCategorizeResultBusinessBean>());

        // Beanをリストに追加
        resultList.add(newResult);
      }

      RK_FixUsageApplyTimeCategorizeResultBusinessBean newResultSub = null;

      // 時間帯の仕訳情報毎に繰り返し
      for (RK_FixUsageApplyRateMenuTimeSlotEntityBean timeSlot : timeSlotList) {
        // ループの初回か、グループ(時間帯)が変わった場合に、仕訳結果を格納するBeanを生成する
        if (newResultSub == null
            || (!newResultSub.getTimeSlotCode().equals(timeSlot.getTimeSlotCode()))) {

          // Beanを生成し、時間帯の情報を設定する
          newResultSub = new RK_FixUsageApplyTimeCategorizeResultBusinessBean();
          // 時間帯コード
          newResultSub.setTimeSlotCode(timeSlot.getTimeSlotCode());
          // 表示順
          newResultSub.setDisplayOrder(timeSlot.getDisplayOrder());
          // 時間帯名称
          newResultSub.setTimeSlotName(timeSlot.getTimeSlotName());
          // 仕訳後使用量
          newResultSub.setCategorizedUsage(BigDecimal.ZERO);

          // Beanをリストに追加
          newResult.getFixUsageApplyTimeCategorizeResultList().add(newResultSub);
        }

        // カレンダー対象列名がnullでない場合には、仕訳対象となる日付のリストを取得
        List<Date> dateList = null;
        if (timeSlot.getCalendarCoveredColumnName() != null) {

          // 【料金メニュー時間帯詳細】の条件で日付のリストを取得
          dateList = calendarBusiness.selectCoveredDateList(
              timeSlot.getCalendarCoveredColumnName(),
              timeSlot.getCoveredValue(), startUsageDate, endUsageDate);
        }

        // 使用量毎の繰り返し
        for (RK_FixUsageApplyUsageBusinessBean usage : usageBusinessBeanList) {

          // 年月を数値化
          int usageMmdd = Integer.parseInt(dateFormat.format(usage.getUsageDate()));

          // 仕訳の条件と一致する場合には、結果に使用量を加算する
          if ((dateList == null || dateList.contains(usage.getUsageDate()))
              && usageMmdd >= Integer.parseInt(timeSlot.getStartMmdd())
              && usageMmdd <= Integer.parseInt(timeSlot.getEndMmdd())
              && usage.getUsageDate().compareTo(contractHist.getApplySd()) >= 0
              && usage.getUsageDate().compareTo(contractHist.getApplyEd()) <= 0) {

            // 開始時分、終了時分をそれぞれ0～47の序数に変換
            int startHhmm = rkFixUsageCommonBusiness.convertHmToOrdinal(timeSlot.getStartHhmm());
            int endHhmm = rkFixUsageCommonBusiness.convertHmToOrdinal(timeSlot.getEndHhmm());

            // 開始時分から終了時分までの使用量を合計する
            BigDecimal total = BigDecimal.ZERO;
            for (int index = startHhmm; index <= endHhmm; index++) {
              total = total.add(usage.getUsageList().get(index));
            }

            // 合計値を仕訳後使用量に加算
            newResultSub.setCategorizedUsage(newResultSub.getCategorizedUsage().add(total));
          }
        }

        // 時間帯が料金算定期間内の場合、しわ取り優先順位を設定する
        // ※時間帯が料金算定期間外の場合は、しわ取り優先順位がNULLとなり、後続のしわ取りの際に増減の対象外となる
        String stUsageMmdd = dateFormat.format(startUsageDate);
        String edUsageMmdd = dateFormat.format(endUsageDate);
        if (timeSlot.getStartMmdd().compareTo(edUsageMmdd) <= 0
            && timeSlot.getEndMmdd().compareTo(stUsageMmdd) >= 0) {
          newResultSub.setCuPriorityOrder(timeSlot.getCuPriorityOrder());
        }
      }
    }

    // 仕訳後使用量の丸め（小数部第１位を四捨五入）
    for (RK_FixUsageApplyCategorizeResultBusinessBean categorized : resultList) {
      for (RK_FixUsageApplyTimeCategorizeResultBusinessBean categorizedSub : categorized
          .getFixUsageApplyTimeCategorizeResultList()) {
        BigDecimal roundUsage = rkFixUsageCommonBusiness.roundUsage(categorizedSub
            .getCategorizedUsage());
        categorizedSub.setCategorizedUsage(roundUsage);
        categorized.setCategorizedUsage(categorized.getCategorizedUsage().add(roundUsage));
      }
    }

    return resultList;
  }

  /**
   * カレンダービジネスを設定します。(DI)
   *
   * @param calendarBusiness
   *          カレンダービジネス
   */
  public void setCalendarBusiness(CalendarBusiness calendarBusiness) {
    this.calendarBusiness = calendarBusiness;
  }

  /**
   * 確定使用量情報反映Daoを設定します。(DI)
   *
   * @param rkFixUsageApplyDao
   *          確定使用量情報反映Dao
   */
  public void setRkFixUsageApplyDao(RK_FixUsageApplyDao rkFixUsageApplyDao) {
    this.rkFixUsageApplyDao = rkFixUsageApplyDao;
  }

  /**
   * 確定使用量共通ビジネスを設定します。(DI)
   *
   * @param rkFixUsageCommonBusiness
   *          確定使用量共通ビジネス
   */
  public void setRkFixUsageCommonBusiness(
      RK_FixUsageCommonBusiness rkFixUsageCommonBusiness) {
    this.rkFixUsageCommonBusiness = rkFixUsageCommonBusiness;
  }

}
