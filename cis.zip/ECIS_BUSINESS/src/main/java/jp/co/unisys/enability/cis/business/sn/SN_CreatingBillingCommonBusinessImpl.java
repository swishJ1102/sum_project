package jp.co.unisys.enability.cis.business.sn;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;

import jp.co.unisys.enability.cis.business.common.DateBusiness;
import jp.co.unisys.enability.cis.common.util.DateCalculateUtil;
import jp.co.unisys.enability.cis.common.util.EMSConstants;
import jp.co.unisys.enability.cis.common.util.StringConvertUtil;
import jp.co.unisys.enability.cis.common.util.constants.ECISCodeConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISKJConstants;
import jp.co.unisys.enability.cis.entity.common.Fcr;
import jp.co.unisys.enability.cis.entity.sn.SN_BillingFixChargeResultBillingLinkageBean;
import jp.co.unisys.enability.cis.entity.sn.SN_CreatingBillingTargetEntityBean;
import jp.co.unisys.enability.cis.entity.sn.SN_NextMrScheduledEntityBean;
import jp.co.unisys.enability.cis.mapper.sn.SN_CreatingBillingCommonMapper;

/**
 * 請求入金共通請求作成ビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class SN_CreatingBillingCommonBusinessImpl implements
    SN_CreatingBillingCommonBusiness {

  /** 請求入金請求作成共通マッパー(DI) */
  private SN_CreatingBillingCommonMapper snCreatingBillingCommonMapper;

  /** 日付関連共通ビジネス(DI) */
  private DateBusiness dateBusiness;

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.sn.SN_CreatingBillingCommonBusiness
   * #createBillingTarget( List<Integer,
   * jp.co.unisys.enability.cis.entity.sn.SN_CreatingBillingTargetEntityBean>,
   * String, String)
   */
  @Override
  public Map<Integer, Map<Integer, SN_CreatingBillingTargetEntityBean>> createBillingTarget(
      List<SN_CreatingBillingTargetEntityBean> beanList) {

    Map<Integer, Map<Integer, SN_CreatingBillingTargetEntityBean>> mapPayment = new LinkedHashMap<>();

    // 《請求作成対象候補EntityBean》リストからMAP<支払ID, MAP<契約ID,《請求作成対象候補EntityBean》>>
    // を生成する
    for (SN_CreatingBillingTargetEntityBean bean : beanList) {
      Map<Integer, SN_CreatingBillingTargetEntityBean> mapContract = new LinkedHashMap<>();
      if (mapPayment.containsKey(bean.getPaymentId())) {
        mapContract = mapPayment.get(bean.getPaymentId());
        mapContract.put(bean.getContractId(), bean);
      } else {
        mapContract.put(bean.getContractId(), bean);
        mapPayment.put(bean.getPaymentId(), mapContract);
      }
    }

    return mapPayment;

  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.sn.SN_CreatingBillingCommonBusiness
   * #removeCreatingBillingTarget( Map<Integer, Map<Integer,
   * jp.co.unisys.enability
   * .cis.entity.sn.SN_CreatingBillingTargetEntityBean>>)
   */
  @Override
  public void removeCreatingBillingTarget(
      Map<Integer, Map<Integer, SN_CreatingBillingTargetEntityBean>> map) {

    // ■ 請求中の【請求】の取得
    Map<String, Object> blMap = new HashMap<String, Object>();
    blMap.put("blStatusCode",
        ECISCodeConstants.BILLING_STATUS_CODE_BILLING);

    List<SN_BillingFixChargeResultBillingLinkageBean> blInfo = snCreatingBillingCommonMapper
        .blInfo(blMap);

    // 取得した請求情報をマップ化する（キー：契約ID,値：利用年月リスト）
    Map<Integer, List<String>> blInfoMap = new HashMap<>();
    for (SN_BillingFixChargeResultBillingLinkageBean bean : blInfo) {
      List<String> usePeriodList = new ArrayList<>();
      if (blInfoMap.containsKey(bean.getContractId())) {
        blInfoMap.get(bean.getContractId()).add(bean.getUsePeriod());
      } else {
        usePeriodList.add(bean.getUsePeriod());
        blInfoMap.put(bean.getContractId(), usePeriodList);
      }
    }

    // ■ 債権回収対象となる【契約】の取得
    Map<String, Object> urgeMngMap = new HashMap<String, Object>();
    urgeMngMap.put("urgeStatusCode",
        ECISCodeConstants.URGE_STATUS_CODE_CANCELLATION_DECISION);

    List<Integer> contractIdList = snCreatingBillingCommonMapper
        .urgeMngInfo(urgeMngMap);

    // 取得した債権情報をマップ化する（キー：契約ID,値：ダミー(null)）
    Map<Integer, List<String>> urgeMngInfoMap = new HashMap<>();
    for (Integer contractId : contractIdList) {
      urgeMngInfoMap.put(contractId, null);
    }

    // 支払IDキーのマップを保持する。
    Map<Integer, Map<Integer, SN_CreatingBillingTargetEntityBean>> paymentMap = new LinkedHashMap<>();
    paymentMap.putAll(map);

    // ■ ”未収”確定している【請求】の確認

    // バッチ処理基準日
    Date date = dateBusiness.getProcessBaseDate(ECISConstants.EXEC_BASE_DATE_BATCH);

    // 保留判定日を正しく取得できるよう、バッチ処理基準日の翌日を設定する
    Calendar calendar = Calendar.getInstance();
    calendar.setTime(date);
    calendar.add(Calendar.DATE, 1);

    //システム共通処理.業務日付計算を呼び出し、保留判定日を取得する。
    Date terminationDate = dateBusiness.calcWorkDate(
        calendar.getTime(),
        ECISCodeConstants.WORK_DAYS_FOR_REMAIN_DATE);

    String remainJudgeDay = StringConvertUtil.convertDateToString(terminationDate,
        ECISConstants.FORMAT_DATE_yyyyMMdd);

    // ■ Map<支払ID>のサイズ分、以下の処理を繰り返す。
    for (Map.Entry<Integer, Map<Integer, SN_CreatingBillingTargetEntityBean>> entryPayment : paymentMap
        .entrySet()) {

      // 契約IDキーのマップを保持する。
      Map<Integer, SN_CreatingBillingTargetEntityBean> contractMap = new LinkedHashMap<>();
      contractMap.putAll(entryPayment.getValue());

      boolean removeFlg = false;
      // ■ Map<契約ID>のサイズ分、以下の処理を繰り返す。
      for (Map.Entry<Integer, SN_CreatingBillingTargetEntityBean> entryContract : contractMap
          .entrySet()) {

        if (ECISConstants.FLG_ON.equals(entryContract.getValue().getPreviousBlAddUpFlag())) {
          // 《請求作成対象候補EntityBean》.前月請求合算フラグがON（合算要）である場合、以下を行う。
          // ■ ”未収”確定していない【請求】の確認
          // 対象の利用年月取得
          String targetUsePeriod = null;
          targetUsePeriod = entryContract.getValue().getUsePeriod();
          List<String> usePeriodList = blInfoMap.get(entryContract.getValue().getContractId());
          if (CollectionUtils.isNotEmpty(usePeriodList)) {
            for (String usePeriod : usePeriodList) {
              // 過去の利用年月の請求中データがあるか確認
              if (usePeriod.compareTo(targetUsePeriod) < 0) {
                // 削除フラグにtrueを設定して繰り返し処理を終了する。
                removeFlg = true;
                break;
              }
            }
          }
          if (removeFlg) {
            break;
          }
        }
        // ■ 債権回収対象となる【契約】の確認
        if (urgeMngInfoMap.containsKey(entryContract.getValue().getContractId())) {
          // 当該Map<契約ID>をremoveする。
          map.get(entryPayment.getKey()).remove(
              entryContract.getKey());
        }
      }

      // ■ ”未収”確定している【請求】の確認
      //検索条件マップを作成する
      HashMap<String, Object> remainMap = new HashMap<String, Object>();
      remainMap.put("paymentId", entryPayment.getKey());
      remainMap.put("remainJudgeDate", remainJudgeDay);
      // 保留判定日より後の日付に更新された請求の件数を確認
      if (snCreatingBillingCommonMapper.countOverRemainDate(remainMap) > 0) {
        // 削除フラグにtrueを設定する
        removeFlg = true;
      }

      // ■ 削除フラグがtrue または 当該Map<支払ID>に紐づくMap<契約ID>が空になった場合
      if (removeFlg || MapUtils.isEmpty(entryPayment.getValue())) {
        // 当該Map<支払ID>をremoveする。
        map.remove(entryPayment.getKey());
      }
    }

  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.sn.SN_CreatingBillingCommonBusiness
   * #removeCreatingBillingTargetSummary( Map<Integer, Map<Integer,
   * jp.co.unisys
   * .enability.cis.entity.sn.SN_CreatingBillingTargetEntityBean>>, String)
   */
  @Override
  public void removeCreatingBillingTargetSummary(
      Map<Integer, Map<Integer, SN_CreatingBillingTargetEntityBean>> map,
      String batchDate) {

    // 支払IDキーのマップを保持する。
    Map<Integer, Map<Integer, SN_CreatingBillingTargetEntityBean>> paymentMap = new LinkedHashMap<>();
    paymentMap.putAll(map);

    // ■ Map<支払ID>のサイズ分、以下の処理を繰り返す。
    for (Map.Entry<Integer, Map<Integer, SN_CreatingBillingTargetEntityBean>> entryPayment : paymentMap
        .entrySet()) {

      // 契約IDキーのマップを保持する。
      Map<Integer, SN_CreatingBillingTargetEntityBean> contractMap = new LinkedHashMap<>();
      contractMap.putAll(entryPayment.getValue());

      boolean removeFlg = false;

      // 紐づく【確定料金実績】が取得できていない【契約】のデータのための利用年月を
      // 同一支払IDから取得する。
      String usePeriod = null;
      for (Map.Entry<Integer, SN_CreatingBillingTargetEntityBean> entryContract : contractMap
          .entrySet()) {
        if (StringUtils.isNotEmpty(entryContract.getValue().getUsePeriod())) {
          usePeriod = entryContract.getValue().getUsePeriod();
          break;
        }
      }

      // ■ Map<契約ID>のサイズ分、以下の処理を繰り返す。
      for (Map.Entry<Integer, SN_CreatingBillingTargetEntityBean> entryContract : contractMap
          .entrySet()) {

        // ■ 《請求作成対象候補EntityBean》.料金ステータスコード <> ”確定”の場合
        if (StringUtils.isNotEmpty(entryContract.getValue().getChargeStatusCode())
            && !ECISCodeConstants.CHARGE_STATUS_CODE_FIX
                .equals(entryContract.getValue().getChargeStatusCode())) {
          // 削除フラグにtrueを設定して繰り返し処理を終了する。
          removeFlg = true;
          break;
        }

        // ■紐づく【確定料金実績】が取得できていない【契約】のデータが存在する場合（確定料金実績が取得できていない）
        if (entryContract.getValue().getFixChargeResultId() == null) {

          // ■ 次回検針予定日、契約開始日、契約終了日の取得
          Map<String, Object> exampleMap = new HashMap<String, Object>();
          exampleMap.put("contractId", entryContract.getValue()
              .getContractId());
          exampleMap.put("contractEndFuSentFlag",
              ECISKJConstants.CONTRACT_END_FIX_USAGE_SENT_FLAG_NON_LINKAGE);

          SN_NextMrScheduledEntityBean nextMrScheEntity = snCreatingBillingCommonMapper
              .selectNextMeterReadingScheduledDate(exampleMap);

          if (nextMrScheEntity != null) {
            Date contractSd = nextMrScheEntity.getContractSd();
            Date contractEd = nextMrScheEntity.getContractEd();
            Date nextMrScheduleDate = nextMrScheEntity.getNextMrScheduledDate();
            Date nextMrScheduleYm = null;

            // 次回検針予定日の年月
            if (ECISCodeConstants.METER_READING_DATE_CATEGORY_DISPERSION
                .equals(nextMrScheEntity.getMeterReadingDateCategory())) {
              // 分散検針の場合、次回検針予定日
              nextMrScheduleYm = nextMrScheEntity.getNextMrScheduledDate();
            } else if (ECISCodeConstants.METER_READING_DATE_CATEGORY_REGULAR_DAY
                .equals(nextMrScheEntity.getMeterReadingDateCategory())) {
              // 定例日検針の場合、-1日した日付の年月
              nextMrScheduleYm = DateCalculateUtil.calculateDate(
                  nextMrScheEntity.getNextMrScheduledDate(),
                  0, 0, -1);
            }

            // Stringに変換

            String strNextScheDate = new SimpleDateFormat(
                EMSConstants.FORMAT_DATE_yyyyMMdd).format(nextMrScheduleDate);
            String strContractSd = new SimpleDateFormat(
                EMSConstants.FORMAT_DATE_yyyyMMdd).format(contractSd);
            String strContractEd = new SimpleDateFormat(
                EMSConstants.FORMAT_DATE_yyyyMMdd).format(contractEd);
            String strNextScheYm = new SimpleDateFormat(
                EMSConstants.FORMAT_DATE_YYYYMM).format(nextMrScheduleYm);

            // ■「契約終了日」≦ バッチ処理基準日
            //   または（「次回検針予定日」の年月 ＝ 《次回検針予定EntityBean》.利用年月
            //   かつ《次回検針予定EntityBean》.契約開始日＜《次回検針予定EntityBean》.次回検針予定日）の場合
            if (strContractEd.compareTo(batchDate) <= 0
                || (strNextScheYm.equals(usePeriod)
                    && strContractSd.compareTo(strNextScheDate) < 0)) {
              // 削除フラグにtrueを設定して繰り返し処理を終了する。
              removeFlg = true;
              break;
            } else {
              // 当該Map<契約ID>をremoveする。
              map.get(entryPayment.getKey()).remove(
                  entryContract.getKey());
              continue;
            }
          } else {
            // 当該Map<契約ID>をremoveする。
            map.get(entryPayment.getKey()).remove(
                entryContract.getKey());
            continue;
          }

        }

        // ■ 《請求作成対象候補EntityBean》.請求番号 <> 空白の場合
        if (StringUtils.isNotEmpty(entryContract.getValue()
            .getBillingNo())) {
          // 当該Map<契約ID>をremoveする。
          map.get(entryPayment.getKey()).remove(
              entryContract.getKey());
          continue;
        }

      }

      // ■ 削除フラグがtrue または 当該Map<支払ID>に紐づくMap<契約ID>が空になった場合
      if (removeFlg || MapUtils.isEmpty(entryPayment.getValue())) {
        // 当該Map<支払ID>をremoveする。
        map.remove(entryPayment.getKey());
      }
    }

  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.sn.SN_CreatingBillingCommonBusiness
   * #calculationMonthlyCharge( List<Fcr>)
   */
  @Override
  public BigDecimal calculationMonthlyCharge(List<Fcr> fcrList) {

    // ■ 月額料金合計値算出
    BigDecimal addMonthlyCharge = BigDecimal.ZERO;
    // 引数.《確定料金実績EntityBean》リスト分、以下の処理を繰り返す。
    for (Fcr fcr : fcrList) {
      // 《確定料金実績EntityBean》.月額料金を月額料金エリアに保持して合算していく。
      if (fcr.getMonthlyCharge() != null) {
        addMonthlyCharge = addMonthlyCharge.add(BigDecimal.valueOf(fcr
            .getMonthlyCharge()));
      }
    }

    return addMonthlyCharge;
  }

  /**
   * 請求入金請求作成共通マッパーを設定する。（DI）
   *
   * @param snCreatingBillingCommonMapper
   *          請求入金請求作成共通マッパー
   */
  public void setSnCreatingBillingCommonMapper(
      SN_CreatingBillingCommonMapper snCreatingBillingCommonMapper) {
    this.snCreatingBillingCommonMapper = snCreatingBillingCommonMapper;
  }

  /**
   * 日付関連共通ビジネスを設定する。（DI）
   *
   * @param dateBusiness
   *          日付関連共通ビジネス
   */
  public void setDateBusiness(
      DateBusiness dateBusiness) {
    this.dateBusiness = dateBusiness;
  }
}
