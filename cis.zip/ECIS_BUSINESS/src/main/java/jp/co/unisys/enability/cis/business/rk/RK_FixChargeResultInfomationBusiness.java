package jp.co.unisys.enability.cis.business.rk;

import jp.co.unisys.enability.cis.business.rk.model.InquiryFixChargeResultBusinessBean;

/**
 * 確定料金実績情報ビジネスインターフェース。
 *
 * @author "Nihon Unisys, Ltd."
 *
 */
public interface RK_FixChargeResultInfomationBusiness {

  /**
   * 確定料金実績情報の取得を行う。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 確定料金実績情報を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param inquiryFixChargeResultBusinessBean
   *          確定料金実績情報BusinessBean
   * @return 確定料金実績情報BusinessBean
   */
  public InquiryFixChargeResultBusinessBean inquiry(
      InquiryFixChargeResultBusinessBean inquiryFixChargeResultBusinessBean);
}
