package jp.co.unisys.enability.cis.business.kj.model;

import java.util.List;

import jp.co.unisys.enability.cis.entity.kj.KJ_InquiryProvideModelEntityBean;

/**
 * 提供モデル企業照会で照会条件および照会結果を格納するBusinessBean
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 *  マスタ情報ビジネス
 *  契約者情報ビジネス
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class InquiryProvideModelCompanyBusinessBean {

  /**
   * 提供モデルコードを保有する。
   */
  private String provideModelCode;

  /**
   * 提供モデル企業コードを保有する。
   */
  private String provideModelCompanyCode;

  /**
   * 提供モデル企業有効フラグを保有する。
   */
  private String provideModelCompanyEffectiveFlag;

  /**
   * 提供モデル情報リストを保有する。
   */
  private List<KJ_InquiryProvideModelEntityBean> provideModelList;

  /**
   * リターンコードを保有する。
   */
  private String returnCode;

  /**
   * メッセージを保有する。
   */
  private String message;

  /**
   * 提供モデルコードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 提供モデルコードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 提供モデルコード
   */
  public String getProvideModelCode() {
    return this.provideModelCode;
  }

  /**
   * 提供モデルコードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 提供モデルコードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param provideModelCode
   *          提供モデルコード
   */
  public void setProvideModelCode(String provideModelCode) {
    this.provideModelCode = provideModelCode;
  }

  /**
   * 提供モデル企業コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 提供モデル企業コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 提供モデル企業コード
   */
  public String getProvideModelCompanyCode() {
    return this.provideModelCompanyCode;
  }

  /**
   * 提供モデル企業コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 提供モデル企業コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param provideModelCompanyCode
   *          提供モデル企業コード
   */
  public void setProvideModelCompanyCode(String provideModelCompanyCode) {
    this.provideModelCompanyCode = provideModelCompanyCode;
  }

  /**
   * 提供モデル企業有効フラグのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 提供モデル企業有効フラグを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 提供モデル企業有効フラグ
   */
  public String getProvideModelCompanyEffectiveFlag() {
    return this.provideModelCompanyEffectiveFlag;
  }

  /**
   * 提供モデル企業有効フラグのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 提供モデル企業有効フラグを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param provideModelCompanyEffectiveFlag
   *          提供モデル企業有効フラグ
   */
  public void setProvideModelCompanyEffectiveFlag(
      String provideModelCompanyEffectiveFlag) {
    this.provideModelCompanyEffectiveFlag = provideModelCompanyEffectiveFlag;
  }

  /**
   * 提供モデル情報リストのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 提供モデル情報リストを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 提供モデル情報リスト
   */
  public List<KJ_InquiryProvideModelEntityBean> getProvideModelList() {
    return this.provideModelList;
  }

  /**
   * 提供モデル情報リストのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 提供モデル情報リストを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param provideModelList
   *          提供モデル情報リスト
   */
  public void setProvideModelList(
      List<KJ_InquiryProvideModelEntityBean> provideModelList) {
    this.provideModelList = provideModelList;
  }

  /**
   * リターンコードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return リターンコード
   */
  public String getReturnCode() {
    return this.returnCode;
  }

  /**
   * リターンコードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param returnCode
   *          リターンコード
   */
  public void setReturnCode(String returnCode) {
    this.returnCode = returnCode;
  }

  /**
   * メッセージのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return メッセージ
   */
  public String getMessage() {
    return this.message;
  }

  /**
   * メッセージのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param message
   *          メッセージ
   */
  public void setMessage(String message) {
    this.message = message;
  }

}
