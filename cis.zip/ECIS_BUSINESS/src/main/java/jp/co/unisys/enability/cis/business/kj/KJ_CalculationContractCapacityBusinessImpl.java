package jp.co.unisys.enability.cis.business.kj;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;
import java.util.Locale;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.dao.DataAccessException;

import jp.co.unisys.enability.cis.business.kj.model.KJ_CalculationContractCapacityBusinessBean;
import jp.co.unisys.enability.cis.common.Exception.SystemException;
import jp.co.unisys.enability.cis.common.util.KJ_CommonUtil;
import jp.co.unisys.enability.cis.common.util.StringConvertUtil;
import jp.co.unisys.enability.cis.common.util.ThreadContext;
import jp.co.unisys.enability.cis.common.util.constants.ECISCodeConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISKJConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISReturnCodeConstants;
import jp.co.unisys.enability.cis.entity.common.ContractHist;
import jp.co.unisys.enability.cis.entity.common.ContractHistExample;
import jp.co.unisys.enability.cis.entity.common.Rqh;
import jp.co.unisys.enability.cis.entity.common.RqhExample;
import jp.co.unisys.enability.cis.mapper.common.ContractHistMapper;
import jp.co.unisys.enability.cis.mapper.common.RqhMapper;

/**
 * 契約電力算定処理ビジネス
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.kj.KJ_CalculationContractCapacityBusiness
 *
 */
public class KJ_CalculationContractCapacityBusinessImpl implements
    KJ_CalculationContractCapacityBusiness {

  /** 実量歴管理マッパー(DI) */
  private RqhMapper rqhMapper;

  /** 契約履歴マッパー(DI) */
  private ContractHistMapper contractHistMapper;

  /** メッセージプロパティ(DI) */
  private MessageSource messageSource;

  /**
   * ログマネジャー
   */
  private static Logger logger = LogManager.getLogger();

  /**
   * 年月計算用(-11)
   */
  private static final int DIFF_MONTH = -11;

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.kj.KJ_CalculationContractCapacityBusiness
   * #update(jp.co.unisys.enability.cis.business.kj.model.
   * KJ_CalculationContractCapacityBusinessBean)
   */
  @Override
  public KJ_CalculationContractCapacityBusinessBean update(
      KJ_CalculationContractCapacityBusinessBean kjCalculationContractCapacityBusinessBean) {
    String errorMessage = null;
    try {
      errorMessage = messageSource.getMessage(KJ_CommonUtil
          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G017),
          new String[] {}, Locale.getDefault());

      // 【実量歴管理】から算定対象を検出する。
      // 《実量歴管理Example》を設定する。
      RqhExample rqhExample = new RqhExample();
      rqhExample
          .createCriteria()
          .andContractIdEqualTo(
              kjCalculationContractCapacityBusinessBean
                  .getContractId())
          .andCoveredPeriodEqualTo(
              kjCalculationContractCapacityBusinessBean
                  .getCoveredPeriod());

      // 《実量歴管理Mapper》.検索（項目指定）を呼び出す。
      // 返却値が0件の場合、契約電力算定処理BusinessBean.リターンコードに（0001）を設定し処理を終了する。
      List<Rqh> rqhListCurrent = rqhMapper.selectByExample(rqhExample);
      if (rqhListCurrent.isEmpty()) {
        kjCalculationContractCapacityBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0001);
        return kjCalculationContractCapacityBusinessBean;
      }

      // 更新モジュールコード
      String updateModuleCode = ThreadContext.getRequestThreadContext()
          .get(ECISConstants.CLASS_NAME_KEY).toString();

      // 契約電力を算出する。
      // 《実量歴管理Example》を設定する。
      rqhExample = new RqhExample();
      rqhExample.createCriteria()
          .andContractIdEqualTo(
              kjCalculationContractCapacityBusinessBean.getContractId())
          .andCoveredPeriodGreaterThanOrEqualTo(
              StringConvertUtil.calcMonthNoException(
                  kjCalculationContractCapacityBusinessBean.getCoveredPeriod(), DIFF_MONTH,
                  ECISConstants.FORMAT_DATE_yyyyMM))
          .andCoveredPeriodLessThanOrEqualTo(
              kjCalculationContractCapacityBusinessBean.getCoveredPeriod());

      rqhExample.setOrderByClause(ECISKJConstants.RQH_ORDER_BY_CLAUSE_DESC);

      // 《実量歴管理Mapper》.検索（項目指定）を呼び出す。
      List<Rqh> rqhList = rqhMapper.selectByExample(rqhExample);

      // 変数.最大電力を「0」で定義する。
      BigDecimal tempPkw = BigDecimal.ZERO;

      // 取得した件数分以下の繰り返し処理を行う。
      for (Rqh rqh : rqhList) {
        // 該当レコード.最大電力＞変数.最大電力の場合
        if (rqh.getPkw() != null) {
          if (tempPkw.compareTo(rqh.getPkw()) < 0) {
            tempPkw = rqh.getPkw();
          }
        }

        // 減設フラグがONの場合、繰り返し処理をやめ
        if (ECISCodeConstants.REDUCE_CONTRACT_CAPACITY_FLG_ON
            .equals(rqh.getRccFlg())) {
          break;
        }
      }

      // 算定された契約電力を【実量歴管理】に更新する。
      int updateCount = updateRqh(
          kjCalculationContractCapacityBusinessBean, tempPkw,
          updateModuleCode, rqhListCurrent.get(0).getUpdateCount());

      // 「更新件数」が1件以外の場合、《契約電力算定処理BusinessBean》.リターンコードに（0001）を設定し処理を終了する。
      if (updateCount != 1) {
        kjCalculationContractCapacityBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0001);
        return kjCalculationContractCapacityBusinessBean;
      }

      // 当月分及び翌月分以降の、【契約履歴】を更新する。
      // 《契約履歴Example》を設定する。
      ContractHistExample contractHistExample = new ContractHistExample();
      contractHistExample
          .createCriteria()
          .andContractIdEqualTo(
              kjCalculationContractCapacityBusinessBean.getContractId())
          .andApplyEdGreaterThanOrEqualTo(
              kjCalculationContractCapacityBusinessBean.getChargeCalculationStartDate());

      // 《契約履歴Mapper》.検索（項目指定）を呼び出す。
      List<ContractHist> contractHistList = contractHistMapper.selectByExample(contractHistExample);

      // 取得した契約履歴リストのデータ数以下の処理を繰り返す。
      for (ContractHist contractHist : contractHistList) {
        // データレコード.契約電力決定区分コードが
        // 定数.契約電力決定区分コード：実量制(2)（CONTRACT_CAPACITY_DECISION_CATEGORY_CODE_REALQUANTITY）の場合、
        if (ECISCodeConstants.CONTRACT_CAPACITY_DECISION_CATEGORY_CODE_REALQUANTITY
            .equals(contractHist.getCcDecisionCategoryCode())) {
          // 契約履歴を更新する
          updateCount = updateContractHist(
              kjCalculationContractCapacityBusinessBean,
              contractHist, tempPkw, updateModuleCode);

          // 「更新件数」が1件以外の場合、《契約電力算定処理BusinessBean》.リターンコードに（0001）を設定し処理を終了する。
          if (updateCount != 1) {
            kjCalculationContractCapacityBusinessBean
                .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0001);
            return kjCalculationContractCapacityBusinessBean;
          }
        }

      }

      // 《契約電力算定処理BusinessBean》.リターンコードに（0000）を設定する。
      kjCalculationContractCapacityBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);
    } catch (NoSuchMessageException ioe) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, ioe);
      kjCalculationContractCapacityBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      kjCalculationContractCapacityBusinessBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
    } catch (DataAccessException exception) {
      logger.error(
          messageSource.getMessage("error.E1129", null,
              Locale.getDefault()),
          exception);
      kjCalculationContractCapacityBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      kjCalculationContractCapacityBusinessBean.setMessage(errorMessage);
    } catch (SystemException se) {
      logger.error(
          messageSource.getMessage("error.E1129", null,
              Locale.getDefault()),
          se);
      kjCalculationContractCapacityBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      kjCalculationContractCapacityBusinessBean.setMessage(errorMessage);
    }

    return kjCalculationContractCapacityBusinessBean;
  }

  /**
   * 実量歴管理更新
   *
   * @param kjCalculationContractCapacityBusinessBean
   *          契約電力算定処理BusinessBean
   * @param updateCcc
   *          算定契約電力
   * @param updateModuleCode
   *          更新モジュールコード
   * @param updateCount
   *          更新回数
   * @return 更新件数
   */
  private int updateRqh(
      KJ_CalculationContractCapacityBusinessBean kjCalculationContractCapacityBusinessBean,
      BigDecimal updateCcc, String updateModuleCode, int updateCount) {

    // 《実量歴管理Entity》を設定する。
    Rqh rqhEntity = new Rqh();

    // 算定契約電力
    rqhEntity.setCcc(updateCcc);

    // 契約電力算定日時
    rqhEntity.setCccTime(new Timestamp(System.currentTimeMillis()));

    // 更新回数 + 1
    rqhEntity.setUpdateCount(updateCount + 1);

    // 更新日時
    rqhEntity.setUpdateTime(new Timestamp(System.currentTimeMillis()));

    // 更新モジュールコード
    rqhEntity.setUpdateModuleCode(updateModuleCode);

    // 《契約電力算定処理BusinessBean》.実行機能区分コードか定数.実行機能区分コード：画面(IMPLEMENT_FUNCTION_CODE_WEB)の場合、
    if (ECISConstants.IMPLEMENT_FUNCTION_CODE_WEB == kjCalculationContractCapacityBusinessBean
        .getImplementFunctionCode()) {
      // オンライン更新日時を設定する。
      rqhEntity.setOnlineUpdateTime(new Timestamp(System
          .currentTimeMillis()));

      // オンライン更新ユーザIDを設定する。
      rqhEntity.setOnlineUpdateUserId(ThreadContext
          .getRequestThreadContext().get(ECISConstants.USER_ID_KEY)
          .toString());
    }

    // 《実量歴管理Example》を設定する。
    RqhExample rqhExample = new RqhExample();

    // 《契約電力算定処理BusinessBean》.実行機能区分コードか定数.実行機能区分コード：画面(IMPLEMENT_FUNCTION_CODE_WEB)の場合、
    // 以下の《契約履歴Example》を設定する。
    if (ECISConstants.IMPLEMENT_FUNCTION_CODE_WEB == kjCalculationContractCapacityBusinessBean
        .getImplementFunctionCode()) {
      rqhExample
          .createCriteria()
          .andContractIdEqualTo(
              kjCalculationContractCapacityBusinessBean
                  .getContractId())
          .andCoveredPeriodEqualTo(
              kjCalculationContractCapacityBusinessBean
                  .getCoveredPeriod())
          .andUpdateCountEqualTo(updateCount);
    } else {
      // 《契約電力算定処理BusinessBean》.実行機能区分コードか定数.実行機能区分コード：バッチ(IMPLEMENT_FUNCTION_CODE_BATCH)の場合、
      // 以下の《契約履歴Example》を設定する。
      rqhExample
          .createCriteria()
          .andContractIdEqualTo(
              kjCalculationContractCapacityBusinessBean
                  .getContractId())
          .andCoveredPeriodEqualTo(
              kjCalculationContractCapacityBusinessBean
                  .getCoveredPeriod());
    }

    // 《実量歴管理Mapper》.選択項目更新を呼び出す、「更新件数」を取得する。
    return rqhMapper.updateByExampleSelective(rqhEntity, rqhExample);
  }

  /**
   * 契約履歴更新
   *
   * @param kjCalculationContractCapacityBusinessBean
   *          契約電力算定処理BusinessBean
   * @param contractHist
   *          契約履歴
   * @param updateCca
   *          契約容量
   * @param updateModuleCode
   *          更新モジュールコード
   * @return 更新件数
   */
  private int updateContractHist(
      KJ_CalculationContractCapacityBusinessBean kjCalculationContractCapacityBusinessBean,
      ContractHist contractHist, BigDecimal updateCca,
      String updateModuleCode) {

    // 《契約履歴Entity》を設定する。
    ContractHist contractHistEntity = new ContractHist();

    // 契約容量
    contractHistEntity.setCca(updateCca);

    // 更新回数
    contractHistEntity.setUpdateCount(contractHist.getUpdateCount() + 1);

    // 更新日時
    contractHistEntity.setUpdateTime(new Timestamp(System
        .currentTimeMillis()));

    // 更新モジュールコード
    contractHistEntity.setUpdateModuleCode(updateModuleCode);

    // 《契約電力算定処理BusinessBean》.実行機能区分コードか定数.実行機能区分コード：画面(IMPLEMENT_FUNCTION_CODE_WEB)の場合、
    if (ECISConstants.IMPLEMENT_FUNCTION_CODE_WEB == kjCalculationContractCapacityBusinessBean
        .getImplementFunctionCode()) {
      // オンライン更新日時を設定する。
      contractHistEntity.setOnlineUpdateTime(new Timestamp(System
          .currentTimeMillis()));

      // オンライン更新ユーザIDを設定する。
      contractHistEntity.setOnlineUpdateUserId(ThreadContext
          .getRequestThreadContext().get(ECISConstants.USER_ID_KEY)
          .toString());
    }

    // 《契約履歴Example》を設定する。
    // 《契約電力算定処理BusinessBean》.実行機能区分コードか定数.実行機能区分コード：画面(IMPLEMENT_FUNCTION_CODE_WEB)の場合、
    // 以下の《契約履歴Example》を設定する。
    ContractHistExample contractHistExample = new ContractHistExample();
    if (ECISConstants.IMPLEMENT_FUNCTION_CODE_WEB == kjCalculationContractCapacityBusinessBean
        .getImplementFunctionCode()) {
      contractHistExample
          .createCriteria()
          .andContractIdEqualTo(
              kjCalculationContractCapacityBusinessBean
                  .getContractId())
          .andApplySdEqualTo(contractHist.getApplySd())
          .andUpdateCountEqualTo(contractHist.getUpdateCount());
    } else {
      // 《契約電力算定処理BusinessBean》.実行機能区分コードか定数.実行機能区分コード：バッチ(IMPLEMENT_FUNCTION_CODE_BATCH)の場合、
      // 以下の《契約履歴Example》を設定する。
      contractHistExample
          .createCriteria()
          .andContractIdEqualTo(
              kjCalculationContractCapacityBusinessBean
                  .getContractId())
          .andApplySdEqualTo(contractHist.getApplySd());
    }

    // 《契約履歴Mapper》.選択項目更新を呼び出す、「更新件数」を取得する。
    return contractHistMapper.updateByExampleSelective(contractHistEntity,
        contractHistExample);
  }

  /**
   * 実量歴管理マッパーを設定する。(DI)
   *
   * @param rqhMapper
   *          実量歴管理マッパー
   */
  public void setRqhMapper(RqhMapper rqhMapper) {
    this.rqhMapper = rqhMapper;
  }

  /**
   * 契約履歴マッパーを設定する。(DI)
   *
   * @param contractHistMapper
   *          契約履歴マッパー
   */
  public void setContractHistMapper(ContractHistMapper contractHistMapper) {
    this.contractHistMapper = contractHistMapper;
  }

  /**
   * messageSourceのセッター(DI)
   *
   * @param messageSource
   *          メッセージソース
   *
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }
}
