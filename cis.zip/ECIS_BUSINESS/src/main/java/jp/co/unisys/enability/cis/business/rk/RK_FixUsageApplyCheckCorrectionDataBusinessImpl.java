package jp.co.unisys.enability.cis.business.rk;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.context.MessageSource;

import jp.co.unisys.enability.cis.business.common.TodoBusiness;
import jp.co.unisys.enability.cis.business.common.model.TodoBusinessBean;
import jp.co.unisys.enability.cis.business.rk.model.RK_FixUsageApplyDataBusinessBean;
import jp.co.unisys.enability.cis.common.util.StringConvertUtil;
import jp.co.unisys.enability.cis.common.util.ThreadContext;
import jp.co.unisys.enability.cis.common.util.constants.ECISCodeConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISTodoConstants;
import jp.co.unisys.enability.cis.entity.common.CtRateM;
import jp.co.unisys.enability.cis.entity.common.CtRateMExample;
import jp.co.unisys.enability.cis.entity.common.Fcr;
import jp.co.unisys.enability.cis.entity.common.FcrExample;
import jp.co.unisys.enability.cis.entity.common.FcrWarningData;
import jp.co.unisys.enability.cis.entity.common.FcrWarningDataExample;
import jp.co.unisys.enability.cis.entity.common.Fu;
import jp.co.unisys.enability.cis.entity.common.FuExample;
import jp.co.unisys.enability.cis.mapper.common.CtRateMMapper;
import jp.co.unisys.enability.cis.mapper.common.FcrMapper;
import jp.co.unisys.enability.cis.mapper.common.FcrWarningDataMapper;
import jp.co.unisys.enability.cis.mapper.common.FuMapper;

/**
 * 訂正データチェックビジネスクラス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_FixUsageApplyCheckCorrectionDataBusinessImpl implements
    RK_FixUsageApplyCheckCorrectionDataBusiness {

  /** 確定料金実績Mapper(DI) */
  private FcrMapper fcrMapper;

  /** 確定料金実績警告データMapper(DI) */
  private FcrWarningDataMapper fcrWarningDataMapper;

  /** 消費税率マスタMapper(DI) */
  private CtRateMMapper ctRateMMapper;

  /** TODOビジネス(DI) */
  private TodoBusiness todoBusiness;

  /** メッセージリソース(DI) */
  private MessageSource messageSource;

  /** 確定使用量Mapper(DI) */
  private FuMapper fuMapper;

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.rk.
   * RK_FixUsageApplyCheckCorrectionDataBusiness
   * #check(jp.co.unisys.enability.cis
   * .business.rk.model.RK_FixUsageApplyDataBusinessBean)
   */
  @Override
  public void check(RK_FixUsageApplyDataBusinessBean applyDataBusinessBean) {

    // 更新用のモジュールコードを取得
    String moduleCode = (String) ThreadContext.getRequestThreadContext()
        .get(ECISConstants.CLASS_NAME_KEY);

    // 《確定使用量反映データビジネスBean》.実量歴登録・更新要否フラグをtrueに設定する。
    applyDataBusinessBean.setRealQuantityNeedUpAddFlag(true);

    // 確定料金実績Example
    FcrExample fcrExample = new FcrExample();

    // 【確定料金実績】の取得条件を設定
    fcrExample.createCriteria()
        // 契約ID
        .andContractIdEqualTo(applyDataBusinessBean.getContractId())
        // 利用年月
        .andUsePeriodEqualTo(applyDataBusinessBean.getUsePeriod());

    // 【確定料金実績】を取得
    List<Fcr> fixChargeResultList = fcrMapper.selectByExample(fcrExample);

    // 【確定料金実績】が存在した場合には、料金ステータスの状態に応じて、TODOか警告を登録する
    if (!fixChargeResultList.isEmpty()) {

      // 最初の要素を取得（契約IDと利用年月で取得しているので、最大１件の想定）
      Fcr fixChargeResult = fixChargeResultList.get(0);

      // 判定用訂正フラグ
      boolean judgementCorrectionFlg = true;

      // 《確定使用量反映データビジネスBean》．送受電コードが、"2"(受電）の場合
      if (ECISCodeConstants.TRANSMISSION_CATEGORY_CODE_RECEIVING
          .equals(applyDataBusinessBean.getTransmissionCatCode())) {

        // 【確定使用量】Example
        FuExample fuExample = new FuExample();
        // 【確定使用量】の取得条件を設定
        fuExample.createCriteria().andFuIdEqualTo(fixChargeResult.getFuId());
        // 【確定使用量】を取得
        List<Fu> fixUsageList = fuMapper.selectByExample(fuExample);

        // 《確定使用量》リストが0件でない場合
        if (!fixUsageList.isEmpty()) {
          // 月間電力量全量
          BigDecimal monthlyTotalKwh = new BigDecimal(applyDataBusinessBean.getMonthlyTotalKwh());

          //変数確定使用量を初期化する。（初期値：0)
          BigDecimal usageQuantity = new BigDecimal(0);

          //《確定使用量》リストの最初の要素（《確定使用量》）の使用量がNULLではない場合
          if (fixUsageList.get(0).getUsageQuantity() != null) {
            //変数確定使用量に《確定使用量》リストの最初の要素（《確定使用量》）の使用量を設定する。
            usageQuantity = fixUsageList.get(0).getUsageQuantity();
          }
          // 確定使用量．使用量 ＝ 《確定使用量反映データビジネスBean》.月間電力量全量の場合
          if (monthlyTotalKwh.compareTo(usageQuantity) == 0) {
            // 変数TODO登録有無にFALSEを設定する。
            judgementCorrectionFlg = false;
          }
        }
      }

      // 判定用訂正フラグがTRUEの場合、料金ステータスの状態に応じて、TODOか警告を登録する
      if (judgementCorrectionFlg) {

        // 確定料金実績が確定されている場合は、TODOを登録し、未確定の場合は、警告を登録する。
        if (ECISRKConstants.CHARGE_STATUS_MASTER_FIXED.equals(fixChargeResult.getCsCode())) {
          // 料金ステータスが"確定"

          // TODOに登録するメッセージのパラメータ
          String[] params = {
              // 確定使用量ファイル名
              applyDataBusinessBean.getFixUsageFileName(),
              // 地点特定番号
              applyDataBusinessBean.getSpotNo(),
              // エリアコード
              applyDataBusinessBean.getAreaCode(),
              // 処理日
              StringConvertUtil.convertDateToString(
                  applyDataBusinessBean.getExecuteDate(), ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
              // 契約番号
              applyDataBusinessBean.getContractNo() };

          // TODOビジネスBean
          TodoBusinessBean todoBusinessBean = new TodoBusinessBean();

          // TODOに登録する情報を設定
          // サブシステムID
          todoBusinessBean.setSubsystemId(ECISConstants.SUBSYSTEM_ID_RK);
          // 機能ID
          todoBusinessBean
              .setFunctionId(ECISTodoConstants.TODO_FUNCTION_ID.RK0101
                  .toString());
          // メッセージID
          todoBusinessBean.setMessageId("todo.T1030");
          // メッセージ
          todoBusinessBean.setMessage(messageSource.getMessage(
              todoBusinessBean.getMessageId(), params,
              Locale.getDefault()));
          // 契約番号
          todoBusinessBean.setContractNo(applyDataBusinessBean.getContractNo());
          // 地点特定番号
          todoBusinessBean.setSpotNo(applyDataBusinessBean.getSpotNo());

          // TODO登録
          todoBusiness.registTodo(todoBusinessBean);

          // 《確定使用量反映データビジネスBean》.実量歴登録・更新要否フラグをfalseに設定する。
          applyDataBusinessBean.setRealQuantityNeedUpAddFlag(false);

          // バッチ処理基準日に対応する消費税適用開始日を取得する。
          // 消費税率マスタ取得
          // 条件設定
          CtRateMExample ctRateMExample = new CtRateMExample();
          // 適用開始日 <= 基準日 <= 適用終了日
          ctRateMExample.createCriteria().andApplySdLessThanOrEqualTo(applyDataBusinessBean.getExecuteDate())
              .andApplyEdGreaterThanOrEqualTo(applyDataBusinessBean.getExecuteDate());
          // 取得実行
          List<CtRateM> ctRateMList = ctRateMMapper.selectByExample(ctRateMExample);

          // 消費税率マスタからデータを取得できた場合、処理継続
          if (!CollectionUtils.isEmpty(ctRateMList)) {
            // 消費税率取得
            // 1件しか返ってこないはずの条件のため、リストの1件目から取得する
            CtRateM ctRateM = ctRateMList.get(0);
            // 算定期間開始日が新税率適用後かチェック
            if (applyDataBusinessBean.getCalculationTermStartDate().compareTo(ctRateM.getApplySd()) < 0) {
              // 《確定使用量反映データビジネスBean》.算定期間開始日 ＜ 《消費税率マスタ》.適用開始日の場合、TODOを登録する。
              // TODOビジネスBean
              todoBusinessBean = new TodoBusinessBean();

              // TODOに登録する情報を設定
              // サブシステムID
              todoBusinessBean.setSubsystemId(ECISConstants.SUBSYSTEM_ID_RK);
              // 機能ID
              todoBusinessBean.setFunctionId(ECISTodoConstants.TODO_FUNCTION_ID.RK0101.toString());
              // メッセージID
              todoBusinessBean.setMessageId("todo.T1075");
              // メッセージ
              // パラメータはtodo.T1030と同じため、前段で作成したparamsを使用する。
              todoBusinessBean.setMessage(messageSource.getMessage(
                  todoBusinessBean.getMessageId(), params, Locale.getDefault()));

              // TODO登録
              todoBusiness.registTodo(todoBusinessBean);
            }
          }
        } else {
          // 料金ステータスが"未確定"

          // 確定料金実績警告データExample
          FcrWarningDataExample fcrWarningDataExample = new FcrWarningDataExample();

          // 「確定使用量訂正データ受信」の警告が登録されている【確定料金実績警告データ】の
          // 件数を取得する条件を設定する
          fcrWarningDataExample
              .createCriteria()
              // 確定使用量ID
              .andFcrIdEqualTo(fixChargeResult.getFcrId())
              // 警告種別コード
              .andWarningClassCodeEqualTo(
                  ECISRKConstants.WARNING_CLASS_MASTER_FIX_USAGE_CORRECT_DATA_LINKAGE);

          // レコード件数を取得
          int cnt = fcrWarningDataMapper
              .countByExample(fcrWarningDataExample);

          // 警告が登録されていない場合は【確定料金実績警告データ】を登録する
          if (cnt == 0) {

            // 確定料金実績警告データEntity
            FcrWarningData fcrWarningData = new FcrWarningData();

            // 【確定料金実績警告データ】に登録する値を設定
            Timestamp timestamp = new Timestamp(new Date().getTime());
            // 確定料金実績ID
            fcrWarningData.setFcrId(fixChargeResult.getFcrId());
            // 警告種別コード
            fcrWarningData
                .setWarningClassCode(
                    ECISRKConstants.WARNING_CLASS_MASTER_FIX_USAGE_CORRECT_DATA_LINKAGE);
            // 更新回数
            fcrWarningData.setUpdateCount(0);
            // 作成日時
            fcrWarningData.setCreateTime(timestamp);
            // 更新日時
            fcrWarningData.setUpdateTime(timestamp);
            // 更新モジュールコード
            fcrWarningData.setUpdateModuleCode(moduleCode);

            // 【確定料金実績警告データ】を登録
            fcrWarningDataMapper.insert(fcrWarningData);
          }

          // 【確定料金実績】.警告対応区分コードが"対応要"でない場合は、"対応要"に更新する
          if (!fixChargeResult.getWarningDealCatCode().equals(
              ECISRKConstants.WARNING_DEAL_CATEGORY_MASTER_NECESSARY)) {

            // システム日付
            Timestamp timestamp = new Timestamp(new Date().getTime());

            // 【確定料金実績】に登録する値を設定する
            // 警告対応区分コード
            fixChargeResult
                .setWarningDealCatCode(ECISRKConstants.WARNING_DEAL_CATEGORY_MASTER_NECESSARY);
            // 更新日時
            fixChargeResult.setUpdateTime(timestamp);
            // 更新モジュールコード
            fixChargeResult.setUpdateModuleCode(moduleCode);

            // 【確定料金実績】の更新
            fcrMapper.updateByExampleSelective(fixChargeResult,
                fcrExample);
          }
        }
      }
    }
  }

  /**
   * 確定料金実績Mapperを設定します。(DI)
   *
   * @param fixChargeResultMapper
   *          確定料金実績Mapper
   */
  public void setFcrMapper(FcrMapper fixChargeResultMapper) {
    this.fcrMapper = fixChargeResultMapper;
  }

  /**
   * 確定料金実績警告データMapperを設定します。(DI)
   *
   * @param fixChargeResultWarningDataMapper
   *          確定料金実績警告データMapper
   */
  public void setFcrWarningDataMapper(
      FcrWarningDataMapper fixChargeResultWarningDataMapper) {
    this.fcrWarningDataMapper = fixChargeResultWarningDataMapper;
  }

  /**
   * 消費税率マスタMapperを設定します。（DI）
   *
   * @param ctRateMMapper
   *          消費税率マスタMapper
   */
  public void setCtRateMMapper(CtRateMMapper ctRateMMapper) {
    this.ctRateMMapper = ctRateMMapper;
  }

  /**
   * TODOビジネスを設定します。(DI)
   *
   * @param todoBusiness
   *          TODOビジネス
   */
  public void setTodoBusiness(TodoBusiness todoBusiness) {
    this.todoBusiness = todoBusiness;
  }

  /**
   * メッセージリソースを設定します。(DI)
   *
   * @param messageSource
   *          メッセージリソース
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }

  /**
   * 確定使用量Mapperを設定します。(DI)
   *
   * @param fuMapper
   *          確定使用量Mapper
   */
  public void setFuMapper(FuMapper fuMapper) {
    this.fuMapper = fuMapper;
  }
}
