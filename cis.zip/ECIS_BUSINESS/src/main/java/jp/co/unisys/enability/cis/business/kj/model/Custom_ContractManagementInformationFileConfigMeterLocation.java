package jp.co.unisys.enability.cis.business.kj.model;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;

/**
 * メータ設置場所情報登録・更新（一括登録）BusinessBean
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * メータ設置場所情報ビジネス
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class Custom_ContractManagementInformationFileConfigMeterLocation {

  /** ファイル名接頭辞 */
  public static final String FILE_NAME_PREFIX = "meterLocation_";

  // ヘッダレコード定義
  /** ヘッダレコード：ファイル種別-パラメータ */
  public static final String HEADER_FILE_KIND_MASK_STRING = "^6$";

  // データレコード定義
  /** タイトル行：イニシャライザで内容を設定する */
  public static final String[] DATA_TITLE_ROW;
  /** データレコード項目数：項目数 */
  public static final int DATA_COLUMN_COUNT;

  /** データレコード：メータ設置場所ID-インデックス */
  public static final int DATA_METER_LOCATION_ID_INDEX = 1;
  /** データレコード：メータ設置場所ID-名称 */
  public static final String DATA_METER_LOCATION_ID_NAME = "メータ設置場所ID";
  /** データレコード：メータ設置場所ID-最小数 */
  public static final int DATA_METER_LOCATION_ID_RANGE_MIN = 1;
  /** データレコード：メータ設置場所ID-最大数 */
  public static final int DATA_METER_LOCATION_ID_RANGE_MAX = 2147483647;
  /** データレコード：メータ設置場所ID-メッセージ文言 */
  public static final String DATA_METER_LOCATION_ID_MESSAGE = new StringBuilder()
      .append(DATA_METER_LOCATION_ID_RANGE_MIN).append("～")
      .append(DATA_METER_LOCATION_ID_RANGE_MAX).toString();

  /** データレコード：契約番号-インデックス */
  public static final int DATA_CONTRACT_NO_INDEX = 2;
  /** データレコード：契約番号-名称 */
  public static final String DATA_CONTRACT_NO_NAME = "契約番号";
  /** データレコード：契約番号-文字数 */
  public static final int DATA_CONTRACT_NO_LENGTH = 25;
  /** データレコード：契約番号-文字数(文字列) */
  public static final String DATA_CONTRACT_NO_LENGTH_STRING = String.valueOf(DATA_CONTRACT_NO_LENGTH);

  /** データレコード：需要場所住所（郵便番号）-インデックス */
  public static final int DATA_PLACE_ADDRESS_POSTAL_CODE_INDEX = 3;
  /** データレコード：需要場所住所（郵便番号）-名称 */
  public static final String DATA_PLACE_ADDRESS_POSTAL_CODE_NAME = "需要場所住所（郵便番号）";
  /** データレコード：需要場所住所（郵便番号）-文字数 */
  public static final int DATA_PLACE_ADDRESS_POSTAL_CODE_LENGTH = 7;
  /** データレコード：需要場所住所（郵便番号）-文字数(文字列) */
  public static final String DATA_PLACE_ADDRESS_POSTAL_CODE_LENGTH_STRING = String
      .valueOf(DATA_PLACE_ADDRESS_POSTAL_CODE_LENGTH);

  /** データレコード：需要場所住所（住所）-インデックス */
  public static final int DATA_PLACE_ADDRESS_FULL_INDEX = 4;
  /** データレコード：需要場所住所（住所）-名称 */
  public static final String DATA_PLACE_ADDRESS_FULL_NAME = "需要場所住所（住所）";
  /** データレコード：需要場所住所（住所）-文字数 */
  public static final int DATA_PLACE_ADDRESS_FULL_LENGTH = 60;
  /** データレコード：需要場所住所（住所）-文字数(文字列) */
  public static final String DATA_PLACE_ADDRESS_FULL_LENGTH_STRING = String.valueOf(DATA_PLACE_ADDRESS_FULL_LENGTH);

  /** データレコード：需要場所住所（建物・部屋名）-インデックス */
  public static final int DATA_PLACE_ADDRESS_BUILDING_INDEX = 5;
  /** データレコード：需要場所住所（建物・部屋名）-名称 */
  public static final String DATA_PLACE_ADDRESS_BUILDING_NAME = "需要場所住所（建物・部屋名）";
  /** データレコード：需要場所住所（建物・部屋名）-文字数 */
  public static final int DATA_PLACE_ADDRESS_BUILDING_LENGTH = 36;
  /** データレコード：需要場所住所（建物・部屋名）-文字数(文字列) */
  public static final String DATA_PLACE_ADDRESS_BUILDING_LENGTH_STRING = String
      .valueOf(DATA_PLACE_ADDRESS_BUILDING_LENGTH);

  /** データレコード：地点特定番号-インデックス */
  public static final int DATA_SPOT_NO_INDEX = 6;
  /** データレコード：地点特定番号-名称 */
  public static final String DATA_SPOT_NO_NAME = "地点特定番号";
  /** データレコード：地点特定番号-文字数 */
  public static final int DATA_SPOT_NO_LENGTH = 22;
  /** データレコード：地点特定番号-文字数(文字列) */
  public static final String DATA_SPOT_NO_LENGTH_STRING = String.valueOf(DATA_SPOT_NO_LENGTH);

  /** データレコード：需要家識別番号-インデックス */
  public static final int DATA_CONTRACTOR_IDENTIFICATION_NO_INDEX = 7;
  /** データレコード：需要家識別番号-名称 */
  public static final String DATA_CONTRACTOR_IDENTIFICATION_NO_NAME = "需要家識別番号";
  /** データレコード：需要家識別番号-文字数 */
  public static final int DATA_CONTRACTOR_IDENTIFICATION_NO_LENGTH = 21;
  /** データレコード：需要家識別番号-文字数(文字列) */
  public static final String DATA_CONTRACTOR_IDENTIFICATION_NO_LENGTH_STRING = String
      .valueOf(DATA_CONTRACTOR_IDENTIFICATION_NO_LENGTH);

  /** データレコード：エリアコード-インデックス */
  public static final int DATA_AREA_CODE_INDEX = 8;
  /** データレコード：エリアコード-名称 */
  public static final String DATA_AREA_CODE_NAME = "エリアコード";

  /** データレコード：基本検針日-インデックス */
  public static final int DATA_BASIC_METER_READING_DATE_INDEX = 9;
  /** データレコード：基本検針日-名称 */
  public static final String DATA_BASIC_METER_READING_DATE_NAME = "基本検針日";
  /** データレコード：基本検針日-最小数 */
  public static final int DATA_BASIC_METER_READING_DATE_RANGE_MIN = 1;
  /** データレコード：基本検針日-最大数 */
  public static final int DATA_BASIC_METER_READING_DATE_RANGE_MAX = 31;
  /** データレコード：基本検針日-メッセージ文言 */
  public static final String DATA_BASIC_METER_READING_DATE_MESSAGE = new StringBuilder()
      .append(DATA_BASIC_METER_READING_DATE_RANGE_MIN).append("～")
      .append(DATA_BASIC_METER_READING_DATE_RANGE_MAX).toString();

  /** データレコード：次回検針予定日-インデックス */
  public static final int DATA_NEXT_METER_READING_SCHEDULED_DATE_INDEX = 10;
  /** データレコード：次回検針予定日-名称 */
  public static final String DATA_NEXT_METER_READING_SCHEDULED_DATE_NAME = "次回検針予定日";
  /** データレコード：次回検針予定日-フォーマット */
  public static final String DATA_NEXT_METER_READING_SCHEDULED_DATE_FORMAT = ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH;
  /** データレコード：次回検針予定日-メッセージ文言 */
  public static final String DATA_NEXT_METER_READING_SCHEDULED_DATE_MESSAGE = new StringBuilder(
      "日付形式（").append(DATA_NEXT_METER_READING_SCHEDULED_DATE_FORMAT)
          .append("）").toString();

  /** データレコード：前回検針日-インデックス */
  public static final int DATA_LAST_TIME_METER_READING_DATE_INDEX = 11;
  /** データレコード：前回検針日-名称 */
  public static final String DATA_LAST_TIME_METER_READING_DATE_NAME = "前回検針日";
  /** データレコード：前回検針日-フォーマット */
  public static final String DATA_LAST_TIME_METER_READING_DATE_FORMAT = ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH;
  /** データレコード：前回検針日-メッセージ文言 */
  public static final String DATA_LAST_TIME_METER_READING_DATE_MESSAGE = new StringBuilder(
      "日付形式（").append(DATA_LAST_TIME_METER_READING_DATE_FORMAT)
          .append("）").toString();

  /** データレコード：送受電区分コード-インデックス */
  public static final int DATA_TRANSMISSION_CATEGORY_CODE_INDEX = 12;
  /** データレコード：送受電区分コード-名称 */
  public static final String DATA_TRANSMISSION_CATEGORY_CODE_NAME = "送受電区分コード";

  /** データレコード：自家発連携有無コード-インデックス */
  public static final int DATA_GENERATOR_LINKAGE_CHECK_CODE_INDEX = 13;
  /** データレコード：自家発連携有無コード-名称 */
  public static final String DATA_GENERATOR_LINKAGE_CHECK_CODE_NAME = "自家発連携有無コード";

  /** データレコード：供給方式コード-インデックス */
  public static final int DATA_SUPPLY_METHOD_CODE_INDEX = 14;
  /** データレコード：供給方式コード-名称 */
  public static final String DATA_SUPPLY_METHOD_CODE_NAME = "供給方式コード";

  /** データレコード：計器識別番号1-インデックス */
  public static final int DATA_METER_IDENTIFICATION_NO1_INDEX = 15;
  /** データレコード：計器識別番号1-名称 */
  public static final String DATA_METER_IDENTIFICATION_NO1_NAME = "計器識別番号1";
  /** データレコード：計器識別番号1-文字数 */
  public static final int DATA_METER_IDENTIFICATION_NO1_LENGTH = 16;
  /** データレコード：計器識別番号1-文字数(文字列) */
  public static final String DATA_METER_IDENTIFICATION_NO1_LENGTH_STRING = String
      .valueOf(DATA_METER_IDENTIFICATION_NO1_LENGTH);

  /** データレコード：計器識別番号2-インデックス */
  public static final int DATA_METER_IDENTIFICATION_NO2_INDEX = 16;
  /** データレコード：計器識別番号2-名称 */
  public static final String DATA_METER_IDENTIFICATION_NO2_NAME = "計器識別番号2";
  /** データレコード：計器識別番号2-文字数 */
  public static final int DATA_METER_IDENTIFICATION_NO2_LENGTH = 16;
  /** データレコード：計器識別番号2-文字数(文字列) */
  public static final String DATA_METER_IDENTIFICATION_NO2_LENGTH_STRING = String
      .valueOf(DATA_METER_IDENTIFICATION_NO2_LENGTH);

  /** データレコード：計器識別番号3-インデックス */
  public static final int DATA_METER_IDENTIFICATION_NO3_INDEX = 17;
  /** データレコード：計器識別番号3-名称 */
  public static final String DATA_METER_IDENTIFICATION_NO3_NAME = "計器識別番号3";
  /** データレコード：計器識別番号3-文字数 */
  public static final int DATA_METER_IDENTIFICATION_NO3_LENGTH = 16;
  /** データレコード：計器識別番号3-文字数(文字列) */
  public static final String DATA_METER_IDENTIFICATION_NO3_LENGTH_STRING = String
      .valueOf(DATA_METER_IDENTIFICATION_NO3_LENGTH);

  /** データレコード：計器識別番号4-インデックス */
  public static final int DATA_METER_IDENTIFICATION_NO4_INDEX = 18;
  /** データレコード：計器識別番号4-名称 */
  public static final String DATA_METER_IDENTIFICATION_NO4_NAME = "計器識別番号4";
  /** データレコード：計器識別番号4-文字数 */
  public static final int DATA_METER_IDENTIFICATION_NO4_LENGTH = 16;
  /** データレコード：計器識別番号4-文字数(文字列) */
  public static final String DATA_METER_IDENTIFICATION_NO4_LENGTH_STRING = String
      .valueOf(DATA_METER_IDENTIFICATION_NO4_LENGTH);

  /** データレコード：計器識別番号5-インデックス */
  public static final int DATA_METER_IDENTIFICATION_NO5_INDEX = 19;
  /** データレコード：計器識別番号5-名称 */
  public static final String DATA_METER_IDENTIFICATION_NO5_NAME = "計器識別番号5";
  /** データレコード：計器識別番号5-文字数 */
  public static final int DATA_METER_IDENTIFICATION_NO5_LENGTH = 16;
  /** データレコード：計器識別番号5-文字数(文字列) */
  public static final String DATA_METER_IDENTIFICATION_NO5_LENGTH_STRING = String
      .valueOf(DATA_METER_IDENTIFICATION_NO5_LENGTH);

  /** データレコード：30分値収集可否・自動検針可否コード1-インデックス */
  public static final int DATA_AUTOMATIC_METER_READING_CHECK_CODE1_INDEX = 20;
  /** データレコード：30分値収集可否・自動検針可否コード1-名称 */
  public static final String DATA_AUTOMATIC_METER_READING_CHECK_CODE1_NAME = "30分値収集可否・自動検針可否コード1";

  /** データレコード：30分値収集可否・自動検針可否コード2-インデックス */
  public static final int DATA_AUTOMATIC_METER_READING_CHECK_CODE2_INDEX = 21;
  /** データレコード：30分値収集可否・自動検針可否コード2-名称 */
  public static final String DATA_AUTOMATIC_METER_READING_CHECK_CODE2_NAME = "30分値収集可否・自動検針可否コード2";

  /** データレコード：30分値収集可否・自動検針可否コード3-インデックス */
  public static final int DATA_AUTOMATIC_METER_READING_CHECK_CODE3_INDEX = 22;
  /** データレコード：30分値収集可否・自動検針可否コード3-名称 */
  public static final String DATA_AUTOMATIC_METER_READING_CHECK_CODE3_NAME = "30分値収集可否・自動検針可否コード3";

  /** データレコード：30分値収集可否・自動検針可否コード4-インデックス */
  public static final int DATA_AUTOMATIC_METER_READING_CHECK_CODE4_INDEX = 23;
  /** データレコード：30分値収集可否・自動検針可否コード4-名称 */
  public static final String DATA_AUTOMATIC_METER_READING_CHECK_CODE4_NAME = "30分値収集可否・自動検針可否コード4";

  /** データレコード：30分値収集可否・自動検針可否コード5-インデックス */
  public static final int DATA_AUTOMATIC_METER_READING_CHECK_CODE5_INDEX = 24;
  /** データレコード：30分値収集可否・自動検針可否コード5-名称 */
  public static final String DATA_AUTOMATIC_METER_READING_CHECK_CODE5_NAME = "30分値収集可否・自動検針可否コード5";

  /** データレコード：検針日区分コード-インデックス */
  public static final int METER_READING_DATE_CATEGORY_CODE_INDEX = 25;
  /** データレコード：検針日区分コード-名称 */
  public static final String METER_READING_DATE_CATEGORY_CODE_NAME = "検針日区分コード";

  /** データレコード：フリー項目1-インデックス */
  public static final int DATA_FREE_01_INDEX = 26;
  /** データレコード：フリー項目1-名称 */
  public static final String DATA_FREE_01_NAME = "フリー項目1";
  /** データレコード：フリー項目1-文字数 */
  public static final int DATA_FREE_01_LENGTH = 200;
  /** データレコード：フリー項目1-文字数(文字列) */
  public static final String DATA_FREE_01_LENGTH_STRING = String
      .valueOf(DATA_FREE_01_LENGTH);

  /** データレコード：フリー項目2-インデックス */
  public static final int DATA_FREE_02_INDEX = 27;
  /** データレコード：フリー項目2-名称 */
  public static final String DATA_FREE_02_NAME = "フリー項目2";
  /** データレコード：フリー項目2-文字数 */
  public static final int DATA_FREE_02_LENGTH = 200;
  /** データレコード：フリー項目2-文字数(文字列) */
  public static final String DATA_FREE_02_LENGTH_STRING = String
      .valueOf(DATA_FREE_02_LENGTH);

  /** データレコード：フリー項目3-インデックス */
  public static final int DATA_FREE_03_INDEX = 28;
  /** データレコード：フリー項目3-名称 */
  public static final String DATA_FREE_03_NAME = "フリー項目3";
  /** データレコード：フリー項目3-文字数 */
  public static final int DATA_FREE_03_LENGTH = 200;
  /** データレコード：フリー項目3-文字数(文字列) */
  public static final String DATA_FREE_03_LENGTH_STRING = String
      .valueOf(DATA_FREE_03_LENGTH);

  /** データレコード：フリー項目4-インデックス */
  public static final int DATA_FREE_04_INDEX = 29;
  /** データレコード：フリー項目4-名称 */
  public static final String DATA_FREE_04_NAME = "フリー項目4";
  /** データレコード：フリー項目4-文字数 */
  public static final int DATA_FREE_04_LENGTH = 200;
  /** データレコード：フリー項目4-文字数(文字列) */
  public static final String DATA_FREE_04_LENGTH_STRING = String
      .valueOf(DATA_FREE_04_LENGTH);

  /** データレコード：フリー項目5-インデックス */
  public static final int DATA_FREE_05_INDEX = 30;
  /** データレコード：フリー項目5-名称 */
  public static final String DATA_FREE_05_NAME = "フリー項目5";
  /** データレコード：フリー項目5-文字数 */
  public static final int DATA_FREE_05_LENGTH = 200;
  /** データレコード：フリー項目5-文字数(文字列) */
  public static final String DATA_FREE_05_LENGTH_STRING = String
      .valueOf(DATA_FREE_05_LENGTH);

  /** データレコード：フリー項目6-インデックス */
  public static final int DATA_FREE_06_INDEX = 31;
  /** データレコード：フリー項目6-名称 */
  public static final String DATA_FREE_06_NAME = "フリー項目6";
  /** データレコード：フリー項目6-文字数 */
  public static final int DATA_FREE_06_LENGTH = 200;
  /** データレコード：フリー項目6-文字数(文字列) */
  public static final String DATA_FREE_06_LENGTH_STRING = String
      .valueOf(DATA_FREE_06_LENGTH);

  /** データレコード：フリー項目7-インデックス */
  public static final int DATA_FREE_07_INDEX = 32;
  /** データレコード：フリー項目7-名称 */
  public static final String DATA_FREE_07_NAME = "フリー項目7";
  /** データレコード：フリー項目7-文字数 */
  public static final int DATA_FREE_07_LENGTH = 200;
  /** データレコード：フリー項目7-文字数(文字列) */
  public static final String DATA_FREE_07_LENGTH_STRING = String
      .valueOf(DATA_FREE_07_LENGTH);

  /** データレコード：フリー項目8-インデックス */
  public static final int DATA_FREE_08_INDEX = 33;
  /** データレコード：フリー項目8-名称 */
  public static final String DATA_FREE_08_NAME = "フリー項目8";
  /** データレコード：フリー項目8-文字数 */
  public static final int DATA_FREE_08_LENGTH = 200;
  /** データレコード：フリー項目8-文字数(文字列) */
  public static final String DATA_FREE_08_LENGTH_STRING = String
      .valueOf(DATA_FREE_08_LENGTH);

  /** データレコード：フリー項目9-インデックス */
  public static final int DATA_FREE_09_INDEX = 34;
  /** データレコード：フリー項目9-名称 */
  public static final String DATA_FREE_09_NAME = "フリー項目9";
  /** データレコード：フリー項目9-文字数 */
  public static final int DATA_FREE_09_LENGTH = 200;
  /** データレコード：フリー項目9-文字数(文字列) */
  public static final String DATA_FREE_09_LENGTH_STRING = String
      .valueOf(DATA_FREE_09_LENGTH);

  /** データレコード：フリー項目10-インデックス */
  public static final int DATA_FREE_10_INDEX = 35;
  /** データレコード：フリー項目10-名称 */
  public static final String DATA_FREE_10_NAME = "フリー項目10";
  /** データレコード：フリー項目10-文字数 */
  public static final int DATA_FREE_10_LENGTH = 200;
  /** データレコード：フリー項目10-文字数(文字列) */
  public static final String DATA_FREE_10_LENGTH_STRING = String
      .valueOf(DATA_FREE_10_LENGTH);

  /** データレコード：更新回数-インデックス */
  public static final int DATA_UPDATE_COUNT_INDEX = 36;
  /** データレコード：更新回数-名称 */
  public static final String DATA_UPDATE_COUNT_NAME = "更新回数";
  /** データレコード：更新回数-最小数 */
  public static final int DATA_UPDATE_COUNT_RANGE_MIN = 0;
  /** データレコード：更新回数-最大数 */
  public static final int DATA_UPDATE_COUNT_RANGE_MAX = 2147483647;
  /** データレコード：更新回数-メッセージ文言 */
  public static final String DATA_UPDATE_COUNT_MESSAGE = new StringBuilder().append(DATA_UPDATE_COUNT_RANGE_MIN)
      .append("～")
      .append(DATA_UPDATE_COUNT_RANGE_MAX).toString();

  /** データレコード：登録・更新区分-インデックス */
  public static final int DATA_REGISTER_UPDATE_CATEGORY_INDEX = 37;
  /** データレコード：登録・更新区分-名称 */
  public static final String DATA_REGISTER_UPDATE_CATEGORY_NAME = "登録・更新区分";

  /**
   * staticイニシャライザ.<br>
   * タイトル行の生成を行う<br>
   * インデックス=タイトル配列のインデックスになるため、番号は自動で設定される<br>
   * カラムの追加・削除があった場合に修正が必要
   */
  static {
    Map<Integer, String> titleMap = new HashMap<Integer, String>();

    // 項目を順番に入れ込んでいく
    // レコード種別は共通のものを使う
    titleMap.put(ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_INDEX,
        ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_NAME);

    titleMap.put(DATA_METER_LOCATION_ID_INDEX, DATA_METER_LOCATION_ID_NAME);
    titleMap.put(DATA_CONTRACT_NO_INDEX, DATA_CONTRACT_NO_NAME);
    titleMap.put(DATA_PLACE_ADDRESS_POSTAL_CODE_INDEX, DATA_PLACE_ADDRESS_POSTAL_CODE_NAME);
    titleMap.put(DATA_PLACE_ADDRESS_FULL_INDEX, DATA_PLACE_ADDRESS_FULL_NAME);
    titleMap.put(DATA_PLACE_ADDRESS_BUILDING_INDEX, DATA_PLACE_ADDRESS_BUILDING_NAME);
    titleMap.put(DATA_SPOT_NO_INDEX, DATA_SPOT_NO_NAME);
    titleMap.put(DATA_CONTRACTOR_IDENTIFICATION_NO_INDEX, DATA_CONTRACTOR_IDENTIFICATION_NO_NAME);
    titleMap.put(DATA_AREA_CODE_INDEX, DATA_AREA_CODE_NAME);
    titleMap.put(DATA_BASIC_METER_READING_DATE_INDEX, DATA_BASIC_METER_READING_DATE_NAME);
    titleMap.put(DATA_NEXT_METER_READING_SCHEDULED_DATE_INDEX, DATA_NEXT_METER_READING_SCHEDULED_DATE_NAME);
    titleMap.put(DATA_LAST_TIME_METER_READING_DATE_INDEX, DATA_LAST_TIME_METER_READING_DATE_NAME);
    titleMap.put(DATA_TRANSMISSION_CATEGORY_CODE_INDEX, DATA_TRANSMISSION_CATEGORY_CODE_NAME);
    titleMap.put(DATA_GENERATOR_LINKAGE_CHECK_CODE_INDEX, DATA_GENERATOR_LINKAGE_CHECK_CODE_NAME);
    titleMap.put(DATA_SUPPLY_METHOD_CODE_INDEX, DATA_SUPPLY_METHOD_CODE_NAME);
    titleMap.put(DATA_METER_IDENTIFICATION_NO1_INDEX, DATA_METER_IDENTIFICATION_NO1_NAME);
    titleMap.put(DATA_METER_IDENTIFICATION_NO2_INDEX, DATA_METER_IDENTIFICATION_NO2_NAME);
    titleMap.put(DATA_METER_IDENTIFICATION_NO3_INDEX, DATA_METER_IDENTIFICATION_NO3_NAME);
    titleMap.put(DATA_METER_IDENTIFICATION_NO4_INDEX, DATA_METER_IDENTIFICATION_NO4_NAME);
    titleMap.put(DATA_METER_IDENTIFICATION_NO5_INDEX, DATA_METER_IDENTIFICATION_NO5_NAME);
    titleMap.put(DATA_AUTOMATIC_METER_READING_CHECK_CODE1_INDEX, DATA_AUTOMATIC_METER_READING_CHECK_CODE1_NAME);
    titleMap.put(DATA_AUTOMATIC_METER_READING_CHECK_CODE2_INDEX, DATA_AUTOMATIC_METER_READING_CHECK_CODE2_NAME);
    titleMap.put(DATA_AUTOMATIC_METER_READING_CHECK_CODE3_INDEX, DATA_AUTOMATIC_METER_READING_CHECK_CODE3_NAME);
    titleMap.put(DATA_AUTOMATIC_METER_READING_CHECK_CODE4_INDEX, DATA_AUTOMATIC_METER_READING_CHECK_CODE4_NAME);
    titleMap.put(DATA_AUTOMATIC_METER_READING_CHECK_CODE5_INDEX, DATA_AUTOMATIC_METER_READING_CHECK_CODE5_NAME);
    titleMap.put(METER_READING_DATE_CATEGORY_CODE_INDEX, METER_READING_DATE_CATEGORY_CODE_NAME);
    titleMap.put(DATA_FREE_01_INDEX, DATA_FREE_01_NAME);
    titleMap.put(DATA_FREE_02_INDEX, DATA_FREE_02_NAME);
    titleMap.put(DATA_FREE_03_INDEX, DATA_FREE_03_NAME);
    titleMap.put(DATA_FREE_04_INDEX, DATA_FREE_04_NAME);
    titleMap.put(DATA_FREE_05_INDEX, DATA_FREE_05_NAME);
    titleMap.put(DATA_FREE_06_INDEX, DATA_FREE_06_NAME);
    titleMap.put(DATA_FREE_07_INDEX, DATA_FREE_07_NAME);
    titleMap.put(DATA_FREE_08_INDEX, DATA_FREE_08_NAME);
    titleMap.put(DATA_FREE_09_INDEX, DATA_FREE_09_NAME);
    titleMap.put(DATA_FREE_10_INDEX, DATA_FREE_10_NAME);
    titleMap.put(DATA_UPDATE_COUNT_INDEX, DATA_UPDATE_COUNT_NAME);
    titleMap.put(DATA_REGISTER_UPDATE_CATEGORY_INDEX, DATA_REGISTER_UPDATE_CATEGORY_NAME);

    Iterator<Integer> it = titleMap.keySet().iterator();
    String[] titleArray = new String[titleMap.size()];
    while (it.hasNext()) {
      Integer key = it.next();
      titleArray[key] = titleMap.get(key);
    }
    DATA_TITLE_ROW = titleArray;
    DATA_COLUMN_COUNT = DATA_TITLE_ROW.length;
  }
}
