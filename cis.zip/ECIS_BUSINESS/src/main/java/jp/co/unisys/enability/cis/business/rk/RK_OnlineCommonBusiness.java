package jp.co.unisys.enability.cis.business.rk;

import java.util.Date;

import jp.co.unisys.enability.cis.business.rk.model.RK_OnlineCommonBusinessBean;
import jp.co.unisys.enability.cis.common.Exception.BusinessLogicException;

/**
 * 料金計算オンライン共通ビジネスインターフェース。
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.mapper.common.FcrMapper
 * @see jp.co.unisys.enability.cis.mapper.common.FcrBreakdownMapper
 * @see jp.co.unisys.enability.cis.mapper.common.FuMapper
 * @see jp.co.unisys.enability.cis.mapper.common.FixInMapper
 * @see jp.co.unisys.enability.cis.mapper.common.ContractMapper
 * @see jp.co.unisys.enability.cis.mapper.common.RmMapper
 * @see jp.co.unisys.enability.cis.mapper.common.FcrWarningDataMapper
 * @see jp.co.unisys.enability.cis.dao.rk.RK_OnlineCommonDao
 * @see jp.co.unisys.enability.cis.rate_engine.business.RateEngineBusiness
 */
public interface RK_OnlineCommonBusiness {

  /**
   * 確定料金実績を取得する。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された条件で、料金計算結果修正・補正画面および料金再現計算画面で必要な下記の情報を取得する。
   * 1.確定料金実績を取得する。
   * 2.契約を取得する。
   * 3.料金メニューを取得する。
   * 4.確定料金実績警告データを取得する。
   * 5.確定料金実績内訳を取得する。
   * 6.付帯メニュー
   * 7.使用量（確定使用量、確定指示数、時間帯別使用量）を取得する。
   * 8.最新の使用量（確定使用量、確定指示数、時間帯別使用量）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param businessBean
   *          料金計算オンライン共通ビジネスBean
   * @throws BusinessLogicException
   *           業務例外が発生した場合
   * @see jp.co.unisys.enability.cis.mapper.common.FcrMapper
   * @see jp.co.unisys.enability.cis.mapper.common.FcrBreakdownMapper
   * @see jp.co.unisys.enability.cis.mapper.common.ContractMapper
   * @see jp.co.unisys.enability.cis.mapper.common.RmMapper
   * @see jp.co.unisys.enability.cis.mapper.common.FcrWarningDataMapper
   * @see jp.co.unisys.enability.cis.dao.rk.RK_OnlineCommonDao
   */
  void selectFixChargeResult(RK_OnlineCommonBusinessBean businessBean) throws BusinessLogicException;

  /**
   * 使用量を取得する。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された条件で、確定使用量IDに紐ずく使用量（確定使用量、確定指示数、時間帯別使用量）、
   * または、契約IDおよび利用年月を条件に、最新の使用量（確定使用量、確定指示数、時間帯別使用量）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param businessBean
   *          料金計算オンライン共通ビジネスBean
   * @throws BusinessLogicException
   *           業務例外が発生した場合
   * @see jp.co.unisys.enability.cis.mapper.common.FuMapper
   * @see jp.co.unisys.enability.cis.mapper.common.FixInMapper
   * @see jp.co.unisys.enability.cis.dao.rk.RK_OnlineCommonDao
   */
  void selectUsageQuantity(RK_OnlineCommonBusinessBean businessBean) throws BusinessLogicException;

  /**
   * 料金の再計算を行う。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された条件で、料金計算エンジンを呼び出し、料金の計算結果を返却する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param businessBean
   *          料金計算オンライン共通ビジネスBean
   * @see jp.co.unisys.enability.cis.rate_engine.business.RateEngineBusiness
   */
  void calculateRetryRate(RK_OnlineCommonBusinessBean businessBean);

  // 商品化追加開発：料金シミュレーション ykomoto 2016/04/20 Edit Start
  /**
   * 料金のシミュレーションを行う。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された条件で、料金計算エンジンを呼び出し、料金の計算結果を返却する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param businessBean
   *          料金計算オンライン共通ビジネスBean
   * @param upBaseDate
   *          単価基準日
   * @see jp.co.unisys.enability.cis.rate_engine.business.RateEngineBusiness
   */
  void rateSimulation(RK_OnlineCommonBusinessBean businessBean, Date upBaseDate);
  // 商品化追加開発：料金シミュレーション ykomoto 2016/04/20 Edit End

  /**
   * 制限中止割引額算出処理を行う。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された条件で、制限中止割引額算出処理を呼び出し、
   * 補正分類、 補正額（円）、項目名称を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param businessBean
   *          料金計算オンライン共通ビジネスBean
   * @throws BusinessLogicException
   * @see jp.co.unisys.enability.cis.rate_engine.business.RateEngineBusiness
   */
  void limitingDiscontinuedDiscountCalculate(RK_OnlineCommonBusinessBean businessBean) throws BusinessLogicException;

}
