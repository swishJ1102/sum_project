package jp.co.unisys.enability.cis.business.rk;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.config.PropertiesFactoryBean;
import org.springframework.context.MessageSource;

import jp.co.unisys.enability.cis.business.rk.model.RK_ConsumptionTaxEquivalentCalcBusinessBean;
import jp.co.unisys.enability.cis.common.Exception.SystemException;
import jp.co.unisys.enability.cis.common.util.RK_PropertyUtil;
import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;
import jp.co.unisys.enability.cis.entity.common.CtRateM;
import jp.co.unisys.enability.cis.entity.common.CtRateMExample;
import jp.co.unisys.enability.cis.mapper.common.CtRateMMapper;

/**
 * 消費税等相当額計算ビジネス
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_ConsumptionTaxEquivalentCalcBusinessImpl implements RK_ConsumptionTaxEquivalentCalcBusiness {

  /**
   * 消費税率マスタMapper(DI)
   */
  private CtRateMMapper ctRateMMapper;

  /**
   * メッセージソース(DI)
   */
  private MessageSource messageSource;

  /**
   * プロパティ(DI)
   */
  private PropertiesFactoryBean applicationProperties;

  /*
   * (非 Javadoc)
   * @see jp.co.unisys.enability.cis.business.rk.RK_ConsumptionTaxEquivalentCalcBusiness#calculate(jp.co.unisys.enability.cis.business.rk.model.RK_ConsumptionTaxEquivalentCalcBusinessBean)
   */
  @Override
  public RK_ConsumptionTaxEquivalentCalcBusinessBean calculate(
      RK_ConsumptionTaxEquivalentCalcBusinessBean consumptionTaxEquivalentCalcBusinessBean) {
    // 引数チェック
    this.validateArgs(consumptionTaxEquivalentCalcBusinessBean);

    // パラメータ設定
    BigDecimal amount = consumptionTaxEquivalentCalcBusinessBean.getAmount();
    Date baseDate1 = consumptionTaxEquivalentCalcBusinessBean.getBaseDate1();
    Date baseDate2 = consumptionTaxEquivalentCalcBusinessBean.getBaseDate2();

    // 消費税率判定方法取得
    String consumptionJudgeFlag = RK_PropertyUtil.getProperty(applicationProperties,
        "consumption.tax.rate.judge.flag");
    // 基準日設定
    // 1の場合、基準日1。それ以外の場合、基準日2
    Date judgeBaseDate = ECISRKConstants.CONSUMPTION_TAX_RATE_JUDGE_FLAG_DATE1.equals(consumptionJudgeFlag)
        ? baseDate1
        : baseDate2;

    // 消費税率マスタ取得
    // 条件設定
    CtRateMExample ctRateMExample = new CtRateMExample();
    // 適用開始日 <= 基準日 <= 適用終了日
    ctRateMExample.createCriteria().andApplySdLessThanOrEqualTo(judgeBaseDate)
        .andApplyEdGreaterThanOrEqualTo(judgeBaseDate);
    // 取得実行
    List<CtRateM> ctRateMList = ctRateMMapper.selectByExample(ctRateMExample);
    // 取得出来なかった場合、システムエラー
    if (CollectionUtils.isEmpty(ctRateMList)) {
      throw new SystemException(messageSource.getMessage(
          "error.E0006", new String[] {
              RK_PropertyUtil.getProperty(applicationProperties,
                  "business.rk.system.error.get.master.consumption.tax.rate") },
          Locale.getDefault()));
    }

    // 消費税率取得
    // 1件しか返ってこないはずの条件のため、リストの1件目から取得する
    CtRateM ctRateM = ctRateMList.get(0);

    // 消費税相当額計算
    Short applyTaxRate = ctRateM.getApplyTaxRate();
    BigDecimal applyTaxRateDecimal = BigDecimal.valueOf(applyTaxRate);
    BigDecimal devidePercent = ECISRKConstants.RATE_DIVIDE_VAL.add(applyTaxRateDecimal);
    // 金額 * 消費税率 / (100 + 消費税率) の小数点以下切捨てを取得
    BigDecimal consumptionTaxEquivalent = amount.multiply(applyTaxRateDecimal).divide(devidePercent, 0,
        BigDecimal.ROUND_DOWN);

    // 戻り値設定
    RK_ConsumptionTaxEquivalentCalcBusinessBean returnBean = new RK_ConsumptionTaxEquivalentCalcBusinessBean();
    // 消費税率
    returnBean.setConsumptionTaxRate(applyTaxRate);
    // 消費税科目コード
    returnBean.setConsumptionTaxItemCode(ctRateM.getCtIc());
    // 消費税相当額
    returnBean.setConsumptionTaxEquivalent(Integer.valueOf(consumptionTaxEquivalent.intValue()));

    return returnBean;
  }

  /**
   * 引数チェックを行う。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 指定された引数に必要な情報が設定されているかをチェックする。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param inputBusinessBean
   *          消費税等相当額計算ビジネスBean
   */
  private void validateArgs(RK_ConsumptionTaxEquivalentCalcBusinessBean inputBusinessBean) {
    // 引数が設定されていない場合、システムエラー
    // 金額
    if (inputBusinessBean.getAmount() == null) {
      throw new SystemException(messageSource.getMessage("validation.argumentrequired",
          new String[] {RK_PropertyUtil.getProperty(applicationProperties,
              "validation.error.argumentrequired.amount") },
          Locale.getDefault()));
    }
    // 基準日1
    if (inputBusinessBean.getBaseDate1() == null) {
      throw new SystemException(messageSource.getMessage("validation.argumentrequired",
          new String[] {RK_PropertyUtil.getProperty(applicationProperties,
              "validation.error.argumentrequired.check.base.date1") },
          Locale.getDefault()));
    }
    // 基準日2
    if (inputBusinessBean.getBaseDate2() == null) {
      throw new SystemException(messageSource.getMessage("validation.argumentrequired",
          new String[] {RK_PropertyUtil.getProperty(applicationProperties,
              "validation.error.argumentrequired.check.base.date2") },
          Locale.getDefault()));
    }
  }

  /**
   * 消費税率マスタMapperのsetter（DI）
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 消費税率マスタMapperを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param ctRateMMapper
   *          消費税率マスタMapper
   */
  public void setCtRateMMapper(CtRateMMapper ctRateMMapper) {
    this.ctRateMMapper = ctRateMMapper;
  }

  /**
   * メッセージソースのsetter（DI）
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージソースを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param messageSource
   *          メッセージソース
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }

  /**
   * プロパティのsetter（DI）
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * プロパティを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param applicationProperties
   *          プロパティ
   */
  public void setApplicationProperties(PropertiesFactoryBean applicationProperties) {
    this.applicationProperties = applicationProperties;
  }

}
