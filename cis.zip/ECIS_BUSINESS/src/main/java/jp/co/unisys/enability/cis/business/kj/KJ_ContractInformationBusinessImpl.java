package jp.co.unisys.enability.cis.business.kj;

import java.io.File;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.DuplicateKeyException;

import jp.co.unisys.enability.cis.business.common.DateBusiness;
import jp.co.unisys.enability.cis.business.gk.ContractInformationFileDeleteValidator;
import jp.co.unisys.enability.cis.business.gk.ContractInformationFileRegistValidator;
import jp.co.unisys.enability.cis.business.gk.ContractInformationFileUpdateValidator;
import jp.co.unisys.enability.cis.business.gk.ContractManagementInformationFileHeaderValidator;
import jp.co.unisys.enability.cis.business.gk.Custom_ContractInformationFileDeleteValidator;
import jp.co.unisys.enability.cis.business.gk.Custom_ContractInformationFileRegistValidator;
import jp.co.unisys.enability.cis.business.gk.Custom_ContractInformationFileUpdateValidator;
import jp.co.unisys.enability.cis.business.kj.model.AddContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.AddSupplementaryContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.ContractManagementInformationFileConfigCommon;
import jp.co.unisys.enability.cis.business.kj.model.ContractManagementInformationFileConfigContract;
import jp.co.unisys.enability.cis.business.kj.model.CsvFileCheckContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.CsvFileCheckRmUpDetailBean;
import jp.co.unisys.enability.cis.business.kj.model.Custom_ContractManagementInformationFileConfigContract;
import jp.co.unisys.enability.cis.business.kj.model.DeleteContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.DownloadContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.InquiryContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.InquiryContractorBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.InquiryMeterLocationBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.InquiryPaymentBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.InquirySupplementaryContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.RegistContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.RegistMeterLocationBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.UpdateContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.UpdateMeterLocationBusinessBean;
import jp.co.unisys.enability.cis.common.Exception.BusinessLogicException;
import jp.co.unisys.enability.cis.common.Exception.SystemException;
import jp.co.unisys.enability.cis.common.util.CommonValidationUtil;
import jp.co.unisys.enability.cis.common.util.DateCalculateUtil;
import jp.co.unisys.enability.cis.common.util.EMSConstants;
import jp.co.unisys.enability.cis.common.util.KJ_CommonUtil;
import jp.co.unisys.enability.cis.common.util.RK_CommonUtil;
import jp.co.unisys.enability.cis.common.util.StringConvertUtil;
import jp.co.unisys.enability.cis.common.util.ThreadContext;
import jp.co.unisys.enability.cis.common.util.constants.ECISCodeConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISKJConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISReturnCodeConstants;
import jp.co.unisys.enability.cis.common.util.model.CheckContactInformationUtilBean;
import jp.co.unisys.enability.cis.dao.kj.ContractManagementInformationDownloadSearchInformationBean;
import jp.co.unisys.enability.cis.entity.common.BusinessMExample;
import jp.co.unisys.enability.cis.entity.common.CcaUnitM;
import jp.co.unisys.enability.cis.entity.common.CcdCategoryMExample;
import jp.co.unisys.enability.cis.entity.common.Contract;
import jp.co.unisys.enability.cis.entity.common.ContractEndReasonM;
import jp.co.unisys.enability.cis.entity.common.ContractExample;
import jp.co.unisys.enability.cis.entity.common.ContractHist;
import jp.co.unisys.enability.cis.entity.common.ContractHistExample;
import jp.co.unisys.enability.cis.entity.common.CssCatM;
import jp.co.unisys.enability.cis.entity.common.IlcM;
import jp.co.unisys.enability.cis.entity.common.MlContractHist;
import jp.co.unisys.enability.cis.entity.common.MlContractHistExample;
import jp.co.unisys.enability.cis.entity.common.MlExample;
import jp.co.unisys.enability.cis.entity.common.PhoneNoCatM;
import jp.co.unisys.enability.cis.entity.common.Rm;
import jp.co.unisys.enability.cis.entity.common.RmExample;
import jp.co.unisys.enability.cis.entity.common.RmMByPmCompany;
import jp.co.unisys.enability.cis.entity.common.RmMByPmCompanyKey;
import jp.co.unisys.enability.cis.entity.common.ScM;
import jp.co.unisys.enability.cis.entity.common.ScMExample;
import jp.co.unisys.enability.cis.entity.common.SplContract;
import jp.co.unisys.enability.cis.entity.common.SplContractExample;
import jp.co.unisys.enability.cis.entity.common.UpsCategoryM;
import jp.co.unisys.enability.cis.entity.common.VoltageCatMExample;
import jp.co.unisys.enability.cis.entity.kj.KJ_ContractHistoryInformationEntityBean;
import jp.co.unisys.enability.cis.entity.kj.KJ_ContractHistoryUpdateCountEntityBean;
import jp.co.unisys.enability.cis.entity.kj.KJ_ContractInformationFileEntityBean;
import jp.co.unisys.enability.cis.entity.kj.KJ_InquiryContractInformationEntityBean;
import jp.co.unisys.enability.cis.entity.kj.KJ_InquiryContractorInformationEntityBean;
import jp.co.unisys.enability.cis.entity.kj.KJ_InquiryMeterLocationEntityBean;
import jp.co.unisys.enability.cis.entity.kj.KJ_InquiryPaymentInformationEntityBean;
import jp.co.unisys.enability.cis.entity.kj.KJ_SupplementaryContractBean;
import jp.co.unisys.enability.cis.entity.kj.KJ_SupplementaryContractInformationEntityBean;
import jp.co.unisys.enability.cis.entity.kj.KJ_UrgeManagementInformationEntityBean;
import jp.co.unisys.enability.cis.mapper.common.BusinessMMapper;
import jp.co.unisys.enability.cis.mapper.common.CcaUnitMMapper;
import jp.co.unisys.enability.cis.mapper.common.CcdCategoryMMapper;
import jp.co.unisys.enability.cis.mapper.common.ContractEndReasonMMapper;
import jp.co.unisys.enability.cis.mapper.common.ContractHistMapper;
import jp.co.unisys.enability.cis.mapper.common.ContractMapper;
import jp.co.unisys.enability.cis.mapper.common.CssCatMMapper;
import jp.co.unisys.enability.cis.mapper.common.IlcMMapper;
import jp.co.unisys.enability.cis.mapper.common.MlContractHistMapper;
import jp.co.unisys.enability.cis.mapper.common.MlMapper;
import jp.co.unisys.enability.cis.mapper.common.PhoneNoCatMMapper;
import jp.co.unisys.enability.cis.mapper.common.RmMByPmCompanyMapper;
import jp.co.unisys.enability.cis.mapper.common.RmMapper;
import jp.co.unisys.enability.cis.mapper.common.ScMMapper;
import jp.co.unisys.enability.cis.mapper.common.SplContractMapper;
import jp.co.unisys.enability.cis.mapper.common.UpsCategoryMMapper;
import jp.co.unisys.enability.cis.mapper.common.VoltageCatMMapper;
import jp.co.unisys.enability.cis.mapper.kj.AgentContractInformationCommonMapper;
import jp.co.unisys.enability.cis.mapper.kj.ContractInformationCommonMapper;
import jp.co.unisys.enability.cis.mapper.kj.MeterLocationInformationCommonMapper;
import jp.co.unisys.enability.cis.mapper.rk.FixChargeResultInformationCommonMapper;
import jp.sf.orangesignal.csv.Csv;
import jp.sf.orangesignal.csv.handlers.ColumnPositionMapListHandler;

/**
 * 契約情報ビジネス
 *
 * @author "Nihon Unisys, Ltd."
 *
 */
public class KJ_ContractInformationBusinessImpl implements
    KJ_ContractInformationBusiness {

  /**
   * メッセージプロパティ(DI)
   */
  private MessageSource messageSource;
  /**
   * 契約マッパー(DI)
   */
  private ContractMapper contractMapper;
  /**
   * 契約情報共通マッパー(DI)
   */
  private ContractInformationCommonMapper contractInformationCommonMapper;
  /**
   * 確定料金共通マッパー(DI)
   */
  private FixChargeResultInformationCommonMapper fixChargeResultInformationCommonMapper;
  /**
   * 契約履歴マッパー(DI)
   */
  private ContractHistMapper contractHistMapper;
  /**
   * メーター設置場所契約履歴マッパー(DI)
   */
  private MlContractHistMapper mlContractHistMapper;
  /**
   * メーター設置場所マッパー(DI)
   */
  private MlMapper mlMapper;
  /**
   * 電話番号区分マッパー(DI)
   */
  private PhoneNoCatMMapper phoneNoCatMMapper;
  /**
   * 接続送電サービス区分マスタマッパー(DI)
   */
  private CssCatMMapper cssCatMMapper;
  /**
   * 契約終了理由マスタマッパー(DI)
   */
  private ContractEndReasonMMapper contractEndReasonMMapper;
  /**
   * 契約容量単位マスタマッパー(DI)
   */
  private CcaUnitMMapper ccaUnitMMapper;
  /**
   * 個人・法人区分マスタマッパー(DI)
   */
  private IlcMMapper ilcMMapper;
  /**
   * 営業委託先マスタマッパー(DI)
   */
  private ScMMapper scMMapper;
  /**
   * 料金メニューマッパー(DI)
   */
  private RmMapper rmMapper;
  /**
   * 電圧区分マッパー(DI)
   */
  private VoltageCatMMapper voltageCatMMapper;
  /**
   * 卸取次店向け契約情報マッパー(DI)
   */
  private AgentContractInformationCommonMapper agentContractInformationCommonMapper;
  /**
   * 単価設定区分マッパー(DI)
   */
  private UpsCategoryMMapper upsCategoryMMapper;
  /**
   * 契約電力決定区分マッパー(DI)
   */
  private CcdCategoryMMapper ccdCategoryMMapper;
  /**
   * 付帯契約情報マッパー(DI)
   */
  private SplContractMapper splContractMapper;
  /**
   * 提供モデル企業別料金メニューマスタマッパー(DI)
   */
  private RmMByPmCompanyMapper rmMByPmCompanyMapper;
  /**
   * 業種コードマッパー(DI)
   */
  private BusinessMMapper businessMMapper;
  /**
   * 契約者情報ビジネス(DI)
   */
  private KJ_ContractorInformationBusiness kjContractorInfomationBusiness;
  /**
   * メータ設置場所ビジネス(DI)
   */
  private KJ_MeterLocationInformationBusiness kjMeterLocationInformationBusiness;
  /**
   * 支払情報ビジネス(DI)
   */
  private KJ_PaymentInformationBusiness kjPaymentInformationBusiness;
  /**
   * 付帯契約情報ビジネス(DI)
   */
  private KJ_SupplementaryContractInformationBusiness kjSupplementaryContractInformationBusiness;
  /**
   * 日付関連共通ビジネス(DI)
   */
  private DateBusiness dateBusiness;
  /**
   * 契約管理情報ファイルヘッダーバリデーター(DI)
   */
  private ContractManagementInformationFileHeaderValidator contractManagementInformationFileHeaderValidator;
  /**
   * 契約情報登録バリデーション(DI)
   */
  private ContractInformationFileRegistValidator contractInformationFileRegistValidator;
  /**
   * （カスタム）契約情報登録バリデーション(DI)
   */
  private Custom_ContractInformationFileRegistValidator customContractInformationFileRegistValidator;
  /**
   * 契約情報更新バリデーション(DI)
   */
  private ContractInformationFileUpdateValidator contractInformationFileUpdateValidator;
  /**
   * （カスタム）契約情報更新バリデーション(DI)
   */
  private Custom_ContractInformationFileUpdateValidator customContractInformationFileUpdateValidator;
  /**
   * 契約情報削除バリデーション(DI)
   */
  private ContractInformationFileDeleteValidator contractInformationFileDeleteValidator;
  /**
   * （カスタム） 契約情報削除バリデーション(DI)
   */
  private Custom_ContractInformationFileDeleteValidator customContractInformationFileDeleteValidator;

  /**
   * 全角数字Map
   */
  private static Map<String, String> fullDigitalMap = new HashMap<String, String>();
  static {
    fullDigitalMap.put("1", "１");
    fullDigitalMap.put("2", "２");
    fullDigitalMap.put("3", "３");
    fullDigitalMap.put("4", "４");
    fullDigitalMap.put("5", "５");
    fullDigitalMap.put("6", "６");
    fullDigitalMap.put("7", "７");
    fullDigitalMap.put("8", "８");
    fullDigitalMap.put("9", "９");
    fullDigitalMap.put("10", "１０");
    fullDigitalMap.put("11", "１１");
    fullDigitalMap.put("12", "１２");
    fullDigitalMap.put("13", "１３");
    fullDigitalMap.put("14", "１４");
    fullDigitalMap.put("15", "１５");
  }

  /**
   * ログマネジャー
   */
  private static Logger logger = LogManager.getLogger();

  /**
   * 最大日付
   */
  private static Date maxDate = StringConvertUtil.stringToDate(
      ECISKJConstants.APPLY_END_DATE_MAX, null);

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.kj.
   * KJ_ContractInformationBusiness #inquiry(jp.co.unisys.enability.cis
   * .business.kj.model.InquiryContractBusinessBean)
   */
  @Override
  public InquiryContractBusinessBean inquiry(
      InquiryContractBusinessBean inquiryContractBusinessBean) {

    String errorMessage = null;

    Integer id = null;
    String num = null;
    Date date = null;
    String pattern = null;

    // 契約情報照会BusinessBeanの値を取得
    Integer contractId = inquiryContractBusinessBean.getContractId();
    Integer contractorId = inquiryContractBusinessBean.getContractorId();
    Integer paymentId = inquiryContractBusinessBean.getPaymentId();
    String contractNo = inquiryContractBusinessBean.getContractNo();
    String contractorNo = inquiryContractBusinessBean.getContractorNo();
    String paymentNo = inquiryContractBusinessBean.getPaymentNo();
    Date targetDate = inquiryContractBusinessBean.getInqCoveredDate();

    try {

      errorMessage = messageSource.getMessage(KJ_CommonUtil
          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G017),
          new String[] {}, Locale.getDefault());

      // 契約者ID or 契約者番号 照会対象日付に値がある場合
      if ((contractorId != null || StringUtils.isNotEmpty(contractorNo))
          && targetDate != null && contractId == null
          && StringUtils.isEmpty(contractNo) && paymentId == null
          && StringUtils.isEmpty(paymentNo)) {

        id = contractorId;
        num = contractorNo;
        date = targetDate;
        pattern = ECISKJConstants.INQUIRY_PATTERN_1;

        // 契約者ID or 契約者番号に値がある場合
      } else if ((contractorId != null || StringUtils
          .isNotEmpty(contractorNo))
          && contractId == null
          && StringUtils.isEmpty(contractNo)
          && paymentId == null
          && StringUtils.isEmpty(paymentNo) && targetDate == null) {

        id = contractorId;
        num = contractorNo;
        pattern = ECISKJConstants.INQUIRY_PATTERN_2;
        date = dateBusiness
            .getProcessBaseDate(ECISConstants.EXEC_BASE_DATE_ONLINE);

        // 契約ID or 契約番号に値がある場合
      } else if ((contractId != null || StringUtils
          .isNotEmpty(contractNo))
          && contractorId == null
          && StringUtils.isEmpty(contractorNo)
          && paymentId == null
          && StringUtils.isEmpty(paymentNo) && targetDate == null) {

        id = contractId;
        num = contractNo;
        pattern = ECISKJConstants.INQUIRY_PATTERN_3;

        // 契約ID or 契約番号 照会対象日付に値がある場合
      } else if ((contractId != null || StringUtils
          .isNotEmpty(contractNo))
          && targetDate != null
          && contractorId == null
          && StringUtils.isEmpty(contractorNo)
          && paymentId == null
          && StringUtils.isEmpty(paymentNo)) {

        id = contractId;
        num = contractNo;
        date = targetDate;
        pattern = ECISKJConstants.INQUIRY_PATTERN_4;

        // 支払ID or 支払番号に値がある場合
      } else if ((paymentId != null || StringUtils.isNotEmpty(paymentNo))
          && contractorId == null
          && StringUtils.isEmpty(contractorNo) && contractId == null
          && StringUtils.isEmpty(contractNo) && targetDate == null) {

        id = paymentId;
        num = paymentNo;
        pattern = ECISKJConstants.INQUIRY_PATTERN_5;
        date = dateBusiness
            .getProcessBaseDate(ECISConstants.EXEC_BASE_DATE_ONLINE);

      } else {
        // その他の場合はリターンコードに（P001）を設定し返却する。
        inquiryContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P001);
        inquiryContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P001),
                new String[] {}, Locale.getDefault()));

        return inquiryContractBusinessBean;
      }
      // 《契約情報共通Mapper》.契約情報取得を呼び出す。
      // 引数のキーと値をMapに関連付ける。
      Map<String, Object> selectParam = new HashMap<String, Object>();
      selectParam.put("id", id);
      selectParam.put("num", num);
      selectParam.put("targetDate", date);
      selectParam.put("inquiryPattern", pattern);

      List<KJ_InquiryContractInformationEntityBean> contractInformationList = contractInformationCommonMapper
          .selectContract(selectParam);

      if (CollectionUtils.isEmpty(contractInformationList)) {
        inquiryContractBusinessBean
            .setContractInformationList(contractInformationList);
        // 正常終了 リターンコードに（0000）を設定し返却する。
        inquiryContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);
        return inquiryContractBusinessBean;
      }

      // 契約IDから契約履歴を取得
      List<Integer> contractIdList = new ArrayList<Integer>();
      for (KJ_InquiryContractInformationEntityBean contract : contractInformationList) {
        contractIdList.add(contract.getContractId());
      }
      Map<String, Object> histParam = new HashMap<String, Object>();
      histParam.put("targetDate", date);
      histParam.put("contractIdList", contractIdList);
      histParam.put("inquiryPattern", pattern);

      List<KJ_ContractHistoryInformationEntityBean> histList = contractInformationCommonMapper
          .selectHist(histParam);

      Map<String, Object> urgeParam = new HashMap<String, Object>();
      urgeParam.put("contractIdList", contractIdList);
      // 督促管理を取得
      List<KJ_UrgeManagementInformationEntityBean> urgeList = contractInformationCommonMapper
          .selectUrge(urgeParam);

      int contractListSize = contractInformationList.size();
      int histSize = histList.size();
      int urgeSize = urgeList.size();
      // 契約に契約履歴と督促情報を契約IDで紐付け
      for (int i = 0; i < contractListSize; i++) {
        KJ_InquiryContractInformationEntityBean contract = contractInformationList
            .get(i);
        List<KJ_ContractHistoryInformationEntityBean> histIntoContract = new ArrayList<KJ_ContractHistoryInformationEntityBean>();
        List<KJ_UrgeManagementInformationEntityBean> urgeIntoContract = new ArrayList<KJ_UrgeManagementInformationEntityBean>();
        for (int t = 0; t < histSize; t++) {
          KJ_ContractHistoryInformationEntityBean hist = histList
              .get(t);
          if (contract.getContractId().equals(hist.getContractId())) {
            histIntoContract.add(hist);
          }
        }
        contract.setContractHistoryInformationList(histIntoContract);
        for (int k = 0; k < urgeSize; k++) {
          KJ_UrgeManagementInformationEntityBean urge = urgeList
              .get(k);
          if (contract.getContractId().equals(urge.getContractId())) {
            urgeIntoContract.add(urge);
          }
        }
        contract.setUrgeManagementInformationList(urgeIntoContract);
      }

      inquiryContractBusinessBean
          .setContractInformationList(contractInformationList);
      // 正常終了 リターンコードに（0000）を設定し返却する。
      inquiryContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);
    } catch (NoSuchMessageException ioe) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, ioe);
      inquiryContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      inquiryContractBusinessBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
    } catch (DataAccessException e) {
      logger.error(messageSource.getMessage("error.E1129", null,
          Locale.getDefault()), e);
      // 例外が起きた場合はリターンコードに（G017）を設定し、処理を終了する。
      inquiryContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      inquiryContractBusinessBean.setMessage(errorMessage);
    }

    return inquiryContractBusinessBean;
  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.kj.
   * KJ_ContractInformationBusiness #regist(jp.co.unisys.enability.cis
   * .business.kj.model.RegistContractBusinessBean)
   */
  @Override
  public RegistContractBusinessBean regist(
      RegistContractBusinessBean registContractBusinessBean) {

    String systemErrorMessage = null;
    String duplicateKeyMessage = null;

    try {
      // システムエラーメッセージ
      systemErrorMessage = messageSource.getMessage(KJ_CommonUtil
          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G017),
          new String[] {}, Locale.getDefault());
      // // 重複エラーメッセージ
      duplicateKeyMessage = messageSource.getMessage(KJ_CommonUtil
          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D023),
          new String[] {}, Locale.getDefault());

      Integer contractorId = registContractBusinessBean.getContractorId();
      Integer paymentId = registContractBusinessBean.getPaymentId();
      String contractorNo = registContractBusinessBean.getContractorNo();
      String paymentNo = registContractBusinessBean.getPaymentNo();
      // 契約開始日
      Date contractStartDate = registContractBusinessBean
          .getContractStartDate();
      // 契約終了日
      Date contractEndDate = registContractBusinessBean
          .getContractEndDate();
      // 契約終了理由コード
      String contractEndReasonCode = registContractBusinessBean
          .getContractEndReasonCode();
      // 託送契約容量単位コード
      String consignmentcontractCapacityUnitCode = registContractBusinessBean
          .getConsignmentcontractCapacityUnitCode();
      // 連絡先個人・法人区分コード
      String contactInformationinDividualLegalEntityCategoryCode = registContractBusinessBean
          .getContactInformationinDividualLegalEntityCategoryCode();
      // 連絡先電話区分コード
      String contractInformationCategoryCode = registContractBusinessBean
          .getContractInformationCategoryCode();
      // 接続送電サービス区分コード
      String connectedSupplyServiceCategoryCode = registContractBusinessBean
          .getConnectedSupplyServiceCategoryCode();
      // 営業委託先コード
      String salesConsignmentCode = registContractBusinessBean
          .getSalesConsignmentCode();

      // コード存在チェック

      // 契約終了日がNULLでないかつ契約終了理由コードがNULLまたは空文字のいずれかでない場合
      if (contractEndDate != null
          && StringUtils.isNotEmpty(contractEndReasonCode)) {

        ContractEndReasonM endReasonResult = contractEndReasonMMapper
            .selectByPrimaryKey(contractEndReasonCode);
        // 返却値が0件の場合リターンコードに（P020）を設定し返却する。
        if (endReasonResult == null) {

          registContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P020);
          registContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P020),
                  new String[] {}, Locale.getDefault()));
          return registContractBusinessBean;
        }
        // 契約終了日が"99991231"の場合契約終了理由コードがNULLまたは空文字のいずれかでない場合リターンコード（P070）を設定する。
        if (contractEndDate.compareTo(maxDate) == 0
            && StringUtils.isNotEmpty(contractEndReasonCode)) {

          registContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P070);
          registContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P070),
                  new String[] {}, Locale.getDefault()));
          return registContractBusinessBean;
        }

      }
      // 託送契約容量単位コードがNULLまたは空文字のいずれかでない場合
      if (StringUtils.isNotEmpty(consignmentcontractCapacityUnitCode)) {

        CcaUnitM capacityUnitResult = ccaUnitMMapper
            .selectByPrimaryKey(consignmentcontractCapacityUnitCode);
        // 返却値が0件の場合リターンコードに（P028）を設定し返却する。
        if (capacityUnitResult == null) {
          registContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P028);
          registContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P028),
                  new String[] {}, Locale.getDefault()));
          return registContractBusinessBean;
        }
      }
      // 連絡先個人・法人区分コードがNULLまたは空文字のいずれかでない場合
      if (StringUtils
          .isNotEmpty(contactInformationinDividualLegalEntityCategoryCode)) {

        IlcM legalResult = ilcMMapper
            .selectByPrimaryKey(contactInformationinDividualLegalEntityCategoryCode);
        // 返却値が0件の場合リターンコードに（P021）を設定し返却する。
        if (legalResult == null) {

          registContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P021);
          registContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P021),
                  new String[] {}, Locale.getDefault()));
          return registContractBusinessBean;
        }
      }
      // 連絡先電話区分コードがNULLまたは空文字のいずれかでない場合
      if (StringUtils.isNotEmpty(contractInformationCategoryCode)) {

        PhoneNoCatM phoneResult = phoneNoCatMMapper
            .selectByPrimaryKey(contractInformationCategoryCode);
        // 返却値が0件の場合リターンコードに（P019）を設定し返却する。
        if (phoneResult == null) {

          registContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P019);
          registContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P019),
                  new String[] {}, Locale.getDefault()));
          return registContractBusinessBean;
        }
      }
      // 接続送電サービス区分コードがNULLまたは空文字のいずれかでない場合
      if (StringUtils.isNotEmpty(connectedSupplyServiceCategoryCode)) {

        CssCatM resultCssCatM = cssCatMMapper
            .selectByPrimaryKey(connectedSupplyServiceCategoryCode);
        // 返却値が0件の場合リターンコードに（P026）を設定し返却する。
        if (resultCssCatM == null) {

          registContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P027);
          registContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P027),
                  new String[] {}, Locale.getDefault()));
          return registContractBusinessBean;
        }
      }
      // 営業委託先コードがNULLまたは空文字のいずれかでない場合
      if (StringUtils.isNotEmpty(salesConsignmentCode)) {

        ScM salesConsignmentResult = scMMapper
            .selectByPrimaryKey(salesConsignmentCode);
        // 返却値が0件の場合リターンコードに（P026）を設定し返却する。
        if (salesConsignmentResult == null) {

          registContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P026);
          registContractBusinessBean.setMessage(salesConsignmentCode);
          registContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P026),
                  new String[] {}, Locale.getDefault()));
          return registContractBusinessBean;
        }
      }

      // 親エンティティ存在チェック

      // 契約者情報照会BusinessBean
      InquiryContractorBusinessBean contractorBean = new InquiryContractorBusinessBean();
      contractorBean.setContractorId(contractorId);
      contractorBean.setContractorNo(contractorNo);

      // 契約者情報照会
      InquiryContractorBusinessBean resultContractorBean = kjContractorInfomationBusiness
          .inquiry(contractorBean);

      String contractorBeanReturnCode = resultContractorBean
          .getReturnCode();

      List<KJ_InquiryContractorInformationEntityBean> contractorList = resultContractorBean
          .getContractorInformationList();
      // リターンコードが“0000”以外の場合、業務例外クラスをスローする。
      if (!ECISReturnCodeConstants.RETURN_CODE_0000
          .equals(contractorBeanReturnCode)) {

        throw new BusinessLogicException(messageSource.getMessage(
            "error.E1281", new String[] {}, Locale.getDefault()),
            false);
      }
      // リターンコードが“0000”かつ返却値が0件の場合リターンコードに（D014）を設定し返却する。
      if (CollectionUtils.isEmpty(contractorList)) {

        registContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D014);
        registContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D014),
                new String[] {}, Locale.getDefault()));
        return registContractBusinessBean;
      }

      // 契約者利用不能チェック

      // 利用不能フラグが“ON”の場合（D013）を設定し返却する。
      if (checkUnavailableFlag(contractorList)) {

        registContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D013);
        registContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D013),
                new String[] {}, Locale.getDefault()));
        return registContractBusinessBean;
      }

      // メータ設置場所照会

      InquiryMeterLocationBusinessBean meterLocationBean = new InquiryMeterLocationBusinessBean();
      meterLocationBean.setMeterLocationId(registContractBusinessBean
          .getMeterLocationId());

      InquiryMeterLocationBusinessBean resultMeterLocationBean = kjMeterLocationInformationBusiness
          .inquiry(meterLocationBean);

      List<KJ_InquiryMeterLocationEntityBean> returnMlBeanList = resultMeterLocationBean
          .getMeterLocationList();
      String meterLocationBeanReturnCode = resultMeterLocationBean
          .getReturnCode();

      // リターンコードが“0000”以外の場合、業務例外クラスをスローする。
      if (!ECISReturnCodeConstants.RETURN_CODE_0000
          .equals(meterLocationBeanReturnCode)) {
        throw new BusinessLogicException(messageSource.getMessage(
            "error.E1299", new String[] {}, Locale.getDefault()),
            false);
      }
      // リターンコードが“0000”かつ返却値が0件の場合リターンコードに（P008）を設定し返却する。
      if (CollectionUtils.isEmpty(returnMlBeanList)) {
        registContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P008);
        registContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P008),
                new String[] {}, Locale.getDefault()));
        return registContractBusinessBean;
      }

      // 支払情報
      InquiryPaymentBusinessBean paymentBean = new InquiryPaymentBusinessBean();
      paymentBean.setPaymentId(paymentId);
      paymentBean.setPaymentNo(paymentNo);

      // 支払情報照会
      InquiryPaymentBusinessBean resultPayment = kjPaymentInformationBusiness
          .inquiry(paymentBean);
      String paymentBeanReturnCode = resultPayment.getReturnCode();

      List<KJ_InquiryPaymentInformationEntityBean> paymentList = resultPayment
          .getPaymentInformationList();

      // リターンコードが“0000”以外の場合、業務例外クラスをスローする。
      if (!ECISReturnCodeConstants.RETURN_CODE_0000
          .equals(paymentBeanReturnCode)) {
        throw new BusinessLogicException(messageSource.getMessage(
            "error.E1288", new String[] {}, Locale.getDefault()),
            false);
      }

      // リターンコードが“0000”かつ返却値が0件の場合リターンコードに（D018）を設定し返却する。
      if (CollectionUtils.isEmpty(paymentList)) {

        registContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D018);
        registContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D018),
                new String[] {}, Locale.getDefault()));
        return registContractBusinessBean;
      }

      // 支払情報照会した際の契約者IDチェック
      if (!contractorList.get(0).getContractorId().equals(paymentList.get(0).getContractorId())) {
        registContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D018);
        registContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D018),
                new String[] {}, Locale.getDefault()));
        return registContractBusinessBean;
      }

      // 支払有効期間チェック
      // paymentStartDate > contractStartDate
      if (checkContractStartDate(paymentList, contractStartDate)) {
        // リターンコードに（G028）を設定し返却する。
        registContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G028);
        registContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G028),
                new String[] {},
                Locale.getDefault()));
        return registContractBusinessBean;
      }

      // 料金メニューチェック
      // 《契約情報登録BusinessBean》.料金メニューIDを取得する
      String rateMenuId = registContractBusinessBean.getChargeMenuId();

      // 提供モデルと提供モデル企業の判定
      RmMByPmCompanyKey keyExample = new RmMByPmCompanyKey();
      // 《契約情報登録BusinessBean》.料金メニューIDを設定する
      keyExample.setRmId(rateMenuId);
      // 《契約者情報照会EntityBean》.提供モデルコードを設定する
      keyExample.setPmCode(contractorList.get(0).getProvideModelCode());
      // 《契約者情報照会EntityBean》.提供モデル企業コードを設定する。
      keyExample.setPmCompanyCode(contractorList.get(0).getProvideModelCompanyCode());
      // 提供モデル企業別料金メニューマスタ情報を検索する。
      RmMByPmCompany rmMByPmCompany = rmMByPmCompanyMapper.selectByPrimaryKey(keyExample);

      // 取得結果判定、返却結果がNULLの場合、リターンコード（G038）を返却する。
      if (rmMByPmCompany == null) {
        registContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G038);
        registContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G038),
                new String[] {}, Locale.getDefault()));
        return registContractBusinessBean;
      }

      // 料金メニュー取得
      Rm rateMenu = rmMapper.selectByPrimaryKey(rateMenuId);
      // 返却値が0件の場合リターンコードに（D003）を設定し返却する。
      if (rateMenu == null) {
        registContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D003);
        registContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D003),
                new String[] {}, Locale.getDefault()));
        return registContractBusinessBean;
      }

      // エリアコードチェック
      // 《メータ設置場所照会EntityBean》一件目を取得する。
      KJ_InquiryMeterLocationEntityBean inquiryMeterLocationEntityBean = returnMlBeanList.get(0);

      // 《メータ設置場所照会EntityBean》.エリアコードが《料金メニュー》.エリアコードと一致しない場合、
      // リターンコードに（G036）を設定し返却する。
      if (!inquiryMeterLocationEntityBean.getAreaCode().equals(rateMenu.getAreaCode())) {
        registContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G036);
        registContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G036),
                new String[] {}, Locale.getDefault()));
        return registContractBusinessBean;
      }

      // 売買区分コードチェック
      // 《メータ設置場所照会EntityBean》.送受電区分コードを取得する。
      String transmissionCategoryCode = inquiryMeterLocationEntityBean.getTransmissionCategoryCode();
      // 《料金メニュー》.売買区分コードを取得する。
      String saleCatCode = rateMenu.getSaleCatCode();

      // 送受電区分コードが"1:送電" かつ 売買区分コードが"2:買電"場合、
      // または 送受電区分コードが"2:受電" かつ 売買区分コードが"1:売電"場合、
      // リターンコードに（G037）を設定し返却する。
      if ((ECISCodeConstants.TRANSMISSION_CATEGORY_CODE_TRANSMISSION.equals(transmissionCategoryCode)
          && ECISCodeConstants.SALE_CATEGORY_PURCHASING.equals(saleCatCode))
          || (ECISCodeConstants.TRANSMISSION_CATEGORY_CODE_RECEIVING.equals(transmissionCategoryCode)
              && ECISCodeConstants.SALE_CATEGORY_SELLING.equals(saleCatCode))) {
        registContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G037);
        registContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G037),
                new String[] {}, Locale.getDefault()));
        return registContractBusinessBean;
      }

      // 適用期間チェック

      // 契約開始日と契約終了日は料金メニュー期間以外の場合
      if (periodCheck(contractStartDate, rateMenu.getApplySd(), rateMenu.getApplyEd()) ||
          periodCheck(contractEndDate, rateMenu.getApplySd(), rateMenu.getApplyEd())) {
        // リターンコードに（G039）を設定し返却する。
        registContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G039);
        registContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G039),
                new String[] {}, Locale.getDefault()));
        return registContractBusinessBean;
      }

      // 契約容量チェック
      String capacityUnit = rateMenu.getCcaUnit();
      BigDecimal capacity = registContractBusinessBean
          .getContractCapacity();

      // 契約容量単位がNULLまたは空文字いずれかでない場合
      if (StringUtils.isNotEmpty(capacityUnit) && capacity == null) {
        // 契約容量がNULLの場合リターンコードにに（P065）を設定し返却する。

        registContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P065);
        registContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P065),
                new String[] {}, Locale.getDefault()));
        return registContractBusinessBean;

      }
      // 契約容量単位がNULLまたは空文字の場合
      if (StringUtils.isEmpty(capacityUnit) && capacity != null) {
        // 契約容量がNULLでない場合リターンこードにに（P064）を設定し返却する。

        registContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P064);
        registContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P064),
                new String[] {}, Locale.getDefault()));
        return registContractBusinessBean;

      }

      // 契約容量選択可能範囲チェック
      if (capacity != null) {
        boolean result = RK_CommonUtil.checkContractCapacity(
            String.valueOf(capacity),
            rateMenu.getCapacitySelectableRange());
        // 返却値が“false”の場合リターンコードに（G006）を設定し返却する。
        if (!result) {

          registContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G006);
          registContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G006),
                  new String[] {}, Locale.getDefault()));
          return registContractBusinessBean;
        }
      }

      // メータ設置場所契約履歴情報重複チェック

      Map<String, Object> meterLocationHistRegistMap = new HashMap<String, Object>();

      meterLocationHistRegistMap.put("meterLocationId",
          registContractBusinessBean.getMeterLocationId());
      meterLocationHistRegistMap.put("coveredDate", contractStartDate);

      int meterLocationHistCount = contractInformationCommonMapper
          .countByMeterLocationContractHistory(meterLocationHistRegistMap);

      // 返却値が1件以上の場合リターンコードに（D024）を設定し返却する。
      if (meterLocationHistCount >= 1) {

        registContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D024);
        registContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D024),
                new String[] {}, Locale.getDefault()));
        return registContractBusinessBean;
      }

      // コンテキスト・ユーザID
      String contextUserId = ThreadContext.getRequestThreadContext()
          .get(ECISConstants.USER_ID_KEY).toString();
      // コンテキスト.モジュールコード
      String contextModuleCode = ThreadContext.getRequestThreadContext()
          .get(ECISConstants.CLASS_NAME_KEY).toString();
      Contract contract = createRegistContract(
          registContractBusinessBean, contractorList.get(0)
              .getContractorId(),
          paymentList.get(0)
              .getPaymentId(),
          maxDate, contextUserId,
          contextModuleCode);
      // 契約登録 新しい契約IDを取得
      contractMapper.insertBySequence(contract);
      Integer newContractId = contract.getContractId();

      // 契約履歴登録
      ContractHist history = createContractHistory(
          registContractBusinessBean, newContractId, maxDate,
          rateMenu.getCcaUnit(), rateMenu.getRmId(), contextUserId,
          contextModuleCode);
      contractHistMapper.insert(history);

      // メータ設置場所契約履歴情報登録
      MlContractHist mlHistory = new MlContractHist();
      // 契約ID
      mlHistory.setContractId(newContractId);
      // 適用開始日
      mlHistory.setApplySd(contractStartDate);
      Timestamp systemTime = new Timestamp(System.currentTimeMillis());

      mlHistory.setMlId(registContractBusinessBean.getMeterLocationId());
      mlHistory.setUpdateCount(0);
      mlHistory.setCreateTime(systemTime);
      mlHistory.setOnlineUpdateTime(systemTime);
      mlHistory.setOnlineUpdateUserId(contextUserId);
      mlHistory.setOnlineUpdateTime(systemTime);
      mlHistory.setUpdateTime(systemTime);
      mlHistory.setUpdateModuleCode(contextModuleCode);
      mlContractHistMapper.insert(mlHistory);

      registContractBusinessBean.setContractId(newContractId);
      // 正常終了
      registContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);
    } catch (DuplicateKeyException duplicateKeyException) {
      logger.error(messageSource.getMessage("error.E1129", null,
          Locale.getDefault()), duplicateKeyException);
      // 重複例外クラス
      registContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D023);
      registContractBusinessBean.setMessage(duplicateKeyMessage);
    } catch (DataIntegrityViolationException dataIntegrityViolationException) {
      logger.error(messageSource.getMessage("error.E1129", null,
          Locale.getDefault()), dataIntegrityViolationException);
      // 制約違反例外クラス
      registContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D023);
      registContractBusinessBean.setMessage(duplicateKeyMessage);
    } catch (BusinessLogicException businessLogicException) {
      logger.error(messageSource.getMessage("error.E1129", null,
          Locale.getDefault()), businessLogicException);
      // 業務例外クラス
      registContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      registContractBusinessBean.setMessage(systemErrorMessage);
    } catch (NoSuchMessageException ioe) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, ioe);
      registContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      registContractBusinessBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
    } catch (DataAccessException e) {
      logger.error(messageSource.getMessage("error.E1129", null,
          Locale.getDefault()), e);
      registContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      registContractBusinessBean.setMessage(e.getMessage());
    }
    return registContractBusinessBean;
  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.kj.
   * KJ_ContractInformationBusiness #update(jp.co.unisys.enability.cis
   * .business.kj.model.UpdateContractBusinessBean)
   */
  @Override
  public UpdateContractBusinessBean update(
      UpdateContractBusinessBean updateContractBusinessBean) {

    final int CONTRACT_CANCEL_FLAG_ON = 1;
    final int CONTRACT_CANCEL_FLAG_OFF = 0;

    String errorMessage = null;

    try {

      errorMessage = messageSource.getMessage(KJ_CommonUtil
          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G017),
          new String[] {}, Locale.getDefault());
      // オンライン処理基準日
      Date onlineDate = dateBusiness
          .getProcessBaseDate(ECISConstants.EXEC_BASE_DATE_ONLINE);

      // コンテキスト・ユーザID
      String contextUserId = ThreadContext.getRequestThreadContext()
          .get(ECISConstants.USER_ID_KEY).toString();
      // コンテキスト.モジュールコード
      String contextModuleCode = ThreadContext.getRequestThreadContext()
          .get(ECISConstants.CLASS_NAME_KEY).toString();

      Integer contractId = updateContractBusinessBean.getContractId();
      String contractNo = updateContractBusinessBean.getContractNo();
      String chargeMenuId = updateContractBusinessBean.getChargeMenuId();

      // 適用開始日
      Date applyStartDate = updateContractBusinessBean
          .getApplyStartDate();
      // 契約終了日
      Date contractEndDate = updateContractBusinessBean
          .getContractEndDate();
      // 契約終了理由コード
      String contractEndReasonCode = updateContractBusinessBean
          .getContractEndReasonCode();
      // 連絡先個人・法人区分コード
      String contactInformationinDividualLegalEntityCategoryCode = updateContractBusinessBean
          .getContactInformationinDividualLegalEntityCategoryCode();
      // 連絡先電話区分コード
      String informationCategoryCode = updateContractBusinessBean
          .getContractInformationCategoryCode();
      // 接続送電サービス区分コード
      String connectedSupplyServiceCategoryCode = updateContractBusinessBean
          .getConnectedSupplyServiceCategoryCode();
      // 託送契約容量単位コード
      String consignmentcontractCapacityUnitCode = updateContractBusinessBean
          .getConsignmentcontractCapacityUnitCode();
      // 営業委託先コード
      String salesConsignmentCode = updateContractBusinessBean
          .getSalesConsignmentCode();

      // コード存在チェック

      // 契約終了日がNULLでなく"99991231"以外であり契約終了理由コードがNULLまたは空文字のいずれかでない場合
      if (contractEndDate != null
          && contractEndDate.compareTo(maxDate) != 0
          && StringUtils.isNotEmpty(contractEndReasonCode)) {

        ContractEndReasonM endReasonResult = contractEndReasonMMapper
            .selectByPrimaryKey(contractEndReasonCode);
        // 返却値が0件の場合リターンコードに（P020）を設定し返却する。
        if (endReasonResult == null) {

          updateContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P020);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P020),
                  new String[] {}, Locale.getDefault()));
          return updateContractBusinessBean;
        }
      }
      // 連絡先個人・法人区分コードがNULLまたは空文字のいずれかでない場合
      if (StringUtils
          .isNotEmpty(contactInformationinDividualLegalEntityCategoryCode)) {

        IlcM legalResult = ilcMMapper
            .selectByPrimaryKey(contactInformationinDividualLegalEntityCategoryCode);
        // 返却値が0件の場合リターンコードに（P021）を設定し返却する。
        if (legalResult == null) {

          updateContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P021);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P021),
                  new String[] {}, Locale.getDefault()));
          return updateContractBusinessBean;
        }
      }
      // 連絡先電話区分コードがNULLまたは空文字のいずれかでない場合
      if (StringUtils.isNotEmpty(informationCategoryCode)) {

        PhoneNoCatM phoneResult = phoneNoCatMMapper
            .selectByPrimaryKey(informationCategoryCode);
        // 返却値が0件の場合リターンコードに（P019）を設定し返却する。
        if (phoneResult == null) {

          updateContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P019);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P019),
                  new String[] {}, Locale.getDefault()));
          return updateContractBusinessBean;
        }
      }
      // 接続送電サービス区分コードがNULLまたは空文字のいずれかでない場合
      if (StringUtils.isNotEmpty(connectedSupplyServiceCategoryCode)) {

        CssCatM cssCatMResult = cssCatMMapper
            .selectByPrimaryKey(connectedSupplyServiceCategoryCode);
        // 返却値が0件の場合リターンコードに（P027）を設定し返却する。
        if (cssCatMResult == null) {

          updateContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P027);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P027),
                  new String[] {}, Locale.getDefault()));
          return updateContractBusinessBean;
        }
      }
      CcaUnitM consignmentCapacityUnitResult = null;
      // 託送契約容量単位コードが空文字の場合空文字の場合空文字を入れる
      String consignmentCapacityUnit = null;
      if (ECISKJConstants.EMPTY_STRING
          .equals(consignmentcontractCapacityUnitCode)) {
        consignmentCapacityUnit = ECISKJConstants.EMPTY_STRING;
      }
      if (StringUtils.isNotEmpty(consignmentcontractCapacityUnitCode)) {
        // 託送契約容量単位コードがNULLまたは空文字のいずれかでない場合
        consignmentCapacityUnitResult = ccaUnitMMapper
            .selectByPrimaryKey(consignmentcontractCapacityUnitCode);
        if (consignmentCapacityUnitResult == null) {
          // 返却値が0件の場合リターンコードに（P028）を設定し返却する。
          updateContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P028);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P028),
                  new String[] {}, Locale.getDefault()));
          return updateContractBusinessBean;
        }
        consignmentCapacityUnit = consignmentCapacityUnitResult
            .getCcaUnitCode();
      }
      if (StringUtils.isNotEmpty(salesConsignmentCode)) {
        // 営業委託先コードがNULLまたは空文字のいずれかでない場合
        ScM salesConsignmentResult = scMMapper
            .selectByPrimaryKey(salesConsignmentCode);
        if (salesConsignmentResult == null) {
          // 返却値が0件の場合リターンコードに（P026）を設定し返却する。
          updateContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P026);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P026),
                  new String[] {}, Locale.getDefault()));
          return updateContractBusinessBean;
        }
      }

      // 契約情報存在チェック
      InquiryContractBusinessBean param = new InquiryContractBusinessBean();

      param.setContractId(contractId);
      param.setContractNo(contractNo);

      InquiryContractBusinessBean inquryContractResult = inquiry(param);
      String contractReturnCode = inquryContractResult.getReturnCode();

      List<KJ_InquiryContractInformationEntityBean> inquryContractList = inquryContractResult
          .getContractInformationList();

      // リターンコードが“0000”以外の場合、業務例外クラスをスローする
      if (!ECISReturnCodeConstants.RETURN_CODE_0000
          .equals(contractReturnCode)) {
        throw new BusinessLogicException(messageSource.getMessage(
            "error.E1285", new String[] {}, Locale.getDefault()),
            false);
      }
      // リターンコードが“0000”かつ返却値が0件の場合リターンコードに（P005）を設定し返却する。
      if (CollectionUtils.isEmpty(inquryContractList)) {

        updateContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P005);
        updateContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P005),
                new String[] {}, Locale.getDefault()));
        return updateContractBusinessBean;
      }

      // 契約終了状態判定のため、算定期間チェックを行う。
      Map<String, Object> exampleMap = new HashMap<String, Object>();
      exampleMap.put("contractId", inquryContractList.get(0).getContractId());
      exampleMap.put("coveredDate", inquryContractList.get(0).getContractEndDate());
      exampleMap.put("flg", ECISKJConstants.INQUIRY_FIX_CHANGE_RESULT_INFOEMATION_FLG_TWO);
      int resultCount = fixChargeResultInformationCommonMapper.countByFixChargeResult(exampleMap);
      // 結果が1件以上の場合リターンコードに（D025）を設定し返却する
      if (resultCount >= 1) {
        updateContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D025);
        updateContractBusinessBean.setMessage(messageSource.getMessage(
            KJ_CommonUtil.getMessageId(ECISReturnCodeConstants.RETURN_CODE_D025),
            new String[] {}, Locale.getDefault()));
        return updateContractBusinessBean;
      }

      // 適用開始日のリスト中に適用開始日より未来日が存在した場合リターンコードに（G001）を設定し返却する
      if (isFeature(inquryContractList, applyStartDate)) {

        updateContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G001);
        updateContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G001),
                new String[] {}, Locale.getDefault()));
        return updateContractBusinessBean;
      }

      // 最新情報を取得
      KJ_ContractHistoryInformationEntityBean kjContractHistoryInformationEntityBean = inquryContractList.get(0)
          .getContractHistoryInformationList().get(0);

      // 適用開始日リストの最新
      Date latestApplyDate = kjContractHistoryInformationEntityBean.getApplyStartDate();

      // 《契約情報照会BusinessBean》.適用開始日リストの最新日と、《契約情報更新BusinessBean》.適用開始日が同日の場合、
      // 以下のチェックを実行する。
      if (latestApplyDate.compareTo(updateContractBusinessBean.getApplyStartDate()) == 0) {

        // 変数.履歴更新フラグにfalseを指定。
        boolean histUpdateFlag = false;
        // 《契約情報更新BusinessBean》.料金メニューIDが更新対象かつ《契約履歴情報EntityBean》.料金メニューIDと一致しない場合、
        // 変数.履歴情報更新フラグにtrueを設定する。
        if (updateContractBusinessBean.getChargeMenuId() != null
            && !updateContractBusinessBean.getChargeMenuId().equals(
                StringUtils.defaultString(kjContractHistoryInformationEntityBean.getRateMenuId()))) {
          histUpdateFlag = true;
        }
        // 《契約情報更新BusinessBean》.契約容量が更新対象かつ《契約履歴情報EntityBean》.契約容量が一致しない場合、
        // 変数.履歴情報更新フラグにtrueを設定する。
        if (ECISConstants.FLG_OFF.equals(updateContractBusinessBean.getContractCapacityNoUpdFlag())) {
          // 契約容量がnullまたはnot nullで判定を変更する。
          if (updateContractBusinessBean.getContractCapacity() == null
              && kjContractHistoryInformationEntityBean.getContractCapacity() != null) {
            histUpdateFlag = true;
          }
          if (updateContractBusinessBean.getContractCapacity() != null
              && kjContractHistoryInformationEntityBean.getContractCapacity() == null) {
            histUpdateFlag = true;
          } else if (updateContractBusinessBean.getContractCapacity() != null
              && updateContractBusinessBean.getContractCapacity().compareTo(
                  kjContractHistoryInformationEntityBean.getContractCapacity()) != 0) {
            histUpdateFlag = true;
          }
        }
        // 《契約情報更新BusinessBean》.契約変更理由が更新対象かつ《契約履歴情報EntityBean》.契約変更理由が一致しない場合、
        // 変数.履歴情報更新フラグにtrueを設定する。
        if (updateContractBusinessBean.getContractChangeReason() != null
            && !updateContractBusinessBean.getContractChangeReason().equals(
                StringUtils.defaultString(
                    kjContractHistoryInformationEntityBean.getContractChangeReason()))) {
          histUpdateFlag = true;
        }
        // 変数.履歴情報フラグがtrueの場合、《契約情報更新BusinessBean》.リターンコードに（G045）を設定し返却する。
        if (histUpdateFlag) {
          updateContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G045);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G045),
                  new String[] {}, Locale.getDefault()));
          return updateContractBusinessBean;
        }
      }

      // 最新＋1日
      Date latestApplyDateNextDay = DateCalculateUtil.calculateDate(
          latestApplyDate, 0, 0, 1);
      if (latestApplyDateNextDay.compareTo(updateContractBusinessBean
          .getApplyStartDate()) == 0) {
        // 《契約情報照会BusinessBean》.適用開始日リストの最新＋1日と、《契約情報更新BusinessBean》.適用開始日が同日の場合、
        // 《契約情報更新BusinessBean》.リターンコードに（G032）を設定し返却する。
        updateContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G032);
        updateContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G032),
                new String[] {}, Locale.getDefault()));
        return updateContractBusinessBean;
      }

      // 《契約情報照会BusinessBean》.契約終了日と《契約情報更新BusinessBean》.適用開始日が同日の場合、
      // 《契約情報更新BusinessBean》.リターンコードに（G043）を設定し返却する。
      if (updateContractBusinessBean.getApplyStartDate()
          .compareTo(inquryContractList.get(0).getContractEndDate()) >= 0) {
        updateContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G043);
        updateContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G043),
                new String[] {}, Locale.getDefault()));
        return updateContractBusinessBean;
      }

      // 親エンティティ存在チェック
      Integer contractorId = inquryContractResult
          .getContractInformationList().get(0).getContractorId();

      InquiryContractorBusinessBean contractorBean = new InquiryContractorBusinessBean();
      contractorBean.setContractorId(contractorId);

      // 契約者情報照会
      InquiryContractorBusinessBean resultContractorBean = kjContractorInfomationBusiness
          .inquiry(contractorBean);

      String contractorBeanReturnCode = resultContractorBean
          .getReturnCode();

      List<KJ_InquiryContractorInformationEntityBean> contractorList = resultContractorBean
          .getContractorInformationList();
      // リターンコードが“0000”以外の場合、業務例外クラスをスローする。
      if (!ECISReturnCodeConstants.RETURN_CODE_0000
          .equals(contractorBeanReturnCode)) {

        throw new BusinessLogicException(messageSource.getMessage(
            "error.E1281", new String[] {}, Locale.getDefault()),
            false);
      }
      // リターンコードが“0000”かつ返却値が0件の場合リターンコードに（D014）を設定し返却する。
      if (CollectionUtils.isEmpty(contractorList)) {

        updateContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D014);
        updateContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D014),
                new String[] {}, Locale.getDefault()));
        return updateContractBusinessBean;
      }

      // 契約者利用不能チェック
      // 利用不能フラグが“ON”の場合（D013）を設定し返却する。
      if (checkUnavailableFlag(contractorList)) {

        updateContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D013);
        updateContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D013),
                new String[] {}, Locale.getDefault()));
        return updateContractBusinessBean;
      }

      Integer paymentId = updateContractBusinessBean.getPaymentId();
      String paymentNo = updateContractBusinessBean.getPaymentNo();
      // 契約開始日
      Date contractStartDate = inquryContractList.get(0)
          .getContractStartDate();
      List<KJ_InquiryPaymentInformationEntityBean> paymentList = null;
      // 支払IDがNULLでないまたは支払番号がNULLまたは空文字のいずれでもない場合
      if (paymentId != null || StringUtils.isNotEmpty(paymentNo)) {

        InquiryPaymentBusinessBean paymentParam = new InquiryPaymentBusinessBean();
        paymentParam.setPaymentId(paymentId);
        paymentParam.setPaymentNo(paymentNo);
        // 支払存在チェック
        InquiryPaymentBusinessBean resultPayment = kjPaymentInformationBusiness
            .inquiry(paymentParam);
        String paymentReturnCode = resultPayment.getReturnCode();
        paymentList = resultPayment.getPaymentInformationList();

        // リターンコードが“0000”以外の場合、業務例外クラスをスローする。
        if (!ECISReturnCodeConstants.RETURN_CODE_0000
            .equals(paymentReturnCode)) {

          throw new BusinessLogicException(
              messageSource.getMessage("error.E1288",
                  new String[] {}, Locale.getDefault()),
              false);
        }
        // “0000”かつ返却値が0件の場合リターンコードに（D018）を設定し返却する。
        if (CollectionUtils.isEmpty(paymentList)) {

          updateContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D018);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D018),
                  new String[] {}, Locale.getDefault()));
          return updateContractBusinessBean;
        }

        // 支払情報照会した際の契約者IDチェック
        if (!contractorList.get(0).getContractorId().equals(paymentList.get(0).getContractorId())) {
          updateContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D018);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D018),
                  new String[] {}, Locale.getDefault()));
          return updateContractBusinessBean;
        }

        int paymentIndex = 0;
        String paymentIndexReturnCode = null;
        int paymentListSize = paymentList.size();
        // 契約開始日≦「オンライン処理日付」≦ 契約終了日(引数の契約終了日がNULLの場合は取得した契約終了日と比較する

        Date tmpContractEd = contractEndDate == null ? inquryContractList
            .get(0).getContractEndDate() : contractEndDate;

        if (contractStartDate.compareTo(onlineDate) <= 0
            && onlineDate.compareTo(tmpContractEd) <= 0) {

          for (int i = 0; i < paymentListSize; i++) {
            KJ_InquiryPaymentInformationEntityBean payment = paymentList
                .get(i);
            Date startDate = payment.getPaymentStartDate();
            Date endDate = payment.getPaymentEndDate();

            // 《支払情報照会BusinessBean》.支払適用開始日≦オンライン処理日付
            // ≦《支払情報照会BusinessBean》.支払適用終了日の場合
            if (startDate.compareTo(onlineDate) <= 0
                && onlineDate.compareTo(endDate) <= 0) {

              paymentIndex++;
            }
          }
          if (paymentIndex == 0) {
            paymentIndexReturnCode = ECISReturnCodeConstants.RETURN_CODE_G027;
          }
        }

        // 「オンライン処理日付」< 契約開始日の場合
        if (onlineDate.before(contractStartDate)) {

          for (int i = 0; i < paymentListSize; i++) {
            KJ_InquiryPaymentInformationEntityBean payment = paymentList
                .get(i);
            Date startDate = payment.getPaymentStartDate();
            Date endDate = payment.getPaymentEndDate();
            // 《支払情報照会BusinessBean》.支払適用開始日≦ 契約開始日
            // ≦《支払情報照会BusinessBean》.支払適用終了日の場合
            if (startDate.compareTo(contractStartDate) <= 0
                && contractStartDate.compareTo(endDate) <= 0) {
              paymentIndex++;
            }
          }
          if (paymentIndex == 0) {
            paymentIndexReturnCode = ECISReturnCodeConstants.RETURN_CODE_G028;
          }
        }
        // リターンコードがNULLでない場合リターンコードに（G027またはG028）を設定し返却する
        if (paymentIndexReturnCode != null) {

          updateContractBusinessBean
              .setReturnCode(paymentIndexReturnCode);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(paymentIndexReturnCode),
                  new String[] {},
                  Locale.getDefault()));
          return updateContractBusinessBean;
        }
      }

      // 《契約情報更新BusinessBean》.契約終了日がNULLまたは空文字のいずれかでない場合、以下の処理を行う。
      if (contractEndDate != null) {
        // 契約期間チェック
        // 契約終了日が契約開始日以前の日付の場合リターンコードに（G005）を設定し返却する。
        if (contractEndDate.compareTo(contractStartDate) <= 0) {

          updateContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G005);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G005),
                  new String[] {}, Locale.getDefault()));
          return updateContractBusinessBean;
        }

        // 《契約情報更新BusinessBean》.契約終了日が、《契約情報照会BusinessBean》.適用開始日リストの最新の適用開始日
        // 以前の場合リターンコードに（G031）を設定し返却する。
        if (updateContractBusinessBean.getContractEndDate().before(
            latestApplyDate)) {
          updateContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G031);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G031),
                  new String[] {}, Locale.getDefault()));
          return updateContractBusinessBean;
        }
      }

      BigDecimal capacity = updateContractBusinessBean
          .getContractCapacity();
      // 料金メニューIDがNULLかつ契約容量がNULLの場合
      if (chargeMenuId == null
          && capacity == null
          && StringUtils.isNotEmpty(updateContractBusinessBean
              .getContractChangeReason())) {
        // 契約変更理由がNULLまたは空文字のいずれでもない場合リターンコードに（P069）を設定し返却する。

        updateContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P069);
        updateContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P069),
                new String[] {}, Locale.getDefault()));
        return updateContractBusinessBean;
      }

      // メータ設置場所照会
      InquiryMeterLocationBusinessBean inquiryMeterLocationBusinessBean = new InquiryMeterLocationBusinessBean();
      inquiryMeterLocationBusinessBean.setContractId(inquryContractList.get(0).getContractId());
      InquiryMeterLocationBusinessBean resulMl = kjMeterLocationInformationBusiness
          .inquiry(inquiryMeterLocationBusinessBean);

      List<KJ_InquiryMeterLocationEntityBean> mlList = resulMl.getMeterLocationList();
      // リターンコードが“0000”以外の場合、業務例外クラスをスローする。
      if (!ECISReturnCodeConstants.RETURN_CODE_0000
          .equals(resulMl.getReturnCode())) {
        throw new BusinessLogicException(messageSource.getMessage(
            "error.E1299", new String[] {}, Locale.getDefault()),
            false);
      }
      // 呼び出しの戻り値が0件の場合、業務例外クラスをスローする
      if (CollectionUtils.isEmpty(mlList)) {

        throw new BusinessLogicException(resulMl.getMessage(), false);
      }

      // エリアコードリストを生成する。
      List<String> areaCodeList = new ArrayList<String>();
      // 送受電区分コードリストを生成する。
      List<String> tranCatCodeList = new ArrayList<String>();
      // メータ設置場所情報リストの件数分より、以下の処理を行う。
      for (KJ_InquiryMeterLocationEntityBean entity : mlList) {
        // エリアコードリストに《メータ設置場所EntityBean》.エリアコードを追加する。
        areaCodeList.add(entity.getAreaCode());
        // 送受電区分コードリストに《メータ設置場所EntityBean》.送受電区分コードを追加する。
        tranCatCodeList.add(entity.getTransmissionCategoryCode());
      }

      Rm rateMenu = null;
      // 料金メニュー存在チェック
      if (StringUtils.isNotEmpty(chargeMenuId)) {

        // 提供モデルと提供モデル企業の判定
        RmMByPmCompanyKey keyExample = new RmMByPmCompanyKey();
        // 《契約情報更新BusinessBean》.料金メニューIDを設定する。
        keyExample.setRmId(chargeMenuId);
        // 《契約者情報照会EntityBean》.提供モデルコードを設定する
        keyExample.setPmCode(contractorList.get(0).getProvideModelCode());
        // 《契約者情報照会EntityBean》.提供モデル企業コードを設定する。
        keyExample.setPmCompanyCode(contractorList.get(0).getProvideModelCompanyCode());
        // 提供モデル企業別料金メニューマスタ情報を検索する。
        RmMByPmCompany rmMByPmCompany = rmMByPmCompanyMapper.selectByPrimaryKey(keyExample);

        // 取得結果判定、返却結果がNULLの場合、リターンコード（G038）を返却する。
        if (rmMByPmCompany == null) {
          updateContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G038);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G038),
                  new String[] {}, Locale.getDefault()));
          return updateContractBusinessBean;
        }

        // 料金メニュー取得
        rateMenu = rmMapper.selectByPrimaryKey(chargeMenuId);
        // 取得結果判定、返却結果がNULLの場合、リターンコード（D003）を返却する。
        if (rateMenu == null) {
          updateContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D003);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D003),
                  new String[] {}, Locale.getDefault()));
          return updateContractBusinessBean;
        }

        // エリアコードチェック
        // エリアコードリスト（変数）に《料金メニューEntity》.エリアコードが存在しない場合、
        // リターンコードに（G036）を設定し返却する。
        if (!areaCodeList.contains(rateMenu.getAreaCode())) {
          updateContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G036);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G036),
                  new String[] {}, Locale.getDefault()));
          return updateContractBusinessBean;
        }

        // 売買区分コードチェック
        // 《料金メニューEntity》.売買区分コードが"1:売電" かつ 送受電区分コードリスト（変数）に"1:送電"が存在しない
        // または、
        // 《料金メニューEntity》.売買区分コードが"2:買電" かつ 送受電区分コードリスト（変数）に"2:受電"が存在しない場合、
        // リターンコードに（G037）を設定し返却する。
        if ((ECISCodeConstants.SALE_CATEGORY_SELLING.equals(rateMenu.getSaleCatCode())
            && !tranCatCodeList.contains(ECISCodeConstants.TRANSMISSION_CATEGORY_CODE_TRANSMISSION))
            || (ECISCodeConstants.SALE_CATEGORY_PURCHASING.equals(rateMenu.getSaleCatCode())
                && !tranCatCodeList.contains(ECISCodeConstants.TRANSMISSION_CATEGORY_CODE_RECEIVING))) {
          updateContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G037);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G037),
                  new String[] {}, Locale.getDefault()));
          return updateContractBusinessBean;
        }

        // 契約容量チェック
        String capacitynit = rateMenu.getCcaUnit();
        // 契約容量単位がNULLまたは空文字いずれかでない場
        if (StringUtils.isNotEmpty(capacitynit) && capacity == null) {
          // 契約容量がNULLの場合リターンコードに（P065）を設定し返却する。

          updateContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P065);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P065),
                  new String[] {}, Locale.getDefault()));
          return updateContractBusinessBean;
        }
        // 契約容量単位がNULLまたは空文字の場合
        if (StringUtils.isEmpty(capacitynit) && capacity != null) {
          // 契約容量がNULLではない場合リターンコードに（P064）を設定し返却する。

          updateContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P064);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P064),
                  new String[] {}, Locale.getDefault()));
          return updateContractBusinessBean;

        }
        // 契約容量選択可能範囲チェック
        if (capacity != null) {
          boolean resultCapaCheck = RK_CommonUtil
              .checkContractCapacity(String.valueOf(capacity),
                  rateMenu.getCapacitySelectableRange());
          if (!resultCapaCheck) {
            updateContractBusinessBean
                .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G006);
            updateContractBusinessBean
                .setMessage(messageSource.getMessage(
                    KJ_CommonUtil
                        .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G006),
                    new String[] {}, Locale.getDefault()));
            return updateContractBusinessBean;
          }
        }
      } else {
        // 料金メニューIDないの場合
        // 最新の履歴から、料金メニューＩＤを取得する
        rateMenu = rmMapper.selectByPrimaryKey(inquryContractList.get(0)
            .getContractHistoryInformationList().get(0).getRateMenuId());
        // 取得結果判定、返却結果がNULLの場合、リターンコード（D003）を返却する。
        if (rateMenu == null) {
          throw new BusinessLogicException(
              messageSource.getMessage("error.E1138",
                  new String[] {}, Locale.getDefault()));
        }
      }

      // 適用期間チェック
      // 契約終了日ない場合、履歴最新終了日を取得し、期間チェック行う
      Date endDate = contractEndDate == null ? inquryContractList.get(0).getContractEndDate() : contractEndDate;
      // 契約開始日と契約終了日は料金期間外の場合
      if (periodCheck(applyStartDate, rateMenu.getApplySd(), rateMenu.getApplyEd()) ||
          periodCheck(endDate, rateMenu.getApplySd(), rateMenu.getApplyEd())) {
        // リターンコードに（G039）を設定し返却する。
        updateContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G039);
        updateContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G039),
                new String[] {}, Locale.getDefault()));
        return updateContractBusinessBean;
      }

      List<KJ_ContractHistoryInformationEntityBean> historyList = inquryContractList
          .get(0).getContractHistoryInformationList();
      Date contractApplyStartDate = historyList.get(0)
          .getApplyStartDate();
      // 《契約情報照会BusinessBean》.適用開始日と《契約情報更新BusinessBean》.適用開始日が同日でない
      if (contractApplyStartDate.compareTo(applyStartDate) != 0) {

        Map<String, Object> fixParamMap = new HashMap<String, Object>();
        fixParamMap.put("contractId", inquryContractList.get(0)
            .getContractId());
        fixParamMap.put("coveredDate", applyStartDate);
        fixParamMap
            .put("flg",
                ECISKJConstants.INQUIRY_FIX_CHANGE_RESULT_INFOEMATION_FLG_ON);
        // 確定料金チェック
        int fixChargeCount = fixChargeResultInformationCommonMapper
            .countByFixChargeResult(fixParamMap);

        // 結果が1件以上の場合リターンコードに（D009）を設定し返却する。
        if (fixChargeCount >= 1) {

          updateContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D009);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D009),
                  new String[] {}, Locale.getDefault()));
          return updateContractBusinessBean;
        }
      }

      List<KJ_SupplementaryContractInformationEntityBean> supplementryContractList = null;
      // 付帯契約存在チェック
      if (contractEndDate != null) {

        InquirySupplementaryContractBusinessBean supplementBean = new InquirySupplementaryContractBusinessBean();
        supplementBean.setContractId(inquryContractList.get(0)
            .getContractId());
        supplementBean.setInqCoveredDate(contractEndDate);
        InquirySupplementaryContractBusinessBean resultSupplementryContract = kjSupplementaryContractInformationBusiness
            .inquiry(supplementBean);
        supplementryContractList = resultSupplementryContract
            .getSupplementaryContractList();
        String returnCodeSpplement = resultSupplementryContract
            .getReturnCode();
        // リターンコードが'0000'以外の場合、業務例外クラスをスローする
        if (!ECISReturnCodeConstants.RETURN_CODE_0000
            .equals(returnCodeSpplement)) {

          throw new BusinessLogicException(
              messageSource.getMessage("error.E1284",
                  new String[] {}, Locale.getDefault()),
              false);
        }

        int size = supplementryContractList.size();
        for (int i = 0; i < size; i++) {
          KJ_SupplementaryContractInformationEntityBean supplement = supplementryContractList
              .get(i);
          Date suppleStartDate = supplement
              .getSupplementaryContractStartDate();
          // 付帯契約開始日 ≧ 契約終了日の場合リターンコードに（G029）を設定し返却する。
          if (suppleStartDate.compareTo(contractEndDate) >= 0) {

            updateContractBusinessBean
                .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G029);
            updateContractBusinessBean
                .setMessage(messageSource.getMessage(
                    KJ_CommonUtil
                        .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G029),
                    new String[] {}, Locale.getDefault()));
            return updateContractBusinessBean;
          }
        }
        // 算定期間チェック
        Map<String, Object> fixParamMap = new HashMap<String, Object>();
        fixParamMap.put("contractId", inquryContractList.get(0)
            .getContractId());
        fixParamMap.put("coveredDate", contractEndDate);
        fixParamMap
            .put("flg",
                ECISKJConstants.INQUIRY_FIX_CHANGE_RESULT_INFOEMATION_FLG_OFF);

        int fixChargeEndCount = fixChargeResultInformationCommonMapper
            .countByFixChargeResult(fixParamMap);
        // 結果が1件以上の場合リターンコードに（D019）を設定し返却する
        if (fixChargeEndCount >= 1) {

          updateContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D019);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D019),
                  new String[] {}, Locale.getDefault()));
          return updateContractBusinessBean;
        }

      }

      // 契約終了取り消しフラグ
      int contractEndCancelFlag = CONTRACT_CANCEL_FLAG_OFF;
      // 契約終了理由コード
      String contractEndReasonCodeOfContract = inquryContractList.get(0)
          .getContractEndReasonCode();
      // 《契約情報更新BusinessBean》.契約終了日が"99991231"かつ、《契約情報照会BusinessBean》.契約終了理由コードがNULLまたは空文字
      // のいずれかでない場合、かつ《契約情報更新BusinessBean》.契約終了理由コードが
      // NULLまたは空文字のいずれかの場合、以下の処理を行う。
      Integer meterLocationId = mlList.get(0).getMeterLocationId();

      if (contractEndDate != null
          && (contractEndDate.compareTo(maxDate) == 0
              && StringUtils
                  .isNotEmpty(contractEndReasonCodeOfContract)
              && StringUtils
                  .isEmpty(contractEndReasonCode))) {

        // 契約情報履歴件数取得
        Map<String, Object> countHistoryMap = new HashMap<String, Object>();
        countHistoryMap.put("meterLocationId", meterLocationId);
        countHistoryMap.put("contractId", inquryContractList.get(0).getContractId());
        countHistoryMap.put("startDate", inquryContractList.get(0).getContractStartDate());
        countHistoryMap.put("flag", ECISConstants.FLG_OFF);
        int historyCount = contractInformationCommonMapper
            .countByContractHistory(countHistoryMap);

        // 結果が1件以上の場合リターンコードに（G026）を設定し返却する
        if (historyCount >= 1) {

          updateContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G026);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G026),
                  new String[] {}, Locale.getDefault()));
          return updateContractBusinessBean;
        }
        contractEndCancelFlag = CONTRACT_CANCEL_FLAG_ON;
      }

      // 《契約情報更新BusinessBean》.契約終了日がNULLまたは空文字のいずれかでない
      // かつ《契約情報更新BusinessBean》.契約終了日が“99991231”でない
      // かつ《契約情報更新BusinessBean》.契約終了理由コードがNULLまたは空文字のいずれかでない場合、以下の処理を行う。
      if (contractEndDate != null
          && contractEndDate.compareTo(maxDate) != 0
          && StringUtils.isNotEmpty(contractEndReasonCode)) {
        // 契約情報履歴件数取得
        Map<String, Object> countHistoryMap = new HashMap<String, Object>();
        countHistoryMap.put("meterLocationId", meterLocationId);
        countHistoryMap.put("contractId", inquryContractList.get(0).getContractId());
        countHistoryMap.put("startDate", inquryContractList.get(0).getContractStartDate());
        countHistoryMap.put("endDate", contractEndDate);
        countHistoryMap.put("flag", ECISConstants.FLG_ON);
        int historyCount = contractInformationCommonMapper.countByContractHistory(countHistoryMap);

        // 結果が1件以上の場合リターンコードに（G026）を設定し返却する
        if (historyCount >= 1) {
          updateContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G026);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G026),
                  new String[] {}, Locale.getDefault()));
          return updateContractBusinessBean;
        }
      }

      // 付帯契約Exampleリスト
      List<SplContractExample> supplementExampleList = new ArrayList<SplContractExample>();
      // 付帯契約更新用リスト
      List<SplContract> supplementryUpdateList = new ArrayList<SplContract>();
      // 契約終了日がNULLでないかつ 契約終了日が“99991231”でないかつ付帯契約がNULLではない
      if (contractEndDate != null
          && contractEndDate.compareTo(maxDate) != 0) {

        int size = supplementryContractList.size();
        for (int i = 0; i < size; i++) {

          KJ_SupplementaryContractInformationEntityBean supplement = supplementryContractList
              .get(i);
          Date supplementEndDate = supplement
              .getSupplementaryContractEndDate();

          // 付帯契約終了日 > 契約終了日
          if (supplementEndDate.after(contractEndDate)) {
            SplContractExample tmpExample = createSupplementaryContractExample(supplement);
            SplContract tmpSuppleyment = createSupplementaryContract(
                supplement, contextUserId, contextModuleCode);
            supplementExampleList.add(tmpExample);
            supplementryUpdateList.add(tmpSuppleyment);
          }
        }
      }

      // 契約履歴情報取得
      Map<String, Object> searchContractHistoryParam = new HashMap<String, Object>();
      searchContractHistoryParam.put("contractId", inquryContractList
          .get(0).getContractId());
      searchContractHistoryParam.put("applyStartDate", applyStartDate);

      KJ_ContractHistoryUpdateCountEntityBean contractHistoryUpdateCount = contractInformationCommonMapper
          .searchContractHistory(searchContractHistoryParam);
      Integer inquryPamentId = (CollectionUtils.isEmpty(paymentList)) ? null
          : paymentList.get(0).getPaymentId();
      // 契約情報更新
      Contract contract = createUpdateContract(
          updateContractBusinessBean, consignmentCapacityUnit,
          inquryPamentId, contextUserId, contextModuleCode);
      // 契約終了取り消しフラグ（変数）が"1"の場合契約終了理由コードに空文字を設定する。
      if (contractEndCancelFlag == CONTRACT_CANCEL_FLAG_ON) {
        contract.setContractEndReasonCode(ECISKJConstants.EMPTY_STRING);
      }

      // consignmentContractCapacityNoUpdFlag 託送契約容量
      // consignmentContractCapacityDecisionDateNoUpdFlag 託送契約容量判定日
      // conditionContractId 契約ID 更新条件
      // conditionUpdateCount 更新回数 更新条件
      Map<String, Object> contractExample = new HashMap<String, Object>();

      contractExample.put("consignmentContractCapacityNoUpdFlag",
          updateContractBusinessBean
              .getConsignmentContractCapacityNoUpdFlag());
      contractExample
          .put("consignmentContractCapacityDecisionDateNoUpdFlag",
              updateContractBusinessBean
                  .getConsignmentContractCapacityDecisionDateNoUpdFlag());
      contractExample.put("conditionContractId", inquryContractList
          .get(0).getContractId());
      contractExample.put("conditionUpdateCount",
          updateContractBusinessBean.getUpdateCount());

      int updateContractCount = contractMapper
          .updateByNoUpdFlagSelective(contract, contractExample);

      // 契約情報更新結果が0件の場合リターンコードに（H001）を設定し返却する
      if (updateContractCount == 0) {
        updateContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_H001);
        updateContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_H001),
                new String[] {}, Locale.getDefault()));
        return updateContractBusinessBean;
      }

      // 《契約履歴更新回数EntityBean》.適用開始日
      Date historyApplyStartDate = contractHistoryUpdateCount
          .getApplyStartDate();

      // 《契約情報更新BusinessBean》.適用開始日より《契約履歴更新回数EntityBean》.適用開始日が過去日の場合
      if (historyApplyStartDate.before(applyStartDate)) {

        // 適用終了日の設定
        // 引数.契約終了日がNULLではない場合、引数.契約終了日を設定し、
        // 引数.契約終了日がNULLの場合、《契約情報照会BusinessBean》.契約終了日を設定する。
        Date applyEd = contractEndDate != null ? contractEndDate
            : inquryContractList.get(0)
                .getContractEndDate();

        // 契約履歴情報登録
        ContractHist contractHistory = createInsertContractHistory(
            updateContractBusinessBean, inquryContractList.get(0),
            rateMenu, applyEd, contextUserId, contextModuleCode);
        contractHistMapper.insertSelective(contractHistory);
        // システム日時
        Timestamp systemTime = new Timestamp(System.currentTimeMillis());
        // メータ設置場所契約履歴情報登録
        MlContractHist mlContractHistory = new MlContractHist();
        mlContractHistory.setMlId(meterLocationId);
        mlContractHistory.setApplySd(applyStartDate);
        mlContractHistory.setContractId(inquryContractList.get(0)
            .getContractId());
        mlContractHistory.setCreateTime(systemTime);
        mlContractHistory.setOnlineUpdateTime(systemTime);
        mlContractHistory.setOnlineUpdateUserId(contextUserId);
        mlContractHistory.setUpdateModuleCode(contextModuleCode);
        mlContractHistory.setUpdateTime(systemTime);
        mlContractHistory.setUpdateCount(0);
        mlContractHistMapper.insertSelective(mlContractHistory);
        // 前回契約履歴情報更新
        ContractHist lastContractHistory = createUpdateContractHistory(
            updateContractBusinessBean,
            (contractHistoryUpdateCount.getUpdateCount() + 1),
            contextUserId, contextModuleCode);

        ContractHistExample lastHistExample = new ContractHistExample();
        lastHistExample
            .createCriteria()
            .andContractIdEqualTo(
                inquryContractList.get(0).getContractId())
            .andApplySdEqualTo(historyApplyStartDate)
            .andUpdateCountEqualTo(
                contractHistoryUpdateCount.getUpdateCount());

        int result = contractHistMapper.updateByExampleSelective(
            lastContractHistory, lastHistExample);
        if (result == 0) {
          // 更新結果が0件の場合リターンコードに（H001）を設定し返却する
          updateContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_H001);
          updateContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_H001),
                  new String[] {}, Locale.getDefault()));
          return updateContractBusinessBean;
        }
      }
      // 《契約情報更新BusinessBean》.適用開始日と《契約履歴更新回数EntityBean》.適用開始日が同日の場合
      if (historyApplyStartDate.compareTo(applyStartDate) == 0) {
        if (contractEndDate != null) {
          // 契約履歴更新
          ContractHist contractHistory = createUpdateContractEndHistory(
              updateContractBusinessBean,
              (contractHistoryUpdateCount.getUpdateCount() + 1),
              contextUserId, contextModuleCode);

          ContractHistExample histExample = new ContractHistExample();

          histExample
              .createCriteria()
              .andContractIdEqualTo(
                  inquryContractList.get(0).getContractId())
              .andApplySdEqualTo(historyApplyStartDate)
              .andUpdateCountEqualTo(
                  contractHistoryUpdateCount.getUpdateCount());

          int result = contractHistMapper.updateByExampleSelective(
              contractHistory, histExample);
          // 更新結果が0件の場合リターンコードに（H001）を設定し返却する
          if (result == 0) {
            updateContractBusinessBean
                .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_H001);
            updateContractBusinessBean
                .setMessage(messageSource.getMessage(
                    KJ_CommonUtil
                        .getMessageId(ECISReturnCodeConstants.RETURN_CODE_H001),
                    new String[] {}, Locale.getDefault()));
            return updateContractBusinessBean;
          }
        }
      }

      // 契約終了日がNULLでない かつ 契約終了日が“99991231でない
      // かつ 付帯契約Exampleリストが空でない場合は、付帯契約情報更新を行う。
      // ※付帯契約Exampleリストには、付帯契約終了日が契約終了日後の付帯契約が設定される。
      if (contractEndDate != null
          && contractEndDate.compareTo(maxDate) != 0
          && !CollectionUtils.isEmpty(supplementExampleList)) {

        int size = supplementExampleList.size();
        for (int i = 0; i < size; i++) {
          // 付帯契約更新
          SplContract record = supplementryUpdateList.get(i);
          SplContractExample example = supplementExampleList
              .get(i);
          // 付帯契約終了日に契約終了日を入れる
          record.setSplContractEd(contractEndDate);
          int supplyUpdateCount = splContractMapper
              .updateByExampleSelective(record, example);
          if (supplyUpdateCount == 0) {
            // リターンコードに（H001）を設定し返却する
            updateContractBusinessBean
                .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_H001);
            return updateContractBusinessBean;
          }
        }
      }

      updateContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);

    } catch (BusinessLogicException businessLogicException) {
      logger.error(messageSource.getMessage("error.E1129", null,
          Locale.getDefault()), businessLogicException);
      // 業務例外クラス
      updateContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      updateContractBusinessBean.setMessage(errorMessage);
    } catch (DataAccessException exception) {
      logger.error(messageSource.getMessage("error.E1129", null,
          Locale.getDefault()), exception);
      updateContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      updateContractBusinessBean.setMessage(errorMessage);
    } catch (NoSuchMessageException ioe) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, ioe);
      updateContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      updateContractBusinessBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
    } catch (SystemException se) {
      logger.error(messageSource.getMessage("error.E1129", null,
          Locale.getDefault()), se);
      updateContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      updateContractBusinessBean.setMessage(errorMessage);
    }
    return updateContractBusinessBean;
  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.kj.
   * KJ_ContractInformationBusiness #delete(jp.co.unisys.enability.cis
   * .business.kj.model.DeleteContractBusinessBean)
   */
  @Override
  public DeleteContractBusinessBean delete(
      DeleteContractBusinessBean deleteContractBusinessBean) {

    String errorMessage = null;

    try {

      errorMessage = messageSource.getMessage(KJ_CommonUtil
          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G017),
          new String[] {}, Locale.getDefault());
      // 契約情報存在チェック
      InquiryContractBusinessBean inquiryContractBusinessBean = new InquiryContractBusinessBean();

      Integer deleteContractId = deleteContractBusinessBean
          .getContractId();
      String deleteContractNo = deleteContractBusinessBean
          .getContractNo();
      Date deleteContractApplyStartDate = deleteContractBusinessBean
          .getApplyStartDate();

      inquiryContractBusinessBean.setContractId(deleteContractId);
      inquiryContractBusinessBean.setContractNo(deleteContractNo);

      InquiryContractBusinessBean resultInquiry = inquiry(inquiryContractBusinessBean);
      String inquiryReturnCode = resultInquiry.getReturnCode();
      List<KJ_InquiryContractInformationEntityBean> inquryList = resultInquiry
          .getContractInformationList();
      // リターンコードが'0000'以外の場合、業務例外クラスをスローする。
      if (!ECISReturnCodeConstants.RETURN_CODE_0000
          .equals(inquiryReturnCode)) {

        throw new BusinessLogicException(messageSource.getMessage(
            "error.E1285", new String[] {}, Locale.getDefault()),
            false);
      }
      // リターンコードが'0000'かつ返却値が0件の場合リターンコードに(P005)を設定し返却する
      if (CollectionUtils.isEmpty(inquryList)) {

        deleteContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P005);
        deleteContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P005),
                new String[] {}, Locale.getDefault()));
        return deleteContractBusinessBean;
      }

      // 契約終了状態判定のため、算定期間チェックを行う。
      Map<String, Object> exampleMap = new HashMap<String, Object>();
      exampleMap.put("contractId", inquryList.get(0).getContractId());
      exampleMap.put("coveredDate", inquryList.get(0).getContractEndDate());
      exampleMap.put("flg", ECISKJConstants.INQUIRY_FIX_CHANGE_RESULT_INFOEMATION_FLG_TWO);
      int resultCount = fixChargeResultInformationCommonMapper.countByFixChargeResult(exampleMap);
      // 結果が1件以上の場合リターンコードに（D025）を設定し返却する
      if (resultCount >= 1) {
        deleteContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D025);
        deleteContractBusinessBean.setMessage(messageSource.getMessage(
            KJ_CommonUtil.getMessageId(ECISReturnCodeConstants.RETURN_CODE_D025),
            new String[] {}, Locale.getDefault()));
        return deleteContractBusinessBean;
      }

      List<KJ_ContractHistoryInformationEntityBean> contractHistList = inquryList
          .get(0).getContractHistoryInformationList();

      // 《契約情報照会EntityBean》（最新）
      KJ_ContractHistoryInformationEntityBean contractHistNew = contractHistList
          .get(0);

      KJ_ContractHistoryInformationEntityBean contractHistLast = null;
      // 契約情報リストが2件以上の場合《契約情報照会EntityBean》（前回）に契約情報リストの二件目を設定する。
      if (contractHistList.size() >= 2) {
        contractHistLast = contractHistList.get(1);
      }

      Date newContractApplyStartDate = contractHistNew
          .getApplyStartDate();
      // 《契約情報照会EntityBean》（最新）.適用開始日と《契約情報削除BusinessBean》.適用開始日が一致しない場合、G001
      if (deleteContractApplyStartDate
          .compareTo(newContractApplyStartDate) != 0) {

        deleteContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G001);
        deleteContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G001),
                new String[] {}, Locale.getDefault()));
        return deleteContractBusinessBean;
      }

      Integer newContractId = contractHistNew.getContractId();

      Map<String, Object> fixParamMap = new HashMap<String, Object>();
      fixParamMap.put("contractId", newContractId);
      fixParamMap.put("coveredDate", deleteContractApplyStartDate);
      fixParamMap
          .put("flg",
              ECISKJConstants.INQUIRY_FIX_CHANGE_RESULT_INFOEMATION_FLG_ON);

      // 確定料金チェック
      Integer fixChargeResultCount = fixChargeResultInformationCommonMapper
          .countByFixChargeResult(fixParamMap);
      // 結果が1件以上の場合リターンコードに（D009）を設定し返却する。
      if (fixChargeResultCount >= 1) {

        deleteContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D009);
        deleteContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D009),
                new String[] {}, Locale.getDefault()));
        return deleteContractBusinessBean;
      }
      // 付帯契約情報存在チェック
      if (contractHistLast == null) {
        // 《契約情報照会EntityBean》(前回)がNULLの場合
        InquirySupplementaryContractBusinessBean inquirySupplementaryContractBusinessBean = new InquirySupplementaryContractBusinessBean();
        inquirySupplementaryContractBusinessBean
            .setContractId(newContractId);

        InquirySupplementaryContractBusinessBean resultSupplementryContract = kjSupplementaryContractInformationBusiness
            .inquiry(inquirySupplementaryContractBusinessBean);
        List<KJ_SupplementaryContractInformationEntityBean> supplementryContractList = resultSupplementryContract
            .getSupplementaryContractList();
        String supplementReturnCode = resultSupplementryContract
            .getReturnCode();

        // リターンコードが'0000'以外の場合、業務例外クラスをスローする。
        if (!ECISReturnCodeConstants.RETURN_CODE_0000
            .equals(supplementReturnCode)) {

          throw new BusinessLogicException(
              messageSource.getMessage("error.E1284",
                  new String[] {}, Locale.getDefault()),
              false);
        }

        // リターンコードが'0000'かつ返却値が1件以上の場合リターンコードに（D001）を設定し返却する。
        if (!CollectionUtils.isEmpty(supplementryContractList)) {

          deleteContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D001);
          deleteContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D001),
                  new String[] {}, Locale.getDefault()));
          return deleteContractBusinessBean;
        }

      }

      // 契約履歴情報取得
      // 引数のキーと値をMapに関連付ける。
      Map<String, Object> contractHistoryParam = new HashMap<String, Object>();
      contractHistoryParam.put("contractId", newContractId);
      contractHistoryParam.put("applyStartDate",
          deleteContractApplyStartDate);

      KJ_ContractHistoryUpdateCountEntityBean resultHistoryBean = contractInformationCommonMapper
          .searchContractHistory(contractHistoryParam);
      // 取得した契約履歴更新回数情報が０件の場合、業務例外クラスをスローする。
      if (resultHistoryBean == null) {
        throw new BusinessLogicException(errorMessage, false);
      }

      // 契約削除
      // 《契約情報照会EntityBean》(前回)がNULLの場合
      if (contractHistLast == null) {

        // 契約削除
        ContractExample deleteLastContractExample = new ContractExample();
        Integer deleteContractUpdateCount = deleteContractBusinessBean
            .getUpdateCount();

        deleteLastContractExample.createCriteria()
            .andContractIdEqualTo(newContractId)
            .andUpdateCountEqualTo(deleteContractUpdateCount);

        // 《契約Mapper》.削除（選択項目）呼び出し
        int deleteCount = contractMapper
            .deleteByExample(deleteLastContractExample);
        // 返却値が0件の場合リターンコードに（H001）を設定し返却する。
        if (deleteCount == 0) {
          deleteContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_H001);

          deleteContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_H001),
                  new String[] {}, Locale.getDefault()));
          return deleteContractBusinessBean;
        }
      }

      // コンテキスト・ユーザID
      String contextUserId = ThreadContext.getRequestThreadContext()
          .get(ECISConstants.USER_ID_KEY).toString();
      // コンテキスト.モジュールコード
      String contextModuleCode = ThreadContext.getRequestThreadContext()
          .get(ECISConstants.CLASS_NAME_KEY).toString();
      Integer deleteContractUpdateCount = deleteContractBusinessBean
          .getUpdateCount();
      // 更新
      // 《契約情報照会EntityBean》(前回)がNULLではない場合
      if (contractHistLast != null) {

        // 契約更新
        Contract updateContract = new Contract();
        // 更新回数に《契約情報削除BusinessBean》.更新回数に1加算した値を設定する
        Integer updateUpdateCount = deleteContractUpdateCount + 1;
        // システム日時
        Timestamp sysetmTime = new Timestamp(System.currentTimeMillis());
        updateContract.setUpdateCount(updateUpdateCount);
        updateContract.setOnlineUpdateTime(sysetmTime);
        updateContract.setOnlineUpdateUserId(contextUserId);
        updateContract.setUpdateTime(sysetmTime);
        updateContract.setUpdateModuleCode(contextModuleCode);

        ContractExample contractExample = new ContractExample();
        contractExample.createCriteria()
            .andContractIdEqualTo(newContractId)
            .andUpdateCountEqualTo(deleteContractUpdateCount);

        int updateContractCount = contractMapper
            .updateByExampleSelective(updateContract,
                contractExample);
        // 返却値が0件の場合リターンコードに（H001）を設定し返却する。
        if (updateContractCount == 0) {
          deleteContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_H001);
          deleteContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_H001),
                  new String[] {}, Locale.getDefault()));
          return deleteContractBusinessBean;
        }
      }

      // 契約履歴削除
      ContractHistExample contractHistoryExample = new ContractHistExample();
      contractHistoryExample.createCriteria()
          .andContractIdEqualTo(newContractId)
          .andApplySdEqualTo(deleteContractApplyStartDate)
          .andUpdateCountEqualTo(resultHistoryBean.getUpdateCount());

      int contractHistoryDeleteCount = contractHistMapper
          .deleteByExample(contractHistoryExample);
      // 返却値が0件の場合リターンコードに（H001）を設定し返却する
      if (contractHistoryDeleteCount == 0) {
        deleteContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_H001);

        deleteContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_H001),
                new String[] {}, Locale.getDefault()));
        return deleteContractBusinessBean;
      }

      // メータ設置場所契約履歴削除
      MlContractHistExample mlHistory = new MlContractHistExample();
      mlHistory.createCriteria().andContractIdEqualTo(newContractId)
          .andApplySdEqualTo(deleteContractApplyStartDate)
          .andUpdateCountEqualTo(0);

      int mlDeleteCount = mlContractHistMapper.deleteByExample(mlHistory);
      // 返却値が0件の場合リターンコードに（H001）を設定し返却する。
      if (mlDeleteCount == 0) {

        deleteContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_H001);

        deleteContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_H001),
                new String[] {}, Locale.getDefault()));
        return deleteContractBusinessBean;
      }
      // 《契約情報照会EntityBean》(前回)がNULLではない場合
      if (contractHistLast != null) {

        // 契約履歴更新
        Integer lastContractId = contractHistLast.getContractId();
        Integer lastContractUpdateCount = contractHistLast
            .getUpdateCount();
        Date newApplyEndDate = inquryList.get(0).getContractEndDate();
        int updateCount = lastContractUpdateCount + 1;
        // システム日時
        Timestamp sysetmTime = new Timestamp(System.currentTimeMillis());
        ContractHist contractHistory = new ContractHist();
        contractHistory.setApplyEd(newApplyEndDate);
        contractHistory.setUpdateCount(updateCount);
        contractHistory.setOnlineUpdateTime(sysetmTime);
        contractHistory.setOnlineUpdateUserId(contextUserId);
        contractHistory.setUpdateTime(sysetmTime);
        contractHistory.setUpdateModuleCode(contextModuleCode);

        ContractHistExample lastContractHistExample = new ContractHistExample();
        // (前回).契約IDを設定する。
        // (前回).適用開始日を設定する。
        // (前回).更新回数を設定する。
        lastContractHistExample
            .createCriteria()
            .andContractIdEqualTo(lastContractId)
            .andApplySdEqualTo(contractHistLast.getApplyStartDate())
            .andUpdateCountEqualTo(lastContractUpdateCount);

        int updateLastContractCount = contractHistMapper
            .updateByExampleSelective(contractHistory,
                lastContractHistExample);

        // 返却値が0件の場合リターンコードに（H001）を設定し返却する。
        if (updateLastContractCount == 0) {

          deleteContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_H001);
          deleteContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_H001),
                  new String[] {}, Locale.getDefault()));
          return deleteContractBusinessBean;
        }
      }

      // 正常終了
      deleteContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);

    } catch (BusinessLogicException businessLosicException) {
      logger.error(messageSource.getMessage("error.E1129", null,
          Locale.getDefault()), businessLosicException);
      // リターンコードに（G017）を設定し返却する。
      deleteContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      deleteContractBusinessBean.setMessage(errorMessage);
    } catch (NoSuchMessageException ioe) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, ioe);
      deleteContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      deleteContractBusinessBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
    } catch (DataAccessException e) {
      logger.error(messageSource.getMessage("error.E1129", null,
          Locale.getDefault()), e);
      deleteContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      deleteContractBusinessBean.setMessage(errorMessage);
    }

    return deleteContractBusinessBean;
  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.kj.
   * KJ_ContractInformationBusiness #add(jp.co.unisys.enability.cis
   * .business.kj.model.AddContractBusinessBean)
   */
  @Override
  public AddContractBusinessBean add(
      AddContractBusinessBean addContractBusinessBean) {

    String errorMessage = null;
    try {
      errorMessage = messageSource.getMessage(KJ_CommonUtil
          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G017),
          new String[] {}, Locale.getDefault());

      Integer meterLocationId = addContractBusinessBean
          .getMeterLocationId();
      InquiryMeterLocationBusinessBean inquiryMeterLocationBusinessBean = new InquiryMeterLocationBusinessBean();
      String contractNo = addContractBusinessBean.getContractNo();
      // メータ設置場所IDがNULLでない場合
      if (meterLocationId != null) {
        // メータ設置場所照会
        inquiryMeterLocationBusinessBean
            .setMeterLocationId(meterLocationId);
        InquiryMeterLocationBusinessBean meterLocationResult = kjMeterLocationInformationBusiness
            .inquiry(inquiryMeterLocationBusinessBean);

        List<KJ_InquiryMeterLocationEntityBean> resultMlBeanList = meterLocationResult
            .getMeterLocationList();
        String meterLocationReturnCode = meterLocationResult
            .getReturnCode();

        // リターンコードが“0000”以外の場合
        if (!ECISReturnCodeConstants.RETURN_CODE_0000
            .equals(meterLocationReturnCode)) {

          // 《契約情報追加BusinessBean》.リターンコードに《メータ設置場所照会BusinessBean》.リターンコードを設定し返却する。
          addContractBusinessBean
              .setReturnCode(meterLocationReturnCode);
          addContractBusinessBean.setMessage(meterLocationResult
              .getMessage());
          return addContractBusinessBean;
        }
        // リターンコードが“0000”かつ返却値が0件の場合リターンコード（P008）を設定し返却する。
        if (CollectionUtils.isEmpty(resultMlBeanList)) {

          addContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P008);
          addContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P008),
                  new String[] {}, Locale.getDefault()));
          return addContractBusinessBean;
        }

        // メータ設置場所更新
        UpdateMeterLocationBusinessBean updateMlBean = createUpdateMeterLocationBusinessBean(
            addContractBusinessBean);

        UpdateMeterLocationBusinessBean returnUpdateMl = kjMeterLocationInformationBusiness
            .update(updateMlBean);
        String returnCodeUpdateMl = returnUpdateMl.getReturnCode();
        // リターンコードが“0000”以外の場合《契約情報追加BusinessBean》.リターンコードに《メータ設置場所更新BusinessBean》.リターンコードを設定し返却する。
        if (!ECISReturnCodeConstants.RETURN_CODE_0000
            .equals(returnCodeUpdateMl)) {
          addContractBusinessBean.setReturnCode(returnCodeUpdateMl);
          addContractBusinessBean.setMessage(returnUpdateMl
              .getMessage());
          return addContractBusinessBean;
        }
        addContractBusinessBean.setPlaceId(meterLocationResult
            .getMeterLocationList().get(0).getPlaceId());
      } else {
        // メータ設置場所IDがNULLの場合

        // 次回検針予定日判定
        Date nextMeterReadingScheduledDate = addContractBusinessBean
            .getNextMeterReadingScheduledDate();
        Date contractStartDate = addContractBusinessBean
            .getContractStartDate();
        // 次回検針予定日 < 契約開始日の場合
        if (nextMeterReadingScheduledDate.before(contractStartDate)) {

          // 《契約情報追加BusinessBean》.次回検針予定日に 契約開始日 +
          // 外部ファイル.次回検針予定日加算日数を設定する
          Date externalNextSucheduleDate = dateBusiness
              .calcWorkDate(
                  contractStartDate,
                  ECISCodeConstants.WORK_DAYS_FOR_NEXT_METER_READING_SCHEDULED_DATE_ADD_DAYS);

          addContractBusinessBean
              .setNextMeterReadingScheduledDate(externalNextSucheduleDate);
        }

        // メータ設置場所登録
        RegistMeterLocationBusinessBean registerMlBean = createRegistMeterLocationBusinessBean(
            addContractBusinessBean);
        RegistMeterLocationBusinessBean returnRegisterMlBean = kjMeterLocationInformationBusiness
            .regist(registerMlBean);
        String returnCodeRegister = returnRegisterMlBean
            .getReturnCode();
        // リターンコードが“0000”以外の場合《契約情報追加BusinessBean》.リターンコードに《メータ設置場所登録BusinessBean》.リターンコードを設定し返却する。
        if (!ECISReturnCodeConstants.RETURN_CODE_0000
            .equals(returnCodeRegister)) {
          addContractBusinessBean.setReturnCode(returnCodeRegister);
          addContractBusinessBean.setMessage(returnRegisterMlBean
              .getMessage());
          return addContractBusinessBean;
        }
        // ID設定
        addContractBusinessBean.setPlaceId(returnRegisterMlBean
            .getPlaceId());
        addContractBusinessBean.setMeterLocationId(returnRegisterMlBean
            .getMeterLocationId());
      }
      // 契約登録
      RegistContractBusinessBean registerContractBean = createRegistContractBusinessBean(addContractBusinessBean);
      RegistContractBusinessBean resultRegisterContractBean = regist(registerContractBean);
      String returnCodeRegisterContract = resultRegisterContractBean
          .getReturnCode();

      // リターンコードが“0000”以外の場合《契約情報追加BusinessBean》.リターンコードにregistBean.リターンコードを設定し返却する
      if (!ECISReturnCodeConstants.RETURN_CODE_0000
          .equals(returnCodeRegisterContract)) {
        addContractBusinessBean
            .setReturnCode(returnCodeRegisterContract);
        addContractBusinessBean.setMessage(resultRegisterContractBean
            .getMessage());
        return addContractBusinessBean;
      }

      addContractBusinessBean.setContractId(registerContractBean
          .getContractId());
      List<KJ_SupplementaryContractBean> sContractSupplementList = addContractBusinessBean
          .getSupplementaryContractList();

      // 《契約情報追加BusinessBean》.付帯契約情報リスト分、以下の処理を繰り返す。
      if (sContractSupplementList != null) {
        // Beanに渡す用の付帯契約IDリスト
        List<Integer> supplementIdList = new ArrayList<Integer>();

        Integer contractId = registerContractBean.getContractId();

        for (KJ_SupplementaryContractBean supplement : sContractSupplementList) {
          // 付帯契約情報追加
          AddSupplementaryContractBusinessBean addSupplementBean = new AddSupplementaryContractBusinessBean();

          // 額・率
          addSupplementBean.setAmountOrRate(supplement
              .getAmountOrRate());
          // 契約ID
          addSupplementBean.setContractId(contractId);
          // 契約番号
          addSupplementBean.setContractNo(contractNo);
          // 付帯契約終了日
          addSupplementBean
              .setSupplementaryContractEndDate(supplement
                  .getSupplementaryContractEndDate());

          // 付帯メニューID
          addSupplementBean.setSupplementaryMenuId(supplement
              .getSupplementaryMenuId());
          // 付帯契約開始日
          addSupplementBean
              .setSupplementaryContractStartDate(supplement
                  .getSupplementaryContractStartDate());

          AddSupplementaryContractBusinessBean resultAddSupple = kjSupplementaryContractInformationBusiness
              .add(addSupplementBean);
          String returnCodeAddSBean = resultAddSupple.getReturnCode();
          if (!ECISReturnCodeConstants.RETURN_CODE_0000
              .equals(returnCodeAddSBean)) {
            // リターンコードが“0000”以外の場合リターンコードに《付帯契約情報追加BusinessBean》.リターンコードを設定し返却する
            addContractBusinessBean
                .setReturnCode(returnCodeAddSBean);
            addContractBusinessBean.setMessage(resultAddSupple
                .getMessage());
            return addContractBusinessBean;
          }
          // 付帯契約リスト.付帯契約IDに付帯契約IDを設定する
          Integer supplementaryContractId = resultAddSupple
              .getSupplementaryContractId();
          supplementIdList.add(supplementaryContractId);
        }
        // 《契約情報追加BusinessBean》.付帯契約IDリストに付帯契約IDリストを設定する
        addContractBusinessBean.setSupplementaryContractIdList(supplementIdList);
      }
      addContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);
    } catch (DataAccessException e) {
      logger.error(messageSource.getMessage("error.E1129", null,
          Locale.getDefault()), e);
      // リターンコードに（G017）を設定し処理を終了する。
      addContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      addContractBusinessBean.setMessage(errorMessage);
    } catch (NoSuchMessageException ioe) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, ioe);
      addContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      addContractBusinessBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
    } catch (SystemException se) {
      logger.error(messageSource.getMessage("error.E1129", null,
          Locale.getDefault()), se);
      addContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      addContractBusinessBean.setMessage(errorMessage);
    }
    return addContractBusinessBean;
  }

  /**
   * 契約履歴リストの適用開始日のリスト中に適用開始日より未来日が存在した場合TRUE
   *
   * @param contractList
   *          契約情報照会List
   * @param applyStartDate
   *          適用開始日
   * @return Boolean
   */
  private boolean isFeature(
      List<KJ_InquiryContractInformationEntityBean> contractList,
      Date applyStartDate) {
    int size = contractList.size();
    for (int i = 0; i < size; i++) {
      KJ_InquiryContractInformationEntityBean contract = contractList
          .get(i);
      // 契約情報リストから契約履歴リストを取得
      List<KJ_ContractHistoryInformationEntityBean> contractHistoryList = contract
          .getContractHistoryInformationList();
      if (CollectionUtils.isEmpty(contractHistoryList)) {
        continue;
      }
      int hSize = contractHistoryList.size();
      for (int t = 0; t < hSize; t++) {
        KJ_ContractHistoryInformationEntityBean contractHistory = contractHistoryList
            .get(t);
        // 契約履歴リストから適用開始日を取得して比較
        Date historyApplyStartDate = contractHistory
            .getApplyStartDate();

        if (historyApplyStartDate.after(applyStartDate)) {
          return true;
        }
      }
    }
    return false;
  }

  /**
   * 契約登録BusinessBeanを返す
   *
   * @param AddContractBusinessBean
   *          契約情報追加BusinessBean
   * @return RegistContractBusinessBean 契約情報登録BusinessBean
   */
  private RegistContractBusinessBean createRegistContractBusinessBean(
      AddContractBusinessBean addContractBusinessBean) {

    RegistContractBusinessBean registContractBusinessBean = new RegistContractBusinessBean();

    // 契約番号
    registContractBusinessBean.setContractNo(addContractBusinessBean
        .getContractNo());

    // 契約者ID
    registContractBusinessBean.setContractorId(addContractBusinessBean
        .getContractorId());

    // 契約者番号
    registContractBusinessBean.setContractorNo(addContractBusinessBean
        .getContractorNo());

    // 支払ID
    registContractBusinessBean.setPaymentId(addContractBusinessBean
        .getPaymentId());

    // 支払番号
    registContractBusinessBean.setPaymentNo(addContractBusinessBean
        .getPaymentNo());

    // メータ設置場所ID
    registContractBusinessBean.setMeterLocationId(addContractBusinessBean
        .getMeterLocationId());

    // 契約開始日
    registContractBusinessBean.setContractStartDate(addContractBusinessBean
        .getContractStartDate());

    // 契約終了日
    registContractBusinessBean.setContractEndDate(addContractBusinessBean
        .getContractEndDate());

    // 契約終了理由コード
    registContractBusinessBean
        .setContractEndReasonCode(addContractBusinessBean
            .getContractEndReasonCode());

    // 託送契約容量
    registContractBusinessBean
        .setConsignmentContractCapacity(addContractBusinessBean
            .getConsignmentContractCapacity());

    // 託送契約容量単位コード
    registContractBusinessBean
        .setConsignmentcontractCapacityUnitCode(addContractBusinessBean
            .getConsignmentcontractCapacityUnitCode());

    // 託送契約容量判定日
    registContractBusinessBean
        .setConsignmentContractCapacityDecisionDate(addContractBusinessBean
            .getConsignmentContractCapacityDecisionDate());

    // 料金チェックフラグ
    registContractBusinessBean.setChargeCheckFlag(addContractBusinessBean
        .getChargeCheckFlag());

    // 契約グループ番号
    registContractBusinessBean.setContractGroupNo(addContractBusinessBean
        .getContractGroupNo());

    // 連絡先個人・法人区分コード
    registContractBusinessBean
        .setContactInformationinDividualLegalEntityCategoryCode(addContractBusinessBean
            .getContactInformationindividualLegalEntityCategoryCode());

    // 連絡先氏名（カナ）
    registContractBusinessBean
        .setContractInformationNameKana(addContractBusinessBean
            .getContractInformationNameKana());

    // 連絡先氏名1
    registContractBusinessBean
        .setContractInformationName1(addContractBusinessBean
            .getContractInformationName1());

    // 連絡先氏名2
    registContractBusinessBean
        .setContractInformationName2(addContractBusinessBean
            .getContractInformationName2());

    // 連絡先住所（郵便番号）
    registContractBusinessBean
        .setContractInformationAddressPostalCode(addContractBusinessBean
            .getContractInformationAddressPostalCode());

    // 連絡先住所（住所）
    registContractBusinessBean
        .setContractInformationAddressFull(addContractBusinessBean
            .getContractInformationAddressFull());

    // 連絡先住所（建物・部屋名）
    registContractBusinessBean
        .setContractInformationAddressBuilding(addContractBusinessBean
            .getContractInformationAddressBuilding());

    // 連絡先電話区分コード
    registContractBusinessBean
        .setContractInformationCategoryCode(addContractBusinessBean
            .getContractInformationCategoryCode());

    // 連絡先電話（市外局番）
    registContractBusinessBean
        .setContractInformationAreaCode(addContractBusinessBean
            .getContractInformationAreaCode());

    // 連絡先電話（市内局番）
    registContractBusinessBean
        .setContractInformationLocalNo(addContractBusinessBean
            .getContractInformationLocalNo());

    // 連絡先電話（加入者番号）
    registContractBusinessBean
        .setContractInformationDirectoryNo(addContractBusinessBean
            .getContractInformationDirectoryNo());

    // 接続送電サービス区分コード
    registContractBusinessBean
        .setConnectedSupplyServiceCategoryCode(addContractBusinessBean
            .getConnectedSupplyServiceCategoryCode());

    // 部分供給区分コード
    registContractBusinessBean
        .setPsInfoCatCode(addContractBusinessBean
            .getPsInfoCatCode());

    // フリー項目1 再エネ電源種別コード
    registContractBusinessBean.setFree1(addContractBusinessBean
        .getRenewableEnergyPowerSourceClassCode());

    // フリー項目2 再エネ設備容量
    registContractBusinessBean.setFree2(addContractBusinessBean
        .getRenewableEnergyFcltCapacity());

    // フリー項目3 再エネ設備認定年度
    registContractBusinessBean.setFree3(addContractBusinessBean
        .getRenewableEnergyFcltAprvFiscalYear());

    // フリー項目4 振込先金融機関コード
    registContractBusinessBean.setFree4(addContractBusinessBean
        .getTransferBankCode());

    // フリー項目5 振込先金融機関支店コード
    registContractBusinessBean.setFree5(addContractBusinessBean
        .getTransferBankBranchCode());

    // フリー項目6 振込先預金種目コード
    registContractBusinessBean.setFree6(addContractBusinessBean
        .getTransferTypeOfAccountCode());

    // フリー項目7 振込先口座番号
    registContractBusinessBean.setFree7(addContractBusinessBean
        .getTransferAccountNo());

    // フリー項目8 振込先口座名義（カナ）
    registContractBusinessBean.setFree8(addContractBusinessBean
        .getTransferAccountHolderNameKana());

    // フリー項目9 設備ID
    registContractBusinessBean.setFree9(addContractBusinessBean
        .getFree9());

    // フリー項目10 申込日
    registContractBusinessBean.setFree10(addContractBusinessBean
        .getEntryDate());

    // フリー項目11 調達開始年月
    registContractBusinessBean.setFree11(addContractBusinessBean
        .getSupplyStartPeriod());

    // フリー項目12 事業税算定対象フラグ
    registContractBusinessBean.setFree12(addContractBusinessBean
        .getBizTaxCalculationCoveredFlag());

    // フリー項目13 振込先金融機関名称（カナ）
    registContractBusinessBean.setFree13(addContractBusinessBean
        .getTransferBankNameKana());

    // フリー項目14 振込先金融機関支店名称（カナ）
    registContractBusinessBean.setFree14(addContractBusinessBean
        .getTransferBankBranchNameKana());

    // 業種コード
    registContractBusinessBean.setBusinessTypeCode(addContractBusinessBean
        .getBusinessTypeCode());

    // 営業委託先コード
    registContractBusinessBean
        .setSalesConsignmentCode(addContractBusinessBean
            .getSalesConsignmentCode());

    // 契約備考
    registContractBusinessBean.setContractNote(addContractBusinessBean
        .getContractNote());

    // 料金メニューID
    registContractBusinessBean.setChargeMenuId(addContractBusinessBean
        .getChargeMenuId());

    // 契約容量
    registContractBusinessBean.setContractCapacity(addContractBusinessBean
        .getContractCapacity());

    // 委託先使用項目1
    registContractBusinessBean
        .setConsignmentUseItem1(addContractBusinessBean
            .getConsignmentUseItem1());

    // 委託先使用項目2
    registContractBusinessBean
        .setConsignmentUseItem2(addContractBusinessBean
            .getConsignmentUseItem2());

    // 委託先使用項目3
    registContractBusinessBean
        .setConsignmentUseItem3(addContractBusinessBean
            .getConsignmentUseItem3());

    // 自社担当者コード
    registContractBusinessBean
        .setOurManagementPersonInChargeCode(addContractBusinessBean
            .getOurManagementPersonInChargeCode());

    // 自社部署コード
    registContractBusinessBean
        .setOurManagementDepartmentCode(addContractBusinessBean
            .getOurManagementDepartmentCode());

    return registContractBusinessBean;
  }

  /**
   * メーター設置場所更新BusinessBeanに値をセットして返す
   *
   * @param AddContractBusinessBean
   *          契約情報追加BusinessBean
   *
   * @return UpdateMeterLocationBusinessBean メータ設置場所更新BusinessBean
   */
  private UpdateMeterLocationBusinessBean createUpdateMeterLocationBusinessBean(
      AddContractBusinessBean addContractBusinessBean) {

    UpdateMeterLocationBusinessBean meterLocationBean = new UpdateMeterLocationBusinessBean();

    // メータ設置場所ID
    meterLocationBean.setMeterLocationId(addContractBusinessBean
        .getMeterLocationId());

    // 需要場所住所（郵便番号）
    meterLocationBean.setPlaceAddressPostalCode(addContractBusinessBean
        .getPlaceAddressPostalCode());

    // 需要場所住所（住所）
    meterLocationBean.setPlaceAddressFull(addContractBusinessBean
        .getPlaceAddressFull());

    // 需要場所住所（建物・部屋名）
    meterLocationBean.setPlaceAddressBuilding(addContractBusinessBean
        .getPlaceAddressBuilding());

    // エリアコード
    meterLocationBean.setAreaCode(addContractBusinessBean.getAreaCode());

    // 地点特定番号
    meterLocationBean.setSpotNo(addContractBusinessBean.getSpotNo());

    // 需要家識別番号
    meterLocationBean.setContractorIdentificationNo(addContractBusinessBean
        .getContractorIdentificationNo());

    // 送受電区分コード
    meterLocationBean.setTransmissionCategoryCode(addContractBusinessBean
        .getTransmissionCategoryCode());

    // 基本検針日
    meterLocationBean.setBasicMeterReadingDate(addContractBusinessBean
        .getBasicMeterReadingDate());

    // 次回検針予定日
    meterLocationBean
        .setNextMeterReadingScheduledDate(addContractBusinessBean
            .getNextMeterReadingScheduledDate());

    // 次回検針予定日更新対象外フラグ
    meterLocationBean.setNextMeterReadingScheduledDateNoUpdFlag(ECISConstants.FLG_OFF);

    // 前回検針日
    meterLocationBean.setLastTimeMeterReadingDate(addContractBusinessBean
        .getLastTimeMeterReadingDate());

    // 前回検針日更新対象外フラグ
    meterLocationBean.setLastTimeMeterReadingDateNoUpdFlag(ECISConstants.FLG_ON);

    // 自家発連携有無コード
    meterLocationBean.setGeneratorLinkageCheckCode(addContractBusinessBean
        .getGeneratorLinkageCheckCode());

    // 供給方式コード
    meterLocationBean.setMethodCode(addContractBusinessBean
        .getSupplyMethodCode());

    // 計器識別番号1
    meterLocationBean.setMeterIdentificationNo1(addContractBusinessBean
        .getMeterIdentificationNo1());

    // 計器識別番号2
    meterLocationBean.setMeterIdentificationNo2(addContractBusinessBean
        .getMeterIdentificationNo2());

    // 計器識別番号3
    meterLocationBean.setMeterIdentificationNo3(addContractBusinessBean
        .getMeterIdentificationNo3());

    // 計器識別番号4
    meterLocationBean.setMeterIdentificationNo4(addContractBusinessBean
        .getMeterIdentificationNo4());

    // 計器識別番号5
    meterLocationBean.setMeterIdentificationNo5(addContractBusinessBean
        .getMeterIdentificationNo5());

    // 30分値収集可否・自動検針可否コード1
    meterLocationBean
        .setAutomaticMeterReadingCkeckCode1(addContractBusinessBean
            .getAutomaticMeterReadingCkeckCode1());

    // 30分値収集可否・自動検針可否コード2
    meterLocationBean
        .setAutomaticMeterReadingCkeckCode2(addContractBusinessBean
            .getAutomaticMeterReadingCkeckCode2());

    // 30分値収集可否・自動検針可否コード3
    meterLocationBean
        .setAutomaticMeterReadingCkeckCode3(addContractBusinessBean
            .getAutomaticMeterReadingCkeckCode3());

    // 30分値収集可否・自動検針可否コード4
    meterLocationBean
        .setAutomaticMeterReadingCkeckCode4(addContractBusinessBean
            .getAutomaticMeterReadingCkeckCode4());

    // 30分値収集可否・自動検針可否コード5
    meterLocationBean
        .setAutomaticMeterReadingCkeckCode5(addContractBusinessBean
            .getAutomaticMeterReadingCkeckCode5());

    // 更新回数
    meterLocationBean.setUpdateCount(addContractBusinessBean
        .getUpdateCount());
    return meterLocationBean;
  }

  /**
   * メータ設置場所登録BusinessBeanに値をセットして返す
   *
   * @param AddContractBusinessBean
   *          契約情報追加BusinessBean
   * @return UpdateMeterLocationBusinessBean メータ設置場所登録BusinessBean
   */
  private RegistMeterLocationBusinessBean createRegistMeterLocationBusinessBean(
      AddContractBusinessBean addContractBusinessBean) {
    RegistMeterLocationBusinessBean meterLocationBean = new RegistMeterLocationBusinessBean();

    // 需要場所住所（郵便番号）
    meterLocationBean.setPlaceAddressPostalCode(addContractBusinessBean
        .getPlaceAddressPostalCode());

    // 需要場所住所（住所）
    meterLocationBean.setPlaceAddressFull(addContractBusinessBean
        .getPlaceAddressFull());

    // 需要場所住所（建物・部屋名）
    meterLocationBean.setPlaceAddressBuilding(addContractBusinessBean
        .getPlaceAddressBuilding());

    // エリアコード
    meterLocationBean.setAreaCode(addContractBusinessBean.getAreaCode());

    // 地点特定番号
    meterLocationBean.setSpotNo(addContractBusinessBean.getSpotNo());

    // 需要家識別番号
    meterLocationBean.setContractorIdentificationNo(addContractBusinessBean
        .getContractorIdentificationNo());

    // 送受電区分コード
    meterLocationBean.setTransmissionCategoryCode(addContractBusinessBean
        .getTransmissionCategoryCode());

    // 基本検針日
    meterLocationBean.setBasicMeterReadingDate(addContractBusinessBean
        .getBasicMeterReadingDate());

    // 次回検針予定日
    meterLocationBean
        .setNextMeterReadingScheduledDate(addContractBusinessBean
            .getNextMeterReadingScheduledDate());

    // 前回検針日
    meterLocationBean.setLastTimeMeterReadingDate(null);

    // 自家発連携有無コード
    meterLocationBean.setGeneratorLinkageCheckCode(addContractBusinessBean
        .getGeneratorLinkageCheckCode());

    // 供給方式コード
    meterLocationBean.setMethodCode(addContractBusinessBean
        .getSupplyMethodCode());

    // 計器識別番号1
    meterLocationBean.setMeterIdentificationNo1(addContractBusinessBean
        .getMeterIdentificationNo1());

    // 計器識別番号2
    meterLocationBean.setMeterIdentificationNo2(addContractBusinessBean
        .getMeterIdentificationNo2());

    // 計器識別番号3
    meterLocationBean.setMeterIdentificationNo3(addContractBusinessBean
        .getMeterIdentificationNo3());

    // 計器識別番号4
    meterLocationBean.setMeterIdentificationNo4(addContractBusinessBean
        .getMeterIdentificationNo4());

    // 計器識別番号5
    meterLocationBean.setMeterIdentificationNo5(addContractBusinessBean
        .getMeterIdentificationNo5());

    // 30分値収集可否・自動検針可否コード1
    meterLocationBean
        .setAutomaticMeterReadingCkeckCode1(addContractBusinessBean
            .getAutomaticMeterReadingCkeckCode1());

    // 30分値収集可否・自動検針可否コード2
    meterLocationBean
        .setAutomaticMeterReadingCkeckCode2(addContractBusinessBean
            .getAutomaticMeterReadingCkeckCode2());

    // 30分値収集可否・自動検針可否コード3
    meterLocationBean
        .setAutomaticMeterReadingCkeckCode3(addContractBusinessBean
            .getAutomaticMeterReadingCkeckCode3());

    // 30分値収集可否・自動検針可否コード4
    meterLocationBean
        .setAutomaticMeterReadingCkeckCode4(addContractBusinessBean
            .getAutomaticMeterReadingCkeckCode4());

    // 30分値収集可否・自動検針可否コード5
    meterLocationBean
        .setAutomaticMeterReadingCkeckCode5(addContractBusinessBean
            .getAutomaticMeterReadingCkeckCode5());

    return meterLocationBean;
  }

  /**
   * 契約(更新)エンティティ取得
   *
   * @param updateContractBusinessBean
   * @param consignmentCapacityUnit
   * @param paymentId
   * @param contextUserId
   * @param contextModuleCode
   * @return
   */
  private Contract createUpdateContract(
      UpdateContractBusinessBean updateContractBusinessBean,
      String consignmentCapacityUnit, Integer paymentId,
      String contextUserId, String contextModuleCode) {

    Contract contract = new Contract();

    // 支払ID
    contract.setPaymentId(paymentId);

    // 契約終了日
    contract.setContractEd(updateContractBusinessBean.getContractEndDate());

    // 契約終了理由コード
    contract.setContractEndReasonCode(updateContractBusinessBean
        .getContractEndReasonCode());

    // 料金チェックフラグ
    contract.setChargeCheckFlag(updateContractBusinessBean
        .getChargeCheckFlag());

    // 営業委託先コード
    contract.setScCode(updateContractBusinessBean.getSalesConsignmentCode());

    // 契約グループ番号
    contract.setContractGroupNo(updateContractBusinessBean
        .getContractGroupNo());

    // 個人・法人区分コード
    contract.setIlcCode(updateContractBusinessBean
        .getContactInformationinDividualLegalEntityCategoryCode());

    // 連絡先氏名（カナ）
    contract.setCiNameKana(updateContractBusinessBean
        .getContractInformationNameKana());

    // 連絡先氏名1
    contract.setCiName1(updateContractBusinessBean
        .getContractInformationName1());

    // 連絡先氏名2
    contract.setCiName2(updateContractBusinessBean
        .getContractInformationName2());

    // 連絡先住所（郵便番号）
    contract.setCiAddressPostalCode(updateContractBusinessBean
        .getContractInformationAddressPostalCode());

    // 連絡先住所（住所）
    contract.setCiAddressFull(updateContractBusinessBean
        .getContractInformationAddressFull());

    // 連絡先住所（建物・部屋名）
    contract.setCiAddressBuilding(updateContractBusinessBean
        .getContractInformationAddressBuilding());

    // 電話番号
    String telAreaNo = updateContractBusinessBean
        .getContractInformationAreaCode();
    String telLocalNo = updateContractBusinessBean
        .getContractInformationLocalNo();
    String telDirNo = updateContractBusinessBean
        .getContractInformationDirectoryNo();

    if (StringUtils.isNotEmpty(telAreaNo)
        && StringUtils.isNotEmpty(telLocalNo)
        && StringUtils.isNotEmpty(telDirNo)) {

      StringBuilder phoneStrBuilder = new StringBuilder();

      phoneStrBuilder.append(telAreaNo);
      phoneStrBuilder.append(ECISConstants.HYPHEN);
      phoneStrBuilder.append(telLocalNo);
      phoneStrBuilder.append(ECISConstants.HYPHEN);
      phoneStrBuilder.append(telDirNo);
      contract.setCiPhoneNo(phoneStrBuilder.toString());

    }
    if (ECISKJConstants.EMPTY_STRING.equals(telAreaNo)
        || ECISKJConstants.EMPTY_STRING.equals(telLocalNo)
        || ECISKJConstants.EMPTY_STRING.equals(telDirNo)) {

      contract.setCiPhoneNo(ECISKJConstants.EMPTY_STRING);

    }
    // 連絡先電話番号

    // 連絡先電話（市外局番）
    contract.setCiAreaCode(telAreaNo);

    // 連絡先電話（市内局番）
    contract.setCiLocalNo(telLocalNo);

    // 連絡先電話（加入者番号）
    contract.setCiDirectoryNo(telDirNo);
    // 連絡先電話区分コード
    contract.setCiCatCode(updateContractBusinessBean
        .getContractInformationCategoryCode());

    // 業種コード
    contract.setBusinessTypeCode(updateContractBusinessBean
        .getBusinessTypeCode());

    // 接続送電サービス区分コード
    contract.setCssCatCode(updateContractBusinessBean
        .getConnectedSupplyServiceCategoryCode());

    // 部分供給区分コード
    contract.setPsInfoCatCode(updateContractBusinessBean
        .getPsInfoCatCode());

    // 託送契約容量
    contract.setConsignmentCca(updateContractBusinessBean
        .getConsignmentContractCapacity());
    // 託送契約容量単位
    contract.setConsignmentCcaUnit(consignmentCapacityUnit);

    // 託送契約容量判定日
    contract.setConsignmentCcaDecisionDate(updateContractBusinessBean
        .getConsignmentContractCapacityDecisionDate());

    // 備考
    contract.setNote(updateContractBusinessBean.getContractNote());

    // フリー項目1
    contract.setFree1(updateContractBusinessBean.getFree1());

    // フリー項目2
    contract.setFree2(updateContractBusinessBean.getFree2());

    // フリー項目3
    contract.setFree3(updateContractBusinessBean.getFree3());

    // フリー項目4
    contract.setFree4(updateContractBusinessBean.getFree4());

    // フリー項目5
    contract.setFree5(updateContractBusinessBean.getFree5());

    // フリー項目6
    contract.setFree6(updateContractBusinessBean.getFree6());

    // フリー項目7
    contract.setFree7(updateContractBusinessBean.getFree7());

    // フリー項目8
    contract.setFree8(updateContractBusinessBean.getFree8());

    // フリー項目9
    contract.setFree9(updateContractBusinessBean.getFree9());

    // フリー項目10
    contract.setFree10(updateContractBusinessBean.getFree10());

    // フリー項目11
    contract.setFree11(updateContractBusinessBean.getFree11());

    // フリー項目12
    contract.setFree12(updateContractBusinessBean.getFree12());

    // フリー項目13
    contract.setFree13(updateContractBusinessBean.getFree13());

    // フリー項目14
    contract.setFree14(updateContractBusinessBean.getFree14());

    // 委託先使用項目1
    contract.setConsignmentUseItem1(updateContractBusinessBean
        .getConsignmentUseItem1());

    // 委託先使用項目2
    contract.setConsignmentUseItem2(updateContractBusinessBean
        .getConsignmentUseItem2());

    // 委託先使用項目3
    contract.setConsignmentUseItem3(updateContractBusinessBean
        .getConsignmentUseItem3());

    // 自社担当者コード
    contract.setOurMngPersonInChargeCode(updateContractBusinessBean
        .getOurManagementPersonInChargeCode());

    // 自社部署コード
    contract.setOurMngDepartmentCode(updateContractBusinessBean
        .getOurManagementDepartmentCode());

    // 更新回数
    contract.setUpdateCount(updateContractBusinessBean.getUpdateCount() + 1);

    Timestamp systemTime = new Timestamp(System.currentTimeMillis());

    // オンライン更新日時
    contract.setOnlineUpdateTime(systemTime);

    // オンライン更新ユーザID
    contract.setOnlineUpdateUserId(contextUserId);

    // 更新モジュールコード
    contract.setUpdateModuleCode(contextModuleCode);

    // 更新日時
    contract.setUpdateTime(systemTime);

    return contract;
  }

  /**
   * registBeanより《契約履歴Entity》に値を設定する
   *
   * @param businessBean
   *          契約情報登録BusinessBean
   * @param contractorId
   *          契約者ID
   * @param paymentId
   *          支払ID
   * @param maxDate
   *          最大日付
   * @param contextUserId
   *          コンテキストユーザID
   * @param contextModuleCode
   *          コンテキストモジュールコード
   * @return 契約Entity
   */
  private Contract createRegistContract(
      RegistContractBusinessBean businessBean, Integer contractorId,
      Integer paymentId, Date maxDate, String contextUserId,
      String contextModuleCode) {

    Contract contract = new Contract();

    // 契約番号
    contract.setContractNo(businessBean.getContractNo());

    // 契約者ID
    contract.setContractorId(contractorId);

    // 支払ID
    contract.setPaymentId(paymentId);

    // 契約開始日
    contract.setContractSd(businessBean.getContractStartDate());

    // 契約終了日 NULLの場合“99991231”を設定
    Date contractEndDate = businessBean.getContractEndDate() == null ? maxDate
        : businessBean.getContractEndDate();
    contract.setContractEd(contractEndDate);

    // 契約終了理由コード
    contract.setContractEndReasonCode(businessBean
        .getContractEndReasonCode());

    // 託送契約容量
    contract.setConsignmentCca(businessBean
        .getConsignmentContractCapacity());

    // 託送契約容量単位
    contract.setConsignmentCcaUnit(businessBean
        .getConsignmentcontractCapacityUnitCode());

    // 託送契約容量判定日
    contract.setConsignmentCcaDecisionDate(businessBean
        .getConsignmentContractCapacityDecisionDate());

    // 料金チェックフラグ NULLまたは空文字のいずれかの場合“0”を設定
    String chargeCheckFlag = StringUtils.isEmpty(businessBean
        .getChargeCheckFlag()) ? ECISKJConstants.CHARGE_CHECK_FLAG_CORRECTION_OFF
            : businessBean.getChargeCheckFlag();
    contract.setChargeCheckFlag(chargeCheckFlag);

    // 契約グループ番号
    contract.setContractGroupNo(businessBean.getContractGroupNo());

    // 個人・法人区分コード
    contract.setIlcCode(businessBean
        .getContactInformationinDividualLegalEntityCategoryCode());

    // 連絡先氏名（カナ）
    contract.setCiNameKana(businessBean.getContractInformationNameKana());

    // 連絡先氏名1
    contract.setCiName1(businessBean.getContractInformationName1());

    // 連絡先氏名2
    contract.setCiName2(businessBean.getContractInformationName2());

    // 連絡先住所（郵便番号）
    contract.setCiAddressPostalCode(businessBean
        .getContractInformationAddressPostalCode());

    // 連絡先住所（住所）
    contract.setCiAddressFull(businessBean
        .getContractInformationAddressFull());

    // 連絡先住所（建物・部屋名）
    contract.setCiAddressBuilding(businessBean
        .getContractInformationAddressBuilding());

    // 電話番号
    String telAreaNo = businessBean.getContractInformationAreaCode();
    String telLocalNo = businessBean.getContractInformationLocalNo();
    String telDirNo = businessBean.getContractInformationDirectoryNo();
    if (StringUtils.isNotEmpty(telAreaNo)
        && StringUtils.isNotEmpty(telLocalNo)
        && StringUtils.isNotEmpty(telDirNo)) {
      StringBuilder phoneStrBuilder = new StringBuilder();

      phoneStrBuilder.append(telAreaNo);
      phoneStrBuilder.append(ECISConstants.HYPHEN);
      phoneStrBuilder.append(telLocalNo);
      phoneStrBuilder.append(ECISConstants.HYPHEN);
      phoneStrBuilder.append(telDirNo);

      // 連絡先電話番号
      contract.setCiPhoneNo(phoneStrBuilder.toString());

    }

    // 連絡先電話（市外局番）
    contract.setCiAreaCode(telAreaNo);

    // 連絡先電話（市内局番）
    contract.setCiLocalNo(telLocalNo);

    // 連絡先電話（加入者番号）
    contract.setCiDirectoryNo(telDirNo);

    // 連絡先電話区分コード
    contract.setCiCatCode(businessBean.getContractInformationCategoryCode());

    // 接続送電サービス区分コード
    contract.setCssCatCode(businessBean
        .getConnectedSupplyServiceCategoryCode());

    // 部分供給区分コード
    contract.setPsInfoCatCode(businessBean
        .getPsInfoCatCode());

    // フリー項目1
    contract.setFree1(businessBean.getFree1());

    // フリー項目2
    contract.setFree2(businessBean.getFree2());

    // フリー項目3
    contract.setFree3(businessBean.getFree3());

    // フリー項目4
    contract.setFree4(businessBean.getFree4());

    // フリー項目5
    contract.setFree5(businessBean.getFree5());

    // フリー項目6
    contract.setFree6(businessBean.getFree6());

    // フリー項目7
    contract.setFree7(businessBean.getFree7());

    // フリー項目8
    contract.setFree8(businessBean.getFree8());

    // フリー項目9
    contract.setFree9(businessBean.getFree9());

    // フリー項目10
    contract.setFree10(businessBean.getFree10());

    // フリー項目11
    contract.setFree11(businessBean.getFree11());

    // フリー項目12
    contract.setFree12(businessBean.getFree12());

    // フリー項目13
    contract.setFree13(businessBean.getFree13());

    // フリー項目14
    contract.setFree14(businessBean.getFree14());

    // 業種コード
    contract.setBusinessTypeCode(businessBean.getBusinessTypeCode());

    // 営業委託先コード
    contract.setScCode(businessBean.getSalesConsignmentCode());

    // 備考
    contract.setNote(businessBean.getContractNote());

    // 委託先使用項目1
    contract.setConsignmentUseItem1(businessBean.getConsignmentUseItem1());

    // 委託先使用項目2
    contract.setConsignmentUseItem2(businessBean.getConsignmentUseItem2());

    // 委託先使用項目3
    contract.setConsignmentUseItem3(businessBean.getConsignmentUseItem3());

    // 自社担当者コード
    contract.setOurMngPersonInChargeCode(businessBean
        .getOurManagementPersonInChargeCode());

    // 自社部署コード
    contract.setOurMngDepartmentCode(businessBean
        .getOurManagementDepartmentCode());

    // 契約終了分確定使用量連携済フラグに“0”を設定
    contract.setContractEndFuSentFlag(ECISKJConstants.CONTRACT_END_FIX_USAGE_SENT_FLAG_NON_LINKAGE);

    Timestamp systemTime = new Timestamp(System.currentTimeMillis());

    // 更新回数
    contract.setUpdateCount(0);

    // 作成日時
    contract.setCreateTime(systemTime);

    // オンライン更新日時
    contract.setOnlineUpdateTime(systemTime);

    // オンライン更新ユーザID
    contract.setOnlineUpdateUserId(contextUserId);

    // 更新モジュールコード
    contract.setUpdateModuleCode(contextModuleCode);

    // 更新日時
    contract.setUpdateTime(systemTime);

    return contract;
  }

  /**
   * registBeanより《契約履歴Entity》に値を設定する
   *
   * @param businessBean
   *          契約情報登録BusinessBean
   * @param contractId
   *          契約ID
   * @param maxDate
   *          最大日付
   * @param ccaUnit
   *          契約容量単位
   * @param rmId
   *          料金メニューID
   * @param contextUserId
   *          コンテキストユーザID
   * @param contextModuleCode
   *          コンテキストモジュールコード
   * @return 契約履歴Entity
   */
  private ContractHist createContractHistory(
      RegistContractBusinessBean businessBean, Integer contractId,
      Date maxDate, String ccaUnit, String rmId, String contextUserId,
      String contextModuleCode) {

    ContractHist contractHistory = new ContractHist();

    // 契約ID
    contractHistory.setContractId(contractId);

    // 適用開始日
    contractHistory.setApplySd(businessBean.getContractStartDate());

    // 契約終了日がNULLの場合適用終了日に“99991231”
    Date applyEndDate = businessBean.getContractEndDate() == null ? maxDate
        : businessBean.getContractEndDate();
    contractHistory.setApplyEd(applyEndDate);

    // 契約容量
    contractHistory.setCca(businessBean.getContractCapacity());

    // 契約容量単位
    contractHistory.setCcaUnit(ccaUnit);

    // 料金メニューID
    contractHistory.setRmId(rmId);

    // 更新回数
    contractHistory.setUpdateCount(0);

    Timestamp systemTime = new Timestamp(System.currentTimeMillis());

    contractHistory.setCreateTime(systemTime);

    contractHistory.setOnlineUpdateTime(systemTime);

    contractHistory.setOnlineUpdateUserId(contextUserId);

    contractHistory.setUpdateModuleCode(contextModuleCode);

    contractHistory.setUpdateTime(systemTime);

    return contractHistory;
  }

  /**
   * 《契約情報更新BusinessBean》より《契約履歴Entity》に値を設定する（登録用）
   *
   * @param businessBean
   *          契約情報更新BusinessBean
   * @param contractId
   *          契約ID
   * @param rateMenuId
   *          料金メニューID
   * @param capaUnit
   *          契約容量単位
   * @param applyEd
   *          適用終了日
   * @param contextUserId
   *          コンテキストユーザID
   * @param contextModuleCode
   *          コンテキストモジュールコード
   * @return 契約履歴Entity
   */
  private ContractHist createInsertContractHistory(
      UpdateContractBusinessBean businessBean,
      KJ_InquiryContractInformationEntityBean contractBean,
      Rm rateMenu, Date applyEd,
      String contextUserId, String contextModuleCode) {

    ContractHist contractHistory = new ContractHist();
    // システム日時
    Timestamp systemTime = new Timestamp(System.currentTimeMillis());

    KJ_ContractHistoryInformationEntityBean history = contractBean
        .getContractHistoryInformationList().get(0);

    contractHistory.setContractId(contractBean.getContractId());
    // 以下4つは値がなければ履歴からとる
    // 料金メニューID rate_menu_id
    // 契約容量 contract_capacity
    // 契約容量単位 contract_capacity_unit
    // 契約変更理由 contract_change_reason
    String rateMenuId = null;
    String capaUnit = null;

    BigDecimal cca = null;
    // 料金メニューIDがNULLまたは空文字の場合は履歴から
    if (StringUtils.isEmpty(businessBean.getChargeMenuId())) {
      rateMenuId = history.getRateMenuId();
      capaUnit = history.getContractCapacityUnit();
      cca = history.getContractCapacity();
    } else {
      // NULLでも空文字でもない場合は料金メニューから
      rateMenuId = rateMenu.getRmId();
      capaUnit = rateMenu.getCcaUnit();

      // 料金メニューの契約容量単位と容量選択可能範囲項目がどちらもnullの場合、従量電灯Aとなる。
      // このチェックで従量電灯Aの場合は、契約容量はnull（未設定）としてください
      if (rateMenu.getCcaUnit() == null
          && rateMenu.getCapacitySelectableRange() == null) {
        cca = null;
      } else {
        cca = businessBean.getContractCapacity();
      }
    }

    contractHistory.setCca(cca);
    contractHistory.setRmId(rateMenuId);
    contractHistory.setCcaUnit(capaUnit);

    String contractChangeReason = null;
    if (businessBean.getContractChangeReason() != null) {
      contractChangeReason = businessBean.getContractChangeReason();
    } else {
      contractChangeReason = history.getContractChangeReason();
    }
    contractHistory.setContractChangeReason(contractChangeReason);

    contractHistory.setApplySd(businessBean.getApplyStartDate());
    contractHistory.setApplyEd(applyEd);

    contractHistory.setUpdateCount(0);

    contractHistory.setCreateTime(systemTime);

    contractHistory.setOnlineUpdateTime(systemTime);

    contractHistory.setOnlineUpdateUserId(contextUserId);

    contractHistory.setUpdateModuleCode(contextModuleCode);

    contractHistory.setUpdateTime(systemTime);

    return contractHistory;
  }

  /**
   * 《契約情報更新BusinessBean》より《契約履歴Entity》に値を設定する(更新用）
   *
   * @param businessBean
   *          契約情報更新BusinessBean
   * @param updateCount
   *          更新回数
   * @param contextUserId
   *          コンテキストユーザID
   * @param contextModuleCode
   *          コンテキストモジュールコード
   * @return 契約履歴Entity
   */
  private ContractHist createUpdateContractHistory(
      UpdateContractBusinessBean businessBean, Integer updateCount,
      String contextUserId, String contextModuleCode) {

    ContractHist contractHistory = new ContractHist();
    // システム日時
    Timestamp systemTime = new Timestamp(System.currentTimeMillis());

    Date applyEd = DateCalculateUtil.calculateDate(
        businessBean.getApplyStartDate(), 0, 0, -1);
    // 適用開始日の一日前
    contractHistory.setApplyEd(applyEd);

    contractHistory.setUpdateCount(updateCount);

    contractHistory.setOnlineUpdateTime(systemTime);

    contractHistory.setOnlineUpdateUserId(contextUserId);

    contractHistory.setUpdateModuleCode(contextModuleCode);

    contractHistory.setUpdateTime(systemTime);

    return contractHistory;
  }

  /**
   * 《契約情報更新BusinessBean》より《契約履歴Entity》に値を設定する(更新用）
   *
   * @param businessBean
   *          契約情報更新BusinessBean
   * @param updateCount
   *          更新回数
   * @param contextUserId
   *          コンテキストユーザID
   * @param contextModuleCode
   *          コンテキストモジュールコード
   * @return 契約履歴Entity
   */
  private ContractHist createUpdateContractEndHistory(
      UpdateContractBusinessBean businessBean, Integer updateCount,
      String contextUserId, String contextModuleCode) {

    ContractHist contractHistory = new ContractHist();
    // システム日時
    Timestamp systemTime = new Timestamp(System.currentTimeMillis());

    contractHistory.setApplyEd(businessBean.getContractEndDate());

    contractHistory.setUpdateCount(updateCount);

    contractHistory.setOnlineUpdateTime(systemTime);

    contractHistory.setOnlineUpdateUserId(contextUserId);

    contractHistory.setUpdateModuleCode(contextModuleCode);

    contractHistory.setUpdateTime(systemTime);

    return contractHistory;
  }

  /**
   * 利用不可の契約者がいた場合はTRUEを返す
   *
   * @param contractorList
   *          契約者リスト
   * @return Boolean
   */
  private boolean checkUnavailableFlag(
      List<KJ_InquiryContractorInformationEntityBean> contractorList) {

    int size = contractorList.size();

    for (int i = 0; i < size; i++) {

      KJ_InquiryContractorInformationEntityBean contractor = contractorList
          .get(i);
      if (ECISKJConstants.UNAVAILABLE_FLAG_USE_IMPOSSIBLE
          .equals(contractor.getUnavailableFlag())) {
        return true;
      }
    }
    return false;

  }

  /**
   * paymentStartDate > contractStartDate || paymentEndDate < contractStartDateのときにTRUE
   *
   * @param paymentList
   *          支払情報リスト
   * @param contractStartDate
   *          契約開始日
   * @return Boolean
   */
  private boolean checkContractStartDate(
      List<KJ_InquiryPaymentInformationEntityBean> paymentList,
      Date contractStartDate) {

    // 支払有効期間チェック
    Date paymentStartDate = paymentList.get(0).getPaymentStartDate();

    if (paymentStartDate.after(contractStartDate)) {
      // paymentStartDate > contractStartDate

      return true;
    }

    return false;
  }

  /**
   * 付帯契約情報の更新情報を返す
   *
   * @param supplement
   *          付帯契約情報
   * @param onlineUpdateUserId
   *          オンライン更新ユーザID
   * @param updateModuleCode
   *          更新モジュールコード
   * @return 付帯契約Entity
   */
  private SplContract createSupplementaryContract(
      KJ_SupplementaryContractInformationEntityBean supplement,
      String onlineUpdateUserId, String updateModuleCode) {

    SplContract supplementaryContract = new SplContract();

    supplementaryContract.setAmountOrRate(supplement.getAmountOrRate());

    supplementaryContract.setContractId(supplement.getContractId());

    supplementaryContract.setSplContractEd(supplement
        .getSupplementaryContractEndDate());

    supplementaryContract.setSplContractSd(supplement
        .getSupplementaryContractStartDate());

    supplementaryContract.setSpmId(supplement.getSupplementaryMenuId());

    // 更新回数
    supplementaryContract.setUpdateCount(supplement.getUpdateCount() + 1);
    Timestamp systemTime = new Timestamp(System.currentTimeMillis());
    // オンライン更新日時
    supplementaryContract.setOnlineUpdateTime(systemTime);
    // オンライン更新ユーザID
    supplementaryContract.setOnlineUpdateUserId(onlineUpdateUserId);
    // 更新日時
    supplementaryContract.setUpdateTime(systemTime);
    // 更新モジュールコード
    supplementaryContract.setUpdateModuleCode(updateModuleCode);

    return supplementaryContract;
  }

  /**
   * 付帯契約情報の更新条件を返す
   *
   * @param supplement
   *          付帯契約情報
   * @return 付帯契約Example
   */
  private SplContractExample createSupplementaryContractExample(
      KJ_SupplementaryContractInformationEntityBean supplement) {

    SplContractExample tmpExample = new SplContractExample();

    Integer supplementContractId = supplement.getSupplementaryContractId();

    Integer supplementUpdateCount = supplement.getUpdateCount();

    tmpExample.createCriteria()
        .andSplContractIdEqualTo(supplementContractId)
        .andUpdateCountEqualTo(supplementUpdateCount);

    return tmpExample;
  }

  /**
   * 期間チェック
   *
   * @param targetDate
   *          対象日付
   * @param from
   *          期間から
   * @param to
   *          期間まで
   * @return true 期間外<br>
   *         false 期間内
   */
  private boolean periodCheck(Date targetDate, Date from, Date to) {
    Date temp = maxDate;
    // 対象日付取得
    if (targetDate != null) {
      temp = targetDate;
    }

    // 開始日より前或いは終了日より後の場合、期間外を返却する
    if (temp.before(from) || temp.after(to)) {
      return true;
    }

    return false;
  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.kj.
   * KJ_ContractInformationBusiness #download(jp.co.unisys.enability.cis
   * .business.kj.model.DownloadContractBusinessBean)
   */
  public DownloadContractBusinessBean download(
      DownloadContractBusinessBean downloadBusinessBean) {

    try {

      Map<String, Object> exampleMap = new HashMap<String, Object>();
      ContractManagementInformationDownloadSearchInformationBean searchInformationBean = downloadBusinessBean
          .getContractManagementInformationDownloadSearchInformationBean();
      // オンライン処理基準日取得
      Date onlineDate = dateBusiness
          .getProcessBaseDate(ECISConstants.EXEC_BASE_DATE_ONLINE);

      // 契約番号
      exampleMap.put(ECISKJConstants.S010107_SEARCH_KEY_CONTRACT_NO,
          searchInformationBean.getContractNo());
      // 提供モデルコード
      exampleMap.put(ECISKJConstants.S010107_SEARCH_KEY_PROVIDE_MODEL,
          searchInformationBean.getProvideModel());
      // 提供モデル企業コード
      exampleMap.put(
          ECISKJConstants.S010107_SEARCH_KEY_PROVIDE_MODEL_COMPANY,
          searchInformationBean.getProvideModelCompany());
      // エリアコード
      exampleMap.put(ECISKJConstants.S010107_SEARCH_KEY_AREA,
          searchInformationBean.getArea());
      // 料金メニュー
      exampleMap.put(ECISKJConstants.S010107_SEARCH_KEY_RATE_MENU,
          searchInformationBean.getRateMenu());

      // 契約開始日From
      if (StringUtils.isNotEmpty(searchInformationBean
          .getContractTermStartDateFrom())) {
        exampleMap
            .put(ECISKJConstants.S010107_SEARCH_KEY_CONTRACT_TERM_START_DATE_FROM,
                StringConvertUtil.stringToDate(
                    searchInformationBean
                        .getContractTermStartDateFrom(),
                    ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH));
      }
      // 契約開始日To
      if (StringUtils.isNotEmpty(searchInformationBean
          .getContractTermStartDateTo())) {
        exampleMap
            .put(ECISKJConstants.S010107_SEARCH_KEY_CONTRACT_TERM_START_DATE_TO,
                StringConvertUtil.stringToDate(
                    searchInformationBean
                        .getContractTermStartDateTo(),
                    ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH));
      }
      // 契約終了日From
      if (StringUtils.isNotEmpty(searchInformationBean
          .getContractTermEndDateFrom())) {
        exampleMap
            .put(ECISKJConstants.S010107_SEARCH_KEY_CONTRACT_TERM_END_DATE_FROM,
                StringConvertUtil.stringToDate(
                    searchInformationBean
                        .getContractTermEndDateFrom(),
                    ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH));
      }
      // 契約終了日To
      if (StringUtils.isNotEmpty(searchInformationBean
          .getContractTermEndDateTo())) {
        exampleMap
            .put(ECISKJConstants.S010107_SEARCH_KEY_CONTRACT_TERM_END_DATE_TO,
                StringConvertUtil.stringToDate(
                    searchInformationBean
                        .getContractTermEndDateTo(),
                    ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH));
      }

      // オンライン処理基準日
      exampleMap
          .put(ECISKJConstants.S010107_SEARCH_KEY_ONLINE_EXECUTE_BASE_DATE,
              onlineDate);

      // ダウンロード情報検索
      List<KJ_ContractInformationFileEntityBean> list = contractInformationCommonMapper
          .selectContractInformationFile(exampleMap);

      // ファイル情報
      downloadBusinessBean.setContractInformationFileEntityBeanList(list);
      // ファイル名の生成
      StringBuilder fileName = new StringBuilder();
      fileName.append(ECISKJConstants.CONTRACT_MANAGEMENT_INFORMATION_DOWNLOAD_FILE_PREFIX_CONTRACT);
      fileName.append(ECISConstants.UNDERLINE);
      fileName.append(StringConvertUtil.convertDateToString(onlineDate,
          ECISConstants.FORMAT_DATE_yyyyMMdd));
      downloadBusinessBean.setDownloadFileName(fileName.toString());
    } catch (Exception e) {
      throw new SystemException(e.getMessage(), e);
    }
    // 返却
    return downloadBusinessBean;

  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.kj.
   * KJ_ContractInformationBusiness #downloadCustom(jp.co.unisys.enability.cis
   * .business.kj.model.DownloadContractBusinessBean)
   */
  public DownloadContractBusinessBean downloadCustom(
      DownloadContractBusinessBean downloadBusinessBean) {

    try {

      Map<String, Object> exampleMap = new HashMap<String, Object>();
      ContractManagementInformationDownloadSearchInformationBean searchInformationBean = downloadBusinessBean
          .getContractManagementInformationDownloadSearchInformationBean();
      // オンライン処理基準日取得
      Date onlineDate = dateBusiness
          .getProcessBaseDate(ECISConstants.EXEC_BASE_DATE_ONLINE);

      // 契約番号
      exampleMap.put(ECISKJConstants.S010107_SEARCH_KEY_CONTRACT_NO,
          searchInformationBean.getContractNo());
      // 提供モデルコード
      exampleMap.put(ECISKJConstants.S010107_SEARCH_KEY_PROVIDE_MODEL,
          searchInformationBean.getProvideModel());
      // 提供モデル企業コード
      exampleMap.put(
          ECISKJConstants.S010107_SEARCH_KEY_PROVIDE_MODEL_COMPANY,
          searchInformationBean.getProvideModelCompany());
      // エリアコード
      exampleMap.put(ECISKJConstants.S010107_SEARCH_KEY_AREA,
          searchInformationBean.getArea());
      // 料金メニュー
      exampleMap.put(ECISKJConstants.S010107_SEARCH_KEY_RATE_MENU,
          searchInformationBean.getRateMenu());

      // 契約開始日From
      if (StringUtils.isNotEmpty(searchInformationBean
          .getContractTermStartDateFrom())) {
        exampleMap
            .put(ECISKJConstants.S010107_SEARCH_KEY_CONTRACT_TERM_START_DATE_FROM,
                StringConvertUtil.stringToDate(
                    searchInformationBean
                        .getContractTermStartDateFrom(),
                    ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH));
      }
      // 契約開始日To
      if (StringUtils.isNotEmpty(searchInformationBean
          .getContractTermStartDateTo())) {
        exampleMap
            .put(ECISKJConstants.S010107_SEARCH_KEY_CONTRACT_TERM_START_DATE_TO,
                StringConvertUtil.stringToDate(
                    searchInformationBean
                        .getContractTermStartDateTo(),
                    ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH));
      }
      // 契約終了日From
      if (StringUtils.isNotEmpty(searchInformationBean
          .getContractTermEndDateFrom())) {
        exampleMap
            .put(ECISKJConstants.S010107_SEARCH_KEY_CONTRACT_TERM_END_DATE_FROM,
                StringConvertUtil.stringToDate(
                    searchInformationBean
                        .getContractTermEndDateFrom(),
                    ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH));
      }
      // 契約終了日To
      if (StringUtils.isNotEmpty(searchInformationBean
          .getContractTermEndDateTo())) {
        exampleMap
            .put(ECISKJConstants.S010107_SEARCH_KEY_CONTRACT_TERM_END_DATE_TO,
                StringConvertUtil.stringToDate(
                    searchInformationBean
                        .getContractTermEndDateTo(),
                    ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH));
      }

      // オンライン処理基準日
      exampleMap
          .put(ECISKJConstants.S010107_SEARCH_KEY_ONLINE_EXECUTE_BASE_DATE,
              onlineDate);

      // ダウンロード情報検索
      List<KJ_ContractInformationFileEntityBean> list = contractInformationCommonMapper
          .selectContractInformationFileCustom(exampleMap);

      // ファイル情報
      downloadBusinessBean.setContractInformationFileEntityBeanList(list);
      // ファイル名の生成
      StringBuilder fileName = new StringBuilder();
      fileName.append(ECISKJConstants.CONTRACT_MANAGEMENT_INFORMATION_DOWNLOAD_FILE_PREFIX_CONTRACT);
      fileName.append(ECISConstants.UNDERLINE);
      fileName.append(StringConvertUtil.convertDateToString(onlineDate,
          ECISConstants.FORMAT_DATE_yyyyMMdd));
      downloadBusinessBean.setDownloadFileName(fileName.toString());
    } catch (Exception e) {
      throw new SystemException(e.getMessage(), e);
    }
    // 返却
    return downloadBusinessBean;

  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.kj.
   * KJ_ContractInformationBusiness #csvFileCheck(jp.co.unisys.enability.cis
   * .business.kj.model.CsvFileCheckContractBusinessBean)
   */
  public CsvFileCheckContractBusinessBean csvFileCheck(
      CsvFileCheckContractBusinessBean csvFileCheckContractBusinessBean) {
    try {
      /* 返却用オブジェクトの生成 */
      CsvFileCheckContractBusinessBean csvResultBean = new CsvFileCheckContractBusinessBean();
      List<String> errorList = new ArrayList<String>();
      List<Map<Integer, String>> registList = new ArrayList<Map<Integer, String>>();
      List<Map<Integer, String>> updateList = new ArrayList<Map<Integer, String>>();
      List<Map<Integer, String>> deleteList = new ArrayList<Map<Integer, String>>();

      /* ファイルオブジェクト取得 */
      File csvFile = csvFileCheckContractBusinessBean.getUploadFile();

      /* ヘッダレコードチェック */
      // アップロードファイルMap生成
      List<Map<Integer, String>> csvList = null;
      csvList = Csv
          .load(csvFile, ECISConstants.ENCODE_TYPE_UTF8,
              ContractManagementInformationFileConfigCommon
                  .getCsvConfig(),
              new ColumnPositionMapListHandler());

      // ファイル構成チェック
      if (ContractManagementInformationFileConfigCommon.UPLOAD_FILE_MINIMUM_LINE_COUNT > csvList
          .size()) {
        // エラーリストへ格納
        errorList.add(StringConvertUtil.convertErrorListString(
            csvFile.getName(),
            null,
            messageSource.getMessage("error.E0028", null,
                Locale.getDefault())));

        // 処理を終了する。
        csvResultBean.setUploadFileName(csvFile.getName());
        csvResultBean.setErrorList(errorList);
        csvResultBean.setRegistList(registList);
        csvResultBean.setUpdateList(updateList);
        csvResultBean.setDeleteList(deleteList);

        return csvResultBean;
      }

      // 項目数チェック
      Map<Integer, String> header = csvList
          .get(ContractManagementInformationFileConfigCommon.ROW_NUMBER_HEADER);
      if (ContractManagementInformationFileConfigCommon.HEADER_COLUMN_COUNT != header
          .size()) {
        // エラーリストへ格納
        errorList
            .add(StringConvertUtil.convertErrorListString(
                csvFile.getName(),
                ContractManagementInformationFileConfigCommon.HEADER_START_LINE_NUMBER,
                messageSource.getMessage("error.E0021", null,
                    Locale.getDefault())));

        // 処理を終了する。
        csvResultBean.setUploadFileName(csvFile.getName());
        csvResultBean.setErrorList(errorList);
        csvResultBean.setRegistList(registList);
        csvResultBean.setUpdateList(updateList);
        csvResultBean.setDeleteList(deleteList);

        return csvResultBean;
      }

      // 単項目チェック
      List<String> headerErrorMessageList = contractManagementInformationFileHeaderValidator
          .validate(
              header,
              ContractManagementInformationFileConfigContract.DATA_FILE_KIND_MASK_STRING);
      if (headerErrorMessageList.size() > 0) {
        for (String errorMessage : headerErrorMessageList) {
          errorList
              .add(StringConvertUtil.convertErrorListString(
                  csvFile.getName(),
                  ContractManagementInformationFileConfigCommon.HEADER_START_LINE_NUMBER,
                  errorMessage));
        }
        // 処理を終了する。
        csvResultBean.setUploadFileName(csvFile.getName());
        csvResultBean.setErrorList(errorList);
        csvResultBean.setRegistList(registList);
        csvResultBean.setUpdateList(updateList);
        csvResultBean.setDeleteList(deleteList);
      }

      /* タイトル行チェック */
      // 項目数チェック
      Map<Integer, String> title = csvList
          .get(ContractManagementInformationFileConfigCommon.ROW_NUMBER_TITLE);
      if (ContractManagementInformationFileConfigContract.DATA_COLUMN_COUNT != title
          .size()) {
        // エラーリストへ格納
        errorList
            .add(StringConvertUtil.convertErrorListString(
                csvFile.getName(),
                ContractManagementInformationFileConfigCommon.TITLE_START_LINE_NUMBER,
                messageSource.getMessage("error.E0021", null,
                    Locale.getDefault())));

        // 処理を終了する。
        csvResultBean.setUploadFileName(csvFile.getName());
        csvResultBean.setErrorList(errorList);
        csvResultBean.setRegistList(registList);
        csvResultBean.setUpdateList(updateList);
        csvResultBean.setDeleteList(deleteList);

        return csvResultBean;
      }

      // タイトル内容チェック
      // HashMapだと順番に揃わない可能性があるため、IteratorでKeyを取得
      Iterator<Integer> titleIt = title.keySet().iterator();
      while (titleIt.hasNext()) {
        // タイトルのカラム番号を取得
        Integer columnNo = titleIt.next();
        // タイトル内容を取得
        String titleValue = title.get(columnNo);
        // コンフィグの内容を取得
        String configValue = ContractManagementInformationFileConfigContract.DATA_TITLE_ROW[columnNo
            .intValue()];
        // 一致していない場合、エラー終了
        if (!configValue.equals(titleValue)) {
          errorList
              .add(StringConvertUtil.convertErrorListString(
                  csvFile.getName(),
                  ContractManagementInformationFileConfigCommon.TITLE_START_LINE_NUMBER,
                  messageSource.getMessage("error.E0028",
                      null, Locale.getDefault())));
          csvResultBean.setUploadFileName(csvFile.getName());
          csvResultBean.setErrorList(errorList);
          csvResultBean.setRegistList(registList);
          csvResultBean.setUpdateList(updateList);
          csvResultBean.setDeleteList(deleteList);
          return csvResultBean;
        }
      }

      /* マスタ情報取得 */
      // 契約終了理由コード
      List<ContractEndReasonM> contraceEndReasonMList = contractEndReasonMMapper
          .selectByExample(null);
      Set<String> contractEndReasonMSet = new HashSet<String>();
      // 契約終了理由コードをSetに格納
      for (ContractEndReasonM contractEndReasonM : contraceEndReasonMList) {
        contractEndReasonMSet.add(contractEndReasonM
            .getContractEndReasonCode());
      }

      // 個人・法人区分コード
      List<IlcM> ilcMList = ilcMMapper.selectByExample(null);
      Set<String> ilcMSet = new HashSet<String>();
      // 個人・法人区分コードをSetに格納
      for (IlcM ilcm : ilcMList) {
        ilcMSet.add(ilcm.getIlcCode());
      }

      // 電話番号区分コード
      List<PhoneNoCatM> phoneNoCatMList = phoneNoCatMMapper
          .selectByExample(null);
      Set<String> phoneNoCatMSet = new HashSet<String>();
      // 電話番号区分コードをSetに格納
      for (PhoneNoCatM phoneNoCatM : phoneNoCatMList) {
        phoneNoCatMSet.add(phoneNoCatM.getPhoneNoCatCode());
      }

      // 接続送電サービス区分コード
      List<CssCatM> cssCatMList = cssCatMMapper.selectByExample(null);
      Set<String> cssCatMSet = new HashSet<String>();
      // 接続送電サービス区分コードをSetに格納
      for (CssCatM cssCatM : cssCatMList) {
        cssCatMSet.add(cssCatM.getCssCatCode());
      }

      // 契約容量単位コード
      List<CcaUnitM> ccaUnitMList = ccaUnitMMapper.selectByExample(null);
      Set<String> ccaUnitMSet = new HashSet<String>();
      // 契約容量単位コードをSetに格納
      for (CcaUnitM ccaUnitM : ccaUnitMList) {
        ccaUnitMSet.add(ccaUnitM.getCcaUnitCode());
      }

      /* データレコードチェック */
      // データレコードエラーリスト作製
      List<String> dataRecordErrorList = new ArrayList<String>();

      // データレコードの数だけ処理を行う
      for (int i = ContractManagementInformationFileConfigCommon.ROW_NUMBER_DATA; i < csvList
          .size(); i++) {

        // 出力用行番号設定
        final int outputRowNumber = i + 1;
        // 初期化
        dataRecordErrorList.clear();

        Map<Integer, String> dataRecordMap = csvList.get(i);

        // 項目数チェック
        if (dataRecordMap.size() != ContractManagementInformationFileConfigContract.DATA_COLUMN_COUNT) {
          // エラーリストへ格納
          dataRecordErrorList.add(StringConvertUtil
              .convertErrorListString(csvFile.getName(),
                  outputRowNumber, messageSource.getMessage(
                      "error.E0021", null,
                      Locale.getDefault())));
          errorList.addAll(dataRecordErrorList);

          // 処理を終了する。
          csvResultBean.setUploadFileName(csvFile.getName());
          csvResultBean.setErrorList(errorList);
          csvResultBean.setRegistList(registList);
          csvResultBean.setUpdateList(updateList);
          csvResultBean.setDeleteList(deleteList);

          return csvResultBean;

        }

        // 登録・更新・削除区分
        String reUpDelCategory = dataRecordMap
            .get(ContractManagementInformationFileConfigContract.DATA_REGISTER_UPDATE_DELETE_CATEGORY_INDEX);

        // 登録・更新・削除区分チェック
        if (StringUtils.isEmpty(reUpDelCategory)) {
          // 次の行の処理を行う
          continue;
        }

        // 単項目チェック
        // バリデーションエラーメッセージ用リスト生成
        List<String> validationErrorMessageList = new ArrayList<String>();
        // 登録・更新・削除区分が登録の場合、登録用単項目チェックを行う
        if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER
            .equals(reUpDelCategory)) {
          validationErrorMessageList = contractInformationFileRegistValidator
              .validate(dataRecordMap);
          // 登録・更新・削除区分が更新の場合、更新用単項目チェックを行う
        } else if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_UPDATE
            .equals(reUpDelCategory)) {
          validationErrorMessageList = contractInformationFileUpdateValidator
              .validate(dataRecordMap);
          // 登録・更新・削除区分が削除の場合、削除用単項目チェックを行う
        } else if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_DELETE
            .equals(reUpDelCategory)) {
          validationErrorMessageList = contractInformationFileDeleteValidator
              .validate(dataRecordMap);
          // 一致しない場合は、エラーリストにメッセージを設定
        } else {
          dataRecordErrorList
              .add(StringConvertUtil.convertErrorListString(
                  csvFile.getName(),
                  outputRowNumber,
                  messageSource
                      .getMessage(
                          "validation.range",
                          new String[] {
                              ContractManagementInformationFileConfigContract.DATA_REGISTER_UPDATE_DELETE_CATEGORY_NAME,
                              ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER
                                  + ","
                                  + ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_UPDATE
                                  + ","
                                  + ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_DELETE },
                          Locale.getDefault())));
        }

        // バリデーションエラーメッセージにファイル名と行数を追加し、データレコードエラーリストに追加
        for (String validationErrorMessage : validationErrorMessageList) {
          dataRecordErrorList.add(StringConvertUtil
              .convertErrorListString(csvFile.getName(),
                  outputRowNumber, validationErrorMessage));
        }

        // 契約終了日
        String contractEndDate = dataRecordMap
            .get(ContractManagementInformationFileConfigContract.DATA_CONTRACT_END_DATE_INDEX);
        // 契約終了理由コード
        String contractEndReasonCode = dataRecordMap
            .get(ContractManagementInformationFileConfigContract.DATA_CONTRACT_END_REASON_CODE_INDEX);
        // 託送契約容量単位
        String consigmentContractCapacityUnit = dataRecordMap
            .get(ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_CONTRACT_CAPACITY_UNIT_INDEX);
        // 個人・法人区分コード
        String individualLegalEntityCategoryCode = dataRecordMap
            .get(ContractManagementInformationFileConfigContract.DATA_INDIVIDUAL_LEGAL_ENTITY_CATEGORY_CODE_INDEX);
        // 連絡先電話区分
        String contractInfoCategoryCode = dataRecordMap
            .get(ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_CATEGORY_CODE_INDEX);
        // 接続送電サービス区分コード
        String connectedSupplyCategoryCode = dataRecordMap
            .get(ContractManagementInformationFileConfigContract.DATA_CONNECTED_SUPPLY_SERVICE_CATEGORY_CODE_INDEX);
        // 営業委託先コード
        String salesConsignmentCode = dataRecordMap
            .get(ContractManagementInformationFileConfigContract.DATA_SALES_CONSIGNMENT_CODE_INDEX);
        // 料金メニューID
        String rateMenuId = dataRecordMap
            .get(ContractManagementInformationFileConfigContract.DATA_RATE_MENU_ID_INDEX);
        // 契約開始日
        String contractStartDate = dataRecordMap
            .get(ContractManagementInformationFileConfigContract.DATA_CONTRACT_START_DATE_INDEX);
        // 適用開始日
        String applyStartDate = dataRecordMap
            .get(ContractManagementInformationFileConfigContract.DATA_APPLY_START_DATE_INDEX);

        // 登録・更新・削除区分が登録または更新の場合、以下のチェックを行う。
        if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER
            .equals(reUpDelCategory)
            || ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_UPDATE
                .equals(reUpDelCategory)) {
          // 契約終了日がNULLまたは空文字以外の場合、以下のチェックを行う。
          if (StringUtils.isNotEmpty(contractEndDate)) {
            // 《契約情報ファイル》.契約終了日が9999/12/31の場合、チェックを行う
            if (ECISKJConstants.APPLY_END_DATE_MAX_YYYYMMDD_SLASH
                .equals(contractEndDate)) {
              // 契約終了理由コードが設定されている場合、エラーリストにメッセージを設定
              if (StringUtils.isNotEmpty(contractEndReasonCode)) {
                dataRecordErrorList.add(StringConvertUtil
                    .convertErrorListString(csvFile
                        .getName(), outputRowNumber,
                        messageSource.getMessage(
                            "error.E1436", null,
                            Locale.getDefault())));
              }
              // 《契約情報ファイル》.契約終了日が9999/12/31以外の場合、以下のチェックを行う
            } else {
              // 契約終了理由コードが設定されていない場合、エラーリストにメッセージを設定
              if (StringUtils.isEmpty(contractEndReasonCode)) {
                dataRecordErrorList.add(StringConvertUtil
                    .convertErrorListString(csvFile
                        .getName(), outputRowNumber,
                        messageSource.getMessage(
                            "error.E1028", null,
                            Locale.getDefault())));
                // 契約終了理由コード判定
                // マスタに当該コードが存在しない場合は、エラーリストにメッセージを格納
              } else {
                if (!contractEndReasonMSet
                    .contains(contractEndReasonCode)) {
                  dataRecordErrorList
                      .add(StringConvertUtil.convertErrorListString(
                          csvFile.getName(),
                          outputRowNumber,
                          messageSource
                              .getMessage(
                                  "validation.range",
                                  new String[] {
                                      ContractManagementInformationFileConfigContract.DATA_CONTRACT_END_REASON_CODE_NAME,
                                      StringUtils
                                          .join(contractEndReasonMSet,
                                              ",") },
                                  Locale.getDefault())));
                }
              }
            }
          }
          // 託送契約容量単位がNULLまたは空文字ではない場合、以下のチェックを行う
          if (StringUtils.isNotEmpty(consigmentContractCapacityUnit)) {
            // 託送契約容量単位コード判定
            // マスタに当該コードが存在しない場合は、エラーリストにメッセージを格納
            if (!ccaUnitMSet
                .contains(consigmentContractCapacityUnit)) {
              dataRecordErrorList
                  .add(StringConvertUtil.convertErrorListString(
                      csvFile.getName(),
                      outputRowNumber,
                      messageSource
                          .getMessage(
                              "validation.range",
                              new String[] {
                                  ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_CONTRACT_CAPACITY_UNIT_NAME,
                                  StringUtils
                                      .join(ccaUnitMSet,
                                          ",") },
                              Locale.getDefault())));
            }

          }

          // 連絡先情報入力チェック
          // チェック用Beanに値を設定
          CheckContactInformationUtilBean checkInfoUtilBean = new CheckContactInformationUtilBean();
          // 連絡先個人・法人区分コード
          checkInfoUtilBean
              .setContactInformationinDividualLegalEntityCategoryCode(individualLegalEntityCategoryCode);
          // 連絡先住所（建物・部屋名）
          checkInfoUtilBean
              .setContractInformationAddressBuilding(dataRecordMap
                  .get(ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_ADDRESS_BUILDING_INDEX));
          // 連絡先住所（住所）
          checkInfoUtilBean
              .setContractInformationAddressFull(dataRecordMap
                  .get(ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_ADDRESS_FULL_INDEX));
          // 連絡先住所（郵便番号）
          checkInfoUtilBean
              .setContractInformationAddressPostalCode(dataRecordMap
                  .get(ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_ADDRESS_POSTAL_CODE_INDEX));
          // 連絡先電話（市外局番）
          checkInfoUtilBean
              .setContractInformationAreaCode(dataRecordMap
                  .get(ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_AREA_CODE_INDEX));
          // 連絡先電話区分コード
          checkInfoUtilBean
              .setContractInformationCategoryCode(contractInfoCategoryCode);
          // 連絡先電話（加入者番号）
          checkInfoUtilBean
              .setContractInformationDirectoryNo(dataRecordMap
                  .get(ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_DIRECTORY_NO_INDEX));
          // 連絡先電話（市内局番）
          checkInfoUtilBean
              .setContractInformationLocalNo(dataRecordMap
                  .get(ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_LOCAL_NO_INDEX));
          // 連絡先氏名1
          checkInfoUtilBean
              .setContractInformationName1(dataRecordMap
                  .get(ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_NAME1_INDEX));
          // 連絡先氏名2
          checkInfoUtilBean
              .setContractInformationName2(dataRecordMap
                  .get(ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_NAME2_INDEX));
          // 連絡先氏名（カナ）
          checkInfoUtilBean
              .setContractInformationNameKana(dataRecordMap
                  .get(ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_NAME_KANA_INDEX));

          // チェックを実行し、結果がNGの場合は、エラーリストにメッセージを格納する
          if (!KJ_CommonUtil
              .checkContactInformation(checkInfoUtilBean)) {
            dataRecordErrorList.add(StringConvertUtil
                .convertErrorListString(csvFile.getName(),
                    outputRowNumber, messageSource
                        .getMessage("error.E1010",
                            null,
                            Locale.getDefault())));
          }

          // 個人・法人区分がNULLまたは空文字ではない場合、以下のチェックを行う
          if (StringUtils
              .isNotEmpty(individualLegalEntityCategoryCode)) {
            // 個人・法人区分コード判定
            // マスタに当該コードが存在しない場合は、エラーリストにメッセージを格納
            if (!ilcMSet
                .contains(individualLegalEntityCategoryCode)) {
              dataRecordErrorList
                  .add(StringConvertUtil.convertErrorListString(
                      csvFile.getName(),
                      outputRowNumber,
                      messageSource
                          .getMessage(
                              "validation.range",
                              new String[] {
                                  ContractManagementInformationFileConfigContract.DATA_INDIVIDUAL_LEGAL_ENTITY_CATEGORY_CODE_NAME,
                                  StringUtils
                                      .join(ilcMSet,
                                          ",") },
                              Locale.getDefault())));
            }
          }

          // 連絡先電話区分コードがNULLまたは空文字ではない場合、以下のチェックを行う
          if (StringUtils.isNotEmpty(contractInfoCategoryCode)) {
            // 連絡先電話区分コード判定
            // マスタに当該コードが存在しない場合は、エラーリストにメッセージを格納
            if (!phoneNoCatMSet.contains(contractInfoCategoryCode)) {
              dataRecordErrorList
                  .add(StringConvertUtil.convertErrorListString(
                      csvFile.getName(),
                      outputRowNumber,
                      messageSource
                          .getMessage(
                              "validation.range",
                              new String[] {
                                  ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_CATEGORY_CODE_NAME,
                                  StringUtils
                                      .join(phoneNoCatMSet,
                                          ",") },
                              Locale.getDefault())));
            }
          }

          // 接続送電サービス区分コードがNULLまたは空文字ではない場合、以下のチェックを行う
          if (StringUtils.isNotEmpty(connectedSupplyCategoryCode)) {
            // 接続送電サービスコード判定
            // マスタに当該コードが存在しない場合は、エラーリストにメッセージを格納
            if (!cssCatMSet.contains(connectedSupplyCategoryCode)) {
              dataRecordErrorList
                  .add(StringConvertUtil.convertErrorListString(
                      csvFile.getName(),
                      outputRowNumber,
                      messageSource
                          .getMessage(
                              "validation.range",
                              new String[] {
                                  ContractManagementInformationFileConfigContract.DATA_CONNECTED_SUPPLY_SERVICE_CATEGORY_CODE_NAME,
                                  StringUtils
                                      .join(cssCatMSet,
                                          ",") },
                              Locale.getDefault())));
            }
          }

          // 営業委託先コードがNULLまたは空文字ではない場合、以下のチェックを行う
          if (StringUtils.isNotEmpty(salesConsignmentCode)) {
            // 営業委託先コードの存在チェック
            ScMExample example = new ScMExample();
            example.createCriteria().andScCodeEqualTo(
                salesConsignmentCode);
            int result = scMMapper.countByExample(example);

            // 検索結果が0件の場合、エラーリストにメッセージを格納する
            if (result == 0) {
              dataRecordErrorList
                  .add(StringConvertUtil.convertErrorListString(
                      csvFile.getName(),
                      outputRowNumber,
                      messageSource
                          .getMessage(
                              "validation.regexitem",
                              new String[] {
                                  ContractManagementInformationFileConfigContract.DATA_SALES_CONSIGNMENT_CODE_NAME },
                              Locale.getDefault())));
            }
          }

          // 料金メニューIDがNULLまたは空文字ではない場合、以下のチェックを行う
          if (StringUtils.isNotEmpty(rateMenuId)) {
            // 料金メニューIDの存在チェック
            RmExample example = new RmExample();
            example.createCriteria().andRmIdEqualTo(rateMenuId);
            int result = rmMapper.countByExample(example);

            // 検索結果が0件の場合、エラーリストにメッセージを格納する
            if (result == 0) {
              dataRecordErrorList
                  .add(StringConvertUtil.convertErrorListString(
                      csvFile.getName(),
                      outputRowNumber,
                      messageSource
                          .getMessage(
                              "validation.regexitem",
                              new String[] {
                                  ContractManagementInformationFileConfigContract.DATA_RATE_MENU_ID_NAME },
                              Locale.getDefault())));
            }
          }

          // 連絡先電話文字列長チェック
          StringBuilder contactPhone = new StringBuilder();
          contactPhone
              .append(dataRecordMap
                  .get(ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_AREA_CODE_INDEX));
          contactPhone
              .append(dataRecordMap
                  .get(ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_LOCAL_NO_INDEX));
          contactPhone
              .append(dataRecordMap
                  .get(ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_DIRECTORY_NO_INDEX));
          if (contactPhone.length() > ContractManagementInformationFileConfigContract.PHONE_MAX) {
            dataRecordErrorList.add(StringConvertUtil
                .convertErrorListString(csvFile.getName(),
                    outputRowNumber, messageSource
                        .getMessage("error.E1392",
                            null,
                            Locale.getDefault())));
          }

        }

        // 登録・更新・削除区分が登録の場合、以下のチェックを行う
        if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER
            .equals(reUpDelCategory)) {
          // 契約終了日がNULLまたは空文字ではない場合、以下のチェックを行う
          if (StringUtils.isNotEmpty(contractEndDate)) {
            // 契約終了日が契約開始日より以前ではないかチェックを行う
            boolean result = CommonValidationUtil.checkDateRange(
                contractEndDate, contractStartDate);
            // チェック結果が、契約開始日より以前（同日はエラー）の場合、エラーリストにメッセージを格納
            if (result) {
              dataRecordErrorList.add(StringConvertUtil
                  .convertErrorListString(csvFile.getName(),
                      outputRowNumber,
                      messageSource.getMessage(
                          "error.E1026", null,
                          Locale.getDefault())));
            }
          }
          // 契約終了日がNULLまたは空文字の場合、チェックを行う
          if (StringUtils.isEmpty(contractEndDate)) {
            // 契約終了理由コードが設定されている場合、エラーリストにメッセージを設定
            if (StringUtils.isNotEmpty(contractEndReasonCode)) {
              dataRecordErrorList.add(StringConvertUtil
                  .convertErrorListString(csvFile.getName(),
                      outputRowNumber,
                      messageSource.getMessage(
                          "error.E1436", null,
                          Locale.getDefault())));
            }
          }
        }

        // 登録・更新・削除区分が更新の場合、以下のチェックを行う
        if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_UPDATE
            .equals(reUpDelCategory)) {
          // 契約終了日がNULLまたは空文字ではない場合、以下のチェックを行う
          if (StringUtils.isNotEmpty(contractEndDate)) {
            // 契約終了日が適用開始日より以前ではないかチェックを行う
            boolean result = CommonValidationUtil.checkDateRange(
                contractEndDate, applyStartDate);
            // チェック結果が、適用開始日より以前（同日はエラー）の場合、エラーリストにメッセージを格納
            if (result) {
              dataRecordErrorList.add(StringConvertUtil
                  .convertErrorListString(csvFile.getName(),
                      outputRowNumber,
                      messageSource.getMessage(
                          "error.E1011", null,
                          Locale.getDefault())));
            }
          }
        }

        // エラー出力状況確認
        if (!CollectionUtils.isEmpty(dataRecordErrorList)) {
          errorList.addAll(dataRecordErrorList);
          continue;
        }

        // 行番号情報設定
        dataRecordMap
            .put(Integer
                .valueOf(ContractManagementInformationFileConfigCommon.DATA_ROW_NO_INDEX),
                String.valueOf(outputRowNumber));

        // データレコード振り分け
        if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER
            .equals(reUpDelCategory)) {
          registList.add(dataRecordMap);
        } else if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_UPDATE
            .equals(reUpDelCategory)) {
          updateList.add(dataRecordMap);
        } else if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_DELETE
            .equals(reUpDelCategory)) {
          deleteList.add(dataRecordMap);
        }
      }

      // 返却
      csvResultBean.setUploadFileName(csvFile.getName());
      csvResultBean.setErrorList(errorList);
      csvResultBean.setRegistList(registList);
      csvResultBean.setUpdateList(updateList);
      csvResultBean.setDeleteList(deleteList);

      return csvResultBean;

    } catch (Exception e) {
      throw new SystemException(e.getMessage(), e);
    }

  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.kj.
   * KJ_ContractInformationBusiness #csvFileCheckCustom(jp.co.unisys.enability.cis
   * .business.kj.model.CsvFileCheckContractBusinessBean)
   */
  public CsvFileCheckContractBusinessBean csvFileCheckCustom(
      CsvFileCheckContractBusinessBean csvFileCheckContractBusinessBean) {
    try {
      /* 返却用オブジェクトの生成 */
      CsvFileCheckContractBusinessBean csvResultBean = new CsvFileCheckContractBusinessBean();
      List<String> errorList = new ArrayList<String>();
      List<Map<Integer, String>> registList = new ArrayList<Map<Integer, String>>();
      List<Map<Integer, String>> updateList = new ArrayList<Map<Integer, String>>();
      List<Map<Integer, String>> deleteList = new ArrayList<Map<Integer, String>>();

      /* ファイルオブジェクト取得 */
      File csvFile = csvFileCheckContractBusinessBean.getUploadFile();

      /* ヘッダレコードチェック */
      // アップロードファイルMap生成
      List<Map<Integer, String>> csvList = null;
      csvList = Csv
          .load(csvFile, ECISConstants.ENCODE_TYPE_UTF8,
              ContractManagementInformationFileConfigCommon
                  .getCsvConfig(),
              new ColumnPositionMapListHandler());

      // ファイル構成チェック
      if (ContractManagementInformationFileConfigCommon.UPLOAD_FILE_MINIMUM_LINE_COUNT > csvList
          .size()) {
        // エラーリストへ格納
        errorList.add(StringConvertUtil.convertErrorListString(
            csvFile.getName(),
            null,
            messageSource.getMessage("error.E0028", null,
                Locale.getDefault())));

        // 処理を終了する。
        csvResultBean.setUploadFileName(csvFile.getName());
        csvResultBean.setErrorList(errorList);
        csvResultBean.setRegistList(registList);
        csvResultBean.setUpdateList(updateList);
        csvResultBean.setDeleteList(deleteList);

        return csvResultBean;
      }

      // 項目数チェック
      Map<Integer, String> header = csvList
          .get(ContractManagementInformationFileConfigCommon.ROW_NUMBER_HEADER);
      if (ContractManagementInformationFileConfigCommon.HEADER_COLUMN_COUNT != header
          .size()) {
        // エラーリストへ格納
        errorList
            .add(StringConvertUtil.convertErrorListString(
                csvFile.getName(),
                ContractManagementInformationFileConfigCommon.HEADER_START_LINE_NUMBER,
                messageSource.getMessage("error.E0021", null,
                    Locale.getDefault())));

        // 処理を終了する。
        csvResultBean.setUploadFileName(csvFile.getName());
        csvResultBean.setErrorList(errorList);
        csvResultBean.setRegistList(registList);
        csvResultBean.setUpdateList(updateList);
        csvResultBean.setDeleteList(deleteList);

        return csvResultBean;
      }

      // 単項目チェック
      List<String> headerErrorMessageList = contractManagementInformationFileHeaderValidator
          .validate(
              header,
              Custom_ContractManagementInformationFileConfigContract.DATA_FILE_KIND_MASK_STRING);
      if (headerErrorMessageList.size() > 0) {
        for (String errorMessage : headerErrorMessageList) {
          errorList
              .add(StringConvertUtil.convertErrorListString(
                  csvFile.getName(),
                  ContractManagementInformationFileConfigCommon.HEADER_START_LINE_NUMBER,
                  errorMessage));
        }
        // 処理を終了する。
        csvResultBean.setUploadFileName(csvFile.getName());
        csvResultBean.setErrorList(errorList);
        csvResultBean.setRegistList(registList);
        csvResultBean.setUpdateList(updateList);
        csvResultBean.setDeleteList(deleteList);
      }

      /* タイトル行チェック */
      // 項目数チェック
      Map<Integer, String> title = csvList
          .get(ContractManagementInformationFileConfigCommon.ROW_NUMBER_TITLE);
      if (Custom_ContractManagementInformationFileConfigContract.DATA_COLUMN_COUNT != title
          .size()) {
        // エラーリストへ格納
        errorList
            .add(StringConvertUtil.convertErrorListString(
                csvFile.getName(),
                ContractManagementInformationFileConfigCommon.TITLE_START_LINE_NUMBER,
                messageSource.getMessage("error.E0021", null,
                    Locale.getDefault())));

        // 処理を終了する。
        csvResultBean.setUploadFileName(csvFile.getName());
        csvResultBean.setErrorList(errorList);
        csvResultBean.setRegistList(registList);
        csvResultBean.setUpdateList(updateList);
        csvResultBean.setDeleteList(deleteList);

        return csvResultBean;
      }

      // タイトル内容チェック
      // HashMapだと順番に揃わない可能性があるため、IteratorでKeyを取得
      Iterator<Integer> titleIt = title.keySet().iterator();
      while (titleIt.hasNext()) {
        // タイトルのカラム番号を取得
        Integer columnNo = titleIt.next();
        // タイトル内容を取得
        String titleValue = title.get(columnNo);
        // コンフィグの内容を取得
        String configValue = Custom_ContractManagementInformationFileConfigContract.DATA_TITLE_ROW[columnNo
            .intValue()];
        // 一致していない場合、エラー終了
        if (!configValue.equals(titleValue)) {
          errorList
              .add(StringConvertUtil.convertErrorListString(
                  csvFile.getName(),
                  ContractManagementInformationFileConfigCommon.TITLE_START_LINE_NUMBER,
                  messageSource.getMessage("error.E0028",
                      null, Locale.getDefault())));
          csvResultBean.setUploadFileName(csvFile.getName());
          csvResultBean.setErrorList(errorList);
          csvResultBean.setRegistList(registList);
          csvResultBean.setUpdateList(updateList);
          csvResultBean.setDeleteList(deleteList);
          return csvResultBean;
        }
      }

      /* マスタ情報取得 */
      // 契約終了理由コード
      List<ContractEndReasonM> contraceEndReasonMList = contractEndReasonMMapper
          .selectByExample(null);
      Set<String> contractEndReasonMSet = new HashSet<String>();
      // 契約終了理由コードをSetに格納
      for (ContractEndReasonM contractEndReasonM : contraceEndReasonMList) {
        contractEndReasonMSet.add(contractEndReasonM
            .getContractEndReasonCode());
      }

      // 個人・法人区分コード
      List<IlcM> ilcMList = ilcMMapper.selectByExample(null);
      Set<String> ilcMSet = new HashSet<String>();
      // 個人・法人区分コードをSetに格納
      for (IlcM ilcm : ilcMList) {
        ilcMSet.add(ilcm.getIlcCode());
      }

      // 電話番号区分コード
      List<PhoneNoCatM> phoneNoCatMList = phoneNoCatMMapper
          .selectByExample(null);
      Set<String> phoneNoCatMSet = new HashSet<String>();
      // 電話番号区分コードをSetに格納
      for (PhoneNoCatM phoneNoCatM : phoneNoCatMList) {
        phoneNoCatMSet.add(phoneNoCatM.getPhoneNoCatCode());
      }

      // 接続送電サービス区分コード
      List<CssCatM> cssCatMList = cssCatMMapper.selectByExample(null);
      Set<String> cssCatMSet = new HashSet<String>();
      // 接続送電サービス区分コードをSetに格納
      for (CssCatM cssCatM : cssCatMList) {
        cssCatMSet.add(cssCatM.getCssCatCode());
      }

      // 契約容量単位コード
      List<CcaUnitM> ccaUnitMList = ccaUnitMMapper.selectByExample(null);
      Set<String> ccaUnitMSet = new HashSet<String>();
      // 契約容量単位コードをSetに格納
      for (CcaUnitM ccaUnitM : ccaUnitMList) {
        ccaUnitMSet.add(ccaUnitM.getCcaUnitCode());
      }

      /* データレコードチェック */
      // データレコードエラーリスト作製
      List<String> dataRecordErrorList = new ArrayList<String>();

      // データレコードの数だけ処理を行う
      for (int i = ContractManagementInformationFileConfigCommon.ROW_NUMBER_DATA; i < csvList
          .size(); i++) {

        // 出力用行番号設定
        final int outputRowNumber = i + 1;
        // 初期化
        dataRecordErrorList.clear();

        Map<Integer, String> dataRecordMap = csvList.get(i);

        // 項目数チェック
        if (dataRecordMap.size() != Custom_ContractManagementInformationFileConfigContract.DATA_COLUMN_COUNT) {
          // エラーリストへ格納
          dataRecordErrorList.add(StringConvertUtil
              .convertErrorListString(csvFile.getName(),
                  outputRowNumber, messageSource.getMessage(
                      "error.E0021", null,
                      Locale.getDefault())));
          errorList.addAll(dataRecordErrorList);

          // 処理を終了する。
          csvResultBean.setUploadFileName(csvFile.getName());
          csvResultBean.setErrorList(errorList);
          csvResultBean.setRegistList(registList);
          csvResultBean.setUpdateList(updateList);
          csvResultBean.setDeleteList(deleteList);

          return csvResultBean;

        }

        // 登録・更新・削除区分
        String reUpDelCategory = dataRecordMap
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_REGISTER_UPDATE_DELETE_CATEGORY_INDEX);

        // 登録・更新・削除区分チェック
        if (StringUtils.isEmpty(reUpDelCategory)) {
          // 次の行の処理を行う
          continue;
        }

        // 単項目チェック
        // バリデーションエラーメッセージ用リスト生成
        List<String> validationErrorMessageList = new ArrayList<String>();
        // 登録・更新・削除区分が登録の場合、登録用単項目チェックを行う
        if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER
            .equals(reUpDelCategory)) {
          validationErrorMessageList = customContractInformationFileRegistValidator
              .validate(dataRecordMap);
          // 登録・更新・削除区分が更新の場合、更新用単項目チェックを行う
        } else if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_UPDATE
            .equals(reUpDelCategory)) {
          validationErrorMessageList = customContractInformationFileUpdateValidator
              .validate(dataRecordMap);
          // 登録・更新・削除区分が削除の場合、削除用単項目チェックを行う
        } else if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_DELETE
            .equals(reUpDelCategory)) {
          validationErrorMessageList = customContractInformationFileDeleteValidator
              .validate(dataRecordMap);
          // 一致しない場合は、エラーリストにメッセージを設定
        } else {
          dataRecordErrorList
              .add(StringConvertUtil.convertErrorListString(
                  csvFile.getName(),
                  outputRowNumber,
                  messageSource
                      .getMessage(
                          "validation.range",
                          new String[] {
                              Custom_ContractManagementInformationFileConfigContract.DATA_REGISTER_UPDATE_DELETE_CATEGORY_NAME,
                              ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER
                                  + ","
                                  + ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_UPDATE
                                  + ","
                                  + ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_DELETE },
                          Locale.getDefault())));
        }

        // バリデーションエラーメッセージにファイル名と行数を追加し、データレコードエラーリストに追加
        for (String validationErrorMessage : validationErrorMessageList) {
          dataRecordErrorList.add(StringConvertUtil
              .convertErrorListString(csvFile.getName(),
                  outputRowNumber, validationErrorMessage));
        }

        // 契約終了日
        String contractEndDate = dataRecordMap
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_END_DATE_INDEX);
        // 契約終了理由コード
        String contractEndReasonCode = dataRecordMap
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_END_REASON_CODE_INDEX);
        // 託送契約容量単位
        String consigmentContractCapacityUnit = dataRecordMap
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_CONTRACT_CAPACITY_UNIT_INDEX);
        // 個人・法人区分コード
        String individualLegalEntityCategoryCode = dataRecordMap
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_INDIVIDUAL_LEGAL_ENTITY_CATEGORY_CODE_INDEX);
        // 連絡先電話区分
        String contractInfoCategoryCode = dataRecordMap
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_CATEGORY_CODE_INDEX);
        // 接続送電サービス区分コード
        String connectedSupplyCategoryCode = dataRecordMap
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONNECTED_SUPPLY_SERVICE_CATEGORY_CODE_INDEX);
        // 営業委託先コード
        String salesConsignmentCode = dataRecordMap
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_SALES_CONSIGNMENT_CODE_INDEX);
        // 料金メニューID
        String rateMenuId = dataRecordMap
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_RATE_MENU_ID_INDEX);
        // 電圧区分コード
        String voltageCatCode = dataRecordMap
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_VOLTAGE_CAT_CODE_INDEX);
        // 契約電力決定区分
        String ccDecisionCategoryCode = dataRecordMap
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_CCDECISION_CATEGORY_CODE_INDEX);
        // 契約開始日
        String contractStartDate = dataRecordMap
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_START_DATE_INDEX);
        // 適用開始日
        String applyStartDate = dataRecordMap
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_APPLY_START_DATE_INDEX);
        // 単価設定区分コード
        String upCatCode = dataRecordMap
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_UP_CAT_CODE_INDEX);
        // 業種コード
        String businessTypeCode = dataRecordMap
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_BUSINESS_TYPE_CODE_INDEX);

        // 登録・更新・削除区分が登録または更新の場合、以下のチェックを行う。
        if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER
            .equals(reUpDelCategory)
            || ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_UPDATE
                .equals(reUpDelCategory)) {
          // 契約終了日がNULLまたは空文字以外の場合、以下のチェックを行う。
          if (StringUtils.isNotEmpty(contractEndDate)) {
            // 《契約情報ファイル》.契約終了日が9999/12/31の場合、チェックを行う
            if (ECISKJConstants.APPLY_END_DATE_MAX_YYYYMMDD_SLASH
                .equals(contractEndDate)) {
              // 契約終了理由コードが設定されている場合、エラーリストにメッセージを設定
              if (StringUtils.isNotEmpty(contractEndReasonCode)) {
                dataRecordErrorList.add(StringConvertUtil
                    .convertErrorListString(csvFile
                        .getName(), outputRowNumber,
                        messageSource.getMessage(
                            "error.E1436", null,
                            Locale.getDefault())));
              }
              // 《契約情報ファイル》.契約終了日が9999/12/31以外の場合、以下のチェックを行う
            } else {
              // 契約終了理由コードが設定されていない場合、エラーリストにメッセージを設定
              if (StringUtils.isEmpty(contractEndReasonCode)) {
                dataRecordErrorList.add(StringConvertUtil
                    .convertErrorListString(csvFile
                        .getName(), outputRowNumber,
                        messageSource.getMessage(
                            "error.E1028", null,
                            Locale.getDefault())));
                // 契約終了理由コード判定
                // マスタに当該コードが存在しない場合は、エラーリストにメッセージを格納
              } else {
                if (!contractEndReasonMSet
                    .contains(contractEndReasonCode)) {
                  dataRecordErrorList
                      .add(StringConvertUtil.convertErrorListString(
                          csvFile.getName(),
                          outputRowNumber,
                          messageSource
                              .getMessage(
                                  "validation.range",
                                  new String[] {
                                      Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_END_REASON_CODE_NAME,
                                      StringUtils
                                          .join(contractEndReasonMSet,
                                              ",") },
                                  Locale.getDefault())));
                }
              }
            }
          }
          // 託送契約容量単位がNULLまたは空文字ではない場合、以下のチェックを行う
          if (StringUtils.isNotEmpty(consigmentContractCapacityUnit)) {
            // 託送契約容量単位コード判定
            // マスタに当該コードが存在しない場合は、エラーリストにメッセージを格納
            if (!ccaUnitMSet
                .contains(consigmentContractCapacityUnit)) {
              dataRecordErrorList
                  .add(StringConvertUtil.convertErrorListString(
                      csvFile.getName(),
                      outputRowNumber,
                      messageSource
                          .getMessage(
                              "validation.range",
                              new String[] {
                                  Custom_ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_CONTRACT_CAPACITY_UNIT_NAME,
                                  StringUtils
                                      .join(ccaUnitMSet,
                                          ",") },
                              Locale.getDefault())));
            }

          }

          // 連絡先情報入力チェック
          // チェック用Beanに値を設定
          CheckContactInformationUtilBean checkInfoUtilBean = new CheckContactInformationUtilBean();
          // 連絡先個人・法人区分コード
          checkInfoUtilBean
              .setContactInformationinDividualLegalEntityCategoryCode(individualLegalEntityCategoryCode);
          // 連絡先住所（建物・部屋名）
          checkInfoUtilBean
              .setContractInformationAddressBuilding(dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_ADDRESS_BUILDING_INDEX));
          // 連絡先住所（住所）
          checkInfoUtilBean
              .setContractInformationAddressFull(dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_ADDRESS_FULL_INDEX));
          // 連絡先住所（郵便番号）
          checkInfoUtilBean
              .setContractInformationAddressPostalCode(dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_ADDRESS_POSTAL_CODE_INDEX));
          // 連絡先電話（市外局番）
          checkInfoUtilBean
              .setContractInformationAreaCode(dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_AREA_CODE_INDEX));
          // 連絡先電話区分コード
          checkInfoUtilBean
              .setContractInformationCategoryCode(contractInfoCategoryCode);
          // 連絡先電話（加入者番号）
          checkInfoUtilBean
              .setContractInformationDirectoryNo(dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_DIRECTORY_NO_INDEX));
          // 連絡先電話（市内局番）
          checkInfoUtilBean
              .setContractInformationLocalNo(dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_LOCAL_NO_INDEX));
          // 連絡先氏名1
          checkInfoUtilBean
              .setContractInformationName1(dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_NAME1_INDEX));
          // 連絡先氏名2
          checkInfoUtilBean
              .setContractInformationName2(dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_NAME2_INDEX));
          // 連絡先氏名（カナ）
          checkInfoUtilBean
              .setContractInformationNameKana(dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_NAME_KANA_INDEX));

          // チェックを実行し、結果がNGの場合は、エラーリストにメッセージを格納する
          if (!KJ_CommonUtil
              .checkContactInformation(checkInfoUtilBean)) {
            dataRecordErrorList.add(StringConvertUtil
                .convertErrorListString(csvFile.getName(),
                    outputRowNumber, messageSource
                        .getMessage("error.E1010",
                            null,
                            Locale.getDefault())));
          }

          // 個人・法人区分がNULLまたは空文字ではない場合、以下のチェックを行う
          if (StringUtils
              .isNotEmpty(individualLegalEntityCategoryCode)) {
            // 個人・法人区分コード判定
            // マスタに当該コードが存在しない場合は、エラーリストにメッセージを格納
            if (!ilcMSet
                .contains(individualLegalEntityCategoryCode)) {
              dataRecordErrorList
                  .add(StringConvertUtil.convertErrorListString(
                      csvFile.getName(),
                      outputRowNumber,
                      messageSource
                          .getMessage(
                              "validation.range",
                              new String[] {
                                  Custom_ContractManagementInformationFileConfigContract.DATA_INDIVIDUAL_LEGAL_ENTITY_CATEGORY_CODE_NAME,
                                  StringUtils
                                      .join(ilcMSet,
                                          ",") },
                              Locale.getDefault())));
            }
          }

          // 連絡先電話区分コードがNULLまたは空文字ではない場合、以下のチェックを行う
          if (StringUtils.isNotEmpty(contractInfoCategoryCode)) {
            // 連絡先電話区分コード判定
            // マスタに当該コードが存在しない場合は、エラーリストにメッセージを格納
            if (!phoneNoCatMSet.contains(contractInfoCategoryCode)) {
              dataRecordErrorList
                  .add(StringConvertUtil.convertErrorListString(
                      csvFile.getName(),
                      outputRowNumber,
                      messageSource
                          .getMessage(
                              "validation.range",
                              new String[] {
                                  Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_CATEGORY_CODE_NAME,
                                  StringUtils
                                      .join(phoneNoCatMSet,
                                          ",") },
                              Locale.getDefault())));
            }
          }

          // 接続送電サービス区分コードがNULLまたは空文字ではない場合、以下のチェックを行う
          if (StringUtils.isNotEmpty(connectedSupplyCategoryCode)) {
            // 接続送電サービスコード判定
            // マスタに当該コードが存在しない場合は、エラーリストにメッセージを格納
            if (!cssCatMSet.contains(connectedSupplyCategoryCode)) {
              dataRecordErrorList
                  .add(StringConvertUtil.convertErrorListString(
                      csvFile.getName(),
                      outputRowNumber,
                      messageSource
                          .getMessage(
                              "validation.range",
                              new String[] {
                                  Custom_ContractManagementInformationFileConfigContract.DATA_CONNECTED_SUPPLY_SERVICE_CATEGORY_CODE_NAME,
                                  StringUtils
                                      .join(cssCatMSet,
                                          ",") },
                              Locale.getDefault())));
            }
          }

          // 営業委託先コードがNULLまたは空文字ではない場合、以下のチェックを行う
          if (StringUtils.isNotEmpty(salesConsignmentCode)) {
            // 営業委託先コードの存在チェック
            ScMExample example = new ScMExample();
            example.createCriteria().andScCodeEqualTo(
                salesConsignmentCode);
            int result = scMMapper.countByExample(example);

            // 検索結果が0件の場合、エラーリストにメッセージを格納する
            if (result == 0) {
              dataRecordErrorList
                  .add(StringConvertUtil.convertErrorListString(
                      csvFile.getName(),
                      outputRowNumber,
                      messageSource
                          .getMessage(
                              "validation.regexitem",
                              new String[] {
                                  Custom_ContractManagementInformationFileConfigContract.DATA_SALES_CONSIGNMENT_CODE_NAME },
                              Locale.getDefault())));
            }
          }

          // 料金メニューIDがNULLまたは空文字ではない場合、以下のチェックを行う
          if (StringUtils.isNotEmpty(rateMenuId)) {
            // 料金メニューIDの存在チェック
            RmExample example = new RmExample();
            example.createCriteria().andRmIdEqualTo(rateMenuId);
            int result = rmMapper.countByExample(example);

            // 検索結果が0件の場合、エラーリストにメッセージを格納する
            if (result == 0) {
              dataRecordErrorList
                  .add(StringConvertUtil.convertErrorListString(
                      csvFile.getName(),
                      outputRowNumber,
                      messageSource
                          .getMessage(
                              "validation.regexitem",
                              new String[] {
                                  Custom_ContractManagementInformationFileConfigContract.DATA_RATE_MENU_ID_NAME },
                              Locale.getDefault())));
            }
          }

          // 連絡先電話文字列長チェック
          StringBuilder contactPhone = new StringBuilder();
          contactPhone
              .append(dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_AREA_CODE_INDEX));
          contactPhone
              .append(dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_LOCAL_NO_INDEX));
          contactPhone
              .append(dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_DIRECTORY_NO_INDEX));
          if (contactPhone.length() > Custom_ContractManagementInformationFileConfigContract.PHONE_MAX) {
            dataRecordErrorList.add(StringConvertUtil
                .convertErrorListString(csvFile.getName(),
                    outputRowNumber, messageSource
                        .getMessage("error.E1392",
                            null,
                            Locale.getDefault())));
          }

          // 業種コードがNULLまたは空文字ではない場合、以下のチェックを行う
          if (StringUtils.isNotEmpty(businessTypeCode)) {
            // 業種コードの存在チェック
            BusinessMExample businessMExample = new BusinessMExample();
            businessMExample.createCriteria().andBusinessTypeCodeEqualTo(businessTypeCode);
            int result = businessMMapper.countByExample(businessMExample);
            // 検索結果が0件の場合、エラーリストにメッセージを格納する
            if (result == 0) {
              dataRecordErrorList
                  .add(StringConvertUtil.convertErrorListString(
                      csvFile.getName(),
                      outputRowNumber,
                      messageSource
                          .getMessage(
                              "validation.regexitem",
                              new String[] {
                                  Custom_ContractManagementInformationFileConfigContract.DATA_BUSINESS_TYPE_CODE_NAME },
                              Locale.getDefault())));
            }
          }
        }

        // 電圧区分コードがNULLまたは空文字ではない場合、以下のチェックを行う
        if (StringUtils.isNotEmpty(voltageCatCode)) {
          // 電圧区分コードの存在チェック
          VoltageCatMExample voltageCatMExample = new VoltageCatMExample();
          voltageCatMExample.createCriteria().andVoltageCatCodeEqualTo(voltageCatCode);
          int result = voltageCatMMapper.countByExample(voltageCatMExample);
          // 検索結果が0件の場合、エラーリストにメッセージを格納する
          if (result == 0) {
            dataRecordErrorList
                .add(StringConvertUtil.convertErrorListString(
                    csvFile.getName(),
                    outputRowNumber,
                    messageSource
                        .getMessage(
                            "validation.regexitem",
                            new String[] {"電圧区分コード" },
                            Locale.getDefault())));
          }
        }

        //設備IDがNULLまたは空文字ではない場合、以下のチェックを行う
        String free9 = dataRecordMap
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_FREE9_INDEX);
        if (StringUtils.isNotEmpty(free9)) {
          Integer meterLocationId = Integer.valueOf(dataRecordMap
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_METER_LOCATION_ID_INDEX));
          MlExample mlExample = new MlExample();
          mlExample.createCriteria().andMlIdEqualTo(meterLocationId)
              .andTransmissionCatCodeEqualTo(ECISCodeConstants.TRANSMISSION_CATEGORY_CODE_RECEIVING);
          int result = mlMapper.countByExample(mlExample);
          //検索結果が0件の場合（送電の場合）、エラーリストにメッセージを格納する
          if (result == 0) {
            dataRecordErrorList
                .add(StringConvertUtil.convertErrorListString(
                    csvFile.getName(),
                    outputRowNumber,
                    messageSource
                        .getMessage(
                            "validationb.illegalrelate",
                            new String[] {"送受電区分", "設備ID" },
                            Locale.getDefault())));
          } else if (!StringUtils.isAlphanumeric(free9)) {
            dataRecordErrorList
                .add(StringConvertUtil.convertErrorListString(
                    csvFile.getName(),
                    outputRowNumber,
                    messageSource
                        .getMessage(
                            "validation.alphanumeric",
                            new String[] {"設備ID" },
                            Locale.getDefault())));
          } else if (free9.length() != 10) {
            dataRecordErrorList
                .add(StringConvertUtil.convertErrorListString(
                    csvFile.getName(),
                    outputRowNumber,
                    messageSource
                        .getMessage(
                            "validation.stringlength",
                            new String[] {"設備ID", "10" },
                            Locale.getDefault())));
          }
        }

        // 契約電力決定区分コードがNULLまたは空文字ではない場合、以下のチェックを行う
        if (StringUtils.isNotEmpty(ccDecisionCategoryCode)) {
          // 電圧区分コードの存在チェック
          CcdCategoryMExample ccdCategoryMExample = new CcdCategoryMExample();
          ccdCategoryMExample.createCriteria().andCcDecisionCategoryCodeEqualTo(ccDecisionCategoryCode);
          int result = ccdCategoryMMapper.countByExample(ccdCategoryMExample);
          // 検索結果が0件の場合、エラーリストにメッセージを格納する
          if (result == 0) {
            dataRecordErrorList
                .add(StringConvertUtil.convertErrorListString(
                    csvFile.getName(),
                    outputRowNumber,
                    messageSource
                        .getMessage(
                            "validation.regexitem",
                            new String[] {"契約電力決定区分コード" },
                            Locale.getDefault())));
          }
        }

        // 料金メニューID、電圧区分コード、契約電力決定区分コードの相関チェック
        Map<String, Object> upExampleMap = new HashMap<String, Object>();
        if (StringUtils.isNotEmpty(voltageCatCode)) {
          // 料金メニューID
          upExampleMap.put("rmId", rateMenuId);
          // 電力区分コード
          upExampleMap.put("voltageCatCode", voltageCatCode);
          // 契約電力決定区分が”実量制”の場合
          if (ECISCodeConstants.CONTRACT_CAPACITY_DECISION_CATEGORY_CODE_REALQUANTITY.equals(
              ccDecisionCategoryCode)) {
            // 電灯電力コード
            upExampleMap.put("elLightAndPowerCatCode",
                ECISCodeConstants.ELECTRIC_LIGHT_AND_POWER_CATEGORY_CODE_POWER);
          }
          int returnCount = agentContractInformationCommonMapper.selectCountRm(upExampleMap);
          // 検索結果が0件の場合、エラーリストにメッセージを格納する
          if (returnCount == 0) {
            dataRecordErrorList
                .add(StringConvertUtil.convertErrorListString(
                    csvFile.getName(),
                    outputRowNumber,
                    messageSource
                        .getMessage(
                            "validationb.illegalrelate3item",
                            new String[] {
                                "料金メニューID",
                                "電圧区分コード",
                                "契約電力決定区分コード"
                            },
                            Locale.getDefault())));
          }

          if (ECISCodeConstants.CUSTOM_VOLTAGE_CAT_CODE_LOW_TENSION.equals(voltageCatCode)
              && ECISCodeConstants.CONTRACT_CAPACITY_DECISION_CATEGORY_CODE_REALQUANTITY.equals(ccDecisionCategoryCode)) {
            // 電圧区分が”低圧” かつ 契約電力決定区分が”実量制”の場合、エラーリストにメッセージを格納する
            dataRecordErrorList.add(StringConvertUtil.convertErrorListString(csvFile.getName(), outputRowNumber,
                messageSource.getMessage("error.E1829", null, Locale.getDefault())));
          }
        }
        // 登録・更新・削除区分が登録の場合、以下のチェックを行う
        if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER
            .equals(reUpDelCategory)) {
          // 契約終了日がNULLまたは空文字ではない場合、以下のチェックを行う
          if (StringUtils.isNotEmpty(contractEndDate)) {
            // 契約終了日が契約開始日より以前ではないかチェックを行う
            boolean result = CommonValidationUtil.checkDateRange(
                contractEndDate, contractStartDate);
            // チェック結果が、契約開始日より以前（同日はエラー）の場合、エラーリストにメッセージを格納
            if (result) {
              dataRecordErrorList.add(StringConvertUtil
                  .convertErrorListString(csvFile.getName(),
                      outputRowNumber,
                      messageSource.getMessage(
                          "error.E1026", null,
                          Locale.getDefault())));
            }
          }
          // 契約終了日がNULLまたは空文字の場合、チェックを行う
          if (StringUtils.isEmpty(contractEndDate)) {
            // 契約終了理由コードが設定されている場合、エラーリストにメッセージを設定
            if (StringUtils.isNotEmpty(contractEndReasonCode)) {
              dataRecordErrorList.add(StringConvertUtil
                  .convertErrorListString(csvFile.getName(),
                      outputRowNumber,
                      messageSource.getMessage(
                          "error.E1436", null,
                          Locale.getDefault())));
            }
          }
        }

        // 登録・更新・削除区分が更新の場合、以下のチェックを行う
        if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_UPDATE
            .equals(reUpDelCategory)) {
          // 契約終了日がNULLまたは空文字ではない場合、以下のチェックを行う
          if (StringUtils.isNotEmpty(contractEndDate)) {
            // 契約終了日が適用開始日より以前ではないかチェックを行う
            boolean result = CommonValidationUtil.checkDateRange(
                contractEndDate, applyStartDate);
            // チェック結果が、適用開始日より以前（同日はエラー）の場合、エラーリストにメッセージを格納
            if (result) {
              dataRecordErrorList.add(StringConvertUtil
                  .convertErrorListString(csvFile.getName(),
                      outputRowNumber,
                      messageSource.getMessage(
                          "error.E1011", null,
                          Locale.getDefault())));
            }
          }
        }

        // 登録・更新・削除区分が登録または更新の場合、以下のチェックを行う。
        if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER
            .equals(reUpDelCategory)
            || ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_UPDATE
                .equals(reUpDelCategory)) {

          // 単価設定区分のチェック及び、単価明細のチェック
          // 単価設定区分がNULLまたは空文字ではない場合、以下のチェックを行う
          if (StringUtils.isNotEmpty(upCatCode)) {

            UpsCategoryM upsCategoryM = upsCategoryMMapper.selectByPrimaryKey(upCatCode);
            // 検索結果が0件の場合
            if (upsCategoryM == null) {
              dataRecordErrorList
                  .add(StringConvertUtil.convertErrorListString(
                      csvFile.getName(),
                      outputRowNumber,
                      messageSource
                          .getMessage(
                              "validation.regexitem",
                              new String[] {"単価設定区分コード" },
                              Locale.getDefault())));
            }
            // 単価設定区分コードが定数.「単価設定区分コード:個別設定」の場合以下のチェックを行う
            if (ECISConstants.UNIT_PRICE_SETTING_CATEGORY_INDIV.equals(upCatCode)) {
              List<CsvFileCheckRmUpDetailBean> rmUpdetailList = new ArrayList<CsvFileCheckRmUpDetailBean>();
              String dcecCatCode1 = dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE1_INDEX);
              String tsCode1 = dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE1_INDEX);
              String branchNo1 = dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO1_INDEX);
              if (StringUtils.isNotEmpty(dcecCatCode1)) {
                CsvFileCheckRmUpDetailBean rmUpDetail1 = new CsvFileCheckRmUpDetailBean();
                // DCEC区分コード1
                rmUpDetail1.setDcecCatCode(dcecCatCode1);
                // 時間帯コード1
                rmUpDetail1.setTsCode(tsCode1);
                // 枝番1
                rmUpDetail1.setBranchNo(branchNo1);
                rmUpdetailList.add(rmUpDetail1);
              }
              String dcecCatCode2 = dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE2_INDEX);
              String tsCode2 = dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE2_INDEX);
              String branchNo2 = dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO2_INDEX);
              if (StringUtils.isNotEmpty(dcecCatCode2)) {
                CsvFileCheckRmUpDetailBean rmUpDetail2 = new CsvFileCheckRmUpDetailBean();
                // DCEC区分コード2
                rmUpDetail2.setDcecCatCode(dcecCatCode2);
                // 時間帯コード2
                rmUpDetail2.setTsCode(tsCode2);
                // 枝番2
                rmUpDetail2.setBranchNo(branchNo2);
                rmUpdetailList.add(rmUpDetail2);
              }

              String dcecCatCode3 = dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE3_INDEX);
              String tsCode3 = dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE3_INDEX);
              String branchNo3 = dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO3_INDEX);
              if (StringUtils.isNotEmpty(dcecCatCode3)) {
                CsvFileCheckRmUpDetailBean rmUpDetail3 = new CsvFileCheckRmUpDetailBean();
                // DCEC区分コード3
                rmUpDetail3.setDcecCatCode(dcecCatCode3);
                // 時間帯コード3
                rmUpDetail3.setTsCode(tsCode3);
                // 枝番3
                rmUpDetail3.setBranchNo(branchNo3);
                rmUpdetailList.add(rmUpDetail3);
              }
              String dcecCatCode4 = dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE4_INDEX);
              String tsCode4 = dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE4_INDEX);
              String branchNo4 = dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO4_INDEX);
              if (StringUtils.isNotEmpty(dcecCatCode4)) {
                CsvFileCheckRmUpDetailBean rmUpDetail4 = new CsvFileCheckRmUpDetailBean();
                // DCEC区分コード4
                rmUpDetail4.setDcecCatCode(dcecCatCode4);
                // 時間帯コード4
                rmUpDetail4.setTsCode(tsCode4);
                // 枝番4
                rmUpDetail4.setBranchNo(branchNo4);
                rmUpdetailList.add(rmUpDetail4);
              }
              String dcecCatCode5 = dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE5_INDEX);
              String tsCode5 = dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE5_INDEX);
              String branchNo5 = dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO5_INDEX);
              if (StringUtils.isNotEmpty(dcecCatCode5)) {
                CsvFileCheckRmUpDetailBean rmUpDetail5 = new CsvFileCheckRmUpDetailBean();
                // DCEC区分コード5
                rmUpDetail5.setDcecCatCode(dcecCatCode5);
                // 時間帯コード5
                rmUpDetail5.setTsCode(tsCode5);
                // 枝番5
                rmUpDetail5.setBranchNo(branchNo5);
                rmUpdetailList.add(rmUpDetail5);
              }
              String dcecCatCode6 = dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE6_INDEX);
              String tsCode6 = dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE6_INDEX);
              String branchNo6 = dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO6_INDEX);
              if (StringUtils.isNotEmpty(dcecCatCode6)) {
                CsvFileCheckRmUpDetailBean rmUpDetail6 = new CsvFileCheckRmUpDetailBean();
                // DCEC区分コード6
                rmUpDetail6.setDcecCatCode(dcecCatCode6);
                // 時間帯コード6
                rmUpDetail6.setTsCode(tsCode6);
                // 枝番6
                rmUpDetail6.setBranchNo(branchNo6);
                rmUpdetailList.add(rmUpDetail6);
              }

              String dcecCatCode7 = dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE7_INDEX);
              String tsCode7 = dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE7_INDEX);
              String branchNo7 = dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO7_INDEX);
              if (StringUtils.isNotEmpty(dcecCatCode7)) {
                CsvFileCheckRmUpDetailBean rmUpDetail7 = new CsvFileCheckRmUpDetailBean();
                // DCEC区分コード7
                rmUpDetail7.setDcecCatCode(dcecCatCode7);
                // 時間帯コード7
                rmUpDetail7.setTsCode(tsCode7);
                // 枝番7
                rmUpDetail7.setBranchNo(branchNo7);
                rmUpdetailList.add(rmUpDetail7);
              }
              String dcecCatCode8 = dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE8_INDEX);
              String tsCode8 = dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE8_INDEX);
              String branchNo8 = dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO8_INDEX);
              if (StringUtils.isNotEmpty(dcecCatCode8)) {
                CsvFileCheckRmUpDetailBean rmUpDetail8 = new CsvFileCheckRmUpDetailBean();
                // DCEC区分コード8
                rmUpDetail8.setDcecCatCode(dcecCatCode8);
                // 時間帯コード8
                rmUpDetail8.setTsCode(tsCode8);
                // 枝番8
                rmUpDetail8.setBranchNo(branchNo8);
                rmUpdetailList.add(rmUpDetail8);
              }

              String dcecCatCode9 = dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE9_INDEX);
              String tsCode9 = dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE9_INDEX);
              String branchNo9 = dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO9_INDEX);
              if (StringUtils.isNotEmpty(dcecCatCode9)) {
                CsvFileCheckRmUpDetailBean rmUpDetail9 = new CsvFileCheckRmUpDetailBean();
                // DCEC区分コード9
                rmUpDetail9.setDcecCatCode(dcecCatCode9);
                // 時間帯コード9
                rmUpDetail9.setTsCode(tsCode9);
                // 枝番9
                rmUpDetail9.setBranchNo(branchNo9);
                rmUpdetailList.add(rmUpDetail9);
              }

              String dcecCatCode10 = dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE10_INDEX);
              String tsCode10 = dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE10_INDEX);
              String branchNo10 = dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO10_INDEX);
              if (StringUtils.isNotEmpty(dcecCatCode10)) {
                CsvFileCheckRmUpDetailBean rmUpDetail10 = new CsvFileCheckRmUpDetailBean();
                // DCEC区分コード10
                rmUpDetail10.setDcecCatCode(dcecCatCode10);
                // 時間帯コード10
                rmUpDetail10.setTsCode(tsCode10);
                // 枝番10
                rmUpDetail10.setBranchNo(branchNo10);
                rmUpdetailList.add(rmUpDetail10);
              }

              String dcecCatCode11 = dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE11_INDEX);
              String tsCode11 = dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE11_INDEX);
              String branchNo11 = dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO11_INDEX);
              if (StringUtils.isNotEmpty(dcecCatCode11)) {
                CsvFileCheckRmUpDetailBean rmUpDetail11 = new CsvFileCheckRmUpDetailBean();
                // DCEC区分コード11
                rmUpDetail11.setDcecCatCode(dcecCatCode11);
                // 時間帯コード11
                rmUpDetail11.setTsCode(tsCode11);
                // 枝番11
                rmUpDetail11.setBranchNo(branchNo11);
                rmUpdetailList.add(rmUpDetail11);
              }

              String dcecCatCode12 = dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE12_INDEX);
              String tsCode12 = dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE12_INDEX);
              String branchNo12 = dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO12_INDEX);
              if (StringUtils.isNotEmpty(dcecCatCode12)) {
                CsvFileCheckRmUpDetailBean rmUpDetail12 = new CsvFileCheckRmUpDetailBean();
                // DCEC区分コード12
                rmUpDetail12.setDcecCatCode(dcecCatCode12);
                // 時間帯コード12
                rmUpDetail12.setTsCode(tsCode12);
                // 枝番12
                rmUpDetail12.setBranchNo(branchNo12);
                rmUpdetailList.add(rmUpDetail12);
              }

              String dcecCatCode13 = dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE13_INDEX);
              String tsCode13 = dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE13_INDEX);
              String branchNo13 = dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO13_INDEX);
              if (StringUtils.isNotEmpty(dcecCatCode13)) {
                CsvFileCheckRmUpDetailBean rmUpDetail13 = new CsvFileCheckRmUpDetailBean();
                // DCEC区分コード13
                rmUpDetail13.setDcecCatCode(dcecCatCode13);
                // 時間帯コード13
                rmUpDetail13.setTsCode(tsCode13);
                // 枝番13
                rmUpDetail13.setBranchNo(branchNo13);
                rmUpdetailList.add(rmUpDetail13);
              }

              String dcecCatCode14 = dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE14_INDEX);
              String tsCode14 = dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE14_INDEX);
              String branchNo14 = dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO14_INDEX);
              if (StringUtils.isNotEmpty(dcecCatCode14)) {
                CsvFileCheckRmUpDetailBean rmUpDetail14 = new CsvFileCheckRmUpDetailBean();
                // DCEC区分コード14
                rmUpDetail14.setDcecCatCode(dcecCatCode14);
                // 時間帯コード14
                rmUpDetail14.setTsCode(tsCode14);
                // 枝番14
                rmUpDetail14.setBranchNo(branchNo14);
                rmUpdetailList.add(rmUpDetail14);
              }

              String dcecCatCode15 = dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE15_INDEX);
              String tsCode15 = dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE15_INDEX);
              String branchNo15 = dataRecordMap
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO15_INDEX);
              if (StringUtils.isNotEmpty(dcecCatCode15)) {
                CsvFileCheckRmUpDetailBean rmUpDetail15 = new CsvFileCheckRmUpDetailBean();
                // DCEC区分コード15
                rmUpDetail15.setDcecCatCode(dcecCatCode15);
                // 時間帯コード15
                rmUpDetail15.setTsCode(tsCode15);
                // 枝番15
                rmUpDetail15.setBranchNo(branchNo15);
                rmUpdetailList.add(rmUpDetail15);
              }

              if (rmUpdetailList.size() == 0) {
                dataRecordErrorList
                    .add(StringConvertUtil.convertErrorListString(
                        csvFile.getName(),
                        outputRowNumber,
                        messageSource
                            .getMessage(
                                "validation.regexitem",
                                new String[] {"DCEC区分コード" },
                                Locale.getDefault())));
              }

              Map<String, Object> upcatParam = new HashMap<String, Object>();

              Date applySD;
              if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER
                  .equals(reUpDelCategory)) {
                applySD = StringConvertUtil
                    .stringToDate(
                        contractStartDate,
                        EMSConstants.FORMAT_DATE_yyyyMMdd_SLASH);
              } else {
                applySD = StringConvertUtil
                    .stringToDate(
                        applyStartDate,
                        EMSConstants.FORMAT_DATE_yyyyMMdd_SLASH);
              }

              // 料金メニュー単価明細Exampleを生成
              upcatParam.put("rateMenuId", rateMenuId);
              upcatParam.put("unitPriceCategoryCode", ECISConstants.UNIT_PRICE_SETTING_CATEGORY_DEF);
              upcatParam.put("upApplySd", applySD);
              upcatParam.put("upApplyEd", applySD);
              int index = 0;
              // 料金メニュー単価明細リストの件数分繰り返し処理を行う。
              for (CsvFileCheckRmUpDetailBean upcatmap : rmUpdetailList) {
                index++;
                int returnCountRmupdetail = 0;
                if (stringToShort(upcatmap.getBranchNo()) != null) {
                  upcatParam.put("dcecCatCode", upcatmap.getDcecCatCode());
                  upcatParam.put("tsCode", upcatmap.getTsCode());
                  upcatParam.put("branchNo", stringToShort(upcatmap.getBranchNo()));
                  // 料金メニュー単価明細.検索（主キー）を呼び出し
                  returnCountRmupdetail = agentContractInformationCommonMapper
                      .selectCountRmUpDetail(upcatParam);
                }

                // 返却値が0件の場合、
                if (returnCountRmupdetail == 0) {
                  dataRecordErrorList
                      .add(StringConvertUtil.convertErrorListString(
                          csvFile.getName(),
                          outputRowNumber,
                          messageSource
                              .getMessage(
                                  "validationb.illegalrelate3item",
                                  new String[] {
                                      "DCEC区分コード"
                                          + fullDigitalMap
                                              .get(String.valueOf(index))
                                          + "：" + upcatmap.getDcecCatCode(),
                                      "時間帯コード" + fullDigitalMap
                                          .get(String.valueOf(index))
                                          + "：" + upcatmap.getTsCode(),
                                      "枝番" + fullDigitalMap
                                          .get(String.valueOf(index)) + "："
                                          + upcatmap.getBranchNo() },
                                  Locale.getDefault())));
                }
              }
            }
          }
        }

        // 予備契約情報のチェック
        // 予備線登録・変更・削除区分
        String reserveLineRegisterUpdateDelete = dataRecordMap.get(
            Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_LINE_REGISTER_UPDATE_DELETE_INDEX);
        Boolean errorFlag = false;

        // 範囲チェック
        if (!(ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER.equals(reserveLineRegisterUpdateDelete)
            || ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_UPDATE
                .equals(reserveLineRegisterUpdateDelete)
            || ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_DELETE
                .equals(reserveLineRegisterUpdateDelete)
            || StringUtils.isEmpty(reserveLineRegisterUpdateDelete))) {
          dataRecordErrorList.add(StringConvertUtil.convertErrorListString(
              csvFile.getName(),
              outputRowNumber,
              messageSource.getMessage(
                  "validation.range",
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_LINE_REGISTER_UPDATE_DELETE_NAME,
                      ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER + ","
                          + ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_UPDATE + ","
                          + ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_DELETE },
                  Locale.getDefault())));
        }
        // 登録時相関チェック
        if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER.equals(reUpDelCategory)) {
          if (!(ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER.equals(
              reserveLineRegisterUpdateDelete)
              || StringUtils.isEmpty(reserveLineRegisterUpdateDelete))) {
            dataRecordErrorList.add(StringConvertUtil.convertErrorListString(
                csvFile.getName(),
                outputRowNumber,
                messageSource.getMessage(
                    "error.E1637",
                    new String[] {"登録", ECISKJConstants.RESERVE_CONTRACT_CLASS_NAME_LINE },
                    Locale.getDefault())));
          }
        }
        // 削除時相関チェック
        if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_DELETE.equals(reUpDelCategory)) {
          if (!(ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_DELETE.equals(
              reserveLineRegisterUpdateDelete)
              || StringUtils.isEmpty(reserveLineRegisterUpdateDelete))) {
            dataRecordErrorList.add(
                StringConvertUtil.convertErrorListString(
                    csvFile.getName(),
                    outputRowNumber,
                    messageSource.getMessage(
                        "error.E1637",
                        new String[] {"削除", ECISKJConstants.RESERVE_CONTRACT_CLASS_NAME_LINE },
                        Locale.getDefault())));
          }
        }

        // 予備線契約開始日
        errorFlag = false;
        String reserveLineStartDate = dataRecordMap.get(
            Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_LINE_CONTRACT_START_DATE_INDEX);
        // 必須チェック
        if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER.equals(reserveLineRegisterUpdateDelete)
            || ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_DELETE
                .equals(reserveLineRegisterUpdateDelete)) {
          if (StringUtils.isEmpty(reserveLineStartDate)) {
            dataRecordErrorList.add(
                StringConvertUtil.convertErrorListString(
                    csvFile.getName(),
                    outputRowNumber,
                    messageSource.getMessage(
                        "validation.requiredstring",
                        new String[] {
                            Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_LINE_CONTRACT_START_DATE_NAME },
                        Locale.getDefault())));
            errorFlag = true;
          }
        }
        // 予備線契約終了日との相関チェック
        String reserveLineEndDate = dataRecordMap.get(
            Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_LINE_CONTRACT_END_DATE_INDEX);
        if (errorFlag == false
            && (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER
                .equals(reserveLineRegisterUpdateDelete)
                || ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_UPDATE
                    .equals(reserveLineRegisterUpdateDelete))) {
          if (StringUtils.isNotEmpty(reserveLineEndDate)) {
            if (CommonValidationUtil.checkDateRange(reserveLineEndDate, reserveLineStartDate)) {
              dataRecordErrorList.add(
                  StringConvertUtil.convertErrorListString(
                      csvFile.getName(),
                      outputRowNumber,
                      messageSource.getMessage(
                          "error.E1638",
                          new String[] {
                              Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_LINE_CONTRACT_END_DATE_NAME,
                              Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_LINE_CONTRACT_START_DATE_NAME },
                          Locale.getDefault())));
            }
          }
        }

        // 予備電源登録・変更・削除区分
        String reservePowerRegisterUpdateDelete = dataRecordMap.get(
            Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_POWER_REGISTER_UPDATE_DELETE_INDEX);
        // 範囲チェック
        if (!(ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER.equals(reservePowerRegisterUpdateDelete)
            || ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_UPDATE
                .equals(reservePowerRegisterUpdateDelete)
            || ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_DELETE
                .equals(reservePowerRegisterUpdateDelete)
            || StringUtils.isEmpty(reservePowerRegisterUpdateDelete))) {
          dataRecordErrorList.add(StringConvertUtil.convertErrorListString(
              csvFile.getName(),
              outputRowNumber,
              messageSource.getMessage(
                  "validation.range",
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_POWER_REGISTER_UPDATE_DELETE_NAME,
                      ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER + ","
                          + ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_UPDATE + ","
                          + ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_DELETE },
                  Locale.getDefault())));
        }
        // 登録時相関チェック
        if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER.equals(reUpDelCategory)) {
          if (!(ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER.equals(
              reservePowerRegisterUpdateDelete)
              || StringUtils.isEmpty(reservePowerRegisterUpdateDelete))) {
            dataRecordErrorList.add(StringConvertUtil.convertErrorListString(
                csvFile.getName(),
                outputRowNumber,
                messageSource.getMessage(
                    "error.E1637",
                    new String[] {"登録", ECISKJConstants.RESERVE_CONTRACT_CLASS_NAME_POWER },
                    Locale.getDefault())));
          }
        }
        // 削除時相関チェック
        if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_DELETE.equals(reUpDelCategory)) {
          if (!(ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_DELETE.equals(
              reservePowerRegisterUpdateDelete)
              || StringUtils.isEmpty(reservePowerRegisterUpdateDelete))) {
            dataRecordErrorList.add(
                StringConvertUtil.convertErrorListString(
                    csvFile.getName(),
                    outputRowNumber,
                    messageSource.getMessage(
                        "error.E1637",
                        new String[] {"削除",
                            ECISKJConstants.RESERVE_CONTRACT_CLASS_NAME_POWER },
                        Locale.getDefault())));
          }
        }

        // 予備電源契約開始日
        errorFlag = false;
        String reservePowerStartDate = dataRecordMap.get(
            Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_POWER_CONTRACT_START_DATE_INDEX);
        // 必須チェック
        if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER.equals(reservePowerRegisterUpdateDelete)
            || ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_DELETE
                .equals(reservePowerRegisterUpdateDelete)) {
          if (StringUtils.isEmpty(reservePowerStartDate)) {
            dataRecordErrorList.add(
                StringConvertUtil.convertErrorListString(
                    csvFile.getName(),
                    outputRowNumber,
                    messageSource.getMessage(
                        "validation.requiredstring",
                        new String[] {
                            Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_POWER_CONTRACT_START_DATE_NAME },
                        Locale.getDefault())));
            errorFlag = true;
          }
        }
        // 予備線契約終了日との相関チェック
        String reservePowerEndDate = dataRecordMap.get(
            Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_POWER_CONTRACT_END_DATE_INDEX);
        if (errorFlag == false
            && (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER
                .equals(reservePowerRegisterUpdateDelete)
                || ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_UPDATE
                    .equals(reservePowerRegisterUpdateDelete))) {
          if (StringUtils.isNotEmpty(reservePowerEndDate)) {
            if (CommonValidationUtil.checkDateRange(reservePowerEndDate, reservePowerStartDate)) {
              dataRecordErrorList.add(
                  StringConvertUtil.convertErrorListString(
                      csvFile.getName(),
                      outputRowNumber,
                      messageSource.getMessage(
                          "error.E1638",
                          new String[] {
                              Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_POWER_CONTRACT_END_DATE_NAME,
                              Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_POWER_CONTRACT_START_DATE_NAME },
                          Locale.getDefault())));
            }
          }
        }

        // エラー出力状況確認
        if (!CollectionUtils.isEmpty(dataRecordErrorList)) {
          errorList.addAll(dataRecordErrorList);
          continue;
        }

        // 行番号情報設定
        dataRecordMap
            .put(Integer
                .valueOf(ContractManagementInformationFileConfigCommon.DATA_ROW_NO_INDEX),
                String.valueOf(outputRowNumber));

        // データレコード振り分け
        if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER
            .equals(reUpDelCategory)) {
          registList.add(dataRecordMap);
        } else if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_UPDATE
            .equals(reUpDelCategory)) {
          updateList.add(dataRecordMap);
        } else if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_DELETE
            .equals(reUpDelCategory)) {
          deleteList.add(dataRecordMap);
        }
      }

      // 返却
      csvResultBean.setUploadFileName(csvFile.getName());
      csvResultBean.setErrorList(errorList);
      csvResultBean.setRegistList(registList);
      csvResultBean.setUpdateList(updateList);
      csvResultBean.setDeleteList(deleteList);

      return csvResultBean;

    } catch (Exception e) {
      throw new SystemException(e.getMessage(), e);
    }

  }

  /**
   * 型式変更：文字型→Short型<br>
   * エラーをハンドリングし、例外はスローしない
   *
   * @param value
   *          変換する文字列
   * @return 変換した数字、失敗した場合はnull
   */
  private Short stringToShort(String value) {
    Integer tempValue = StringConvertUtil.stringToInteger(value);
    if (tempValue == null) {
      return null;
    }

    return tempValue.shortValue();
  }

  /**
   * 契約マッパーのセッター(DI)
   *
   * @param contractMapper
   *          契約マッパー
   */
  public void setContractMapper(ContractMapper contractMapper) {
    this.contractMapper = contractMapper;
  }

  /**
   * 契約情報共通マッパーのセッター(DI)
   *
   * @param contractInformationCommonMapper
   *          契約情報共通マッパー
   */
  public void setContractInformationCommonMapper(
      ContractInformationCommonMapper contractInformationCommonMapper) {
    this.contractInformationCommonMapper = contractInformationCommonMapper;
  }

  /**
   * 確定料金共通マッパーのセッター(DI)
   *
   * @param fixChargeResultInformationCommonMapper
   *          確定料金共通マッパー
   */
  public void setFixChargeResultInformationCommonMapper(
      FixChargeResultInformationCommonMapper fixChargeResultInformationCommonMapper) {
    this.fixChargeResultInformationCommonMapper = fixChargeResultInformationCommonMapper;
  }

  /**
   * 契約履歴マッパーのセッター(DI)
   *
   * @param contractHistMapper
   *          契約履歴マッパー
   */
  public void setContractHistMapper(ContractHistMapper contractHistMapper) {
    this.contractHistMapper = contractHistMapper;
  }

  /**
   * メーター設置場所契約履歴マッパーのセッター(DI)
   *
   * @param mlContractHistMapper
   *          メータ設置場所履歴マッパー
   */
  public void setMlContractHistMapper(
      MlContractHistMapper mlContractHistMapper) {
    this.mlContractHistMapper = mlContractHistMapper;
  }

  /**
   * メーター設置場所マッパーのセッター(DI)
   *
   * @param mlMapper
   *          メータ設置場所マッパー
   */
  public void setMlMapper(MlMapper mlMapper) {
    this.mlMapper = mlMapper;
  }

  /**
   * 電話番号区分マッパーのセッター(DI)
   *
   * @param phoneNoCatMMapper
   *          電話番号区分マッパー
   */
  public void setPhoneNoCatMMapper(PhoneNoCatMMapper phoneNoCatMMapper) {
    this.phoneNoCatMMapper = phoneNoCatMMapper;
  }

  /**
   * 接続送電サービス区分マスタマッパーのセッター(DI)
   *
   * @param cssCatMMapper
   *          接続送電サービス区分マスタマッパー
   */
  public void setCssCatMMapper(CssCatMMapper cssCatMMapper) {
    this.cssCatMMapper = cssCatMMapper;
  }

  /**
   * 契約終了理由マスタマッパーのセッター(DI)
   *
   * @param contractEndReasonMMapper
   *          契約終了理由マスタマッパー
   */
  public void setContractEndReasonMMapper(
      ContractEndReasonMMapper contractEndReasonMMapper) {
    this.contractEndReasonMMapper = contractEndReasonMMapper;
  }

  /**
   * 契約容量単位マスタマッパーのセッター(DI)
   *
   * @param ccaUnitMMapper
   *          契約容量単位マスタマッパー
   */
  public void setCcaUnitMMapper(CcaUnitMMapper ccaUnitMMapper) {
    this.ccaUnitMMapper = ccaUnitMMapper;
  }

  /**
   * 個人・法人区分マスタマッパーのセッター(DI)
   *
   * @param ilcMMapper
   *          個人・法人区分マスタマッパー
   */
  public void setIlcMMapper(IlcMMapper ilcMMapper) {
    this.ilcMMapper = ilcMMapper;
  }

  /**
   * 営業委託先マスタマッパーのセッター(DI)
   *
   * @param scMMapper
   *          営業委託先マスタマッパー
   */
  public void setScMMapper(ScMMapper scMMapper) {
    this.scMMapper = scMMapper;
  }

  /**
   * 料金メニューマッパーのセッター(DI)
   *
   * @param rmMapper
   *          料金メニューマッパー
   */
  public void setRmMapper(RmMapper rmMapper) {
    this.rmMapper = rmMapper;
  }

  /**
   * 電圧区分マッパーのセッター(DI)
   *
   * @param voltageCatMMappe
   *          電圧区分マッパー
   */
  public void setVoltageCatMMapper(VoltageCatMMapper voltageCatMMapper) {
    this.voltageCatMMapper = voltageCatMMapper;
  }

  /**
   * 契約電力決定区分マッパーのセッター(DI)
   *
   * @param ccdCategoryMMapper
   *          契約電力決定区分マッパー
   */
  public void setCcdCategoryMMapper(CcdCategoryMMapper ccdCategoryMMapper) {
    this.ccdCategoryMMapper = ccdCategoryMMapper;
  }

  /**
   * 卸取次店向け契約情報マッパーのセッター(DI)
   *
   * @param agentContractInformationCommonMapper
   *          卸取次店向け契約情報区分マッパー
   */
  public void setAgentContractInformationCommonMapper(
      AgentContractInformationCommonMapper agentContractInformationCommonMapper) {
    this.agentContractInformationCommonMapper = agentContractInformationCommonMapper;
  }

  /**
   * 単価設定区分マッパーのセッター(DI)
   *
   * @param upsCategoryMMapper
   *          単価設定区分マッパー
   */
  public void setUpsCategoryMMapper(UpsCategoryMMapper upsCategoryMMapper) {
    this.upsCategoryMMapper = upsCategoryMMapper;
  }

  /**
   * 付帯契約情報マッパーのセッター(DI)
   *
   * @param splContractMapper
   *          付帯契約情報マッパー
   */
  public void setSplContractMapper(SplContractMapper splContractMapper) {
    this.splContractMapper = splContractMapper;
  }

  /**
   * 提供モデル企業別料金メニューマスタマッパーのセッター(DI)
   *
   * @param rmMByPmCompanyMapper
   *          提供モデル企業別料金メニューマスタマッパー
   */
  public void setRmMByPmCompanyMapper(RmMByPmCompanyMapper rmMByPmCompanyMapper) {
    this.rmMByPmCompanyMapper = rmMByPmCompanyMapper;
  }

  /**
   * 業種コードマッパーのセッター(DI)
   *
   * @param businessMMapper
   *          業種コードマッパー
   */
  public void setBusinessMMapper(BusinessMMapper businessMMapper) {
    this.businessMMapper = businessMMapper;
  }

  /**
   * 日付関連共通ビジネスのセッター(DI)
   *
   * @param dateBusiness
   *          日付関連共通ビジネス
   */
  public void setDateBusiness(DateBusiness dateBusiness) {
    this.dateBusiness = dateBusiness;
  }

  /**
   * messageSourceのセッター(DI)
   *
   * @param messageSource
   *          メッセージソース
   *
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }

  /**
   * 契約管理情報ファイルヘッダーバリデーターのセッター(DI)
   *
   * @param contractManagementInformationFileHeaderValidator
   *          契約管理情報ファイルヘッダーバリデーター
   *
   */
  public void setContractManagementInformationFileHeaderValidator(
      ContractManagementInformationFileHeaderValidator contractManagementInformationFileHeaderValidator) {
    this.contractManagementInformationFileHeaderValidator = contractManagementInformationFileHeaderValidator;
  }

  /**
   * 契約情報登録バリデーションのセッター(DI)
   *
   * @param contractInformationFileRegistValidator
   *          契約情報登録バリデーション
   */
  public void setContractInformationFileRegistValidator(
      ContractInformationFileRegistValidator contractInformationFileRegistValidator) {
    this.contractInformationFileRegistValidator = contractInformationFileRegistValidator;
  }

  /**
   * 契約情報登録バリデーションのセッター(DI) （カスタム）
   *
   * @param customContractInformationFileRegistValidator
   *          契約情報登録バリデーション
   */
  public void setCustomContractInformationFileRegistValidator(
      Custom_ContractInformationFileRegistValidator customContractInformationFileRegistValidator) {
    this.customContractInformationFileRegistValidator = customContractInformationFileRegistValidator;
  }

  /**
   * 契約情報更新バリデーションのセッター(DI)
   *
   * @param contractInformationFileUpdateValidator
   *          契約情報更新バリデーション
   */
  public void setContractInformationFileUpdateValidator(
      ContractInformationFileUpdateValidator contractInformationFileUpdateValidator) {
    this.contractInformationFileUpdateValidator = contractInformationFileUpdateValidator;
  }

  /**
   * 契約情報更新バリデーションのセッター(DI) （カスタム）
   *
   * @param customContractInformationFileUpdateValidator
   *          契約情報更新バリデーション
   */
  public void setCustomContractInformationFileUpdateValidator(
      Custom_ContractInformationFileUpdateValidator customContractInformationFileUpdateValidator) {
    this.customContractInformationFileUpdateValidator = customContractInformationFileUpdateValidator;
  }

  /**
   * 契約情報削除バリデーションのセッター(DI)
   *
   * @param contractInformationFileDeleteValidator
   *          契約情報削除バリデーション(DI)
   */
  public void setContractInformationFileDeleteValidator(
      ContractInformationFileDeleteValidator contractInformationFileDeleteValidator) {
    this.contractInformationFileDeleteValidator = contractInformationFileDeleteValidator;
  }

  /**
   * 契約情報削除バリデーションのセッター(DI) （カスタム）
   *
   * @param contractInformationFileDeleteValidator
   *          契約情報削除バリデーション(DI)
   */
  public void setCustomContractInformationFileDeleteValidator(
      Custom_ContractInformationFileDeleteValidator customContractInformationFileDeleteValidator) {
    this.customContractInformationFileDeleteValidator = customContractInformationFileDeleteValidator;
  }

  /**
   * メータ設置場所情報共通マッパーのセッター(DI)
   *
   * @param meterLocationInformationCommonMapper
   *          メータ設置場所情報共通マッパー
   */
  public void setMeterLocationInformationCommonMapper(
      MeterLocationInformationCommonMapper meterLocationInformationCommonMapper) {
  }

  /**
   * 契約者情報共通ビジネスのセッター(DI)
   *
   * @param kjContractorInfomationBusiness
   *          契約者情報共通ビジネス
   */
  public void setKjContractorInfomationBusiness(
      KJ_ContractorInformationBusiness kjContractorInfomationBusiness) {
    this.kjContractorInfomationBusiness = kjContractorInfomationBusiness;
  }

  /**
   * メータ設置場所情報共通ビジネスのセッター(DI)
   *
   * @param kjMeterLocationInformationBusiness
   *          メータ設置場所情報共通ビジネス
   */
  public void setKjMeterLocationInformationBusiness(
      KJ_MeterLocationInformationBusiness kjMeterLocationInformationBusiness) {
    this.kjMeterLocationInformationBusiness = kjMeterLocationInformationBusiness;
  }

  /**
   * 支払情報共通ビジネスのセッター(DI)
   *
   * @param kjPaymentInformationBusiness
   *          支払情報共通ビジネス
   */
  public void setKjPaymentInformationBusiness(
      KJ_PaymentInformationBusiness kjPaymentInformationBusiness) {
    this.kjPaymentInformationBusiness = kjPaymentInformationBusiness;
  }

  /**
   * 付帯契約情報共通ビジネスのセッター(DI)
   *
   * @param kjSupplementaryContractInformationBusiness
   *          付帯契約情報共通ビジネス
   */
  public void setKjSupplementaryContractInformationBusiness(
      KJ_SupplementaryContractInformationBusiness kjSupplementaryContractInformationBusiness) {
    this.kjSupplementaryContractInformationBusiness = kjSupplementaryContractInformationBusiness;
  }

}
