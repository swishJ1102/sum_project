package jp.co.unisys.enability.cis.business.rk;

import java.util.Date;
import java.util.List;

import jp.co.unisys.enability.cis.business.rk.model.RK_OnlineCommonBusinessBean;
import jp.co.unisys.enability.cis.business.rk.model.RK_RateMenuInfoBean;

public interface RK_RateSimulationBusiness {

  /**
   * 契約容量チェック
   *
   * 料金メニュー毎に契約容量のチェックを行います。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param rateMenuId
   *          料金メニューID
   * @param contractcapacity
   *          契約容量
   * @return エラーコード
   */
  String checkContractCapacity(String rateMenuId, String contractcapacity);

  /**
   * 料金シミュレーションを実行する。
   *
   * @param csvBusinessBean
   *          使用量CSV仕訳ビジネスBean
   * @param upBaseDate
   *          単価基準日
   * @return 料金計算オンライン共通ビジネスBean
   */
  List<RK_OnlineCommonBusinessBean> doSimulation(
      RK_RateMenuInfoBean rateMenuInfo,
      Date upBaseDate);
}
