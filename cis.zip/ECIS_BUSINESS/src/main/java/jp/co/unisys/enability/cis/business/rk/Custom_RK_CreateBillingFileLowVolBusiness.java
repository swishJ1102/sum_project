package jp.co.unisys.enability.cis.business.rk;

import java.util.Date;

import jp.co.unisys.enability.cis.common.Exception.BusinessLogicException;

/**
 * 請求データファイル出力（低圧）ビジネス_カスタムインターフェース
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.gk.GK_WorkCommonBusiness
 * @see jp.co.unisys.enability.cis.mapper.rk.Custom_RK_CreateBillingFileLowVolMapper
 *
 *      変更履歴(kg-epj) 2016.02.26 T.Hori 新規作成
 */
public interface Custom_RK_CreateBillingFileLowVolBusiness {

  /**
   * 請求データファイル（低圧）を作成する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数に指定された日に確定した請求情報を
   * ファイルに出力する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param batchExecuteDate
   *          バッチ実行日
   * @throws BusinessLogicException
   *           業務例外
   */
  public void creatingBillingFileForLowVoltage(Date batchExecuteDate)
      throws BusinessLogicException;

}
