package jp.co.unisys.enability.cis.business.gk;

import jp.co.unisys.enability.cis.business.gk.model.InquiryUserACLBusinessBean;
import jp.co.unisys.enability.cis.common.Exception.SystemException;

/**
 * ユーザ認証(ACL管理)共通処理。
 *
 * @author "Nihon Unisys, Ltd."
 */
public interface InquiryUserACLBusiness {
  /**
   * アクションIDに紐づくアクションが実施可能なユーザか判定する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 1.アクションマスタ、ACLから権限情報を取得し、認証処理を行う。
   * 2.認証処理の処理結果をInquiryUserACLBusinessBean.resultに設定、返却する。
   *   チェック結果：false(権限なし)
   *     権限情報が取得できない場合
   *     権限情報の拒否フラグが1の場合
   *   チェック結果：true(権限あり)
   *     権限情報の拒否フラグが0の場合
   * </pre>
   *
   * @param actionId
   *          権限チェック対象のアクションID
   * @param roleId
   *          権限チェック対象のロールID
   * @return inquiryUserACLBusinessBean ユーザアクセスコントロール検索BusinessBean
   * @throws SystemException
   *           予期せぬエラーが発生した場合
   */
  InquiryUserACLBusinessBean inquiryUserACL(
      InquiryUserACLBusinessBean inquiryUserACLBusinessBean)
      throws SystemException;
}
