package jp.co.unisys.enability.cis.business.common;

import jp.co.unisys.enability.cis.business.common.model.MailManagementBusinessBean;

/**
 * メール管理共通ビジネスインタフェース。
 *
 * <pre>
 * <p><b>【仕様詳細】<b><p>
 * メール管理への情報登録を行う。
 * </pre>
 *
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.common.MailManagementBusinessImpl
 */
public interface MailManagementBusiness {

  /**
   * メール管理へ引数の情報を登録する。
   *
   * <pre>
   * <p><b>【仕様詳細】<b><p>
   * メール管理への登録を行う。
   * その際、本文にメールＩＤ（シーケンス）を付与する。
   * また、引数の宛先（To,Cc,Bcc）全てに値が付与されていない場合、
   * 登録は行わずインフォログを出力する。
   * </pre>
   *
   * @param bean
   *          メール管理共通ビジネスBean
   */
  void registMailManagement(MailManagementBusinessBean bean);
}
