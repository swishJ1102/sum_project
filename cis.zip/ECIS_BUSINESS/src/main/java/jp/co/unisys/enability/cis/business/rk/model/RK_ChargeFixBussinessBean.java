package jp.co.unisys.enability.cis.business.rk.model;

import java.util.List;
import java.util.Map;

/**
 * 料金確定ビジネスの情報を保持するクラス。
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * ChargeFixBussinessBean - 料金確定ビジネスBean
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_ChargeFixBussinessBean {
  /**
   * 年月日を保有する。
   */
  private String calendarDate;

  /**
   * 対象カレンダーリストを保有する。
   */
  private List<Map<String, String>> coveredCalendarList;

  /**
   * 年月日のgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 年月日を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 年月日
   */
  public String getCalendarDate() {
    return this.calendarDate;
  }

  /**
   * 年月日のsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 年月日を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param calendarDate
   *          年月日
   */
  public void setCalendarDate(String calendarDate) {
    this.calendarDate = calendarDate;
  }

  /**
   * 対象カレンダーリストのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 対象カレンダーリストを取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 対象カレンダーリスト
   */
  public List<Map<String, String>> getCoveredCalendarList() {
    return this.coveredCalendarList;
  }

  /**
   * 対象カレンダーリストのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 対象カレンダーリストを設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param coveredCalendarList
   *          対象カレンダーリスト
   */
  public void setCoveredCalendarList(List<Map<String, String>> coveredCalendarList) {
    this.coveredCalendarList = coveredCalendarList;
  }
}
