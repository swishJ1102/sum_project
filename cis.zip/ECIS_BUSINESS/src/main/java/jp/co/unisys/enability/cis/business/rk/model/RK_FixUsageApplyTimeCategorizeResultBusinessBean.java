package jp.co.unisys.enability.cis.business.rk.model;

import java.math.BigDecimal;

/**
 * 時間帯別使用量の仕訳結果を保持するビジネスBean。
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * 確定使用量情報反映ビジネス。
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_FixUsageApplyTimeCategorizeResultBusinessBean {

  /**
   * 時間帯コードを保有する。
   */
  private String timeSlotCode;

  /**
   * 表示順を保有する。
   */
  private Integer displayOrder;

  /**
   * 時間帯名称を保有する。
   */
  private String timeSlotName;

  /**
   * 仕訳後使用量を保有する。
   */
  private BigDecimal categorizedUsage;

  /**
   * しわ取り優先順位を保有する。
   */
  private Integer cuPriorityOrder;

  /**
   * 時間帯コードのgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 時間帯コードを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 時間帯コード
   */
  public String getTimeSlotCode() {
    return this.timeSlotCode;
  }

  /**
   * 時間帯コードのsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 時間帯コードを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param timeSlotCode
   *          時間帯コード
   */
  public void setTimeSlotCode(String timeSlotCode) {
    this.timeSlotCode = timeSlotCode;
  }

  /**
   * 表示順のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 表示順を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 表示順
   */
  public Integer getDisplayOrder() {
    return this.displayOrder;
  }

  /**
   * 表示順のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 表示順を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param displayOrder
   *          表示順
   */
  public void setDisplayOrder(Integer displayOrder) {
    this.displayOrder = displayOrder;
  }

  /**
   * 時間帯名称のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 時間帯名称を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 時間帯名称
   */
  public String getTimeSlotName() {
    return this.timeSlotName;
  }

  /**
   * 時間帯名称のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 時間帯名称を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param timeSlotName
   *          時間帯名称
   */
  public void setTimeSlotName(String timeSlotName) {
    this.timeSlotName = timeSlotName;
  }

  /**
   * 仕訳後使用量のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 仕訳後使用量を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 仕訳後使用量
   */
  public BigDecimal getCategorizedUsage() {
    return this.categorizedUsage;
  }

  /**
   * 仕訳後使用量のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 仕訳後使用量を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param categorizedUsage
   *          仕訳後使用量
   */
  public void setCategorizedUsage(BigDecimal categorizedUsage) {
    this.categorizedUsage = categorizedUsage;
  }

  /**
   * しわ取り優先順位のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * しわ取り優先順位を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return しわ取り優先順位
   */
  public Integer getCuPriorityOrder() {
    return cuPriorityOrder;
  }

  /**
   * しわ取り優先順位のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * しわ取り優先順位を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param cuPriorityOrder
   *          しわ取り優先順位
   */
  public void setCuPriorityOrder(Integer cuPriorityOrder) {
    this.cuPriorityOrder = cuPriorityOrder;
  }
}
