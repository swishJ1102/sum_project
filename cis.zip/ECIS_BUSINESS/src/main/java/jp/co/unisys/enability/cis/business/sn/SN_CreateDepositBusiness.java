package jp.co.unisys.enability.cis.business.sn;

import java.util.Date;
import java.util.List;

import jp.co.unisys.enability.cis.common.Exception.BusinessLogicException;
import jp.co.unisys.enability.cis.entity.common.CorpAccountMngM;
import jp.co.unisys.enability.cis.entity.common.Rr;

/**
 * 請求入金共通入金作成ビジネスインターフェース。
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.mapper.sn.SN_CreateDepositMapper
 */
public interface SN_CreateDepositBusiness {

  /**
   * 入金作成処理（口座振替、クレジット払い）。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 収納区分が“口座振替”である【収納結果】から、【入金】の登録を行う。
   * 収納先の【請求】が存在しない場合は不明入金として【入金】を登録する。
   * 不明入金となった場合、収納先の【請求】に紐付く【督促管理】が解約決定となっている場合は
   * 【ToDo】の登録を行う。
   *
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param rr
   *          収納結果EntityBean
   * @param batchBaseDate
   *          バッチ処理基準日
   * @throws BusinessLogicException
   *           業務例外が発生した場合
   */
  public void createDepositForAccountTransferAndCredit(Rr rr, Date batchBaseDate) throws BusinessLogicException;

  /**
   * 入金作成処理（コンビニ）。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 収納区分が“コンビニ”である【収納結果】が“確報”である場合は【入金】の登録を行う。
   * “速報”または“速報取消”である場合は【請求】の更新を行う。
   * 収納先の【請求】が存在しない場合は不明入金として【入金】を登録する。
   * 不明入金となった場合、収納先の【請求】に紐付く【督促管理】が解約決定となっている場合は
   * 【ToDo】の登録を行う。
   *
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param rr
   *          収納結果EntityBean
   * @param batchBaseDate
   *          バッチ処理基準日
   */
  public void createDepositForConvenience(Rr rr, Date batchBaseDate);

  /**
   * 入金作成処理（振込）。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 収納区分が“振込”である【収納結果】から、【入金】の登録を行う。
   * 自社口座への収納、または収納先の【請求】が複数存在する、または存在しない場合は不明入金として【入金】を登録する。
   * 不明入金となった場合、収納先の【請求】に紐付く【督促管理】が解約決定となっている場合は
   * 【ToDo】の登録を行う。
   *
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param rr
   *          収納結果EntityBean
   * @param batchBaseDate
   *          バッチ処理基準日
   * @param corpAccountMngMList
   *          自社口座管理EntityBeanリスト
   */
  public void createDepositForTransfer(Rr rr, Date batchBaseDate, List<CorpAccountMngM> corpAccountMngMList);

  /**
   * 入金作成処理（債権回収）。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 収納区分が“債権回収”である【収納結果】から、【入金】の登録を行う。
   * 収納先の【請求】が存在しない場合は不明入金として【入金】を登録する。
   * 不明入金となった場合は【ToDo】の登録を行う。
   *
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param rr
   *          収納結果EntityBean
   * @param batchBaseDate
   *          バッチ処理基準日
   * @return 備考
   */
  public String createDepositForCommissionCollectionClaim(Rr rr, Date batchBaseDate);

}
