package jp.co.unisys.enability.cis.business.sn;

import java.util.Date;

import jp.co.unisys.enability.cis.common.Exception.BusinessLogicException;

/**
 * 請求情報作成ビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 *
 */
public interface SN_CreatingBillingFileBusiness {

  /**
   * 請求情報作成処理。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数に指定された日に確定した請求情報を
   * ファイルに出力する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param batchDate
   *          バッチ処理基準日
   * @throws BusinessLogicException
   *           業務例外
   */
  public void creatingBillingFile(Date batchDate)
      throws BusinessLogicException;
}
