package jp.co.unisys.enability.cis.business.gk;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import jp.co.unisys.enability.cis.business.kj.model.ContractManagementInformationFileConfigCommon;
import jp.co.unisys.enability.cis.business.kj.model.Custom_ContractManagementInformationFileConfigContractor;
import jp.co.unisys.enability.cis.common.util.CommonValidationUtil;
import jp.co.unisys.enability.cis.common.util.EMSMessageResource;

/**
 * （カスタム）契約者情報ファイル登録チェッククラス
 *
 * @author "Nihon Unisys, Ltd."
 */
public class Custom_ContractorInformationFileRegistValidator {

  /** プロパティクラスを定義 */
  private EMSMessageResource emsMessageResource;

  /**
   * メッセージプロパティキー管理のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージプロパティキー管理を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param emsMessageResource
   *          メッセージプロパティキー管理
   */
  public void setEmsMessageResource(EMSMessageResource emsMessageResource) {
    this.emsMessageResource = emsMessageResource;
  }

  /**
   * 契約者情報ファイル登録のバリデーションを実施、チェック結果のメッセージListを返却する。 （カスタム仕様の追加項目対応）
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 1 引数のバリデーションを行う。
   * 2 チェック結果がNGの場合、戻り値のメッセージListにエラーメッセージを詰めて返却する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param dataRecordMap
   *          データレコードマップ
   * @return メッセージList
   */
  public List<String> validate(Map<Integer, String> dataRecordMap) {

    List<String> messageList = new ArrayList<String>();

    // データレコード種別：必須チェック
    String dataRecordClass = dataRecordMap
        .get(ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_INDEX);
    if (CommonValidationUtil.isNull(dataRecordClass)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_NAME }));

      // データレコード種別：正規表現チェック
    } else if (dataRecordClass != null
        && !CommonValidationUtil
            .checkByPattern(
                dataRecordClass,
                ContractManagementInformationFileConfigCommon.DATA_KIND_MASK_STRING)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_ITEM_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_NAME }));
    }

    // 契約者番号：必須チェック
    String contractorNo = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NO_INDEX);
    if (CommonValidationUtil.isNull(contractorNo)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NO_NAME }));

      // 契約者番号：文字種別チェック（半角英数字）
    } else if (contractorNo != null
        && !CommonValidationUtil.isAlphabetNumric(contractorNo)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_ALPHANUMERIC_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NO_NAME }));

      // 契約者番号：文字種別チェック（半角英数字　低圧CISシステム許容文字）
    } else if (contractorNo != null
        && !CommonValidationUtil.isRangeWordByECIS(contractorNo)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NO_NAME,
                      "半角英数字（低圧CISシステム許容文字）" }));

      // 契約者番号：文字列最大長チェック
    } else if (contractorNo != null
        && !CommonValidationUtil
            .maxLength(
                contractorNo,
                Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NO_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NO_NAME,
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NO_LENGTH_STRING }));
    }

    // 外部システム契約者番号：文字種別チェック（半角英数ハイフン）
    String externalManageContractorNo = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigContractor.DATA_EXTERNAL_MANAGE_CONTRACTOR_NO_INDEX);
    if (externalManageContractorNo != null
        && !CommonValidationUtil.isAlphabetNumricHyphen(externalManageContractorNo)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_ALPHANUMERICHYPHEN_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_EXTERNAL_MANAGE_CONTRACTOR_NO_NAME }));
      // 外部システム契約者番号：文字種別チェック（低圧CISシステム許容文字）
    } else if (externalManageContractorNo != null
        && !CommonValidationUtil.isRangeWordByECIS(externalManageContractorNo)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_EXTERNAL_MANAGE_CONTRACTOR_NO_NAME,
                      "半角英数字ハイフン（低圧CISシステム許容文字）" }));
      // 外部システム契約者番号：文字列最大長チェック
    } else if (externalManageContractorNo != null
        && !CommonValidationUtil
            .maxLength(
                externalManageContractorNo,
                Custom_ContractManagementInformationFileConfigContractor.DATA_EXTERNAL_MANAGE_CONTRACTOR_NO_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_EXTERNAL_MANAGE_CONTRACTOR_NO_NAME,
                      Custom_ContractManagementInformationFileConfigContractor.DATA_EXTERNAL_MANAGE_CONTRACTOR_NO_LENGTH_STRING }));
    }

    // 個人・法人区分コード：必須チェック
    String individualLegalEntityCategoryCode = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigContractor.DATA_INDIVIDUAL_LEGAL_ENTITY_CATEGORY_CODE_INDEX);
    if (CommonValidationUtil.isNull(individualLegalEntityCategoryCode)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_INDIVIDUAL_LEGAL_ENTITY_CATEGORY_CODE_NAME }));
    }

    // 契約者名1（カナ）：必須チェック
    String contractorName1Kana = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME1_KANA_INDEX);
    if (CommonValidationUtil.isNull(contractorName1Kana)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME1_KANA_NAME }));

      // 契約者名1（カナ）：文字列最大長チェック
    } else if (contractorName1Kana != null
        && !CommonValidationUtil
            .maxLength(
                contractorName1Kana,
                Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME1_KANA_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME1_KANA_NAME,
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME1_KANA_LENGTH_STRING }));

      // 契約者名1（カナ）：正規表現チェック
    } else if (contractorName1Kana != null
        && !CommonValidationUtil
            .checkByPattern(
                contractorName1Kana,
                Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME1_KANA_MASK_STRING)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_ITEM_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME1_KANA_NAME }));
    }

    // 契約者名1：必須チェック
    String contractorName1 = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME1_INDEX);
    if (CommonValidationUtil.isNull(contractorName1)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME1_NAME }));

      // 契約者名1：文字種別チェック（全角）
    } else if (contractorName1 != null
        && !CommonValidationUtil.isZenkakuType(contractorName1)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME1_NAME }));

      // 契約者名1：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (contractorName1 != null
        && !CommonValidationUtil.isRangeWordByECIS(contractorName1)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME1_NAME,
                      "全角（低圧CISシステム許容文字）" }));

      // 契約者名1：文字列最大長チェック
    } else if (contractorName1 != null
        && !CommonValidationUtil
            .maxLength(
                contractorName1,
                Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME1_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME1_NAME,
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME1_LENGTH_STRING }));
    }

    // 契約者名2：文字種別チェック（全角）
    String contractorName2 = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME2_INDEX);
    if (contractorName2 != null
        && !CommonValidationUtil.isZenkakuType(contractorName2)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME2_NAME }));

      // 契約者名2：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (contractorName2 != null
        && !CommonValidationUtil.isRangeWordByECIS(contractorName2)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME2_NAME,
                      "全角（低圧CISシステム許容文字）" }));

      // 契約者名2：文字列最大長チェック
    } else if (contractorName2 != null
        && !CommonValidationUtil
            .maxLength(
                contractorName2,
                Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME2_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME2_NAME,
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME2_LENGTH_STRING }));
    }

    // 契約者名1（宛名用）：文字種別チェック（全角）
    String contractorName1MailingName = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME1_MAILING_NAME_INDEX);
    if (contractorName1MailingName != null
        && !CommonValidationUtil
            .isZenkakuType(contractorName1MailingName)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME1_MAILING_NAME_NAME }));

      // 契約者名1（宛名用）：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (contractorName1MailingName != null
        && !CommonValidationUtil
            .isRangeWordByECIS(contractorName1MailingName)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME1_MAILING_NAME_NAME,
                      "全角（低圧CISシステム許容文字）" }));

      // 契約者名1（宛名用）：文字列最大長チェック
    } else if (contractorName1MailingName != null
        && !CommonValidationUtil
            .maxLength(
                contractorName1MailingName,
                Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME1_MAILING_NAME_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME1_MAILING_NAME_NAME,
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME1_MAILING_NAME_LENGTH_STRING }));
    }

    // 契約者名2（宛名用）：文字種別チェック（全角）
    String contractorName2MailingName = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME2_MAILING_NAME_INDEX);
    if (contractorName2MailingName != null
        && !CommonValidationUtil
            .isZenkakuType(contractorName2MailingName)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME2_MAILING_NAME_NAME }));

      // 契約者名2（宛名用）：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (contractorName2MailingName != null
        && !CommonValidationUtil
            .isRangeWordByECIS(contractorName2MailingName)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME2_MAILING_NAME_NAME,
                      "全角（低圧CISシステム許容文字）" }));

      // 契約者名2（宛名用）：文字列最大長チェック
    } else if (contractorName2MailingName != null
        && !CommonValidationUtil
            .maxLength(
                contractorName2MailingName,
                Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME2_MAILING_NAME_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME2_MAILING_NAME_NAME,
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME2_MAILING_NAME_LENGTH_STRING }));
    }

    // 敬称：必須チェック
    String prefix = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigContractor.DATA_PREFIX_INDEX);
    if (CommonValidationUtil.isNull(prefix)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_PREFIX_NAME }));

      // 敬称：文字種別チェック（全角）
    } else if (prefix != null
        && !CommonValidationUtil.isZenkakuType(prefix)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_PREFIX_NAME }));

      // 敬称：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (prefix != null
        && !CommonValidationUtil.isRangeWordByECIS(prefix)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_PREFIX_NAME,
                      "全角（低圧CISシステム許容文字）" }));

      // 敬称：文字列最大長チェック
    } else if (prefix != null
        && !CommonValidationUtil
            .maxLength(
                prefix,
                Custom_ContractManagementInformationFileConfigContractor.DATA_PREFIX_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_PREFIX_NAME,
                      Custom_ContractManagementInformationFileConfigContractor.DATA_PREFIX_LENGTH_STRING }));
    }

    // 契約者住所（郵便番号）：必須チェック
    String contractorAddressPostalCode = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_POSTAL_CODE_INDEX);
    if (CommonValidationUtil.isNull(contractorAddressPostalCode)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_POSTAL_CODE_NAME }));

      // 契約者住所（郵便番号）：文字種別チェック（半角数字）
    } else if (contractorAddressPostalCode != null
        && !CommonValidationUtil.isNumric(contractorAddressPostalCode)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_POSTAL_CODE_NAME,
                      "半角数字" }));

      // 契約者住所（郵便番号）：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (contractorAddressPostalCode != null
        && !CommonValidationUtil
            .isRangeWordByECIS(contractorAddressPostalCode)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_POSTAL_CODE_NAME,
                      "半角数字（低圧CISシステム許容文字）" }));

      // 契約者住所（郵便番号）：文字列指定長チェック
    } else if (contractorAddressPostalCode != null
        && !CommonValidationUtil
            .justLength(
                contractorAddressPostalCode,
                Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_POSTAL_CODE_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_STRINGLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_POSTAL_CODE_NAME,
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_POSTAL_CODE_LENGTH_STRING }));
    }

    // 契約者住所（都道府県名）：必須チェック
    String contractorAddressPrefectures = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_PREFECTURES_INDEX);
    if (CommonValidationUtil.isNull(contractorAddressPrefectures)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_PREFECTURES_NAME }));

      // 契約者住所（都道府県名）：文字種別チェック（全角）
    } else if (contractorAddressPrefectures != null
        && !CommonValidationUtil
            .isZenkakuType(contractorAddressPrefectures)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_PREFECTURES_NAME }));

      // 契約者住所（都道府県名）：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (contractorAddressPrefectures != null
        && !CommonValidationUtil
            .isRangeWordByECIS(contractorAddressPrefectures)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_PREFECTURES_NAME,
                      "全角（低圧CISシステム許容文字）" }));

      // 契約者住所（都道府県名）：文字列最大長チェック
    } else if (contractorAddressPrefectures != null
        && !CommonValidationUtil
            .maxLength(
                contractorAddressPrefectures,
                Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_PREFECTURES_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_PREFECTURES_NAME,
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_PREFECTURES_LENGTH_STRING }));
    }

    // 契約者住所（市区郡町村名）：必須チェック
    String contractorAddressMunicipality = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_MUNICIPALITY_INDEX);
    if (CommonValidationUtil.isNull(contractorAddressMunicipality)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_MUNICIPALITY_NAME }));

      // 契約者住所（市区郡町村名）：文字種別チェック（全角）
    } else if (contractorAddressMunicipality != null
        && !CommonValidationUtil
            .isZenkakuType(contractorAddressMunicipality)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_MUNICIPALITY_NAME }));

      // 契約者住所（市区郡町村名）：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (contractorAddressMunicipality != null
        && !CommonValidationUtil
            .isRangeWordByECIS(contractorAddressMunicipality)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_MUNICIPALITY_NAME,
                      "全角（低圧CISシステム許容文字）" }));

      // 契約者住所（市区郡町村名）：文字列最大長チェック
    } else if (contractorAddressMunicipality != null
        && !CommonValidationUtil
            .maxLength(
                contractorAddressMunicipality,
                Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_MUNICIPALITY_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_MUNICIPALITY_NAME,
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_MUNICIPALITY_LENGTH_STRING }));
    }

    // 契約者住所（字名・丁目）：文字種別チェック（全角）
    String contractorAddressSection = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_SECTION_INDEX);
    if (contractorAddressSection != null
        && !CommonValidationUtil
            .isZenkakuType(contractorAddressSection)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_SECTION_NAME }));

      // 契約者住所（字名・丁目）：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (contractorAddressSection != null
        && !CommonValidationUtil
            .isRangeWordByECIS(contractorAddressSection)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_SECTION_NAME,
                      "全角（低圧CISシステム許容文字）" }));

      // 契約者住所（字名・丁目）：文字列最大長チェック
    } else if (contractorAddressSection != null
        && !CommonValidationUtil
            .maxLength(
                contractorAddressSection,
                Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_SECTION_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_SECTION_NAME,
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_SECTION_LENGTH_STRING }));
    }

    // 契約者住所（番地･号）：文字列最大長チェック
    String contractorAddressBlock = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_BLOCK_INDEX);
    if (contractorAddressBlock != null
        && !CommonValidationUtil
            .maxLength(
                contractorAddressBlock,
                Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_BLOCK_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_BLOCK_NAME,
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_BLOCK_LENGTH_STRING }));

      // 契約者住所（番地･号）：正規表現チェック
    } else if (contractorAddressBlock != null
        && !CommonValidationUtil
            .checkByPattern(
                contractorAddressBlock,
                Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_BLOCK_MASK_STRING)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_ITEM_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_BLOCK_NAME }));
    }

    // 契約者住所（建物名）：文字種別チェック（全角）
    String contractorAddressBuildingName = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_BUILDING_NAME_INDEX);
    if (contractorAddressBuildingName != null
        && !CommonValidationUtil
            .isZenkakuType(contractorAddressBuildingName)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_BUILDING_NAME_NAME }));

      // 契約者住所（建物名）：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (contractorAddressBuildingName != null
        && !CommonValidationUtil
            .isRangeWordByECIS(contractorAddressBuildingName)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_BUILDING_NAME_NAME,
                      "全角（低圧CISシステム許容文字）" }));

      // 契約者住所（建物名）：文字列最大長チェック
    } else if (contractorAddressBuildingName != null
        && !CommonValidationUtil
            .maxLength(
                contractorAddressBuildingName,
                Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_BUILDING_NAME_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_BUILDING_NAME_NAME,
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_BUILDING_NAME_LENGTH_STRING }));
    }

    // 契約者住所（部屋名）：文字種別チェック（全角）
    String contractorAddressRoom = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_ROOM_INDEX);
    if (contractorAddressRoom != null
        && !CommonValidationUtil
            .isZenkakuType(contractorAddressRoom)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_FULLWIDTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_ROOM_NAME }));

      // 契約者住所（部屋名）：文字種別チェック（全角　低圧CISシステム許容文字）
    } else if (contractorAddressRoom != null
        && !CommonValidationUtil
            .isRangeWordByECIS(contractorAddressRoom)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_ROOM_NAME,
                      "全角（低圧CISシステム許容文字）" }));

      // 契約者住所（部屋名）：文字列最大長チェック
    } else if (contractorAddressRoom != null
        && !CommonValidationUtil
            .maxLength(
                contractorAddressRoom,
                Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_ROOM_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_ROOM_NAME,
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_ROOM_LENGTH_STRING }));
    }

    // 契約者電話区分コード1：必須チェック
    String contractorPhoneCategoryCode1 = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_CATEGORY_CODE1_INDEX);
    if (CommonValidationUtil.isNull(contractorPhoneCategoryCode1)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_CATEGORY_CODE1_NAME }));
    }

    // 契約者電話1（市外局番）：必須チェック
    String contractorPhoneAreaCode1 = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_AREA_CODE1_INDEX);
    if (CommonValidationUtil.isNull(contractorPhoneAreaCode1)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_AREA_CODE1_NAME }));

      // 契約者電話1（市外局番）：文字種別チェック（半角数字）
    } else if (contractorPhoneAreaCode1 != null
        && !CommonValidationUtil.isNumric(contractorPhoneAreaCode1)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_AREA_CODE1_NAME,
                      "半角数字" }));

      // 契約者電話1（市外局番）：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (contractorPhoneAreaCode1 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(contractorPhoneAreaCode1)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_AREA_CODE1_NAME,
                      "半角数字（低圧CISシステム許容文字）" }));

      // 契約者電話1（市外局番）：文字列最大長チェック
    } else if (contractorPhoneAreaCode1 != null
        && !CommonValidationUtil
            .maxLength(
                contractorPhoneAreaCode1,
                Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_AREA_CODE1_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_AREA_CODE1_NAME,
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_AREA_CODE1_LENGTH_STRING }));
    }

    // 契約者電話1（市内局番）：必須チェック
    String contractorPhoneLocalNo = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_LOCAL_NO_INDEX);
    if (CommonValidationUtil.isNull(contractorPhoneLocalNo)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_LOCAL_NO_NAME }));

      // 契約者電話1（市内局番）：文字種別チェック（半角数字）
    } else if (contractorPhoneLocalNo != null
        && !CommonValidationUtil.isNumric(contractorPhoneLocalNo)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_LOCAL_NO_NAME,
                      "半角数字" }));

      // 契約者電話1（市内局番）：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (contractorPhoneLocalNo != null
        && !CommonValidationUtil
            .isRangeWordByECIS(contractorPhoneLocalNo)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_LOCAL_NO_NAME,
                      "半角数字（低圧CISシステム許容文字）" }));

      // 契約者電話1（市内局番）：文字列最大長チェック
    } else if (contractorPhoneLocalNo != null
        && !CommonValidationUtil
            .maxLength(
                contractorPhoneLocalNo,
                Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_LOCAL_NO_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_LOCAL_NO_NAME,
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_LOCAL_NO_LENGTH_STRING }));
    }

    // 契約者電話1（加入者番号）：必須チェック
    String contractorPhoneDirectoryNo = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_DIRECTORY_NO_INDEX);
    if (CommonValidationUtil.isNull(contractorPhoneDirectoryNo)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_DIRECTORY_NO_NAME }));

      // 契約者電話1（加入者番号）：文字種別チェック（半角数字）
    } else if (contractorPhoneDirectoryNo != null
        && !CommonValidationUtil.isNumric(contractorPhoneDirectoryNo)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_DIRECTORY_NO_NAME,
                      "半角数字" }));

      // 契約者電話1（加入者番号）：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (contractorPhoneDirectoryNo != null
        && !CommonValidationUtil
            .isRangeWordByECIS(contractorPhoneDirectoryNo)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_DIRECTORY_NO_NAME,
                      "半角数字（低圧CISシステム許容文字）" }));

      // 契約者電話1（加入者番号）：文字列最大長チェック
    } else if (contractorPhoneDirectoryNo != null
        && !CommonValidationUtil
            .maxLength(
                contractorPhoneDirectoryNo,
                Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_DIRECTORY_NO_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_DIRECTORY_NO_NAME,
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_DIRECTORY_NO_LENGTH_STRING }));
    }

    // 契約者電話2（市外局番）：文字種別チェック（半角数字）
    String contractorPhoneAreaCode2 = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_AREA_CODE2_INDEX);
    if (contractorPhoneAreaCode2 != null
        && !CommonValidationUtil.isNumric(contractorPhoneAreaCode2)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_AREA_CODE2_NAME,
                      "半角数字" }));

      // 契約者電話2（市外局番）：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (contractorPhoneAreaCode2 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(contractorPhoneAreaCode2)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_AREA_CODE2_NAME,
                      "半角数字（低圧CISシステム許容文字）" }));

      // 契約者電話2（市外局番）：文字列最大長チェック
    } else if (contractorPhoneAreaCode2 != null
        && !CommonValidationUtil
            .maxLength(
                contractorPhoneAreaCode2,
                Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_AREA_CODE2_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_AREA_CODE2_NAME,
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_AREA_CODE2_LENGTH_STRING }));
    }

    // 契約者電話2（市内局番）：文字種別チェック（半角数字）
    String contractorPhoneLocalNo2 = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_LOCAL_NO2_INDEX);
    if (contractorPhoneLocalNo2 != null
        && !CommonValidationUtil.isNumric(contractorPhoneLocalNo2)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_LOCAL_NO2_NAME,
                      "半角数字" }));

      // 契約者電話2（市内局番）：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (contractorPhoneLocalNo2 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(contractorPhoneLocalNo2)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_LOCAL_NO2_NAME,
                      "半角数字（低圧CISシステム許容文字）" }));

      // 契約者電話2（市内局番）：文字列最大長チェック
    } else if (contractorPhoneLocalNo2 != null
        && !CommonValidationUtil
            .maxLength(
                contractorPhoneLocalNo2,
                Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_LOCAL_NO2_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_LOCAL_NO2_NAME,
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_LOCAL_NO2_LENGTH_STRING }));
    }

    // 契約者電話2（加入者番号）：文字種別チェック（半角数字）
    String contractorPhoneDirectoryNo2 = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_DIRECTORY_NO2_INDEX);
    if (contractorPhoneDirectoryNo2 != null
        && !CommonValidationUtil.isNumric(contractorPhoneDirectoryNo2)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_DIRECTORY_NO2_NAME,
                      "半角数字" }));

      // 契約者電話2（加入者番号）：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (contractorPhoneDirectoryNo2 != null
        && !CommonValidationUtil
            .isRangeWordByECIS(contractorPhoneDirectoryNo2)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_DIRECTORY_NO2_NAME,
                      "半角数字（低圧CISシステム許容文字）" }));

      // 契約者電話2（加入者番号）：文字列最大長チェック
    } else if (contractorPhoneDirectoryNo2 != null
        && !CommonValidationUtil
            .maxLength(
                contractorPhoneDirectoryNo2,
                Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_DIRECTORY_NO2_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_DIRECTORY_NO2_NAME,
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_DIRECTORY_NO2_LENGTH_STRING }));
    }

    // 契約者メールアドレス1：文字列最大長チェック
    String contractorMailAddress1 = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_MAIL_ADDRESS1_INDEX);
    if (contractorMailAddress1 != null
        && !CommonValidationUtil
            .maxLength(
                contractorMailAddress1,
                Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_MAIL_ADDRESS1_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_MAIL_ADDRESS1_NAME,
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_MAIL_ADDRESS1_LENGTH_STRING }));

      // 契約者メールアドレス1：正規表現チェック
    } else if (contractorMailAddress1 != null
        && !CommonValidationUtil
            .checkByPattern(
                contractorMailAddress1,
                Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_MAIL_ADDRESS1_MASK_STRING)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_ITEM_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_MAIL_ADDRESS1_NAME }));
    }

    // 契約者メールアドレス2：文字列最大長チェック
    String contractorMailAddress2 = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_MAIL_ADDRESS2_INDEX);
    if (contractorMailAddress2 != null
        && !CommonValidationUtil
            .maxLength(
                contractorMailAddress2,
                Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_MAIL_ADDRESS2_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_MAIL_ADDRESS2_NAME,
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_MAIL_ADDRESS2_LENGTH_STRING }));

      // 契約者メールアドレス2：正規表現チェック
    } else if (contractorMailAddress2 != null
        && !CommonValidationUtil
            .checkByPattern(
                contractorMailAddress2,
                Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_MAIL_ADDRESS2_MASK_STRING)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_ITEM_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_MAIL_ADDRESS2_NAME }));
    }

    // 提供モデルコード：必須チェック
    String provideModelCode = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigContractor.DATA_PROVIDE_MODEL_CODE_INDEX);
    if (CommonValidationUtil.isNull(provideModelCode)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_PROVIDE_MODEL_CODE_NAME }));
    }

    // 提供モデル企業コード：必須チェック
    String provideModelCompanyCode = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigContractor.DATA_PROVIDE_MODEL_COMPANY_CODE_INDEX);
    if (CommonValidationUtil.isNull(provideModelCompanyCode)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_PROVIDE_MODEL_COMPANY_CODE_NAME }));
    }

    // 取引先コード：文字種別チェック（半角英数字）
    String customerCode = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CUSTOMER_CODE_INDEX);
    if (customerCode != null
        && !CommonValidationUtil.isAlphabetNumric(customerCode)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_ALPHANUMERIC_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CUSTOMER_CODE_NAME }));

      // 取引先コード：文字種別チェック（半角英数字　低圧CISシステム許容文字）
    } else if (customerCode != null
        && !CommonValidationUtil.isRangeWordByECIS(customerCode)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CUSTOMER_CODE_NAME,
                      "半角英数字（低圧CISシステム許容文字）" }));

      // 取引先コード：文字列最大長チェック
    } else if (customerCode != null
        && !CommonValidationUtil
            .maxLength(
                customerCode,
                Custom_ContractManagementInformationFileConfigContractor.DATA_CUSTOMER_CODE_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CUSTOMER_CODE_NAME,
                      Custom_ContractManagementInformationFileConfigContractor.DATA_CUSTOMER_CODE_LENGTH_STRING }));
    }

    // 督促対象外フラグ：必須チェック
    String urgeNotCoveredFlag = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigContractor.DATA_URGE_NOT_COVERED_FLAG_INDEX);
    if (CommonValidationUtil.isNull(urgeNotCoveredFlag)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_URGE_NOT_COVERED_FLAG_NAME }));
      // 督促対象外フラグ：文字種別チェック（半角数字）
    } else if (urgeNotCoveredFlag != null
        && !CommonValidationUtil.isNumric(urgeNotCoveredFlag)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_URGE_NOT_COVERED_FLAG_NAME,
                      "半角数字" }));

      // 督促対象外フラグ：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (urgeNotCoveredFlag != null
        && !CommonValidationUtil
            .isRangeWordByECIS(urgeNotCoveredFlag)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_URGE_NOT_COVERED_FLAG_NAME,
                      "半角数字（低圧CISシステム許容文字）" }));
      // 督促対象外フラグ：数値範囲チェック
    } else if (urgeNotCoveredFlag != null
        && !CommonValidationUtil
            .checkRange(
                urgeNotCoveredFlag,
                Custom_ContractManagementInformationFileConfigContractor.DATA_URGE_NOT_COVERED_FLAG_RANGE_MIN,
                Custom_ContractManagementInformationFileConfigContractor.DATA_URGE_NOT_COVERED_FLAG_RANGE_MAX)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_RANGE_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_URGE_NOT_COVERED_FLAG_NAME,
                      Custom_ContractManagementInformationFileConfigContractor.DATA_URGE_NOT_COVERED_FLAG_MESSAGE }));
    }

    // 見える化提供フラグ：必須チェック
    String visualizationProvideFlag = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigContractor.DATA_VISUALIZATION_PROVIDE_FLAG_INDEX);
    if (CommonValidationUtil.isNull(visualizationProvideFlag)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_VISUALIZATION_PROVIDE_FLAG_NAME }));

      // 見える化提供フラグ：文字種別チェック（半角数字）
    } else if (visualizationProvideFlag != null
        && !CommonValidationUtil.isNumric(visualizationProvideFlag)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_VISUALIZATION_PROVIDE_FLAG_NAME,
                      "半角数字" }));

      // 見える化提供フラグ：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (visualizationProvideFlag != null
        && !CommonValidationUtil
            .isRangeWordByECIS(visualizationProvideFlag)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_VISUALIZATION_PROVIDE_FLAG_NAME,
                      "半角数字（低圧CISシステム許容文字）" }));
      // 見える化提供フラグ：数値範囲チェック
    } else if (visualizationProvideFlag != null
        && !CommonValidationUtil
            .checkRange(
                visualizationProvideFlag,
                Custom_ContractManagementInformationFileConfigContractor.DATA_VISUALIZATION_PROVIDE_FLAG_RANGE_MIN,
                Custom_ContractManagementInformationFileConfigContractor.DATA_VISUALIZATION_PROVIDE_FLAG_RANGE_MAX)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_RANGE_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_VISUALIZATION_PROVIDE_FLAG_NAME,
                      Custom_ContractManagementInformationFileConfigContractor.DATA_VISUALIZATION_PROVIDE_FLAG_MESSAGE }));
    }

    // 備考：文字列最大長チェック
    String note = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigContractor.DATA_NOTE_INDEX);
    if (note != null
        && !CommonValidationUtil
            .maxLength(
                note,
                Custom_ContractManagementInformationFileConfigContractor.DATA_NOTE_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_NOTE_NAME,
                      Custom_ContractManagementInformationFileConfigContractor.DATA_NOTE_LENGTH_STRING }));
      // 備考：文字種別チェック（低圧CISシステム許容文字）
    } else if (note != null
        && !CommonValidationUtil
            .isRangeWordByECIS(note)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_NOTE_NAME,
                      "低圧CISシステム許容文字" }));
    }

    // 利用不能フラグ：必須チェック
    String unavailableFlag = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigContractor.DATA_UNAVAILABLE_FLAG_INDEX);
    if (CommonValidationUtil.isNull(unavailableFlag)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_UNAVAILABLE_FLAG_NAME }));
      // 利用不能フラグ：文字種別チェック（半角数字）
    } else if (unavailableFlag != null
        && !CommonValidationUtil.isNumric(unavailableFlag)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_UNAVAILABLE_FLAG_NAME,
                      "半角数字" }));

      // 利用不能フラグ：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (unavailableFlag != null
        && !CommonValidationUtil
            .isRangeWordByECIS(unavailableFlag)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_UNAVAILABLE_FLAG_NAME,
                      "半角数字（低圧CISシステム許容文字）" }));
      // 利用不能フラグ：数値範囲チェック
    } else if (unavailableFlag != null
        && !CommonValidationUtil
            .checkRange(
                unavailableFlag,
                Custom_ContractManagementInformationFileConfigContractor.DATA_UNAVAILABLE_FLAG_RANGE_MIN,
                Custom_ContractManagementInformationFileConfigContractor.DATA_UNAVAILABLE_FLAG_RANGE_MAX)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_RANGE_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_UNAVAILABLE_FLAG_NAME,
                      Custom_ContractManagementInformationFileConfigContractor.DATA_UNAVAILABLE_FLAG_MESSAGE }));
    }

    String agentContractorNo = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigContractor.DATA_AGENT_CONTRACTOR_NO_INDEX);
    // 卸取次店契約者番号：文字種別チェック（半角英数字ハイフン）
    if (agentContractorNo != null
        && !CommonValidationUtil.isAlphabetNumricHyphen(agentContractorNo)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_ALPHANUMERICHYPHEN_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_AGENT_CONTRACTOR_NO_NAME }));

      // 卸取次店契約者番号：文字種別チェック（半角英数字　低圧CISシステム許容文字）
    } else if (agentContractorNo != null
        && !CommonValidationUtil.isRangeWordByECIS(agentContractorNo)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_AGENT_CONTRACTOR_NO_NAME,
                      "半角英数字ハイフン（低圧CISシステム許容文字）" }));

      // 卸取次店契約者番号：文字列最大長チェック
    } else if (agentContractorNo != null
        && !CommonValidationUtil
            .maxLength(
                agentContractorNo,
                Custom_ContractManagementInformationFileConfigContractor.DATA_AGENT_CONTRACTOR_NO_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_AGENT_CONTRACTOR_NO_NAME,
                      Custom_ContractManagementInformationFileConfigContractor.DATA_AGENT_CONTRACTOR_NO_LENGTH_STRING }));
    }

    String free01 = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_01_INDEX);
    // フリー項目1：文字種別チェック（低圧CISシステム許容文字）
    if (free01 != null
        && !CommonValidationUtil.isRangeWordByECIS(free01)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_01_NAME,
                      "低圧CISシステム許容文字" }));

      // フリー項目1：文字列最大長チェック
    } else if (free01 != null
        && !CommonValidationUtil
            .maxLength(
                free01,
                Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_01_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_01_NAME,
                      Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_01_LENGTH_STRING }));

    }

    String free02 = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_02_INDEX);
    // フリー項目2：文字種別チェック（低圧CISシステム許容文字）
    if (free02 != null
        && !CommonValidationUtil.isRangeWordByECIS(free02)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_02_NAME,
                      "低圧CISシステム許容文字" }));

      // フリー項目2：文字列最大長チェック
    } else if (free02 != null
        && !CommonValidationUtil
            .maxLength(
                free02,
                Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_02_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_02_NAME,
                      Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_02_LENGTH_STRING }));

    }

    String free03 = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_03_INDEX);
    // フリー項目3：文字種別チェック（低圧CISシステム許容文字）
    if (free03 != null
        && !CommonValidationUtil.isRangeWordByECIS(free03)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_03_NAME,
                      "低圧CISシステム許容文字" }));

      // フリー項目3：文字列最大長チェック
    } else if (free03 != null
        && !CommonValidationUtil
            .maxLength(
                free03,
                Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_03_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_03_NAME,
                      Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_03_LENGTH_STRING }));

    }

    String free04 = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_04_INDEX);
    // フリー項目4：文字種別チェック（低圧CISシステム許容文字）
    if (free04 != null
        && !CommonValidationUtil.isRangeWordByECIS(free04)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_04_NAME,
                      "低圧CISシステム許容文字" }));

      // フリー項目4：文字列最大長チェック
    } else if (free04 != null
        && !CommonValidationUtil
            .maxLength(
                free04,
                Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_04_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_04_NAME,
                      Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_04_LENGTH_STRING }));

    }

    String free05 = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_05_INDEX);
    // フリー項目5：文字種別チェック（低圧CISシステム許容文字）
    if (free05 != null
        && !CommonValidationUtil.isRangeWordByECIS(free05)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_05_NAME,
                      "低圧CISシステム許容文字" }));

      // フリー項目5：文字列最大長チェック
    } else if (free05 != null
        && !CommonValidationUtil
            .maxLength(
                free05,
                Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_05_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_05_NAME,
                      Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_05_LENGTH_STRING }));

    }

    String free06 = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_06_INDEX);
    // フリー項目6：文字種別チェック（低圧CISシステム許容文字）
    if (free06 != null
        && !CommonValidationUtil.isRangeWordByECIS(free06)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_06_NAME,
                      "低圧CISシステム許容文字" }));

      // フリー項目6：文字列最大長チェック
    } else if (free06 != null
        && !CommonValidationUtil
            .maxLength(
                free06,
                Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_06_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_06_NAME,
                      Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_06_LENGTH_STRING }));

    }

    String free07 = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_07_INDEX);
    // フリー項目7：文字種別チェック（低圧CISシステム許容文字）
    if (free07 != null
        && !CommonValidationUtil.isRangeWordByECIS(free07)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_07_NAME,
                      "低圧CISシステム許容文字" }));

      // フリー項目7：文字列最大長チェック
    } else if (free07 != null
        && !CommonValidationUtil
            .maxLength(
                free07,
                Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_07_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_07_NAME,
                      Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_07_LENGTH_STRING }));

    }

    String free08 = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_08_INDEX);
    // フリー項目8：文字種別チェック（低圧CISシステム許容文字）
    if (free08 != null
        && !CommonValidationUtil.isRangeWordByECIS(free08)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_08_NAME,
                      "低圧CISシステム許容文字" }));

      // フリー項目8：文字列最大長チェック
    } else if (free08 != null
        && !CommonValidationUtil
            .maxLength(
                free08,
                Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_08_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_08_NAME,
                      Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_08_LENGTH_STRING }));

    }

    String free09 = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_09_INDEX);
    // フリー項目9：文字種別チェック（低圧CISシステム許容文字）
    if (free09 != null
        && !CommonValidationUtil.isRangeWordByECIS(free09)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_09_NAME,
                      "低圧CISシステム許容文字" }));

      // フリー項目9：文字列最大長チェック
    } else if (free09 != null
        && !CommonValidationUtil
            .maxLength(
                free09,
                Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_09_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_09_NAME,
                      Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_09_LENGTH_STRING }));

    }

    String free10 = dataRecordMap
        .get(Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_10_INDEX);
    // フリー項目10：文字種別チェック（低圧CISシステム許容文字）
    if (free10 != null
        && !CommonValidationUtil.isRangeWordByECIS(free10)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_10_NAME,
                      "低圧CISシステム許容文字" }));

      // フリー項目10：文字列最大長チェック
    } else if (free10 != null
        && !CommonValidationUtil
            .maxLength(
                free10,
                Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_10_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_10_NAME,
                      Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_10_LENGTH_STRING }));

    }

    return messageList;
  }
}
