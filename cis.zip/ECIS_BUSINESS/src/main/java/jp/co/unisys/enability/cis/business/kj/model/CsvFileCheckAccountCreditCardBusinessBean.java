package jp.co.unisys.enability.cis.business.kj.model;

import java.io.File;
import java.util.List;
import java.util.Map;

/**
 * 口座クレカ情報CSVファイルチェックBusinessBean
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * 口座クレカ情報ビジネス
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class CsvFileCheckAccountCreditCardBusinessBean {

  /**
   * アップロードファイルを保有する。
   */
  private File uploadFile;

  /**
   * アップロードファイル名を保有する。
   */
  private String uploadFileName;

  /**
   * エラーリストを保有する。
   */
  private List<String> errorList;

  /**
   * 登録オブジェクトリストを保有する。
   */
  private List<Map<Integer, String>> registList;

  /**
   * アップロードファイルのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * アップロードファイルを取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return アップロードファイル
   */
  public File getUploadFile() {
    return this.uploadFile;
  }

  /**
   * アップロードファイルのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * アップロードファイルを設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param uploadFile
   *          アップロードファイル
   */
  public void setUploadFile(File uploadFile) {
    this.uploadFile = uploadFile;
  }

  /**
   * アップロードファイル名のgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * アップロードファイル名を取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return アップロードファイル名
   */
  public String getUploadFileName() {
    return this.uploadFileName;
  }

  /**
   * アップロードファイル名のsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * アップロードファイル名を設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param uploadFileName
   *          アップロードファイル名
   */
  public void setUploadFileName(String uploadFileName) {
    this.uploadFileName = uploadFileName;
  }

  /**
   * エラーリストのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * エラーリストを取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return エラーリスト
   */
  public List<String> getErrorList() {
    return this.errorList;
  }

  /**
   * エラーリストのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * エラーリストを設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param errorList
   *          エラーリスト
   */
  public void setErrorList(List<String> errorList) {
    this.errorList = errorList;
  }

  /**
   * 登録オブジェクトリストのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 登録オブジェクトリストを取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 登録オブジェクトリスト
   */
  public List<Map<Integer, String>> getRegistList() {
    return this.registList;
  }

  /**
   * 登録オブジェクトリストのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 登録オブジェクトリストを設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param registList
   *          登録オブジェクトリスト
   */
  public void setRegistList(List<Map<Integer, String>> registList) {
    this.registList = registList;
  }

}
