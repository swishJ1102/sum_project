package jp.co.unisys.enability.cis.business.kj.model;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import jp.co.unisys.enability.cis.entity.common.RmUp;
import jp.co.unisys.enability.cis.entity.common.RmUpDetail;

/**
 * 契約情報更新で、更新条件を格納するビジネスBean
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * 契約情報ビジネス
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class UpdateAgentContractBusinessBean {

  /**
   * 契約IDを保有する。
   */
  private Integer contractId;

  /**
   * 契約番号を保有する。
   */
  private String contractNo;

  /**
   * 支払IDを保有する。
   */
  private Integer paymentId;

  /**
   * 支払番号を保有する。
   */
  private String paymentNo;

  /**
   * 契約開始日を保有する。
   */
  private Date contractStartDate;

  /**
   * 契約終了日を保有する。
   */
  private Date contractEndDate;

  /**
   * 契約終了理由コードを保有する。
   */
  private String contractEndReasonCode;

  /**
   * 託送契約容量を保有する。
   */
  private BigDecimal consignmentContractCapacity;

  /**
   * 託送契約容量単位コードを保有する。
   */
  private String consignmentcontractCapacityUnitCode;

  /**
   * 託送契約容量判定日を保有する。
   */
  private Date consignmentContractCapacityDecisionDate;

  /**
   * 料金チェックフラグを保有する。
   */
  private String chargeCheckFlag;

  /**
   * 契約グループ番号を保有する。
   */
  private String contractGroupNo;

  /**
   * 連絡先個人・法人区分コードを保有する。
   */
  private String contactInformationinDividualLegalEntityCategoryCode;

  /**
   * 連絡先氏名（カナ）を保有する。
   */
  private String contractInformationNameKana;

  /**
   * 連絡先氏名1を保有する。
   */
  private String contractInformationName1;

  /**
   * 連絡先氏名2を保有する。
   */
  private String contractInformationName2;

  /**
   * 連絡先住所（郵便番号）を保有する。
   */
  private String contractInformationAddressPostalCode;

  /**
   * 連絡先住所（住所）を保有する。
   */
  private String contractInformationAddressFull;

  /**
   * 連絡先住所（建物・部屋名）を保有する。
   */
  private String contractInformationAddressBuilding;

  /**
   * 連絡先電話区分コードを保有する。
   */
  private String contractInformationCategoryCode;

  /**
   * 連絡先電話（市外局番）を保有する。
   */
  private String contractInformationAreaCode;

  /**
   * 連絡先電話（市内局番）を保有する。
   */
  private String contractInformationLocalNo;

  /**
   * 連絡先電話（加入者番号）を保有する。
   */
  private String contractInformationDirectoryNo;

  /**
   * 需要者窓口連絡先所属を保有する。
   */
  private String consumerContractAffiliation;

  /**
   * 需要者窓口連絡先氏名を保有する。
   */
  private String consumerContractName;

  /**
   * 需要者窓口連絡先電話番号（市外局番）を保有する。
   */
  private String consumerContractAreaCode;

  /**
   * 需要者窓口連絡先電話番号（市内局番）を保有する。
   */
  private String consumerContractLocalNo;

  /**
   * 需要者窓口連絡先電話番号（加入者番号）を保有する。
   */
  private String consumerContractDirectoryNo;

  /**
   * 主任技術者連絡先所属を保有する。
   */
  private String chiefEngineerOfficerAffiliation;

  /**
   * 主任技術者連絡先氏名を保有する。
   */
  private String chiefEngineerOfficerName;

  /**
   * 主任技術者連絡先電話番号（市外局番）を保有する。
   */
  private String chiefEngineerOfficerAreaCode;

  /**
   * 主任技術者連絡先電話番号（市内局番）を保有する。
   */
  private String chiefEngineerOfficerLocalNo;

  /**
   * 主任技術者連絡先電話番号（加入者番号）を保有する。
   */
  private String chiefEngineerOfficerDirectoryNo;

  /**
   * 接続送電サービス区分コードを保有する。
   */
  private String connectedSupplyServiceCategoryCode;

  /**
   * フリー項目1を保有する。
   */
  private String free1;

  /**
   * フリー項目2を保有する。
   */
  private String free2;

  /**
   * フリー項目3を保有する。
   */
  private String free3;

  /**
   * フリー項目4を保有する。
   */
  private String free4;

  /**
   * フリー項目5を保有する。
   */
  private String free5;

  /**
   * フリー項目6を保有する。
   */
  private String free6;

  /**
   * フリー項目7を保有する。
   */
  private String free7;

  /**
   * フリー項目8を保有する。
   */
  private String free8;

  /**
   * フリー項目9を保有する。
   */
  private String free9;

  /**
   * フリー項目10を保有する。
   */
  private String free10;

  /**
   * フリー項目11を保有する。
   */
  private String free11;

  /**
   * フリー項目12を保有する。
   */
  private String free12;

  /**
   * フリー項目13を保有する。
   */
  private String free13;

  /**
   * フリー項目14を保有する。
   */
  private String free14;

  /**
   * 業種コードを保有する。
   */
  private String businessTypeCode;

  /**
   * 営業委託先コードを保有する。
   */
  private String salesConsignmentCode;

  /**
   * 部分供給区分コードを保有する。
   */
  private String partialSupplyInformationCategoryCode;

  /**
   * 契約備考を保有する。
   */
  private String contractNote;

  /**
   * 実量歴必須フラグを保有する。
   */
  private String realQuantityNeed;

  /**
   * 実量歴取込済フラグを保有する。
   */
  private String realQuantityImportCompleteFlag;

  /**
   * 適用開始日を保有する。
   */
  private Date applyStartDate;

  /**
   * 料金メニューIDを保有する。
   */
  private String chargeMenuId;

  /**
   * 料金メニュー単価を保有する。
   */
  private RmUp rmUp;

  /**
   * 料金メニュー単価明細リストを保有する。
   */
  private List<RmUpDetail> rmUpDetailList;

  /**
   * 契約容量を保有する。
   */
  private BigDecimal contractCapacity;

  /**
   * 電圧区分コードを保有する。
   */
  private String voltageCatCode;

  /**
   * 契約電力決定区分コードを保有する。
   */
  private String ccDecisionCategoryCode;

  /**
   * 単価設定区分コードを保有する。
   */
  private String upCatCode;

  /**
   * 契約変更理由を保有する。
   */
  private String contractChangeReason;

  /**
   * 委託先使用項目1を保有する。
   */
  private String consignmentUseItem1;

  /**
   * 委託先使用項目2を保有する。
   */
  private String consignmentUseItem2;

  /**
   * 委託先使用項目3を保有する。
   */
  private String consignmentUseItem3;

  /**
   * 自社担当者コードを保有する。
   */
  private String ourManagementPersonInChargeCode;

  /**
   * 自社部署コードを保有する。
   */
  private String ourManagementDepartmentCode;

  /**
   * 卸取次店契約番号を保有する。
   */
  private String agentContractNo;

  /**
   * 契約フリー項目1を保有する。
   */
  private String contractFree1;

  /**
   * 契約フリー項目2を保有する。
   */
  private String contractFree2;

  /**
   * 契約フリー項目3を保有する。
   */
  private String contractFree3;

  /**
   * 契約フリー項目4を保有する。
   */
  private String contractFree4;

  /**
   * 契約フリー項目5を保有する。
   */
  private String contractFree5;

  /**
   * 契約フリー項目6を保有する。
   */
  private String contractFree6;

  /**
   * 契約フリー項目7を保有する。
   */
  private String contractFree7;

  /**
   * 契約フリー項目8を保有する。
   */
  private String contractFree8;

  /**
   * 契約フリー項目9を保有する。
   */
  private String contractFree9;

  /**
   * 契約フリー項目10を保有する。
   */
  private String contractFree10;

  /**
   * 更新回数を保有する。
   */
  private Integer updateCount;

  /**
   * リターンコードを保有する。
   */
  private String returnCode;

  /**
   * メッセージを保有する。
   */
  private String message;

  /**
   * 託送契約容量フラグ
   */
  private String consignmentContractCapacityNoUpdFlag;

  /**
   * 託送契約容量判定日フラグ
   */
  private String consignmentContractCapacityDecisionDateNoUpdFlag;

  /**
   * 契約容量フラグ
   */
  private String contractCapacityNoUpdFlag;

  /**
   * 契約IDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約IDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約ID
   */
  public Integer getContractId() {
    return this.contractId;
  }

  /**
   * 契約IDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約IDを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractId
   *          契約ID
   */
  public void setContractId(Integer contractId) {
    this.contractId = contractId;
  }

  /**
   * 契約番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約番号を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約番号
   */
  public String getContractNo() {
    return this.contractNo;
  }

  /**
   * 契約番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約番号を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractNo
   *          契約番号
   */
  public void setContractNo(String contractNo) {
    this.contractNo = contractNo;
  }

  /**
   * 支払IDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 支払IDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 支払ID
   */
  public Integer getPaymentId() {
    return this.paymentId;
  }

  /**
   * 支払IDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 支払IDを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param paymentId
   *          支払ID
   */
  public void setPaymentId(Integer paymentId) {
    this.paymentId = paymentId;
  }

  /**
   * 支払番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 支払番号を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 支払番号
   */
  public String getPaymentNo() {
    return this.paymentNo;
  }

  /**
   * 支払番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 支払番号を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param paymentNo
   *          支払番号
   */
  public void setPaymentNo(String paymentNo) {
    this.paymentNo = paymentNo;
  }

  /**
   * 契約開始日のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約開始日を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約開始日
   */
  public Date getContractStartDate() {
    return this.contractStartDate;
  }

  /**
   * 契約開始日のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約開始日を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractStartDate
   *          契約開始日
   */
  public void setContractStartDate(Date contractStartDate) {
    this.contractStartDate = contractStartDate;
  }

  /**
   * 契約終了日のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約終了日を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約終了日
   */
  public Date getContractEndDate() {
    return this.contractEndDate;
  }

  /**
   * 契約終了日のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約終了日を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractEndDate
   *          契約終了日
   */
  public void setContractEndDate(Date contractEndDate) {
    this.contractEndDate = contractEndDate;
  }

  /**
   * 契約終了理由コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約終了理由コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約終了理由コード
   */
  public String getContractEndReasonCode() {
    return this.contractEndReasonCode;
  }

  /**
   * 契約終了理由コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約終了理由コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractEndReasonCode
   *          契約終了理由コード
   */
  public void setContractEndReasonCode(String contractEndReasonCode) {
    this.contractEndReasonCode = contractEndReasonCode;
  }

  /**
   * 託送契約容量のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 託送契約容量を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 託送契約容量
   */
  public BigDecimal getConsignmentContractCapacity() {
    return this.consignmentContractCapacity;
  }

  /**
   * 託送契約容量のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 託送契約容量を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param consignmentContractCapacity
   *          託送契約容量
   */
  public void setConsignmentContractCapacity(
      BigDecimal consignmentContractCapacity) {
    this.consignmentContractCapacity = consignmentContractCapacity;
  }

  /**
   * 託送契約容量単位コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 託送契約容量単位コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 託送契約容量単位コード
   */
  public String getConsignmentcontractCapacityUnitCode() {
    return this.consignmentcontractCapacityUnitCode;
  }

  /**
   * 託送契約容量単位コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 託送契約容量単位コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param consignmentcontractCapacityUnitCode
   *          託送契約容量単位コード
   */
  public void setConsignmentcontractCapacityUnitCode(
      String consignmentcontractCapacityUnitCode) {
    this.consignmentcontractCapacityUnitCode = consignmentcontractCapacityUnitCode;
  }

  /**
   * 託送契約容量判定日のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 託送契約容量判定日を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 託送契約容量判定日
   */
  public Date getConsignmentContractCapacityDecisionDate() {
    return this.consignmentContractCapacityDecisionDate;
  }

  /**
   * 託送契約容量判定日のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 託送契約容量判定日を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param consignmentContractCapacityDecisionDate
   *          託送契約容量判定日
   */
  public void setConsignmentContractCapacityDecisionDate(
      Date consignmentContractCapacityDecisionDate) {
    this.consignmentContractCapacityDecisionDate = consignmentContractCapacityDecisionDate;
  }

  /**
   * 料金チェックフラグのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金チェックフラグを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 料金チェックフラグ
   */
  public String getChargeCheckFlag() {
    return this.chargeCheckFlag;
  }

  /**
   * 料金チェックフラグのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金チェックフラグを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param chargeCheckFlag
   *          料金チェックフラグ
   */
  public void setChargeCheckFlag(String chargeCheckFlag) {
    this.chargeCheckFlag = chargeCheckFlag;
  }

  /**
   * 契約グループ番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約グループ番号を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約グループ番号
   */
  public String getContractGroupNo() {
    return this.contractGroupNo;
  }

  /**
   * 契約グループ番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約グループ番号を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractGroupNo
   *          契約グループ番号
   */
  public void setContractGroupNo(String contractGroupNo) {
    this.contractGroupNo = contractGroupNo;
  }

  /**
   * 連絡先個人・法人区分コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先個人・法人区分コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 連絡先個人・法人区分コード
   */
  public String getContactInformationinDividualLegalEntityCategoryCode() {
    return this.contactInformationinDividualLegalEntityCategoryCode;
  }

  /**
   * 連絡先個人・法人区分コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先個人・法人区分コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contactInformationinDividualLegalEntityCategoryCode
   *          連絡先個人・法人区分コード
   */
  public void setContactInformationinDividualLegalEntityCategoryCode(
      String contactInformationinDividualLegalEntityCategoryCode) {
    this.contactInformationinDividualLegalEntityCategoryCode = contactInformationinDividualLegalEntityCategoryCode;
  }

  /**
   * 連絡先氏名（カナ）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先氏名（カナ）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 連絡先氏名（カナ）
   */
  public String getContractInformationNameKana() {
    return this.contractInformationNameKana;
  }

  /**
   * 連絡先氏名（カナ）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先氏名（カナ）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractInformationNameKana
   *          連絡先氏名（カナ）
   */
  public void setContractInformationNameKana(
      String contractInformationNameKana) {
    this.contractInformationNameKana = contractInformationNameKana;
  }

  /**
   * 連絡先氏名1のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先氏名1を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 連絡先氏名1
   */
  public String getContractInformationName1() {
    return this.contractInformationName1;
  }

  /**
   * 連絡先氏名1のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先氏名1を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractInformationName1
   *          連絡先氏名1
   */
  public void setContractInformationName1(String contractInformationName1) {
    this.contractInformationName1 = contractInformationName1;
  }

  /**
   * 連絡先氏名2のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先氏名2を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 連絡先氏名2
   */
  public String getContractInformationName2() {
    return this.contractInformationName2;
  }

  /**
   * 連絡先氏名2のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先氏名2を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractInformationName2
   *          連絡先氏名2
   */
  public void setContractInformationName2(String contractInformationName2) {
    this.contractInformationName2 = contractInformationName2;
  }

  /**
   * 連絡先住所（郵便番号）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先住所（郵便番号）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 連絡先住所（郵便番号）
   */
  public String getContractInformationAddressPostalCode() {
    return this.contractInformationAddressPostalCode;
  }

  /**
   * 連絡先住所（郵便番号）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先住所（郵便番号）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractInformationAddressPostalCode
   *          連絡先住所（郵便番号）
   */
  public void setContractInformationAddressPostalCode(
      String contractInformationAddressPostalCode) {
    this.contractInformationAddressPostalCode = contractInformationAddressPostalCode;
  }

  /**
   * 連絡先住所（住所）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先住所（住所）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 連絡先住所（住所）
   */
  public String getContractInformationAddressFull() {
    return this.contractInformationAddressFull;
  }

  /**
   * 連絡先住所（住所）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先住所（住所）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractInformationAddressFull
   *          連絡先住所（住所）
   */
  public void setContractInformationAddressFull(
      String contractInformationAddressFull) {
    this.contractInformationAddressFull = contractInformationAddressFull;
  }

  /**
   * 連絡先住所（建物・部屋名）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先住所（建物・部屋名）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 連絡先住所（建物・部屋名）
   */
  public String getContractInformationAddressBuilding() {
    return this.contractInformationAddressBuilding;
  }

  /**
   * 連絡先住所（建物・部屋名）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先住所（建物・部屋名）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractInformationAddressBuilding
   *          連絡先住所（建物・部屋名）
   */
  public void setContractInformationAddressBuilding(
      String contractInformationAddressBuilding) {
    this.contractInformationAddressBuilding = contractInformationAddressBuilding;
  }

  /**
   * 連絡先電話区分コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先電話区分コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 連絡先電話区分コード
   */
  public String getContractInformationCategoryCode() {
    return this.contractInformationCategoryCode;
  }

  /**
   * 連絡先電話区分コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先電話区分コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractInformationCategoryCode
   *          連絡先電話区分コード
   */
  public void setContractInformationCategoryCode(
      String contractInformationCategoryCode) {
    this.contractInformationCategoryCode = contractInformationCategoryCode;
  }

  /**
   * 連絡先電話（市外局番）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先電話（市外局番）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 連絡先電話（市外局番）
   */
  public String getContractInformationAreaCode() {
    return this.contractInformationAreaCode;
  }

  /**
   * 連絡先電話（市外局番）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先電話（市外局番）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractInformationAreaCode
   *          連絡先電話（市外局番）
   */
  public void setContractInformationAreaCode(
      String contractInformationAreaCode) {
    this.contractInformationAreaCode = contractInformationAreaCode;
  }

  /**
   * 連絡先電話（市内局番）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先電話（市内局番）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 連絡先電話（市内局番）
   */
  public String getContractInformationLocalNo() {
    return this.contractInformationLocalNo;
  }

  /**
   * 連絡先電話（市内局番）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先電話（市内局番）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractInformationLocalNo
   *          連絡先電話（市内局番）
   */
  public void setContractInformationLocalNo(String contractInformationLocalNo) {
    this.contractInformationLocalNo = contractInformationLocalNo;
  }

  /**
   * 連絡先電話（加入者番号）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先電話（加入者番号）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 連絡先電話（加入者番号）
   */
  public String getContractInformationDirectoryNo() {
    return this.contractInformationDirectoryNo;
  }

  /**
   * 連絡先電話（加入者番号）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先電話（加入者番号）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractInformationDirectoryNo
   *          連絡先電話（加入者番号）
   */
  public void setContractInformationDirectoryNo(
      String contractInformationDirectoryNo) {
    this.contractInformationDirectoryNo = contractInformationDirectoryNo;
  }

  /**
   * 需要者窓口連絡先所属のgetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 需要者窓口連絡先所属を取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 需要者窓口連絡先所属
   */
  public String getConsumerContractAffiliation() {
    return this.consumerContractAffiliation;
  }

  /**
   * 需要者窓口連絡先所属のsetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 需要者窓口連絡先所属を設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param consumerContractAffiliation
   *          需要者窓口連絡先所属
   */
  public void setConsumerContractAffiliation(String consumerContractAffiliation) {
    this.consumerContractAffiliation = consumerContractAffiliation;
  }

  /**
   * 需要者窓口連絡先氏名のgetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 需要者窓口連絡先氏名を取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 需要者窓口連絡先氏名
   */
  public String getConsumerContractName() {
    return this.consumerContractName;
  }

  /**
   * 需要者窓口連絡先氏名のsetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 需要者窓口連絡先氏名を設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param consumerContractName
   *          需要者窓口連絡先氏名
   */
  public void setConsumerContractName(String consumerContractName) {
    this.consumerContractName = consumerContractName;
  }

  /**
   * 需要者窓口連絡先電話番号（市外局番）のgetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 需要者窓口連絡先電話番号（市外局番）を取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 需要者窓口連絡先電話番号（市外局番）
   */
  public String getConsumerContractAreaCode() {
    return this.consumerContractAreaCode;
  }

  /**
   * 需要者窓口連絡先電話番号（市外局番）のsetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 需要者窓口連絡先電話番号（市外局番）を設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param consumerContractAreaCode
   *          需要者窓口連絡先電話番号（市外局番）
   */
  public void setConsumerContractAreaCode(String consumerContractAreaCode) {
    this.consumerContractAreaCode = consumerContractAreaCode;
  }

  /**
   * 需要者窓口連絡先電話番号（市内局番）のgetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 需要者窓口連絡先電話番号（市内局番）を取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 需要者窓口連絡先電話番号（市内局番）
   */
  public String getConsumerContractLocalNo() {
    return this.consumerContractLocalNo;
  }

  /**
   * 需要者窓口連絡先電話番号（市内局番）のsetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 需要者窓口連絡先電話番号（市内局番）を設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param consumerContractLocalNo
   *          需要者窓口連絡先電話番号（市内局番）
   */
  public void setConsumerContractLocalNo(String consumerContractLocalNo) {
    this.consumerContractLocalNo = consumerContractLocalNo;
  }

  /**
   * 需要者窓口連絡先電話番号（加入者番号）のgetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 需要者窓口連絡先電話番号（加入者番号）を取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 需要者窓口連絡先電話番号（加入者番号）
   */
  public String getConsumerContractDirectoryNo() {
    return this.consumerContractDirectoryNo;
  }

  /**
   * 需要者窓口連絡先電話番号（加入者番号）のsetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 需要者窓口連絡先電話番号（加入者番号）を設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param consumerContractDirectoryNo
   *          需要者窓口連絡先電話番号（加入者番号）
   */
  public void setConsumerContractDirectoryNo(String consumerContractDirectoryNo) {
    this.consumerContractDirectoryNo = consumerContractDirectoryNo;
  }

  /**
   * 主任技術者連絡先所属のgetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 主任技術者連絡先所属を取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 主任技術者連絡先所属
   */
  public String getChiefEngineerOfficerAffiliation() {
    return this.chiefEngineerOfficerAffiliation;
  }

  /**
   * 主任技術者連絡先所属のsetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 主任技術者連絡先所属を設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param chiefEngineerOfficerAffiliation
   *          主任技術者連絡先所属
   */
  public void setChiefEngineerOfficerAffiliation(String chiefEngineerOfficerAffiliation) {
    this.chiefEngineerOfficerAffiliation = chiefEngineerOfficerAffiliation;
  }

  /**
   * 主任技術者連絡先氏名のgetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 主任技術者連絡先氏名を取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 主任技術者連絡先氏名
   */
  public String getChiefEngineerOfficerName() {
    return this.chiefEngineerOfficerName;
  }

  /**
   * 主任技術者連絡先氏名のsetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 主任技術者連絡先氏名を設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param chiefEngineerOfficerName
   *          主任技術者連絡先氏名
   */
  public void setChiefEngineerOfficerName(String chiefEngineerOfficerName) {
    this.chiefEngineerOfficerName = chiefEngineerOfficerName;
  }

  /**
   * 主任技術者連絡先電話番号（市外局番）のgetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 主任技術者連絡先電話番号（市外局番）を取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 主任技術者連絡先電話番号（市外局番）
   */
  public String getChiefEngineerOfficerAreaCode() {
    return this.chiefEngineerOfficerAreaCode;
  }

  /**
   * 主任技術者連絡先電話番号（市外局番）のsetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 主任技術者連絡先電話番号（市外局番）を設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param chiefEngineerOfficerAreaCode
   *          主任技術者連絡先電話番号（市外局番）
   */
  public void setChiefEngineerOfficerAreaCode(String chiefEngineerOfficerAreaCode) {
    this.chiefEngineerOfficerAreaCode = chiefEngineerOfficerAreaCode;
  }

  /**
   * 主任技術者連絡先電話番号（市内局番）のgetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 主任技術者連絡先電話番号（市内局番）を取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 主任技術者連絡先電話番号（市内局番）
   */
  public String getChiefEngineerOfficerLocalNo() {
    return this.chiefEngineerOfficerLocalNo;
  }

  /**
   * 主任技術者連絡先電話番号（市内局番）のsetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 主任技術者連絡先電話番号（市内局番）を設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param chiefEngineerOfficerLocalNo
   *          主任技術者連絡先電話番号（市内局番）
   */
  public void setChiefEngineerOfficerLocalNo(String chiefEngineerOfficerLocalNo) {
    this.chiefEngineerOfficerLocalNo = chiefEngineerOfficerLocalNo;
  }

  /**
   * 主任技術者連絡先電話番号（加入者番号）のgetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 主任技術者連絡先電話番号（加入者番号）を取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 主任技術者連絡先電話番号（加入者番号）
   */
  public String getChiefEngineerOfficerDirectoryNo() {
    return this.chiefEngineerOfficerDirectoryNo;
  }

  /**
   * 主任技術者連絡先電話番号（加入者番号）のsetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 主任技術者連絡先電話番号（加入者番号）を設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param chiefEngineerOfficerDirectoryNo
   *          主任技術者連絡先電話番号（加入者番号）
   */
  public void setChiefEngineerOfficerDirectoryNo(String chiefEngineerOfficerDirectoryNo) {
    this.chiefEngineerOfficerDirectoryNo = chiefEngineerOfficerDirectoryNo;
  }

  /**
   * 接続送電サービス区分コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 接続送電サービス区分コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 接続送電サービス区分コード
   */
  public String getConnectedSupplyServiceCategoryCode() {
    return this.connectedSupplyServiceCategoryCode;
  }

  /**
   * 接続送電サービス区分コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 接続送電サービス区分コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param connectedSupplyServiceCategoryCode
   *          接続送電サービス区分コード
   */
  public void setConnectedSupplyServiceCategoryCode(
      String connectedSupplyServiceCategoryCode) {
    this.connectedSupplyServiceCategoryCode = connectedSupplyServiceCategoryCode;
  }

  /**
   * フリー項目1のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * フリー項目1を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return フリー項目1
   */
  public String getFree1() {
    return this.free1;
  }

  /**
   * フリー項目1のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * フリー項目1を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param free1
   *          フリー項目1
   */
  public void setFree1(String free1) {
    this.free1 = free1;
  }

  /**
   * フリー項目2のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * フリー項目2を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return フリー項目2
   */
  public String getFree2() {
    return this.free2;
  }

  /**
   * フリー項目2のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * フリー項目2を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param free2
   *          フリー項目2
   */
  public void setFree2(String free2) {
    this.free2 = free2;
  }

  /**
   * フリー項目3のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * フリー項目3を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return フリー項目3
   */
  public String getFree3() {
    return this.free3;
  }

  /**
   * フリー項目3のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * フリー項目3を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param free3
   *          フリー項目3
   */
  public void setFree3(String free3) {
    this.free3 = free3;
  }

  /**
   * フリー項目4のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * フリー項目4を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return フリー項目4
   */
  public String getFree4() {
    return this.free4;
  }

  /**
   * フリー項目4のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * フリー項目4を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param free4
   *          フリー項目4
   */
  public void setFree4(String free4) {
    this.free4 = free4;
  }

  /**
   * フリー項目5のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * フリー項目5を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return フリー項目5
   */
  public String getFree5() {
    return this.free5;
  }

  /**
   * フリー項目5のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * フリー項目5を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param free5
   *          フリー項目5
   */
  public void setFree5(String free5) {
    this.free5 = free5;
  }

  /**
   * フリー項目6のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * フリー項目6を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return フリー項目6
   */
  public String getFree6() {
    return this.free6;
  }

  /**
   * フリー項目6のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * フリー項目6を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param free6
   *          フリー項目6
   */
  public void setFree6(String free6) {
    this.free6 = free6;
  }

  /**
   * フリー項目7のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * フリー項目7を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return フリー項目7
   */
  public String getFree7() {
    return this.free7;
  }

  /**
   * フリー項目7のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * フリー項目7を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param free7
   *          フリー項目7
   */
  public void setFree7(String free7) {
    this.free7 = free7;
  }

  /**
   * フリー項目8のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * フリー項目8を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return フリー項目8
   */
  public String getFree8() {
    return this.free8;
  }

  /**
   * フリー項目8のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * フリー項目8を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param free8
   *          フリー項目8
   */
  public void setFree8(String free8) {
    this.free8 = free8;
  }

  /**
   * フリー項目9のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * フリー項目9を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return フリー項目9
   */
  public String getFree9() {
    return this.free9;
  }

  /**
   * フリー項目9のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * フリー項目9を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param free9
   *          フリー項目9
   */
  public void setFree9(String free9) {
    this.free9 = free9;
  }

  /**
   * フリー項目10のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * フリー項目10を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return フリー項目10
   */
  public String getFree10() {
    return this.free10;
  }

  /**
   * フリー項目10のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * フリー項目10を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param free10
   *          フリー項目10
   */
  public void setFree10(String free10) {
    this.free10 = free10;
  }

  /**
   * フリー項目11のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * フリー項目11を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return フリー項目11
   */
  public String getFree11() {
    return this.free11;
  }

  /**
   * フリー項目11のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * フリー項目11を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param free11
   *          フリー項目11
   */
  public void setFree11(String free11) {
    this.free11 = free11;
  }

  /**
   * フリー項目12のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * フリー項目12を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return フリー項目12
   */
  public String getFree12() {
    return this.free12;
  }

  /**
   * フリー項目12のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * フリー項目12を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param free12
   *          フリー項目12
   */
  public void setFree12(String free12) {
    this.free12 = free12;
  }

  /**
   * フリー項目13のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * フリー項目13を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return フリー項目13
   */
  public String getFree13() {
    return this.free13;
  }

  /**
   * フリー項目13のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * フリー項目13を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param free13
   *          フリー項目13
   */
  public void setFree13(String free13) {
    this.free13 = free13;
  }

  /**
   * フリー項目14のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * フリー項目14を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return フリー項目14
   */
  public String getFree14() {
    return this.free14;
  }

  /**
   * フリー項目14のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * フリー項目14を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param free14
   *          フリー項目14
   */
  public void setFree14(String free14) {
    this.free14 = free14;
  }

  /**
   * 業種コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 業種コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 業種コード
   */
  public String getBusinessTypeCode() {
    return this.businessTypeCode;
  }

  /**
   * 業種コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 業種コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param businessTypeCode
   *          業種コード
   */
  public void setBusinessTypeCode(String businessTypeCode) {
    this.businessTypeCode = businessTypeCode;
  }

  /**
   * 営業委託先コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 営業委託先コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 営業委託先コード
   */
  public String getSalesConsignmentCode() {
    return this.salesConsignmentCode;
  }

  /**
   * 営業委託先コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 営業委託先コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param salesConsignmentCode
   *          営業委託先コード
   */
  public void setSalesConsignmentCode(String salesConsignmentCode) {
    this.salesConsignmentCode = salesConsignmentCode;
  }

  /**
   * 部分供給区分コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 部分供給区分コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 部分供給区分コード
   */
  public String getPartialSupplyInformationCategoryCode() {
    return partialSupplyInformationCategoryCode;
  }

  /**
   * 部分供給区分コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 部分供給区分コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param partialSupplyInformationCategoryCode
   *          部分供給区分コード
   */
  public void setPartialSupplyInformationCategoryCode(String partialSupplyInformationCategoryCode) {
    this.partialSupplyInformationCategoryCode = partialSupplyInformationCategoryCode;
  }

  /**
   * 契約備考のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約備考を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約備考
   */
  public String getContractNote() {
    return this.contractNote;
  }

  /**
   * 契約備考のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約備考を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractNote
   *          契約備考
   */
  public void setContractNote(String contractNote) {
    this.contractNote = contractNote;
  }

  /**
   * 実量歴必須フラグのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 実量歴必須フラグを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 実量歴必須フラグ
   */
  public String getRealQuantityNeed() {
    return realQuantityNeed;
  }

  /**
   * 実量歴必須フラグのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 実量歴必須フラグを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param realQuantityNeed
   *          実量歴必須フラグ
   */
  public void setRealQuantityNeed(String realQuantityNeed) {
    this.realQuantityNeed = realQuantityNeed;
  }

  /**
   * 実量歴取込済フラグのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 実量歴取込済フラグを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 実量歴取込済フラグ
   */
  public String getRealQuantityImportCompleteFlag() {
    return realQuantityImportCompleteFlag;
  }

  /**
   * 実量歴取込済フラグのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 実量歴取込済フラグを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param realQuantityImportCompleteFlag
   *          実量歴取込済フラグ
   */
  public void setRealQuantityImportCompleteFlag(
      String realQuantityImportCompleteFlag) {
    this.realQuantityImportCompleteFlag = realQuantityImportCompleteFlag;
  }

  /**
   * 適用開始日のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 適用開始日を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 適用開始日
   */
  public Date getApplyStartDate() {
    return this.applyStartDate;
  }

  /**
   * 適用開始日のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 適用開始日を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param applyStartDate
   *          適用開始日
   */
  public void setApplyStartDate(Date applyStartDate) {
    this.applyStartDate = applyStartDate;
  }

  /**
   * 料金メニューIDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金メニューIDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 料金メニューID
   */
  public String getChargeMenuId() {
    return this.chargeMenuId;
  }

  /**
   * 料金メニューIDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金メニューIDを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param chargeMenuId
   *          料金メニューID
   */
  public void setChargeMenuId(String chargeMenuId) {
    this.chargeMenuId = chargeMenuId;
  }

  /**
   * 料金メニュー単価のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金メニュー単価を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 料金メニュー単価
   */
  public RmUp getRmUp() {
    return rmUp;
  }

  /**
   * 料金メニュー単価のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金メニュー単価を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param rmUp
   *          料金メニュー単価
   */
  public void setRmUp(RmUp rmUp) {
    this.rmUp = rmUp;
  }

  /**
   * 料金メニュー単価明細リストのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金メニュー単価明細リストを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 料金メニュー単価明細リスト
   */
  public List<RmUpDetail> getRmUpDetailList() {
    return rmUpDetailList;
  }

  /**
   * 料金メニュー単価明細リストのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金メニュー単価明細リストを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param rmUpDetailList
   *          料金メニュー単価明細リスト
   */
  public void setRmUpDetailList(List<RmUpDetail> rmUpDetailList) {
    this.rmUpDetailList = rmUpDetailList;
  }

  /**
   * 契約容量のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約容量を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約容量
   */
  public BigDecimal getContractCapacity() {
    return this.contractCapacity;
  }

  /**
   * 契約容量のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約容量を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractCapacity
   *          契約容量
   */
  public void setContractCapacity(BigDecimal contractCapacity) {
    this.contractCapacity = contractCapacity;
  }

  /**
   * 電圧区分コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 電圧区分コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 電圧区分コード
   */
  public String getVoltageCatCode() {
    return voltageCatCode;
  }

  /**
   * 電圧区分コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 電圧区分コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param voltageCatCode
   *          電圧区分コード
   */
  public void setVoltageCatCode(String voltageCatCode) {
    this.voltageCatCode = voltageCatCode;
  }

  /**
   * 契約電力決定区分コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約電力決定区分コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約電力決定区分コード
   */
  public String getCcDecisionCategoryCode() {
    return ccDecisionCategoryCode;
  }

  /**
   * 契約電力決定区分コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約電力決定区分コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param ccDecisionCategoryCode
   *          契約電力決定区分コード
   */
  public void setCcDecisionCategoryCode(String ccDecisionCategoryCode) {
    this.ccDecisionCategoryCode = ccDecisionCategoryCode;
  }

  /**
   * 単価設定区分コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 単価設定区分コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 単価設定区分コード
   */
  public String getUpCatCode() {
    return upCatCode;
  }

  /**
   * 単価設定区分コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 単価設定区分コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param upCatCode
   *          単価設定区分コード
   */
  public void setUpCatCode(String upCatCode) {
    this.upCatCode = upCatCode;
  }

  /**
   * 契約変更理由のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約変更理由を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約変更理由
   */
  public String getContractChangeReason() {
    return this.contractChangeReason;
  }

  /**
   * 契約変更理由のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約変更理由を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractChangeReason
   *          契約変更理由
   */
  public void setContractChangeReason(String contractChangeReason) {
    this.contractChangeReason = contractChangeReason;
  }

  /**
   * 委託先使用項目1のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 委託先使用項目1を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 委託先使用項目1
   */
  public String getConsignmentUseItem1() {
    return this.consignmentUseItem1;
  }

  /**
   * 委託先使用項目1のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 委託先使用項目1を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param consignmentUseItem1
   *          委託先使用項目1
   */
  public void setConsignmentUseItem1(String consignmentUseItem1) {
    this.consignmentUseItem1 = consignmentUseItem1;
  }

  /**
   * 委託先使用項目2のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 委託先使用項目2を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 委託先使用項目2
   */
  public String getConsignmentUseItem2() {
    return this.consignmentUseItem2;
  }

  /**
   * 委託先使用項目2のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 委託先使用項目2を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param consignmentUseItem2
   *          委託先使用項目2
   */
  public void setConsignmentUseItem2(String consignmentUseItem2) {
    this.consignmentUseItem2 = consignmentUseItem2;
  }

  /**
   * 委託先使用項目3のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 委託先使用項目3を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 委託先使用項目3
   */
  public String getConsignmentUseItem3() {
    return this.consignmentUseItem3;
  }

  /**
   * 委託先使用項目3のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 委託先使用項目3を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param consignmentUseItem3
   *          委託先使用項目3
   */
  public void setConsignmentUseItem3(String consignmentUseItem3) {
    this.consignmentUseItem3 = consignmentUseItem3;
  }

  /**
   * 自社担当者コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 自社担当者コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 自社担当者コード
   */
  public String getOurManagementPersonInChargeCode() {
    return this.ourManagementPersonInChargeCode;
  }

  /**
   * 自社担当者コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 自社担当者コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param ourManagementPersonInChargeCode
   *          自社担当者コード
   */
  public void setOurManagementPersonInChargeCode(
      String ourManagementPersonInChargeCode) {
    this.ourManagementPersonInChargeCode = ourManagementPersonInChargeCode;
  }

  /**
   * 自社部署コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 自社部署コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 自社部署コード
   */
  public String getOurManagementDepartmentCode() {
    return this.ourManagementDepartmentCode;
  }

  /**
   * 自社部署コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 自社部署コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param ourManagementDepartmentCode
   *          自社部署コード
   */
  public void setOurManagementDepartmentCode(
      String ourManagementDepartmentCode) {
    this.ourManagementDepartmentCode = ourManagementDepartmentCode;
  }

  /**
   * 卸取次店契約番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 卸取次店契約番号を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 卸取次店契約番号
   */
  public String getAgentContractNo() {
    return agentContractNo;
  }

  /**
   * 卸取次店契約番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 卸取次店契約番号を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param agentContractNo
   *          卸取次店契約番号
   */
  public void setAgentContractNo(String agentContractNo) {
    this.agentContractNo = agentContractNo;
  }

  /**
   * 契約フリー項目1のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約フリー項目1を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約フリー項目1
   */
  public String getContractFree1() {
    return contractFree1;
  }

  /**
   * 契約フリー項目1のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約フリー項目1を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractFree1
   *          契約フリー項目1
   */
  public void setContractFree1(String contractFree1) {
    this.contractFree1 = contractFree1;
  }

  /**
   * 契約フリー項目2のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約フリー項目2を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約フリー項目2
   */
  public String getContractFree2() {
    return contractFree2;
  }

  /**
   * 契約フリー項目2のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約フリー項目2を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractFree2
   *          契約フリー項目2
   */
  public void setContractFree2(String contractFree2) {
    this.contractFree2 = contractFree2;
  }

  /**
   * 契約フリー項目3のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約フリー項目3を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約フリー項目3
   */
  public String getContractFree3() {
    return contractFree3;
  }

  /**
   * 契約フリー項目3のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約フリー項目3を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractFree3
   *          契約フリー項目3
   */
  public void setContractFree3(String contractFree3) {
    this.contractFree3 = contractFree3;
  }

  /**
   * 契約フリー項目4のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約フリー項目4を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約フリー項目4
   */
  public String getContractFree4() {
    return contractFree4;
  }

  /**
   * 契約フリー項目4のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約フリー項目4を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractFree4
   *          契約フリー項目4
   */
  public void setContractFree4(String contractFree4) {
    this.contractFree4 = contractFree4;
  }

  /**
   * 契約フリー項目5のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約フリー項目5を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約フリー項目5
   */
  public String getContractFree5() {
    return contractFree5;
  }

  /**
   * 契約フリー項目5のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約フリー項目5を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractFree5
   *          契約フリー項目5
   */
  public void setContractFree5(String contractFree5) {
    this.contractFree5 = contractFree5;
  }

  /**
   * 契約フリー項目6のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約フリー項目6を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約フリー項目6
   */
  public String getContractFree6() {
    return contractFree6;
  }

  /**
   * 契約フリー項目6のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約フリー項目6を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractFree6
   *          契約フリー項目6
   */
  public void setContractFree6(String contractFree6) {
    this.contractFree6 = contractFree6;
  }

  /**
   * 契約フリー項目7のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約フリー項目7を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約フリー項目7
   */
  public String getContractFree7() {
    return contractFree7;
  }

  /**
   * 契約フリー項目7のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約フリー項目7を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractFree7
   *          契約フリー項目7
   */
  public void setContractFree7(String contractFree7) {
    this.contractFree7 = contractFree7;
  }

  /**
   * 契約フリー項目8のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約フリー項目8を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約フリー項目8
   */
  public String getContractFree8() {
    return contractFree8;
  }

  /**
   * 契約フリー項目8のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約フリー項目8を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractFree8
   *          契約フリー項目8
   */
  public void setContractFree8(String contractFree8) {
    this.contractFree8 = contractFree8;
  }

  /**
   * 契約フリー項目9 のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約フリー項目9を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約フリー項目9
   */
  public String getContractFree9() {
    return contractFree9;
  }

  /**
   * 契約フリー項目9のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約フリー項目9を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractFree9
   *          契約フリー項目9
   */
  public void setContractFree9(String contractFree9) {
    this.contractFree9 = contractFree9;
  }

  /**
   * 契約フリー項目10のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約フリー項目10を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約フリー項目10
   */
  public String getContractFree10() {
    return contractFree10;
  }

  /**
   * 契約フリー項目10のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約フリー項目10を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractFree10
   *          契約フリー項目10
   */
  public void setContractFree10(String contractFree10) {
    this.contractFree10 = contractFree10;
  }

  /**
   * 更新回数のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 更新回数を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 更新回数
   */
  public Integer getUpdateCount() {
    return this.updateCount;
  }

  /**
   * 更新回数のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 更新回数を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param updateCount
   *          更新回数
   */
  public void setUpdateCount(Integer updateCount) {
    this.updateCount = updateCount;
  }

  /**
   * リターンコードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return リターンコード
   */
  public String getReturnCode() {
    return this.returnCode;
  }

  /**
   * リターンコードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param returnCode
   *          リターンコード
   */
  public void setReturnCode(String returnCode) {
    this.returnCode = returnCode;
  }

  /**
   * メッセージのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return メッセージ
   */
  public String getMessage() {
    return this.message;
  }

  /**
   * メッセージのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param message
   *          メッセージ
   */
  public void setMessage(String message) {
    this.message = message;
  }

  public String getConsignmentContractCapacityNoUpdFlag() {
    return consignmentContractCapacityNoUpdFlag;
  }

  public void setConsignmentContractCapacityNoUpdFlag(
      String consignmentContractCapacityNoUpdFlag) {
    this.consignmentContractCapacityNoUpdFlag = consignmentContractCapacityNoUpdFlag;
  }

  public String getConsignmentContractCapacityDecisionDateNoUpdFlag() {
    return consignmentContractCapacityDecisionDateNoUpdFlag;
  }

  public void setConsignmentContractCapacityDecisionDateNoUpdFlag(
      String consignmentContractCapacityDecisionDateNoUpdFlag) {
    this.consignmentContractCapacityDecisionDateNoUpdFlag = consignmentContractCapacityDecisionDateNoUpdFlag;
  }

  public String getContractCapacityNoUpdFlag() {
    return contractCapacityNoUpdFlag;
  }

  public void setContractCapacityNoUpdFlag(String contractCapacityNoUpdFlag) {
    this.contractCapacityNoUpdFlag = contractCapacityNoUpdFlag;
  }

}
