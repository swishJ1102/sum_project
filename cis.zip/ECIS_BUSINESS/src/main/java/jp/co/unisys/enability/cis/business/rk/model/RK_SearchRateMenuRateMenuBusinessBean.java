package jp.co.unisys.enability.cis.business.rk.model;

import java.util.List;

/**
 * 料金メニュー検索APIの検索結果で、料金メニューの情報を保持するビジネスクラス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_SearchRateMenuRateMenuBusinessBean {

  /**
   * 料金メニューIDを保有する。
   */
  private String rateMenuId;

  /**
   * 料金メニューを保有する。
   */
  private String rateMenu;

  /**
   * 表示用名称を保有する。
   */
  private String displayName;

  /**
   * 適用開始日を保有する。
   */
  private String applySd;

  /**
   * 適用終了日を保有する。
   */
  private String applyed;

  /**
   * 電灯電力区分コードを保有する。
   */
  private String elLightAndPowerCatCode;

  /**
   * 電圧区分コードを保有する。
   */
  private String voltageCategoryCode;

  /**
   * 電圧区分を保有する。
   */
  private String voltageCategory;

  /**
   * 売買区分コードを保有する。
   */
  private String saleCategoryCode;

  /**
   * 売買区分を保有する。
   */
  private String saleCategory;

  /**
   * 契約容量単位を保有する。
   */
  private String contractCapacityUnit;

  /**
   * 容量選択可能範囲を保有する。
   */
  private String capacitySelectableRange;

  /**
   * 表示順を保有する。
   */
  private Integer displayOrder;

  /**
   * 料金メニュー単価リストを保有する。
   */
  private List<RK_SearchRateMenuRateMenuUPBusinessBean> rateMenuUPList;

  /**
   * 最低月額料金フラグを保有する。
   */
  private String mmcFlag;

  /**
   * 料金メニューIDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金メニューIDを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 料金メニューID
   */
  public String getRateMenuId() {
    return this.rateMenuId;
  }

  /**
   * 料金メニューIDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金メニューIDを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param rateMenuId
   *          料金メニューID
   */
  public void setRateMenuId(String rateMenuId) {
    this.rateMenuId = rateMenuId;
  }

  /**
   * 料金メニューのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金メニューを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 料金メニュー
   */
  public String getRateMenu() {
    return this.rateMenu;
  }

  /**
   * 料金メニューのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金メニューを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param rateMenu
   *          料金メニュー
   */
  public void setRateMenu(String rateMenu) {
    this.rateMenu = rateMenu;
  }

  /**
   * 表示用名称のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 表示用名称を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 表示用名称
   */
  public String getDisplayName() {
    return this.displayName;
  }

  /**
   * 表示用名称のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 表示用名称を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param displayName
   *          表示用名称
   */
  public void setDisplayName(String displayName) {
    this.displayName = displayName;
  }

  /**
   * 適用開始日のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 適用開始日を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 適用開始日
   */
  public String getApplySd() {
    return applySd;
  }

  /**
   * 適用開始日のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 適用開始日を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param applySd
   *          適用開始日
   */
  public void setApplySd(String applySd) {
    this.applySd = applySd;
  }

  /**
   * 適用終了日のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 適用終了日を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 適用終了日
   */
  public String getApplyed() {
    return applyed;
  }

  /**
   * 適用終了日のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 適用終了日を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param applyed
   *          適用終了日
   */
  public void setApplyed(String applyed) {
    this.applyed = applyed;
  }

  /**
   * 電圧区分コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 電圧区分コードを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 電圧区分コード
   */
  public String getVoltageCategoryCode() {
    return this.voltageCategoryCode;
  }

  /**
   * 電圧区分コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 電圧区分コードを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param voltageCategoryCode
   *          電圧区分コード
   */
  public void setVoltageCategoryCode(String voltageCategoryCode) {
    this.voltageCategoryCode = voltageCategoryCode;
  }

  /**
   * 電灯電力区分コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 電灯電力区分コードを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 電灯電力区分コード
   */
  public String getElLightAndPowerCatCode() {
    return elLightAndPowerCatCode;
  }

  /**
   * 電灯電力区分コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 電灯電力区分コードを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param elLightAndPowerCatCode
   *          電灯電力区分コード
   */
  public void setElLightAndPowerCatCode(String elLightAndPowerCatCode) {
    this.elLightAndPowerCatCode = elLightAndPowerCatCode;
  }

  /**
   * 電圧区分のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 電圧区分を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 電圧区分
   */
  public String getVoltageCategory() {
    return this.voltageCategory;
  }

  /**
   * 電圧区分のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 電圧区分を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param voltageCategory
   *          電圧区分
   */
  public void setVoltageCategory(String voltageCategory) {
    this.voltageCategory = voltageCategory;
  }

  /**
   * 売買区分コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 売買区分コードを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 売買区分コード
   */
  public String getSaleCategoryCode() {
    return this.saleCategoryCode;
  }

  /**
   * 売買区分コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 売買区分コードを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param saleCategoryCode
   *          売買区分コード
   */
  public void setSaleCategoryCode(String saleCategoryCode) {
    this.saleCategoryCode = saleCategoryCode;
  }

  /**
   * 売買区分のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 売買区分を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 売買区分
   */
  public String getSaleCategory() {
    return this.saleCategory;
  }

  /**
   * 売買区分のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 売買区分を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param saleCategory
   *          売買区分
   */
  public void setSaleCategory(String saleCategory) {
    this.saleCategory = saleCategory;
  }

  /**
   * 契約容量単位のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約容量単位を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約容量単位
   */
  public String getContractCapacityUnit() {
    return this.contractCapacityUnit;
  }

  /**
   * 契約容量単位のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約容量単位を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractCapacityUnit
   *          契約容量単位
   */
  public void setContractCapacityUnit(String contractCapacityUnit) {
    this.contractCapacityUnit = contractCapacityUnit;
  }

  /**
   * 容量選択可能範囲のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 容量選択可能範囲を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 容量選択可能範囲
   */
  public String getCapacitySelectableRange() {
    return this.capacitySelectableRange;
  }

  /**
   * 容量選択可能範囲のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 容量選択可能範囲を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param capacitySelectableRange
   *          容量選択可能範囲
   */
  public void setCapacitySelectableRange(String capacitySelectableRange) {
    this.capacitySelectableRange = capacitySelectableRange;
  }

  /**
   * 表示順のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 表示順を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 表示順
   */
  public Integer getDisplayOrder() {
    return this.displayOrder;
  }

  /**
   * 表示順のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 表示順を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param displayOrder
   *          表示順
   */
  public void setDisplayOrder(Integer displayOrder) {
    this.displayOrder = displayOrder;
  }

  /**
   * 料金メニュー単価リストのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金メニュー単価リストを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 料金メニュー単価リスト
   */
  public List<RK_SearchRateMenuRateMenuUPBusinessBean> getRateMenuUPList() {
    return this.rateMenuUPList;
  }

  /**
   * 料金メニュー単価リストのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金メニュー単価リストを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param rateMenuUPList
   *          料金メニュー単価リスト
   */
  public void setRateMenuUPList(
      List<RK_SearchRateMenuRateMenuUPBusinessBean> rateMenuUPList) {
    this.rateMenuUPList = rateMenuUPList;
  }

  /**
   * 最低月額料金フラグのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 最低月額料金フラグを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 最低月額料金フラグ
   */
  public String getMmcFlag() {
    return this.mmcFlag;
  }

  /**
   * 最低月額料金フラグのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 最低月額料金フラグを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param mmcFlag
   *          最低月額料金フラグ
   */
  public void setMmcFlag(
      String mmcFlag) {
    this.mmcFlag = mmcFlag;
  }

}
