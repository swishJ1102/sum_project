package jp.co.unisys.enability.cis.business.sn.model;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * 債権譲渡通知メールデータビジネスBean. 債権譲渡登録通知用のメール情報を格納するBeanクラス
 *
 * @author "Nihon Unisys, Ltd."
 */
public class SN040701_ClaimAssignmentMailBusinessBean extends SN_CreateMailBusinessBean {

  /** 請求ID */
  private Integer billingId;

  /** 請求番号（請求） */
  private String billingNoBilling;

  /** 契約者ID（請求） */
  private Integer contractorIdBilling;

  /** 契約者番号（請求） */
  private String contractorNoBilling;

  /** 取引先コード（請求） */
  private String customerCodeBilling;

  /** 支払ID（請求） */
  private Integer paymentIdBilling;

  /** 請求区分コード */
  private String billingCategoryCode;

  /** 提供モデルコード（請求） */
  private String provideModelCodeBilling;

  /** 提供モデル企業コード（請求） */
  private String provideModelCompanyCodeBilling;

  /** 利用年月（請求） */
  private String usePeriodBilling;

  /** 請求額 */
  private Long billingAmount;

  /** ご利用金額 */
  private Long useAmount;

  /** 決済予定日 */
  private Date settlementScheduledDate;

  /** 支払期日 */
  private Date paymentFixedDate;

  /** 請求ステータスコード */
  private String billingStatusCode;

  /** 請求特別消込理由コード */
  private String billingSpecialReconciliationReasonCode;

  /** 合算請求フラグ */
  private String addUpBillingFlag;

  /** 先延ばし支払期日フラグ */
  private String procrastinationPaymentFixedDateFlag;

  /** 請求作成日 */
  private Date billingCreateDate;

  /** 複合消込フラグ */
  private String multipleReconcileFlag;

  /** まとめ請求フラグ */
  private String combinedBillingFlag;

  /** 完了フラグ（請求） */
  private String completedFlagBilling;

  /** 金融機関コード */
  private String bankCode;

  /** 金融機関名 */
  private String bankName;

  /** 金融機関支店コード */
  private String bankBranchCode;

  /** 金融機関支店名 */
  private String bankBranchName;

  /** 金融機関預金種目コード */
  private String bankTypeOfAccountCode;

  /** 金融機関預金種目 */
  private String bankTypeOfAccount;

  /** 口座番号 */
  private String accountNo;

  /** 口座名義 */
  private String accountHolderName;

  /** 備考（請求） */
  private String noteBilling;

  /** 契約者ID（契約者） */
  private Integer contractorIdContractor;

  /** 契約者番号（契約者） */
  private String contractorNoContractor;

  /** 契約者名1（カナ） */
  private String contractorName1Kana;

  /** 契約者名1 */
  private String contractorName1;

  /** 契約者名2 */
  private String contractorName2;

  /** 契約者名1（宛名用） */
  private String contractorName1MailingName;

  /** 契約者名2（宛名用） */
  private String contractorName2MailingName;

  /** 敬称 */
  private String prefix;

  /** 契約者住所（郵便番号） */
  private String contractorAddressPostalCode;

  /** 契約者住所（住所） */
  private String contractorAddressFull;

  /** 契約者住所（建物・部屋名） */
  private String contractorAddressBuilding;

  /** 契約者住所（都道府県名） */
  private String contractorAddressPrefectures;

  /** 契約者住所（市区郡町村名） */
  private String contractorAddressMunicipality;

  /** 契約者住所（字名・丁目） */
  private String contractorAddressSection;

  /** 契約者住所（番地･号） */
  private String contractorAddressBlock;

  /** 契約者住所（建物名） */
  private String contractorAddressBuildingName;

  /** 契約者住所（部屋名） */
  private String contractorAddressRoom;

  /** 契約者電話番号1 */
  private String contractorPhoneNo1;

  /** 契約者電話区分コード1 */
  private String contractorPhoneCategoryCode1;

  /** 契約者電話1（市外局番） */
  private String contractorPhoneAreaCode1;

  /** 契約者電話1（市内局番） */
  private String contractorPhoneLocalNo1;

  /** 契約者電話1（加入者番号） */
  private String contractorPhoneDirectoryNo1;

  /** 契約者電話番号2 */
  private String contractorPhoneNo2;

  /** 契約者電話区分コード2 */
  private String contractorPhoneCategoryCode2;

  /** 契約者電話2（市外局番） */
  private String contractorPhoneAreaCode2;

  /** 契約者電話2（市内局番） */
  private String contractorPhoneLocalNo2;

  /** 契約者電話2（加入者番号） */
  private String contractorPhoneDirectoryNo2;

  /** 契約者メールアドレス1 */
  private String contractorMailAddress1;

  /** 契約者メールアドレス2 */
  private String contractorMailAddress2;

  /** 提供モデルコード（契約者） */
  private String provideModelCodeContractor;

  /** 提供モデル企業コード（契約者） */
  private String provideModelCompanyCodeContractor;

  /** 利用不能フラグ */
  private String unavailableFlag;

  /** 取引先コード（契約者） */
  private String customerCodeContractor;

  /** 督促対象外フラグ */
  private String urgeNotCoveredFlag;

  /** 個人・法人区分コード（契約者） */
  private String individualLegalEntityCategoryCodeContractor;

  /** 見える化提供フラグ */
  private String visualizationProvideFlag;

  /** 備考（契約者） */
  private String noteContractor;

  /** 確定料金実績ID */
  private Integer fixChargeResultId;

  /** 契約ID（確定料金実績） */
  private Integer contractIdFixChargeResult;

  /** 契約番号（確定料金実績） */
  private String contractNoFixChargeResult;

  /** 適用開始日 */
  private Date applyStartDate;

  /** 利用年月（確定料金実績） */
  private String usePeriodFixChargeResult;

  /** 契約者ID（確定料金実績） */
  private Integer contractorIdFixChargeResult;

  /** 契約者番号（確定料金実績） */
  private String contractorNoFixChargeResult;

  /** 部課コード */
  private String sectionCode;

  /** 取引先コード（確定料金実績） */
  private String customerCodeFixChargeResult;

  /** 提供モデルコード（確定料金実績） */
  private String provideModelCodeFixChargeResult;

  /** 提供モデル企業コード（確定料金実績） */
  private String provideModelCompanyCodeFixChargeResult;

  /** メータ設置場所ID */
  private Integer meterLocationId;

  /** エリアコード */
  private String areaCode;

  /** 自社管理エリアコード */
  private String ourManagementAreaCode;

  /** 地点特定番号 */
  private String spotNo;

  /** 次回検針予定日 */
  private Date nextMeterReadingScheduledDate;

  /** 料金メニューID */
  private String rateMenuId;

  /** 契約容量 */
  private BigDecimal contractCapacity;

  /** 託送契約容量（確定料金実績） */
  private BigDecimal consignmentContractCapacityFixChargeResult;

  /** 取引種別コード */
  private String dealClassCode;

  /** 確定使用量ID */
  private Integer fixUsageId;

  /** 検針日 */
  private Date meterReadingDate;

  /** 検針理由コード */
  private String meterReadingReasonCode;

  /** 料金算定開始日 */
  private Date chargeCalculationStartDate;

  /** 料金算定終了日 */
  private Date chargeCalculationEndDate;

  /** 料金確定日 */
  private Date chargeFixDate;

  /** 計算用力率 */
  private Short calculatingPowerFactor;

  /** 月額料金 */
  private Long monthlyCharge;

  /** 消費税等相当額 */
  private Integer consumptionTaxEquivalent;

  /** 消費税率 */
  private Short consumptionTaxRate;

  /** 消費税科目コード */
  private String consumptionTaxItemCode;

  /** 基本料金 */
  private BigDecimal basicCharge;

  /** 従量料金 */
  private BigDecimal usageCharge;

  /** 燃料費調整額 */
  private BigDecimal fuelCostAdjustment;

  /** 再エネ賦課金 */
  private BigDecimal renewableEnergyCharge;

  /** 付帯金額 */
  private BigDecimal supplementaryAmount;

  /** 売上1補正金額 */
  private BigDecimal saleProceeds1Correction;

  /** 売上2補正金額 */
  private BigDecimal saleProceeds2Correction;

  /** 売上計上日 */
  private Date saleProceedsRecordedDate;

  /** 売上計上処理日 */
  private Date saleProceedsRecordedExecuteDate;

  /** 売上1科目コード */
  private String saleProceedsItemCode1;

  /** 売上1金額 */
  private Long saleProceeds1;

  /** 売上2科目コード */
  private String saleProceedsItemCode2;

  /** 売上2金額 */
  private Long saleProceeds2;

  /** 売掛金科目コード */
  private String accountsReceivableItemCode;

  /** 売掛金額 */
  private Long accountsReceivableAmount;

  /** 売掛金消込計上日 */
  private Date accountsReceivableReconcileRecordedDate;

  /** 売掛金消込基準日 */
  private Date accountsReceivableReconcileBaseDate;

  /** 売掛金消込処理日 */
  private Date accountsReceivableReconcileExecuteDate;

  /** 請求番号（確定料金実績） */
  private String billingNoFixChargeResult;

  /** 請求消込時充当有無フラグ */
  private String billingReconcileAppropriationFlag;

  /** 売掛金消込振替先科目コード */
  private String accountsReceivableReconcileTransferItemCode;

  /** 完了フラグ（確定料金実績） */
  private String completedFlagFixChargeResult;

  /** 料金ステータスコード */
  private String chargeStatusCode;

  /** 債権回収依頼対象フラグ */
  private String commissionCollectionClaimCoveredFlag;

  /** 契約グループ番号（確定料金実績） */
  private String contractGroupNoFixChargeResult;

  /** 警告対応区分コード */
  private String warningDealCategoryCode;

  /** 作成日 */
  private Date createDate;

  /** 接続送電サービス区分コード（確定料金実績） */
  private String connectedSupplyServiceCategoryCodeFixChargeResult;

  /** 託送料金相当額 */
  private Long consignmentChargeEquivalent;

  /** 備考（確定料金実績） */
  private String noteFixChargeResult;

  /** 契約容量単位 */
  private String contractCapacityUnit;

  /** 託送契約容量単位（確定料金実績） */
  private String consignmentContractCapacityUnitFixChargeResult;

  /** 託送契約容量判定日（確定料金実績） */
  private Date consignmentContractCapacityDecisionDateFixChargeResult;

  /** 営業委託先コード（確定料金実績） */
  private String salesConsignmentCodeFixChargeResult;

  /** 業種コード（確定料金実績） */
  private String businessTypeCodeFixChargeResult;

  /** 契約ID（契約） */
  private Integer contractIdContract;

  /** 契約者ID（契約） */
  private Integer contractorIdContract;

  /** 支払ID（契約） */
  private Integer paymentIdContract;

  /** 契約開始日 */
  private Date contractStartDate;

  /** 契約終了日 */
  private Date contractEndDate;

  /** 契約番号（契約） */
  private String contractNoContract;

  /** 契約終了理由コード */
  private String contractEndReasonCode;

  /** 料金チェックフラグ */
  private String chargeCheckFlag;

  /** 営業委託先コード */
  private String salesConsignmentCode;

  /** 契約グループ番号（契約） */
  private String contractGroupNoContract;

  /** 個人・法人区分コード（契約） */
  private String individualLegalEntityCategoryCodeContract;

  /** 連絡先氏名（カナ） */
  private String contractInformationNameKana;

  /** 連絡先氏名1 */
  private String contractInformationName1;

  /** 連絡先氏名2 */
  private String contractInformationName2;

  /** 連絡先住所（郵便番号） */
  private String contractInformationAddressPostalCode;

  /** 連絡先住所（住所） */
  private String contractInformationAddressFull;

  /** 連絡先住所（建物・部屋名） */
  private String contractInformationAddressBuilding;

  /** 連絡先電話番号 */
  private String contractInformationPhoneNo;

  /** 連絡先電話区分コード */
  private String contractInformationCategoryCode;

  /** 連絡先電話（市外局番） */
  private String contractInformationAreaCode;

  /** 連絡先電話（市内局番） */
  private String contractInformationLocalNo;

  /** 連絡先電話（加入者番号） */
  private String contractInformationDirectoryNo;

  /** 業種コード */
  private String businessTypeCode;

  /** 接続送電サービス区分コード（契約） */
  private String connectedSupplyServiceCategoryCodeContract;

  /** 託送契約容量（契約） */
  private BigDecimal consignmentContractCapacityContract;

  /** 託送契約容量単位 */
  private String consignmentContractCapacityUnit;

  /** 託送契約容量判定日 */
  private Date consignmentContractCapacityDecisionDate;

  /** 契約終了分確定使用量連携済フラグ */
  private String contractEndFixUsageSentFlag;

  /** 備考（契約） */
  private String noteContract;

  /** フリー項目1 */
  private String free1;

  /** フリー項目2 */
  private String free2;

  /** フリー項目3 */
  private String free3;

  /** フリー項目4 */
  private String free4;

  /** フリー項目5 */
  private String free5;

  /** フリー項目6 */
  private String free6;

  /** フリー項目7 */
  private String free7;

  /** フリー項目8 */
  private String free8;

  /** フリー項目9 */
  private String free9;

  /** フリー項目10 */
  private String free10;

  /** フリー項目11 */
  private String free11;

  /** フリー項目12 */
  private String free12;

  /** フリー項目13 */
  private String free13;

  /** フリー項目14 */
  private String free14;

  /** 委託先使用項目1 */
  private String consignmentUseItem1;

  /** 委託先使用項目2 */
  private String consignmentUseItem2;

  /** 委託先使用項目3 */
  private String consignmentUseItem3;

  /** 自社担当者コード */
  private String ourManagementPersonInChargeCode;

  /** 自社部署コード */
  private String ourManagementDepartmentCode;

  /** 支払ID（支払履歴） */
  private Integer paymentIdPaymentHistory;

  /** 支払適用開始日 */
  private Date paymentStartDate;

  /** 支払適用終了日 */
  private Date paymentEndDate;

  /** 支払方法コード */
  private String paymentWayCode;

  /** 口座クレカID */
  private Integer accountCreditCardId;

  /** 個人・法人区分コード（支払履歴） */
  private String individualLegalEntityCategoryCodePaymentHistory;

  /** 請求先氏名1 */
  private String billingName1;

  /** 請求先氏名2 */
  private String billingName2;

  /** 敬称（支払履歴） */
  private String prefixPaymentHistory;

  /** 請求先住所（郵便番号） */
  private String billingAddressPostalCode;

  /** 請求先住所（都道府県名） */
  private String billingAddressPrefectures;

  /** 請求先住所（市区郡町村名） */
  private String billingAddressMunicipality;

  /** 請求先住所（字名・丁目） */
  private String billingAddressSection;

  /** 請求先住所（番地･号） */
  private String billingAddressBlock;

  /** 請求先住所（建物名） */
  private String billingAddressBuildingName;

  /** 請求先住所（部屋名） */
  private String billingAddressRoom;

  /** 請求先電話番号 */
  private String billingPhoneNo;

  /** 請求先電話区分コード */
  private String billingPhoneCategoryCode;

  /** 請求先メールアドレス1 */
  private String billingMailAddress1;

  /** 請求先メールアドレス2 */
  private String billingMailAddress2;

  /** メール送信日 */
  private Date mailSendDate;

  /** 対象債権情報ビジネスBeanリスト */
  private List<SN040701_CoveredAssignmentBusinessBean> coveredAssignmentBusinessBeanList;

  /**
   * 請求IDを設定する。
   *
   * @param billingId
   *          請求ID
   */
  public void setBillingId(Integer billingId) {
    this.billingId = billingId;
  }

  /**
   * 請求IDを取得する。
   *
   * @return 請求ID
   */
  public Integer getBillingId() {
    return this.billingId;
  }

  /**
   * 請求番号（請求）を設定する。
   *
   * @param billingNoBilling
   *          請求番号（請求）
   */
  public void setBillingNoBilling(String billingNoBilling) {
    this.billingNoBilling = billingNoBilling;
  }

  /**
   * 請求番号（請求）を取得する。
   *
   * @return 請求番号（請求）
   */
  public String getBillingNoBilling() {
    return this.billingNoBilling;
  }

  /**
   * 契約者ID（請求）を設定する。
   *
   * @param contractorIdBilling
   *          契約者ID（請求）
   */
  public void setContractorIdBilling(Integer contractorIdBilling) {
    this.contractorIdBilling = contractorIdBilling;
  }

  /**
   * 契約者ID（請求）を取得する。
   *
   * @return 契約者ID（請求）
   */
  public Integer getContractorIdBilling() {
    return this.contractorIdBilling;
  }

  /**
   * 契約者番号（請求）を設定する。
   *
   * @param contractorNoBilling
   *          契約者番号（請求）
   */
  public void setContractorNoBilling(String contractorNoBilling) {
    this.contractorNoBilling = contractorNoBilling;
  }

  /**
   * 契約者番号（請求）を取得する。
   *
   * @return 契約者番号（請求）
   */
  public String getContractorNoBilling() {
    return this.contractorNoBilling;
  }

  /**
   * 取引先コード（請求）を設定する。
   *
   * @param customerCodeBilling
   *          取引先コード（請求）
   */
  public void setCustomerCodeBilling(String customerCodeBilling) {
    this.customerCodeBilling = customerCodeBilling;
  }

  /**
   * 取引先コード（請求）を取得する。
   *
   * @return 取引先コード（請求）
   */
  public String getCustomerCodeBilling() {
    return this.customerCodeBilling;
  }

  /**
   * 支払ID（請求）を設定する。
   *
   * @param paymentIdBilling
   *          支払ID（請求）
   */
  public void setPaymentIdBilling(Integer paymentIdBilling) {
    this.paymentIdBilling = paymentIdBilling;
  }

  /**
   * 支払ID（請求）を取得する。
   *
   * @return 支払ID（請求）
   */
  public Integer getPaymentIdBilling() {
    return this.paymentIdBilling;
  }

  /**
   * 請求区分コードを設定する。
   *
   * @param billingCategoryCode
   *          請求区分コード
   */
  public void setBillingCategoryCode(String billingCategoryCode) {
    this.billingCategoryCode = billingCategoryCode;
  }

  /**
   * 請求区分コードを取得する。
   *
   * @return 請求区分コード
   */
  public String getBillingCategoryCode() {
    return this.billingCategoryCode;
  }

  /**
   * 提供モデルコード（請求）を設定する。
   *
   * @param provideModelCodeBilling
   *          提供モデルコード（請求）
   */
  public void setProvideModelCodeBilling(String provideModelCodeBilling) {
    this.provideModelCodeBilling = provideModelCodeBilling;
  }

  /**
   * 提供モデルコード（請求）を取得する。
   *
   * @return 提供モデルコード（請求）
   */
  public String getProvideModelCodeBilling() {
    return this.provideModelCodeBilling;
  }

  /**
   * 提供モデル企業コード（請求）を設定する。
   *
   * @param provideModelCompanyCodeBilling
   *          提供モデル企業コード（請求）
   */
  public void setProvideModelCompanyCodeBilling(String provideModelCompanyCodeBilling) {
    this.provideModelCompanyCodeBilling = provideModelCompanyCodeBilling;
  }

  /**
   * 提供モデル企業コード（請求）を取得する。
   *
   * @return 提供モデル企業コード（請求）
   */
  public String getProvideModelCompanyCodeBilling() {
    return this.provideModelCompanyCodeBilling;
  }

  /**
   * 利用年月（請求）を設定する。
   *
   * @param usePeriodBilling
   *          利用年月（請求）
   */
  public void setUsePeriodBilling(String usePeriodBilling) {
    this.usePeriodBilling = usePeriodBilling;
  }

  /**
   * 利用年月（請求）を取得する。
   *
   * @return 利用年月（請求）
   */
  public String getUsePeriodBilling() {
    return this.usePeriodBilling;
  }

  /**
   * 請求額を設定する。
   *
   * @param billingAmount
   *          請求額
   */
  public void setBillingAmount(Long billingAmount) {
    this.billingAmount = billingAmount;
  }

  /**
   * 請求額を取得する。
   *
   * @return 請求額
   */
  public Long getBillingAmount() {
    return this.billingAmount;
  }

  /**
   * ご利用金額を設定する。
   *
   * @param useAmount
   *          ご利用金額
   */
  public void setUseAmount(Long useAmount) {
    this.useAmount = useAmount;
  }

  /**
   * ご利用金額を取得する。
   *
   * @return ご利用金額
   */
  public Long getUseAmount() {
    return this.useAmount;
  }

  /**
   * 決済予定日を設定する。
   *
   * @param settlementScheduledDate
   *          決済予定日
   */
  public void setSettlementScheduledDate(Date settlementScheduledDate) {
    this.settlementScheduledDate = settlementScheduledDate;
  }

  /**
   * 決済予定日を取得する。
   *
   * @return 決済予定日
   */
  public Date getSettlementScheduledDate() {
    return this.settlementScheduledDate;
  }

  /**
   * 支払期日を設定する。
   *
   * @param paymentFixedDate
   *          支払期日
   */
  public void setPaymentFixedDate(Date paymentFixedDate) {
    this.paymentFixedDate = paymentFixedDate;
  }

  /**
   * 支払期日を取得する。
   *
   * @return 支払期日
   */
  public Date getPaymentFixedDate() {
    return this.paymentFixedDate;
  }

  /**
   * 請求ステータスコードを設定する。
   *
   * @param billingStatusCode
   *          請求ステータスコード
   */
  public void setBillingStatusCode(String billingStatusCode) {
    this.billingStatusCode = billingStatusCode;
  }

  /**
   * 請求ステータスコードを取得する。
   *
   * @return 請求ステータスコード
   */
  public String getBillingStatusCode() {
    return this.billingStatusCode;
  }

  /**
   * 請求特別消込理由コードを設定する。
   *
   * @param billingSpecialReconciliationReasonCode
   *          請求特別消込理由コード
   */
  public void setBillingSpecialReconciliationReasonCode(String billingSpecialReconciliationReasonCode) {
    this.billingSpecialReconciliationReasonCode = billingSpecialReconciliationReasonCode;
  }

  /**
   * 請求特別消込理由コードを取得する。
   *
   * @return 請求特別消込理由コード
   */
  public String getBillingSpecialReconciliationReasonCode() {
    return this.billingSpecialReconciliationReasonCode;
  }

  /**
   * 合算請求フラグを設定する。
   *
   * @param addUpBillingFlag
   *          合算請求フラグ
   */
  public void setAddUpBillingFlag(String addUpBillingFlag) {
    this.addUpBillingFlag = addUpBillingFlag;
  }

  /**
   * 合算請求フラグを取得する。
   *
   * @return 合算請求フラグ
   */
  public String getAddUpBillingFlag() {
    return this.addUpBillingFlag;
  }

  /**
   * 先延ばし支払期日フラグを設定する。
   *
   * @param procrastinationPaymentFixedDateFlag
   *          先延ばし支払期日フラグ
   */
  public void setProcrastinationPaymentFixedDateFlag(String procrastinationPaymentFixedDateFlag) {
    this.procrastinationPaymentFixedDateFlag = procrastinationPaymentFixedDateFlag;
  }

  /**
   * 先延ばし支払期日フラグを取得する。
   *
   * @return 先延ばし支払期日フラグ
   */
  public String getProcrastinationPaymentFixedDateFlag() {
    return this.procrastinationPaymentFixedDateFlag;
  }

  /**
   * 請求作成日を設定する。
   *
   * @param billingCreateDate
   *          請求作成日
   */
  public void setBillingCreateDate(Date billingCreateDate) {
    this.billingCreateDate = billingCreateDate;
  }

  /**
   * 請求作成日を取得する。
   *
   * @return 請求作成日
   */
  public Date getBillingCreateDate() {
    return this.billingCreateDate;
  }

  /**
   * 複合消込フラグを設定する。
   *
   * @param multipleReconcileFlag
   *          複合消込フラグ
   */
  public void setMultipleReconcileFlag(String multipleReconcileFlag) {
    this.multipleReconcileFlag = multipleReconcileFlag;
  }

  /**
   * 複合消込フラグを取得する。
   *
   * @return 複合消込フラグ
   */
  public String getMultipleReconcileFlag() {
    return this.multipleReconcileFlag;
  }

  /**
   * まとめ請求フラグを設定する。
   *
   * @param combinedBillingFlag
   *          まとめ請求フラグ
   */
  public void setCombinedBillingFlag(String combinedBillingFlag) {
    this.combinedBillingFlag = combinedBillingFlag;
  }

  /**
   * まとめ請求フラグを取得する。
   *
   * @return まとめ請求フラグ
   */
  public String getCombinedBillingFlag() {
    return this.combinedBillingFlag;
  }

  /**
   * 完了フラグ（請求）を設定する。
   *
   * @param completedFlagBilling
   *          完了フラグ（請求）
   */
  public void setCompletedFlagBilling(String completedFlagBilling) {
    this.completedFlagBilling = completedFlagBilling;
  }

  /**
   * 完了フラグ（請求）を取得する。
   *
   * @return 完了フラグ（請求）
   */
  public String getCompletedFlagBilling() {
    return this.completedFlagBilling;
  }

  /**
   * 金融機関コードを設定する。
   *
   * @param bankCode
   *          金融機関コード
   */
  public void setBankCode(String bankCode) {
    this.bankCode = bankCode;
  }

  /**
   * 金融機関コードを取得する。
   *
   * @return 金融機関コード
   */
  public String getBankCode() {
    return this.bankCode;
  }

  /**
   * 金融機関名を設定する。
   *
   * @param bankName
   *          金融機関名
   */
  public void setBankName(String bankName) {
    this.bankName = bankName;
  }

  /**
   * 金融機関名を取得する。
   *
   * @return 金融機関名
   */
  public String getBankName() {
    return this.bankName;
  }

  /**
   * 金融機関支店コードを設定する。
   *
   * @param bankBranchCode
   *          金融機関支店コード
   */
  public void setBankBranchCode(String bankBranchCode) {
    this.bankBranchCode = bankBranchCode;
  }

  /**
   * 金融機関支店コードを取得する。
   *
   * @return 金融機関支店コード
   */
  public String getBankBranchCode() {
    return this.bankBranchCode;
  }

  /**
   * 金融機関支店名を設定する。
   *
   * @param bankBranchName
   *          金融機関支店名
   */
  public void setBankBranchName(String bankBranchName) {
    this.bankBranchName = bankBranchName;
  }

  /**
   * 金融機関支店名を取得する。
   *
   * @return 金融機関支店名
   */
  public String getBankBranchName() {
    return this.bankBranchName;
  }

  /**
   * 金融機関預金種目コードを設定する。
   *
   * @param bankTypeOfAccountCode
   *          金融機関預金種目コード
   */
  public void setBankTypeOfAccountCode(String bankTypeOfAccountCode) {
    this.bankTypeOfAccountCode = bankTypeOfAccountCode;
  }

  /**
   * 金融機関預金種目コードを取得する。
   *
   * @return 金融機関預金種目コード
   */
  public String getBankTypeOfAccountCode() {
    return this.bankTypeOfAccountCode;
  }

  /**
   * 金融機関預金種目を設定する。
   *
   * @param bankTypeOfAccount
   *          金融機関預金種目
   */
  public void setBankTypeOfAccount(String bankTypeOfAccount) {
    this.bankTypeOfAccount = bankTypeOfAccount;
  }

  /**
   * 金融機関預金種目を取得する。
   *
   * @return 金融機関預金種目
   */
  public String getBankTypeOfAccount() {
    return this.bankTypeOfAccount;
  }

  /**
   * 口座番号を設定する。
   *
   * @param accountNo
   *          口座番号
   */
  public void setAccountNo(String accountNo) {
    this.accountNo = accountNo;
  }

  /**
   * 口座番号を取得する。
   *
   * @return 口座番号
   */
  public String getAccountNo() {
    return this.accountNo;
  }

  /**
   * 口座名義を設定する。
   *
   * @param accountHolderName
   *          口座名義
   */
  public void setAccountHolderName(String accountHolderName) {
    this.accountHolderName = accountHolderName;
  }

  /**
   * 口座名義を取得する。
   *
   * @return 口座名義
   */
  public String getAccountHolderName() {
    return this.accountHolderName;
  }

  /**
   * 備考（請求）を設定する。
   *
   * @param noteBilling
   *          備考（請求）
   */
  public void setNoteBilling(String noteBilling) {
    this.noteBilling = noteBilling;
  }

  /**
   * 備考（請求）を取得する。
   *
   * @return 備考（請求）
   */
  public String getNoteBilling() {
    return this.noteBilling;
  }

  /**
   * 契約者ID（契約者）を設定する。
   *
   * @param contractorIdContractor
   *          契約者ID（契約者）
   */
  public void setContractorIdContractor(Integer contractorIdContractor) {
    this.contractorIdContractor = contractorIdContractor;
  }

  /**
   * 契約者ID（契約者）を取得する。
   *
   * @return 契約者ID（契約者）
   */
  public Integer getContractorIdContractor() {
    return this.contractorIdContractor;
  }

  /**
   * 契約者番号（契約者）を設定する。
   *
   * @param contractorNoContractor
   *          契約者番号（契約者）
   */
  public void setContractorNoContractor(String contractorNoContractor) {
    this.contractorNoContractor = contractorNoContractor;
  }

  /**
   * 契約者番号（契約者）を取得する。
   *
   * @return 契約者番号（契約者）
   */
  public String getContractorNoContractor() {
    return this.contractorNoContractor;
  }

  /**
   * 契約者名1（カナ）を設定する。
   *
   * @param contractorName1Kana
   *          契約者名1（カナ）
   */
  public void setContractorName1Kana(String contractorName1Kana) {
    this.contractorName1Kana = contractorName1Kana;
  }

  /**
   * 契約者名1（カナ）を取得する。
   *
   * @return 契約者名1（カナ）
   */
  public String getContractorName1Kana() {
    return this.contractorName1Kana;
  }

  /**
   * 契約者名1を設定する。
   *
   * @param contractorName1
   *          契約者名1
   */
  public void setContractorName1(String contractorName1) {
    this.contractorName1 = contractorName1;
  }

  /**
   * 契約者名1を取得する。
   *
   * @return 契約者名1
   */
  public String getContractorName1() {
    return this.contractorName1;
  }

  /**
   * 契約者名2を設定する。
   *
   * @param contractorName2
   *          契約者名2
   */
  public void setContractorName2(String contractorName2) {
    this.contractorName2 = contractorName2;
  }

  /**
   * 契約者名2を取得する。
   *
   * @return 契約者名2
   */
  public String getContractorName2() {
    return this.contractorName2;
  }

  /**
   * 契約者名1（宛名用）を設定する。
   *
   * @param contractorName1MailingName
   *          契約者名1（宛名用）
   */
  public void setContractorName1MailingName(String contractorName1MailingName) {
    this.contractorName1MailingName = contractorName1MailingName;
  }

  /**
   * 契約者名1（宛名用）を取得する。
   *
   * @return 契約者名1（宛名用）
   */
  public String getContractorName1MailingName() {
    return this.contractorName1MailingName;
  }

  /**
   * 契約者名2（宛名用）を設定する。
   *
   * @param contractorName2MailingName
   *          契約者名2（宛名用）
   */
  public void setContractorName2MailingName(String contractorName2MailingName) {
    this.contractorName2MailingName = contractorName2MailingName;
  }

  /**
   * 契約者名2（宛名用）を取得する。
   *
   * @return 契約者名2（宛名用）
   */
  public String getContractorName2MailingName() {
    return this.contractorName2MailingName;
  }

  /**
   * 敬称を設定する。
   *
   * @param prefix
   *          敬称
   */
  public void setPrefix(String prefix) {
    this.prefix = prefix;
  }

  /**
   * 敬称を取得する。
   *
   * @return 敬称
   */
  public String getPrefix() {
    return this.prefix;
  }

  /**
   * 契約者住所（郵便番号）を設定する。
   *
   * @param contractorAddressPostalCode
   *          契約者住所（郵便番号）
   */
  public void setContractorAddressPostalCode(String contractorAddressPostalCode) {
    this.contractorAddressPostalCode = contractorAddressPostalCode;
  }

  /**
   * 契約者住所（郵便番号）を取得する。
   *
   * @return 契約者住所（郵便番号）
   */
  public String getContractorAddressPostalCode() {
    return this.contractorAddressPostalCode;
  }

  /**
   * 契約者住所（住所）を設定する。
   *
   * @param contractorAddressFull
   *          契約者住所（住所）
   */
  public void setContractorAddressFull(String contractorAddressFull) {
    this.contractorAddressFull = contractorAddressFull;
  }

  /**
   * 契約者住所（住所）を取得する。
   *
   * @return 契約者住所（住所）
   */
  public String getContractorAddressFull() {
    return this.contractorAddressFull;
  }

  /**
   * 契約者住所（建物・部屋名）を設定する。
   *
   * @param contractorAddressBuilding
   *          契約者住所（建物・部屋名）
   */
  public void setContractorAddressBuilding(String contractorAddressBuilding) {
    this.contractorAddressBuilding = contractorAddressBuilding;
  }

  /**
   * 契約者住所（建物・部屋名）を取得する。
   *
   * @return 契約者住所（建物・部屋名）
   */
  public String getContractorAddressBuilding() {
    return this.contractorAddressBuilding;
  }

  /**
   * 契約者住所（都道府県名）を設定する。
   *
   * @param contractorAddressPrefectures
   *          契約者住所（都道府県名）
   */
  public void setContractorAddressPrefectures(String contractorAddressPrefectures) {
    this.contractorAddressPrefectures = contractorAddressPrefectures;
  }

  /**
   * 契約者住所（都道府県名）を取得する。
   *
   * @return 契約者住所（都道府県名）
   */
  public String getContractorAddressPrefectures() {
    return this.contractorAddressPrefectures;
  }

  /**
   * 契約者住所（市区郡町村名）を設定する。
   *
   * @param contractorAddressMunicipality
   *          契約者住所（市区郡町村名）
   */
  public void setContractorAddressMunicipality(String contractorAddressMunicipality) {
    this.contractorAddressMunicipality = contractorAddressMunicipality;
  }

  /**
   * 契約者住所（市区郡町村名）を取得する。
   *
   * @return 契約者住所（市区郡町村名）
   */
  public String getContractorAddressMunicipality() {
    return this.contractorAddressMunicipality;
  }

  /**
   * 契約者住所（字名・丁目）を設定する。
   *
   * @param contractorAddressSection
   *          契約者住所（字名・丁目）
   */
  public void setContractorAddressSection(String contractorAddressSection) {
    this.contractorAddressSection = contractorAddressSection;
  }

  /**
   * 契約者住所（字名・丁目）を取得する。
   *
   * @return 契約者住所（字名・丁目）
   */
  public String getContractorAddressSection() {
    return this.contractorAddressSection;
  }

  /**
   * 契約者住所（番地･号）を設定する。
   *
   * @param contractorAddressBlock
   *          契約者住所（番地･号）
   */
  public void setContractorAddressBlock(String contractorAddressBlock) {
    this.contractorAddressBlock = contractorAddressBlock;
  }

  /**
   * 契約者住所（番地･号）を取得する。
   *
   * @return 契約者住所（番地･号）
   */
  public String getContractorAddressBlock() {
    return this.contractorAddressBlock;
  }

  /**
   * 契約者住所（建物名）を設定する。
   *
   * @param contractorAddressBuildingName
   *          契約者住所（建物名）
   */
  public void setContractorAddressBuildingName(String contractorAddressBuildingName) {
    this.contractorAddressBuildingName = contractorAddressBuildingName;
  }

  /**
   * 契約者住所（建物名）を取得する。
   *
   * @return 契約者住所（建物名）
   */
  public String getContractorAddressBuildingName() {
    return this.contractorAddressBuildingName;
  }

  /**
   * 契約者住所（部屋名）を設定する。
   *
   * @param contractorAddressRoom
   *          契約者住所（部屋名）
   */
  public void setContractorAddressRoom(String contractorAddressRoom) {
    this.contractorAddressRoom = contractorAddressRoom;
  }

  /**
   * 契約者住所（部屋名）を取得する。
   *
   * @return 契約者住所（部屋名）
   */
  public String getContractorAddressRoom() {
    return this.contractorAddressRoom;
  }

  /**
   * 契約者電話番号1を設定する。
   *
   * @param contractorPhoneNo1
   *          契約者電話番号1
   */
  public void setContractorPhoneNo1(String contractorPhoneNo1) {
    this.contractorPhoneNo1 = contractorPhoneNo1;
  }

  /**
   * 契約者電話番号1を取得する。
   *
   * @return 契約者電話番号1
   */
  public String getContractorPhoneNo1() {
    return this.contractorPhoneNo1;
  }

  /**
   * 契約者電話区分コード1を設定する。
   *
   * @param contractorPhoneCategoryCode1
   *          契約者電話区分コード1
   */
  public void setContractorPhoneCategoryCode1(String contractorPhoneCategoryCode1) {
    this.contractorPhoneCategoryCode1 = contractorPhoneCategoryCode1;
  }

  /**
   * 契約者電話区分コード1を取得する。
   *
   * @return 契約者電話区分コード1
   */
  public String getContractorPhoneCategoryCode1() {
    return this.contractorPhoneCategoryCode1;
  }

  /**
   * 契約者電話1（市外局番）を設定する。
   *
   * @param contractorPhoneAreaCode1
   *          契約者電話1（市外局番）
   */
  public void setContractorPhoneAreaCode1(String contractorPhoneAreaCode1) {
    this.contractorPhoneAreaCode1 = contractorPhoneAreaCode1;
  }

  /**
   * 契約者電話1（市外局番）を取得する。
   *
   * @return 契約者電話1（市外局番）
   */
  public String getContractorPhoneAreaCode1() {
    return this.contractorPhoneAreaCode1;
  }

  /**
   * 契約者電話1（市内局番）を設定する。
   *
   * @param contractorPhoneLocalNo1
   *          契約者電話1（市内局番）
   */
  public void setContractorPhoneLocalNo1(String contractorPhoneLocalNo1) {
    this.contractorPhoneLocalNo1 = contractorPhoneLocalNo1;
  }

  /**
   * 契約者電話1（市内局番）を取得する。
   *
   * @return 契約者電話1（市内局番）
   */
  public String getContractorPhoneLocalNo1() {
    return this.contractorPhoneLocalNo1;
  }

  /**
   * 契約者電話1（加入者番号）を設定する。
   *
   * @param contractorPhoneDirectoryNo1
   *          契約者電話1（加入者番号）
   */
  public void setContractorPhoneDirectoryNo1(String contractorPhoneDirectoryNo1) {
    this.contractorPhoneDirectoryNo1 = contractorPhoneDirectoryNo1;
  }

  /**
   * 契約者電話1（加入者番号）を取得する。
   *
   * @return 契約者電話1（加入者番号）
   */
  public String getContractorPhoneDirectoryNo1() {
    return this.contractorPhoneDirectoryNo1;
  }

  /**
   * 契約者電話番号2を設定する。
   *
   * @param contractorPhoneNo2
   *          契約者電話番号2
   */
  public void setContractorPhoneNo2(String contractorPhoneNo2) {
    this.contractorPhoneNo2 = contractorPhoneNo2;
  }

  /**
   * 契約者電話番号2を取得する。
   *
   * @return 契約者電話番号2
   */
  public String getContractorPhoneNo2() {
    return this.contractorPhoneNo2;
  }

  /**
   * 契約者電話区分コード2を設定する。
   *
   * @param contractorPhoneCategoryCode2
   *          契約者電話区分コード2
   */
  public void setContractorPhoneCategoryCode2(String contractorPhoneCategoryCode2) {
    this.contractorPhoneCategoryCode2 = contractorPhoneCategoryCode2;
  }

  /**
   * 契約者電話区分コード2を取得する。
   *
   * @return 契約者電話区分コード2
   */
  public String getContractorPhoneCategoryCode2() {
    return this.contractorPhoneCategoryCode2;
  }

  /**
   * 契約者電話2（市外局番）を設定する。
   *
   * @param contractorPhoneAreaCode2
   *          契約者電話2（市外局番）
   */
  public void setContractorPhoneAreaCode2(String contractorPhoneAreaCode2) {
    this.contractorPhoneAreaCode2 = contractorPhoneAreaCode2;
  }

  /**
   * 契約者電話2（市外局番）を取得する。
   *
   * @return 契約者電話2（市外局番）
   */
  public String getContractorPhoneAreaCode2() {
    return this.contractorPhoneAreaCode2;
  }

  /**
   * 契約者電話2（市内局番）を設定する。
   *
   * @param contractorPhoneLocalNo2
   *          契約者電話2（市内局番）
   */
  public void setContractorPhoneLocalNo2(String contractorPhoneLocalNo2) {
    this.contractorPhoneLocalNo2 = contractorPhoneLocalNo2;
  }

  /**
   * 契約者電話2（市内局番）を取得する。
   *
   * @return 契約者電話2（市内局番）
   */
  public String getContractorPhoneLocalNo2() {
    return this.contractorPhoneLocalNo2;
  }

  /**
   * 契約者電話2（加入者番号）を設定する。
   *
   * @param contractorPhoneDirectoryNo2
   *          契約者電話2（加入者番号）
   */
  public void setContractorPhoneDirectoryNo2(String contractorPhoneDirectoryNo2) {
    this.contractorPhoneDirectoryNo2 = contractorPhoneDirectoryNo2;
  }

  /**
   * 契約者電話2（加入者番号）を取得する。
   *
   * @return 契約者電話2（加入者番号）
   */
  public String getContractorPhoneDirectoryNo2() {
    return this.contractorPhoneDirectoryNo2;
  }

  /**
   * 契約者メールアドレス1を設定する。
   *
   * @param contractorMailAddress1
   *          契約者メールアドレス1
   */
  public void setContractorMailAddress1(String contractorMailAddress1) {
    this.contractorMailAddress1 = contractorMailAddress1;
  }

  /**
   * 契約者メールアドレス1を取得する。
   *
   * @return 契約者メールアドレス1
   */
  public String getContractorMailAddress1() {
    return this.contractorMailAddress1;
  }

  /**
   * 契約者メールアドレス2を設定する。
   *
   * @param contractorMailAddress2
   *          契約者メールアドレス2
   */
  public void setContractorMailAddress2(String contractorMailAddress2) {
    this.contractorMailAddress2 = contractorMailAddress2;
  }

  /**
   * 契約者メールアドレス2を取得する。
   *
   * @return 契約者メールアドレス2
   */
  public String getContractorMailAddress2() {
    return this.contractorMailAddress2;
  }

  /**
   * 提供モデルコード（契約者）を設定する。
   *
   * @param provideModelCodeContractor
   *          提供モデルコード（契約者）
   */
  public void setProvideModelCodeContractor(String provideModelCodeContractor) {
    this.provideModelCodeContractor = provideModelCodeContractor;
  }

  /**
   * 提供モデルコード（契約者）を取得する。
   *
   * @return 提供モデルコード（契約者）
   */
  public String getProvideModelCodeContractor() {
    return this.provideModelCodeContractor;
  }

  /**
   * 提供モデル企業コード（契約者）を設定する。
   *
   * @param provideModelCompanyCodeContractor
   *          提供モデル企業コード（契約者）
   */
  public void setProvideModelCompanyCodeContractor(String provideModelCompanyCodeContractor) {
    this.provideModelCompanyCodeContractor = provideModelCompanyCodeContractor;
  }

  /**
   * 提供モデル企業コード（契約者）を取得する。
   *
   * @return 提供モデル企業コード（契約者）
   */
  public String getProvideModelCompanyCodeContractor() {
    return this.provideModelCompanyCodeContractor;
  }

  /**
   * 利用不能フラグを設定する。
   *
   * @param unavailableFlag
   *          利用不能フラグ
   */
  public void setUnavailableFlag(String unavailableFlag) {
    this.unavailableFlag = unavailableFlag;
  }

  /**
   * 利用不能フラグを取得する。
   *
   * @return 利用不能フラグ
   */
  public String getUnavailableFlag() {
    return this.unavailableFlag;
  }

  /**
   * 取引先コード（契約者）を設定する。
   *
   * @param customerCodeContractor
   *          取引先コード（契約者）
   */
  public void setCustomerCodeContractor(String customerCodeContractor) {
    this.customerCodeContractor = customerCodeContractor;
  }

  /**
   * 取引先コード（契約者）を取得する。
   *
   * @return 取引先コード（契約者）
   */
  public String getCustomerCodeContractor() {
    return this.customerCodeContractor;
  }

  /**
   * 督促対象外フラグを設定する。
   *
   * @param urgeNotCoveredFlag
   *          督促対象外フラグ
   */
  public void setUrgeNotCoveredFlag(String urgeNotCoveredFlag) {
    this.urgeNotCoveredFlag = urgeNotCoveredFlag;
  }

  /**
   * 督促対象外フラグを取得する。
   *
   * @return 督促対象外フラグ
   */
  public String getUrgeNotCoveredFlag() {
    return this.urgeNotCoveredFlag;
  }

  /**
   * 個人・法人区分コード（契約者）を設定する。
   *
   * @param individualLegalEntityCategoryCodeContractor
   *          個人・法人区分コード（契約者）
   */
  public void setIndividualLegalEntityCategoryCodeContractor(String individualLegalEntityCategoryCodeContractor) {
    this.individualLegalEntityCategoryCodeContractor = individualLegalEntityCategoryCodeContractor;
  }

  /**
   * 個人・法人区分コード（契約者）を取得する。
   *
   * @return 個人・法人区分コード（契約者）
   */
  public String getIndividualLegalEntityCategoryCodeContractor() {
    return this.individualLegalEntityCategoryCodeContractor;
  }

  /**
   * 見える化提供フラグを設定する。
   *
   * @param visualizationProvideFlag
   *          見える化提供フラグ
   */
  public void setVisualizationProvideFlag(String visualizationProvideFlag) {
    this.visualizationProvideFlag = visualizationProvideFlag;
  }

  /**
   * 見える化提供フラグを取得する。
   *
   * @return 見える化提供フラグ
   */
  public String getVisualizationProvideFlag() {
    return this.visualizationProvideFlag;
  }

  /**
   * 備考（契約者）を設定する。
   *
   * @param noteContractor
   *          備考（契約者）
   */
  public void setNoteContractor(String noteContractor) {
    this.noteContractor = noteContractor;
  }

  /**
   * 備考（契約者）を取得する。
   *
   * @return 備考（契約者）
   */
  public String getNoteContractor() {
    return this.noteContractor;
  }

  /**
   * 確定料金実績IDを設定する。
   *
   * @param fixChargeResultId
   *          確定料金実績ID
   */
  public void setFixChargeResultId(Integer fixChargeResultId) {
    this.fixChargeResultId = fixChargeResultId;
  }

  /**
   * 確定料金実績IDを取得する。
   *
   * @return 確定料金実績ID
   */
  public Integer getFixChargeResultId() {
    return this.fixChargeResultId;
  }

  /**
   * 契約ID（確定料金実績）を設定する。
   *
   * @param contractIdFixChargeResult
   *          契約ID（確定料金実績）
   */
  public void setContractIdFixChargeResult(Integer contractIdFixChargeResult) {
    this.contractIdFixChargeResult = contractIdFixChargeResult;
  }

  /**
   * 契約ID（確定料金実績）を取得する。
   *
   * @return 契約ID（確定料金実績）
   */
  public Integer getContractIdFixChargeResult() {
    return this.contractIdFixChargeResult;
  }

  /**
   * 契約番号（確定料金実績）を設定する。
   *
   * @param contractNoFixChargeResult
   *          契約番号（確定料金実績）
   */
  public void setContractNoFixChargeResult(String contractNoFixChargeResult) {
    this.contractNoFixChargeResult = contractNoFixChargeResult;
  }

  /**
   * 契約番号（確定料金実績）を取得する。
   *
   * @return 契約番号（確定料金実績）
   */
  public String getContractNoFixChargeResult() {
    return this.contractNoFixChargeResult;
  }

  /**
   * 適用開始日を設定する。
   *
   * @param applyStartDate
   *          適用開始日
   */
  public void setApplyStartDate(Date applyStartDate) {
    this.applyStartDate = applyStartDate;
  }

  /**
   * 適用開始日を取得する。
   *
   * @return 適用開始日
   */
  public Date getApplyStartDate() {
    return this.applyStartDate;
  }

  /**
   * 利用年月（確定料金実績）を設定する。
   *
   * @param usePeriodFixChargeResult
   *          利用年月（確定料金実績）
   */
  public void setUsePeriodFixChargeResult(String usePeriodFixChargeResult) {
    this.usePeriodFixChargeResult = usePeriodFixChargeResult;
  }

  /**
   * 利用年月（確定料金実績）を取得する。
   *
   * @return 利用年月（確定料金実績）
   */
  public String getUsePeriodFixChargeResult() {
    return this.usePeriodFixChargeResult;
  }

  /**
   * 契約者ID（確定料金実績）を設定する。
   *
   * @param contractorIdFixChargeResult
   *          契約者ID（確定料金実績）
   */
  public void setContractorIdFixChargeResult(Integer contractorIdFixChargeResult) {
    this.contractorIdFixChargeResult = contractorIdFixChargeResult;
  }

  /**
   * 契約者ID（確定料金実績）を取得する。
   *
   * @return 契約者ID（確定料金実績）
   */
  public Integer getContractorIdFixChargeResult() {
    return this.contractorIdFixChargeResult;
  }

  /**
   * 契約者番号（確定料金実績）を設定する。
   *
   * @param contractorNoFixChargeResult
   *          契約者番号（確定料金実績）
   */
  public void setContractorNoFixChargeResult(String contractorNoFixChargeResult) {
    this.contractorNoFixChargeResult = contractorNoFixChargeResult;
  }

  /**
   * 契約者番号（確定料金実績）を取得する。
   *
   * @return 契約者番号（確定料金実績）
   */
  public String getContractorNoFixChargeResult() {
    return this.contractorNoFixChargeResult;
  }

  /**
   * 部課コードを設定する。
   *
   * @param sectionCode
   *          部課コード
   */
  public void setSectionCode(String sectionCode) {
    this.sectionCode = sectionCode;
  }

  /**
   * 部課コードを取得する。
   *
   * @return 部課コード
   */
  public String getSectionCode() {
    return this.sectionCode;
  }

  /**
   * 取引先コード（確定料金実績）を設定する。
   *
   * @param customerCodeFixChargeResult
   *          取引先コード（確定料金実績）
   */
  public void setCustomerCodeFixChargeResult(String customerCodeFixChargeResult) {
    this.customerCodeFixChargeResult = customerCodeFixChargeResult;
  }

  /**
   * 取引先コード（確定料金実績）を取得する。
   *
   * @return 取引先コード（確定料金実績）
   */
  public String getCustomerCodeFixChargeResult() {
    return this.customerCodeFixChargeResult;
  }

  /**
   * 提供モデルコード（確定料金実績）を設定する。
   *
   * @param provideModelCodeFixChargeResult
   *          提供モデルコード（確定料金実績）
   */
  public void setProvideModelCodeFixChargeResult(String provideModelCodeFixChargeResult) {
    this.provideModelCodeFixChargeResult = provideModelCodeFixChargeResult;
  }

  /**
   * 提供モデルコード（確定料金実績）を取得する。
   *
   * @return 提供モデルコード（確定料金実績）
   */
  public String getProvideModelCodeFixChargeResult() {
    return this.provideModelCodeFixChargeResult;
  }

  /**
   * 提供モデル企業コード（確定料金実績）を設定する。
   *
   * @param provideModelCompanyCodeFixChargeResult
   *          提供モデル企業コード（確定料金実績）
   */
  public void setProvideModelCompanyCodeFixChargeResult(String provideModelCompanyCodeFixChargeResult) {
    this.provideModelCompanyCodeFixChargeResult = provideModelCompanyCodeFixChargeResult;
  }

  /**
   * 提供モデル企業コード（確定料金実績）を取得する。
   *
   * @return 提供モデル企業コード（確定料金実績）
   */
  public String getProvideModelCompanyCodeFixChargeResult() {
    return this.provideModelCompanyCodeFixChargeResult;
  }

  /**
   * メータ設置場所IDを設定する。
   *
   * @param meterLocationId
   *          メータ設置場所ID
   */
  public void setMeterLocationId(Integer meterLocationId) {
    this.meterLocationId = meterLocationId;
  }

  /**
   * メータ設置場所IDを取得する。
   *
   * @return メータ設置場所ID
   */
  public Integer getMeterLocationId() {
    return this.meterLocationId;
  }

  /**
   * エリアコードを設定する。
   *
   * @param areaCode
   *          エリアコード
   */
  public void setAreaCode(String areaCode) {
    this.areaCode = areaCode;
  }

  /**
   * エリアコードを取得する。
   *
   * @return エリアコード
   */
  public String getAreaCode() {
    return this.areaCode;
  }

  /**
   * 自社管理エリアコードを設定する。
   *
   * @param ourManagementAreaCode
   *          自社管理エリアコード
   */
  public void setOurManagementAreaCode(String ourManagementAreaCode) {
    this.ourManagementAreaCode = ourManagementAreaCode;
  }

  /**
   * 自社管理エリアコードを取得する。
   *
   * @return 自社管理エリアコード
   */
  public String getOurManagementAreaCode() {
    return this.ourManagementAreaCode;
  }

  /**
   * 地点特定番号を設定する。
   *
   * @param spotNo
   *          地点特定番号
   */
  public void setSpotNo(String spotNo) {
    this.spotNo = spotNo;
  }

  /**
   * 地点特定番号を取得する。
   *
   * @return 地点特定番号
   */
  public String getSpotNo() {
    return this.spotNo;
  }

  /**
   * 次回検針予定日を設定する。
   *
   * @param nextMeterReadingScheduledDate
   *          次回検針予定日
   */
  public void setNextMeterReadingScheduledDate(Date nextMeterReadingScheduledDate) {
    this.nextMeterReadingScheduledDate = nextMeterReadingScheduledDate;
  }

  /**
   * 次回検針予定日を取得する。
   *
   * @return 次回検針予定日
   */
  public Date getNextMeterReadingScheduledDate() {
    return this.nextMeterReadingScheduledDate;
  }

  /**
   * 料金メニューIDを設定する。
   *
   * @param rateMenuId
   *          料金メニューID
   */
  public void setRateMenuId(String rateMenuId) {
    this.rateMenuId = rateMenuId;
  }

  /**
   * 料金メニューIDを取得する。
   *
   * @return 料金メニューID
   */
  public String getRateMenuId() {
    return this.rateMenuId;
  }

  /**
   * 契約容量を設定する。
   *
   * @param contractCapacity
   *          契約容量
   */
  public void setContractCapacity(BigDecimal contractCapacity) {
    this.contractCapacity = contractCapacity;
  }

  /**
   * 契約容量を取得する。
   *
   * @return 契約容量
   */
  public BigDecimal getContractCapacity() {
    return this.contractCapacity;
  }

  /**
   * 託送契約容量（確定料金実績）を設定する。
   *
   * @param consignmentContractCapacityFixChargeResult
   *          託送契約容量（確定料金実績）
   */
  public void setConsignmentContractCapacityFixChargeResult(BigDecimal consignmentContractCapacityFixChargeResult) {
    this.consignmentContractCapacityFixChargeResult = consignmentContractCapacityFixChargeResult;
  }

  /**
   * 託送契約容量（確定料金実績）を取得する。
   *
   * @return 託送契約容量（確定料金実績）
   */
  public BigDecimal getConsignmentContractCapacityFixChargeResult() {
    return this.consignmentContractCapacityFixChargeResult;
  }

  /**
   * 取引種別コードを設定する。
   *
   * @param dealClassCode
   *          取引種別コード
   */
  public void setDealClassCode(String dealClassCode) {
    this.dealClassCode = dealClassCode;
  }

  /**
   * 取引種別コードを取得する。
   *
   * @return 取引種別コード
   */
  public String getDealClassCode() {
    return this.dealClassCode;
  }

  /**
   * 確定使用量IDを設定する。
   *
   * @param fixUsageId
   *          確定使用量ID
   */
  public void setFixUsageId(Integer fixUsageId) {
    this.fixUsageId = fixUsageId;
  }

  /**
   * 確定使用量IDを取得する。
   *
   * @return 確定使用量ID
   */
  public Integer getFixUsageId() {
    return this.fixUsageId;
  }

  /**
   * 検針日を設定する。
   *
   * @param meterReadingDate
   *          検針日
   */
  public void setMeterReadingDate(Date meterReadingDate) {
    this.meterReadingDate = meterReadingDate;
  }

  /**
   * 検針日を取得する。
   *
   * @return 検針日
   */
  public Date getMeterReadingDate() {
    return this.meterReadingDate;
  }

  /**
   * 検針理由コードを設定する。
   *
   * @param meterReadingReasonCode
   *          検針理由コード
   */
  public void setMeterReadingReasonCode(String meterReadingReasonCode) {
    this.meterReadingReasonCode = meterReadingReasonCode;
  }

  /**
   * 検針理由コードを取得する。
   *
   * @return 検針理由コード
   */
  public String getMeterReadingReasonCode() {
    return this.meterReadingReasonCode;
  }

  /**
   * 料金算定開始日を設定する。
   *
   * @param chargeCalculationStartDate
   *          料金算定開始日
   */
  public void setChargeCalculationStartDate(Date chargeCalculationStartDate) {
    this.chargeCalculationStartDate = chargeCalculationStartDate;
  }

  /**
   * 料金算定開始日を取得する。
   *
   * @return 料金算定開始日
   */
  public Date getChargeCalculationStartDate() {
    return this.chargeCalculationStartDate;
  }

  /**
   * 料金算定終了日を設定する。
   *
   * @param chargeCalculationEndDate
   *          料金算定終了日
   */
  public void setChargeCalculationEndDate(Date chargeCalculationEndDate) {
    this.chargeCalculationEndDate = chargeCalculationEndDate;
  }

  /**
   * 料金算定終了日を取得する。
   *
   * @return 料金算定終了日
   */
  public Date getChargeCalculationEndDate() {
    return this.chargeCalculationEndDate;
  }

  /**
   * 料金確定日を設定する。
   *
   * @param chargeFixDate
   *          料金確定日
   */
  public void setChargeFixDate(Date chargeFixDate) {
    this.chargeFixDate = chargeFixDate;
  }

  /**
   * 料金確定日を取得する。
   *
   * @return 料金確定日
   */
  public Date getChargeFixDate() {
    return this.chargeFixDate;
  }

  /**
   * 計算用力率を設定する。
   *
   * @param calculatingPowerFactor
   *          計算用力率
   */
  public void setCalculatingPowerFactor(Short calculatingPowerFactor) {
    this.calculatingPowerFactor = calculatingPowerFactor;
  }

  /**
   * 計算用力率を取得する。
   *
   * @return 計算用力率
   */
  public Short getCalculatingPowerFactor() {
    return this.calculatingPowerFactor;
  }

  /**
   * 月額料金を設定する。
   *
   * @param monthlyCharge
   *          月額料金
   */
  public void setMonthlyCharge(Long monthlyCharge) {
    this.monthlyCharge = monthlyCharge;
  }

  /**
   * 月額料金を取得する。
   *
   * @return 月額料金
   */
  public Long getMonthlyCharge() {
    return this.monthlyCharge;
  }

  /**
   * 消費税等相当額を設定する。
   *
   * @param consumptionTaxEquivalent
   *          消費税等相当額
   */
  public void setConsumptionTaxEquivalent(Integer consumptionTaxEquivalent) {
    this.consumptionTaxEquivalent = consumptionTaxEquivalent;
  }

  /**
   * 消費税等相当額を取得する。
   *
   * @return 消費税等相当額
   */
  public Integer getConsumptionTaxEquivalent() {
    return this.consumptionTaxEquivalent;
  }

  /**
   * 消費税率を設定する。
   *
   * @param consumptionTaxRate
   *          消費税率
   */
  public void setConsumptionTaxRate(Short consumptionTaxRate) {
    this.consumptionTaxRate = consumptionTaxRate;
  }

  /**
   * 消費税率を取得する。
   *
   * @return 消費税率
   */
  public Short getConsumptionTaxRate() {
    return this.consumptionTaxRate;
  }

  /**
   * 消費税科目コードを設定する。
   *
   * @param consumptionTaxItemCode
   *          消費税科目コード
   */
  public void setConsumptionTaxItemCode(String consumptionTaxItemCode) {
    this.consumptionTaxItemCode = consumptionTaxItemCode;
  }

  /**
   * 消費税科目コードを取得する。
   *
   * @return 消費税科目コード
   */
  public String getConsumptionTaxItemCode() {
    return this.consumptionTaxItemCode;
  }

  /**
   * 基本料金を設定する。
   *
   * @param basicCharge
   *          基本料金
   */
  public void setBasicCharge(BigDecimal basicCharge) {
    this.basicCharge = basicCharge;
  }

  /**
   * 基本料金を取得する。
   *
   * @return 基本料金
   */
  public BigDecimal getBasicCharge() {
    return this.basicCharge;
  }

  /**
   * 従量料金を設定する。
   *
   * @param usageCharge
   *          従量料金
   */
  public void setUsageCharge(BigDecimal usageCharge) {
    this.usageCharge = usageCharge;
  }

  /**
   * 従量料金を取得する。
   *
   * @return 従量料金
   */
  public BigDecimal getUsageCharge() {
    return this.usageCharge;
  }

  /**
   * 燃料費調整額を設定する。
   *
   * @param fuelCostAdjustment
   *          燃料費調整額
   */
  public void setFuelCostAdjustment(BigDecimal fuelCostAdjustment) {
    this.fuelCostAdjustment = fuelCostAdjustment;
  }

  /**
   * 燃料費調整額を取得する。
   *
   * @return 燃料費調整額
   */
  public BigDecimal getFuelCostAdjustment() {
    return this.fuelCostAdjustment;
  }

  /**
   * 再エネ賦課金を設定する。
   *
   * @param renewableEnergyCharge
   *          再エネ賦課金
   */
  public void setRenewableEnergyCharge(BigDecimal renewableEnergyCharge) {
    this.renewableEnergyCharge = renewableEnergyCharge;
  }

  /**
   * 再エネ賦課金を取得する。
   *
   * @return 再エネ賦課金
   */
  public BigDecimal getRenewableEnergyCharge() {
    return this.renewableEnergyCharge;
  }

  /**
   * 付帯金額を設定する。
   *
   * @param supplementaryAmount
   *          付帯金額
   */
  public void setSupplementaryAmount(BigDecimal supplementaryAmount) {
    this.supplementaryAmount = supplementaryAmount;
  }

  /**
   * 付帯金額を取得する。
   *
   * @return 付帯金額
   */
  public BigDecimal getSupplementaryAmount() {
    return this.supplementaryAmount;
  }

  /**
   * 売上1補正金額を設定する。
   *
   * @param saleProceeds1Correction
   *          売上1補正金額
   */
  public void setSaleProceeds1Correction(BigDecimal saleProceeds1Correction) {
    this.saleProceeds1Correction = saleProceeds1Correction;
  }

  /**
   * 売上1補正金額を取得する。
   *
   * @return 売上1補正金額
   */
  public BigDecimal getSaleProceeds1Correction() {
    return this.saleProceeds1Correction;
  }

  /**
   * 売上2補正金額を設定する。
   *
   * @param saleProceeds2Correction
   *          売上2補正金額
   */
  public void setSaleProceeds2Correction(BigDecimal saleProceeds2Correction) {
    this.saleProceeds2Correction = saleProceeds2Correction;
  }

  /**
   * 売上2補正金額を取得する。
   *
   * @return 売上2補正金額
   */
  public BigDecimal getSaleProceeds2Correction() {
    return this.saleProceeds2Correction;
  }

  /**
   * 売上計上日を設定する。
   *
   * @param saleProceedsRecordedDate
   *          売上計上日
   */
  public void setSaleProceedsRecordedDate(Date saleProceedsRecordedDate) {
    this.saleProceedsRecordedDate = saleProceedsRecordedDate;
  }

  /**
   * 売上計上日を取得する。
   *
   * @return 売上計上日
   */
  public Date getSaleProceedsRecordedDate() {
    return this.saleProceedsRecordedDate;
  }

  /**
   * 売上計上処理日を設定する。
   *
   * @param saleProceedsRecordedExecuteDate
   *          売上計上処理日
   */
  public void setSaleProceedsRecordedExecuteDate(Date saleProceedsRecordedExecuteDate) {
    this.saleProceedsRecordedExecuteDate = saleProceedsRecordedExecuteDate;
  }

  /**
   * 売上計上処理日を取得する。
   *
   * @return 売上計上処理日
   */
  public Date getSaleProceedsRecordedExecuteDate() {
    return this.saleProceedsRecordedExecuteDate;
  }

  /**
   * 売上1科目コードを設定する。
   *
   * @param saleProceedsItemCode1
   *          売上1科目コード
   */
  public void setSaleProceedsItemCode1(String saleProceedsItemCode1) {
    this.saleProceedsItemCode1 = saleProceedsItemCode1;
  }

  /**
   * 売上1科目コードを取得する。
   *
   * @return 売上1科目コード
   */
  public String getSaleProceedsItemCode1() {
    return this.saleProceedsItemCode1;
  }

  /**
   * 売上1金額を設定する。
   *
   * @param saleProceeds1
   *          売上1金額
   */
  public void setSaleProceeds1(Long saleProceeds1) {
    this.saleProceeds1 = saleProceeds1;
  }

  /**
   * 売上1金額を取得する。
   *
   * @return 売上1金額
   */
  public Long getSaleProceeds1() {
    return this.saleProceeds1;
  }

  /**
   * 売上2科目コードを設定する。
   *
   * @param saleProceedsItemCode2
   *          売上2科目コード
   */
  public void setSaleProceedsItemCode2(String saleProceedsItemCode2) {
    this.saleProceedsItemCode2 = saleProceedsItemCode2;
  }

  /**
   * 売上2科目コードを取得する。
   *
   * @return 売上2科目コード
   */
  public String getSaleProceedsItemCode2() {
    return this.saleProceedsItemCode2;
  }

  /**
   * 売上2金額を設定する。
   *
   * @param saleProceeds2
   *          売上2金額
   */
  public void setSaleProceeds2(Long saleProceeds2) {
    this.saleProceeds2 = saleProceeds2;
  }

  /**
   * 売上2金額を取得する。
   *
   * @return 売上2金額
   */
  public Long getSaleProceeds2() {
    return this.saleProceeds2;
  }

  /**
   * 売掛金科目コードを設定する。
   *
   * @param accountsReceivableItemCode
   *          売掛金科目コード
   */
  public void setAccountsReceivableItemCode(String accountsReceivableItemCode) {
    this.accountsReceivableItemCode = accountsReceivableItemCode;
  }

  /**
   * 売掛金科目コードを取得する。
   *
   * @return 売掛金科目コード
   */
  public String getAccountsReceivableItemCode() {
    return this.accountsReceivableItemCode;
  }

  /**
   * 売掛金額を設定する。
   *
   * @param accountsReceivableAmount
   *          売掛金額
   */
  public void setAccountsReceivableAmount(Long accountsReceivableAmount) {
    this.accountsReceivableAmount = accountsReceivableAmount;
  }

  /**
   * 売掛金額を取得する。
   *
   * @return 売掛金額
   */
  public Long getAccountsReceivableAmount() {
    return this.accountsReceivableAmount;
  }

  /**
   * 売掛金消込計上日を設定する。
   *
   * @param accountsReceivableReconcileRecordedDate
   *          売掛金消込計上日
   */
  public void setAccountsReceivableReconcileRecordedDate(Date accountsReceivableReconcileRecordedDate) {
    this.accountsReceivableReconcileRecordedDate = accountsReceivableReconcileRecordedDate;
  }

  /**
   * 売掛金消込計上日を取得する。
   *
   * @return 売掛金消込計上日
   */
  public Date getAccountsReceivableReconcileRecordedDate() {
    return this.accountsReceivableReconcileRecordedDate;
  }

  /**
   * 売掛金消込基準日を設定する。
   *
   * @param accountsReceivableReconcileBaseDate
   *          売掛金消込基準日
   */
  public void setAccountsReceivableReconcileBaseDate(Date accountsReceivableReconcileBaseDate) {
    this.accountsReceivableReconcileBaseDate = accountsReceivableReconcileBaseDate;
  }

  /**
   * 売掛金消込基準日を取得する。
   *
   * @return 売掛金消込基準日
   */
  public Date getAccountsReceivableReconcileBaseDate() {
    return this.accountsReceivableReconcileBaseDate;
  }

  /**
   * 売掛金消込処理日を設定する。
   *
   * @param accountsReceivableReconcileExecuteDate
   *          売掛金消込処理日
   */
  public void setAccountsReceivableReconcileExecuteDate(Date accountsReceivableReconcileExecuteDate) {
    this.accountsReceivableReconcileExecuteDate = accountsReceivableReconcileExecuteDate;
  }

  /**
   * 売掛金消込処理日を取得する。
   *
   * @return 売掛金消込処理日
   */
  public Date getAccountsReceivableReconcileExecuteDate() {
    return this.accountsReceivableReconcileExecuteDate;
  }

  /**
   * 請求番号（確定料金実績）を設定する。
   *
   * @param billingNoFixChargeResult
   *          請求番号（確定料金実績）
   */
  public void setBillingNoFixChargeResult(String billingNoFixChargeResult) {
    this.billingNoFixChargeResult = billingNoFixChargeResult;
  }

  /**
   * 請求番号（確定料金実績）を取得する。
   *
   * @return 請求番号（確定料金実績）
   */
  public String getBillingNoFixChargeResult() {
    return this.billingNoFixChargeResult;
  }

  /**
   * 請求消込時充当有無フラグを設定する。
   *
   * @param billingReconcileAppropriationFlag
   *          請求消込時充当有無フラグ
   */
  public void setBillingReconcileAppropriationFlag(String billingReconcileAppropriationFlag) {
    this.billingReconcileAppropriationFlag = billingReconcileAppropriationFlag;
  }

  /**
   * 請求消込時充当有無フラグを取得する。
   *
   * @return 請求消込時充当有無フラグ
   */
  public String getBillingReconcileAppropriationFlag() {
    return this.billingReconcileAppropriationFlag;
  }

  /**
   * 売掛金消込振替先科目コードを設定する。
   *
   * @param accountsReceivableReconcileTransferItemCode
   *          売掛金消込振替先科目コード
   */
  public void setAccountsReceivableReconcileTransferItemCode(String accountsReceivableReconcileTransferItemCode) {
    this.accountsReceivableReconcileTransferItemCode = accountsReceivableReconcileTransferItemCode;
  }

  /**
   * 売掛金消込振替先科目コードを取得する。
   *
   * @return 売掛金消込振替先科目コード
   */
  public String getAccountsReceivableReconcileTransferItemCode() {
    return this.accountsReceivableReconcileTransferItemCode;
  }

  /**
   * 完了フラグ（確定料金実績）を設定する。
   *
   * @param completedFlagFixChargeResult
   *          完了フラグ（確定料金実績）
   */
  public void setCompletedFlagFixChargeResult(String completedFlagFixChargeResult) {
    this.completedFlagFixChargeResult = completedFlagFixChargeResult;
  }

  /**
   * 完了フラグ（確定料金実績）を取得する。
   *
   * @return 完了フラグ（確定料金実績）
   */
  public String getCompletedFlagFixChargeResult() {
    return this.completedFlagFixChargeResult;
  }

  /**
   * 料金ステータスコードを設定する。
   *
   * @param chargeStatusCode
   *          料金ステータスコード
   */
  public void setChargeStatusCode(String chargeStatusCode) {
    this.chargeStatusCode = chargeStatusCode;
  }

  /**
   * 料金ステータスコードを取得する。
   *
   * @return 料金ステータスコード
   */
  public String getChargeStatusCode() {
    return this.chargeStatusCode;
  }

  /**
   * 債権回収依頼対象フラグを設定する。
   *
   * @param commissionCollectionClaimCoveredFlag
   *          債権回収依頼対象フラグ
   */
  public void setCommissionCollectionClaimCoveredFlag(String commissionCollectionClaimCoveredFlag) {
    this.commissionCollectionClaimCoveredFlag = commissionCollectionClaimCoveredFlag;
  }

  /**
   * 債権回収依頼対象フラグを取得する。
   *
   * @return 債権回収依頼対象フラグ
   */
  public String getCommissionCollectionClaimCoveredFlag() {
    return this.commissionCollectionClaimCoveredFlag;
  }

  /**
   * 契約グループ番号（確定料金実績）を設定する。
   *
   * @param contractGroupNoFixChargeResult
   *          契約グループ番号（確定料金実績）
   */
  public void setContractGroupNoFixChargeResult(String contractGroupNoFixChargeResult) {
    this.contractGroupNoFixChargeResult = contractGroupNoFixChargeResult;
  }

  /**
   * 契約グループ番号（確定料金実績）を取得する。
   *
   * @return 契約グループ番号（確定料金実績）
   */
  public String getContractGroupNoFixChargeResult() {
    return this.contractGroupNoFixChargeResult;
  }

  /**
   * 警告対応区分コードを設定する。
   *
   * @param warningDealCategoryCode
   *          警告対応区分コード
   */
  public void setWarningDealCategoryCode(String warningDealCategoryCode) {
    this.warningDealCategoryCode = warningDealCategoryCode;
  }

  /**
   * 警告対応区分コードを取得する。
   *
   * @return 警告対応区分コード
   */
  public String getWarningDealCategoryCode() {
    return this.warningDealCategoryCode;
  }

  /**
   * 作成日を設定する。
   *
   * @param createDate
   *          作成日
   */
  public void setCreateDate(Date createDate) {
    this.createDate = createDate;
  }

  /**
   * 作成日を取得する。
   *
   * @return 作成日
   */
  public Date getCreateDate() {
    return this.createDate;
  }

  /**
   * 接続送電サービス区分コード（確定料金実績）を設定する。
   *
   * @param connectedSupplyServiceCategoryCodeFixChargeResult
   *          接続送電サービス区分コード（確定料金実績）
   */
  public void setConnectedSupplyServiceCategoryCodeFixChargeResult(
      String connectedSupplyServiceCategoryCodeFixChargeResult) {
    this.connectedSupplyServiceCategoryCodeFixChargeResult = connectedSupplyServiceCategoryCodeFixChargeResult;
  }

  /**
   * 接続送電サービス区分コード（確定料金実績）を取得する。
   *
   * @return 接続送電サービス区分コード（確定料金実績）
   */
  public String getConnectedSupplyServiceCategoryCodeFixChargeResult() {
    return this.connectedSupplyServiceCategoryCodeFixChargeResult;
  }

  /**
   * 託送料金相当額を設定する。
   *
   * @param consignmentChargeEquivalent
   *          託送料金相当額
   */
  public void setConsignmentChargeEquivalent(Long consignmentChargeEquivalent) {
    this.consignmentChargeEquivalent = consignmentChargeEquivalent;
  }

  /**
   * 託送料金相当額を取得する。
   *
   * @return 託送料金相当額
   */
  public Long getConsignmentChargeEquivalent() {
    return this.consignmentChargeEquivalent;
  }

  /**
   * 備考（確定料金実績）を設定する。
   *
   * @param noteFixChargeResult
   *          備考（確定料金実績）
   */
  public void setNoteFixChargeResult(String noteFixChargeResult) {
    this.noteFixChargeResult = noteFixChargeResult;
  }

  /**
   * 備考（確定料金実績）を取得する。
   *
   * @return 備考（確定料金実績）
   */
  public String getNoteFixChargeResult() {
    return this.noteFixChargeResult;
  }

  /**
   * 契約容量単位を設定する。
   *
   * @param contractCapacityUnit
   *          契約容量単位
   */
  public void setContractCapacityUnit(String contractCapacityUnit) {
    this.contractCapacityUnit = contractCapacityUnit;
  }

  /**
   * 契約容量単位を取得する。
   *
   * @return 契約容量単位
   */
  public String getContractCapacityUnit() {
    return this.contractCapacityUnit;
  }

  /**
   * 託送契約容量単位（確定料金実績）を設定する。
   *
   * @param consignmentContractCapacityUnitFixChargeResult
   *          託送契約容量単位（確定料金実績）
   */
  public void setConsignmentContractCapacityUnitFixChargeResult(
      String consignmentContractCapacityUnitFixChargeResult) {
    this.consignmentContractCapacityUnitFixChargeResult = consignmentContractCapacityUnitFixChargeResult;
  }

  /**
   * 託送契約容量単位（確定料金実績）を取得する。
   *
   * @return 託送契約容量単位（確定料金実績）
   */
  public String getConsignmentContractCapacityUnitFixChargeResult() {
    return consignmentContractCapacityUnitFixChargeResult;
  }

  /**
   * 託送契約容量判定日（確定料金実績）を設定する。
   *
   * @param consignmentContractCapacityDecisionDateFixChargeResult
   *          託送契約容量判定日（確定料金実績）
   */
  public void setConsignmentContractCapacityDecisionDateFixChargeResult(
      Date consignmentContractCapacityDecisionDateFixChargeResult) {
    this.consignmentContractCapacityDecisionDateFixChargeResult = consignmentContractCapacityDecisionDateFixChargeResult;
  }

  /**
   * 託送契約容量判定日（確定料金実績）を取得する。
   *
   * @return 託送契約容量判定日（確定料金実績）
   */
  public Date getConsignmentContractCapacityDecisionDateFixChargeResult() {
    return consignmentContractCapacityDecisionDateFixChargeResult;
  }

  /**
   * 営業委託先コード（確定料金実績）を設定する。
   *
   * @param salesConsignmentCodeFixChargeResult
   *          営業委託先コード（確定料金実績）
   */
  public void setSalesConsignmentCodeFixChargeResult(String salesConsignmentCodeFixChargeResult) {
    this.salesConsignmentCodeFixChargeResult = salesConsignmentCodeFixChargeResult;
  }

  /**
   * 営業委託先コード（確定料金実績）を取得する。
   *
   * @return 営業委託先コード（確定料金実績）
   */
  public String getSalesConsignmentCodeFixChargeResult() {
    return salesConsignmentCodeFixChargeResult;
  }

  /**
   * 業種コード（確定料金実績）を設定する。
   *
   * @param businessTypeCodeFixChargeResult
   *          業種コード（確定料金実績）
   */
  public void setBusinessTypeCodeFixChargeResult(String businessTypeCodeFixChargeResult) {
    this.businessTypeCodeFixChargeResult = businessTypeCodeFixChargeResult;
  }

  /**
   * 業種コード（確定料金実績）を取得する。
   *
   * @return 業種コード（確定料金実績）
   */
  public String getBusinessTypeCodeFixChargeResult() {
    return businessTypeCodeFixChargeResult;
  }

  /**
   * 契約ID（契約）を設定する。
   *
   * @param contractIdContract
   *          契約ID（契約）
   */
  public void setContractIdContract(Integer contractIdContract) {
    this.contractIdContract = contractIdContract;
  }

  /**
   * 契約ID（契約）を取得する。
   *
   * @return 契約ID（契約）
   */
  public Integer getContractIdContract() {
    return this.contractIdContract;
  }

  /**
   * 契約者ID（契約）を設定する。
   *
   * @param contractorIdContract
   *          契約者ID（契約）
   */
  public void setContractorIdContract(Integer contractorIdContract) {
    this.contractorIdContract = contractorIdContract;
  }

  /**
   * 契約者ID（契約）を取得する。
   *
   * @return 契約者ID（契約）
   */
  public Integer getContractorIdContract() {
    return this.contractorIdContract;
  }

  /**
   * 支払ID（契約）を設定する。
   *
   * @param paymentIdContract
   *          支払ID（契約）
   */
  public void setPaymentIdContract(Integer paymentIdContract) {
    this.paymentIdContract = paymentIdContract;
  }

  /**
   * 支払ID（契約）を取得する。
   *
   * @return 支払ID（契約）
   */
  public Integer getPaymentIdContract() {
    return this.paymentIdContract;
  }

  /**
   * 契約開始日を設定する。
   *
   * @param contractStartDate
   *          契約開始日
   */
  public void setContractStartDate(Date contractStartDate) {
    this.contractStartDate = contractStartDate;
  }

  /**
   * 契約開始日を取得する。
   *
   * @return 契約開始日
   */
  public Date getContractStartDate() {
    return this.contractStartDate;
  }

  /**
   * 契約終了日を設定する。
   *
   * @param contractEndDate
   *          契約終了日
   */
  public void setContractEndDate(Date contractEndDate) {
    this.contractEndDate = contractEndDate;
  }

  /**
   * 契約終了日を取得する。
   *
   * @return 契約終了日
   */
  public Date getContractEndDate() {
    return this.contractEndDate;
  }

  /**
   * 契約番号（契約）を設定する。
   *
   * @param contractNoContract
   *          契約番号（契約）
   */
  public void setContractNoContract(String contractNoContract) {
    this.contractNoContract = contractNoContract;
  }

  /**
   * 契約番号（契約）を取得する。
   *
   * @return 契約番号（契約）
   */
  public String getContractNoContract() {
    return this.contractNoContract;
  }

  /**
   * 契約終了理由コードを設定する。
   *
   * @param contractEndReasonCode
   *          契約終了理由コード
   */
  public void setContractEndReasonCode(String contractEndReasonCode) {
    this.contractEndReasonCode = contractEndReasonCode;
  }

  /**
   * 契約終了理由コードを取得する。
   *
   * @return 契約終了理由コード
   */
  public String getContractEndReasonCode() {
    return this.contractEndReasonCode;
  }

  /**
   * 料金チェックフラグを設定する。
   *
   * @param chargeCheckFlag
   *          料金チェックフラグ
   */
  public void setChargeCheckFlag(String chargeCheckFlag) {
    this.chargeCheckFlag = chargeCheckFlag;
  }

  /**
   * 料金チェックフラグを取得する。
   *
   * @return 料金チェックフラグ
   */
  public String getChargeCheckFlag() {
    return this.chargeCheckFlag;
  }

  /**
   * 営業委託先コードを設定する。
   *
   * @param salesConsignmentCode
   *          営業委託先コード
   */
  public void setSalesConsignmentCode(String salesConsignmentCode) {
    this.salesConsignmentCode = salesConsignmentCode;
  }

  /**
   * 営業委託先コードを取得する。
   *
   * @return 営業委託先コード
   */
  public String getSalesConsignmentCode() {
    return this.salesConsignmentCode;
  }

  /**
   * 契約グループ番号（契約）を設定する。
   *
   * @param contractGroupNoContract
   *          契約グループ番号（契約）
   */
  public void setContractGroupNoContract(String contractGroupNoContract) {
    this.contractGroupNoContract = contractGroupNoContract;
  }

  /**
   * 契約グループ番号（契約）を取得する。
   *
   * @return 契約グループ番号（契約）
   */
  public String getContractGroupNoContract() {
    return this.contractGroupNoContract;
  }

  /**
   * 個人・法人区分コード（契約）を設定する。
   *
   * @param individualLegalEntityCategoryCodeContract
   *          個人・法人区分コード（契約）
   */
  public void setIndividualLegalEntityCategoryCodeContract(String individualLegalEntityCategoryCodeContract) {
    this.individualLegalEntityCategoryCodeContract = individualLegalEntityCategoryCodeContract;
  }

  /**
   * 個人・法人区分コード（契約）を取得する。
   *
   * @return 個人・法人区分コード（契約）
   */
  public String getIndividualLegalEntityCategoryCodeContract() {
    return this.individualLegalEntityCategoryCodeContract;
  }

  /**
   * 連絡先氏名（カナ）を設定する。
   *
   * @param contractInformationNameKana
   *          連絡先氏名（カナ）
   */
  public void setContractInformationNameKana(String contractInformationNameKana) {
    this.contractInformationNameKana = contractInformationNameKana;
  }

  /**
   * 連絡先氏名（カナ）を取得する。
   *
   * @return 連絡先氏名（カナ）
   */
  public String getContractInformationNameKana() {
    return this.contractInformationNameKana;
  }

  /**
   * 連絡先氏名1を設定する。
   *
   * @param contractInformationName1
   *          連絡先氏名1
   */
  public void setContractInformationName1(String contractInformationName1) {
    this.contractInformationName1 = contractInformationName1;
  }

  /**
   * 連絡先氏名1を取得する。
   *
   * @return 連絡先氏名1
   */
  public String getContractInformationName1() {
    return this.contractInformationName1;
  }

  /**
   * 連絡先氏名2を設定する。
   *
   * @param contractInformationName2
   *          連絡先氏名2
   */
  public void setContractInformationName2(String contractInformationName2) {
    this.contractInformationName2 = contractInformationName2;
  }

  /**
   * 連絡先氏名2を取得する。
   *
   * @return 連絡先氏名2
   */
  public String getContractInformationName2() {
    return this.contractInformationName2;
  }

  /**
   * 連絡先住所（郵便番号）を設定する。
   *
   * @param contractInformationAddressPostalCode
   *          連絡先住所（郵便番号）
   */
  public void setContractInformationAddressPostalCode(String contractInformationAddressPostalCode) {
    this.contractInformationAddressPostalCode = contractInformationAddressPostalCode;
  }

  /**
   * 連絡先住所（郵便番号）を取得する。
   *
   * @return 連絡先住所（郵便番号）
   */
  public String getContractInformationAddressPostalCode() {
    return this.contractInformationAddressPostalCode;
  }

  /**
   * 連絡先住所（住所）を設定する。
   *
   * @param contractInformationAddressFull
   *          連絡先住所（住所）
   */
  public void setContractInformationAddressFull(String contractInformationAddressFull) {
    this.contractInformationAddressFull = contractInformationAddressFull;
  }

  /**
   * 連絡先住所（住所）を取得する。
   *
   * @return 連絡先住所（住所）
   */
  public String getContractInformationAddressFull() {
    return this.contractInformationAddressFull;
  }

  /**
   * 連絡先住所（建物・部屋名）を設定する。
   *
   * @param contractInformationAddressBuilding
   *          連絡先住所（建物・部屋名）
   */
  public void setContractInformationAddressBuilding(String contractInformationAddressBuilding) {
    this.contractInformationAddressBuilding = contractInformationAddressBuilding;
  }

  /**
   * 連絡先住所（建物・部屋名）を取得する。
   *
   * @return 連絡先住所（建物・部屋名）
   */
  public String getContractInformationAddressBuilding() {
    return this.contractInformationAddressBuilding;
  }

  /**
   * 連絡先電話番号を設定する。
   *
   * @param contractInformationPhoneNo
   *          連絡先電話番号
   */
  public void setContractInformationPhoneNo(String contractInformationPhoneNo) {
    this.contractInformationPhoneNo = contractInformationPhoneNo;
  }

  /**
   * 連絡先電話番号を取得する。
   *
   * @return 連絡先電話番号
   */
  public String getContractInformationPhoneNo() {
    return this.contractInformationPhoneNo;
  }

  /**
   * 連絡先電話区分コードを設定する。
   *
   * @param contractInformationCategoryCode
   *          連絡先電話区分コード
   */
  public void setContractInformationCategoryCode(String contractInformationCategoryCode) {
    this.contractInformationCategoryCode = contractInformationCategoryCode;
  }

  /**
   * 連絡先電話区分コードを取得する。
   *
   * @return 連絡先電話区分コード
   */
  public String getContractInformationCategoryCode() {
    return this.contractInformationCategoryCode;
  }

  /**
   * 連絡先電話（市外局番）を設定する。
   *
   * @param contractInformationAreaCode
   *          連絡先電話（市外局番）
   */
  public void setContractInformationAreaCode(String contractInformationAreaCode) {
    this.contractInformationAreaCode = contractInformationAreaCode;
  }

  /**
   * 連絡先電話（市外局番）を取得する。
   *
   * @return 連絡先電話（市外局番）
   */
  public String getContractInformationAreaCode() {
    return this.contractInformationAreaCode;
  }

  /**
   * 連絡先電話（市内局番）を設定する。
   *
   * @param contractInformationLocalNo
   *          連絡先電話（市内局番）
   */
  public void setContractInformationLocalNo(String contractInformationLocalNo) {
    this.contractInformationLocalNo = contractInformationLocalNo;
  }

  /**
   * 連絡先電話（市内局番）を取得する。
   *
   * @return 連絡先電話（市内局番）
   */
  public String getContractInformationLocalNo() {
    return this.contractInformationLocalNo;
  }

  /**
   * 連絡先電話（加入者番号）を設定する。
   *
   * @param contractInformationDirectoryNo
   *          連絡先電話（加入者番号）
   */
  public void setContractInformationDirectoryNo(String contractInformationDirectoryNo) {
    this.contractInformationDirectoryNo = contractInformationDirectoryNo;
  }

  /**
   * 連絡先電話（加入者番号）を取得する。
   *
   * @return 連絡先電話（加入者番号）
   */
  public String getContractInformationDirectoryNo() {
    return this.contractInformationDirectoryNo;
  }

  /**
   * 業種コードを設定する。
   *
   * @param businessTypeCode
   *          業種コード
   */
  public void setBusinessTypeCode(String businessTypeCode) {
    this.businessTypeCode = businessTypeCode;
  }

  /**
   * 業種コードを取得する。
   *
   * @return 業種コード
   */
  public String getBusinessTypeCode() {
    return this.businessTypeCode;
  }

  /**
   * 接続送電サービス区分コード（契約）を設定する。
   *
   * @param connectedSupplyServiceCategoryCodeContract
   *          接続送電サービス区分コード（契約）
   */
  public void setConnectedSupplyServiceCategoryCodeContract(String connectedSupplyServiceCategoryCodeContract) {
    this.connectedSupplyServiceCategoryCodeContract = connectedSupplyServiceCategoryCodeContract;
  }

  /**
   * 接続送電サービス区分コード（契約）を取得する。
   *
   * @return 接続送電サービス区分コード（契約）
   */
  public String getConnectedSupplyServiceCategoryCodeContract() {
    return this.connectedSupplyServiceCategoryCodeContract;
  }

  /**
   * 託送契約容量（契約）を設定する。
   *
   * @param consignmentContractCapacityContract
   *          託送契約容量（契約）
   */
  public void setConsignmentContractCapacityContract(BigDecimal consignmentContractCapacityContract) {
    this.consignmentContractCapacityContract = consignmentContractCapacityContract;
  }

  /**
   * 託送契約容量（契約）を取得する。
   *
   * @return 託送契約容量（契約）
   */
  public BigDecimal getConsignmentContractCapacityContract() {
    return this.consignmentContractCapacityContract;
  }

  /**
   * 託送契約容量単位を設定する。
   *
   * @param consignmentContractCapacityUnit
   *          託送契約容量単位
   */
  public void setConsignmentContractCapacityUnit(String consignmentContractCapacityUnit) {
    this.consignmentContractCapacityUnit = consignmentContractCapacityUnit;
  }

  /**
   * 託送契約容量単位を取得する。
   *
   * @return 託送契約容量単位
   */
  public String getConsignmentContractCapacityUnit() {
    return this.consignmentContractCapacityUnit;
  }

  /**
   * 託送契約容量判定日を設定する。
   *
   * @param consignmentContractCapacityDecisionDate
   *          託送契約容量判定日
   */
  public void setConsignmentContractCapacityDecisionDate(Date consignmentContractCapacityDecisionDate) {
    this.consignmentContractCapacityDecisionDate = consignmentContractCapacityDecisionDate;
  }

  /**
   * 託送契約容量判定日を取得する。
   *
   * @return 託送契約容量判定日
   */
  public Date getConsignmentContractCapacityDecisionDate() {
    return this.consignmentContractCapacityDecisionDate;
  }

  /**
   * 契約終了分確定使用量連携済フラグを設定する。
   *
   * @param contractEndFixUsageSentFlag
   *          契約終了分確定使用量連携済フラグ
   */
  public void setContractEndFixUsageSentFlag(String contractEndFixUsageSentFlag) {
    this.contractEndFixUsageSentFlag = contractEndFixUsageSentFlag;
  }

  /**
   * 契約終了分確定使用量連携済フラグを取得する。
   *
   * @return 契約終了分確定使用量連携済フラグ
   */
  public String getContractEndFixUsageSentFlag() {
    return this.contractEndFixUsageSentFlag;
  }

  /**
   * 備考（契約）を設定する。
   *
   * @param noteContract
   *          備考（契約）
   */
  public void setNoteContract(String noteContract) {
    this.noteContract = noteContract;
  }

  /**
   * 備考（契約）を取得する。
   *
   * @return 備考（契約）
   */
  public String getNoteContract() {
    return this.noteContract;
  }

  /**
   * フリー項目1を設定する。
   *
   * @param free1
   *          フリー項目1
   */
  public void setFree1(String free1) {
    this.free1 = free1;
  }

  /**
   * フリー項目1を取得する。
   *
   * @return フリー項目1
   */
  public String getFree1() {
    return this.free1;
  }

  /**
   * フリー項目2を設定する。
   *
   * @param free2
   *          フリー項目2
   */
  public void setFree2(String free2) {
    this.free2 = free2;
  }

  /**
   * フリー項目2を取得する。
   *
   * @return フリー項目2
   */
  public String getFree2() {
    return this.free2;
  }

  /**
   * フリー項目3を設定する。
   *
   * @param free3
   *          フリー項目3
   */
  public void setFree3(String free3) {
    this.free3 = free3;
  }

  /**
   * フリー項目3を取得する。
   *
   * @return フリー項目3
   */
  public String getFree3() {
    return this.free3;
  }

  /**
   * フリー項目4を設定する。
   *
   * @param free4
   *          フリー項目4
   */
  public void setFree4(String free4) {
    this.free4 = free4;
  }

  /**
   * フリー項目4を取得する。
   *
   * @return フリー項目4
   */
  public String getFree4() {
    return this.free4;
  }

  /**
   * フリー項目5を設定する。
   *
   * @param free5
   *          フリー項目5
   */
  public void setFree5(String free5) {
    this.free5 = free5;
  }

  /**
   * フリー項目5を取得する。
   *
   * @return フリー項目5
   */
  public String getFree5() {
    return this.free5;
  }

  /**
   * フリー項目6を設定する。
   *
   * @param free6
   *          フリー項目6
   */
  public void setFree6(String free6) {
    this.free6 = free6;
  }

  /**
   * フリー項目6を取得する。
   *
   * @return フリー項目6
   */
  public String getFree6() {
    return this.free6;
  }

  /**
   * フリー項目7を設定する。
   *
   * @param free7
   *          フリー項目7
   */
  public void setFree7(String free7) {
    this.free7 = free7;
  }

  /**
   * フリー項目7を取得する。
   *
   * @return フリー項目7
   */
  public String getFree7() {
    return this.free7;
  }

  /**
   * フリー項目8を設定する。
   *
   * @param free8
   *          フリー項目8
   */
  public void setFree8(String free8) {
    this.free8 = free8;
  }

  /**
   * フリー項目8を取得する。
   *
   * @return フリー項目8
   */
  public String getFree8() {
    return this.free8;
  }

  /**
   * フリー項目9を設定する。
   *
   * @param free9
   *          フリー項目9
   */
  public void setFree9(String free9) {
    this.free9 = free9;
  }

  /**
   * フリー項目9を取得する。
   *
   * @return フリー項目9
   */
  public String getFree9() {
    return this.free9;
  }

  /**
   * フリー項目10を設定する。
   *
   * @param free10
   *          フリー項目10
   */
  public void setFree10(String free10) {
    this.free10 = free10;
  }

  /**
   * フリー項目10を取得する。
   *
   * @return フリー項目10
   */
  public String getFree10() {
    return this.free10;
  }

  /**
   * フリー項目11を設定する。
   *
   * @param free11
   *          フリー項目11
   */
  public void setFree11(String free11) {
    this.free11 = free11;
  }

  /**
   * フリー項目11を取得する。
   *
   * @return フリー項目11
   */
  public String getFree11() {
    return this.free11;
  }

  /**
   * フリー項目12を設定する。
   *
   * @param free12
   *          フリー項目12
   */
  public void setFree12(String free12) {
    this.free12 = free12;
  }

  /**
   * フリー項目12を取得する。
   *
   * @return フリー項目12
   */
  public String getFree12() {
    return this.free12;
  }

  /**
   * フリー項目13を設定する。
   *
   * @param free13
   *          フリー項目13
   */
  public void setFree13(String free13) {
    this.free13 = free13;
  }

  /**
   * フリー項目13を取得する。
   *
   * @return フリー項目13
   */
  public String getFree13() {
    return this.free13;
  }

  /**
   * フリー項目14を設定する。
   *
   * @param free14
   *          フリー項目14
   */
  public void setFree14(String free14) {
    this.free14 = free14;
  }

  /**
   * フリー項目14を取得する。
   *
   * @return フリー項目14
   */
  public String getFree14() {
    return this.free14;
  }

  /**
   * 委託先使用項目1を設定する。
   *
   * @param consignmentUseItem1
   *          委託先使用項目1
   */
  public void setConsignmentUseItem1(String consignmentUseItem1) {
    this.consignmentUseItem1 = consignmentUseItem1;
  }

  /**
   * 委託先使用項目1を取得する。
   *
   * @return 委託先使用項目1
   */
  public String getConsignmentUseItem1() {
    return this.consignmentUseItem1;
  }

  /**
   * 委託先使用項目2を設定する。
   *
   * @param consignmentUseItem2
   *          委託先使用項目2
   */
  public void setConsignmentUseItem2(String consignmentUseItem2) {
    this.consignmentUseItem2 = consignmentUseItem2;
  }

  /**
   * 委託先使用項目2を取得する。
   *
   * @return 委託先使用項目2
   */
  public String getConsignmentUseItem2() {
    return this.consignmentUseItem2;
  }

  /**
   * 委託先使用項目3を設定する。
   *
   * @param consignmentUseItem3
   *          委託先使用項目3
   */
  public void setConsignmentUseItem3(String consignmentUseItem3) {
    this.consignmentUseItem3 = consignmentUseItem3;
  }

  /**
   * 委託先使用項目3を取得する。
   *
   * @return 委託先使用項目3
   */
  public String getConsignmentUseItem3() {
    return this.consignmentUseItem3;
  }

  /**
   * 自社担当者コードを設定する。
   *
   * @param ourManagementPersonInChargeCode
   *          自社担当者コード
   */
  public void setOurManagementPersonInChargeCode(String ourManagementPersonInChargeCode) {
    this.ourManagementPersonInChargeCode = ourManagementPersonInChargeCode;
  }

  /**
   * 自社担当者コードを取得する。
   *
   * @return 自社担当者コード
   */
  public String getOurManagementPersonInChargeCode() {
    return this.ourManagementPersonInChargeCode;
  }

  /**
   * 自社部署コードを設定する。
   *
   * @param ourManagementDepartmentCode
   *          自社部署コード
   */
  public void setOurManagementDepartmentCode(String ourManagementDepartmentCode) {
    this.ourManagementDepartmentCode = ourManagementDepartmentCode;
  }

  /**
   * 自社部署コードを取得する。
   *
   * @return 自社部署コード
   */
  public String getOurManagementDepartmentCode() {
    return this.ourManagementDepartmentCode;
  }

  /**
   * 支払ID（支払履歴）を設定する。
   *
   * @param paymentIdPaymentHistory
   *          支払ID（支払履歴）
   */
  public void setPaymentIdPaymentHistory(Integer paymentIdPaymentHistory) {
    this.paymentIdPaymentHistory = paymentIdPaymentHistory;
  }

  /**
   * 支払ID（支払履歴）を取得する。
   *
   * @return 支払ID（支払履歴）
   */
  public Integer getPaymentIdPaymentHistory() {
    return this.paymentIdPaymentHistory;
  }

  /**
   * 支払適用開始日を設定する。
   *
   * @param paymentStartDate
   *          支払適用開始日
   */
  public void setPaymentStartDate(Date paymentStartDate) {
    this.paymentStartDate = paymentStartDate;
  }

  /**
   * 支払適用開始日を取得する。
   *
   * @return 支払適用開始日
   */
  public Date getPaymentStartDate() {
    return this.paymentStartDate;
  }

  /**
   * 支払適用終了日を設定する。
   *
   * @param paymentEndDate
   *          支払適用終了日
   */
  public void setPaymentEndDate(Date paymentEndDate) {
    this.paymentEndDate = paymentEndDate;
  }

  /**
   * 支払適用終了日を取得する。
   *
   * @return 支払適用終了日
   */
  public Date getPaymentEndDate() {
    return this.paymentEndDate;
  }

  /**
   * 支払方法コードを設定する。
   *
   * @param paymentWayCode
   *          支払方法コード
   */
  public void setPaymentWayCode(String paymentWayCode) {
    this.paymentWayCode = paymentWayCode;
  }

  /**
   * 支払方法コードを取得する。
   *
   * @return 支払方法コード
   */
  public String getPaymentWayCode() {
    return this.paymentWayCode;
  }

  /**
   * 口座クレカIDを設定する。
   *
   * @param accountCreditCardId
   *          口座クレカID
   */
  public void setAccountCreditCardId(Integer accountCreditCardId) {
    this.accountCreditCardId = accountCreditCardId;
  }

  /**
   * 口座クレカIDを取得する。
   *
   * @return 口座クレカID
   */
  public Integer getAccountCreditCardId() {
    return this.accountCreditCardId;
  }

  /**
   * 個人・法人区分コード（支払履歴）を設定する。
   *
   * @param individualLegalEntityCategoryCodePaymentHistory
   *          個人・法人区分コード（支払履歴）
   */
  public void setIndividualLegalEntityCategoryCodePaymentHistory(
      String individualLegalEntityCategoryCodePaymentHistory) {
    this.individualLegalEntityCategoryCodePaymentHistory = individualLegalEntityCategoryCodePaymentHistory;
  }

  /**
   * 個人・法人区分コード（支払履歴）を取得する。
   *
   * @return 個人・法人区分コード（支払履歴）
   */
  public String getIndividualLegalEntityCategoryCodePaymentHistory() {
    return this.individualLegalEntityCategoryCodePaymentHistory;
  }

  /**
   * 請求先氏名1を設定する。
   *
   * @param billingName1
   *          請求先氏名1
   */
  public void setBillingName1(String billingName1) {
    this.billingName1 = billingName1;
  }

  /**
   * 請求先氏名1を取得する。
   *
   * @return 請求先氏名1
   */
  public String getBillingName1() {
    return this.billingName1;
  }

  /**
   * 請求先氏名2を設定する。
   *
   * @param billingName2
   *          請求先氏名2
   */
  public void setBillingName2(String billingName2) {
    this.billingName2 = billingName2;
  }

  /**
   * 請求先氏名2を取得する。
   *
   * @return 請求先氏名2
   */
  public String getBillingName2() {
    return this.billingName2;
  }

  /**
   * 敬称（支払履歴）を設定する。
   *
   * @param prefixPaymentHistory
   *          敬称（支払履歴）
   */
  public void setPrefixPaymentHistory(String prefixPaymentHistory) {
    this.prefixPaymentHistory = prefixPaymentHistory;
  }

  /**
   * 敬称（支払履歴）を取得する。
   *
   * @return 敬称（支払履歴）
   */
  public String getPrefixPaymentHistory() {
    return this.prefixPaymentHistory;
  }

  /**
   * 請求先住所（郵便番号）を設定する。
   *
   * @param billingAddressPostalCode
   *          請求先住所（郵便番号）
   */
  public void setBillingAddressPostalCode(String billingAddressPostalCode) {
    this.billingAddressPostalCode = billingAddressPostalCode;
  }

  /**
   * 請求先住所（郵便番号）を取得する。
   *
   * @return 請求先住所（郵便番号）
   */
  public String getBillingAddressPostalCode() {
    return this.billingAddressPostalCode;
  }

  /**
   * 請求先住所（都道府県名）を設定する。
   *
   * @param billingAddressPrefectures
   *          請求先住所（都道府県名）
   */
  public void setBillingAddressPrefectures(String billingAddressPrefectures) {
    this.billingAddressPrefectures = billingAddressPrefectures;
  }

  /**
   * 請求先住所（都道府県名）を取得する。
   *
   * @return 請求先住所（都道府県名）
   */
  public String getBillingAddressPrefectures() {
    return this.billingAddressPrefectures;
  }

  /**
   * 請求先住所（市区郡町村名）を設定する。
   *
   * @param billingAddressMunicipality
   *          請求先住所（市区郡町村名）
   */
  public void setBillingAddressMunicipality(String billingAddressMunicipality) {
    this.billingAddressMunicipality = billingAddressMunicipality;
  }

  /**
   * 請求先住所（市区郡町村名）を取得する。
   *
   * @return 請求先住所（市区郡町村名）
   */
  public String getBillingAddressMunicipality() {
    return this.billingAddressMunicipality;
  }

  /**
   * 請求先住所（字名・丁目）を設定する。
   *
   * @param billingAddressSection
   *          請求先住所（字名・丁目）
   */
  public void setBillingAddressSection(String billingAddressSection) {
    this.billingAddressSection = billingAddressSection;
  }

  /**
   * 請求先住所（字名・丁目）を取得する。
   *
   * @return 請求先住所（字名・丁目）
   */
  public String getBillingAddressSection() {
    return this.billingAddressSection;
  }

  /**
   * 請求先住所（番地･号）を設定する。
   *
   * @param billingAddressBlock
   *          請求先住所（番地･号）
   */
  public void setBillingAddressBlock(String billingAddressBlock) {
    this.billingAddressBlock = billingAddressBlock;
  }

  /**
   * 請求先住所（番地･号）を取得する。
   *
   * @return 請求先住所（番地･号）
   */
  public String getBillingAddressBlock() {
    return this.billingAddressBlock;
  }

  /**
   * 請求先住所（建物名）を設定する。
   *
   * @param billingAddressBuildingName
   *          請求先住所（建物名）
   */
  public void setBillingAddressBuildingName(String billingAddressBuildingName) {
    this.billingAddressBuildingName = billingAddressBuildingName;
  }

  /**
   * 請求先住所（建物名）を取得する。
   *
   * @return 請求先住所（建物名）
   */
  public String getBillingAddressBuildingName() {
    return this.billingAddressBuildingName;
  }

  /**
   * 請求先住所（部屋名）を設定する。
   *
   * @param billingAddressRoom
   *          請求先住所（部屋名）
   */
  public void setBillingAddressRoom(String billingAddressRoom) {
    this.billingAddressRoom = billingAddressRoom;
  }

  /**
   * 請求先住所（部屋名）を取得する。
   *
   * @return 請求先住所（部屋名）
   */
  public String getBillingAddressRoom() {
    return this.billingAddressRoom;
  }

  /**
   * 請求先電話番号を設定する。
   *
   * @param billingPhoneNo
   *          請求先電話番号
   */
  public void setBillingPhoneNo(String billingPhoneNo) {
    this.billingPhoneNo = billingPhoneNo;
  }

  /**
   * 請求先電話番号を取得する。
   *
   * @return 請求先電話番号
   */
  public String getBillingPhoneNo() {
    return this.billingPhoneNo;
  }

  /**
   * 請求先電話区分コードを設定する。
   *
   * @param billingPhoneCategoryCode
   *          請求先電話区分コード
   */
  public void setBillingPhoneCategoryCode(String billingPhoneCategoryCode) {
    this.billingPhoneCategoryCode = billingPhoneCategoryCode;
  }

  /**
   * 請求先電話区分コードを取得する。
   *
   * @return 請求先電話区分コード
   */
  public String getBillingPhoneCategoryCode() {
    return this.billingPhoneCategoryCode;
  }

  /**
   * 請求先メールアドレス1を設定する。
   *
   * @param billingMailAddress1
   *          請求先メールアドレス1
   */
  public void setBillingMailAddress1(String billingMailAddress1) {
    this.billingMailAddress1 = billingMailAddress1;
  }

  /**
   * 請求先メールアドレス1を取得する。
   *
   * @return 請求先メールアドレス1
   */
  public String getBillingMailAddress1() {
    return this.billingMailAddress1;
  }

  /**
   * 請求先メールアドレス2を設定する。
   *
   * @param billingMailAddress2
   *          請求先メールアドレス2
   */
  public void setBillingMailAddress2(String billingMailAddress2) {
    this.billingMailAddress2 = billingMailAddress2;
  }

  /**
   * 請求先メールアドレス2を取得する。
   *
   * @return 請求先メールアドレス2
   */
  public String getBillingMailAddress2() {
    return this.billingMailAddress2;
  }

  /**
   * メール送信日を設定する。
   *
   * @param mailSendDate
   *          メール送信日
   */
  public void setMailSendDate(Date mailSendDate) {
    this.mailSendDate = mailSendDate;
  }

  /**
   * メール送信日を取得する。
   *
   * @return メール送信日
   */
  public Date getMailSendDate() {
    return this.mailSendDate;
  }

  /**
   * 対象債権情報ビジネスBeanリストを取得する。
   *
   * @return 対象債権情報ビジネスBeanリスト
   */
  public List<SN040701_CoveredAssignmentBusinessBean> getCoveredAssignmentBusinessBeanList() {
    return coveredAssignmentBusinessBeanList;
  }

  /**
   * 対象債権情報ビジネスBeanリストを設定する。
   *
   * @param coveredAssignmentBusinessBeanList
   *          対象債権情報ビジネスBeanリスト
   */
  public void setCoveredAssignmentBusinessBeanList(
      List<SN040701_CoveredAssignmentBusinessBean> coveredAssignmentBusinessBeanList) {
    this.coveredAssignmentBusinessBeanList = coveredAssignmentBusinessBeanList;
  }
}