package jp.co.unisys.enability.cis.business.kj;

import jp.co.unisys.enability.cis.business.kj.model.RealQuantityHistoryBusinessBean;

/**
 * 実量歴管理ビジネスインターフェース。
 *
 * @author "Nihon Unisys, Ltd."
 *
 */
public interface KJ_RealQuantityHistoryBusiness {

  /**
   * 実量歴管理照会を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 実量歴一覧取得
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param RealQuantityHistoryBusinessBean
   *          実量歴管理BusinessBean
   * @return 実量歴管理BusinessBean
   */
  public RealQuantityHistoryBusinessBean inquiry(
      RealQuantityHistoryBusinessBean realQuantityHistoryBusinessBean);

  /**
   * 実量歴更新を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 実量歴更新
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param RealQuantityHistoryBusinessBean
   *          実量歴管理BusinessBean
   * @return 実量歴管理BusinessBean
   */
  public RealQuantityHistoryBusinessBean update(
      RealQuantityHistoryBusinessBean realQuantityHistoryBusinessBean);

  /**
   * 確定料金状態取得。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 確定料金状態取得
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param RealQuantityHistoryBusinessBean
   *          実量歴管理BusinessBean
   * @return 実量歴管理BusinessBean
   */
  public RealQuantityHistoryBusinessBean getChargeStatus(
      RealQuantityHistoryBusinessBean realQuantityHistoryBusinessBean);

}
