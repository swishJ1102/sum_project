package jp.co.unisys.enability.cis.business.rk.model;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * 料金メニュー検索APIの検索結果で、料金メニュー単価の情報を保持するビジネスクラス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_SearchRateMenuRateMenuUPBusinessBean {

  /**
   * 最低月額料金を保有する。
   */
  private BigDecimal minimumMonthlyCharge;

  /**
   * 適用開始日を保有する。
   */
  private Date applyStartDate;

  /**
   * 適用終了日を保有する。
   */
  private Date applyEndDate;

  /**
   * 基本料金単価明細を保有する。
   */
  private List<RK_SearchRateMenuBasicChargeUPDetailBusinessBean> basicChargeUPDetailList;

  /**
   * 従量料金単価明細を保有する。
   */
  private List<RK_SearchRateMenuUsageChargeUPDetailBusinessBean> usageChargeUPDetailList;

  /**
   * 最低月額料金のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 最低月額料金を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 最低月額料金
   */
  public BigDecimal getMinimumMonthlyCharge() {
    return this.minimumMonthlyCharge;
  }

  /**
   * 最低月額料金のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 最低月額料金を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param minimumMonthlyCharge
   *          最低月額料金
   */
  public void setMinimumMonthlyCharge(BigDecimal minimumMonthlyCharge) {
    this.minimumMonthlyCharge = minimumMonthlyCharge;
  }

  /**
   * 適用開始日のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 適用開始日を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 適用開始日
   */
  public Date getApplyStartDate() {
    return this.applyStartDate;
  }

  /**
   * 適用開始日のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 適用開始日を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param applyStartDate
   *          適用開始日
   */
  public void setApplyStartDate(Date applyStartDate) {
    this.applyStartDate = applyStartDate;
  }

  /**
   * 適用終了日のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 適用終了日を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 適用終了日
   */
  public Date getApplyEndDate() {
    return this.applyEndDate;
  }

  /**
   * 適用終了日のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 適用終了日を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param applyEndDate
   *          適用終了日
   */
  public void setApplyEndDate(Date applyEndDate) {
    this.applyEndDate = applyEndDate;
  }

  /**
   * 基本料金単価明細のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 基本料金単価明細を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 基本料金単価明細
   */
  public List<RK_SearchRateMenuBasicChargeUPDetailBusinessBean> getBasicChargeUPDetailList() {
    return this.basicChargeUPDetailList;
  }

  /**
   * 基本料金単価明細のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 基本料金単価明細を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param basicChargeUPDetailList
   *          基本料金単価明細
   */
  public void setBasicChargeUPDetailList(
      List<RK_SearchRateMenuBasicChargeUPDetailBusinessBean> basicChargeUPDetailList) {
    this.basicChargeUPDetailList = basicChargeUPDetailList;
  }

  /**
   * 従量料金単価明細のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 従量料金単価明細を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 従量料金単価明細
   */
  public List<RK_SearchRateMenuUsageChargeUPDetailBusinessBean> getUsageChargeUPDetailList() {
    return this.usageChargeUPDetailList;
  }

  /**
   * 従量料金単価明細のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 従量料金単価明細を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param usageChargeUPDetailList
   *          従量料金単価明細
   */
  public void setUsageChargeUPDetailList(
      List<RK_SearchRateMenuUsageChargeUPDetailBusinessBean> usageChargeUPDetailList) {
    this.usageChargeUPDetailList = usageChargeUPDetailList;
  }

}
