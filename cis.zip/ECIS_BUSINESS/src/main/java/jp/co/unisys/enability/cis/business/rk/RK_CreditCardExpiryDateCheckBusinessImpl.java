package jp.co.unisys.enability.cis.business.rk;

import java.util.Date;

import jp.co.unisys.enability.cis.business.common.DateBusiness;
import jp.co.unisys.enability.cis.business.rk.model.RK_ChargeCalcWarningCheckBusinessBean;
import jp.co.unisys.enability.cis.common.util.DateCalculateUtil;
import jp.co.unisys.enability.cis.common.util.StringConvertUtil;
import jp.co.unisys.enability.cis.common.util.constants.ECISCodeConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;
import jp.co.unisys.enability.cis.dao.rk.RK_ChargeCalcWarningCheckDao;
import jp.co.unisys.enability.cis.entity.common.AcInformation;

/**
 * BRK0103-03クレカ有効期限チェックビジネス
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.common.DateBusiness
 * @see jp.co.unisys.enability.cis.dao.rk.RK_ChargeCalcWarningCheckDao
 */
public class RK_CreditCardExpiryDateCheckBusinessImpl implements RK_ChargeCalcWarningCheckBusiness {

  /**
   * 日付関連共通ビジネス(DI)
   */
  private DateBusiness dateBusiness;

  /**
   * 料金計算警告共通DAO(DI)
   */
  private RK_ChargeCalcWarningCheckDao rkChargeCalcWarningCheckDao;

  /**
   * クレカ有効期限チェック
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * クレカ有効期限日とクレカ有効期限によりクレカ有効期限チェックを行う。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param chargeCalcWarningCheckBean
   *          《料金計算警告チェックビジネスBean》
   * @return 警告コード
   * @see jp.co.unisys.enability.cis.business.common.DateBusiness
   * @see jp.co.unisys.enability.cis.dao.rk.RK_ChargeCalcWarningCheckDao
   */
  @Override
  public String check(RK_ChargeCalcWarningCheckBusinessBean chargeCalcWarningCheckBean) {
    // パラメータ取得
    Date checkBaseDate = chargeCalcWarningCheckBean.getCheckBaseDate();

    // 口座クレカ情報取得
    AcInformation acInfomation = rkChargeCalcWarningCheckDao.selectAccountCreditCardInfo(
        chargeCalcWarningCheckBean.getContractId(), checkBaseDate);
    // 口座クレカ情報が取得できなかった場合、判定不要のため、処理終了
    if (acInfomation == null) {
      return null;
    }

    // 警告対象クレカ有効期限日取得
    // バッチ処理基準日から、規定の日数後の日付を取得する
    Date warningTargetCreditExpirationDate = dateBusiness.calcWorkDate(checkBaseDate,
        ECISCodeConstants.WORK_DAYS_FOR_CREDIT_CARD_EXPIRATION_DATE_WARNING_DAYS);

    // 警告対象クレカ有効期限日が設定されている場合
    if (warningTargetCreditExpirationDate != null) {
      // 口座クレカ情報.クレカ有効期限(年月)の月末を取得する
      Date creExpirationDate = StringConvertUtil.stringToDate(acInfomation.getCreExpirationDate(),
          ECISConstants.FORMAT_DATE_yyyyMM);
      Date creExpirationMonthMaximumDate = DateCalculateUtil.getEndOfMonth(creExpirationDate);

      // 警告対象クレカ有効期限日 > 口座クレカ情報.クレカ有効期限の月末 の場合
      // クレカ有効期限間近警告を返却する
      if (warningTargetCreditExpirationDate.compareTo(creExpirationMonthMaximumDate) > 0) {
        return ECISRKConstants.WARNING_CLASS_MASTER_CREDIT_CARD_EXPIRATION_DATE_NEAR;
      }
    }

    return null;
  }

  /**
   * 日付関連共通ビジネスのsetter（DI）
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 日付関連共通ビジネスを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param dateBusiness
   *          日付関連共通ビジネス
   */
  public void setDateBusiness(DateBusiness dateBusiness) {
    this.dateBusiness = dateBusiness;
  }

  /**
   * 料金計算警告共通DAOのsetter（DI）
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金計算警告共通DAOを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param rkChargeCalcWarningCheckDao
   *          料金計算警告共通DAO
   */
  public void setRkChargeCalcWarningCheckDao(RK_ChargeCalcWarningCheckDao rkChargeCalcWarningCheckDao) {
    this.rkChargeCalcWarningCheckDao = rkChargeCalcWarningCheckDao;
  }
}
