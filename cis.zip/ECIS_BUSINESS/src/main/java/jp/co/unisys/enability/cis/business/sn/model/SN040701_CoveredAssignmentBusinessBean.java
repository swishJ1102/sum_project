package jp.co.unisys.enability.cis.business.sn.model;

import java.util.Date;

/**
 * 対象債権情報ビジネスBean. メールデータに出力する対象債権情報を保持するBeanクラス
 *
 * @author "Nihon Unisys, Ltd."
 */
public class SN040701_CoveredAssignmentBusinessBean {

  /** 契約番号 */
  private String contractNo;

  /** ご利用年月 */
  private String usePeriod;

  /** ご利用金額 */
  private Long monthlyCharge;

  /** 譲渡年月日 */
  private Date assignmentDate;

  /**
   * 契約番号を設定する。
   *
   * @param contractNo
   *          契約番号
   */
  public void setContractNo(String contractNo) {
    this.contractNo = contractNo;
  }

  /**
   * 契約番号を取得する。
   *
   * @return 契約番号
   */
  public String getContractNo() {
    return this.contractNo;
  }

  /**
   * ご利用年月を設定する。
   *
   * @param usePeriod
   *          ご利用年月
   */
  public void setUsePeriod(String usePeriod) {
    this.usePeriod = usePeriod;
  }

  /**
   * ご利用年月を取得する。
   *
   * @return ご利用年月
   */
  public String getUsePeriod() {
    return this.usePeriod;
  }

  /**
   * ご利用金額を設定する。
   *
   * @param monthlyCharge
   *          ご利用金額
   */
  public void setMonthlyCharge(Long monthlyCharge) {
    this.monthlyCharge = monthlyCharge;
  }

  /**
   * ご利用金額を取得する。
   *
   * @return ご利用金額
   */
  public Long getMonthlyCharge() {
    return this.monthlyCharge;
  }

  /**
   * 譲渡年月日を設定する。
   *
   * @param assignmentDate
   *          譲渡年月日
   */
  public void setAssignmentDate(Date assignmentDate) {
    this.assignmentDate = assignmentDate;
  }

  /**
   * 譲渡年月日を取得する。
   *
   * @return 譲渡年月日
   */
  public Date getAssignmentDate() {
    return this.assignmentDate;
  }
}