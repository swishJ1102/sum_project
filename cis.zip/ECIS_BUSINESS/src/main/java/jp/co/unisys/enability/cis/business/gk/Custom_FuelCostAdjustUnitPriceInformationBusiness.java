package jp.co.unisys.enability.cis.business.gk;

import jp.co.unisys.enability.cis.business.gk.model.Custom_InquiryFuelCostAdjustUnitPriceBusinessBean;

/**
 * 燃調単価情報ビジネス_カスタムインターフェース
 *
 * @author "Nihon Unisys, Ltd."
 *
 *         変更履歴(kg-epj) 2016.02.04 ko 新規作成
 */
public interface Custom_FuelCostAdjustUnitPriceInformationBusiness {

  /**
   * 燃調単価情報を取得する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 燃調単価情報の取得を行う。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param businessBean
   *          燃調単価情報照会BusinessBean_カスタム
   * @return 燃調単価情報照会BusinessBean_カスタム
   */
  public Custom_InquiryFuelCostAdjustUnitPriceBusinessBean inquiryFuelCostAdjustUnitPrice(
      Custom_InquiryFuelCostAdjustUnitPriceBusinessBean businessBean);
}