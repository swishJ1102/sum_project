package jp.co.unisys.enability.cis.business.rk.model;

import java.util.List;

import jp.co.unisys.enability.cis.entity.rk.RK_InquiryAgentFixChargeResultEntityBean;

/**
 * 確定料金実績情報照会で、検索条件および検索結果を格納するビジネスBean
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * 確定料金実績情報ビジネス
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class InquiryAgentFixChargeResultBusinessBean {

  /**
   * 請求IDを保有する。
   */
  private Integer billingId;

  /**
   * 請求番号を保有する。
   */
  private String billingNo;

  /**
   * 契約IDを保有する。
   */
  private Integer contractId;

  /**
   * 契約番号を保有する。
   */
  private String contractNo;

  /**
   * ご利用年月FROMを保有する。
   */
  private String usePeriodFrom;

  /**
   * ご利用年月TOを保有する。
   */
  private String usePeriodTo;

  /**
   * 契約番号リストを保有する。
   */
  private List<String> contractNoList;

  /**
   * 確定料金実績情報リストを保有する。
   */
  private List<RK_InquiryAgentFixChargeResultEntityBean> agentFixChargeResultList;

  /**
   * リターンコードを保有する。
   */
  private String returnCode;

  /**
   * メッセージを保有する。
   */
  private String message;

  /**
   * 請求IDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求IDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 請求ID
   */
  public Integer getBillingId() {
    return this.billingId;
  }

  /**
   * 請求IDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求IDを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param billingId
   *          請求ID
   */
  public void setBillingId(Integer billingId) {
    this.billingId = billingId;
  }

  /**
   * 請求番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求番号を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 請求番号
   */
  public String getBillingNo() {
    return this.billingNo;
  }

  /**
   * 請求番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求番号を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param billingNo
   *          請求番号
   */
  public void setBillingNo(String billingNo) {
    this.billingNo = billingNo;
  }

  /**
   * 契約IDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約IDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約ID
   */
  public Integer getContractId() {
    return this.contractId;
  }

  /**
   * 契約IDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約IDを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractId
   *          契約ID
   */
  public void setContractId(Integer contractId) {
    this.contractId = contractId;
  }

  /**
   * 契約番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約番号を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約番号
   */
  public String getContractNo() {
    return this.contractNo;
  }

  /**
   * 契約番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約番号を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractNo
   *          契約番号
   */
  public void setContractNo(String contractNo) {
    this.contractNo = contractNo;
  }

  /**
   * ご利用年月FROMのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * ご利用年月FROMを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return ご利用年月FROM
   */
  public String getUsePeriodFrom() {
    return this.usePeriodFrom;
  }

  /**
   * ご利用年月FROMのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * ご利用年月FROMを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param usePeriodFrom
   *          ご利用年月FROM
   */
  public void setUsePeriodFrom(String usePeriodFrom) {
    this.usePeriodFrom = usePeriodFrom;
  }

  /**
   * ご利用年月TOのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * ご利用年月TOを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return ご利用年月TO
   */
  public String getUsePeriodTo() {
    return this.usePeriodTo;
  }

  /**
   * ご利用年月TOのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * ご利用年月TOを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param usePeriodTo
   *          ご利用年月TO
   */
  public void setUsePeriodTo(String usePeriodTo) {
    this.usePeriodTo = usePeriodTo;
  }

  /**
   * 契約番号リストのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約番号リストを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約番号リスト
   */
  public List<String> getContractNoList() {
    return this.contractNoList;
  }

  /**
   * 契約番号リストのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約番号リストを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractNoList
   *          契約番号リスト
   */
  public void setContractNoList(List<String> contractNoList) {
    this.contractNoList = contractNoList;
  }

  /**
   * 確定料金実績情報リストのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 確定料金実績情報リストを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 確定料金実績情報リスト
   */
  public List<RK_InquiryAgentFixChargeResultEntityBean> getAgentFixChargeResultList() {
    return this.agentFixChargeResultList;
  }

  /**
   * 確定料金実績情報リストのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 確定料金実績情報リストを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param fixChargeResultList
   *          確定料金実績情報リスト
   */
  public void setAgentFixChargeResultList(
      List<RK_InquiryAgentFixChargeResultEntityBean> agentFixChargeResultList) {
    this.agentFixChargeResultList = agentFixChargeResultList;
  }

  /**
   * リターンコードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return リターンコード
   */
  public String getReturnCode() {
    return this.returnCode;
  }

  /**
   * リターンコードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param returnCode
   *          リターンコード
   */
  public void setReturnCode(String returnCode) {
    this.returnCode = returnCode;
  }

  /**
   * メッセージのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return メッセージ
   */
  public String getMessage() {
    return this.message;
  }

  /**
   * メッセージのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param message
   *          メッセージ
   */
  public void setMessage(String message) {
    this.message = message;
  }

}
