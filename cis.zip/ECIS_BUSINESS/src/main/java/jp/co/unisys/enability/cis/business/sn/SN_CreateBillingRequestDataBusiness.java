package jp.co.unisys.enability.cis.business.sn;

import java.util.Properties;

import jp.co.unisys.enability.cis.business.sn.model.SN_BillingDetailInfoBusinessBean;
import jp.co.unisys.enability.cis.business.sn.model.SN_BillingRequestDataBusinessBean;

/**
 * 請求依頼データ作成ビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 *
 */
public interface SN_CreateBillingRequestDataBusiness {

  /**
   * 請求依頼データ作成（口振・クレカ）
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 口振・クレカの請求書に出力するデータを請求依頼データBeanに設定する。
   * 汎用化を考慮し、出力しない項目も請求依頼データBeanに設定しておき、
   * CSVファイルレコード設定情報ファイルを基に実際に出力する項目を制御する。
   * </pre>
   *
   * @param bean
   *          請求明細情報Bean
   * @param consignerCode
   *          委託者コード
   * @param prop
   *          プロパティオブジェクト
   * @return SN_BillingRequestDataBusinessBean 請求依頼データBean
   */
  SN_BillingRequestDataBusinessBean createBillingRequestDataBeanForAccountAndCredit(
      SN_BillingDetailInfoBusinessBean bean, String consignerCode, Properties prop);

  /**
   * 請求依頼データ作成（コンビニ・振込）
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * コンビニ・振込の請求書に出力するデータを請求依頼データBeanに設定する。
   * 汎用化を考慮し、出力しない項目も請求依頼データBeanに設定しておき、
   * CSVファイルレコード設定情報ファイルを基に実際に出力する項目を制御する。
   * </pre>
   *
   * @param bean
   *          請求明細情報Bean
   * @param consignerCode
   *          委託者コード
   * @param prop
   *          プロパティオブジェクト
   * @return SN_BillingRequestDataBusinessBean 請求依頼データBean
   */
  SN_BillingRequestDataBusinessBean createBillingRequestDataBeanForConveniAndTransfer(
      SN_BillingDetailInfoBusinessBean bean, String consignerCode, Properties prop);

  /**
   * 請求依頼データ作成（卸／取次事業者）
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 卸／取次事業者の請求書に出力するデータを請求依頼データBeanに設定する。
   * 汎用化を考慮し、出力しない項目も請求依頼データBeanに設定しておき、
   * CSVファイルレコード設定情報ファイルを基に実際に出力する項目を制御する。
   * </pre>
   *
   * @param bean
   *          請求明細情報Bean
   * @param consignerCode
   *          委託者コード
   * @param prop
   *          プロパティオブジェクト
   * @return SN_BillingRequestDataBusinessBean 請求依頼データBean
   */
  SN_BillingRequestDataBusinessBean createBillingRequestDataBeanForWsAgOp(
      SN_BillingDetailInfoBusinessBean bean, String consignerCode, Properties prop);

  /**
   * 請求依頼データ作成（債権回収依頼）
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 債権回収依頼の請求書に出力するデータを請求依頼データBeanに設定する。
   * 汎用化を考慮し、出力しない項目も請求依頼データBeanに設定しておき、
   * CSVファイルレコード設定情報ファイルを基に実際に出力する項目を制御する。
   * </pre>
   *
   * @param bean
   *          請求明細情報Bean
   * @param consignerCode
   *          委託者コード
   * @param prop
   *          プロパティオブジェクト
   * @return SN_BillingRequestDataBusinessBean 請求依頼データBean
   */
  SN_BillingRequestDataBusinessBean createBillingRequestDataBeanForReceivable(
      SN_BillingDetailInfoBusinessBean bean, String consignerCode, Properties prop);
}
