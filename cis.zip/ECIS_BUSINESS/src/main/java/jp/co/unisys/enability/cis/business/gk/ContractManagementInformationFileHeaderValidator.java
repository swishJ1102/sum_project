package jp.co.unisys.enability.cis.business.gk;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import jp.co.unisys.enability.cis.business.kj.model.ContractManagementInformationFileConfigCommon;
import jp.co.unisys.enability.cis.common.util.CommonValidationUtil;
import jp.co.unisys.enability.cis.common.util.EMSMessageResource;

/**
 * 契約管理情報ファイルヘッダー部チェッククラス<br>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class ContractManagementInformationFileHeaderValidator {

  /** プロパティクラスを定義 */
  private EMSMessageResource emsMessageResource;

  /**
   * メッセージプロパティキー管理のsetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージプロパティキー管理を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param emsMessageResource
   *          メッセージプロパティキー管理
   */
  public void setEmsMessageResource(EMSMessageResource emsMessageResource) {
    this.emsMessageResource = emsMessageResource;
  }

  /**
   * 契約管理情報ファイルヘッダー部のチェックを実施、チェック結果のメッセージListを返却する。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 1 引数のバリデーションを行う。
   * 2 チェック結果がNGの場合、戻り値のメッセージListにエラーメッセージを詰めて返却する。
   *
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param headerMap
   *          契約管理情報アップロードファイルのヘッダ行
   * @param fileKindMaskString
   *          ファイル種別チェック用文字列(^0$",^1$"等を想定)
   * @return メッセージList
   */
  public List<String> validate(Map<Integer, String> headerMap, String fileKindMaskString) {

    List<String> messageList = new ArrayList<String>();

    // ヘッダレコード種別：必須チェック
    String headerRecordClass = headerMap
        .get(ContractManagementInformationFileConfigCommon.HEADER_RECORD_KIND_INDEX);
    if (CommonValidationUtil.isNull(headerRecordClass)) {
      messageList.add(emsMessageResource.getMessage(
          EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
          new String[] {ContractManagementInformationFileConfigCommon.HEADER_RECORD_KIND_NAME }));

      // ヘッダレコード種別：正規表現チェック
    } else if (headerRecordClass != null
        && !CommonValidationUtil.checkByPattern(headerRecordClass,
            ContractManagementInformationFileConfigCommon.HEADER_RECORD_KIND_MASK_STRING)) {
      messageList.add(emsMessageResource.getMessage(
          EMSMessageResource.VALIDATION_REGEX_ITEM_KEY,
          new String[] {ContractManagementInformationFileConfigCommon.HEADER_RECORD_KIND_NAME }));
    }

    // ファイル種別：必須チェック
    String fileClass = headerMap.get(ContractManagementInformationFileConfigCommon.HEADER_FILE_KIND_INDEX);
    if (CommonValidationUtil.isNull(fileClass)) {
      messageList.add(emsMessageResource.getMessage(
          EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
          new String[] {ContractManagementInformationFileConfigCommon.HEADER_FILE_KIND_NAME }));

      // ファイル種別：正規表現チェック
    } else if (fileClass != null
        && !CommonValidationUtil.checkByPattern(fileClass, fileKindMaskString)) {
      messageList.add(emsMessageResource.getMessage(
          EMSMessageResource.VALIDATION_REGEX_ITEM_KEY,
          new String[] {ContractManagementInformationFileConfigCommon.HEADER_FILE_KIND_NAME }));
    }
    return messageList;
  }
}
