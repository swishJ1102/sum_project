package jp.co.unisys.enability.cis.business.sn.model;

/**
 * メール作成用ビジネスBeanクラス
 * 
 * @author "Nihon Unisys, Ltd."
 *
 */
public class SN_CreateMailBusinessBean {

}
