package jp.co.unisys.enability.cis.business.kj;

import java.sql.Timestamp;
import java.util.List;
import java.util.Locale;

import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.DuplicateKeyException;

import jp.co.unisys.enability.cis.business.kj.model.Custom_AddCustomContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.Custom_DeleteCustomContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.Custom_InquiryCustomContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.Custom_UpdateCustomContractBusinessBean;
import jp.co.unisys.enability.cis.common.Exception.BusinessLogicException;
import jp.co.unisys.enability.cis.common.Exception.SystemException;
import jp.co.unisys.enability.cis.common.util.KJ_CommonUtil;
import jp.co.unisys.enability.cis.common.util.ThreadContext;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISKJConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISReturnCodeConstants;
import jp.co.unisys.enability.cis.entity.common.CContract;
import jp.co.unisys.enability.cis.entity.common.CContractExample;
import jp.co.unisys.enability.cis.mapper.common.CContractMapper;

/**
 * カスタム契約情報ビジネス
 *
 * @author "Nihon Unisys, Ltd."
 *
 *         変更履歴(kg-epj) 2016.02.19 liu 新規作成
 *
 */
public class Custom_KJ_CustomContractInformationBusinessImpl implements Custom_KJ_CustomContractInformationBusiness {

  /**
   * メッセージプロパティ(DI)
   */
  private MessageSource messageSource;
  /**
   * 契約マッパー(DI)
   */
  private CContractMapper cContractMapper;
  /**
   * ログマネジャー
   */
  private static Logger logger = LogManager.getLogger();

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.kj.
   * Custom_KJ_CustomContractInformationBusiness #inquiry(jp.co.unisys.enability.cis
   * .business.kj.model.Custom_InquiryCustomContractBusinessBean)
   */
  @Override
  public Custom_InquiryCustomContractBusinessBean inquiry(
      Custom_InquiryCustomContractBusinessBean inquiryContractBusinessBean) {

    String errorMessage = null;

    // カスタム契約情報照会BusinessBeanの値を取得
    Integer contractId = inquiryContractBusinessBean.getContractId();

    try {
      errorMessage = messageSource.getMessage(
          KJ_CommonUtil.getMessageId(ECISReturnCodeConstants.RETURN_CODE_G017), new String[] {},
          Locale.getDefault());

      // 《カスタム契約情報共通Mapper》.契約情報取得を呼び出す。
      // 引数のキーと値をMapに関連付ける。
      CContractExample example = new CContractExample();
      example.createCriteria().andContractIdEqualTo(contractId);
      List<CContract> inquiryCustomContractorInformationEntityBeanList = cContractMapper.selectByExample(example);

      inquiryContractBusinessBean
          .setCustomContractInformationList(inquiryCustomContractorInformationEntityBeanList);
      // 正常終了
      inquiryContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);

    } catch (NoSuchMessageException ioe) {
      // [kg-epj]<d-start>
      //logger.error(messageSource.getMessage("error.E1129", null, Locale.getDefault()), ioe);
      // [kg-epj]<d-end>
      // [kg-epj]<i-start>
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, ioe);
      // [kg-epj]<i-end>
      inquiryContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      inquiryContractBusinessBean.setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
    } catch (DataAccessException e) {
      // [kg-epj]<d-start>
      //logger.error(messageSource.getMessage("error.E1129", null, Locale.getDefault()), e);
      // [kg-epj]<d-end>
      // [kg-epj]<i-start>
      logger.error(errorMessage, e);
      // [kg-epj]<i-end>
      // 例外が起きた場合はリターンコードに（G017）を設定し、処理を終了する。
      inquiryContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      inquiryContractBusinessBean.setMessage(errorMessage);
    }

    return inquiryContractBusinessBean;
  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.kj.
   * Custom_KJ_CustomContractInformationBusiness #update(jp.co.unisys.enability.cis
   * .business.kj.model.Custom_UpdateCustomContractBusinessBean)
   */
  @Override
  public Custom_UpdateCustomContractBusinessBean update(
      Custom_UpdateCustomContractBusinessBean updateContractBusinessBean) {
    String errorMessage = null;

    try {

      // リターンコード(G017)に対応するメッセージを取得する。
      errorMessage = messageSource.getMessage(KJ_CommonUtil
          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G017),
          new String[] {}, Locale.getDefault());

      // コンテキスト・ユーザID
      String contextUserId = ThreadContext.getRequestThreadContext()
          .get(ECISConstants.USER_ID_KEY).toString();
      // コンテキスト.モジュールコード
      String contextModuleCode = ThreadContext.getRequestThreadContext()
          .get(ECISConstants.CLASS_NAME_KEY).toString();

      // 契約者ID
      Integer contractId = updateContractBusinessBean.getContractId();

      // 契約情報存在チェック
      Custom_InquiryCustomContractBusinessBean param = new Custom_InquiryCustomContractBusinessBean();

      param.setContractId(contractId);

      // 契約情報照会
      Custom_InquiryCustomContractBusinessBean inquryContractResult = inquiry(param);
      String contractReturnCode = inquryContractResult.getReturnCode();

      List<CContract> inquryContractList = inquryContractResult
          .getCustomContractInformationList();

      // リターンコードが“0000”以外の場合、業務例外クラスをスローする
      if (!ECISReturnCodeConstants.RETURN_CODE_0000
          .equals(contractReturnCode)) {
        throw new BusinessLogicException(messageSource.getMessage(
            "error.E1285", new String[] {}, Locale.getDefault()),
            false);
      }
      // リターンコードが“0000”かつ返却値が0件の場合リターンコードに（P005）を設定し返却する。
      if (CollectionUtils.isEmpty(inquryContractList)) {

        updateContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P005);
        updateContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P005),
                new String[] {}, Locale.getDefault()));
        return updateContractBusinessBean;
      }

      CContract contract = new CContract();

      //契約ID
      contract.setContractId(updateContractBusinessBean.getContractId());

      //営業担当者・組織コード
      contract.setSalesDepartmentCd(updateContractBusinessBean.getSalesDepartmentCd());

      //問合わせ先コード
      contract.setContactCd(updateContractBusinessBean.getContactCd());

      // 更新回数
      contract.setUpdateCount(inquryContractList.get(0).getUpdateCount() + 1);

      Timestamp systemTime = new Timestamp(System.currentTimeMillis());

      // オンライン更新日時
      contract.setOnlineUpdateTime(systemTime);

      // オンライン更新ユーザID
      contract.setOnlineUpdateUserId(contextUserId);

      // 更新モジュールコード
      contract.setUpdateModuleCode(contextModuleCode);

      // 更新日時
      contract.setUpdateTime(systemTime);

      //契約Mapper呼び出し
      // conditionContractId 契約ID 更新条件
      // conditionUpdateCount 更新回数 更新条件
      CContractExample contractExample = new CContractExample();
      contractExample
          .createCriteria()
          .andContractIdEqualTo(
              inquryContractList
                  .get(0).getContractId());

      int updateContractCount = cContractMapper
          .updateByExampleSelective(contract, contractExample);

      // 契約情報更新結果が0件の場合リターンコードに（H001）を設定し返却する
      if (updateContractCount == 0) {
        updateContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_H001);
        updateContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_H001),
                new String[] {}, Locale.getDefault()));
        return updateContractBusinessBean;
      }

      updateContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);

    } catch (BusinessLogicException businessLogicException) {
      logger.error(errorMessage, businessLogicException);
      // 業務例外クラス
      updateContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      updateContractBusinessBean.setMessage(errorMessage);
    } catch (DataAccessException exception) {
      logger.error(errorMessage, exception);
      updateContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      updateContractBusinessBean.setMessage(errorMessage);
    } catch (NoSuchMessageException ioe) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, ioe);
      updateContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      updateContractBusinessBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
    } catch (SystemException se) {
      logger.error(errorMessage, se);
      updateContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      updateContractBusinessBean.setMessage(errorMessage);
    }
    return updateContractBusinessBean;
  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.kj.
   * Custom_KJ_CustomContractInformationBusiness #add(jp.co.unisys.enability.cis
   * .business.kj.model.Custom_AddCustomContractBusinessBean)
   */
  @Override
  public Custom_AddCustomContractBusinessBean add(
      Custom_AddCustomContractBusinessBean addContractBusinessBean) {

    String errorMessageG017 = null;
    String errorMessageD023 = null;

    try {

      // リターンコード(G017)に対応するメッセージを取得する。
      errorMessageG017 = messageSource.getMessage(KJ_CommonUtil
          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G017),
          new String[] {}, Locale.getDefault());

      // リターンコード(D023)に対応するメッセージを取得する。
      errorMessageD023 = messageSource.getMessage(KJ_CommonUtil
          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D023),
          new String[] {}, Locale.getDefault());

      // コンテキスト・ユーザID
      String contextUserId = ThreadContext.getRequestThreadContext()
          .get(ECISConstants.USER_ID_KEY).toString();
      // コンテキスト.モジュールコード
      String contextModuleCode = ThreadContext.getRequestThreadContext()
          .get(ECISConstants.CLASS_NAME_KEY).toString();

      CContract contract = new CContract();

      // 契約ID
      contract.setContractId(addContractBusinessBean.getContractId());
      // 営業担当者・組織コード
      contract.setSalesDepartmentCd(addContractBusinessBean.getSalesDepartmentCd());
      // 問合わせ先コード
      contract.setContactCd(addContractBusinessBean.getContactCd());
      // 更新回数
      contract.setUpdateCount(0);
      Timestamp systemTime = new Timestamp(System.currentTimeMillis());
      // 作成日時
      contract.setCreateTime(systemTime);
      // オンライン更新日時
      contract.setOnlineUpdateTime(systemTime);
      // オンライン更新ユーザID
      contract.setOnlineUpdateUserId(contextUserId);
      // 更新モジュールコード
      contract.setUpdateModuleCode(contextModuleCode);
      // 更新日時
      contract.setUpdateTime(systemTime);
      // 契約登録
      cContractMapper.insert(contract);

      addContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);
    } catch (DuplicateKeyException e) {
      logger.error(errorMessageD023, e);
      // 重複エラー
      addContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D023);
      addContractBusinessBean.setMessage(errorMessageD023);
    } catch (DataIntegrityViolationException dataIntegrityViolationException) {
      logger.error(errorMessageD023, dataIntegrityViolationException);
      // 制約違反例外クラス
      addContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D023);
      addContractBusinessBean.setMessage(errorMessageD023);
    } catch (NoSuchMessageException ioe) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, ioe);
      addContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      addContractBusinessBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
    } catch (DataAccessException e) {
      logger.error(errorMessageG017, e);
      addContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      addContractBusinessBean.setMessage(errorMessageG017);
    }
    return addContractBusinessBean;
  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.kj.Custom_KJ_CustomContractInformationBusiness#
   * delete
   * (jp.co.unisys.enability.cis.business.kj.model.Custom_DeleteCustomContractBusinessBean)
   */
  @Override
  public Custom_DeleteCustomContractBusinessBean delete(
      Custom_DeleteCustomContractBusinessBean deleteContractBusinessBean) {

    try {

      // カスタム契約情報削除
      int deleteByPrimaryKeyCnt = cContractMapper
          .deleteByPrimaryKey(deleteContractBusinessBean.getContractId());

      // 返却値が0件の場合
      if (deleteByPrimaryKeyCnt == 0) {
        deleteContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_H001);
        deleteContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_H001),
                new String[] {}, Locale.getDefault()));

        return deleteContractBusinessBean;
      }

      deleteContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);

      return deleteContractBusinessBean;

    } catch (NoSuchMessageException e) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, e);
      // メッセージプロパティ不在
      deleteContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      deleteContractBusinessBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);

      return deleteContractBusinessBean;
    }

  }

  /**
   * カスタム契約マッパーのセッター(DI)
   *
   * @param contractMapper
   *          カスタム契約マッパー
   */
  public void setCContractMapper(CContractMapper cContractMapper) {
    this.cContractMapper = cContractMapper;
  }

  /**
   * messageSourceのセッター(DI)
   *
   * @param messageSource
   *          メッセージソース
   *
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }

}
