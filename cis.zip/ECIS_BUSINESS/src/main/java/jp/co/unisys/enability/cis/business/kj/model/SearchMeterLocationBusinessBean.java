package jp.co.unisys.enability.cis.business.kj.model;

import java.util.Date;
import java.util.List;

import jp.co.unisys.enability.cis.entity.kj.KJ_SearchMeterLocationEntityBean;

/**
 * 口座クレカ情報一覧照会で、照会結果を格納するビジネスBean
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * 口座クレカ情報ビジネス
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class SearchMeterLocationBusinessBean {

  /**
   * 地点特定番号を保有する。
   */
  private String spotNo;

  /**
   * 契約開始日を保有する。
   */
  private Date contractStartDate;

  /**
   * メータ設置場所照会リストを保有する。
   */
  private List<KJ_SearchMeterLocationEntityBean> meterLocationList;

  /**
   * リターンコードを保有する。
   */
  private String returnCode;

  /**
   * メッセージを保有する。
   */
  private String message;

  /**
   * 地点特定番号のgetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 地点特定番号を取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 地点特定番号
   */
  public String getSpotNo() {
    return spotNo;
  }

  /**
   * 地点特定番号のsetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 地点特定番号を設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param spotNo
   *          地点特定番号
   */
  public void setSpotNo(String spotNo) {
    this.spotNo = spotNo;
  }

  /**
   * 契約開始日のgetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約開始日を取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 契約開始日
   */
  public Date getContractStartDate() {
    return contractStartDate;
  }

  /**
   * 契約開始日のsetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約開始日を設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param contractStartDate
   *          契約開始日
   */
  public void setContractStartDate(Date contractStartDate) {
    this.contractStartDate = contractStartDate;
  }

  /**
   * メータ設置場所照会リストのgetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メータ設置場所照会リストを取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return メータ設置場所照会リスト
   */
  public List<KJ_SearchMeterLocationEntityBean> getMeterLocationList() {
    return meterLocationList;
  }

  /**
   * メータ設置場所照会リストのsetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メータ設置場所照会リストを設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param meterLocationList
   *          メータ設置場所照会リスト
   */
  public void setMeterLocationList(
      List<KJ_SearchMeterLocationEntityBean> meterLocationList) {
    this.meterLocationList = meterLocationList;
  }

  /**
   * リターンコードのgetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return リターンコード
   */
  public String getReturnCode() {
    return returnCode;
  }

  /**
   * リターンコードのsetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param returnCode
   *          リターンコード
   */
  public void setReturnCode(String returnCode) {
    this.returnCode = returnCode;
  }

  /**
   * メッセージのgetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return メッセージ
   */
  public String getMessage() {
    return message;
  }

  /**
   * メッセージのsetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param message
   *          メッセージ
   */
  public void setMessage(String message) {
    this.message = message;
  }

}
