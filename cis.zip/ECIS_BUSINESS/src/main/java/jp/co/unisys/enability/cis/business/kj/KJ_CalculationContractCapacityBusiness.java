package jp.co.unisys.enability.cis.business.kj;

import jp.co.unisys.enability.cis.business.kj.model.KJ_CalculationContractCapacityBusinessBean;

/**
 * 契約電力算定処理ビジネスインターフェース
 *
 * @author "Nihon Unisys, Ltd."
 *
 */
public interface KJ_CalculationContractCapacityBusiness {

  /**
   * 契約電力算定処理の更新を行う。
   *
   * <pre>
   *  <p><b>【仕様詳細】</b></p>
   *  算定された契約電力を【実量歴管理】に更新する。
   * 《契約電力算定処理BusinessBean》.契約電力算定日時の年月と、《契約電力算定処理BusinessBean》.対象年月が一致する場合、
   * 【契約履歴】を更新する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param KJ_CalculationContractCapacityBusinessBean
   *          契約電力算定処理BusinessBean
   * @return 契約電力算定処理BusinessBean
   */
  public KJ_CalculationContractCapacityBusinessBean update(
      KJ_CalculationContractCapacityBusinessBean kjCalculationContractCapacityBusinessBean);
}
