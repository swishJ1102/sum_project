package jp.co.unisys.enability.cis.business.kj;

import jp.co.unisys.enability.cis.business.kj.model.Custom_InquiryCustomContractorBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.Custom_RegistCustomContractorBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.Custom_UpdateCustomContractorBusinessBean;

/**
 * カスタム契約者情報ビジネスインターフェース
 *
 * @author "Nihon Unisys, Ltd."
 *
 *         変更履歴(kg-epj) 2016.02.05 ko 新規作成
 */
public interface Custom_KJ_CustomContractorInformationBusiness {

  /**
   * カスタム契約者情報を取得する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * カスタム契約者情報の取得を行う。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param businessBean
   *          カスタム契約者情報照会BusinessBean
   * @return カスタム契約者情報照会BusinessBean
   */
  public Custom_InquiryCustomContractorBusinessBean inquiry(Custom_InquiryCustomContractorBusinessBean businessBean);

  /**
   * カスタム契約者情報登録を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * CRMまたは、低圧CISにて契約者の更新時に利用される。指定された「契約者番号」に該当する【カスタム契約者】を登録する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param registContractorBusinessBean
   *          カスタム 契約者情報登録BusinessBean
   * @return カスタム契約者情報登録BusinessBean
   */
  public Custom_RegistCustomContractorBusinessBean regist(
      Custom_RegistCustomContractorBusinessBean registContractorBusinessBean);

  /**
   * 契約者情報更新を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * CRMまたは、低圧CISにて契約者の更新時に利用される。指定された「契約者番号」に該当する【契約者】、【カスタム契約者】を更新する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param updateContractorBusinessBean
   *          カスタム契約者情報更新BusinessBean
   * @return カスタム契約者情報更新BusinessBean
   */
  public Custom_UpdateCustomContractorBusinessBean update(
      Custom_UpdateCustomContractorBusinessBean updateContractorBusinessBean);

}