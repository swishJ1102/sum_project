package jp.co.unisys.enability.cis.business.rk;

import java.util.Date;

import org.apache.commons.lang3.time.DateUtils;

import jp.co.unisys.enability.cis.business.rk.model.RK_UsageLinkageCheckCheckDataBusinessBean;
import jp.co.unisys.enability.cis.business.rk.model.RK_UsageLinkageCheckContractBusinessBean;
import jp.co.unisys.enability.cis.business.rk.model.RK_UsageLinkageCheckTermDecisionBusinessBean;
import jp.co.unisys.enability.cis.common.util.StringConvertUtil;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;
import jp.co.unisys.enability.cis.dao.rk.RK_UsageLinkageCheckDao;

/**
 * 対象期間不足チェックビジネス。
 *
 * @author "Nihon Unisys, Ltd.
 * @see jp.co.unisys.enability.cis.business.rk.RK_UsageLinkageCheckBusiness
 */
public class RK_CheckCoveredTermBusinessImpl implements
    RK_CheckFixUsageBusiness {

  /** 料金計算チェックビジネス(DI) */
  private RK_UsageLinkageCheckBusiness rkUsageLinkageCheckBusiness;

  /** 使用量連携チェックDAO（DI） */
  private RK_UsageLinkageCheckDao rkUsageLinkageCheckDao;

  /**
   * 対象期間不足チェック。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 対象の契約から算定期間を取得し、その算定期間すべての使用量が連携されているか判定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param checkDataBusinessBean
   *          チェック対象ビジネスBean
   * @param termDecisionBusinessBean
   *          期間判定情報ビジネスBean
   * @return true:処理継続、false:処理終了
   */
  @Override
  public boolean check(
      RK_UsageLinkageCheckCheckDataBusinessBean checkDataBusinessBean,
      RK_UsageLinkageCheckTermDecisionBusinessBean termDecisionBusinessBean) {

    // 継続フラグ
    boolean continuation = true;

    // 算定期間開始日・算定期間終了日
    Date calculateStartDate = null;
    Date calculateEndDate = null;

    // TODOメッセージに登録する料金算定期間・使用量対象期間
    StringBuilder calculateTerm = new StringBuilder();
    StringBuilder coveredTerm = new StringBuilder();

    // 契約情報ごとの繰り返し
    for (RK_UsageLinkageCheckContractBusinessBean contract : termDecisionBusinessBean
        .getContractList()) {

      // 前回使用終了日の取得
      Date lastTimeUserEd = rkUsageLinkageCheckDao.selectLastTimeUsageEd(contract.getContractNo(),
          checkDataBusinessBean.getMeterReadingDate());

      // 算定期間開始日の判定
      calculateStartDate = decideCalculateStartDate(lastTimeUserEd,
          contract.getContractStartDate());

      // 算定期間終了日の判定
      calculateEndDate = decideCalculateEndDate(termDecisionBusinessBean.getCoveredTermEndDate(),
          contract.getContractEndDate());

      // 確定使用量の対象期間と算定期間を比較して、対象期間の範囲が算定期間の範囲に対して不足している場合には、
      // TODOを登録し、【月次実績】.月次実績エラー区分コードを"エラー"で更新する
      if (termDecisionBusinessBean.getCoveredTermStartDate().compareTo(
          calculateStartDate) > 0
          || termDecisionBusinessBean.getCoveredTermEndDate()
              .compareTo(calculateEndDate) < 0) {

        // 初期化
        calculateTerm.setLength(0);

        // 算定期間を"yyyy/MM/dd～yyyy/MM/dd"の形式で文字列化
        calculateTerm.append(formatDate(calculateStartDate));
        calculateTerm.append(ECISRKConstants.TERM_NAMISEN_ZENKAKU);
        calculateTerm.append(formatDate(calculateEndDate));

        // 初期化
        coveredTerm.setLength(0);

        // 確定使用量の対象期間を"yyyy/MM/dd～yyyy/MM/dd"の形式で文字列化
        coveredTerm.append(formatDate(termDecisionBusinessBean
            .getCoveredTermStartDate()));
        coveredTerm.append(ECISRKConstants.TERM_NAMISEN_ZENKAKU);
        coveredTerm.append(formatDate(termDecisionBusinessBean
            .getCoveredTermEndDate()));

        // TODOメッセージを作成するパラメータ
        Object[] params = {
            // 確定使用量ファイル名
            checkDataBusinessBean.getFixUsageFileName(),
            // 地点特定番号
            checkDataBusinessBean.getSpotNo(),
            // エリアコード
            checkDataBusinessBean.getAreaCode(),
            // 処理日
            formatDate(checkDataBusinessBean.getExecuteDate()),
            // 契約番号
            contract.getContractNo(),
            // 料金算定期間
            calculateTerm.toString(),
            // 使用量対象期間
            coveredTerm.toString() };

        // TODO登録
        rkUsageLinkageCheckBusiness.registerTodo("todo.T1022", null, "todo.T1040", params,
            contract.getContractNo(), checkDataBusinessBean.getSpotNo(), null);

        // 月次実績エラー区分コードをエラーで更新
        rkUsageLinkageCheckBusiness
            .updateMonthlyUsageResultError(checkDataBusinessBean);

        // 処理を継続しない
        continuation = false;

        // エラーが発生した時点で繰り返し処理を終了する
        break;
      }
    }

    return continuation;
  }

  /**
   * 算定期間開始日を判定する。
   *
   * @param lastTimeUsageEndDate
   *          前回使用終了日
   * @param contractStartDate
   *          契約開始日
   * @return 算定期間開始日
   */
  private Date decideCalculateStartDate(Date lastTimeUsageEndDate, Date contractStartDate) {

    Date result = null;

    if (lastTimeUsageEndDate != null) {
      // 前回使用終了日が存在する場合は、前回使用終了日の翌日を算定期間開始日に設定する
      result = DateUtils.addDays(lastTimeUsageEndDate, 1);
    } else {
      // 前回検針日が存在しない場合は、契約開始日を算定期間開始日に設定する
      result = contractStartDate;
    }

    return result;
  }

  /**
   * 対象期間終了日と契約情報から算定期間終了日を判定する。
   *
   * @param usageEndDate
   *          対象期間終了日
   * @param contractEndDate
   *          契約終了日
   * @return 算定期間終了日
   */
  private Date decideCalculateEndDate(Date usageEndDate, Date contractEndDate) {
    Date result = null;

    if (usageEndDate.compareTo(contractEndDate) <= 0) {
      // 対象期間終了日が契約終了日以前の日付の場合

      // 対象期間終了日を算定期間終了日に設定する
      result = usageEndDate;
    } else {
      // 検針日が契約終了日よりも後の日付の場合、契約終了日を算定期間終了日に設定する
      result = contractEndDate;
    }

    return result;
  }

  /**
   * 日付を"yyyy/MM/dd"形式の文字列に変換する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で渡された日付を"yyyy/MM/dd"形式の文字列に変換し、結果として返す。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param targetDate
   *          変換対象の日付
   * @return 変換後の文字列
   */
  private String formatDate(Date targetDate) {
    return StringConvertUtil.convertDateToString(targetDate,
        ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH);
  }

  /**
   * 料金計算チェックビジネスを設定します。(DI)
   *
   * @author "Nihon Unisys, Ltd."
   * @param rkUsageLinkageCheckBusiness
   *          料金計算チェックビジネス
   */
  public void setRkUsageLinkageCheckBusiness(
      RK_UsageLinkageCheckBusiness rkUsageLinkageCheckBusiness) {
    this.rkUsageLinkageCheckBusiness = rkUsageLinkageCheckBusiness;
  }

  /**
   * 使用量連携チェックDAOを設定します。(DI)
   *
   * @author "Nihon Unisys, Ltd."
   * @param rkUsageLinkageCheckDao
   *          使用量連携チェックDAO
   */
  public void setRkUsageLinkageCheckDao(RK_UsageLinkageCheckDao rkUsageLinkageCheckDao) {
    this.rkUsageLinkageCheckDao = rkUsageLinkageCheckDao;
  }
}
