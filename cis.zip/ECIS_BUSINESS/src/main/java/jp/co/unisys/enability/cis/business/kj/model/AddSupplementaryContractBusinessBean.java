package jp.co.unisys.enability.cis.business.kj.model;

import java.math.BigDecimal;
import java.util.Date;

/**
 * 付帯契約情報追加で、登録条件を格納するビジネスBean
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * 契約情報ビジネス
 * 付帯契約情報ビジネス
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class AddSupplementaryContractBusinessBean {

  /**
   * 付帯契約IDを保有する。
   */
  private Integer supplementaryContractId;

  /**
   * 契約IDを保有する。
   */
  private Integer contractId;

  /**
   * 契約番号を保有する。
   */
  private String contractNo;

  /**
   * 付帯メニューIDを保有する。
   */
  private String supplementaryMenuId;

  /**
   * 付帯契約開始日を保有する。
   */
  private Date supplementaryContractStartDate;

  /**
   * 付帯契約終了日を保有する。
   */
  private Date supplementaryContractEndDate;

  /**
   * 額・率を保有する。
   */
  private BigDecimal amountOrRate;

  /**
   * リターンコードを保有する。
   */
  private String returnCode;

  /**
   * メッセージを保有する。
   */
  private String message;

  /**
   * 付帯契約IDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 付帯契約IDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 付帯契約ID
   */
  public Integer getSupplementaryContractId() {
    return this.supplementaryContractId;
  }

  /**
   * 付帯契約IDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 付帯契約IDを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param supplementaryContractId
   *          付帯契約ID
   */
  public void setSupplementaryContractId(Integer supplementaryContractId) {
    this.supplementaryContractId = supplementaryContractId;
  }

  /**
   * 契約IDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約IDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約ID
   */
  public Integer getContractId() {
    return this.contractId;
  }

  /**
   * 契約IDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約IDを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractId
   *          契約ID
   */
  public void setContractId(Integer contractId) {
    this.contractId = contractId;
  }

  /**
   * 契約番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約番号を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約番号
   */
  public String getContractNo() {
    return this.contractNo;
  }

  /**
   * 契約番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約番号を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractNo
   *          契約番号
   */
  public void setContractNo(String contractNo) {
    this.contractNo = contractNo;
  }

  /**
   * 付帯メニューIDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 付帯メニューIDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 付帯メニューID
   */
  public String getSupplementaryMenuId() {
    return this.supplementaryMenuId;
  }

  /**
   * 付帯メニューIDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 付帯メニューIDを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param supplementaryMenuId
   *          付帯メニューID
   */
  public void setSupplementaryMenuId(String supplementaryMenuId) {
    this.supplementaryMenuId = supplementaryMenuId;
  }

  /**
   * 付帯契約開始日のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 付帯契約開始日を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 付帯契約開始日
   */
  public Date getSupplementaryContractStartDate() {
    return this.supplementaryContractStartDate;
  }

  /**
   * 付帯契約開始日のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 付帯契約開始日を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param supplementaryContractStartDate
   *          付帯契約開始日
   */
  public void setSupplementaryContractStartDate(
      Date supplementaryContractStartDate) {
    this.supplementaryContractStartDate = supplementaryContractStartDate;
  }

  /**
   * 付帯契約終了日のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 付帯契約終了日を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 付帯契約終了日
   */
  public Date getSupplementaryContractEndDate() {
    return this.supplementaryContractEndDate;
  }

  /**
   * 付帯契約終了日のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 付帯契約終了日を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param supplementaryContractEndDate
   *          付帯契約終了日
   */
  public void setSupplementaryContractEndDate(
      Date supplementaryContractEndDate) {
    this.supplementaryContractEndDate = supplementaryContractEndDate;
  }

  /**
   * 額・率のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 額・率を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 額・率
   */
  public BigDecimal getAmountOrRate() {
    return this.amountOrRate;
  }

  /**
   * 額・率のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 額・率を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param amountOrRate
   *          額・率
   */
  public void setAmountOrRate(BigDecimal amountOrRate) {
    this.amountOrRate = amountOrRate;
  }

  /**
   * リターンコードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return リターンコード
   */
  public String getReturnCode() {
    return this.returnCode;
  }

  /**
   * リターンコードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param returnCode
   *          リターンコード
   */
  public void setReturnCode(String returnCode) {
    this.returnCode = returnCode;
  }

  /**
   * メッセージのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return メッセージ
   */
  public String getMessage() {
    return this.message;
  }

  /**
   * メッセージのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param message
   *          メッセージ
   */
  public void setMessage(String message) {
    this.message = message;
  }

}
