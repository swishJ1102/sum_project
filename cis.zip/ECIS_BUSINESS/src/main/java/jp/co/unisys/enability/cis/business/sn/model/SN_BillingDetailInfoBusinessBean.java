package jp.co.unisys.enability.cis.business.sn.model;

import java.util.Date;
import java.util.List;

import jp.co.unisys.enability.cis.entity.common.AcInformation;
import jp.co.unisys.enability.cis.entity.common.Bl;
import jp.co.unisys.enability.cis.entity.common.Contract;
import jp.co.unisys.enability.cis.entity.common.Contractor;
import jp.co.unisys.enability.cis.entity.common.Fcr;
import jp.co.unisys.enability.cis.entity.common.PaymentHist;
import jp.co.unisys.enability.cis.entity.common.Place;
import jp.co.unisys.enability.cis.entity.common.PmCompanyM;
import jp.co.unisys.enability.cis.entity.common.UrgeMng;

/**
 * 請求明細情報Bean. 請求依頼ファイル情報を格納するBeanクラス
 * 
 * @author "Nihon Unisys, Ltd."
 *
 */
public class SN_BillingDetailInfoBusinessBean extends SN_CreateMailBusinessBean {

  /** 《請求EntityBean》 */
  private Bl bl;

  /** 《契約者EntityBean》 */
  private Contractor contractor;

  /** 《口座クレカ情報EntityBean》 */
  private AcInformation acInformation;

  /** 《支払履歴EntityBean》 */
  private PaymentHist paymentHist;

  /** 《需要場所EntityBean》 */
  private Place place;

  /** 《督促管理EntityBean》 */
  private UrgeMng urgeMng;

  /** 《契約EntityBean》 */
  private Contract contract;

  /** 《提供モデル企業マスタEntityBean》 */
  private PmCompanyM pmCompanyM;

  /** 消費税等相当額 */
  private Long ctEquivalent;

  /** 預り金 */
  private Long depositsReceived;

  /** メール送信日 */
  private Date mailSendDate;

  /** 解約予告対象全契約番号 */
  private List<String> cancellationContrantNoList;

  /** 解約予告対象フラグ */
  private boolean cancellationPreviousNoticeFlg = false;

  /** 《確定料金実績EntityBean》リスト */
  private List<Fcr> fcrList;

  /** 契約数（他～ の件数） */
  private int totalContractOther;

  /** 全契約番号リスト */
  private List<String> contractNoList;

  /** 全利用年月リスト */
  private List<String> usePeriodList;

  /**
   * 《請求EntityBean》を設定する。
   *
   * @param bl
   *          《請求EntityBean》
   */
  public void setBl(Bl bl) {
    this.bl = bl;
  }

  /**
   * 《請求EntityBean》を取得する。
   *
   * @return 《請求EntityBean》
   */
  public Bl getBl() {
    return this.bl;
  }

  /**
   * 《契約者EntityBean》を設定する。
   *
   * @param contractor
   *          《契約者EntityBean》
   */
  public void setContractor(Contractor contractor) {
    this.contractor = contractor;
  }

  /**
   * 《契約者EntityBean》を取得する。
   *
   * @return 《契約者EntityBean》
   */
  public Contractor getContractor() {
    return this.contractor;
  }

  /**
   * 《口座クレカ情報EntityBean》を設定する。
   *
   * @param acInformation
   *          《口座クレカ情報EntityBean》
   */
  public void setAcInformation(AcInformation acInformation) {
    this.acInformation = acInformation;
  }

  /**
   * 《口座クレカ情報EntityBean》を取得する。
   *
   * @return 《口座クレカ情報EntityBean》
   */
  public AcInformation getAcInformation() {
    return this.acInformation;
  }

  /**
   * 《支払履歴EntityBean》を設定する。
   *
   * @param paymentHist
   *          《支払履歴EntityBean》
   */
  public void setPaymentHist(PaymentHist paymentHist) {
    this.paymentHist = paymentHist;
  }

  /**
   * 《支払履歴EntityBean》を取得する。
   *
   * @return 《支払履歴EntityBean》
   */
  public PaymentHist getPaymentHist() {
    return this.paymentHist;
  }

  /**
   * 《需要場所EntityBean》を設定する。
   *
   * @param place
   *          《需要場所EntityBean》
   */
  public void setPlace(Place place) {
    this.place = place;
  }

  /**
   * 《需要場所EntityBean》を取得する。
   *
   * @return 《需要場所EntityBean》
   */
  public Place getPlace() {
    return this.place;
  }

  /**
   * 《督促管理EntityBean》を設定する。
   *
   * @param urgeMng
   *          《督促管理EntityBean》
   */
  public void setUrgeMng(UrgeMng urgeMng) {
    this.urgeMng = urgeMng;
  }

  /**
   * 《督促管理EntityBean》を取得する。
   *
   * @return 《督促管理EntityBean》
   */
  public UrgeMng getUrgeMng() {
    return this.urgeMng;
  }

  /**
   * 《契約EntityBean》を設定する。
   *
   * @param contract
   *          《契約EntityBean》
   */
  public void setContract(Contract contract) {
    this.contract = contract;
  }

  /**
   * 《契約EntityBean》を取得する。
   *
   * @return 《契約EntityBean》
   */
  public Contract getContract() {
    return this.contract;
  }

  /**
   * 《提供モデル企業マスタEntityBean》を設定する。
   *
   * @param pmCompanyM
   *          《提供モデル企業マスタEntityBean》
   */
  public void setPmCompanyM(PmCompanyM pmCompanyM) {
    this.pmCompanyM = pmCompanyM;
  }

  /**
   * 《提供モデル企業マスタEntityBean》を取得する。
   *
   * @return 《提供モデル企業マスタEntityBean》
   */
  public PmCompanyM getPmCompanyM() {
    return this.pmCompanyM;
  }

  /**
   * 消費税等相当額を設定する。
   *
   * @param ctEquivalent
   *          消費税等相当額
   */
  public void setCtEquivalent(Long ctEquivalent) {
    this.ctEquivalent = ctEquivalent;
  }

  /**
   * 消費税等相当額を取得する。
   *
   * @return 消費税等相当額
   */
  public Long getCtEquivalent() {
    return this.ctEquivalent;
  }

  /**
   * 預り金を設定する。
   *
   * @param depositsReceived
   *          預り金
   */
  public void setDepositsReceived(Long depositsReceived) {
    this.depositsReceived = depositsReceived;
  }

  /**
   * 預り金を取得する。
   *
   * @return 預り金
   */
  public Long getDepositsReceived() {
    return this.depositsReceived;
  }

  /**
   * メール送信日を設定する。
   *
   * @param mailSendDate
   *          メール送信日
   */
  public void setMailSendDate(Date mailSendDate) {
    this.mailSendDate = mailSendDate;
  }

  /**
   * メール送信日を取得する。
   *
   * @return メール送信日
   */
  public Date getMailSendDate() {
    return this.mailSendDate;
  }

  /**
   * 解約予告対象全契約番号を設定する。
   *
   * @param cancellationContrantNoAll
   *          解約予告対象全契約番号
   */
  public void setCancellationContrantNoList(List<String> cancellationContrantNoList) {
    this.cancellationContrantNoList = cancellationContrantNoList;
  }

  /**
   * 解約予告対象全契約番号を取得する。
   *
   * @return 解約予告対象全契約番号
   */
  public List<String> getCancellationContrantNoList() {
    return this.cancellationContrantNoList;
  }

  /**
   * 解約予告対象フラグを設定する。
   *
   * @param cancellationPreviousNoticeFlg
   *          解約予告対象フラグ
   */
  public void setCancellationPreviousNoticeFlg(boolean cancellationPreviousNoticeFlg) {
    this.cancellationPreviousNoticeFlg = cancellationPreviousNoticeFlg;
  }

  /**
   * 解約予告対象フラグを取得する。
   *
   * @return 解約予告対象フラグ
   */
  public boolean getCancellationPreviousNoticeFlg() {
    return this.cancellationPreviousNoticeFlg;
  }

  /**
   * 《確定料金実績EntityBean》リストを設定する。
   *
   * @param fcrList
   *          《確定料金実績EntityBean》リスト
   */
  public void setFcrList(List<Fcr> fcrList) {
    this.fcrList = fcrList;
  }

  /**
   * 《確定料金実績EntityBean》リストを取得する。
   *
   * @return 《確定料金実績EntityBean》リスト
   */
  public List<Fcr> getFcrList() {
    return this.fcrList;
  }

  /**
   * 全契約番号リストを設定する。
   *
   * @param contractNoList
   *          全契約番号リスト
   */
  public void setContractNoList(List<String> contractNoList) {
    this.contractNoList = contractNoList;
  }

  /**
   * 全契約番号リストを取得する。
   *
   * @return 全契約番号リスト
   */
  public List<String> getContractNoList() {
    return this.contractNoList;
  }

  /**
   * 契約数（他～ の件数）を設定する。
   *
   * @param totalContractOther
   *          契約数（他～ の件数）
   */
  public void setTotalContractOther(int totalContractOther) {
    this.totalContractOther = totalContractOther;
  }

  /**
   * 契約数（他～ の件数）を取得する。
   *
   * @return 契約数（他～ の件数）
   */
  public int getTotalContractOther() {
    return this.totalContractOther;
  }

  /**
   * 全利用年月を取得する。
   *
   * @return 全利用年月
   */
  public List<String> getUsePeriodList() {
    return usePeriodList;
  }

  /**
   * 全利用年月リストを設定する。
   *
   * @param usePeriodList
   *          全利用年月リスト
   */
  public void setUsePeriodList(List<String> usePeriodList) {
    this.usePeriodList = usePeriodList;
  }

}
