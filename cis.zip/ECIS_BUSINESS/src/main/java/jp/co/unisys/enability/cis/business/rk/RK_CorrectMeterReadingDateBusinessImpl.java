package jp.co.unisys.enability.cis.business.rk;

import java.sql.Timestamp;
import java.util.Date;

import org.springframework.beans.factory.config.PropertiesFactoryBean;

import jp.co.unisys.enability.cis.common.util.RK_PropertyUtil;
import jp.co.unisys.enability.cis.common.util.ThreadContext;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.dao.rk.RK_FixChargePreprocessDao;

/**
 * BRK0111-01確定使用量前処理ビジネス
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.dao.rk.RK_FixChargePreprocessDao
 */
public class RK_CorrectMeterReadingDateBusinessImpl implements
    RK_FixChargePreprocessBusiness {

  /** 確定使用量前処理Dao(DI) */
  private RK_FixChargePreprocessDao rkFixChargePreprocessDao;

  /**
   * プロパティ(DI)
   */
  private PropertiesFactoryBean applicationProperties;

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.rk.RK_FixChargePreprocess#process()
   */
  @Override
  public void process(Date executeDate) {

    // タイムスタンプ・モジュールコード
    Timestamp updateTime = new Timestamp(new Date().getTime());
    String moduleCode = (String) ThreadContext.getRequestThreadContext()
        .get(ECISConstants.CLASS_NAME_KEY);

    // 検針日補正エリアの取得
    String[] updateMeterReadingDateArea = RK_PropertyUtil.getProperty(applicationProperties,
        "fixchargepreprocess.updatemeterreadingdate.arealist").split(",");

    rkFixChargePreprocessDao.updateMeterReadingDateForKansai(executeDate, updateTime, moduleCode);
    rkFixChargePreprocessDao
        .updateMeterReadingDate(executeDate, updateMeterReadingDateArea, updateTime, moduleCode);
  }

  /**
   * 確定使用量前処理Daoを設定します。(DI)
   *
   * @param rkFixChargePreprocessDao
   *          確定使用量前処理Dao(DI)
   */
  public void setRkFixChargePreprocessDao(
      RK_FixChargePreprocessDao rkFixChargePreprocessDao) {
    this.rkFixChargePreprocessDao = rkFixChargePreprocessDao;
  }

  /**
   * アプリケーションプロパティを設定します。(DI)
   *
   * @author "Nihon Unisys, Ltd."
   * @param applicationProperties
   *          アプリケーションプロパティ
   */
  public void setApplicationProperties(
      PropertiesFactoryBean applicationProperties) {
    this.applicationProperties = applicationProperties;
  }
}
