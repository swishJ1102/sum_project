package jp.co.unisys.enability.cis.business.gk;

/**
 * アクセスログ登録
 * 
 * <pre>
 * <p><b>【仕様詳細】<b><p>
 * アクセスログ登録を行う。
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public interface AccessLogRegisterBussiness {

  /**
   * アクセスログファイルにログを出力する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 1.システム日付に該当するアクセスファイルが存在しない場合、アクセスログファイルを作成する。
   * 2.アクセスログファイルのサイズが外部ファイルで定義されているファイルサイズを超過している場合、ローテーションする。
   * 3.画面マスタから引数の画面IDに該当する画面名を取得する。
   * 4.アクションマスタから引数のアクションIDに該当するアクション名を取得する。
   * 5.アクセスログにシステム日時、ユーザID、画面名、アクション名、処理内容詳細を出力する。
   *   画面名、アクション名が取得できない場合は、画面ID、アクションIDをログに出力する。
   * </pre>
   *
   * @param userId
   *          ユーザID
   * @param dispId
   *          画面ID
   * @param actionId
   *          アクションID
   * @param value
   *          操作内容詳細
   */
  public void accessLogRegister(String userId, String dispId, String actionId, String value);

}
