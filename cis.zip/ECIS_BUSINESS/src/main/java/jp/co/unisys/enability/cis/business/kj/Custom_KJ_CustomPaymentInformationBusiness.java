package jp.co.unisys.enability.cis.business.kj;

import jp.co.unisys.enability.cis.business.kj.model.Custom_DeleteCustomPaymentBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.Custom_RegistCustomPaymentBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.Custom_UpdateCustomPaymentBusinessBean;

/**
 * 支払情報ビジネス_カスタムインターフェース。
 *
 * @author "Nihon Unisys, Ltd."
 *
 *         変更履歴(kg-epj) 2016.02.22 芦垣 新規作成
 *
 */
public interface Custom_KJ_CustomPaymentInformationBusiness {

  /**
   * 支払情報の登録を行う。
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * CRMや低圧CISから、「契約者」に紐付く【カスタム支払履歴】を登録する場合に使用する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param registPaymentBusinessBean
   *          支払情報登録BusinessBean_カスタム
   * @return 支払情報登録BusinessBean_カスタム
   */
  public Custom_RegistCustomPaymentBusinessBean regist(
      Custom_RegistCustomPaymentBusinessBean registPaymentBusinessBean);

  /**
   * 支払情報更新を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 指定された支払情報を更新する。確定された請求に使用されているかどうかチェックし、使用されていた場合、更新不可とする。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param updatePaymentBusinessBean
   *          支払情報更新BusinessBean_カスタム
   * @return 支払情報更新BusinessBean_カスタム
   */
  public Custom_UpdateCustomPaymentBusinessBean update(
      Custom_UpdateCustomPaymentBusinessBean updatePaymentBusinessBean);

  /**
   * 支払情報削除を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 指定された支払情報を削除する。確定された請求に使用されているかどうかチェックし、使用されていた場合、削除不可とする。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param deletePaymentBusinessBean
   *          カスタム支払情報削除BusinessBean_カスタム
   * @return カスタム支払情報削除BusinessBean_カスタム
   */
  public Custom_DeleteCustomPaymentBusinessBean delete(
      Custom_DeleteCustomPaymentBusinessBean deletePaymentBusinessBean);

}
