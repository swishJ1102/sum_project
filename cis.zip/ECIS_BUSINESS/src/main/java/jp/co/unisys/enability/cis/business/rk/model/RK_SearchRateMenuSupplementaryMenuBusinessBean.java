package jp.co.unisys.enability.cis.business.rk.model;

import java.util.List;

/**
 * 料金メニュー検索APIの検索結果で、付帯メニューの情報を保持するビジネスクラス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_SearchRateMenuSupplementaryMenuBusinessBean {

  /**
   * 付帯メニューIDを保有する。
   */
  private String supplementaryMenuId;

  /**
   * 付帯メニューを保有する。
   */
  private String supplementaryMenu;

  /**
   * 表示用名称を保有する。
   */
  private String displayName;

  /**
   * 付帯種別コードを保有する。
   */
  private String supplementaryClassCode;

  /**
   * 付帯種別を保有する。
   */
  private String supplementaryClass;

  /**
   * 付帯対象区分コードを保有する。
   */
  private String supplementaryCoveredCategoryCode;

  /**
   * 付帯対象区分を保有する。
   */
  private String supplementaryCoveredCategory;

  /**
   * 割引・割増区分コードを保有する。
   */
  private String discountCategoryCode;

  /**
   * 割引・割増区分を保有する。
   */
  private String discountSurchargeCategory;

  /**
   * 個別設定フラグを保有する。
   */
  private String individualSettingFlag;

  /**
   * 売買区分コードを保有する。
   */
  private String saleCategoryCode;

  /**
   * 売買区分を保有する。
   */
  private String saleCategory;

  /**
   * 表示順を保有する。
   */
  private Integer displayOrder;

  /**
   * 付帯メニュー単価リストを保有する。
   */
  private List<RK_SearchRateMenuSupplementaryMenuUPBusinessBean> supplementaryMenuUPList;

  /**
   * 付帯メニューIDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 付帯メニューIDを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 付帯メニューID
   */
  public String getSupplementaryMenuId() {
    return this.supplementaryMenuId;
  }

  /**
   * 付帯メニューIDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 付帯メニューIDを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param supplementaryMenuId
   *          付帯メニューID
   */
  public void setSupplementaryMenuId(String supplementaryMenuId) {
    this.supplementaryMenuId = supplementaryMenuId;
  }

  /**
   * 付帯メニューのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 付帯メニューを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 付帯メニュー
   */
  public String getSupplementaryMenu() {
    return this.supplementaryMenu;
  }

  /**
   * 付帯メニューのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 付帯メニューを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param supplementaryMenu
   *          付帯メニュー
   */
  public void setSupplementaryMenu(String supplementaryMenu) {
    this.supplementaryMenu = supplementaryMenu;
  }

  /**
   * 表示用名称のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 表示用名称を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 表示用名称
   */
  public String getDisplayName() {
    return this.displayName;
  }

  /**
   * 表示用名称のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 表示用名称を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param displayName
   *          表示用名称
   */
  public void setDisplayName(String displayName) {
    this.displayName = displayName;
  }

  /**
   * 付帯種別コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 付帯種別コードを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 付帯種別コード
   */
  public String getSupplementaryClassCode() {
    return this.supplementaryClassCode;
  }

  /**
   * 付帯種別コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 付帯種別コードを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param supplementaryClassCode
   *          付帯種別コード
   */
  public void setSupplementaryClassCode(String supplementaryClassCode) {
    this.supplementaryClassCode = supplementaryClassCode;
  }

  /**
   * 付帯種別のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 付帯種別を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 付帯種別
   */
  public String getSupplementaryClass() {
    return this.supplementaryClass;
  }

  /**
   * 付帯種別のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 付帯種別を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param supplementaryClass
   *          付帯種別
   */
  public void setSupplementaryClass(String supplementaryClass) {
    this.supplementaryClass = supplementaryClass;
  }

  /**
   * 付帯対象区分コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 付帯対象区分コードを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 付帯対象区分コード
   */
  public String getSupplementaryCoveredCategoryCode() {
    return this.supplementaryCoveredCategoryCode;
  }

  /**
   * 付帯対象区分コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 付帯対象区分コードを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param supplementaryCoveredCategoryCode
   *          付帯対象区分コード
   */
  public void setSupplementaryCoveredCategoryCode(
      String supplementaryCoveredCategoryCode) {
    this.supplementaryCoveredCategoryCode = supplementaryCoveredCategoryCode;
  }

  /**
   * 付帯対象区分のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 付帯対象区分を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 付帯対象区分
   */
  public String getSupplementaryCoveredCategory() {
    return this.supplementaryCoveredCategory;
  }

  /**
   * 付帯対象区分のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 付帯対象区分を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param supplementaryCoveredCategory
   *          付帯対象区分
   */
  public void setSupplementaryCoveredCategory(
      String supplementaryCoveredCategory) {
    this.supplementaryCoveredCategory = supplementaryCoveredCategory;
  }

  /**
   * 割引・割増区分コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 割引・割増区分コードを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 割引・割増区分コード
   */
  public String getDiscountCategoryCode() {
    return this.discountCategoryCode;
  }

  /**
   * 割引・割増区分コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 割引・割増区分コードを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param discountCategoryCode
   *          割引・割増区分コード
   */
  public void setDiscountCategoryCode(String discountCategoryCode) {
    this.discountCategoryCode = discountCategoryCode;
  }

  /**
   * 割引・割増区分のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 割引・割増区分を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 割引・割増区分
   */
  public String getDiscountSurchargeCategory() {
    return this.discountSurchargeCategory;
  }

  /**
   * 割引・割増区分のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 割引・割増区分を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param discountSurchargeCategory
   *          割引・割増区分
   */
  public void setDiscountSurchargeCategory(String discountSurchargeCategory) {
    this.discountSurchargeCategory = discountSurchargeCategory;
  }

  /**
   * 個別設定フラグのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 個別設定フラグを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 個別設定フラグ
   */
  public String getIndividualSettingFlag() {
    return this.individualSettingFlag;
  }

  /**
   * 個別設定フラグのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 個別設定フラグを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param individualSettingFlag
   *          個別設定フラグ
   */
  public void setIndividualSettingFlag(String individualSettingFlag) {
    this.individualSettingFlag = individualSettingFlag;
  }

  /**
   * 売買区分コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 売買区分コードを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 売買区分コード
   */
  public String getSaleCategoryCode() {
    return this.saleCategoryCode;
  }

  /**
   * 売買区分コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 売買区分コードを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param saleCategoryCode
   *          売買区分コード
   */
  public void setSaleCategoryCode(String saleCategoryCode) {
    this.saleCategoryCode = saleCategoryCode;
  }

  /**
   * 売買区分のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 売買区分を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 売買区分
   */
  public String getSaleCategory() {
    return this.saleCategory;
  }

  /**
   * 売買区分のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 売買区分を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param saleCategory
   *          売買区分
   */
  public void setSaleCategory(String saleCategory) {
    this.saleCategory = saleCategory;
  }

  /**
   * 表示順のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 表示順を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 表示順
   */
  public Integer getDisplayOrder() {
    return this.displayOrder;
  }

  /**
   * 表示順のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 表示順を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param displayOrder
   *          表示順
   */
  public void setDisplayOrder(Integer displayOrder) {
    this.displayOrder = displayOrder;
  }

  /**
   * 付帯メニュー単価リストのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 付帯メニュー単価リストを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 付帯メニュー単価リスト
   */
  public List<RK_SearchRateMenuSupplementaryMenuUPBusinessBean> getSupplementaryMenuUPList() {
    return this.supplementaryMenuUPList;
  }

  /**
   * 付帯メニュー単価リストのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 付帯メニュー単価リストを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param supplementaryMenuUPList
   *          付帯メニュー単価リスト
   */
  public void setSupplementaryMenuUPList(
      List<RK_SearchRateMenuSupplementaryMenuUPBusinessBean> supplementaryMenuUPList) {
    this.supplementaryMenuUPList = supplementaryMenuUPList;
  }

}
