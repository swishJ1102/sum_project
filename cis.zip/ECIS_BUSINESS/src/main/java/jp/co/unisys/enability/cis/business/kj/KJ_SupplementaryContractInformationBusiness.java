package jp.co.unisys.enability.cis.business.kj;

import jp.co.unisys.enability.cis.business.kj.model.AddSupplementaryContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.CsvFileCheckSupplementaryContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.DeleteSupplementaryContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.DownloadSupplementaryContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.InquirySupplementaryContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.UpdateSupplementaryContractBusinessBean;

/**
 * 付帯契約情報ビジネスインターフェース。
 *
 * @author "Nihon Unisys, Ltd."
 *
 */
public interface KJ_SupplementaryContractInformationBusiness {

  /**
   * 付帯契約情報照会を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * CRMや低圧CISにて【契約】に紐付く【付帯契約】の照会に利用される。
   * 指定された「契約番号」、「付帯メニュー」、「照会対象日付」に該当する【付帯契約】の情報を返却する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param inquirySupplementaryContractBusinessBean
   *          付帯契約情報照会BusinessBean
   * @return 付帯契約情報照会BusinessBean
   */
  public InquirySupplementaryContractBusinessBean inquiry(
      InquirySupplementaryContractBusinessBean inquirySupplementaryContractBusinessBean);

  /**
   * 付帯契約情報更新を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約に付帯メニューを紐付ける際に利用される。
   * 指定の契約に紐付く付帯契約情報の付帯契約終了日を更新する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param updateSupplementaryContractBusinessBean
   *          付帯契約情報更新BusinessBean》
   * @return 付帯契約情報更新BusinessBean
   */
  public UpdateSupplementaryContractBusinessBean update(
      UpdateSupplementaryContractBusinessBean updateSupplementaryContractBusinessBean);

  /**
   * 付帯契約情報削除を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 付帯情報削除にて付帯情報の削除時に利用される。
   * 指定の契約に紐付く付帯契約情報を削除する。ただし、既に料金実績が確定している場合は、エラーとする。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param deleteSupplementaryContractBusinessBean
   *          付帯契約情報削除BusinessBean
   * @return 付帯契約情報削除BusinessBean
   */
  public DeleteSupplementaryContractBusinessBean delete(
      DeleteSupplementaryContractBusinessBean deleteSupplementaryContractBusinessBean);

  /**
   * 付帯契約情報追加を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約に付帯メニューを紐付ける際に利用される。
   * 指定された「契約番号」、「付帯メニュー」の情報を低圧CISの【付帯契約】に登録する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param addSupplementaryContractBusinessBean
   *          付帯契約情報追加BusinessBean
   * @return 付帯契約情報追加BusinessBean
   */
  public AddSupplementaryContractBusinessBean add(
      AddSupplementaryContractBusinessBean addSupplementaryContractBusinessBean);

  /**
   * ダウンロードファイルの情報を取得する処理を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 1       ダウンロードファイル情報取得のMapperを呼び出し、ダウンロードファイル情報を取得する。
   * 2       CSVファイル名を生成する。
   * 3       DownloadSupplementaryContractBusinessBeanにダウンロードファイル情報とCSVファイル名を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param DownloadSupplementaryContractBusinessBean
   *          検索条件
   * @return DownloadSupplementaryContractBusinessBean ダウンロードファイル情報、CSVファイル名
   * @see jp.co.unisys.enability.cis.mapper.kj.SupplementaryContractInformationCommonMapper
   */
  DownloadSupplementaryContractBusinessBean download(
      DownloadSupplementaryContractBusinessBean downloadBusinessBean);

  /**
   * アップロードファイルのヘッダレコード、データレコードをチェックし、チェックでエラーにならない場合、DB更新用のオブジェクトを返却する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   *         返却用オブジェクトを生成する。
   * 1       ヘッダレコードチェック処理を行い、入力内容に誤りがある場合、エラー情報を返却用オブジェクトに設定し、処理を終了する。
   * 2       データレコードチェック処理を全てのデータレコード行数分、チェックを行う。
   * 3       入力内容に誤りがある場合、エラー情報を全て返却用オブジェクトに設定し、処理を終了する。
   * 4       入力内容に誤りがない場合、データレコードの情報を返却用オブジェクトに設定し、処理を終了する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param CsvFileCheckSupplementaryContractBusinessBean
   *          アップロードファイル情報
   * @return CsvFileCheckSupplementaryContractBusinessBean データレコード情報、エラーリスト情報
   */
  CsvFileCheckSupplementaryContractBusinessBean csvFileCheck(
      CsvFileCheckSupplementaryContractBusinessBean csvFileCheckBusinessBean);
}
