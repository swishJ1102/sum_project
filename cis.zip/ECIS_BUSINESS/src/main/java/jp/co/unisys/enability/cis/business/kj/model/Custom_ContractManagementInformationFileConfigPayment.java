package jp.co.unisys.enability.cis.business.kj.model;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;

/**
 * 支払情報登録・更新（一括登録）BusinessBean
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * 支払情報ビジネス
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class Custom_ContractManagementInformationFileConfigPayment {

  /** ファイル名接頭辞 */
  public static final String FILE_NAME_PREFIX = "payment_";

  // ヘッダレコード定義
  /** ヘッダレコード：ファイル種別-パラメータ */
  public static final String HEADER_FILE_KIND_MASK_STRING = "^2$";

  // データレコード定義
  /** タイトル行：イニシャライザで内容を設定する */
  public static final String[] DATA_TITLE_ROW;
  /** データレコード項目数：項目数 */
  public static final int DATA_COLUMN_COUNT;

  /** データレコード：契約者番号-インデックス */
  public static final int DATA_CONTRACTOR_NO_INDEX = 1;
  /** データレコード：契約者番号-名称 */
  public static final String DATA_CONTRACTOR_NO_NAME = "契約者番号";
  /** データレコード：契約者番号-文字数 */
  public static final int DATA_CONTRACTOR_NO_LENGTH = 25;
  /** データレコード：契約者番号-文字数(文字列) */
  public static final String DATA_CONTRACTOR_NO_LENGTH_STRING = String.valueOf(DATA_CONTRACTOR_NO_LENGTH);

  /** データレコード：支払番号-インデックス */
  public static final int DATA_PAYMENT_NO_INDEX = 2;
  /** データレコード：支払番号-名称 */
  public static final String DATA_PAYMENT_NO_NAME = "支払番号";
  /** データレコード：支払番号-文字数 */
  public static final int DATA_PAYMENT_NO_LENGTH = 25;
  /** データレコード：支払番号-文字数(文字列) */
  public static final String DATA_PAYMENT_NO_LENGTH_STRING = String.valueOf(DATA_PAYMENT_NO_LENGTH);

  /** データレコード：外部システム契約番号-インデックス */
  public static final int DATA_EXTERNAL_MANAGE_CONTRACT_NO_INDEX = 3;
  /** データレコード：外部システム契約番号-名称 */
  public static final String DATA_EXTERNAL_MANAGE_CONTRACT_NO_NAME = "外部システム契約番号";
  /** データレコード：外部システム契約番号-文字数 */
  public static final int DATA_EXTERNAL_MANAGE_CONTRACT_NO_LENGTH = 11;
  /** データレコード：外部システム契約番号-文字数(文字列) */
  public static final String DATA_EXTERNAL_MANAGE_CONTRACT_NO_LENGTH_STRING = String
      .valueOf(DATA_EXTERNAL_MANAGE_CONTRACT_NO_LENGTH);

  /** データレコード：外部システム支払番号-インデックス */
  public static final int DATA_EXTERNAL_MANAGE_PAYMENT_NO_INDEX = 4;
  /** データレコード：外部システム支払番号-名称 */
  public static final String DATA_EXTERNAL_MANAGE_PAYMENT_NO_NAME = "外部システム支払番号";
  /** データレコード：外部システム支払番号-文字数 */
  public static final int DATA_EXTERNAL_MANAGE_PAYMENT_NO_LENGTH = 11;
  /** データレコード：外部システム支払番号-文字数(文字列) */
  public static final String DATA_EXTERNAL_MANAGE_PAYMENT_NO_LENGTH_STRING = String
      .valueOf(DATA_EXTERNAL_MANAGE_PAYMENT_NO_LENGTH);

  /** データレコード：支払期限区分-インデックス */
  public static final int DATA_PAYMENT_EXPIRATION_CATEGORY_INDEX = 5;
  /** データレコード：支払期限区分-名称 */
  public static final String DATA_PAYMENT_EXPIRATION_CATEGORY_NAME = "支払期限区分";
  /** データレコード：支払期限区分-最小数 */
  public static final int DATA_PAYMENT_EXPIRATION_CATEGORY_RANGE_MIN = 0;
  /** データレコード：支払期限区分-最大数 */
  public static final int DATA_PAYMENT_EXPIRATION_CATEGORY_RANGE_MAX = 1;
  /** データレコード：支払期限区分-メッセージ文言 */
  public static final String DATA_PAYMENT_EXPIRATION_CATEGORY_MESSAGE = new StringBuilder()
      .append(DATA_PAYMENT_EXPIRATION_CATEGORY_RANGE_MIN).append("～")
      .append(DATA_PAYMENT_EXPIRATION_CATEGORY_RANGE_MAX).toString();

  /** データレコード：個別支払期限（月数）-インデックス */
  public static final int DATA_INDIVIDUAL_PAYMENT_EXPIRATION_MONTHS_INDEX = 6;
  /** データレコード：個別支払期限（月数）-名称 */
  public static final String DATA_INDIVIDUAL_PAYMENT_EXPIRATION_MONTHS_NAME = "個別支払期限（月数）";
  /** データレコード：個別支払期限（月数）-チェック用文字列 */
  public static final String DATA_INDIVIDUAL_PAYMENT_EXPIRATION_MONTHS_MASK_STRING = "^([1-9]{1}[0-9]?)$";

  /** データレコード：個別支払期限（日）-インデックス */
  public static final int DATA_INDIVIDUAL_PAYMENT_EXPIRATION_DATE_INDEX = 7;
  /** データレコード：個別支払期限（日）-名称 */
  public static final String DATA_INDIVIDUAL_PAYMENT_EXPIRATION_DATE_NAME = "個別支払期限（日）";
  /** データレコード：個別支払期限（日）-チェック用文字列 */
  public static final String DATA_INDIVIDUAL_PAYMENT_EXPIRATION_DATE_MASK_STRING = "^([1-9]|1[0-9]|2[0-8]|99)$";

  /** データレコード：請求合算フラグ-インデックス */
  public static final int DATA_BILLING_ADD_UP_FLAG_INDEX = 8;
  /** データレコード：請求合算フラグ-名称 */
  public static final String DATA_BILLING_ADD_UP_FLAG_NAME = "請求合算フラグ";
  /** データレコード：請求合算フラグ-最小数 */
  public static final int DATA_BILLING_ADD_UP_FLAG_RANGE_MIN = 0;
  /** データレコード：請求合算フラグ-最大数 */
  public static final int DATA_BILLING_ADD_UP_FLAG_RANGE_MAX = 1;
  /** データレコード：請求合算フラグ-メッセージ文言 */
  public static final String DATA_BILLING_ADD_UP_FLAG_MESSAGE = new StringBuilder()
      .append(DATA_BILLING_ADD_UP_FLAG_RANGE_MIN).append("～")
      .append(DATA_BILLING_ADD_UP_FLAG_RANGE_MAX).toString();

  /** データレコード：口振クレカ翌月請求フラグ-インデックス */
  public static final int DATA_DIRECT_DEBIT_CREDIT_CARD_NEXT_MONTH_BILLING_FLAG_INDEX = 9;
  /** データレコード：口振クレカ翌月請求フラグ-名称 */
  public static final String DATA_DIRECT_DEBIT_CREDIT_CARD_NEXT_MONTH_BILLING_FLAG_NAME = "口振クレカ翌月請求フラグ";
  /** データレコード：口振クレカ翌月請求フラグ-最小数 */
  public static final int DATA_DIRECT_DEBIT_CREDIT_CARD_NEXT_MONTH_BILLING_FLAG_RANGE_MIN = 0;
  /** データレコード：口振クレカ翌月請求フラグ-最大数 */
  public static final int DATA_DIRECT_DEBIT_CREDIT_CARD_NEXT_MONTH_BILLING_FLAG_RANGE_MAX = 1;
  /** データレコード：口振クレカ翌月請求フラグ-メッセージ文言 */
  public static final String DATA_DIRECT_DEBIT_CREDIT_CARD_NEXT_MONTH_BILLING_FLAG_MESSAGE = new StringBuilder()
      .append(DATA_DIRECT_DEBIT_CREDIT_CARD_NEXT_MONTH_BILLING_FLAG_RANGE_MIN).append("～")
      .append(DATA_DIRECT_DEBIT_CREDIT_CARD_NEXT_MONTH_BILLING_FLAG_RANGE_MAX).toString();

  /** データレコード：口座クレカID-インデックス */
  public static final int DATA_ACCOUNT_CREDIT_CARD_ID_INDEX = 10;
  /** データレコード：口座クレカID-名称 */
  public static final String DATA_ACCOUNT_CREDIT_CARD_ID_NAME = "口座クレカID";
  /** データレコード：口座クレカID-最小数 */
  public static final int DATA_ACCOUNT_CREDIT_CARD_ID_RANGE_MIN = 1;
  /** データレコード：口座クレカID-最大数 */
  public static final int DATA_ACCOUNT_CREDIT_CARD_ID_RANGE_MAX = 2147483647;
  /** データレコード：口座クレカID-メッセージ文言 */
  public static final String DATA_ACCOUNT_CREDIT_CARD_ID_MESSAGE = new StringBuilder()
      .append(DATA_ACCOUNT_CREDIT_CARD_ID_RANGE_MIN).append("～")
      .append(DATA_ACCOUNT_CREDIT_CARD_ID_RANGE_MAX).toString();

  /** データレコード：個人・法人区分コード-インデックス */
  public static final int DATA_INDIVIDUAL_LEGAL_ENTITY_CATEGORY_CODE_INDEX = 11;
  /** データレコード：個人・法人区分コード-名称 */
  public static final String DATA_INDIVIDUAL_LEGAL_ENTITY_CATEGORY_CODE_NAME = "個人・法人区分コード";

  /** データレコード：支払適用開始日-インデックス */
  public static final int DATA_PAYMENT_START_DATE_INDEX = 12;
  /** データレコード：支払適用開始日-名称 */
  public static final String DATA_PAYMENT_START_DATE_NAME = "支払適用開始日";
  /** データレコード：支払適用開始日-フォーマット */
  public static final String DATA_PAYMENT_START_DATE_FORMAT = ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH;
  /** データレコード：支払適用開始日-メッセージ文言 */
  public static final String DATA_PAYMENT_START_DATE_MESSAGE = new StringBuilder(
      "日付形式（").append(DATA_PAYMENT_START_DATE_FORMAT)
          .append("）").toString();

  /** データレコード：支払方法コード-インデックス */
  public static final int DATA_PAYMENT_WAY_CODE_INDEX = 13;
  /** データレコード：支払方法コード-名称 */
  public static final String DATA_PAYMENT_WAY_CODE_NAME = "支払方法コード";

  /** データレコード：請求先氏名1-インデックス */
  public static final int DATA_BILLING_NAME1_INDEX = 14;
  /** データレコード：請求先氏名1-名称 */
  public static final String DATA_BILLING_NAME1_NAME = "請求先氏名1";
  /** データレコード：請求先氏名1-文字数 */
  public static final int DATA_BILLING_NAME1_LENGTH = 22;
  /** データレコード：請求先氏名1-文字数(文字列) */
  public static final String DATA_BILLING_NAME1_LENGTH_STRING = String.valueOf(DATA_BILLING_NAME1_LENGTH);

  /** データレコード：請求先氏名2-インデックス */
  public static final int DATA_BILLING_NAME2_INDEX = 15;
  /** データレコード：請求先氏名2-名称 */
  public static final String DATA_BILLING_NAME2_NAME = "請求先氏名2";
  /** データレコード：請求先氏名2-文字数 */
  public static final int DATA_BILLING_NAME2_LENGTH = 27;
  /** データレコード：請求先氏名2-文字数(文字列) */
  public static final String DATA_BILLING_NAME2_LENGTH_STRING = String.valueOf(DATA_BILLING_NAME2_LENGTH);

  /** データレコード：敬称-インデックス */
  public static final int DATA_PREFIX_INDEX = 16;
  /** データレコード：敬称-名称 */
  public static final String DATA_PREFIX_NAME = "敬称";
  /** データレコード：敬称-文字数 */
  public static final int DATA_PREFIX_LENGTH = 2;
  /** データレコード：敬称-文字数(文字列) */
  public static final String DATA_PREFIX_LENGTH_STRING = String.valueOf(DATA_PREFIX_LENGTH);

  /** データレコード：請求先住所（郵便番号）-インデックス */
  public static final int DATA_BILLING_ADDRESS_POSTAL_CODE_INDEX = 17;
  /** データレコード：請求先住所（郵便番号）-名称 */
  public static final String DATA_BILLING_ADDRESS_POSTAL_CODE_NAME = "請求先住所（郵便番号）";
  /** データレコード：請求先住所（郵便番号）-文字数 */
  public static final int DATA_BILLING_ADDRESS_POSTAL_CODE_LENGTH = 7;
  /** データレコード：請求先住所（郵便番号）-文字数(文字列) */
  public static final String DATA_BILLING_ADDRESS_POSTAL_CODE_LENGTH_STRING = String
      .valueOf(DATA_BILLING_ADDRESS_POSTAL_CODE_LENGTH);

  /** データレコード：請求先住所（都道府県名）-インデックス */
  public static final int DATA_BILLING_ADDRESS_PREFECTURES_INDEX = 18;
  /** データレコード：請求先住所（都道府県名）-名称 */
  public static final String DATA_BILLING_ADDRESS_PREFECTURES_NAME = "請求先住所（都道府県名）";
  /** データレコード：請求先住所（都道府県名）-文字数 */
  public static final int DATA_BILLING_ADDRESS_PREFECTURES_LENGTH = 4;
  /** データレコード：請求先住所（都道府県名）-文字数(文字列) */
  public static final String DATA_BILLING_ADDRESS_PREFECTURES_LENGTH_STRING = String
      .valueOf(DATA_BILLING_ADDRESS_PREFECTURES_LENGTH);

  /** データレコード：請求先住所（市区郡町村名）-インデックス */
  public static final int DATA_BILLING_ADDRESS_MUNICIPALITY_INDEX = 19;
  /** データレコード：請求先住所（市区郡町村名）-名称 */
  public static final String DATA_BILLING_ADDRESS_MUNICIPALITY_NAME = "請求先住所（市区郡町村名）";
  /** データレコード：請求先住所（市区郡町村名）-文字数 */
  public static final int DATA_BILLING_ADDRESS_MUNICIPALITY_LENGTH = 27;
  /** データレコード：請求先住所（市区郡町村名）-文字数(文字列) */
  public static final String DATA_BILLING_ADDRESS_MUNICIPALITY_LENGTH_STRING = String
      .valueOf(DATA_BILLING_ADDRESS_MUNICIPALITY_LENGTH);

  /** データレコード：請求先住所（字名・丁目）-インデックス */
  public static final int DATA_BILLING_ADDRESS_SECTION_INDEX = 20;
  /** データレコード：請求先住所（字名・丁目）-名称 */
  public static final String DATA_BILLING_ADDRESS_SECTION_NAME = "請求先住所（字名・丁目）";
  /** データレコード：請求先住所（字名・丁目）-文字数 */
  public static final int DATA_BILLING_ADDRESS_SECTION_LENGTH = 12;
  /** データレコード：請求先住所（字名・丁目）-文字数(文字列) */
  public static final String DATA_BILLING_ADDRESS_SECTION_LENGTH_STRING = String
      .valueOf(DATA_BILLING_ADDRESS_SECTION_LENGTH);

  /** データレコード：請求先住所（番地･号）-インデックス */
  public static final int DATA_BILLING_ADDRESS_BLOCK_INDEX = 21;
  /** データレコード：請求先住所（番地･号）-名称 */
  public static final String DATA_BILLING_ADDRESS_BLOCK_NAME = "請求先住所（番地･号）";
  /** データレコード：請求先住所（番地･号）-文字数 */
  public static final int DATA_BILLING_ADDRESS_BLOCK_LENGTH = 10;
  /** データレコード：請求先住所（番地･号）-文字数(文字列) */
  public static final String DATA_BILLING_ADDRESS_BLOCK_LENGTH_STRING = String
      .valueOf(DATA_BILLING_ADDRESS_BLOCK_LENGTH);
  /** データレコード：請求先住所（番地･号）-チェック用文字列 */
  public static final String DATA_BILLING_ADDRESS_BLOCK_MASK_STRING = "^[a-zA-Z0-9]+(-[a-zA-Z0-9]+)*$";

  /** データレコード：請求先住所（建物名）-インデックス */
  public static final int DATA_BILLING_ADDRESS_BUILDING_NAME_INDEX = 22;
  /** データレコード：請求先住所（建物名）-名称 */
  public static final String DATA_BILLING_ADDRESS_BUILDING_NAME_NAME = "請求先住所（建物名）";
  /** データレコード：請求先住所（建物名）-文字数 */
  public static final int DATA_BILLING_ADDRESS_BUILDING_NAME_LENGTH = 25;
  /** データレコード：請求先住所（建物名）-文字数(文字列) */
  public static final String DATA_BILLING_ADDRESS_BUILDING_NAME_LENGTH_STRING = String
      .valueOf(DATA_BILLING_ADDRESS_BUILDING_NAME_LENGTH);

  /** データレコード：請求先住所（部屋名）-インデックス */
  public static final int DATA_BILLING_ADDRESS_ROOM_INDEX = 23;
  /** データレコード：請求先住所（部屋名）-名称 */
  public static final String DATA_BILLING_ADDRESS_ROOM_NAME = "請求先住所（部屋名）";
  /** データレコード：請求先住所（部屋名）-文字数 */
  public static final int DATA_BILLING_ADDRESS_ROOM_LENGTH = 10;
  /** データレコード：請求先住所（部屋名）-文字数(文字列) */
  public static final String DATA_BILLING_ADDRESS_ROOM_LENGTH_STRING = String
      .valueOf(DATA_BILLING_ADDRESS_ROOM_LENGTH);

  /** データレコード：請求先電話番号-インデックス */
  public static final int DATA_BILLING_PHONE_NO_INDEX = 24;
  /** データレコード：請求先電話番号-名称 */
  public static final String DATA_BILLING_PHONE_NO_NAME = "請求先電話番号";
  /** データレコード：請求先電話番号-文字数 */
  public static final int DATA_BILLING_PHONE_NO_LENGTH = 16;
  /** データレコード：請求先電話番号-文字数(文字列) */
  public static final String DATA_BILLING_PHONE_NO_LENGTH_STRING = String.valueOf(DATA_BILLING_PHONE_NO_LENGTH);
  /** データレコード：請求先電話番号-チェック用文字列 */
  public static final String DATA_BILLING_PHONE_NO_MASK_STRING = "^0\\d{1,4}-?\\d{1,4}-?\\d{4}$";

  /** データレコード：請求先電話区分コード-インデックス */
  public static final int DATA_BILLING_PHONE_CATEGORY_CODE_INDEX = 25;
  /** データレコード：請求先電話区分コード-名称 */
  public static final String DATA_BILLING_PHONE_CATEGORY_CODE_NAME = "請求先電話区分コード";

  /** データレコード：請求先メールアドレス1-インデックス */
  public static final int DATA_BILLING_MAIL_ADDRESS1_INDEX = 26;
  /** データレコード：請求先メールアドレス1-名称 */
  public static final String DATA_BILLING_MAIL_ADDRESS1_NAME = "請求先メールアドレス1";
  /** データレコード：請求先メールアドレス1-文字数 */
  public static final int DATA_BILLING_MAIL_ADDRESS1_LENGTH = 50;
  /** データレコード：請求先メールアドレス1-文字数(文字数) */
  public static final String DATA_BILLING_MAIL_ADDRESS1_LENGTH_STRING = String
      .valueOf(DATA_BILLING_MAIL_ADDRESS1_LENGTH);
  /** データレコード：請求先メールアドレス1-チェック用文字列 */
  public static final String DATA_BILLING_MAIL_ADDRESS1_MASK_STRING = "(?:[-!#-'*+/-9=?A-Z^-~]+(?:\\.[-!#-'*+/-9=?A-Z^-~]+)*|\"(?:[!#-\\[\\]-~]|\\\\[\\x09 -~])*\")@[-!#-'*+/-9=?A-Z^-~]+(?:\\.[-!#-'*+/-9=?A-Z^-~]+)*";

  /** データレコード：請求先メールアドレス2-インデックス */
  public static final int DATA_BILLING_MAIL_ADDRESS2_INDEX = 27;
  /** データレコード：請求先メールアドレス2-名称 */
  public static final String DATA_BILLING_MAIL_ADDRESS2_NAME = "請求先メールアドレス2";
  /** データレコード：請求先メールアドレス2-文字数 */
  public static final int DATA_BILLING_MAIL_ADDRESS2_LENGTH = 50;
  /** データレコード：請求先メールアドレス2-文字数(文字数) */
  public static final String DATA_BILLING_MAIL_ADDRESS2_LENGTH_STRING = String
      .valueOf(DATA_BILLING_MAIL_ADDRESS2_LENGTH);
  /** データレコード：請求先メールアドレス2-チェック用文字列 */
  public static final String DATA_BILLING_MAIL_ADDRESS2_MASK_STRING = "(?:[-!#-'*+/-9=?A-Z^-~]+(?:\\.[-!#-'*+/-9=?A-Z^-~]+)*|\"(?:[!#-\\[\\]-~]|\\\\[\\x09 -~])*\")@[-!#-'*+/-9=?A-Z^-~]+(?:\\.[-!#-'*+/-9=?A-Z^-~]+)*";

  /** データレコード：フリー項目1-インデックス */
  public static final int DATA_BILLING_FREE1_INDEX = 28;
  /** データレコード：フリー項目1-名称 */
  public static final String DATA_BILLING_FREE1_NAME = "フリー項目1";
  /** データレコード：フリー項目1-文字数 */
  public static final int DATA_BILLING_FREE1_LENGTH = 27;
  /** データレコード：フリー項目1-文字数(文字列) */
  public static final String DATA_BILLING_FREE1_LENGTH_STRING = String
      .valueOf(DATA_BILLING_FREE1_LENGTH);

  /** データレコード：フリー項目2-インデックス */
  public static final int DATA_BILLING_FREE2_INDEX = 29;
  /** データレコード：フリー項目2-名称 */
  public static final String DATA_BILLING_FREE2_NAME = "フリー項目2";
  /** データレコード：フリー項目2-文字数 */
  public static final int DATA_BILLING_FREE2_LENGTH = 27;
  /** データレコード：フリー項目2-文字数(文字列) */
  public static final String DATA_BILLING_FREE2_LENGTH_STRING = String
      .valueOf(DATA_BILLING_FREE2_LENGTH);

  /** データレコード：更新回数-インデックス */
  public static final int DATA_UPDATE_COUNT_INDEX = 30;
  /** データレコード：更新回数-名称 */
  public static final String DATA_UPDATE_COUNT_NAME = "更新回数";
  /** データレコード：更新回数-最小数 */
  public static final int DATA_UPDATE_COUNT_RANGE_MIN = 0;
  /** データレコード：更新回数-最大数 */
  public static final int DATA_UPDATE_COUNT_RANGE_MAX = 2147483647;
  /** データレコード：更新回数-メッセージ文言 */
  public static final String DATA_UPDATE_COUNT_MESSAGE = new StringBuilder().append(DATA_UPDATE_COUNT_RANGE_MIN)
      .append("～").append(DATA_UPDATE_COUNT_RANGE_MAX)
      .toString();

  /** データレコード：登録・更新・削除区分-インデックス */
  public static final int DATA_REGISTER_UPDATE_DELETE_CATEGORY_INDEX = 31;
  /** データレコード：登録・更新・削除区分-名称 */
  public static final String DATA_REGISTER_UPDATE_DELETE_CATEGORY_NAME = "登録・更新・削除区分";

  /**
   * staticイニシャライザ.<br>
   * タイトル行の生成を行う<br>
   * インデックス=タイトル配列のインデックスになるため、番号は自動で設定される<br>
   * カラムの追加・削除があった場合に修正が必要
   */
  static {
    Map<Integer, String> titleMap = new HashMap<Integer, String>();

    // 項目を順番に入れ込んでいく
    // レコード種別は共通のものを使う
    titleMap.put(ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_INDEX,
        ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_NAME);

    titleMap.put(DATA_CONTRACTOR_NO_INDEX, DATA_CONTRACTOR_NO_NAME);
    titleMap.put(DATA_PAYMENT_NO_INDEX, DATA_PAYMENT_NO_NAME);
    titleMap.put(DATA_EXTERNAL_MANAGE_CONTRACT_NO_INDEX, DATA_EXTERNAL_MANAGE_CONTRACT_NO_NAME);
    titleMap.put(DATA_EXTERNAL_MANAGE_PAYMENT_NO_INDEX, DATA_EXTERNAL_MANAGE_PAYMENT_NO_NAME);
    titleMap.put(DATA_PAYMENT_EXPIRATION_CATEGORY_INDEX,
        DATA_PAYMENT_EXPIRATION_CATEGORY_NAME);
    titleMap.put(DATA_INDIVIDUAL_PAYMENT_EXPIRATION_MONTHS_INDEX,
        DATA_INDIVIDUAL_PAYMENT_EXPIRATION_MONTHS_NAME);
    titleMap.put(DATA_INDIVIDUAL_PAYMENT_EXPIRATION_DATE_INDEX,
        DATA_INDIVIDUAL_PAYMENT_EXPIRATION_DATE_NAME);
    titleMap.put(DATA_BILLING_ADD_UP_FLAG_INDEX,
        DATA_BILLING_ADD_UP_FLAG_NAME);
    titleMap.put(DATA_DIRECT_DEBIT_CREDIT_CARD_NEXT_MONTH_BILLING_FLAG_INDEX,
        DATA_DIRECT_DEBIT_CREDIT_CARD_NEXT_MONTH_BILLING_FLAG_NAME);
    titleMap.put(DATA_ACCOUNT_CREDIT_CARD_ID_INDEX, DATA_ACCOUNT_CREDIT_CARD_ID_NAME);
    titleMap.put(DATA_INDIVIDUAL_LEGAL_ENTITY_CATEGORY_CODE_INDEX, DATA_INDIVIDUAL_LEGAL_ENTITY_CATEGORY_CODE_NAME);
    titleMap.put(DATA_PAYMENT_START_DATE_INDEX, DATA_PAYMENT_START_DATE_NAME);
    titleMap.put(DATA_PAYMENT_WAY_CODE_INDEX, DATA_PAYMENT_WAY_CODE_NAME);
    titleMap.put(DATA_BILLING_NAME1_INDEX, DATA_BILLING_NAME1_NAME);
    titleMap.put(DATA_BILLING_NAME2_INDEX, DATA_BILLING_NAME2_NAME);
    titleMap.put(DATA_PREFIX_INDEX, DATA_PREFIX_NAME);
    titleMap.put(DATA_BILLING_ADDRESS_POSTAL_CODE_INDEX, DATA_BILLING_ADDRESS_POSTAL_CODE_NAME);
    titleMap.put(DATA_BILLING_ADDRESS_PREFECTURES_INDEX, DATA_BILLING_ADDRESS_PREFECTURES_NAME);
    titleMap.put(DATA_BILLING_ADDRESS_MUNICIPALITY_INDEX, DATA_BILLING_ADDRESS_MUNICIPALITY_NAME);
    titleMap.put(DATA_BILLING_ADDRESS_SECTION_INDEX, DATA_BILLING_ADDRESS_SECTION_NAME);
    titleMap.put(DATA_BILLING_ADDRESS_BLOCK_INDEX, DATA_BILLING_ADDRESS_BLOCK_NAME);
    titleMap.put(DATA_BILLING_ADDRESS_BUILDING_NAME_INDEX, DATA_BILLING_ADDRESS_BUILDING_NAME_NAME);
    titleMap.put(DATA_BILLING_ADDRESS_ROOM_INDEX, DATA_BILLING_ADDRESS_ROOM_NAME);
    titleMap.put(DATA_BILLING_PHONE_NO_INDEX, DATA_BILLING_PHONE_NO_NAME);
    titleMap.put(DATA_BILLING_PHONE_CATEGORY_CODE_INDEX, DATA_BILLING_PHONE_CATEGORY_CODE_NAME);
    titleMap.put(DATA_BILLING_MAIL_ADDRESS1_INDEX, DATA_BILLING_MAIL_ADDRESS1_NAME);
    titleMap.put(DATA_BILLING_MAIL_ADDRESS2_INDEX, DATA_BILLING_MAIL_ADDRESS2_NAME);
    titleMap.put(DATA_BILLING_FREE1_INDEX, DATA_BILLING_FREE1_NAME);
    titleMap.put(DATA_BILLING_FREE2_INDEX, DATA_BILLING_FREE2_NAME);
    titleMap.put(DATA_UPDATE_COUNT_INDEX, DATA_UPDATE_COUNT_NAME);
    titleMap.put(DATA_REGISTER_UPDATE_DELETE_CATEGORY_INDEX, DATA_REGISTER_UPDATE_DELETE_CATEGORY_NAME);

    Iterator<Integer> it = titleMap.keySet().iterator();
    String[] titleArray = new String[titleMap.size()];
    while (it.hasNext()) {
      Integer key = it.next();
      titleArray[key] = titleMap.get(key);
    }
    DATA_TITLE_ROW = titleArray;
    DATA_COLUMN_COUNT = DATA_TITLE_ROW.length;
  }

}
