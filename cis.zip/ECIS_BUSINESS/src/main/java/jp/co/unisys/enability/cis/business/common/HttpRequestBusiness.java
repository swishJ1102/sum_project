package jp.co.unisys.enability.cis.business.common;

import org.springframework.util.MultiValueMap;

public interface HttpRequestBusiness {

    /**
     * Proxy設定処理
     * @param host ホスト
     * @param port ポート番号
     */
    void setProxy(String host, String port);

    /**
     * Proxy設定解除処理
     */
    void unsetProxy();

    /**
     * Basic認証設定処理
     * @param userName ユーザ名
     * @param password パスワード
     */
    void setBasicAuthentication(String userName, String password);

    /**
     * Basic認証設定解除処理
     */
    void unsetBasicAuthentication();

    /**
     * タイムアウト設定処理
     * @param timeout 接続タイムアウト値（ミリ秒）
     */
    void setConnectTimeout(Integer timeout);

    /**
     * 文字コード設定処理
     * @param charset 文字コード
     */
    void setCharset(String charset);

    /**
     * POST通信処理
     * @param url 接続先URL
     * @param data 送信データ
     * @return レスポンスボディ
     * @throws Exception
     */
    String doPost(String url, MultiValueMap<String, Object> data) throws Exception;

    /**
     * POST通信処理（JSON）
     * @param url 接続先URL
     * @param data 送信データ
     * @return レスポンスボディ
     * @throws Exception
     */
    String doPostAsJson(String url, MultiValueMap<String, Object> data) throws Exception;

    /**
     * GET通信処理
     * @param url 接続先URL
     * @param data 送信データ
     * @return レスポンスボディ
     * @throws Exception
     */
    String doGet(String url, MultiValueMap<String, Object> data) throws Exception;

}