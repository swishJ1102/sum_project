package jp.co.unisys.enability.cis.business.rk.model;

import java.util.List;

/**
 * 計算用使用量登録ビジネスBean。
 *
 * <pre>
 * <p>
 * <b>【使用ビジネス】</b>
 * </p>
 * 計算用使用量登録ビジネス。
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_CalcForUsageRegisterBusinessBean {

  /**
   * 計算用使用量
   */
  private RK_CalcForUsageBusinessBean calcForUsage;

  /**
   * 計算用時間帯別使用量
   */
  private List<RK_CalcForTimeSlotByUsageBusinessBean> calcForTimeSlotByUsage;

  /**
   * 計算用指示数
   */
  private List<RK_CalcForIndicationNoBusinessBean> calcForIndicationNo;

  /**
   * 計算用使用量のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計算用使用量を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 計算用使用量
   */
  public RK_CalcForUsageBusinessBean getCalcForUsage() {
    return calcForUsage;
  }

  /**
   * 計算用使用量のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計算用使用量を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param calcForUsage
   *          計算用使用量
   */
  public void setCalcForUsage(RK_CalcForUsageBusinessBean calcForUsage) {
    this.calcForUsage = calcForUsage;
  }

  /**
   * 計算用時間帯別使用量のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計算用時間帯別使用量を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 計算用時間帯別使用量
   */
  public List<RK_CalcForTimeSlotByUsageBusinessBean> getCalcForTimeSlotByUsage() {
    return calcForTimeSlotByUsage;
  }

  /**
   * 計算用時間帯別使用量のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計算用時間帯別使用量を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param calcForTimeSlotByUsage
   *          計算用時間帯別使用量
   */
  public void setCalcForTimeSlotByUsage(
      List<RK_CalcForTimeSlotByUsageBusinessBean> calcForTimeSlotByUsage) {
    this.calcForTimeSlotByUsage = calcForTimeSlotByUsage;
  }

  /**
   * 計算用指示数のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計算用指示数を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 計算用指示数
   */
  public List<RK_CalcForIndicationNoBusinessBean> getCalcForIndicationNo() {
    return calcForIndicationNo;
  }

  /**
   * 計算用指示数のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計算用指示数を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param calcForIndicationNo
   *          計算用指示数
   */
  public void setCalcForIndicationNo(
      List<RK_CalcForIndicationNoBusinessBean> calcForIndicationNo) {
    this.calcForIndicationNo = calcForIndicationNo;
  }
}
