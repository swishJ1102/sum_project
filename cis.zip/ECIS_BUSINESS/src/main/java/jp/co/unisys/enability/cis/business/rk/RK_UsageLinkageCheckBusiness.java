package jp.co.unisys.enability.cis.business.rk;

import java.util.Date;
import java.util.List;

import jp.co.unisys.enability.cis.business.rk.model.RK_UsageLinkageCheckCheckDataBusinessBean;
import jp.co.unisys.enability.cis.business.rk.model.RK_UsageLinkageCheckTermDecisionBusinessBean;
import jp.co.unisys.enability.cis.common.Exception.BusinessLogicException;
import jp.co.unisys.enability.cis.entity.common.Todo;

/**
 * 料金計算チェックビジネスインターフェース。
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.dao.rk.RK_UsageLinkageCheckDao
 * @see jp.co.unisys.enability.cis.business.common.TodoBusiness
 */
public interface RK_UsageLinkageCheckBusiness {

  /**
   * 使用量連携チェックを行うためのデータを取得する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * バッチ実行日に取り込まれた確定使用量メッセージから、
   * 地点特定番号毎に使用量連携チェックを行うためのデータを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param executeDate
   *          バッチ実行日
   * @return チェック用データのリスト
   * @see jp.co.unisys.enability.cis.dao.rk.RK_UsageLinkageCheckDao
   */
  List<RK_UsageLinkageCheckCheckDataBusinessBean> selectCheckData(
      Date executeDate);

  /**
   * 期間判定情報を取得する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された確定使用量メッセージの対象期間内で有効な契約を特定し、
   * 契約期間等で連携チェックを行うための情報を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param spotNo
   *          地点特定番号
   * @param fixUsageFileName
   *          確定使用量ファイル名
   * @param areaCode
   *          エリアコード
   * @param abolitionFlag
   *          廃止判定フラグ
   * @return 期間判定情報ビジネスBean
   * @see jp.co.unisys.enability.cis.dao.rk.RK_UsageLinkageCheckDao
   */
  public RK_UsageLinkageCheckTermDecisionBusinessBean selectTermDecision(
      String spotNo, String fixUsageFileName, String areaCode, String abolitionFlag);

  /**
   * 月次実績エラー区分コードを更新する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 【月次実績】.月次実績エラー区分コードを指定のコードに更新する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param checkDataBusinessBean
   *          チェック対象ビジネスBean
   * @param errorCategoryCode
   *          月次実績エラー区分コード
   */
  public void updateMonthlyUsageResult(
      RK_UsageLinkageCheckCheckDataBusinessBean checkDataBusinessBean,
      String errorCategoryCode);

  /**
   * 月次実績エラー区分コードを"エラー"に更新する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された【月次実績】の月次実績エラー区分コードを、"エラー"に更新する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param checkDataBusinessBean
   *          チェック対象ビジネスBean
   * @throws BusinessLogicException
   *           エラーが発生した場合
   */
  public void updateMonthlyUsageResultError(
      RK_UsageLinkageCheckCheckDataBusinessBean checkDataBusinessBean);

  /**
   * 月次実績エラー区分コードを"無視"に更新する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された【月次実績】の月次実績エラー区分コードを、"無視"に更新する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param checkDataBusinessBean
   *          チェック対象ビジネスBean
   * @throws BusinessLogicException
   *           エラーが発生した場合
   */
  public void updateMonthlyUsageResultIgnore(
      RK_UsageLinkageCheckCheckDataBusinessBean checkDataBusinessBean);

  /**
   * TODOを登録する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数のメッセージIDとパラメータからメッセージを作成し、TODOを登録する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param messageId
   *          メッセージID
   * @param params
   *          メッセージを作成するパラメータ
   * @param noteMessageId
   *          備考メッセージID
   * @param noteParams
   *          備考メッセージを作成するパラメータ
   * @param contractNo
   *          契約番号
   * @param spotNo
   *          地点特定番号
   * @param nextMrScheduledDate
   *          次回検針予定日
   * @see jp.co.unisys.enability.cis.business.common.TodoBusiness
   */
  public void registerTodo(String messageId, Object[] params, String noteMessageId, Object[] noteParams,
      String contractNo, String spotNo, Date nextMrScheduledDate);

  /**
   * TODOを取得する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数の機能ID、メッセージID、地点特定番号、次回検針予定日からTODOを検索、取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param functionId
   *          機能ID
   * @param messageId
   *          メッセージID
   * @param spotNo
   *          地点特定番号
   * @param nextMrScheduledDate
   *          次回検針予定日
   * @see jp.co.unisys.enability.cis.business.common.TodoBusiness
   */
  public List<Todo> selectTodo(String functionId, String messageId, String spotNo, Date nextMrScheduledDate);

  /**
   * TODOを更新する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数のTODO情報リストとパラメータからTODO取得で得たTODOを更新する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param todoList
   *          メッセージID
   * @param params
   *          メッセージを作成するパラメータ
   * @see jp.co.unisys.enability.cis.business.common.TodoBusiness
   */
  public void updateTodo(List<Todo> todoList, String[] params);
}
