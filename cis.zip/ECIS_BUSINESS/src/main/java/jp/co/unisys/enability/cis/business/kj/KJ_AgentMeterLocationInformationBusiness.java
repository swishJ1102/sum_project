package jp.co.unisys.enability.cis.business.kj;

import jp.co.unisys.enability.cis.business.kj.model.InquiryAgentMeterLocationBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.RegistAgentMeterLocationBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.UpdateAgentMeterLocationBusinessBean;

/**
 * メータ設置場所ビジネスインターフェース
 *
 * @author "Nihon Unisys, Ltd."
 *
 */
public interface KJ_AgentMeterLocationInformationBusiness {

  /**
   * メータ設置場所照会を行う。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * CRMや低圧CISで、メータ設置場所を特定する場合に使用される。
   * 指定された「地点特定番号」（供給地点特定番号または、受電地点特定番号）で特定された情報を返却する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param inquiryMeterLocationBusinessBean
   *          メータ設置場所照会BusinessBean
   * @return メータ設置場所照会BusinessBean
   */
  public InquiryAgentMeterLocationBusinessBean inquiry(
      InquiryAgentMeterLocationBusinessBean inquiryMeterLocationBusinessBean);

  /**
   * メータ設置場所登録を行う。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * CRMや低圧CISで、メータ設置場所を特定する場合に使用される。
   * 指定された「地点特定番号」（供給地点特定番号または、受電地点特定番号）で特定された情報を返却する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param registMeterLocationBusinessBean
   *          メータ設置場所登録BusinessBean
   * @return メータ設置場所登録BusinessBean
   */
  public RegistAgentMeterLocationBusinessBean regist(
      RegistAgentMeterLocationBusinessBean registMeterLocationBusinessBean);

  /**
   * メータ設置場所更新を行う。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * CRMや低圧CISで、メータ設置場所を特定する場合に使用される。
   * 指定された「地点特定番号」（供給地点特定番号または、受電地点特定番号）で特定された情報を返却する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param updateMeterLocationBusinessBean
   *          メータ設置場所更新BusinessBean
   * @return メータ設置場所更新BusinessBean
   */
  public UpdateAgentMeterLocationBusinessBean update(
      UpdateAgentMeterLocationBusinessBean updateMeterLocationBusinessBean);
}