package jp.co.unisys.enability.cis.business.rk;

import jp.co.unisys.enability.cis.business.rk.model.RK_ChargeCalcWarningCheckBusinessBean;
import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;
import jp.co.unisys.enability.cis.entity.common.RestrictionDiscountInfoExample;
import jp.co.unisys.enability.cis.mapper.common.RestrictionDiscountInfoMapper;

/**
 * BRK0103-03過去分未請求の停電情報存在チェックビジネス
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.common.DateBusiness
 * @see jp.co.unisys.enability.cis.dao.rk.RK_ChargeCalcWarningCheckDao
 */
public class RK_PastUnclaimedBlackoutExistCheckBusinessImpl implements
    RK_ChargeCalcWarningCheckBusiness {
  /**
   * 制限中止割引情報Mapper（DI）
   */
  private RestrictionDiscountInfoMapper restrictionDiscountInfoMapper;

  /**
   * 過去分未請求の停電情報存在チェックビジネス
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param chargeCalcWarningCheckBean
   *          《料金計算警告チェックビジネスBean》
   * @return 警告コード
   * @see jp.co.unisys.enability.cis.dao.rk.RK_ChargeCalcWarningCheckDao
   */
  @Override
  public String check(
      RK_ChargeCalcWarningCheckBusinessBean chargeCalcWarningCheckBean) {

    // 制限中止割引情報の取込状況を取得する。.
    // 制限中止割引情報Example
    RestrictionDiscountInfoExample restrictionDiscountInfoExample = new RestrictionDiscountInfoExample();
    //【制限中止割引情報】を取得する条件を設定
    restrictionDiscountInfoExample.createCriteria()
        // 契約ID
        .andContractIdEqualTo(
            chargeCalcWarningCheckBean.getContractId())
        // 対象年月
        .andCoveredPeriodLessThan(chargeCalcWarningCheckBean.getUsePeriod())
        // 計上年月
        .andRecordedPeriodIsNull();
    //制限中止割引情報Mapper.countByExampleを呼び出し、件数を取得する。
    //変数.件数が１件以上の場合
    if (restrictionDiscountInfoMapper.countByExample(restrictionDiscountInfoExample) >= 1) {
      //戻り値に359 を設定する
      return ECISRKConstants.WARNING_CLASS_MASTER_PAST_UNCLAIMED_BLACKOUT_EXIST;
    }
    //// 戻り値にnull を設定する。
    return null;
  }

  /**
   * 制限中止割引情報Mapperのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 制限中止割引情報Mapperを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param restrictionDiscountInfoMapper
   *          制限中止割引情報Mapper
   */
  public void setRestrictionDiscountInfoMapper(RestrictionDiscountInfoMapper restrictionDiscountInfoMapper) {
    this.restrictionDiscountInfoMapper = restrictionDiscountInfoMapper;
  }

}
