/*-------------------------------------------------------------------------------
 * All Rights Reserved. Copyright(C) Nihon Unisys, Ltd.
 * vendor : Nihon Unisys, Ltd.
 * create : 2016/04/20
 *-----------------------------------------------------------------------------*/
package jp.co.unisys.enability.cis.business.rk.model;

import java.io.InputStream;
import java.util.Date;
import java.util.List;

/**
 * 使用量CSV仕訳ビジネスBean
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_UsageCsvCalculateBusinessBean {

  /**
   * 使用量ファイルを保有する。
   */
  private InputStream usageFile;

  /**
   * 料金メニュー毎情報リストを保有する。
   */
  private List<RK_RateMenuInfoBean> RateMenuInfoList;

  /**
   * 料金計算基準日を保有する。
   */
  private Date rateCalculationBaseDate;

  /**
   * リターンコードを保有する。
   */
  private String returnCode;

  /**
   * メッセージを保有する。
   */
  private String message;

  /**
   * 使用量ファイルのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 使用量ファイルを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 使用量ファイル
   */
  public InputStream getUsagefile() {
    return usageFile;
  }

  /**
   * 使用量ファイルのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 使用量ファイルを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return usageFile 使用量ファイル
   */
  public void setUsagefile(InputStream usageFile) {
    this.usageFile = usageFile;

  }

  /**
   * 料金メニュー毎情報リストのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金メニュー毎情報リストを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 料金メニュー毎情報リスト
   */
  public List<RK_RateMenuInfoBean> getRatemenuinfolist() {
    return RateMenuInfoList;
  }

  /**
   * 料金メニュー毎情報リストのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金メニュー毎情報リストを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return RateMenuInfoList 料金メニュー毎情報リスト
   */
  public void setRatemenuinfolist(List<RK_RateMenuInfoBean> RateMenuInfoList) {
    this.RateMenuInfoList = RateMenuInfoList;

  }

  /**
   * 料金計算基準日のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金計算基準日を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 料金計算基準日
   */
  public Date getRatecalculationbasedate() {
    return rateCalculationBaseDate;
  }

  /**
   * 料金計算基準日のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金計算基準日を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return rateCalculationBaseDate 料金計算基準日
   */
  public void setRatecalculationbasedate(Date rateCalculationBaseDate) {
    this.rateCalculationBaseDate = rateCalculationBaseDate;

  }

  /**
   * 戻り値を設定のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 戻り値を設定を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 戻り値を設定
   */
  public String getReturncode() {
    return returnCode;
  }

  /**
   * 戻り値を設定のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 戻り値を設定を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return returnCode 戻り値を設定
   */
  public void setReturncode(String returnCode) {
    this.returnCode = returnCode;

  }

  /**
   * エラー発生時にエラーメッセージを設定のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * エラー発生時にエラーメッセージを設定を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return エラー発生時にエラーメッセージを設定
   */
  public String getMessage() {
    return message;
  }

  /**
   * エラー発生時にエラーメッセージを設定のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * エラー発生時にエラーメッセージを設定を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return message エラー発生時にエラーメッセージを設定
   */
  public void setMessage(String message) {
    this.message = message;

  }
}
