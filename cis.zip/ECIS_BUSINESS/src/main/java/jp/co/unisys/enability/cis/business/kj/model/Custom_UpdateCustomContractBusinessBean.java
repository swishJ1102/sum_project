package jp.co.unisys.enability.cis.business.kj.model;

/**
 * 契約情報更新で、更新条件を格納するビジネスBean
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * 契約情報ビジネス
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class Custom_UpdateCustomContractBusinessBean {

  /**
   * 契約IDを保有する。
   */
  private Integer contractId;

  /**
   * 営業担当者・組織コードを保有する。
   */
  private String salesDepartmentCd;

  /**
   * 問合わせ先コードを保有する。
   */
  private String contactCd;

  /**
   * リターンコードを保有する。
   */
  private String returnCode;

  /**
   * メッセージを保有する。
   */
  private String message;

  /**
   * 契約IDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約IDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約ID
   */
  public Integer getContractId() {
    return this.contractId;
  }

  /**
   * 契約IDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約IDを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractId
   *          契約ID
   */
  public void setContractId(Integer contractId) {
    this.contractId = contractId;
  }

  /**
   * 営業担当者・組織コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 営業担当者・組織コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 営業担当者・組織コード
   */
  public String getSalesDepartmentCd() {
    return this.salesDepartmentCd;
  }

  /**
   * 営業担当者・組織コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 営業担当者・組織コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param salesDepartmentCd
   *          営業担当者・組織コード
   */
  public void setSalesDepartmentCd(String salesDepartmentCd) {
    this.salesDepartmentCd = salesDepartmentCd;
  }

  /**
   * 問合わせ先コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 問合わせ先コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 問合わせ先コード
   */
  public String getContactCd() {
    return this.contactCd;
  }

  /**
   * 問合わせ先コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 問合わせ先コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contactCd
   *          問合わせ先コード
   */
  public void setContactCd(String contactCd) {
    this.contactCd = contactCd;
  }

  /**
   * リターンコードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return リターンコード
   */
  public String getReturnCode() {
    return this.returnCode;
  }

  /**
   * リターンコードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param returnCode
   *          リターンコード
   */
  public void setReturnCode(String returnCode) {
    this.returnCode = returnCode;
  }

  /**
   * メッセージのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return メッセージ
   */
  public String getMessage() {
    return this.message;
  }

  /**
   * メッセージのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param message
   *          メッセージ
   */
  public void setMessage(String message) {
    this.message = message;
  }
}
