package jp.co.unisys.enability.cis.business.rk;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Properties;

import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.config.PropertiesFactoryBean;
import org.springframework.context.MessageSource;

import jp.co.unisys.enability.cis.business.common.TodoBusiness;
import jp.co.unisys.enability.cis.business.common.model.TodoBusinessBean;
import jp.co.unisys.enability.cis.business.rk.model.RK_FixUsageApplyDataBusinessBean;
import jp.co.unisys.enability.cis.business.rk.model.RK_FixUsageApplyUsageBusinessBean;
import jp.co.unisys.enability.cis.common.util.RK_PropertyUtil;
import jp.co.unisys.enability.cis.common.util.StringConvertUtil;
import jp.co.unisys.enability.cis.common.util.constants.ECISCodeConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISSRConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISTodoConstants;
import jp.co.unisys.enability.cis.dao.rk.RK_FixUsageApplyDao;
import jp.co.unisys.enability.cis.entity.common.DemandResult;
import jp.co.unisys.enability.cis.entity.common.DemandResultExample;
import jp.co.unisys.enability.cis.entity.common.Fu;
import jp.co.unisys.enability.cis.entity.common.FuExample;
import jp.co.unisys.enability.cis.entity.common.MrCalendarM;
import jp.co.unisys.enability.cis.entity.common.MrCalendarMExample;
import jp.co.unisys.enability.cis.entity.rk.RK_FixUsageApplyDataEntityBean;
import jp.co.unisys.enability.cis.mapper.common.DemandResultMapper;
import jp.co.unisys.enability.cis.mapper.common.FuMapper;
import jp.co.unisys.enability.cis.mapper.common.MrCalendarMMapper;

/**
 * 確定使用量情報反映ビジネスクラス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_FixUsageApplyBusinessImpl implements RK_FixUsageApplyBusiness {

  /** 確定使用量情報反映Dao(DI) */
  private RK_FixUsageApplyDao rkFixUsageApplyDao;

  /** 確定使用量共通ビジネスインターフェース(DI) */
  private RK_FixUsageCommonBusiness rkFixUsageCommonBusiness;

  /** 確定使用量Mapper(DI) */
  private FuMapper fuMapper;

  /** 需要実績Mapper(DI) */
  private DemandResultMapper demandResultMapper;

  /** TODOビジネス(DI) */
  private TodoBusiness todoBusiness;

  /** メッセージリソース(DI) */
  private MessageSource messageSource;

  /** 検針カレンダーMapper(DI) */
  private MrCalendarMMapper mrCalendarMMapper;

  /** プロパティファクトリー(DI) */
  private PropertiesFactoryBean applicationProperties;

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.rk.RK_FixUsageApplyBusiness#
   * selectApplyData(java.util.Date)
   */
  @Override
  public List<RK_FixUsageApplyDataBusinessBean> selectApplyData(
      Date executeDate) {

    // 確定使用量メッセージの取り込み処理を行うための情報を取得する
    List<RK_FixUsageApplyDataEntityBean> sourceList = rkFixUsageApplyDao
        .selectFixUsageApplyData(executeDate);

    // 結果のリストを生成
    List<RK_FixUsageApplyDataBusinessBean> destList = new ArrayList<RK_FixUsageApplyDataBusinessBean>(
        sourceList.size());

    // プロパティオブジェクトを取得
    Properties prop = RK_PropertyUtil.getPropertiesFactory(applicationProperties);

    // 計量日制エリアリストをプロパティから取得し、カンマで分割・Listにする
    List<String> measureDateAreaList = Arrays.asList(prop.getProperty("measure.date.area.list").split(
        ECISConstants.COMMA));

    // 確定使用量情報反映を保持するBean
    RK_FixUsageApplyDataBusinessBean rKFixUsageApplyDataBusinessBean = null;

    // 確定使用量反映データごとに繰り返し
    for (RK_FixUsageApplyDataEntityBean source : sourceList) {

      // Beanを生成
      rKFixUsageApplyDataBusinessBean = new RK_FixUsageApplyDataBusinessBean();

      // それぞれのBeanで共通の項目をコピー
      // 地点特定番号
      rKFixUsageApplyDataBusinessBean.setSpotNo(source.getSpotNo());
      // 確定使用量ファイル名
      rKFixUsageApplyDataBusinessBean.setFixUsageFileName(source
          .getFixUsageFileName());
      // エリアコード
      rKFixUsageApplyDataBusinessBean.setAreaCode(source.getAreaCode());
      // 検針日
      rKFixUsageApplyDataBusinessBean.setMeterReadingDate(source
          .getMeterReadingDate());
      // 対象年月
      rKFixUsageApplyDataBusinessBean.setCoveredPeriod(source
          .getCoveredPeriod());
      // 力率
      rKFixUsageApplyDataBusinessBean.setPowerFactor(source
          .getPowerFactor());
      // 更新コード
      rKFixUsageApplyDataBusinessBean.setUpdateCode(source
          .getUpdateCode());
      // 需要家識別番号
      rKFixUsageApplyDataBusinessBean
          .setContractorIdentificationNo(source
              .getContractorIdentificationNo());
      // 次回検針予定日
      rKFixUsageApplyDataBusinessBean
          .setNextMeterReadingScheduledDate(source
              .getNextMeterReadingScheduledDate());

      // 地点の最大需要電力
      rKFixUsageApplyDataBusinessBean.setSpotPeakDemand(source
          .getSpotPeakDemand());

      // メータ設置場所ID
      rKFixUsageApplyDataBusinessBean.setMeterLocationId(source
          .getMeterLocationId());
      // 計器識別番号1
      rKFixUsageApplyDataBusinessBean.setMeterIdentificationNo1(source
          .getMeterIdentificationNo1());
      // 検針日区分コード
      rKFixUsageApplyDataBusinessBean.setMeterReadingDateCategoryCode(source.getMeterReadingDateCategoryCode());
      // 契約ID
      rKFixUsageApplyDataBusinessBean.setContractId(source
          .getContractId());
      // 契約番号
      rKFixUsageApplyDataBusinessBean.setContractNo(source
          .getContractNo());
      // 契約開始日
      rKFixUsageApplyDataBusinessBean.setContractStartDate(source
          .getContractStartDate());
      // 契約終了日
      rKFixUsageApplyDataBusinessBean.setContractEndDate(source
          .getContractEndDate());
      // 契約終了理由コード
      rKFixUsageApplyDataBusinessBean.setContractEndReasonCode(source
          .getContractEndReasonCode());
      // 契約終了分確定使用量連携済フラグ
      rKFixUsageApplyDataBusinessBean
          .setContractEndFixUsageSentFlag(source
              .getContractEndFixUsageSentFlag());
      // 送受電区分コード
      rKFixUsageApplyDataBusinessBean.setTransmissionCatCode(source.getTransmissionCatCode());
      // 月間全量
      rKFixUsageApplyDataBusinessBean.setMonthlyTotalKwh(source.getMonthlyTotalKwh());

      // 確定使用量Example
      FuExample contractFuExample = new FuExample();

      // 確定使用量を取得する条件を設定
      contractFuExample.createCriteria().andContractIdEqualTo(source.getContractId());
      // 利用年月の降順で並べ替え
      contractFuExample.setOrderByClause("use_period DESC");
      // 確定使用量を取得
      List<Fu> contractFuList = fuMapper.selectByExample(contractFuExample);

      // 計算対象フラグ
      boolean calculationFlag = true;

      // 利用年月
      String usePeriod = null;

      // 検針日が属する年月
      String meterReadingYm = null;

      // 機能制御用プロパティの利用年月算定方法区分が"1"(検針日から算出)の場合
      if (ECISConstants.FLG_ON.equals(RK_PropertyUtil.getProperty(applicationProperties,
          "useperiod.calculation.way.category"))) {

        // 内部変数.検針日の年月 = 《確定使用量反映データEntityBean》.検針日を“年月”の形式で文字列化
        meterReadingYm = StringConvertUtil.convertDateToString(
            source.getMeterReadingDate(),
            ECISConstants.FORMAT_DATE_yyyyMM);
      } else {
        // 検針日が属する年月に対象年月を設定
        meterReadingYm = source.getCoveredPeriod();
      }

      // 高圧かつ検針日区分が"定例日検針"かつ基本検針日が"1日"以外の場合(※高圧１日検針以外の場合)
      if (!(source.getFixUsageFileName()
          .startsWith(ECISSRConstants.MDMS_LINKAGE_FILE_CATEGORY_M_HIGH_TENSION_FIXUSAGE)
          && ECISCodeConstants.METER_READING_DATE_CATEGORY_REGULAR_DAY
              .equals(source.getMeterReadingDateCategoryCode())
          && Integer.parseInt(source.getBasicMeterReadingDate()) == 1)) {

        // 確定使用量が取得できなかった場合
        if (contractFuList.size() == 0) {

          // 低圧発電の場合
          if (source.getFixUsageFileName()
              .startsWith(ECISSRConstants.MDMS_LINKAGE_FILE_CATEGORY_M_LOW_TENSION_FIXGENERATION)) {

            // 検針日の属する年月を利用年月とする
            usePeriod = meterReadingYm;

            // 低圧発電以外の場合
          } else {

            // 確定使用量対象日_最小の月を取得
            String strMinimumFuCoveredDateMonth = new SimpleDateFormat("MM")
                .format(source.getMinimumFuCoveredDate());

            // 確定使用量対象日_最大を+1日した月を取得
            // 確定使用量対象日_最大に+1日する
            Calendar calculationMaximumFuCoveredDate = Calendar.getInstance();
            calculationMaximumFuCoveredDate.setTime(source.getMaximumFuCoveredDate());
            calculationMaximumFuCoveredDate.add(Calendar.DAY_OF_MONTH, 1);
            Date maximumFuCoveredDateNextDay = calculationMaximumFuCoveredDate.getTime();

            // +1日された日付から月を取得
            String strMaximumFuCoveredDateMonth = new SimpleDateFormat("MM")
                .format(maximumFuCoveredDateNextDay);

            // 確定使用量対象日_最小の月 = 確定使用量対象日_最大 +1日の月の場合
            if (strMinimumFuCoveredDateMonth.equals(strMaximumFuCoveredDateMonth)) {

              // 対象年月を利用年月とする
              usePeriod = source.getCoveredPeriod();

            } else {

              // 検針日の属する年月を利用年月とする
              usePeriod = meterReadingYm;

            }
          }

        } else {

          // 処理対象確定使用量データ
          Fu targetFixUsage = new Fu();

          // 通常時フラグ
          boolean normalTimeFlg = true;

          for (Fu fixUsage : contractFuList) {

            // 《確定使用量》.利用年月と内部変数.検針日の年月が一致するデータが存在する場合
            if (fixUsage.getUsePeriod().equals(meterReadingYm)) {

              // 一致するデータを処理対象確定使用量データとする
              targetFixUsage = fixUsage;

              // 通常時フラグをoffにする
              normalTimeFlg = false;
              break;
            }
          }

          // 《確定使用量》.利用年月と内部変数.検針日の年月が一致するデータが存在しない場合
          if (normalTimeFlg) {

            // 検針日の属する年月を利用年月とする
            usePeriod = meterReadingYm;

          } else if (!normalTimeFlg && targetFixUsage.getMurMrDate().equals(
              source.getMeterReadingDate())) {
            // 【確定使用量】.月次実績検針日と確定使用量メッセージで連携された検針日が同日の場合、
            // 【確定使用量】.利用年月を利用年月とする
            usePeriod = targetFixUsage.getUsePeriod();

            // 取り込み済みの【確定使用量】から検針期間の情報を設定する
            // スマートメータ区分コード
            rKFixUsageApplyDataBusinessBean.setSmartMeterCategoryCode(targetFixUsage.getSmCatCode());

            // 検針日区分コード
            rKFixUsageApplyDataBusinessBean
                .setMeterReadingDateCategoryCode(targetFixUsage.getMrDateCatCode());

            // 検針期間開始日
            rKFixUsageApplyDataBusinessBean.setMeterReadingStartDate(targetFixUsage.getMrSd());

            // 検針期間終了日
            rKFixUsageApplyDataBusinessBean.setMeterReadingEndDate(targetFixUsage.getMrEd());

          } else {

            // 月内で２回の検針が行われた（同一年月で日が異なる検針日の確定使用量が連携された）場合

            // 検針日が同年月の確定使用量と使用量の対象期間が重複していないか
            // ※確定使用量の使用終了日が確定使用量対象日の開始日より前の日付であれば重複なしとみなす
            if (targetFixUsage.getUsageEd().before(
                source.getMinimumFuCoveredDate())) {
              // 期間が重複していなければ、契約終了により２度目の検針が行われたとみなし、
              // 【確定使用量】利用年月の直近の利用年月の翌月を「利用年月」とする。
              usePeriod = StringConvertUtil.convertDateToString(DateUtils
                  .addMonths(StringConvertUtil.stringToDate(
                      targetFixUsage.getUsePeriod(),
                      ECISConstants.FORMAT_DATE_yyyyMM), 1),
                  ECISConstants.FORMAT_DATE_yyyyMM);
            } else {
              // 期間が重複している場合は、TODOを登録し、使用量を計算対象外とする

              // TODOのパラメータ
              Object[] params = {
                  // 確定使用量ファイル名
                  rKFixUsageApplyDataBusinessBean
                      .getFixUsageFileName(),
                  // 地点特定番号
                  rKFixUsageApplyDataBusinessBean.getSpotNo(),
                  // エリアコード
                  rKFixUsageApplyDataBusinessBean.getAreaCode(),
                  // バッチ実行日(yyyy/MM/dd)
                  StringConvertUtil.convertDateToString(executeDate,
                      ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH) };

              // TODOビジネスBean
              TodoBusinessBean todoBean = new TodoBusinessBean();
              // サブシステムID
              todoBean.setSubsystemId(ECISConstants.SUBSYSTEM_ID_RK);
              // 機能ID
              todoBean.setFunctionId(ECISTodoConstants.TODO_FUNCTION_ID.RK0101
                  .toString());
              // メッセージID
              todoBean.setMessageId("todo.T1047");
              // メッセージ
              todoBean.setMessage(messageSource.getMessage(
                  todoBean.getMessageId(), params,
                  Locale.getDefault()));
              // 地点特定番号
              todoBean.setSpotNo(rKFixUsageApplyDataBusinessBean.getSpotNo());

              // TODO登録
              todoBusiness.registTodo(todoBean);

              // 計算対象外とする
              calculationFlag = false;
            }
          }
        }
      }

      // 計算対象フラグが"true"の場合、計算に必要なデータを取得する
      if (calculationFlag) {
        // 算定期間開始日
        Date calcTermStart = null;

        // 確定使用量Example
        FuExample fuExample = new FuExample();

        // 過去分の確定使用量を取得する条件を設定
        fuExample.createCriteria()
            // 契約ID
            .andContractIdEqualTo(source.getContractId())
            // 検針日(確定使用量メッセージで連携された検針日より前)
            .andMurMrDateLessThan(source.getMeterReadingDate());

        // 使用終了日の降順で並べ替える
        fuExample
            .setOrderByClause(ECISRKConstants.FIX_USAGE_APPLY_FIX_USAGE_ORDER_BY_CLAUSE);

        // 過去分の確定使用量を取得
        List<Fu> fixUsageList = fuMapper.selectByExample(fuExample);

        // 算定期間開始日の判定
        if (fixUsageList.isEmpty()) {
          // 過去分の【確定使用量】が存在しない場合、契約開始日を算定期間開始日とする
          calcTermStart = source.getContractStartDate();
        } else {
          // 過去分の【確定使用量】が存在する場合、その中で最大の使用量終了日の翌日を算定期間開始日とする
          calcTermStart = DateUtils.addDays(fixUsageList.get(0)
              .getUsageEd(), 1);
        }

        //高圧かつ検針日区分が"定例日検針"かつ基本検針日が"1日"の場合
        if (source.getFixUsageFileName()
            .startsWith(ECISSRConstants.MDMS_LINKAGE_FILE_CATEGORY_M_HIGH_TENSION_FIXUSAGE)
            && ECISCodeConstants.METER_READING_DATE_CATEGORY_REGULAR_DAY
                .equals(source.getMeterReadingDateCategoryCode())
            && Integer.parseInt(source.getBasicMeterReadingDate()) == 1) {

          // 利用年月を算定期間開始日が含まれる月に更新する。
          usePeriod = StringConvertUtil.convertDateToString(
              calcTermStart,
              ECISConstants.FORMAT_DATE_yyyyMM);
        }

        // 【需要実績】を取得
        List<DemandResult> demandResultList = selectDemandResult(
            source.getSpotNo(),
            // 確定使用量ファイル名
            source.getFixUsageFileName(),
            // エリアコード
            source.getAreaCode(),
            // 確定使用量対象日
            calcTermStart, source.getContractEndDate());

        // 算定期間終了日は取得した【需要実績】の最後の要素の確定使用量対象日
        Date calcTermEnd = demandResultList.get(
            demandResultList.size() - 1).getFuCoveredDate();

        // 利用年月・算定期間・バッチ実行日の値をBeanに設定する
        rKFixUsageApplyDataBusinessBean.setUsePeriod(usePeriod);
        rKFixUsageApplyDataBusinessBean
            .setCalculationTermStartDate(calcTermStart);
        rKFixUsageApplyDataBusinessBean
            .setCalculationTermEndDate(calcTermEnd);
        rKFixUsageApplyDataBusinessBean.setExecuteDate(executeDate);

        // 使用量を格納するBusinessBeanのリストを作成
        List<RK_FixUsageApplyUsageBusinessBean> usageList = new ArrayList<RK_FixUsageApplyUsageBusinessBean>(
            demandResultList.size());

        // 使用量BusinessBean
        RK_FixUsageApplyUsageBusinessBean usage = null;

        // 取得した【需要実績】ごとに、繰り返し
        for (DemandResult demandResult : demandResultList) {

          // Beanを生成
          usage = new RK_FixUsageApplyUsageBusinessBean();

          // 使用量Beanに値を設定
          // 年月日
          usage.setUsageDate(demandResult.getFuCoveredDate());
          // 使用量リスト
          // 30分確定使用量01～48をリストに変換して設定
          usage.setUsageList(rkFixUsageCommonBusiness
              .demandResultToFixUsageList(demandResult));

          // Beanをリストに追加
          usageList.add(usage);
        }

        // 使用量リストをBeanに設定
        rKFixUsageApplyDataBusinessBean.setCoveredUsageList(usageList);

        // スマートメータ区分コードがnull（訂正データでない）の場合は、検針期間の判定を行う
        if (rKFixUsageApplyDataBusinessBean.getSmartMeterCategoryCode() == null) {

          // スマートメータ区分コードを設定
          rKFixUsageApplyDataBusinessBean.setSmartMeterCategoryCode(source.getSmartMeterCategoryCode());

          // 検針日区分コードを設定
          rKFixUsageApplyDataBusinessBean
              .setMeterReadingDateCategoryCode(source.getMeterReadingDateCategoryCode());

          // 検針日区分が"分散検針"の場合は、検針カレンダーマスタから検針期間を取得する
          if (ECISCodeConstants.METER_READING_DATE_CATEGORY_DISPERSION.equals(rKFixUsageApplyDataBusinessBean
              .getMeterReadingDateCategoryCode())) {
            // エリアコードが計量日制エリアリストのいずれかと一致する場合、計量日制エリアとする
            boolean measureDateAreaFlag = measureDateAreaList.contains(rKFixUsageApplyDataBusinessBean
                .getAreaCode());

            // 検針期間判定
            decideMeterReadingDate(rKFixUsageApplyDataBusinessBean, source.getBasicMeterReadingDate(),
                measureDateAreaFlag);
          } else if (ECISCodeConstants.METER_READING_DATE_CATEGORY_REGULAR_DAY
              .equals(rKFixUsageApplyDataBusinessBean
                  .getMeterReadingDateCategoryCode())) {
            // 検針日区分が"定例日検針"の場合は、基本検針日から検針期間を取得する
            decideMeterReadingDateForRegularDay(
                rKFixUsageApplyDataBusinessBean,
                source.getBasicMeterReadingDate());
          } else {
            // 検針日区分が"固定日検針"の場合は、1日固定として検針期間を取得する
            decideMeterReadingDateForRegularDay(
                rKFixUsageApplyDataBusinessBean,
                ECISConstants.DATE_FIRST);
          }
        }
      }

      // 結果のリストにBeanを追加
      destList.add(rKFixUsageApplyDataBusinessBean);
    }

    return destList;
  }

  /**
   * 【需要実績】を取得する。
   *
   * @param spotNo
   *          地点特定番号
   * @param fixUsageFileName
   *          確定使用量ファイル名
   * @param areaCode
   *          エリアコード
   * @param startDate
   *          対象期間開始日
   * @param endDate
   *          対象期間終了日
   * @return 需要実績Entity
   */
  private List<DemandResult> selectDemandResult(String spotNo,
      String fixUsageFileName, String areaCode, Date startDate,
      Date endDate) {
    // 需要実績Example
    DemandResultExample demandResultExample = new DemandResultExample();

    // 【需要実績】を取得する条件を設定
    demandResultExample.createCriteria()
        // 地点特定番号
        .andSpotNoEqualTo(spotNo)
        // 確定使用量ファイル名
        .andFuFileNameEqualTo(fixUsageFileName)
        // エリアコード
        .andAreaCodeEqualTo(areaCode)
        // 確定使用量対象日
        .andFuCoveredDateBetween(startDate, endDate);

    // 並び順を設定
    // 確定使用量対象日の昇順
    demandResultExample
        .setOrderByClause(ECISRKConstants.FIX_USAGE_APPLY_DEMAND_RESULT_ORDER_BY_CLAUSE);

    // 【需要実績】を返却
    return demandResultMapper.selectByExample(demandResultExample);
  }

  /**
   * 検針期間の判定を行う。
   *
   * @param fixUsageApplyDataBusinessBean
   *          確定使用量反映データビジネスBean
   * @param basicMeterReadingDate
   *          基本検針日
   * @param measureDateAreaFlag
   *          計量日制フラグ
   */
  private void decideMeterReadingDate(RK_FixUsageApplyDataBusinessBean fixUsageApplyDataBusinessBean,
      String basicMeterReadingDate, boolean measureDateAreaFlag) {

    // 通常月の判定（契約初月でも契約最終月でもない）
    if (!fixUsageApplyDataBusinessBean.getContractStartDate().equals(
        fixUsageApplyDataBusinessBean.getCalculationTermStartDate())
        && !fixUsageApplyDataBusinessBean.getContractEndDate().equals(
            fixUsageApplyDataBusinessBean.getCalculationTermEndDate())) {

      // 通常月の場合、検針期間に算定期間と同じ期間を設定する
      // 検針期間開始日
      fixUsageApplyDataBusinessBean.setMeterReadingStartDate(fixUsageApplyDataBusinessBean
          .getCalculationTermStartDate());

      // 検針期間終了日
      fixUsageApplyDataBusinessBean.setMeterReadingEndDate(fixUsageApplyDataBusinessBean
          .getCalculationTermEndDate());
    } else {
      // 通常月でない場合の判定

      // 利用年月を取得する
      String lastUsePeriod = StringConvertUtil.calcMonthNoException(
          fixUsageApplyDataBusinessBean.getUsePeriod(), -1,
          ECISConstants.FORMAT_DATE_yyyyMM);

      // 検針カレンダーExampleを生成
      MrCalendarMExample mrCalendarMExample = new MrCalendarMExample();

      // 検針カレンダーExampleに条件を設定
      mrCalendarMExample.createCriteria()
          // エリアコード
          .andAreaCodeEqualTo(fixUsageApplyDataBusinessBean.getAreaCode())
          // 基本検針日
          .andBasicMrDateIntEqualTo(Short.valueOf(basicMeterReadingDate))
          // 利用年月（当月、前月）
          .andUsePeriodIn(Arrays.asList(fixUsageApplyDataBusinessBean.getUsePeriod(), lastUsePeriod));

      // 利用年月の昇順で並べ替え
      mrCalendarMExample.setOrderByClause(ECISRKConstants.FIX_USAGE_APPLY_METER_READIN_CALENDAR_ORDER_BY_CLAUSE);

      // 前月・当月の検針カレンダーを取得する
      List<MrCalendarM> mrCalendarMList = mrCalendarMMapper.selectByExample(mrCalendarMExample);

      // 取得した検針カレンダーの件数が２件未満の場合は、検針期間を設定せずに処理を終了する
      if (mrCalendarMList.size() < 2) {
        return;
      }

      // 取得した検針カレンダーの１件目が前月分
      MrCalendarM previousMrCalendar = mrCalendarMList.get(0);

      // 取得した検針カレンダーの２件目が当月分
      MrCalendarM currentMrCalendar = mrCalendarMList.get(1);

      // 当月検針日の前日を取得
      Date dayBeforeMeterReadingDate = DateUtils.addDays(currentMrCalendar.getMrDate(), -1);

      // 計量日が存在する場合は当月計量日の前日を取得
      Date dayBeforeMeasureDate = null;
      if (currentMrCalendar.getMeasureDate() != null) {
        dayBeforeMeasureDate = DateUtils.addDays(currentMrCalendar.getMeasureDate(), -1);
      }

      // メータの状態等を条件に検針期間を判定する
      if (ECISCodeConstants.SMART_METER_CATEGORY_CODE_NOT_REPLACED.equals(fixUsageApplyDataBusinessBean
          .getSmartMeterCategoryCode()) || !measureDateAreaFlag) {
        // スマートメータ区分が"従来計器"か計量日制エリアでない場合

        // 計算月の判定
        if (fixUsageApplyDataBusinessBean.getContractStartDate().equals(
            fixUsageApplyDataBusinessBean.getCalculationTermStartDate())) {
          // 契約初月の場合
          // 検針期間開始日＝前月検針日
          fixUsageApplyDataBusinessBean.setMeterReadingStartDate(previousMrCalendar.getMrDate());
          // 検針期間終了日＝当月検針日の前日
          fixUsageApplyDataBusinessBean.setMeterReadingEndDate(dayBeforeMeterReadingDate);
        } else {
          // 契約最終月の場合
          // 検針期間開始日＝算定期間開始日
          fixUsageApplyDataBusinessBean.setMeterReadingStartDate(fixUsageApplyDataBusinessBean
              .getCalculationTermStartDate());
          // 検針期間終了日＝当月検針日の前日
          fixUsageApplyDataBusinessBean.setMeterReadingEndDate(dayBeforeMeterReadingDate);
        }
      } else if (ECISCodeConstants.SMART_METER_CATEGORY_CODE_REPLACED_AFTER_LAST_METER_READING
          .equals(fixUsageApplyDataBusinessBean.getSmartMeterCategoryCode())) {
        // スマートメータ区分が"前回検針後にスマメ切替"の場合

        // 計算月の判定
        if (fixUsageApplyDataBusinessBean.getContractStartDate().equals(
            fixUsageApplyDataBusinessBean.getCalculationTermStartDate())) {
          // 契約初月の場合
          // 検針期間開始日＝前月検針日
          fixUsageApplyDataBusinessBean.setMeterReadingStartDate(previousMrCalendar.getMrDate());
          // 検針期間終了日＝当月計量日の前日
          fixUsageApplyDataBusinessBean.setMeterReadingEndDate(dayBeforeMeasureDate);
        } else {
          // 契約最終月の場合
          // 検針期間開始日＝算定期間開始日
          fixUsageApplyDataBusinessBean.setMeterReadingStartDate(fixUsageApplyDataBusinessBean
              .getCalculationTermStartDate());
          // 検針期間終了日＝当月計量日の前日
          fixUsageApplyDataBusinessBean.setMeterReadingEndDate(dayBeforeMeasureDate);
        }
      } else {
        // スマートメータ区分が"スマメ切替済"の場合

        // 計算月の判定
        if (fixUsageApplyDataBusinessBean.getContractStartDate().equals(
            fixUsageApplyDataBusinessBean.getCalculationTermStartDate())) {
          // 契約初月の場合
          // 検針期間開始日＝前月計量日
          fixUsageApplyDataBusinessBean.setMeterReadingStartDate(previousMrCalendar.getMeasureDate());
          // 検針期間終了日＝当月計量日の前日
          fixUsageApplyDataBusinessBean.setMeterReadingEndDate(dayBeforeMeasureDate);
        } else {
          // 契約最終月の場合
          // 検針期間開始日＝算定期間開始日
          fixUsageApplyDataBusinessBean.setMeterReadingStartDate(fixUsageApplyDataBusinessBean
              .getCalculationTermStartDate());
          // 検針期間終了日＝当月計量日の前日
          fixUsageApplyDataBusinessBean.setMeterReadingEndDate(dayBeforeMeasureDate);
        }
      }
    }
  }

  /**
   * 定例日検針の検針期間判定を行う。
   *
   * @param fixUsageApplyDataBusinessBean
   *          確定使用量反映データビジネスBean
   * @param basicMeterReadingDate
   *          基本検針日
   */
  private void decideMeterReadingDateForRegularDay(RK_FixUsageApplyDataBusinessBean fixUsageApplyDataBusinessBean,
      String basicMeterReadingDate) {

    // 通常月の判定（契約初月でも契約最終月でもない）
    if (!fixUsageApplyDataBusinessBean.getContractStartDate().equals(
        fixUsageApplyDataBusinessBean.getCalculationTermStartDate())
        && !fixUsageApplyDataBusinessBean.getContractEndDate().equals(
            fixUsageApplyDataBusinessBean.getCalculationTermEndDate())) {

      // 通常月の場合、検針期間に算定期間と同じ期間を設定する
      // 検針期間開始日
      fixUsageApplyDataBusinessBean.setMeterReadingStartDate(fixUsageApplyDataBusinessBean
          .getCalculationTermStartDate());

      // 検針期間終了日
      fixUsageApplyDataBusinessBean.setMeterReadingEndDate(fixUsageApplyDataBusinessBean
          .getCalculationTermEndDate());
    } else {
      // 通常月でない場合の判定（契約初月か廃止月か）

      // 基本検針日を数値化
      int basicMrDateInt = Integer.parseInt(basicMeterReadingDate);

      // 基本検針日が1日の場合
      if (basicMrDateInt == 1) {

        // 計算月の判定
        if (fixUsageApplyDataBusinessBean.getContractStartDate().equals(
            fixUsageApplyDataBusinessBean.getCalculationTermStartDate())) {
          // 契約初月の場合
          // 利用年月の末尾に"01"を付加した文字列を日付型へ変換し、当月初日とする
          Date currentMonthFirstDate = StringConvertUtil
              .stringToDate(fixUsageApplyDataBusinessBean.getUsePeriod()
                  + ECISConstants.DATE_FIRST, ECISConstants.FORMAT_DATE_yyyyMMdd);
          // 検針期間開始日＝利用年月当月の1日
          fixUsageApplyDataBusinessBean.setMeterReadingStartDate(currentMonthFirstDate);

          // 検針期間終了日＝算定期間終了日
          fixUsageApplyDataBusinessBean
              .setMeterReadingEndDate(fixUsageApplyDataBusinessBean.getCalculationTermEndDate());
        } else {
          // 契約最終月の場合
          // 検針期間開始日＝算定期間開始日
          fixUsageApplyDataBusinessBean.setMeterReadingStartDate(fixUsageApplyDataBusinessBean
              .getCalculationTermStartDate());

          // 利用年月の翌月を取得
          String nextUsePeriod = StringConvertUtil.calcMonthNoException(
              fixUsageApplyDataBusinessBean.getUsePeriod(), 1,
              ECISConstants.FORMAT_DATE_yyyyMM);

          // 利用年月翌月の末尾に"01"を付加した文字列を日付型へ変換し、翌月初日とする
          Date nextMonthFirstDate = StringConvertUtil.stringToDate(nextUsePeriod
              + ECISConstants.DATE_FIRST, ECISConstants.FORMAT_DATE_yyyyMMdd);
          // 翌月1日の前日は当月末日
          Date currentMonthEndDate = DateUtils.addDays(nextMonthFirstDate, -1);

          // 検針期間終了日＝利用年月当月の末日
          fixUsageApplyDataBusinessBean.setMeterReadingEndDate(currentMonthEndDate);
        }
      } else {
        // それ以外（基本検針日が1日以外）の場合
        // 利用年月の前月を取得
        String lastUsePeriod = StringConvertUtil.calcMonthNoException(
            fixUsageApplyDataBusinessBean.getUsePeriod(), -1,
            ECISConstants.FORMAT_DATE_yyyyMM);

        // 基本検針日を0埋め2桁の文字列に変換
        String basicMrStr = String.format("%02d", basicMrDateInt);

        // 利用年月の末尾に基本検針日を付加した文字列を日付型へ変換
        Date currentMonthEndDate = StringConvertUtil.stringToDate(fixUsageApplyDataBusinessBean.getUsePeriod()
            + basicMrStr, ECISConstants.FORMAT_DATE_yyyyMMdd);
        // その前日を当月最終日とする
        currentMonthEndDate = DateUtils.addDays(currentMonthEndDate, -1);

        // 検針期間終了日＝利用年月当月の末日
        fixUsageApplyDataBusinessBean.setMeterReadingEndDate(currentMonthEndDate);

        // 計算月の判定
        if (fixUsageApplyDataBusinessBean.getContractStartDate().equals(
            fixUsageApplyDataBusinessBean.getCalculationTermStartDate())) {
          // 契約初月の場合
          // 利用年月の末尾に基本検針日を付加した文字列を日付型へ変換し、前月初日とする
          Date lastMonthFirstDate = StringConvertUtil.stringToDate(lastUsePeriod
              + basicMrStr, ECISConstants.FORMAT_DATE_yyyyMMdd);
          // 検針期間開始日＝利用年月当月の1日
          fixUsageApplyDataBusinessBean.setMeterReadingStartDate(lastMonthFirstDate);
        } else {
          // 契約最終月の場合
          // 検針期間開始日＝算定期間開始日
          fixUsageApplyDataBusinessBean.setMeterReadingStartDate(fixUsageApplyDataBusinessBean
              .getCalculationTermStartDate());
        }
      }
    }
  }

  /**
   * 確定使用量情報反映Daoを設定します。(DI)
   *
   * @param rkFixUsageApplyDao
   *          確定使用量情報反映Dao
   */
  public void setRkFixUsageApplyDao(RK_FixUsageApplyDao rkFixUsageApplyDao) {
    this.rkFixUsageApplyDao = rkFixUsageApplyDao;
  }

  /**
   * 確定使用量共通ビジネスインターフェースを設定します。(DI)
   *
   * @param rkFixUsageCommonBusiness
   *          確定使用量共通ビジネスインターフェース
   */
  public void setRkFixUsageCommonBusiness(
      RK_FixUsageCommonBusiness rkFixUsageCommonBusiness) {
    this.rkFixUsageCommonBusiness = rkFixUsageCommonBusiness;
  }

  /**
   * 確定使用量Mapperを設定します。(DI)
   *
   * @param fuMapper
   *          確定使用量Mapper
   */
  public void setFuMapper(FuMapper fuMapper) {
    this.fuMapper = fuMapper;
  }

  /**
   * 需要実績Mapperを設定します。(DI)
   *
   * @param demandResultMapper
   *          需要実績Mapper
   */
  public void setDemandResultMapper(DemandResultMapper demandResultMapper) {
    this.demandResultMapper = demandResultMapper;
  }

  /**
   * TODOビジネスを設定します。(DI)
   *
   * @param todoBusiness
   *          TODOビジネス
   */
  public void setTodoBusiness(TodoBusiness todoBusiness) {
    this.todoBusiness = todoBusiness;
  }

  /**
   * メッセージリソースを設定します。(DI)
   *
   * @param messageSource
   *          メッセージリソース
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }

  /**
   * 検針カレンダーMapperを設定します。(DI)
   *
   * @param mrCalendarMapper
   *          検針カレンダーMapper
   */
  public void setMrCalendarMMapper(MrCalendarMMapper mrCalendarMMapper) {
    this.mrCalendarMMapper = mrCalendarMMapper;
  }

  /**
   * プロパティファクトリーを設定します。(DI)
   *
   * @param applicationProperties
   *          プロパティファクトリー
   */
  public void setApplicationProperties(
      PropertiesFactoryBean applicationProperties) {
    this.applicationProperties = applicationProperties;
  }

}