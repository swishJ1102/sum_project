package jp.co.unisys.enability.cis.business.kj;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.config.PropertiesFactoryBean;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.dao.DataAccessException;

import jp.co.unisys.enability.cis.business.common.DateBusiness;
import jp.co.unisys.enability.cis.business.kj.model.Custom_AgentSearchContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.SearchContractListBusinessBean;
import jp.co.unisys.enability.cis.common.Exception.SystemException;
import jp.co.unisys.enability.cis.common.util.KJ_CommonUtil;
import jp.co.unisys.enability.cis.common.util.StringConvertUtil;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISKJConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISReturnCodeConstants;
import jp.co.unisys.enability.cis.entity.kj.Custom_KJ_AgentContractorInformationSearchEntityBean;
import jp.co.unisys.enability.cis.entity.kj.KJ_ContractListResultEntityBean;
import jp.co.unisys.enability.cis.mapper.kj.Custom_AgentContractInfoSearchCommonMapper;

/**
 * 卸取次店向け契約情報検索ビジネス_カスタムクラス
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.kj.Custom_KJ_AgentContractSearchInformationBusiness
 *
 *      変更履歴(kg-epj) 2016.03.01 芦垣 新規作成
 */
// [kg-epj]<d-start>
//public class KJ_AgentContractSearchInformationBusinessImpl implements
//		KJ_AgentContractSearchInformationBusiness {
// [kg-epj]<d-start>
// [kg-epj]<i-start>
public class Custom_KJ_AgentContractSearchInformationBusinessImpl implements
    Custom_KJ_AgentContractSearchInformationBusiness {
  // [kg-epj]<i-end>

  /**
   * メッセージリソース(DI)
   */
  private MessageSource messageSource;

  // [kg-epj]<d-start>
  //	/**
  //	 * 契約情報検索共通マッパー(DI)
  //	 */
  //	private AgentContractInfoSearchCommonMapper agentContractInfoSearchCommonMapper;
  // [kg-epj]<d-end>
  // [kg-epj]<i-start>
  /**
   * 卸取次店向け契約情報検索共通Mapper_カスタム(DI)
   */
  private Custom_AgentContractInfoSearchCommonMapper agentContractInfoSearchCommonMapper;
  // [kg-epj]<i-end>

  /**
   * 日付関連共通ビジネス(DI)
   */
  private DateBusiness dateBusiness;

  /**
   * プロパティファクトリー(DI)
   */
  private PropertiesFactoryBean applicationProperties;

  /**
   * ログマネジャー
   */
  private static Logger logger = LogManager.getLogger();

  // [kg-epj]<d-start>
  //	/*
  //	 * (非 Javadoc)
  //	 *
  //	 * @see jp.co.unisys.enability.cis.business.kj.
  //	 * KJ_AgentContractSearchInformationBusiness
  //	 * #search(jp.co.unisys.enability.cis
  //	 * .business.kj.model.AgentSearchContractBusinessBean)
  //	 */
  //	@Override
  //	public AgentSearchContractBusinessBean search(
  //			AgentSearchContractBusinessBean AgentSearchContractBusiness) {
  // [kg-epj]<d-end>

  // [kg-epj]<i-start>
  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.kj.
   * Custom_KJ_AgentContractSearchInformationBusiness
   * #search(jp.co.unisys.enability.cis
   * .business.kj.model.Custom_AgentSearchContractBusinessBean)
   */
  @Override
  public Custom_AgentSearchContractBusinessBean search(
      Custom_AgentSearchContractBusinessBean AgentSearchContractBusiness) {
    // [kg-epj]<i-end>

    String errMsg = null;
    String fileMsg = null;

    try {

      // Propaertiesオブジェクト取得
      Properties prop = applicationProperties.getObject();

      // システムエラーメッセージを取得
      errMsg = messageSource.getMessage(KJ_CommonUtil
          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G017),
          null, Locale.getDefault());

      fileMsg = messageSource.getMessage("error.E1283", null,
          Locale.getDefault());

      // 契約情報検索BusinessBean.最大検索結果件数がnullまたは'0'の場合、以下を設定する。
      if (AgentSearchContractBusiness.getMaxSearchResultCount() == null
          || AgentSearchContractBusiness.getMaxSearchResultCount()
              .equals(0)) {
        // 契約情報検索BusinessBean.最大検索結果件数:システム定義.最大検索結果件数
        // 最大検索件数を取得する。
        AgentSearchContractBusiness
            .setMaxSearchResultCount(StringConvertUtil.stringToInteger(prop
                .getProperty("maxsearchcount.SKJ020101")));
      }

      // 契約情報検索BusinessBean.契約者電話番号が設定されている場合、以下を設定する。
      String cntractorPhoneNo = AgentSearchContractBusiness
          .getContractorPhoneNo();
      if (cntractorPhoneNo != null) {
        // 契約情報検索BusinessBean.契約者電話番号のハイフンを除去
        cntractorPhoneNo = cntractorPhoneNo.replace(
            ECISConstants.HYPHEN, "");
      }

      // 契約情報検索マップに契約情報検索BusinessBeanを設定する。
      Map<String, Object> exampleMap = new HashMap<String, Object>();
      // 契約者ID
      exampleMap.put("contractorId",
          AgentSearchContractBusiness.getContractorId());
      // 契約者番号
      exampleMap.put("contractorNo",
          AgentSearchContractBusiness.getContractorNo());
      // 個人・法人区分コード
      exampleMap.put("individualLegalEntityCategoryCode",
          AgentSearchContractBusiness
              .getIndividualLegalEntityCategoryCode());
      // 契約者名カナ
      exampleMap.put("contractorNameKana",
          AgentSearchContractBusiness.getContractorNameKana());
      // 契約者名
      exampleMap.put("contractorNameKanji",
          AgentSearchContractBusiness.getContractorNameKanji());
      // 契約者住所
      exampleMap.put("contractorAddress",
          AgentSearchContractBusiness.getContractorAddress());
      // 契約者電話番号
      exampleMap.put("contractorPhoneNo", cntractorPhoneNo);
      // 契約者メールアドレス
      exampleMap.put("contractorMailAddress",
          AgentSearchContractBusiness.getContractorMailAddress());
      // 提供モデルコード
      exampleMap.put("provideModelCode",
          AgentSearchContractBusiness.getProvideModelCode());
      // 提供モデル企業コード
      exampleMap.put("provideModelCompanyCode",
          AgentSearchContractBusiness.getProvideModelCompanyCode());
      // 契約ID
      exampleMap.put("contractId",
          AgentSearchContractBusiness.getContractId());
      // 契約番号
      exampleMap.put("contractNo",
          AgentSearchContractBusiness.getContractNo());
      // 営業委託先コード
      exampleMap.put("salesConsignmentCode",
          AgentSearchContractBusiness.getSalesConsignmentCode());
      // メータ設置場所ID
      exampleMap.put("meterLocationId",
          AgentSearchContractBusiness.getMeterLocationId());
      // 地点特定番号
      exampleMap.put("spotNo", AgentSearchContractBusiness.getSpotNo());
      // 送受電区分コード
      exampleMap.put("transmissionCategoryCode",
          AgentSearchContractBusiness.getTransmissionCategoryCode());
      // 需要場所住所
      exampleMap.put("placeAddress",
          AgentSearchContractBusiness.getPlaceAddress());
      // 請求ID
      exampleMap.put("billingId",
          AgentSearchContractBusiness.getBillingId());
      // 請求番号
      exampleMap.put("billingNo",
          AgentSearchContractBusiness.getBillingNo());
      // 契約終了状況
      exampleMap.put("contractEndSts",
          AgentSearchContractBusiness.getContractEndSts());
      // 契約者利用状況
      exampleMap.put("contractorUseSts",
          AgentSearchContractBusiness.getContractorUseSts());
      // 最大検索結果件数
      exampleMap.put("maxSearchResultCount",
          AgentSearchContractBusiness.getMaxSearchResultCount());
      // 卸取次店契約者番号
      exampleMap.put("agentContractorNo",
          AgentSearchContractBusiness.getAgentContractorNo());
      // 卸取次店契約番号
      exampleMap.put("agentContractNo",
          AgentSearchContractBusiness.getAgentContractNo());
      // 要求日付
      exampleMap.put("requestDate",
          AgentSearchContractBusiness.getRequestDate());
      // 電圧区分コード
      exampleMap.put("voltageCatetoryCode",
          AgentSearchContractBusiness.getVoltageCatetoryCode());
      // 契約電力決定区分コード
      exampleMap.put("contractCapacityDecisionCategoryCode",
          AgentSearchContractBusiness.getContractCapacityDecisionCategoryCode());
      // オンライン基準処理日
      exampleMap.put("onlineDate", dateBusiness
          .getProcessBaseDate(ECISConstants.EXEC_BASE_DATE_ONLINE));

      // [kg-epj]<i-start>
      // 外部システム契約者番号
      exampleMap.put("gasCustomerNo", AgentSearchContractBusiness.getGasCustomerNo());
      // 外部システム契約番号
      exampleMap.put("gasSupplyContractNo", AgentSearchContractBusiness.getGasSupplyContractNo());
      // 外部システム支払番号
      exampleMap.put("gasPaymentNo", AgentSearchContractBusiness.getGasPaymentNo());
      // [kg-epj]<i-end>

      // 検索結果件数取得
      // 1契約情報検索共通マッパー.契約情報検索件数呼び出し
      // 引数：契約情報検索マップ
      int resultCount = agentContractInfoSearchCommonMapper
          .countByControctInfoSearch(exampleMap);

      // 契約情報検索
      // [kg-epj]<d-start>
      //			List<KJ_AgentContractorInformationSearchEntityBean> resultList = new ArrayList<KJ_AgentContractorInformationSearchEntityBean>();
      // [kg-epj]<d-end>
      // [kg-epj]<i-start>
      List<Custom_KJ_AgentContractorInformationSearchEntityBean> resultList = new ArrayList<Custom_KJ_AgentContractorInformationSearchEntityBean>();
      // [kg-epj]<i-end>
      // 検索結果件数取得の結果が1件以上の場合、以下の処理を行う。
      if (resultCount > 0) {
        // 契約情報検索共通マッパー.契約情報検索呼び出し
        // 引数：契約情報検索マップ
        resultList = agentContractInfoSearchCommonMapper
            .controctInfoSearch(exampleMap);
      }

      // 契約情報検索BusinessBeanを作成し、契約情報検索共通マッパー.契約情報検索の戻り値等を設定する。
      // 契約情報検索BusinessBean.検索結果件数：検索結果件数取得の戻り値
      AgentSearchContractBusiness.setSearchResultCount(resultCount);
      // 契約情報検索BusinessBean.契約者情報検索結果一覧エンティティリスト：契約情報検索の戻り値
      AgentSearchContractBusiness
          .setSerchContractorEntityList(resultList);
      // 契約情報検索BusinessBean.ページ内一覧表示件数：システム定義.ページ内一覧表示件数
      // ページ内一覧表示件数を取得する
      AgentSearchContractBusiness.setPageDisplayCount(StringConvertUtil
          .stringToInteger(prop
              .getProperty("pagedisplaycount.SKJ020101")));

      // 正常終了
      AgentSearchContractBusiness
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);

    } catch (DataAccessException e) {
      logger.error(
          messageSource.getMessage("error.E1129", null,
              Locale.getDefault()),
          e);
      // 契約情報検索BusinessBean.リターンコードに（G017）を設定し処理を終了する。
      AgentSearchContractBusiness
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      AgentSearchContractBusiness.setMessage(errMsg);
    } catch (NoSuchMessageException e) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, e);
      AgentSearchContractBusiness
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      AgentSearchContractBusiness
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
    } catch (IOException e) {
      logger.error(
          messageSource.getMessage("error.E1129", null,
              Locale.getDefault()),
          e);
      AgentSearchContractBusiness
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      AgentSearchContractBusiness.setMessage(fileMsg);
    } catch (SystemException e) {
      logger.error(
          messageSource.getMessage("error.E1129", null,
              Locale.getDefault()),
          e);
      AgentSearchContractBusiness
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      AgentSearchContractBusiness.setMessage(e.getMessage());
    }

    return AgentSearchContractBusiness;
  }

  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.business.kj.Custom_KJ_AgentContractSearchInformationBusiness
   * #searchContractList(jp.co.unisys.enability.cis.business.kj.model.SearchContractListBusinessBean)
   */
  @Override
  public SearchContractListBusinessBean searchContractList(
      SearchContractListBusinessBean searchContractListBusiness) {
    String errMsg = null;
    String fileMsg = null;

    try {
      // Propaertiesオブジェクト取得
      Properties prop = applicationProperties.getObject();
      // システムエラーメッセージを取得
      errMsg = getPropertiesMesseage(ECISReturnCodeConstants.RETURN_CODE_G017);
      fileMsg = messageSource.getMessage("error.E1283", null, Locale.getDefault());

      // 《契約リスト検索BusinessBean》.契約者番号がNULLまたは空文字の場合
      if (StringUtils.isEmpty(searchContractListBusiness.getContractorNo())) {
        // 契約リスト検索BusinessBean.リターンコードに（P001）を設定し処理を終了する。
        searchContractListBusiness.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P001);
        searchContractListBusiness.setMessage(getPropertiesMesseage(ECISReturnCodeConstants.RETURN_CODE_P001));
        return searchContractListBusiness;
      }

      // 《契約リスト検索BusinessBean》.契約者番号がNULLまたは空文字ではない場合
      // 契約情報取得のための、検索条件を条件Mapに設定する。
      Map<String, Object> exampleMap = new HashMap<>();
      exampleMap.put("contractorNo", searchContractListBusiness.getContractorNo());
      exampleMap.put("contractNoList", searchContractListBusiness.getContractNoList());
      exampleMap.put("inqCoveredDate", searchContractListBusiness.getInqCoveredDate());
      exampleMap.put("pmCode", searchContractListBusiness.getProvideModelCode());
      exampleMap.put("pmCompanyCode", searchContractListBusiness.getProvideModelCompanyCode());
      exampleMap.put("maxDate", StringConvertUtil.stringToDate(
          ECISKJConstants.APPLY_END_DATE_MAX, ECISConstants.FORMAT_DATE_yyyyMMdd));
      exampleMap.put("maxSearchResultCount", StringConvertUtil.stringToInteger(prop
          .getProperty("maxsearchcount.SKJ020101")));

      // 契約リスト検索メソッドを呼び出し、契約情報リストを取得する。
      List<KJ_ContractListResultEntityBean> contractListResultList = agentContractInfoSearchCommonMapper
          .contractListSearch(exampleMap);

      // 照会結果設定
      searchContractListBusiness.setContractListResultList(contractListResultList);
      // 正常終了：契約リスト検索BusinessBean》.リターンコードに（0000）を設定する
      searchContractListBusiness.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);

    } catch (DataAccessException e) {
      logger.error(messageSource.getMessage("error.E1129", null, Locale.getDefault()), e);
      // 契約リスト検索BusinessBean.リターンコードに（G017）を設定し処理を終了する。
      searchContractListBusiness.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      searchContractListBusiness.setMessage(errMsg);

    } catch (NoSuchMessageException e) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, e);
      // 契約リスト検索BusinessBean.リターンコードに（G017）を設定し処理を終了する。
      searchContractListBusiness.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      searchContractListBusiness.setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);

    } catch (SystemException e) {
      logger.error(messageSource.getMessage("error.E1129", null, Locale.getDefault()), e);
      // 契約リスト検索BusinessBean.リターンコードに（G017）を設定し処理を終了する。
      searchContractListBusiness.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      searchContractListBusiness.setMessage(e.getMessage());
    } catch (IOException e) {
      logger.error(messageSource.getMessage("error.E1129", null, Locale.getDefault()), e);
      // 契約リスト検索BusinessBean.リターンコードに（G017）を設定し処理を終了する。
      searchContractListBusiness.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      searchContractListBusiness.setMessage(fileMsg);
    }

    return searchContractListBusiness;
  }

  /**
   * プロパティからリターンコードに対応するメッセージを取得する
   *
   * @param prop
   *          プロパティ
   * @param returnCode
   *          リターンコード
   * @return
   */
  private String getPropertiesMesseage(String returnCode)
      throws NoSuchMessageException {
    return messageSource.getMessage(KJ_CommonUtil.getMessageId(returnCode),
        new String[] {}, Locale.getDefault());
  }

  /**
   * メッセージリソースのsetter(DI)
   *
   * @param messageSource
   *          メッセージリソース
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }

  // [kg-epj]<d-start>
  //	/**
  //	 * 契約情報検索共通マッパーのsetter(DI)
  //	 *
  //	 * @param AgentContractInfoSearchCommonMapper
  //	 *            契約情報検索共通マッパー
  //	 */
  //	public void setAgentContractInfoSearchCommonMapper(
  //			AgentContractInfoSearchCommonMapper AgentContractInfoSearchCommonMapper) {
  //		this.agentContractInfoSearchCommonMapper = AgentContractInfoSearchCommonMapper;
  //	}
  // [kg-epj]<d-end>
  // [kg-epj]<i-start>
  /**
   * 卸取次店向け契約情報検索共通Mapper_カスタムのsetter(DI)
   *
   * @param AgentContractInfoSearchCommonMapper
   *          卸取次店向け契約情報検索共通Mapper_カスタム
   */
  public void setAgentContractInfoSearchCommonMapper(
      Custom_AgentContractInfoSearchCommonMapper AgentContractInfoSearchCommonMapper) {
    this.agentContractInfoSearchCommonMapper = AgentContractInfoSearchCommonMapper;
  }
  // [kg-epj]<i-end>

  /**
   * 日付関連共通ビジネスのsetter(DI)
   *
   * @param dateBusiness
   *          日付関連共通ビジネス
   */
  public void setDateBusiness(DateBusiness dateBusiness) {
    this.dateBusiness = dateBusiness;
  }

  /**
   * プロパティファクトリーを設定する。(DI)
   *
   * @param applicationProperties
   *          プロパティファクトリー
   */
  public void setApplicationProperties(
      PropertiesFactoryBean applicationProperties) {
    this.applicationProperties = applicationProperties;
  }
}