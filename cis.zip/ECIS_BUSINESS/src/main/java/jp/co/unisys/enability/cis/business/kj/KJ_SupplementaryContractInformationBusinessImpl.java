package jp.co.unisys.enability.cis.business.kj;

import java.io.File;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.util.CollectionUtils;

import jp.co.unisys.enability.cis.business.common.DateBusiness;
import jp.co.unisys.enability.cis.business.gk.ContractManagementInformationFileHeaderValidator;
import jp.co.unisys.enability.cis.business.gk.SupplementaryContractInformationFileDeleteValidator;
import jp.co.unisys.enability.cis.business.gk.SupplementaryContractInformationFileRegistValidator;
import jp.co.unisys.enability.cis.business.gk.SupplementaryContractInformationFileUpdateValidator;
import jp.co.unisys.enability.cis.business.kj.model.AddSupplementaryContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.ContractManagementInformationFileConfigCommon;
import jp.co.unisys.enability.cis.business.kj.model.ContractManagementInformationFileConfigSupplementaryContract;
import jp.co.unisys.enability.cis.business.kj.model.CsvFileCheckSupplementaryContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.DeleteSupplementaryContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.DownloadSupplementaryContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.InquiryContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.InquiryContractorBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.InquirySupplementaryContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.UpdateSupplementaryContractBusinessBean;
import jp.co.unisys.enability.cis.common.Exception.BusinessLogicException;
import jp.co.unisys.enability.cis.common.Exception.SystemException;
import jp.co.unisys.enability.cis.common.util.CommonValidationUtil;
import jp.co.unisys.enability.cis.common.util.KJ_CommonUtil;
import jp.co.unisys.enability.cis.common.util.StringConvertUtil;
import jp.co.unisys.enability.cis.common.util.ThreadContext;
import jp.co.unisys.enability.cis.common.util.constants.ECISCodeConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISKJConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISReturnCodeConstants;
import jp.co.unisys.enability.cis.entity.common.RmExample;
import jp.co.unisys.enability.cis.entity.common.SplContract;
import jp.co.unisys.enability.cis.entity.common.SplContractExample;
import jp.co.unisys.enability.cis.entity.common.Spm;
import jp.co.unisys.enability.cis.entity.common.SpmMByPmCompany;
import jp.co.unisys.enability.cis.entity.common.SpmMByPmCompanyKey;
import jp.co.unisys.enability.cis.entity.kj.KJ_InquiryContractInformationEntityBean;
import jp.co.unisys.enability.cis.entity.kj.KJ_InquiryContractorInformationEntityBean;
import jp.co.unisys.enability.cis.entity.kj.KJ_SupplementaryContractInformationEntityBean;
import jp.co.unisys.enability.cis.entity.kj.KJ_SupplementaryContractInformationFileEntityBean;
import jp.co.unisys.enability.cis.mapper.common.RmMapper;
import jp.co.unisys.enability.cis.mapper.common.SplContractMapper;
import jp.co.unisys.enability.cis.mapper.common.SpmMByPmCompanyMapper;
import jp.co.unisys.enability.cis.mapper.common.SpmMapper;
import jp.co.unisys.enability.cis.mapper.kj.SupplementaryContractInformationCommonMapper;
import jp.co.unisys.enability.cis.mapper.rk.FixChargeResultInformationCommonMapper;
import jp.sf.orangesignal.csv.Csv;
import jp.sf.orangesignal.csv.handlers.ColumnPositionMapListHandler;

/**
 * 付帯契約情報ビジネス
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.kj.KJ_SupplementaryContractInformationBusiness
 *
 */
public class KJ_SupplementaryContractInformationBusinessImpl implements
    KJ_SupplementaryContractInformationBusiness {

  /**
   * 契約情報ビジネス(DI)
   */
  private KJ_ContractInformationBusiness kjContractInformationBusiness;

  /**
   * 契約者情報ビジネス(DI)
   */
  private KJ_ContractorInformationBusiness kjContractorInformationBusiness;

  /**
   * 確定料金実績情報共通マッパー(DI)
   */
  private FixChargeResultInformationCommonMapper fixChargeResultInformationCommonMapper;

  /**
   * 付帯契約情報共通マッパー(DI)
   */
  private SupplementaryContractInformationCommonMapper supplementaryContractInformationCommonMapper;

  /**
   * 付帯契約マッパー(DI)
   */
  private SplContractMapper splContractMapper;

  /**
   * 付帯メニューマッパー(DI)
   */
  private SpmMapper spmMapper;

  /**
   * 料金メニューマッパー(DI)
   */
  private RmMapper rmMapper;

  /**
   * 提供モデル企業別付帯メニューマスタマッパー(DI)
   */
  private SpmMByPmCompanyMapper spmMByPmCompanyMapper;

  /**
   * メッセージプロパティ(DI)
   */
  private MessageSource messageSource;

  /**
   * 日付関連共通ビジネス(DI)
   */
  private DateBusiness dateBusiness;

  /**
   * 契約管理情報ファイルヘッダーバリデーター(DI)
   */
  private ContractManagementInformationFileHeaderValidator contractManagementInformationFileHeaderValidator;

  /**
   * 付帯契約情報登録バリデーション(DI)
   */
  private SupplementaryContractInformationFileRegistValidator supplementaryContractInformationFileRegistValidator;

  /**
   * 付帯契約情報更新バリデーション(DI)
   */
  private SupplementaryContractInformationFileUpdateValidator supplementaryContractInformationFileUpdateValidator;

  /**
   * 付帯契約情報削除バリデーション(DI)
   */
  private SupplementaryContractInformationFileDeleteValidator supplementaryContractInformationFileDeleteValidator;

  /**
   * ログマネジャー
   */
  private static Logger logger = LogManager.getLogger();

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.kj.
   * KJ_SupplementaryContractInformationBusiness
   * #inquiry(jp.co.unisys.enability
   * .cis.business.kj.model.InquirySupplementaryContractBusinessBean)
   */
  @Override
  public InquirySupplementaryContractBusinessBean inquiry(
      InquirySupplementaryContractBusinessBean inquiryBean) {
    // 付帯契約情報照会条件Map
    Map<String, Object> conditionsMap = new HashMap<String, Object>();

    // DataAccessException用エラーメッセージ
    String dataAccessExceptionEMsg = null;
    try {

      dataAccessExceptionEMsg = messageSource.getMessage(KJ_CommonUtil
          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G017),
          new String[] {}, Locale.getDefault());
      // 照会パターンの設定
      // (《付帯契約情報照会BusinessBean》.契約IDがNULLではない、
      // または、《付帯契約情報照会BusinessBean》.契約番号がNULLまたは空文字のいずれかでない)、
      // かつ 《付帯契約情報照会BusinessBean》.照会対象日付がNULLではない、
      // かつ 《付帯契約情報照会BusinessBean》.付帯契約IDがNULLの場合
      if ((inquiryBean.getContractId() != null || StringUtils
          .isNotEmpty(inquiryBean.getContractNo()))
          && inquiryBean.getInqCoveredDate() != null
          && inquiryBean.getSupplementaryContractId() == null) {

        // 条件Map.ID
        conditionsMap.put("id", inquiryBean.getContractId());
        // 条件Map.番号
        conditionsMap.put("num", inquiryBean.getContractNo());
        // 条件Map.日付
        conditionsMap.put("date", inquiryBean.getInqCoveredDate());
        // 条件Map.照会パターン
        conditionsMap.put("selectPatten",
            ECISKJConstants.INQUIRY_PATTERN_1);

        // (《付帯契約情報照会BusinessBean》.契約IDがNULLではない、
        // または、《付帯契約情報照会BusinessBean》.契約番号がNULLまたは空文字のいずれかでない)、
        // かつ 《付帯契約情報照会BusinessBean》.照会対象日付がNULL、
        // かつ 《付帯契約情報照会BusinessBean》.付帯契約IDがNULLの場合
      } else if ((inquiryBean.getContractId() != null || StringUtils
          .isNotEmpty(inquiryBean.getContractNo()))
          && inquiryBean.getInqCoveredDate() == null
          && inquiryBean.getSupplementaryContractId() == null) {

        // 条件Map.ID
        conditionsMap.put("id", inquiryBean.getContractId());
        // 条件Map.番号
        conditionsMap.put("num", inquiryBean.getContractNo());
        // 条件Map.日付
        conditionsMap.put("date", null);
        // 条件Map.照会パターン
        conditionsMap.put("selectPatten",
            ECISKJConstants.INQUIRY_PATTERN_2);

        // (《付帯契約情報照会BusinessBean》.契約IDがNULL、
        // かつ 《付帯契約情報照会BusinessBean》.契約番号がNULLまたは空文字)、
        // かつ 《付帯契約情報照会BusinessBean》.照会対象日付がNULL、
        // かつ 《付帯契約情報照会BusinessBean》.付帯契約IDがNULLではない場合
      } else if ((inquiryBean.getContractId() == null && StringUtils
          .isEmpty(inquiryBean.getContractNo()))
          && inquiryBean.getInqCoveredDate() == null
          && inquiryBean.getSupplementaryContractId() != null) {

        // 条件Map.ID
        conditionsMap.put("id",
            inquiryBean.getSupplementaryContractId());
        // 条件Map.番号
        conditionsMap.put("num", null);
        // 条件Map.日付
        conditionsMap.put("date", null);
        // 条件Map.照会パターン
        conditionsMap.put("selectPatten",
            ECISKJConstants.INQUIRY_PATTERN_3);

        // パターン外の場合
      } else {

        inquiryBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P001);
        inquiryBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P001),
                new String[] {}, Locale.getDefault()));
        return inquiryBean;

      }
      // 《付帯契約情報共通DAO》.付帯契約情報取得を呼び出す。
      // 照会結果設定
      List<KJ_SupplementaryContractInformationEntityBean> supplementaryContractInformationEntityBeanList = supplementaryContractInformationCommonMapper
          .selectSupplementaryContract(conditionsMap);

      inquiryBean
          .setSupplementaryContractList(supplementaryContractInformationEntityBeanList);
      // 正常終了
      inquiryBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);

    } catch (DataAccessException e) {
      logger.error(messageSource.getMessage("error.E1129", null,
          Locale.getDefault()), e);
      // catch 業務例外クラス
      inquiryBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      inquiryBean.setMessage(dataAccessExceptionEMsg);

    } catch (NoSuchMessageException e) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, e);
      inquiryBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      inquiryBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
    }
    return inquiryBean;
  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.kj.
   * KJ_SupplementaryContractInformationBusiness
   * #update(jp.co.unisys.enability.
   * cis.business.kj.model.UpdateSupplementaryContractBusinessBean)
   */
  @Override
  public UpdateSupplementaryContractBusinessBean update(
      UpdateSupplementaryContractBusinessBean updateSupplementaryContractBusinessBean) {

    // BusinessLogicException用エラーメッセージ
    String businessLogicExceptionEMsg = null;

    // 付帯契約情報ビジネスBean
    InquirySupplementaryContractBusinessBean inquirySupplementaryContractBusinessBean;

    // 付帯契約情報EntityBean
    KJ_SupplementaryContractInformationEntityBean supplementaryContractInformationEntityBean;

    // 契約情報ビジネスBean
    InquiryContractBusinessBean inquiryContractBusinessBean;

    // 契約情報EntityBean
    KJ_InquiryContractInformationEntityBean inquiryContractInformationEntityBean;

    // 付帯契約Entity
    SplContract supplementaryContract;

    // 付帯契約EntitytExample
    SplContractExample supplementaryContractExample;

    try {
      businessLogicExceptionEMsg = messageSource.getMessage(KJ_CommonUtil
          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G017),
          new String[] {}, Locale.getDefault());
      // 付帯契約情報の存在チェック
      inquirySupplementaryContractBusinessBean = new InquirySupplementaryContractBusinessBean();
      // 《付帯契約情報照会BusinessBean》.付帯契約IDに《付帯契約情報更新BusinessBean》.付帯契約IDを設定する。
      inquirySupplementaryContractBusinessBean
          .setSupplementaryContractId(updateSupplementaryContractBusinessBean
              .getSupplementaryContractId());

      inquirySupplementaryContractBusinessBean = inquiry(inquirySupplementaryContractBusinessBean);

      // 《付帯契約情報照会BusinessBean》.リターンコードが“0000”以外の場合
      if (!ECISReturnCodeConstants.RETURN_CODE_0000
          .equals(inquirySupplementaryContractBusinessBean
              .getReturnCode())) {

        throw new BusinessLogicException(messageSource.getMessage(
            "error.E1284", new String[] {}, Locale.getDefault()), false);

      }
      // 《付帯契約情報照会EntityBean》リストの返却値が0件の場合
      if (CollectionUtils.isEmpty(inquirySupplementaryContractBusinessBean
          .getSupplementaryContractList())) {

        updateSupplementaryContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P010);
        updateSupplementaryContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P010),
                new String[] {}, Locale.getDefault()));
        return updateSupplementaryContractBusinessBean;

      }
      // 《付帯契約情報照会BusinessBean》より《付帯契約情報照会EntityBean》リストの1番目を取得する。
      supplementaryContractInformationEntityBean = inquirySupplementaryContractBusinessBean
          .getSupplementaryContractList().get(0);
      // 付帯契約終了日と付帯契約開始日の相関チェック
      // 《付帯契約情報更新BusinessBean》.付帯契約終了日が
      // 《付帯契約情報照会EntityBean》.付帯契約開始日以前の場合、
      if (DateUtils.truncatedCompareTo(
          updateSupplementaryContractBusinessBean
              .getSupplementaryContractEndDate(),
          supplementaryContractInformationEntityBean
              .getSupplementaryContractStartDate(),
          Calendar.DAY_OF_MONTH) <= 0) {

        updateSupplementaryContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G002);
        updateSupplementaryContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G002),
                new String[] {}, Locale.getDefault()));
        return updateSupplementaryContractBusinessBean;

      }
      // 親契約情報の存在チェック
      inquiryContractBusinessBean = new InquiryContractBusinessBean();
      // 《契約情報照会BusinessBean》.契約IDに《付帯契約情報照会EntityBean》.契約IDを設定する。
      inquiryContractBusinessBean
          .setContractId(supplementaryContractInformationEntityBean
              .getContractId());
      // 《契約情報照会BusinessBean》.照会対象日付に《付帯契約情報照会EntityBean》.付帯契約開始日を設定する。
      inquiryContractBusinessBean
          .setInqCoveredDate(supplementaryContractInformationEntityBean
              .getSupplementaryContractStartDate());
      inquiryContractBusinessBean = kjContractInformationBusiness
          .inquiry(inquiryContractBusinessBean);
      // 《契約情報照会BusinessBean》.リターンコードが“0000”以外の場合
      if (!ECISReturnCodeConstants.RETURN_CODE_0000
          .equals(inquiryContractBusinessBean.getReturnCode())) {

        throw new BusinessLogicException(messageSource.getMessage(
            "error.E1285", new String[] {}, Locale.getDefault()), false);

      }
      // 《契約情報照会EntityBean》リストの返却値が0件の場合
      if (CollectionUtils.isEmpty(inquiryContractBusinessBean.getContractInformationList())) {

        updateSupplementaryContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D002);
        updateSupplementaryContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D002),
                new String[] {}, Locale.getDefault()));
        return updateSupplementaryContractBusinessBean;

      }

      // 《契約情報照会BusinessBean》より《契約情報照会EntityBean》リストの1番目を取得する。
      inquiryContractInformationEntityBean = inquiryContractBusinessBean
          .getContractInformationList().get(0);

      // 契約終了状態判定のため、算定期間チェックを行う。
      Map<String, Object> exampleMap = new HashMap<String, Object>();
      exampleMap.put("contractId", inquiryContractInformationEntityBean.getContractId());
      exampleMap.put("coveredDate", inquiryContractInformationEntityBean.getContractEndDate());
      exampleMap.put("flg", ECISKJConstants.INQUIRY_FIX_CHANGE_RESULT_INFOEMATION_FLG_TWO);
      int resultCount = fixChargeResultInformationCommonMapper.countByFixChargeResult(exampleMap);
      // 結果が1件以上の場合リターンコードに（D025）を設定し返却する
      if (resultCount >= 1) {
        updateSupplementaryContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D025);
        updateSupplementaryContractBusinessBean.setMessage(messageSource.getMessage(
            KJ_CommonUtil.getMessageId(ECISReturnCodeConstants.RETURN_CODE_D025),
            new String[] {}, Locale.getDefault()));
        return updateSupplementaryContractBusinessBean;
      }

      // 付帯契約終了状態チェック
      exampleMap = new HashMap<String, Object>();
      exampleMap.put("contractId", supplementaryContractInformationEntityBean.getContractId());
      exampleMap.put("coveredDate",
          supplementaryContractInformationEntityBean.getSupplementaryContractEndDate());
      exampleMap.put("flg", ECISKJConstants.INQUIRY_FIX_CHANGE_RESULT_INFOEMATION_FLG_OFF);
      int splresultCount = fixChargeResultInformationCommonMapper.countByFixChargeResult(exampleMap);
      // 結果が1件以上の場合リターンコードに（D026）を設定し返却する
      if (splresultCount >= 1) {
        updateSupplementaryContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D026);
        updateSupplementaryContractBusinessBean.setMessage(messageSource.getMessage(
            KJ_CommonUtil.getMessageId(ECISReturnCodeConstants.RETURN_CODE_D026),
            new String[] {}, Locale.getDefault()));
        return updateSupplementaryContractBusinessBean;
      }

      // 付帯契約終了日と契約終了日の相関チェック
      // 《付帯契約情報更新BusinessBean》.付帯契約終了日が《契約情報照会EntityBean》.契約終了日より後の場合
      if (DateUtils.truncatedCompareTo(
          updateSupplementaryContractBusinessBean
              .getSupplementaryContractEndDate(),
          inquiryContractInformationEntityBean.getContractEndDate(),
          Calendar.DAY_OF_MONTH) > 0) {

        updateSupplementaryContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G003);
        updateSupplementaryContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G003),
                new String[] {}, Locale.getDefault()));
        return updateSupplementaryContractBusinessBean;

      }
      // 更新可否チェック
      // 確定料金情報照会条件Map
      Map<String, Object> conditionsMap = new HashMap<String, Object>();

      // 条件Map.契約ID
      conditionsMap.put("contractId",
          inquiryContractInformationEntityBean.getContractId());
      // 条件Map.対象日
      conditionsMap.put("coveredDate",
          updateSupplementaryContractBusinessBean.getSupplementaryContractEndDate());
      // 条件Map.フラグ
      conditionsMap.put("flg",
          ECISKJConstants.INQUIRY_FIX_CHANGE_RESULT_INFOEMATION_FLG_THREE);

      // 《確定料金実績情報共通Dao》.確定料金実績件数取得の返却値が1件以上の場合
      if (fixChargeResultInformationCommonMapper
          .countByFixChargeResult(conditionsMap) >= 1) {

        updateSupplementaryContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D007);
        updateSupplementaryContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D007),
                new String[] {}, Locale.getDefault()));
        return updateSupplementaryContractBusinessBean;

      }
      // DB更新
      Timestamp systemDate = new Timestamp(System.currentTimeMillis());
      supplementaryContract = new SplContract();
      supplementaryContractExample = new SplContractExample();
      // 付帯契約終了日
      supplementaryContract
          .setSplContractEd(updateSupplementaryContractBusinessBean
              .getSupplementaryContractEndDate());
      // 更新回数
      supplementaryContract
          .setUpdateCount(updateSupplementaryContractBusinessBean
              .getUpdateCount() + 1);
      // オンライン更新日時
      supplementaryContract.setOnlineUpdateTime(systemDate);
      // オンライン更新ユーザID
      supplementaryContract.setOnlineUpdateUserId(ThreadContext
          .getRequestThreadContext().get(ECISConstants.USER_ID_KEY)
          .toString());
      // 更新日時
      supplementaryContract.setUpdateTime(systemDate);
      // 更新モジュールコード
      supplementaryContract.setUpdateModuleCode(ThreadContext
          .getRequestThreadContext()
          .get(ECISConstants.CLASS_NAME_KEY).toString());
      // 付帯契約ID(更新条件)
      // 更新回数(更新条件)
      supplementaryContractExample
          .createCriteria()
          .andSplContractIdEqualTo(
              updateSupplementaryContractBusinessBean
                  .getSupplementaryContractId())
          .andUpdateCountEqualTo(
              updateSupplementaryContractBusinessBean
                  .getUpdateCount());
      // 《付帯契約情報共通Mapper》.選択項目更新（主キー・更新回数）の返却値が0件の場合
      if (splContractMapper.updateByExampleSelective(
          supplementaryContract, supplementaryContractExample) == 0) {

        updateSupplementaryContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_H001);
        updateSupplementaryContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_H001),
                new String[] {}, Locale.getDefault()));
        return updateSupplementaryContractBusinessBean;

      }
      // 正常終了
      updateSupplementaryContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);

    } catch (BusinessLogicException e) {
      logger.error(messageSource.getMessage("error.E1129", null,
          Locale.getDefault()), e);
      // catch 業務例外クラス
      updateSupplementaryContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      updateSupplementaryContractBusinessBean
          .setMessage(businessLogicExceptionEMsg);

    } catch (NoSuchMessageException e) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, e);
      updateSupplementaryContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      updateSupplementaryContractBusinessBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
    }
    return updateSupplementaryContractBusinessBean;
  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.kj.
   * KJ_SupplementaryContractInformationBusiness
   * #delete(jp.co.unisys.enability.
   * cis.business.kj.model.DeleteSupplementaryContractBusinessBean)
   */
  @Override
  public DeleteSupplementaryContractBusinessBean delete(
      DeleteSupplementaryContractBusinessBean deleteSupplementaryContractBusinessBean) {

    // BusinessLogicException用エラーメッセージ
    String businessLogicExceptionEMsg = null;

    // 付帯契約情報ビジネスBean
    InquirySupplementaryContractBusinessBean inquirySupplementaryContractBusinessBean;

    // 付帯契約情報EntityBean
    KJ_SupplementaryContractInformationEntityBean supplementaryContractInformationEntityBean;

    // 契約情報ビジネスBean
    InquiryContractBusinessBean inquiryContractBusinessBean;

    // 契約情報EntityBean
    KJ_InquiryContractInformationEntityBean inquiryContractInformationEntityBean;

    // 付帯契約EntitytExample
    SplContractExample supplementaryContractExample;

    try {
      businessLogicExceptionEMsg = messageSource.getMessage(KJ_CommonUtil
          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G017),
          new String[] {}, Locale.getDefault());

      // 付帯契約情報の存在チェック
      inquirySupplementaryContractBusinessBean = new InquirySupplementaryContractBusinessBean();
      // 《付帯契約情報照会BusinessBean》.付帯契約IDに《付帯契約情報削除BusinessBean》.付帯契約IDを設定する。
      inquirySupplementaryContractBusinessBean
          .setSupplementaryContractId(deleteSupplementaryContractBusinessBean
              .getSupplementaryContractId());
      inquirySupplementaryContractBusinessBean = inquiry(inquirySupplementaryContractBusinessBean);
      // 《付帯契約情報照会BusinessBean》.リターンコードが“0000”以外の場合
      if (!ECISReturnCodeConstants.RETURN_CODE_0000
          .equals(inquirySupplementaryContractBusinessBean
              .getReturnCode())) {

        throw new BusinessLogicException(messageSource.getMessage(
            "error.E1284", new String[] {}, Locale.getDefault()), false);

      }
      // 《付帯契約情報照会EntityBean》リストの返却値が0件の場合
      if (CollectionUtils.isEmpty(inquirySupplementaryContractBusinessBean
          .getSupplementaryContractList())) {

        deleteSupplementaryContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P010);
        deleteSupplementaryContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P010),
                new String[] {}, Locale.getDefault()));
        return deleteSupplementaryContractBusinessBean;

      }
      // 《付帯契約情報照会BusinessBean》より《付帯契約情報照会EntityBean》リストの1番目を取得する。
      supplementaryContractInformationEntityBean = inquirySupplementaryContractBusinessBean
          .getSupplementaryContractList().get(0);
      // 親契約情報の存在チェック
      inquiryContractBusinessBean = new InquiryContractBusinessBean();
      // 《契約情報照会BusinessBean》.契約IDに《付帯契約情報照会EntityBean》.契約IDを設定する。
      inquiryContractBusinessBean
          .setContractId(supplementaryContractInformationEntityBean
              .getContractId());
      // 《契約情報照会BusinessBean》.照会対象日付に《付帯契約情報照会EntityBean》.付帯契約開始日を設定する。
      inquiryContractBusinessBean
          .setInqCoveredDate(supplementaryContractInformationEntityBean
              .getSupplementaryContractStartDate());
      inquiryContractBusinessBean = kjContractInformationBusiness
          .inquiry(inquiryContractBusinessBean);
      // 《契約情報照会BusinessBean》.リターンコードが“0000”以外の場合
      if (!ECISReturnCodeConstants.RETURN_CODE_0000
          .equals(inquiryContractBusinessBean.getReturnCode())) {

        throw new BusinessLogicException(messageSource.getMessage(
            "error.E1285", new String[] {}, Locale.getDefault()), false);

      }
      // 《契約情報照会EntityBean》リストの返却値が0件の場合
      if (CollectionUtils.isEmpty(inquiryContractBusinessBean.getContractInformationList())) {

        deleteSupplementaryContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D002);
        deleteSupplementaryContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D002),
                new String[] {}, Locale.getDefault()));
        return deleteSupplementaryContractBusinessBean;

      }

      // 《契約情報照会BusinessBean》より《契約情報照会EntityBean》リストの1番目を取得する。
      inquiryContractInformationEntityBean = inquiryContractBusinessBean
          .getContractInformationList().get(0);

      // 契約終了状態判定のため、算定期間チェックを行う。
      Map<String, Object> exampleMap = new HashMap<String, Object>();
      exampleMap.put("contractId", inquiryContractInformationEntityBean.getContractId());
      exampleMap.put("coveredDate", inquiryContractInformationEntityBean.getContractEndDate());
      exampleMap.put("flg", ECISKJConstants.INQUIRY_FIX_CHANGE_RESULT_INFOEMATION_FLG_TWO);
      int resultCount = fixChargeResultInformationCommonMapper.countByFixChargeResult(exampleMap);
      // 結果が1件以上の場合リターンコードに（D025）を設定し返却する
      if (resultCount >= 1) {
        deleteSupplementaryContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D025);
        deleteSupplementaryContractBusinessBean.setMessage(messageSource.getMessage(
            KJ_CommonUtil.getMessageId(ECISReturnCodeConstants.RETURN_CODE_D025),
            new String[] {}, Locale.getDefault()));
        return deleteSupplementaryContractBusinessBean;
      }

      // 削除可否チェック
      // 《確定料金実績情報共通Dao》.確定料金実績件数取得の返却値が1件以上の場合
      if (getFixChargeResultInformationCount(
          inquiryContractInformationEntityBean.getContractId(),
          supplementaryContractInformationEntityBean
              .getSupplementaryContractStartDate()) >= 1) {

        deleteSupplementaryContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D008);
        deleteSupplementaryContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D008),
                new String[] {}, Locale.getDefault()));
        return deleteSupplementaryContractBusinessBean;

      }
      // 付帯契約削除
      supplementaryContractExample = new SplContractExample();
      // 付帯契約ID(削除条件)
      // 更新回数(削除条件)
      supplementaryContractExample
          .createCriteria()
          .andSplContractIdEqualTo(
              deleteSupplementaryContractBusinessBean
                  .getSupplementaryContractId())
          .andUpdateCountEqualTo(
              deleteSupplementaryContractBusinessBean
                  .getUpdateCount());
      // 《付帯契約情報共通Dao》.削除の返却値が0件の場合
      if (splContractMapper
          .deleteByExample(supplementaryContractExample) == 0) {

        deleteSupplementaryContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_H001);
        deleteSupplementaryContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_H001),
                new String[] {}, Locale.getDefault()));
        return deleteSupplementaryContractBusinessBean;

      }
      // 正常終了
      deleteSupplementaryContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);

    } catch (BusinessLogicException e) {
      logger.error(messageSource.getMessage("error.E1129", null,
          Locale.getDefault()), e);
      // catch 業務例外クラス
      deleteSupplementaryContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      deleteSupplementaryContractBusinessBean
          .setMessage(businessLogicExceptionEMsg);

    } catch (NoSuchMessageException e) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, e);
      deleteSupplementaryContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      deleteSupplementaryContractBusinessBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
    }
    return deleteSupplementaryContractBusinessBean;
  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.kj.
   * KJ_SupplementaryContractInformationBusiness
   * #add(jp.co.unisys.enability.cis
   * .business.kj.model.AddSupplementaryContractBusinessBean)
   */
  @Override
  public AddSupplementaryContractBusinessBean add(
      AddSupplementaryContractBusinessBean addSupplementaryContractBusinessBean) {

    // 付帯契約終了日
    Date supplementaryContractEndDate = null;

    // BusinessLogicException用エラーメッセージ
    String businessLogicExceptionEMsg = null;

    // DuplicateKeyException用エラーメッセージ
    String duplicateKeyExceptionEmsg = null;

    // 契約情報ビジネスBean
    InquiryContractBusinessBean inquiryContractBusinessBean;

    // 契約者情報ビジネスBean
    InquiryContractorBusinessBean inquiryContractorBusinessBean;

    // 契約情報EntityBean
    KJ_InquiryContractInformationEntityBean inquiryContractInformationEntityBean;

    // 契約者情報照会EntityBean
    KJ_InquiryContractorInformationEntityBean inquiryContractorInformationEntityBean;

    // 付帯メニューEntity
    Spm supplementaryMenu;

    // 料金メニューEntityExample
    RmExample rateMenuExample;

    // 付帯契約Entity
    SplContract supplementaryContract;

    try {
      businessLogicExceptionEMsg = messageSource.getMessage(KJ_CommonUtil
          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G017),
          new String[] {}, Locale.getDefault());
      duplicateKeyExceptionEmsg = messageSource.getMessage(KJ_CommonUtil
          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D023),
          new String[] {}, Locale.getDefault());
      // 親契約情報存在チェック
      inquiryContractBusinessBean = new InquiryContractBusinessBean();
      // 《契約情報照会BusinessBean》.照会対象日付に《付帯契約情報追加BusinessBean》.付帯契約開始日を設定する。
      inquiryContractBusinessBean
          .setInqCoveredDate(addSupplementaryContractBusinessBean
              .getSupplementaryContractStartDate());
      // 《契約情報照会BusinessBean》.契約IDに《付帯契約情報追加BusinessBean》.契約IDを設定する。
      inquiryContractBusinessBean
          .setContractId(addSupplementaryContractBusinessBean
              .getContractId());
      // 《契約情報照会BusinessBean》.契約番号に《付帯契約情報追加BusinessBean》.契約番号を設定する。
      inquiryContractBusinessBean
          .setContractNo(addSupplementaryContractBusinessBean
              .getContractNo());
      inquiryContractBusinessBean = kjContractInformationBusiness
          .inquiry(inquiryContractBusinessBean);
      // 《契約情報照会BusinessBean》.リターンコードが“0000”以外の場合
      if (!ECISReturnCodeConstants.RETURN_CODE_0000
          .equals(inquiryContractBusinessBean.getReturnCode())) {

        throw new BusinessLogicException(messageSource.getMessage(
            "error.E1285", new String[] {}, Locale.getDefault()), false);

      }
      // 《契約情報照会EntityBean》リストの返却値が0件の場合
      if (CollectionUtils.isEmpty(inquiryContractBusinessBean.getContractInformationList())) {

        addSupplementaryContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D016);
        addSupplementaryContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D016),
                new String[] {}, Locale.getDefault()));
        return addSupplementaryContractBusinessBean;

      }

      // 《契約情報照会BusinessBean》より《契約情報照会EntityBean》リストの1番目を取得する。
      inquiryContractInformationEntityBean = inquiryContractBusinessBean
          .getContractInformationList().get(0);

      // 契約終了状態判定のため、算定期間チェックを行う。
      Map<String, Object> exampleMap = new HashMap<String, Object>();
      exampleMap.put("contractId", inquiryContractInformationEntityBean.getContractId());
      exampleMap.put("coveredDate", inquiryContractInformationEntityBean.getContractEndDate());
      exampleMap.put("flg", ECISKJConstants.INQUIRY_FIX_CHANGE_RESULT_INFOEMATION_FLG_TWO);
      int resultCount = fixChargeResultInformationCommonMapper.countByFixChargeResult(exampleMap);
      // 結果が1件以上の場合リターンコードに（D025）を設定し返却する
      if (resultCount >= 1) {
        addSupplementaryContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D025);
        addSupplementaryContractBusinessBean.setMessage(messageSource.getMessage(
            KJ_CommonUtil.getMessageId(ECISReturnCodeConstants.RETURN_CODE_D025),
            new String[] {}, Locale.getDefault()));
        return addSupplementaryContractBusinessBean;
      }

      // 契約者情報取得
      // 《契約者情報照会BusinessBean》を生成し、照会条件を設定する。
      inquiryContractorBusinessBean = new InquiryContractorBusinessBean();
      // 《契約情報照会EntityBean》.契約者IDを設定する。
      inquiryContractorBusinessBean.setContractorId(inquiryContractInformationEntityBean.getContractorId());
      // 契約者情報ビジネス.照会を呼出し
      inquiryContractorBusinessBean = kjContractorInformationBusiness.inquiry(inquiryContractorBusinessBean);

      // 契約者情報取得結果判定
      // 《契約者情報照会BusinessBean》.リターンコードが“0000”以外の場合、業務例外をスローする。
      if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(inquiryContractorBusinessBean.getReturnCode())) {

        throw new BusinessLogicException(messageSource.getMessage("error.E1281", new String[] {},
            Locale.getDefault()), false);
      }
      // 《契約者情報照会BusinessBean》.リターンコードが“0000”
      // かつ 返却値が0件の場合、コード(D014)を返却する。
      if (CollectionUtils.isEmpty(inquiryContractorBusinessBean.getContractorInformationList())) {
        // コード(D014)を設定する。
        addSupplementaryContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D014);
        addSupplementaryContractBusinessBean.setMessage(
            messageSource.getMessage(
                KJ_CommonUtil.getMessageId(ECISReturnCodeConstants.RETURN_CODE_D014),
                new String[] {}, Locale.getDefault()));
        return addSupplementaryContractBusinessBean;
      }

      // 《契約者情報照会BusinessBean》より《契約者情報照会EntityBean》リストの1番目を取得する。
      inquiryContractorInformationEntityBean = inquiryContractorBusinessBean.getContractorInformationList()
          .get(0);

      // 日付相関チェック
      // 《付帯契約情報追加BusinessBean》.付帯契約開始日が《契約情報照会EntityBean》.契約開始日より前の場合
      if (DateUtils
          .truncatedCompareTo(addSupplementaryContractBusinessBean
              .getSupplementaryContractStartDate(),
              inquiryContractInformationEntityBean
                  .getContractStartDate(),
              Calendar.DAY_OF_MONTH) < 0) {

        addSupplementaryContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G004);
        addSupplementaryContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G004),
                new String[] {}, Locale.getDefault()));
        return addSupplementaryContractBusinessBean;

      }
      // 《付帯契約情報追加BusinessBean》.付帯契約終了日がNULLではない かつ
      // 《付帯契約情報追加BusinessBean》.付帯契約終了日が《契約情報照会EntityBean》.契約終了日より後の場合
      if (addSupplementaryContractBusinessBean
          .getSupplementaryContractEndDate() != null
          && DateUtils.truncatedCompareTo(
              addSupplementaryContractBusinessBean
                  .getSupplementaryContractEndDate(),
              inquiryContractInformationEntityBean
                  .getContractEndDate(),
              Calendar.DAY_OF_MONTH) > 0) {

        addSupplementaryContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G003);
        addSupplementaryContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G003),
                new String[] {}, Locale.getDefault()));
        return addSupplementaryContractBusinessBean;

      }
      // 《付帯契約情報追加BusinessBean》.付帯契約終了日がNULLの場合
      if (addSupplementaryContractBusinessBean
          .getSupplementaryContractEndDate() == null) {

        supplementaryContractEndDate = inquiryContractInformationEntityBean
            .getContractEndDate();

        // 《付帯契約情報追加BusinessBean》.付帯契約終了日がNULLでない場合
      } else {

        supplementaryContractEndDate = addSupplementaryContractBusinessBean
            .getSupplementaryContractEndDate();

      }
      // 付帯メニュー存在チェック
      // 《付帯契約情報追加BusinessBean》.付帯メニューIDを取得する
      String supplementaryMenuId = addSupplementaryContractBusinessBean.getSupplementaryMenuId();
      // 《付帯契約情報追加BusinessBean》.付帯メニューIDがNULLまたは空白でない場合
      if (StringUtils.isNotEmpty(supplementaryMenuId)) {
        // 提供モデルと提供モデル企業の判定
        SpmMByPmCompanyKey keyExample = new SpmMByPmCompanyKey();
        // 《付帯契約情報追加BusinessBean》.付帯メニューIDを設定する
        keyExample.setSpmId(supplementaryMenuId);
        // 《契約者情報照会EntityBean》.提供モデルコードを設定する
        keyExample.setPmCode(inquiryContractorInformationEntityBean.getProvideModelCode());
        // 《契約者情報照会EntityBean》.提供モデル企業コードを設定する
        keyExample.setPmCompanyCode(inquiryContractorInformationEntityBean.getProvideModelCompanyCode());
        // 提供モデル企業別付帯メニューマスタ情報を検索する。
        SpmMByPmCompany spmMByPmCompany = spmMByPmCompanyMapper.selectByPrimaryKey(keyExample);
        // 取得結果判定、返却結果がNULLの場合、リターンコード（G040）を返却する。
        if (spmMByPmCompany == null) {
          addSupplementaryContractBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G040);
          addSupplementaryContractBusinessBean.setMessage(
              messageSource.getMessage(KJ_CommonUtil.getMessageId(
                  ECISReturnCodeConstants.RETURN_CODE_G040), new String[] {}, Locale.getDefault()));
          return addSupplementaryContractBusinessBean;
        }

        // 付帯メニューを取得
        supplementaryMenu = spmMapper.selectByPrimaryKey(supplementaryMenuId);

        // 《付帯メニューDao》.検索（主キー）の返却値が0件の場合
        if (supplementaryMenu == null) {

          addSupplementaryContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P011);
          addSupplementaryContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P011),
                  new String[] {}, Locale.getDefault()));
          return addSupplementaryContractBusinessBean;
        }

        // 適用期間チェック
        // 引数.付帯契約開始日が《付帯メニュー》.付帯メニュー適用終了日より後の場合、
        // リターンコード（G041）を返却する。
        if (addSupplementaryContractBusinessBean.getSupplementaryContractStartDate().after(
            supplementaryMenu.getSpmApplyEd())) {
          addSupplementaryContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G041);
          addSupplementaryContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G041),
                  new String[] {}, Locale.getDefault()));
          return addSupplementaryContractBusinessBean;
        }
        // 引数.付帯契約終了日がNULLではない
        // かつ 引数.付帯契約終了日が《付帯メニュー》.付帯メニュー適用開始日より前の場合、
        // リターンコード（G041）を返却する。
        if (supplementaryContractEndDate.before(supplementaryMenu.getSpmApplySd())) {
          addSupplementaryContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G041);
          addSupplementaryContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G041),
                  new String[] {}, Locale.getDefault()));
          return addSupplementaryContractBusinessBean;
        }

        // 《付帯メニューEntity》.個別設定フラグが“0：個別設定なし”
        // かつ 《付帯契約情報追加BusinessBean》.額・率がNULLではない場合
        if ((ECISKJConstants.INDIVIDUAL_SETTING_FLAG_OFF)
            .equals(supplementaryMenu.getIndividualSettingFlag())
            && addSupplementaryContractBusinessBean
                .getAmountOrRate() != null) {

          addSupplementaryContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G018);
          addSupplementaryContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G018),
                  new String[] {}, Locale.getDefault()));
          return addSupplementaryContractBusinessBean;

        }
        // 《付帯メニューEntity》.個別設定フラグが“1：個別設定あり”
        // かつ 《付帯契約情報追加BusinessBean》.額・率がNULLの場合
        if ((ECISKJConstants.INDIVIDUAL_SETTING_FLAG_ON)
            .equals(supplementaryMenu.getIndividualSettingFlag())
            && addSupplementaryContractBusinessBean
                .getAmountOrRate() == null) {

          addSupplementaryContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G019);
          addSupplementaryContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G019),
                  new String[] {}, Locale.getDefault()));
          return addSupplementaryContractBusinessBean;

        }

        // 付帯メニューの付帯種別コードが定額の場合、以下のチェックを行う
        if (ECISCodeConstants.SUPPLEMENTARY_CLASS_CODE_FIXED_AMOUNT
            .equals(supplementaryMenu.getSplClassCode())) {
          // String型に変換
          String amoutOrRate = StringConvertUtil.convertBigDecimalToString(
              addSupplementaryContractBusinessBean
                  .getAmountOrRate(),
              null);
          // 額・率のフォーマットが9999.99でない場合、エラーリストにメッセージを格納
          boolean result = CommonValidationUtil
              .checkBigDecimalStringDigit(
                  amoutOrRate,
                  ContractManagementInformationFileConfigSupplementaryContract.DATA_AMOUNT_OR_RATE_AMOUNT_DIGIT_INTEGER,
                  ContractManagementInformationFileConfigSupplementaryContract.DATA_AMOUNT_OR_RATE_AMOUNT_DIGIT_FLOAT);
          if (!result) {
            addSupplementaryContractBusinessBean
                .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G034);
            addSupplementaryContractBusinessBean
                .setMessage(messageSource.getMessage(
                    KJ_CommonUtil
                        .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G034),
                    new String[] {}, Locale.getDefault()));
            return addSupplementaryContractBusinessBean;
          }

          // 付帯メニューの付帯種別コードが定率の場合、以下のチェックを行う
        } else if (ECISCodeConstants.SUPPLEMENTARY_CLASS_CODE_FIXED_RATE
            .equals(supplementaryMenu.getSplClassCode())) {
          // 額・率が1より大きい場合、エラーリストのメッセージを格納

          if (addSupplementaryContractBusinessBean.getAmountOrRate() != null) {
            if (ContractManagementInformationFileConfigSupplementaryContract.DATA_AMOUNT_OR_RATE_RATE_MIN_VALUE
                .compareTo(addSupplementaryContractBusinessBean.getAmountOrRate()) == -1) {
              addSupplementaryContractBusinessBean
                  .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G035);
              addSupplementaryContractBusinessBean
                  .setMessage(messageSource.getMessage(
                      KJ_CommonUtil
                          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G035),
                      new String[] {}, Locale.getDefault()));
              return addSupplementaryContractBusinessBean;
            }
          }
        }

        rateMenuExample = new RmExample();
        // 《契約情報照会EntityBean》.契約履歴情報リストの一件目.料金メニューID
        // 《付帯メニューEntity》.売買区分コード
        rateMenuExample
            .createCriteria()
            .andRmIdEqualTo(
                inquiryContractInformationEntityBean
                    .getContractHistoryInformationList()
                    .get(0).getRateMenuId())
            .andSaleCatCodeEqualTo(
                supplementaryMenu.getSaleCatCode());
        // 売買区分チェック
        // 《料金メニューDao》.検索（項目指定）の返却値が0件の場合
        if (rmMapper.selectByExample(rateMenuExample).isEmpty()) {

          addSupplementaryContractBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G010);
          addSupplementaryContractBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G010),
                  new String[] {}, Locale.getDefault()));
          return addSupplementaryContractBusinessBean;

        }
      }

      // 追加可否チェック
      // 《確定料金実績情報共通Dao》.確定料金実績件数取得の返却値が1件以上の場合
      if (getFixChargeResultInformationCount(
          inquiryContractInformationEntityBean.getContractId(),
          addSupplementaryContractBusinessBean
              .getSupplementaryContractStartDate()) >= 1) {

        addSupplementaryContractBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D017);
        addSupplementaryContractBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D017),
                new String[] {}, Locale.getDefault()));
        return addSupplementaryContractBusinessBean;

      }
      // DB登録
      Timestamp systemDate = new Timestamp(System.currentTimeMillis());
      supplementaryContract = new SplContract();
      // 契約ID
      supplementaryContract
          .setContractId(inquiryContractInformationEntityBean
              .getContractId());
      // 付帯メニューID
      supplementaryContract.setSpmId(addSupplementaryContractBusinessBean
          .getSupplementaryMenuId());
      // 付帯契約開始日
      supplementaryContract
          .setSplContractSd(addSupplementaryContractBusinessBean
              .getSupplementaryContractStartDate());
      // 付帯契約終了日
      supplementaryContract
          .setSplContractEd(supplementaryContractEndDate);
      // 額・率
      supplementaryContract
          .setAmountOrRate(addSupplementaryContractBusinessBean
              .getAmountOrRate());
      // 更新回数
      supplementaryContract.setUpdateCount(0);
      // 作成日時
      supplementaryContract.setCreateTime(systemDate);
      // オンライン更新日時
      supplementaryContract.setOnlineUpdateTime(systemDate);
      // オンライン更新ユーザID
      supplementaryContract.setOnlineUpdateUserId(ThreadContext
          .getRequestThreadContext().get(ECISConstants.USER_ID_KEY)
          .toString());
      // 更新日時
      supplementaryContract.setUpdateTime(systemDate);
      // 更新モジュールコード
      supplementaryContract.setUpdateModuleCode(ThreadContext
          .getRequestThreadContext()
          .get(ECISConstants.CLASS_NAME_KEY).toString());
      // 《付帯契約情報共通Dao》.追加
      splContractMapper.insertBySequence(supplementaryContract);
      addSupplementaryContractBusinessBean
          .setSupplementaryContractId(supplementaryContract
              .getSplContractId());
      // 正常終了
      addSupplementaryContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);

    } catch (DuplicateKeyException e) {
      logger.error(messageSource.getMessage("error.E1129", null,
          Locale.getDefault()), e);
      // catch 重複例外クラス
      addSupplementaryContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D023);
      addSupplementaryContractBusinessBean
          .setMessage(duplicateKeyExceptionEmsg);

    } catch (BusinessLogicException e) {
      logger.error(messageSource.getMessage("error.E1129", null,
          Locale.getDefault()), e);
      // catch 業務例外クラス
      addSupplementaryContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      addSupplementaryContractBusinessBean
          .setMessage(businessLogicExceptionEMsg);

    } catch (NoSuchMessageException e) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, e);
      addSupplementaryContractBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      addSupplementaryContractBusinessBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
    }
    return addSupplementaryContractBusinessBean;
  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.kj.
   * KJ_SupplementaryContractInformationBusiness
   * #download(jp.co.unisys.enability.cis
   * .business.kj.model.DownloadSupplementaryContractBusinessBean)
   */
  @Override
  public DownloadSupplementaryContractBusinessBean download(
      DownloadSupplementaryContractBusinessBean downloadSupplementaryContractBusinessBean) {
    Map<String, Object> exampleMap = new HashMap<String, Object>();
    try {
      // 契約番号
      exampleMap
          .put(ECISKJConstants.S010107_SEARCH_KEY_CONTRACT_NO,
              downloadSupplementaryContractBusinessBean
                  .getContractManagementInformationDownloadSearchInformationBean()
                  .getContractNo());
      // 付帯メニュー
      exampleMap
          .put(ECISKJConstants.S010107_SEARCH_KEY_SUPPLEMENTARY_MENU,
              downloadSupplementaryContractBusinessBean
                  .getContractManagementInformationDownloadSearchInformationBean()
                  .getSupplementaryMenu());
      // 付帯契約期間（開始日）
      exampleMap
          .put(ECISKJConstants.S010107_SEARCH_KEY_SUPPLEMENTARY_CONTRACT_TERM_START_DATE,
              downloadSupplementaryContractBusinessBean
                  .getContractManagementInformationDownloadSearchInformationBean()
                  .getSupplementaryContractTermStartDate());
      // 付帯契約期間（終了日）
      exampleMap
          .put(ECISKJConstants.S010107_SEARCH_KEY_SUPPLEMENTARY_CONTRACT_TERM_END_DATE,
              downloadSupplementaryContractBusinessBean
                  .getContractManagementInformationDownloadSearchInformationBean()
                  .getSupplementaryContractTermEndDate());

      // 付帯契約情報ファイルの出力内容取得
      List<KJ_SupplementaryContractInformationFileEntityBean> supplementaryContractInformationFileEntityBeanList = supplementaryContractInformationCommonMapper
          .selectSupplementaryContractInformationFile(exampleMap);

      // オンライン処理基準日設定
      String onlineDate = StringConvertUtil
          .convertDateToString(
              dateBusiness
                  .getProcessBaseDate(ECISConstants.EXEC_BASE_DATE_ONLINE),
              ECISConstants.FORMAT_DATE_yyyyMMdd);

      // CSVファイル名設定
      StringBuilder fileName = new StringBuilder();
      fileName.append(
          ECISKJConstants.CONTRACT_MANAGEMENT_INFORMATION_DOWNLOAD_FILE_PREFIX_SUPPLEMENTARY_CONTRACT);
      fileName.append(ECISConstants.UNDERLINE);
      fileName.append(onlineDate);
      downloadSupplementaryContractBusinessBean
          .setDownloadFileName(fileName.toString());

      // 付帯契約情報ファイルの出力内容設定
      downloadSupplementaryContractBusinessBean
          .setSupplementaryContractInformationFileEntityBeanList(
              supplementaryContractInformationFileEntityBeanList);
    } catch (Exception e) {
      throw new SystemException(e.getMessage(), e);
    }
    return downloadSupplementaryContractBusinessBean;
  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.kj.
   * KJ_SupplementaryContractInformationBusiness
   * #csvFileCheck(jp.co.unisys.enability.cis
   * .business.kj.model.CsvFileCheckSupplementaryContractBusinessBean)
   */
  @Override
  public CsvFileCheckSupplementaryContractBusinessBean csvFileCheck(
      CsvFileCheckSupplementaryContractBusinessBean csvFileCheckBusinessBean) {
    try {
      /* 返却用オブジェクトの生成 */
      CsvFileCheckSupplementaryContractBusinessBean csvResultBean = new CsvFileCheckSupplementaryContractBusinessBean();
      List<String> errorList = new ArrayList<String>();
      List<Map<Integer, String>> registList = new ArrayList<Map<Integer, String>>();
      List<Map<Integer, String>> updateList = new ArrayList<Map<Integer, String>>();
      List<Map<Integer, String>> deleteList = new ArrayList<Map<Integer, String>>();

      /* ファイルオブジェクトの取得 */
      File csvFile = csvFileCheckBusinessBean.getUploadFile();

      /* ヘッダレコードチェック */
      // アップロードファイルMap生成
      List<Map<Integer, String>> csvList = null;
      csvList = Csv.load(csvFile, ECISConstants.ENCODE_TYPE_UTF8,
          ContractManagementInformationFileConfigCommon.getCsvConfig(),
          new ColumnPositionMapListHandler());

      // ファイル構成チェック
      if (ContractManagementInformationFileConfigCommon.UPLOAD_FILE_MINIMUM_LINE_COUNT > csvList
          .size()) {
        // エラーリストへ格納
        errorList.add(StringConvertUtil.convertErrorListString(
            csvFile.getName(),
            null,
            messageSource.getMessage("error.E0028", null,
                Locale.getDefault())));

        // 処理を終了する
        csvResultBean.setUploadFileName(csvFile.getName());
        csvResultBean.setErrorList(errorList);
        csvResultBean.setRegistList(registList);
        csvResultBean.setUpdateList(updateList);
        csvResultBean.setDeleteList(deleteList);

        return csvResultBean;
      }

      // 項目数チェック
      Map<Integer, String> header = csvList
          .get(ContractManagementInformationFileConfigCommon.ROW_NUMBER_HEADER);
      if (ContractManagementInformationFileConfigCommon.HEADER_COLUMN_COUNT != header
          .size()) {
        // エラーリストへ格納
        errorList
            .add(StringConvertUtil.convertErrorListString(
                csvFile.getName(),
                ContractManagementInformationFileConfigCommon.HEADER_START_LINE_NUMBER,
                messageSource.getMessage("error.E0021", null,
                    Locale.getDefault())));

        // 処理を終了する
        csvResultBean.setUploadFileName(csvFile.getName());
        csvResultBean.setErrorList(errorList);
        csvResultBean.setRegistList(registList);
        csvResultBean.setUpdateList(updateList);
        csvResultBean.setDeleteList(deleteList);

        return csvResultBean;
      }

      // 単項目チェック
      List<String> headerErrorMessageList = contractManagementInformationFileHeaderValidator
          .validate(
              header,
              ContractManagementInformationFileConfigSupplementaryContract.HEADER_FILE_KIND_PARAM);
      if (headerErrorMessageList.size() > 0) {
        for (String errorMessage : headerErrorMessageList) {
          errorList
              .add(StringConvertUtil.convertErrorListString(
                  csvFile.getName(),
                  ContractManagementInformationFileConfigCommon.HEADER_START_LINE_NUMBER,
                  errorMessage));
        }
        // 処理を終了する
        csvResultBean.setUploadFileName(csvFile.getName());
        csvResultBean.setErrorList(errorList);
        csvResultBean.setRegistList(registList);
        csvResultBean.setUpdateList(updateList);
        csvResultBean.setDeleteList(deleteList);
      }

      /* タイトル行チェック */
      // 項目数チェック
      Map<Integer, String> title = csvList
          .get(ContractManagementInformationFileConfigCommon.ROW_NUMBER_TITLE);
      if (ContractManagementInformationFileConfigSupplementaryContract.DATA_COLUMN_COUNT != title
          .size()) {
        // エラーリストへ格納
        errorList
            .add(StringConvertUtil.convertErrorListString(
                csvFile.getName(),
                ContractManagementInformationFileConfigCommon.TITLE_START_LINE_NUMBER,
                messageSource.getMessage("error.E0021", null,
                    Locale.getDefault())));

        // 処理を終了する
        csvResultBean.setUploadFileName(csvFile.getName());
        csvResultBean.setErrorList(errorList);
        csvResultBean.setRegistList(registList);
        csvResultBean.setUpdateList(updateList);
        csvResultBean.setDeleteList(deleteList);

        return csvResultBean;
      }

      // タイトル内容チェック
      // HashMapだと順番に揃わない可能性があるため、IteratorでKeyを取得
      Iterator<Integer> titleIt = title.keySet().iterator();
      while (titleIt.hasNext()) {
        // タイトルのカラム番号を取得
        Integer columnNo = titleIt.next();
        // タイトル内容を取得
        String titleValue = title.get(columnNo);
        // コンフィグの内容を取得
        String configValue = ContractManagementInformationFileConfigSupplementaryContract.DATA_TITLE_ROW[columnNo
            .intValue()];
        // 一致していない場合、エラー終了
        if (!configValue.equals(titleValue)) {
          errorList
              .add(StringConvertUtil.convertErrorListString(
                  csvFile.getName(),
                  ContractManagementInformationFileConfigCommon.TITLE_START_LINE_NUMBER,
                  messageSource.getMessage("error.E0028", null,
                      Locale.getDefault())));
          csvResultBean.setUploadFileName(csvFile.getName());
          csvResultBean.setErrorList(errorList);
          csvResultBean.setRegistList(registList);
          csvResultBean.setUpdateList(updateList);
          csvResultBean.setDeleteList(deleteList);
          return csvResultBean;
        }
      }

      /* データレコードチェック */
      // データレコードエラーリスト作製
      List<String> dataRecordErrorList = new ArrayList<String>();

      // データレコードの数だけ処理を行う
      for (int i = ContractManagementInformationFileConfigCommon.ROW_NUMBER_DATA; i < csvList
          .size(); i++) {
        // 初期化
        dataRecordErrorList.clear();

        Map<Integer, String> dataRecordMap = csvList.get(i);

        // 項目数チェック
        if (dataRecordMap
            .size() != ContractManagementInformationFileConfigSupplementaryContract.DATA_COLUMN_COUNT) {
          // エラーリストへ格納
          dataRecordErrorList.add(StringConvertUtil
              .convertErrorListString(csvFile.getName(), i + 1,
                  messageSource.getMessage("error.E0021", null,
                      Locale.getDefault())));
          errorList.addAll(dataRecordErrorList);

          // 処理を終了する
          csvResultBean.setUploadFileName(csvFile.getName());
          csvResultBean.setErrorList(errorList);
          csvResultBean.setRegistList(registList);
          csvResultBean.setUpdateList(updateList);
          csvResultBean.setDeleteList(deleteList);

          return csvResultBean;

        }

        // 登録・更新・削除区分
        String reUpDelCategory = dataRecordMap
            .get(ContractManagementInformationFileConfigSupplementaryContract.DATA_REGISTER_UPDATE_DELETE_CATEGORY_INDEX);

        // 登録・更新・削除区分チェック
        if (StringUtils.isEmpty(reUpDelCategory)) {
          // 次の行の処理を行う
          continue;
        }

        // バリデーションエラーメッセージ用リスト生成
        List<String> validationErrorMessageList = new ArrayList<String>();
        // 単項目チェック
        // 登録・更新・削除区分が登録の場合、登録用単項目チェックを行う
        if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER
            .equals(reUpDelCategory)) {
          validationErrorMessageList = supplementaryContractInformationFileRegistValidator
              .validate(dataRecordMap);
          // 登録・更新・削除区分が更新の場合、更新用単項目チェックを行う
        } else if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_UPDATE
            .equals(reUpDelCategory)) {
          validationErrorMessageList = supplementaryContractInformationFileUpdateValidator
              .validate(dataRecordMap);
          // 登録・更新・削除区分が削除の場合、削除用単項目チェックを行う
        } else if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_DELETE
            .equals(reUpDelCategory)) {
          validationErrorMessageList = supplementaryContractInformationFileDeleteValidator
              .validate(dataRecordMap);
          // 一致しない場合は、エラーリストにメッセージを設定
        } else {
          dataRecordErrorList
              .add(StringConvertUtil.convertErrorListString(
                  csvFile.getName(),
                  i + 1,
                  messageSource
                      .getMessage(
                          "validation.range",
                          new String[] {
                              ContractManagementInformationFileConfigSupplementaryContract.DATA_REGISTER_UPDATE_DELETE_CATEGORY_NAME,
                              ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER
                                  + ","
                                  + ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_UPDATE
                                  + ","
                                  + ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_DELETE },
                          Locale.getDefault())));
        }

        // バリデーションエラーメッセージにファイル名と行数を追加し、データレコードエラーリストに追加
        for (String validationErrorMessage : validationErrorMessageList) {
          dataRecordErrorList.add(StringConvertUtil
              .convertErrorListString(csvFile.getName(), i + 1,
                  validationErrorMessage));
        }

        // 登録・更新・削除区分が登録の場合、以下のチェックを行う
        if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER.equals(reUpDelCategory)) {

          // 付帯メニューID
          String suppMenuId = dataRecordMap
              .get(ContractManagementInformationFileConfigSupplementaryContract.DATA_SUPPLEMENTARY_MENU_ID_INDEX);
          // 付帯契約開始日
          String suppContractStartDate = dataRecordMap
              .get(ContractManagementInformationFileConfigSupplementaryContract.DATA_SUPPLEMENTARY_CONTRACT_START_DATE_INDEX);
          // 付帯契約終了日
          String suppContractEndDate = dataRecordMap
              .get(ContractManagementInformationFileConfigSupplementaryContract.DATA_SUPPLEMENTARY_CONTRACT_END_DATE_INDEX);
          // 額・率
          String amoutOrRate = dataRecordMap
              .get(ContractManagementInformationFileConfigSupplementaryContract.DATA_AMOUNT_OR_RATE_INDEX);

          // 付帯メニューの取得
          Spm spmEntity = spmMapper
              .selectByPrimaryKey(suppMenuId);

          // 付帯メニュー判定
          // マスタに当該コードが存在しない場合は、エラーリストにメッセージを格納
          if (spmEntity == null) {
            dataRecordErrorList
                .add(StringConvertUtil
                    .convertErrorListString(
                        csvFile.getName(),
                        i + 1,
                        messageSource
                            .getMessage(
                                "validation.regexitem",
                                new String[] {
                                    ContractManagementInformationFileConfigSupplementaryContract.DATA_SUPPLEMENTARY_MENU_ID_NAME },
                                Locale.getDefault())));
          } else {
            // 額・率
            // 付帯メニューの個別設定フラグが個別設定有りの場合、以下のチェックを行う
            if (ECISKJConstants.INDIVIDUAL_SETTING_FLAG_ON
                .equals(spmEntity.getIndividualSettingFlag())) {
              // 額・率が設定されていない場合、エラーリストにメッセージを格納
              if (StringUtils.isEmpty(amoutOrRate)) {
                dataRecordErrorList.add(StringConvertUtil
                    .convertErrorListString(csvFile.getName(),
                        i + 1, messageSource.getMessage(
                            "error.E1024", null,
                            Locale.getDefault())));
              }

              // 付帯メニューの付帯種別コードが定額の場合、以下のチェックを行う
              else if (ECISCodeConstants.SUPPLEMENTARY_CLASS_CODE_FIXED_AMOUNT
                  .equals(spmEntity.getSplClassCode())) {
                // 額・率のフォーマットがZZZ9.ZZでない場合、エラーリストにメッセージを格納
                boolean result = CommonValidationUtil
                    .checkBigDecimalStringDigit(
                        amoutOrRate,
                        ContractManagementInformationFileConfigSupplementaryContract.DATA_AMOUNT_OR_RATE_AMOUNT_DIGIT_INTEGER,
                        ECISKJConstants.SUPPLEMENTARY_CONTRACT_AMOUNT_SCALE);
                if (!result) {
                  dataRecordErrorList.add(StringConvertUtil
                      .convertErrorListString(csvFile
                          .getName(), i + 1,
                          messageSource.getMessage(
                              "error.E1157", null,
                              Locale.getDefault())));
                }

                // 付帯メニューの付帯種別コードが定率の場合、以下のチェックを行う
              } else if (ECISCodeConstants.SUPPLEMENTARY_CLASS_CODE_FIXED_RATE
                  .equals(spmEntity.getSplClassCode())) {
                // 額・率が1より大きい場合、エラーリストのメッセージを格納
                BigDecimal target = new BigDecimal(amoutOrRate);
                if (ContractManagementInformationFileConfigSupplementaryContract.DATA_AMOUNT_OR_RATE_RATE_MIN_VALUE
                    .compareTo(target) == -1) {
                  dataRecordErrorList.add(StringConvertUtil
                      .convertErrorListString(csvFile
                          .getName(), i + 1,
                          messageSource.getMessage(
                              "error.E1158", null,
                              Locale.getDefault())));
                }
              }
              // 付帯メニューの個別設定フラグが個別設定なしの場合、以下のチェックを行う
            } else if (ECISKJConstants.INDIVIDUAL_SETTING_FLAG_OFF
                .equals(spmEntity.getIndividualSettingFlag())) {
              // 額・率が設定されている場合、エラーリストにメッセージを格納
              if (StringUtils.isNotEmpty(amoutOrRate)) {
                dataRecordErrorList.add(StringConvertUtil
                    .convertErrorListString(csvFile.getName(),
                        i + 1, messageSource.getMessage(
                            "error.E1025", null,
                            Locale.getDefault())));
              }
            }

          }

          // 付帯契約開始日、付帯契約終了日
          // 付帯契約終了日がNULLまたは空文字以外の場合、以下のチェックを行う
          if (!StringUtils.isEmpty(suppContractEndDate)) {
            // 付帯契約終了日が付帯契約開始日以前かチェックを行う
            boolean result = CommonValidationUtil.checkDateRange(
                suppContractEndDate, suppContractStartDate);

            // 付帯契約終了日が付帯契約開始日以前の場合、エラーリストにメッセージを格納
            if (result) {
              dataRecordErrorList.add(StringConvertUtil
                  .convertErrorListString(csvFile.getName(),
                      i + 1, messageSource.getMessage(
                          "error.E1027", null,
                          Locale.getDefault())));
            }
          }

        }

        // エラー出力状況確認
        if (!dataRecordErrorList.isEmpty()) {
          errorList.addAll(dataRecordErrorList);
          continue;
        }

        // 行番号情報設定
        dataRecordMap
            .put(Integer
                .valueOf(ContractManagementInformationFileConfigCommon.DATA_ROW_NO_INDEX),
                String.valueOf(i + 1));

        // データレコード振り分け
        if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER
            .equals(reUpDelCategory)) {
          registList.add(dataRecordMap);
        } else if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_UPDATE
            .equals(reUpDelCategory)) {
          updateList.add(dataRecordMap);
        } else if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_DELETE
            .equals(reUpDelCategory)) {
          deleteList.add(dataRecordMap);
        }

      }
      // 返却
      csvResultBean.setUploadFileName(csvFile.getName());
      csvResultBean.setErrorList(errorList);
      csvResultBean.setRegistList(registList);
      csvResultBean.setUpdateList(updateList);
      csvResultBean.setDeleteList(deleteList);
      return csvResultBean;
    } catch (Exception e) {
      throw new SystemException(e.getMessage(), e);
    }
  }

  /**
   * 確定料金実績件数取得
   *
   * @param contractId
   *          契約ID
   * @param coveredDate
   *          対象日
   *
   */
  private int getFixChargeResultInformationCount(Integer contractId,
      Date coveredDate) {

    // 確定料金情報照会条件Map
    Map<String, Object> conditionsMap = new HashMap<String, Object>();

    // 条件Map.契約ID
    conditionsMap.put("contractId", contractId);
    // 条件Map.対象日
    conditionsMap.put("coveredDate", coveredDate);
    // 条件Map.フラグ
    conditionsMap.put("flg",
        ECISKJConstants.INQUIRY_FIX_CHANGE_RESULT_INFOEMATION_FLG_ON);

    return fixChargeResultInformationCommonMapper
        .countByFixChargeResult(conditionsMap);
  }

  /**
   * 契約情報ビジネスのセッター(DI)
   *
   * @param kjContractInformationBusiness
   *          契約情報ビジネス
   *
   */
  public void setKjContractInformationBusiness(
      KJ_ContractInformationBusiness kjContractInformationBusiness) {
    this.kjContractInformationBusiness = kjContractInformationBusiness;
  }

  /**
   * 契約者情報ビジネスのセッター(DI)
   *
   * @param kjContractorInformationBusiness
   *          契約者情報ビジネス
   */
  public void setKjContractorInformationBusiness(
      KJ_ContractorInformationBusiness kjContractorInformationBusiness) {
    this.kjContractorInformationBusiness = kjContractorInformationBusiness;
  }

  /**
   * 確定料金実績情報共通マッパーのセッター(DI)
   *
   * @param fixChargeResultInformationCommonMapper
   *          確定料金実績情報共通マッパー
   *
   */
  public void setFixChargeResultInformationCommonMapper(
      FixChargeResultInformationCommonMapper fixChargeResultInformationCommonMapper) {
    this.fixChargeResultInformationCommonMapper = fixChargeResultInformationCommonMapper;
  }

  /**
   * 付帯契約情報共通マッパーのセッター(DI)
   *
   * @param supplementaryContractInformationCommonMapper
   *          付帯契約情報共通マッパー
   *
   */
  public void setSupplementaryContractInformationCommonMapper(
      SupplementaryContractInformationCommonMapper supplementaryContractInformationCommonMapper) {
    this.supplementaryContractInformationCommonMapper = supplementaryContractInformationCommonMapper;
  }

  /**
   * 付帯契約マッパーのセッター(DI)
   *
   * @param supplementaryContractMapper
   *          付帯契約マッパー
   *
   */
  public void setSupplementaryContractMapper(
      SplContractMapper supplementaryContractMapper) {
    this.splContractMapper = supplementaryContractMapper;
  }

  /**
   * 付帯メニューマッパーのセッター(DI)
   *
   * @param supplementaryMenuMapper
   *          付帯メニューマッパー
   *
   */
  public void setSupplementaryMenuMapper(SpmMapper supplementaryMenuMapper) {
    this.spmMapper = supplementaryMenuMapper;
  }

  /**
   * 料金メニューマッパーのセッター(DI)
   *
   * @param rateMenuMapper
   *          料金メニューマッパー
   *
   */
  public void setRateMenuMapper(RmMapper rateMenuMapper) {
    this.rmMapper = rateMenuMapper;
  }

  /**
   * 提供モデル企業別付帯メニューマスタマッパーのセッター(DI)
   *
   * @param spmMByPmCompanyMapper
   *          提供モデル企業別付帯メニューマスタマッパー
   */
  public void setSpmMByPmCompanyMapper(SpmMByPmCompanyMapper spmMByPmCompanyMapper) {
    this.spmMByPmCompanyMapper = spmMByPmCompanyMapper;
  }

  /**
   * messageSourceのセッター(DI)
   *
   * @param messageSource
   *          メッセージソース
   *
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }

  /**
   * 日付関連共通ビジネスを設定します。(DI)
   *
   * @param dateBusiness
   *          日付関連共通ビジネス
   *
   */
  public void setDateBusiness(DateBusiness dateBusiness) {
    this.dateBusiness = dateBusiness;
  }

  /**
   * 契約管理情報ファイルヘッダーバリデーターのセッター(DI)
   *
   * @param contractManagementInformationFileHeaderValidator
   *          契約管理情報ファイルヘッダーバリデーター
   *
   */
  public void setContractManagementInformationFileHeaderValidator(
      ContractManagementInformationFileHeaderValidator contractManagementInformationFileHeaderValidator) {
    this.contractManagementInformationFileHeaderValidator = contractManagementInformationFileHeaderValidator;
  }

  /**
   * 付帯契約情報登録バリデーションのセッター(DI)
   *
   * @param supplementaryContractInformationFileRegistValidator
   *          付帯契約情報登録バリデーション(DI)
   */
  public void setSupplementaryContractInformationFileRegistValidator(
      SupplementaryContractInformationFileRegistValidator supplementaryContractInformationFileRegistValidator) {
    this.supplementaryContractInformationFileRegistValidator = supplementaryContractInformationFileRegistValidator;
  }

  /**
   * 付帯契約情報更新バリデーションのセッター(DI)
   *
   * @param supplementaryContractInformationFileRegistValidator
   *          付帯契約情報更新バリデーション(DI)
   */
  public void setSupplementaryContractInformationFileUpdateValidator(
      SupplementaryContractInformationFileUpdateValidator supplementaryContractInformationFileUpdateValidator) {
    this.supplementaryContractInformationFileUpdateValidator = supplementaryContractInformationFileUpdateValidator;
  }

  /**
   * 付帯契約情報削除バリデーションのセッター(DI)
   *
   * @param supplementaryContractInformationFileRegistValidator
   *          付帯契約情報削除バリデーション(DI)
   */
  public void setSupplementaryContractInformationFileDeleteValidator(
      SupplementaryContractInformationFileDeleteValidator supplementaryContractInformationFileDeleteValidator) {
    this.supplementaryContractInformationFileDeleteValidator = supplementaryContractInformationFileDeleteValidator;
  }

}
