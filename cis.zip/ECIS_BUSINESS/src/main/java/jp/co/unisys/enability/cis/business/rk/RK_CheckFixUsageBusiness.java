package jp.co.unisys.enability.cis.business.rk;

import jp.co.unisys.enability.cis.business.rk.model.RK_UsageLinkageCheckCheckDataBusinessBean;
import jp.co.unisys.enability.cis.business.rk.model.RK_UsageLinkageCheckTermDecisionBusinessBean;

/**
 * 使用量連携チェック・確定使用量メッセージチェックビジネスインターフェース。
 *
 * <pre>
 * <p><b>【仕様詳細】</b></p>
 * 使用量連携チェックの各チェックは、このクラスを実装する。
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public interface RK_CheckFixUsageBusiness {

  /**
   * 使用量連携チェックのチェック処理。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 使用量連携チェック機能から呼び出されるメソッド。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param checkDataBusinessBean
   *          チェック対象ビジネスBean
   * @param termDecisionBusinessBean
   *          期間判定情報ビジネスBean
   * @return true:処理継続、false:処理終了
   */
  public abstract boolean check(
      RK_UsageLinkageCheckCheckDataBusinessBean checkDataBusinessBean,
      RK_UsageLinkageCheckTermDecisionBusinessBean termDecisionBusinessBean);
}
