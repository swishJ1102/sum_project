package jp.co.unisys.enability.cis.business.kj.model;

import java.util.List;

import jp.co.unisys.enability.cis.dao.kj.ContractManagementInformationDownloadSearchInformationBean;
import jp.co.unisys.enability.cis.entity.kj.KJ_ContractInformationFileEntityBean;

/**
 * 契約情報ダウンロードBusinessBean
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * 契約情報ビジネス
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class DownloadContractBusinessBean {

  /**
   * ダウンロードファイル名を保有する。
   */
  private String downloadFileName;

  /**
   * 契約管理情報ダウンロード検索条件を保有する。
   */
  private ContractManagementInformationDownloadSearchInformationBean contractManagementInformationDownloadSearchInformationBean;

  /**
   * 契約情報ファイルリストを保有する。
   */
  private List<KJ_ContractInformationFileEntityBean> contractInformationFileEntityBeanList;

  /**
   * ダウンロードファイル名のgetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * ダウンロードファイル名を取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return ダウンロードファイル名
   */
  public String getDownloadFileName() {
    return downloadFileName;
  }

  /**
   * ダウンロードファイル名のsetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * ダウンロードファイル名を設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param downloadFileName
   *          ダウンロードファイル名
   */
  public void setDownloadFileName(String downloadFileName) {
    this.downloadFileName = downloadFileName;
  }

  /**
   * 契約管理情報ダウンロード検索条件のgetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約管理情報ダウンロード検索条件を取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 契約管理情報ダウンロード検索条件
   */
  public ContractManagementInformationDownloadSearchInformationBean getContractManagementInformationDownloadSearchInformationBean() {
    return contractManagementInformationDownloadSearchInformationBean;
  }

  /**
   * 契約管理情報ダウンロード検索条件のsetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約管理情報ダウンロード検索条件を設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param contractManagementInformationDownloadSearchInformationBean
   *          契約管理情報ダウンロード検索条件
   */
  public void setContractManagementInformationDownloadSearchInformationBean(
      ContractManagementInformationDownloadSearchInformationBean contractManagementInformationDownloadSearchInformationBean) {
    this.contractManagementInformationDownloadSearchInformationBean = contractManagementInformationDownloadSearchInformationBean;
  }

  /**
   * 契約情報ファイルリストのgetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約情報ファイルリストを取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 契約情報ファイルリスト
   */
  public List<KJ_ContractInformationFileEntityBean> getContractInformationFileEntityBeanList() {
    return contractInformationFileEntityBeanList;
  }

  /**
   * 契約情報ファイルリストのsetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約情報ファイルリストを設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param contractInformationFileEntityBeanList
   *          契約情報ファイルリスト
   */
  public void setContractInformationFileEntityBeanList(
      List<KJ_ContractInformationFileEntityBean> contractInformationFileEntityBeanList) {
    this.contractInformationFileEntityBeanList = contractInformationFileEntityBeanList;
  }
}
