package jp.co.unisys.enability.cis.business.rk;

import org.apache.commons.lang3.StringUtils;

import jp.co.unisys.enability.cis.business.rk.model.RK_ChargeCalcWarningCheckBusinessBean;
import jp.co.unisys.enability.cis.common.util.constants.ECISCodeConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;
import jp.co.unisys.enability.cis.dao.rk.RK_ChargeCalcWarningCheckDao;
import jp.co.unisys.enability.cis.entity.common.Rm;

/**
 * BRK0103-03月額料金マイナスチェックビジネス
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_MonthlyChargeMinusCheckBusinessImpl implements RK_ChargeCalcWarningCheckBusiness {

  /**
   * 料金計算警告共通DAO(DI)
   */
  private RK_ChargeCalcWarningCheckDao rkChargeCalcWarningCheckDao;

  /**
   * 月額料金マイナスチェック。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 売上関連項目計算から取得した月額料金によりチェックを行う。
   * 売買区分＝売電の時、月額料金がマイナスだった場合エラー
   * 売買区分＝買電の時、月額料金がプラスだった場合エラー
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param chargeCalcWarningCheckBean
   *          《料金計算警告チェックビジネスBean》
   * @return 警告コード
   * @throws Exception
   *           予期せぬエラーが発生した場合
   */
  @Override
  public String check(RK_ChargeCalcWarningCheckBusinessBean chargeCalcWarningCheckBean) {

    Long monthlyCharge = chargeCalcWarningCheckBean.getMonthlyCharge();
    Rm rm = chargeCalcWarningCheckBean.getRm();

    String saleCatCode = null;
    if (rm == null || StringUtils.isEmpty(rm.getSaleCatCode())) {
      // 料金メニューマスタを取得する

      rm = rkChargeCalcWarningCheckDao.selectContractClassInfo(chargeCalcWarningCheckBean.getContractId(),
          chargeCalcWarningCheckBean.getUsePeriod());
      if (rm != null) {
        saleCatCode = rm.getSaleCatCode();
      }
    } else {
      saleCatCode = rm.getSaleCatCode();
    }

    if (ECISCodeConstants.SALE_CATEGORY_SELLING.equals(saleCatCode)) {
      // 売電の場合
      // 月額料金が0未満の場合、月額料金マイナス値エラー
      if (monthlyCharge.compareTo(0L) < 0) {
        return ECISRKConstants.WARNING_CLASS_MASTER_MONTHLY_CHARGE_MINUS;
      }
    } else {
      // 買電の場合
      // 月額料金がプラスの場合、月額料金プラス値のエラー
      if (monthlyCharge.compareTo(0L) > 0) {
        return ECISRKConstants.WARNING_CLASS_MASTER_MONTHLY_CHARGE_MINUS;
      }
    }

    return null;
  }

  /**
   * 料金計算警告共通DAOのsetter（DI）
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金計算警告共通DAOを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param rkChargeCalcWarningCheckDao
   *          料金計算警告共通DAO
   */
  public void setRkChargeCalcWarningCheckDao(RK_ChargeCalcWarningCheckDao rkChargeCalcWarningCheckDao) {
    this.rkChargeCalcWarningCheckDao = rkChargeCalcWarningCheckDao;
  }
}
