package jp.co.unisys.enability.cis.business.rk;

import jp.co.unisys.enability.cis.business.rk.model.RK_ChargeCalcWarningCheckBusinessBean;
import jp.co.unisys.enability.cis.common.util.constants.ECISCodeConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;
import jp.co.unisys.enability.cis.entity.common.ContractHist;
import jp.co.unisys.enability.cis.entity.common.ContractHistExample;
import jp.co.unisys.enability.cis.entity.common.Rqh;
import jp.co.unisys.enability.cis.entity.common.RqhKey;
import jp.co.unisys.enability.cis.mapper.common.ContractHistMapper;
import jp.co.unisys.enability.cis.mapper.common.RqhMapper;

/**
 * BRK0103-03最大需要電力チェックビジネス
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.common.DateBusiness
 * @see jp.co.unisys.enability.cis.dao.rk.RK_ChargeCalcWarningCheckDao
 */
public class RK_PeakKwCheckBusinessImpl implements
    RK_ChargeCalcWarningCheckBusiness {

  /**
   * 実量歴管理Mapper(DI)
   */
  private RqhMapper rqhMapper;

  /**
   * 契約履歴Mapper(DI)
   */
  private ContractHistMapper contractHistMapper;

  /**
   * 最大需要電力チェックビジネス
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param chargeCalcWarningCheckBean
   *          《料金計算警告チェックビジネスBean》
   * @return 警告コード
   * @see jp.co.unisys.enability.cis.business.common.DateBusiness
   * @see jp.co.unisys.enability.cis.dao.rk.RK_ChargeCalcWarningCheckDao
   */
  @Override
  public String check(
      RK_ChargeCalcWarningCheckBusinessBean chargeCalcWarningCheckBean) {

    // 実量歴管理情報を取得する。
    // 実量歴管理キーBeanを生成する
    RqhKey rqhKey = new RqhKey();
    // 引数設定
    rqhKey.setContractId(chargeCalcWarningCheckBean.getContractId());
    rqhKey.setCoveredPeriod(chargeCalcWarningCheckBean.getUsePeriod());
    // 実量歴管理Mapper.selectByPrimaryKeyを呼び出し、実量歴管理情報を取得する
    Rqh rqh = rqhMapper.selectByPrimaryKey(rqhKey);

    // 契約履歴EntityBeanを取得する
    // 契約履歴Example
    ContractHistExample contractHistExample = new ContractHistExample();

    // 【契約履歴】を取得する条件を設定
    contractHistExample
        .createCriteria()
        // 契約ID
        .andContractIdEqualTo(
            chargeCalcWarningCheckBean.getContractId())
        // 適用開始日
        .andApplySdLessThanOrEqualTo(
            chargeCalcWarningCheckBean
                .getChargeCalculationStartDate())
        // 適用終了日
        .andApplyEdGreaterThanOrEqualTo(
            chargeCalcWarningCheckBean
                .getChargeCalculationStartDate());

    // 【契約履歴】取得
    ContractHist contractHis = contractHistMapper.selectByExample(
        contractHistExample).get(0);

    // チェックの判断を行う。
    // 電圧区分コードが「高圧」の場合
    if ((ECISCodeConstants.CUSTOM_VOLTAGE_CAT_CODE_HIGH_TENSION.equals(
        contractHis.getVoltageCatCode())
        // 電圧区分コードが「特高」の場合
        || ECISCodeConstants.CUSTOM_VOLTAGE_CAT_CODE_SPECIALLY_HIGH.equals(contractHis.getVoltageCatCode()))
        // 最大電力（確定使用量）がNULLの場合
        && rqh.getPkwUsage() == null) {
      // 戻り値に307 を設定する。
      return ECISRKConstants.WARNING_CLASS_MASTER_PEAK_KW;
    }
    // 戻り値にnull を設定する。
    return null;
  }

  /**
   * 実量歴管理Mapperのsetter（DI）
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 実量歴管理Mapperを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param cclMMaper
   *          実量歴管理Mapper
   */
  public void setRqhMapper(RqhMapper rqhMapper) {
    this.rqhMapper = rqhMapper;
  }

  /**
   * 契約履歴Mapperのsetter（DI）
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約履歴Mapperを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param cclMMaper
   *          契約履歴Mapper
   */
  public void setContractHistMapper(ContractHistMapper contractHistMapper) {
    this.contractHistMapper = contractHistMapper;
  }

}
