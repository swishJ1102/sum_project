package jp.co.unisys.enability.cis.business.rk.model;

import java.util.Date;
import java.util.List;

/**
 * 確定使用量対象日毎の30分電力量を保持するビジネスBean。
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * 使用量連携チェックビジネス。
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_UsageLinkageCheckTermDecisionBusinessBean {

  /**
   * 対象期間開始日を保有する。
   */
  private Date coveredTermStartDate;

  /**
   * 対象期間終了日を保有する。
   */
  private Date coveredTermEndDate;

  /**
   * 契約情報リストを保有する。
   */
  private List<RK_UsageLinkageCheckContractBusinessBean> contractList;

  /**
   * 対象期間開始日のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 対象期間開始日を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 対象期間開始日
   */
  public Date getCoveredTermStartDate() {
    return this.coveredTermStartDate;
  }

  /**
   * 対象期間開始日のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 対象期間開始日を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param coveredTermStartDate
   *          対象期間開始日
   */
  public void setCoveredTermStartDate(Date coveredTermStartDate) {
    this.coveredTermStartDate = coveredTermStartDate;
  }

  /**
   * 対象期間終了日のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 対象期間終了日を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 対象期間終了日
   */
  public Date getCoveredTermEndDate() {
    return this.coveredTermEndDate;
  }

  /**
   * 対象期間終了日のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 対象期間終了日を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param coveredTermEndDate
   *          対象期間終了日
   */
  public void setCoveredTermEndDate(Date coveredTermEndDate) {
    this.coveredTermEndDate = coveredTermEndDate;
  }

  /**
   * 契約情報リストのgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約情報リストを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約情報リスト
   */
  public List<RK_UsageLinkageCheckContractBusinessBean> getContractList() {
    return this.contractList;
  }

  /**
   * 契約情報リストのsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約情報リストを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractList
   *          契約情報リスト
   */
  public void setContractList(
      List<RK_UsageLinkageCheckContractBusinessBean> contractList) {
    this.contractList = contractList;
  }

}
