package jp.co.unisys.enability.cis.business.rk;

import java.util.Locale;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.MessageSource;

import jp.co.unisys.enability.cis.business.rk.model.RK_UsageLinkageCheckCheckDataBusinessBean;
import jp.co.unisys.enability.cis.business.rk.model.RK_UsageLinkageCheckTermDecisionBusinessBean;
import jp.co.unisys.enability.cis.common.util.StringConvertUtil;
import jp.co.unisys.enability.cis.common.util.constants.ECISCodeConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;

/**
 * 取り込み対象外チェックビジネスクラス。
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.rk.RK_UsageLinkageCheckBusiness
 */
public class RK_CheckNotModifiedBusinessImpl implements RK_CheckFixUsageBusiness {

  /** 料金計算チェックビジネス(DI) */
  private RK_UsageLinkageCheckBusiness rkUsageLinkageCheckBusiness;

  /** メッセージプロパティ */
  private MessageSource messageSource;

  /** ロガー */
  private static final Logger LOGGER = LogManager.getLogger();

  @Override
  public boolean check(RK_UsageLinkageCheckCheckDataBusinessBean checkDataBusinessBean,
      RK_UsageLinkageCheckTermDecisionBusinessBean termDecisionBusinessBean) {

    // 継続フラグ
    boolean continuation = true;

    // 計算済みフラグが"ON"で、更新コードが"更新なし"で再度連携された場合は、
    // 【月次実績】.月次実績エラー区分コードを"無視"で更新する
    if (ECISConstants.FLG_ON.equals(checkDataBusinessBean.getCalculatedFlag())
        && ECISCodeConstants.MONTHLY_USAGE_RESULT_UPDATE_CODE_NOT_MODIFIED.equals(checkDataBusinessBean
            .getUpdateCode())) {

      // 【月次実績】を更新
      rkUsageLinkageCheckBusiness.updateMonthlyUsageResultIgnore(checkDataBusinessBean);

      // ログのパラメーター
      String[] parameters = new String[] {
          // 処理日
          StringConvertUtil.convertDateToString(checkDataBusinessBean.getExecuteDate(),
              ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
          // 地点特定番号
          checkDataBusinessBean.getSpotNo(),
          // 確定使用量ファイル名
          checkDataBusinessBean.getFixUsageFileName(),
          // エリアコード
          checkDataBusinessBean.getAreaCode(),
          // 更新コード
          checkDataBusinessBean.getProvideCheckCode()
      };

      // 取り込み対象外となった確定使用量メッセージの情報を出力
      LOGGER.info(messageSource.getMessage("info.I1026", parameters, Locale.getDefault()));

      // 処理を継続しない
      continuation = false;
    }

    return continuation;
  }

  /**
   * 料金計算チェックビジネスを設定します。(DI)
   *
   * @param rkUsageLinkageCheckBusiness
   *          料金計算チェックビジネス
   */
  public void setRkUsageLinkageCheckBusiness(
      RK_UsageLinkageCheckBusiness rkUsageLinkageCheckBusiness) {
    this.rkUsageLinkageCheckBusiness = rkUsageLinkageCheckBusiness;
  }

  /**
   * メッセージプロパティを設定します。(DI)
   *
   * @param messageSource
   *          メッセージプロパティ
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }

}
