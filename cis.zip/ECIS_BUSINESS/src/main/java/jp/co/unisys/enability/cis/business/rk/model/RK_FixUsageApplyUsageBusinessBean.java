package jp.co.unisys.enability.cis.business.rk.model;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * 使用量を保持するビジネスBean。
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * 確定使用量情報反映ビジネス。
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_FixUsageApplyUsageBusinessBean {

  /**
   * 年月日を保有する。
   */
  private Date usageDate;

  /**
   * 使用量リストを保有する。
   */
  private List<BigDecimal> usageList;

  /**
   * 年月日のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 年月日を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 年月日
   */
  public Date getUsageDate() {
    return this.usageDate;
  }

  /**
   * 年月日のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 年月日を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param usageDate
   *          年月日
   */
  public void setUsageDate(Date usageDate) {
    this.usageDate = usageDate;
  }

  /**
   * 使用量リストのgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 使用量リストを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 使用量リスト
   */
  public List<BigDecimal> getUsageList() {
    return this.usageList;
  }

  /**
   * 使用量リストのsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 使用量リストを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param usageList
   *          使用量リスト
   */
  public void setUsageList(List<BigDecimal> usageList) {
    this.usageList = usageList;
  }

}
