package jp.co.unisys.enability.cis.business.sn;

import java.util.Map;

import jp.co.unisys.enability.cis.entity.sn.SN_CreatingBillingTargetEntityBean;

/**
 * 請求入金共通請求作成ビジネスインタフェース。
 *
 * <pre>
 * <p><b>【仕様詳細】</b></p>
 * 本クラスは請求単位でインスタンスを持つ請求作成共通のクラスである。
 * 【請求】に登録する情報を各メソッドより取得し、メンバ変数.《請求EntityBean》に設定する。
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 *
 */
public interface SN_CreatingBillingBusiness {

  /**
   * 請求作成処理。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 各メソッドを呼び出し、請求作成に必要な
   * 情報を取得し、請求に登録する。
   * ・計上年月日の取得
   * ・契約単位の金額合算処理
   * ・預り金充当処理
   * ・請求の作成
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param map
   *          Map<契約ID, 《請求作成対象候補EntityBean》>
   * @param batchDate
   *          バッチ処理基準日
   * @param paymentWayCode
   *          支払方法コード
   * @param multipleMcBlFlag
   *          まとめ請求フラグ
   */
  void createBilling(Map<Integer, SN_CreatingBillingTargetEntityBean> map,
      String batchDate, String paymentWayCode, boolean multipleMcBlFlag);

  /**
   * 債権回収請求作成処理。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 各メソッドを呼び出し、請求作成に必要な
   * 情報を取得し、請求に登録する。
   * ・計上年月日の取得
   * ・契約単位の金額合算処理
   * ・預り金充当処理
   * ・請求の作成
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param bean
   *          《請求作成対象候補EntityBean》
   * @param batchDate
   *          バッチ処理基準日
   * @param processFlg
   *          処理フラグ
   */
  void claimCollectionCreateBilling(SN_CreatingBillingTargetEntityBean bean,
      String batchDate, String processFlg);

}
