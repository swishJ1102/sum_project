/**
 *
 */
package jp.co.unisys.enability.cis.business.rk;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import jp.co.unisys.enability.cis.business.rk.model.RK_OnlineCommonBusinessBean;
import jp.co.unisys.enability.cis.business.rk.model.RK_RateMenuInfoBean;
import jp.co.unisys.enability.cis.business.rk.model.RK_UsePeriodRateMenuInfoBean;
import jp.co.unisys.enability.cis.common.util.RK_CommonUtil;
import jp.co.unisys.enability.cis.common.util.StringConvertUtil;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISReturnCodeConstants;
import jp.co.unisys.enability.cis.entity.common.Rm;
import jp.co.unisys.enability.cis.mapper.common.RmMapper;

public class RK_RateSimulationBusinessImpl implements RK_RateSimulationBusiness {

  /** 料金メニューマスタマッパー(DI) */
  private RmMapper rmMapper;

  /** 料金計算オンライン共通ビジネス(DI) */
  private RK_OnlineCommonBusiness rkOnlineCommonBusiness;

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.rk.RK_RateSimulationBusiness#
   * checkContractCapacity
   * (jp.co.unisys.enability.cis.business.rk.model.RK_RateMenuInfoBean[])
   */
  @Override
  public String checkContractCapacity(String rateMenuId, String contractcapacity) {

    // 料金メニューID入力チェック
    if (StringUtils.isEmpty(rateMenuId)) {
      return ECISReturnCodeConstants.RETURN_CODE_P029;
    }

    // 料金メニュー存在チェック
    Rm rm = rmMapper.selectByPrimaryKey(rateMenuId);
    if (rm == null) {
      return ECISReturnCodeConstants.RETURN_CODE_D003;
    }

    if (StringUtils.isNotEmpty(rm.getCapacitySelectableRange())) {
      // 契約容量入力チェック
      contractcapacity = StringConvertUtil.convertBigDecimalToString(
          contractcapacity, null);

      try {
        if (!RK_CommonUtil.checkContractCapacity(contractcapacity,
            rm.getCapacitySelectableRange())) {
          return ECISReturnCodeConstants.RETURN_CODE_G006;
        }
      } catch (IllegalArgumentException e) {
        return ECISReturnCodeConstants.RETURN_CODE_G006;
      }
    }
    return ECISConstants.EMPTY_STRING;
  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.rk.RK_RateSimulationBusiness#doSimulation
   * (
   * jp.co.unisys.enability.cis.business.rk.model.RK_UsageCsvCalculateBusinessBean
   * , java.util.Date)
   */
  @Override
  public List<RK_OnlineCommonBusinessBean> doSimulation(
      RK_RateMenuInfoBean rateMenuInfo, Date rateCalculationBaseDate) {

    List<RK_OnlineCommonBusinessBean> comonBusinessBeanList = new ArrayList<>();

    // 料金計算オンライン共通ビジネスを呼び出す。
    for (RK_UsePeriodRateMenuInfoBean useperiodratemenuinfolist : rateMenuInfo
        .getUseperiodratemenuinfolist()) {

      // ビジネスBeanの作成
      RK_OnlineCommonBusinessBean comonBusinessBean = this
          .createOnlineCommonBusinessInfo(
              useperiodratemenuinfolist,
              rateMenuInfo.getRatemenuid(),
              rateMenuInfo.getContractcapacity());
      // ビジネスの実行
      comonBusinessBeanList.add(this.executeOnlineCommonBusiness(
          comonBusinessBean, rateCalculationBaseDate));

    }
    return comonBusinessBeanList;
  }

  /**
   * 料金計算オンライン共通Bean作成
   *
   * @param rateMenuInfoBean
   *          料金メニュー毎計算結果Bean
   * @return 料金計算オンライン共通Bean
   */
  private RK_OnlineCommonBusinessBean createOnlineCommonBusinessInfo(
      RK_UsePeriodRateMenuInfoBean usePeriodBean, String rateMenuId,
      BigDecimal contractCapacity) {

    RK_OnlineCommonBusinessBean commonBusinessBean = new RK_OnlineCommonBusinessBean();

    Rm rm = new Rm();
    rm.setRmId(rateMenuId);
    // 料金メニュー
    commonBusinessBean.setRateMenu(rm);
    // 利用年月
    commonBusinessBean.setUsePeriod(usePeriodBean.getUseperiod());
    // 契約容量
    commonBusinessBean.setContractCapacity(contractCapacity);
    // 確定使用量(最新)
    commonBusinessBean.setFixUsageLatest(usePeriodBean.getFixusage());
    // 確定指示数(最新)
    commonBusinessBean.setFixIndicationNoLatest(usePeriodBean.getFixin());
    // 時間帯別使用量(最新)
    commonBusinessBean.setTimeSlotUsageLatestList(usePeriodBean
        .getTimeslotusagenewestlist());
    commonBusinessBean.setSupplementaryMenuList(new ArrayList<>());

    return commonBusinessBean;
  }

  /**
   * 料金計算オンライン共通ビジネス呼び出し
   *
   * @param businessBean
   *          料金計算オンライン共通ビジネスBean
   * @param upBaseDate
   *          単価基準日
   * @return 料金計算オンライン共通ビジネスBean
   */
  private RK_OnlineCommonBusinessBean executeOnlineCommonBusiness(
      RK_OnlineCommonBusinessBean businessBean,
      Date upBaseDate) {

    // 2016/07/01 料金シミュレーション不具合対応 Mod Start
    // ダミーの日付を使う処理をやめ、利用年月は算定期間終了日から算出
    //		// 利用年月(ダミー )
    //		String dummyUsePeriod = StringConvertUtil.convertDateToString(
    //				rateCalculationBaseDate, EMSConstants.FORMAT_DATE_YYYYMM);
    //		// 利用年月(バックアップ)
    //		String bkUsePeriod = businessBean.getFixUsageLatest().getUsePeriod();
    //		// 終了日用のカレンダー
    //		Calendar cal = Calendar.getInstance();
    //		cal.setTime(rateCalculationBaseDate);
    //		cal.add(Calendar.MONTH, 1);
    //
    //		// 利用年月をダミー化
    //		businessBean.getFixUsageLatest().setUsePeriod(dummyUsePeriod);
    //		// 使用開始日をダミー化
    //		businessBean.getFixUsageLatest().setUsageSd(rateCalculationBaseDate);
    //		// 使用終了日をダミー化
    //		businessBean.getFixUsageLatest().setUsageEd(cal.getTime());
    //
    //		// シミュレーション実行
    //		rkOnlineCommonBusiness.rateSimulation(businessBean);
    //
    //		// ダミー化した利用年月を元に戻す。
    //		businessBean.getFixUsageLatest().setUsePeriod(bkUsePeriod);

    // 利用年月は算定期間の終了日から
    String usePeriod = StringConvertUtil.convertDateToString(
        businessBean.getFixUsageLatest().getUsageEd(), ECISConstants.FORMAT_DATE_yyyyMM);
    businessBean.setUsePeriod(usePeriod);
    // シミュレーション実行
    rkOnlineCommonBusiness.rateSimulation(businessBean, upBaseDate);
    // 2016/07/01 料金シミュレーション不具合対応 Mod End

    return businessBean;
  }

  /**
   * rmMapperのセッター(DI)
   *
   * @param rmMapper
   */
  public void setRmMapper(RmMapper rmMapper) {
    this.rmMapper = rmMapper;
  }

  /**
   * 料金計算オンライン共通ビジネスのセッター(DI)
   *
   * @param rkOnlineCommonBusiness
   *          料金計算オンライン共通ビジネス
   */
  public void setRkOnlineCommonBusiness(
      RK_OnlineCommonBusiness rkOnlineCommonBusiness) {
    this.rkOnlineCommonBusiness = rkOnlineCommonBusiness;
  }
}
