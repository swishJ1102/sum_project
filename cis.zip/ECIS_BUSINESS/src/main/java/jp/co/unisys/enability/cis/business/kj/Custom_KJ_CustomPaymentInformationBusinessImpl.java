package jp.co.unisys.enability.cis.business.kj;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DuplicateKeyException;

import jp.co.unisys.enability.cis.business.kj.model.Custom_DeleteCustomPaymentBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.Custom_RegistCustomPaymentBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.Custom_UpdateCustomPaymentBusinessBean;
import jp.co.unisys.enability.cis.common.util.KJ_CommonUtil;
import jp.co.unisys.enability.cis.common.util.ThreadContext;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISKJConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISReturnCodeConstants;
import jp.co.unisys.enability.cis.entity.common.CPaymentHist;
import jp.co.unisys.enability.cis.entity.common.CPaymentHistExample;
import jp.co.unisys.enability.cis.mapper.common.CPaymentHistMapper;

/**
 * 支払情報ビジネス_カスタムクラス
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.kj.Custom_KJ_CustomPaymentInformationBusiness
 *
 *      変更履歴(kg-epj) 2016.02.22 芦垣 新規作成
 *
 */
public class Custom_KJ_CustomPaymentInformationBusinessImpl implements
    Custom_KJ_CustomPaymentInformationBusiness {

  /**
   * カスタム支払履歴情報マッパー(DI)
   */
  private CPaymentHistMapper paymentHistMapper;
  /**
   * updatecount設定値
   */
  private static final int INT_CNT_ZERO = 0;
  /**
   * メッセージプロパティ(DI)
   */
  private MessageSource messageSource;

  /**
   * ログマネジャー
   */
  private static Logger logger = LogManager.getLogger();

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.kj.Cutom_KJ_CustomPaymentInformationBusiness#
   * regist
   * (jp.co.unisys.enability.cis.business.kj.model.Custom_RegistCustomPaymentBusinessBean)
   */
  @Override
  public Custom_RegistCustomPaymentBusinessBean regist(
      Custom_RegistCustomPaymentBusinessBean registPaymentBusinessBean) {

    String errorMessageG017 = null;
    String errorMessageD023 = null;

    try {

      // リターンコード(D023)に対応するメッセージを取得する。
      errorMessageD023 = messageSource.getMessage(KJ_CommonUtil.getMessageId(
          ECISReturnCodeConstants.RETURN_CODE_D023), new String[] {},
          Locale.getDefault());
      // リターンコード(G017)に対応するメッセージを取得する。
      errorMessageG017 = messageSource.getMessage(KJ_CommonUtil.getMessageId(
          ECISReturnCodeConstants.RETURN_CODE_G017), new String[] {},
          Locale.getDefault());

      //システム日時
      Date date = new Date();
      Timestamp sysDate = new Timestamp(date.getTime());

      // カスタム支払履歴情報設定
      CPaymentHist paymentHistory = new CPaymentHist();

      paymentHistory.setPaymentId(registPaymentBusinessBean.getPaymentId());
      paymentHistory.setPaymentSd(registPaymentBusinessBean.getPaymentStartDate());
      paymentHistory.setGasSupplyContractNo(registPaymentBusinessBean.getGasSupplyContractNo());
      paymentHistory.setGasPaymentNo(registPaymentBusinessBean.getGasPaymentNo());
      paymentHistory.setUpdateCount(INT_CNT_ZERO);
      paymentHistory.setCreateTime(sysDate);
      paymentHistory.setOnlineUpdateTime(sysDate);
      paymentHistory.setOnlineUpdateUserId(ThreadContext.getRequestThreadContext()
          .get(ECISConstants.USER_ID_KEY).toString());
      paymentHistory.setUpdateTime(sysDate);
      paymentHistory.setUpdateModuleCode(ThreadContext.getRequestThreadContext()
          .get(ECISConstants.CLASS_NAME_KEY).toString());

      // カスタム支払履歴情報登録
      paymentHistMapper.insert(paymentHistory);

      // リターンコード設定
      registPaymentBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);

    } catch (DuplicateKeyException e) {
      logger.error(errorMessageD023, e);
      // 重複エラー
      registPaymentBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D023);
      registPaymentBusinessBean.setMessage(errorMessageD023);
      return registPaymentBusinessBean;
    } catch (DataAccessException e) {
      logger.error(errorMessageG017, e);
      registPaymentBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      registPaymentBusinessBean.setMessage(errorMessageG017);
    } catch (NoSuchMessageException e) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, e);
      // メッセージプロパティ不在エラー
      registPaymentBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      registPaymentBusinessBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
      return registPaymentBusinessBean;
    }
    return registPaymentBusinessBean;
  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.kj.Custom_KJ_CustomPaymentInformationBusiness#
   * update
   * (jp.co.unisys.enability.cis.business.kj.model.Custom_UpdateCustomPaymentBusinessBean)
   */

  @Override
  public Custom_UpdateCustomPaymentBusinessBean update(
      Custom_UpdateCustomPaymentBusinessBean updatePaymentBusinessBean) {
    try {

      // カスタム支払履歴情報取得
      // Exampleの設定
      CPaymentHistExample cPaymentHistExample = new CPaymentHistExample();
      cPaymentHistExample.createCriteria().andPaymentIdEqualTo(updatePaymentBusinessBean.getPaymentId())
          .andPaymentSdEqualTo(updatePaymentBusinessBean.getPaymentStartDate());
      //《カスタム支払履歴Mapper》呼び出し
      List<CPaymentHist> cPaymentHistList = paymentHistMapper.selectByExample(cPaymentHistExample);

      // [kg-epj:JTS-22]<d-start>
      //			//件数0件
      //			if(CollectionUtils.isEmpty(cPaymentHistList)){
      //				setMessageAndReturnCode(updatePaymentBusinessBean,
      //						ECISReturnCodeConstants.RETURN_CODE_H001);
      //
      //				return updatePaymentBusinessBean;
      //			}
      //
      //			// 外部システム合算契約番号が設定されている場合、以下を設定する。
      //			String gasSupplyContractNo = updatePaymentBusinessBean
      //					.getGasSupplyContractNo();
      //			if (gasSupplyContractNo != null) {
      //				// 外部システム合算契約番号のハイフンを除去
      //				gasSupplyContractNo = gasSupplyContractNo.replace(
      //						ECISConstants.HYPHEN, "");
      //			}
      //
      //			// 外部システム支払番号が設定されている場合、以下を設定する。
      //			String gasPaymentNo = updatePaymentBusinessBean
      //					.getGasPaymentNo();
      //			if (gasPaymentNo != null) {
      //				// 外部システム支払番号のハイフンを除去
      //				gasPaymentNo = gasPaymentNo.replace(
      //						ECISConstants.HYPHEN, "");
      //			}
      //
      //			// 支払情報更新
      //			Date date = new Date();
      //			Timestamp sysDate = new Timestamp(date.getTime());
      //
      //				// 初期化
      //				CPaymentHist paymentHistory = new CPaymentHist();
      //
      //				// カスタム支払履歴情報更新
      //				paymentHistory.setPaymentId(updatePaymentBusinessBean.getPaymentId());
      //				paymentHistory.setPaymentSd(updatePaymentBusinessBean.getPaymentStartDate());
      //				paymentHistory.setGasSupplyContractNo(gasSupplyContractNo);
      //				paymentHistory.setGasPaymentNo(gasPaymentNo);
      //				paymentHistory.setUpdateCount(cPaymentHistList.get(0).getUpdateCount() +1);
      //				paymentHistory.setCreateTime(cPaymentHistList.get(0).getCreateTime());
      //				paymentHistory.setOnlineUpdateTime(sysDate);
      //				paymentHistory.setOnlineUpdateUserId(ThreadContext.getRequestThreadContext()
      //						.get(ECISConstants.USER_ID_KEY).toString());
      //				paymentHistory.setUpdateTime(sysDate);
      //				paymentHistory.setUpdateModuleCode(ThreadContext.getRequestThreadContext()
      //						.get(ECISConstants.CLASS_NAME_KEY).toString());
      //
      //				//《カスタム支払履歴Example》の生成
      //				CPaymentHistExample paymentHistoryExample = new CPaymentHistExample();
      //
      //				//Exampleの条件の設定
      //				paymentHistoryExample.createCriteria().andPaymentIdEqualTo(updatePaymentBusinessBean.getPaymentId())
      //				.andPaymentSdEqualTo(updatePaymentBusinessBean.getPaymentStartDate());
      //
      //				int updateByExampleCnt = paymentHistMapper
      //						.updateByExample(paymentHistory, paymentHistoryExample);
      //				// 件数0
      //				if (updateByExampleCnt == 0) {
      //					setMessageAndReturnCode(updatePaymentBusinessBean,
      //							ECISReturnCodeConstants.RETURN_CODE_H001);
      //
      //					return updatePaymentBusinessBean;
      //			}
      // [kg-epj:JTS-22]<d-end>
      // [kg-epj:JTS-22]<i-start>
      //件数0件
      if (CollectionUtils.isEmpty(cPaymentHistList)) {

        //システム日時
        Date date = new Date();
        Timestamp sysDate = new Timestamp(date.getTime());

        // カスタム支払履歴情報設定
        CPaymentHist paymentHistory = new CPaymentHist();

        paymentHistory.setPaymentId(updatePaymentBusinessBean.getPaymentId());
        paymentHistory.setPaymentSd(updatePaymentBusinessBean.getPaymentStartDate());
        paymentHistory.setGasSupplyContractNo(updatePaymentBusinessBean.getGasSupplyContractNo());
        paymentHistory.setGasPaymentNo(updatePaymentBusinessBean.getGasPaymentNo());
        paymentHistory.setUpdateCount(INT_CNT_ZERO);
        paymentHistory.setCreateTime(sysDate);
        paymentHistory.setOnlineUpdateTime(sysDate);
        paymentHistory.setOnlineUpdateUserId(ThreadContext.getRequestThreadContext()
            .get(ECISConstants.USER_ID_KEY).toString());
        paymentHistory.setUpdateTime(sysDate);
        paymentHistory.setUpdateModuleCode(ThreadContext.getRequestThreadContext()
            .get(ECISConstants.CLASS_NAME_KEY).toString());

        // カスタム支払履歴情報登録
        paymentHistMapper.insert(paymentHistory);

      } else {

        // 支払情報更新
        Date date = new Date();
        Timestamp sysDate = new Timestamp(date.getTime());

        // 初期化
        CPaymentHist paymentHistory = new CPaymentHist();

        // カスタム支払履歴情報更新
        paymentHistory.setPaymentId(updatePaymentBusinessBean.getPaymentId());
        paymentHistory.setPaymentSd(updatePaymentBusinessBean.getPaymentStartDate());
        paymentHistory.setGasSupplyContractNo(updatePaymentBusinessBean.getGasSupplyContractNo());
        paymentHistory.setGasPaymentNo(updatePaymentBusinessBean.getGasPaymentNo());
        paymentHistory.setUpdateCount(cPaymentHistList.get(0).getUpdateCount() + 1);
        paymentHistory.setCreateTime(cPaymentHistList.get(0).getCreateTime());
        paymentHistory.setOnlineUpdateTime(sysDate);
        paymentHistory.setOnlineUpdateUserId(ThreadContext.getRequestThreadContext()
            .get(ECISConstants.USER_ID_KEY).toString());
        paymentHistory.setUpdateTime(sysDate);
        paymentHistory.setUpdateModuleCode(ThreadContext.getRequestThreadContext()
            .get(ECISConstants.CLASS_NAME_KEY).toString());

        //《カスタム支払履歴Example》の生成
        CPaymentHistExample paymentHistoryExample = new CPaymentHistExample();

        //Exampleの条件の設定
        paymentHistoryExample.createCriteria().andPaymentIdEqualTo(updatePaymentBusinessBean.getPaymentId())
            .andPaymentSdEqualTo(updatePaymentBusinessBean.getPaymentStartDate());

        int updateByExampleCnt = paymentHistMapper
            .updateByExample(paymentHistory, paymentHistoryExample);
        // 件数0
        if (updateByExampleCnt == 0) {
          setMessageAndReturnCode(updatePaymentBusinessBean,
              ECISReturnCodeConstants.RETURN_CODE_H001);

          return updatePaymentBusinessBean;
        }

      }
      // [kg-epj:JTS-22]<i-end>

      updatePaymentBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);

      return updatePaymentBusinessBean;

    } catch (NoSuchMessageException e) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, e);
      // メッセージプロパティ不在エラー
      updatePaymentBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      updatePaymentBusinessBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
      return updatePaymentBusinessBean;
    }
  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.kj.Custom_KJ_CustomPaymentInformationBusiness#
   * delete
   * (jp.co.unisys.enability.cis.business.kj.model.Custom_DeleteCustomPaymentBusinessBean)
   */
  @Override
  public Custom_DeleteCustomPaymentBusinessBean delete(
      Custom_DeleteCustomPaymentBusinessBean deletePaymentBusinessBean) {

    try {

      // 支払履歴削除
      CPaymentHistExample deletePaymentHistoryExample = new CPaymentHistExample();
      deletePaymentHistoryExample
          .createCriteria()
          .andPaymentIdEqualTo(
              deletePaymentBusinessBean
                  .getPaymentId())
          .andPaymentSdEqualTo(
              deletePaymentBusinessBean.getPaymentStartDate());

      int deleteByExampleCnt = paymentHistMapper
          .deleteByExample(deletePaymentHistoryExample);

      // 返却値が0件の場合
      if (deleteByExampleCnt == 0) {
        setMessageAndReturnCode(deletePaymentBusinessBean,
            ECISReturnCodeConstants.RETURN_CODE_H001);

        return deletePaymentBusinessBean;
      }

      deletePaymentBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);

      return deletePaymentBusinessBean;

    } catch (NoSuchMessageException e) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, e);
      // メッセージプロパティ不在
      deletePaymentBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      deletePaymentBusinessBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);

      return deletePaymentBusinessBean;
    }

  }

  /**
   * ビーンに入力があった場合ビーン項目を、ない場合エンティティ項目を返す。
   *
   * @param beanItem
   * @param oldHistItem
   * @return
   */
  public Object setInheritingItem(Object beanItem, Object oldHistItem) {
    // 入力ありの場合
    if (beanItem != null) {
      return beanItem;
    } else {
      // 入力なしの場合
      return oldHistItem;
    }
  }

  /**
   * カスタム支払情報更新ビジネスビーンのリターンコードとメッセージを設定する。
   *
   * @param prop
   *          プロパティ
   * @param bean
   *          支払情報更新ビジネスビーン
   * @param returnCode
   *          リターンコード
   */
  private void setMessageAndReturnCode(Custom_UpdateCustomPaymentBusinessBean bean,
      String returnCode) throws NoSuchMessageException {

    bean.setReturnCode(returnCode);
    bean.setMessage(getPropertiesMesseage(returnCode));

  }

  /**
   * 支払情報削除ビジネスビーンのリターンコードとメッセージを設定する。
   *
   * @param prop
   *          プロパティ
   * @param bean
   *          支払情報削除ビジネスビーン
   * @param returnCode
   *          リターンコード
   */
  private void setMessageAndReturnCode(Custom_DeleteCustomPaymentBusinessBean bean,
      String returnCode) throws NoSuchMessageException {

    bean.setReturnCode(returnCode);
    bean.setMessage(getPropertiesMesseage(returnCode));

  }

  /**
   * プロパティからリターンコードに対応するメッセージを取得する
   *
   * @param prop
   *          プロパティ
   * @param returnCode
   *          リターンコード
   * @return
   */
  private String getPropertiesMesseage(String returnCode)
      throws NoSuchMessageException {
    return messageSource.getMessage(KJ_CommonUtil.getMessageId(returnCode),
        new String[] {}, Locale.getDefault());
  }

  /**
   * 支払履歴情報マッパーのセッター(DI)
   *
   * @param 支払履歴情報マッパー
   */
  public void setPaymentHistoryMapper(CPaymentHistMapper paymentHistMapper) {
    this.paymentHistMapper = paymentHistMapper;
  }

  /**
   * メッセージプロパティのセッター(DI)
   *
   * @param メッセージプロパティ
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }

}
