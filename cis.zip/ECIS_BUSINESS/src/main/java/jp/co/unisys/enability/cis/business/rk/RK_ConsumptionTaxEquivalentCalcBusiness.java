package jp.co.unisys.enability.cis.business.rk;

import jp.co.unisys.enability.cis.business.rk.model.RK_ConsumptionTaxEquivalentCalcBusinessBean;

/**
 * 消費税等相当額計算ビジネスインターフェース
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.mapper.common.CtRateMMapper
 */
public interface RK_ConsumptionTaxEquivalentCalcBusiness {

  /**
   * 消費税相当額計算処理を行う。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 1. 外部定義ファイルに設定された消費税率判定方法により、基準日を設定する。
   * 2. 基準日を元に、消費税率マスタから消費税率を取得する。
   * 3. 引数の金額、2で取得した消費税率を元に、消費税額を計算する。
   * 4. 計算結果を戻り値に設定し、返却する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param consumptionTaxEquivalentCalcBusinessBean
   *          消費税等相当額計算ビジネスBean
   * @return 消費税等相当額計算ビジネスBean
   * @see jp.co.unisys.enability.cis.mapper.common.CtRateMMapper
   */
  public RK_ConsumptionTaxEquivalentCalcBusinessBean calculate(
      RK_ConsumptionTaxEquivalentCalcBusinessBean consumptionTaxEquivalentCalcBusinessBean);

}
