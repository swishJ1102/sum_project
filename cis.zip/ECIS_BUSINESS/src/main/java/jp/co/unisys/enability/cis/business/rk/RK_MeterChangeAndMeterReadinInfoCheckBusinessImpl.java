package jp.co.unisys.enability.cis.business.rk;

import jp.co.unisys.enability.cis.business.rk.model.RK_ChargeCalcWarningCheckBusinessBean;
import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;
import jp.co.unisys.enability.cis.entity.common.McSmrInfoExample;
import jp.co.unisys.enability.cis.mapper.common.McSmrInfoMapper;

/**
 * BRK0103-03計量器交換、臨時検針情報の取込チェックビジネス
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.common.DateBusiness
 * @see jp.co.unisys.enability.cis.dao.rk.RK_ChargeCalcWarningCheckDao
 */
public class RK_MeterChangeAndMeterReadinInfoCheckBusinessImpl implements
    RK_ChargeCalcWarningCheckBusiness {

  /**
   * 計器交換・臨時検針情報Mapper
   */
  private McSmrInfoMapper mcSmrInfoMapper;

  /**
   * 計量器交換、臨時検針情報の取込チェックビジネス
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param chargeCalcWarningCheckBean
   *          《料金計算警告チェックビジネスBean》
   * @return 警告コード
   * @see jp.co.unisys.enability.cis.business.common.DateBusiness
   * @see jp.co.unisys.enability.cis.dao.rk.RK_ChargeCalcWarningCheckDao
   */
  @Override
  public String check(
      RK_ChargeCalcWarningCheckBusinessBean chargeCalcWarningCheckBean) {

    // 実計器交換・臨時検針情報の取込状況を取得する。
    // 実計器交換・臨時検針情報Example
    McSmrInfoExample mcSmrInfoExample = new McSmrInfoExample();
    //【実計器交換・臨時検針】を取得する条件を設定
    mcSmrInfoExample.createCriteria()
        //契約ID
        .andContractIdEqualTo(chargeCalcWarningCheckBean.getContractId())
        //対象年月
        .andCoveredPeriodEqualTo(chargeCalcWarningCheckBean.getUsePeriod());
    //計器交換・臨時検針情報Mapper.countByExampleを呼び出し、件数を取得する
    //変数.件数が１件以上の場合
    if (mcSmrInfoMapper.countByExample(mcSmrInfoExample) >= 1) {
      //戻り値に309 を設定する
      return ECISRKConstants.WARNING_CLASS_MASTER_MC_SMR_INFO;
    }
    //// 戻り値にnull を設定する。
    return null;
  }

  /**
   * 計器交換・臨時検針情報Mapperのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計器交換・臨時検針情報Mapperを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param cclMMaper
   *          計器交換・臨時検針情報Mapper
   */
  public void setMcSmrInfoMapper(McSmrInfoMapper mcSmrInfoMapper) {
    this.mcSmrInfoMapper = mcSmrInfoMapper;
  }

}
