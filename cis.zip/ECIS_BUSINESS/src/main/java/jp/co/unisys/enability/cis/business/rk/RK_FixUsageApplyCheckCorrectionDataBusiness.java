package jp.co.unisys.enability.cis.business.rk;

import jp.co.unisys.enability.cis.business.rk.model.RK_FixUsageApplyDataBusinessBean;

/**
 * 訂正データチェックビジネスインターフェース。
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.mapper.common.FcrMapper
 * @see jp.co.unisys.enability.cis.mapper.common.FcrWarningDataMapper
 * @see jp.co.unisys.enability.cis.business.common.TodoBusiness
 */
public interface RK_FixUsageApplyCheckCorrectionDataBusiness {

  /**
   * 確定使用量メッセージが訂正データかチェックし、TODOの登録等を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 確定使用量メッセージが訂正データかチェックし、計算結果の状態に応じて、
   * TODOや警告の登録を行う。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param applyDataBusinessBean
   *          確定使用量メッセージの情報を保持するBean
   * @see jp.co.unisys.enability.cis.mapper.common.FcrMapper
   * @see jp.co.unisys.enability.cis.mapper.common.FcrWarningDataMapper
   * @see jp.co.unisys.enability.cis.business.common.TodoBusiness
   */
  public abstract void check(RK_FixUsageApplyDataBusinessBean applyDataBusinessBean);
}
