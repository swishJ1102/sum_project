package jp.co.unisys.enability.cis.business.sn.model;

import java.io.Serializable;
import java.util.Date;

/**
 * 請求入金画面表示請求情報ビジネスBean. 画面に表示する請求情報を保持するBeanクラス
 *
 * @author "Nihon Unisys, Ltd."
 */
public class SN_ScreenBillingInfoBusinessBean implements Serializable {

  /** シリアルバージョンID */
  private static final long serialVersionUID = 1L;

  /** 請求ID */
  private Integer billingId;

  /** 請求番号 */
  private String billingNo;

  /** ご利用年月 */
  private String usePeriod;

  /** 請求額 */
  private Long billingAmount;

  /** 支払期日 */
  private Date paymentFixedDate;

  /** 請求ステータス */
  private String billingStatus;

  /** 督促ステータス */
  private String urgeStatus;

  /** ご利用金額 */
  private Long useAmount;

  /** 請求更新回数 */
  private Integer billingUpdateCnt;

  /** 督促管理更新回数 */
  private Integer urgeMngUpdateCnt;

  /** 請求ステータスコード */
  private String billingStatusCode;

  /** 督促ステータスコード */
  private String urgeStatusCode;

  /**
   * 請求IDを設定する。
   *
   * @param billingId
   *          請求ID
   */
  public void setBillingId(Integer billingId) {
    this.billingId = billingId;
  }

  /**
   * 請求IDを取得する。
   *
   * @return 請求ID
   */
  public Integer getBillingId() {
    return this.billingId;
  }

  /**
   * 請求番号を設定する。
   *
   * @param billingNo
   *          請求番号
   */
  public void setBillingNo(String billingNo) {
    this.billingNo = billingNo;
  }

  /**
   * 請求番号を取得する。
   *
   * @return 請求番号
   */
  public String getBillingNo() {
    return this.billingNo;
  }

  /**
   * ご利用年月を設定する。
   *
   * @param usePeriod
   *          ご利用年月
   */
  public void setUsePeriod(String usePeriod) {
    this.usePeriod = usePeriod;
  }

  /**
   * ご利用年月を取得する。
   *
   * @return ご利用年月
   */
  public String getUsePeriod() {
    return this.usePeriod;
  }

  /**
   * 請求額を設定する。
   *
   * @param billingAmount
   *          請求額
   */
  public void setBillingAmount(Long billingAmount) {
    this.billingAmount = billingAmount;
  }

  /**
   * 請求額を取得する。
   *
   * @return 請求額
   */
  public Long getBillingAmount() {
    return this.billingAmount;
  }

  /**
   * 支払期日を設定する。
   *
   * @param paymentFixedDate
   *          支払期日
   */
  public void setPaymentFixedDate(Date paymentFixedDate) {
    this.paymentFixedDate = paymentFixedDate;
  }

  /**
   * 支払期日を取得する。
   *
   * @return 支払期日
   */
  public Date getPaymentFixedDate() {
    return this.paymentFixedDate;
  }

  /**
   * 請求ステータスを設定する。
   *
   * @param billingStatus
   *          請求ステータス
   */
  public void setBillingStatus(String billingStatus) {
    this.billingStatus = billingStatus;
  }

  /**
   * 請求ステータスを取得する。
   *
   * @return 請求ステータス
   */
  public String getBillingStatus() {
    return this.billingStatus;
  }

  /**
   * 督促ステータスを設定する。
   *
   * @param urgeStatus
   *          督促ステータス
   */
  public void setUrgeStatus(String urgeStatus) {
    this.urgeStatus = urgeStatus;
  }

  /**
   * 督促ステータスを取得する。
   *
   * @return 督促ステータス
   */
  public String getUrgeStatus() {
    return this.urgeStatus;
  }

  /**
   * ご利用金額を設定する。
   *
   * @param useAmount
   *          ご利用金額
   */
  public void setUseAmount(Long useAmount) {
    this.useAmount = useAmount;
  }

  /**
   * ご利用金額を取得する。
   *
   * @return ご利用金額
   */
  public Long getUseAmount() {
    return this.useAmount;
  }

  /**
   * 請求更新回数を設定する。
   *
   * @param billingUpdateCnt
   *          請求更新回数
   */
  public void setBillingUpdateCnt(Integer billingUpdateCnt) {
    this.billingUpdateCnt = billingUpdateCnt;
  }

  /**
   * 請求更新回数を取得する。
   *
   * @return 請求更新回数
   */
  public Integer getBillingUpdateCnt() {
    return this.billingUpdateCnt;
  }

  /**
   * 督促管理更新回数を設定する。
   *
   * @param urgeMngUpdateCnt
   *          督促管理更新回数
   */
  public void setUrgeMngUpdateCnt(Integer urgeMngUpdateCnt) {
    this.urgeMngUpdateCnt = urgeMngUpdateCnt;
  }

  /**
   * 督促管理更新回数を取得する。
   *
   * @return 督促管理更新回数
   */
  public Integer getUrgeMngUpdateCnt() {
    return this.urgeMngUpdateCnt;
  }

  /**
   * 請求ステータスコードを取得する。
   *
   * @return billingStatusCode 請求ステータスコード
   */
  public String getBillingStatusCode() {
    return billingStatusCode;
  }

  /**
   * 請求ステータスコードを設定する。
   *
   * @param billingStatusCode
   *          請求ステータスコード
   */
  public void setBillingStatusCode(String billingStatusCode) {
    this.billingStatusCode = billingStatusCode;
  }

  /**
   * 督促ステータスコードを取得する。
   *
   * @return urgeStatusCode 督促ステータス
   */
  public String getUrgeStatusCode() {
    return urgeStatusCode;
  }

  /**
   * 督促ステータスコードを設定する。
   *
   * @param urgeStatusCode
   *          督促ステータスコード
   */
  public void setUrgeStatusCode(String urgeStatusCode) {
    this.urgeStatusCode = urgeStatusCode;
  }

}