package jp.co.unisys.enability.cis.business.kj.model;

import java.util.Date;
import java.util.List;

import jp.co.unisys.enability.cis.entity.kj.KJ_InquiryMeterLocationEntityBean;

/**
 * メータ設置場所照会で、検索条件および検索結果を格納するエンティティBean
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * メータ設置場所情報ビジネス
 * 契約情報ビジネス
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class InquiryMeterLocationBusinessBean {

  /**
   * メータ設置場所IDを保有する。
   */
  private Integer meterLocationId;

  /**
   * 契約IDを保有する。
   */
  private Integer contractId;

  /**
   * 契約番号を保有する。
   */
  private String contractNo;

  /**
   * 地点特定番号を保有する。
   */
  private String spotNo;

  /**
   * スマートメータ区分コードを保有する。
   */
  private String smartMeterCategoryCode;

  /**
   * 次回検針予定日を保有する。
   */
  private Date nextMeterReadingScheduledDate;

  /**
   * メータ設置場所照会リストを保有する。
   */
  private List<KJ_InquiryMeterLocationEntityBean> meterLocationList;

  /**
   * リターンコードを保有する。
   */
  private String returnCode;

  /**
   * メッセージを保有する。
   */
  private String message;

  /**
   * メータ設置場所IDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メータ設置場所IDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return メータ設置場所ID
   */
  public Integer getMeterLocationId() {
    return this.meterLocationId;
  }

  /**
   * メータ設置場所IDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メータ設置場所IDを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param meterLocationId
   *          メータ設置場所ID
   */
  public void setMeterLocationId(Integer meterLocationId) {
    this.meterLocationId = meterLocationId;
  }

  /**
   * 契約IDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約IDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約ID
   */
  public Integer getContractId() {
    return this.contractId;
  }

  /**
   * 契約IDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約IDを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractId
   *          契約ID
   */
  public void setContractId(Integer contractId) {
    this.contractId = contractId;
  }

  /**
   * 契約番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約番号を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約番号
   */
  public String getContractNo() {
    return this.contractNo;
  }

  /**
   * 契約番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約番号を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractNo
   *          契約番号
   */
  public void setContractNo(String contractNo) {
    this.contractNo = contractNo;
  }

  /**
   * 地点特定番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 地点特定番号を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 地点特定番号
   */
  public String getSpotNo() {
    return this.spotNo;
  }

  /**
   * 地点特定番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 地点特定番号を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param spotNo
   *          地点特定番号
   */
  public void setSpotNo(String spotNo) {
    this.spotNo = spotNo;
  }

  /**
   * スマートメータ区分コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * スマートメータ区分コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return スマートメータ区分コード
   */
  public String getSmartMeterCategoryCode() {
    return smartMeterCategoryCode;
  }

  /**
   * スマートメータ区分コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * スマートメータ区分コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param smartMeterCategoryCode
   *          スマートメータ区分コード
   */
  public void setSmartMeterCategoryCode(String smartMeterCategoryCode) {
    this.smartMeterCategoryCode = smartMeterCategoryCode;
  }

  /**
   * 次回検針予定日のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 次回検針予定日を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 次回検針予定日
   */
  public Date getNextMeterReadingScheduledDate() {
    return nextMeterReadingScheduledDate;
  }

  /**
   * 次回検針予定日のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 次回検針予定日を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param nextMeterReadingScheduledDate
   *          次回検針予定日
   */
  public void setNextMeterReadingScheduledDate(
      Date nextMeterReadingScheduledDate) {
    this.nextMeterReadingScheduledDate = nextMeterReadingScheduledDate;
  }

  /**
   * メータ設置場所照会リストのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メータ設置場所照会リストを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return メータ設置場所照会リスト
   */
  public List<KJ_InquiryMeterLocationEntityBean> getMeterLocationList() {
    return meterLocationList;
  }

  /**
   * メータ設置場所照会リストのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メータ設置場所照会リストを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param meterLocationList
   *          メータ設置場所照会リスト
   */
  public void setMeterLocationList(
      List<KJ_InquiryMeterLocationEntityBean> meterLocationList) {
    this.meterLocationList = meterLocationList;
  }

  /**
   * リターンコードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return リターンコード
   */
  public String getReturnCode() {
    return returnCode;
  }

  /**
   * リターンコードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param returnCode
   *          リターンコード
   */
  public void setReturnCode(String returnCode) {
    this.returnCode = returnCode;
  }

  /**
   * メッセージのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return メッセージ
   */
  public String getMessage() {
    return message;
  }

  /**
   * メッセージのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param message
   *          メッセージ
   */
  public void setMessage(String message) {
    this.message = message;
  }
}
