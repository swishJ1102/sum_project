/*-------------------------------------------------------------------------------
 * All Rights Reserved. Copyright(C) Nihon Unisys, Ltd.
 * vendor : Nihon Unisys, Ltd.
 * create : 2016/04/20
 *-----------------------------------------------------------------------------*/
package jp.co.unisys.enability.cis.business.rk.model;

import java.util.List;

import jp.co.unisys.enability.cis.entity.common.FixIn;
import jp.co.unisys.enability.cis.entity.common.Fu;
import jp.co.unisys.enability.cis.entity.common.TsUsage;

/**
 * 卸取次店向け契約情報検索APIのリクエスト情報を保持するBeanクラス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_UsePeriodRateMenuInfoBean {

  /**
   * 利用年月を保有する。
   */
  private String usePeriod;

  /**
   * 確定使用量を保有する。
   */
  private Fu fixUsage;

  /**
   * 確定指示数を保有する。
   */
  private FixIn fixIn;

  /**
   * 時間帯別使用量リストを保有する。
   */
  private List<TsUsage> timeSlotUsageNewestList;

  /**
   * 使用量ビジネスBeanリストを保有する。
   */
  private List<RK_FixUsageApplyUsageBusinessBean> fixUsageApplyUsageBusinessBeanList;

  /**
   * 利用年月のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 利用年月を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 利用年月
   */
  public String getUseperiod() {
    return usePeriod;
  }

  /**
   * 利用年月のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 利用年月を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return usePeriod 利用年月
   */
  public void setUseperiod(String usePeriod) {
    this.usePeriod = usePeriod;

  }

  /**
   * 確定使用量のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 確定使用量を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 確定使用量
   */
  public Fu getFixusage() {
    return fixUsage;
  }

  /**
   * 確定使用量のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 確定使用量を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return fixUsage 確定使用量
   */
  public void setFixusage(Fu fixUsage) {
    this.fixUsage = fixUsage;

  }

  /**
   * 確定指示数のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 確定指示数を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 確定指示数
   */
  public FixIn getFixin() {
    return fixIn;
  }

  /**
   * 確定指示数のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 確定指示数を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return fixIn 確定指示数
   */
  public void setFixin(FixIn fixIn) {
    this.fixIn = fixIn;

  }

  /**
   * 時間帯別使用量リストのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 時間帯別使用量リストを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 時間帯別使用量リスト
   */
  public List<TsUsage> getTimeslotusagenewestlist() {
    return timeSlotUsageNewestList;
  }

  /**
   * 時間帯別使用量リストのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 時間帯別使用量リストを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return timeSlotUsageNewestList 時間帯別使用量リスト
   */
  public void setTimeslotusagenewestlist(List<TsUsage> timeSlotUsageNewestList) {
    this.timeSlotUsageNewestList = timeSlotUsageNewestList;

  }

  /**
   * 使用量ビジネスBeanリストのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 使用量ビジネスBeanリストを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 使用量ビジネスBeanリスト
   */
  public List<RK_FixUsageApplyUsageBusinessBean> getFixusageapplyusagebusinessbeanlist() {
    return fixUsageApplyUsageBusinessBeanList;
  }

  /**
   * 使用量ビジネスBeanリストのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 使用量ビジネスBeanリストを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return fixUsageApplyUsageBusinessBeanList 使用量ビジネスBeanリスト
   */
  public void setFixusageapplyusagebusinessbeanlist(
      List<RK_FixUsageApplyUsageBusinessBean> fixUsageApplyUsageBusinessBeanList) {
    this.fixUsageApplyUsageBusinessBeanList = fixUsageApplyUsageBusinessBeanList;

  }
}
