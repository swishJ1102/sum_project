package jp.co.unisys.enability.cis.business.rk.model;

import java.math.BigDecimal;
import java.util.Date;

/**
 * 料金メニュー検索APIの検索結果で、付帯メニュー単価の情報を保持するビジネスクラス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_SearchRateMenuSupplementaryMenuUPBusinessBean {

  /**
   * 額・率を保有する。
   */
  private BigDecimal amountOrRate;

  /**
   * 上限額を保有する。
   */
  private BigDecimal maximumAmount;

  /**
   * 下限額を保有する。
   */
  private BigDecimal minimumAmount;

  /**
   * 適用開始日を保有する。
   */
  private Date applyStartDate;

  /**
   * 適用終了日を保有する。
   */
  private Date applyEndDate;

  /**
   * 額・率のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 額・率を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 額・率
   */
  public BigDecimal getAmountOrRate() {
    return this.amountOrRate;
  }

  /**
   * 額・率のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 額・率を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param amountOrRate
   *          額・率
   */
  public void setAmountOrRate(BigDecimal amountOrRate) {
    this.amountOrRate = amountOrRate;
  }

  /**
   * 上限額のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 上限額を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 上限額
   */
  public BigDecimal getMaximumAmount() {
    return this.maximumAmount;
  }

  /**
   * 上限額のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 上限額を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param maximumAmount
   *          上限額
   */
  public void setMaximumAmount(BigDecimal maximumAmount) {
    this.maximumAmount = maximumAmount;
  }

  /**
   * 下限額のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 下限額を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 下限額
   */
  public BigDecimal getMinimumAmount() {
    return this.minimumAmount;
  }

  /**
   * 下限額のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 下限額を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param minimumAmount
   *          下限額
   */
  public void setMinimumAmount(BigDecimal minimumAmount) {
    this.minimumAmount = minimumAmount;
  }

  /**
   * 適用開始日のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 適用開始日を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 適用開始日
   */
  public Date getApplyStartDate() {
    return this.applyStartDate;
  }

  /**
   * 適用開始日のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 適用開始日を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param applyStartDate
   *          適用開始日
   */
  public void setApplyStartDate(Date applyStartDate) {
    this.applyStartDate = applyStartDate;
  }

  /**
   * 適用終了日のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 適用終了日を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 適用終了日
   */
  public Date getApplyEndDate() {
    return this.applyEndDate;
  }

  /**
   * 適用終了日のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 適用終了日を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param applyEndDate
   *          適用終了日
   */
  public void setApplyEndDate(Date applyEndDate) {
    this.applyEndDate = applyEndDate;
  }

}
