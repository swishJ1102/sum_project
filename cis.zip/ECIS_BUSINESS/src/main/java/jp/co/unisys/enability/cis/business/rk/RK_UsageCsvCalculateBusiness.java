package jp.co.unisys.enability.cis.business.rk;

import jp.co.unisys.enability.cis.business.rk.model.RK_UsageCsvCalculateBusinessBean;

public interface RK_UsageCsvCalculateBusiness {
  /**
   * 仕訳
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 仕訳を行います。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param RK_UsageCsvCalculateBusinessBean
   *          使用量CSV仕訳ビジネスBean
   * @throws Ecxeption
   *           業務例外が発生した場合
   * @return 使用量CSV仕訳ビジネスBean
   */
  RK_UsageCsvCalculateBusinessBean calculate(RK_UsageCsvCalculateBusinessBean usageCsvCalculateBusinessBean);

}
