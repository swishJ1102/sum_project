package jp.co.unisys.enability.cis.business.kj;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.config.PropertiesFactoryBean;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DuplicateKeyException;

import jp.co.unisys.enability.cis.business.common.DateBusiness;
import jp.co.unisys.enability.cis.business.kj.model.InquiryAgentMeterLocationBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.RegistAgentMeterLocationBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.UpdateAgentMeterLocationBusinessBean;
import jp.co.unisys.enability.cis.common.Exception.BusinessLogicException;
import jp.co.unisys.enability.cis.common.Exception.SystemException;
import jp.co.unisys.enability.cis.common.util.KJ_CommonUtil;
import jp.co.unisys.enability.cis.common.util.ThreadContext;
import jp.co.unisys.enability.cis.common.util.constants.ECISCodeConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISKJConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISReturnCodeConstants;
import jp.co.unisys.enability.cis.entity.common.AmrcM;
import jp.co.unisys.enability.cis.entity.common.AreaM;
import jp.co.unisys.enability.cis.entity.common.CdWayM;
import jp.co.unisys.enability.cis.entity.common.GlcM;
import jp.co.unisys.enability.cis.entity.common.Ml;
import jp.co.unisys.enability.cis.entity.common.MlAddInfo;
import jp.co.unisys.enability.cis.entity.common.MlExample;
import jp.co.unisys.enability.cis.entity.common.MrDateCatM;
import jp.co.unisys.enability.cis.entity.common.Place;
import jp.co.unisys.enability.cis.entity.common.PlaceExample;
import jp.co.unisys.enability.cis.entity.common.PrefectureM;
import jp.co.unisys.enability.cis.entity.common.SmCatM;
import jp.co.unisys.enability.cis.entity.common.SmM;
import jp.co.unisys.enability.cis.entity.common.TransmissionCatM;
import jp.co.unisys.enability.cis.entity.kj.KJ_InquiryAgentMeterLocationEntityBean;
import jp.co.unisys.enability.cis.mapper.common.AmrcMMapper;
import jp.co.unisys.enability.cis.mapper.common.AreaMMapper;
import jp.co.unisys.enability.cis.mapper.common.CdWayMMapper;
import jp.co.unisys.enability.cis.mapper.common.GlcMMapper;
import jp.co.unisys.enability.cis.mapper.common.MlAddInfoMapper;
import jp.co.unisys.enability.cis.mapper.common.MlMapper;
import jp.co.unisys.enability.cis.mapper.common.MrDateCatMMapper;
import jp.co.unisys.enability.cis.mapper.common.PlaceMapper;
import jp.co.unisys.enability.cis.mapper.common.PrefectureMMapper;
import jp.co.unisys.enability.cis.mapper.common.SmCatMMapper;
import jp.co.unisys.enability.cis.mapper.common.SmMMapper;
import jp.co.unisys.enability.cis.mapper.common.TransmissionCatMMapper;
import jp.co.unisys.enability.cis.mapper.kj.AgentMeterLocationInformationCommonMapper;
import jp.sf.orangesignal.csv.Csv;
import jp.sf.orangesignal.csv.CsvConfig;
import jp.sf.orangesignal.csv.QuotePolicy;
import jp.sf.orangesignal.csv.handlers.StringArrayListHandler;

/**
 * メータ設置場所ビジネス
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.kj.KJ_AgentMeterLocationInformationBusiness
 *
 */
public class KJ_AgentMeterLocationInformationBusinessImpl implements
    KJ_AgentMeterLocationInformationBusiness {

  /**
   * メータ設置場所共通Mapper(DI)
   */
  private AgentMeterLocationInformationCommonMapper meterLocationInformationCommonMapper;

  /**
   * エリアマスタMapper(DI)
   */
  private AreaMMapper areaMMapper;

  /**
   * 送受電区分マスタMapper(DI)
   */
  private TransmissionCatMMapper transmissionCatMMapper;

  /**
   * 自家発連携マスタMapper(DI)
   */
  private GlcMMapper glcMMapper;

  /**
   * 供給方式マスタMapper(DI)
   */
  private SmMMapper smMMapper;

  /**
   * 30分値収集可否・自動検針可否マスタMapper(DI)
   */
  private AmrcMMapper amrcMMapper;

  /**
   * スマートメータ区分マスタMapper(DI)
   */
  private SmCatMMapper smcatMMapper;

  /**
   * 都道府県マスタMapper(DI)
   */
  private PrefectureMMapper prefectureMMapper;

  /**
   * 契約決定方法マスタMapper(DI)
   */
  private CdWayMMapper cdWayMMapper;

  /**
   * メータ設置場所Mapper(DI)
   */
  private MlMapper mlMapper;

  /**
   * 需要場所Mapper(DI)
   */
  private PlaceMapper placeMapper;

  /**
   * メータ設置場所付加Mapper(DI)
   */
  private MlAddInfoMapper mlAddInfoMapper;

  /**
   * 検針日区分マスタMapper(DI)
   */
  private MrDateCatMMapper mrDateCatMMapper;

  /**
   * 日付関連共通ビジネス(DI)
   */
  private DateBusiness dateBusiness;

  /**
   * メッセージプロパティ(DI)
   */
  private MessageSource messageSource;

  /**
   * プロパティ（DI）
   */
  private PropertiesFactoryBean applicationProperties;

  /**
   * ログマネジャー
   */
  private static Logger logger = LogManager.getLogger();

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.kj.
   * KJ_AgentMeterLocationInformationBusiness
   * #inquiry(jp.co.unisys.enability.cis.business.kj.model.
   * InquiryAgentMeterLocationBusinessBean)
   */
  @Override
  public InquiryAgentMeterLocationBusinessBean inquiry(
      InquiryAgentMeterLocationBusinessBean inquiryMeterLocationBusinessBean) {

    // 変数の定義
    String inquiryPattern = null;
    Integer id = null;
    String no = null;
    String code = null;
    Date date = null;
    // 契約者情報照会条件Map
    Map<String, Object> exampleMap = new HashMap<String, Object>();

    try {
      // 各項目より、照会パターンを設定
      // （《メータ設置場所照会BusinessBean》.契約IDがNULLでない
      // または、《メータ設置場所照会BusinessBean》.契約番号がNULLまたは空文字のいずれでもない）
      // かつ その他の《メータ設置場所照会BusinessBean》項目に値が設定されていない場合、以下を設定する。
      if ((inquiryMeterLocationBusinessBean.getContractId() != null || StringUtils
          .isNotEmpty(inquiryMeterLocationBusinessBean
              .getContractNo()))
          && inquiryMeterLocationBusinessBean.getMeterLocationId() == null
          && StringUtils.isEmpty(inquiryMeterLocationBusinessBean
              .getSpotNo())
          && StringUtils.isEmpty(inquiryMeterLocationBusinessBean
              .getSmartMeterCategoryCode())
          && inquiryMeterLocationBusinessBean
              .getNextMeterReadingScheduledDate() == null) {
        // ID（変数）に《メータ設置場所照会BusinessBean》.契約IDを設定する。
        // 番号（変数）に《メータ設置場所照会BusinessBean》.契約番号を設定する。
        // 照会パターン（変数）に“1”を設定する。
        id = inquiryMeterLocationBusinessBean.getContractId();
        no = inquiryMeterLocationBusinessBean.getContractNo();
        inquiryPattern = ECISKJConstants.INQUIRY_PATTERN_1;
        // 《メータ設置場所照会BusinessBean》.メータ設置場所IDがNULLでない
        // かつ その他の《メータ設置場所照会BusinessBean》項目に値が設定されていない場合、以下を設定する。
      } else if (inquiryMeterLocationBusinessBean.getMeterLocationId() != null
          && inquiryMeterLocationBusinessBean.getContractId() == null
          && StringUtils.isEmpty(inquiryMeterLocationBusinessBean
              .getContractNo())
          && StringUtils.isEmpty(inquiryMeterLocationBusinessBean
              .getSpotNo())
          && StringUtils.isEmpty(inquiryMeterLocationBusinessBean
              .getSmartMeterCategoryCode())
          && inquiryMeterLocationBusinessBean
              .getNextMeterReadingScheduledDate() == null) {
        // ID（変数）に《メータ設置場所照会BusinessBean》.メータ設置場所IDを設定する。
        // 番号（変数）にNULLを設定する。
        // // 照会パターン（変数）に“2”を設定する。
        id = inquiryMeterLocationBusinessBean.getMeterLocationId();
        inquiryPattern = ECISKJConstants.INQUIRY_PATTERN_2;

        //《卸取次店向けメータ設置場所照会BusinessBean》.基準日判定除外フラグが"1"の場合
        // かつ《卸取次店向けメータ設置場所照会BusinessBean》.地点特定番号がNULLまたは空文字のいずれでもない
        // かつ その他の《卸取次店向けメータ設置場所照会BusinessBean》項目に値が設定されていない場合、以下を設定する。
      } else if (StringUtils.equals(ECISKJConstants.BASE_DATE_EXCLUDE_FLAG_ON,
          inquiryMeterLocationBusinessBean.getBaseDateExcludeFlag())
          && StringUtils.isNotEmpty(inquiryMeterLocationBusinessBean
              .getSpotNo())
          && inquiryMeterLocationBusinessBean.getContractId() == null
          && StringUtils.isEmpty(inquiryMeterLocationBusinessBean
              .getContractNo())
          && inquiryMeterLocationBusinessBean.getMeterLocationId() == null
          && StringUtils.isEmpty(inquiryMeterLocationBusinessBean
              .getSmartMeterCategoryCode())
          && inquiryMeterLocationBusinessBean
              .getNextMeterReadingScheduledDate() == null) {
        // ID（変数）にNULLを設定する。
        // 番号（変数）に《メータ設置場所照会BusinessBean》.地点特定番号を設定する。
        // 照会パターン（変数）に“5”を設定する。
        no = inquiryMeterLocationBusinessBean.getSpotNo();
        inquiryPattern = ECISKJConstants.INQUIRY_PATTERN_5;
        // 《メータ設置場所照会BusinessBean》.地点特定番号がNULLまたは空文字のいずれでもない
        // かつ その他の《メータ設置場所照会BusinessBean》項目に値が設定されていない場合、以下を設定する。
      } else if (StringUtils.isNotEmpty(inquiryMeterLocationBusinessBean
          .getSpotNo())
          && inquiryMeterLocationBusinessBean.getContractId() == null
          && StringUtils.isEmpty(inquiryMeterLocationBusinessBean
              .getContractNo())
          && inquiryMeterLocationBusinessBean.getMeterLocationId() == null
          && StringUtils.isEmpty(inquiryMeterLocationBusinessBean
              .getSmartMeterCategoryCode())
          && inquiryMeterLocationBusinessBean
              .getNextMeterReadingScheduledDate() == null) {
        // ID（変数）にNULLを設定する。
        // 番号（変数）に《メータ設置場所照会BusinessBean》.地点特定番号を設定する。
        // 照会パターン（変数）に“3”を設定する。
        no = inquiryMeterLocationBusinessBean.getSpotNo();
        inquiryPattern = ECISKJConstants.INQUIRY_PATTERN_3;
        // 《メータ設置場所照会BusinessBean》.スマートメータ区分コードがNULLまたは空文字のいずれでもない
        // かつ《メータ設置場所照会BusinessBean》.次回検針予定日がNULLでない
        // かつ その他の《メータ設置場所照会BusinessBean》項目に値が設定されていない場合、以下を設定する。
      } else if (StringUtils.isNotEmpty(inquiryMeterLocationBusinessBean
          .getSmartMeterCategoryCode())
          && inquiryMeterLocationBusinessBean
              .getNextMeterReadingScheduledDate() != null
          && inquiryMeterLocationBusinessBean.getContractId() == null
          && StringUtils.isEmpty(inquiryMeterLocationBusinessBean
              .getContractNo())
          && inquiryMeterLocationBusinessBean.getMeterLocationId() == null
          && StringUtils.isEmpty(inquiryMeterLocationBusinessBean
              .getSpotNo())) {
        // コード（変数）に《メータ設置場所照会BusinessBean》.スマートメータ区分コードを設定する。
        // 日付（変数）に《メータ設置場所照会BusinessBean》.次回検針予定日を設定する。
        // 照会パターン（変数）に“4”を設定する。
        code = inquiryMeterLocationBusinessBean
            .getSmartMeterCategoryCode();
        date = inquiryMeterLocationBusinessBean
            .getNextMeterReadingScheduledDate();
        inquiryPattern = ECISKJConstants.INQUIRY_PATTERN_4;
        // 上記以外の場合、《メータ設置場所照会BusinessBean》.リターンコードに（P001）を設定し返却する。
      } else {
        inquiryMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P001);
        inquiryMeterLocationBusinessBean
            .setMessage(getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P001),
                null));
        return inquiryMeterLocationBusinessBean;
      }
      // オンライン処理基準日
      Date onlineDate = this.getOnLineDate();
      // メータ設置場所取得
      exampleMap.put("id", id);
      exampleMap.put("no", no);
      exampleMap.put("code", code);
      exampleMap.put("date", date);
      exampleMap.put("inquiryPattern", inquiryPattern);
      exampleMap.put("onlineDate", onlineDate);
      List<KJ_InquiryAgentMeterLocationEntityBean> meterLocationList = meterLocationInformationCommonMapper
          .selectMeterLocation(exampleMap);
      // 戻り値を設定
      inquiryMeterLocationBusinessBean
          .setMeterLocationList(meterLocationList);
      inquiryMeterLocationBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);
      // 業務例外クラス(データアクセスエラーまたはオンライン処理基準日取得エラー)
    } catch (DataAccessException | BusinessLogicException e) {
      logger.error(
          messageSource.getMessage("error.E1129", null,
              Locale.getDefault()),
          e);
      // 《メータ設置場所照会BusinessBean》.リターンコードに（G017）を設定し、処理を終了する。
      inquiryMeterLocationBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      inquiryMeterLocationBusinessBean
          .setMessage(getMessage(
              KJ_CommonUtil
                  .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G017),
              null));
    } catch (NoSuchMessageException nsme) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, nsme);
      inquiryMeterLocationBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      inquiryMeterLocationBusinessBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
    }

    return inquiryMeterLocationBusinessBean;
  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.kj.
   * KJ_AgentMeterLocationInformationBusiness
   * #regist(jp.co.unisys.enability.cis.business.kj.model.
   * RegistAgentMeterLocationBusinessBean)
   */
  @Override
  public RegistAgentMeterLocationBusinessBean regist(
      RegistAgentMeterLocationBusinessBean registMeterLocationBusinessBean) {

    String message = null;
    String smartMeterCategoryCode = null;
    String meterReadingDateCategoryCode = null;

    try {
      // プロパティ取得
      Properties prop = applicationProperties.getObject();

      // エリアコード存在チェック
      if (!doCheckAreaCode(registMeterLocationBusinessBean.getAreaCode())) {
        // 《メータ設置場所登録BusinessBean》.リターンコードに（P014）を設定し処理を終了する。
        registMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P014);
        registMeterLocationBusinessBean
            .setMessage(getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P014),
                null));
        return registMeterLocationBusinessBean;
      }

      // 送受電区分コード存在チェック
      if (!doCheckTransmissionCategoryCode(registMeterLocationBusinessBean
          .getTransmissionCategoryCode())) {
        // 《メータ設置場所登録BusinessBean》.リターンコードに（P015）を設定し処理を終了する。
        registMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P015);
        registMeterLocationBusinessBean
            .setMessage(getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P015),
                null));
        return registMeterLocationBusinessBean;
      }

      // 自家発連携有無コード存在チェック
      if (!doCheckGeneratorLinkageCheckCode(registMeterLocationBusinessBean
          .getGeneratorLinkageCheckCode())) {
        // 《メータ設置場所登録BusinessBean》.リターンコードに（P016）を設定し処理を終了する。
        registMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P016);
        registMeterLocationBusinessBean
            .setMessage(getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P016),
                null));
        return registMeterLocationBusinessBean;
      }

      // 供給方式コード存在チェック
      if (!doCheckSupplyMethodCode(registMeterLocationBusinessBean
          .getMethodCode())) {
        // 《メータ設置場所登録BusinessBean》.リターンコードに（P017）を設定し処理を終了する。
        registMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P017);
        registMeterLocationBusinessBean
            .setMessage(getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P017),
                null));
        return registMeterLocationBusinessBean;
      }

      // 30分値収集可否・自動検針可否コード1存在チェック
      if (!doCheckAutomaticMeterReadingCkeckCode(registMeterLocationBusinessBean
          .getAutomaticMeterReadingCkeckCode1())) {
        // 《メータ設置場所登録BusinessBean》.リターンコードに（P018）を設定する。
        // 《メータ設置場所登録BusinessBean》.メッセージに以下のメッセージ情報を設定する。
        // メッセージID： error.E1082
        // プレースホルダ0： 30分値収集可否・自動検針可否コード1
        message = getMessage(
            KJ_CommonUtil
                .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P018),
            new String[] {prop
                .getProperty("message.str.ml.amrcCode1") });
        registMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P018);
        registMeterLocationBusinessBean.setMessage(message);
        return registMeterLocationBusinessBean;
      }

      // 30分値収集可否・自動検針可否コード2存在チェック
      if (!doCheckAutomaticMeterReadingCkeckCode(registMeterLocationBusinessBean
          .getAutomaticMeterReadingCkeckCode2())) {
        // 《メータ設置場所登録BusinessBean》.リターンコードに（P018）を設定する。
        // 《メータ設置場所登録BusinessBean》.メッセージに以下のメッセージ情報を設定する。
        // メッセージID： error.E1082
        // プレースホルダ0： 30分値収集可否・自動検針可否コード2
        message = getMessage(
            KJ_CommonUtil
                .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P018),
            new String[] {prop
                .getProperty("message.str.ml.amrcCode2") });
        registMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P018);
        registMeterLocationBusinessBean.setMessage(message);
        return registMeterLocationBusinessBean;
      }

      // 30分値収集可否・自動検針可否コード3存在チェック
      if (!doCheckAutomaticMeterReadingCkeckCode(registMeterLocationBusinessBean
          .getAutomaticMeterReadingCkeckCode3())) {
        // 《メータ設置場所登録BusinessBean》.リターンコードに（P018）を設定する。
        // 《メータ設置場所登録BusinessBean》.メッセージに以下のメッセージ情報を設定する。
        // メッセージID： error.E1082
        // プレースホルダ0： 30分値収集可否・自動検針可否コード3
        message = getMessage(
            KJ_CommonUtil
                .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P018),
            new String[] {prop
                .getProperty("message.str.ml.amrcCode3") });
        registMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P018);
        registMeterLocationBusinessBean.setMessage(message);
        return registMeterLocationBusinessBean;
      }

      // 30分値収集可否・自動検針可否コード4存在チェック
      if (!doCheckAutomaticMeterReadingCkeckCode(registMeterLocationBusinessBean
          .getAutomaticMeterReadingCkeckCode4())) {
        // 《メータ設置場所登録BusinessBean》.リターンコードに（P018）を設定する。
        // 《メータ設置場所登録BusinessBean》.メッセージに以下のメッセージ情報を設定する。
        // メッセージID： error.E1082
        // プレースホルダ0： 30分値収集可否・自動検針可否コード4
        message = getMessage(
            KJ_CommonUtil
                .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P018),
            new String[] {prop
                .getProperty("message.str.ml.amrcCode4") });
        registMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P018);
        registMeterLocationBusinessBean.setMessage(message);
        return registMeterLocationBusinessBean;
      }

      // 30分値収集可否・自動検針可否コード5存在チェック
      if (!doCheckAutomaticMeterReadingCkeckCode(registMeterLocationBusinessBean
          .getAutomaticMeterReadingCkeckCode5())) {
        // 《メータ設置場所登録BusinessBean》.リターンコードに（P018）を設定する。
        // 《メータ設置場所登録BusinessBean》.メッセージに以下のメッセージ情報を設定する。
        // メッセージID： error.E1082
        // プレースホルダ0： 30分値収集可否・自動検針可否コード5
        message = getMessage(
            KJ_CommonUtil
                .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P018),
            new String[] {prop
                .getProperty("message.str.ml.amrcCode5") });
        registMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P018);
        registMeterLocationBusinessBean.setMessage(message);
        return registMeterLocationBusinessBean;
      }

      // スマートメータ区分コード存在チェック
      if (!doCheckSmartMeterCategoryCode(registMeterLocationBusinessBean
          .getSmartMeterCategoryCode())) {
        // 《メータ設置場所登録BusinessBean》.リターンコードに（P083）を設定し処理を終了する。
        registMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P083);
        registMeterLocationBusinessBean
            .setMessage(getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P083),
                null));
        return registMeterLocationBusinessBean;
      }

      // 契約決定方法コード存在チェック
      if (!doCheckContractDecisionWayCode(registMeterLocationBusinessBean
          .getContractDecisionWayCode())) {
        // 《メータ設置場所更新BusinessBean》.リターンコードに（P085）を設定し処理を終了する。
        registMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P085);
        registMeterLocationBusinessBean
            .setMessage(getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P085),
                null));
        return registMeterLocationBusinessBean;
      }

      // 都道府県コード存在チェック
      if (!doCheckPrefectureCode(registMeterLocationBusinessBean.getMeterLocationFree1())) {
        // 《メータ設置場所登録BusinessBean》.リターンコードに（P096）を設定し処理を終了する。
        registMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P096);
        registMeterLocationBusinessBean
            .setMessage(getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P096),
                null));
        return registMeterLocationBusinessBean;
      }

      // 検針日区分コード存在チェック
      if (!doCheckMeterReadingDateCategoryCode(registMeterLocationBusinessBean
          .getMeterReadingDateCategoryCode())) {
        // 《メータ設置場所更新BusinessBean》.リターンコードに（P100）を設定し処理を終了する。
        registMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P100);
        registMeterLocationBusinessBean
            .setMessage(getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P100),
                null));
        return registMeterLocationBusinessBean;
      }

      // 地点特定番号重複チェック
      if (!doCheckSpotNo(registMeterLocationBusinessBean.getSpotNo())) {
        // 《メータ設置場所登録BusinessBean》.リターンコードに（D022)を設定して、返却する。
        registMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D022);
        registMeterLocationBusinessBean
            .setMessage(getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D022),
                null));
        return registMeterLocationBusinessBean;
      }

      // システム時刻を取得
      Date sysDate = new Date();
      Timestamp systime = new Timestamp(sysDate.getTime());
      // 需要場所EntityBeanを設定
      // 《メータ設置場所登録BusinessBean》より、《需要場所Entity》に値を設定する。
      Place place = new Place();
      place.setPlaceAddressPostalCode(registMeterLocationBusinessBean
          .getPlaceAddressPostalCode());
      place.setPlaceAddressFull(registMeterLocationBusinessBean
          .getPlaceAddressFull());
      place.setPlaceAddressBuilding(registMeterLocationBusinessBean
          .getPlaceAddressBuilding());
      // 《需要場所Entity》.更新回数に“0”を設定する。
      place.setUpdateCount(0);
      // 《需要場所Entity》.作成日時にシステム日時を設定する。
      place.setCreateTime(systime);
      // 《需要場所Entity》.オンライン更新日時にシステム日時を設定する。
      place.setOnlineUpdateTime(systime);
      // 《需要場所Entity》.オンライン更新ユーザIDにコンテキスト.ユーザIDを設定する。
      place.setOnlineUpdateUserId(ThreadContext.getRequestThreadContext()
          .get(ECISConstants.USER_ID_KEY).toString());
      // 《需要場所Entity》.更新日時にシステム日時を設定する。
      place.setUpdateTime(systime);
      // 《需要場所Entity》.更新モジュールコードにコンテキスト.モジュールコードを設定する。
      place.setUpdateModuleCode(ThreadContext.getRequestThreadContext()
          .get(ECISConstants.CLASS_NAME_KEY).toString());
      // 需要場所登録
      placeMapper.insertBySequence(place);

      // 《メータ設置場所登録BusinessBean》.スマートメータ区分コードがNULLまたは空文字のいずれでもない場合
      if (StringUtils.isNotEmpty(registMeterLocationBusinessBean
          .getSmartMeterCategoryCode())) {
        // スマートメータ区分コード変数に《メータ設置場所登録BusinessBean》.スマートメータ区分コードを設定する
        smartMeterCategoryCode = registMeterLocationBusinessBean
            .getSmartMeterCategoryCode();
        // 《メータ設置場所登録BusinessBean》.スマートメータ区分コードがNULLまたは空文字のいずれかの場合
      } else {
        // 登録時スマートメータ区分判定を呼び出し、返却値をスマートメータ区分コード変数に設定する
        smartMeterCategoryCode = decideSmartMeterCategoryForRegist(registMeterLocationBusinessBean
            .getAutomaticMeterReadingCkeckCode1());
      }

      // 《メータ設置場所登録BusinessBean》.検針日区分コードがNULLでも空文字でもない場合
      if (StringUtils.isNotEmpty(registMeterLocationBusinessBean
          .getMeterReadingDateCategoryCode())) {
        // 変数.検針日区分コードに《メータ設置場所登録BusinessBean》.検針日区分コードを設定する。
        meterReadingDateCategoryCode = registMeterLocationBusinessBean
            .getMeterReadingDateCategoryCode();
        // 《メータ設置場所登録BusinessBean》.検針日区分コードがNULLか空文字の場合
      } else {
        // 変数.検針日区分コードに定数.分散検針:「1」を設定する。
        meterReadingDateCategoryCode = ECISCodeConstants.METER_READING_DATE_CATEGORY_DISPERSION;
      }

      // メータ設置場所EntityBeanを設定
      // 《メータ設置場所登録BusinessBean》より、《メータ設置場所Entity》に値を設定する。
      Ml ml = new Ml();
      ml.setAreaCode(registMeterLocationBusinessBean.getAreaCode());
      ml.setSpotNo(registMeterLocationBusinessBean.getSpotNo());
      ml.setContractorIdn(registMeterLocationBusinessBean
          .getContractorIdentificationNo());
      ml.setTransmissionCatCode(registMeterLocationBusinessBean
          .getTransmissionCategoryCode());
      ml.setBasicMrDate(registMeterLocationBusinessBean
          .getBasicMeterReadingDate());
      ml.setLastTimeMrDate(registMeterLocationBusinessBean
          .getLastTimeMeterReadingDate());
      ml.setNextMrScheduledDate(registMeterLocationBusinessBean
          .getNextMeterReadingScheduledDate());
      ml.setGlcCode(registMeterLocationBusinessBean
          .getGeneratorLinkageCheckCode());
      ml.setSmCode(registMeterLocationBusinessBean.getMethodCode());
      // 契約決定方法コード
      if (registMeterLocationBusinessBean.getContractDecisionWayCode() == null) {
        ml.setContractDecisionWayCode(ECISCodeConstants.CONTRACT_DECISION_WAY_CODE_SYSTEM_MANAGE_NA);
      } else {
        ml.setContractDecisionWayCode(registMeterLocationBusinessBean.getContractDecisionWayCode());
      }
      ml.setMeterIdn1(registMeterLocationBusinessBean
          .getMeterIdentificationNo1());
      ml.setMeterIdn2(registMeterLocationBusinessBean
          .getMeterIdentificationNo2());
      ml.setMeterIdn3(registMeterLocationBusinessBean
          .getMeterIdentificationNo3());
      ml.setMeterIdn4(registMeterLocationBusinessBean
          .getMeterIdentificationNo4());
      ml.setMeterIdn5(registMeterLocationBusinessBean
          .getMeterIdentificationNo5());
      ml.setAmrcCode1(registMeterLocationBusinessBean
          .getAutomaticMeterReadingCkeckCode1());
      ml.setAmrcCode2(registMeterLocationBusinessBean
          .getAutomaticMeterReadingCkeckCode2());
      ml.setAmrcCode3(registMeterLocationBusinessBean
          .getAutomaticMeterReadingCkeckCode3());
      ml.setAmrcCode4(registMeterLocationBusinessBean
          .getAutomaticMeterReadingCkeckCode4());
      ml.setAmrcCode5(registMeterLocationBusinessBean
          .getAutomaticMeterReadingCkeckCode5());
      // 《メータ設置場所Entity》.需要場所IDに《需要場所Entity》.需要場所IDを設定する。
      ml.setPlaceId(place.getPlaceId());
      // 《メータ設置場所Entity》.スマートメータ区分コードにスマートメータ区分コード変数を設定する。
      ml.setSmCatCode(smartMeterCategoryCode);
      // 《メータ設置場所Entity》.検針日区分コードに変数.検針日区分コードを設定する。
      ml.setMrDateCatCode(meterReadingDateCategoryCode);
      // 《メータ設置場所Entity》.更新回数に“0”を設定する。
      ml.setUpdateCount(0);
      // 《メータ設置場所Entity》.作成日時にシステム日時を設定する。
      ml.setCreateTime(systime);
      // 《メータ設置場所Entity》.オンライン更新日時にシステム日時を設定する。
      ml.setOnlineUpdateTime(systime);
      // 《メータ設置場所Entity》.オンライン更新ユーザIDにコンテキスト.ユーザIDを設定する。
      ml.setOnlineUpdateUserId(ThreadContext.getRequestThreadContext()
          .get(ECISConstants.USER_ID_KEY).toString());
      // 《メータ設置場所Entity》.更新日時にシステム日時を設定する。
      ml.setUpdateTime(systime);
      // 《メータ設置場所Entity》.更新モジュールコードにコンテキスト.モジュールコードを設定する。
      ml.setUpdateModuleCode(ThreadContext.getRequestThreadContext()
          .get(ECISConstants.CLASS_NAME_KEY).toString());
      // メータ設置場所登録
      mlMapper.insertBySequence(ml);
      // シーケンスの設定
      // 《メータ設置場所登録BusinessBean》.需要場所IDに《需要場所Entity》.需要場所IDを設定する。
      registMeterLocationBusinessBean.setPlaceId(place.getPlaceId());
      // 《メータ設置場所登録BusinessBean》.メータ設置場所IDに《メータ設置場所Entity》.メータ設置場所IDを設定する。
      registMeterLocationBusinessBean.setMeterLocationId(ml.getMlId());

      MlAddInfo mlAddInfo = new MlAddInfo();
      mlAddInfo.setMlId(ml.getMlId());
      mlAddInfo.setFree1(registMeterLocationBusinessBean
          .getMeterLocationFree1());
      mlAddInfo.setFree2(registMeterLocationBusinessBean
          .getMeterLocationFree2());
      mlAddInfo.setFree3(registMeterLocationBusinessBean
          .getMeterLocationFree3());
      mlAddInfo.setFree4(registMeterLocationBusinessBean
          .getMeterLocationFree4());
      mlAddInfo.setFree5(registMeterLocationBusinessBean
          .getMeterLocationFree5());
      mlAddInfo.setFree6(registMeterLocationBusinessBean
          .getMeterLocationFree6());
      mlAddInfo.setFree7(registMeterLocationBusinessBean
          .getMeterLocationFree7());
      mlAddInfo.setFree8(registMeterLocationBusinessBean
          .getMeterLocationFree8());
      mlAddInfo.setFree9(registMeterLocationBusinessBean
          .getMeterLocationFree9());
      mlAddInfo.setFree10(registMeterLocationBusinessBean
          .getMeterLocationFree10());
      mlAddInfo.setUpdateCount(0);
      mlAddInfo.setCreateTime(systime);
      mlAddInfo.setOnlineUpdateTime(systime);
      mlAddInfo.setOnlineUpdateUserId(ThreadContext
          .getRequestThreadContext().get(ECISConstants.USER_ID_KEY)
          .toString());
      mlAddInfo.setUpdateTime(systime);
      mlAddInfo.setUpdateModuleCode(ThreadContext
          .getRequestThreadContext()
          .get(ECISConstants.CLASS_NAME_KEY).toString());
      mlAddInfoMapper.insert(mlAddInfo);

      registMeterLocationBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);
      // 重複例外クラス
    } catch (DuplicateKeyException de) {
      logger.error(
          messageSource.getMessage("error.E1129", null,
              Locale.getDefault()),
          de);
      // 《メータ設置場所登録BusinessBean》.リターンコードに（D023）を設定し、処理を終了する。
      registMeterLocationBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D023);
      registMeterLocationBusinessBean.setMessage(getMessage(KJ_CommonUtil
          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D023),
          null));
      return registMeterLocationBusinessBean;
      // 業務例外クラス
    } catch (DataAccessException | IOException e) {
      logger.error(
          messageSource.getMessage("error.E1129", null,
              Locale.getDefault()),
          e);
      // 《メータ設置場所登録BusinessBean》.リターンコードに（G017）を設定し処理を終了する。
      registMeterLocationBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      registMeterLocationBusinessBean.setMessage(getMessage(KJ_CommonUtil
          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G017),
          null));
    } catch (NoSuchMessageException nsme) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, nsme);
      registMeterLocationBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      registMeterLocationBusinessBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
    }

    return registMeterLocationBusinessBean;
  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.kj.
   * KJ_AgentMeterLocationInformationBusiness
   * #update(jp.co.unisys.enability.cis.business.kj.model.
   * UpdateAgentMeterLocationBusinessBean)
   */
  @Override
  public UpdateAgentMeterLocationBusinessBean update(
      UpdateAgentMeterLocationBusinessBean updateMeterLocationBusinessBean) {

    String message = null;
    String smartMeterCategoryCode = null;
    String meterReadingDateCategoryCode = null;
    
    // 地点特定番号変更フラグ
	boolean spotNoChangeFlg = false;

    // プロパティ取得
    Properties prop;
    try {
      prop = applicationProperties.getObject();
    } catch (IOException ioEx) {
      logger.error(
          messageSource.getMessage("error.E1129", null,
              Locale.getDefault()),
          ioEx);
      throw new SystemException(ECISKJConstants.IO_EXCEPTION, ioEx);
    }
    try {
      // エリアコード存在チェック
      if (!doCheckAreaCode(updateMeterLocationBusinessBean.getAreaCode())) {
        // 《メータ設置場所更新BusinessBean》.リターンコードに（P014）を設定し処理を終了する。
        updateMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P014);
        updateMeterLocationBusinessBean
            .setMessage(getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P014),
                null));
        return updateMeterLocationBusinessBean;
      }

      // 送受電区分コード存在チェック
      if (!doCheckTransmissionCategoryCode(updateMeterLocationBusinessBean
          .getTransmissionCategoryCode())) {
        // 《メータ設置場所更新BusinessBean》.リターンコードに（P015）を設定し処理を終了する。
        updateMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P015);
        updateMeterLocationBusinessBean
            .setMessage(getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P015),
                null));
        return updateMeterLocationBusinessBean;
      }

      // 自家発連携有無コード存在チェック
      if (!doCheckGeneratorLinkageCheckCode(updateMeterLocationBusinessBean
          .getGeneratorLinkageCheckCode())) {
        // 《メータ設置場所更新BusinessBean》.リターンコードに（P016）を設定し処理を終了する。
        updateMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P016);
        updateMeterLocationBusinessBean
            .setMessage(getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P016),
                null));
        return updateMeterLocationBusinessBean;
      }

      // 供給方式コード存在チェック
      if (!doCheckSupplyMethodCode(updateMeterLocationBusinessBean
          .getMethodCode())) {
        // 《メータ設置場所更新BusinessBean》.リターンコードに（P017）を設定し処理を終了する。
        updateMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P017);
        updateMeterLocationBusinessBean
            .setMessage(getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P017),
                null));
        return updateMeterLocationBusinessBean;
      }

      // 30分値収集可否・自動検針可否コード1存在チェック
      if (!doCheckAutomaticMeterReadingCkeckCode(updateMeterLocationBusinessBean
          .getAutomaticMeterReadingCkeckCode1())) {
        // 《メータ設置場所更新BusinessBean》.リターンコードに（P018）を設定する。
        // 《メータ設置場所更新BusinessBean》.メッセージに以下のメッセージ情報を設定する。
        // メッセージID： error.E1082
        // プレースホルダ0： 30分値収集可否・自動検針可否コード1
        message = getMessage(
            KJ_CommonUtil
                .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P018),
            new String[] {prop
                .getProperty("message.str.ml.amrcCode1") });
        updateMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P018);
        updateMeterLocationBusinessBean.setMessage(message);
        return updateMeterLocationBusinessBean;
      }

      // 30分値収集可否・自動検針可否コード2存在チェック
      if (!doCheckAutomaticMeterReadingCkeckCode(updateMeterLocationBusinessBean
          .getAutomaticMeterReadingCkeckCode2())) {
        // 《メータ設置場所更新BusinessBean》.リターンコードに（P018）を設定する。
        // 《メータ設置場所更新BusinessBean》.メッセージに以下のメッセージ情報を設定する。
        // メッセージID： error.E1082
        // プレースホルダ0： 30分値収集可否・自動検針可否コード2
        message = getMessage(
            KJ_CommonUtil
                .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P018),
            new String[] {prop
                .getProperty("message.str.ml.amrcCode2") });
        updateMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P018);
        updateMeterLocationBusinessBean.setMessage(message);
        return updateMeterLocationBusinessBean;
      }

      // 30分値収集可否・自動検針可否コード3存在チェック
      if (!doCheckAutomaticMeterReadingCkeckCode(updateMeterLocationBusinessBean
          .getAutomaticMeterReadingCkeckCode3())) {
        // 《メータ設置場所更新BusinessBean》.リターンコードに（P018）を設定する。
        // 《メータ設置場所更新BusinessBean》.メッセージに以下のメッセージ情報を設定する。
        // メッセージID： error.E1082
        // プレースホルダ0： 30分値収集可否・自動検針可否コード3
        message = getMessage(
            KJ_CommonUtil
                .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P018),
            new String[] {prop
                .getProperty("message.str.ml.amrcCode3") });
        updateMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P018);
        updateMeterLocationBusinessBean.setMessage(message);
        return updateMeterLocationBusinessBean;
      }

      // 30分値収集可否・自動検針可否コード4存在チェック
      if (!doCheckAutomaticMeterReadingCkeckCode(updateMeterLocationBusinessBean
          .getAutomaticMeterReadingCkeckCode4())) {
        // 《メータ設置場所更新BusinessBean》.リターンコードに（P018）を設定する。
        // 《メータ設置場所更新BusinessBean》.メッセージに以下のメッセージ情報を設定する。
        // メッセージID： error.E1082
        // プレースホルダ0： 30分値収集可否・自動検針可否コード4
        message = getMessage(
            KJ_CommonUtil
                .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P018),
            new String[] {prop
                .getProperty("message.str.ml.amrcCode4") });
        updateMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P018);
        updateMeterLocationBusinessBean.setMessage(message);
        return updateMeterLocationBusinessBean;
      }

      // 30分値収集可否・自動検針可否コード5存在チェック
      if (!doCheckAutomaticMeterReadingCkeckCode(updateMeterLocationBusinessBean
          .getAutomaticMeterReadingCkeckCode5())) {
        // 《メータ設置場所更新BusinessBean》.リターンコードに（P018）を設定する。
        // 《メータ設置場所更新BusinessBean》.メッセージに以下のメッセージ情報を設定する。
        // メッセージID： error.E1082
        // プレースホルダ0： 30分値収集可否・自動検針可否コード5
        message = getMessage(
            KJ_CommonUtil
                .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P018),
            new String[] {prop
                .getProperty("message.str.ml.amrcCode5") });
        updateMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P018);
        updateMeterLocationBusinessBean.setMessage(message);
        return updateMeterLocationBusinessBean;
      }

      // スマートメータ区分コード存在チェック
      if (!doCheckSmartMeterCategoryCode(updateMeterLocationBusinessBean
          .getSmartMeterCategoryCode())) {
        // 《メータ設置場所更新BusinessBean》.リターンコードに（P083）を設定し処理を終了する。
        updateMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P083);
        updateMeterLocationBusinessBean
            .setMessage(getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P083),
                null));
        return updateMeterLocationBusinessBean;
      }

      // 契約決定方法コード存在チェック
      if (!doCheckContractDecisionWayCode(updateMeterLocationBusinessBean
          .getContractDecisionWayCode())) {
        // 《メータ設置場所更新BusinessBean》.リターンコードに（P085）を設定し処理を終了する。
        updateMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P085);
        updateMeterLocationBusinessBean
            .setMessage(getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P085),
                null));
        return updateMeterLocationBusinessBean;
      }

      // 都道府県コード存在チェック
      if (!doCheckPrefectureCode(updateMeterLocationBusinessBean.getMeterLocationFree1())) {
        // 《メータ設置場所更新BusinessBean》.リターンコードに（P096）を設定し処理を終了する。
        updateMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P096);
        updateMeterLocationBusinessBean
            .setMessage(getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P096),
                null));
        return updateMeterLocationBusinessBean;
      }

      // 検針日区分コード存在チェック
      if (!doCheckMeterReadingDateCategoryCode(updateMeterLocationBusinessBean
          .getMeterReadingDateCategoryCode())) {
        // 《メータ設置場所更新BusinessBean》.リターンコードに（P100）を設定し処理を終了する。
        updateMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P100);
        updateMeterLocationBusinessBean
            .setMessage(getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P100),
                null));
        return updateMeterLocationBusinessBean;
      }

      // メータ設置場所ID取得
      // 《メータ設置場所照会BusinessBean》の設定
      // 《メータ設置場所照会BusinessBean》.メータ設置場所IDに《メータ設置場所更新BusinessBean》.メータ設置場所IDを設定する。
      InquiryAgentMeterLocationBusinessBean inquiryMeterLocationBusinessBean = new InquiryAgentMeterLocationBusinessBean();
      inquiryMeterLocationBusinessBean
          .setMeterLocationId(updateMeterLocationBusinessBean
              .getMeterLocationId());
      // メータ設置場所照会ビジネスを呼出
      inquiryMeterLocationBusinessBean = inquiry(inquiryMeterLocationBusinessBean);
      // 《メータ設置場所照会BusinessBean》.リターンコードが（0000）以外の場合、業務例外クラスをスローする。
      if (!ECISReturnCodeConstants.RETURN_CODE_0000
          .equals(inquiryMeterLocationBusinessBean.getReturnCode())) {
        // 業務例外クラス
        throw new BusinessLogicException(
            getMessage("error.E1299", null), false);
      }
      // 《メータ設置場所照会BusinessBean》.リターンコードが（0000）かつ、返却値が0件の場合、以下の処理を実行する。
      if (CollectionUtils.isEmpty(inquiryMeterLocationBusinessBean
          .getMeterLocationList())) {
        // 《メータ設置場所更新BusinessBean》.リターンコードにリターンコード（P008）を設定して返却する。
        updateMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P008);
        updateMeterLocationBusinessBean
            .setMessage(getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P008),
                null));
        return updateMeterLocationBusinessBean;

      }
      // 《メータ設置場所更新BusinessBean》.地点特定番号と《メータ設置場所照会BusinessBean》.地点特定番号が異なる場合、以下の処理を行う。
      String spotNo = updateMeterLocationBusinessBean.getSpotNo();
      if (spotNo != null
          && !inquiryMeterLocationBusinessBean.getMeterLocationList()
              .get(0).getSpotNo().equals(spotNo)) {
        // 地点特定番号重複チェック
        if (!doCheckSpotNo(spotNo)) {
          // 《メータ設置場所更新BusinessBean》.リターンコードに（D022)を設定して、返却する。
          updateMeterLocationBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D022);
          updateMeterLocationBusinessBean
              .setMessage(getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D022),
                  null));
          return updateMeterLocationBusinessBean;

        }
        // 地点特定番号変更フラグを立てる
		spotNoChangeFlg = true;
      }

      // システム時刻を取得
      Date sysDate = new Date();
      Timestamp systime = new Timestamp(sysDate.getTime());
      // 需要場所EntityBeanを設定
      // 《メータ設置場所更新BusinessBean》をコピーし、《需要場所Entity》とする。
      Place place = new Place();
      place.setPlaceAddressPostalCode(updateMeterLocationBusinessBean
          .getPlaceAddressPostalCode());
      place.setPlaceAddressFull(updateMeterLocationBusinessBean
          .getPlaceAddressFull());
      place.setPlaceAddressBuilding(updateMeterLocationBusinessBean
          .getPlaceAddressBuilding());
      // 《需要場所Entity》.更新回数に《メータ設置場所更新BusinessBean》.更新回数に1加算した値を設定する。
      place.setUpdateCount(updateMeterLocationBusinessBean
          .getUpdateCount() + 1);
      // 《需要場所Entity》.オンライン更新日時にシステム日時を設定する。
      place.setOnlineUpdateTime(systime);
      // 《需要場所Entity》.オンライン更新ユーザIDにコンテキスト.ユーザIDを設定する。
      place.setOnlineUpdateUserId(ThreadContext.getRequestThreadContext()
          .get(ECISConstants.USER_ID_KEY).toString());
      // 《需要場所Entity》.更新日時にシステム日時を設定する。
      place.setUpdateTime(systime);
      // 《需要場所Entity》.更新モジュールコードにコンテキスト.モジュールコードを設定する。
      place.setUpdateModuleCode(ThreadContext.getRequestThreadContext()
          .get(ECISConstants.CLASS_NAME_KEY).toString());
      // メータ設置場所登録条件を設定
      PlaceExample placeExample = new PlaceExample();
      placeExample
          .createCriteria()
          .andPlaceIdEqualTo(
              inquiryMeterLocationBusinessBean
                  .getMeterLocationList().get(0).getPlaceId())
          .andUpdateCountEqualTo(
              updateMeterLocationBusinessBean.getUpdateCount());
      // 需要場所更新
      int placeNum = placeMapper.updateByExampleSelective(place,
          placeExample);
      // 返却値が0件の場合、リターンコード（H001)を返却する。
      if (placeNum == 0) {
        updateMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_H001);
        updateMeterLocationBusinessBean
            .setMessage(getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_H001),
                null));
        return updateMeterLocationBusinessBean;
      }

      // 《メータ設置場所更新BusinessBean》.スマートメータ区分コードがNULLまたは空文字のいずれでもない場合
      if (StringUtils.isNotEmpty(updateMeterLocationBusinessBean
          .getSmartMeterCategoryCode())) {
        // スマートメータ区分コード変数に《メータ設置場所更新BusinessBean》.スマートメータ区分コードを設定する
        smartMeterCategoryCode = updateMeterLocationBusinessBean
            .getSmartMeterCategoryCode();
        // 《メータ設置場所更新BusinessBean》.スマートメータ区分コードがNULLまたは空文字のいずれかの場合
      } else {
        // 更新時スマートメータ区分判定を呼び出し、返却値をスマートメータ区分コード変数に設定する
        smartMeterCategoryCode = decideSmartMeterCategoryForUpdate(
            inquiryMeterLocationBusinessBean
                .getMeterLocationList().get(0).getSmartMeterCategoryCode(),
            updateMeterLocationBusinessBean
                .getAutomaticMeterReadingCkeckCode1());
      }

      // 《メータ設置場所更新BusinessBean》.検針日区分コードがNULLでも空文字でもない場合
      if (StringUtils.isNotEmpty(updateMeterLocationBusinessBean
          .getMeterReadingDateCategoryCode())) {
        // 変数.検針日区分コードに《メータ設置場所更新BusinessBean》.検針日区分コードを設定する。
        meterReadingDateCategoryCode = updateMeterLocationBusinessBean
            .getMeterReadingDateCategoryCode();
      }

      // メータ設置場所EntityBeanを設定
      // 《メータ設置場所更新BusinessBean》をコピーし、《メータ設置場所Entity》とする。
      Ml ml = new Ml();
      ml.setAreaCode(updateMeterLocationBusinessBean.getAreaCode());
      ml.setSpotNo(updateMeterLocationBusinessBean.getSpotNo());
      ml.setContractorIdn(updateMeterLocationBusinessBean
          .getContractorIdentificationNo());
      ml.setTransmissionCatCode(updateMeterLocationBusinessBean
          .getTransmissionCategoryCode());
      ml.setBasicMrDate(updateMeterLocationBusinessBean
          .getBasicMeterReadingDate());
      ml.setNextMrScheduledDate(updateMeterLocationBusinessBean
          .getNextMeterReadingScheduledDate());
      ml.setLastTimeMrDate(updateMeterLocationBusinessBean
          .getLastTimeMeterReadingDate());
      ml.setGlcCode(updateMeterLocationBusinessBean
          .getGeneratorLinkageCheckCode());
      ml.setSmCode(updateMeterLocationBusinessBean.getMethodCode());
      ml.setContractDecisionWayCode(updateMeterLocationBusinessBean.getContractDecisionWayCode());
      ml.setMeterIdn1(updateMeterLocationBusinessBean
          .getMeterIdentificationNo1());
      ml.setMeterIdn2(updateMeterLocationBusinessBean
          .getMeterIdentificationNo2());
      ml.setMeterIdn3(updateMeterLocationBusinessBean
          .getMeterIdentificationNo3());
      ml.setMeterIdn4(updateMeterLocationBusinessBean
          .getMeterIdentificationNo4());
      ml.setMeterIdn5(updateMeterLocationBusinessBean
          .getMeterIdentificationNo5());
      ml.setAmrcCode1(updateMeterLocationBusinessBean
          .getAutomaticMeterReadingCkeckCode1());
      ml.setAmrcCode2(updateMeterLocationBusinessBean
          .getAutomaticMeterReadingCkeckCode2());
      ml.setAmrcCode3(updateMeterLocationBusinessBean
          .getAutomaticMeterReadingCkeckCode3());
      ml.setAmrcCode4(updateMeterLocationBusinessBean
          .getAutomaticMeterReadingCkeckCode4());
      ml.setAmrcCode5(updateMeterLocationBusinessBean
          .getAutomaticMeterReadingCkeckCode5());
      // 《メータ設置場所Entity》.スマートメータ区分コードにスマートメータ区分コード変数を設定する。
      ml.setSmCatCode(smartMeterCategoryCode);
      // 《メータ設置場所Entity》.検針日区分コードに変数.検針日区分コードを設定する。
      ml.setMrDateCatCode(meterReadingDateCategoryCode);
      // 《メータ設置場所Entity》.更新回数に《メータ設置場所更新BusinessBean》.更新回数に1加算した値を設定する。
      ml.setUpdateCount(updateMeterLocationBusinessBean.getUpdateCount() + 1);
      // 《メータ設置場所Entity》.オンライン更新日時にシステム日時を設定する。
      ml.setOnlineUpdateTime(systime);
      // 《メータ設置場所Entity》.オンライン更新ユーザIDにコンテキスト.ユーザIDを設定する。
      ml.setOnlineUpdateUserId(ThreadContext.getRequestThreadContext()
          .get(ECISConstants.USER_ID_KEY).toString());
      // 《メータ設置場所Entity》.更新日時にシステム日時を設定する。
      ml.setUpdateTime(systime);
      // 《メータ設置場所Entity》.更新モジュールコードにコンテキスト.モジュールコードを設定する。
      ml.setUpdateModuleCode(ThreadContext.getRequestThreadContext()
          .get(ECISConstants.CLASS_NAME_KEY).toString());
      // メータ設置場所更新条件を設定
      Map<String, Object> mlMap = new HashMap<String, Object>();
      mlMap.put("nextMeterReadingScheduledDateNoUpdFlag",
          updateMeterLocationBusinessBean
              .getNextMeterReadingScheduledDateNoUpdFlag());
      mlMap.put("lastTimeMeterReadingDateNoUpdFlag",
          updateMeterLocationBusinessBean
              .getLastTimeMeterReadingDateNoUpdFlag());
      mlMap.put("conditionMeterLocationId",
          inquiryMeterLocationBusinessBean.getMeterLocationId());
      mlMap.put("conditionUpdateCount",
          updateMeterLocationBusinessBean.getUpdateCount());
      // メータ設置場所更新
      int mlNum = mlMapper.updateByNoUpdFlagSelective(ml, mlMap);
      // 返却値が0件の場合、リターンコード（H001)を返却する。
      if (mlNum == 0) {
        updateMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_H001);
        updateMeterLocationBusinessBean
            .setMessage(getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_H001),
                null));
        return updateMeterLocationBusinessBean;
      }

      // メータ設置場所付加情報取得
      MlAddInfo mlAddInfoUpdateCountEntity = mlAddInfoMapper.selectByPrimaryKey(
          updateMeterLocationBusinessBean.getMeterLocationId());

      // メータ設置場所付加情報更新件数
      int mlAddInfoNum = 0;

      // メータ設置場所付加情報更新
      if (mlAddInfoUpdateCountEntity != null) {
        MlAddInfo mlAddInfo = new MlAddInfo();
        mlAddInfo.setMlId(updateMeterLocationBusinessBean
            .getMeterLocationId());
        mlAddInfo.setFree1(updateMeterLocationBusinessBean
            .getMeterLocationFree1());
        mlAddInfo.setFree2(updateMeterLocationBusinessBean
            .getMeterLocationFree2());
        mlAddInfo.setFree3(updateMeterLocationBusinessBean
            .getMeterLocationFree3());
        mlAddInfo.setFree4(updateMeterLocationBusinessBean
            .getMeterLocationFree4());
        mlAddInfo.setFree5(updateMeterLocationBusinessBean
            .getMeterLocationFree5());
        mlAddInfo.setFree6(updateMeterLocationBusinessBean
            .getMeterLocationFree6());
        mlAddInfo.setFree7(updateMeterLocationBusinessBean
            .getMeterLocationFree7());
        mlAddInfo.setFree8(updateMeterLocationBusinessBean
            .getMeterLocationFree8());
        mlAddInfo.setFree9(updateMeterLocationBusinessBean
            .getMeterLocationFree9());
        mlAddInfo.setFree10(updateMeterLocationBusinessBean
            .getMeterLocationFree10());
        mlAddInfo.setUpdateCount(mlAddInfoUpdateCountEntity.getUpdateCount() + 1);
        mlAddInfo.setOnlineUpdateTime(systime);
        mlAddInfo.setOnlineUpdateUserId(ThreadContext.getRequestThreadContext()
            .get(ECISConstants.USER_ID_KEY).toString());
        mlAddInfo.setUpdateTime(systime);
        mlAddInfo.setUpdateModuleCode(ThreadContext.getRequestThreadContext()
            .get(ECISConstants.CLASS_NAME_KEY).toString());

        // メータ設置場所付加情報更新
        mlAddInfoNum = mlAddInfoMapper.updateByPrimaryKeySelective(mlAddInfo);
      }

      // 返却値が0件の場合、リターンコード（H001)を返却する。
      if (mlAddInfoNum == 0) {
        updateMeterLocationBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_H001);
        updateMeterLocationBusinessBean
            .setMessage(getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_H001),
                null));
        return updateMeterLocationBusinessBean;
      }
      
      /* 地点特定番号変更情報ファイル出力処理  */
	  // 地点特定番号変更フラグが立っている場合、以下の処理を行う。
	  if (spotNoChangeFlg) {
	      String mlId = inquiryMeterLocationBusinessBean.getMeterLocationList().get(0).getMeterLocationId()
	              .toString();
		  String contractNo = inquiryMeterLocationBusinessBean.getMeterLocationList().get(0).getContractNo();
		  String beforeSpotNo = inquiryMeterLocationBusinessBean.getMeterLocationList().get(0).getSpotNo();
		  String afterSpotNo = updateMeterLocationBusinessBean.getSpotNo();

		  try {
		      // -- 出力ファイルのパス作成 --
			  String spotNoInfoFileOutputDir = prop.getProperty("spotNoChangeInfofile.output.dir");
			  String spotNoInfoFileNameHaeder = prop.getProperty("spotNoChangeInfofile.output.filename");
			  StringBuffer spotNoInfoFileName = new StringBuffer();
			  spotNoInfoFileName.append(spotNoInfoFileNameHaeder)
			 		  .append(mlId)
					  .append(ECISConstants.UNDERLINE)
					  .append(new SimpleDateFormat(ECISConstants.FORMAT_DATE_yyyyMMddHHmmss).format(new Date()))
					  .append(ECISConstants.FILE_EXTENSION_CSV);
			  File spotNoChangeInfoFile = Paths.get(
			  		  spotNoInfoFileOutputDir, spotNoInfoFileName.toString()).toFile();

			  // -- 主力データの作成 --
			  List<String[]> lines = new ArrayList<String[]>();
			  //変更後地点特定番号, 変更前地点特定番号, 契約番号
			  lines.add(new String[] {afterSpotNo, beforeSpotNo, contractNo });

			  // -- CSV Config の設定 --
			  CsvConfig csvconfig = new CsvConfig();
			  // NULL項目はダブルクォートのみで表示
			  csvconfig.setNullString(ECISConstants.CSVCONFIG_OPTION_NULL_STRING);
			  // 改行コードの設定
			  csvconfig.setLineSeparator(ECISConstants.ENTER_CODE);
			  // 囲み文字無効
			  csvconfig.setQuoteDisabled(true);
			  csvconfig.setQuotePolicy(QuotePolicy.ALL);
			  // エスケープ文字有効
			  csvconfig.setEscapeDisabled(false);
			  // エスケープ文字ダブルクォートを設定
			  csvconfig.setEscape(CsvConfig.DEFAULT_QUOTE);

			  // -- ファイル書き込み --
			  Csv.save(lines, spotNoChangeInfoFile, ECISConstants.ENCODE_TYPE_UTF8,
					  csvconfig, new StringArrayListHandler());

		  } catch (Exception e) {
			  logger.error(messageSource.getMessage("error.E1605",
					  new String[] {contractNo, beforeSpotNo, afterSpotNo }, Locale.getDefault()), e);
		  }
	  }

      updateMeterLocationBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);
      // 業務例外クラス
    } catch (DataAccessException | BusinessLogicException e) {
      logger.error(
          messageSource.getMessage("error.E1129", null,
              Locale.getDefault()),
          e);
      // 《メータ設置場所更新BusinessBean》.リターンコードに（G017）を設定して返却する。
      updateMeterLocationBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      updateMeterLocationBusinessBean.setMessage(getMessage(KJ_CommonUtil
          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G017),
          null));
    } catch (NoSuchMessageException nsme) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, nsme);
      updateMeterLocationBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      updateMeterLocationBusinessBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
    }
    return updateMeterLocationBusinessBean;
  }

  /**
   * エリアコード存在チェック
   *
   * @param areaCode
   *          エリアコード
   * @return true チェック成功 false チェック失敗
   */
  private boolean doCheckAreaCode(String areaCode) {
    // エリアコードがNULLまたは空文字のいずれかでない場合、以下のチェックを行う。
    if (StringUtils.isNotEmpty(areaCode)) {
      // エリアマスタMapper.検索（主キー）を呼び出し。
      // 引数： エリアコード
      AreaM areaM = areaMMapper.selectByPrimaryKey(areaCode);
      // 返却値が0件の場合、チェック失敗。
      if (areaM == null) {
        return false;
      }
    }
    return true;
  }

  /**
   * 送受電区分コード存在チェック
   *
   * @param transmissionCategoryCode
   *          送受電区分コード
   * @return true チェック成功 false チェック失敗
   */
  private boolean doCheckTransmissionCategoryCode(
      String transmissionCategoryCode) {
    // 送受電区分コードがNULLまたは空文字のいずれかでない場合、以下のチェックを行う。
    if (StringUtils.isNotEmpty(transmissionCategoryCode)) {
      // 送受電区分マスタMapper.検索（主キー）を呼び出し。
      // 引数： 送受電区分コード
      TransmissionCatM transmissionCatM = transmissionCatMMapper
          .selectByPrimaryKey(transmissionCategoryCode);
      // 返却値が0件の場合、チェック失敗。
      if (transmissionCatM == null) {
        return false;
      }
    }
    return true;
  }

  /**
   * 自家発連携有無コード存在チェック
   *
   * @param generatorLinkageCheckCode
   *          自家発連携有無コード
   * @return true チェック成功 false チェック失敗
   */
  private boolean doCheckGeneratorLinkageCheckCode(
      String generatorLinkageCheckCode) {
    // 自家発連携有無コードがNULLまたは空文字のいずれかでない場合、以下のチェックを行う。
    if (StringUtils.isNotEmpty(generatorLinkageCheckCode)) {
      // 自家発連携有無マスタMapper.検索（主キー）を呼び出し。
      // 引数：.自家発連携有無コード
      GlcM glcM = glcMMapper
          .selectByPrimaryKey(generatorLinkageCheckCode);
      // 返却値が0件の場合、チェック失敗。
      if (glcM == null) {
        return false;
      }
    }
    return true;
  }

  /**
   * 供給方式コード存在チェック
   *
   * @param supplyMethodCode
   *          供給方式コード
   * @return true チェック成功 false チェック失敗
   */
  private boolean doCheckSupplyMethodCode(String supplyMethodCode) {
    // 供給方式コード存在チェック
    // 供給方式コードがNULLまたは空文字のいずれかでない場合、以下のチェックを行う。
    if (StringUtils.isNotEmpty(supplyMethodCode)) {
      // 供給方式マスタMapper.検索（主キー）を呼び出し。
      // 引数： 供給方式コード
      SmM smMM = smMMapper.selectByPrimaryKey(supplyMethodCode);
      // 返却値が0件の場合、チェック失敗。
      if (smMM == null) {
        return false;
      }
    }
    return true;
  }

  /**
   * 30分値収集可否・自動検針可否コード存在チェック
   *
   * @param automaticMeterReadingCkeckCode
   *          30分値収集可否・自動検針可否コード
   * @return true チェック成功 false チェック失敗
   */
  private boolean doCheckAutomaticMeterReadingCkeckCode(
      String automaticMeterReadingCkeckCode) {
    // 30分値収集可否・自動検針可否コードが NULLまたは空文字のいずれかでない場合、以下のチェックを行う。
    if (StringUtils.isNotEmpty(automaticMeterReadingCkeckCode)) {
      // 30分値収集可否・自動検針可否マスタ検索（主キー）を呼び出し。
      // 引数：30分値収集可否・自動検針可否コード
      AmrcM amrcM1 = amrcMMapper
          .selectByPrimaryKey(automaticMeterReadingCkeckCode);
      // 返却値が0件の場合、チェック失敗。
      if (amrcM1 == null) {
        return false;
      }
    }
    return true;
  }

  /**
   * スマートメータ区分コード存在チェック
   *
   * @param smartMeterCategoryCode
   *          スマートメータ区分コード
   * @return true チェック成功 false チェック失敗
   */
  private boolean doCheckSmartMeterCategoryCode(String smartMeterCategoryCode) {
    // スマートメータ区分コード存在チェック
    // スマートメータ区分コードがNULLまたは空文字のいずれかでない場合、以下のチェックを行う。
    if (StringUtils.isNotEmpty(smartMeterCategoryCode)) {
      // スマートメータ区分マスタMapper.検索（主キー）を呼び出し。
      // 引数： スマートメータ区分コード
      SmCatM smcatMM = smcatMMapper.selectByPrimaryKey(smartMeterCategoryCode);
      // 返却値が0件の場合、チェック失敗。
      if (smcatMM == null) {
        return false;
      }
    }
    return true;
  }

  /**
   * 都道府県コード存在チェック
   *
   * @param prefectureCode
   *          都道府県コード
   * @return true チェック成功 false チェック失敗
   */
  private boolean doCheckPrefectureCode(String prefectureCode) {
    // 都道府県コードがNULLまたは空文字のいずれかでない場合、以下のチェックを行う。
    if (StringUtils.isNotEmpty(prefectureCode)) {
      // 都道府県マスタMapper.検索（主キー）を呼び出し。
      // 引数： 都道府県コード
      PrefectureM prefectureM = prefectureMMapper.selectByPrimaryKey(prefectureCode);
      // 返却値が0件の場合、チェック失敗。
      if (prefectureM == null) {
        return false;
      }
    }
    return true;
  }

  /**
   * 契約決定方法コード存在チェック
   *
   * @param smartMeterCategoryCode
   *          契約決定方法コード
   * @return true チェック成功 false チェック失敗
   */
  private boolean doCheckContractDecisionWayCode(String contractDecisionWayCode) {
    // 契約決定方法コード存在チェック
    // 契約決定方法コードがNULLまたは空文字のいずれかでない場合、以下のチェックを行う。
    if (StringUtils.isNotEmpty(contractDecisionWayCode)) {
      // 契約決定方法マスタMapper.検索（主キー）を呼び出し。
      // 引数： 契約決定方法コード
      CdWayM cdWayMM = cdWayMMapper.selectByPrimaryKey(contractDecisionWayCode);
      // 返却値が0件の場合、チェック失敗。
      if (cdWayMM == null) {
        return false;
      }
    }
    return true;
  }

  /**
   * 地点特定番号重複チェック
   *
   * @param spotNo
   *          地点特定番号
   * @return true チェック成功 false チェック失敗
   */
  private boolean doCheckSpotNo(String spotNo) {
    // 《メータ設置場所Entity》の設定
    // 《メータ設置場所Entity》.地点特定番号に引数.地点特定番号を設定する。
    MlExample mlExample = new MlExample();
    mlExample.createCriteria().andSpotNoEqualTo(spotNo);
    // 地点特定番号の検索（件数）を呼び出し。
    // 引数：《メータ設置場所Entity》
    int count = mlMapper.countByExample(mlExample);
    // 返却値.件数が1件以上の場合、以下の処理を行う。
    if (count >= 1) {
      return false;
    }
    return true;
  }

  /**
   * 検針日区分コード存在チェック
   *
   * @param meterReadingDateCategoryCode
   *          検針日区分コード
   * @return true チェック成功 false チェック失敗
   */
  private boolean doCheckMeterReadingDateCategoryCode(String meterReadingDateCategoryCode) {
    // 検針日区分コード存在チェック
    // 検針日区分コードがNULLまたは空文字のいずれかでない場合、以下のチェックを行う。
    if (StringUtils.isNotEmpty(meterReadingDateCategoryCode)) {
      // 検針日区分マスタMapper.検索（主キー）を呼び出し。
      // 引数： 契約決定方法コード
      MrDateCatM mrDateCatM = mrDateCatMMapper.selectByPrimaryKey(meterReadingDateCategoryCode);
      // 返却値が0件の場合、チェック失敗。
      if (mrDateCatM == null) {
        return false;
      }
    }
    return true;
  }

  /**
   * 共通機能を呼出し、オンライン処理基準日を取得する
   *
   * @return オンライン処理基準日
   * @throws BusinessLogicException
   */
  private Date getOnLineDate() throws BusinessLogicException {

    // オンライン処理基準日変数を定義する
    Date returnDate = null;
    try {
      // オンライン処理基準日を取得する
      returnDate = dateBusiness
          .getProcessBaseDate(ECISConstants.EXEC_BASE_DATE_ONLINE);
      // エラーが発生した場合、
    } catch (SystemException e) {
      throw new BusinessLogicException(messageSource.getMessage(
          "error.E0006", new String[] {"オンライン処理基準日" },
          Locale.getDefault()), false);

    }

    // オンライン処理基準日を返却する
    return returnDate;
  }

  /**
   * 登録時スマートメータ区分判定
   *
   * @param automaticMeterReadingCkeckCode
   *          30分値収集可否・自動検針可否コード
   * @return スマートメータ区分コード
   */
  private String decideSmartMeterCategoryForRegist(
      String automaticMeterReadingCkeckCode) {

    // スマートメータ区分コード変数を定義する
    String smartMeterCategoryCode = null;
    // スマートメータ区分コード変数に従来機器を設定する
    smartMeterCategoryCode = ECISCodeConstants.SMART_METER_CATEGORY_CODE_NOT_REPLACED;
    // 30分値収集可否・自動検針可否コードが30分値収集可 自動検針可または30分値収集可 自動検針不可の場合
    if (ECISCodeConstants.AUTOMATIC_METER_READING_CHECK_CODE_AVAILABLE_AVAILABLE
        .equals(automaticMeterReadingCkeckCode)
        || ECISCodeConstants.AUTOMATIC_METER_READING_CHECK_CODE_AVAILABLE_UNAVAILABLE
            .equals(automaticMeterReadingCkeckCode)) {
      // スマートメータ区分コード変数にスマメ切替済を設定する
      smartMeterCategoryCode = ECISCodeConstants.SMART_METER_CATEGORY_CODE_REPLACED_BEFORE_LAST_METER_READING;
    }

    // スマートメータ区分コードを返却する
    return smartMeterCategoryCode;
  }

  /**
   * 更新時スマートメータ区分判定
   *
   * @param smartMeterCategoryCodeChangeBefore
   *          スマートメータ区分コード（変更前）
   * @param automaticMeterReadingCkeckCode
   *          30分値収集可否・自動検針可否コード
   * @return スマートメータ区分コード（変更後）
   */
  private String decideSmartMeterCategoryForUpdate(
      String smartMeterCategoryCodeChangeBefore,
      String automaticMeterReadingCkeckCode) {

    // スマートメータ区分コード（変更後）変数を定義する
    String smartMeterCategoryCodeChangeAfter = null;
    // スマートメータ区分コード（変更後）にスマートメータ区分コード（変更前）を設定する
    smartMeterCategoryCodeChangeAfter = smartMeterCategoryCodeChangeBefore;
    // 30分値収集可否・自動検針可否コードが30分値収集可 自動検針可または30分値収集可 自動検針不可の場合
    if (ECISCodeConstants.AUTOMATIC_METER_READING_CHECK_CODE_AVAILABLE_AVAILABLE
        .equals(automaticMeterReadingCkeckCode)
        || ECISCodeConstants.AUTOMATIC_METER_READING_CHECK_CODE_AVAILABLE_UNAVAILABLE
            .equals(automaticMeterReadingCkeckCode)) {
      // スマートメータ区分コード（変更前）が従来機器の場合
      if (ECISCodeConstants.SMART_METER_CATEGORY_CODE_NOT_REPLACED
          .equals(smartMeterCategoryCodeChangeBefore)) {
        // スマートメータ区分コード（変更後）に前回検針後にスマメ切替を設定する
        smartMeterCategoryCodeChangeAfter = ECISCodeConstants.SMART_METER_CATEGORY_CODE_REPLACED_AFTER_LAST_METER_READING;
        // スマートメータ区分コード（変更前）が前回検針後にスマメ切替後の場合
      } else if (ECISCodeConstants.SMART_METER_CATEGORY_CODE_REPLACED_AFTER_LAST_METER_READING
          .equals(smartMeterCategoryCodeChangeBefore)) {
        // スマートメータ区分コード（変更後）にスマメ切替済を設定する
        smartMeterCategoryCodeChangeAfter = ECISCodeConstants.SMART_METER_CATEGORY_CODE_REPLACED_BEFORE_LAST_METER_READING;
      }
    }

    // スマートメータ区分コード（変更後）を返却する
    return smartMeterCategoryCodeChangeAfter;
  }

  /**
   * プロパティからメッセージを取得する。 パラメータがある場合はバインドさせたメッセージとなる。
   *
   * @param messageKey
   *          メッセージキー
   * @param params
   *          パラメータ配列
   * @return メッセージ
   */
  public String getMessage(String messageKey, Object[] params) {
    return messageSource
        .getMessage(messageKey, params, Locale.getDefault());
  }

  /**
   * メータ設置場所共通Mapperのsetter
   *
   * @param meterLocationInformationCommonMapper
   *          メータ設置場所共通Mapper
   */
  public void setAgentMeterLocationInformationCommonMapper(
      AgentMeterLocationInformationCommonMapper meterLocationInformationCommonMapper) {
    this.meterLocationInformationCommonMapper = meterLocationInformationCommonMapper;
  }

  /**
   * エリアマスタMapperのsetter(DI)
   *
   * @param areaMMapper
   *          エリアマスタMapper
   */
  public void setAreaMMapper(AreaMMapper areaMMapper) {
    this.areaMMapper = areaMMapper;
  }

  /**
   * 送受電区分マスタMapperのsetter(DI)
   *
   * @param transmissionCatMMapper
   *          送受電区分マスタMapper
   */
  public void setTransmissionCatMMapper(
      TransmissionCatMMapper transmissionCatMMapper) {
    this.transmissionCatMMapper = transmissionCatMMapper;
  }

  /**
   * 需要場所Mapperのsetter(DI)
   *
   * @param placeMapper
   *          需要場所Mapper
   */
  public void setPlaceMapper(PlaceMapper placeMapper) {
    this.placeMapper = placeMapper;
  }

  /**
   * 自家発連携マスタMapperのsetter(DI)
   *
   * @param glcMMapper
   *          自家発連携マスタMapper
   */
  public void setGlcMMapper(GlcMMapper glcMMapper) {
    this.glcMMapper = glcMMapper;
  }

  /**
   * 供給方式マスタMapperのsetter(DI)
   *
   * @param smMMapper
   *          供給方式マスタMapper
   */
  public void setSmMMapper(SmMMapper smMMapper) {
    this.smMMapper = smMMapper;
  }

  /**
   * 30分値収集可否・自動検針可否マスタMapperのsetter(DI)
   *
   * @param amrcMMapper
   *          30分値収集可否・自動検針可否マスタMapper
   */
  public void setAmrcMMapper(AmrcMMapper amrcMMapper) {
    this.amrcMMapper = amrcMMapper;
  }

  /**
   * スマートメータ区分マスタMapperのsetter(DI)
   *
   * @param smcatMMapper
   *          スマートメータ区分マスタMapper
   */
  public void setSmCatMMapper(SmCatMMapper smcatMMapper) {
    this.smcatMMapper = smcatMMapper;
  }

  /**
   * 契約決定方法マスタMapperのsetter(DI)
   *
   * @param cdWayMMapper
   *          契約決定方法マスタMapper
   */
  public void setCdWayMMapper(CdWayMMapper cdWayMMapper) {
    this.cdWayMMapper = cdWayMMapper;
  }

  /**
   * メータ設置場所Mapperのsetter(DI)
   *
   * @param mlMapper
   *          メータ設置場所Mapper
   */
  public void setMlMapper(MlMapper mlMapper) {
    this.mlMapper = mlMapper;
  }

  /**
   * メータ設置場所付加Mapperのsetter(DI)
   *
   * @param mlAddInfoMapper
   *          メータ設置場所付加Mapper
   */
  public void setMlAddInfoMapper(MlAddInfoMapper mlAddInfoMapper) {
    this.mlAddInfoMapper = mlAddInfoMapper;
  }

  /**
   * 検針日区分マスタMapperのsetter(DI)
   *
   * @param mrDateCatMMapper
   *          検針日区分マスタMapper
   */
  public void setMrDateCatMMapper(MrDateCatMMapper mrDateCatMMapper) {
    this.mrDateCatMMapper = mrDateCatMMapper;
  }

  /**
   * 日付関連共通ビジネスのsetter(DI)
   *
   * @param dateBusiness
   *          日付関連共通ビジネス
   */
  public void setDateBusiness(DateBusiness dateBusiness) {
    this.dateBusiness = dateBusiness;
  }

  /**
   * messageSourceのsetter(DI)
   *
   * @param messageSource
   *          メッセージソース
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }

  /**
   * プロパティのsetter（DI）
   *
   * @param applicationProperties
   *          プロパティ
   */
  public void setApplicationProperties(
      PropertiesFactoryBean applicationProperties) {
    this.applicationProperties = applicationProperties;
  }

  /**
   * 都道府県マスタMapperのsetter(DI)
   *
   * @param prefectureMMapper
   *          都道府県マスタMapper
   */
  public void setPrefectureMMapper(PrefectureMMapper prefectureMMapper) {
    this.prefectureMMapper = prefectureMMapper;
  }
}
