package jp.co.unisys.enability.cis.business.sn.model;

import java.util.List;

import jp.co.unisys.enability.cis.entity.common.Fcr;

/**
 * CSV作成用ビジネスBeanクラス
 * 
 * @author "Nihon Unisys, Ltd."
 *
 */
public class SN_CreateCsvBusinessBean {

  /** 請求ID */
  private String blBlId;

  /** 請求番号 */
  private String blBlNo;

  /** 契約者ID */
  private String blContractorId;

  /** 契約者番号 */
  private String blContractorNo;

  /** 取引先コード */
  private String blCustomerCode;

  /** 支払ID */
  private String blPaymentId;

  /** 請求区分コード */
  private String blBlCatCode;

  /** 提供モデルコード */
  private String blPmCode;

  /** 提供モデル企業コード */
  private String blPmCompanyCode;

  /** 利用年月 */
  private String blUsePeriod;

  /** 請求額 */
  private String blBlAmount;

  /** ご利用金額 */
  private String blUseAmount;

  /** 決済予定日 */
  private String blSettlementScheduledDate;

  /** 支払期日 */
  private String blPfd;

  /** 請求ステータスコード */
  private String blBlStatusCode;

  /** 請求特別消込理由コード */
  private String blBlSrReasonCode;

  /** 合算請求フラグ */
  private String blAddUpBlFlag;

  /** 先延ばし支払期日フラグ */
  private String blProcrastinationPfdFlag;

  /** 請求作成日 */
  private String blBlCreateDate;

  /** 複合消込フラグ */
  private String blMultipleRccFlag;

  /** まとめ請求フラグ */
  private String blCombinedBlFlag;

  /** 完了フラグ */
  private String blCompletedFlag;

  /** 金融機関コード */
  private String blBankCode;

  /** 金融機関名 */
  private String blBankName;

  /** 金融機関支店コード */
  private String blBankBranchCode;

  /** 金融機関支店名 */
  private String blBankBranchName;

  /** 金融機関預金種目コード */
  private String blBtOfAccountCode;

  /** 金融機関預金種目 */
  private String blBtOfAccount;

  /** 口座番号 */
  private String blAccountNo;

  /** 口座名義 */
  private String blAccountHolderName;

  /** 備考 */
  private String blNote;

  /** 契約者ID */
  private String contractorContractorId;

  /** 契約者番号 */
  private String contractorContractorNo;

  /** 契約者名1（カナ） */
  private String contractorCn1Kana;

  /** 契約者名1 */
  private String contractorCn1;

  /** 契約者名2 */
  private String contractorCn2;

  /** 契約者名1（宛名用） */
  private String contractorCn1MailingName;

  /** 契約者名2（宛名用） */
  private String contractorCn2MailingName;

  /** 敬称 */
  private String contractorPrefix;

  /** 契約者住所（郵便番号） */
  private String contractorCaPostalCode;

  /** 契約者住所（住所） */
  private String contractorCaFull;

  /** 契約者住所（建物・部屋名） */
  private String contractorCaBuilding;

  /** 契約者住所（都道府県名） */
  private String contractorCaPrefectures;

  /** 契約者住所（市区郡町村名） */
  private String contractorCaMunicipality;

  /** 契約者住所（字名・丁目） */
  private String contractorCaSection;

  /** 契約者住所（番地･号） */
  private String contractorCaBlock;

  /** 契約者住所（建物名） */
  private String contractorCaBuildingName;

  /** 契約者住所（部屋名） */
  private String contractorCaRoom;

  /** 契約者電話番号1 */
  private String contractorCphNo1;

  /** 契約者電話区分コード1 */
  private String contractorCphCatCode1;

  /** 契約者電話1（市外局番） */
  private String contractorCphAreaCode1;

  /** 契約者電話1（市内局番） */
  private String contractorCphLocalNo1;

  /** 契約者電話1（加入者番号） */
  private String contractorCphDirectoryNo1;

  /** 契約者電話番号2 */
  private String contractorCphNo2;

  /** 契約者電話区分コード2 */
  private String contractorCphCatCode2;

  /** 契約者電話2（市外局番） */
  private String contractorCphAreaCode2;

  /** 契約者電話2（市内局番） */
  private String contractorCphLocalNo2;

  /** 契約者電話2（加入者番号） */
  private String contractorCphDirectoryNo2;

  /** 契約者メールアドレス1 */
  private String contractorCma1;

  /** 契約者メールアドレス2 */
  private String contractorCma2;

  /** 提供モデルコード */
  private String contractorPmCode;

  /** 提供モデル企業コード */
  private String contractorPmCompanyCode;

  /** 利用不能フラグ */
  private String contractorUnavailableFlag;

  /** 取引先コード */
  private String contractorCustomerCode;

  /** 督促対象外フラグ */
  private String contractorUrgeNotCoveredFlag;

  /** 個人・法人区分コード */
  private String contractorIlcCode;

  /** 見える化提供フラグ */
  private String contractorVisualizationProvideFlag;

  /** 備考 */
  private String contractorNote;

  /** 口座クレカID */
  private String acInformationAccountCreId;

  /** 契約者ID */
  private String acInformationContractorId;

  /** 決済アクセスキー */
  private String acInformationAccessKey;

  /** 口座クレカ区分コード */
  private String acInformationAcCatCode;

  /** 金融機関コード */
  private String acInformationBankCode;

  /** 金融機関支店コード */
  private String acInformationBankBranchCode;

  /** 金融機関預金種目コード */
  private String acInformationBtOfAccountCode;

  /** 口座番号 */
  private String acInformationAccountNo;

  /** 口座名義 */
  private String acInformationAccountHolderName;

  /** クレカブランドコード */
  private String acInformationCreBrandCode;

  /** クレカ番号 */
  private String acInformationCreNo;

  /** クレカ有効期限 */
  private String acInformationCreExpirationDate;

  /** 利用不能フラグ */
  private String acInformationUnavailableFlag;

  /** 支払ID */
  private String paymentHistPaymentId;

  /** 支払適用開始日 */
  private String paymentHistPaymentSd;

  /** 支払適用終了日 */
  private String paymentHistPaymentEd;

  /** 支払方法コード */
  private String paymentHistPwCode;

  /** 口座クレカID */
  private String paymentHistAccountCreId;

  /** 個人・法人区分コード */
  private String paymentHistIlcCode;

  /** 請求先氏名1 */
  private String paymentHistBlName1;

  /** 請求先氏名2 */
  private String paymentHistBlName2;

  /** 敬称 */
  private String paymentHistPrefix;

  /** 請求先住所（郵便番号） */
  private String paymentHistBlAddressPostalCode;

  /** 請求先住所（都道府県名） */
  private String paymentHistBlAddressPrefectures;

  /** 請求先住所（市区郡町村名） */
  private String paymentHistBlAddressMunicipality;

  /** 請求先住所（字名・丁目） */
  private String paymentHistBlAddressSection;

  /** 請求先住所（番地･号） */
  private String paymentHistBlAddressBlock;

  /** 請求先住所（建物名） */
  private String paymentHistBlAddressBuildingName;

  /** 請求先住所（部屋名） */
  private String paymentHistBlAddressRoom;

  /** 請求先電話番号 */
  private String paymentHistBlPhoneNo;

  /** 請求先電話区分コード */
  private String paymentHistBlPhoneCatCode;

  /** 請求先メールアドレス1 */
  private String paymentHistBlMailAddress1;

  /** 請求先メールアドレス2 */
  private String paymentHistBlMailAddress2;

  /** 需要場所ID */
  private String placePlaceId;

  /** 需要場所住所（郵便番号） */
  private String placePlaceAddressPostalCode;

  /** 需要場所住所（住所） */
  private String placePlaceAddressFull;

  /** 需要場所住所（建物・部屋名） */
  private String placePlaceAddressBuilding;

  /** 督促管理ID */
  private String urgeMngUrgeMngId;

  /** 解約予告請求ID */
  private String urgeMngCpBlId;

  /** 解約予告実施日 */
  private String urgeMngCpEnforceDate;

  /** 解約通知日 */
  private String urgeMngCancellationNoticeDate;

  /** 解約回避支払期日 */
  private String urgeMngCePfd;

  /** 解約予定日 */
  private String urgeMngCancellationScheduledDate;

  /** 督促ステータスコード */
  private String urgeMngUrgeStatusCode;

  /** 解約回避理由コード */
  private String urgeMngCeReasonCode;

  /** 解約回避日 */
  private String urgeMngCeDate;

  /** 督促備考 */
  private String urgeMngUrgeNote;

  /** 契約ID */
  private String contractContractId;

  /** 契約者ID */
  private String contractContractorId;

  /** 支払ID */
  private String contractPaymentId;

  /** 契約開始日 */
  private String contractContractSd;

  /** 契約終了日 */
  private String contractContractEd;

  /** 契約番号 */
  private String contractContractNo;

  /** 契約終了理由コード */
  private String contractContractEndReasonCode;

  /** 料金チェックフラグ */
  private String contractChargeCheckFlag;

  /** 営業委託先コード */
  private String contractScCode;

  /** 契約グループ番号 */
  private String contractContractGroupNo;

  /** 個人・法人区分コード */
  private String contractIlcCode;

  /** 連絡先氏名（カナ） */
  private String contractCiNameKana;

  /** 連絡先氏名1 */
  private String contractCiName1;

  /** 連絡先氏名2 */
  private String contractCiName2;

  /** 連絡先住所（郵便番号） */
  private String contractCiAddressPostalCode;

  /** 連絡先住所（住所） */
  private String contractCiAddressFull;

  /** 連絡先住所（建物・部屋名） */
  private String contractCiAddressBuilding;

  /** 連絡先電話番号 */
  private String contractCiPhoneNo;

  /** 連絡先電話区分コード */
  private String contractCiCatCode;

  /** 連絡先電話（市外局番） */
  private String contractCiAreaCode;

  /** 連絡先電話（市内局番） */
  private String contractCiLocalNo;

  /** 連絡先電話（加入者番号） */
  private String contractCiDirectoryNo;

  /** 業種コード */
  private String contractBusinessTypeCode;

  /** 接続送電サービス区分コード */
  private String contractCssCatCode;

  /** 託送契約容量 */
  private String contractConsignmentCca;

  /** 託送契約容量単位 */
  private String contractConsignmentCcaUnit;

  /** 託送契約容量判定日 */
  private String contractConsignmentCcaDecisionDate;

  /** 契約終了分確定使用量連携済フラグ */
  private String contractContractEndFuSentFlag;

  /** 備考 */
  private String contractNote;

  /** フリー項目1 */
  private String contractFree1;

  /** フリー項目2 */
  private String contractFree2;

  /** フリー項目3 */
  private String contractFree3;

  /** フリー項目4 */
  private String contractFree4;

  /** フリー項目5 */
  private String contractFree5;

  /** フリー項目6 */
  private String contractFree6;

  /** フリー項目7 */
  private String contractFree7;

  /** フリー項目8 */
  private String contractFree8;

  /** フリー項目9 */
  private String contractFree9;

  /** フリー項目10 */
  private String contractFree10;

  /** フリー項目11 */
  private String contractFree11;

  /** フリー項目12 */
  private String contractFree12;

  /** フリー項目13 */
  private String contractFree13;

  /** フリー項目14 */
  private String contractFree14;

  /** 委託先使用項目1 */
  private String contractConsignmentUseItem1;

  /** 委託先使用項目2 */
  private String contractConsignmentUseItem2;

  /** 委託先使用項目3 */
  private String contractConsignmentUseItem3;

  /** 自社担当者コード */
  private String contractOurMngPersonInChargeCode;

  /** 自社部署コード */
  private String contractOurMngDepartmentCode;

  /** 提供モデルコード */
  private String pmCompanyMPmCode;

  /** 提供モデル企業コード */
  private String pmCompanyMPmCompanyCode;

  /** 提供モデル企業 */
  private String pmCompanyMPmCompany;

  /** 提供モデル企業（カナ） */
  private String pmCompanyMPmCompanyKana;

  /** 有効開始日 */
  private String pmCompanyMEffectiveSd;

  /** 有効終了日 */
  private String pmCompanyMEffectiveEd;

  /** 郵送先（郵便番号） */
  private String pmCompanyMAddresseePostalCode;

  /** 郵送先（都道府県名） */
  private String pmCompanyMAddresseePrefectures;

  /** 郵送先（市区郡町村名） */
  private String pmCompanyMAddresseeMunicipality;

  /** 郵送先（字名・丁目） */
  private String pmCompanyMAddresseeSection;

  /** 郵送先（番地・号） */
  private String pmCompanyMAddresseeBlock;

  /** 郵送先（建物名） */
  private String pmCompanyMAddresseeBuildingName;

  /** 郵送先（部屋名） */
  private String pmCompanyMAddresseeRoom;

  /** 郵送先（宛名１） */
  private String pmCompanyMAddresseeMailingName1;

  /** 郵送先（宛名２） */
  private String pmCompanyMAddresseeMailingName2;

  /** 敬称 */
  private String pmCompanyMPrefix;

  /** 支払期日日数 */
  private String pmCompanyMPfdDays;

  /** 割当金融機関コード */
  private String pmCompanyMAllotmentBankCode;

  /** 割当金融機関支店コード */
  private String pmCompanyMAllotmentBankBranchCode;

  /** 割当預金種目コード */
  private String pmCompanyMAllotmentBtOfAccountCode;

  /** 割当口座番号 */
  private String pmCompanyMAaNo;

  /** 割当口座名義 */
  private String pmCompanyMAaHolderName;

  /** 見える化提供フラグ */
  private String pmCompanyMVisualizationProvideFlag;

  /** PPS区分 */
  private String pmCompanyMPpsCat;

  /** 《確定料金実績EntityBean》リスト */
  private List<Fcr> fcrList;

  /** 全契約番号リスト */
  private List<String> contractNoList;

  /** 地点特定番号 */
  private String spotNo;

  /**
   * 請求IDを設定する。
   *
   * @param blBlId
   *          請求ID
   */
  public void setBlBlId(String blBlId) {
    this.blBlId = blBlId;
  }

  /**
   * 請求IDを取得する。
   *
   * @return 請求ID
   */
  public String getBlBlId() {
    return this.blBlId;
  }

  /**
   * 請求番号を設定する。
   *
   * @param blBlNo
   *          請求番号
   */
  public void setBlBlNo(String blBlNo) {
    this.blBlNo = blBlNo;
  }

  /**
   * 請求番号を取得する。
   *
   * @return 請求番号
   */
  public String getBlBlNo() {
    return this.blBlNo;
  }

  /**
   * 契約者IDを設定する。
   *
   * @param blContractorId
   *          契約者ID
   */
  public void setBlContractorId(String blContractorId) {
    this.blContractorId = blContractorId;
  }

  /**
   * 契約者IDを取得する。
   *
   * @return 契約者ID
   */
  public String getBlContractorId() {
    return this.blContractorId;
  }

  /**
   * 契約者番号を設定する。
   *
   * @param blContractorNo
   *          契約者番号
   */
  public void setBlContractorNo(String blContractorNo) {
    this.blContractorNo = blContractorNo;
  }

  /**
   * 契約者番号を取得する。
   *
   * @return 契約者番号
   */
  public String getBlContractorNo() {
    return this.blContractorNo;
  }

  /**
   * 取引先コードを設定する。
   *
   * @param blCustomerCode
   *          取引先コード
   */
  public void setBlCustomerCode(String blCustomerCode) {
    this.blCustomerCode = blCustomerCode;
  }

  /**
   * 取引先コードを取得する。
   *
   * @return 取引先コード
   */
  public String getBlCustomerCode() {
    return this.blCustomerCode;
  }

  /**
   * 支払IDを設定する。
   *
   * @param blPaymentId
   *          支払ID
   */
  public void setBlPaymentId(String blPaymentId) {
    this.blPaymentId = blPaymentId;
  }

  /**
   * 支払IDを取得する。
   *
   * @return 支払ID
   */
  public String getBlPaymentId() {
    return this.blPaymentId;
  }

  /**
   * 請求区分コードを設定する。
   *
   * @param blBlCatCode
   *          請求区分コード
   */
  public void setBlBlCatCode(String blBlCatCode) {
    this.blBlCatCode = blBlCatCode;
  }

  /**
   * 請求区分コードを取得する。
   *
   * @return 請求区分コード
   */
  public String getBlBlCatCode() {
    return this.blBlCatCode;
  }

  /**
   * 提供モデルコードを設定する。
   *
   * @param blPmCode
   *          提供モデルコード
   */
  public void setBlPmCode(String blPmCode) {
    this.blPmCode = blPmCode;
  }

  /**
   * 提供モデルコードを取得する。
   *
   * @return 提供モデルコード
   */
  public String getBlPmCode() {
    return this.blPmCode;
  }

  /**
   * 提供モデル企業コードを設定する。
   *
   * @param blPmCompanyCode
   *          提供モデル企業コード
   */
  public void setBlPmCompanyCode(String blPmCompanyCode) {
    this.blPmCompanyCode = blPmCompanyCode;
  }

  /**
   * 提供モデル企業コードを取得する。
   *
   * @return 提供モデル企業コード
   */
  public String getBlPmCompanyCode() {
    return this.blPmCompanyCode;
  }

  /**
   * 利用年月を設定する。
   *
   * @param blUsePeriod
   *          利用年月
   */
  public void setBlUsePeriod(String blUsePeriod) {
    this.blUsePeriod = blUsePeriod;
  }

  /**
   * 利用年月を取得する。
   *
   * @return 利用年月
   */
  public String getBlUsePeriod() {
    return this.blUsePeriod;
  }

  /**
   * 請求額を設定する。
   *
   * @param blBlAmount
   *          請求額
   */
  public void setBlBlAmount(String blBlAmount) {
    this.blBlAmount = blBlAmount;
  }

  /**
   * 請求額を取得する。
   *
   * @return 請求額
   */
  public String getBlBlAmount() {
    return this.blBlAmount;
  }

  /**
   * ご利用金額を設定する。
   *
   * @param blUseAmount
   *          ご利用金額
   */
  public void setBlUseAmount(String blUseAmount) {
    this.blUseAmount = blUseAmount;
  }

  /**
   * ご利用金額を取得する。
   *
   * @return ご利用金額
   */
  public String getBlUseAmount() {
    return this.blUseAmount;
  }

  /**
   * 決済予定日を設定する。
   *
   * @param blSettlementScheduledDate
   *          決済予定日
   */
  public void setBlSettlementScheduledDate(String blSettlementScheduledDate) {
    this.blSettlementScheduledDate = blSettlementScheduledDate;
  }

  /**
   * 決済予定日を取得する。
   *
   * @return 決済予定日
   */
  public String getBlSettlementScheduledDate() {
    return this.blSettlementScheduledDate;
  }

  /**
   * 支払期日を設定する。
   *
   * @param blPfd
   *          支払期日
   */
  public void setBlPfd(String blPfd) {
    this.blPfd = blPfd;
  }

  /**
   * 支払期日を取得する。
   *
   * @return 支払期日
   */
  public String getBlPfd() {
    return this.blPfd;
  }

  /**
   * 請求ステータスコードを設定する。
   *
   * @param blBlStatusCode
   *          請求ステータスコード
   */
  public void setBlBlStatusCode(String blBlStatusCode) {
    this.blBlStatusCode = blBlStatusCode;
  }

  /**
   * 請求ステータスコードを取得する。
   *
   * @return 請求ステータスコード
   */
  public String getBlBlStatusCode() {
    return this.blBlStatusCode;
  }

  /**
   * 請求特別消込理由コードを設定する。
   *
   * @param blBlSrReasonCode
   *          請求特別消込理由コード
   */
  public void setBlBlSrReasonCode(String blBlSrReasonCode) {
    this.blBlSrReasonCode = blBlSrReasonCode;
  }

  /**
   * 請求特別消込理由コードを取得する。
   *
   * @return 請求特別消込理由コード
   */
  public String getBlBlSrReasonCode() {
    return this.blBlSrReasonCode;
  }

  /**
   * 合算請求フラグを設定する。
   *
   * @param blAddUpBlFlag
   *          合算請求フラグ
   */
  public void setBlAddUpBlFlag(String blAddUpBlFlag) {
    this.blAddUpBlFlag = blAddUpBlFlag;
  }

  /**
   * 合算請求フラグを取得する。
   *
   * @return 合算請求フラグ
   */
  public String getBlAddUpBlFlag() {
    return this.blAddUpBlFlag;
  }

  /**
   * 先延ばし支払期日フラグを設定する。
   *
   * @param blProcrastinationPfdFlag
   *          先延ばし支払期日フラグ
   */
  public void setBlProcrastinationPfdFlag(String blProcrastinationPfdFlag) {
    this.blProcrastinationPfdFlag = blProcrastinationPfdFlag;
  }

  /**
   * 先延ばし支払期日フラグを取得する。
   *
   * @return 先延ばし支払期日フラグ
   */
  public String getBlProcrastinationPfdFlag() {
    return this.blProcrastinationPfdFlag;
  }

  /**
   * 請求作成日を設定する。
   *
   * @param blBlCreateDate
   *          請求作成日
   */
  public void setBlBlCreateDate(String blBlCreateDate) {
    this.blBlCreateDate = blBlCreateDate;
  }

  /**
   * 請求作成日を取得する。
   *
   * @return 請求作成日
   */
  public String getBlBlCreateDate() {
    return this.blBlCreateDate;
  }

  /**
   * 複合消込フラグを設定する。
   *
   * @param blMultipleRccFlag
   *          複合消込フラグ
   */
  public void setBlMultipleRccFlag(String blMultipleRccFlag) {
    this.blMultipleRccFlag = blMultipleRccFlag;
  }

  /**
   * 複合消込フラグを取得する。
   *
   * @return 複合消込フラグ
   */
  public String getBlMultipleRccFlag() {
    return this.blMultipleRccFlag;
  }

  /**
   * まとめ請求フラグを設定する。
   *
   * @param blCombinedBlFlag
   *          まとめ請求フラグ
   */
  public void setBlCombinedBlFlag(String blCombinedBlFlag) {
    this.blCombinedBlFlag = blCombinedBlFlag;
  }

  /**
   * まとめ請求フラグを取得する。
   *
   * @return まとめ請求フラグ
   */
  public String getBlCombinedBlFlag() {
    return this.blCombinedBlFlag;
  }

  /**
   * 完了フラグを設定する。
   *
   * @param blCompletedFlag
   *          完了フラグ
   */
  public void setBlCompletedFlag(String blCompletedFlag) {
    this.blCompletedFlag = blCompletedFlag;
  }

  /**
   * 完了フラグを取得する。
   *
   * @return 完了フラグ
   */
  public String getBlCompletedFlag() {
    return this.blCompletedFlag;
  }

  /**
   * 金融機関コードを設定する。
   *
   * @param blBankCode
   *          金融機関コード
   */
  public void setBlBankCode(String blBankCode) {
    this.blBankCode = blBankCode;
  }

  /**
   * 金融機関コードを取得する。
   *
   * @return 金融機関コード
   */
  public String getBlBankCode() {
    return this.blBankCode;
  }

  /**
   * 金融機関名を設定する。
   *
   * @param blBankName
   *          金融機関名
   */
  public void setBlBankName(String blBankName) {
    this.blBankName = blBankName;
  }

  /**
   * 金融機関名を取得する。
   *
   * @return 金融機関名
   */
  public String getBlBankName() {
    return this.blBankName;
  }

  /**
   * 金融機関支店コードを設定する。
   *
   * @param blBankBranchCode
   *          金融機関支店コード
   */
  public void setBlBankBranchCode(String blBankBranchCode) {
    this.blBankBranchCode = blBankBranchCode;
  }

  /**
   * 金融機関支店コードを取得する。
   *
   * @return 金融機関支店コード
   */
  public String getBlBankBranchCode() {
    return this.blBankBranchCode;
  }

  /**
   * 金融機関支店名を設定する。
   *
   * @param blBankBranchName
   *          金融機関支店名
   */
  public void setBlBankBranchName(String blBankBranchName) {
    this.blBankBranchName = blBankBranchName;
  }

  /**
   * 金融機関支店名を取得する。
   *
   * @return 金融機関支店名
   */
  public String getBlBankBranchName() {
    return this.blBankBranchName;
  }

  /**
   * 金融機関預金種目コードを設定する。
   *
   * @param blBtOfAccountCode
   *          金融機関預金種目コード
   */
  public void setBlBtOfAccountCode(String blBtOfAccountCode) {
    this.blBtOfAccountCode = blBtOfAccountCode;
  }

  /**
   * 金融機関預金種目コードを取得する。
   *
   * @return 金融機関預金種目コード
   */
  public String getBlBtOfAccountCode() {
    return this.blBtOfAccountCode;
  }

  /**
   * 金融機関預金種目を設定する。
   *
   * @param blBtOfAccount
   *          金融機関預金種目
   */
  public void setBlBtOfAccount(String blBtOfAccount) {
    this.blBtOfAccount = blBtOfAccount;
  }

  /**
   * 金融機関預金種目を取得する。
   *
   * @return 金融機関預金種目
   */
  public String getBlBtOfAccount() {
    return this.blBtOfAccount;
  }

  /**
   * 口座番号を設定する。
   *
   * @param blAccountNo
   *          口座番号
   */
  public void setBlAccountNo(String blAccountNo) {
    this.blAccountNo = blAccountNo;
  }

  /**
   * 口座番号を取得する。
   *
   * @return 口座番号
   */
  public String getBlAccountNo() {
    return this.blAccountNo;
  }

  /**
   * 口座名義を設定する。
   *
   * @param blAccountHolderName
   *          口座名義
   */
  public void setBlAccountHolderName(String blAccountHolderName) {
    this.blAccountHolderName = blAccountHolderName;
  }

  /**
   * 口座名義を取得する。
   *
   * @return 口座名義
   */
  public String getBlAccountHolderName() {
    return this.blAccountHolderName;
  }

  /**
   * 備考を設定する。
   *
   * @param blNote
   *          備考
   */
  public void setBlNote(String blNote) {
    this.blNote = blNote;
  }

  /**
   * 備考を取得する。
   *
   * @return 備考
   */
  public String getBlNote() {
    return this.blNote;
  }

  /**
   * 契約者IDを設定する。
   *
   * @param contractorContractorId
   *          契約者ID
   */
  public void setContractorContractorId(String contractorContractorId) {
    this.contractorContractorId = contractorContractorId;
  }

  /**
   * 契約者IDを取得する。
   *
   * @return 契約者ID
   */
  public String getContractorContractorId() {
    return this.contractorContractorId;
  }

  /**
   * 契約者番号を設定する。
   *
   * @param contractorContractorNo
   *          契約者番号
   */
  public void setContractorContractorNo(String contractorContractorNo) {
    this.contractorContractorNo = contractorContractorNo;
  }

  /**
   * 契約者番号を取得する。
   *
   * @return 契約者番号
   */
  public String getContractorContractorNo() {
    return this.contractorContractorNo;
  }

  /**
   * 契約者名1（カナ）を設定する。
   *
   * @param contractorCn1Kana
   *          契約者名1（カナ）
   */
  public void setContractorCn1Kana(String contractorCn1Kana) {
    this.contractorCn1Kana = contractorCn1Kana;
  }

  /**
   * 契約者名1（カナ）を取得する。
   *
   * @return 契約者名1（カナ）
   */
  public String getContractorCn1Kana() {
    return this.contractorCn1Kana;
  }

  /**
   * 契約者名1を設定する。
   *
   * @param contractorCn1
   *          契約者名1
   */
  public void setContractorCn1(String contractorCn1) {
    this.contractorCn1 = contractorCn1;
  }

  /**
   * 契約者名1を取得する。
   *
   * @return 契約者名1
   */
  public String getContractorCn1() {
    return this.contractorCn1;
  }

  /**
   * 契約者名2を設定する。
   *
   * @param contractorCn2
   *          契約者名2
   */
  public void setContractorCn2(String contractorCn2) {
    this.contractorCn2 = contractorCn2;
  }

  /**
   * 契約者名2を取得する。
   *
   * @return 契約者名2
   */
  public String getContractorCn2() {
    return this.contractorCn2;
  }

  /**
   * 契約者名1（宛名用）を設定する。
   *
   * @param contractorCn1MailingName
   *          契約者名1（宛名用）
   */
  public void setContractorCn1MailingName(String contractorCn1MailingName) {
    this.contractorCn1MailingName = contractorCn1MailingName;
  }

  /**
   * 契約者名1（宛名用）を取得する。
   *
   * @return 契約者名1（宛名用）
   */
  public String getContractorCn1MailingName() {
    return this.contractorCn1MailingName;
  }

  /**
   * 契約者名2（宛名用）を設定する。
   *
   * @param contractorCn2MailingName
   *          契約者名2（宛名用）
   */
  public void setContractorCn2MailingName(String contractorCn2MailingName) {
    this.contractorCn2MailingName = contractorCn2MailingName;
  }

  /**
   * 契約者名2（宛名用）を取得する。
   *
   * @return 契約者名2（宛名用）
   */
  public String getContractorCn2MailingName() {
    return this.contractorCn2MailingName;
  }

  /**
   * 敬称を設定する。
   *
   * @param contractorPrefix
   *          敬称
   */
  public void setContractorPrefix(String contractorPrefix) {
    this.contractorPrefix = contractorPrefix;
  }

  /**
   * 敬称を取得する。
   *
   * @return 敬称
   */
  public String getContractorPrefix() {
    return this.contractorPrefix;
  }

  /**
   * 契約者住所（郵便番号）を設定する。
   *
   * @param contractorCaPostalCode
   *          契約者住所（郵便番号）
   */
  public void setContractorCaPostalCode(String contractorCaPostalCode) {
    this.contractorCaPostalCode = contractorCaPostalCode;
  }

  /**
   * 契約者住所（郵便番号）を取得する。
   *
   * @return 契約者住所（郵便番号）
   */
  public String getContractorCaPostalCode() {
    return this.contractorCaPostalCode;
  }

  /**
   * 契約者住所（住所）を設定する。
   *
   * @param contractorCaFull
   *          契約者住所（住所）
   */
  public void setContractorCaFull(String contractorCaFull) {
    this.contractorCaFull = contractorCaFull;
  }

  /**
   * 契約者住所（住所）を取得する。
   *
   * @return 契約者住所（住所）
   */
  public String getContractorCaFull() {
    return this.contractorCaFull;
  }

  /**
   * 契約者住所（建物・部屋名）を設定する。
   *
   * @param contractorCaBuilding
   *          契約者住所（建物・部屋名）
   */
  public void setContractorCaBuilding(String contractorCaBuilding) {
    this.contractorCaBuilding = contractorCaBuilding;
  }

  /**
   * 契約者住所（建物・部屋名）を取得する。
   *
   * @return 契約者住所（建物・部屋名）
   */
  public String getContractorCaBuilding() {
    return this.contractorCaBuilding;
  }

  /**
   * 契約者住所（都道府県名）を設定する。
   *
   * @param contractorCaPrefectures
   *          契約者住所（都道府県名）
   */
  public void setContractorCaPrefectures(String contractorCaPrefectures) {
    this.contractorCaPrefectures = contractorCaPrefectures;
  }

  /**
   * 契約者住所（都道府県名）を取得する。
   *
   * @return 契約者住所（都道府県名）
   */
  public String getContractorCaPrefectures() {
    return this.contractorCaPrefectures;
  }

  /**
   * 契約者住所（市区郡町村名）を設定する。
   *
   * @param contractorCaMunicipality
   *          契約者住所（市区郡町村名）
   */
  public void setContractorCaMunicipality(String contractorCaMunicipality) {
    this.contractorCaMunicipality = contractorCaMunicipality;
  }

  /**
   * 契約者住所（市区郡町村名）を取得する。
   *
   * @return 契約者住所（市区郡町村名）
   */
  public String getContractorCaMunicipality() {
    return this.contractorCaMunicipality;
  }

  /**
   * 契約者住所（字名・丁目）を設定する。
   *
   * @param contractorCaSection
   *          契約者住所（字名・丁目）
   */
  public void setContractorCaSection(String contractorCaSection) {
    this.contractorCaSection = contractorCaSection;
  }

  /**
   * 契約者住所（字名・丁目）を取得する。
   *
   * @return 契約者住所（字名・丁目）
   */
  public String getContractorCaSection() {
    return this.contractorCaSection;
  }

  /**
   * 契約者住所（番地･号）を設定する。
   *
   * @param contractorCaBlock
   *          契約者住所（番地･号）
   */
  public void setContractorCaBlock(String contractorCaBlock) {
    this.contractorCaBlock = contractorCaBlock;
  }

  /**
   * 契約者住所（番地･号）を取得する。
   *
   * @return 契約者住所（番地･号）
   */
  public String getContractorCaBlock() {
    return this.contractorCaBlock;
  }

  /**
   * 契約者住所（建物名）を設定する。
   *
   * @param contractorCaBuildingName
   *          契約者住所（建物名）
   */
  public void setContractorCaBuildingName(String contractorCaBuildingName) {
    this.contractorCaBuildingName = contractorCaBuildingName;
  }

  /**
   * 契約者住所（建物名）を取得する。
   *
   * @return 契約者住所（建物名）
   */
  public String getContractorCaBuildingName() {
    return this.contractorCaBuildingName;
  }

  /**
   * 契約者住所（部屋名）を設定する。
   *
   * @param contractorCaRoom
   *          契約者住所（部屋名）
   */
  public void setContractorCaRoom(String contractorCaRoom) {
    this.contractorCaRoom = contractorCaRoom;
  }

  /**
   * 契約者住所（部屋名）を取得する。
   *
   * @return 契約者住所（部屋名）
   */
  public String getContractorCaRoom() {
    return this.contractorCaRoom;
  }

  /**
   * 契約者電話番号1を設定する。
   *
   * @param contractorCphNo1
   *          契約者電話番号1
   */
  public void setContractorCphNo1(String contractorCphNo1) {
    this.contractorCphNo1 = contractorCphNo1;
  }

  /**
   * 契約者電話番号1を取得する。
   *
   * @return 契約者電話番号1
   */
  public String getContractorCphNo1() {
    return this.contractorCphNo1;
  }

  /**
   * 契約者電話区分コード1を設定する。
   *
   * @param contractorCphCatCode1
   *          契約者電話区分コード1
   */
  public void setContractorCphCatCode1(String contractorCphCatCode1) {
    this.contractorCphCatCode1 = contractorCphCatCode1;
  }

  /**
   * 契約者電話区分コード1を取得する。
   *
   * @return 契約者電話区分コード1
   */
  public String getContractorCphCatCode1() {
    return this.contractorCphCatCode1;
  }

  /**
   * 契約者電話1（市外局番）を設定する。
   *
   * @param contractorCphAreaCode1
   *          契約者電話1（市外局番）
   */
  public void setContractorCphAreaCode1(String contractorCphAreaCode1) {
    this.contractorCphAreaCode1 = contractorCphAreaCode1;
  }

  /**
   * 契約者電話1（市外局番）を取得する。
   *
   * @return 契約者電話1（市外局番）
   */
  public String getContractorCphAreaCode1() {
    return this.contractorCphAreaCode1;
  }

  /**
   * 契約者電話1（市内局番）を設定する。
   *
   * @param contractorCphLocalNo1
   *          契約者電話1（市内局番）
   */
  public void setContractorCphLocalNo1(String contractorCphLocalNo1) {
    this.contractorCphLocalNo1 = contractorCphLocalNo1;
  }

  /**
   * 契約者電話1（市内局番）を取得する。
   *
   * @return 契約者電話1（市内局番）
   */
  public String getContractorCphLocalNo1() {
    return this.contractorCphLocalNo1;
  }

  /**
   * 契約者電話1（加入者番号）を設定する。
   *
   * @param contractorCphDirectoryNo1
   *          契約者電話1（加入者番号）
   */
  public void setContractorCphDirectoryNo1(String contractorCphDirectoryNo1) {
    this.contractorCphDirectoryNo1 = contractorCphDirectoryNo1;
  }

  /**
   * 契約者電話1（加入者番号）を取得する。
   *
   * @return 契約者電話1（加入者番号）
   */
  public String getContractorCphDirectoryNo1() {
    return this.contractorCphDirectoryNo1;
  }

  /**
   * 契約者電話番号2を設定する。
   *
   * @param contractorCphNo2
   *          契約者電話番号2
   */
  public void setContractorCphNo2(String contractorCphNo2) {
    this.contractorCphNo2 = contractorCphNo2;
  }

  /**
   * 契約者電話番号2を取得する。
   *
   * @return 契約者電話番号2
   */
  public String getContractorCphNo2() {
    return this.contractorCphNo2;
  }

  /**
   * 契約者電話区分コード2を設定する。
   *
   * @param contractorCphCatCode2
   *          契約者電話区分コード2
   */
  public void setContractorCphCatCode2(String contractorCphCatCode2) {
    this.contractorCphCatCode2 = contractorCphCatCode2;
  }

  /**
   * 契約者電話区分コード2を取得する。
   *
   * @return 契約者電話区分コード2
   */
  public String getContractorCphCatCode2() {
    return this.contractorCphCatCode2;
  }

  /**
   * 契約者電話2（市外局番）を設定する。
   *
   * @param contractorCphAreaCode2
   *          契約者電話2（市外局番）
   */
  public void setContractorCphAreaCode2(String contractorCphAreaCode2) {
    this.contractorCphAreaCode2 = contractorCphAreaCode2;
  }

  /**
   * 契約者電話2（市外局番）を取得する。
   *
   * @return 契約者電話2（市外局番）
   */
  public String getContractorCphAreaCode2() {
    return this.contractorCphAreaCode2;
  }

  /**
   * 契約者電話2（市内局番）を設定する。
   *
   * @param contractorCphLocalNo2
   *          契約者電話2（市内局番）
   */
  public void setContractorCphLocalNo2(String contractorCphLocalNo2) {
    this.contractorCphLocalNo2 = contractorCphLocalNo2;
  }

  /**
   * 契約者電話2（市内局番）を取得する。
   *
   * @return 契約者電話2（市内局番）
   */
  public String getContractorCphLocalNo2() {
    return this.contractorCphLocalNo2;
  }

  /**
   * 契約者電話2（加入者番号）を設定する。
   *
   * @param contractorCphDirectoryNo2
   *          契約者電話2（加入者番号）
   */
  public void setContractorCphDirectoryNo2(String contractorCphDirectoryNo2) {
    this.contractorCphDirectoryNo2 = contractorCphDirectoryNo2;
  }

  /**
   * 契約者電話2（加入者番号）を取得する。
   *
   * @return 契約者電話2（加入者番号）
   */
  public String getContractorCphDirectoryNo2() {
    return this.contractorCphDirectoryNo2;
  }

  /**
   * 契約者メールアドレス1を設定する。
   *
   * @param contractorCma1
   *          契約者メールアドレス1
   */
  public void setContractorCma1(String contractorCma1) {
    this.contractorCma1 = contractorCma1;
  }

  /**
   * 契約者メールアドレス1を取得する。
   *
   * @return 契約者メールアドレス1
   */
  public String getContractorCma1() {
    return this.contractorCma1;
  }

  /**
   * 契約者メールアドレス2を設定する。
   *
   * @param contractorCma2
   *          契約者メールアドレス2
   */
  public void setContractorCma2(String contractorCma2) {
    this.contractorCma2 = contractorCma2;
  }

  /**
   * 契約者メールアドレス2を取得する。
   *
   * @return 契約者メールアドレス2
   */
  public String getContractorCma2() {
    return this.contractorCma2;
  }

  /**
   * 提供モデルコードを設定する。
   *
   * @param contractorPmCode
   *          提供モデルコード
   */
  public void setContractorPmCode(String contractorPmCode) {
    this.contractorPmCode = contractorPmCode;
  }

  /**
   * 提供モデルコードを取得する。
   *
   * @return 提供モデルコード
   */
  public String getContractorPmCode() {
    return this.contractorPmCode;
  }

  /**
   * 提供モデル企業コードを設定する。
   *
   * @param contractorPmCompanyCode
   *          提供モデル企業コード
   */
  public void setContractorPmCompanyCode(String contractorPmCompanyCode) {
    this.contractorPmCompanyCode = contractorPmCompanyCode;
  }

  /**
   * 提供モデル企業コードを取得する。
   *
   * @return 提供モデル企業コード
   */
  public String getContractorPmCompanyCode() {
    return this.contractorPmCompanyCode;
  }

  /**
   * 利用不能フラグを設定する。
   *
   * @param contractorUnavailableFlag
   *          利用不能フラグ
   */
  public void setContractorUnavailableFlag(String contractorUnavailableFlag) {
    this.contractorUnavailableFlag = contractorUnavailableFlag;
  }

  /**
   * 利用不能フラグを取得する。
   *
   * @return 利用不能フラグ
   */
  public String getContractorUnavailableFlag() {
    return this.contractorUnavailableFlag;
  }

  /**
   * 取引先コードを設定する。
   *
   * @param contractorCustomerCode
   *          取引先コード
   */
  public void setContractorCustomerCode(String contractorCustomerCode) {
    this.contractorCustomerCode = contractorCustomerCode;
  }

  /**
   * 取引先コードを取得する。
   *
   * @return 取引先コード
   */
  public String getContractorCustomerCode() {
    return this.contractorCustomerCode;
  }

  /**
   * 督促対象外フラグを設定する。
   *
   * @param contractorUrgeNotCoveredFlag
   *          督促対象外フラグ
   */
  public void setContractorUrgeNotCoveredFlag(String contractorUrgeNotCoveredFlag) {
    this.contractorUrgeNotCoveredFlag = contractorUrgeNotCoveredFlag;
  }

  /**
   * 督促対象外フラグを取得する。
   *
   * @return 督促対象外フラグ
   */
  public String getContractorUrgeNotCoveredFlag() {
    return this.contractorUrgeNotCoveredFlag;
  }

  /**
   * 個人・法人区分コードを設定する。
   *
   * @param contractorIlcCode
   *          個人・法人区分コード
   */
  public void setContractorIlcCode(String contractorIlcCode) {
    this.contractorIlcCode = contractorIlcCode;
  }

  /**
   * 個人・法人区分コードを取得する。
   *
   * @return 個人・法人区分コード
   */
  public String getContractorIlcCode() {
    return this.contractorIlcCode;
  }

  /**
   * 見える化提供フラグを設定する。
   *
   * @param contractorVisualizationProvideFlag
   *          見える化提供フラグ
   */
  public void setContractorVisualizationProvideFlag(String contractorVisualizationProvideFlag) {
    this.contractorVisualizationProvideFlag = contractorVisualizationProvideFlag;
  }

  /**
   * 見える化提供フラグを取得する。
   *
   * @return 見える化提供フラグ
   */
  public String getContractorVisualizationProvideFlag() {
    return this.contractorVisualizationProvideFlag;
  }

  /**
   * 備考を設定する。
   *
   * @param contractorNote
   *          備考
   */
  public void setContractorNote(String contractorNote) {
    this.contractorNote = contractorNote;
  }

  /**
   * 備考を取得する。
   *
   * @return 備考
   */
  public String getContractorNote() {
    return this.contractorNote;
  }

  /**
   * 口座クレカIDを設定する。
   *
   * @param acInformationAccountCreId
   *          口座クレカID
   */
  public void setAcInformationAccountCreId(String acInformationAccountCreId) {
    this.acInformationAccountCreId = acInformationAccountCreId;
  }

  /**
   * 口座クレカIDを取得する。
   *
   * @return 口座クレカID
   */
  public String getAcInformationAccountCreId() {
    return this.acInformationAccountCreId;
  }

  /**
   * 契約者IDを設定する。
   *
   * @param acInformationContractorId
   *          契約者ID
   */
  public void setAcInformationContractorId(String acInformationContractorId) {
    this.acInformationContractorId = acInformationContractorId;
  }

  /**
   * 契約者IDを取得する。
   *
   * @return 契約者ID
   */
  public String getAcInformationContractorId() {
    return this.acInformationContractorId;
  }

  /**
   * 決済アクセスキーを設定する。
   *
   * @param acInformationAccessKey
   *          決済アクセスキー
   */
  public void setAcInformationAccessKey(String acInformationAccessKey) {
    this.acInformationAccessKey = acInformationAccessKey;
  }

  /**
   * 決済アクセスキーを取得する。
   *
   * @return 決済アクセスキー
   */
  public String getAcInformationAccessKey() {
    return this.acInformationAccessKey;
  }

  /**
   * 口座クレカ区分コードを設定する。
   *
   * @param acInformationAcCatCode
   *          口座クレカ区分コード
   */
  public void setAcInformationAcCatCode(String acInformationAcCatCode) {
    this.acInformationAcCatCode = acInformationAcCatCode;
  }

  /**
   * 口座クレカ区分コードを取得する。
   *
   * @return 口座クレカ区分コード
   */
  public String getAcInformationAcCatCode() {
    return this.acInformationAcCatCode;
  }

  /**
   * 金融機関コードを設定する。
   *
   * @param acInformationBankCode
   *          金融機関コード
   */
  public void setAcInformationBankCode(String acInformationBankCode) {
    this.acInformationBankCode = acInformationBankCode;
  }

  /**
   * 金融機関コードを取得する。
   *
   * @return 金融機関コード
   */
  public String getAcInformationBankCode() {
    return this.acInformationBankCode;
  }

  /**
   * 金融機関支店コードを設定する。
   *
   * @param acInformationBankBranchCode
   *          金融機関支店コード
   */
  public void setAcInformationBankBranchCode(String acInformationBankBranchCode) {
    this.acInformationBankBranchCode = acInformationBankBranchCode;
  }

  /**
   * 金融機関支店コードを取得する。
   *
   * @return 金融機関支店コード
   */
  public String getAcInformationBankBranchCode() {
    return this.acInformationBankBranchCode;
  }

  /**
   * 金融機関預金種目コードを設定する。
   *
   * @param acInformationBtOfAccountCode
   *          金融機関預金種目コード
   */
  public void setAcInformationBtOfAccountCode(String acInformationBtOfAccountCode) {
    this.acInformationBtOfAccountCode = acInformationBtOfAccountCode;
  }

  /**
   * 金融機関預金種目コードを取得する。
   *
   * @return 金融機関預金種目コード
   */
  public String getAcInformationBtOfAccountCode() {
    return this.acInformationBtOfAccountCode;
  }

  /**
   * 口座番号を設定する。
   *
   * @param acInformationAccountNo
   *          口座番号
   */
  public void setAcInformationAccountNo(String acInformationAccountNo) {
    this.acInformationAccountNo = acInformationAccountNo;
  }

  /**
   * 口座番号を取得する。
   *
   * @return 口座番号
   */
  public String getAcInformationAccountNo() {
    return this.acInformationAccountNo;
  }

  /**
   * 口座名義を設定する。
   *
   * @param acInformationAccountHolderName
   *          口座名義
   */
  public void setAcInformationAccountHolderName(String acInformationAccountHolderName) {
    this.acInformationAccountHolderName = acInformationAccountHolderName;
  }

  /**
   * 口座名義を取得する。
   *
   * @return 口座名義
   */
  public String getAcInformationAccountHolderName() {
    return this.acInformationAccountHolderName;
  }

  /**
   * クレカブランドコードを設定する。
   *
   * @param acInformationCreBrandCode
   *          クレカブランドコード
   */
  public void setAcInformationCreBrandCode(String acInformationCreBrandCode) {
    this.acInformationCreBrandCode = acInformationCreBrandCode;
  }

  /**
   * クレカブランドコードを取得する。
   *
   * @return クレカブランドコード
   */
  public String getAcInformationCreBrandCode() {
    return this.acInformationCreBrandCode;
  }

  /**
   * クレカ番号を設定する。
   *
   * @param acInformationCreNo
   *          クレカ番号
   */
  public void setAcInformationCreNo(String acInformationCreNo) {
    this.acInformationCreNo = acInformationCreNo;
  }

  /**
   * クレカ番号を取得する。
   *
   * @return クレカ番号
   */
  public String getAcInformationCreNo() {
    return this.acInformationCreNo;
  }

  /**
   * クレカ有効期限を設定する。
   *
   * @param acInformationCreExpirationDate
   *          クレカ有効期限
   */
  public void setAcInformationCreExpirationDate(String acInformationCreExpirationDate) {
    this.acInformationCreExpirationDate = acInformationCreExpirationDate;
  }

  /**
   * クレカ有効期限を取得する。
   *
   * @return クレカ有効期限
   */
  public String getAcInformationCreExpirationDate() {
    return this.acInformationCreExpirationDate;
  }

  /**
   * 利用不能フラグを設定する。
   *
   * @param acInformationUnavailableFlag
   *          利用不能フラグ
   */
  public void setAcInformationUnavailableFlag(String acInformationUnavailableFlag) {
    this.acInformationUnavailableFlag = acInformationUnavailableFlag;
  }

  /**
   * 利用不能フラグを取得する。
   *
   * @return 利用不能フラグ
   */
  public String getAcInformationUnavailableFlag() {
    return this.acInformationUnavailableFlag;
  }

  /**
   * 支払IDを設定する。
   *
   * @param paymentHistPaymentId
   *          支払ID
   */
  public void setPaymentHistPaymentId(String paymentHistPaymentId) {
    this.paymentHistPaymentId = paymentHistPaymentId;
  }

  /**
   * 支払IDを取得する。
   *
   * @return 支払ID
   */
  public String getPaymentHistPaymentId() {
    return this.paymentHistPaymentId;
  }

  /**
   * 支払適用開始日を設定する。
   *
   * @param paymentHistPaymentSd
   *          支払適用開始日
   */
  public void setPaymentHistPaymentSd(String paymentHistPaymentSd) {
    this.paymentHistPaymentSd = paymentHistPaymentSd;
  }

  /**
   * 支払適用開始日を取得する。
   *
   * @return 支払適用開始日
   */
  public String getPaymentHistPaymentSd() {
    return this.paymentHistPaymentSd;
  }

  /**
   * 支払適用終了日を設定する。
   *
   * @param paymentHistPaymentEd
   *          支払適用終了日
   */
  public void setPaymentHistPaymentEd(String paymentHistPaymentEd) {
    this.paymentHistPaymentEd = paymentHistPaymentEd;
  }

  /**
   * 支払適用終了日を取得する。
   *
   * @return 支払適用終了日
   */
  public String getPaymentHistPaymentEd() {
    return this.paymentHistPaymentEd;
  }

  /**
   * 支払方法コードを設定する。
   *
   * @param paymentHistPwCode
   *          支払方法コード
   */
  public void setPaymentHistPwCode(String paymentHistPwCode) {
    this.paymentHistPwCode = paymentHistPwCode;
  }

  /**
   * 支払方法コードを取得する。
   *
   * @return 支払方法コード
   */
  public String getPaymentHistPwCode() {
    return this.paymentHistPwCode;
  }

  /**
   * 口座クレカIDを設定する。
   *
   * @param paymentHistAccountCreId
   *          口座クレカID
   */
  public void setPaymentHistAccountCreId(String paymentHistAccountCreId) {
    this.paymentHistAccountCreId = paymentHistAccountCreId;
  }

  /**
   * 口座クレカIDを取得する。
   *
   * @return 口座クレカID
   */
  public String getPaymentHistAccountCreId() {
    return this.paymentHistAccountCreId;
  }

  /**
   * 個人・法人区分コードを設定する。
   *
   * @param paymentHistIlcCode
   *          個人・法人区分コード
   */
  public void setPaymentHistIlcCode(String paymentHistIlcCode) {
    this.paymentHistIlcCode = paymentHistIlcCode;
  }

  /**
   * 個人・法人区分コードを取得する。
   *
   * @return 個人・法人区分コード
   */
  public String getPaymentHistIlcCode() {
    return this.paymentHistIlcCode;
  }

  /**
   * 請求先氏名1を設定する。
   *
   * @param paymentHistBlName1
   *          請求先氏名1
   */
  public void setPaymentHistBlName1(String paymentHistBlName1) {
    this.paymentHistBlName1 = paymentHistBlName1;
  }

  /**
   * 請求先氏名1を取得する。
   *
   * @return 請求先氏名1
   */
  public String getPaymentHistBlName1() {
    return this.paymentHistBlName1;
  }

  /**
   * 請求先氏名2を設定する。
   *
   * @param paymentHistBlName2
   *          請求先氏名2
   */
  public void setPaymentHistBlName2(String paymentHistBlName2) {
    this.paymentHistBlName2 = paymentHistBlName2;
  }

  /**
   * 請求先氏名2を取得する。
   *
   * @return 請求先氏名2
   */
  public String getPaymentHistBlName2() {
    return this.paymentHistBlName2;
  }

  /**
   * 敬称を設定する。
   *
   * @param paymentHistPrefix
   *          敬称
   */
  public void setPaymentHistPrefix(String paymentHistPrefix) {
    this.paymentHistPrefix = paymentHistPrefix;
  }

  /**
   * 敬称を取得する。
   *
   * @return 敬称
   */
  public String getPaymentHistPrefix() {
    return this.paymentHistPrefix;
  }

  /**
   * 請求先住所（郵便番号）を設定する。
   *
   * @param paymentHistBlAddressPostalCode
   *          請求先住所（郵便番号）
   */
  public void setPaymentHistBlAddressPostalCode(String paymentHistBlAddressPostalCode) {
    this.paymentHistBlAddressPostalCode = paymentHistBlAddressPostalCode;
  }

  /**
   * 請求先住所（郵便番号）を取得する。
   *
   * @return 請求先住所（郵便番号）
   */
  public String getPaymentHistBlAddressPostalCode() {
    return this.paymentHistBlAddressPostalCode;
  }

  /**
   * 請求先住所（都道府県名）を設定する。
   *
   * @param paymentHistBlAddressPrefectures
   *          請求先住所（都道府県名）
   */
  public void setPaymentHistBlAddressPrefectures(String paymentHistBlAddressPrefectures) {
    this.paymentHistBlAddressPrefectures = paymentHistBlAddressPrefectures;
  }

  /**
   * 請求先住所（都道府県名）を取得する。
   *
   * @return 請求先住所（都道府県名）
   */
  public String getPaymentHistBlAddressPrefectures() {
    return this.paymentHistBlAddressPrefectures;
  }

  /**
   * 請求先住所（市区郡町村名）を設定する。
   *
   * @param paymentHistBlAddressMunicipality
   *          請求先住所（市区郡町村名）
   */
  public void setPaymentHistBlAddressMunicipality(String paymentHistBlAddressMunicipality) {
    this.paymentHistBlAddressMunicipality = paymentHistBlAddressMunicipality;
  }

  /**
   * 請求先住所（市区郡町村名）を取得する。
   *
   * @return 請求先住所（市区郡町村名）
   */
  public String getPaymentHistBlAddressMunicipality() {
    return this.paymentHistBlAddressMunicipality;
  }

  /**
   * 請求先住所（字名・丁目）を設定する。
   *
   * @param paymentHistBlAddressSection
   *          請求先住所（字名・丁目）
   */
  public void setPaymentHistBlAddressSection(String paymentHistBlAddressSection) {
    this.paymentHistBlAddressSection = paymentHistBlAddressSection;
  }

  /**
   * 請求先住所（字名・丁目）を取得する。
   *
   * @return 請求先住所（字名・丁目）
   */
  public String getPaymentHistBlAddressSection() {
    return this.paymentHistBlAddressSection;
  }

  /**
   * 請求先住所（番地･号）を設定する。
   *
   * @param paymentHistBlAddressBlock
   *          請求先住所（番地･号）
   */
  public void setPaymentHistBlAddressBlock(String paymentHistBlAddressBlock) {
    this.paymentHistBlAddressBlock = paymentHistBlAddressBlock;
  }

  /**
   * 請求先住所（番地･号）を取得する。
   *
   * @return 請求先住所（番地･号）
   */
  public String getPaymentHistBlAddressBlock() {
    return this.paymentHistBlAddressBlock;
  }

  /**
   * 請求先住所（建物名）を設定する。
   *
   * @param paymentHistBlAddressBuildingName
   *          請求先住所（建物名）
   */
  public void setPaymentHistBlAddressBuildingName(String paymentHistBlAddressBuildingName) {
    this.paymentHistBlAddressBuildingName = paymentHistBlAddressBuildingName;
  }

  /**
   * 請求先住所（建物名）を取得する。
   *
   * @return 請求先住所（建物名）
   */
  public String getPaymentHistBlAddressBuildingName() {
    return this.paymentHistBlAddressBuildingName;
  }

  /**
   * 請求先住所（部屋名）を設定する。
   *
   * @param paymentHistBlAddressRoom
   *          請求先住所（部屋名）
   */
  public void setPaymentHistBlAddressRoom(String paymentHistBlAddressRoom) {
    this.paymentHistBlAddressRoom = paymentHistBlAddressRoom;
  }

  /**
   * 請求先住所（部屋名）を取得する。
   *
   * @return 請求先住所（部屋名）
   */
  public String getPaymentHistBlAddressRoom() {
    return this.paymentHistBlAddressRoom;
  }

  /**
   * 請求先電話番号を設定する。
   *
   * @param paymentHistBlPhoneNo
   *          請求先電話番号
   */
  public void setPaymentHistBlPhoneNo(String paymentHistBlPhoneNo) {
    this.paymentHistBlPhoneNo = paymentHistBlPhoneNo;
  }

  /**
   * 請求先電話番号を取得する。
   *
   * @return 請求先電話番号
   */
  public String getPaymentHistBlPhoneNo() {
    return this.paymentHistBlPhoneNo;
  }

  /**
   * 請求先電話区分コードを設定する。
   *
   * @param paymentHistBlPhoneCatCode
   *          請求先電話区分コード
   */
  public void setPaymentHistBlPhoneCatCode(String paymentHistBlPhoneCatCode) {
    this.paymentHistBlPhoneCatCode = paymentHistBlPhoneCatCode;
  }

  /**
   * 請求先電話区分コードを取得する。
   *
   * @return 請求先電話区分コード
   */
  public String getPaymentHistBlPhoneCatCode() {
    return this.paymentHistBlPhoneCatCode;
  }

  /**
   * 請求先メールアドレス1を設定する。
   *
   * @param paymentHistBlMailAddress1
   *          請求先メールアドレス1
   */
  public void setPaymentHistBlMailAddress1(String paymentHistBlMailAddress1) {
    this.paymentHistBlMailAddress1 = paymentHistBlMailAddress1;
  }

  /**
   * 請求先メールアドレス1を取得する。
   *
   * @return 請求先メールアドレス1
   */
  public String getPaymentHistBlMailAddress1() {
    return this.paymentHistBlMailAddress1;
  }

  /**
   * 請求先メールアドレス2を設定する。
   *
   * @param paymentHistBlMailAddress2
   *          請求先メールアドレス2
   */
  public void setPaymentHistBlMailAddress2(String paymentHistBlMailAddress2) {
    this.paymentHistBlMailAddress2 = paymentHistBlMailAddress2;
  }

  /**
   * 請求先メールアドレス2を取得する。
   *
   * @return 請求先メールアドレス2
   */
  public String getPaymentHistBlMailAddress2() {
    return this.paymentHistBlMailAddress2;
  }

  /**
   * 需要場所IDを設定する。
   *
   * @param placePlaceId
   *          需要場所ID
   */
  public void setPlacePlaceId(String placePlaceId) {
    this.placePlaceId = placePlaceId;
  }

  /**
   * 需要場所IDを取得する。
   *
   * @return 需要場所ID
   */
  public String getPlacePlaceId() {
    return this.placePlaceId;
  }

  /**
   * 需要場所住所（郵便番号）を設定する。
   *
   * @param placePlaceAddressPostalCode
   *          需要場所住所（郵便番号）
   */
  public void setPlacePlaceAddressPostalCode(String placePlaceAddressPostalCode) {
    this.placePlaceAddressPostalCode = placePlaceAddressPostalCode;
  }

  /**
   * 需要場所住所（郵便番号）を取得する。
   *
   * @return 需要場所住所（郵便番号）
   */
  public String getPlacePlaceAddressPostalCode() {
    return this.placePlaceAddressPostalCode;
  }

  /**
   * 需要場所住所（住所）を設定する。
   *
   * @param placePlaceAddressFull
   *          需要場所住所（住所）
   */
  public void setPlacePlaceAddressFull(String placePlaceAddressFull) {
    this.placePlaceAddressFull = placePlaceAddressFull;
  }

  /**
   * 需要場所住所（住所）を取得する。
   *
   * @return 需要場所住所（住所）
   */
  public String getPlacePlaceAddressFull() {
    return this.placePlaceAddressFull;
  }

  /**
   * 需要場所住所（建物・部屋名）を設定する。
   *
   * @param placePlaceAddressBuilding
   *          需要場所住所（建物・部屋名）
   */
  public void setPlacePlaceAddressBuilding(String placePlaceAddressBuilding) {
    this.placePlaceAddressBuilding = placePlaceAddressBuilding;
  }

  /**
   * 需要場所住所（建物・部屋名）を取得する。
   *
   * @return 需要場所住所（建物・部屋名）
   */
  public String getPlacePlaceAddressBuilding() {
    return this.placePlaceAddressBuilding;
  }

  /**
   * 督促管理IDを設定する。
   *
   * @param urgeMngUrgeMngId
   *          督促管理ID
   */
  public void setUrgeMngUrgeMngId(String urgeMngUrgeMngId) {
    this.urgeMngUrgeMngId = urgeMngUrgeMngId;
  }

  /**
   * 督促管理IDを取得する。
   *
   * @return 督促管理ID
   */
  public String getUrgeMngUrgeMngId() {
    return this.urgeMngUrgeMngId;
  }

  /**
   * 解約予告請求IDを設定する。
   *
   * @param urgeMngCpBlId
   *          解約予告請求ID
   */
  public void setUrgeMngCpBlId(String urgeMngCpBlId) {
    this.urgeMngCpBlId = urgeMngCpBlId;
  }

  /**
   * 解約予告請求IDを取得する。
   *
   * @return 解約予告請求ID
   */
  public String getUrgeMngCpBlId() {
    return this.urgeMngCpBlId;
  }

  /**
   * 解約予告実施日を設定する。
   *
   * @param urgeMngCpEnforceDate
   *          解約予告実施日
   */
  public void setUrgeMngCpEnforceDate(String urgeMngCpEnforceDate) {
    this.urgeMngCpEnforceDate = urgeMngCpEnforceDate;
  }

  /**
   * 解約予告実施日を取得する。
   *
   * @return 解約予告実施日
   */
  public String getUrgeMngCpEnforceDate() {
    return this.urgeMngCpEnforceDate;
  }

  /**
   * 解約通知日を設定する。
   *
   * @param urgeMngCancellationNoticeDate
   *          解約通知日
   */
  public void setUrgeMngCancellationNoticeDate(String urgeMngCancellationNoticeDate) {
    this.urgeMngCancellationNoticeDate = urgeMngCancellationNoticeDate;
  }

  /**
   * 解約通知日を取得する。
   *
   * @return 解約通知日
   */
  public String getUrgeMngCancellationNoticeDate() {
    return this.urgeMngCancellationNoticeDate;
  }

  /**
   * 解約回避支払期日を設定する。
   *
   * @param urgeMngCePfd
   *          解約回避支払期日
   */
  public void setUrgeMngCePfd(String urgeMngCePfd) {
    this.urgeMngCePfd = urgeMngCePfd;
  }

  /**
   * 解約回避支払期日を取得する。
   *
   * @return 解約回避支払期日
   */
  public String getUrgeMngCePfd() {
    return this.urgeMngCePfd;
  }

  /**
   * 解約予定日を設定する。
   *
   * @param urgeMngCancellationScheduledDate
   *          解約予定日
   */
  public void setUrgeMngCancellationScheduledDate(String urgeMngCancellationScheduledDate) {
    this.urgeMngCancellationScheduledDate = urgeMngCancellationScheduledDate;
  }

  /**
   * 解約予定日を取得する。
   *
   * @return 解約予定日
   */
  public String getUrgeMngCancellationScheduledDate() {
    return this.urgeMngCancellationScheduledDate;
  }

  /**
   * 督促ステータスコードを設定する。
   *
   * @param urgeMngUrgeStatusCode
   *          督促ステータスコード
   */
  public void setUrgeMngUrgeStatusCode(String urgeMngUrgeStatusCode) {
    this.urgeMngUrgeStatusCode = urgeMngUrgeStatusCode;
  }

  /**
   * 督促ステータスコードを取得する。
   *
   * @return 督促ステータスコード
   */
  public String getUrgeMngUrgeStatusCode() {
    return this.urgeMngUrgeStatusCode;
  }

  /**
   * 解約回避理由コードを設定する。
   *
   * @param urgeMngCeReasonCode
   *          解約回避理由コード
   */
  public void setUrgeMngCeReasonCode(String urgeMngCeReasonCode) {
    this.urgeMngCeReasonCode = urgeMngCeReasonCode;
  }

  /**
   * 解約回避理由コードを取得する。
   *
   * @return 解約回避理由コード
   */
  public String getUrgeMngCeReasonCode() {
    return this.urgeMngCeReasonCode;
  }

  /**
   * 解約回避日を設定する。
   *
   * @param urgeMngCeDate
   *          解約回避日
   */
  public void setUrgeMngCeDate(String urgeMngCeDate) {
    this.urgeMngCeDate = urgeMngCeDate;
  }

  /**
   * 解約回避日を取得する。
   *
   * @return 解約回避日
   */
  public String getUrgeMngCeDate() {
    return this.urgeMngCeDate;
  }

  /**
   * 督促備考を設定する。
   *
   * @param urgeMngUrgeNote
   *          督促備考
   */
  public void setUrgeMngUrgeNote(String urgeMngUrgeNote) {
    this.urgeMngUrgeNote = urgeMngUrgeNote;
  }

  /**
   * 督促備考を取得する。
   *
   * @return 督促備考
   */
  public String getUrgeMngUrgeNote() {
    return this.urgeMngUrgeNote;
  }

  /**
   * 契約IDを設定する。
   *
   * @param contractContractId
   *          契約ID
   */
  public void setContractContractId(String contractContractId) {
    this.contractContractId = contractContractId;
  }

  /**
   * 契約IDを取得する。
   *
   * @return 契約ID
   */
  public String getContractContractId() {
    return this.contractContractId;
  }

  /**
   * 契約者IDを設定する。
   *
   * @param contractContractorId
   *          契約者ID
   */
  public void setContractContractorId(String contractContractorId) {
    this.contractContractorId = contractContractorId;
  }

  /**
   * 契約者IDを取得する。
   *
   * @return 契約者ID
   */
  public String getContractContractorId() {
    return this.contractContractorId;
  }

  /**
   * 支払IDを設定する。
   *
   * @param contractPaymentId
   *          支払ID
   */
  public void setContractPaymentId(String contractPaymentId) {
    this.contractPaymentId = contractPaymentId;
  }

  /**
   * 支払IDを取得する。
   *
   * @return 支払ID
   */
  public String getContractPaymentId() {
    return this.contractPaymentId;
  }

  /**
   * 契約開始日を設定する。
   *
   * @param contractContractSd
   *          契約開始日
   */
  public void setContractContractSd(String contractContractSd) {
    this.contractContractSd = contractContractSd;
  }

  /**
   * 契約開始日を取得する。
   *
   * @return 契約開始日
   */
  public String getContractContractSd() {
    return this.contractContractSd;
  }

  /**
   * 契約終了日を設定する。
   *
   * @param contractContractEd
   *          契約終了日
   */
  public void setContractContractEd(String contractContractEd) {
    this.contractContractEd = contractContractEd;
  }

  /**
   * 契約終了日を取得する。
   *
   * @return 契約終了日
   */
  public String getContractContractEd() {
    return this.contractContractEd;
  }

  /**
   * 契約番号を設定する。
   *
   * @param contractContractNo
   *          契約番号
   */
  public void setContractContractNo(String contractContractNo) {
    this.contractContractNo = contractContractNo;
  }

  /**
   * 契約番号を取得する。
   *
   * @return 契約番号
   */
  public String getContractContractNo() {
    return this.contractContractNo;
  }

  /**
   * 契約終了理由コードを設定する。
   *
   * @param contractContractEndReasonCode
   *          契約終了理由コード
   */
  public void setContractContractEndReasonCode(String contractContractEndReasonCode) {
    this.contractContractEndReasonCode = contractContractEndReasonCode;
  }

  /**
   * 契約終了理由コードを取得する。
   *
   * @return 契約終了理由コード
   */
  public String getContractContractEndReasonCode() {
    return this.contractContractEndReasonCode;
  }

  /**
   * 料金チェックフラグを設定する。
   *
   * @param contractChargeCheckFlag
   *          料金チェックフラグ
   */
  public void setContractChargeCheckFlag(String contractChargeCheckFlag) {
    this.contractChargeCheckFlag = contractChargeCheckFlag;
  }

  /**
   * 料金チェックフラグを取得する。
   *
   * @return 料金チェックフラグ
   */
  public String getContractChargeCheckFlag() {
    return this.contractChargeCheckFlag;
  }

  /**
   * 営業委託先コードを設定する。
   *
   * @param contractScCode
   *          営業委託先コード
   */
  public void setContractScCode(String contractScCode) {
    this.contractScCode = contractScCode;
  }

  /**
   * 営業委託先コードを取得する。
   *
   * @return 営業委託先コード
   */
  public String getContractScCode() {
    return this.contractScCode;
  }

  /**
   * 契約グループ番号を設定する。
   *
   * @param contractContractGroupNo
   *          契約グループ番号
   */
  public void setContractContractGroupNo(String contractContractGroupNo) {
    this.contractContractGroupNo = contractContractGroupNo;
  }

  /**
   * 契約グループ番号を取得する。
   *
   * @return 契約グループ番号
   */
  public String getContractContractGroupNo() {
    return this.contractContractGroupNo;
  }

  /**
   * 個人・法人区分コードを設定する。
   *
   * @param contractIlcCode
   *          個人・法人区分コード
   */
  public void setContractIlcCode(String contractIlcCode) {
    this.contractIlcCode = contractIlcCode;
  }

  /**
   * 個人・法人区分コードを取得する。
   *
   * @return 個人・法人区分コード
   */
  public String getContractIlcCode() {
    return this.contractIlcCode;
  }

  /**
   * 連絡先氏名（カナ）を設定する。
   *
   * @param contractCiNameKana
   *          連絡先氏名（カナ）
   */
  public void setContractCiNameKana(String contractCiNameKana) {
    this.contractCiNameKana = contractCiNameKana;
  }

  /**
   * 連絡先氏名（カナ）を取得する。
   *
   * @return 連絡先氏名（カナ）
   */
  public String getContractCiNameKana() {
    return this.contractCiNameKana;
  }

  /**
   * 連絡先氏名1を設定する。
   *
   * @param contractCiName1
   *          連絡先氏名1
   */
  public void setContractCiName1(String contractCiName1) {
    this.contractCiName1 = contractCiName1;
  }

  /**
   * 連絡先氏名1を取得する。
   *
   * @return 連絡先氏名1
   */
  public String getContractCiName1() {
    return this.contractCiName1;
  }

  /**
   * 連絡先氏名2を設定する。
   *
   * @param contractCiName2
   *          連絡先氏名2
   */
  public void setContractCiName2(String contractCiName2) {
    this.contractCiName2 = contractCiName2;
  }

  /**
   * 連絡先氏名2を取得する。
   *
   * @return 連絡先氏名2
   */
  public String getContractCiName2() {
    return this.contractCiName2;
  }

  /**
   * 連絡先住所（郵便番号）を設定する。
   *
   * @param contractCiAddressPostalCode
   *          連絡先住所（郵便番号）
   */
  public void setContractCiAddressPostalCode(String contractCiAddressPostalCode) {
    this.contractCiAddressPostalCode = contractCiAddressPostalCode;
  }

  /**
   * 連絡先住所（郵便番号）を取得する。
   *
   * @return 連絡先住所（郵便番号）
   */
  public String getContractCiAddressPostalCode() {
    return this.contractCiAddressPostalCode;
  }

  /**
   * 連絡先住所（住所）を設定する。
   *
   * @param contractCiAddressFull
   *          連絡先住所（住所）
   */
  public void setContractCiAddressFull(String contractCiAddressFull) {
    this.contractCiAddressFull = contractCiAddressFull;
  }

  /**
   * 連絡先住所（住所）を取得する。
   *
   * @return 連絡先住所（住所）
   */
  public String getContractCiAddressFull() {
    return this.contractCiAddressFull;
  }

  /**
   * 連絡先住所（建物・部屋名）を設定する。
   *
   * @param contractCiAddressBuilding
   *          連絡先住所（建物・部屋名）
   */
  public void setContractCiAddressBuilding(String contractCiAddressBuilding) {
    this.contractCiAddressBuilding = contractCiAddressBuilding;
  }

  /**
   * 連絡先住所（建物・部屋名）を取得する。
   *
   * @return 連絡先住所（建物・部屋名）
   */
  public String getContractCiAddressBuilding() {
    return this.contractCiAddressBuilding;
  }

  /**
   * 連絡先電話番号を設定する。
   *
   * @param contractCiPhoneNo
   *          連絡先電話番号
   */
  public void setContractCiPhoneNo(String contractCiPhoneNo) {
    this.contractCiPhoneNo = contractCiPhoneNo;
  }

  /**
   * 連絡先電話番号を取得する。
   *
   * @return 連絡先電話番号
   */
  public String getContractCiPhoneNo() {
    return this.contractCiPhoneNo;
  }

  /**
   * 連絡先電話区分コードを設定する。
   *
   * @param contractCiCatCode
   *          連絡先電話区分コード
   */
  public void setContractCiCatCode(String contractCiCatCode) {
    this.contractCiCatCode = contractCiCatCode;
  }

  /**
   * 連絡先電話区分コードを取得する。
   *
   * @return 連絡先電話区分コード
   */
  public String getContractCiCatCode() {
    return this.contractCiCatCode;
  }

  /**
   * 連絡先電話（市外局番）を設定する。
   *
   * @param contractCiAreaCode
   *          連絡先電話（市外局番）
   */
  public void setContractCiAreaCode(String contractCiAreaCode) {
    this.contractCiAreaCode = contractCiAreaCode;
  }

  /**
   * 連絡先電話（市外局番）を取得する。
   *
   * @return 連絡先電話（市外局番）
   */
  public String getContractCiAreaCode() {
    return this.contractCiAreaCode;
  }

  /**
   * 連絡先電話（市内局番）を設定する。
   *
   * @param contractCiLocalNo
   *          連絡先電話（市内局番）
   */
  public void setContractCiLocalNo(String contractCiLocalNo) {
    this.contractCiLocalNo = contractCiLocalNo;
  }

  /**
   * 連絡先電話（市内局番）を取得する。
   *
   * @return 連絡先電話（市内局番）
   */
  public String getContractCiLocalNo() {
    return this.contractCiLocalNo;
  }

  /**
   * 連絡先電話（加入者番号）を設定する。
   *
   * @param contractCiDirectoryNo
   *          連絡先電話（加入者番号）
   */
  public void setContractCiDirectoryNo(String contractCiDirectoryNo) {
    this.contractCiDirectoryNo = contractCiDirectoryNo;
  }

  /**
   * 連絡先電話（加入者番号）を取得する。
   *
   * @return 連絡先電話（加入者番号）
   */
  public String getContractCiDirectoryNo() {
    return this.contractCiDirectoryNo;
  }

  /**
   * 業種コードを設定する。
   *
   * @param contractBusinessTypeCode
   *          業種コード
   */
  public void setContractBusinessTypeCode(String contractBusinessTypeCode) {
    this.contractBusinessTypeCode = contractBusinessTypeCode;
  }

  /**
   * 業種コードを取得する。
   *
   * @return 業種コード
   */
  public String getContractBusinessTypeCode() {
    return this.contractBusinessTypeCode;
  }

  /**
   * 接続送電サービス区分コードを設定する。
   *
   * @param contractCssCatCode
   *          接続送電サービス区分コード
   */
  public void setContractCssCatCode(String contractCssCatCode) {
    this.contractCssCatCode = contractCssCatCode;
  }

  /**
   * 接続送電サービス区分コードを取得する。
   *
   * @return 接続送電サービス区分コード
   */
  public String getContractCssCatCode() {
    return this.contractCssCatCode;
  }

  /**
   * 託送契約容量を設定する。
   *
   * @param contractConsignmentCca
   *          託送契約容量
   */
  public void setContractConsignmentCca(String contractConsignmentCca) {
    this.contractConsignmentCca = contractConsignmentCca;
  }

  /**
   * 託送契約容量を取得する。
   *
   * @return 託送契約容量
   */
  public String getContractConsignmentCca() {
    return this.contractConsignmentCca;
  }

  /**
   * 託送契約容量単位を設定する。
   *
   * @param contractConsignmentCcaUnit
   *          託送契約容量単位
   */
  public void setContractConsignmentCcaUnit(String contractConsignmentCcaUnit) {
    this.contractConsignmentCcaUnit = contractConsignmentCcaUnit;
  }

  /**
   * 託送契約容量単位を取得する。
   *
   * @return 託送契約容量単位
   */
  public String getContractConsignmentCcaUnit() {
    return this.contractConsignmentCcaUnit;
  }

  /**
   * 託送契約容量判定日を設定する。
   *
   * @param contractConsignmentCcaDecisionDate
   *          託送契約容量判定日
   */
  public void setContractConsignmentCcaDecisionDate(String contractConsignmentCcaDecisionDate) {
    this.contractConsignmentCcaDecisionDate = contractConsignmentCcaDecisionDate;
  }

  /**
   * 託送契約容量判定日を取得する。
   *
   * @return 託送契約容量判定日
   */
  public String getContractConsignmentCcaDecisionDate() {
    return this.contractConsignmentCcaDecisionDate;
  }

  /**
   * 契約終了分確定使用量連携済フラグを設定する。
   *
   * @param contractContractEndFuSentFlag
   *          契約終了分確定使用量連携済フラグ
   */
  public void setContractContractEndFuSentFlag(String contractContractEndFuSentFlag) {
    this.contractContractEndFuSentFlag = contractContractEndFuSentFlag;
  }

  /**
   * 契約終了分確定使用量連携済フラグを取得する。
   *
   * @return 契約終了分確定使用量連携済フラグ
   */
  public String getContractContractEndFuSentFlag() {
    return this.contractContractEndFuSentFlag;
  }

  /**
   * 備考を設定する。
   *
   * @param contractNote
   *          備考
   */
  public void setContractNote(String contractNote) {
    this.contractNote = contractNote;
  }

  /**
   * 備考を取得する。
   *
   * @return 備考
   */
  public String getContractNote() {
    return this.contractNote;
  }

  /**
   * フリー項目1を設定する。
   *
   * @param contractFree1
   *          フリー項目1
   */
  public void setContractFree1(String contractFree1) {
    this.contractFree1 = contractFree1;
  }

  /**
   * フリー項目1を取得する。
   *
   * @return フリー項目1
   */
  public String getContractFree1() {
    return this.contractFree1;
  }

  /**
   * フリー項目2を設定する。
   *
   * @param contractFree2
   *          フリー項目2
   */
  public void setContractFree2(String contractFree2) {
    this.contractFree2 = contractFree2;
  }

  /**
   * フリー項目2を取得する。
   *
   * @return フリー項目2
   */
  public String getContractFree2() {
    return this.contractFree2;
  }

  /**
   * フリー項目3を設定する。
   *
   * @param contractFree3
   *          フリー項目3
   */
  public void setContractFree3(String contractFree3) {
    this.contractFree3 = contractFree3;
  }

  /**
   * フリー項目3を取得する。
   *
   * @return フリー項目3
   */
  public String getContractFree3() {
    return this.contractFree3;
  }

  /**
   * フリー項目4を設定する。
   *
   * @param contractFree4
   *          フリー項目4
   */
  public void setContractFree4(String contractFree4) {
    this.contractFree4 = contractFree4;
  }

  /**
   * フリー項目4を取得する。
   *
   * @return フリー項目4
   */
  public String getContractFree4() {
    return this.contractFree4;
  }

  /**
   * フリー項目5を設定する。
   *
   * @param contractFree5
   *          フリー項目5
   */
  public void setContractFree5(String contractFree5) {
    this.contractFree5 = contractFree5;
  }

  /**
   * フリー項目5を取得する。
   *
   * @return フリー項目5
   */
  public String getContractFree5() {
    return this.contractFree5;
  }

  /**
   * フリー項目6を設定する。
   *
   * @param contractFree6
   *          フリー項目6
   */
  public void setContractFree6(String contractFree6) {
    this.contractFree6 = contractFree6;
  }

  /**
   * フリー項目6を取得する。
   *
   * @return フリー項目6
   */
  public String getContractFree6() {
    return this.contractFree6;
  }

  /**
   * フリー項目7を設定する。
   *
   * @param contractFree7
   *          フリー項目7
   */
  public void setContractFree7(String contractFree7) {
    this.contractFree7 = contractFree7;
  }

  /**
   * フリー項目7を取得する。
   *
   * @return フリー項目7
   */
  public String getContractFree7() {
    return this.contractFree7;
  }

  /**
   * フリー項目8を設定する。
   *
   * @param contractFree8
   *          フリー項目8
   */
  public void setContractFree8(String contractFree8) {
    this.contractFree8 = contractFree8;
  }

  /**
   * フリー項目8を取得する。
   *
   * @return フリー項目8
   */
  public String getContractFree8() {
    return this.contractFree8;
  }

  /**
   * フリー項目9を設定する。
   *
   * @param contractFree9
   *          フリー項目9
   */
  public void setContractFree9(String contractFree9) {
    this.contractFree9 = contractFree9;
  }

  /**
   * フリー項目9を取得する。
   *
   * @return フリー項目9
   */
  public String getContractFree9() {
    return this.contractFree9;
  }

  /**
   * フリー項目10を設定する。
   *
   * @param contractFree10
   *          フリー項目10
   */
  public void setContractFree10(String contractFree10) {
    this.contractFree10 = contractFree10;
  }

  /**
   * フリー項目10を取得する。
   *
   * @return フリー項目10
   */
  public String getContractFree10() {
    return this.contractFree10;
  }

  /**
   * フリー項目11を設定する。
   *
   * @param contractFree11
   *          フリー項目11
   */
  public void setContractFree11(String contractFree11) {
    this.contractFree11 = contractFree11;
  }

  /**
   * フリー項目11を取得する。
   *
   * @return フリー項目11
   */
  public String getContractFree11() {
    return this.contractFree11;
  }

  /**
   * フリー項目12を設定する。
   *
   * @param contractFree12
   *          フリー項目12
   */
  public void setContractFree12(String contractFree12) {
    this.contractFree12 = contractFree12;
  }

  /**
   * フリー項目12を取得する。
   *
   * @return フリー項目12
   */
  public String getContractFree12() {
    return this.contractFree12;
  }

  /**
   * フリー項目13を設定する。
   *
   * @param contractFree13
   *          フリー項目13
   */
  public void setContractFree13(String contractFree13) {
    this.contractFree13 = contractFree13;
  }

  /**
   * フリー項目13を取得する。
   *
   * @return フリー項目13
   */
  public String getContractFree13() {
    return this.contractFree13;
  }

  /**
   * フリー項目14を設定する。
   *
   * @param contractFree14
   *          フリー項目14
   */
  public void setContractFree14(String contractFree14) {
    this.contractFree14 = contractFree14;
  }

  /**
   * フリー項目14を取得する。
   *
   * @return フリー項目14
   */
  public String getContractFree14() {
    return this.contractFree14;
  }

  /**
   * 委託先使用項目1を設定する。
   *
   * @param contractConsignmentUseItem1
   *          委託先使用項目1
   */
  public void setContractConsignmentUseItem1(String contractConsignmentUseItem1) {
    this.contractConsignmentUseItem1 = contractConsignmentUseItem1;
  }

  /**
   * 委託先使用項目1を取得する。
   *
   * @return 委託先使用項目1
   */
  public String getContractConsignmentUseItem1() {
    return this.contractConsignmentUseItem1;
  }

  /**
   * 委託先使用項目2を設定する。
   *
   * @param contractConsignmentUseItem2
   *          委託先使用項目2
   */
  public void setContractConsignmentUseItem2(String contractConsignmentUseItem2) {
    this.contractConsignmentUseItem2 = contractConsignmentUseItem2;
  }

  /**
   * 委託先使用項目2を取得する。
   *
   * @return 委託先使用項目2
   */
  public String getContractConsignmentUseItem2() {
    return this.contractConsignmentUseItem2;
  }

  /**
   * 委託先使用項目3を設定する。
   *
   * @param contractConsignmentUseItem3
   *          委託先使用項目3
   */
  public void setContractConsignmentUseItem3(String contractConsignmentUseItem3) {
    this.contractConsignmentUseItem3 = contractConsignmentUseItem3;
  }

  /**
   * 委託先使用項目3を取得する。
   *
   * @return 委託先使用項目3
   */
  public String getContractConsignmentUseItem3() {
    return this.contractConsignmentUseItem3;
  }

  /**
   * 自社担当者コードを設定する。
   *
   * @param contractOurMngPersonInChargeCode
   *          自社担当者コード
   */
  public void setContractOurMngPersonInChargeCode(String contractOurMngPersonInChargeCode) {
    this.contractOurMngPersonInChargeCode = contractOurMngPersonInChargeCode;
  }

  /**
   * 自社担当者コードを取得する。
   *
   * @return 自社担当者コード
   */
  public String getContractOurMngPersonInChargeCode() {
    return this.contractOurMngPersonInChargeCode;
  }

  /**
   * 自社部署コードを設定する。
   *
   * @param contractOurMngDepartmentCode
   *          自社部署コード
   */
  public void setContractOurMngDepartmentCode(String contractOurMngDepartmentCode) {
    this.contractOurMngDepartmentCode = contractOurMngDepartmentCode;
  }

  /**
   * 自社部署コードを取得する。
   *
   * @return 自社部署コード
   */
  public String getContractOurMngDepartmentCode() {
    return this.contractOurMngDepartmentCode;
  }

  /**
   * 提供モデルコードを設定する。
   *
   * @param pmCompanyMPmCode
   *          提供モデルコード
   */
  public void setPmCompanyMPmCode(String pmCompanyMPmCode) {
    this.pmCompanyMPmCode = pmCompanyMPmCode;
  }

  /**
   * 提供モデルコードを取得する。
   *
   * @return 提供モデルコード
   */
  public String getPmCompanyMPmCode() {
    return this.pmCompanyMPmCode;
  }

  /**
   * 提供モデル企業コードを設定する。
   *
   * @param pmCompanyMPmCompanyCode
   *          提供モデル企業コード
   */
  public void setPmCompanyMPmCompanyCode(String pmCompanyMPmCompanyCode) {
    this.pmCompanyMPmCompanyCode = pmCompanyMPmCompanyCode;
  }

  /**
   * 提供モデル企業コードを取得する。
   *
   * @return 提供モデル企業コード
   */
  public String getPmCompanyMPmCompanyCode() {
    return this.pmCompanyMPmCompanyCode;
  }

  /**
   * 提供モデル企業を設定する。
   *
   * @param pmCompanyMPmCompany
   *          提供モデル企業
   */
  public void setPmCompanyMPmCompany(String pmCompanyMPmCompany) {
    this.pmCompanyMPmCompany = pmCompanyMPmCompany;
  }

  /**
   * 提供モデル企業を取得する。
   *
   * @return 提供モデル企業
   */
  public String getPmCompanyMPmCompany() {
    return this.pmCompanyMPmCompany;
  }

  /**
   * 提供モデル企業（カナ）を設定する。
   *
   * @param pmCompanyMPmCompanyKana
   *          提供モデル企業（カナ）
   */
  public void setPmCompanyMPmCompanyKana(String pmCompanyMPmCompanyKana) {
    this.pmCompanyMPmCompanyKana = pmCompanyMPmCompanyKana;
  }

  /**
   * 提供モデル企業（カナ）を取得する。
   *
   * @return 提供モデル企業（カナ）
   */
  public String getPmCompanyMPmCompanyKana() {
    return this.pmCompanyMPmCompanyKana;
  }

  /**
   * 有効開始日を設定する。
   *
   * @param pmCompanyMEffectiveSd
   *          有効開始日
   */
  public void setPmCompanyMEffectiveSd(String pmCompanyMEffectiveSd) {
    this.pmCompanyMEffectiveSd = pmCompanyMEffectiveSd;
  }

  /**
   * 有効開始日を取得する。
   *
   * @return 有効開始日
   */
  public String getPmCompanyMEffectiveSd() {
    return this.pmCompanyMEffectiveSd;
  }

  /**
   * 有効終了日を設定する。
   *
   * @param pmCompanyMEffectiveEd
   *          有効終了日
   */
  public void setPmCompanyMEffectiveEd(String pmCompanyMEffectiveEd) {
    this.pmCompanyMEffectiveEd = pmCompanyMEffectiveEd;
  }

  /**
   * 有効終了日を取得する。
   *
   * @return 有効終了日
   */
  public String getPmCompanyMEffectiveEd() {
    return this.pmCompanyMEffectiveEd;
  }

  /**
   * 郵送先（郵便番号）を設定する。
   *
   * @param pmCompanyMAddresseePostalCode
   *          郵送先（郵便番号）
   */
  public void setPmCompanyMAddresseePostalCode(String pmCompanyMAddresseePostalCode) {
    this.pmCompanyMAddresseePostalCode = pmCompanyMAddresseePostalCode;
  }

  /**
   * 郵送先（郵便番号）を取得する。
   *
   * @return 郵送先（郵便番号）
   */
  public String getPmCompanyMAddresseePostalCode() {
    return this.pmCompanyMAddresseePostalCode;
  }

  /**
   * 郵送先（都道府県名）を設定する。
   *
   * @param pmCompanyMAddresseePrefectures
   *          郵送先（都道府県名）
   */
  public void setPmCompanyMAddresseePrefectures(String pmCompanyMAddresseePrefectures) {
    this.pmCompanyMAddresseePrefectures = pmCompanyMAddresseePrefectures;
  }

  /**
   * 郵送先（都道府県名）を取得する。
   *
   * @return 郵送先（都道府県名）
   */
  public String getPmCompanyMAddresseePrefectures() {
    return this.pmCompanyMAddresseePrefectures;
  }

  /**
   * 郵送先（市区郡町村名）を設定する。
   *
   * @param pmCompanyMAddresseeMunicipality
   *          郵送先（市区郡町村名）
   */
  public void setPmCompanyMAddresseeMunicipality(String pmCompanyMAddresseeMunicipality) {
    this.pmCompanyMAddresseeMunicipality = pmCompanyMAddresseeMunicipality;
  }

  /**
   * 郵送先（市区郡町村名）を取得する。
   *
   * @return 郵送先（市区郡町村名）
   */
  public String getPmCompanyMAddresseeMunicipality() {
    return this.pmCompanyMAddresseeMunicipality;
  }

  /**
   * 郵送先（字名・丁目）を設定する。
   *
   * @param pmCompanyMAddresseeSection
   *          郵送先（字名・丁目）
   */
  public void setPmCompanyMAddresseeSection(String pmCompanyMAddresseeSection) {
    this.pmCompanyMAddresseeSection = pmCompanyMAddresseeSection;
  }

  /**
   * 郵送先（字名・丁目）を取得する。
   *
   * @return 郵送先（字名・丁目）
   */
  public String getPmCompanyMAddresseeSection() {
    return this.pmCompanyMAddresseeSection;
  }

  /**
   * 郵送先（番地・号）を設定する。
   *
   * @param pmCompanyMAddresseeBlock
   *          郵送先（番地・号）
   */
  public void setPmCompanyMAddresseeBlock(String pmCompanyMAddresseeBlock) {
    this.pmCompanyMAddresseeBlock = pmCompanyMAddresseeBlock;
  }

  /**
   * 郵送先（番地・号）を取得する。
   *
   * @return 郵送先（番地・号）
   */
  public String getPmCompanyMAddresseeBlock() {
    return this.pmCompanyMAddresseeBlock;
  }

  /**
   * 郵送先（建物名）を設定する。
   *
   * @param pmCompanyMAddresseeBuildingName
   *          郵送先（建物名）
   */
  public void setPmCompanyMAddresseeBuildingName(String pmCompanyMAddresseeBuildingName) {
    this.pmCompanyMAddresseeBuildingName = pmCompanyMAddresseeBuildingName;
  }

  /**
   * 郵送先（建物名）を取得する。
   *
   * @return 郵送先（建物名）
   */
  public String getPmCompanyMAddresseeBuildingName() {
    return this.pmCompanyMAddresseeBuildingName;
  }

  /**
   * 郵送先（部屋名）を設定する。
   *
   * @param pmCompanyMAddresseeRoom
   *          郵送先（部屋名）
   */
  public void setPmCompanyMAddresseeRoom(String pmCompanyMAddresseeRoom) {
    this.pmCompanyMAddresseeRoom = pmCompanyMAddresseeRoom;
  }

  /**
   * 郵送先（部屋名）を取得する。
   *
   * @return 郵送先（部屋名）
   */
  public String getPmCompanyMAddresseeRoom() {
    return this.pmCompanyMAddresseeRoom;
  }

  /**
   * 郵送先（宛名１）を設定する。
   *
   * @param pmCompanyMAddresseeMailingName1
   *          郵送先（宛名１）
   */
  public void setPmCompanyMAddresseeMailingName1(String pmCompanyMAddresseeMailingName1) {
    this.pmCompanyMAddresseeMailingName1 = pmCompanyMAddresseeMailingName1;
  }

  /**
   * 郵送先（宛名１）を取得する。
   *
   * @return 郵送先（宛名１）
   */
  public String getPmCompanyMAddresseeMailingName1() {
    return this.pmCompanyMAddresseeMailingName1;
  }

  /**
   * 郵送先（宛名２）を設定する。
   *
   * @param pmCompanyMAddresseeMailingName2
   *          郵送先（宛名２）
   */
  public void setPmCompanyMAddresseeMailingName2(String pmCompanyMAddresseeMailingName2) {
    this.pmCompanyMAddresseeMailingName2 = pmCompanyMAddresseeMailingName2;
  }

  /**
   * 郵送先（宛名２）を取得する。
   *
   * @return 郵送先（宛名２）
   */
  public String getPmCompanyMAddresseeMailingName2() {
    return this.pmCompanyMAddresseeMailingName2;
  }

  /**
   * 敬称を設定する。
   *
   * @param pmCompanyMPrefix
   *          敬称
   */
  public void setPmCompanyMPrefix(String pmCompanyMPrefix) {
    this.pmCompanyMPrefix = pmCompanyMPrefix;
  }

  /**
   * 敬称を取得する。
   *
   * @return 敬称
   */
  public String getPmCompanyMPrefix() {
    return this.pmCompanyMPrefix;
  }

  /**
   * 支払期日日数を設定する。
   *
   * @param pmCompanyMPfdDays
   *          支払期日日数
   */
  public void setPmCompanyMPfdDays(String pmCompanyMPfdDays) {
    this.pmCompanyMPfdDays = pmCompanyMPfdDays;
  }

  /**
   * 支払期日日数を取得する。
   *
   * @return 支払期日日数
   */
  public String getPmCompanyMPfdDays() {
    return this.pmCompanyMPfdDays;
  }

  /**
   * 割当金融機関コードを設定する。
   *
   * @param pmCompanyMAllotmentBankCode
   *          割当金融機関コード
   */
  public void setPmCompanyMAllotmentBankCode(String pmCompanyMAllotmentBankCode) {
    this.pmCompanyMAllotmentBankCode = pmCompanyMAllotmentBankCode;
  }

  /**
   * 割当金融機関コードを取得する。
   *
   * @return 割当金融機関コード
   */
  public String getPmCompanyMAllotmentBankCode() {
    return this.pmCompanyMAllotmentBankCode;
  }

  /**
   * 割当金融機関支店コードを設定する。
   *
   * @param pmCompanyMAllotmentBankBranchCode
   *          割当金融機関支店コード
   */
  public void setPmCompanyMAllotmentBankBranchCode(String pmCompanyMAllotmentBankBranchCode) {
    this.pmCompanyMAllotmentBankBranchCode = pmCompanyMAllotmentBankBranchCode;
  }

  /**
   * 割当金融機関支店コードを取得する。
   *
   * @return 割当金融機関支店コード
   */
  public String getPmCompanyMAllotmentBankBranchCode() {
    return this.pmCompanyMAllotmentBankBranchCode;
  }

  /**
   * 割当預金種目コードを設定する。
   *
   * @param pmCompanyMAllotmentBtOfAccountCode
   *          割当預金種目コード
   */
  public void setPmCompanyMAllotmentBtOfAccountCode(String pmCompanyMAllotmentBtOfAccountCode) {
    this.pmCompanyMAllotmentBtOfAccountCode = pmCompanyMAllotmentBtOfAccountCode;
  }

  /**
   * 割当預金種目コードを取得する。
   *
   * @return 割当預金種目コード
   */
  public String getPmCompanyMAllotmentBtOfAccountCode() {
    return this.pmCompanyMAllotmentBtOfAccountCode;
  }

  /**
   * 割当口座番号を設定する。
   *
   * @param pmCompanyMAaNo
   *          割当口座番号
   */
  public void setPmCompanyMAaNo(String pmCompanyMAaNo) {
    this.pmCompanyMAaNo = pmCompanyMAaNo;
  }

  /**
   * 割当口座番号を取得する。
   *
   * @return 割当口座番号
   */
  public String getPmCompanyMAaNo() {
    return this.pmCompanyMAaNo;
  }

  /**
   * 割当口座名義を設定する。
   *
   * @param pmCompanyMAaHolderName
   *          割当口座名義
   */
  public void setPmCompanyMAaHolderName(String pmCompanyMAaHolderName) {
    this.pmCompanyMAaHolderName = pmCompanyMAaHolderName;
  }

  /**
   * 割当口座名義を取得する。
   *
   * @return 割当口座名義
   */
  public String getPmCompanyMAaHolderName() {
    return this.pmCompanyMAaHolderName;
  }

  /**
   * 見える化提供フラグを設定する。
   *
   * @param pmCompanyMVisualizationProvideFlag
   *          見える化提供フラグ
   */
  public void setPmCompanyMVisualizationProvideFlag(String pmCompanyMVisualizationProvideFlag) {
    this.pmCompanyMVisualizationProvideFlag = pmCompanyMVisualizationProvideFlag;
  }

  /**
   * 見える化提供フラグを取得する。
   *
   * @return 見える化提供フラグ
   */
  public String getPmCompanyMVisualizationProvideFlag() {
    return this.pmCompanyMVisualizationProvideFlag;
  }

  /**
   * PPS区分を設定する。
   *
   * @param pmCompanyMPpsCat
   *          PPS区分
   */
  public void setPmCompanyMPpsCat(String pmCompanyMPpsCat) {
    this.pmCompanyMPpsCat = pmCompanyMPpsCat;
  }

  /**
   * PPS区分を取得する。
   *
   * @return PPS区分
   */
  public String getPmCompanyMPpsCat() {
    return this.pmCompanyMPpsCat;
  }

  /**
   * 《確定料金実績EntityBean》リストを設定する。
   *
   * @param fcrList
   *          《確定料金実績EntityBean》リスト
   */
  public void setFcrList(List<Fcr> fcrList) {
    this.fcrList = fcrList;
  }

  /**
   * 《確定料金実績EntityBean》リストを取得する。
   *
   * @return 《確定料金実績EntityBean》リスト
   */
  public List<Fcr> getFcrList() {
    return this.fcrList;
  }

  /**
   * 全契約番号リストを設定する。
   *
   * @param contractNoList
   *          全契約番号リスト
   */
  public void setContractNoList(List<String> contractNoList) {
    this.contractNoList = contractNoList;
  }

  /**
   * 全契約番号リストを取得する。
   *
   * @return 全契約番号リスト
   */
  public List<String> getContractNoList() {
    return this.contractNoList;
  }

  /**
   * 地点特定番号を設定する。
   *
   * @param spotNo
   *          地点特定番号
   */
  public void setSpotNo(String spotNo) {
    this.spotNo = spotNo;
  }

  /**
   * 地点特定番号を取得する。
   *
   * @return 地点特定番号
   */
  public String getSpotNo() {
    return this.spotNo;
  }
}
