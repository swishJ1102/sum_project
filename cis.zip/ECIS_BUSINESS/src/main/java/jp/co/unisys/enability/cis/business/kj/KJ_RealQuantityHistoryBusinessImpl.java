package jp.co.unisys.enability.cis.business.kj;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.dao.DataAccessException;

import jp.co.unisys.enability.cis.business.kj.model.RealQuantityHistoryBusinessBean;
import jp.co.unisys.enability.cis.common.Exception.SystemException;
import jp.co.unisys.enability.cis.common.util.KJ_CommonUtil;
import jp.co.unisys.enability.cis.common.util.ThreadContext;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISKJConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISReturnCodeConstants;
import jp.co.unisys.enability.cis.entity.common.Fcr;
import jp.co.unisys.enability.cis.entity.common.FcrExample;
import jp.co.unisys.enability.cis.entity.common.Rqh;
import jp.co.unisys.enability.cis.entity.common.RqhExample;
import jp.co.unisys.enability.cis.mapper.common.FcrMapper;
import jp.co.unisys.enability.cis.mapper.common.RqhMapper;

/**
 * 実量歴管理ビジネス
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.kj.KJ_RealQuantityHistoryBusiness
 *
 */
public class KJ_RealQuantityHistoryBusinessImpl implements
    KJ_RealQuantityHistoryBusiness {

  /** 実量歴管理マッパー(DI) */
  private RqhMapper rqhMapper;

  /** 確定料金実績マッパー(DI) */
  private FcrMapper fcrMapper;

  /** メッセージプロパティ(DI) */
  private MessageSource messageSource;

  /**
   * ログマネジャー
   */
  private static Logger logger = LogManager.getLogger();

  /**
   * 実量歴管理リストSize
   */
  private static final int RQHLIST_COUNT = 12;

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.kj.KJ_RealQuantityHistoryBusiness
   * #inquiry
   * (jp.co.unisys.enability.cis.business.kj.model.RealQuantityHistoryBusinessBean
   * )
   */
  @Override
  public RealQuantityHistoryBusinessBean inquiry(
      RealQuantityHistoryBusinessBean realQuantityHistoryBusinessBean) {

    String errorMessage = null;
    try {
      errorMessage = messageSource.getMessage(KJ_CommonUtil
          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G017),
          new String[] {}, Locale.getDefault());

      // 《実量歴管理Example》を設定する。
      RqhExample rqhExample = new RqhExample();

      // 契約IDと対象年月を設定する。
      rqhExample
          .createCriteria()
          .andContractIdEqualTo(
              realQuantityHistoryBusinessBean.getContractId())
          .andCoveredPeriodLessThanOrEqualTo(
              realQuantityHistoryBusinessBean.getCoveredPeriod());

      // 対象年月 降順
      rqhExample.setOrderByClause(ECISKJConstants.RQH_ORDER_BY_CLAUSE_DESC);

      // 《実量歴管理Mapper》.検索（項目指定）呼び出し、実量歴一覧取得
      List<Rqh> rqhList = rqhMapper.selectByExample(rqhExample);

      List<Rqh> tempRqhList = new ArrayList<Rqh>();
      if (rqhList.size() > RQHLIST_COUNT) {
        for (int i = 0; i < RQHLIST_COUNT; i++) {
          Rqh rqh = rqhList.get(i);
          tempRqhList.add(rqh);
        }
      } else {
        tempRqhList.addAll(rqhList);
      }

      // 照会結果設定
      realQuantityHistoryBusinessBean.setRealQuantityHistoryList(tempRqhList);

      // 正常終了
      realQuantityHistoryBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);
    } catch (NoSuchMessageException ioe) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, ioe);
      realQuantityHistoryBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      realQuantityHistoryBusinessBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
    } catch (DataAccessException exception) {
      logger.error(
          messageSource.getMessage("error.E1129", null,
              Locale.getDefault()),
          exception);
      realQuantityHistoryBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      realQuantityHistoryBusinessBean.setMessage(errorMessage);
    } catch (SystemException se) {
      logger.error(
          messageSource.getMessage("error.E1129", null,
              Locale.getDefault()),
          se);
      realQuantityHistoryBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      realQuantityHistoryBusinessBean.setMessage(errorMessage);
    }

    return realQuantityHistoryBusinessBean;
  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.kj.KJ_RealQuantityHistoryBusiness
   * #update
   * (jp.co.unisys.enability.cis.business.kj.model.RealQuantityHistoryBusinessBean
   * )
   */
  @Override
  public RealQuantityHistoryBusinessBean update(
      RealQuantityHistoryBusinessBean realQuantityHistoryBusinessBean) {

    String errorMessage = null;
    try {
      errorMessage = messageSource.getMessage(KJ_CommonUtil
          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G017),
          new String[] {}, Locale.getDefault());

      // 元の実量歴情報
      Rqh originalRqh = realQuantityHistoryBusinessBean
          .getRealQuantityHistoryList().get(0);

      // 《実量歴管理Entity》を設定する。
      Rqh rqhEntity = new Rqh();

      // 契約IDを設定する。
      rqhEntity.setContractId(realQuantityHistoryBusinessBean
          .getContractId());

      // 対象年月を設定する。
      rqhEntity.setCoveredPeriod(realQuantityHistoryBusinessBean
          .getCoveredPeriod());

      // 供給地点特定番号 を設定する。
      rqhEntity.setSpotNo(originalRqh.getSpotNo());

      // 算定期間開始日を設定する。
      rqhEntity.setCcSd(originalRqh.getCcSd());

      // 最大電力（算定帳票）を設定する。
      rqhEntity.setPkwCalculation(originalRqh.getPkwCalculation());

      // 最大電力（確定使用量）を設定する。
      rqhEntity.setPkwUsage(originalRqh.getPkwUsage());

      // 算定契約電力を設定する。
      rqhEntity.setCcc(originalRqh.getCcc());

      // 最大電力（手入力）を設定する。
      rqhEntity.setPkwManual(realQuantityHistoryBusinessBean
          .getPkwManual());

      // 最大電力を設定する。
      rqhEntity.setPkw(realQuantityHistoryBusinessBean.getPkw());

      // 契約電力算定日時を設定する。
      rqhEntity.setCccTime(originalRqh.getCccTime());

      // 減設フラグを設定する。
      rqhEntity.setRccFlg(realQuantityHistoryBusinessBean.getRccFlg());

      // 更新回数を設定する。
      rqhEntity.setUpdateCount(realQuantityHistoryBusinessBean
          .getUpdateCount() + 1);

      // 作成日時を設定する。
      rqhEntity.setCreateTime(originalRqh.getCreateTime());

      // システム日時
      Timestamp sysDate = new Timestamp((new Date()).getTime());

      // オンライン更新日時を設定する。
      rqhEntity.setOnlineUpdateTime(sysDate);

      // オンライン更新ユーザIDを設定する。
      rqhEntity.setOnlineUpdateUserId(ThreadContext
          .getRequestThreadContext().get(ECISConstants.USER_ID_KEY)
          .toString());

      // 更新日時を設定する。
      rqhEntity.setUpdateTime(sysDate);

      // 更新モジュールコード
      rqhEntity.setUpdateModuleCode(ThreadContext
          .getRequestThreadContext()
          .get(ECISConstants.CLASS_NAME_KEY).toString());

      // 《実量歴管理Example》を設定する。
      RqhExample rqhExample = new RqhExample();

      // 契約ID、対象年月、更新回数を設定する。
      rqhExample
          .createCriteria()
          .andContractIdEqualTo(
              realQuantityHistoryBusinessBean.getContractId())
          .andCoveredPeriodEqualTo(
              realQuantityHistoryBusinessBean.getCoveredPeriod())
          .andUpdateCountEqualTo(
              realQuantityHistoryBusinessBean.getUpdateCount());

      // 《実量歴管理Mapper》.選択項目更新を呼び出す。
      int updateCount = rqhMapper.updateByExample(rqhEntity, rqhExample);

      // 返却値が0件の場合、以下のメッセージ情報を設定し処理を終了する。
      if (updateCount == 0) {
        // リターンコード ：（H001）
        realQuantityHistoryBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_H001);

        // メッセージ ：（H001）に対応するメッセージ
        realQuantityHistoryBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_H001),
                new String[] {}, Locale.getDefault()));

        return realQuantityHistoryBusinessBean;
      }

      // 正常終了
      realQuantityHistoryBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);
    } catch (NoSuchMessageException ioe) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, ioe);
      realQuantityHistoryBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      realQuantityHistoryBusinessBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
    } catch (DataAccessException exception) {
      logger.error(
          messageSource.getMessage("error.E1129", null,
              Locale.getDefault()),
          exception);
      realQuantityHistoryBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      realQuantityHistoryBusinessBean.setMessage(errorMessage);
    } catch (SystemException se) {
      logger.error(
          messageSource.getMessage("error.E1129", null,
              Locale.getDefault()),
          se);
      realQuantityHistoryBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      realQuantityHistoryBusinessBean.setMessage(errorMessage);
    }

    return realQuantityHistoryBusinessBean;
  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.kj.KJ_RealQuantityHistoryBusiness
   * #getChargeStatus
   * (jp.co.unisys.enability.cis.business.kj.model.RealQuantityHistoryBusinessBean
   * )
   */
  @Override
  public RealQuantityHistoryBusinessBean getChargeStatus(
      RealQuantityHistoryBusinessBean realQuantityHistoryBusinessBean) {

    String errorMessage = null;
    try {
      errorMessage = messageSource.getMessage(KJ_CommonUtil
          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G017),
          new String[] {}, Locale.getDefault());

      // 《確定料金実績Example》を設定する。
      // 契約IDと利用年月を設定する。
      FcrExample fcrExample = new FcrExample();
      fcrExample
          .createCriteria()
          .andContractIdEqualTo(
              realQuantityHistoryBusinessBean.getContractId())
          .andUsePeriodEqualTo(
              realQuantityHistoryBusinessBean.getCoveredPeriod());

      // 《確定料金実績Mapper》.検索（項目指定）呼び出し。
      List<Fcr> fcrList = fcrMapper.selectByExample(fcrExample);

      // 取得結果が0件の場合
      if (fcrList.isEmpty()) {
        // 《実量歴管理BusinessBean》.料金ステータスコードに空文字を設定する。
        realQuantityHistoryBusinessBean.setCsCode(ECISConstants.EMPTY_STRING);
      } else {
        // それ以外の場合、
        // 取得した【確定料金実績】リストの1番目．料金ステータスコードを《実量歴管理BusinessBean》.料金ステータスコードに設定する。
        realQuantityHistoryBusinessBean.setCsCode(fcrList.get(0)
            .getCsCode());
      }

      // 正常終了
      realQuantityHistoryBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);
    } catch (NoSuchMessageException ioe) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, ioe);
      realQuantityHistoryBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      realQuantityHistoryBusinessBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
    } catch (DataAccessException exception) {
      logger.error(
          messageSource.getMessage("error.E1129", null,
              Locale.getDefault()),
          exception);
      realQuantityHistoryBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      realQuantityHistoryBusinessBean.setMessage(errorMessage);
    } catch (SystemException se) {
      logger.error(
          messageSource.getMessage("error.E1129", null,
              Locale.getDefault()),
          se);
      realQuantityHistoryBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      realQuantityHistoryBusinessBean.setMessage(errorMessage);
    }

    return realQuantityHistoryBusinessBean;
  }

  /**
   * 実量歴管理マッパーーのセッター(DI)
   *
   * @param rqhMapper
   *          実量歴管理マッパー
   *
   */
  public void setRqhMapper(RqhMapper rqhMapper) {
    this.rqhMapper = rqhMapper;
  }

  /**
   * 確定料金実績マッパーーのセッター(DI)
   *
   * @param fcrMapper
   *          確定料金実績マッパー
   *
   */
  public void setFcrMapper(FcrMapper fcrMapper) {
    this.fcrMapper = fcrMapper;
  }

  /**
   * messageSourceのセッター(DI)
   *
   * @param messageSource
   *          メッセージソース
   *
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }

}
