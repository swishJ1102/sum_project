package jp.co.unisys.enability.cis.business.kj;

import jp.co.unisys.enability.cis.business.kj.model.InquiryProvideModelCompanyBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.InquirySalesConsignmentCompanyBusinessBean;

/**
 * マスタ情報ビジネスインターフェース
 *
 * @author "Nihon Unisys, Ltd."
 *
 */
public interface KJ_MasterInformationBusiness {

  /**
   * 提供モデル企業の照会を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * CRMや低圧CIS側画面で、【提供モデル】【提供モデル企業】を特定する場合に、
   * 指定された「提供モデルコード」「提供企業モデルコード」に紐付く【提供モデル】【提供モデル企業】の一覧情報を返却する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param inquiryProvideModelCompanyBusinessBean
   *          提供モデル企業照会BusinessBean
   * @return 提供モデル企業照会BusinessBean
   */
  public InquiryProvideModelCompanyBusinessBean inquiryProvideModelCompany(
      InquiryProvideModelCompanyBusinessBean inquiryProvideModelCompanyBusinessBean);

  /**
   * 営業委託先企業一覧照会を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * CRMや低圧CIS側画面で、【営業委託先マスタ】を特定する場合に、指定された「営業委託先コード」に紐付く【営業委託先マスタ】の一覧情報を返却する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param inquirySalesConsignmentCompanyBusinessBean
   *          営業委託先企業照会BusinessBean
   * @return 営業委託先企業照会BusinessBean
   */
  public InquirySalesConsignmentCompanyBusinessBean inquirySalesConsignmentCompany(
      InquirySalesConsignmentCompanyBusinessBean inquirySalesConsignmentCompanyBusinessBean);
}
