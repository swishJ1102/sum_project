package jp.co.unisys.enability.cis.business.rk;

import jp.co.unisys.enability.cis.business.rk.model.InquiryMcSmrInfoBusinessBean;

/**
 * 計量器交換・臨時検針情報ビジネスインターフェース。
 *
 * @author "Nihon Unisys, Ltd."
 *
 */
public interface RK_McSmrInfoBusiness {

  /**
   * 計量器交換・臨時検針情報の取得を行う。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計量器交換・臨時検針情報を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param inquiryMcSmrInfoBusinessBean
   *          計量器交換・臨時検針情報照会BusinessBean
   * @return 計量器交換・臨時検針情報照会BusinessBean
   */
  public InquiryMcSmrInfoBusinessBean inquiry(
      InquiryMcSmrInfoBusinessBean inquiryMcSmrInfoBusinessBean);
}
