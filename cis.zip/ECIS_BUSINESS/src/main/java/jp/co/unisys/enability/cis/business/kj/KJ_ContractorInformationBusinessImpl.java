package jp.co.unisys.enability.cis.business.kj;

import java.io.File;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.util.CollectionUtils;

import jp.co.unisys.enability.cis.business.common.DateBusiness;
import jp.co.unisys.enability.cis.business.gk.ContractManagementInformationFileHeaderValidator;
import jp.co.unisys.enability.cis.business.gk.ContractorInformationFileRegistValidator;
import jp.co.unisys.enability.cis.business.gk.ContractorInformationFileUpdateValidator;
import jp.co.unisys.enability.cis.business.gk.Custom_ContractorInformationFileRegistValidator;
import jp.co.unisys.enability.cis.business.gk.Custom_ContractorInformationFileUpdateValidator;
import jp.co.unisys.enability.cis.business.kj.model.ContractManagementInformationFileConfigCommon;
import jp.co.unisys.enability.cis.business.kj.model.ContractManagementInformationFileConfigContractor;
import jp.co.unisys.enability.cis.business.kj.model.CsvFileCheckContractorBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.Custom_ContractManagementInformationFileConfigContractor;
import jp.co.unisys.enability.cis.business.kj.model.DownloadContractorBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.InquiryContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.InquiryContractorBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.InquiryProvideModelCompanyBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.RegistContractorBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.UpdateContractorBusinessBean;
import jp.co.unisys.enability.cis.common.Exception.BusinessLogicException;
import jp.co.unisys.enability.cis.common.Exception.SystemException;
import jp.co.unisys.enability.cis.common.util.KJ_CommonUtil;
import jp.co.unisys.enability.cis.common.util.StringConvertUtil;
import jp.co.unisys.enability.cis.common.util.ThreadContext;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISKJConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISReturnCodeConstants;
import jp.co.unisys.enability.cis.entity.common.Contractor;
import jp.co.unisys.enability.cis.entity.common.ContractorExample;
import jp.co.unisys.enability.cis.entity.common.IlcM;
import jp.co.unisys.enability.cis.entity.common.PaymentExample;
import jp.co.unisys.enability.cis.entity.common.PhoneNoCatM;
import jp.co.unisys.enability.cis.entity.common.PmCompanyMExample;
import jp.co.unisys.enability.cis.entity.common.PmM;
import jp.co.unisys.enability.cis.entity.kj.KJ_ContractorInformationFileEntityBean;
import jp.co.unisys.enability.cis.entity.kj.KJ_InquiryContractorInformationEntityBean;
import jp.co.unisys.enability.cis.mapper.common.ContractorMapper;
import jp.co.unisys.enability.cis.mapper.common.IlcMMapper;
import jp.co.unisys.enability.cis.mapper.common.PaymentMapper;
import jp.co.unisys.enability.cis.mapper.common.PhoneNoCatMMapper;
import jp.co.unisys.enability.cis.mapper.common.PmCompanyMMapper;
import jp.co.unisys.enability.cis.mapper.common.PmMMapper;
import jp.co.unisys.enability.cis.mapper.kj.ContractorInformationCommonMapper;
import jp.sf.orangesignal.csv.Csv;
import jp.sf.orangesignal.csv.handlers.ColumnPositionMapListHandler;

/**
 * 契約者情報ビジネス
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.kj.KJ_ContractorInformationBusiness
 *
 */
public class KJ_ContractorInformationBusinessImpl implements
    KJ_ContractorInformationBusiness {

  /**
   * 契約者情報共通マッパー(DI)
   */
  private ContractorInformationCommonMapper contractorInformationCommonMapper;

  /**
   * 電話番号区分マッパー(DI)
   */
  private PhoneNoCatMMapper phoneNoCatMMapper;

  /**
   * マスタ情報マッパー(DI)
   */
  private KJ_MasterInformationBusiness kjMasterInformationBusiness;

  /**
   * 個人法人マスターマッパー(DI)
   */
  private IlcMMapper ilcMMapper;

  /**
   * 契約者情報マッパー(DI)
   */
  private ContractorMapper contractorMapper;

  /**
   * 提供モデルマッパー
   */
  private PmMMapper pmMMapper;

  /**
   * 提供モデル企業マッパー
   */
  private PmCompanyMMapper pmCompanyMMapper;

  /**
   * 支払マッパー(DI)
   */
  private PaymentMapper paymentMapper;

  /**
   * 日付関連共通ビジネスインタフェース(DI)
   */
  private DateBusiness dateBusiness;

  /**
   * 契約情報ビジネス(DI)
   */
  private KJ_ContractInformationBusiness kjContractInformationBusiness;

  /**
   * メッセージプロパティ(DI)
   */
  private MessageSource messageSource;

  /**
   * 契約管理情報ファイルヘッダーバリデーター(DI)
   */
  private ContractManagementInformationFileHeaderValidator contractManagementInformationFileHeaderValidator;

  /**
   * 契約者情報ファイル登録バリデーター(DI)
   */
  private ContractorInformationFileRegistValidator contractorInformationFileRegistValidator;

  /**
   * （カスタム）契約者情報ファイル登録バリデーター(DI)
   */
  private Custom_ContractorInformationFileRegistValidator customContractorInformationFileRegistValidator;

  /**
   * 契約者情報ファイル更新バリデーター(DI)
   */
  private ContractorInformationFileUpdateValidator contractorInformationFileUpdateValidator;

  /**
   * （カスタム）契約者情報ファイル更新バリデーター(DI)
   */
  private Custom_ContractorInformationFileUpdateValidator customContractorInformationFileUpdateValidator;

  /**
   * ログマネジャー
   */
  private static Logger logger = LogManager.getLogger();

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.kj.KJ_ContractorInformationBusiness
   * #inquiry
   * (jp.co.unisys.enability.cis.business.kj.model.InquiryContractorBusinessBean
   * )
   */
  @Override
  public InquiryContractorBusinessBean inquiry(
      InquiryContractorBusinessBean inquiryBean) {

    // 契約者情報照会条件Map
    Map<String, Object> conditionsMap = new HashMap<String, Object>();

    // DataAccessException用エラーメッセージ
    String dataAccessExceptionEMsg = null;

    try {

      dataAccessExceptionEMsg = messageSource.getMessage(KJ_CommonUtil
          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G017),
          new String[] {}, Locale.getDefault());

      // 《契約者情報共通DAO》.契約者情報取得を呼び出す。
      // 照会結果設定
      // 条件Map.契約者ID
      conditionsMap.put("contractorId", inquiryBean.getContractorId());
      // 条件Map.契約者番号
      conditionsMap.put("contractorNo", inquiryBean.getContractorNo());
      List<KJ_InquiryContractorInformationEntityBean> inquiryContractorInformationEntityBeanList = contractorInformationCommonMapper
          .selectContractor(conditionsMap);
      inquiryBean
          .setContractorInformationList(inquiryContractorInformationEntityBeanList);
      // 正常終了
      inquiryBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);

    } catch (DataAccessException e) {
      logger.error(messageSource.getMessage("error.E1129", null,
          Locale.getDefault()), e);
      // catch 業務例外クラス
      inquiryBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      inquiryBean.setMessage(dataAccessExceptionEMsg);

    } catch (NoSuchMessageException e) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, e);
      inquiryBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      inquiryBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
    }
    return inquiryBean;
  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.kj.KJ_ContractorInformationBusiness
   * #regist
   * (jp.co.unisys.enability.cis.business.kj.model.RegistContractorBusinessBean
   * )
   */
  @Override
  public RegistContractorBusinessBean regist(
      RegistContractorBusinessBean registContractorBusinessBean) {

    // BusinessLogicException用エラーメッセージ
    String businessLogicExceptionEMsg = null;

    // DuplicateKeyException用エラーメッセージ
    String duplicateKeyExceptionEMsg = null;

    // 提供モデル企業一覧照会BusinessBean
    InquiryProvideModelCompanyBusinessBean inquiryProvideModelCompanyBusinessBean;

    // 契約者Entity
    Contractor contractor;

    try {

      businessLogicExceptionEMsg = messageSource.getMessage(KJ_CommonUtil
          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G017),
          new String[] {}, Locale.getDefault());

      duplicateKeyExceptionEMsg = messageSource.getMessage(KJ_CommonUtil
          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D023),
          new String[] {}, Locale.getDefault());

      // DB存在チェック
      // 《電話番号区分Mapper》.検索（主キー）電話番号区分1の取得結果が0件の場合
      if (contractorPhoneCategoryCodeCheck(registContractorBusinessBean
          .getContractorPhoneCategoryCode1())) {

        registContractorBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P019);
        registContractorBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P019),
                new String[] {}, Locale.getDefault()));

        return registContractorBusinessBean;

      }
      // 《電話番号区分Mapper》.検索（主キー）電話番号区分2の取得結果が0件の場合
      if (contractorPhoneCategoryCodeCheck(registContractorBusinessBean
          .getContractorPhoneCategoryCode2())) {

        registContractorBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P019);
        registContractorBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P019),
                new String[] {}, Locale.getDefault()));
        return registContractorBusinessBean;

      }
      inquiryProvideModelCompanyBusinessBean = new InquiryProvideModelCompanyBusinessBean();
      // 《提供モデル企業一覧照会BusinessBean》.提供モデルコードに《契約者情報登録BusinessBean》.提供モデルコードを設定する。
      inquiryProvideModelCompanyBusinessBean
          .setProvideModelCode(registContractorBusinessBean
              .getProvideModelCode());
      // 《提供モデル企業一覧照会BusinessBean》.提供モデル企業コードに《契約者情報登録BusinessBean》.提供モデル企業コードを設定する。
      inquiryProvideModelCompanyBusinessBean
          .setProvideModelCompanyCode(registContractorBusinessBean
              .getProvideModelCompanyCode());
      // 《提供モデル企業一覧照会BusinessBean》.提供モデル企業有効フラグに“1”を設定する。
      inquiryProvideModelCompanyBusinessBean
          .setProvideModelCompanyEffectiveFlag(ECISKJConstants.PROVIDE_MODEL_COMPANYEFFECTIVE_FLAG_ALL);
      // 提供モデル企業一覧照会
      inquiryProvideModelCompanyBusinessBean = kjMasterInformationBusiness
          .inquiryProvideModelCompany(inquiryProvideModelCompanyBusinessBean);
      // 《提供モデル企業一覧照会BusinessBean》.リターンコードが“0000”以外の場合
      if (!ECISReturnCodeConstants.RETURN_CODE_0000
          .equals(inquiryProvideModelCompanyBusinessBean
              .getReturnCode())) {

        throw new BusinessLogicException(messageSource.getMessage(
            "error.E1287", new String[] {}, Locale.getDefault()), false);
      }
      // 《提供モデル企業一覧照会BusinessBean》.提供モデル情報リストの返却値が0件の場合
      if (CollectionUtils.isEmpty(inquiryProvideModelCompanyBusinessBean.getProvideModelList())) {

        registContractorBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P040);
        registContractorBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P040),
                new String[] {}, Locale.getDefault()));
        return registContractorBusinessBean;

      }
      // 《個人・法人区分マスタDao》.検索（主キー）の返却値が0件の場合
      if (ilcMMapper
          .selectByPrimaryKey(registContractorBusinessBean
              .getIndividualLegalEntityCategoryCode()) == null) {

        registContractorBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P021);
        registContractorBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P021),
                new String[] {}, Locale.getDefault()));
        return registContractorBusinessBean;

      }
      // DB登録
      Timestamp systemDate = new Timestamp(System.currentTimeMillis());
      contractor = new Contractor();
      // 契約者番号
      contractor.setContractorNo(registContractorBusinessBean
          .getContractorNo());
      // 契約者名1（カナ）
      contractor.setCn1Kana(registContractorBusinessBean
          .getContractorName1Kana());
      // 契約者名1
      contractor
          .setCn1(registContractorBusinessBean.getContractorName1());
      // 契約者名2
      contractor
          .setCn2(registContractorBusinessBean.getContractorName2());
      // 契約者名1（宛名用）
      contractor.setCn1MailingName(registContractorBusinessBean
          .getContractorName1MailingName());
      // 契約者名2（宛名用）
      contractor.setCn2MailingName(registContractorBusinessBean
          .getContractorName2MailingName());
      // 敬称
      contractor.setPrefix(registContractorBusinessBean.getPrefix());
      // 契約者住所（郵便番号）
      contractor.setCaPostalCode(registContractorBusinessBean
          .getContractorAddressPostalCode());
      // 契約者住所（都道府県名）
      contractor.setCaPrefectures(registContractorBusinessBean
          .getContractorAddressPrefectures());
      // 契約者住所（市区郡町村名）
      contractor.setCaMunicipality(registContractorBusinessBean
          .getContractorAddressMunicipality());
      // 契約者住所（字名・丁目）
      contractor.setCaSection(registContractorBusinessBean
          .getContractorAddressSection());
      // 契約者住所（番地･号）
      contractor.setCaBlock(registContractorBusinessBean
          .getContractorAddressBlock());
      // 契約者住所（建物名）
      contractor.setCaBuildingName(registContractorBusinessBean
          .getContractorAddressBuildingName());
      // 契約者住所（部屋名）
      contractor.setCaRoom(registContractorBusinessBean
          .getContractorAddressRoom());
      // 契約者電話区分コード1
      contractor.setCphCatCode1(registContractorBusinessBean
          .getContractorPhoneCategoryCode1());
      // 契約者電話1（市外局番）
      contractor.setCphAreaCode1(registContractorBusinessBean
          .getContractorPhoneAreaCode1());
      // 契約者電話1（市内局番）
      contractor.setCphLocalNo1(registContractorBusinessBean
          .getContractorPhoneLocalNo1());
      // 契約者電話1（加入者番号）
      contractor.setCphDirectoryNo1(registContractorBusinessBean
          .getContractorPhoneDirectoryNo1());
      // 契約者電話区分コード2
      contractor.setCphCatCode2(registContractorBusinessBean
          .getContractorPhoneCategoryCode2());
      // 契約者電話2（市外局番）
      contractor.setCphAreaCode2(registContractorBusinessBean
          .getContractorPhoneAreaCode2());
      // 契約者電話2（市内局番）
      contractor.setCphLocalNo2(registContractorBusinessBean
          .getContractorPhoneLocalNo2());
      // 契約者電話2（加入者番号）
      contractor.setCphDirectoryNo2(registContractorBusinessBean
          .getContractorPhoneDirectoryNo2());
      // 契約者メールアドレス1
      contractor.setCma1(registContractorBusinessBean
          .getContractorMailAddress1());
      // 契約者メールアドレス1
      contractor.setCma2(registContractorBusinessBean
          .getContractorMailAddress2());
      // 提供モデルコード
      contractor.setPmCode(registContractorBusinessBean
          .getProvideModelCode());
      // 提供モデル企業コード
      contractor.setPmCompanyCode(registContractorBusinessBean
          .getProvideModelCompanyCode());
      // 利用不能フラグ
      // 《契約者情報登録BusinessBean》.利用不能フラグがnullまたは空文字以外の場合
      if (StringUtils.isNotEmpty(registContractorBusinessBean
          .getUnavailableFlag())) {
        contractor.setUnavailableFlag(registContractorBusinessBean
            .getUnavailableFlag());
      } else {
        contractor
            .setUnavailableFlag(ECISKJConstants.UNAVAILABLE_FLAG_USE_POSSIBLE);
      }
      // 取引先コード
      contractor.setCustomerCode(registContractorBusinessBean
          .getCustomerCode());
      // 督促対象外フラグ
      contractor.setUrgeNotCoveredFlag(registContractorBusinessBean
          .getUrgeNotCoveredFlag());
      // 個人・法人区分コード
      contractor.setIlcCode(registContractorBusinessBean
          .getIndividualLegalEntityCategoryCode());
      // 見える化提供フラグ
      contractor.setVisualizationProvideFlag(registContractorBusinessBean
          .getVisualizationProvideFlag());
      // 備考
      contractor.setNote(registContractorBusinessBean.getNote());
      // 契約者住所(住所)
      contractor.setCaFull(registCaFullStrBuilder(
          registContractorBusinessBean
              .getContractorAddressPrefectures(),
          registContractorBusinessBean
              .getContractorAddressMunicipality(),
          registContractorBusinessBean.getContractorAddressSection(),
          registContractorBusinessBean.getContractorAddressBlock()));
      // 契約者住所(建物・部屋名)
      contractor.setCaBuilding(registCaBuildingStrBuilder(
          registContractorBusinessBean
              .getContractorAddressBuildingName(),
          registContractorBusinessBean.getContractorAddressRoom()));
      // 契約者電話番号1
      contractor.setCphNo1(cphNoStrBuilder(registContractorBusinessBean
          .getContractorPhoneAreaCode1(),
          registContractorBusinessBean.getContractorPhoneLocalNo1(),
          registContractorBusinessBean
              .getContractorPhoneDirectoryNo1()));
      // 契約者電話番号2
      contractor.setCphNo2(cphNoStrBuilder(registContractorBusinessBean
          .getContractorPhoneAreaCode2(),
          registContractorBusinessBean.getContractorPhoneLocalNo2(),
          registContractorBusinessBean
              .getContractorPhoneDirectoryNo2()));
      // 更新回数
      contractor.setUpdateCount(0);
      // 作成日時
      contractor.setCreateTime(systemDate);
      // オンライン更新日時
      contractor.setOnlineUpdateTime(systemDate);
      // オンライン更新ユーザID
      contractor.setOnlineUpdateUserId(ThreadContext
          .getRequestThreadContext().get(ECISConstants.USER_ID_KEY)
          .toString());
      // 更新日時
      contractor.setUpdateTime(systemDate);
      // 更新モジュールコード
      contractor.setUpdateModuleCode(ThreadContext
          .getRequestThreadContext()
          .get(ECISConstants.CLASS_NAME_KEY).toString());
      // 《契約者情報共通Dao》.契約者情報登録を呼び出す。
      contractorMapper.insertBySequence(contractor);
      registContractorBusinessBean.setContractorId(contractor
          .getContractorId());
      // 正常終了
      registContractorBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);

    } catch (DuplicateKeyException e) {
      logger.error(messageSource.getMessage("error.E1129", null,
          Locale.getDefault()), e);
      // 重複例外クラス
      registContractorBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D023);
      registContractorBusinessBean.setMessage(duplicateKeyExceptionEMsg);
    } catch (DataIntegrityViolationException dataIntegrityViolationException) {
      logger.error(messageSource.getMessage("error.E1129", null,
          Locale.getDefault()), dataIntegrityViolationException);
      // 制約違反例外クラス
      registContractorBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D023);
      registContractorBusinessBean.setMessage(duplicateKeyExceptionEMsg);
    } catch (BusinessLogicException e) {
      logger.error(messageSource.getMessage("error.E1129", null,
          Locale.getDefault()), e);
      // 業務例外クラス
      registContractorBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      registContractorBusinessBean.setMessage(businessLogicExceptionEMsg);
    } catch (NoSuchMessageException e) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, e);
      registContractorBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      registContractorBusinessBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
    } catch (DataAccessException e) {
      logger.error(messageSource.getMessage("error.E1129", null,
          Locale.getDefault()), e);
      registContractorBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      registContractorBusinessBean.setMessage(e.getMessage());
    }
    return registContractorBusinessBean;
  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.kj.KJ_ContractorInformationBusiness
   * #update
   * (jp.co.unisys.enability.cis.business.kj.model.UpdateContractorBusinessBean
   * )
   */
  @Override
  public UpdateContractorBusinessBean update(
      UpdateContractorBusinessBean updateContractorBusinessBean) {

    // BusinessLogicException用エラーメッセージ
    String businessLogicExceptionEMsg = null;

    // オンライン処理基準日取得エラー用エラーメッセージ
    String getProcessBaseDateErrorEMsg = null;

    // 契約者情報照会BusinessBean
    InquiryContractorBusinessBean inquiryContractorBusinessBean;

    // 契約者情報照会EntityBean
    KJ_InquiryContractorInformationEntityBean inquiryContractorInformationEntityBean;

    // 契約情報ビジネスBean
    InquiryContractBusinessBean inquiryContractBusinessBean;

    // 契約者Entity
    Contractor contractor;

    // 契約者EntityExample
    ContractorExample contractorExample;

    try {

      businessLogicExceptionEMsg = messageSource.getMessage(KJ_CommonUtil
          .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G017),
          new String[] {}, Locale.getDefault());
      getProcessBaseDateErrorEMsg = messageSource.getMessage("error.E1286", new String[] {}, Locale.getDefault());

      // DB存在チェック
      inquiryContractorBusinessBean = new InquiryContractorBusinessBean();
      // 《契約者情報更新BusinessBean》.契約者IDを設定する。
      inquiryContractorBusinessBean
          .setContractorId(updateContractorBusinessBean
              .getContractorId());
      // 《契約者情報更新BusinessBean》.契約者番号を設定する。
      inquiryContractorBusinessBean
          .setContractorNo(updateContractorBusinessBean
              .getContractorNo());
      // 契約者情報照会呼び出し
      inquiryContractorBusinessBean = inquiry(inquiryContractorBusinessBean);
      // 《契約者情報照会BusinessBean》.リターンコードが'0000'以外の場合
      if (!ECISReturnCodeConstants.RETURN_CODE_0000
          .equals(inquiryContractorBusinessBean.getReturnCode())) {

        throw new BusinessLogicException(messageSource.getMessage(
            "error.E1281", new String[] {}, Locale.getDefault()), false);
      }
      // 《契約者情報照会EntityBean》リストが0件の場合
      if (CollectionUtils.isEmpty(inquiryContractorBusinessBean.getContractorInformationList())) {

        updateContractorBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P003);
        updateContractorBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P003),
                new String[] {}, Locale.getDefault()));
        return updateContractorBusinessBean;

      }
      inquiryContractorInformationEntityBean = inquiryContractorBusinessBean
          .getContractorInformationList().get(0);
      // 《電話番号区分Dao》.検索（主キー）電話番号区分1のが0件の場合
      if (contractorPhoneCategoryCodeCheck(updateContractorBusinessBean
          .getContractorPhoneCategoryCode1())) {

        updateContractorBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P019);
        updateContractorBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P019),
                new String[] {}, Locale.getDefault()));
        return updateContractorBusinessBean;

      }
      // 《電話番号区分Dao》.検索（主キー）電話番号区分2の取得結果が0件の場合
      if (contractorPhoneCategoryCodeCheck(updateContractorBusinessBean
          .getContractorPhoneCategoryCode2())) {

        updateContractorBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P019);
        updateContractorBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P019),
                new String[] {}, Locale.getDefault()));
        return updateContractorBusinessBean;

      }
      // 《契約者情報更新BusinessBean》.個人・法人区分コードがnullまたは空文字でない場合
      // 《個人・法人区分マスタDao》.検索（主キー）の返却値が0件の場合
      if (StringUtils.isNotEmpty(updateContractorBusinessBean
          .getIndividualLegalEntityCategoryCode())
          && ilcMMapper
              .selectByPrimaryKey(updateContractorBusinessBean
                  .getIndividualLegalEntityCategoryCode()) == null) {

        updateContractorBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P021);
        updateContractorBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P021),
                new String[] {}, Locale.getDefault()));
        return updateContractorBusinessBean;

      }
      // 《契約者情報更新BusinessBean》.利用不能フラグが"1：利用不能" かつ
      // 《契約者情報照会EntityBean》.利用不能フラグが"0：利用可能"の場合
      if ((ECISKJConstants.UNAVAILABLE_FLAG_USE_IMPOSSIBLE)
          .equals(updateContractorBusinessBean.getUnavailableFlag())
          && (ECISKJConstants.UNAVAILABLE_FLAG_USE_POSSIBLE)
              .equals(inquiryContractorInformationEntityBean
                  .getUnavailableFlag())) {

        inquiryContractBusinessBean = new InquiryContractBusinessBean();
        // 《契約者情報照会EntityBean》.契約者番号を設定する。
        inquiryContractBusinessBean
            .setContractorNo(inquiryContractorInformationEntityBean
                .getContractorNo());
        // オンライン処理基準日を設定する。
        inquiryContractBusinessBean
            .setInqCoveredDate(dateBusiness
                .getProcessBaseDate(ECISConstants.EXEC_BASE_DATE_ONLINE));
        // 契約情報照会呼び出し
        inquiryContractBusinessBean = kjContractInformationBusiness
            .inquiry(inquiryContractBusinessBean);
        // 《契約情報照会BusinessBean》.リターンコードが'0000'以外の場合
        if (!ECISReturnCodeConstants.RETURN_CODE_0000
            .equals(inquiryContractBusinessBean.getReturnCode())) {

          throw new BusinessLogicException(
              messageSource.getMessage("error.E1285",
                  new String[] {}, Locale.getDefault()),
              false);

        }
        // 《契約情報ビジネスBean》.契約情報リストが1件以上の場合
        if (inquiryContractBusinessBean.getContractInformationList()
            .size() >= 1) {

          updateContractorBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D005);
          updateContractorBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_D005),
                  new String[] {}, Locale.getDefault()));
          return updateContractorBusinessBean;

        }
      }

      // 督促対象チェック
      // 《契約者情報更新BusinessBean》.督促対象外フラグが"0：督促対象"の場合
      if (ECISKJConstants.URGE_NOT_COVERED_FLAG_URGE_COVERED
          .equals(updateContractorBusinessBean
              .getUrgeNotCoveredFlag())) {

        // 支払Exampleを生成し値を設定
        PaymentExample paymentExample = new PaymentExample();

        // 検索条件
        // 前月請求合算フラグが"0：否"
        paymentExample
            .createCriteria()
            .andContractorIdEqualTo(
                inquiryContractorInformationEntityBean.getContractorId())
            .andPreviousBlAddUpFlagEqualTo(
                ECISKJConstants.BILLING_ADD_UP_FLAG_UNNECESSARY);
        // または、支払期限個別設定フラグが"1：個別"
        paymentExample
            .or(paymentExample
                .createCriteria()
                .andContractorIdEqualTo(
                    inquiryContractorInformationEntityBean
                        .getContractorId())
                .andPeIndividualSettingFlagEqualTo(
                    ECISKJConstants.PAYMENT_EXPIRATION_CATEGORY_FLAG_INDIVIDUAL));

        // 支払Mapper.countByExampleを呼出
        int count = paymentMapper.countByExample(paymentExample);

        // 返却値が1件以上の場合、以下のメッセージ情報を設定
        if (count >= 1) {
          updateContractorBusinessBean
              .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G046);
          updateContractorBusinessBean
              .setMessage(messageSource.getMessage(
                  KJ_CommonUtil
                      .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G046),
                  new String[] {}, Locale.getDefault()));
          return updateContractorBusinessBean;
        }
      }

      // DB更新
      Timestamp systemDate = new Timestamp(System.currentTimeMillis());
      contractor = new Contractor();
      contractorExample = new ContractorExample();
      // 契約者名1（カナ）
      contractor.setCn1Kana(updateContractorBusinessBean
          .getContractorName1Kana());
      // 契約者名1
      contractor
          .setCn1(updateContractorBusinessBean.getContractorName1());
      // 契約者名2
      contractor
          .setCn2(updateContractorBusinessBean.getContractorName2());
      // 契約者名1（宛名用）
      contractor.setCn1MailingName(updateContractorBusinessBean
          .getContractorName1MailingName());
      // 契約者名2（宛名用）
      contractor.setCn2MailingName(updateContractorBusinessBean
          .getContractorName2MailingName());
      // 敬称
      contractor.setPrefix(updateContractorBusinessBean.getPrefix());
      // 契約者住所（郵便番号）
      contractor.setCaPostalCode(updateContractorBusinessBean
          .getContractorAddressPostalCode());
      // 契約者住所（都道府県名）
      contractor.setCaPrefectures(updateContractorBusinessBean
          .getContractorAddressPrefectures());
      // 契約者住所（市区郡町村名）
      contractor.setCaMunicipality(updateContractorBusinessBean
          .getContractorAddressMunicipality());
      // 契約者住所（字名・丁目）
      contractor.setCaSection(updateContractorBusinessBean
          .getContractorAddressSection());
      // 契約者住所（番地･号）
      contractor.setCaBlock(updateContractorBusinessBean
          .getContractorAddressBlock());
      // 契約者住所（建物名）
      contractor.setCaBuildingName(updateContractorBusinessBean
          .getContractorAddressBuildingName());
      // 契約者住所（部屋名）
      contractor.setCaRoom(updateContractorBusinessBean
          .getContractorAddressRoom());
      // 契約者電話区分コード1
      contractor.setCphCatCode1(updateContractorBusinessBean
          .getContractorPhoneCategoryCode1());
      // 契約者電話1（市外局番）
      contractor.setCphAreaCode1(updateContractorBusinessBean
          .getContractorPhoneAreaCode1());
      // 契約者電話1（市内局番）
      contractor.setCphLocalNo1(updateContractorBusinessBean
          .getContractorPhoneLocalNo1());
      // 契約者電話1（加入者番号）
      contractor.setCphDirectoryNo1(updateContractorBusinessBean
          .getContractorPhoneDirectoryNo1());
      // 契約者電話区分コード2
      contractor.setCphCatCode2(updateContractorBusinessBean
          .getContractorPhoneCategoryCode2());
      // 契約者電話2（市外局番）
      contractor.setCphAreaCode2(updateContractorBusinessBean
          .getContractorPhoneAreaCode2());
      // 契約者電話2（市内局番）
      contractor.setCphLocalNo2(updateContractorBusinessBean
          .getContractorPhoneLocalNo2());
      // 契約者電話2（加入者番号）
      contractor.setCphDirectoryNo2(updateContractorBusinessBean
          .getContractorPhoneDirectoryNo2());
      // 契約者メールアドレス1
      contractor.setCma1(updateContractorBusinessBean
          .getContractorMailAddress1());
      // 契約者メールアドレス2
      contractor.setCma2(updateContractorBusinessBean
          .getContractorMailAddress2());
      // 利用不能フラグ
      contractor.setUnavailableFlag(updateContractorBusinessBean
          .getUnavailableFlag());
      // 取引先コード
      contractor.setCustomerCode(updateContractorBusinessBean
          .getCustomerCode());
      // 督促対象外フラグ
      contractor.setUrgeNotCoveredFlag(updateContractorBusinessBean
          .getUrgeNotCoveredFlag());
      // 個人・法人区分コード
      contractor.setIlcCode(updateContractorBusinessBean
          .getIndividualLegalEntityCategoryCode());
      // 見える化提供フラグ
      contractor.setVisualizationProvideFlag(updateContractorBusinessBean
          .getVisualizationProvideFlag());
      // 備考
      contractor.setNote(updateContractorBusinessBean.getNote());
      // 更新回数
      contractor.setUpdateCount(updateContractorBusinessBean
          .getUpdateCount() + 1);
      // 契約者住所(住所)
      contractor.setCaFull(updateCaFullStrBuilder(
          updateContractorBusinessBean
              .getContractorAddressPrefectures(),
          updateContractorBusinessBean
              .getContractorAddressMunicipality(),
          updateContractorBusinessBean.getContractorAddressSection(),
          updateContractorBusinessBean.getContractorAddressBlock(),
          inquiryContractorInformationEntityBean
              .getContractorAddressSection(),
          inquiryContractorInformationEntityBean
              .getContractorAddressBlock()));
      // 契約者住所(建物・部屋名)
      contractor.setCaBuilding(updateCaBuildingStrBuilder(
          updateContractorBusinessBean
              .getContractorAddressBuildingName(),
          updateContractorBusinessBean.getContractorAddressRoom(),
          inquiryContractorInformationEntityBean
              .getContractorAddressBuildingName(),
          inquiryContractorInformationEntityBean
              .getContractorAddressRoom()));
      // 契約者電話番号1
      contractor.setCphNo1(cphNoStrBuilder(updateContractorBusinessBean
          .getContractorPhoneAreaCode1(),
          updateContractorBusinessBean.getContractorPhoneLocalNo1(),
          updateContractorBusinessBean
              .getContractorPhoneDirectoryNo1()));
      // 契約者電話番号
      contractor.setCphNo2(cphNoStrBuilder(updateContractorBusinessBean
          .getContractorPhoneAreaCode2(),
          updateContractorBusinessBean.getContractorPhoneLocalNo2(),
          updateContractorBusinessBean
              .getContractorPhoneDirectoryNo2()));
      // オンライン更新日時
      contractor.setOnlineUpdateTime(systemDate);
      // オンライン更新ユーザID
      contractor.setOnlineUpdateUserId(ThreadContext
          .getRequestThreadContext().get(ECISConstants.USER_ID_KEY)
          .toString());
      // 更新日時
      contractor.setUpdateTime(systemDate);
      // 更新モジュールコード
      contractor.setUpdateModuleCode(ThreadContext
          .getRequestThreadContext()
          .get(ECISConstants.CLASS_NAME_KEY).toString());
      // 契約者ID
      // 更新回数
      contractorExample
          .createCriteria()
          .andContractorIdEqualTo(
              inquiryContractorInformationEntityBean
                  .getContractorId())
          .andUpdateCountEqualTo(
              updateContractorBusinessBean.getUpdateCount());
      // 《契約者情報共通Dao》.契約者情報更新の返却値が0件の場合
      if (contractorMapper.updateByExampleSelective(contractor,
          contractorExample) == 0) {

        updateContractorBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_H001);
        updateContractorBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_H001),
                new String[] {}, Locale.getDefault()));
        return updateContractorBusinessBean;

      }
      // 正常終了
      updateContractorBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);

    } catch (BusinessLogicException e) {
      logger.error(messageSource.getMessage("error.E1129", null,
          Locale.getDefault()), e);
      // catch 業務例外クラス
      updateContractorBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      updateContractorBusinessBean.setMessage(businessLogicExceptionEMsg);

    } catch (NoSuchMessageException e) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, e);
      updateContractorBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      updateContractorBusinessBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
    } catch (SystemException e) {
      logger.error(messageSource.getMessage("error.E1129", null,
          Locale.getDefault()), e);
      updateContractorBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      updateContractorBusinessBean
          .setMessage(getProcessBaseDateErrorEMsg);
    }
    return updateContractorBusinessBean;
  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.kj.KJ_ContractorInformationBusiness
   * #csvFileCheck
   * (jp.co.unisys.enability.cis.business.kj.model.CsvFileCheckContractorBusinessBean
   * )
   */
  public CsvFileCheckContractorBusinessBean csvFileCheck(
      CsvFileCheckContractorBusinessBean csvFileCheckContractorBusinessBean) {
    try {
      // 返却用オブジェクト生成
      CsvFileCheckContractorBusinessBean csvResultBean = new CsvFileCheckContractorBusinessBean();

      // エラーリスト
      List<String> errorList = new ArrayList<String>();
      // 登録オブジェクトリスト
      List<Map<Integer, String>> registList = new ArrayList<Map<Integer, String>>();
      // 更新オブジェクトリスト
      List<Map<Integer, String>> updateList = new ArrayList<Map<Integer, String>>();

      // ファイル取得
      File contractorFile = csvFileCheckContractorBusinessBean
          .getUploadFile();
      String fileName = contractorFile.getName();

      // ファイル読み込み
      List<Map<Integer, String>> csvMapList = Csv
          .load(contractorFile, ECISConstants.ENCODE_TYPE_UTF8,
              ContractManagementInformationFileConfigCommon
                  .getCsvConfig(),
              new ColumnPositionMapListHandler());

      /**
       * ヘッダレコードチェック
       */
      // ファイル構成チェック
      if (ContractManagementInformationFileConfigCommon.UPLOAD_FILE_MINIMUM_LINE_COUNT > csvMapList
          .size()) {
        errorList.add(StringConvertUtil.convertErrorListString(
            fileName,
            null,
            messageSource.getMessage("error.E0028", null,
                Locale.getDefault())));
        csvResultBean.setUploadFileName(fileName);
        csvResultBean.setErrorList(errorList);
        csvResultBean.setRegistList(registList);
        csvResultBean.setUpdateList(updateList);
        return csvResultBean;
      }

      // ヘッダレコード取得
      Map<Integer, String> headerRecord = csvMapList
          .get(ContractManagementInformationFileConfigCommon.ROW_NUMBER_HEADER);
      // 項目数チェック
      if (ContractManagementInformationFileConfigCommon.HEADER_COLUMN_COUNT != headerRecord
          .size()) {
        errorList
            .add(StringConvertUtil.convertErrorListString(
                contractorFile.getName(),
                ContractManagementInformationFileConfigCommon.HEADER_START_LINE_NUMBER,
                messageSource.getMessage("error.E0021", null,
                    Locale.getDefault())));
        csvResultBean.setUploadFileName(fileName);
        csvResultBean.setErrorList(errorList);
        csvResultBean.setRegistList(registList);
        csvResultBean.setUpdateList(updateList);
        return csvResultBean;
      }

      // 単項目チェック
      List<String> headerErrorMessageList = contractManagementInformationFileHeaderValidator
          .validate(
              headerRecord,
              ContractManagementInformationFileConfigContractor.HEADER_FILE_KIND_MASK_STRING);
      if (headerErrorMessageList.size() > 0) {
        for (String message : headerErrorMessageList) {
          errorList
              .add(StringConvertUtil
                  .convertErrorListString(
                      fileName,
                      ContractManagementInformationFileConfigCommon.HEADER_START_LINE_NUMBER,
                      message));
        }
        csvResultBean.setUploadFileName(fileName);
        csvResultBean.setErrorList(errorList);
        csvResultBean.setRegistList(registList);
        csvResultBean.setUpdateList(updateList);
        return csvResultBean;
      }

      /**
       * タイトルレコードチェック
       */
      Map<Integer, String> titleRecord = csvMapList
          .get(ContractManagementInformationFileConfigCommon.ROW_NUMBER_TITLE);
      // 項目数チェック
      if (ContractManagementInformationFileConfigContractor.DATA_COLUMN_COUNT != titleRecord
          .size()) {
        // データレコード項目数と一致しない場合、エラー終了
        errorList
            .add(StringConvertUtil
                .convertErrorListString(
                    fileName,
                    ContractManagementInformationFileConfigCommon.TITLE_START_LINE_NUMBER,
                    messageSource.getMessage("error.E0021",
                        null, Locale.getDefault())));
        csvResultBean.setUploadFileName(fileName);
        csvResultBean.setErrorList(errorList);
        csvResultBean.setRegistList(registList);
        csvResultBean.setUpdateList(updateList);
        return csvResultBean;
      }

      // 各項目チェック
      // HashMapだと順番に揃わない可能性があるため、IteratorでKeyを取得
      Iterator<Integer> titleIt = titleRecord.keySet().iterator();
      while (titleIt.hasNext()) {
        // タイトルのカラム番号を取得
        Integer columnNo = titleIt.next();
        // タイトル内容を取得
        String titleValue = titleRecord.get(columnNo);
        // コンフィグの内容を取得
        String configValue = ContractManagementInformationFileConfigContractor.DATA_TITLE_ROW[columnNo
            .intValue()];
        // 一致していない場合、エラー終了
        if (!configValue.equals(titleValue)) {
          errorList
              .add(StringConvertUtil
                  .convertErrorListString(
                      fileName,
                      ContractManagementInformationFileConfigCommon.TITLE_START_LINE_NUMBER,
                      messageSource.getMessage(
                          "error.E0028", null,
                          Locale.getDefault())));
          csvResultBean.setUploadFileName(fileName);
          csvResultBean.setErrorList(errorList);
          csvResultBean.setRegistList(registList);
          csvResultBean.setUpdateList(updateList);
          return csvResultBean;
        }
      }

      /**
       * マスタ情報取得
       */
      // 個人・法人区分コード
      List<IlcM> individualLegalEntityCategoryMasterList = ilcMMapper
          .selectByExample(null);
      // チェック用Setに詰め替え
      Set<String> individualLegalEntityCategoryMasterCodeCheckSet = new HashSet<String>();
      for (IlcM individualLegalEntityCategoryMaster : individualLegalEntityCategoryMasterList) {
        individualLegalEntityCategoryMasterCodeCheckSet
            .add(individualLegalEntityCategoryMaster.getIlcCode());
      }
      // エラー用メッセージ設定
      String individualLegalEntityCategoryMasterCodeErrorMessageOption = StringUtils
          .join(individualLegalEntityCategoryMasterCodeCheckSet, ",");

      // 電話番号区分コード
      List<PhoneNoCatM> phoneNoCategoryMasterList = phoneNoCatMMapper
          .selectByExample(null);
      // チェック用Setに詰め替え
      Set<String> phoneNoCategoryMasterCodeCheckSet = new HashSet<String>();
      for (PhoneNoCatM phoneNoCategoryMaster : phoneNoCategoryMasterList) {
        phoneNoCategoryMasterCodeCheckSet.add(phoneNoCategoryMaster
            .getPhoneNoCatCode());
      }
      // エラー用メッセージ設定
      String phoneNoCategoryMasterCodeErrorMessageOption = StringUtils
          .join(phoneNoCategoryMasterCodeCheckSet, ",");

      // 提供モデルコード
      List<PmM> provideModelMasterList = pmMMapper
          .selectByExample(null);
      // チェック用Setに詰め替え
      Set<String> provideModelMasterCodeCheckSet = new HashSet<String>();
      for (PmM provideModelMaster : provideModelMasterList) {
        provideModelMasterCodeCheckSet.add(provideModelMaster
            .getPmCode());
      }
      // エラー用メッセージ設定
      String provideModelMasterCodeErrorMessageOption = StringUtils.join(
          provideModelMasterCodeCheckSet, ",");

      // 登録・更新区分エラー用メッセージ設定
      String registUpdateCategoryErrorMessageOption = StringUtils
          .join(new String[] {
              ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER,
              ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_UPDATE },
              ",");

      /**
       * データレコードチェック
       */
      // データレコードの件数分処理を行う
      for (int i = ContractManagementInformationFileConfigCommon.ROW_NUMBER_DATA; i < csvMapList
          .size(); i++) {
        // 出力用行番号設定
        final int outputRowNumber = i + 1;

        // データレコードエラーリスト生成
        List<String> dataRecordErrorList = new ArrayList<String>();

        // データレコード取得
        Map<Integer, String> dataRecord = csvMapList.get(i);

        // 項目数チェック
        if (ContractManagementInformationFileConfigContractor.DATA_COLUMN_COUNT != dataRecord
            .size()) {
          // 項目数が一致しない場合、エラーリストに追加し、処理を終了する
          dataRecordErrorList.add(StringConvertUtil
              .convertErrorListString(fileName, outputRowNumber,
                  messageSource.getMessage("error.E0021",
                      null, Locale.getDefault())));
          errorList.addAll(dataRecordErrorList);

          // 処理を終了する。
          csvResultBean.setUploadFileName(fileName);
          csvResultBean.setErrorList(errorList);
          csvResultBean.setRegistList(registList);
          csvResultBean.setUpdateList(updateList);
          return csvResultBean;
        }

        // スキップ判定
        String registerUpdateCategory = dataRecord
            .get(ContractManagementInformationFileConfigContractor.DATA_REGISTER_UPDATE_CATEGORY_INDEX);
        if (StringUtils.isEmpty(registerUpdateCategory)) {
          continue;
        }

        // 単項目チェック
        // バリデーションエラーメッセージ用リスト生成
        List<String> validationErrorMessageList = new ArrayList<String>();
        // 登録・更新区分の値により、チェックメソッドを分岐
        switch (registerUpdateCategory) {
          case ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER:
            // 登録バリデーション実行
            validationErrorMessageList = contractorInformationFileRegistValidator
                .validate(dataRecord);
            break;
          case ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_UPDATE:
            // 更新バリデーション実行
            validationErrorMessageList = contractorInformationFileUpdateValidator
                .validate(dataRecord);
            break;
          default:
            // 登録・更新区分が不正な場合、エラーメッセージ設定
            dataRecordErrorList
                .add(StringConvertUtil.convertErrorListString(
                    fileName,
                    outputRowNumber,
                    messageSource
                        .getMessage(
                            "validation.range",
                            new String[] {
                                ContractManagementInformationFileConfigContractor.DATA_REGISTER_UPDATE_CATEGORY_NAME,
                                registUpdateCategoryErrorMessageOption },
                            Locale.getDefault())));
        }

        // バリデーションエラーメッセージにファイル名と行数を追加し、データレコードエラーリストに追加
        for (String validationErrorMessage : validationErrorMessageList) {
          dataRecordErrorList.add(StringConvertUtil
              .convertErrorListString(fileName, outputRowNumber,
                  validationErrorMessage));
        }

        // 登録・更新区分が登録または更新の場合のみチェック
        if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER
            .equals(registerUpdateCategory)
            || ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_UPDATE
                .equals(registerUpdateCategory)) {

          // 個人・法人区分コードチェック
          if (!individualLegalEntityCategoryMasterCodeCheckSet
              .contains(dataRecord
                  .get(ContractManagementInformationFileConfigContractor.DATA_INDIVIDUAL_LEGAL_ENTITY_CATEGORY_CODE_INDEX))) {
            dataRecordErrorList
                .add(StringConvertUtil.convertErrorListString(
                    fileName,
                    outputRowNumber,
                    messageSource
                        .getMessage(
                            "validation.range",
                            new String[] {
                                ContractManagementInformationFileConfigContractor.DATA_INDIVIDUAL_LEGAL_ENTITY_CATEGORY_CODE_NAME,
                                individualLegalEntityCategoryMasterCodeErrorMessageOption },
                            Locale.getDefault())));
          }

          // 契約者電話区分コード1チェック
          if (!phoneNoCategoryMasterCodeCheckSet
              .contains(dataRecord
                  .get(ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_CATEGORY_CODE1_INDEX))) {
            dataRecordErrorList
                .add(StringConvertUtil.convertErrorListString(
                    fileName,
                    outputRowNumber,
                    messageSource
                        .getMessage(
                            "validation.range",
                            new String[] {
                                ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_CATEGORY_CODE1_NAME,
                                phoneNoCategoryMasterCodeErrorMessageOption },
                            Locale.getDefault())));
          }

          // 契約者電話区分コード2チェック
          // 入力されている場合のみ判定する
          String contractorPhoneCategoryCode2 = dataRecord
              .get(ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_CATEGORY_CODE2_INDEX);
          if (StringUtils.isNotEmpty(contractorPhoneCategoryCode2)) {
            if (!phoneNoCategoryMasterCodeCheckSet
                .contains(contractorPhoneCategoryCode2)) {
              dataRecordErrorList
                  .add(StringConvertUtil
                      .convertErrorListString(
                          fileName,
                          outputRowNumber,
                          messageSource
                              .getMessage(
                                  "validation.range",
                                  new String[] {
                                      ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_CATEGORY_CODE2_NAME,
                                      phoneNoCategoryMasterCodeErrorMessageOption },
                                  Locale.getDefault())));
            }
          }

          // 契約者電話2チェック
          // 全て未入力または全て入力であるかチェックする
          if (!KJ_CommonUtil
              .checkContractorPhone2(
                  contractorPhoneCategoryCode2,
                  dataRecord
                      .get(ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_AREA_CODE2_INDEX),
                  dataRecord
                      .get(ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_LOCAL_NO2_INDEX),
                  dataRecord
                      .get(ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_DIRECTORY_NO2_INDEX))) {
            dataRecordErrorList.add(StringConvertUtil
                .convertErrorListString(fileName,
                    outputRowNumber, messageSource
                        .getMessage("error.E1014",
                            null,
                            Locale.getDefault())));
          }

          // 契約者電話1文字列長チェック
          StringBuilder contractorPhone1 = new StringBuilder();
          contractorPhone1
              .append(dataRecord
                  .get(ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_AREA_CODE1_INDEX));
          contractorPhone1
              .append(dataRecord
                  .get(ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_LOCAL_NO_INDEX));
          contractorPhone1
              .append(dataRecord
                  .get(ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_DIRECTORY_NO_INDEX));
          if (contractorPhone1.length() > ContractManagementInformationFileConfigContractor.PHONE_MAX) {
            dataRecordErrorList.add(StringConvertUtil
                .convertErrorListString(fileName,
                    outputRowNumber, messageSource
                        .getMessage("error.E1393",
                            null,
                            Locale.getDefault())));
          }

          // 契約者電話2文字列長チェック
          StringBuilder contractorPhone2 = new StringBuilder();
          contractorPhone2
              .append(dataRecord
                  .get(ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_AREA_CODE2_INDEX));
          contractorPhone2
              .append(dataRecord
                  .get(ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_LOCAL_NO2_INDEX));
          contractorPhone2
              .append(dataRecord
                  .get(ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_DIRECTORY_NO2_INDEX));
          if (contractorPhone2.length() > ContractManagementInformationFileConfigContractor.PHONE_MAX) {
            dataRecordErrorList.add(StringConvertUtil
                .convertErrorListString(fileName,
                    outputRowNumber, messageSource
                        .getMessage("error.E1394",
                            null,
                            Locale.getDefault())));
          }

          // 契約者メールアドレス1、2のチェック
          if (!KJ_CommonUtil
              .checkMailAddressCorrelation(
                  dataRecord
                      .get(ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_MAIL_ADDRESS1_INDEX),
                  dataRecord
                      .get(ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_MAIL_ADDRESS2_INDEX))) {
            dataRecordErrorList.add(StringConvertUtil
                .convertErrorListString(fileName,
                    outputRowNumber, messageSource
                        .getMessage("error.E1219",
                            null,
                            Locale.getDefault())));
          }

        }

        // 登録時のみのチェック
        if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER
            .equals(registerUpdateCategory)) {
          // 提供モデルコード取得
          String provideModelCode = dataRecord
              .get(ContractManagementInformationFileConfigContractor.DATA_PROVIDE_MODEL_CODE_INDEX);

          // 提供モデルコードチェック
          if (!provideModelMasterCodeCheckSet
              .contains(provideModelCode)) {
            // マスタに含まれていない場合、エラー
            dataRecordErrorList
                .add(StringConvertUtil.convertErrorListString(
                    fileName,
                    outputRowNumber,
                    messageSource
                        .getMessage(
                            "validation.range",
                            new String[] {
                                ContractManagementInformationFileConfigContractor.DATA_PROVIDE_MODEL_CODE_NAME,
                                provideModelMasterCodeErrorMessageOption },
                            Locale.getDefault())));
          } else {
            // 提供モデルコードがマスタに含まれている場合
            // 提供モデル企業コードのチェック

            // 取得条件設定
            PmCompanyMExample pmCompanyMasterEx = new PmCompanyMExample();
            // 提供モデルコードと提供モデル企業コードの複合PKチェック
            pmCompanyMasterEx
                .createCriteria()
                .andPmCodeEqualTo(provideModelCode)
                .andPmCompanyCodeEqualTo(
                    dataRecord
                        .get(ContractManagementInformationFileConfigContractor.DATA_PROVIDE_MODEL_COMPANY_CODE_INDEX));
            int count = pmCompanyMMapper
                .countByExample(pmCompanyMasterEx);
            if (count == 0) {
              dataRecordErrorList
                  .add(StringConvertUtil
                      .convertErrorListString(
                          fileName,
                          outputRowNumber,
                          messageSource
                              .getMessage(
                                  "validation.regexitem",
                                  new String[] {
                                      ContractManagementInformationFileConfigContractor.DATA_PROVIDE_MODEL_COMPANY_CODE_NAME },
                                  Locale.getDefault())));
            }
          }
        }

        // データレコードエラーリストチェック
        if (!dataRecordErrorList.isEmpty()) {
          // データレコードエラーリストが存在する場合
          // 処理用オブジェクトには格納しない
          errorList.addAll(dataRecordErrorList);
          continue;
        }

        // データレコード振分
        Map<Integer, String> resultDataRecordMap = new HashMap<Integer, String>(
            dataRecord);
        // 行番号設定
        // 実際の行数（インデックス＋１）を設定する
        resultDataRecordMap
            .put(ContractManagementInformationFileConfigCommon.DATA_ROW_NO_INDEX,
                String.valueOf(outputRowNumber));
        // 登録・更新により振分
        if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER
            .equals(registerUpdateCategory)) {
          // 登録の場合、登録オブジェクトリストに追加
          registList.add(resultDataRecordMap);
        } else if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_UPDATE
            .equals(registerUpdateCategory)) {
          // 更新の場合、更新オブジェクトリストに追加
          updateList.add(resultDataRecordMap);
        }
      }

      // オブジェクト返却
      csvResultBean.setUploadFileName(fileName);
      csvResultBean.setErrorList(errorList);
      csvResultBean.setRegistList(registList);
      csvResultBean.setUpdateList(updateList);
      return csvResultBean;
    } catch (Exception e) {
      throw new SystemException(e.getMessage(), e);
    }
  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.kj.KJ_ContractorInformationBusiness
   * #csvFileCheck
   * (jp.co.unisys.enability.cis.business.kj.model.CsvFileCheckContractorBusinessBean
   * )
   */
  public CsvFileCheckContractorBusinessBean csvFileCheckCustom(
      CsvFileCheckContractorBusinessBean csvFileCheckContractorBusinessBean) {
    try {
      // 返却用オブジェクト生成
      CsvFileCheckContractorBusinessBean csvResultBean = new CsvFileCheckContractorBusinessBean();

      // エラーリスト
      List<String> errorList = new ArrayList<String>();
      // 登録オブジェクトリスト
      List<Map<Integer, String>> registList = new ArrayList<Map<Integer, String>>();
      // 更新オブジェクトリスト
      List<Map<Integer, String>> updateList = new ArrayList<Map<Integer, String>>();

      // ファイル取得
      File contractorFile = csvFileCheckContractorBusinessBean
          .getUploadFile();
      String fileName = contractorFile.getName();

      // ファイル読み込み
      List<Map<Integer, String>> csvMapList = Csv
          .load(contractorFile, ECISConstants.ENCODE_TYPE_UTF8,
              ContractManagementInformationFileConfigCommon
                  .getCsvConfig(),
              new ColumnPositionMapListHandler());

      /**
       * ヘッダレコードチェック
       */
      // ファイル構成チェック
      if (ContractManagementInformationFileConfigCommon.UPLOAD_FILE_MINIMUM_LINE_COUNT > csvMapList
          .size()) {
        errorList.add(StringConvertUtil.convertErrorListString(
            fileName,
            null,
            messageSource.getMessage("error.E0028", null,
                Locale.getDefault())));
        csvResultBean.setUploadFileName(fileName);
        csvResultBean.setErrorList(errorList);
        csvResultBean.setRegistList(registList);
        csvResultBean.setUpdateList(updateList);
        return csvResultBean;
      }

      // ヘッダレコード取得
      Map<Integer, String> headerRecord = csvMapList
          .get(ContractManagementInformationFileConfigCommon.ROW_NUMBER_HEADER);
      // 項目数チェック
      if (ContractManagementInformationFileConfigCommon.HEADER_COLUMN_COUNT != headerRecord
          .size()) {
        errorList
            .add(StringConvertUtil.convertErrorListString(
                contractorFile.getName(),
                ContractManagementInformationFileConfigCommon.HEADER_START_LINE_NUMBER,
                messageSource.getMessage("error.E0021", null,
                    Locale.getDefault())));
        csvResultBean.setUploadFileName(fileName);
        csvResultBean.setErrorList(errorList);
        csvResultBean.setRegistList(registList);
        csvResultBean.setUpdateList(updateList);
        return csvResultBean;
      }

      // 単項目チェック
      List<String> headerErrorMessageList = contractManagementInformationFileHeaderValidator
          .validate(
              headerRecord,
              Custom_ContractManagementInformationFileConfigContractor.HEADER_FILE_KIND_MASK_STRING);
      if (headerErrorMessageList.size() > 0) {
        for (String message : headerErrorMessageList) {
          errorList
              .add(StringConvertUtil
                  .convertErrorListString(
                      fileName,
                      ContractManagementInformationFileConfigCommon.HEADER_START_LINE_NUMBER,
                      message));
        }
        csvResultBean.setUploadFileName(fileName);
        csvResultBean.setErrorList(errorList);
        csvResultBean.setRegistList(registList);
        csvResultBean.setUpdateList(updateList);
        return csvResultBean;
      }

      /**
       * タイトルレコードチェック
       */
      Map<Integer, String> titleRecord = csvMapList
          .get(ContractManagementInformationFileConfigCommon.ROW_NUMBER_TITLE);
      // 項目数チェック
      if (Custom_ContractManagementInformationFileConfigContractor.DATA_COLUMN_COUNT != titleRecord
          .size()) {
        // データレコード項目数と一致しない場合、エラー終了
        errorList
            .add(StringConvertUtil
                .convertErrorListString(
                    fileName,
                    ContractManagementInformationFileConfigCommon.TITLE_START_LINE_NUMBER,
                    messageSource.getMessage("error.E0021",
                        null, Locale.getDefault())));
        csvResultBean.setUploadFileName(fileName);
        csvResultBean.setErrorList(errorList);
        csvResultBean.setRegistList(registList);
        csvResultBean.setUpdateList(updateList);
        return csvResultBean;
      }

      // 各項目チェック
      // HashMapだと順番に揃わない可能性があるため、IteratorでKeyを取得
      Iterator<Integer> titleIt = titleRecord.keySet().iterator();
      while (titleIt.hasNext()) {
        // タイトルのカラム番号を取得
        Integer columnNo = titleIt.next();
        // タイトル内容を取得
        String titleValue = titleRecord.get(columnNo);
        // コンフィグの内容を取得
        String configValue = Custom_ContractManagementInformationFileConfigContractor.DATA_TITLE_ROW[columnNo
            .intValue()];
        // 一致していない場合、エラー終了
        if (!configValue.equals(titleValue)) {
          errorList
              .add(StringConvertUtil
                  .convertErrorListString(
                      fileName,
                      ContractManagementInformationFileConfigCommon.TITLE_START_LINE_NUMBER,
                      messageSource.getMessage(
                          "error.E0028", null,
                          Locale.getDefault())));
          csvResultBean.setUploadFileName(fileName);
          csvResultBean.setErrorList(errorList);
          csvResultBean.setRegistList(registList);
          csvResultBean.setUpdateList(updateList);
          return csvResultBean;
        }
      }

      /**
       * マスタ情報取得
       */
      // 個人・法人区分コード
      List<IlcM> individualLegalEntityCategoryMasterList = ilcMMapper
          .selectByExample(null);
      // チェック用Setに詰め替え
      Set<String> individualLegalEntityCategoryMasterCodeCheckSet = new HashSet<String>();
      for (IlcM individualLegalEntityCategoryMaster : individualLegalEntityCategoryMasterList) {
        individualLegalEntityCategoryMasterCodeCheckSet
            .add(individualLegalEntityCategoryMaster.getIlcCode());
      }
      // エラー用メッセージ設定
      String individualLegalEntityCategoryMasterCodeErrorMessageOption = StringUtils
          .join(individualLegalEntityCategoryMasterCodeCheckSet, ",");

      // 電話番号区分コード
      List<PhoneNoCatM> phoneNoCategoryMasterList = phoneNoCatMMapper
          .selectByExample(null);
      // チェック用Setに詰め替え
      Set<String> phoneNoCategoryMasterCodeCheckSet = new HashSet<String>();
      for (PhoneNoCatM phoneNoCategoryMaster : phoneNoCategoryMasterList) {
        phoneNoCategoryMasterCodeCheckSet.add(phoneNoCategoryMaster
            .getPhoneNoCatCode());
      }
      // エラー用メッセージ設定
      String phoneNoCategoryMasterCodeErrorMessageOption = StringUtils
          .join(phoneNoCategoryMasterCodeCheckSet, ",");

      // 提供モデルコード
      List<PmM> provideModelMasterList = pmMMapper
          .selectByExample(null);
      // チェック用Setに詰め替え
      Set<String> provideModelMasterCodeCheckSet = new HashSet<String>();
      for (PmM provideModelMaster : provideModelMasterList) {
        provideModelMasterCodeCheckSet.add(provideModelMaster
            .getPmCode());
      }
      // エラー用メッセージ設定
      String provideModelMasterCodeErrorMessageOption = StringUtils.join(
          provideModelMasterCodeCheckSet, ",");

      // 登録・更新区分エラー用メッセージ設定
      String registUpdateCategoryErrorMessageOption = StringUtils
          .join(new String[] {
              ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER,
              ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_UPDATE },
              ",");

      /**
       * データレコードチェック
       */
      // データレコードの件数分処理を行う
      for (int i = ContractManagementInformationFileConfigCommon.ROW_NUMBER_DATA; i < csvMapList
          .size(); i++) {
        // 出力用行番号設定
        final int outputRowNumber = i + 1;

        // データレコードエラーリスト生成
        List<String> dataRecordErrorList = new ArrayList<String>();

        // データレコード取得
        Map<Integer, String> dataRecord = csvMapList.get(i);

        // 項目数チェック
        if (Custom_ContractManagementInformationFileConfigContractor.DATA_COLUMN_COUNT != dataRecord
            .size()) {
          // 項目数が一致しない場合、エラーリストに追加し、処理を終了する
          dataRecordErrorList.add(StringConvertUtil
              .convertErrorListString(fileName, outputRowNumber,
                  messageSource.getMessage("error.E0021",
                      null, Locale.getDefault())));
          errorList.addAll(dataRecordErrorList);

          // 処理を終了する。
          csvResultBean.setUploadFileName(fileName);
          csvResultBean.setErrorList(errorList);
          csvResultBean.setRegistList(registList);
          csvResultBean.setUpdateList(updateList);
          return csvResultBean;
        }

        // スキップ判定
        String registerUpdateCategory = dataRecord
            .get(Custom_ContractManagementInformationFileConfigContractor.DATA_REGISTER_UPDATE_CATEGORY_INDEX);
        if (StringUtils.isEmpty(registerUpdateCategory)) {
          continue;
        }

        // 単項目チェック
        // バリデーションエラーメッセージ用リスト生成
        List<String> validationErrorMessageList = new ArrayList<String>();
        // 登録・更新区分の値により、チェックメソッドを分岐
        switch (registerUpdateCategory) {
          case ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER:
            // 登録バリデーション実行
            validationErrorMessageList = customContractorInformationFileRegistValidator
                .validate(dataRecord);
            break;
          case ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_UPDATE:
            // 更新バリデーション実行
            validationErrorMessageList = customContractorInformationFileUpdateValidator
                .validate(dataRecord);
            break;
          default:
            // 登録・更新区分が不正な場合、エラーメッセージ設定
            dataRecordErrorList
                .add(StringConvertUtil.convertErrorListString(
                    fileName,
                    outputRowNumber,
                    messageSource
                        .getMessage(
                            "validation.range",
                            new String[] {
                                Custom_ContractManagementInformationFileConfigContractor.DATA_REGISTER_UPDATE_CATEGORY_NAME,
                                registUpdateCategoryErrorMessageOption },
                            Locale.getDefault())));
        }

        // バリデーションエラーメッセージにファイル名と行数を追加し、データレコードエラーリストに追加
        for (String validationErrorMessage : validationErrorMessageList) {
          dataRecordErrorList.add(StringConvertUtil
              .convertErrorListString(fileName, outputRowNumber,
                  validationErrorMessage));
        }

        // 登録・更新区分が登録または更新の場合のみチェック
        if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER
            .equals(registerUpdateCategory)
            || ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_UPDATE
                .equals(registerUpdateCategory)) {

          // 個人・法人区分コードチェック
          if (!individualLegalEntityCategoryMasterCodeCheckSet
              .contains(dataRecord
                  .get(Custom_ContractManagementInformationFileConfigContractor.DATA_INDIVIDUAL_LEGAL_ENTITY_CATEGORY_CODE_INDEX))) {
            dataRecordErrorList
                .add(StringConvertUtil.convertErrorListString(
                    fileName,
                    outputRowNumber,
                    messageSource
                        .getMessage(
                            "validation.range",
                            new String[] {
                                Custom_ContractManagementInformationFileConfigContractor.DATA_INDIVIDUAL_LEGAL_ENTITY_CATEGORY_CODE_NAME,
                                individualLegalEntityCategoryMasterCodeErrorMessageOption },
                            Locale.getDefault())));
          }

          // 契約者電話区分コード1チェック
          if (!phoneNoCategoryMasterCodeCheckSet
              .contains(dataRecord
                  .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_CATEGORY_CODE1_INDEX))) {
            dataRecordErrorList
                .add(StringConvertUtil.convertErrorListString(
                    fileName,
                    outputRowNumber,
                    messageSource
                        .getMessage(
                            "validation.range",
                            new String[] {
                                Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_CATEGORY_CODE1_NAME,
                                phoneNoCategoryMasterCodeErrorMessageOption },
                            Locale.getDefault())));
          }

          // 契約者電話区分コード2チェック
          // 入力されている場合のみ判定する
          String contractorPhoneCategoryCode2 = dataRecord
              .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_CATEGORY_CODE2_INDEX);
          if (StringUtils.isNotEmpty(contractorPhoneCategoryCode2)) {
            if (!phoneNoCategoryMasterCodeCheckSet
                .contains(contractorPhoneCategoryCode2)) {
              dataRecordErrorList
                  .add(StringConvertUtil
                      .convertErrorListString(
                          fileName,
                          outputRowNumber,
                          messageSource
                              .getMessage(
                                  "validation.range",
                                  new String[] {
                                      Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_CATEGORY_CODE2_NAME,
                                      phoneNoCategoryMasterCodeErrorMessageOption },
                                  Locale.getDefault())));
            }
          }

          // 契約者電話2チェック
          // 全て未入力または全て入力であるかチェックする
          if (!KJ_CommonUtil
              .checkContractorPhone2(
                  contractorPhoneCategoryCode2,
                  dataRecord
                      .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_AREA_CODE2_INDEX),
                  dataRecord
                      .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_LOCAL_NO2_INDEX),
                  dataRecord
                      .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_DIRECTORY_NO2_INDEX))) {
            dataRecordErrorList.add(StringConvertUtil
                .convertErrorListString(fileName,
                    outputRowNumber, messageSource
                        .getMessage("error.E1014",
                            null,
                            Locale.getDefault())));
          }

          // 契約者電話1文字列長チェック
          StringBuilder contractorPhone1 = new StringBuilder();
          contractorPhone1
              .append(dataRecord
                  .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_AREA_CODE1_INDEX));
          contractorPhone1
              .append(dataRecord
                  .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_LOCAL_NO_INDEX));
          contractorPhone1
              .append(dataRecord
                  .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_DIRECTORY_NO_INDEX));
          if (contractorPhone1
              .length() > Custom_ContractManagementInformationFileConfigContractor.PHONE_MAX) {
            dataRecordErrorList.add(StringConvertUtil
                .convertErrorListString(fileName,
                    outputRowNumber, messageSource
                        .getMessage("error.E1393",
                            null,
                            Locale.getDefault())));
          }

          // 契約者電話2文字列長チェック
          StringBuilder contractorPhone2 = new StringBuilder();
          contractorPhone2
              .append(dataRecord
                  .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_AREA_CODE2_INDEX));
          contractorPhone2
              .append(dataRecord
                  .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_LOCAL_NO2_INDEX));
          contractorPhone2
              .append(dataRecord
                  .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_DIRECTORY_NO2_INDEX));
          if (contractorPhone2
              .length() > Custom_ContractManagementInformationFileConfigContractor.PHONE_MAX) {
            dataRecordErrorList.add(StringConvertUtil
                .convertErrorListString(fileName,
                    outputRowNumber, messageSource
                        .getMessage("error.E1394",
                            null,
                            Locale.getDefault())));
          }

          // 契約者メールアドレス1、2のチェック
          if (!KJ_CommonUtil
              .checkMailAddressCorrelation(
                  dataRecord
                      .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_MAIL_ADDRESS1_INDEX),
                  dataRecord
                      .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_MAIL_ADDRESS2_INDEX))) {
            dataRecordErrorList.add(StringConvertUtil
                .convertErrorListString(fileName,
                    outputRowNumber, messageSource
                        .getMessage("error.E1219",
                            null,
                            Locale.getDefault())));
          }

        }

        // 登録時のみのチェック
        if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER
            .equals(registerUpdateCategory)) {
          // 提供モデルコード取得
          String provideModelCode = dataRecord
              .get(Custom_ContractManagementInformationFileConfigContractor.DATA_PROVIDE_MODEL_CODE_INDEX);

          // 提供モデルコードチェック
          if (!provideModelMasterCodeCheckSet
              .contains(provideModelCode)) {
            // マスタに含まれていない場合、エラー
            dataRecordErrorList
                .add(StringConvertUtil.convertErrorListString(
                    fileName,
                    outputRowNumber,
                    messageSource
                        .getMessage(
                            "validation.range",
                            new String[] {
                                Custom_ContractManagementInformationFileConfigContractor.DATA_PROVIDE_MODEL_CODE_NAME,
                                provideModelMasterCodeErrorMessageOption },
                            Locale.getDefault())));
          } else {
            // 提供モデルコードがマスタに含まれている場合
            // 提供モデル企業コードのチェック

            // 取得条件設定
            PmCompanyMExample pmCompanyMasterEx = new PmCompanyMExample();
            // 提供モデルコードと提供モデル企業コードの複合PKチェック
            pmCompanyMasterEx
                .createCriteria()
                .andPmCodeEqualTo(provideModelCode)
                .andPmCompanyCodeEqualTo(
                    dataRecord
                        .get(Custom_ContractManagementInformationFileConfigContractor.DATA_PROVIDE_MODEL_COMPANY_CODE_INDEX));
            int count = pmCompanyMMapper
                .countByExample(pmCompanyMasterEx);
            if (count == 0) {
              dataRecordErrorList
                  .add(StringConvertUtil
                      .convertErrorListString(
                          fileName,
                          outputRowNumber,
                          messageSource
                              .getMessage(
                                  "validation.regexitem",
                                  new String[] {
                                      Custom_ContractManagementInformationFileConfigContractor.DATA_PROVIDE_MODEL_COMPANY_CODE_NAME },
                                  Locale.getDefault())));
            }
          }

          // フリー項目に値が設定されている場合、卸取次店契約者番号は必須
          // 卸取次店契約者取得
          String agentContractorNo = dataRecord
              .get(Custom_ContractManagementInformationFileConfigContractor.DATA_AGENT_CONTRACTOR_NO_INDEX);
          if (StringUtils.isEmpty(agentContractorNo)) {
            if (!StringUtils.isEmpty(dataRecord
                .get(Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_01_INDEX)) ||
                !StringUtils.isEmpty(dataRecord.get(
                    Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_02_INDEX))
                ||
                !StringUtils.isEmpty(dataRecord.get(
                    Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_03_INDEX))
                ||
                !StringUtils.isEmpty(dataRecord.get(
                    Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_04_INDEX))
                ||
                !StringUtils.isEmpty(dataRecord.get(
                    Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_05_INDEX))
                ||
                !StringUtils.isEmpty(dataRecord.get(
                    Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_06_INDEX))
                ||
                !StringUtils.isEmpty(dataRecord.get(
                    Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_07_INDEX))
                ||
                !StringUtils.isEmpty(dataRecord.get(
                    Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_08_INDEX))
                ||
                !StringUtils.isEmpty(dataRecord.get(
                    Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_09_INDEX))
                ||
                !StringUtils.isEmpty(dataRecord.get(
                    Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_10_INDEX))) {
              dataRecordErrorList
                  .add(StringConvertUtil.convertErrorListString(
                      fileName,
                      outputRowNumber,
                      messageSource
                          .getMessage(
                              "error.E1515",
                              null,
                              Locale.getDefault())));
            }
          }
        }

        // データレコードエラーリストチェック
        if (!dataRecordErrorList.isEmpty()) {
          // データレコードエラーリストが存在する場合
          // 処理用オブジェクトには格納しない
          errorList.addAll(dataRecordErrorList);
          continue;
        }

        // データレコード振分
        Map<Integer, String> resultDataRecordMap = new HashMap<Integer, String>(
            dataRecord);
        // 行番号設定
        // 実際の行数（インデックス＋１）を設定する
        resultDataRecordMap
            .put(ContractManagementInformationFileConfigCommon.DATA_ROW_NO_INDEX,
                String.valueOf(outputRowNumber));
        // 登録・更新により振分
        if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER
            .equals(registerUpdateCategory)) {
          // 登録の場合、登録オブジェクトリストに追加
          registList.add(resultDataRecordMap);
        } else if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_UPDATE
            .equals(registerUpdateCategory)) {
          // 更新の場合、更新オブジェクトリストに追加
          updateList.add(resultDataRecordMap);
        }
      }

      // オブジェクト返却
      csvResultBean.setUploadFileName(fileName);
      csvResultBean.setErrorList(errorList);
      csvResultBean.setRegistList(registList);
      csvResultBean.setUpdateList(updateList);
      return csvResultBean;
    } catch (Exception e) {
      throw new SystemException(e.getMessage(), e);
    }
  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.kj.KJ_ContractorInformationBusiness
   * #download
   * (jp.co.unisys.enability.cis.business.kj.model.DownloadContractorBusinessBean
   * )
   */
  public DownloadContractorBusinessBean download(
      DownloadContractorBusinessBean downloadContractorBusinessBean) {
    try {
      // ダウンロード情報検索
      Map<String, Object> exampleMap = new HashMap<String, Object>();
      // 契約者番号
      exampleMap
          .put(ECISKJConstants.S010107_SEARCH_KEY_CONTRACTOR_NO,
              downloadContractorBusinessBean
                  .getContractManagementInformationDownloadSearchInformationBean()
                  .getContractorNo());
      // 提供モデルコード
      exampleMap
          .put(ECISKJConstants.S010107_SEARCH_KEY_PROVIDE_MODEL,
              downloadContractorBusinessBean
                  .getContractManagementInformationDownloadSearchInformationBean()
                  .getProvideModel());
      // 提供モデル企業コード
      exampleMap
          .put(ECISKJConstants.S010107_SEARCH_KEY_PROVIDE_MODEL_COMPANY,
              downloadContractorBusinessBean
                  .getContractManagementInformationDownloadSearchInformationBean()
                  .getProvideModelCompany());
      // 個人・法人区分コード
      exampleMap
          .put(ECISKJConstants.S010107_SEARCH_KEY_INDIVIDUAL_LEGAL_ENTITY_CATEGORY,
              downloadContractorBusinessBean
                  .getContractManagementInformationDownloadSearchInformationBean()
                  .getIndividualLegalEntityCategory());
      // 取引先コード
      exampleMap
          .put(ECISKJConstants.S010107_SEARCH_KEY_CUSTOMER_CODE,
              downloadContractorBusinessBean
                  .getContractManagementInformationDownloadSearchInformationBean()
                  .getCustomerCode());

      // 「督促対象外分は除く」チェックボックス（空文字：null、"0"：チェックオン）
      exampleMap
          .put(ECISKJConstants.S010107_SEARCH_KEY_URGE_COVERED,
              downloadContractorBusinessBean
                  .getContractManagementInformationDownloadSearchInformationBean()
                  .getUrgeCovered());

      // 「契約者利用状況不能分を含む」チェックボックス(null：チェックオフ、"0"：チェックオン")
      exampleMap
          .put(ECISKJConstants.S010107_SEARCH_KEY_CONTRACTOR_USE_STATUS,
              downloadContractorBusinessBean
                  .getContractManagementInformationDownloadSearchInformationBean()
                  .getContractorUseStatus());

      List<KJ_ContractorInformationFileEntityBean> contractorInformationFileEntityBeanList = contractorInformationCommonMapper
          .selectContractorInformationFile(exampleMap);

      // ファイル名作成
      StringBuilder fileName = new StringBuilder();
      fileName.append(ECISKJConstants.CONTRACT_MANAGEMENT_INFORMATION_DOWNLOAD_FILE_PREFIX_CONTRACTOR);
      fileName.append(ECISConstants.UNDERLINE);
      fileName.append(StringConvertUtil.convertDateToString(dateBusiness
          .getProcessBaseDate(ECISConstants.EXEC_BASE_DATE_ONLINE),
          null));
      downloadContractorBusinessBean.setDownloadFileName(fileName
          .toString());

      // 契約者情報ファイルの出力内容設定
      downloadContractorBusinessBean
          .setContractorInformationFileEntityBeanList(contractorInformationFileEntityBeanList);

    } catch (Exception e) {
      throw new SystemException(e.getMessage(), e);
    }
    return downloadContractorBusinessBean;
  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.kj.KJ_ContractorInformationBusiness
   * #downloadCustom
   * (jp.co.unisys.enability.cis.business.kj.model.DownloadContractorBusinessBean
   * )
   */
  public DownloadContractorBusinessBean downloadCustom(
      DownloadContractorBusinessBean downloadContractorBusinessBean) {
    try {
      // ダウンロード情報検索
      Map<String, Object> exampleMap = new HashMap<String, Object>();
      // 契約者番号
      exampleMap
          .put(ECISKJConstants.S010107_SEARCH_KEY_CONTRACTOR_NO,
              downloadContractorBusinessBean
                  .getContractManagementInformationDownloadSearchInformationBean()
                  .getContractorNo());
      // 提供モデルコード
      exampleMap
          .put(ECISKJConstants.S010107_SEARCH_KEY_PROVIDE_MODEL,
              downloadContractorBusinessBean
                  .getContractManagementInformationDownloadSearchInformationBean()
                  .getProvideModel());
      // 提供モデル企業コード
      exampleMap
          .put(ECISKJConstants.S010107_SEARCH_KEY_PROVIDE_MODEL_COMPANY,
              downloadContractorBusinessBean
                  .getContractManagementInformationDownloadSearchInformationBean()
                  .getProvideModelCompany());
      // 個人・法人区分コード
      exampleMap
          .put(ECISKJConstants.S010107_SEARCH_KEY_INDIVIDUAL_LEGAL_ENTITY_CATEGORY,
              downloadContractorBusinessBean
                  .getContractManagementInformationDownloadSearchInformationBean()
                  .getIndividualLegalEntityCategory());
      // 取引先コード
      exampleMap
          .put(ECISKJConstants.S010107_SEARCH_KEY_CUSTOMER_CODE,
              downloadContractorBusinessBean
                  .getContractManagementInformationDownloadSearchInformationBean()
                  .getCustomerCode());

      // 「督促対象外分は除く」チェックボックス（空文字：null、"0"：チェックオン）
      exampleMap
          .put(ECISKJConstants.S010107_SEARCH_KEY_URGE_COVERED,
              downloadContractorBusinessBean
                  .getContractManagementInformationDownloadSearchInformationBean()
                  .getUrgeCovered());

      // 「契約者利用状況不能分を含む」チェックボックス(null：チェックオフ、"0"：チェックオン")
      exampleMap
          .put(ECISKJConstants.S010107_SEARCH_KEY_CONTRACTOR_USE_STATUS,
              downloadContractorBusinessBean
                  .getContractManagementInformationDownloadSearchInformationBean()
                  .getContractorUseStatus());

      // 外部システム契約者番号
      exampleMap
          .put(ECISKJConstants.S010107_SEARCH_KEY_EXTERNAL_MANAGE_CONTRACTOR_NO,
              downloadContractorBusinessBean
                  .getContractManagementInformationDownloadSearchInformationBean()
                  .getExternalManageContractorNo());

      List<KJ_ContractorInformationFileEntityBean> contractorInformationFileEntityBeanList = contractorInformationCommonMapper
          .selectContractorInformationFileCustom(exampleMap);

      // ファイル名作成
      StringBuilder fileName = new StringBuilder();
      fileName.append(ECISKJConstants.CONTRACT_MANAGEMENT_INFORMATION_DOWNLOAD_FILE_PREFIX_CONTRACTOR);
      fileName.append(ECISConstants.UNDERLINE);
      fileName.append(StringConvertUtil.convertDateToString(dateBusiness
          .getProcessBaseDate(ECISConstants.EXEC_BASE_DATE_ONLINE),
          null));
      downloadContractorBusinessBean.setDownloadFileName(fileName
          .toString());

      // 契約者情報ファイルの出力内容設定
      downloadContractorBusinessBean
          .setContractorInformationFileEntityBeanList(contractorInformationFileEntityBeanList);

    } catch (Exception e) {
      throw new SystemException(e.getMessage(), e);
    }
    return downloadContractorBusinessBean;
  }

  /**
   * 登録用契約者住所（建物・部屋名）を生成
   *
   * @param contractorAddressBuildingName
   *          建物名
   * @param contractorAddressRoom
   *          部屋名
   *
   */
  private String registCaBuildingStrBuilder(
      String contractorAddressBuildingName, String contractorAddressRoom) {
    String caBuilding = "";

    // 建物、部屋名がNULLまたは空文字でない場合
    if (StringUtils.isNotEmpty(contractorAddressBuildingName)
        && StringUtils.isNotEmpty(contractorAddressRoom)) {

      caBuilding = new StringBuilder(contractorAddressBuildingName)
          .append(ECISKJConstants.STRING_BUILDER_ZENKAKU_SPACE)
          .append(contractorAddressRoom).toString();

      // 建物、部屋名のどちらかがNULLまたは空文字でない場合
    } else if (StringUtils.isNotEmpty(contractorAddressBuildingName)
        || StringUtils.isNotEmpty(contractorAddressRoom)) {

      caBuilding = new StringBuilder(
          StringUtils.defaultString(contractorAddressBuildingName))
              .append(StringUtils.defaultString(contractorAddressRoom))
              .toString();
    }
    return caBuilding;
  }

  /**
   * 更新用契約者住所（建物・部屋名）を生成
   *
   * @param newContractorAddressBuildingName
   *          更新後建物名
   * @param newContractorAddressRoom
   *          更新後部屋名
   * @param oldContractorAddressBuildingName
   *          更新前建物
   * @param oldCcontractorAddressRoom
   *          更新前部屋名
   *
   */
  private String updateCaBuildingStrBuilder(
      String newContractorAddressBuildingName,
      String newContractorAddressRoom,
      String oldContractorAddressBuildingName,
      String oldCcontractorAddressRoom) {
    String caBuilding = null;
    // 契約者住所（建物名）に更新前建物名を設定
    String contractorAddressBuildingName = oldContractorAddressBuildingName;
    // 契約者住所（部屋名）に更新前部屋名を設定
    String contractorAddressRoom = oldCcontractorAddressRoom;

    // 更新後建物名に入力がある場合
    if (null != newContractorAddressBuildingName) {
      // 契約者住所（建物名）に更新後建物名を設定
      contractorAddressBuildingName = newContractorAddressBuildingName;
    }
    // 更新後部屋名に入力がある場合
    if (null != newContractorAddressRoom) {
      // 契約者住所（部屋名）に更新後部屋名を設定
      contractorAddressRoom = newContractorAddressRoom;
    }

    // 建物、部屋名がNULLまたは空文字でない場合
    if (StringUtils.isNotEmpty(contractorAddressBuildingName)
        && StringUtils.isNotEmpty(contractorAddressRoom)) {

      caBuilding = new StringBuilder(contractorAddressBuildingName)
          .append(ECISKJConstants.STRING_BUILDER_ZENKAKU_SPACE)
          .append(contractorAddressRoom).toString();

      // 建物、部屋名のどちらかがNULLでない場合
    } else if (null != contractorAddressBuildingName
        || null != contractorAddressRoom) {

      caBuilding = new StringBuilder(
          StringUtils.defaultString(contractorAddressBuildingName))
              .append(StringUtils.defaultString(contractorAddressRoom))
              .toString();
    }
    return caBuilding;
  }

  /**
   * 契約者電話番号を生成
   *
   * @param contractorPhoneAreaCode
   *          市外局番
   * @param contractorPhoneLocalNo
   *          市内局番
   * @param contractorPhoneDirectoryNo
   *          加入者番号
   *
   */
  private String cphNoStrBuilder(String contractorPhoneAreaCode,
      String contractorPhoneLocalNo, String contractorPhoneDirectoryNo) {
    String cphNo = null;
    // 市外局番、市内局番、加入者番号がNULLまたは空文字でない場合
    if (StringUtils.isNotEmpty(contractorPhoneAreaCode)
        && StringUtils.isNotEmpty(contractorPhoneLocalNo)
        && StringUtils.isNotEmpty(contractorPhoneDirectoryNo)) {

      cphNo = new StringBuilder(contractorPhoneAreaCode)
          .append(ECISConstants.HYPHEN)
          .append(contractorPhoneLocalNo)
          .append(ECISConstants.HYPHEN)
          .append(contractorPhoneDirectoryNo).toString();

    } else if (null != contractorPhoneAreaCode
        && null != contractorPhoneLocalNo
        && null != contractorPhoneDirectoryNo) {

      cphNo = "";

    }
    return cphNo;
  }

  /**
   * 登録用契約者住所を生成
   *
   * @param contractorAddressPrefectures
   *          都道府県名
   * @param contractorAddressMunicipality
   *          市区郡町村名
   * @param contractorAddressSection
   *          字名・丁目
   * @param contractorAddressBlock
   *          番地・号
   *
   */
  private String registCaFullStrBuilder(String contractorAddressPrefectures,
      String contractorAddressMunicipality,
      String contractorAddressSection, String contractorAddressBlock) {
    String caFull = new StringBuilder(contractorAddressPrefectures).append(
        contractorAddressMunicipality).toString();
    // 字名・丁目、番地・号がNULLまたは空文字でない場合
    if (StringUtils.isNotEmpty(contractorAddressBlock)
        && StringUtils.isNotEmpty(contractorAddressSection)) {

      caFull = new StringBuilder(caFull).append(contractorAddressSection)
          .append(ECISKJConstants.STRING_BUILDER_ZENKAKU_SPACE)
          .append(contractorAddressBlock).toString();

      return caFull;
    }
    // 字名・丁目がNULLまたは空文字でない場合
    if (StringUtils.isNotEmpty(contractorAddressSection)) {

      caFull = new StringBuilder(caFull).append(
          StringUtils.defaultString(contractorAddressSection))
          .toString();

    }
    // 番地・号がNULLまたは空文字でない場合
    if (StringUtils.isNotEmpty(contractorAddressBlock)) {

      caFull = new StringBuilder(caFull)
          .append(ECISKJConstants.STRING_BUILDER_ZENKAKU_SPACE)
          .append(StringUtils.defaultString(contractorAddressBlock))
          .toString();

    }
    return caFull;
  }

  /**
   * 更新用契約者住所を生成
   *
   * @param contractorAddressPrefectures
   *          都道府県名
   * @param contractorAddressMunicipality
   *          市区郡町村名
   * @param newContractorAddressSection
   *          更新前字名・丁目
   * @param newContractorAddressBlock
   *          更新前番地・号
   * @param oldContractorAddressSection
   *          更新後字名・丁目
   * @param oldContractorAddressBlock
   *          更新後番地・号
   *
   */
  private String updateCaFullStrBuilder(String contractorAddressPrefectures,
      String contractorAddressMunicipality,
      String newContractorAddressSection,
      String newContractorAddressBlock,
      String oldContractorAddressSection, String oldContractorAddressBlock) {

    String caFull = new StringBuilder(contractorAddressPrefectures).append(
        contractorAddressMunicipality).toString();

    // 字名・丁目に更新前字名・丁目を設定
    String contractorAddressSection = oldContractorAddressSection;
    // 番地・号に更新前番地・号を設定
    String contractorAddressBlock = oldContractorAddressBlock;

    // 更新後字名・丁目に入力がある場合
    if (null != newContractorAddressSection) {
      // 字名・丁目に更新後字名・丁目を設定
      contractorAddressSection = newContractorAddressSection;
    }
    // 更新後番地・号に入力がある場合
    if (null != newContractorAddressBlock) {
      // 番地・号に更新後番地・号を設定
      contractorAddressBlock = newContractorAddressBlock;
    }

    // 字名・丁目、番地・号がNULLまたは空文字でない場合
    if (StringUtils.isNotEmpty(contractorAddressSection)
        && StringUtils.isNotEmpty(contractorAddressBlock)) {

      caFull = new StringBuilder(caFull).append(contractorAddressSection)
          .append(ECISKJConstants.STRING_BUILDER_ZENKAKU_SPACE)
          .append(contractorAddressBlock).toString();

      return caFull;
    }
    // 字名・丁目がNULLまたは空文字でない場合
    if (StringUtils.isNotEmpty(contractorAddressSection)) {

      caFull = new StringBuilder(caFull).append(contractorAddressSection)
          .toString();

    }
    // 番地・号がNULLまたは空文字でない場合
    if (StringUtils.isNotEmpty(contractorAddressBlock)) {

      caFull = new StringBuilder(caFull)
          .append(ECISKJConstants.STRING_BUILDER_ZENKAKU_SPACE)
          .append(contractorAddressBlock).toString();

    }
    return caFull;
  }

  /**
   * 契約者電話番号区分コードの存在チェック
   *
   * @param contractorPhoneCategoryCode
   *          契約者電話番号区分コード
   *
   */
  private Boolean contractorPhoneCategoryCodeCheck(
      String contractorPhoneCategoryCode) {
    // 契約者電話番号区分コードがNULLまたは空文字でない場合かつ返却値が0件の場合
    if (StringUtils.isNotEmpty(contractorPhoneCategoryCode)
        && phoneNoCatMMapper
            .selectByPrimaryKey(contractorPhoneCategoryCode) == null) {

      return true;
    }
    return false;

  }

  /**
   * 契約者情報共通マッパーのセッター(DI)
   *
   * @param contractorInformationCommonMapper
   *          契約者情報共通マッパー
   *
   */
  public void setContractorInformationCommonMapper(
      ContractorInformationCommonMapper contractorInformationCommonMapper) {
    this.contractorInformationCommonMapper = contractorInformationCommonMapper;
  }

  /**
   * 電話番号区分マッパーのセッター(DI)
   *
   * @param phoneNoCategoryMasterMapper
   *          電話番号区分マッパー
   *
   */
  public void setPhoneNoCategoryMasterMapper(
      PhoneNoCatMMapper phoneNoCategoryMasterMapper) {
    this.phoneNoCatMMapper = phoneNoCategoryMasterMapper;
  }

  /**
   * マスタ情報マッパーのセッター(DI)
   *
   * @param masterInformationBusiness
   *          マスタ情報マッパー
   *
   */
  public void setKjMasterInformationBusiness(
      KJ_MasterInformationBusiness masterInformationBusiness) {
    this.kjMasterInformationBusiness = masterInformationBusiness;
  }

  /**
   * 個人法人マスタマッパーのセッター(DI)
   *
   * @param individualLegalEntityCategoryMasterMapper
   *          個人法人マスタマッパー
   *
   */
  public void setIndividualLegalEntityCategoryMasterMapper(
      IlcMMapper individualLegalEntityCategoryMasterMapper) {
    this.ilcMMapper = individualLegalEntityCategoryMasterMapper;
  }

  /**
   * 契約者情報マッパーのセッター(DI)
   *
   * @param contractorMapper
   *          契約者情報マッパー
   *
   */
  public void setContractorMapper(ContractorMapper contractorMapper) {
    this.contractorMapper = contractorMapper;
  }

  /**
   * 提供モデルマスタマッパーのセッター(DI)
   *
   * @param provideModelMasterMapper
   *          提供モデルマスタマッパー
   *
   */
  public void setProvideModelMasterMapper(PmMMapper provideModelMasterMapper) {
    this.pmMMapper = provideModelMasterMapper;
  }

  /**
   * 提供モデル企業マスタマッパーのセッター(DI)
   *
   * @param provideModelCompanyMasterMapper
   *          提供モデル企業マスタマッパー
   *
   */
  public void setProvideModelCompanyMasterMapper(
      PmCompanyMMapper provideModelCompanyMasterMapper) {
    this.pmCompanyMMapper = provideModelCompanyMasterMapper;
  }

  /**
   * 支払マッパーのセッター(DI)
   *
   * @param paymentMapper
   *          支払マッパー
   *
   */
  public void setPaymentMapper(PaymentMapper paymentMapper) {
    this.paymentMapper = paymentMapper;
  }

  /**
   * 日付関連共通ビジネスインタフェースのセッター(DI)
   *
   * @param dateBusiness
   *          日付関連共通ビジネス
   *
   */
  public void setDateBusiness(DateBusiness dateBusiness) {
    this.dateBusiness = dateBusiness;
  }

  /**
   * 契約情報ビジネスのセッター(DI)
   *
   * @param kjContractInformationBusiness
   *          契約情報ビジネス
   *
   */
  public void setKjContractInformationBusiness(
      KJ_ContractInformationBusiness kjContractInformationBusiness) {
    this.kjContractInformationBusiness = kjContractInformationBusiness;
  }

  /**
   * messageSourceのセッター(DI)
   *
   * @param messageSource
   *          メッセージソース
   *
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }

  /**
   * 契約管理情報ファイルヘッダーバリデーターのセッター(DI)
   *
   * @param contractManagementInformationFileHeaderValidator
   *          契約管理情報ファイルヘッダーバリデーター
   *
   */
  public void setContractManagementInformationFileHeaderValidator(
      ContractManagementInformationFileHeaderValidator contractManagementInformationFileHeaderValidator) {
    this.contractManagementInformationFileHeaderValidator = contractManagementInformationFileHeaderValidator;
  }

  /**
   * 契約者情報ファイル登録バリデーターのセッター(DI)
   *
   * @param contractorInformationFileRegistValidator
   *          契約者情報ファイル登録バリデーター
   *
   */
  public void setContractorInformationFileRegistValidator(
      ContractorInformationFileRegistValidator contractorInformationFileRegistValidator) {
    this.contractorInformationFileRegistValidator = contractorInformationFileRegistValidator;
  }

  /**
   * 契約者情報ファイル登録バリデーターのセッター(DI) （カスタム）
   * 
   * @param contractorInformationFileRegistValidator
   *          契約者情報ファイル登録バリデーター
   *
   */
  public void setCustomContractorInformationFileRegistValidator(
      Custom_ContractorInformationFileRegistValidator customContractorInformationFileRegistValidator) {
    this.customContractorInformationFileRegistValidator = customContractorInformationFileRegistValidator;
  }

  /**
   * 契約者情報ファイル更新バリデーターのセッター(DI)
   *
   * @param contractorInformationFileUpdateValidator
   *          契約者情報ファイル更新バリデーター
   *
   */
  public void setContractorInformationFileUpdateValidator(
      ContractorInformationFileUpdateValidator contractorInformationFileUpdateValidator) {
    this.contractorInformationFileUpdateValidator = contractorInformationFileUpdateValidator;
  }

  /**
   * 契約者情報ファイル更新バリデーターのセッター(DI) （カスタム）
   * 
   * @param contractorInformationFileUpdateValidator
   *          契約者情報ファイル更新バリデーター
   *
   */
  public void setCustomContractorInformationFileUpdateValidator(
      Custom_ContractorInformationFileUpdateValidator customContractorInformationFileUpdateValidator) {
    this.customContractorInformationFileUpdateValidator = customContractorInformationFileUpdateValidator;
  }

}
