package jp.co.unisys.enability.cis.business.sn;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Locale;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.config.PropertiesFactoryBean;
import org.springframework.context.MessageSource;

import jp.co.unisys.enability.cis.common.Exception.SystemException;
import jp.co.unisys.enability.cis.common.util.ThreadContext;
import jp.co.unisys.enability.cis.common.util.constants.ECISCodeConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.entity.common.Deposit;
import jp.co.unisys.enability.cis.entity.common.MdReasonM;
import jp.co.unisys.enability.cis.mapper.common.DepositMapper;
import jp.co.unisys.enability.cis.mapper.common.MdReasonMMapper;

/**
 * 請求入金共通本入金ビジネス
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.mapper.common.DepositMapper
 * @see jp.co.unisys.enability.cis.mapper.common.MdReasonMMapper
 */
public class SN0204_FactDepositBusinessImpl implements SN0204_FactDepositBusiness {

  /** プロパティファイル取得キー：勘定科目コード：現預金 */
  private static final String ACCOUNT_ITEM_CODE_CASH_EQUIVALENT_KEY = "account.itemcode.cash.equivalent";

  /** 入金マッパー(DI) */
  private DepositMapper depositMapper;

  /** 手動入金理由マスタマッパー(DI) */
  private MdReasonMMapper mdReasonMMapper;

  /** プロパティ定義クラス(DI) */
  private PropertiesFactoryBean applicationProperties;

  /** メッセージプロパティ(DI) */
  private MessageSource messageSource;

  /*
   * (非 Javadoc)
   * @see jp.co.unisys.enability.cis.business.sn.SN0204_FactDepositBusiness#
   * updateDeposit(java.lang.Integer, java.util.Date, java.util.Date, java.util.Date, java.lang.String)
   */
  @Override
  public void updateDeposit(Integer depositId, Date recordedDate, Date batchBaseDate,
      Date depositDate, String manuallyDepositReasonCode) {

    // 入金科目コード
    String depositIc = null;

    // 引数.手動入金理由コードが設定されている場合
    if (manuallyDepositReasonCode != null) {

      // 手動入金理由マスタSELECT（手動入金理由マスタマッパー.selectByPrimaryKey呼び出し）
      MdReasonM mdReasonM = mdReasonMMapper.selectByPrimaryKey(manuallyDepositReasonCode);

      // 手動入金理由マスタが取得できなかった場合は、システム例外をスロー
      if (mdReasonM == null) {
        throw new SystemException(messageSource.getMessage(
            "error.E1424",
            new String[] {manuallyDepositReasonCode },
            Locale.getDefault()));
      }

      // 入金科目コード設定（手動入金理由マスタ．割当勘定科目コード）
      depositIc = mdReasonM.getAaIc();

      // 引数.手動入金理由コードが設定されていない場合
    } else {

      try {
        // 入金科目コード設定（プロパティ．勘定科目コード：現預金））
        Properties prop = applicationProperties.getObject();
        depositIc = prop.getProperty(ACCOUNT_ITEM_CODE_CASH_EQUIVALENT_KEY);

      } catch (IOException e) {
        // プロパティファイルの読み込みに失敗した場合、以下のメッセージを設定し、システム例外をスローする。
        throw new SystemException(messageSource.getMessage("error.E1278", null, Locale.getDefault()), e);
      }

      if (StringUtils.isEmpty(depositIc)) {
        // プロパティファイルの読み込みに失敗した場合、以下のメッセージを設定し、システム例外をスローする。
        throw new SystemException(messageSource.getMessage("error.E1278", null, Locale.getDefault()));
      }
    }

    // 作成日時、更新日時
    Timestamp wTimestamp = new Timestamp(System.currentTimeMillis());

    // 《入金EntityBean》生成
    Deposit deposit = new Deposit();

    // 入金ID
    deposit.setDepositId(depositId);
    // 入金計上日
    deposit.setDrDate(recordedDate);
    // 入金計上基準日
    deposit.setDrBaseDate(depositDate);
    // 入金計上処理日
    deposit.setDrExecuteDate(batchBaseDate);
    // 入金科目コード（本入金）
    deposit.setDepositIc(depositIc);
    // 入金ステータスコード
    deposit.setDepositStatusCode(ECISCodeConstants.DEPOSIT_STATUS_CODE_FACT_DEPOSIT);
    // 完了フラグ
    deposit.setCompletedFlag(ECISConstants.FLG_ON);
    // 更新日時
    deposit.setUpdateTime(wTimestamp);
    // 更新モジュールコード
    deposit.setUpdateModuleCode(
        ThreadContext.getRequestThreadContext().get(ECISConstants.CLASS_NAME_KEY).toString());

    // 入金UPDATE（入金Dao.選択項目更新（主キー）呼び出し）
    depositMapper.updateByPrimaryKeySelective(deposit);
  }

  /**
   * 入金マッパーを設定する。(DI)
   *
   * @param depositMapper
   *          入金マッパー
   */
  public void setDepositMapper(
      DepositMapper depositMapper) {
    this.depositMapper = depositMapper;
  }

  /**
   * 手動入金理由マスタマッパーを設定する。(DI)
   *
   * @param mdReasonMMapper
   *          入金マッパー
   */
  public void setMdReasonMMapper(
      MdReasonMMapper mdReasonMMapper) {
    this.mdReasonMMapper = mdReasonMMapper;
  }

  /**
   * プロパティ定義クラスを設定する。(DI)
   *
   * @param applicationProperties
   */
  public void setApplicationProperties(
      PropertiesFactoryBean applicationProperties) {
    this.applicationProperties = applicationProperties;
  }

  /**
   * メッセージプロパティを設定する。(DI)
   *
   * @param messageSource
   */
  public void setMessageSource(
      MessageSource messageSource) {
    this.messageSource = messageSource;
  }
}
