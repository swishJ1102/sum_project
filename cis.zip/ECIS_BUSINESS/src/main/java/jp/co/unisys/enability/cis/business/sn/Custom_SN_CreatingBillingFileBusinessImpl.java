package jp.co.unisys.enability.cis.business.sn;

import java.io.File;
import java.io.IOException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.TreeMap;

import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.config.PropertiesFactoryBean;
import org.springframework.context.MessageSource;

import jp.co.unisys.enability.cis.business.gk.GK_WorkCommonBusiness;
import jp.co.unisys.enability.cis.business.gk.model.GK_RegistDownloadManageBusinessBean;
import jp.co.unisys.enability.cis.common.Exception.BusinessLogicException;
import jp.co.unisys.enability.cis.common.Exception.SystemException;
import jp.co.unisys.enability.cis.common.util.StringConvertUtil;
import jp.co.unisys.enability.cis.common.util.constants.ECISCodeConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISFunctionIdConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISSNConstants;
import jp.co.unisys.enability.cis.entity.common.Bl;
import jp.co.unisys.enability.cis.entity.common.BlExample;
import jp.co.unisys.enability.cis.entity.common.CContract;
import jp.co.unisys.enability.cis.entity.common.CContractor;
import jp.co.unisys.enability.cis.entity.common.CPaymentHist;
import jp.co.unisys.enability.cis.entity.common.CPaymentHistExample;
import jp.co.unisys.enability.cis.entity.common.Contract;
import jp.co.unisys.enability.cis.entity.common.ContractAddInfo;
import jp.co.unisys.enability.cis.entity.common.ContractExample;
import jp.co.unisys.enability.cis.entity.common.ContractHist;
import jp.co.unisys.enability.cis.entity.common.ContractHistExample;
import jp.co.unisys.enability.cis.entity.common.Contractor;
import jp.co.unisys.enability.cis.entity.common.ContractorAddInfo;
import jp.co.unisys.enability.cis.entity.common.ContractorExample;
import jp.co.unisys.enability.cis.entity.common.DsUsage;
import jp.co.unisys.enability.cis.entity.common.DsUsageExample;
import jp.co.unisys.enability.cis.entity.common.Fcr;
import jp.co.unisys.enability.cis.entity.common.FcrBreakdown;
import jp.co.unisys.enability.cis.entity.common.FcrBreakdownExample;
import jp.co.unisys.enability.cis.entity.common.FcrExample;
import jp.co.unisys.enability.cis.entity.common.FixIn;
import jp.co.unisys.enability.cis.entity.common.FixInExample;
import jp.co.unisys.enability.cis.entity.common.Fu;
import jp.co.unisys.enability.cis.entity.common.Payment;
import jp.co.unisys.enability.cis.entity.common.PaymentHist;
import jp.co.unisys.enability.cis.entity.common.PaymentHistExample;
import jp.co.unisys.enability.cis.entity.common.ReserveContractHist;
import jp.co.unisys.enability.cis.entity.common.RestrictionDiscountInfo;
import jp.co.unisys.enability.cis.entity.common.RestrictionDiscountInfoExample;
import jp.co.unisys.enability.cis.entity.common.Rqh;
import jp.co.unisys.enability.cis.entity.common.RqhExample;
import jp.co.unisys.enability.cis.entity.common.TsUsage;
import jp.co.unisys.enability.cis.entity.common.TsUsageExample;
import jp.co.unisys.enability.cis.mapper.common.BlMapper;
import jp.co.unisys.enability.cis.mapper.common.CContractMapper;
import jp.co.unisys.enability.cis.mapper.common.CContractorMapper;
import jp.co.unisys.enability.cis.mapper.common.CPaymentHistMapper;
import jp.co.unisys.enability.cis.mapper.common.ContractAddInfoMapper;
import jp.co.unisys.enability.cis.mapper.common.ContractHistMapper;
import jp.co.unisys.enability.cis.mapper.common.ContractMapper;
import jp.co.unisys.enability.cis.mapper.common.ContractorAddInfoMapper;
import jp.co.unisys.enability.cis.mapper.common.ContractorMapper;
import jp.co.unisys.enability.cis.mapper.common.DsUsageMapper;
import jp.co.unisys.enability.cis.mapper.common.FcrBreakdownMapper;
import jp.co.unisys.enability.cis.mapper.common.FcrMapper;
import jp.co.unisys.enability.cis.mapper.common.FixInMapper;
import jp.co.unisys.enability.cis.mapper.common.FuMapper;
import jp.co.unisys.enability.cis.mapper.common.PaymentHistMapper;
import jp.co.unisys.enability.cis.mapper.common.PaymentMapper;
import jp.co.unisys.enability.cis.mapper.common.RestrictionDiscountInfoMapper;
import jp.co.unisys.enability.cis.mapper.common.RqhMapper;
import jp.co.unisys.enability.cis.mapper.common.TsUsageMapper;
import jp.co.unisys.enability.cis.mapper.sn.Custom_SN_CreatingBillingFileMapper;
import jp.sf.orangesignal.csv.Csv;
import jp.sf.orangesignal.csv.CsvConfig;
import jp.sf.orangesignal.csv.QuotePolicy;
import jp.sf.orangesignal.csv.handlers.StringArrayListHandler;

/**
 * 請求情報作成ビジネス_カスタム。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class Custom_SN_CreatingBillingFileBusinessImpl implements
    Custom_SN_CreatingBillingFileBusiness {
  /** ロガー */
  private static final Logger LOGGER = LogManager.getLogger();
  /**
   * 請求Mapper(DI)
   */
  private BlMapper blMapper;

  /**
   * 契約者Mapper(DI)
   */
  private ContractorMapper contractorMapper;

  /**
   * カスタム契約者Mapper(DI)
   */
  private CContractorMapper cContractorMapper;

  /**
   * 契約者付加情報Mapper(DI)
   */
  private ContractorAddInfoMapper contractorAddInfoMapper;

  /**
   * 支払Mapper(DI)
   */
  private PaymentMapper paymentMapper;

  /**
   * 支払履歴Mapper(DI)
   */
  private PaymentHistMapper paymentHistMapper;

  /**
   * カスタム支払履歴Mapper(DI)
   */
  private CPaymentHistMapper cPaymentHistMapper;

  /**
   * 契約Mapper(DI)
   */
  private ContractMapper contractMapper;

  /**
   * カスタム契約Mapper(DI)
   */
  private CContractMapper cContractMapper;

  /**
   * 契約付加情報Mapper(DI)
   */
  private ContractAddInfoMapper contractAddInfoMapper;

  /**
   * 契約履歴Mapper(DI)
   */
  private ContractHistMapper contractHistMapper;

  /**
   * 確定料金実績Mapper(DI)
   */
  private FcrMapper fcrMapper;

  /**
   * 確定料金実績内訳Mapper(DI)
   */
  private FcrBreakdownMapper fcrBreakdownMapper;

  /**
   * 実量歴管理Mapper(DI)
   */
  private RqhMapper rqhMapper;

  /**
   * 確定使用量Mapper(DI)
   */
  private FuMapper fuMapper;

  /**
   * 確定指示数Mapper(DI)
   */
  private FixInMapper fixInMapper;

  /**
   * 時間帯別使用量Mapper(DI)
   */
  private TsUsageMapper tsUsageMapper;

  /**
   * 日割別使用量Mapper(DI)
   */
  private DsUsageMapper dsUsageMapper;

  /**
   * 制限中止割引情報Mapper(DI)
   */
  private RestrictionDiscountInfoMapper restrictionDiscountInfoMapper;

  /**
   * 請求情報作成Mapper(DI)
   */
  private Custom_SN_CreatingBillingFileMapper customSnCreatingBillingFileMapper;

  /**
   * 業務共通ビジネス(DI)
   */
  private GK_WorkCommonBusiness gkWorkCommonBusiness;

  /**
   * プロパティ(DI)
   */
  private PropertiesFactoryBean applicationProperties;

  /**
   * メッセージプロパティ(DI)
   */
  private MessageSource messageSource;

  /**
   * 001(請求)
   */
  private static final String STR_BILLINGDATARECORD_CODE = "001";

  /**
   * 002(契約者)
   */
  private static final String STR_CONTRACTORDATARECORD_CODE = "002";

  /**
   * 003(支払)
   */
  private static final String STR_PAYMENTDATARECORD_CODE = "003";

  /**
   * 004(支払履歴)
   */
  private static final String STR_PAYMENTHISTDATARECORD_CODE = "004";

  /**
   * 005(契約)
   */
  private static final String STR_CONTRACTDATARECORD_CODE = "005";

  /**
   * 006(契約履歴)
   */
  private static final String STR_CONTRACTHISTDATARECORD_CODE = "006";

  /**
   * 007(確定料金実績)
   */
  private static final String STR_FCRDATARECORD_CODE = "007";

  /**
   * 008(確定料金実績内訳)
   */
  private static final String STR_FCRBREAKDOWNDATARECORD_CODE = "008";

  /**
   * 009(実量歴管理)
   */
  private static final String STR_RQHDATARECORD_CODE = "009";

  /**
   * 010(確定使用量)
   */
  private static final String STR_FUDATARECORD_CODE = "010";

  /**
   * 011(確定指示数)
   */
  private static final String STR_FIXINDATARECORD_CODE = "011";

  /**
   * 012(時間帯別使用量)
   */
  private static final String STR_TSUSAGEDATARECORD_CODE = "012";

  /**
   * 013(日割別使用量)
   */
  private static final String STR_DSUSAGEDATARECORD_CODE = "013";

  /**
   * 014(予備契約履歴)
   */
  private static final String STR_RESERVECONTRACTHISTDATARECORD_CODE = "014";

  /**
   * 015(制限中止割引情報)
   */
  private static final String STR_RESTRICTIONDISCOUNTINFODATARECORD_CODE = "015";

  /**
   * 年月計算用(-11)
   */
  private static final int DIFF_MONTH = -11;

  /**
   * 時間帯別使用量設定：時間帯別使用量取得_ソート条件
   */
  private static final String TSUSAGE_ORDER_BY_CLAUSE = "ds_sd ASC, ts_code ASC";

  /**
   * 日割別使用量：日割別使用量取得_ソート条件
   */
  private static final String DSUSAGE_ORDER_BY_CLAUSE = "ds_sd ASC";

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.sn.SN_CreatingBillingFileBusiness
   * #creatingBillingFile(java.util.Date)
   */
  @Override
  public void creatingBillingFile(Date batchDate)
      throws BusinessLogicException {
    // バッチ実行日が設定されていない場合、システム例外
    if (batchDate == null) {
      throw new SystemException(messageSource.getMessage("error.E1411",
          null, Locale.getDefault()));
    }
    LOGGER.info("処理を開始します。処理対象日:{}", batchDate);
    // 《請求Example》の設定
    BlExample blExample = new BlExample();

    // 請求作成日を設定する。
    blExample.createCriteria().andBlCreateDateEqualTo(batchDate);
    blExample.setOrderByClause(ECISSNConstants.BSN010801_BL_ORDER_BY_CLAUSE);

    // 《請求マッパー》.検索（項目指定）を呼び出し、≪請求エンティティリスト≫を取得する。
    List<Bl> blList = blMapper.selectByExample(blExample);

    // 取得結果が0件の場合、処理終了
    if (CollectionUtils.isEmpty(blList)) {
      return;
    }

    // プロパティ取得
    Properties prop;
    try {
      prop = applicationProperties.getObject();
    } catch (IOException ioe) {
      throw new SystemException(messageSource.getMessage("error.E1129",
          null, Locale.getDefault()), ioe);
    }

    // ファイル出力先ディレクトリ作成
    String outputBaseDir = prop
        .getProperty("custom.batch.sn.billingfile.output.dir");
    String batchDateStr = StringConvertUtil.convertDateToString(batchDate,
        ECISConstants.FORMAT_DATE_yyyyMMdd);

    // 出力先パス設定
    String outputFolderPath = new StringBuilder().append(outputBaseDir)
        .append(batchDateStr).append(ECISConstants.SLASH).toString();

    File outputDir = new File(outputFolderPath);
    // ディレクトリが存在しない場合、再帰作成
    // 再帰作成に失敗した場合、排他エラーで業務例外
    if (!outputDir.exists() && !outputDir.mkdirs()) {
      throw new BusinessLogicException(messageSource.getMessage(
          "error.E0039", null, Locale.getDefault()), false);
    }

    // 請求情報データ作成
    Map<String, List<String[]>> csvDataListMap = new TreeMap<String, List<String[]>>();
    this.createBillingDataRecordList(blList, csvDataListMap, batchDate);

    // CSVファイル作成
    for (Map.Entry<String, List<String[]>> entry : csvDataListMap
        .entrySet()) {
      this.saveCSV(batchDate, batchDateStr, prop, outputFolderPath,
          entry.getKey(), entry.getValue());
    }
  }

  /**
   * 請求情報データ作成
   *
   * @param billingDataList
   * @param csvDataListMap
   * @param batchDate
   */
  private void createBillingDataRecordList(List<Bl> billingDataList,
      Map<String, List<String[]>> csvDataListMap, Date batchDate) {
    // 請求情報データ作成
    for (Bl bl : billingDataList) {
      List<String[]> billingDataRecordList = new ArrayList<String[]>();

      // 《請求》レコード生成。
      billingDataRecordList.add(this.createBillingDataRecord(bl));

      Boolean isAgent = false;
      // 《請求エンティティ》.契約者IDが空白またはnullの場合
      if (bl.getContractorId() == null) {
        // 卸取次ぎフラグにtrueを設定する。
        isAgent = true;
      } else {
        // 上記以外の場合
        // 卸取次ぎフラグにfalseを設定する。
        isAgent = false;
      }

      // 《請求情報作成マッパー》から契約者IDを取得する。
      // 引数： 《請求エンティティ》.請求番号
      List<Integer> contractorIdList = customSnCreatingBillingFileMapper
          .selectContractorList(bl.getBlNo());

      // 《契約者Example》の設定
      ContractorExample contractorExample = new ContractorExample();
      contractorExample.createCriteria().andContractorIdIn(
          contractorIdList);
      contractorExample
          .setOrderByClause(ECISSNConstants.BSN010801_CONTRACTOR_ORDER_BY_CLAUSE);

      // 契約者リストを取得する。
      List<Contractor> contractorList = contractorMapper
          .selectByExample(contractorExample);

      // 提供モデル企業コード
      String strPmCompanyCode = contractorList.get(0).getPmCompanyCode();
      for (Contractor contractor : contractorList) {

        // カスタム契約者を取得する。
        CContractor cContractor = cContractorMapper.selectByPrimaryKey(contractor.getContractorId());

        // 契約者付加情報を取得する。
        ContractorAddInfo contractorAddInfo = contractorAddInfoMapper
            .selectByPrimaryKey(contractor.getContractorId());

        billingDataRecordList.add(this
            .createContractorDataRecord(contractor, cContractor, contractorAddInfo));
      }

      // 卸取次ぎフラグがfalseの場合、以下の処理を行う。
      if (!isAgent) {
        // 《支払》レコード生成。
        Payment payment = paymentMapper.selectByPrimaryKey(bl
            .getPaymentId());
        if (payment != null) {
          // 《支払》レコード生成。
          billingDataRecordList
              .add(this.createPaymentDataRecord(payment));
        }

        // 《支払履歴Example》の設定
        PaymentHistExample paymentHistExample = new PaymentHistExample();
        paymentHistExample.createCriteria()
            .andPaymentIdEqualTo(bl.getPaymentId())
            .andPaymentSdLessThanOrEqualTo(batchDate)
            .andPaymentEdGreaterThanOrEqualTo(batchDate);

        List<PaymentHist> paymentHistList = paymentHistMapper
            .selectByExample(paymentHistExample);
        for (PaymentHist paymentHist : paymentHistList) {

          // 《カスタム支払履歴Example》の設定
          CPaymentHistExample cPaymentHistExample = new CPaymentHistExample();
          cPaymentHistExample.createCriteria()
              .andPaymentIdEqualTo(bl.getPaymentId())
              .andPaymentSdEqualTo(paymentHist.getPaymentSd());

          List<CPaymentHist> cPaymentHistList = cPaymentHistMapper
              .selectByExample(cPaymentHistExample);

          CPaymentHist cPaymentHist = (cPaymentHistList.size() > 0 ? cPaymentHistList.get(0) : null);

          // 《支払履歴》レコード生成。
          billingDataRecordList.add(this
              .createPaymentHistDataRecord(paymentHist, cPaymentHist));
        }

      }

      // 《確定料金実績Example》の設定
      FcrExample fcrExample = new FcrExample();
      fcrExample.createCriteria().andBlNoEqualTo(bl.getBlNo());
      fcrExample
          .setOrderByClause(ECISSNConstants.BSN010801_FCR_ORDER_BY_CLAUSE);

      // 《確定料金実績》レコード生成。
      List<Fcr> fcrList = fcrMapper.selectByExample(fcrExample);
      for (Fcr fcr : fcrList) {

        if (fcr.getCcSd() != null) {
          // 《契約》の設定
          ContractExample contractExample = new ContractExample();
          // 契約期間に関する抽出条件：算定開始日が契約期間に含まれる
          contractExample.createCriteria().andContractIdEqualTo(fcr.getContractId())
              .andContractSdLessThanOrEqualTo(fcr.getCcSd())
              .andContractEdGreaterThanOrEqualTo(fcr.getCcSd());

          List<Contract> contractList = contractMapper
              .selectByExample(contractExample);

          for (Contract contract : contractList) {

            // 《契約付加情報》の設定
            ContractAddInfo contractAddInfo = contractAddInfoMapper
                .selectByPrimaryKey(contract.getContractId());

            // 《カスタム契約》の設定
            CContract cContract = cContractMapper.selectByPrimaryKey(contract.getContractId());

            // 《契約履歴》の設定
            ContractHistExample contractHistExample = new ContractHistExample();
            // 適用期間に関する抽出条件：算定開始日が適用期間に含まれる
            contractHistExample.createCriteria().andContractIdEqualTo(fcr.getContractId())
                .andApplySdLessThanOrEqualTo(fcr.getCcSd())
                .andApplyEdGreaterThanOrEqualTo(fcr.getCcSd());

            List<ContractHist> contractHistList = contractHistMapper
                .selectByExample(contractHistExample);

            // 《契約》レコード生成。
            billingDataRecordList.add(this
                .createContractDataRecord(contract, contractAddInfo, cContract,
                    contractHistList.get(contractHistList.size() - 1).getVoltageCatCode()));

            for (ContractHist contractHist : contractHistList) {
              billingDataRecordList.add(this.createContractHistDataRecord(contractHist));
            }
          }
        }

        // 《確定料金実績》レコード生成。
        billingDataRecordList.add(this.createFcrDataRecord(fcr));

        // 《確定料金実績内訳Example》の設定
        FcrBreakdownExample fcrBreakdownExample = new FcrBreakdownExample();
        fcrBreakdownExample.createCriteria().andFcrIdEqualTo(
            fcr.getFcrId());
        fcrBreakdownExample
            .setOrderByClause(ECISSNConstants.BSN010801_FCRBREAKDOWN_ORDER_BY_CLAUSE);

        // 《確定料金実績内訳》レコード生成。
        List<FcrBreakdown> fcrBreakdownList = fcrBreakdownMapper
            .selectByExample(fcrBreakdownExample);
        for (FcrBreakdown fcrBreakdown : fcrBreakdownList) {
          billingDataRecordList.add(this
              .createFcrBreakdownDataRecord(fcrBreakdown));
        }

        // 《実量歴管理Example》の設定
        RqhExample rqhExample = new RqhExample();
        rqhExample
            .createCriteria()
            .andContractIdEqualTo(fcr.getContractId())
            .andCoveredPeriodGreaterThanOrEqualTo(
                StringConvertUtil.calcMonthNoException(
                    fcr.getUsePeriod(), DIFF_MONTH,
                    ECISConstants.FORMAT_DATE_yyyyMM))
            .andCoveredPeriodLessThanOrEqualTo(fcr.getUsePeriod());
        rqhExample
            .setOrderByClause(ECISSNConstants.BSN010801_RQH_ORDER_BY_CLAUSE);

        // 《実量歴管理》レコード生成。
        List<Rqh> rqhList = rqhMapper.selectByExample(rqhExample);
        for (Rqh rqh : rqhList) {
          billingDataRecordList.add(this.createRqhDataRecord(rqh));
        }

        // 《確定使用量》レコード生成。
        Fu fu = fuMapper.selectByPrimaryKey(fcr.getFuId());
        if (fu != null) {
          billingDataRecordList.add(this.createFuDataRecord(fu));
        }

        // 《確定指示数Example》の設定
        FixInExample fixInExample = new FixInExample();
        fixInExample.createCriteria().andFuIdEqualTo(fcr.getFuId());
        fixInExample
            .setOrderByClause(ECISSNConstants.BSN010801_FIXIN_ORDER_BY_CLAUSE);

        // 《確定指示数》レコード生成。
        List<FixIn> fixInList = fixInMapper
            .selectByExample(fixInExample);
        for (FixIn fixIn : fixInList) {
          billingDataRecordList
              .add(this.createFixInDataRecord(fixIn));
        }

        if (fcr.getCcSd() != null && fcr.getCcEd() != null) {
          // 《時間帯別使用量Example》の設定
          TsUsageExample tsUsageExample = new TsUsageExample();
          tsUsageExample.createCriteria().andFuIdEqualTo(fcr.getFuId())
              .andDsSdGreaterThanOrEqualTo(fcr.getCcSd())
              .andDsSdLessThanOrEqualTo(fcr.getCcEd());
          tsUsageExample
              .setOrderByClause(TSUSAGE_ORDER_BY_CLAUSE);

          // 《時間帯別使用量》レコード生成。
          List<TsUsage> tsUsageList = tsUsageMapper
              .selectByExample(tsUsageExample);
          for (TsUsage tsUsage : tsUsageList) {
            billingDataRecordList.add(this
                .createTsUsageDataRecord(tsUsage));
          }

          // 《日割別使用量Example》の設定
          DsUsageExample dsUsageExample = new DsUsageExample();
          dsUsageExample.createCriteria().andFuIdEqualTo(fcr.getFuId())
              .andDsSdGreaterThanOrEqualTo(fcr.getCcSd())
              .andDsSdLessThanOrEqualTo(fcr.getCcEd());
          dsUsageExample
              .setOrderByClause(DSUSAGE_ORDER_BY_CLAUSE);

          // 《日割別使用量》レコード生成。
          List<DsUsage> dsUsageList = dsUsageMapper
              .selectByExample(dsUsageExample);
          if (dsUsageList != null) {
            for (DsUsage dsUsage : dsUsageList) {
              billingDataRecordList.add(this
                  .createDsUsageDataRecord(dsUsage));
            }
          }
        }

        // 《請求情報作成マッパー》から《予備契約履歴エンティティリスト》リストを取得する。
        Map<String, Object> mapReserveContractHist = new LinkedHashMap<String, Object>();
        mapReserveContractHist.put("contractId", fcr.getContractId());
        mapReserveContractHist.put("ccSd", fcr.getCcSd());
        mapReserveContractHist.put("ccEd", fcr.getCcEd());
        List<ReserveContractHist> reserveContractHistList = customSnCreatingBillingFileMapper
            .selectReserveContractHistList(mapReserveContractHist);

        // 《予備契約履歴》レコード生成。
        if (reserveContractHistList != null) {
          for (ReserveContractHist reserveContractHist : reserveContractHistList) {
            billingDataRecordList.add(this
                .createReserveContractHistDataRecord(reserveContractHist));
          }
        }

        for (FcrBreakdown fcrBreakdown : fcrBreakdownList) {
          if (fcrBreakdown.getRestrictionDiscountInfoId() != null) {
            // 《制限中止割引情報Example》の設定
            RestrictionDiscountInfoExample restrictionDiscountInfoExample = new RestrictionDiscountInfoExample();
            restrictionDiscountInfoExample.createCriteria().andRestrictionDiscountInfoIdEqualTo(
                fcrBreakdown.getRestrictionDiscountInfoId());

            // 《制限中止割引情報》レコード生成。
            List<RestrictionDiscountInfo> restrictionDiscountInfoList = restrictionDiscountInfoMapper
                .selectByExample(restrictionDiscountInfoExample);
            for (RestrictionDiscountInfo restrictionDiscountInfo : restrictionDiscountInfoList) {
              billingDataRecordList.add(this
                  .createRestrictionDiscountInfoDataRecord(restrictionDiscountInfo));
            }
          }
        }
      }

      if (csvDataListMap.containsKey(strPmCompanyCode)) {
        csvDataListMap.get(strPmCompanyCode).addAll(
            billingDataRecordList);
      } else {
        csvDataListMap.put(strPmCompanyCode,
            billingDataRecordList);
      }
    }
  }

  /**
   * 《請求》レコード生成
   *
   * @param snBillingEntityBean
   * @return 《請求》レコード
   */
  private String[] createBillingDataRecord(Bl bl) {
    // 《請求》レコード
    String[] billingDataRecord = {
        STR_BILLINGDATARECORD_CODE,
        this.objToString(bl.getBlId()),
        this.objToString(bl.getBlNo()),
        this.objToString(bl.getContractorId()),
        this.objToString(bl.getContractorNo()),
        this.objToString(bl.getCustomerCode()),
        this.objToString(bl.getPaymentId()),
        this.objToString(bl.getBlCatCode()),
        this.objToString(bl.getPmCode()),
        this.objToString(bl.getPmCompanyCode()),
        this.objToString(bl.getUsePeriod()),
        this.objToString(bl.getBlAmount()),
        this.objToString(bl.getUseAmount()),
        StringConvertUtil.convertDateToString(
            bl.getSettlementScheduledDate(),
            ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
        StringConvertUtil.convertDateToString(bl.getPfd(),
            ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
        this.objToString(bl.getBlStatusCode()),
        this.objToString(bl.getBlSrReasonCode()),
        this.objToString(bl.getAddUpBlFlag()),
        this.objToString(bl.getProcrastinationPfdFlag()),
        StringConvertUtil.convertDateToString(bl.getBlCreateDate(),
            ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
        this.objToString(bl.getMultipleRccFlag()),
        this.objToString(bl.getCombinedBlFlag()),
        this.objToString(bl.getCompletedFlag()),
        this.objToString(bl.getBankCode()),
        this.objToString(bl.getBankName()),
        this.objToString(bl.getBankBranchCode()),
        this.objToString(bl.getBankBranchName()),
        this.objToString(bl.getBtOfAccountCode()),
        this.objToString(bl.getBtOfAccount()),
        this.objToString(bl.getAccountNo()),
        this.objToString(bl.getAccountHolderName()),
        this.objToString(bl.getNote()) };

    return billingDataRecord;
  }

  /**
   * 《契約者》レコード生成
   *
   * @param contractor
   * @param contractorAddInfo
   * @param cContractor
   * @return 《契約者》レコード
   */
  private String[] createContractorDataRecord(Contractor contractor, CContractor cContractor,
      ContractorAddInfo contractorAddInfo) {
    // 《契約者》レコード
    String[] contractorDataRecord = {
        STR_CONTRACTORDATARECORD_CODE,
        this.objToString(contractor.getContractorId()),
        this.objToString(contractor.getContractorNo()),
        this.objToString(contractor.getCn1Kana()),
        this.objToString(contractor.getCn1()),
        this.objToString(contractor.getCn2()),
        this.objToString(contractor.getCn1MailingName()),
        this.objToString(contractor.getCn2MailingName()),
        this.objToString(contractor.getPrefix()),
        this.objToString(contractor.getCaPostalCode()),
        this.objToString(contractor.getCaFull()),
        this.objToString(contractor.getCaBuilding()),
        this.objToString(contractor.getCaPrefectures()),
        this.objToString(contractor.getCaMunicipality()),
        this.objToString(contractor.getCaSection()),
        this.objToString(contractor.getCaBlock()),
        this.objToString(contractor.getCaBuildingName()),
        this.objToString(contractor.getCaRoom()),
        this.objToString(contractor.getCphNo1()),
        this.objToString(contractor.getCphCatCode1()),
        this.objToString(contractor.getCphAreaCode1()),
        this.objToString(contractor.getCphLocalNo1()),
        this.objToString(contractor.getCphDirectoryNo1()),
        this.objToString(contractor.getCphNo2()),
        this.objToString(contractor.getCphCatCode2()),
        this.objToString(contractor.getCphAreaCode2()),
        this.objToString(contractor.getCphLocalNo2()),
        this.objToString(contractor.getCphDirectoryNo2()),
        this.objToString(contractor.getCma1()),
        this.objToString(contractor.getCma2()),
        this.objToString(contractor.getPmCode()),
        this.objToString(contractor.getPmCompanyCode()),
        this.objToString(contractor.getUnavailableFlag()),
        this.objToString(contractor.getCustomerCode()),
        this.objToString(contractor.getUrgeNotCoveredFlag()),
        this.objToString(contractor.getIlcCode()),
        this.objToString(contractor.getVisualizationProvideFlag()),
        this.objToString(contractor.getNote()),
        // カスタム契約者
        this.objToString((cContractor != null ? cContractor.getGasCustomerNo() : null)),
        // 契約者付加情報
        this.objToString((contractorAddInfo != null ? contractorAddInfo.getAgentContractorNo() : null)),
        this.objToString((contractorAddInfo != null ? contractorAddInfo.getFree1() : null)),
        this.objToString((contractorAddInfo != null ? contractorAddInfo.getFree2() : null)),
        this.objToString((contractorAddInfo != null ? contractorAddInfo.getFree3() : null)),
        this.objToString((contractorAddInfo != null ? contractorAddInfo.getFree4() : null)),
        this.objToString((contractorAddInfo != null ? contractorAddInfo.getFree5() : null)),
        this.objToString((contractorAddInfo != null ? contractorAddInfo.getFree6() : null)),
        this.objToString((contractorAddInfo != null ? contractorAddInfo.getFree7() : null)),
        this.objToString((contractorAddInfo != null ? contractorAddInfo.getFree8() : null)),
        this.objToString((contractorAddInfo != null ? contractorAddInfo.getFree9() : null)),
        this.objToString((contractorAddInfo != null ? contractorAddInfo.getFree10() : null)),
    };

    return contractorDataRecord;
  }

  /**
   * 《支払》レコード生成
   *
   * @param payment
   * @return 《支払》レコード
   */
  private String[] createPaymentDataRecord(Payment payment) {
    // 《支払》レコード生成。
    String[] paymentDataRecord = {
        STR_PAYMENTDATARECORD_CODE,
        this.objToString(payment.getPaymentId()),
        this.objToString(payment.getContractorId()),
        this.objToString(payment.getPaymentNo()),
        this.objToString(payment.getDdCreNextMonthBlFlag()),
        this.objToString(payment.getPreviousBlAddUpFlag()),
        this.objToString(payment.getPeIndividualSettingFlag()),
        this.objToString(payment.getPeAddMonths()),
        this.objToString(payment.getPeDate()) };

    return paymentDataRecord;
  }

  /**
   * 《支払履歴》レコード生成
   *
   * @param paymentHist
   * @param cPaymentHist
   * @return 《支払履歴》レコード
   */
  private String[] createPaymentHistDataRecord(PaymentHist paymentHist, CPaymentHist cPaymentHist) {

    // カスタム支払履歴.支払適用開始日
    String paymentSd = (cPaymentHist != null ? StringConvertUtil.convertDateToString(cPaymentHist.getPaymentSd(),
        ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH)
        : null);

    // カスタム支払履歴.外部システム契約番号（ガス需給契約番号）
    String gasSupplyContractNo = (cPaymentHist != null ? this.objToString(cPaymentHist.getGasSupplyContractNo())
        : null);

    // カスタム支払履歴.外部システム支払番号（ガス支払番号）
    String gasPaymentNo = (cPaymentHist != null ? this.objToString(cPaymentHist.getGasPaymentNo()) : null);

    // 《支払履歴》レコード
    String[] paymentHistDataRecord = {
        STR_PAYMENTHISTDATARECORD_CODE,
        this.objToString(paymentHist.getPaymentId()),
        StringConvertUtil.convertDateToString(
            paymentHist.getPaymentSd(),
            ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
        StringConvertUtil.convertDateToString(
            paymentHist.getPaymentEd(),
            ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
        this.objToString(paymentHist.getPwCode()),
        this.objToString(paymentHist.getAccountCreId()),
        this.objToString(paymentHist.getIlcCode()),
        this.objToString(paymentHist.getBlName1()),
        this.objToString(paymentHist.getBlName2()),
        this.objToString(paymentHist.getPrefix()),
        this.objToString(paymentHist.getBlAddressPostalCode()),
        this.objToString(paymentHist.getBlAddressPrefectures()),
        this.objToString(paymentHist.getBlAddressMunicipality()),
        this.objToString(paymentHist.getBlAddressSection()),
        this.objToString(paymentHist.getBlAddressBlock()),
        this.objToString(paymentHist.getBlAddressBuildingName()),
        this.objToString(paymentHist.getBlAddressRoom()),
        this.objToString(paymentHist.getBlPhoneNo()),
        this.objToString(paymentHist.getBlPhoneCatCode()),
        this.objToString(paymentHist.getBlMailAddress1()),
        this.objToString(paymentHist.getBlMailAddress2()),
        this.objToString(paymentHist.getFree1()),
        this.objToString(paymentHist.getFree2()),
        paymentSd,
        gasSupplyContractNo,
        gasPaymentNo
    };

    return paymentHistDataRecord;
  }

  /**
   * 《契約》レコード生成
   *
   * @param contract
   * @param contractAddInfo
   * @param cContract
   * @param voltageCatCode
   * @return 《契約》レコード
   */
  private String[] createContractDataRecord(Contract contract, ContractAddInfo contractAddInfo,
      CContract cContract, String voltageCatCode) {

    String psInfoCatCode = ECISConstants.EMPTY_STRING;

    if (!ECISCodeConstants.CUSTOM_VOLTAGE_CAT_CODE_LOW_TENSION.equals(voltageCatCode)) {
      // 電圧区分コードが低圧以外の場合
      psInfoCatCode = this.objToString(contract.getPsInfoCatCode());
    }

    // 《契約》レコード
    String[] contractDataRecord = {
        STR_CONTRACTDATARECORD_CODE,
        // 契約
        this.objToString(contract.getContractId()),
        this.objToString(contract.getContractorId()),
        this.objToString(contract.getPaymentId()),
        StringConvertUtil.convertDateToString(
            contract.getContractSd(),
            ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
        StringConvertUtil.convertDateToString(
            contract.getContractEd(),
            ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
        this.objToString(contract.getContractNo()),
        this.objToString(contract.getContractEndReasonCode()),
        this.objToString(contract.getChargeCheckFlag()),
        this.objToString(contract.getScCode()),
        this.objToString(contract.getContractGroupNo()),
        this.objToString(contract.getIlcCode()),
        this.objToString(contract.getCiNameKana()),
        this.objToString(contract.getCiName1()),
        this.objToString(contract.getCiName2()),
        this.objToString(contract.getCiAddressPostalCode()),
        this.objToString(contract.getCiAddressFull()),
        this.objToString(contract.getCiAddressBuilding()),
        this.objToString(contract.getCiPhoneNo()),
        this.objToString(contract.getCiCatCode()),
        this.objToString(contract.getCiAreaCode()),
        this.objToString(contract.getCiLocalNo()),
        this.objToString(contract.getCiDirectoryNo()),
        this.objToString(contract.getCcAffiliation()),
        this.objToString(contract.getCcName()),
        this.objToString(contract.getCcPhoneNo()),
        this.objToString(contract.getCcAreaCode()),
        this.objToString(contract.getCcLocalNo()),
        this.objToString(contract.getCcDirectoryNo()),
        this.objToString(contract.getCeoAffiliation()),
        this.objToString(contract.getCeoName()),
        this.objToString(contract.getCeoPhoneNo()),
        this.objToString(contract.getCeoAreaCode()),
        this.objToString(contract.getCeoLocalNo()),
        this.objToString(contract.getCeoDirectoryNo()),
        this.objToString(contract.getBusinessTypeCode()),
        this.objToString(contract.getCssCatCode()),
        this.objToString(contract.getConsignmentCca()),
        this.objToString(contract.getConsignmentCcaUnit()),
        StringConvertUtil.convertDateToString(
            contract.getConsignmentCcaDecisionDate(),
            ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
        this.objToString(contract.getContractEndFuSentFlag()),
        psInfoCatCode,
        this.objToString(contract.getNote()),
        this.objToString(contract.getRealQuantityNeedFlag()),
        this.objToString(contract.getRealQuantityImportCompleteFlag()),
        this.objToString(contract.getFree1()),
        this.objToString(contract.getFree2()),
        this.objToString(contract.getFree3()),
        this.objToString(contract.getFree4()),
        this.objToString(contract.getFree5()),
        this.objToString(contract.getFree6()),
        this.objToString(contract.getFree7()),
        this.objToString(contract.getFree8()),
        this.objToString(contract.getFree9()),
        this.objToString(contract.getFree10()),
        this.objToString(contract.getFree11()),
        this.objToString(contract.getFree12()),
        this.objToString(contract.getFree13()),
        this.objToString(contract.getFree14()),
        this.objToString(contract.getConsignmentUseItem1()),
        this.objToString(contract.getConsignmentUseItem2()),
        this.objToString(contract.getConsignmentUseItem3()),
        this.objToString(contract.getOurMngPersonInChargeCode()),
        this.objToString(contract.getOurMngDepartmentCode()),

        // 契約付加情報
        (contractAddInfo != null ? this.objToString(contractAddInfo.getAgentContractNo()) : null),
        (contractAddInfo != null ? this.objToString(contractAddInfo.getFree1()) : null),
        (contractAddInfo != null ? this.objToString(contractAddInfo.getFree2()) : null),
        (contractAddInfo != null ? this.objToString(contractAddInfo.getFree3()) : null),
        (contractAddInfo != null ? this.objToString(contractAddInfo.getFree4()) : null),
        (contractAddInfo != null ? this.objToString(contractAddInfo.getFree5()) : null),
        (contractAddInfo != null ? this.objToString(contractAddInfo.getFree6()) : null),
        (contractAddInfo != null ? this.objToString(contractAddInfo.getFree7()) : null),
        (contractAddInfo != null ? this.objToString(contractAddInfo.getFree8()) : null),
        (contractAddInfo != null ? this.objToString(contractAddInfo.getFree9()) : null),
        (contractAddInfo != null ? this.objToString(contractAddInfo.getFree10()) : null),

        // カスタム契約
        (cContract != null ? this.objToString(cContract.getSalesDepartmentCd()) : null),
        (cContract != null ? this.objToString(cContract.getContactCd()) : null),
    };

    return contractDataRecord;
  }

  /**
   * 《契約履歴》レコード生成
   *
   * @param contract
   * @param contractAddInfo
   * @param cContract
   * @return 《契約履歴》レコード
   */
  private String[] createContractHistDataRecord(ContractHist contractHist) {

    // 《契約履歴》レコード
    String[] contractHistDataRecord = {
        STR_CONTRACTHISTDATARECORD_CODE,
        this.objToString(contractHist.getContractId()),
        StringConvertUtil.convertDateToString(
            contractHist.getApplySd(),
            ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
        StringConvertUtil.convertDateToString(
            contractHist.getApplyEd(),
            ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
        this.objToString(contractHist.getContractChangeReason()),
        this.objToString(contractHist.getCcDecisionCategoryCode()),
        this.objToString(contractHist.getVoltageCatCode()),
        this.objToString(contractHist.getUpCatCode()),

    };

    return contractHistDataRecord;
  }

  /**
   * 《確定料金実績》レコード生成
   *
   * @param fcr
   * @return 確定料金実績》レコード
   */
  private String[] createFcrDataRecord(Fcr fcr) {
    // 《確定料金実績》レコード
    String[] fcrDataRecord = {
        STR_FCRDATARECORD_CODE,
        this.objToString(fcr.getFcrId()),
        this.objToString(fcr.getContractId()),
        this.objToString(fcr.getContractNo()),
        StringConvertUtil.convertDateToString(fcr.getApplySd(),
            ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
        this.objToString(fcr.getUsePeriod()),
        this.objToString(fcr.getContractorId()),
        this.objToString(fcr.getContractorNo()),
        this.objToString(fcr.getSectionCode()),
        this.objToString(fcr.getCustomerCode()),
        this.objToString(fcr.getPmCode()),
        this.objToString(fcr.getPmCompanyCode()),
        this.objToString(fcr.getMlId()),
        this.objToString(fcr.getAreaCode()),
        this.objToString(fcr.getOurMngAreaCode()),
        this.objToString(fcr.getSpotNo()),
        StringConvertUtil.convertDateToString(
            fcr.getNextMrScheduledDate(),
            ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
        this.objToString(fcr.getRmId()),
        this.objToString(fcr.getCca()),
        this.objToString(fcr.getCcaUnit()),
        this.objToString(fcr.getConsignmentCca()),
        this.objToString(fcr.getConsignmentCcaUnit()),
        StringConvertUtil.convertDateToString(
            fcr.getConsignmentCcaDecisionDate(),
            ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
        this.objToString(fcr.getConsignmentChargeEquivalent()),
        this.objToString(fcr.getDealClassCode()),
        this.objToString(fcr.getFuId()),
        StringConvertUtil.convertDateToString(fcr.getMrDate(),
            ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
        this.objToString(fcr.getMrReasonCode()),
        StringConvertUtil.convertDateToString(fcr.getCcSd(),
            ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
        StringConvertUtil.convertDateToString(fcr.getCcEd(),
            ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
        StringConvertUtil.convertDateToString(fcr.getCfd(),
            ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
        this.objToString(fcr.getCalculatingPowerFactor()),
        this.objToString(fcr.getMonthlyCharge()),
        this.objToString(fcr.getCtEquivalent()),
        this.objToString(fcr.getCtRate()),
        this.objToString(fcr.getCtIc()),
        this.objToString(fcr.getBasicCharge()),
        this.objToString(fcr.getUsageCharge()),
        this.objToString(fcr.getFca()),
        this.objToString(fcr.getRec()),
        this.objToString(fcr.getSplAmount()),
        this.objToString(fcr.getCec()),
        this.objToString(fcr.getSp1Correction()),
        this.objToString(fcr.getSp2Correction()),
        this.objToString(fcr.getSp3Correction()),
        StringConvertUtil.convertDateToString(fcr.getSpRecordedDate(),
            ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
        StringConvertUtil.convertDateToString(
            fcr.getSpRecordedExecuteDate(),
            ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
        this.objToString(fcr.getSpIc1()),
        this.objToString(fcr.getSp1()),
        this.objToString(fcr.getSpIc2()),
        this.objToString(fcr.getSp2()),
        this.objToString(fcr.getSpIc3()),
        this.objToString(fcr.getSp3()),
        this.objToString(fcr.getArIc()),
        this.objToString(fcr.getArAmount()),
        StringConvertUtil.convertDateToString(
            fcr.getArRccRecordedDate(),
            ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
        StringConvertUtil.convertDateToString(fcr.getArRccBaseDate(),
            ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
        StringConvertUtil.convertDateToString(
            fcr.getArRccExecuteDate(),
            ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
        this.objToString(fcr.getBlNo()),
        this.objToString(fcr.getBlRccAppropriationFlag()),
        this.objToString(fcr.getArRccTransferIc()),
        this.objToString(fcr.getCompletedFlag()),
        this.objToString(fcr.getCsCode()),
        this.objToString(fcr.getCcccFlag()),
        this.objToString(fcr.getContractGroupNo()),
        this.objToString(fcr.getWarningDealCatCode()),
        StringConvertUtil.convertDateToString(fcr.getCreateDate(),
            ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
        this.objToString(fcr.getCssCatCode()),
        this.objToString(fcr.getScCode()),
        this.objToString(fcr.getBusinessTypeCode()),
        this.objToString(fcr.getPuMultipleMCat()),
        this.objToString(fcr.getNote()),
        this.objToString(fcr.getRegistrationNumber()),
        this.objToString(fcr.getEligibleInvoiceIssuer()) };

    return fcrDataRecord;
  }

  /**
   * 《確定料金実績内訳》レコード生成
   *
   * @param fcrBreakdown
   * @return 《確定料金実績内訳》レコード
   */
  private String[] createFcrBreakdownDataRecord(FcrBreakdown fcrBreakdown) {
    // 《確定料金実績内訳》レコード
    String[] fcrBreakdownDataRecord = {
        STR_FCRBREAKDOWNDATARECORD_CODE,
        this.objToString(fcrBreakdown.getFcrId()),
        this.objToString(fcrBreakdown.getDisplayOrder()),
        this.objToString(fcrBreakdown.getDetailOutputOrder()),
        this.objToString(fcrBreakdown.getDisplayName1()),
        this.objToString(fcrBreakdown.getDisplayName2()),
        this.objToString(fcrBreakdown.getCapacityOrUsage()),
        this.objToString(fcrBreakdown.getUp()),
        this.objToString(fcrBreakdown.getAmount()),
        this.objToString(fcrBreakdown.getSplContractId()),
        this.objToString(fcrBreakdown.getSplRate()),
        this.objToString(fcrBreakdown.getSplCoveredCatCode()),
        this.objToString(fcrBreakdown.getFcrBreakdownCatCode()),
        this.objToString(fcrBreakdown.getRestrictionDiscountInfoId()) };

    return fcrBreakdownDataRecord;
  }

  /**
   * 《実量歴管理》レコード生成
   *
   * @param rqh
   * @return 《実量歴管理》レコード
   */
  private String[] createRqhDataRecord(Rqh rqh) {
    // 《実量歴管理》レコード
    String[] rqhDataRecord = {
        STR_RQHDATARECORD_CODE,
        this.objToString(rqh.getContractId()),
        this.objToString(rqh.getCoveredPeriod()),
        this.objToString(rqh.getSpotNo()),
        StringConvertUtil.convertDateToString(rqh.getCcSd(),
            ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
        this.objToString(rqh.getPkwCalculation()),
        this.objToString(rqh.getPkwUsage()),
        this.objToString(rqh.getPkwManual()),
        this.objToString(rqh.getPkw()),
        this.objToString(rqh.getCcc()),
        StringConvertUtil.convertDateToString(rqh.getCccTime(),
            ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
        this.objToString(rqh.getRccFlg()) };

    return rqhDataRecord;
  }

  /**
   * 《確定使用量》レコード生成
   *
   * @param fu
   * @return 《確定使用量》レコード
   */
  private String[] createFuDataRecord(Fu fu) {
    // 《確定使用量》レコード
    String[] fuDataRecord = {
        STR_FUDATARECORD_CODE,
        this.objToString(fu.getFuId()),
        this.objToString(fu.getContractId()),
        this.objToString(fu.getMlId()),
        this.objToString(fu.getSmCatCode()),
        this.objToString(fu.getMrDateCatCode()),
        this.objToString(fu.getUsePeriod()),
        this.objToString(fu.getUsageQuantity()),
        this.objToString(fu.getPdReference()),
        StringConvertUtil.convertDateToString(fu.getUsageSd(),
            ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
        StringConvertUtil.convertDateToString(fu.getUsageEd(),
            ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
        this.objToString(fu.getCcDays()),
        StringConvertUtil.convertDateToString(fu.getMrDate(),
            ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
        StringConvertUtil.convertDateToString(fu.getMurMrDate(),
            ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
        StringConvertUtil.convertDateToString(
            fu.getNextMrScheduledDate(),
            ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
        StringConvertUtil.convertDateToString(fu.getMrSd(),
            ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
        StringConvertUtil.convertDateToString(fu.getMrEd(),
            ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
        this.objToString(fu.getMrDays()),
        this.objToString(fu.getBeforeReplacementMrDays()),
        StringConvertUtil.convertDateToString(fu.getCreateDate(),
            ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
        this.objToString(fu.getPowerFactor()) };

    return fuDataRecord;
  }

  /**
   * 《確定指示数》レコード生成
   *
   * @param fixIn
   * @return 《確定指示数》レコード
   */
  private String[] createFixInDataRecord(FixIn fixIn) {
    // 《確定指示数》レコード
    String[] fixInDataRecord = {
        STR_FIXINDATARECORD_CODE,
        this.objToString(fixIn.getFuId()),
        this.objToString(fixIn.getMeterCatCode()),
        this.objToString(fixIn.getFtuCurrentIn()),
        this.objToString(fixIn.getFtuPreviousIn()),
        this.objToString(fixIn.getInDifference()),
        this.objToString(fixIn.getInCalculationUsage()),
        this.objToString(fixIn.getEffectiveCurrentIndicationNo()),
        this.objToString(fixIn.getEffectivePreviousIndicationNo()),
        this.objToString(fixIn.getEffectiveIndicationNoDifference()),
        this.objToString(fixIn.getEffectiveIndicationNoCalculationUsage()),
        this.objToString(fixIn.getReactiveCurrentIndicationNo()),
        this.objToString(fixIn.getReactivePreviousIndicationNo()),
        this.objToString(fixIn.getReactiveIndicationNoDifference()),
        this.objToString(fixIn.getReactiveIndicationNoCalculationUsage()),
        this.objToString(fixIn.getMultiplyingFactor()),
        this.objToString(fixIn.getKwhDisadvantageFactor()),
        this.objToString(fixIn.getFixInUsageDiffFlag()),
        this.objToString(fixIn.getMeterReplacementFlag()),
        this.objToString(fixIn.getMeterIdn()) };

    return fixInDataRecord;
  }

  /**
   * 《時間帯別使用量》レコード生成
   *
   * @param tsUsage
   * @return 《時間帯別使用量》レコード
   */
  private String[] createTsUsageDataRecord(TsUsage tsUsage) {
    // 《時間帯別使用量》レコード
    String[] tsUsageDataRecord = {
        STR_TSUSAGEDATARECORD_CODE,
        this.objToString(tsUsage.getFuId()),
        StringConvertUtil.convertDateToString(tsUsage.getDsSd(),
            ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
        this.objToString(tsUsage.getTsCode()),
        this.objToString(tsUsage.getTsName()),
        this.objToString(tsUsage.getUsageQuantity()) };

    return tsUsageDataRecord;
  }

  /**
   * 《日割別使用量》レコード生成
   *
   * @param dsUsage
   * @return 《日割別使用量》レコード
   */
  private String[] createDsUsageDataRecord(DsUsage dsUsage) {

    // 《日割別使用量》レコード
    String[] dsUsageDataRecord = {
        STR_DSUSAGEDATARECORD_CODE,
        this.objToString(dsUsage.getFuId()),
        StringConvertUtil.convertDateToString(dsUsage.getDsSd(),
            ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
        StringConvertUtil.convertDateToString(dsUsage.getDsEd(),
            ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
        this.objToString(dsUsage.getUsageQuantity()),
        this.objToString(dsUsage.getCca()) };

    return dsUsageDataRecord;
  }

  /**
   * 《予備契約履歴》レコード生成
   *
   * @param reserveContractHist
   * @return 《予備契約履歴》レコード
   */
  private String[] createReserveContractHistDataRecord(ReserveContractHist reserveContractHist) {

    // 《予備契約履歴》レコード
    String[] reserveContractHistDataRecord = {
        STR_RESERVECONTRACTHISTDATARECORD_CODE,
        this.objToString(reserveContractHist.getContractId()),
        this.objToString(reserveContractHist.getReserveContractClass()),
        StringConvertUtil.convertDateToString(
            reserveContractHist.getReserveContractSd(),
            ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
        StringConvertUtil.convertDateToString(
            reserveContractHist.getReserveContractEd(),
            ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
        this.objToString(reserveContractHist.getCapacity()) };

    return reserveContractHistDataRecord;
  }

  /**
   * 《制限中止割引情報》レコード生成
   *
   * @param restrictionDiscountInfo
   * @return 《制限中止割引情報》レコード
   */
  private String[] createRestrictionDiscountInfoDataRecord(RestrictionDiscountInfo restrictionDiscountInfo) {
    // 《制限中止割引情報》レコード
    String[] restrictionDiscountInfoDataRecord = {
        STR_RESTRICTIONDISCOUNTINFODATARECORD_CODE,
        this.objToString(restrictionDiscountInfo.getRestrictionDiscountInfoId()),
        this.objToString(restrictionDiscountInfo.getContractId()),
        this.objToString(restrictionDiscountInfo.getCoveredPeriod()),
        this.objToString(restrictionDiscountInfo.getRecordedPeriod()),
        StringConvertUtil.convertDateToString(restrictionDiscountInfo.getCcSd(),
            ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
        this.objToString(restrictionDiscountInfo.getdCoveredCode()),
        this.objToString(restrictionDiscountInfo.getdCoveredDays()),
        this.objToString(restrictionDiscountInfo.getdCoveredTime()) };

    return restrictionDiscountInfoDataRecord;
  }

  /**
   * CSVファイル作成
   *
   * @param batchDate
   * @param batchDateStr
   * @param prop
   * @param outputFolderPath
   * @param pmCompanyCode
   * @param csvDateList
   */
  private void saveCSV(Date batchDate, String batchDateStr, Properties prop,
      String outputFolderPath, String pmCompanyCode,
      List<String[]> csvDateList) {
    // CSV設定
    CsvConfig csvconfig = new CsvConfig();

    // 行の区切り：CRLF
    csvconfig.setLineSeparator(ECISConstants.ENTER_CODE);

    // 囲み文字有効
    csvconfig.setQuoteDisabled(false);
    // 全項目で、囲み文字で項目を囲む
    csvconfig.setQuotePolicy(QuotePolicy.ALL);
    // 囲み文字ダブルクォートを設定
    csvconfig.setQuote(CsvConfig.DEFAULT_QUOTE);
    // エスケープ文字有効
    csvconfig.setEscapeDisabled(false);
    // エスケープ文字ダブルクォートを設定
    csvconfig.setEscape(CsvConfig.DEFAULT_QUOTE);
    // NULL項目はダブルクォートのみで表示
    csvconfig.setNullString(ECISConstants.CSVCONFIG_OPTION_NULL_STRING);

    // 空行スキップ設定
    csvconfig.setIgnoreEmptyLines(true);

    // ファイル名設定
    String fileNameTemplate = prop.getProperty("batch.sn.billingfile");
    String fileName = MessageFormat.format(fileNameTemplate, batchDateStr);
    String outputFileFullPath = outputFolderPath + pmCompanyCode + fileName;
    File outputFile = new File(outputFileFullPath);

    // CSVファイル作成
    try {
      Csv.save(csvDateList, outputFile, ECISConstants.ENCODE_TYPE_SJIS,
          csvconfig, new StringArrayListHandler());
    } catch (IOException ioe) {
      throw new SystemException(ioe.getMessage(), ioe);
    }

    // ダウンロード管理登録
    GK_RegistDownloadManageBusinessBean downloadManageBean = new GK_RegistDownloadManageBusinessBean();

    // サブシステムID
    downloadManageBean.setSubsystemId(ECISConstants.SUBSYSTEM_ID_SN);

    // 機能ID
    downloadManageBean
        .setFunctionId(ECISFunctionIdConstants.FUNCTION_ID.SN0108
            .toString());

    // ファイル分類コード
    downloadManageBean
        .setFileCategoryCode(ECISCodeConstants.FILE_CATEGORY_CODE_BILLING_DATA_B1);

    // 論理ファイル名
    downloadManageBean.setLogicalFileName(outputFile.getName());

    // ファイルパス
    downloadManageBean.setFilePath(outputFileFullPath);

    // ダウンロード期限日数取得キー
    downloadManageBean
        .setDownloadExpirationDateCountKey("batch.sn.billingfile.download.expiration.date");

    // 処理基準日をDate型に変換してから設定する
    downloadManageBean.setExecuteBaseDate(batchDate);

    // 出力したファイルの情報を【ダウンロード管理】に登録する。
    gkWorkCommonBusiness.registDownloadManage(downloadManageBean);
  }

  /**
   * 型式変更
   *
   * @param value
   *          変換する対象
   * @return 変換した文字列、nullの場合は空文字を返却する
   */
  private String objToString(Object value) {
    // 引数がnullの場合、空文字を返却する。
    if (value == null) {
      return ECISConstants.EMPTY_STRING;
    }
    // String型に変換後、改行コードを半角スペースに変換する。
    return String.valueOf(value).replaceAll(ECISConstants.REPLACEMENT_TARGET_ENTER_CODE_CSV_FILE_DOWNLOAD,
        ECISConstants.SPACE_HANKAKU);
  }

  /**
   * 請求Mapperを設定する。（DI）
   *
   * @param blMapper
   *          請求Mapper
   */
  public void setBlMapper(BlMapper blMapper) {
    this.blMapper = blMapper;
  }

  /**
   * 契約者Mapperを設定する。（DI）
   *
   * @param contractorMapper
   *          契約者Mapper
   */
  public void setContractorMapper(ContractorMapper contractorMapper) {
    this.contractorMapper = contractorMapper;
  }

  /**
   * カスタム契約者Mapperを設定する。（DI）
   *
   * @param cContractorMapper
   *          カスタム契約者Mapper
   */
  public void setCContractorMapper(CContractorMapper ccontractorMapper) {
    this.cContractorMapper = ccontractorMapper;
  }

  /**
   * 契約者付加情報Mapperを設定する。（DI）
   *
   * @param contractorAddInfoMapper
   *          契約者付加情報Mapper
   */
  public void setContractorAddInfoMapper(ContractorAddInfoMapper contractorAddInfoMapper) {
    this.contractorAddInfoMapper = contractorAddInfoMapper;
  }

  /**
   * 支払Mapperを設定する。（DI）
   *
   * @param paymentMapper
   *          支払Mapper
   */
  public void setPaymentMapper(PaymentMapper paymentMapper) {
    this.paymentMapper = paymentMapper;
  }

  /**
   * 支払履歴Mapperを設定する。（DI）
   *
   * @param paymentHistMapper
   *          支払履歴Mapper
   */
  public void setPaymentHistMapper(PaymentHistMapper paymentHistMapper) {
    this.paymentHistMapper = paymentHistMapper;
  }

  /**
   * カスタム支払履歴Mapperを設定する。（DI）
   *
   * @param cpaymentHistMapper
   *          カスタム支払履歴Mapper
   */
  public void setCPaymentHistMapper(CPaymentHistMapper cpaymentHistMapper) {
    this.cPaymentHistMapper = cpaymentHistMapper;
  }

  /**
   * 契約Mapperを設定する。（DI）
   *
   * @param contractMapper
   *          契約Mapper
   */
  public void setContractMapper(ContractMapper contractMapper) {
    this.contractMapper = contractMapper;
  }

  /**
   * カスタム契約Mapperを設定する。（DI）
   *
   * @param ccontractMapper
   *          カスタム契約Mapper
   */
  public void setCContractMapper(CContractMapper ccontractMapper) {
    this.cContractMapper = ccontractMapper;
  }

  /**
   * 契約付加情報Mapperを設定する。（DI）
   *
   * @param contractAddInfoMapper
   *          契約付加情報Mapper
   */
  public void setContractAddInfoMapper(ContractAddInfoMapper contractAddInfoMapper) {
    this.contractAddInfoMapper = contractAddInfoMapper;
  }

  /**
   * 契約履歴Mapperを設定する。（DI）
   *
   * @param contractHistMapper
   *          契約履歴Mapper
   */
  public void setContractHistMapper(ContractHistMapper contractHistMapper) {
    this.contractHistMapper = contractHistMapper;
  }

  /**
   * 確定料金実績Mapperを設定する。（DI）
   *
   * @param fcrMapper
   *          確定料金実績Mapper
   */
  public void setFcrMapper(FcrMapper fcrMapper) {
    this.fcrMapper = fcrMapper;
  }

  /**
   * 確定料金実績内訳Mapperを設定する。（DI）
   *
   * @param fcrBreakdownMapper
   *          確定料金実績内訳Mapper
   */
  public void setFcrBreakdownMapper(FcrBreakdownMapper fcrBreakdownMapper) {
    this.fcrBreakdownMapper = fcrBreakdownMapper;
  }

  /**
   * 実量歴管理Mapperを設定する。（DI）
   *
   * @param rqhMapper
   *          実量歴管理Mapper
   */
  public void setRqhMapper(RqhMapper rqhMapper) {
    this.rqhMapper = rqhMapper;
  }

  /**
   * 確定使用量Mapperを設定する。（DI）
   *
   * @param fuMapper
   *          確定使用量Mapper
   */
  public void setFuMapper(FuMapper fuMapper) {
    this.fuMapper = fuMapper;
  }

  /**
   * 確定指示数Mapperを設定する。（DI）
   *
   * @param fixInMapper
   *          確定指示数Mapper
   */
  public void setFixInMapper(FixInMapper fixInMapper) {
    this.fixInMapper = fixInMapper;
  }

  /**
   * 時間帯別使用量Mapperを設定する。（DI）
   *
   * @param tsUsageMapper
   *          時間帯別使用量Mapper
   */
  public void setTsUsageMapper(TsUsageMapper tsUsageMapper) {
    this.tsUsageMapper = tsUsageMapper;
  }

  /**
   * 日割別使用量Mapperを設定する。（DI）
   *
   * @param dsUsageMapper
   *          日割別使用量Mapper
   */
  public void setDsUsageMapper(DsUsageMapper dsUsageMapper) {
    this.dsUsageMapper = dsUsageMapper;
  }

  /**
   * 制限中止割引情報Mapperを設定する。（DI）
   *
   * @param restrictionDiscountInfoMapper
   *          制限中止割引情報Mapper
   */
  public void setRestrictionDiscountInfoMapper(RestrictionDiscountInfoMapper restrictionDiscountInfoMapper) {
    this.restrictionDiscountInfoMapper = restrictionDiscountInfoMapper;
  }

  /**
   * 請求情報作成Mapperを設定する。（DI）
   *
   * @param customSnCreatingBillingFileMapper
   *          請求情報作成Mapper
   */
  public void setCustomSnCreatingBillingFileMapper(
      Custom_SN_CreatingBillingFileMapper customSnCreatingBillingFileMapper) {
    this.customSnCreatingBillingFileMapper = customSnCreatingBillingFileMapper;
  }

  /**
   * 業務共通ビジネスを設定する。（DI）
   *
   * @param gkWorkCommonBusiness
   *          業務共通ビジネス
   */
  public void setGkWorkCommonBusiness(
      GK_WorkCommonBusiness gkWorkCommonBusiness) {
    this.gkWorkCommonBusiness = gkWorkCommonBusiness;
  }

  /**
   * プロパティを設定する。（DI）
   *
   * @param applicationProperties
   *          プロパティ
   */
  public void setApplicationProperties(
      PropertiesFactoryBean applicationProperties) {
    this.applicationProperties = applicationProperties;
  }

  /**
   * メッセージプロパティを設定する。（DI）
   *
   * @param messageSource
   *          メッセージプロパティ
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }

}
