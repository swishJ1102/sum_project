package jp.co.unisys.enability.cis.business.gk.model;

import java.util.Date;

/**
 * 業務共通ダウンロード管理登録Bean
 * 
 * @author "Nihon Unisys, Ltd."
 *
 */
public class GK_RegistDownloadManageBusinessBean {

  /** サブシステムID */
  private String subsystemId;
  /** 機能ID */
  private String functionId;
  /** ファイル分類コード */
  private String fileCategoryCode;
  /** 論理ファイル名 */
  private String logicalFileName;
  /** ファイルパス */
  private String filePath;
  /** ダウンロード期限日数取得キー */
  private String downloadExpirationDateCountKey;
  /** 処理基準日 */
  private Date executeBaseDate;

  /**
   * サブシステムIDを取得します。
   *
   * @return subsystemId サブシステムID
   */
  public String getSubsystemId() {
    return subsystemId;
  }

  /**
   * サブシステムIDを設定します。
   *
   * @param subsystemId
   *          サブシステムID
   */
  public void setSubsystemId(String subsystemId) {
    this.subsystemId = subsystemId;
  }

  /**
   * 機能IDを取得します。
   *
   * @return functionId 機能ID
   */
  public String getFunctionId() {
    return functionId;
  }

  /**
   * 機能IDを設定します。
   *
   * @param functionId
   *          機能ID
   */
  public void setFunctionId(String functionId) {
    this.functionId = functionId;
  }

  /**
   * ファイル分類コードを取得します。
   *
   * @return fileCategoryCode ファイル分類コード
   */
  public String getFileCategoryCode() {
    return fileCategoryCode;
  }

  /**
   * ファイル分類コードを設定します。
   *
   * @param fileCategoryCode
   *          ファイル分類コード
   */
  public void setFileCategoryCode(String fileCategoryCode) {
    this.fileCategoryCode = fileCategoryCode;
  }

  /**
   * 論理ファイル名を取得します。
   *
   * @return logicalFileName 論理ファイル名
   */
  public String getLogicalFileName() {
    return logicalFileName;
  }

  /**
   * 論理ファイル名を設定します。
   *
   * @param logicalFileName
   *          論理ファイル名
   */
  public void setLogicalFileName(String logicalFileName) {
    this.logicalFileName = logicalFileName;
  }

  /**
   * ファイルパスを取得します。
   *
   * @return filePath ファイルパス
   */
  public String getFilePath() {
    return filePath;
  }

  /**
   * ファイルパスを設定します。
   *
   * @param filePath
   *          ファイルパス
   */
  public void setFilePath(String filePath) {
    this.filePath = filePath;
  }

  /**
   * ダウンロード期限日数取得キーを取得します。
   *
   * @return downloadExpirationDateCountKey ダウンロード期限日数取得キー
   */
  public String getDownloadExpirationDateCountKey() {
    return downloadExpirationDateCountKey;
  }

  /**
   * ダウンロード期限日数取得キーを設定します。
   *
   * @param downloadExpirationDateCountKey
   *          ダウンロード期限日数取得キー
   */
  public void setDownloadExpirationDateCountKey(
      String downloadExpirationDateCountKey) {
    this.downloadExpirationDateCountKey = downloadExpirationDateCountKey;
  }

  /**
   * 処理基準日を取得します。
   *
   * @return executeBaseDate 処理基準日
   */
  public Date getExecuteBaseDate() {
    return executeBaseDate;
  }

  /**
   * 処理基準日を設定します。
   *
   * @param executeBaseDate
   *          処理基準日
   */
  public void setExecuteBaseDate(Date executeBaseDate) {
    this.executeBaseDate = executeBaseDate;
  }

}
