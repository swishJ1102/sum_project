package jp.co.unisys.enability.cis.business.rk;

/**
 * 計量器交換情報反映ビジネスインターフェース。
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.mapper.common.McSmrInfoMapper
 * @see jp.co.unisys.enability.cis.mapper.common.McSmrDetail2Mapper
 * @see jp.co.unisys.enability.cis.mapper.common.FuMapper
 * @see jp.co.unisys.enability.cis.mapper.common.FixInMapper
 */
public interface RK_MeterExchangeInformationReflectionBusiness {

  /**
   * 「力測有効電力量指示数算出使用量」および「力測無効電力量指示数算出使用量」を算出して確定指示数の更新を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 「力測有効電力量指示数算出使用量」および「力測無効電力量指示数算出使用量」を算出し、
   * 【確定指示数】の更新を行う。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractId
   *          契約ID
   * @param coveredPeriod
   *          対象年月
   * @see jp.co.unisys.enability.cis.mapper.common.McSmrInfoMapper
   * @see jp.co.unisys.enability.cis.mapper.common.McSmrDetail2Mapper
   * @see jp.co.unisys.enability.cis.mapper.common.FuMapper
   * @see jp.co.unisys.enability.cis.mapper.common.FixInMapper
   */
  public abstract void meterExchangeInformationReflection(Integer contractId, String coveredPeriod);
}
