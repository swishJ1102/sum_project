package jp.co.unisys.enability.cis.business.kj.model;

import java.math.BigDecimal;
import java.util.Date;

/**
 * 契約情報更新で、更新条件を格納するビジネスBean
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * 契約情報更新ビジネス
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class SupplementaryContractInformationBean {

  /** 付帯メニューID */
  private String supplementaryMenuId;

  /** 付帯契約開始日 */
  private Date supplementaryContractStartDate;

  /** 付帯契約終了日 */
  private Date supplementaryContractEndDate;

  /** 額・率 */
  private BigDecimal amountOrRate;

  /** 付帯契約情報更新フラグ */
  private String updateFlagSupplementaryContract;

  public String getSupplementaryMenuId() {
    return supplementaryMenuId;
  }

  public void setSupplementaryMenuId(String supplementaryMenuId) {
    this.supplementaryMenuId = supplementaryMenuId;
  }

  public Date getSupplementaryContractStartDate() {
    return supplementaryContractStartDate;
  }

  public void setSupplementaryContractStartDate(Date supplementaryContractStartDate) {
    this.supplementaryContractStartDate = supplementaryContractStartDate;
  }

  public Date getSupplementaryContractEndDate() {
    return supplementaryContractEndDate;
  }

  public void setSupplementaryContractEndDate(Date supplementaryContractEndDate) {
    this.supplementaryContractEndDate = supplementaryContractEndDate;
  }

  public BigDecimal getAmountOrRate() {
    return amountOrRate;
  }

  public void setAmountOrRate(BigDecimal amountOrRate) {
    this.amountOrRate = amountOrRate;
  }

  public String getUpdateFlagSupplementaryContract() {
    return updateFlagSupplementaryContract;
  }

  public void setUpdateFlagSupplementaryContract(String updateFlagSupplementaryContract) {
    this.updateFlagSupplementaryContract = updateFlagSupplementaryContract;
  }

}
