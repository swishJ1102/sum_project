package jp.co.unisys.enability.cis.business.rk;

import java.util.Date;
import java.util.List;

import jp.co.unisys.enability.cis.business.rk.model.RK_UsageLinkageCheckCheckDataBusinessBean;
import jp.co.unisys.enability.cis.business.rk.model.RK_UsageLinkageCheckTermDecisionBusinessBean;
import jp.co.unisys.enability.cis.common.util.StringConvertUtil;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;
import jp.co.unisys.enability.cis.dao.rk.RK_UsageLinkageCheckDao;
import jp.co.unisys.enability.cis.entity.common.DemandResult;
import jp.co.unisys.enability.cis.entity.common.DemandResultExample;
import jp.co.unisys.enability.cis.entity.rk.RK_UsageLinkageCheckLatestContractEntityBean;
import jp.co.unisys.enability.cis.mapper.common.DemandResultMapper;

/**
 * 契約期間外チェックビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.rk.RK_UsageLinkageCheckBusiness
 * @see jp.co.unisys.enability.cis.dao.rk.RK_UsageLinkageCheckDao
 */
public class RK_CheckOutsideContractTermBusinessImpl implements
    RK_CheckFixUsageBusiness {

  /** 料金計算チェックビジネス(DI) */
  private RK_UsageLinkageCheckBusiness rkUsageLinkageCheckBusiness;

  /** 使用量連携チェックDao(DI) */
  private RK_UsageLinkageCheckDao rkUsageLinkageCheckDao;

  /** 需要実績Mapper(DI) */
  private DemandResultMapper demandResultMapper;

  /**
   * 契約期間外チェック。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約が存在しない期間の確定使用量メッセージかを判定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param checkDataBusinessBean
   *          チェック対象ビジネスBean
   * @param termDecisionBusinessBean
   *          期間判定情報ビジネスBean
   * @return true:処理継続、false:処理終了
   */
  @Override
  public boolean check(
      RK_UsageLinkageCheckCheckDataBusinessBean checkDataBusinessBean,
      RK_UsageLinkageCheckTermDecisionBusinessBean termDecisionBusinessBean) {

    boolean continuation = true;

    // 契約情報が存在しない場合は、TODOを登録し、【月次実績】.月次実績エラー区分コードを"エラー"で更新する
    if (termDecisionBusinessBean.getContractList().isEmpty()) {

      // 地点特定番号に紐づく最新の契約情報を取得
      RK_UsageLinkageCheckLatestContractEntityBean latestContract = rkUsageLinkageCheckDao
          .selectLatestContract(checkDataBusinessBean.getSpotNo());

      // 需要実績Example
      DemandResultExample demandResultExample = new DemandResultExample();

      // 需要実績の取得条件を設定
      demandResultExample.createCriteria()
          // 地点特定番号
          .andSpotNoEqualTo(checkDataBusinessBean.getSpotNo())
          // 確定使用量ファイル名
          .andFuFileNameEqualTo(checkDataBusinessBean.getFixUsageFileName())
          // エリアコード
          .andAreaCodeEqualTo(checkDataBusinessBean.getAreaCode());

      // 確定使用量対象日の昇順でソート
      demandResultExample
          .setOrderByClause(ECISRKConstants.CHECK_OUTSIDE_CONTRACT_TERM_DEMAND_RESULT_ORDER_BY_CLAUSE);

      // 地点特定番号に紐づく需要実績を取得
      List<DemandResult> demandResultList = demandResultMapper.selectByExample(demandResultExample);

      // 最初の要素が確定使用量対象日の開始日
      Date coveredTermStartDate = demandResultList.get(0).getFuCoveredDate();

      // 最後の要素が確定使用量対象日の終了日
      Date coveredTermEndDate = demandResultList.get(demandResultList.size() - 1).getFuCoveredDate();

      // 契約期間を"yyyy/MM/dd～yyyy/MM/dd"の形式で文字列化
      StringBuilder contractTerm = new StringBuilder();
      contractTerm.append(formatDate(latestContract
          .getContractStartDate()));
      contractTerm.append(ECISRKConstants.TERM_NAMISEN_ZENKAKU);
      contractTerm
          .append(formatDate(latestContract.getContractEndDate()));

      // 確定使用量の対象期間を"yyyy/MM/dd～yyyy/MM/dd"の形式で文字列化
      StringBuilder coveredTerm = new StringBuilder();
      coveredTerm.append(formatDate(coveredTermStartDate));
      coveredTerm.append(ECISRKConstants.TERM_NAMISEN_ZENKAKU);
      coveredTerm.append(formatDate(coveredTermEndDate));

      // TODOメッセージを作成するパラメータ
      String[] params = {
          // 確定使用量ファイル名
          checkDataBusinessBean.getFixUsageFileName(),
          // 地点特定番号
          checkDataBusinessBean.getSpotNo(),
          // エリアコード
          checkDataBusinessBean.getAreaCode(),
          // 処理日
          formatDate(checkDataBusinessBean.getExecuteDate()),
          // 契約番号
          latestContract.getContractNo(),
          // 需給契約期間
          contractTerm.toString(),
          // 使用量対象期間
          coveredTerm.toString() };

      // TODO登録
      rkUsageLinkageCheckBusiness.registerTodo("todo.T1021", null, "todo.T1039", params,
          latestContract.getContractNo(), checkDataBusinessBean.getSpotNo(), null);

      // 月次実績エラー区分コードをエラーで更新
      rkUsageLinkageCheckBusiness
          .updateMonthlyUsageResultError(checkDataBusinessBean);

      // 処理を継続しない
      continuation = false;
    }

    return continuation;
  }

  /**
   * 日付を"yyyy/MM/dd"形式の文字列に変換する。
   *
   * @param targetDate
   *          変換対象の日付
   * @return 変換後の文字列
   */
  private String formatDate(Date targetDate) {
    return StringConvertUtil.convertDateToString(targetDate,
        ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH);
  }

  /**
   * 料金計算チェックビジネスを設定します。(DI)
   * 
   * @param rkUsageLinkageCheckBusiness
   *          料金計算チェックビジネス
   */
  public void setRkUsageLinkageCheckBusiness(
      RK_UsageLinkageCheckBusiness rkUsageLinkageCheckBusiness) {
    this.rkUsageLinkageCheckBusiness = rkUsageLinkageCheckBusiness;
  }

  /**
   * 使用量連携チェックDaoを設定します。(DI)
   * 
   * @param rkUsageLinkageCheckDao
   *          使用量連携チェックDao
   */
  public void setRkUsageLinkageCheckDao(
      RK_UsageLinkageCheckDao rkUsageLinkageCheckDao) {
    this.rkUsageLinkageCheckDao = rkUsageLinkageCheckDao;
  }

  /**
   * 需要実績Mapperを設定します。(DI)
   * 
   * @param demandResultMapper
   *          需要実績Mapper
   */
  public void setDemandResultMapper(DemandResultMapper demandResultMapper) {
    this.demandResultMapper = demandResultMapper;
  }

}
