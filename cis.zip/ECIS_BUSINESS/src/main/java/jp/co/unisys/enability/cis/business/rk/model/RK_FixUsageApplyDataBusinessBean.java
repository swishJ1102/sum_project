package jp.co.unisys.enability.cis.business.rk.model;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * 確定使用量情報を保持するビジネスBean。
 *
 * <pre>
 * <p>
 * <b>【使用ビジネス】</b>
 * </p>
 * 確定使用量情報反映ビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_FixUsageApplyDataBusinessBean {

	/**
	 * 地点特定番号を保有する。
	 */
	private String spotNo;

	/**
	 * 確定使用量ファイル名を保有する。
	 */
	private String fixUsageFileName;

	/**
	 * エリアコードを保有する。
	 */
	private String areaCode;

	/**
	 * 検針日を保有する。
	 */
	private Date meterReadingDate;

	/**
	 * 対象年月を保有する。
	 */
	private String coveredPeriod;

	/**
	 * 力率を保有する。
	 */
	private Short powerFactor;

	/**
	 * 更新コードを保有する。
	 */
	private String updateCode;

	/**
	 * 需要家識別番号を保有する。
	 */
	private String contractorIdentificationNo;

	/**
	 * 次回検針予定日を保有する。
	 */
	private Date nextMeterReadingScheduledDate;

	/**
	 * 地点の最大需要電力を保有する。
	 */
	private Integer spotPeakDemand;

	/**
	 * メータ設置場所IDを保有する。
	 */
	private Integer meterLocationId;

	/**
	 * 計器識別番号1を保有する。
	 */
	private String meterIdentificationNo1;

	/**
	 * 契約IDを保有する。
	 */
	private Integer contractId;

	/**
	 * 契約番号を保有する。
	 */
	private String contractNo;

	/**
	 * 契約開始日を保有する。
	 */
	private Date contractStartDate;

	/**
	 * 契約終了日を保有する。
	 */
	private Date contractEndDate;

	/**
	 * 契約終了理由コードを保有する。
	 */
	private String contractEndReasonCode;

	/**
	 * 契約終了分確定使用量連携済フラグを保有する。
	 */
	private String contractEndFixUsageSentFlag;

	/**
	 * 利用年月を保有する。
	 */
	private String usePeriod;

	/**
	 * 算定期間開始日を保有する。
	 */
	private Date calculationTermStartDate;

	/**
	 * 算定期間終了日を保有する。
	 */
	private Date calculationTermEndDate;

	/**
	 * 対象使用量リストを保有する。
	 */
	private List<RK_FixUsageApplyUsageBusinessBean> coveredUsageList;

	/**
	 * 確定使用量IDを保有する。
	 */
	private Integer fixUsageId;

	/**
	 * 使用量を保有する。
	 */
	private BigDecimal usageQuantity;

	/**
	 * バッチ実行日を保有する。
	 */
	private Date executeDate;

	/**
	 * スマートメータ区分コードを保有する。
	 */
	private String smartMeterCategoryCode;

	/**
	 * 検針期間開始日を保有する。
	 */
	private Date meterReadingStartDate;

	/**
	 * 検針期間終了日を保有する。
	 */
	private Date meterReadingEndDate;

	/**
	 * 実量歴登録・更新要否フラグ
	 */
	private Boolean realQuantityNeedUpAddFlag;

	/**
	 * 検針日区分コードを保有する。
	 */
	private String meterReadingDateCategoryCode;

	/**
	 * 臨時検針最大電力を保有する。
	 */
	private BigDecimal temporaryMeterReadingPeakDemand;

	/**
	 * 送受電区分コードを保有する。
	 */
	private String transmissionCatCode;

	/**
	 * 月間電力量全量を保有する。
	 */
	private Long monthlyTotalKwh;

	/**
	 * 地点特定番号のgetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 地点特定番号を取得します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @return 地点特定番号
	 */
	public String getSpotNo() {
		return this.spotNo;
	}

	/**
	 * 地点特定番号のsetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 地点特定番号を設定します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @param spotNo
	 *          地点特定番号
	 */
	public void setSpotNo(String spotNo) {
		this.spotNo = spotNo;
	}

	/**
	 * 確定使用量ファイル名のgetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 確定使用量ファイル名を取得します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @return 確定使用量ファイル名
	 */
	public String getFixUsageFileName() {
		return this.fixUsageFileName;
	}

	/**
	 * 確定使用量ファイル名のsetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 確定使用量ファイル名を設定します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @param fixUsageFileName
	 *          確定使用量ファイル名
	 */
	public void setFixUsageFileName(String fixUsageFileName) {
		this.fixUsageFileName = fixUsageFileName;
	}

	/**
	 * エリアコードのgetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * エリアコードを取得します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @return エリアコード
	 */
	public String getAreaCode() {
		return this.areaCode;
	}

	/**
	 * エリアコードのsetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * エリアコードを設定します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @param areaCode
	 *          エリアコード
	 */
	public void setAreaCode(String areaCode) {
		this.areaCode = areaCode;
	}

	/**
	 * 検針日のgetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 検針日を取得します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @return 検針日
	 */
	public Date getMeterReadingDate() {
		return this.meterReadingDate;
	}

	/**
	 * 検針日のsetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 検針日を設定します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @param meterReadingDate
	 *          検針日
	 */
	public void setMeterReadingDate(Date meterReadingDate) {
		this.meterReadingDate = meterReadingDate;
	}

	/**
	 * 対象年月のgetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 対象年月を取得します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @return 対象年月
	 */
	public String getCoveredPeriod() {
		return this.coveredPeriod;
	}

	/**
	 * 対象年月のsetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 対象年月を設定します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @param meterReadingDate
	 *          対象年月
	 */
	public void setCoveredPeriod(String coveredPeriod) {
		this.coveredPeriod = coveredPeriod;
	}

	/**
	 * 力率のgetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 力率を取得します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @return 力率
	 */
	public Short getPowerFactor() {
		return this.powerFactor;
	}

	/**
	 * 力率のsetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 力率を設定します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @param powerFactor
	 *          力率
	 */
	public void setPowerFactor(Short powerFactor) {
		this.powerFactor = powerFactor;
	}

	/**
	 * 更新コードのgetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 更新コードを取得します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @return 更新コード
	 */
	public String getUpdateCode() {
		return this.updateCode;
	}

	/**
	 * 更新コードのsetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 更新コードを設定します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @param updateCode
	 *          更新コード
	 */
	public void setUpdateCode(String updateCode) {
		this.updateCode = updateCode;
	}

	/**
	 * 需要家識別番号のgetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 需要家識別番号を取得します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @return 需要家識別番号
	 */
	public String getContractorIdentificationNo() {
		return this.contractorIdentificationNo;
	}

	/**
	 * 需要家識別番号のsetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 需要家識別番号を設定します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @param contractorIdentificationNo
	 *          需要家識別番号
	 */
	public void setContractorIdentificationNo(String contractorIdentificationNo) {
		this.contractorIdentificationNo = contractorIdentificationNo;
	}

	/**
	 * 次回検針予定日のgetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 次回検針予定日を取得します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @return 次回検針予定日
	 */
	public Date getNextMeterReadingScheduledDate() {
		return this.nextMeterReadingScheduledDate;
	}

	/**
	 * 次回検針予定日のsetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 次回検針予定日を設定します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @param nextMeterReadingScheduledDate
	 *          次回検針予定日
	 */
	public void setNextMeterReadingScheduledDate(
			Date nextMeterReadingScheduledDate) {
		this.nextMeterReadingScheduledDate = nextMeterReadingScheduledDate;
	}

	/**
	 * 地点の最大需要電力のgetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 地点の最大需要電力を取得します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @return 地点の最大需要電力
	 */
	public Integer getSpotPeakDemand() {
		return spotPeakDemand;
	}

	/**
	 * 地点の最大需要電力のsetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 地点の最大需要電力を設定します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @param spotPeakDemand
	 *          地点の最大需要電力
	 */
	public void setSpotPeakDemand(Integer spotPeakDemand) {
		this.spotPeakDemand = spotPeakDemand;
	}

	/**
	 * メータ設置場所IDのgetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * メータ設置場所IDを取得します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @return メータ設置場所ID
	 */
	public Integer getMeterLocationId() {
		return this.meterLocationId;
	}

	/**
	 * メータ設置場所IDのsetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * メータ設置場所IDを設定します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @param meterLocationId
	 *          メータ設置場所ID
	 */
	public void setMeterLocationId(Integer meterLocationId) {
		this.meterLocationId = meterLocationId;
	}

	/**
	 * 計器識別番号1のgetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 計器識別番号1を取得します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @return 計器識別番号1
	 */
	public String getMeterIdentificationNo1() {
		return this.meterIdentificationNo1;
	}

	/**
	 * 計器識別番号1のsetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 計器識別番号1を設定します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @param meterIdentificationNo1
	 *          計器識別番号1
	 */
	public void setMeterIdentificationNo1(String meterIdentificationNo1) {
		this.meterIdentificationNo1 = meterIdentificationNo1;
	}

	/**
	 * 契約IDのgetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 契約IDを取得します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @return 契約ID
	 */
	public Integer getContractId() {
		return this.contractId;
	}

	/**
	 * 契約IDのsetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 契約IDを設定します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @param contractId
	 *          契約ID
	 */
	public void setContractId(Integer contractId) {
		this.contractId = contractId;
	}

	/**
	 * 契約番号のgetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 契約番号を取得します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @return 契約番号
	 */
	public String getContractNo() {
		return this.contractNo;
	}

	/**
	 * 契約番号のsetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 契約番号を設定します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @param contractNo
	 *          契約番号
	 */
	public void setContractNo(String contractNo) {
		this.contractNo = contractNo;
	}

	/**
	 * 契約開始日のgetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 契約開始日を取得します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @return 契約開始日
	 */
	public Date getContractStartDate() {
		return this.contractStartDate;
	}

	/**
	 * 契約開始日のsetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 契約開始日を設定します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @param contractStartDate
	 *          契約開始日
	 */
	public void setContractStartDate(Date contractStartDate) {
		this.contractStartDate = contractStartDate;
	}

	/**
	 * 契約終了日のgetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 契約終了日を取得します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @return 契約終了日
	 */
	public Date getContractEndDate() {
		return this.contractEndDate;
	}

	/**
	 * 契約終了日のsetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 契約終了日を設定します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @param contractEndDate
	 *          契約終了日
	 */
	public void setContractEndDate(Date contractEndDate) {
		this.contractEndDate = contractEndDate;
	}

	/**
	 * 契約終了理由コードのgetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 契約終了理由コードを取得します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @return 契約終了理由コード
	 */
	public String getContractEndReasonCode() {
		return this.contractEndReasonCode;
	}

	/**
	 * 契約終了理由コードのsetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 契約終了理由コードを設定します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @param contractEndReasonCode
	 *          契約終了理由コード
	 */
	public void setContractEndReasonCode(String contractEndReasonCode) {
		this.contractEndReasonCode = contractEndReasonCode;
	}

	/**
	 * 契約終了分確定使用量連携済フラグのgetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 契約終了分確定使用量連携済フラグを取得します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @return 契約終了分確定使用量連携済フラグ
	 */
	public String getContractEndFixUsageSentFlag() {
		return this.contractEndFixUsageSentFlag;
	}

	/**
	 * 契約終了分確定使用量連携済フラグのsetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 契約終了分確定使用量連携済フラグを設定します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @param contractEndFixUsageSentFlag
	 *          契約終了分確定使用量連携済フラグ
	 */
	public void setContractEndFixUsageSentFlag(String contractEndFixUsageSentFlag) {
		this.contractEndFixUsageSentFlag = contractEndFixUsageSentFlag;
	}

	/**
	 * 利用年月のgetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 利用年月を取得します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @return 利用年月
	 */
	public String getUsePeriod() {
		return this.usePeriod;
	}

	/**
	 * 利用年月のsetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 利用年月を設定します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @param usePeriod
	 *          利用年月
	 */
	public void setUsePeriod(String usePeriod) {
		this.usePeriod = usePeriod;
	}

	/**
	 * 算定期間開始日のgetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 算定期間開始日を取得します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @return 算定期間開始日
	 */
	public Date getCalculationTermStartDate() {
		return this.calculationTermStartDate;
	}

	/**
	 * 算定期間開始日のsetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 算定期間開始日を設定します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @param calculationTermStartDate
	 *          算定期間開始日
	 */
	public void setCalculationTermStartDate(Date calculationTermStartDate) {
		this.calculationTermStartDate = calculationTermStartDate;
	}

	/**
	 * 算定期間終了日のgetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 算定期間終了日を取得します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @return 算定期間終了日
	 */
	public Date getCalculationTermEndDate() {
		return this.calculationTermEndDate;
	}

	/**
	 * 算定期間終了日のsetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 算定期間終了日を設定します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @param calculationTermEndDate
	 *          算定期間終了日
	 */
	public void setCalculationTermEndDate(Date calculationTermEndDate) {
		this.calculationTermEndDate = calculationTermEndDate;
	}

	/**
	 * 対象使用量リストのgetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 対象使用量リストを取得します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @return 対象使用量リスト
	 */
	public List<RK_FixUsageApplyUsageBusinessBean> getCoveredUsageList() {
		return this.coveredUsageList;
	}

	/**
	 * 対象使用量リストのsetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 対象使用量リストを設定します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @param coveredUsageList
	 *          対象使用量リスト
	 */
	public void setCoveredUsageList(
			List<RK_FixUsageApplyUsageBusinessBean> coveredUsageList) {
		this.coveredUsageList = coveredUsageList;
	}

	/**
	 * 確定使用量IDのgetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 確定使用量IDを取得します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @return 確定使用量ID
	 */
	public Integer getFixUsageId() {
		return this.fixUsageId;
	}

	/**
	 * 確定使用量IDのsetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 確定使用量IDを設定します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @param fixUsageId
	 *          確定使用量ID
	 */
	public void setFixUsageId(Integer fixUsageId) {
		this.fixUsageId = fixUsageId;
	}

	/**
	 * 使用量のgetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 使用量を取得します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @return 使用量
	 */
	public BigDecimal getUsageQuantity() {
		return this.usageQuantity;
	}

	/**
	 * 使用量のsetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 使用量を設定します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @param usageQuantity
	 *          使用量
	 */
	public void setUsageQuantity(BigDecimal usageQuantity) {
		this.usageQuantity = usageQuantity;
	}

	/**
	 * バッチ実行日のgetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * バッチ実行日を取得します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @return 最大需要電力（参考）
	 */
	public Date getExecuteDate() {
		return this.executeDate;
	}

	/**
	 * バッチ実行日のsetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * バッチ実行日を設定します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @param usageQuantity
	 *          最大需要電力（参考）
	 */
	public void setExecuteDate(Date executeDate) {
		this.executeDate = executeDate;
	}

	/**
	 * スマートメータ区分コードのgetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * スマートメータ区分コードを取得します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @return スマートメータ区分コード
	 */
	public String getSmartMeterCategoryCode() {
		return this.smartMeterCategoryCode;
	}

	/**
	 * スマートメータ区分コードのsetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * スマートメータ区分コードを設定します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @param smartMeterCategoryCode
	 *          スマートメータ区分コード
	 */
	public void setSmartMeterCategoryCode(String smartMeterCategoryCode) {
		this.smartMeterCategoryCode = smartMeterCategoryCode;
	}

	/**
	 * 検針期間開始日のgetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 検針期間開始日を取得します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @return 検針期間開始日
	 */
	public Date getMeterReadingStartDate() {
		return this.meterReadingStartDate;
	}

	/**
	 * 検針期間開始日のsetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 検針期間開始日を設定します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @param meterReadingStartDate
	 *          検針期間開始日
	 */
	public void setMeterReadingStartDate(Date meterReadingStartDate) {
		this.meterReadingStartDate = meterReadingStartDate;
	}

	/**
	 * 検針期間終了日のgetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 検針期間終了日を取得します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @return 検針期間終了日
	 */
	public Date getMeterReadingEndDate() {
		return this.meterReadingEndDate;
	}

	/**
	 * 検針期間終了日のsetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 検針期間終了日を設定します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @param meterReadingEndDate
	 *          検針期間終了日
	 */
	public void setMeterReadingEndDate(Date meterReadingEndDate) {
		this.meterReadingEndDate = meterReadingEndDate;
	}

	/**
	 * 実量歴登録・更新要否フラグのgetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 実量歴登録・更新要否フラグを取得します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @return 実量歴登録・更新要否フラグ
	 */
	public Boolean getRealQuantityNeedUpAddFlag() {
		return realQuantityNeedUpAddFlag;
	}

	/**
	 * 実量歴登録・更新要否フラグのsetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 実量歴登録・更新要否フラグを設定します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @param realQuantityNeedUpAddFlag
	 *          実量歴登録・更新要否フラグ
	 */
	public void setRealQuantityNeedUpAddFlag(Boolean realQuantityNeedUpAddFlag) {
		this.realQuantityNeedUpAddFlag = realQuantityNeedUpAddFlag;
	}

	/**
	 * 検針日区分コードのgetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 検針日区分コードを取得します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @return 検針日区分コード
	 */
	public String getMeterReadingDateCategoryCode() {
		return this.meterReadingDateCategoryCode;
	}

	/**
	 * 検針日区分コードのsetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 検針日区分コードを設定します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @param meterReadingDateCategoryCode
	 *          検針日区分コード
	 */
	public void setMeterReadingDateCategoryCode(String meterReadingDateCategoryCode) {
		this.meterReadingDateCategoryCode = meterReadingDateCategoryCode;
	}

	/**
	 * 臨時検針最大電力のgetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 臨時検針最大電力を取得します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @return 臨時検針最大電力
	 */
	public BigDecimal getTemporaryMeterReadingPeakDemand() {
		return temporaryMeterReadingPeakDemand;
	}

	/**
	 * 臨時検針最大電力のsetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 臨時検針最大電力を設定します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @param temporaryMeterReadingPeakDemand
	 *          臨時検針最大電力
	 */
	public void setTemporaryMeterReadingPeakDemand(BigDecimal temporaryMeterReadingPeakDemand) {
		this.temporaryMeterReadingPeakDemand = temporaryMeterReadingPeakDemand;
	}

	/**
	 * 送受電区分コードのgetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 送受電区分コードを取得します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @return 送受電区分コード
	 */
	public String getTransmissionCatCode() {
		return transmissionCatCode;
	}

	/**
	 * 送受電区分コードのsetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 送受電区分コードを設定します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @param transmissionCatCode
	 *          送受電区分コード
	 */
	public void setTransmissionCatCode(String transmissionCatCode) {
		this.transmissionCatCode = transmissionCatCode;
	}

	/**
	 * 月間電力量全量のgetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 月間電力量全量を取得します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @return 月間電力量全量
	 */
	public Long getMonthlyTotalKwh() {
		return monthlyTotalKwh;
	}

	/**
	 * 月間電力量全量のsetter。
	 *
	 * <pre>
	 * <p><b>【仕様詳細】</b></p>
	 * 月間電力量全量を設定します。
	 * </pre>
	 *
	 * @author "Nihon Unisys, Ltd."
	 * @param monthlyTotalKwh
	 *         月間電力量全量
	 */
	public void setMonthlyTotalKwh(Long monthlyTotalKwh) {
		this.monthlyTotalKwh = monthlyTotalKwh;
	}

}
