package jp.co.unisys.enability.cis.business.rk.model;

import java.math.BigDecimal;
import java.sql.Timestamp;

/**
 * 計算用指示数ビジネスBean。
 *
 * <pre>
 * <p>
 * <b>【使用ビジネス】</b>
 * </p>
 * 計算用使用量登録ビジネス。
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_CalcForIndicationNoBusinessBean {

  /**
   * 契約ID
   */
  Integer contractId;

  /**
   * 利用年月
   */
  String usePeriod;

  /**
   * 計器区分コード
   */
  String meterCategoryCode;

  /**
   * 指示数算出使用量
   */
  BigDecimal indicationNoCalculationUsage;

  /**
   * 更新回数
   */
  Integer updateCount;

  /**
   * 作成日時
   */
  Timestamp createTime;

  /**
   * オンライン更新日時
   */
  Timestamp onlineUpdateTime;

  /**
   * オンライン更新ユーザID
   */
  String onlineUpdateUserId;

  /**
   * 更新日時
   */
  Timestamp updateTime;

  /**
   * 更新モジュールコード
   */
  String updateModuleCode;

  /**
   * 契約IDのgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約IDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約ID
   */
  public Integer getContractId() {
    return contractId;
  }

  /**
   * 契約IDのsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約IDを設定する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractId
   *          契約ID
   */
  public void setContractId(Integer contractId) {
    this.contractId = contractId;
  }

  /**
   * 利用年月のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 利用年月を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 利用年月
   */
  public String getUsePeriod() {
    return usePeriod;
  }

  /**
   * 利用年月のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 利用年月を設定する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param usePeriod
   *          利用年月
   */
  public void setUsePeriod(String usePeriod) {
    this.usePeriod = usePeriod;
  }

  /**
   * 計器区分コードのgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計器区分コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 計器区分コード
   */
  public String getMeterCategoryCode() {
    return meterCategoryCode;
  }

  /**
   * 計器区分コードのsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計器区分コードを設定する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param meterCategoryCode
   *          計器区分コード
   */
  public void setMeterCategoryCode(String meterCategoryCode) {
    this.meterCategoryCode = meterCategoryCode;
  }

  /**
   * 指示数算出使用量のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 指示数算出使用量を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 指示数算出使用量
   */
  public BigDecimal getIndicationNoCalculationUsage() {
    return indicationNoCalculationUsage;
  }

  /**
   * 指示数算出使用量のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 指示数算出使用量を設定する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param indicationNoCalculationUsage
   *          指示数算出使用量
   */
  public void setIndicationNoCalculationUsage(
      BigDecimal indicationNoCalculationUsage) {
    this.indicationNoCalculationUsage = indicationNoCalculationUsage;
  }

  /**
   * 更新回数のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 更新回数を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 更新回数
   */
  public Integer getUpdateCount() {
    return updateCount;
  }

  /**
   * 更新回数のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 更新回数を設定する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param updateCount
   *          更新回数
   */
  public void setUpdateCount(Integer updateCount) {
    this.updateCount = updateCount;
  }

  /**
   * 作成日時のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 作成日時を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 作成日時
   */
  public Timestamp getCreateTime() {
    return createTime;
  }

  /**
   * 作成日時のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 作成日時を設定する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param createTime
   *          作成日時
   */
  public void setCreateTime(Timestamp createTime) {
    this.createTime = createTime;
  }

  /**
   * オンライン更新日時のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * オンライン更新日時を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return オンライン更新日時
   */
  public Timestamp getOnlineUpdateTime() {
    return onlineUpdateTime;
  }

  /**
   * オンライン更新日時のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * オンライン更新日時を設定する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param onlineUpdateTime
   *          オンライン更新日時
   */
  public void setOnlineUpdateTime(Timestamp onlineUpdateTime) {
    this.onlineUpdateTime = onlineUpdateTime;
  }

  /**
   * オンライン更新ユーザIDのgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * オンライン更新ユーザIDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return オンライン更新ユーザID
   */
  public String getOnlineUpdateUserId() {
    return onlineUpdateUserId;
  }

  /**
   * オンライン更新ユーザIDのsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * オンライン更新ユーザIDを設定する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param onlineUpdateUserId
   *          オンライン更新ユーザID
   */
  public void setOnlineUpdateUserId(String onlineUpdateUserId) {
    this.onlineUpdateUserId = onlineUpdateUserId;
  }

  /**
   * 更新日時のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 更新日時を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 更新日時
   */
  public Timestamp getUpdateTime() {
    return updateTime;
  }

  /**
   * 更新日時のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 更新日時を設定する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param updateTime
   *          更新日時
   */
  public void setUpdateTime(Timestamp updateTime) {
    this.updateTime = updateTime;
  }

  /**
   * 更新モジュールコードのgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 更新モジュールコードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 更新モジュールコード
   */
  public String getUpdateModuleCode() {
    return updateModuleCode;
  }

  /**
   * 更新モジュールコードのsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 更新モジュールコードを設定する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param updateModuleCode
   *          更新モジュールコード
   */
  public void setUpdateModuleCode(String updateModuleCode) {
    this.updateModuleCode = updateModuleCode;
  }
}
