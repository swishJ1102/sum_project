package jp.co.unisys.enability.cis.business.rk;

import java.util.Date;
import java.util.List;

import jp.co.unisys.enability.cis.business.rk.model.RK_UsageLinkageCheckCheckDataBusinessBean;
import jp.co.unisys.enability.cis.business.rk.model.RK_UsageLinkageCheckTermDecisionBusinessBean;
import jp.co.unisys.enability.cis.common.util.StringConvertUtil;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;
import jp.co.unisys.enability.cis.dao.rk.RK_UsageLinkageCheckDao;
import jp.co.unisys.enability.cis.entity.rk.RK_UsageLinkageCheckEndFixUsageNotLinkedEntityBean;

/**
 * 同一地点廃止分未到達チェックビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.rk.RK_UsageLinkageCheckBusiness
 */
public class RK_CheckOrderOfLinkageBusinessImpl implements
    RK_CheckFixUsageBusiness {

  /** 料金計算チェックビジネス(DI) */
  private RK_UsageLinkageCheckBusiness rkUsageLinkageCheckBusiness;

  /** 使用量連携チェックDao(DI) */
  private RK_UsageLinkageCheckDao rkUsageLinkageCheckDao;

  /**
   * 同一地点廃止分未到達チェック。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 廃止分の確定使用量メッセージが連携されるより前に、再点分が連携されていないか判定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param checkDataBusinessBean
   *          チェック対象ビジネスBean
   * @param termDecisionBusinessBean
   *          期間判定情報ビジネスBean
   * @return true:処理継続、false:処理終了
   */
  @Override
  public boolean check(
      RK_UsageLinkageCheckCheckDataBusinessBean checkDataBusinessBean,
      RK_UsageLinkageCheckTermDecisionBusinessBean termDecisionBusinessBean) {

    // 継続フラグ
    boolean continuation = true;

    // 使用量対象期間より前に契約が終了していて、
    // 契約終了分確定使用量連携済フラグが"OFF"の契約情報を取得する
    List<RK_UsageLinkageCheckEndFixUsageNotLinkedEntityBean> contractList = rkUsageLinkageCheckDao
        .selectEndFixUsageNotLinked(checkDataBusinessBean.getSpotNo(),
            termDecisionBusinessBean.getCoveredTermStartDate());

    // 契約情報が存在した場合は、TODOを登録する
    if (!contractList.isEmpty()) {

      // TODOメッセージに登録する契約情報
      StringBuilder contractInfo = new StringBuilder();

      // 契約情報ごとに繰り返し、すべての契約情報を列挙する
      for (RK_UsageLinkageCheckEndFixUsageNotLinkedEntityBean contract : contractList) {

        // 契約情報を設定
        // 契約番号
        contractInfo.append(contract.getContractNo());
        // 全角空白
        contractInfo
            .append(ECISRKConstants.DELIMITER_ITEMS_SPACE_ZENKAKU);
        // 契約期間開始日
        contractInfo
            .append(formatDate(contract.getContractStartDate()));
        // ～
        contractInfo.append(ECISRKConstants.TERM_NAMISEN_ZENKAKU);
        // 契約期間終了日
        contractInfo.append(formatDate(contract.getContractEndDate()));

        // 区切り文字
        contractInfo
            .append(ECISRKConstants.DELIMITER_METER_CATEGORY_CODE_COMMA);
      }

      // 末尾の区切り文字を削除する
      contractInfo.setLength(contractInfo.length()
          - ECISRKConstants.DELIMITER_METER_CATEGORY_CODE_COMMA
              .length());

      // TODOメッセージに登録する対象期間
      StringBuilder coveredTerm = new StringBuilder();

      // 確定使用量の対象期間を"yyyy/MM/dd～yyyy/MM/dd"の形式で文字列化
      // 対象期間開始日
      coveredTerm.append(formatDate(termDecisionBusinessBean
          .getCoveredTermStartDate()));
      // ～
      coveredTerm.append(ECISRKConstants.TERM_NAMISEN_ZENKAKU);
      // 対象期間終了日
      coveredTerm.append(formatDate(termDecisionBusinessBean
          .getCoveredTermEndDate()));

      // TODOメッセージを作成するパラメータ
      String[] params = {
          // 確定使用量ファイル名
          checkDataBusinessBean.getFixUsageFileName(),
          // 地点特定番号
          checkDataBusinessBean.getSpotNo(),
          // エリアコード
          checkDataBusinessBean.getAreaCode(),
          // 処理日
          formatDate(checkDataBusinessBean.getExecuteDate()),
          // 使用量対象期間
          coveredTerm.toString(),
          // 契約番号と需給期間
          contractInfo.toString() };

      // TODO登録
      rkUsageLinkageCheckBusiness.registerTodo("todo.T1023", null, "todo.T1041", params, null,
          checkDataBusinessBean.getSpotNo(), null);

      // ※このチェックでエラーとなってもチェック処理は継続するため、継続フラグは設定しない
    }

    return continuation;
  }

  /**
   * 日付を"yyyy/MM/dd"形式の文字列に変換する。
   *
   * @param targetDate
   *          変換対象の日付
   * @return 変換後の文字列
   */
  private String formatDate(Date targetDate) {
    return StringConvertUtil.convertDateToString(targetDate,
        ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH);
  }

  /**
   * 料金計算チェックビジネスを設定します。(DI)
   * 
   * @param rkUsageLinkageCheckBusiness
   *          料金計算チェックビジネス
   */
  public void setRkUsageLinkageCheckBusiness(
      RK_UsageLinkageCheckBusiness rkUsageLinkageCheckBusiness) {
    this.rkUsageLinkageCheckBusiness = rkUsageLinkageCheckBusiness;
  }

  /**
   * 使用量連携チェックDaoを設定します。(DI)
   * 
   * @param rkUsageLinkageCheckDao
   *          使用量連携チェックDao
   */
  public void setRkUsageLinkageCheckDao(RK_UsageLinkageCheckDao rkUsageLinkageCheckDao) {
    this.rkUsageLinkageCheckDao = rkUsageLinkageCheckDao;
  }

}
