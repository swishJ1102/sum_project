package jp.co.unisys.enability.cis.business.sn;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;
import org.springframework.context.MessageSource;

import jp.co.unisys.enability.cis.business.gk.GK_WorkCommonBusiness;
import jp.co.unisys.enability.cis.business.sn.model.SN_BillingDetailInfoBusinessBean;
import jp.co.unisys.enability.cis.business.sn.model.SN_BillingRequestDataBusinessBean;
import jp.co.unisys.enability.cis.common.Exception.SystemException;
import jp.co.unisys.enability.cis.common.util.EMSConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISCodeConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.entity.common.AcInformation;
import jp.co.unisys.enability.cis.entity.common.Bl;
import jp.co.unisys.enability.cis.entity.common.Contract;
import jp.co.unisys.enability.cis.entity.common.Contractor;
import jp.co.unisys.enability.cis.entity.common.PaymentHist;
import jp.co.unisys.enability.cis.entity.common.Place;
import jp.co.unisys.enability.cis.entity.common.PmCompanyM;
import jp.co.unisys.enability.cis.entity.common.UrgeMng;

/**
 * 請求依頼データ作成ビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class SN_CreateBillingRequestDataBusinessImpl implements
    SN_CreateBillingRequestDataBusiness {

  /** プロパティファイル取得キー：請求依頼データ作成：請求区分コード */
  private static final String BL_CAT_CODE = "business.sn.requestfile.blcatcode";

  /** プロパティファイル取得キー：請求依頼データ作成：決済予定日 */
  private static final String SETTLEMENT_SCHEDULED_DATE = "business.sn.requestfile.settlementscheduleddate";

  /** プロパティファイル取得キー：請求依頼データ作成：請求番号 */
  private static final String BL_NO = "business.sn.requestfile.blno";

  /** プロパティファイル取得キー：請求依頼データ作成：契約者番号 */
  private static final String CONTRACTOR_NO = "business.sn.requestfile.contractorno";

  /** プロパティファイル取得キー：請求依頼データ作成：請求先住所_宛先郵便番号 */
  private static final String BL_ADDRESS_POSTAL_CODE = "business.sn.requestfile.bladdresspostalcode";

  /** プロパティファイル取得キー：請求依頼データ作成：請求先住所（都道府県名） */
  private static final String BL_ADDRESS_PREFECTURES = "business.sn.requestfile.bladdressprefectures";

  /** プロパティファイル取得キー：請求依頼データ作成：請求先住所（市区郡町村名） */
  private static final String BL_ADDRESS_MUNICIPALITY = "business.sn.requestfile.bladdressmunicipality";

  /** プロパティファイル取得キー：請求依頼データ作成：請求先住所（字名・丁目） */
  private static final String BL_ADDRESS_SECTION = "business.sn.requestfile.bladdresssection";

  /** プロパティファイル取得キー：請求依頼データ作成：請求先住所（番地・号） */
  private static final String BL_ADDRESS_BLOCK = "business.sn.requestfile.bladdressblock";

  /** プロパティファイル取得キー：請求依頼データ作成：請求先住所（建物名） */
  private static final String BL_ADDRESS_BUILDING_NAME = "business.sn.requestfile.bladdressbuildingname";

  /** プロパティファイル取得キー：請求依頼データ作成：請求先住所（部屋名） */
  private static final String BL_ADDRESS_ROOM = "business.sn.requestfile.bladdressroom";

  /** プロパティファイル取得キー：請求依頼データ作成：請求先氏名1 */
  private static final String BL_NAME_1 = "business.sn.requestfile.blname1";

  /** プロパティファイル取得キー：請求依頼データ作成：請求先氏名2 */
  private static final String BL_NAME_2 = "business.sn.requestfile.blname2";

  /** プロパティファイル取得キー：請求依頼データ作成：請求先情報_敬称 */
  private static final String BL_PREFIX = "business.sn.requestfile.bl.prefix";

  /** プロパティファイル取得キー：請求依頼データ作成：契約者住所_宛先郵便番号 */
  private static final String CA_POSTAL_CODE = "business.sn.requestfile.capostalcode";

  /** プロパティファイル取得キー：請求依頼データ作成：契約者住所（都道府県名） */
  private static final String CA_PREFECTURES = "business.sn.requestfile.caprefectures";

  /** プロパティファイル取得キー：請求依頼データ作成：契約者住所（市区郡町村名） */
  private static final String CA_MUNICIPALITY = "business.sn.requestfile.camunicipality";

  /** プロパティファイル取得キー：請求依頼データ作成：契約者住所（字名・丁目） */
  private static final String CA_SECTION = "business.sn.requestfile.casection";

  /** プロパティファイル取得キー：請求依頼データ作成：契約者住所（番地･号） */
  private static final String CA_BLOCK = "business.sn.requestfile.cablock";

  /** プロパティファイル取得キー：請求依頼データ作成：契約者住所（建物名） */
  private static final String CA_BUILDING_NAME = "business.sn.requestfile.cabuildingname";

  /** プロパティファイル取得キー：請求依頼データ作成：契約者住所（部屋名） */
  private static final String CA_ROOM = "business.sn.requestfile.caroom";

  /** プロパティファイル取得キー：請求依頼データ作成：契約者名1（宛名用） */
  private static final String CN_1_MAILING_NAME = "business.sn.requestfile.cn1mailingname";

  /** プロパティファイル取得キー：請求依頼データ作成：契約者名2（宛名用） */
  private static final String CN_2_MAILING_NAME = "business.sn.requestfile.cn2mailingname";

  /** プロパティファイル取得キー：請求依頼データ作成：契約者情報_敬称 */
  private static final String CONTRACTOR_PREFIX = "business.sn.requestfile.contractor.prefix";

  /** プロパティファイル取得キー：請求依頼データ作成：契約者名1 */
  private static final String CN_1 = "business.sn.requestfile.cn1";

  /** プロパティファイル取得キー：請求依頼データ作成：契約者名2 */
  private static final String CN_2 = "business.sn.requestfile.cn2";

  /** プロパティファイル取得キー：請求依頼データ作成：支払期日 */
  private static final String PFD = "business.sn.requestfile.pfd";

  /** プロパティファイル取得キー：請求依頼データ作成：利用年月 */
  private static final String USE_PERIOD = "business.sn.requestfile.useperiod";

  /** プロパティファイル取得キー：請求依頼データ作成：請求額 */
  private static final String BL_AMOUNT = "business.sn.requestfile.blamount";

  /** プロパティファイル取得キー：請求依頼データ作成：消費税相当額 */
  private static final String CT_EQUIVALENT = "business.sn.requestfile.ctequivalent";

  /** プロパティファイル取得キー：請求依頼データ作成：ご利用金額 */
  private static final String USE_AMOUNT = "business.sn.requestfile.useamount";

  /** プロパティファイル取得キー：請求依頼データ作成：預り金等 */
  private static final String DEPOSITS_RECEIVED = "business.sn.requestfile.depositsreceived";

  /** プロパティファイル取得キー：請求依頼データ作成：契約数計 */
  private static final String TOTAL_CONTRACT = "business.sn.requestfile.totalcontract";

  /** プロパティファイル取得キー：請求依頼データ作成：アクセスキー */
  private static final String ACCESS_KEY = "business.sn.requestfile.accesskey";

  /** プロパティファイル取得キー：請求依頼データ作成：振込先金融機関コード */
  private static final String BANK_CODE = "business.sn.requestfile.bankcode";

  /** プロパティファイル取得キー：請求依頼データ作成：振込先金融機関名 */
  private static final String BANK_NAME = "business.sn.requestfile.bankname";

  /** プロパティファイル取得キー：請求依頼データ作成：振込先金融機関支店コード */
  private static final String BANK_BRANCH_CODE = "business.sn.requestfile.bankbranchcode";

  /** プロパティファイル取得キー：請求依頼データ作成：振込先金融機関支店名 */
  private static final String BANK_BRANCH_NAME = "business.sn.requestfile.bankbranchname";

  /** プロパティファイル取得キー：請求依頼データ作成：振込先預金種目コード */
  private static final String BT_OF_ACCOUNT_CODE = "business.sn.requestfile.btofaccountcode";

  /** プロパティファイル取得キー：請求依頼データ作成：振込先預金種目 */
  private static final String BT_OF_ACCOUNT = "business.sn.requestfile.btofaccount";

  /** プロパティファイル取得キー：請求依頼データ作成：振込先口座番号 */
  private static final String ACCOUNT_NO = "business.sn.requestfile.accountno";

  /** プロパティファイル取得キー：請求依頼データ作成：振込先口座名義 */
  private static final String ACCOUNT_HOLDER_NAME = "business.sn.requestfile.accountholdername";

  /** プロパティファイル取得キー：請求依頼データ作成：郵送先（郵便番号） */
  private static final String ADDRESSEE_POSTAL_CODE = "business.sn.requestfile.addresseepostalcode";

  /** プロパティファイル取得キー：請求依頼データ作成：郵送先（都道府県名） */
  private static final String ADDRESSEE_PREFECTURES = "business.sn.requestfile.addresseeprefectures";

  /** プロパティファイル取得キー：請求依頼データ作成：郵送先（市区郡町村名） */
  private static final String ADDRESSEE_MUNICIPALITY = "business.sn.requestfile.addresseemunicipality";

  /** プロパティファイル取得キー：請求依頼データ作成：郵送先（字名・丁目） */
  private static final String ADDRESSEE_SECTION = "business.sn.requestfile.addresseesection";

  /** プロパティファイル取得キー：請求依頼データ作成：郵送先（番地・号） */
  private static final String ADDRESSEE_BLOCK = "business.sn.requestfile.addresseeblock";

  /** プロパティファイル取得キー：請求依頼データ作成：郵送先（建物名） */
  private static final String ADDRESSEE_BUILDING_NAME = "business.sn.requestfile.addresseebuildingname";

  /** プロパティファイル取得キー：請求依頼データ作成：郵送先（部屋名） */
  private static final String ADDRESSEE_ROOM = "business.sn.requestfile.addresseeroom";

  /** プロパティファイル取得キー：請求依頼データ作成：提供モデル企業 */
  private static final String PM_COMPANY = "business.sn.requestfile.pmcompany";

  /** プロパティファイル取得キー：請求依頼データ作成：郵送先（宛名１） */
  private static final String ADDRESSEE_MAILING_NAME_1 = "business.sn.requestfile.addresseemailingname1";

  /** プロパティファイル取得キー：請求依頼データ作成：郵送先（宛名２） */
  private static final String ADDRESSEE_MAILING_NAME_2 = "business.sn.requestfile.addresseemailingname2";

  /** プロパティファイル取得キー：請求依頼データ作成：郵送先_敬称 */
  private static final String ADDRESSEE_PREFIX = "business.sn.requestfile.addresseeprefix";

  /** プロパティファイル取得キー：請求依頼ファイル：お知らせ */
  private static final String BL_REQUEST_FILE_NOTICE = "business.sn.requestfile.notice";

  /** プロパティファイル取得キー：請求依頼ファイル：内訳 ご請求分（単独） */
  private static final String BL_REQUEST_FILE_BREAKDOWN_BLMONTH = "business.sn.requestfile.breakdown.blmonth";

  /** プロパティファイル取得キー：請求依頼ファイル：内訳 ご請求分（まとめ・合算） */
  private static final String BL_REQUEST_FILE_BREAKDOWN_BLMONTH_SUMMARY = "business.sn.requestfile.breakdown.blmonth.summary";

  /** プロパティファイル取得キー：請求依頼ファイル：内訳 電気ご利用料金 */
  private static final String BL_REQUEST_FILE_BREAKDOWN_USEAMOUNT = "business.sn.requestfile.breakdown.useamount";

  /** プロパティファイル取得キー：請求依頼ファイル：内訳 消費税相当額 */
  private static final String BL_REQUEST_FILE_BREAKDOWN_CTEQUIVALENT = "business.sn.requestfile.breakdown.ctequivalent";

  /** プロパティファイル取得キー：請求依頼ファイル：内訳 預り金 */
  private static final String BL_REQUEST_FILE_BREAKDOWN_DEPOSITSRECEIVED = "business.sn.requestfile.breakdown.depositsreceived";

  /** プロパティファイル取得キー：請求依頼ファイル：内訳 契約番号（単独） */
  private static final String BL_REQUEST_FILE_BREAKDOWN_CONTRACTNO = "business.sn.requestfile.breakdown.contractno";

  /** プロパティファイル取得キー：請求依頼ファイル：内訳 契約番号（まとめ） */
  private static final String BL_REQUEST_FILE_BREAKDOWN_CONTRACTNO_SUMMARY = "business.sn.requestfile.breakdown.contractno.summary";

  /** プロパティファイル取得キー：請求依頼ファイル：内訳 ご使用場所 */
  private static final String BL_REQUEST_FILE_BREAKDOWN_PLACE = "business.sn.requestfile.breakdown.place";

  /** プロパティファイル取得キー：請求依頼ファイル：内訳 合算1 */
  private static final String BL_REQUEST_FILE_BREAKDOWN_ADDUP1 = "business.sn.requestfile.breakdown.addup1";

  /** プロパティファイル取得キー：請求依頼ファイル：内訳 合算2 */
  private static final String BL_REQUEST_FILE_BREAKDOWN_ADDUP2 = "business.sn.requestfile.breakdown.addup2";

  /** データ区分：データ */
  private static final String DATA_CATEGORY_DATA = "2";

  /** 年（終了位置） */
  private static final int YYYY_END = 4;

  /** 月（終了位置） */
  private static final int MM_END = 6;

  /** 需要場所住所区切り位置（バイト数） */
  private static final int DELIMTER_PLACE_ADDRESS = 52;

  /** 需要場所住所１行目 */
  private static final int PLACE_ADDRESS_1LINE = 0;

  /** 需要場所住所２行目 */
  private static final int PLACE_ADDRESS_2LINE = 1;

  /** 需要場所住所３行目 */
  private static final int PLACE_ADDRESS_3LINE = 2;

  /** 需要場所住所４行目 */
  private static final int PLACE_ADDRESS_4LINE = 3;

  /** 郵便番号上３桁（終了位置） */
  private static final int POSTAL_CODE1_END = 3;

  /** 郵便番号下４桁（終了位置） */
  private static final int POSTAL_CODE2_END = 7;

  /** 業務共通ビジネス(DI) */
  private GK_WorkCommonBusiness gkWorkCommonBusiness;

  /** メッセージプロパティ(DI) */
  private MessageSource messageSource;

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.sn.SN_CreateBillingRequestDataBeanBusiness
   * #createBillingRequestDataBeanForAccountAndCredit(SN_BillingDetailInfoBusinessBean, String, Properties)
   */
  @Override
  public SN_BillingRequestDataBusinessBean createBillingRequestDataBeanForAccountAndCredit(
      SN_BillingDetailInfoBusinessBean bean, String consignerCode, Properties prop) {

    SN_BillingRequestDataBusinessBean snBillingRequestDataBusinessBean = new SN_BillingRequestDataBusinessBean();

    // 共通設定
    this.createRequestDataCommon(bean, consignerCode, snBillingRequestDataBusinessBean, prop);

    /*
     * 以下の項目は未設定
     */
    // ■お知らせ
    // ■内訳01・名称
    // ■内訳01・金額
    // ■内訳02・名称
    // ■内訳02・金額
    // ■内訳03・名称
    // ■内訳03・金額
    // ■内訳04・名称
    // ■内訳04・金額
    // ■内訳05・名称
    // ■内訳05・金額
    // ■内訳06・名称
    // ■内訳06・金額
    // ■内訳07・名称
    // ■内訳07・金額
    // ■内訳08・名称
    // ■内訳08・金額
    // ■内訳09・名称
    // ■内訳09・金額
    // ■内訳10・名称
    // ■内訳10・金額
    // ■内訳11・名称
    // ■内訳11・金額
    // ■内訳12・名称
    // ■内訳12・金額
    // ■内訳13・名称
    // ■内訳13・金額

    /*
     * 汎用化のため、他の項目も設定しておく。
     */
    this.setBillingRequestDataBusinessBean(bean, snBillingRequestDataBusinessBean, false);

    return snBillingRequestDataBusinessBean;

  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.sn.SN_CreateBillingRequestDataBeanBusiness
   * #createBillingRequestDataBeanForConveniAndTransfer(SN_BillingDetailInfoBusinessBean, String, Properties)
   */
  @Override
  public SN_BillingRequestDataBusinessBean createBillingRequestDataBeanForConveniAndTransfer(
      SN_BillingDetailInfoBusinessBean bean, String consignerCode, Properties prop) {

    SN_BillingRequestDataBusinessBean snBillingRequestDataBusinessBean = new SN_BillingRequestDataBusinessBean();

    // 共通設定
    this.createRequestDataCommon(bean, consignerCode, snBillingRequestDataBusinessBean, prop);

    if (bean.getCancellationPreviousNoticeFlg()) {
      // 当該請求のデータが解約予告対象の場合
      // ■お知らせ
      snBillingRequestDataBusinessBean.setNotification(gkWorkCommonBusiness.evaluateStringVelocity(
          getProp(prop, BL_REQUEST_FILE_NOTICE), bean));
    }
    // ■内訳01・名称
    if (ECISConstants.FLG_OFF.equals(bean.getBl().getCombinedBlFlag())
        && ECISConstants.FLG_OFF.equals(bean.getBl().getAddUpBlFlag())) {
      // 《請求明細情報Bean》の「まとめ請求フラグ」および「合算請求フラグ」の双方が"OFF"の場合
      if (bean.getFcrList().get(0).getCcSd() != null && bean.getFcrList().get(0).getCcEd() != null) {
        snBillingRequestDataBusinessBean.setBreakdown01Name(gkWorkCommonBusiness.evaluateStringVelocity(
            getProp(prop, BL_REQUEST_FILE_BREAKDOWN_BLMONTH), bean));
      }
    } else {
      // 《請求明細情報Bean》の「まとめ請求フラグ」および「合算請求フラグ」のどちらかが"ON"の場合
      snBillingRequestDataBusinessBean.setBreakdown01Name(gkWorkCommonBusiness.evaluateStringVelocity(
          getProp(prop, BL_REQUEST_FILE_BREAKDOWN_BLMONTH_SUMMARY), bean));
    }
    // ■内訳01・金額 未設定
    // ■内訳02・名称
    snBillingRequestDataBusinessBean.setBreakdown02Name(gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, BL_REQUEST_FILE_BREAKDOWN_USEAMOUNT), bean));
    // ■内訳02・金額
    snBillingRequestDataBusinessBean.setBreakdown02Amount(gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, USE_AMOUNT), bean));
    // ■内訳03・名称
    snBillingRequestDataBusinessBean.setBreakdown03Name(gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, BL_REQUEST_FILE_BREAKDOWN_CTEQUIVALENT), bean));
    // ■内訳03・金額
    snBillingRequestDataBusinessBean.setBreakdown03Amount(gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, CT_EQUIVALENT), bean));

    // 《請求明細情報Bean》.預り金が0でない場合に設定
    String editDepositsReceived = gkWorkCommonBusiness.evaluateStringVelocity(getProp(prop, DEPOSITS_RECEIVED),
        bean);
    if (Integer.valueOf(editDepositsReceived) != 0) {
      // ■内訳04・名称
      snBillingRequestDataBusinessBean.setBreakdown04Name(gkWorkCommonBusiness.evaluateStringVelocity(
          getProp(prop, BL_REQUEST_FILE_BREAKDOWN_DEPOSITSRECEIVED), bean));
      // ■内訳04・金額
      snBillingRequestDataBusinessBean.setBreakdown04Amount(EMSConstants.MINUS + editDepositsReceived);
    }
    // ■内訳05・名称 未設定
    // ■内訳05・金額 未設定
    // ■内訳06・名称
    if (ECISConstants.FLG_OFF.equals(bean.getBl().getCombinedBlFlag())) {
      // 【請求】の「まとめ請求フラグ」が"OFF"の場合
      snBillingRequestDataBusinessBean.setBreakdown06Name(gkWorkCommonBusiness.evaluateStringVelocity(
          getProp(prop, BL_REQUEST_FILE_BREAKDOWN_CONTRACTNO), bean));
    } else {
      // 【請求】の「まとめ請求フラグ」が"ON"の場合
      snBillingRequestDataBusinessBean.setBreakdown06Name(gkWorkCommonBusiness.evaluateStringVelocity(
          getProp(prop, BL_REQUEST_FILE_BREAKDOWN_CONTRACTNO_SUMMARY), bean));
    }
    // ■内訳06・金額 未設定
    // ■内訳07・名称
    snBillingRequestDataBusinessBean.setBreakdown07Name(gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, BL_REQUEST_FILE_BREAKDOWN_PLACE), bean));
    // ■内訳07・金額 未設定
    // ■内訳08・名称～内訳11・名称
    if (bean.getPlace() != null) {
      // 需要場所情報が取得できた場合、需要場所住所を設定する。
      this.setPlaceAddress(bean, snBillingRequestDataBusinessBean, prop);
    }
    // ■内訳08・金額 未設定
    // ■内訳09・金額 未設定
    // ■内訳10・金額 未設定
    // ■内訳11・金額 未設定
    // ■内訳12・名称
    if (ECISConstants.FLG_ON.equals(bean.getBl().getAddUpBlFlag())) {
      // 【請求】の「合算請求フラグ」が"ON"の場合
      snBillingRequestDataBusinessBean.setBreakdown12Name(gkWorkCommonBusiness.evaluateStringVelocity(
          getProp(prop, BL_REQUEST_FILE_BREAKDOWN_ADDUP1), bean));
    }
    // ■内訳12・金額 未設定
    // ■内訳13・名称
    if (ECISConstants.FLG_ON.equals(bean.getBl().getAddUpBlFlag())) {
      // 【請求】の「合算請求フラグ」が"ON"の場合
      snBillingRequestDataBusinessBean.setBreakdown13Name(gkWorkCommonBusiness.evaluateStringVelocity(
          getProp(prop, BL_REQUEST_FILE_BREAKDOWN_ADDUP2), bean));
    }
    // ■内訳13・金額 未設定
    /*
     * 汎用化のため、他の項目も設定しておく。
     */
    this.setBillingRequestDataBusinessBean(bean, snBillingRequestDataBusinessBean, false);

    return snBillingRequestDataBusinessBean;

  }

  /**
   * 需要場所住所設定
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 内訳欄の需要場所住所を設定する。
   * </pre>
   *
   * @param bean
   *          請求明細情報Bean
   * @param snBillingRequestDataBusinessBean
   *          請求依頼データBean
   * @param prop
   *          プロパティオブジェクト
   */
  private void setPlaceAddress(SN_BillingDetailInfoBusinessBean bean,
      SN_BillingRequestDataBusinessBean snBillingRequestDataBusinessBean, Properties prop) {

    StringBuilder sb = new StringBuilder();
    // 需要場所住所（住所）
    sb.append(bean.getPlace().getPlaceAddressFull());
    if (StringUtils.isNotEmpty(bean.getPlace().getPlaceAddressBuilding())) {
      // 需要場所住所（建物・部屋名）に設定がある場合
      sb.append(EMSConstants.SPACE_ZENKAKU);
      sb.append(bean.getPlace().getPlaceAddressBuilding());
    }
    if (ECISConstants.FLG_ON.equals(bean.getBl().getCombinedBlFlag())) {
      // 【請求】の「まとめ請求フラグ」が"ON"の場合
      sb.append(EMSConstants.SPACE_ZENKAKU);
      sb.append(ECISConstants.OTHER);
    }

    // 需要場所住所区切り編集 全角半角が混在する文字列を指定した区切りバイト数で編集する。
    List<String> delimitAddressList = this.delimitString(sb.toString(), DELIMTER_PLACE_ADDRESS);

    for (int i = 0; i < delimitAddressList.size(); i++) {
      if (i == PLACE_ADDRESS_1LINE) {
        // ■内訳08・名称 需要場所住所１行目
        snBillingRequestDataBusinessBean.setBreakdown08Name(delimitAddressList.get(i));
      } else if (i == PLACE_ADDRESS_2LINE) {
        // ■内訳09・名称 需要場所住所２行目
        snBillingRequestDataBusinessBean.setBreakdown09Name(delimitAddressList.get(i));
      } else if (i == PLACE_ADDRESS_3LINE) {
        // ■内訳10・名称 需要場所住所３行目
        snBillingRequestDataBusinessBean.setBreakdown10Name(delimitAddressList.get(i));
      } else if (i == PLACE_ADDRESS_4LINE) {
        // ■内訳11・名称 需要場所住所４行目
        snBillingRequestDataBusinessBean.setBreakdown11Name(delimitAddressList.get(i));
      }
    }

  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.sn.SN_CreateBillingRequestDataBeanBusiness
   * #createBillingRequestDataBeanForWsAgOp(SN_BillingDetailInfoBusinessBean, String, Properties)
   */
  @Override
  public SN_BillingRequestDataBusinessBean createBillingRequestDataBeanForWsAgOp(
      SN_BillingDetailInfoBusinessBean bean, String consignerCode, Properties prop) {

    SN_BillingRequestDataBusinessBean snBillingRequestDataBusinessBean = new SN_BillingRequestDataBusinessBean();

    this.createRequestDataCommonForWsAgOp(bean, consignerCode, snBillingRequestDataBusinessBean, prop);

    // ■お知らせ 未設定
    // ■内訳01・名称
    snBillingRequestDataBusinessBean.setBreakdown01Name(gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, BL_REQUEST_FILE_BREAKDOWN_BLMONTH_SUMMARY), bean));
    // ■内訳01・金額 未設定
    // ■内訳02・名称
    snBillingRequestDataBusinessBean.setBreakdown02Name(gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, BL_REQUEST_FILE_BREAKDOWN_USEAMOUNT), bean));
    // ■内訳02・金額
    snBillingRequestDataBusinessBean.setBreakdown02Amount(gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, USE_AMOUNT), bean));
    // ■内訳03・名称
    snBillingRequestDataBusinessBean.setBreakdown03Name(gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, BL_REQUEST_FILE_BREAKDOWN_CTEQUIVALENT), bean));
    // ■内訳03・金額
    snBillingRequestDataBusinessBean.setBreakdown03Amount(gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, CT_EQUIVALENT), bean));

    // ■内訳04・名称 未設定
    // ■内訳04・金額 未設定
    // ■内訳05・名称 未設定
    // ■内訳05・金額 未設定
    // ■内訳06・名称 未設定
    // ■内訳06・金額 未設定
    // ■内訳07・名称 未設定
    // ■内訳07・金額 未設定
    // ■内訳08・名称 未設定
    // ■内訳08・金額 未設定
    // ■内訳09・名称 未設定
    // ■内訳09・金額 未設定
    // ■内訳10・名称 未設定
    // ■内訳10・金額 未設定
    // ■内訳11・名称 未設定
    // ■内訳11・金額 未設定
    // ■内訳12・名称 未設定
    // ■内訳12・金額 未設定
    // ■内訳13・名称 未設定
    // ■内訳13・金額 未設定

    /*
     * 汎用化のため、他の項目も設定しておく。
     */
    this.setBillingRequestDataBusinessBean(bean, snBillingRequestDataBusinessBean, true);

    return snBillingRequestDataBusinessBean;

  }

  /**
   * 請求依頼データ作成（卸／取次事業者）前半部
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 卸／取次事業者の請求書に出力する前半部分の設定を行う。
   * </pre>
   *
   * @param bean
   *          請求明細情報Bean
   * @param consignerCode
   *          委託者コード
   * @param snBillingRequestDataBusinessBean
   *          請求依頼データBean
   * @param prop
   *          プロパティオブジェクト
   */
  private void createRequestDataCommonForWsAgOp(SN_BillingDetailInfoBusinessBean bean, String consignerCode,
      SN_BillingRequestDataBusinessBean snBillingRequestDataBusinessBean, Properties prop) {

    // ■レコード区分
    snBillingRequestDataBusinessBean.setRecordCategory(DATA_CATEGORY_DATA);
    // ■委託者コード
    snBillingRequestDataBusinessBean.setConsignerCode(consignerCode);
    // ■請求区分コード
    snBillingRequestDataBusinessBean.setBillingCategoryCode(gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, BL_CAT_CODE), bean));
    // ■決済予定日
    if (bean.getBl().getSettlementScheduledDate() != null) {
      snBillingRequestDataBusinessBean.setSettlementScheduledDate(gkWorkCommonBusiness.evaluateStringVelocity(
          getProp(prop, SETTLEMENT_SCHEDULED_DATE), bean));
    }
    // ■請求番号
    snBillingRequestDataBusinessBean.setBillingNo(gkWorkCommonBusiness.evaluateStringVelocity(getProp(prop, BL_NO),
        bean));
    // ■契約者番号
    snBillingRequestDataBusinessBean.setContractorNo(gkWorkCommonBusiness
        .evaluateStringVelocity(getProp(prop, CONTRACTOR_NO), bean));
    // 郵送先情報の設定
    if (bean.getPmCompanyM() != null) {
      this.setAddresse(bean, snBillingRequestDataBusinessBean, prop);
    }
    // ■契約者名1 未設定
    // ■契約者名2 未設定
    // ■支払期日
    snBillingRequestDataBusinessBean.setPaymentFixedDate(gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, PFD), bean));
    // ■利用年月
    String editUsePeriod = gkWorkCommonBusiness.evaluateStringVelocity(getProp(prop, USE_PERIOD), bean);
    snBillingRequestDataBusinessBean.setUsePeriod(editUsePeriod.substring(0, YYYY_END) + EMSConstants.SLASH
        + editUsePeriod.substring(YYYY_END, MM_END));
    // ■請求額
    snBillingRequestDataBusinessBean.setBillingAmount(gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, BL_AMOUNT), bean));
    // ■消費税相当額
    snBillingRequestDataBusinessBean
        .setConsumptionTaxEquivalent(gkWorkCommonBusiness.evaluateStringVelocity(getProp(prop, CT_EQUIVALENT),
            bean));
    // ■ご利用金額
    snBillingRequestDataBusinessBean.setUseAmount(gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, USE_AMOUNT), bean));
    // ■預り金等
    snBillingRequestDataBusinessBean.setDepositsReceived(gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, DEPOSITS_RECEIVED), bean));
    // ■契約数計
    snBillingRequestDataBusinessBean.setTotalNumberOfContracts(gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, TOTAL_CONTRACT), bean));
    // ■アクセスキー 未設定
    // ■振込先金融機関コード
    snBillingRequestDataBusinessBean.setBankCode(gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, BANK_CODE), bean));
    // ■振込先金融機関名
    snBillingRequestDataBusinessBean.setBankName(gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, BANK_NAME), bean));
    // ■振込先金融機関支店コード
    snBillingRequestDataBusinessBean.setBankBranchCode(gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, BANK_BRANCH_CODE), bean));
    // ■振込先金融機関支店名
    snBillingRequestDataBusinessBean.setBankBranchName(gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, BANK_BRANCH_NAME),
        bean));
    // ■振込先預金種目コード
    snBillingRequestDataBusinessBean.setBankTypeOfAccountCode(gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, BT_OF_ACCOUNT_CODE), bean));
    // ■振込先預金種目
    snBillingRequestDataBusinessBean.setBankTypeOfAccount(gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, BT_OF_ACCOUNT), bean));
    // ■振込先口座番号
    snBillingRequestDataBusinessBean.setAccountNo(gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, ACCOUNT_NO), bean));
    // ■振込先口座名義
    snBillingRequestDataBusinessBean.setAccountHolderName(gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, ACCOUNT_HOLDER_NAME), bean));
  }

  /**
   * 郵送先情報の設定
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 郵送先情報を設定する。
   * </pre>
   *
   * @param bean
   *          請求明細情報Bean
   * @param snBillingRequestDataBusinessBean
   *          請求依頼データBean
   * @param prop
   *          プロパティオブジェクト
   */
  private void setAddresse(SN_BillingDetailInfoBusinessBean bean,
      SN_BillingRequestDataBusinessBean snBillingRequestDataBusinessBean, Properties prop) {

    // ■宛先郵便番号 上3桁 ＋ "-" ＋ 下4桁で編集
    String editAddresseePostalCode = gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, ADDRESSEE_POSTAL_CODE), bean);
    snBillingRequestDataBusinessBean.setDestinationPostalCode(editAddresseePostalCode
        .substring(0, POSTAL_CODE1_END)
        + EMSConstants.MINUS
        + editAddresseePostalCode.substring(POSTAL_CODE1_END, POSTAL_CODE2_END));
    // ■宛先住所
    StringBuilder sb = new StringBuilder();
    sb.append(gkWorkCommonBusiness.evaluateStringVelocity(getProp(prop, ADDRESSEE_PREFECTURES), bean));
    sb.append(gkWorkCommonBusiness.evaluateStringVelocity(getProp(prop, ADDRESSEE_MUNICIPALITY), bean));
    // 郵送先（字名・丁目）に設定がある場合に連結する。
    String editAddresseeSection = gkWorkCommonBusiness.evaluateStringVelocity(getProp(prop, ADDRESSEE_SECTION),
        bean);
    if (StringUtils.isNotEmpty(editAddresseeSection)) {
      sb.append(editAddresseeSection);
    }
    // 郵送先（番地・号）に設定がある場合に連結する。
    String editAddresseeBlock = gkWorkCommonBusiness.evaluateStringVelocity(getProp(prop, ADDRESSEE_BLOCK), bean);
    if (StringUtils.isNotEmpty(editAddresseeBlock)) {
      sb.append(EMSConstants.SPACE_ZENKAKU);
      sb.append(editAddresseeBlock);
    }
    // 郵送先（建物名）に設定がある場合に連結する。
    String editAddresseeBuildingName = gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, ADDRESSEE_BUILDING_NAME), bean);
    if (StringUtils.isNotEmpty(editAddresseeBuildingName)) {
      sb.append(EMSConstants.SPACE_ZENKAKU);
      sb.append(editAddresseeBuildingName);
    }
    // 郵送先（部屋名）に設定がある場合に連結する。
    String editAddresseeRoom = gkWorkCommonBusiness.evaluateStringVelocity(getProp(prop, ADDRESSEE_ROOM), bean);
    if (StringUtils.isNotEmpty(editAddresseeRoom)) {
      sb.append(EMSConstants.SPACE_ZENKAKU);
      sb.append(editAddresseeRoom);
    }
    snBillingRequestDataBusinessBean.setAddress(sb.toString());
    // ■宛先住所（都道府県名）
    snBillingRequestDataBusinessBean.setAddressPrefectures(gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, ADDRESSEE_PREFECTURES), bean));
    // ■宛先住所（市区郡町村名）
    snBillingRequestDataBusinessBean.setAddressMunicipality(gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, ADDRESSEE_MUNICIPALITY), bean));
    // ■宛先住所（字名・丁目）
    snBillingRequestDataBusinessBean.setAddressSection(editAddresseeSection);
    // ■宛先住所（番地・号）
    snBillingRequestDataBusinessBean.setAddressBlock(editAddresseeBlock);
    // ■宛先住所（建物名）
    snBillingRequestDataBusinessBean.setAddressBuildingName(editAddresseeBuildingName);
    // ■宛先住所（部屋名）
    snBillingRequestDataBusinessBean.setAddressRoom(editAddresseeRoom);
    // ■宛先会社名
    snBillingRequestDataBusinessBean.setAddressCompanyName(gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, PM_COMPANY), bean));
    // 宛先部課、宛先氏名の設定
    String editAddresseeMailingName1 = gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, ADDRESSEE_MAILING_NAME_1), bean);
    String editAddresseeMailingName2 = gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, ADDRESSEE_MAILING_NAME_2), bean);
    String editAddresseePrefix = gkWorkCommonBusiness.evaluateStringVelocity(getProp(prop, ADDRESSEE_PREFIX), bean);
    if (StringUtils.isEmpty(editAddresseeMailingName2)) {
      // 郵送先（宛名2）に設定がない場合、宛先部課に敬称を付与する。
      String addressDepartment;
      if (StringUtils.isNotEmpty(editAddresseePrefix)) {
        addressDepartment = editAddresseeMailingName1 + EMSConstants.SPACE_ZENKAKU + editAddresseePrefix;
      } else {
        addressDepartment = editAddresseeMailingName1;
      }
      // ■宛先部課
      snBillingRequestDataBusinessBean.setAddressDepartment(addressDepartment);
    } else {
      // 郵送先（宛名2）に設定がある場合、宛先氏名に敬称を付与する。
      // ■宛先部課
      snBillingRequestDataBusinessBean.setAddressDepartment(editAddresseeMailingName1);
      String addressName;
      if (StringUtils.isNotEmpty(editAddresseePrefix)) {
        addressName = editAddresseeMailingName2 + EMSConstants.SPACE_ZENKAKU + editAddresseePrefix;
      } else {
        addressName = editAddresseeMailingName2;
      }
      // ■宛先氏名
      snBillingRequestDataBusinessBean.setAddressName(addressName);
    }
  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.sn.SN_CreateBillingRequestDataBeanBusiness
   * #createBillingRequestDataBeanForReceivable(SN_BillingDetailInfoBusinessBean, String, Properties)
   */
  @Override
  public SN_BillingRequestDataBusinessBean createBillingRequestDataBeanForReceivable(
      SN_BillingDetailInfoBusinessBean bean, String consignerCode, Properties prop) {

    SN_BillingRequestDataBusinessBean snBillingRequestDataBusinessBean = new SN_BillingRequestDataBusinessBean();

    // 共通設定
    this.createRequestDataCommon(bean, consignerCode, snBillingRequestDataBusinessBean, prop);

    /*
     * 以下の項目は未設定
     */
    // ■お知らせ
    // ■内訳01・名称
    // ■内訳01・金額
    // ■内訳02・名称
    // ■内訳02・金額
    // ■内訳03・名称
    // ■内訳03・金額
    // ■内訳04・名称
    // ■内訳04・金額
    // ■内訳05・名称
    // ■内訳05・金額
    // ■内訳06・名称
    // ■内訳06・金額
    // ■内訳07・名称
    // ■内訳07・金額
    // ■内訳08・名称
    // ■内訳08・金額
    // ■内訳09・名称
    // ■内訳09・金額
    // ■内訳10・名称
    // ■内訳10・金額
    // ■内訳11・名称
    // ■内訳11・金額
    // ■内訳12・名称
    // ■内訳12・金額
    // ■内訳13・名称
    // ■内訳13・金額

    /*
     * 汎用化のため、他の項目も設定しておく。
     */
    this.setBillingRequestDataBusinessBean(bean, snBillingRequestDataBusinessBean, false);

    return snBillingRequestDataBusinessBean;

  }

  /**
   * 請求依頼データ作成（共通項目）
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 口振・クレカ・コンビニ・振込・債権の請求書に出力する共通項目の設定を行う。
   * 卸／取次事業者は設定元が異なるため、個別で行う。
   * </pre>
   *
   * @param bean
   *          請求明細情報Bean
   * @param consignerCode
   *          委託者コード
   * @param prop
   *          プロパティオブジェクト
   * @param SN_BillingRequestDataBusinessBean
   *          請求依頼データBean
   */
  private void createRequestDataCommon(SN_BillingDetailInfoBusinessBean bean, String consignerCode,
      SN_BillingRequestDataBusinessBean snBillingRequestDataBusinessBean, Properties prop) {

    // ■レコード区分
    snBillingRequestDataBusinessBean.setRecordCategory(DATA_CATEGORY_DATA);
    // ■委託者コード
    snBillingRequestDataBusinessBean.setConsignerCode(consignerCode);
    // ■請求区分コード
    snBillingRequestDataBusinessBean.setBillingCategoryCode(gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, BL_CAT_CODE), bean));
    // ■決済予定日
    if (bean.getBl().getSettlementScheduledDate() != null) {
      snBillingRequestDataBusinessBean.setSettlementScheduledDate(gkWorkCommonBusiness.evaluateStringVelocity(
          getProp(prop, SETTLEMENT_SCHEDULED_DATE), bean));
    }
    // ■請求番号
    snBillingRequestDataBusinessBean.setBillingNo(gkWorkCommonBusiness.evaluateStringVelocity(getProp(prop, BL_NO),
        bean));
    // ■契約者番号
    snBillingRequestDataBusinessBean.setContractorNo(gkWorkCommonBusiness
        .evaluateStringVelocity(getProp(prop, CONTRACTOR_NO), bean));

    // 請求先住所情報が取得できたか、【支払履歴】.請求先郵便番号の設定有無で判定
    if (bean.getPaymentHist() != null && StringUtils.isNotEmpty(bean.getPaymentHist().getBlAddressPostalCode())) {
      // 請求先住所情報が取得できた場合は支払履歴情報
      this.setPaymentHistAddressInfo(bean, snBillingRequestDataBusinessBean, prop);
    } else {
      // 請求書情報が取得できない場合は契約者情報
      this.setContractorAddressInfo(bean, snBillingRequestDataBusinessBean, prop);
    }

    // ■契約者名1
    snBillingRequestDataBusinessBean.setContractorName1(gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, CN_1), bean));
    // ■契約者名2
    snBillingRequestDataBusinessBean.setContractorName2(gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, CN_2), bean));
    // ■支払期日
    snBillingRequestDataBusinessBean.setPaymentFixedDate(gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, PFD), bean));
    // ■利用年月
    String editUsePeriod = gkWorkCommonBusiness.evaluateStringVelocity(getProp(prop, USE_PERIOD), bean);
    snBillingRequestDataBusinessBean.setUsePeriod(editUsePeriod.substring(0, YYYY_END) + EMSConstants.SLASH
        + editUsePeriod.substring(YYYY_END, MM_END));
    // ■請求額
    snBillingRequestDataBusinessBean.setBillingAmount(gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, BL_AMOUNT), bean));
    // ■消費税相当額
    snBillingRequestDataBusinessBean
        .setConsumptionTaxEquivalent(gkWorkCommonBusiness.evaluateStringVelocity(getProp(prop, CT_EQUIVALENT),
            bean));
    // ■ご利用金額
    snBillingRequestDataBusinessBean.setUseAmount(gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, USE_AMOUNT), bean));
    // ■預り金等
    snBillingRequestDataBusinessBean.setDepositsReceived(gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, DEPOSITS_RECEIVED), bean));
    // ■契約数計
    snBillingRequestDataBusinessBean.setTotalNumberOfContracts(gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, TOTAL_CONTRACT), bean));
    // ■アクセスキー
    snBillingRequestDataBusinessBean.setAccessKey(gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, ACCESS_KEY), bean));
    // ■振込先金融機関コード
    snBillingRequestDataBusinessBean.setBankCode(gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, BANK_CODE), bean));
    // ■振込先金融機関名
    snBillingRequestDataBusinessBean.setBankName(gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, BANK_NAME), bean));
    // ■振込先金融機関支店コード
    snBillingRequestDataBusinessBean.setBankBranchCode(gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, BANK_BRANCH_CODE), bean));
    // ■振込先金融機関支店名
    snBillingRequestDataBusinessBean.setBankBranchName(gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, BANK_BRANCH_NAME), bean));
    // ■振込先預金種目コード
    snBillingRequestDataBusinessBean.setBankTypeOfAccountCode(gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, BT_OF_ACCOUNT_CODE), bean));
    // ■振込先預金種目
    snBillingRequestDataBusinessBean.setBankTypeOfAccount(gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, BT_OF_ACCOUNT), bean));
    // ■振込先口座番号
    snBillingRequestDataBusinessBean.setAccountNo(gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, ACCOUNT_NO), bean));
    // ■振込先口座名義
    snBillingRequestDataBusinessBean.setAccountHolderName(gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, ACCOUNT_HOLDER_NAME), bean));
  }

  /**
   * 請求先住所情報の設定
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 支払履歴の請求先情報を設定する。
   * </pre>
   *
   * @param bean
   *          請求明細情報Bean
   * @param snBillingRequestDataBusinessBean
   *          請求依頼データBean
   * @param prop
   *          プロパティオブジェクト
   */
  private void setPaymentHistAddressInfo(SN_BillingDetailInfoBusinessBean bean,
      SN_BillingRequestDataBusinessBean snBillingRequestDataBusinessBean, Properties prop) {

    // ■宛先郵便番号 上3桁 ＋ "-" ＋ 下4桁で編集
    String editBlAddressPostalCode = gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, BL_ADDRESS_POSTAL_CODE), bean);
    if (StringUtils.isNotEmpty(editBlAddressPostalCode)) {
      // 請求先住所情報に設定がある場合は請求先住所（郵便番号）
      snBillingRequestDataBusinessBean.setDestinationPostalCode(editBlAddressPostalCode
          .substring(0, POSTAL_CODE1_END)
          + EMSConstants.MINUS
          + editBlAddressPostalCode.substring(POSTAL_CODE1_END, POSTAL_CODE2_END));
    }
    // ■宛先住所
    StringBuilder sb = new StringBuilder();
    // 請求先住所（都道府県名）に設定がある場合に連結する。
    String editBlAddressPrefectures = gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, BL_ADDRESS_PREFECTURES), bean);
    if (StringUtils.isNotEmpty(editBlAddressPrefectures)) {
      sb.append(editBlAddressPrefectures);
    }
    // 請求先住所（市区郡町村名）に設定がある場合に連結する。
    String editBlAddressMunicipality = gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, BL_ADDRESS_MUNICIPALITY), bean);
    if (StringUtils.isNotEmpty(editBlAddressMunicipality)) {
      sb.append(editBlAddressMunicipality);
    }
    // 請求先住所（字名・丁目）に設定がある場合に連結する。
    String editBlAddressSection = gkWorkCommonBusiness.evaluateStringVelocity(getProp(prop, BL_ADDRESS_SECTION),
        bean);
    if (StringUtils.isNotEmpty(editBlAddressSection)) {
      sb.append(editBlAddressSection);
    }
    // 請求先住所（番地・号）に設定がある場合に連結する。
    String editBlAddressBlock = gkWorkCommonBusiness.evaluateStringVelocity(getProp(prop, BL_ADDRESS_BLOCK), bean);
    if (StringUtils.isNotEmpty(editBlAddressBlock)) {
      sb.append(EMSConstants.SPACE_ZENKAKU);
      sb.append(editBlAddressBlock);
    }
    // 請求先住所（建物名）に設定がある場合に連結する。
    String editBlAddressBuildingName = gkWorkCommonBusiness.evaluateStringVelocity(
        getProp(prop, BL_ADDRESS_BUILDING_NAME), bean);
    if (StringUtils.isNotEmpty(editBlAddressBuildingName)) {
      sb.append(EMSConstants.SPACE_ZENKAKU);
      sb.append(editBlAddressBuildingName);
    }
    // 請求先住所（部屋名）に設定がある場合に連結する。
    String editBlAddressRoom = gkWorkCommonBusiness.evaluateStringVelocity(getProp(prop, BL_ADDRESS_ROOM), bean);
    if (StringUtils.isNotEmpty(editBlAddressRoom)) {
      sb.append(EMSConstants.SPACE_ZENKAKU);
      sb.append(editBlAddressRoom);
    }
    snBillingRequestDataBusinessBean.setAddress(sb.toString());
    // ■宛先住所（都道府県名）
    snBillingRequestDataBusinessBean.setAddressPrefectures(editBlAddressPrefectures);
    // ■宛先住所（市区郡町村名）
    snBillingRequestDataBusinessBean.setAddressMunicipality(editBlAddressMunicipality);
    // ■宛先住所（字名・丁目）
    snBillingRequestDataBusinessBean.setAddressSection(editBlAddressSection);
    // ■宛先住所（番地・号）
    snBillingRequestDataBusinessBean.setAddressBlock(editBlAddressBlock);
    // ■宛先住所（建物名）
    snBillingRequestDataBusinessBean.setAddressBuildingName(editBlAddressBuildingName);
    // ■宛先住所（部屋名）
    snBillingRequestDataBusinessBean.setAddressRoom(editBlAddressRoom);

    String editBlName1 = gkWorkCommonBusiness.evaluateStringVelocity(getProp(prop, BL_NAME_1), bean);
    String editBlName2 = gkWorkCommonBusiness.evaluateStringVelocity(getProp(prop, BL_NAME_2), bean);
    String editBlPrefix = gkWorkCommonBusiness.evaluateStringVelocity(getProp(prop, BL_PREFIX), bean);
    if (ECISCodeConstants.PERSONAL_CORPORATION_CATEGORY_CORPORATION.equals(bean.getContractor().getIlcCode())) {
      // 《請求明細情報Bean》の《契約者Bean》「個人・法人区分コード」が"法人"の場合
      if (StringUtils.isNotEmpty(editBlName1) && StringUtils.isNotEmpty(editBlName2)) {
        // 請求先氏名1、請求先氏名2の両方設定されている場合、宛先部課に敬称を付加する。
        // ■宛先会社名
        snBillingRequestDataBusinessBean.setAddressCompanyName(editBlName1);
        // ■宛先部課
        snBillingRequestDataBusinessBean.setAddressDepartment(editBlName2 + EMSConstants.SPACE_ZENKAKU
            + editBlPrefix);
      } else if (StringUtils.isNotEmpty(editBlName1)) {
        // 請求先氏名1のみ設定されている場合、宛先会社名に敬称を付加する。
        // ■宛先会社名に敬称を付加する。
        snBillingRequestDataBusinessBean.setAddressCompanyName(editBlName1 + EMSConstants.SPACE_ZENKAKU
            + editBlPrefix);
        // ■宛先部課
        snBillingRequestDataBusinessBean.setAddressDepartment(editBlName2);
      }
    } else if (ECISCodeConstants.PERSONAL_CORPORATION_CATEGORY_PERSONAL.equals(bean.getContractor()
        .getIlcCode())) {
      // 《請求明細情報Bean》の「個人・法人区分コード」が"個人"場合
      if (StringUtils.isNotEmpty(editBlPrefix)) {
        // ■宛先氏名に敬称を付加する。
        snBillingRequestDataBusinessBean
            .setAddressName(editBlName1 + EMSConstants.SPACE_ZENKAKU + editBlPrefix);
      } else {
        snBillingRequestDataBusinessBean.setAddressName(editBlName1);
      }

    }
  }

  /**
   * 契約者住所情報の設定
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者の請求先情報を設定する。
   * </pre>
   *
   * @param bean
   *          請求明細情報Bean
   * @param snBillingRequestDataBusinessBean
   *          請求依頼データBean
   * @param prop
   *          プロパティオブジェクト
   */
  private void setContractorAddressInfo(SN_BillingDetailInfoBusinessBean bean,
      SN_BillingRequestDataBusinessBean snBillingRequestDataBusinessBean, Properties prop) {

    // ■宛先郵便番号 上3桁 ＋ "-" ＋ 下4桁で編集
    // 契約者住所（郵便番号）
    String editCaPostalCode = gkWorkCommonBusiness.evaluateStringVelocity(getProp(prop, CA_POSTAL_CODE), bean);
    snBillingRequestDataBusinessBean.setDestinationPostalCode(editCaPostalCode.substring(0, POSTAL_CODE1_END)
        + EMSConstants.MINUS
        + editCaPostalCode.substring(POSTAL_CODE1_END, POSTAL_CODE2_END));
    // ■宛先住所
    StringBuilder sb = new StringBuilder();
    // 契約者住所（都道府県名）～（部屋名）を連結する。
    // 契約者住所（都道府県名）
    String editCaPrefectures = gkWorkCommonBusiness.evaluateStringVelocity(getProp(prop, CA_PREFECTURES), bean);
    sb.append(editCaPrefectures);
    // 契約者住所（市区郡町村名）
    String editCaMunicipality = gkWorkCommonBusiness.evaluateStringVelocity(getProp(prop, CA_MUNICIPALITY), bean);
    sb.append(editCaMunicipality);
    // 契約者住所（字名・丁目）に設定がある場合に連結する。
    String editCaSection = gkWorkCommonBusiness.evaluateStringVelocity(getProp(prop, CA_SECTION), bean);
    if (StringUtils.isNotEmpty(editCaSection)) {
      sb.append(editCaSection);
    }
    // 契約者住所（番地・号）に設定がある場合に連結する。
    String editCaBlock = gkWorkCommonBusiness.evaluateStringVelocity(getProp(prop, CA_BLOCK), bean);
    if (StringUtils.isNotEmpty(editCaBlock)) {
      sb.append(EMSConstants.SPACE_ZENKAKU);
      sb.append(editCaBlock);
    }
    // 契約者住所（建物名）に設定がある場合に連結する。
    String editCaBuildingName = gkWorkCommonBusiness.evaluateStringVelocity(getProp(prop, CA_BUILDING_NAME), bean);
    if (StringUtils.isNotEmpty(editCaBuildingName)) {
      sb.append(EMSConstants.SPACE_ZENKAKU);
      sb.append(editCaBuildingName);
    }
    // 契約者住所（部屋名）に設定がある場合に連結する。
    String editCaRoom = gkWorkCommonBusiness.evaluateStringVelocity(getProp(prop, CA_ROOM), bean);
    if (StringUtils.isNotEmpty(editCaRoom)) {
      sb.append(EMSConstants.SPACE_ZENKAKU);
      sb.append(editCaRoom);
    }
    snBillingRequestDataBusinessBean.setAddress(sb.toString());

    // ■宛先住所（都道府県名）
    snBillingRequestDataBusinessBean.setAddressPrefectures(editCaPrefectures);
    // ■宛先住所（市区郡町村名）
    snBillingRequestDataBusinessBean.setAddressMunicipality(editCaMunicipality);
    // ■宛先住所（字名・丁目）
    snBillingRequestDataBusinessBean.setAddressSection(editCaSection);
    // ■宛先住所（番地・号）
    snBillingRequestDataBusinessBean.setAddressBlock(editCaBlock);
    // ■宛先住所（建物名）
    snBillingRequestDataBusinessBean.setAddressBuildingName(editCaBuildingName);
    // ■宛先住所（部屋名）
    snBillingRequestDataBusinessBean.setAddressRoom(editCaRoom);

    String editCn1MailingName = gkWorkCommonBusiness.evaluateStringVelocity(getProp(prop, CN_1_MAILING_NAME), bean);
    String editCn2MailingName = gkWorkCommonBusiness.evaluateStringVelocity(getProp(prop, CN_2_MAILING_NAME), bean);
    String editContractorPrefix = gkWorkCommonBusiness.evaluateStringVelocity(getProp(prop, CONTRACTOR_PREFIX),
        bean);
    String editCn1 = gkWorkCommonBusiness.evaluateStringVelocity(getProp(prop, CN_1), bean);
    String editCn2 = gkWorkCommonBusiness.evaluateStringVelocity(getProp(prop, CN_2), bean);
    if (ECISCodeConstants.PERSONAL_CORPORATION_CATEGORY_CORPORATION.equals(bean.getContractor().getIlcCode())) {
      // 《請求明細情報Bean》の《契約者Bean》「個人・法人区分コード」が"法人"の場合
      if (StringUtils.isNotEmpty(editCn1MailingName) && StringUtils.isNotEmpty(editCn2MailingName)) {
        // 契約者名1（宛名用）、契約者名2（宛名用）の両方設定されている場合、宛先部課に敬称を付加する。
        // ■宛先会社名
        snBillingRequestDataBusinessBean.setAddressCompanyName(editCn1MailingName);
        // ■宛先部課に敬称を付加する。
        snBillingRequestDataBusinessBean.setAddressDepartment(editCn2MailingName + EMSConstants.SPACE_ZENKAKU
            + editContractorPrefix);
      } else if (StringUtils.isNotEmpty(editCn1MailingName)) {
        // 契約者名1（宛名用）のみ設定されている場合
        if (StringUtils.isNotEmpty(editCn2)) {
          // 契約者2に設定がある場合
          // ■宛先会社名
          snBillingRequestDataBusinessBean.setAddressCompanyName(editCn1MailingName);
          // ■宛先部課
          snBillingRequestDataBusinessBean.setAddressDepartment(editCn2 + EMSConstants.SPACE_ZENKAKU
              + editContractorPrefix);
        } else {
          // 契約者2に設定がない場合
          // ■宛先会社名に敬称を付加する。
          snBillingRequestDataBusinessBean
              .setAddressCompanyName(editCn1MailingName + EMSConstants.SPACE_ZENKAKU
                  + editContractorPrefix);
        }
      } else if (StringUtils.isNotEmpty(editCn2MailingName)) {
        // 契約者名2（宛名用）のみ設定されている場合
        // ■宛先会社名
        snBillingRequestDataBusinessBean.setAddressCompanyName(editCn1);
        // ■宛先部課
        snBillingRequestDataBusinessBean.setAddressDepartment(editCn2MailingName + EMSConstants.SPACE_ZENKAKU
            + editContractorPrefix);
      } else {
        // 契約者名1（宛名用）、契約者名2（宛名用）の両方設定されていない場合
        if (StringUtils.isNotEmpty(editCn2)) {
          // 契約者2に設定がある場合
          // ■宛先会社名
          snBillingRequestDataBusinessBean.setAddressCompanyName(editCn1);
          // ■宛先部課
          snBillingRequestDataBusinessBean.setAddressDepartment(editCn2 + EMSConstants.SPACE_ZENKAKU
              + editContractorPrefix);
        } else {
          // 契約者2に設定がない場合
          // ■宛先会社名に敬称を付加する。
          snBillingRequestDataBusinessBean.setAddressCompanyName(editCn1 + EMSConstants.SPACE_ZENKAKU
              + editContractorPrefix);
        }
      }
    } else if (ECISCodeConstants.PERSONAL_CORPORATION_CATEGORY_PERSONAL.equals(bean.getContractor().getIlcCode())) {
      // 《請求明細情報Bean》の《契約者Bean》「個人・法人区分コード」が"個人"の場合
      if (StringUtils.isNotEmpty(editCn1MailingName)) {
        // ■宛先氏名
        snBillingRequestDataBusinessBean.setAddressName(editCn1MailingName + EMSConstants.SPACE_ZENKAKU
            + editContractorPrefix);
      } else {
        // 契約者名1（宛名用）が設定されていない場合、契約者名1を設定する。
        // ■宛先氏名
        snBillingRequestDataBusinessBean.setAddressName(editCn1
            + EMSConstants.SPACE_ZENKAKU + editContractorPrefix);
      }
    }
  }

  /**
   *
   * 請求依頼データBean設定
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * DBより取得した項目を請求依頼データBeanに設定しておく。
   * </pre>
   *
   * @param bean
   *          請求明細情報Bean
   * @param snBillingRequestDataBusinessBean
   *          請求依頼データBean
   * @param wsAgOpFlg
   *          卸／取次事業者フラグ
   */
  private void setBillingRequestDataBusinessBean(SN_BillingDetailInfoBusinessBean bean,
      SN_BillingRequestDataBusinessBean snBillingRequestDataBusinessBean, boolean wsAgOpFlg) {

    // ■《請求EntityBean》
    this.setBl(bean.getBl(), snBillingRequestDataBusinessBean);

    if (!wsAgOpFlg) {
      // ■卸／取次事業者以外の設定

      // ■《契約者EntityBean》
      this.setContractor(bean.getContractor(), snBillingRequestDataBusinessBean);

      // ■《口座クレカ情報EntityBean》
      this.setAcInformation(bean.getAcInformation(), snBillingRequestDataBusinessBean);

      // ■《支払履歴EntityBean》
      this.setPaymentHist(bean.getPaymentHist(), snBillingRequestDataBusinessBean);

      // ■《需要場所EntityBean》
      this.setPlace(bean.getPlace(), snBillingRequestDataBusinessBean);

      // ■《督促管理EntityBean》
      this.setUrgeMng(bean.getUrgeMng(), snBillingRequestDataBusinessBean);

      // ■《契約EntityBean》
      this.setContract(bean.getContract(), snBillingRequestDataBusinessBean);

    } else {
      // ■卸／取次事業者の設定

      // ■《提供モデル企業マスタEntityBean》
      this.setPmCompanyM(bean.getPmCompanyM(), snBillingRequestDataBusinessBean);

    }

    // 《確定料金実績EntityBean》リスト
    snBillingRequestDataBusinessBean.setFcrList(bean.getFcrList());
    // 全契約番号リスト
    snBillingRequestDataBusinessBean.setContractNoList(bean.getContractNoList());
  }

  /**
   *
   * 請求依頼データBean設定（請求）
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * DBより取得した請求を請求依頼データBeanに設定しておく。
   * </pre>
   *
   * @param bl
   *          請求Bean
   * @param snBillingRequestDataBusinessBean
   *          請求依頼データBean
   */
  private void setBl(Bl bl,
      SN_BillingRequestDataBusinessBean snBillingRequestDataBusinessBean) {

    // ■《請求EntityBean》
    SimpleDateFormat formatDate = new SimpleDateFormat(EMSConstants.FORMAT_DATE_yyyyMMdd);
    snBillingRequestDataBusinessBean.setBlBlId(String.valueOf(bl.getBlId()));
    snBillingRequestDataBusinessBean.setBlBlNo(bl.getBlNo());
    snBillingRequestDataBusinessBean.setBlContractorId(String.valueOf(bl.getContractorId()));
    snBillingRequestDataBusinessBean.setBlContractorNo(bl.getContractorNo());
    snBillingRequestDataBusinessBean.setBlCustomerCode(bl.getCustomerCode());
    snBillingRequestDataBusinessBean.setBlPaymentId(String.valueOf(bl.getPaymentId()));
    snBillingRequestDataBusinessBean.setBlBlCatCode(bl.getBlCatCode());
    snBillingRequestDataBusinessBean.setBlPmCode(bl.getPmCode());
    snBillingRequestDataBusinessBean.setBlPmCompanyCode(bl.getPmCompanyCode());
    snBillingRequestDataBusinessBean.setBlUsePeriod(bl.getUsePeriod());
    snBillingRequestDataBusinessBean.setBlBlAmount(String.valueOf(bl.getBlAmount()));
    snBillingRequestDataBusinessBean.setBlUseAmount(String.valueOf(bl.getUseAmount()));
    if (bl.getSettlementScheduledDate() != null) {
      snBillingRequestDataBusinessBean.setBlSettlementScheduledDate(formatDate.format(bl
          .getSettlementScheduledDate()));
    }
    snBillingRequestDataBusinessBean.setBlPfd(formatDate.format(bl.getPfd()));
    snBillingRequestDataBusinessBean.setBlBlStatusCode(bl.getBlStatusCode());
    snBillingRequestDataBusinessBean.setBlBlSrReasonCode(bl.getBlSrReasonCode());
    snBillingRequestDataBusinessBean.setBlAddUpBlFlag(bl.getAddUpBlFlag());
    snBillingRequestDataBusinessBean.setBlProcrastinationPfdFlag(bl.getProcrastinationPfdFlag());
    snBillingRequestDataBusinessBean.setBlBlCreateDate(formatDate.format(bl.getBlCreateDate()));
    snBillingRequestDataBusinessBean.setBlMultipleRccFlag(bl.getMultipleRccFlag());
    snBillingRequestDataBusinessBean.setBlCombinedBlFlag(bl.getCombinedBlFlag());
    snBillingRequestDataBusinessBean.setBlCompletedFlag(bl.getCompletedFlag());
    snBillingRequestDataBusinessBean.setBlBankCode(bl.getBankCode());
    snBillingRequestDataBusinessBean.setBlBankName(bl.getBankName());
    snBillingRequestDataBusinessBean.setBlBankBranchCode(bl.getBankBranchCode());
    snBillingRequestDataBusinessBean.setBlBankBranchName(bl.getBankBranchName());
    snBillingRequestDataBusinessBean.setBlBtOfAccountCode(bl.getBtOfAccountCode());
    snBillingRequestDataBusinessBean.setBlBtOfAccount(bl.getBtOfAccount());
    snBillingRequestDataBusinessBean.setBlAccountNo(bl.getAccountNo());
    snBillingRequestDataBusinessBean.setBlAccountHolderName(bl.getAccountHolderName());
    snBillingRequestDataBusinessBean.setBlNote(bl.getNote());
  }

  /**
   *
   * 請求依頼データBean設定（契約者）
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * DBより取得した契約者を請求依頼データBeanに設定しておく。
   * </pre>
   *
   * @param contractor
   *          契約者Bean
   * @param snBillingRequestDataBusinessBean
   *          請求依頼データBean
   */
  private void setContractor(Contractor contractor,
      SN_BillingRequestDataBusinessBean snBillingRequestDataBusinessBean) {

    // ■《契約者EntityBean》
    snBillingRequestDataBusinessBean.setContractorContractorId(String.valueOf(contractor.getContractorId()));
    snBillingRequestDataBusinessBean.setContractorContractorNo(contractor.getContractorNo());
    snBillingRequestDataBusinessBean.setContractorCn1Kana(contractor.getCn1Kana());
    snBillingRequestDataBusinessBean.setContractorCn1(contractor.getCn1());
    snBillingRequestDataBusinessBean.setContractorCn2(contractor.getCn2());
    snBillingRequestDataBusinessBean.setContractorCn1MailingName(contractor.getCn1MailingName());
    snBillingRequestDataBusinessBean.setContractorCn2MailingName(contractor.getCn2MailingName());
    snBillingRequestDataBusinessBean.setContractorPrefix(contractor.getPrefix());
    snBillingRequestDataBusinessBean.setContractorCaPostalCode(contractor.getCaPostalCode());
    snBillingRequestDataBusinessBean.setContractorCaFull(contractor.getCaFull());
    snBillingRequestDataBusinessBean.setContractorCaBuilding(contractor.getCaBuilding());
    snBillingRequestDataBusinessBean.setContractorCaPrefectures(contractor.getCaPrefectures());
    snBillingRequestDataBusinessBean.setContractorCaMunicipality(contractor.getCaMunicipality());
    snBillingRequestDataBusinessBean.setContractorCaSection(contractor.getCaSection());
    snBillingRequestDataBusinessBean.setContractorCaBlock(contractor.getCaBlock());
    snBillingRequestDataBusinessBean.setContractorCaBuildingName(contractor.getCaBuildingName());
    snBillingRequestDataBusinessBean.setContractorCaRoom(contractor.getCaRoom());
    snBillingRequestDataBusinessBean.setContractorCphNo1(contractor.getCphNo1());
    snBillingRequestDataBusinessBean.setContractorCphCatCode1(contractor.getCphCatCode1());
    snBillingRequestDataBusinessBean.setContractorCphAreaCode1(contractor.getCphAreaCode1());
    snBillingRequestDataBusinessBean.setContractorCphLocalNo1(contractor.getCphLocalNo1());
    snBillingRequestDataBusinessBean.setContractorCphDirectoryNo1(contractor.getCphDirectoryNo1());
    snBillingRequestDataBusinessBean.setContractorCphNo2(contractor.getCphNo2());
    snBillingRequestDataBusinessBean.setContractorCphCatCode2(contractor.getCphCatCode2());
    snBillingRequestDataBusinessBean.setContractorCphAreaCode2(contractor.getCphAreaCode2());
    snBillingRequestDataBusinessBean.setContractorCphLocalNo2(contractor.getCphLocalNo2());
    snBillingRequestDataBusinessBean.setContractorCphDirectoryNo2(contractor.getCphDirectoryNo2());
    snBillingRequestDataBusinessBean.setContractorCma1(contractor.getCma1());
    snBillingRequestDataBusinessBean.setContractorCma2(contractor.getCma2());
    snBillingRequestDataBusinessBean.setContractorPmCode(contractor.getPmCode());
    snBillingRequestDataBusinessBean.setContractorPmCompanyCode(contractor.getPmCompanyCode());
    snBillingRequestDataBusinessBean.setContractorUnavailableFlag(contractor.getUnavailableFlag());
    snBillingRequestDataBusinessBean.setContractorCustomerCode(contractor.getCustomerCode());
    snBillingRequestDataBusinessBean.setContractorUrgeNotCoveredFlag(contractor.getUrgeNotCoveredFlag());
    snBillingRequestDataBusinessBean.setContractorIlcCode(contractor.getIlcCode());
    snBillingRequestDataBusinessBean.setContractorVisualizationProvideFlag(contractor
        .getVisualizationProvideFlag());
    snBillingRequestDataBusinessBean.setContractorNote(contractor.getNote());
  }

  /**
   *
   * 請求依頼データBean設定（口座クレカ情報）
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * DBより取得した口座クレカ情報を請求依頼データBeanに設定しておく。
   * </pre>
   *
   * @param acInformation
   *          口座クレカ情報Bean
   * @param snBillingRequestDataBusinessBean
   *          請求依頼データBean
   */
  private void setAcInformation(AcInformation acInformation,
      SN_BillingRequestDataBusinessBean snBillingRequestDataBusinessBean) {

    // ■《口座クレカ情報EntityBean》
    if (acInformation != null) {
      snBillingRequestDataBusinessBean.setAcInformationAccountCreId(String.valueOf(acInformation
          .getAccountCreId()));
      snBillingRequestDataBusinessBean.setAcInformationContractorId(String.valueOf(acInformation
          .getContractorId()));
      snBillingRequestDataBusinessBean.setAcInformationAccessKey(acInformation.getAccessKey());
      snBillingRequestDataBusinessBean.setAcInformationAcCatCode(acInformation.getAcCatCode());
      snBillingRequestDataBusinessBean.setAcInformationBankCode(acInformation.getBankCode());
      snBillingRequestDataBusinessBean.setAcInformationBankBranchCode(acInformation.getBankBranchCode());
      snBillingRequestDataBusinessBean.setAcInformationBtOfAccountCode(acInformation.getBtOfAccountCode());
      snBillingRequestDataBusinessBean.setAcInformationAccountNo(acInformation.getAccountNo());
      snBillingRequestDataBusinessBean.setAcInformationAccountHolderName(acInformation.getAccountHolderName());
      snBillingRequestDataBusinessBean.setAcInformationCreBrandCode(acInformation.getCreBrandCode());
      snBillingRequestDataBusinessBean.setAcInformationCreNo(acInformation.getCreNo());
      snBillingRequestDataBusinessBean.setAcInformationCreExpirationDate(acInformation.getCreExpirationDate());
      snBillingRequestDataBusinessBean.setAcInformationUnavailableFlag(acInformation.getUnavailableFlag());
    }
  }

  /**
   *
   * 請求依頼データBean設定（支払履歴）
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * DBより取得した支払履歴を請求依頼データBeanに設定しておく。
   * </pre>
   *
   * @param paymentHist
   *          支払履歴Bean
   * @param snBillingRequestDataBusinessBean
   *          請求依頼データBean
   */
  private void setPaymentHist(PaymentHist paymentHist,
      SN_BillingRequestDataBusinessBean snBillingRequestDataBusinessBean) {

    if (paymentHist != null) {
      // ■《支払履歴EntityBean》
      SimpleDateFormat formatDate = new SimpleDateFormat(EMSConstants.FORMAT_DATE_yyyyMMdd);
      snBillingRequestDataBusinessBean.setPaymentHistPaymentId(String.valueOf(paymentHist.getPaymentId()));
      snBillingRequestDataBusinessBean.setPaymentHistPaymentSd(formatDate.format(paymentHist.getPaymentSd()));
      snBillingRequestDataBusinessBean.setPaymentHistPaymentEd(formatDate.format(paymentHist.getPaymentEd()));
      snBillingRequestDataBusinessBean.setPaymentHistPwCode(paymentHist.getPwCode());
      if (paymentHist.getAccountCreId() != null) {
        snBillingRequestDataBusinessBean
            .setPaymentHistAccountCreId(String.valueOf(paymentHist.getAccountCreId()));
      }
      snBillingRequestDataBusinessBean.setPaymentHistIlcCode(paymentHist.getIlcCode());
      snBillingRequestDataBusinessBean.setPaymentHistBlName1(paymentHist.getBlName1());
      snBillingRequestDataBusinessBean.setPaymentHistBlName2(paymentHist.getBlName2());
      snBillingRequestDataBusinessBean.setPaymentHistPrefix(paymentHist.getPrefix());
      snBillingRequestDataBusinessBean.setPaymentHistBlAddressPostalCode(paymentHist.getBlAddressPostalCode());
      snBillingRequestDataBusinessBean.setPaymentHistBlAddressPrefectures(paymentHist.getBlAddressPrefectures());
      snBillingRequestDataBusinessBean
          .setPaymentHistBlAddressMunicipality(paymentHist.getBlAddressMunicipality());
      snBillingRequestDataBusinessBean.setPaymentHistBlAddressSection(paymentHist.getBlAddressSection());
      snBillingRequestDataBusinessBean.setPaymentHistBlAddressBlock(paymentHist.getBlAddressBlock());
      snBillingRequestDataBusinessBean
          .setPaymentHistBlAddressBuildingName(paymentHist.getBlAddressBuildingName());
      snBillingRequestDataBusinessBean.setPaymentHistBlAddressRoom(paymentHist.getBlAddressRoom());
      snBillingRequestDataBusinessBean.setPaymentHistBlPhoneNo(paymentHist.getBlPhoneNo());
      snBillingRequestDataBusinessBean.setPaymentHistBlPhoneCatCode(paymentHist.getBlPhoneCatCode());
      snBillingRequestDataBusinessBean.setPaymentHistBlMailAddress1(paymentHist.getBlMailAddress1());
      snBillingRequestDataBusinessBean.setPaymentHistBlMailAddress2(paymentHist.getBlMailAddress2());
    }
  }

  /**
   *
   * 請求依頼データBean設定（需要場所）
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * DBより取得した需要場所を請求依頼データBeanに設定しておく。
   * </pre>
   *
   * @param place
   *          需要場所Bean
   * @param snBillingRequestDataBusinessBean
   *          請求依頼データBean
   */
  private void setPlace(Place place,
      SN_BillingRequestDataBusinessBean snBillingRequestDataBusinessBean) {

    // ■《需要場所EntityBean》
    if (place != null) {
      snBillingRequestDataBusinessBean.setPlacePlaceId(String.valueOf(place.getPlaceId()));
      snBillingRequestDataBusinessBean.setPlacePlaceAddressPostalCode(place.getPlaceAddressPostalCode());
      snBillingRequestDataBusinessBean.setPlacePlaceAddressFull(place.getPlaceAddressFull());
      snBillingRequestDataBusinessBean.setPlacePlaceAddressBuilding(place.getPlaceAddressBuilding());
    }
  }

  /**
   *
   * 請求依頼データBean設定（督促管理）
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * DBより取得した督促管理を請求依頼データBeanに設定しておく。
   * </pre>
   *
   * @param urgeMng
   *          督促管理Bean
   * @param snBillingRequestDataBusinessBean
   *          請求依頼データBean
   */
  private void setUrgeMng(UrgeMng urgeMng,
      SN_BillingRequestDataBusinessBean snBillingRequestDataBusinessBean) {

    // ■《督促管理EntityBean》
    if (urgeMng != null) {
      SimpleDateFormat formatDate = new SimpleDateFormat(EMSConstants.FORMAT_DATE_yyyyMMdd);
      snBillingRequestDataBusinessBean.setUrgeMngUrgeMngId(String.valueOf(urgeMng.getUrgeMngId()));
      snBillingRequestDataBusinessBean.setUrgeMngCpBlId(String.valueOf(urgeMng.getCpBlId()));
      if (urgeMng.getCpEnforceDate() != null) {
        snBillingRequestDataBusinessBean.setUrgeMngCpEnforceDate(formatDate.format(urgeMng.getCpEnforceDate()));
      }
      if (urgeMng.getCancellationNoticeDate() != null) {
        snBillingRequestDataBusinessBean.setUrgeMngCancellationNoticeDate(formatDate.format(urgeMng
            .getCancellationNoticeDate()));
      }
      if (urgeMng.getCePfd() != null) {
        snBillingRequestDataBusinessBean.setUrgeMngCePfd(formatDate.format(urgeMng.getCePfd()));
      }
      if (urgeMng.getCancellationScheduledDate() != null) {
        snBillingRequestDataBusinessBean.setUrgeMngCancellationScheduledDate(formatDate.format(urgeMng
            .getCancellationScheduledDate()));
      }
      snBillingRequestDataBusinessBean.setUrgeMngUrgeStatusCode(urgeMng.getUrgeStatusCode());
      snBillingRequestDataBusinessBean.setUrgeMngCeReasonCode(urgeMng.getCeReasonCode());
      if (urgeMng.getCeDate() != null) {
        snBillingRequestDataBusinessBean.setUrgeMngCeDate(formatDate.format(urgeMng.getCeDate()));
      }
      snBillingRequestDataBusinessBean.setUrgeMngUrgeNote(urgeMng.getUrgeNote());
    }
  }

  /**
   *
   * 請求依頼データBean設定（契約）
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * DBより取得した契約を請求依頼データBeanに設定しておく。
   * </pre>
   *
   * @param contract
   *          契約Bean
   * @param snBillingRequestDataBusinessBean
   *          請求依頼データBean
   */
  private void setContract(Contract contract,
      SN_BillingRequestDataBusinessBean snBillingRequestDataBusinessBean) {

    // ■《契約EntityBean》
    if (contract != null) {
      SimpleDateFormat formatDate = new SimpleDateFormat(EMSConstants.FORMAT_DATE_yyyyMMdd);
      snBillingRequestDataBusinessBean.setContractContractId(String.valueOf(contract.getContractId()));
      snBillingRequestDataBusinessBean.setContractContractorId(String.valueOf(contract.getContractorId()));
      snBillingRequestDataBusinessBean.setContractPaymentId(String.valueOf(contract.getPaymentId()));
      snBillingRequestDataBusinessBean.setContractContractSd(formatDate.format(contract.getContractSd()));
      snBillingRequestDataBusinessBean.setContractContractEd(formatDate.format(contract.getContractEd()));
      snBillingRequestDataBusinessBean.setContractContractNo(contract.getContractNo());
      snBillingRequestDataBusinessBean.setContractContractEndReasonCode(contract.getContractEndReasonCode());
      snBillingRequestDataBusinessBean.setContractChargeCheckFlag(contract.getChargeCheckFlag());
      snBillingRequestDataBusinessBean.setContractScCode(contract.getScCode());
      snBillingRequestDataBusinessBean.setContractContractGroupNo(contract.getContractGroupNo());
      snBillingRequestDataBusinessBean.setContractIlcCode(contract.getIlcCode());
      snBillingRequestDataBusinessBean.setContractCiNameKana(contract.getCiNameKana());
      snBillingRequestDataBusinessBean.setContractCiName1(contract.getCiName1());
      snBillingRequestDataBusinessBean.setContractCiName2(contract.getCiName2());
      snBillingRequestDataBusinessBean.setContractCiAddressPostalCode(contract.getCiAddressPostalCode());
      snBillingRequestDataBusinessBean.setContractCiAddressFull(contract.getCiAddressFull());
      snBillingRequestDataBusinessBean.setContractCiAddressBuilding(contract.getCiAddressBuilding());
      snBillingRequestDataBusinessBean.setContractCiPhoneNo(contract.getCiPhoneNo());
      snBillingRequestDataBusinessBean.setContractCiCatCode(contract.getCiCatCode());
      snBillingRequestDataBusinessBean.setContractCiAreaCode(contract.getCiAreaCode());
      snBillingRequestDataBusinessBean.setContractCiLocalNo(contract.getCiLocalNo());
      snBillingRequestDataBusinessBean.setContractCiDirectoryNo(contract.getCiDirectoryNo());
      snBillingRequestDataBusinessBean.setContractBusinessTypeCode(contract.getBusinessTypeCode());
      snBillingRequestDataBusinessBean.setContractCssCatCode(contract.getCssCatCode());
      if (contract.getConsignmentCca() != null) {
        snBillingRequestDataBusinessBean.setContractConsignmentCca(contract.getConsignmentCca().toString());
      }
      snBillingRequestDataBusinessBean.setContractConsignmentCcaUnit(contract.getConsignmentCcaUnit());
      if (contract.getConsignmentCcaDecisionDate() != null) {
        snBillingRequestDataBusinessBean.setContractConsignmentCcaDecisionDate(formatDate.format(contract
            .getConsignmentCcaDecisionDate()));
      }
      snBillingRequestDataBusinessBean.setContractContractEndFuSentFlag(contract.getContractEndFuSentFlag());
      snBillingRequestDataBusinessBean.setContractNote(contract.getNote());
      snBillingRequestDataBusinessBean.setContractFree1(contract.getFree1());
      snBillingRequestDataBusinessBean.setContractFree2(contract.getFree2());
      snBillingRequestDataBusinessBean.setContractFree3(contract.getFree3());
      snBillingRequestDataBusinessBean.setContractFree4(contract.getFree4());
      snBillingRequestDataBusinessBean.setContractFree5(contract.getFree5());
      snBillingRequestDataBusinessBean.setContractFree6(contract.getFree6());
      snBillingRequestDataBusinessBean.setContractFree7(contract.getFree7());
      snBillingRequestDataBusinessBean.setContractFree8(contract.getFree8());
      snBillingRequestDataBusinessBean.setContractFree9(contract.getFree9());
      snBillingRequestDataBusinessBean.setContractFree10(contract.getFree10());
      snBillingRequestDataBusinessBean.setContractFree11(contract.getFree11());
      snBillingRequestDataBusinessBean.setContractFree12(contract.getFree12());
      snBillingRequestDataBusinessBean.setContractFree13(contract.getFree13());
      snBillingRequestDataBusinessBean.setContractFree14(contract.getFree14());
      snBillingRequestDataBusinessBean.setContractConsignmentUseItem1(contract.getConsignmentUseItem1());
      snBillingRequestDataBusinessBean.setContractConsignmentUseItem2(contract.getConsignmentUseItem2());
      snBillingRequestDataBusinessBean.setContractConsignmentUseItem3(contract.getConsignmentUseItem3());
      snBillingRequestDataBusinessBean
          .setContractOurMngPersonInChargeCode(contract.getOurMngPersonInChargeCode());
      snBillingRequestDataBusinessBean.setContractOurMngDepartmentCode(contract.getOurMngDepartmentCode());
    }
  }

  /**
   *
   * 請求依頼データBean設定（提供モデル企業マスタ）
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * DBより取得した提供モデル企業マスタを請求依頼データBeanに設定しておく。
   * </pre>
   *
   * @param pmCompanyM
   *          提供モデル企業マスタBean
   * @param snBillingRequestDataBusinessBean
   *          請求依頼データBean
   */
  private void setPmCompanyM(PmCompanyM pmCompanyM,
      SN_BillingRequestDataBusinessBean snBillingRequestDataBusinessBean) {

    if (pmCompanyM != null) {
      // ■《提供モデル企業マスタEntityBean》
      SimpleDateFormat formatDate = new SimpleDateFormat(EMSConstants.FORMAT_DATE_yyyyMMdd);
      snBillingRequestDataBusinessBean.setPmCompanyMPmCode(pmCompanyM.getPmCode());
      snBillingRequestDataBusinessBean.setPmCompanyMPmCompanyCode(pmCompanyM.getPmCompanyCode());
      snBillingRequestDataBusinessBean.setPmCompanyMPmCompany(pmCompanyM.getPmCompany());
      snBillingRequestDataBusinessBean.setPmCompanyMPmCompanyKana(pmCompanyM.getPmCompanyKana());
      snBillingRequestDataBusinessBean.setPmCompanyMEffectiveSd(formatDate.format(pmCompanyM.getEffectiveSd()));
      snBillingRequestDataBusinessBean.setPmCompanyMEffectiveEd(formatDate.format(pmCompanyM.getEffectiveEd()));
      snBillingRequestDataBusinessBean.setPmCompanyMAddresseePostalCode(pmCompanyM.getAddresseePostalCode());
      snBillingRequestDataBusinessBean.setPmCompanyMAddresseePrefectures(pmCompanyM.getAddresseePrefectures());
      snBillingRequestDataBusinessBean.setPmCompanyMAddresseeMunicipality(pmCompanyM.getAddresseeMunicipality());
      snBillingRequestDataBusinessBean.setPmCompanyMAddresseeSection(pmCompanyM.getAddresseeSection());
      snBillingRequestDataBusinessBean.setPmCompanyMAddresseeBlock(pmCompanyM.getAddresseeBlock());
      snBillingRequestDataBusinessBean.setPmCompanyMAddresseeBuildingName(pmCompanyM.getAddresseeBuildingName());
      snBillingRequestDataBusinessBean.setPmCompanyMAddresseeRoom(pmCompanyM.getAddresseeRoom());
      snBillingRequestDataBusinessBean.setPmCompanyMAddresseeMailingName1(pmCompanyM.getAddresseeMailingName1());
      snBillingRequestDataBusinessBean.setPmCompanyMAddresseeMailingName2(pmCompanyM.getAddresseeMailingName2());
      snBillingRequestDataBusinessBean.setPmCompanyMPrefix(pmCompanyM.getPrefix());
      snBillingRequestDataBusinessBean.setPmCompanyMPfdDays(String.valueOf(pmCompanyM.getPfdDays()));
      snBillingRequestDataBusinessBean.setPmCompanyMAllotmentBankCode(pmCompanyM.getAllotmentBankCode());
      snBillingRequestDataBusinessBean.setPmCompanyMAllotmentBankBranchCode(pmCompanyM
          .getAllotmentBankBranchCode());
      snBillingRequestDataBusinessBean.setPmCompanyMAllotmentBtOfAccountCode(pmCompanyM
          .getAllotmentBtOfAccountCode());
      snBillingRequestDataBusinessBean.setPmCompanyMAaNo(pmCompanyM.getAaNo());
      snBillingRequestDataBusinessBean.setPmCompanyMAaHolderName(pmCompanyM.getAaHolderName());
      snBillingRequestDataBusinessBean.setPmCompanyMVisualizationProvideFlag(pmCompanyM
          .getVisualizationProvideFlag());
      snBillingRequestDataBusinessBean.setPmCompanyMPpsCat(pmCompanyM.getPpsCat());
    }
  }

  /**
   *
   * 文字列区切り編集
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 対象文字列を指定した区切りバイト数で区切ってリストに設定する。
   * </pre>
   *
   * @param target
   *          対象文字列
   * @param delimiter
   *          区切りバイト数
   * @return List<String> 区切り文字列リスト
   */
  private List<String> delimitString(String target, int delimiter) {

    List<String> list = new ArrayList<>();
    // 対象文字列をcharの文字配列に設定
    char[] chars = target.toCharArray();

    int cnt = 0;
    int beginIndex = 0;
    // 文字配列分、繰り返す。
    for (int i = 0; i < chars.length; i++) {
      char c = chars[i];

      // 半角判定
      if ((c <= ECISConstants.UNICODE_ALPHANUMERIC_UPPER_LIMIT) || // 英数字
          (c == ECISConstants.UNICODE_YEN_SIGN) || // \記号
          (c == ECISConstants.UNICODE_OVER_LINE) || // ~記号
          (c >= ECISConstants.UNICODE_HALFKANA_LOWER_LIMIT
              && c <= ECISConstants.UNICODE_HALFKANA_UPPER_LIMIT) // 半角カナ
      ) {
        // 半角の場合
        cnt += 1;
      } else {
        // 全角の場合
        cnt += 2;
      }

      if (cnt == delimiter) {
        // 区切りバイト数に達した場合、区切り位置までの文字列をリストに設定
        list.add(target.substring(beginIndex, i + 1));
        beginIndex = i + 1;
        cnt = 0;
      }
      if (cnt > delimiter) {
        // 区切りバイト数を超えた場合（区切り位置が全角の場合）、区切り位置の前までの文字列をリストに設定
        list.add(target.substring(beginIndex, i));
        beginIndex = i;
        cnt = 0;
        i--;
      }
    }

    // 残りの文字列がある場合、残り全てを設定
    if (beginIndex < chars.length) {
      list.add(target.substring(beginIndex));
    }

    return list;
  }

  /**
   * プロパティ値の取得
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * プロパティ値の取得して返却する。
   * 値がnullの場合、エラーメッセージをスローする。
   * </pre>
   *
   * @param prop
   *          プロパティオブジェクト
   * @param key
   *          プロパティキー
   * @return String プロパティ値
   */
  private String getProp(Properties prop, String key) {

    // プロパティ値を取得
    String value = prop.getProperty(key);
    if (StringUtils.isEmpty(value)) {
      // nullの場合、エラーメッセージをスローする。
      SystemException se = new SystemException(
          messageSource.getMessage("error.E1410", new String[] {
              key }, Locale.getDefault()));
      throw se;
    }
    return value;
  }

  /**
   * 業務共通ビジネスを設定する。（DI）
   *
   * @param gkWorkCommonBusiness
   *          業務共通ビジネス
   */
  public void setGkWorkCommonBusiness(
      GK_WorkCommonBusiness gkWorkCommonBusiness) {
    this.gkWorkCommonBusiness = gkWorkCommonBusiness;
  }

  /**
   * メッセージプロパティを設定する。（DI）
   *
   * @param messageSource
   *          メッセージプロパティ
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }

}
