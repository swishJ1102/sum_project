package jp.co.unisys.enability.cis.business.rk;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.springframework.context.MessageSource;

import jp.co.unisys.enability.cis.business.common.TodoBusiness;
import jp.co.unisys.enability.cis.business.common.model.TodoBusinessBean;
import jp.co.unisys.enability.cis.business.rk.model.RK_UsageLinkageCheckCheckDataBusinessBean;
import jp.co.unisys.enability.cis.business.rk.model.RK_UsageLinkageCheckContractBusinessBean;
import jp.co.unisys.enability.cis.business.rk.model.RK_UsageLinkageCheckTermDecisionBusinessBean;
import jp.co.unisys.enability.cis.common.util.ThreadContext;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISTodoConstants;
import jp.co.unisys.enability.cis.dao.rk.RK_UsageLinkageCheckDao;
import jp.co.unisys.enability.cis.entity.common.Mur;
import jp.co.unisys.enability.cis.entity.common.Todo;
import jp.co.unisys.enability.cis.entity.common.TodoExample;
import jp.co.unisys.enability.cis.entity.rk.RK_UsageLinkageCheckCheckDataEntityBean;
import jp.co.unisys.enability.cis.entity.rk.RK_UsageLinkageCheckTermDecisionEntityBean;
import jp.co.unisys.enability.cis.mapper.common.MurMapper;
import jp.co.unisys.enability.cis.mapper.common.TodoMapper;

/**
 * 使用量連携チェックビジネスクラス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_UsageLinkageCheckBusinessImpl implements
    RK_UsageLinkageCheckBusiness {

  /** 使用量連携チェックDao(DI) */
  private RK_UsageLinkageCheckDao rkUsageLinkageCheckDao;

  /** 月次実績Mapper(DI) */
  private MurMapper murMapper;

  /** TODOビジネス(DI) */
  private TodoBusiness todoBusiness;

  /** メッセージリソース(DI) */
  private MessageSource messageSource;

  /** TODOマッパー(DI) */
  private TodoMapper todoMapper;

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.rk.RK_UsageLinkageCheckBusiness#
   * selectCheckData(java.util.Date)
   */
  @Override
  public List<RK_UsageLinkageCheckCheckDataBusinessBean> selectCheckData(
      Date executeDate) {

    // チェック対象データ取得
    List<RK_UsageLinkageCheckCheckDataEntityBean> sourceList = rkUsageLinkageCheckDao
        .selectCheckData(executeDate);

    // BusinessBeanを格納するリストを作成
    List<RK_UsageLinkageCheckCheckDataBusinessBean> destList = new ArrayList<RK_UsageLinkageCheckCheckDataBusinessBean>(
        sourceList.size());

    // チェック対象データを保持するBean
    RK_UsageLinkageCheckCheckDataBusinessBean rKUsageLinkageCheckCheckDataBusinessBean = null;

    // 取得したチェック対象データごとに繰り返し
    for (RK_UsageLinkageCheckCheckDataEntityBean source : sourceList) {

      // Beanを生成
      rKUsageLinkageCheckCheckDataBusinessBean = new RK_UsageLinkageCheckCheckDataBusinessBean();

      // EntityBeanからBusinessBeanへデータをコピーする
      // 地点特定番号
      rKUsageLinkageCheckCheckDataBusinessBean.setSpotNo(source
          .getSpotNo());
      // 確定使用量ファイル名
      rKUsageLinkageCheckCheckDataBusinessBean.setFixUsageFileName(source
          .getFixUsageFileName());
      // エリアコード
      rKUsageLinkageCheckCheckDataBusinessBean.setAreaCode(source
          .getAreaCode());
      // 検針日
      rKUsageLinkageCheckCheckDataBusinessBean.setMeterReadingDate(source
          .getMeterReadingDate());
      // 次回検針予定日
      rKUsageLinkageCheckCheckDataBusinessBean
          .setNextMeterReadingScheduledDate(source
              .getNextMeterReadingScheduledDate());
      // 仕訳コード
      rKUsageLinkageCheckCheckDataBusinessBean.setCategorizeCode(source
          .getCategorizeCode());
      // 提供可否コード
      rKUsageLinkageCheckCheckDataBusinessBean.setProvideCheckCode(source
          .getProvideCheckCode());
      // 電圧区分
      rKUsageLinkageCheckCheckDataBusinessBean.setVoltageCategoryName(source
          .getVoltageCategoryName());
      // 月次実績エラー区分コード
      rKUsageLinkageCheckCheckDataBusinessBean
          .setMonthlyUsageResultErrorCategoryCode(source
              .getMonthlyUsageResultErrorCategoryCode());
      // 更新番号
      rKUsageLinkageCheckCheckDataBusinessBean.setUpdateNo(source
          .getUpdateNo());
      // 分割番号
      rKUsageLinkageCheckCheckDataBusinessBean.setSplitNo(source
          .getSplitNo());
      // 最大更新番号
      rKUsageLinkageCheckCheckDataBusinessBean.setMaxUpdateNo(source
          .getMaxUpdateNo());
      // 地点特定番号有効フラグ
      rKUsageLinkageCheckCheckDataBusinessBean
          .setSpotNoEffectiveFlag(source.getSpotNoEffectiveFlag());
      // バッチ実行日
      rKUsageLinkageCheckCheckDataBusinessBean
          .setExecuteDate(executeDate);
      // 更新コード
      rKUsageLinkageCheckCheckDataBusinessBean.setUpdateCode(source.getUpdateCode());
      // 計算済みフラグ
      rKUsageLinkageCheckCheckDataBusinessBean.setCalculatedFlag(source.getCalculatedFlag());

      // リストにBeanを追加
      destList.add(rKUsageLinkageCheckCheckDataBusinessBean);
    }

    return destList;
  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.rk.RK_UsageLinkageCheckBusiness#
   * selectTermDecision(java.lang.String, java.lang.String, java.lang.String)
   */
  @Override
  public RK_UsageLinkageCheckTermDecisionBusinessBean selectTermDecision(
      String spotNo, String fixUsageFileName, String areaCode, String abolitionFlag) {

    // 期間判定情報を取得する
    List<RK_UsageLinkageCheckTermDecisionEntityBean> sourceList = rkUsageLinkageCheckDao
        .selectTermDecision(spotNo, fixUsageFileName, areaCode, abolitionFlag);

    // BusinessBeanを格納するリストを作成
    List<RK_UsageLinkageCheckContractBusinessBean> contractList = new ArrayList<RK_UsageLinkageCheckContractBusinessBean>();

    // 30分電力量を保持するBean
    RK_UsageLinkageCheckTermDecisionBusinessBean rKUsageLinkageCheckTermDecisionBusinessBean = new RK_UsageLinkageCheckTermDecisionBusinessBean();

    // 期間判定情報を保持するBean
    RK_UsageLinkageCheckContractBusinessBean rKUsageLinkageCheckContractBusinessBean = null;

    // 取得した期間判定情報ごとに繰り返し
    for (RK_UsageLinkageCheckTermDecisionEntityBean source : sourceList) {

      // 対象期間が未設定であれば設定する
      if (rKUsageLinkageCheckTermDecisionBusinessBean
          .getCoveredTermStartDate() == null) {
        rKUsageLinkageCheckTermDecisionBusinessBean
            .setCoveredTermStartDate(source
                .getCoveredTermStartDate());
        rKUsageLinkageCheckTermDecisionBusinessBean
            .setCoveredTermEndDate(source.getCoveredTermEndDate());
      }

      // Beanを生成
      rKUsageLinkageCheckContractBusinessBean = new RK_UsageLinkageCheckContractBusinessBean();

      // EntityBeanからBusinessBeanへデータをコピーする
      // 契約番号
      rKUsageLinkageCheckContractBusinessBean.setContractNo(source
          .getContractNo());
      // 契約開始日
      rKUsageLinkageCheckContractBusinessBean.setContractStartDate(source
          .getContractStartDate());
      // 契約終了日
      rKUsageLinkageCheckContractBusinessBean.setContractEndDate(source
          .getContractEndDate());
      // 契約終了分確定使用量連携済フラグ
      rKUsageLinkageCheckContractBusinessBean
          .setContractEndFixUsageSentFlag(source
              .getContractEndFixUsageSentFlag());
      // 契約終了理由コード
      rKUsageLinkageCheckContractBusinessBean
          .setContractEndReasonCode(source.getContractEndReasonCode());
      // 前回使用終了日
      rKUsageLinkageCheckContractBusinessBean
          .setLastTimeUsageEndDate(source
              .getLastTimeUsageEndDate());

      // Beanをリストへ追加
      contractList.add(rKUsageLinkageCheckContractBusinessBean);
    }

    // リストをBeanに設定
    rKUsageLinkageCheckTermDecisionBusinessBean
        .setContractList(contractList);

    return rKUsageLinkageCheckTermDecisionBusinessBean;
  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.rk.RK_UsageLinkageCheckBusiness#
   * updateMonthlyUsageResult(jp.co.unisys.enability.cis.business.rk.model.
   * RK_UsageLinkageCheckCheckDataBusinessBean, java.lang.String)
   */
  @Override
  public void updateMonthlyUsageResult(
      RK_UsageLinkageCheckCheckDataBusinessBean checkDataBusinessBean,
      String errorCategoryCode) {

    // タイムスタンプ・モジュールコード
    Timestamp timestamp = new Timestamp(new Date().getTime());
    String moduleCode = (String) ThreadContext.getRequestThreadContext()
        .get(ECISConstants.CLASS_NAME_KEY);

    // 月次実績Entity
    Mur mur = new Mur();

    // 【月次実績】を更新する情報を設定
    // 地点特定番号
    mur.setSpotNo(checkDataBusinessBean.getSpotNo());
    // 確定使用量ファイル名
    mur.setFuFileName(checkDataBusinessBean.getFixUsageFileName());
    // エリアコード
    mur.setAreaCode(checkDataBusinessBean.getAreaCode());
    // 月次実績エラー区分コード
    mur.setMurErrorCatCode(errorCategoryCode);
    // 更新時刻
    mur.setUpdateTime(timestamp);
    // 更新モジュールコード
    mur.setUpdateModuleCode(moduleCode);

    // 【月次実績】を更新する
    murMapper.updateByPrimaryKeySelective(mur);
  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.rk.RK_UsageLinkageCheckBusiness#
   * updateMonthlyUsageResultError
   * (jp.co.unisys.enability.cis.business.rk.model
   * .RK_UsageLinkageCheckCheckDataBusinessBean)
   */
  @Override
  public void updateMonthlyUsageResultError(
      RK_UsageLinkageCheckCheckDataBusinessBean checkDataBusinessBean) {

    // 【月次実績】.月次実績エラー区分コードを"エラー"で更新する
    updateMonthlyUsageResult(
        checkDataBusinessBean,
        ECISRKConstants.MONTHLY_USAGE_RESULT_ERROR_CATEGORY_MASTER_ERROR);
  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.rk.RK_UsageLinkageCheckBusiness#
   * updateMonthlyUsageResultIgnore
   * (jp.co.unisys.enability.cis.business.rk.model
   * .RK_UsageLinkageCheckCheckDataBusinessBean)
   */
  @Override
  public void updateMonthlyUsageResultIgnore(
      RK_UsageLinkageCheckCheckDataBusinessBean checkDataBusinessBean) {

    // 【月次実績】.月次実績エラー区分コードを"無視"で更新する
    updateMonthlyUsageResult(
        checkDataBusinessBean,
        ECISRKConstants.MONTHLY_USAGE_RESULT_ERROR_CATEGORY_MASTER_IGNORE);
  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.rk.RK_UsageLinkageCheckBusiness#
   * registerTodo(java.lang.String, java.lang.String, java.lang.Object[], java.lang.String, java.lang.String,
   * java.util.Date)
   */
  @Override
  public void registerTodo(String messageId, Object[] params, String noteMessageId, Object[] noteParams,
      String contractNo, String spotNo, Date nextMrScheduledDate) {

    // デフォルトロケール
    Locale defaultLocale = Locale.getDefault();

    // TODOビジネスBean
    TodoBusinessBean todoBean = new TodoBusinessBean();

    // TODOを更新する情報を設定する
    // 契約番号
    todoBean.setContractNo(contractNo);
    // 地点特定番号
    todoBean.setSpotNo(spotNo);
    // 次回検針予定日
    todoBean.setNextMrScheduledDate(nextMrScheduledDate);
    // サブシステムID
    todoBean.setSubsystemId(ECISConstants.SUBSYSTEM_ID_RK);
    // ファンクションID
    todoBean.setFunctionId(ECISTodoConstants.TODO_FUNCTION_ID.RK0102
        .toString());
    // メッセージID
    todoBean.setMessageId(messageId);
    // メッセージ
    todoBean.setMessage(messageSource.getMessage(messageId, params, defaultLocale));
    // 備考
    if (noteMessageId != null) {
      todoBean.setNote(messageSource.getMessage(noteMessageId, noteParams, defaultLocale));
    }

    // TODOを登録
    todoBusiness.registTodo(todoBean);
  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.rk.RK_UsageLinkageCheckBusiness#
   * selectTodo(java.lang.String, java.lang.String, java.lang.String, java.util.Date)
   */
  @Override
  public List<Todo> selectTodo(String functionId, String messageId, String spotNo, Date nextMrScheduledDate) {

    // 検索用オブジェクト作成
    TodoExample example = new TodoExample();
    // 機能ID
    example.createCriteria()
        .andFunctionIdEqualTo(functionId)
        // メッセージID
        .andMessageIdEqualTo(messageId)
        // 地点特定番号
        .andSpotNoEqualTo(spotNo)
        // 次回検針予定日
        .andNextMrScheduledDateEqualTo(nextMrScheduledDate);

    List<Todo> todoList = todoMapper.selectByExample(example);

    return todoList;
  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.rk.RK_UsageLinkageCheckBusiness#
   * updateTodo(java.util.List<Todo>, java.lang.String[])
   */
  @Override
  public void updateTodo(List<Todo> todoList, String[] params) {

    Date sysDate = new Date();
    Timestamp systime = new Timestamp(sysDate.getTime());
    // デフォルトロケール
    Locale defaultLocale = Locale.getDefault();

    for (Todo todo : todoList) {
      //更新日
      todo.setUpdateDate(systime);
      //メッセージ
      todo.setMessage(messageSource.getMessage(todo.getMessageId(), params, defaultLocale));
      //TODOステータスコード
      //TODOステータスコードが「2」以外の場合、
      if (!(todo.getTodoStatusCode().equals("2"))) {
        //TODO情報.TODOステータスコードを設定する
        todo.setTodoStatusCode(todo.getTodoStatusCode());
        //TODOステータスコードが「2」である場合、
      } else {
        //「1」を設定する
        todo.setTodoStatusCode("1");
      }
      //更新回数
      todo.setUpdateCount(todo.getUpdateCount() + 1);
      //更新日時
      todo.setUpdateTime(systime);
      //更新モジュールコード
      todo.setUpdateModuleCode(
          (String) ThreadContext.getRequestThreadContext().get(ECISConstants.CLASS_NAME_KEY));

      TodoExample example = new TodoExample();
      example.createCriteria()
          .andTodoIdEqualTo(todo.getTodoId());
      //TODOMapper.updateByExampleを呼び出し、TODOの更新を行う。
      todoMapper.updateByExample(todo, example);
    }

  }

  /**
   * 使用量連携チェックDaoを設定します。(DI)
   *
   * @param rkUsageLinkageCheckDao
   *          使用量連携チェックDao
   */
  public void setRkUsageLinkageCheckDao(
      RK_UsageLinkageCheckDao rkUsageLinkageCheckDao) {
    this.rkUsageLinkageCheckDao = rkUsageLinkageCheckDao;
  }

  /**
   * 月次実績Mapperを設定します。(DI)
   *
   * @param murMapper
   *          月次実績Mapper
   */
  public void setMurMapper(MurMapper murMapper) {
    this.murMapper = murMapper;
  }

  /**
   * TODOビジネスを設定します。(DI)
   *
   * @param todoBusiness
   *          TODOビジネス
   */
  public void setTodoBusiness(TodoBusiness todoBusiness) {
    this.todoBusiness = todoBusiness;
  }

  /**
   * メッセージリソースを設定します。(DI)
   *
   * @param messageSource
   *          メッセージリソース
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }

  /**
   * TODOMapperを設定します。(DI)
   *
   * @param todoMapper
   *          TODOMapper
   */
  public void setTodoMapper(TodoMapper todoMapper) {
    this.todoMapper = todoMapper;
  }
}
