package jp.co.unisys.enability.cis.business.rk.model;

import java.util.Date;

/**
 * 契約期間等の相関チェックを行うための情報を保持するビジネスBean。
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * 使用量連携チェックビジネス。
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_UsageLinkageCheckContractBusinessBean {

  /**
   * 契約番号を保有する。
   */
  private String contractNo;

  /**
   * 契約開始日を保有する。
   */
  private Date contractStartDate;

  /**
   * 契約終了日を保有する。
   */
  private Date contractEndDate;

  /**
   * 契約終了分確定使用量連携済フラグを保有する。
   */
  private String contractEndFixUsageSentFlag;

  /**
   * 契約終了理由コードを保有する。
   */
  private String contractEndReasonCode;

  /**
   * 前回使用終了日を保有する。
   */
  private Date lastTimeUsageEndDate;

  /**
   * 契約番号のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約番号を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約番号
   */
  public String getContractNo() {
    return this.contractNo;
  }

  /**
   * 契約番号のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約番号を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractNo
   *          契約番号
   */
  public void setContractNo(String contractNo) {
    this.contractNo = contractNo;
  }

  /**
   * 契約開始日のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約開始日を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約開始日
   */
  public Date getContractStartDate() {
    return this.contractStartDate;
  }

  /**
   * 契約開始日のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約開始日を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractStartDate
   *          契約開始日
   */
  public void setContractStartDate(Date contractStartDate) {
    this.contractStartDate = contractStartDate;
  }

  /**
   * 契約終了日のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約終了日を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約終了日
   */
  public Date getContractEndDate() {
    return this.contractEndDate;
  }

  /**
   * 契約終了日のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約終了日を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractEndDate
   *          契約終了日
   */
  public void setContractEndDate(Date contractEndDate) {
    this.contractEndDate = contractEndDate;
  }

  /**
   * 契約終了分確定使用量連携済フラグのgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約終了分確定使用量連携済フラグを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約終了分確定使用量連携済フラグ
   */
  public String getContractEndFixUsageSentFlag() {
    return this.contractEndFixUsageSentFlag;
  }

  /**
   * 契約終了分確定使用量連携済フラグのsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約終了分確定使用量連携済フラグを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractEndFixUsageSentFlag
   *          契約終了分確定使用量連携済フラグ
   */
  public void setContractEndFixUsageSentFlag(
      String contractEndFixUsageSentFlag) {
    this.contractEndFixUsageSentFlag = contractEndFixUsageSentFlag;
  }

  /**
   * 契約終了理由コードのgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約終了理由コードを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約終了理由コード
   */
  public String getContractEndReasonCode() {
    return this.contractEndReasonCode;
  }

  /**
   * 契約終了理由コードのsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約終了理由コードを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractEndReasonCode
   *          契約終了理由コード
   */
  public void setContractEndReasonCode(String contractEndReasonCode) {
    this.contractEndReasonCode = contractEndReasonCode;
  }

  /**
   * 前回使用終了日のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 前回使用終了日を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 前回使用終了日
   */
  public Date getLastTimeUsageEndDate() {
    return this.lastTimeUsageEndDate;
  }

  /**
   * 前回使用終了日のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 前回使用終了日を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param lastTimeUsageEndDate
   *          前回使用終了日
   */
  public void setLastTimeUsageEndDate(Date lastTimeUsageEndDate) {
    this.lastTimeUsageEndDate = lastTimeUsageEndDate;
  }

}
