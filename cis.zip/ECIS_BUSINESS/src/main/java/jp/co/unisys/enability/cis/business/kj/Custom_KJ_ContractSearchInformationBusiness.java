package jp.co.unisys.enability.cis.business.kj;

//[kg-epj]<d-start>
//import jp.co.unisys.enability.cis.business.kj.model.SearchContractBusinessBean;
//[kg-epj]<d-end>
//[kg-epj]<i-start>
import jp.co.unisys.enability.cis.business.kj.model.Custom_SearchContractBusinessBean;
//[kg-epj]<i-end>

/**
 * 契約情報ビジネスインターフェース。
 *
 * @author "Nihon Unisys, Ltd."
 *
 */
//[kg-epj]<d-start>
//public interface KJ_ContractSearchInformationBusiness {
//[kg-epj]<d-end>
//[kg-epj]<i-start>
public interface Custom_KJ_ContractSearchInformationBusiness {
  //[kg-epj]<i-end>

  /**
   * 契約情報の検索を行う。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * CRMや低圧CISからのオーダーにより、契約者および契約を特定するように検索し、検索結果を返却する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param searchContractBusinessn
   *          契約情報検索BusinessBean_カスタム
   * @return 契約情報検索BusinessBean_カスタム
   */
  //[kg-epj]<d-start>
  //    public SearchContractBusinessBean search(SearchContractBusinessBean searchContractBusiness);
  //[kg-epj]<d-end>
  //[kg-epj]<i-start>
  public Custom_SearchContractBusinessBean search(Custom_SearchContractBusinessBean searchContractBusiness);
  //[kg-epj]<i-end>

}
