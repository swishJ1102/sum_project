package jp.co.unisys.enability.cis.business.rk.model;

import java.math.BigDecimal;
import java.util.List;

import jp.co.unisys.enability.cis.entity.common.CclM;
import jp.co.unisys.enability.cis.entity.common.Contract;
import jp.co.unisys.enability.cis.entity.common.ContractAddInfo;
import jp.co.unisys.enability.cis.entity.common.ContractHist;
import jp.co.unisys.enability.cis.entity.common.DsUsage;
import jp.co.unisys.enability.cis.entity.common.Fcr;
import jp.co.unisys.enability.cis.entity.common.FcrBreakdown;
import jp.co.unisys.enability.cis.entity.common.FcrWarningData;
import jp.co.unisys.enability.cis.entity.common.FixIn;
import jp.co.unisys.enability.cis.entity.common.Fu;
import jp.co.unisys.enability.cis.entity.common.Rm;
import jp.co.unisys.enability.cis.entity.common.Rqh;
import jp.co.unisys.enability.cis.entity.common.Spm;
import jp.co.unisys.enability.cis.entity.common.TsUsage;
import jp.co.unisys.enability.cis.entity.common.WarningClassM;

/**
 * 料金計算オンライン共通ビジネスの情報を保持するクラス。
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * RK_OnlineCommonBusiness - 料金計算オンライン共通ビジネス
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_OnlineCommonBusinessBean {

  /**
   * 処理結果を保有する。
   */
  private Integer executeResult;

  /**
   * 確定料金実績IDを保有する。
   */
  private Integer fixChargeResultId;

  /**
   * 確定使用量IDを保有する。
   */
  private Integer fixUsageId;

  /**
   * 契約IDを保有する。
   */
  private Integer contractId;

  /**
   * 利用年月を保有する。
   */
  private String usePeriod;

  /**
   * 契約を保有する。
   */
  private Contract contract;

  /**
   * 契約付加情報を保有する。
   */
  private ContractAddInfo contractAddInfo;

  /**
   * 料金メニューを保有する。
   */
  private Rm rateMenu;

  /**
   * 付帯メニューを保有する。
   */
  private List<Spm> supplementaryMenuList;

  /**
   * 契約容量を保有する。
   */
  private BigDecimal contractCapacity;

  /**
   * 確定使用量を保有する。
   */
  private Fu fixUsage;

  /**
   * 確定指示数を保有する。
   */
  private FixIn fixIndicationNo;

  /**
   * 日割別使用量を保有する。
   */
  private List<DsUsage> dateSlotUsageList;

  /**
   * 時間帯別使用量を保有する。
   */
  private List<TsUsage> timeSlotUsageList;

  /**
   * 確定使用量（最新）を保有する。
   */
  private Fu fixUsageLatest;

  /**
   * 確定指示数（最新）を保有する。
   */
  private FixIn fixIndicationNoLatest;

  /**
   * 日割別使用量（最新）を保有する。
   */
  private List<DsUsage> dateSlotUsageLatestList;

  /**
   * 時間帯別使用量（最新）を保有する。
   */
  private List<TsUsage> timeSlotUsageLatestList;

  /**
   * 確定料金実績を保有する。
   */
  private Fcr fixChargeResult;

  /**
   * 確定料金実績内訳を保有する。
   */
  private List<FcrBreakdown> fixChargeResultBreakdownList;

  /**
   * 確定料金実績内訳（補正）を保有する。
   */
  private List<FcrBreakdown> fixChargeResultBreakdownCrtList;

  /**
   * 確定料金実績警告データを保有する。
   */
  private List<FcrWarningData> fixChargeResultWarningDataList;

  /**
   * 警告種別マスタを保有する。
   */
  private List<WarningClassM> warningClassMasterList;

  /**
   * 対応フラグを保有する。
   */
  private String dealFlag;

  /**
   * 契約履歴を保有する。
   */
  private ContractHist contractHist;

  /**
   * 実量歴一覧を保有する。
   */
  private List<Rqh> rqhList;

  /**
   * 契約種別マスタを保有する。
   */
  private CclM cclM;

  /**
   * エリアコードを保有する。
   */
  private String areaCode;

  /**
   * 契約電力決定区分コードを保有する。
   */
  private String contractCapacityDecisionCategoryCode;

  /**
   * 電圧区分コードを保有する。
   */
  private String voltageCategoryCode;

  /**
   * 対象年月を保有する。
   */
  private String coveredPeriod;

  /**
   * 制限中止期間を保有する。
   */
  private String limitDate;

  /**
   * 補正分類を保有する。
   */
  private String correctionCategoy;

  /**
   * 補正額（円）を保有する。
   */
  private String amountChg;

  /**
   * 項目名称を保有する。
   */
  private String displayName;

  /**
   * 力率を保有する。
   */
  private String powerFactor;

  /**
   * 契約容量を保有する。
   */
  private String contractCurrentCapacityPower;

  /**
   * 割引対象コードを保有する。
   */
  private String discountCoveredCode;

  /**
   * 使用量合計
   */
  private BigDecimal totalUsageQuantity;

  /**
   * 当月最大電力
   */
  private BigDecimal PeakKw;

  /**
   * 計算結果のgetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 計算結果を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 計算結果
   */
  public Integer getExecuteResult() {
    return executeResult;
  }

  /**
   * 計算結果のsetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 計算結果を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param executeResult
   *          計算結果
   */
  public void setExecuteResult(Integer executeResult) {
    this.executeResult = executeResult;
  }

  /**
   * 確定料金実績IDのgetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 確定料金実績IDを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 確定料金実績ID
   */
  public Integer getFixChargeResultId() {
    return this.fixChargeResultId;
  }

  /**
   * 確定料金実績IDのsetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 確定料金実績IDを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param fixChargeResultId
   *          確定料金実績ID
   */
  public void setFixChargeResultId(Integer fixChargeResultId) {
    this.fixChargeResultId = fixChargeResultId;
  }

  /**
   * 確定使用量IDのgetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 確定使用量IDを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 確定使用量ID
   */
  public Integer getFixUsageId() {
    return this.fixUsageId;
  }

  /**
   * 確定使用量IDのsetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 確定使用量IDを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param fixUsageId
   *          確定使用量ID
   */
  public void setFixUsageId(Integer fixUsageId) {
    this.fixUsageId = fixUsageId;
  }

  /**
   * 契約IDのgetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 契約IDを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約ID
   */
  public Integer getContractId() {
    return this.contractId;
  }

  /**
   * 契約IDのsetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 契約IDを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractId
   *          契約ID
   */
  public void setContractId(Integer contractId) {
    this.contractId = contractId;
  }

  /**
   * 利用年月のgetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 利用年月を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 利用年月
   */
  public String getUsePeriod() {
    return this.usePeriod;
  }

  /**
   * 利用年月のsetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 利用年月を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param usePeriod
   *          利用年月
   */
  public void setUsePeriod(String usePeriod) {
    this.usePeriod = usePeriod;
  }

  /**
   * 契約のgetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 契約を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約
   */
  public Contract getContract() {
    return this.contract;
  }

  /**
   * 契約のsetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 契約を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contract
   *          契約
   */
  public void setContract(Contract contract) {
    this.contract = contract;
  }

  /**
   * 契約付加情報のgetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 契約付加情報を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約付加情報
   */
  public ContractAddInfo getContractAddInfo() {
    return this.contractAddInfo;
  }

  /**
   * 契約付加情報のsetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 契約付加情報を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractAddInfo
   *          契約付加情報
   */
  public void setContractAddInfo(ContractAddInfo contractAddInfo) {
    this.contractAddInfo = contractAddInfo;
  }

  /**
   * 料金メニューのgetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 料金メニューを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 料金メニュー
   */
  public Rm getRateMenu() {
    return this.rateMenu;
  }

  /**
   * 料金メニューのsetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 料金メニューを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param rateMenu
   *          料金メニュー
   */
  public void setRateMenu(Rm rateMenu) {
    this.rateMenu = rateMenu;
  }

  /**
   * 付帯メニューのgetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 付帯メニューを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 付帯メニュー
   */
  public List<Spm> getSupplementaryMenuList() {
    return this.supplementaryMenuList;
  }

  /**
   * 付帯メニューのsetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 付帯メニューを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param supplementaryMenuList
   *          付帯メニュー
   */
  public void setSupplementaryMenuList(List<Spm> supplementaryMenuList) {
    this.supplementaryMenuList = supplementaryMenuList;
  }

  /**
   * 契約容量のgetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 契約容量を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約容量
   */
  public BigDecimal getContractCapacity() {
    return this.contractCapacity;
  }

  /**
   * 契約容量のsetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 契約容量を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractCapacity
   *          契約容量
   */
  public void setContractCapacity(BigDecimal contractCapacity) {
    this.contractCapacity = contractCapacity;
  }

  /**
   * 確定使用量のgetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 確定使用量を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 確定使用量
   */
  public Fu getFixUsage() {
    return this.fixUsage;
  }

  /**
   * 確定使用量のsetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 確定使用量を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param fixUsage
   *          確定使用量
   */
  public void setFixUsage(Fu fixUsage) {
    this.fixUsage = fixUsage;
  }

  /**
   * 確定指示数のgetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 確定指示数を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 確定指示数
   */
  public FixIn getFixIndicationNo() {
    return this.fixIndicationNo;
  }

  /**
   * 確定指示数のsetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 確定指示数を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param fixIndicationNo
   *          確定指示数
   */
  public void setFixIndicationNo(FixIn fixIndicationNo) {
    this.fixIndicationNo = fixIndicationNo;
  }

  /**
   * 日割別使用量のgetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 日割別使用量を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 日割別使用量
   */
  public List<DsUsage> getDateSlotUsageList() {
    return this.dateSlotUsageList;
  }

  /**
   * 日割別使用量のsetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 日割別使用量を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param dateSlotUsageList
   *          日割別使用量
   */
  public void setDateSlotUsageList(List<DsUsage> dateSlotUsageList) {
    this.dateSlotUsageList = dateSlotUsageList;
  }

  /**
   * 時間帯別使用量のgetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 時間帯別使用量を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 時間帯別使用量
   */
  public List<TsUsage> getTimeSlotUsageList() {
    return this.timeSlotUsageList;
  }

  /**
   * 時間帯別使用量のsetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 時間帯別使用量を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param timeSlotUsageList
   *          時間帯別使用量
   */
  public void setTimeSlotUsageList(List<TsUsage> timeSlotUsageList) {
    this.timeSlotUsageList = timeSlotUsageList;
  }

  /**
   * 確定使用量（最新）のgetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 確定使用量（最新）を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 確定使用量（最新）
   */
  public Fu getFixUsageLatest() {
    return this.fixUsageLatest;
  }

  /**
   * 確定使用量（最新）のsetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 確定使用量（最新）を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param fixUsageLatest
   *          確定使用量（最新）
   */
  public void setFixUsageLatest(Fu fixUsageLatest) {
    this.fixUsageLatest = fixUsageLatest;
  }

  /**
   * 確定指示数（最新）のgetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 確定指示数（最新）を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 確定指示数（最新）
   */
  public FixIn getFixIndicationNoLatest() {
    return this.fixIndicationNoLatest;
  }

  /**
   * 確定指示数（最新）のsetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 確定指示数（最新）を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param fixIndicationNoLatest
   *          確定指示数（最新）
   */
  public void setFixIndicationNoLatest(FixIn fixIndicationNoLatest) {
    this.fixIndicationNoLatest = fixIndicationNoLatest;
  }

  /**
   * 日割別使用量（最新）のgetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 日割別使用量（最新）を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 日割別使用量（最新）
   */
  public List<DsUsage> getDateSlotUsageLatestList() {
    return this.dateSlotUsageLatestList;
  }

  /**
   * 日割別使用量（最新）のsetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 日割別使用量（最新）を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param dateSlotUsageLatestList
   *          日割別使用量（最新）
   */
  public void setDateSlotUsageLatestList(List<DsUsage> dateSlotUsageLatestList) {
    this.dateSlotUsageLatestList = dateSlotUsageLatestList;
  }

  /**
   * 時間帯別使用量（最新）のgetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 時間帯別使用量（最新）を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 時間帯別使用量（最新）
   */
  public List<TsUsage> getTimeSlotUsageLatestList() {
    return this.timeSlotUsageLatestList;
  }

  /**
   * 時間帯別使用量（最新）のsetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 時間帯別使用量（最新）を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param timeSlotUsageLatestList
   *          時間帯別使用量（最新）
   */
  public void setTimeSlotUsageLatestList(List<TsUsage> timeSlotUsageLatestList) {
    this.timeSlotUsageLatestList = timeSlotUsageLatestList;
  }

  /**
   * 確定料金実績のgetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 確定料金実績を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 確定料金実績
   */
  public Fcr getFixChargeResult() {
    return this.fixChargeResult;
  }

  /**
   * 確定料金実績のsetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 確定料金実績を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param fixChargeResult
   *          確定料金実績
   */
  public void setFixChargeResult(Fcr fixChargeResult) {
    this.fixChargeResult = fixChargeResult;
  }

  /**
   * 確定料金実績内訳のgetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 確定料金実績内訳を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 確定料金実績内訳
   */
  public List<FcrBreakdown> getFixChargeResultBreakdownList() {
    return this.fixChargeResultBreakdownList;
  }

  /**
   * 確定料金実績内訳のsetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 確定料金実績内訳を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param fixChargeResultBreakdownList
   *          確定料金実績内訳
   */
  public void setFixChargeResultBreakdownList(List<FcrBreakdown> fixChargeResultBreakdownList) {
    this.fixChargeResultBreakdownList = fixChargeResultBreakdownList;
  }

  /**
   * 確定料金実績内訳（補正）のgetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 確定料金実績内訳（補正）を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 確定料金実績内訳（補正）
   */
  public List<FcrBreakdown> getFixChargeResultBreakdownCrtList() {
    return this.fixChargeResultBreakdownCrtList;
  }

  /**
   * 確定料金実績内訳（補正）のsetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 確定料金実績内訳（補正）を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param fixChargeResultBreakdownCrtList
   *          確定料金実績内訳（補正）
   */
  public void setFixChargeResultBreakdownCrtList(List<FcrBreakdown> fixChargeResultBreakdownCrtList) {
    this.fixChargeResultBreakdownCrtList = fixChargeResultBreakdownCrtList;
  }

  /**
   * 確定料金実績警告データのgetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 確定料金実績警告データを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 確定料金実績警告データ
   */
  public List<FcrWarningData> getFixChargeResultWarningDataList() {
    return this.fixChargeResultWarningDataList;
  }

  /**
   * 確定料金実績警告データのsetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 確定料金実績警告データを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param fixChargeResultWarningDataList
   *          確定料金実績警告データ
   */
  public void setFixChargeResultWarningDataList(List<FcrWarningData> fixChargeResultWarningDataList) {
    this.fixChargeResultWarningDataList = fixChargeResultWarningDataList;
  }

  /**
   * 警告種別マスタのgetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 警告種別マスタを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 警告種別マスタ
   */
  public List<WarningClassM> getWarningClassMasterList() {
    return this.warningClassMasterList;
  }

  /**
   * 警告種別マスタのsetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 警告種別マスタを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param warningClassMasterList
   *          警告種別マスタ
   */
  public void setWarningClassMasterList(List<WarningClassM> warningClassMasterList) {
    this.warningClassMasterList = warningClassMasterList;
  }

  /**
   * 対応フラグのgetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 対応フラグを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 対応フラグ
   */
  public String getDealFlag() {
    return this.dealFlag;
  }

  /**
   * 対応フラグのsetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 対応フラグを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param dealFlag
   *          対応フラグ
   */
  public void setDealFlag(String dealFlag) {
    this.dealFlag = dealFlag;
  }

  /**
   * 契約履歴のgetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 契約履歴を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約履歴
   */
  public ContractHist getContractHist() {
    return contractHist;
  }

  /**
   * 契約履歴のsetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 契約履歴を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractHist
   *          契約履歴
   */
  public void setContractHist(ContractHist contractHist) {
    this.contractHist = contractHist;
  }

  /**
   * 実量歴一覧のgetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 実量歴一覧を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 実量歴一覧
   */
  public List<Rqh> getRqhList() {
    return rqhList;
  }

  /**
   * 実量歴一覧のsetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 実量歴一覧を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param rqhList
   *          実量歴一覧
   */
  public void setRqhList(List<Rqh> rqhList) {
    this.rqhList = rqhList;
  }

  /**
   * 契約種別マスタのgetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 契約種別マスタを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約種別マスタ
   */
  public CclM getCclM() {
    return cclM;
  }

  /**
   * 契約種別マスタのsetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 契約種別マスタを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param cclM
   *          契約種別マスタ
   */
  public void setCclM(CclM cclM) {
    this.cclM = cclM;
  }

  /**
   * エリアコードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * エリアコードを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return エリアコード
   */
  public String getAreaCode() {
    return areaCode;
  }

  /**
   * エリアコードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * エリアコードを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param areaCode
   *          エリアコード
   */
  public void setAreaCode(String areaCode) {
    this.areaCode = areaCode;
  }

  /**
   * 契約電力決定区分コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約電力決定区分コードを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約電力決定区分コード
   */
  public String getContractCapacityDecisionCategoryCode() {
    return contractCapacityDecisionCategoryCode;
  }

  /**
   * 契約電力決定区分コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約電力決定区分コードを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractCapacityDecisionCategoryCode
   *          契約電力決定区分コード
   */
  public void setContractCapacityDecisionCategoryCode(
      String contractCapacityDecisionCategoryCode) {
    this.contractCapacityDecisionCategoryCode = contractCapacityDecisionCategoryCode;
  }

  /**
   * 電圧区分コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 電圧区分コードを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 電圧区分コード
   */
  public String getVoltageCategoryCode() {
    return voltageCategoryCode;
  }

  /**
   * 電圧区分コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 電圧区分コードを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param voltageCategoryCode
   *          電圧区分コード
   */
  public void setVoltageCategoryCode(String voltageCategoryCode) {
    this.voltageCategoryCode = voltageCategoryCode;
  }

  /**
   * 対象年月のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 対象年月を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 対象年月
   */
  public String getCoveredPeriod() {
    return coveredPeriod;
  }

  /**
   * 対象年月のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 対象年月を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param coveredPeriod
   *          対象年月
   */
  public void setCoveredPeriod(String coveredPeriod) {
    this.coveredPeriod = coveredPeriod;
  }

  /**
   * 制限中止期間のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 制限中止期間を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 制限中止期間
   */
  public String getLimitDate() {
    return limitDate;
  }

  /**
   * 制限中止期間のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 制限中止期間を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param limitDate
   *          制限中止期間
   */
  public void setLimitDate(String limitDate) {
    this.limitDate = limitDate;
  }

  /**
   * 補正分類のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 補正分類を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 補正分類
   */
  public String getCorrectionCategoy() {
    return correctionCategoy;
  }

  /**
   * 補正分類のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 補正分類を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param correctionCategoy
   *          補正分類
   */
  public void setCorrectionCategoy(String correctionCategoy) {
    this.correctionCategoy = correctionCategoy;
  }

  /**
   * 補正額（円）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 補正額（円）を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 補正額（円）
   */
  public String getAmountChg() {
    return amountChg;
  }

  /**
   * 補正額（円）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 補正額（円）を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param amountChg
   *          補正額（円）
   */
  public void setAmountChg(String amountChg) {
    this.amountChg = amountChg;
  }

  /**
   * 項目名称のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 項目名称を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 項目名称
   */
  public String getDisplayName() {
    return displayName;
  }

  /**
   * 項目名称のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 項目名称を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param displayName
   *          項目名称
   */
  public void setDisplayName(String displayName) {
    this.displayName = displayName;
  }

  /**
   * 力率のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 力率を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 力率
   */
  public String getPowerFactor() {
    return powerFactor;
  }

  /**
   * 力率のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 力率を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param powerFactor
   *          力率
   */
  public void setPowerFactor(String powerFactor) {
    this.powerFactor = powerFactor;
  }

  /**
   * 契約容量のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約容量を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約容量
   */
  public String getContractCurrentCapacityPower() {
    return contractCurrentCapacityPower;
  }

  /**
   * 契約容量のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約容量を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractCurrentCapacityPower
   *          契約容量
   */
  public void setContractCurrentCapacityPower(String contractCurrentCapacityPower) {
    this.contractCurrentCapacityPower = contractCurrentCapacityPower;
  }

  /**
   * 割引対象コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 割引対象コードを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 割引対象コード
   */
  public String getDiscountCoveredCode() {
    return discountCoveredCode;
  }

  /**
   * 割引対象コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 割引対象コードを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param discountCoveredCode
   *          割引対象コード
   */
  public void setDiscountCoveredCode(String discountCoveredCode) {
    this.discountCoveredCode = discountCoveredCode;
  }

  /**
   * 使用量合計のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 使用量合計を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 使用量合計
   */
  public BigDecimal getTotalUsageQuantity() {
    return totalUsageQuantity;
  }

  /**
   * 使用量合計のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 使用量合計を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param totalUsageQuantity
   *          使用量合計
   */
  public void setTotalUsageQuantity(BigDecimal totalUsageQuantity) {
    this.totalUsageQuantity = totalUsageQuantity;
  }

  /**
   * 当月最大電力のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 当月最大電力を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 当月最大電力
   */
  public BigDecimal getPeakKw() {
    return PeakKw;
  }

  /**
   * 当月最大電力のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 当月最大電力を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param totalUsageQuantity
   *          当月最大電力
   */
  public void setPeakKw(BigDecimal peakKw) {
    this.PeakKw = peakKw;
  }
}
