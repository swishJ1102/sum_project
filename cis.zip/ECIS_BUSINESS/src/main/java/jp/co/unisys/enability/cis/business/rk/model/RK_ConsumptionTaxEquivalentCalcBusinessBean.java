package jp.co.unisys.enability.cis.business.rk.model;

import java.math.BigDecimal;
import java.util.Date;

/**
 * 消費税等相当額計算ビジネスBean
 * 
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * 消費税等相当額計算ビジネス
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_ConsumptionTaxEquivalentCalcBusinessBean {

  /**
   * 引数：基準日１
   **/
  private Date baseDate1;

  /**
   * 引数：基準日２
   **/
  private Date baseDate2;

  /**
   * 引数：金額
   **/
  private BigDecimal amount;

  /**
   * 戻り値：消費税率
   **/
  private Short consumptionTaxRate;

  /**
   * 戻り値：消費税科目コード
   **/
  private String consumptionTaxItemCode;

  /**
   * 戻り値：消費税等相当額
   **/
  private Integer consumptionTaxEquivalent;

  /**
   * 基準日１のgetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 基準日１を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 基準日１
   */
  public Date getBaseDate1() {
    return baseDate1;
  }

  /**
   * 基準日１のsetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 基準日１を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param baseDate1
   *          基準日１
   */
  public void setBaseDate1(Date baseDate1) {
    this.baseDate1 = baseDate1;
  }

  /**
   * 基準日２のgetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 基準日２を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 基準日２
   */
  public Date getBaseDate2() {
    return baseDate2;
  }

  /**
   * 基準日２のsetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 基準日２を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param baseDate2
   *          基準日２
   */
  public void setBaseDate2(Date baseDate2) {
    this.baseDate2 = baseDate2;
  }

  /**
   * 金額のgetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 金額を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 金額
   */
  public BigDecimal getAmount() {
    return amount;
  }

  /**
   * 金額のsetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 金額を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param amount
   *          金額
   */
  public void setAmount(BigDecimal amount) {
    this.amount = amount;
  }

  /**
   * 消費税率のgetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 消費税率を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 消費税率
   */
  public Short getConsumptionTaxRate() {
    return consumptionTaxRate;
  }

  /**
   * 消費税率のsetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 消費税率を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param consumptionTaxRate
   *          消費税率
   */
  public void setConsumptionTaxRate(Short consumptionTaxRate) {
    this.consumptionTaxRate = consumptionTaxRate;
  }

  /**
   * 消費税科目コードのgetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 消費税科目コードを取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 消費税科目コード
   */
  public String getConsumptionTaxItemCode() {
    return consumptionTaxItemCode;
  }

  /**
   * 消費税科目コードのsetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 消費税科目コードを設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param consumptionTaxItemCode
   *          消費税科目コード
   */
  public void setConsumptionTaxItemCode(String consumptionTaxItemCode) {
    this.consumptionTaxItemCode = consumptionTaxItemCode;
  }

  /**
   * 消費税等相当額のgetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 消費税等相当額を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 消費税等相当額
   */
  public Integer getConsumptionTaxEquivalent() {
    return consumptionTaxEquivalent;
  }

  /**
   * 消費税等相当額のsetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 消費税等相当額を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param consumptionTaxEquivalent
   *          消費税等相当額
   */
  public void setConsumptionTaxEquivalent(Integer consumptionTaxEquivalent) {
    this.consumptionTaxEquivalent = consumptionTaxEquivalent;
  }

}
