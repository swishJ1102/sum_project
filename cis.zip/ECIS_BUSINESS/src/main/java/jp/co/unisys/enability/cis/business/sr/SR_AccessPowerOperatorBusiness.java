package jp.co.unisys.enability.cis.business.sr;

import java.sql.Timestamp;
import java.util.Date;

import jp.co.unisys.enability.cis.business.sr.model.SR_SSLauthenticationBusinessBean;
import jp.co.unisys.enability.cis.common.Exception.BusinessLogicException;
import jp.co.unisys.enability.cis.common.Exception.SystemException;
import jp.co.unisys.enability.cis.entity.common.AreaM;
import jp.co.unisys.enability.cis.entity.common.PmCompanyM;
import jp.co.unisys.enability.cis.entity.common.TfMng;

/**
 * 電力事業者アクセスクラス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public interface SR_AccessPowerOperatorBusiness {

  /**
   * SSL認証
   *
   * <pre>
   * <p>
   * <b>【仕様詳細】</b>
   * </p>
   * SSL認証を行い、接続を行う。
   *
   * @author "Nihon Unisys, Ltd."
   * @param systemTime
   * @param SR_SSLauthenticationBusinessBean
   *          SSL認証ビジネスBean
   * @param batchExecutesDate
   *          バッチ処理基準日
   * @throws BusinessLogicException
   *           業務例外が発生した場合
   */
  public void sslAuthentication(
      SR_SSLauthenticationBusinessBean sslAuthentication, Timestamp systemTime, Date batchExecutesDate,
      PmCompanyM pmCompany, AreaM areaMaster) throws SystemException;

  /**
   * ファイルリスト受信要求
   *
   * <pre>
   * <p>
   * <b>【仕様詳細】</b>
   * </p>
   * ファイルリスト受信要求を行い、受信可能なファイル一覧を取得。
   *
   * @author "Nihon Unisys, Ltd."
   * @param SR_SSLauthenticationBusinessBean
   *          SSL認証ビジネスBean
   * @throws BusinessLogicException
   */
  public void fileListReceptionRequest(SR_SSLauthenticationBusinessBean sslAuthentication) throws SystemException;

  /**
   * ファイル受信要求
   *
   * <pre>
   * <p>
   * <b>【仕様詳細】</b>
   * </p>
   * ファイル受信要求を行い、Zipファイルを取得する。
   *
   * @author "Nihon Unisys, Ltd."
   * @param noReceivableFile
   * @param systemTime
   * @param SR_SSLauthenticationBusinessBean
   *          SSL認証ビジネスBean
   * @throws BusinessLogicException
   * @throws Exception
   */
  public void fileReceptionRequest(SR_SSLauthenticationBusinessBean sslAuthentication, TfMng noReceivableFile)
      throws SystemException;

  /**
   * SSL接続を閉じる
   *
   * <pre>
   * <p>
   * <b>【仕様詳細】</b>
   * </p>
   * 接続しているSSLを閉じる。
   *
   * @author "Nihon Unisys, Ltd."
   * @param SR_SSLauthenticationBusinessBean
   *          SSL認証ビジネスBean
   * @throws BusinessLogicException
   */
  public void sslClose() throws BusinessLogicException;

}
