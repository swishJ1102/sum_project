package jp.co.unisys.enability.cis.business.kj;

import jp.co.unisys.enability.cis.business.kj.model.S010101_ContractManagementInformationUploadBusinessBean;

/**
 * 契約管理情報ファイルアップロード画面ビジネスインタフェース
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.kj.KJ_ContractorInformationBusiness
 * @see jp.co.unisys.enability.cis.business.kj.KJ_AccountCreditCardInformationBusiness
 * @see jp.co.unisys.enability.cis.business.kj.KJ_PaymentInformationBusiness
 * @see jp.co.unisys.enability.cis.business.kj.KJ_ContractInformationBusiness
 * @see jp.co.unisys.enability.cis.business.kj.KJ_SupplementaryContractInformationBusiness
 * @see jp.co.unisys.enability.cis.business.kj.KJ_MeterLocationInformationBusiness
 * @see jp.co.unisys.enability.cis.mapper.common.BulkRegisterControlMapper
 */
public interface S010101_ContractManagementInformationUploadBusiness {

  /**
   * 非同期処理を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 1 エラーリストが存在する場合、削除する。
   * 2 アップロードファイルを読み込み、バリデーションを行う。
   * 3 削除、登録、更新の順に処理を行う。
   * 4 アップロードファイルを削除する。
   * 5 一括登録制御ロックを解放する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractManagementInformationUploadBusinessBean
   *          契約管理情報アップロードBusinessBean
   */
  public void asyncProcess(
      S010101_ContractManagementInformationUploadBusinessBean contractManagementInformationUploadBusinessBean);
}
