package jp.co.unisys.enability.cis.business.rk.model;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;

/**
 * 計算用使用量ビジネスBean。
 *
 * <pre>
 * <p>
 * <b>【使用ビジネス】</b>
 * </p>
 * 計算用使用量登録ビジネス。
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_CalcForUsageBusinessBean {

  /**
   * 契約ID
   */
  Integer contractId;

  /**
   * 利用年月
   */
  String usePeriod;

  /**
   * 確定使用量ID
   */
  Integer fixUsageId;

  /**
   * 契約容量
   */
  BigDecimal contractCapacity;

  /**
   * 契約電力決定区分コード
   */
  String contractCapacityDecisionCategoryCode;

  /**
   * 最大電力
   */
  BigDecimal peakKw;

  /**
   * 使用量合計
   */
  BigDecimal totalUsage;

  /**
   * 料金算定開始日
   */
  Date chargeCalculationStartDate;

  /**
   * 料金算定終了日
   */
  Date chargeCalculationEndDate;

  /**
   * 料金算定日数
   */
  Integer chargeCalculationDays;

  /**
   * 力率
   */
  Integer proratedBasisDays;

  /**
   * 力率
   */
  Integer powerFactor;

  /**
   * 料金メニューID
   */
  String rateMenuId;

  /**
   * 更新回数
   */
  Integer updateCount;

  /**
   * 作成日時
   */
  Timestamp createTime;

  /**
   * オンライン更新日時
   */
  Timestamp onlineUpdateTime;

  /**
   * オンライン更新ユーザID
   */
  String onlineUpdateUserId;

  /**
   * 更新日時
   */
  Timestamp updateTime;

  /**
   * 更新モジュールコード
   */
  String updateModuleCode;

  /**
   * 契約IDのgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約IDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約ID
   */
  public Integer getContractId() {
    return contractId;
  }

  /**
   * 契約IDのsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約IDを設定する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractId
   *          契約ID
   */
  public void setContractId(Integer contractId) {
    this.contractId = contractId;
  }

  /**
   * 利用年月のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 利用年月を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 利用年月
   */
  public String getUsePeriod() {
    return usePeriod;
  }

  /**
   * 利用年月のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 利用年月を設定する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param usePeriod
   *          利用年月
   */
  public void setUsePeriod(String usePeriod) {
    this.usePeriod = usePeriod;
  }

  /**
   * 確定使用量IDのgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 確定使用量IDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 確定使用量ID
   */
  public Integer getFixUsageId() {
    return fixUsageId;
  }

  /**
   * 契約容量のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約容量を設定する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param fixUsageId
   *          契約容量
   */
  public void setFixUsageId(Integer fixUsageId) {
    this.fixUsageId = fixUsageId;
  }

  /**
   * 契約容量のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約容量を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約容量
   */
  public BigDecimal getContractCapacity() {
    return contractCapacity;
  }

  /**
   * 契約容量のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約容量を設定する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractCapacity
   *          契約容量
   */
  public void setContractCapacity(BigDecimal contractCapacity) {
    this.contractCapacity = contractCapacity;
  }

  /**
   * 契約電力決定区分コードのgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約電力決定区分コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約電力決定区分コード
   */
  public String getContractCapacityDecisionCategoryCode() {
    return contractCapacityDecisionCategoryCode;
  }

  /**
   * 契約電力決定区分コードのsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約電力決定区分コードを設定する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractCapacityDecisionCategoryCode
   *          契約電力決定区分コード
   */
  public void setContractCapacityDecisionCategoryCode(String contractCapacityDecisionCategoryCode) {
    this.contractCapacityDecisionCategoryCode = contractCapacityDecisionCategoryCode;
  }

  /**
   * 最大電力のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 最大電力を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 最大電力
   */
  public BigDecimal getPeakKw() {
    return peakKw;
  }

  /**
   * 最大電力のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 最大電力を設定する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param peakKw
   *          最大電力
   */
  public void setPeakKw(BigDecimal peakKw) {
    this.peakKw = peakKw;
  }

  /**
   * 使用量合計のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 使用量合計を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 使用量合計
   */
  public BigDecimal getTotalUsage() {
    return totalUsage;
  }

  /**
   * 使用量合計のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 使用量合計を設定する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param totalUsage
   *          使用量合計
   */
  public void setTotalUsage(BigDecimal totalUsage) {
    this.totalUsage = totalUsage;
  }

  /**
   * 料金算定開始日のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金算定開始日を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 料金算定開始日
   */
  public Date getChargeCalculationStartDate() {
    return chargeCalculationStartDate;
  }

  /**
   * 料金算定開始日のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金算定開始日を設定する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param chargeCalculationStartDate
   *          料金算定開始日
   */
  public void setChargeCalculationStartDate(Date chargeCalculationStartDate) {
    this.chargeCalculationStartDate = chargeCalculationStartDate;
  }

  /**
   * 料金算定終了日のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金算定終了日を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 料金算定終了日
   */
  public Date getChargeCalculationEndDate() {
    return chargeCalculationEndDate;
  }

  /**
   * 料金算定終了日のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金算定終了日を設定する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param chargeCalculationEndDate
   *          料金算定終了日
   */
  public void setChargeCalculationEndDate(Date chargeCalculationEndDate) {
    this.chargeCalculationEndDate = chargeCalculationEndDate;
  }

  /**
   * 料金算定日数のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金算定日数を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 料金算定日数
   */
  public Integer getChargeCalculationDays() {
    return chargeCalculationDays;
  }

  /**
   * 料金算定日数のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金算定日数を設定する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param chargeCalculationDays
   *          料金算定日数
   */
  public void setChargeCalculationDays(Integer chargeCalculationDays) {
    this.chargeCalculationDays = chargeCalculationDays;
  }

  /**
   * 日割日数のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 日割日数を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 日割日数
   */
  public Integer getProratedBasisDays() {
    return proratedBasisDays;
  }

  /**
   * 日割日数のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 日割日数を設定する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param proratedBasisDays
   *          日割日数
   */
  public void setProratedBasisDays(Integer proratedBasisDays) {
    this.proratedBasisDays = proratedBasisDays;
  }

  /**
   * 力率のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 力率を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 力率
   */
  public Integer getPowerFactor() {
    return powerFactor;
  }

  /**
   * 力率のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 力率を設定する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param powerFactor
   *          力率
   */
  public void setPowerFactor(Integer powerFactor) {
    this.powerFactor = powerFactor;
  }

  /**
   * 料金メニューIDのgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金メニューIDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 料金メニューID
   */
  public String getRateMenuId() {
    return rateMenuId;
  }

  /**
   * 料金メニューIDのsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金メニューIDを設定する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param rateMenuId
   *          料金メニューID
   */
  public void setRateMenuId(String rateMenuId) {
    this.rateMenuId = rateMenuId;
  }

  /**
   * 更新回数のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 更新回数を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 更新回数
   */
  public Integer getUpdateCount() {
    return updateCount;
  }

  /**
   * 更新回数のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 更新回数を設定する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param updateCount
   *          更新回数
   */
  public void setUpdateCount(Integer updateCount) {
    this.updateCount = updateCount;
  }

  /**
   * 作成日時のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 作成日時を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 作成日時
   */
  public Timestamp getCreateTime() {
    return createTime;
  }

  /**
   * 作成日時のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 作成日時を設定する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param createTime
   *          作成日時
   */
  public void setCreateTime(Timestamp createTime) {
    this.createTime = createTime;
  }

  /**
   * オンライン更新日時のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * オンライン更新日時を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return オンライン更新日時
   */
  public Timestamp getOnlineUpdateTime() {
    return onlineUpdateTime;
  }

  /**
   * オンライン更新日時のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * オンライン更新日時を設定する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param onlineUpdateTime
   *          オンライン更新日時
   */
  public void setOnlineUpdateTime(Timestamp onlineUpdateTime) {
    this.onlineUpdateTime = onlineUpdateTime;
  }

  /**
   * オンライン更新ユーザIDのgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * オンライン更新ユーザIDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return オンライン更新ユーザID
   */
  public String getOnlineUpdateUserId() {
    return onlineUpdateUserId;
  }

  /**
   * オンライン更新ユーザIDのsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * オンライン更新ユーザIDを設定する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param onlineUpdateUserId
   *          オンライン更新ユーザID
   */
  public void setOnlineUpdateUserId(String onlineUpdateUserId) {
    this.onlineUpdateUserId = onlineUpdateUserId;
  }

  /**
   * 更新日時のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 更新日時を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 更新日時
   */
  public Timestamp getUpdateTime() {
    return updateTime;
  }

  /**
   * 更新日時のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 更新日時を設定する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param updateTime
   *          更新日時
   */
  public void setUpdateTime(Timestamp updateTime) {
    this.updateTime = updateTime;
  }

  /**
   * 更新モジュールコードのgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 更新モジュールコードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 更新モジュールコード
   */
  public String getUpdateModuleCode() {
    return updateModuleCode;
  }

  /**
   * 更新モジュールコードのsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 更新モジュールコードを設定する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param updateModuleCode
   *          更新モジュールコード
   */
  public void setUpdateModuleCode(String updateModuleCode) {
    this.updateModuleCode = updateModuleCode;
  }
}
