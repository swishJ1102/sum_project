package jp.co.unisys.enability.cis.business.rk.model;

import java.util.List;

import jp.co.unisys.enability.cis.entity.common.Fcr;
import jp.co.unisys.enability.cis.entity.common.FcrBreakdown;

/**
 * 売上関連項目計算ビジネスBean
 * 
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * 売上関連項目計算ビジネス
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_SaleProceedsRelationItemCalcBusinessBean {

  /**
   * 確定料金実績を保有する。
   */
  private Fcr fixChargeResult;

  /**
   * 確定料金実績内訳を保有する。
   */
  private List<FcrBreakdown> fixChargeResultBreakdownList;

  /**
   * 確定料金実績内訳（補正用）を保有する。
   */
  private List<FcrBreakdown> fixChargeResultBreakdownForCorrectList;

  /**
   * 確定料金実績のgetter。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 確定料金実績を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 確定料金実績
   */
  public Fcr getFixChargeResult() {
    return this.fixChargeResult;
  }

  /**
   * 確定料金実績のsetter。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 確定料金実績を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param fixChargeResult
   *          確定料金実績
   */
  public void setFixChargeResult(Fcr fixChargeResult) {
    this.fixChargeResult = fixChargeResult;
  }

  /**
   * 確定料金実績内訳のgetter。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 確定料金実績内訳を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 確定料金実績内訳
   */
  public List<FcrBreakdown> getFixChargeResultBreakdownList() {
    return this.fixChargeResultBreakdownList;
  }

  /**
   * 確定料金実績内訳のsetter。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 確定料金実績内訳を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param fixChargeResultBreakdownList
   *          確定料金実績内訳
   */
  public void setFixChargeResultBreakdownList(List<FcrBreakdown> fixChargeResultBreakdownList) {
    this.fixChargeResultBreakdownList = fixChargeResultBreakdownList;
  }

  /**
   * 確定料金実績内訳（補正用）のgetter。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 確定料金実績内訳（補正用）を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 確定料金実績内訳（補正用）
   */
  public List<FcrBreakdown> getFixChargeResultBreakdownForCorrectList() {
    return fixChargeResultBreakdownForCorrectList;
  }

  /**
   * 確定料金実績内訳（補正用）のsetter。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 確定料金実績内訳（補正用）を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param fixChargeResultBreakdownForCorrectList
   *          確定料金実績内訳（補正用）
   */
  public void setFixChargeResultBreakdownForCorrectList(List<FcrBreakdown> fixChargeResultBreakdownForCorrectList) {
    this.fixChargeResultBreakdownForCorrectList = fixChargeResultBreakdownForCorrectList;
  }

}
