package jp.co.unisys.enability.cis.business.kj.model;

import java.util.Date;
import java.util.List;

import jp.co.unisys.enability.cis.entity.kj.KJ_ContractListResultEntityBean;

/**
 * 卸取次店向け契約情報検索で検索条件および検索結果を格納するBusinessBean
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 *  卸取次店向け契約情報検索ビジネス
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 *
 */
public class SearchContractListBusinessBean {

  /**
   * 契約者番号を保有する。
   */
  private String contractorNo;

  /**
   * 契約番号リストを保有する。
   */
  private List<String> contractNoList;

  /**
   * 照会対象日付を保有する。
   */
  private Date inqCoveredDate;

  /**
   * 提供モデルコードを保有する。
   */
  private String provideModelCode;

  /**
   * 提供モデル企業コードを保有する。
   */
  private String provideModelCompanyCode;

  /**
   * 契約情報リストを保有する。
   */
  private List<KJ_ContractListResultEntityBean> contractListResultList;

  /**
   * リターンコードを保有する。
   */
  private String returnCode;

  /**
   * メッセージを保有する。
   */
  private String message;

  /**
   * 契約者番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者番号を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者番号
   */
  public String getContractorNo() {
    return this.contractorNo;
  }

  /**
   * 契約者番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者番号を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorNo
   *          契約者番号
   */
  public void setContractorNo(String contractorNo) {
    this.contractorNo = contractorNo;
  }

  /**
   * 契約番号リストのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約番号リストを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約番号リスト
   */
  public List<String> getContractNoList() {
    return this.contractNoList;
  }

  /**
   * 契約番号リストのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約番号リストを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractNoList
   *          契約番号
   */
  public void setContractNoList(List<String> contractNoList) {
    this.contractNoList = contractNoList;
  }

  /**
   * 照会対象日付のgetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 照会対象日付を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 照会対象日付
   */
  public Date getInqCoveredDate() {
    return this.inqCoveredDate;
  }

  /**
   * 照会対象日付のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 照会対象日付を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param inqCoveredDate
   *          照会対象日付
   */
  public void setInqCoveredDate(Date inqCoveredDate) {
    this.inqCoveredDate = inqCoveredDate;
  }

  /**
   * 提供モデルコードのgetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 提供モデルコードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 提供モデルコード
   */
  public String getProvideModelCode() {
    return this.provideModelCode;
  }

  /**
   * 提供モデルコードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 提供モデルコードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param provideModelCode
   *          提供モデルコード
   */
  public void setProvideModelCode(String provideModelCode) {
    this.provideModelCode = provideModelCode;
  }

  /**
   * 提供モデル企業コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 提供モデル企業コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 提供モデル企業コード
   */
  public String getProvideModelCompanyCode() {
    return this.provideModelCompanyCode;
  }

  /**
   * 提供モデル企業コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 提供モデル企業コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param provideModelCompanyCode
   *          提供モデル企業コード
   */
  public void setProvideModelCompanyCode(String provideModelCompanyCode) {
    this.provideModelCompanyCode = provideModelCompanyCode;
  }

  /**
   * 契約情報取得リストのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約情報取得リストを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約情報取得リスト
   */
  public List<KJ_ContractListResultEntityBean> getContractListResultList() {
    return this.contractListResultList;
  }

  /**
   * 契約情報取得リストのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約情報取得リストを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractListResultList
   *          契約情報取得リスト
   */
  public void setContractListResultList(List<KJ_ContractListResultEntityBean> contractListResultList) {
    this.contractListResultList = contractListResultList;
  }

  /**
   * リターンコードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return リターンコード
   */
  public String getReturnCode() {
    return this.returnCode;
  }

  /**
   * リターンコードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param returnCode
   *          リターンコード
   */
  public void setReturnCode(String returnCode) {
    this.returnCode = returnCode;
  }

  /**
   * メッセージのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return メッセージ
   */
  public String getMessage() {
    return this.message;
  }

  /**
   * メッセージのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param message
   *          メッセージ
   */
  public void setMessage(String message) {
    this.message = message;
  }
}
