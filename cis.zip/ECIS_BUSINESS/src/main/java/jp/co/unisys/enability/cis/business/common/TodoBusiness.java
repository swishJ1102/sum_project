package jp.co.unisys.enability.cis.business.common;

import jp.co.unisys.enability.cis.business.common.model.TodoBusinessBean;

/**
 * TODO共通ビジネスインタフェース。
 * 
 * <pre>
 * <p><b>【仕様詳細】<b><p>
 * TODOテーブルへの操作を行う。
 * </pre>
 *
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.common.TodoBusinessImpl
 */
public interface TodoBusiness {

  /**
   * TODOへの登録を行う。
   * 
   * <pre>
   * <p><b>【仕様詳細】<b><p>
   * 引数のbeanを基に、TODOテーブルへの登録を行う。
   * todo_id,todo_noに関してはシーケンス（sq_todo_id）より発番し、
   * SQL実行時に設定を行う。
   * </pre>
   *
   * @param todoBean
   *          todoビジネスBean
   */
  void registTodo(TodoBusinessBean todoBean);
}
