package jp.co.unisys.enability.cis.business.sr;

import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.unisys.enability.cis.business.common.HttpRequestBusiness;
import jp.co.unisys.enability.cis.business.common.HttpRequestBusinessImpl;
import jp.co.unisys.enability.cis.common.util.ThreadContext;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.entity.common.Contractor;
import jp.co.unisys.enability.cis.entity.common.ContractorExample;
import jp.co.unisys.enability.cis.entity.common.Remit;
import jp.co.unisys.enability.cis.entity.common.RemitExample;
import jp.co.unisys.enability.cis.entity.common.Todo;
import jp.co.unisys.enability.cis.mapper.common.ContractorMapper;
import jp.co.unisys.enability.cis.mapper.common.RemitMapper;
import jp.co.unisys.enability.cis.mapper.common.TodoMapper;
import jp.co.unisys.enability.cis.mapper.sr.SR110101_RegistRemittanceInstructionMapper;

import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

/**
 * 送金指示登録Businessクラス
 *
 * @author "Nihon Unisys, Ltd."
 */
public class SR110101_RegistRemittanceInstructionBusinessImpl implements SR110101_RegistRemittanceInstructionBusiness {

    /** 送金指示登録Mapper */
    private SR110101_RegistRemittanceInstructionMapper registRemittanceInstructionMapper;

    /** 送金Mapper（DI） */
    private RemitMapper remitMapper;

    /** 契約者Mapper（DI） */
    private ContractorMapper contractorMapper;

     /** TodoMapper（DI） */
    private TodoMapper todoMapper;

    /**
     * 送金指示登録対象取得
     * @author "Nihon Unisys, Ltd."
     * @param batchBaseDate バッチ処理基準日
     * @param settlementScheduledDate 決済予定日
     * @return 送金指示登録対象リスト
     */
    public List<Map<String, Object>> selectRemittanceInstructionTarget(
			Date batchBaseDate, Date settlementScheduledDate) throws Exception {

        // 条件Map設定
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("batchBaseDate", batchBaseDate);
		map.put("settlementScheduledDate", settlementScheduledDate);

        // 結果返却
        return registRemittanceInstructionMapper.selectRemittanceInstructionTarget(map);

    }

    /**
     * 契約者取得
     * @author "Nihon Unisys, Ltd."
     * @param contractorId 契約者ID
     * @return 契約者Entityリスト
     */
    public List<Contractor> selectContractor(String contractorId) {

        ContractorExample contractorExample = new ContractorExample();

        contractorExample.createCriteria().andContractorIdEqualTo(Integer.valueOf(contractorId));

        // 結果返却
        return contractorMapper.selectByExample(contractorExample);

    }

    /**
     * 支払履歴取得
     * @author "Nihon Unisys, Ltd."
     * @param accountId 口座ID
     * @param remitCreateDate 送金作成日
     * @return 送金先レコードリスト
     */
    public List<Map<String, Object>> selectPaymentHistory(String accountId, Date remitCreateDate) throws Exception {

        // 条件Map設定
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("rtAccountId", accountId);
        map.put("remitCreateDate", remitCreateDate);

        // 結果返却
        return registRemittanceInstructionMapper.selectRemitteeInfo(map);

    }

    /**
     * 送金ステータス更新
     * @author "Nihon Unisys, Ltd."
     * @param remitId 送金ID
     * @param remitStatusCode 送金ステータスコード
     * @param updateCount 更新回数
     * @return 更新結果件数
     */
    public Integer updateRemittanceStatusCode(
            String remitId,
            String remitStatusCode,
            Integer updateCount) {

        // 更新結果件数
        Integer updateRemittanceStatusCodeResultCount = 0;

        // システム日時
        Timestamp systemDateTime = new Timestamp(System.currentTimeMillis());
        // 更新モジュールコード
        String updateModuleCode = ThreadContext.getRequestThreadContext().get(ECISConstants.CLASS_NAME_KEY).toString();

        Remit remit = new Remit();
        remit.setRemitStatusCode(remitStatusCode);
        remit.setUpdateCount(updateCount + 1);
        remit.setUpdateTime(systemDateTime);
        remit.setUpdateModuleCode(updateModuleCode);

        RemitExample remitExample = new RemitExample();
        remitExample.createCriteria().andRemitIdEqualTo(Integer.valueOf(remitId));

        updateRemittanceStatusCodeResultCount = remitMapper.updateByExampleSelective(remit, remitExample);

        // 結果返却
        return updateRemittanceStatusCodeResultCount;

    }

    /**
     * API連携
     * @author "Nihon Unisys, Ltd."
     * @param url 接続先URL
     * @param timeout タイムアウト値（ミリ秒）
     * @param useProxy Proxy使用有無
     * @param proxyHost Proxyホスト
     * @param proxyPort Proxyポート番号
     * @param useBasicAuthentication Basic認証使用有無
     * @param basicAuthenticationUser Basic認証ユーザ
     * @param basicAuthenticationPassword Basic認証パスワード
     * @param shopId ショップID
     * @param shopPassword ショップパスワード
     * @param processingDivision 処理区分
     * @param depositId 入金ID
     * @param accountId 口座ID
     * @param receiptAmount 入金金額
     * @return レスポンスボディ
     * @throws Exception
     */
    public String callAPI(
            String url,
            Integer timeout,
            Boolean useProxy,
            String proxyHost,
            String proxyPort,
            Boolean useBasicAuthentication,
            String basicAuthenticationUser,
            String basicAuthenticationPassword,
            String shopId,
            String shopPassword,
            String processingDivision,
            String depositId,
            String accountId,
            Long receiptAmount) throws Exception {

        HttpRequestBusiness httpRequestBusiness = new HttpRequestBusinessImpl();

        if (null != timeout) {

            httpRequestBusiness.setConnectTimeout(timeout);

        }

        if (useProxy) {

            httpRequestBusiness.setProxy(proxyHost, proxyPort);

        }

        if (useBasicAuthentication) {

            httpRequestBusiness.setBasicAuthentication(basicAuthenticationUser, basicAuthenticationPassword);

        }

        MultiValueMap<String, Object> data = new LinkedMultiValueMap<String, Object>();

        data.add("Shop_ID", shopId);
        data.add("Shop_Pass", shopPassword);
        data.add("Method", processingDivision);
        data.add("Deposit_ID", depositId);
        data.add("Bank_ID", accountId);
        data.add("Amount", String.valueOf(receiptAmount));

        String responseBody = httpRequestBusiness.doPost(
                url,
                data);

        return responseBody;

    }

    /**
     * TODO登録
     * @author "Nihon Unisys, Ltd."
     * @param ssysId サブシステムID
     * @param functionId 機能ID
     * @param messageId メッセージID
     * @param todoSearchKey TODO検索キー
     * @param message メッセージ
     * @param todoStatusCode TODOステータスコード
     * @return 登録結果件数
     */
    public Integer insertTodo(
            String ssysId,
            String functionId,
            String messageId,
            String todoSearchKey,
            String message,
            String todoStatusCode) {

        // 登録結果件数
        Integer insertTodoResultCount = 0;

        // システム日時
        Timestamp systemDateTime = new Timestamp(System.currentTimeMillis());
        // 更新モジュールコード
        String updateModuleCode = ThreadContext.getRequestThreadContext().get(ECISConstants.CLASS_NAME_KEY).toString();

        Todo todo = new Todo();

        todo.setAccrualTime(systemDateTime);
        todo.setSsysId(ssysId);
        todo.setFunctionId(functionId);
        todo.setMessageId(messageId);
        todo.setTodoSearchKey(todoSearchKey);
        todo.setMessage(message);
        todo.setTodoStatusCode(todoStatusCode);
        todo.setUpdateCount(0);
        todo.setCreateTime(systemDateTime);
        todo.setUpdateTime(systemDateTime);
        todo.setUpdateModuleCode(updateModuleCode);

        insertTodoResultCount = this.todoMapper.insertSelective(todo);

        // 結果返却
        return insertTodoResultCount;

    }

    /**
     * 送金指示登録Mapperを設定する。(DI)
     *
     * @param sr110101RegistRemittanceInstructionMapper 送金Mapper(DI)
     */
    public void setSR110101RegistRemittanceInstructionMapper(
            SR110101_RegistRemittanceInstructionMapper sr110101RegistRemittanceInstructionMapper) {

        this.registRemittanceInstructionMapper = sr110101RegistRemittanceInstructionMapper;

    }

    /**
     * 送金Mapperを設定する。(DI)
     *
     * @param remitMapper 送金Mapper(DI)
     */
    public void setRemitMapper(
            RemitMapper remitMapper) {

        this.remitMapper = remitMapper;

    }

    /**
     * 契約者Mapperを設定する。(DI)
     *
     * @param contractorMapper 契約者Mapper(DI)
     */
    public void setContractorMapper(
            ContractorMapper contractorMapper) {

        this.contractorMapper = contractorMapper;

    }

    /**
     * TODOMapperを設定する。(DI)
     *
     * @param todoMapper TodoMapper(DI)
     */
    public void setTodoMapper(
            TodoMapper todoMapper) {

        this.todoMapper = todoMapper;

    }

}
