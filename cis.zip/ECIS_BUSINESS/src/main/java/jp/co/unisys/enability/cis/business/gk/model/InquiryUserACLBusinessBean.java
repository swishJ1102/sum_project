package jp.co.unisys.enability.cis.business.gk.model;

/**
 * ユーザ認証Beanクラス
 *
 * @author "Nihon Unisys, Ltd."
 */
public class InquiryUserACLBusinessBean {

  /**
   * アクションIDを保有する。
   */
  private String actionId;

  /**
   * ロールIDを保有する。
   */
  private String roleId;

  /**
   * 認証結果を保有する。
   */
  private boolean result;

  /**
   * アクションIDのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * アクションIDを取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return アクションID
   */
  public String getActionId() {
    return this.actionId;
  }

  /**
   * アクションIDのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * アクションIDを設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param actionId
   *          アクションID
   */
  public void setActionId(String actionId) {
    this.actionId = actionId;
  }

  /**
   * ロールIDのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * ロールIDを取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return ロールID
   */
  public String getRoleId() {
    return this.roleId;
  }

  /**
   * ロールIDのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * ロールIDを設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param roleId
   *          ロールID
   */
  public void setRoleId(String roleId) {
    this.roleId = roleId;
  }

  /**
   * 認証結果のgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 認証結果を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 認証結果
   */
  public boolean getResult() {
    return this.result;
  }

  /**
   * 認証結果のsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 認証結果を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param result
   *          認証結果
   */
  public void setResult(boolean result) {
    this.result = result;
  }

}
