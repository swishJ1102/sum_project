package jp.co.unisys.enability.cis.business.rk;

import jp.co.unisys.enability.cis.business.rk.model.RK_ChargeCalcWarningCheckBusinessBean;
import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;

/**
 * BRK0103-03算定日数暦日数差異チェックビジネス
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_MeterReadingDaysMonthDaysDiffCheckBusinessImpl implements
    RK_ChargeCalcWarningCheckBusiness {

  /**
   * 算定日数暦日数差異チェック
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 検針日数と置換検針日数が異なるかチェックを行う。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param chargeCalcWarningCheckBean
   *          《料金計算警告チェックビジネスBean》
   * @return 警告コード
   */
  @Override
  public String check(
      RK_ChargeCalcWarningCheckBusinessBean chargeCalcWarningCheckBean) {
    // 変数の定義
    String checkResult = null;

    // 《料金計算警告チェックビジネスBean》.検針日数と《料金計算警告チェックビジネスBean》.置換前検針日数が異なる場合
    if (!chargeCalcWarningCheckBean.getMeterReadingDays().equals(
        chargeCalcWarningCheckBean
            .getBeforeReplacementMeterReadingDays())) {
      // チェック結果（変数）に"306"を設定する
      checkResult = ECISRKConstants.WARNING_CLASS_MASTER_METER_READING_DAYS_MONTH_DAYS_NOT_EQUAL;
    }

    return checkResult;
  }

}
