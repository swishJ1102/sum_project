package jp.co.unisys.enability.cis.business.rk.model;

import java.util.Date;

/**
 * チェック対象の確定使用量の情報を保持するビジネスBean。
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * 使用量連携チェックビジネス。
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_UsageLinkageCheckCheckDataBusinessBean {

  /**
   * 地点特定番号を保有する。
   */
  private String spotNo;

  /**
   * 確定使用量ファイル名を保有する。
   */
  private String fixUsageFileName;

  /**
   * エリアコードを保有する。
   */
  private String areaCode;

  /**
   * 検針日を保有する。
   */
  private Date meterReadingDate;

  /**
   * 次回検針予定日を保有する。
   */
  private Date nextMeterReadingScheduledDate;

  /**
   * 仕訳コードを保有する。
   */
  private String categorizeCode;

  /**
   * 提供可否コードを保有する。
   */
  private String provideCheckCode;

  /**
   * 電圧区分を保有する。
   */
  private String voltageCategoryName;

  /**
   * 月次実績エラー区分コードを保有する。
   */
  private String monthlyUsageResultErrorCategoryCode;

  /**
   * 更新番号を保有する。
   */
  private String updateNo;

  /**
   * 分割番号を保有する。
   */
  private String splitNo;

  /**
   * 最大更新番号を保有する。
   */
  private String maxUpdateNo;

  /**
   * 地点特定番号有効フラグを保有する。
   */
  private String spotNoEffectiveFlag;

  /**
   * バッチ実行日を保有する。
   */
  private Date executeDate;

  /**
   * 更新コードを保有する。
   */
  private String updateCode;

  /**
   * 計算済みフラグを保有する。
   */
  private String calculatedFlag;

  /**
   * 地点特定番号のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 地点特定番号を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 地点特定番号
   */
  public String getSpotNo() {
    return this.spotNo;
  }

  /**
   * 地点特定番号のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 地点特定番号を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param spotNo
   *          地点特定番号
   */
  public void setSpotNo(String spotNo) {
    this.spotNo = spotNo;
  }

  /**
   * 確定使用量ファイル名のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 確定使用量ファイル名を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 確定使用量ファイル名
   */
  public String getFixUsageFileName() {
    return this.fixUsageFileName;
  }

  /**
   * 確定使用量ファイル名のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 確定使用量ファイル名を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param fixUsageFileName
   *          確定使用量ファイル名
   */
  public void setFixUsageFileName(String fixUsageFileName) {
    this.fixUsageFileName = fixUsageFileName;
  }

  /**
   * エリアコードのgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * エリアコードを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return エリアコード
   */
  public String getAreaCode() {
    return this.areaCode;
  }

  /**
   * エリアコードのsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * エリアコードを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param areaCode
   *          エリアコード
   */
  public void setAreaCode(String areaCode) {
    this.areaCode = areaCode;
  }

  /**
   * 検針日のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 検針日を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 検針日
   */
  public Date getMeterReadingDate() {
    return this.meterReadingDate;
  }

  /**
   * 検針日のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 検針日を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param meterReadingDate
   *          検針日
   */
  public void setMeterReadingDate(Date meterReadingDate) {
    this.meterReadingDate = meterReadingDate;
  }

  /**
   * 次回検針予定日のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 次回検針予定日を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 次回検針予定日
   */
  public Date getNextMeterReadingScheduledDate() {
    return this.nextMeterReadingScheduledDate;
  }

  /**
   * 次回検針予定日のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 次回検針予定日を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param nextMeterReadingScheduledDate
   *          次回検針予定日
   */
  public void setNextMeterReadingScheduledDate(
      Date nextMeterReadingScheduledDate) {
    this.nextMeterReadingScheduledDate = nextMeterReadingScheduledDate;
  }

  /**
   * 仕訳コードのgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 仕訳コードを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 仕訳コード
   */
  public String getCategorizeCode() {
    return this.categorizeCode;
  }

  /**
   * 仕訳コードのsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 仕訳コードを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param categorizeCode
   *          仕訳コード
   */
  public void setCategorizeCode(String categorizeCode) {
    this.categorizeCode = categorizeCode;
  }

  /**
   * 提供可否コードのgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 提供可否コードを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 提供可否コード
   */
  public String getProvideCheckCode() {
    return this.provideCheckCode;
  }

  /**
   * 提供可否コードのsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 提供可否コードを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param provideCheckCode
   *          提供可否コード
   */
  public void setProvideCheckCode(String provideCheckCode) {
    this.provideCheckCode = provideCheckCode;
  }

  /**
   * 電圧区分のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 電圧区分を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 電圧区分
   */
  public String getVoltageCategoryName() {
    return this.voltageCategoryName;
  }

  /**
   * 電圧区分のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 電圧区分を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param voltageCategoryName
   *          電圧区分
   */
  public void setVoltageCategoryName(String voltageCategoryName) {
    this.voltageCategoryName = voltageCategoryName;
  }

  /**
   * 月次実績エラー区分コードのgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 月次実績エラー区分コードを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 月次実績エラー区分コード
   */
  public String getMonthlyUsageResultErrorCategoryCode() {
    return this.monthlyUsageResultErrorCategoryCode;
  }

  /**
   * 月次実績エラー区分コードのsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 月次実績エラー区分コードを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param monthlyUsageResultErrorCategoryCode
   *          月次実績エラー区分コード
   */
  public void setMonthlyUsageResultErrorCategoryCode(
      String monthlyUsageResultErrorCategoryCode) {
    this.monthlyUsageResultErrorCategoryCode = monthlyUsageResultErrorCategoryCode;
  }

  /**
   * 更新番号のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 更新番号を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 更新番号
   */
  public String getUpdateNo() {
    return this.updateNo;
  }

  /**
   * 更新番号のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 更新番号を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param updateNo
   *          更新番号
   */
  public void setUpdateNo(String updateNo) {
    this.updateNo = updateNo;
  }

  /**
   * 分割番号のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 分割番号を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 分割番号
   */
  public String getSplitNo() {
    return this.splitNo;
  }

  /**
   * 分割番号のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 分割番号を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param splitNo
   *          分割番号
   */
  public void setSplitNo(String splitNo) {
    this.splitNo = splitNo;
  }

  /**
   * 最大更新番号のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 最大更新番号を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 最大更新番号
   */
  public String getMaxUpdateNo() {
    return this.maxUpdateNo;
  }

  /**
   * 最大更新番号のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 最大更新番号を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param maxUpdateNo
   *          最大更新番号
   */
  public void setMaxUpdateNo(String maxUpdateNo) {
    this.maxUpdateNo = maxUpdateNo;
  }

  /**
   * 地点特定番号有効フラグのgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 地点特定番号有効フラグを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 地点特定番号有効フラグ
   */
  public String getSpotNoEffectiveFlag() {
    return this.spotNoEffectiveFlag;
  }

  /**
   * 地点特定番号有効フラグのsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 地点特定番号有効フラグを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param spotNoEffectiveFlag
   *          地点特定番号有効フラグ
   */
  public void setSpotNoEffectiveFlag(String spotNoEffectiveFlag) {
    this.spotNoEffectiveFlag = spotNoEffectiveFlag;
  }

  /**
   * バッチ実行日のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * バッチ実行日を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return バッチ実行日
   */
  public Date getExecuteDate() {
    return executeDate;
  }

  /**
   * バッチ実行日のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * バッチ実行日を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param spotNoEffectiveFlag
   *          バッチ実行日
   */
  public void setExecuteDate(Date executeDate) {
    this.executeDate = executeDate;
  }

  /**
   * 更新コードのgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 更新コードを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 更新コード
   */
  public String getUpdateCode() {
    return this.updateCode;
  }

  /**
   * 更新コードのsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 更新コードを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param updateCode
   *          更新コード
   */
  public void setUpdateCode(String updateCode) {
    this.updateCode = updateCode;
  }

  /**
   * 計算済みフラグのgetter。
   * 
   * <pre>
   *
   * <p><b>【仕様詳細】</b></p>
   * 計算済みフラグを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 計算済みフラグ
   */
  public String getCalculatedFlag() {
    return this.calculatedFlag;
  }

  /**
   * 計算済みフラグのsetter。
   * 
   * <pre>
   *
   * <p><b>【仕様詳細】</b></p>
   * 計算済みフラグを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param calculatedFlag
   *          計算済みフラグ
   */
  public void setCalculatedFlag(String calculatedFlag) {
    this.calculatedFlag = calculatedFlag;
  }

}
