package jp.co.unisys.enability.cis.business.sn.model;

/**
 * 料金実績一覧データビジネスBean. 料金実績一覧のデータを保持するBeanクラス
 *
 * @author "Nihon Unisys, Ltd."
 */
public class SN0106_ChargeResultListDataBusinessBean extends SN_CreateCsvBusinessBean {

  /** 確定料金実績ID */
  private String fcrId;

  /** 契約ID */
  private String contractId;

  /** 契約番号 */
  private String contractNo;

  /** 適用開始日 */
  private String applySd;

  /** 利用年月 */
  private String usePeriod;

  /** 契約者ID */
  private String contractorId;

  /** 契約者番号 */
  private String contractorNo;

  /** 部課コード */
  private String sectionCode;

  /** 取引先コード */
  private String customerCode;

  /** 提供モデルコード */
  private String pmCode;

  /** 提供モデル企業コード */
  private String pmCompanyCode;

  /** メータ設置場所ID */
  private String mlId;

  /** エリアコード */
  private String areaCode;

  /** 自社管理エリアコード */
  private String ourMngAreaCode;

  /** 地点特定番号 */
  private String spotNo;

  /** 次回検針予定日 */
  private String nextMrScheduledDate;

  /** 料金メニューID */
  private String rmId;

  /** 契約容量 */
  private String cca;

  /** 託送契約容量 */
  private String consignmentCca;

  /** 取引種別コード */
  private String dealClassCode;

  /** 確定使用量ID */
  private String fuId;

  /** 検針日 */
  private String mrDate;

  /** 検針理由コード */
  private String mrReasonCode;

  /** 料金算定開始日 */
  private String ccSd;

  /** 料金算定終了日 */
  private String ccEd;

  /** 料金確定日 */
  private String cfd;

  /** 計算用力率 */
  private String calculatingPowerFactor;

  /** 確定料金 */
  private String fixCharge;

  /** 消費税等相当額 */
  private String ctEquivalent;

  /** 消費税率 */
  private String ctRate;

  /** 消費税科目コード */
  private String ctIc;

  /** 基本料金 */
  private String basicCharge;

  /** 電力量料金 */
  private String powerConsumptionCharge;

  /** 燃料費調整額 */
  private String fca;

  /** 再エネ賦課金 */
  private String rec;

  /** 契約超過金 */
  private String contractExcessCharge;

  /** 付帯金額 */
  private String splAmount;

  /** 売上1補正金額 */
  private String sp1Correction;

  /** 売上2補正金額 */
  private String sp2Correction;

  /** 売上3補正金額 */
  private String sp3Correction;

  /** 売上計上日 */
  private String spRecordedDate;

  /** 売上計上処理日 */
  private String spRecordedExecuteDate;

  /** 売上1科目コード */
  private String spIc1;

  /** 売上1金額 */
  private String sp1;

  /** 売上2科目コード */
  private String spIc2;

  /** 売上2金額 */
  private String sp2;

  /** 売上3科目コード */
  private String spIc3;

  /** 売上3金額 */
  private String sp3;

  /** 売掛金科目コード */
  private String arIc;

  /** 売掛金額 */
  private String arAmount;

  /** 売掛金消込計上日 */
  private String arRccRecordedDate;

  /** 売掛金消込基準日 */
  private String arRccBaseDate;

  /** 売掛金消込処理日 */
  private String arRccExecuteDate;

  /** 請求番号 */
  private String blNo;

  /** 請求消込時充当有無フラグ */
  private String blRccAppropriationFlag;

  /** 売掛金消込振替先科目コード */
  private String arRccTransferIc;

  /** 完了フラグ */
  private String completedFlag;

  /** 料金ステータスコード */
  private String csCode;

  /** 債権回収依頼対象フラグ */
  private String ccccFlag;

  /** 契約グループ番号 */
  private String contractGroupNo;

  /** 警告対応区分コード */
  private String warningDealCatCode;

  /** 確定料金実績作成日 */
  private String fcrCreateDate;

  /** 接続送電サービス区分コード */
  private String cssCatCode;

  /** 託送料金相当額 */
  private String consignmentChargeEquivalent;

  /** 備考 */
  private String note;

  /** 契約容量単位 */
  private String ccaUnit;

  /** 託送契約容量単位 */
  private String consignmentCcaUnit;

  /** 託送契約容量判定日 */
  private String consignmentCcaDecisionDate;

  /** 営業委託先コード */
  private String scCode;

  /** 業種コード */
  private String businessTypeCode;

  /** 使用量 */
  private String usageQuantity;

  /** 最大需要電力（参考） */
  private String pdReference;

  /** 使用開始日 */
  private String usageSd;

  /** 使用終了日 */
  private String usageEd;

  /** 料金算定日数 */
  private String ccDays;

  /** 確定使用量作成日 */
  private String fuCreateDate;

  /** 力率 */
  private String powerFactor;

  /** 計器区分コード */
  private String meterCatCode;

  /** 全日電力量当月指示数 */
  private String currentIn;

  /** 全日電力量前月指示数 */
  private String previousIn;

  /** 全日電力量指示数差(差引) */
  private String inDifference;

  /** 乗率 */
  private String multiplyingFactor;

  /** 全日電力量指示数算出使用量 */
  private String inCalculationUsage;

  /** 力測有効電力量当月指示数 */
  private String effectiveCurrentIndicationNo;

  /** 力測有効電力量前月指示数 */
  private String effectivePreviousIndicationNo;

  /** 力測有効電力量指示数差（差引） */
  private String effectiveIndicationNoDifference;

  /** 力測有効電力量指示数算出使用量 */
  private String effectiveIndicationNoCalculationUsage;

  /** 力測無効電力量当月指示数 */
  private String reactiveCurrentIndicationNo;

  /** 力測無効電力量前月指示数 */
  private String reactivePreviousIndicationNo;

  /** 力測無効電力量指示数差（差引） */
  private String reactiveIndicationNoDifference;

  /** 力測無効電力量指示数算出使用量 */
  private String reactiveIndicationNoCalculationUsage;

  /** 損失補正率 */
  private String kwhDisadvantageFactor;

  /** 計器交換フラグ */
  private String meterReplacementFlag;

  /** 計器識別番号 */
  private String meterIdn;

  /** 実量歴対象年月 */
  private String coveredPeriod;

  /** 実量歴最大電力 */
  private String peakKw;

  /** 日割１容量 */
  private String contractCapacity1;

  /** 日割１使用量 */
  private String usageQuantity1;

  /** 日割２容量 */
  private String contractCapacity2;

  /** 日割２使用量 */
  private String usageQuantity2;

  /** 日割３容量 */
  private String contractCapacity3;

  /** 日割３使用量 */
  private String usageQuantity3;

  /** 料金メニュー名称 */
  private String rmName;

  /** エリア名称 */
  private String areaName;

  /** 夏季使用量 */
  private String summerSeasonUsage;

  /** 他季使用量 */
  private String otherSeasonUsage;

  /** 提供モデル企業名 */
  private String pmCompanyName;

  /**
   * 確定料金実績IDを設定する。
   *
   * @param fcrId
   *          確定料金実績ID
   */
  public void setFcrId(String fcrId) {
    this.fcrId = fcrId;
  }

  /**
   * 確定料金実績IDを取得する。
   *
   * @return 確定料金実績ID
   */
  public String getFcrId() {
    return this.fcrId;
  }

  /**
   * 契約IDを設定する。
   *
   * @param contractId
   *          契約ID
   */
  public void setContractId(String contractId) {
    this.contractId = contractId;
  }

  /**
   * 契約IDを取得する。
   *
   * @return 契約ID
   */
  public String getContractId() {
    return this.contractId;
  }

  /**
   * 契約番号を設定する。
   *
   * @param contractNo
   *          契約番号
   */
  public void setContractNo(String contractNo) {
    this.contractNo = contractNo;
  }

  /**
   * 契約番号を取得する。
   *
   * @return 契約番号
   */
  public String getContractNo() {
    return this.contractNo;
  }

  /**
   * 適用開始日を設定する。
   *
   * @param applySd
   *          適用開始日
   */
  public void setApplySd(String applySd) {
    this.applySd = applySd;
  }

  /**
   * 適用開始日を取得する。
   *
   * @return 適用開始日
   */
  public String getApplySd() {
    return this.applySd;
  }

  /**
   * 利用年月を設定する。
   *
   * @param usePeriod
   *          利用年月
   */
  public void setUsePeriod(String usePeriod) {
    this.usePeriod = usePeriod;
  }

  /**
   * 利用年月を取得する。
   *
   * @return 利用年月
   */
  public String getUsePeriod() {
    return this.usePeriod;
  }

  /**
   * 契約者IDを設定する。
   *
   * @param contractorId
   *          契約者ID
   */
  public void setContractorId(String contractorId) {
    this.contractorId = contractorId;
  }

  /**
   * 契約者IDを取得する。
   *
   * @return 契約者ID
   */
  public String getContractorId() {
    return this.contractorId;
  }

  /**
   * 契約者番号を設定する。
   *
   * @param contractorNo
   *          契約者番号
   */
  public void setContractorNo(String contractorNo) {
    this.contractorNo = contractorNo;
  }

  /**
   * 契約者番号を取得する。
   *
   * @return 契約者番号
   */
  public String getContractorNo() {
    return this.contractorNo;
  }

  /**
   * 部課コードを設定する。
   *
   * @param sectionCode
   *          部課コード
   */
  public void setSectionCode(String sectionCode) {
    this.sectionCode = sectionCode;
  }

  /**
   * 部課コードを取得する。
   *
   * @return 部課コード
   */
  public String getSectionCode() {
    return this.sectionCode;
  }

  /**
   * 取引先コードを設定する。
   *
   * @param customerCode
   *          取引先コード
   */
  public void setCustomerCode(String customerCode) {
    this.customerCode = customerCode;
  }

  /**
   * 取引先コードを取得する。
   *
   * @return 取引先コード
   */
  public String getCustomerCode() {
    return this.customerCode;
  }

  /**
   * 提供モデルコードを設定する。
   *
   * @param pmCode
   *          提供モデルコード
   */
  public void setPmCode(String pmCode) {
    this.pmCode = pmCode;
  }

  /**
   * 提供モデルコードを取得する。
   *
   * @return 提供モデルコード
   */
  public String getPmCode() {
    return this.pmCode;
  }

  /**
   * 提供モデル企業コードを設定する。
   *
   * @param pmCompanyCode
   *          提供モデル企業コード
   */
  public void setPmCompanyCode(String pmCompanyCode) {
    this.pmCompanyCode = pmCompanyCode;
  }

  /**
   * 提供モデル企業コードを取得する。
   *
   * @return 提供モデル企業コード
   */
  public String getPmCompanyCode() {
    return this.pmCompanyCode;
  }

  /**
   * メータ設置場所IDを設定する。
   *
   * @param mlId
   *          メータ設置場所ID
   */
  public void setMlId(String mlId) {
    this.mlId = mlId;
  }

  /**
   * メータ設置場所IDを取得する。
   *
   * @return メータ設置場所ID
   */
  public String getMlId() {
    return this.mlId;
  }

  /**
   * エリアコードを設定する。
   *
   * @param areaCode
   *          エリアコード
   */
  public void setAreaCode(String areaCode) {
    this.areaCode = areaCode;
  }

  /**
   * エリアコードを取得する。
   *
   * @return エリアコード
   */
  public String getAreaCode() {
    return this.areaCode;
  }

  /**
   * 自社管理エリアコードを設定する。
   *
   * @param ourMngAreaCode
   *          自社管理エリアコード
   */
  public void setOurMngAreaCode(String ourMngAreaCode) {
    this.ourMngAreaCode = ourMngAreaCode;
  }

  /**
   * 自社管理エリアコードを取得する。
   *
   * @return 自社管理エリアコード
   */
  public String getOurMngAreaCode() {
    return this.ourMngAreaCode;
  }

  /**
   * 地点特定番号を設定する。
   *
   * @param spotNo
   *          地点特定番号
   */
  public void setSpotNo(String spotNo) {
    this.spotNo = spotNo;
  }

  /**
   * 地点特定番号を取得する。
   *
   * @return 地点特定番号
   */
  public String getSpotNo() {
    return this.spotNo;
  }

  /**
   * 次回検針予定日を設定する。
   *
   * @param nextMrScheduledDate
   *          次回検針予定日
   */
  public void setNextMrScheduledDate(String nextMrScheduledDate) {
    this.nextMrScheduledDate = nextMrScheduledDate;
  }

  /**
   * 次回検針予定日を取得する。
   *
   * @return 次回検針予定日
   */
  public String getNextMrScheduledDate() {
    return this.nextMrScheduledDate;
  }

  /**
   * 料金メニューIDを設定する。
   *
   * @param rmId
   *          料金メニューID
   */
  public void setRmId(String rmId) {
    this.rmId = rmId;
  }

  /**
   * 料金メニューIDを取得する。
   *
   * @return 料金メニューID
   */
  public String getRmId() {
    return this.rmId;
  }

  /**
   * 契約容量を設定する。
   *
   * @param cca
   *          契約容量
   */
  public void setCca(String cca) {
    this.cca = cca;
  }

  /**
   * 契約容量を取得する。
   *
   * @return 契約容量
   */
  public String getCca() {
    return this.cca;
  }

  /**
   * 託送契約容量を設定する。
   *
   * @param consignmentCca
   *          託送契約容量
   */
  public void setConsignmentCca(String consignmentCca) {
    this.consignmentCca = consignmentCca;
  }

  /**
   * 託送契約容量を取得する。
   *
   * @return 託送契約容量
   */
  public String getConsignmentCca() {
    return this.consignmentCca;
  }

  /**
   * 取引種別コードを設定する。
   *
   * @param dealClassCode
   *          取引種別コード
   */
  public void setDealClassCode(String dealClassCode) {
    this.dealClassCode = dealClassCode;
  }

  /**
   * 取引種別コードを取得する。
   *
   * @return 取引種別コード
   */
  public String getDealClassCode() {
    return this.dealClassCode;
  }

  /**
   * 確定使用量IDを設定する。
   *
   * @param fuId
   *          確定使用量ID
   */
  public void setFuId(String fuId) {
    this.fuId = fuId;
  }

  /**
   * 確定使用量IDを取得する。
   *
   * @return 確定使用量ID
   */
  public String getFuId() {
    return this.fuId;
  }

  /**
   * 検針日を設定する。
   *
   * @param mrDate
   *          検針日
   */
  public void setMrDate(String mrDate) {
    this.mrDate = mrDate;
  }

  /**
   * 検針日を取得する。
   *
   * @return 検針日
   */
  public String getMrDate() {
    return this.mrDate;
  }

  /**
   * 検針理由コードを設定する。
   *
   * @param mrReasonCode
   *          検針理由コード
   */
  public void setMrReasonCode(String mrReasonCode) {
    this.mrReasonCode = mrReasonCode;
  }

  /**
   * 検針理由コードを取得する。
   *
   * @return 検針理由コード
   */
  public String getMrReasonCode() {
    return this.mrReasonCode;
  }

  /**
   * 料金算定開始日を設定する。
   *
   * @param ccSd
   *          料金算定開始日
   */
  public void setCcSd(String ccSd) {
    this.ccSd = ccSd;
  }

  /**
   * 料金算定開始日を取得する。
   *
   * @return 料金算定開始日
   */
  public String getCcSd() {
    return this.ccSd;
  }

  /**
   * 料金算定終了日を設定する。
   *
   * @param ccEd
   *          料金算定終了日
   */
  public void setCcEd(String ccEd) {
    this.ccEd = ccEd;
  }

  /**
   * 料金算定終了日を取得する。
   *
   * @return 料金算定終了日
   */
  public String getCcEd() {
    return this.ccEd;
  }

  /**
   * 料金確定日を設定する。
   *
   * @param cfd
   *          料金確定日
   */
  public void setCfd(String cfd) {
    this.cfd = cfd;
  }

  /**
   * 料金確定日を取得する。
   *
   * @return 料金確定日
   */
  public String getCfd() {
    return this.cfd;
  }

  /**
   * 計算用力率を設定する。
   *
   * @param calculatingPowerFactor
   *          計算用力率
   */
  public void setCalculatingPowerFactor(String calculatingPowerFactor) {
    this.calculatingPowerFactor = calculatingPowerFactor;
  }

  /**
   * 計算用力率を取得する。
   *
   * @return 計算用力率
   */
  public String getCalculatingPowerFactor() {
    return this.calculatingPowerFactor;
  }

  /**
   * 確定料金を設定する。
   *
   * @param fixCharge
   *          確定料金
   */
  public void setFixCharge(String fixCharge) {
    this.fixCharge = fixCharge;
  }

  /**
   * 確定料金を取得する。
   *
   * @return 確定料金
   */
  public String getFixCharge() {
    return this.fixCharge;
  }

  /**
   * 消費税等相当額を設定する。
   *
   * @param ctEquivalent
   *          消費税等相当額
   */
  public void setCtEquivalent(String ctEquivalent) {
    this.ctEquivalent = ctEquivalent;
  }

  /**
   * 消費税等相当額を取得する。
   *
   * @return 消費税等相当額
   */
  public String getCtEquivalent() {
    return this.ctEquivalent;
  }

  /**
   * 消費税率を設定する。
   *
   * @param ctRate
   *          消費税率
   */
  public void setCtRate(String ctRate) {
    this.ctRate = ctRate;
  }

  /**
   * 消費税率を取得する。
   *
   * @return 消費税率
   */
  public String getCtRate() {
    return this.ctRate;
  }

  /**
   * 消費税科目コードを設定する。
   *
   * @param ctIc
   *          消費税科目コード
   */
  public void setCtIc(String ctIc) {
    this.ctIc = ctIc;
  }

  /**
   * 消費税科目コードを取得する。
   *
   * @return 消費税科目コード
   */
  public String getCtIc() {
    return this.ctIc;
  }

  /**
   * 基本料金を設定する。
   *
   * @param basicCharge
   *          基本料金
   */
  public void setBasicCharge(String basicCharge) {
    this.basicCharge = basicCharge;
  }

  /**
   * 基本料金を取得する。
   *
   * @return 基本料金
   */
  public String getBasicCharge() {
    return this.basicCharge;
  }

  /**
   * 電力量料金を設定する。
   *
   * @param powerConsumptionCharge
   *          電力量料金
   */
  public void setPowerConsumptionCharge(String powerConsumptionCharge) {
    this.powerConsumptionCharge = powerConsumptionCharge;
  }

  /**
   * 電力量料金を取得する。
   *
   * @return 電力量料金
   */
  public String getPowerConsumptionCharge() {
    return this.powerConsumptionCharge;
  }

  /**
   * 燃料費調整額を設定する。
   *
   * @param fca
   *          燃料費調整額
   */
  public void setFca(String fca) {
    this.fca = fca;
  }

  /**
   * 燃料費調整額を取得する。
   *
   * @return 燃料費調整額
   */
  public String getFca() {
    return this.fca;
  }

  /**
   * 再エネ賦課金を設定する。
   *
   * @param rec
   *          再エネ賦課金
   */
  public void setRec(String rec) {
    this.rec = rec;
  }

  /**
   * 再エネ賦課金を取得する。
   *
   * @return 再エネ賦課金
   */
  public String getRec() {
    return this.rec;
  }

  /**
   * 契約超過金を設定する。
   *
   * @param contractExcessCharge
   *          契約超過金
   */
  public void setContractExcessCharge(String contractExcessCharge) {
    this.contractExcessCharge = contractExcessCharge;
  }

  /**
   * 契約超過金を取得する。
   *
   * @return 契約超過金
   */
  public String getContractExcessCharge() {
    return this.contractExcessCharge;
  }

  /**
   * 付帯金額を設定する。
   *
   * @param splAmount
   *          付帯金額
   */
  public void setSplAmount(String splAmount) {
    this.splAmount = splAmount;
  }

  /**
   * 付帯金額を取得する。
   *
   * @return 付帯金額
   */
  public String getSplAmount() {
    return this.splAmount;
  }

  /**
   * 売上1補正金額を設定する。
   *
   * @param sp1Correction
   *          売上1補正金額
   */
  public void setSp1Correction(String sp1Correction) {
    this.sp1Correction = sp1Correction;
  }

  /**
   * 売上1補正金額を取得する。
   *
   * @return 売上1補正金額
   */
  public String getSp1Correction() {
    return this.sp1Correction;
  }

  /**
   * 売上2補正金額を設定する。
   *
   * @param sp2Correction
   *          売上2補正金額
   */
  public void setSp2Correction(String sp2Correction) {
    this.sp2Correction = sp2Correction;
  }

  /**
   * 売上2補正金額を取得する。
   *
   * @return 売上2補正金額
   */
  public String getSp2Correction() {
    return this.sp2Correction;
  }

  /**
   * 売上3補正金額を設定する。
   *
   * @param sp3Correction
   *          売上3補正金額
   */
  public void setSp3Correction(String sp3Correction) {
    this.sp3Correction = sp3Correction;
  }

  /**
   * 売上3補正金額を取得する。
   *
   * @return 売上3補正金額
   */
  public String getSp3Correction() {
    return this.sp3Correction;
  }

  /**
   * 売上計上日を設定する。
   *
   * @param spRecordedDate
   *          売上計上日
   */
  public void setSpRecordedDate(String spRecordedDate) {
    this.spRecordedDate = spRecordedDate;
  }

  /**
   * 売上計上日を取得する。
   *
   * @return 売上計上日
   */
  public String getSpRecordedDate() {
    return this.spRecordedDate;
  }

  /**
   * 売上計上処理日を設定する。
   *
   * @param spRecordedExecuteDate
   *          売上計上処理日
   */
  public void setSpRecordedExecuteDate(String spRecordedExecuteDate) {
    this.spRecordedExecuteDate = spRecordedExecuteDate;
  }

  /**
   * 売上計上処理日を取得する。
   *
   * @return 売上計上処理日
   */
  public String getSpRecordedExecuteDate() {
    return this.spRecordedExecuteDate;
  }

  /**
   * 売上1科目コードを設定する。
   *
   * @param spIc1
   *          売上1科目コード
   */
  public void setSpIc1(String spIc1) {
    this.spIc1 = spIc1;
  }

  /**
   * 売上1科目コードを取得する。
   *
   * @return 売上1科目コード
   */
  public String getSpIc1() {
    return this.spIc1;
  }

  /**
   * 売上1金額を設定する。
   *
   * @param sp1
   *          売上1金額
   */
  public void setSp1(String sp1) {
    this.sp1 = sp1;
  }

  /**
   * 売上1金額を取得する。
   *
   * @return 売上1金額
   */
  public String getSp1() {
    return this.sp1;
  }

  /**
   * 売上2科目コードを設定する。
   *
   * @param spIc2
   *          売上2科目コード
   */
  public void setSpIc2(String spIc2) {
    this.spIc2 = spIc2;
  }

  /**
   * 売上2科目コードを取得する。
   *
   * @return 売上2科目コード
   */
  public String getSpIc2() {
    return this.spIc2;
  }

  /**
   * 売上2金額を設定する。
   *
   * @param sp2
   *          売上2金額
   */
  public void setSp2(String sp2) {
    this.sp2 = sp2;
  }

  /**
   * 売上2金額を取得する。
   *
   * @return 売上2金額
   */
  public String getSp2() {
    return this.sp2;
  }

  /**
   * 売上3科目コードを設定する。
   *
   * @param spIc3
   *          売上3科目コード
   */
  public void setSpIc3(String spIc3) {
    this.spIc3 = spIc3;
  }

  /**
   * 売上3科目コードを取得する。
   *
   * @return 売上3科目コード
   */
  public String getSpIc3() {
    return this.spIc3;
  }

  /**
   * 売上3金額を設定する。
   *
   * @param sp3
   *          売上3金額
   */
  public void setSp3(String sp3) {
    this.sp3 = sp3;
  }

  /**
   * 売上3金額を取得する。
   *
   * @return 売上金額
   */
  public String getSp3() {
    return this.sp3;
  }

  /**
   * 売掛金科目コードを設定する。
   *
   * @param arIc
   *          売掛金科目コード
   */
  public void setArIc(String arIc) {
    this.arIc = arIc;
  }

  /**
   * 売掛金科目コードを取得する。
   *
   * @return 売掛金科目コード
   */
  public String getArIc() {
    return this.arIc;
  }

  /**
   * 売掛金額を設定する。
   *
   * @param arAmount
   *          売掛金額
   */
  public void setArAmount(String arAmount) {
    this.arAmount = arAmount;
  }

  /**
   * 売掛金額を取得する。
   *
   * @return 売掛金額
   */
  public String getArAmount() {
    return this.arAmount;
  }

  /**
   * 売掛金消込計上日を設定する。
   *
   * @param arRccRecordedDate
   *          売掛金消込計上日
   */
  public void setArRccRecordedDate(String arRccRecordedDate) {
    this.arRccRecordedDate = arRccRecordedDate;
  }

  /**
   * 売掛金消込計上日を取得する。
   *
   * @return 売掛金消込計上日
   */
  public String getArRccRecordedDate() {
    return this.arRccRecordedDate;
  }

  /**
   * 売掛金消込基準日を設定する。
   *
   * @param arRccBaseDate
   *          売掛金消込基準日
   */
  public void setArRccBaseDate(String arRccBaseDate) {
    this.arRccBaseDate = arRccBaseDate;
  }

  /**
   * 売掛金消込基準日を取得する。
   *
   * @return 売掛金消込基準日
   */
  public String getArRccBaseDate() {
    return this.arRccBaseDate;
  }

  /**
   * 売掛金消込処理日を設定する。
   *
   * @param arRccExecuteDate
   *          売掛金消込処理日
   */
  public void setArRccExecuteDate(String arRccExecuteDate) {
    this.arRccExecuteDate = arRccExecuteDate;
  }

  /**
   * 売掛金消込処理日を取得する。
   *
   * @return 売掛金消込処理日
   */
  public String getArRccExecuteDate() {
    return this.arRccExecuteDate;
  }

  /**
   * 請求番号を設定する。
   *
   * @param blNo
   *          請求番号
   */
  public void setBlNo(String blNo) {
    this.blNo = blNo;
  }

  /**
   * 請求番号を取得する。
   *
   * @return 請求番号
   */
  public String getBlNo() {
    return this.blNo;
  }

  /**
   * 請求消込時充当有無フラグを設定する。
   *
   * @param blRccAppropriationFlag
   *          請求消込時充当有無フラグ
   */
  public void setBlRccAppropriationFlag(String blRccAppropriationFlag) {
    this.blRccAppropriationFlag = blRccAppropriationFlag;
  }

  /**
   * 請求消込時充当有無フラグを取得する。
   *
   * @return 請求消込時充当有無フラグ
   */
  public String getBlRccAppropriationFlag() {
    return this.blRccAppropriationFlag;
  }

  /**
   * 売掛金消込振替先科目コードを設定する。
   *
   * @param arRccTransferIc
   *          売掛金消込振替先科目コード
   */
  public void setArRccTransferIc(String arRccTransferIc) {
    this.arRccTransferIc = arRccTransferIc;
  }

  /**
   * 売掛金消込振替先科目コードを取得する。
   *
   * @return 売掛金消込振替先科目コード
   */
  public String getArRccTransferIc() {
    return this.arRccTransferIc;
  }

  /**
   * 完了フラグを設定する。
   *
   * @param completedFlag
   *          完了フラグ
   */
  public void setCompletedFlag(String completedFlag) {
    this.completedFlag = completedFlag;
  }

  /**
   * 完了フラグを取得する。
   *
   * @return 完了フラグ
   */
  public String getCompletedFlag() {
    return this.completedFlag;
  }

  /**
   * 料金ステータスコードを設定する。
   *
   * @param csCode
   *          料金ステータスコード
   */
  public void setCsCode(String csCode) {
    this.csCode = csCode;
  }

  /**
   * 料金ステータスコードを取得する。
   *
   * @return 料金ステータスコード
   */
  public String getCsCode() {
    return this.csCode;
  }

  /**
   * 債権回収依頼対象フラグを設定する。
   *
   * @param ccccFlag
   *          債権回収依頼対象フラグ
   */
  public void setCcccFlag(String ccccFlag) {
    this.ccccFlag = ccccFlag;
  }

  /**
   * 債権回収依頼対象フラグを取得する。
   *
   * @return 債権回収依頼対象フラグ
   */
  public String getCcccFlag() {
    return this.ccccFlag;
  }

  /**
   * 契約グループ番号を設定する。
   *
   * @param contractGroupNo
   *          契約グループ番号
   */
  public void setContractGroupNo(String contractGroupNo) {
    this.contractGroupNo = contractGroupNo;
  }

  /**
   * 契約グループ番号を取得する。
   *
   * @return 契約グループ番号
   */
  public String getContractGroupNo() {
    return this.contractGroupNo;
  }

  /**
   * 警告対応区分コードを設定する。
   *
   * @param warningDealCatCode
   *          警告対応区分コード
   */
  public void setWarningDealCatCode(String warningDealCatCode) {
    this.warningDealCatCode = warningDealCatCode;
  }

  /**
   * 警告対応区分コードを取得する。
   *
   * @return 警告対応区分コード
   */
  public String getWarningDealCatCode() {
    return this.warningDealCatCode;
  }

  /**
   * 確定料金実績作成日を設定する。
   *
   * @param fcrCreateDate
   *          確定料金実績作成日
   */
  public void setFcrCreateDate(String fcrCreateDate) {
    this.fcrCreateDate = fcrCreateDate;
  }

  /**
   * 確定料金実績作成日を取得する。
   *
   * @return 確定料金実績作成日
   */
  public String getFcrCreateDate() {
    return this.fcrCreateDate;
  }

  /**
   * 接続送電サービス区分コードを設定する。
   *
   * @param cssCatCode
   *          接続送電サービス区分コード
   */
  public void setCssCatCode(String cssCatCode) {
    this.cssCatCode = cssCatCode;
  }

  /**
   * 接続送電サービス区分コードを取得する。
   *
   * @return 接続送電サービス区分コード
   */
  public String getCssCatCode() {
    return this.cssCatCode;
  }

  /**
   * 託送料金相当額を設定する。
   *
   * @param consignmentChargeEquivalent
   *          託送料金相当額
   */
  public void setConsignmentChargeEquivalent(String consignmentChargeEquivalent) {
    this.consignmentChargeEquivalent = consignmentChargeEquivalent;
  }

  /**
   * 託送料金相当額を取得する。
   *
   * @return 託送料金相当額
   */
  public String getConsignmentChargeEquivalent() {
    return this.consignmentChargeEquivalent;
  }

  /**
   * 備考を設定する。
   *
   * @param note
   *          備考
   */
  public void setNote(String note) {
    this.note = note;
  }

  /**
   * 備考を取得する。
   *
   * @return 備考
   */
  public String getNote() {
    return this.note;
  }

  /**
   * 契約容量単位を設定する。
   *
   * @param ccaUnit
   *          契約容量単位
   */
  public void setCcaUnit(String ccaUnit) {
    this.ccaUnit = ccaUnit;
  }

  /**
   * 契約容量単位を取得する。
   *
   * @return 契約容量単位
   */
  public String getCcaUnit() {
    return this.ccaUnit;
  }

  /**
   * 託送契約容量単位を設定する。
   *
   * @param consignmentCcaUnit
   *          託送契約容量単位
   */
  public void setConsignmentCcaUnit(String consignmentCcaUnit) {
    this.consignmentCcaUnit = consignmentCcaUnit;
  }

  /**
   * 託送契約容量単位を取得する。
   *
   * @return 託送契約容量単位
   */
  public String getConsignmentCcaUnit() {
    return this.consignmentCcaUnit;
  }

  /**
   * 託送契約容量判定日を設定する。
   *
   * @param consignmentCcaDecisionDate
   *          託送契約容量判定日
   */
  public void setConsignmentCcaDecisionDate(String consignmentCcaDecisionDate) {
    this.consignmentCcaDecisionDate = consignmentCcaDecisionDate;
  }

  /**
   * 託送契約容量判定日を取得する。
   *
   * @return 託送契約容量判定日
   */
  public String getConsignmentCcaDecisionDate() {
    return this.consignmentCcaDecisionDate;
  }

  /**
   * 営業委託先コードを設定する。
   *
   * @param scCode
   *          営業委託先コード
   */
  public void setScCode(String scCode) {
    this.scCode = scCode;
  }

  /**
   * 営業委託先コードを取得する。
   *
   * @return 営業委託先コード
   */
  public String getScCode() {
    return this.scCode;
  }

  /**
   * 業種コードを設定する。
   *
   * @param businessTypeCode
   *          業種コード
   */
  public void setBusinessTypeCode(String businessTypeCode) {
    this.businessTypeCode = businessTypeCode;
  }

  /**
   * 業種コードを取得する。
   *
   * @return 業種コード
   */
  public String getBusinessTypeCode() {
    return this.businessTypeCode;
  }

  /**
   * 使用量を設定する。
   *
   * @param usageQuantity
   *          使用量
   */
  public void setUsageQuantity(String usageQuantity) {
    this.usageQuantity = usageQuantity;
  }

  /**
   * 使用量を取得する。
   *
   * @return 使用量
   */
  public String getUsageQuantity() {
    return this.usageQuantity;
  }

  /**
   * 最大需要電力（参考）を設定する。
   *
   * @param pdReference
   *          最大需要電力（参考）
   */
  public void setPdReference(String pdReference) {
    this.pdReference = pdReference;
  }

  /**
   * 最大需要電力（参考）を取得する。
   *
   * @return 最大需要電力（参考）
   */
  public String getPdReference() {
    return this.pdReference;
  }

  /**
   * 使用開始日を設定する。
   *
   * @param usageSd
   *          使用開始日
   */
  public void setUsageSd(String usageSd) {
    this.usageSd = usageSd;
  }

  /**
   * 使用開始日を取得する。
   *
   * @return 使用開始日
   */
  public String getUsageSd() {
    return this.usageSd;
  }

  /**
   * 使用終了日を設定する。
   *
   * @param usageEd
   *          使用終了日
   */
  public void setUsageEd(String usageEd) {
    this.usageEd = usageEd;
  }

  /**
   * 使用終了日を取得する。
   *
   * @return 使用終了日
   */
  public String getUsageEd() {
    return this.usageEd;
  }

  /**
   * 料金算定日数を設定する。
   *
   * @param ccDays
   *          料金算定日数
   */
  public void setCcDays(String ccDays) {
    this.ccDays = ccDays;
  }

  /**
   * 料金算定日数を取得する。
   *
   * @return 料金算定日数
   */
  public String getCcDays() {
    return this.ccDays;
  }

  /**
   * 確定使用量作成日を設定する。
   *
   * @param fuCreateDate
   *          確定使用量作成日
   */
  public void setFuCreateDate(String fuCreateDate) {
    this.fuCreateDate = fuCreateDate;
  }

  /**
   * 確定使用量作成日を取得する。
   *
   * @return 確定使用量作成日
   */
  public String getFuCreateDate() {
    return this.fuCreateDate;
  }

  /**
   * 力率を設定する。
   *
   * @param powerFactor
   *          力率
   */
  public void setPowerFactor(String powerFactor) {
    this.powerFactor = powerFactor;
  }

  /**
   * 力率を取得する。
   *
   * @return 力率
   */
  public String getPowerFactor() {
    return this.powerFactor;
  }

  /**
   * 計器区分コードを設定する。
   *
   * @param meterCatCode
   *          計器区分コード
   */
  public void setMeterCatCode(String meterCatCode) {
    this.meterCatCode = meterCatCode;
  }

  /**
   * 計器区分コードを取得する。
   *
   * @return 計器区分コード
   */
  public String getMeterCatCode() {
    return this.meterCatCode;
  }

  /**
   * 全日電力量当月指示数を設定する。
   *
   * @param currentIn
   *          全日電力量当月指示数
   */
  public void setCurrentIn(String currentIn) {
    this.currentIn = currentIn;
  }

  /**
   * 全日電力量当月指示数を取得する。
   *
   * @return 全日電力量当月指示数
   */
  public String getCurrentIn() {
    return this.currentIn;
  }

  /**
   * 全日電力量前月指示数を設定する。
   *
   * @param previousIn
   *          全日電力量前月指示数
   */
  public void setPreviousIn(String previousIn) {
    this.previousIn = previousIn;
  }

  /**
   * 全日電力量前月指示数を取得する。
   *
   * @return 全日電力量前月指示数
   */
  public String getPreviousIn() {
    return this.previousIn;
  }

  /**
   * 全日電力量指示数差(差引)を設定する。
   *
   * @param inDifference
   *          全日電力量指示数差(差引)
   */
  public void setInDifference(String inDifference) {
    this.inDifference = inDifference;
  }

  /**
   * 全日電力量指示数差(差引)を取得する。
   *
   * @return 全日電力量指示数差(差引)
   */
  public String getInDifference() {
    return this.inDifference;
  }

  /**
   * 乗率を設定する。
   *
   * @param multiplyingFactor
   *          乗率
   */
  public void setMultiplyingFactor(String multiplyingFactor) {
    this.multiplyingFactor = multiplyingFactor;
  }

  /**
   * 乗率を取得する。
   *
   * @return 乗率
   */
  public String getMultiplyingFactor() {
    return this.multiplyingFactor;
  }

  /**
   * 全日電力量指示数算出使用量を設定する。
   *
   * @param inCalculationUsage
   *          全日電力量指示数算出使用量
   */
  public void setInCalculationUsage(String inCalculationUsage) {
    this.inCalculationUsage = inCalculationUsage;
  }

  /**
   * 全日電力量指示数算出使用量を取得する。
   *
   * @return 全日電力量指示数算出使用量
   */
  public String getInCalculationUsage() {
    return this.inCalculationUsage;
  }

  /**
   * 力測有効電力量当月指示数を設定する。
   *
   * @param effectiveCurrentIndicationNo
   *          力測有効電力量当月指示数
   */
  public void setEffectiveCurrentIndicationNo(String effectiveCurrentIndicationNo) {
    this.effectiveCurrentIndicationNo = effectiveCurrentIndicationNo;
  }

  /**
   * 力測有効電力量当月指示数を取得する。
   *
   * @return 力測有効電力量当月指示数
   */
  public String getEffectiveCurrentIndicationNo() {
    return this.effectiveCurrentIndicationNo;
  }

  /**
   * 力測有効電力量前月指示数を設定する。
   *
   * @param effectiveCurrentIndicationNo
   *          力測有効電力量前月指示数
   */
  public void setEffectivePreviousIndicationNo(String effectivePreviousIndicationNo) {
    this.effectivePreviousIndicationNo = effectivePreviousIndicationNo;
  }

  /**
   * 力測有効電力量前月指示数を取得する。
   *
   * @return 力測有効電力量前月指示数
   */
  public String getEffectivePreviousIndicationNo() {
    return this.effectivePreviousIndicationNo;
  }

  /**
   * 力測有効電力量指示数差（差引）を設定する。
   *
   * @param effectiveCurrentIndicationNo
   *          力測有効電力量指示数差（差引）
   */
  public void setEffectiveIndicationNoDifference(String effectiveIndicationNoDifference) {
    this.effectiveIndicationNoDifference = effectiveIndicationNoDifference;
  }

  /**
   * 力測有効電力量指示数差（差引）を取得する。
   *
   * @return 力測有効電力量指示数差（差引）
   */
  public String getEffectiveIndicationNoDifference() {
    return this.effectiveIndicationNoDifference;
  }

  /**
   * 力測有効電力量指示数算出使用量を設定する。
   *
   * @param effectiveCurrentIndicationNo
   *          力測有効電力量指示数算出使用量
   */
  public void setEffectiveIndicationNoCalculationUsage(String effectiveIndicationNoCalculationUsage) {
    this.effectiveIndicationNoCalculationUsage = effectiveIndicationNoCalculationUsage;
  }

  /**
   * 力測有効電力量指示数算出使用量を取得する。
   *
   * @return 力測有効電力量指示数算出使用量
   */
  public String getEffectiveIndicationNoCalculationUsage() {
    return this.effectiveIndicationNoCalculationUsage;
  }

  /**
   * 力測無効電力量当月指示数を設定する。
   *
   * @param effectiveCurrentIndicationNo
   *          力測無効電力量当月指示数
   */
  public void setReactiveCurrentIndicationNo(String reactiveCurrentIndicationNo) {
    this.reactiveCurrentIndicationNo = reactiveCurrentIndicationNo;
  }

  /**
   * 力測無効電力量当月指示数を取得する。
   *
   * @return 力測無効電力量当月指示数
   */
  public String getReactiveCurrentIndicationNo() {
    return this.reactiveCurrentIndicationNo;
  }

  /**
   * 力測無効電力量前月指示数を設定する。
   *
   * @param effectiveCurrentIndicationNo
   *          力測無効電力量前月指示数
   */
  public void setReactivePreviousIndicationNo(String reactivePreviousIndicationNo) {
    this.reactivePreviousIndicationNo = reactivePreviousIndicationNo;
  }

  /**
   * 力測無効電力量前月指示数を取得する。
   *
   * @return 力測無効電力量前月指示数
   */
  public String getReactivePreviousIndicationNo() {
    return this.reactivePreviousIndicationNo;
  }

  /**
   * 力測無効電力量指示数差（差引）を設定する。
   *
   * @param effectiveCurrentIndicationNo
   *          力測無効電力量指示数差（差引）
   */
  public void setReactiveIndicationNoDifference(String reactiveIndicationNoDifference) {
    this.reactiveIndicationNoDifference = reactiveIndicationNoDifference;
  }

  /**
   * 力測無効電力量指示数差（差引）を取得する。
   *
   * @return 力測無効電力量指示数差（差引）
   */
  public String getReactiveIndicationNoDifference() {
    return this.reactiveIndicationNoDifference;
  }

  /**
   * 力測無効電力量指示数算出使用量を設定する。
   *
   * @param effectiveCurrentIndicationNo
   *          力測無効電力量指示数算出使用量
   */
  public void setReactiveIndicationNoCalculationUsage(String reactiveIndicationNoCalculationUsage) {
    this.reactiveIndicationNoCalculationUsage = reactiveIndicationNoCalculationUsage;
  }

  /**
   * 力測無効電力量指示数算出使用量を取得する。
   *
   * @return 力測無効電力量指示数算出使用量
   */
  public String getReactiveIndicationNoCalculationUsage() {
    return this.reactiveIndicationNoCalculationUsage;
  }

  /**
   * 損失補正率を設定する。
   *
   * @param effectiveCurrentIndicationNo
   *          損失補正率
   */
  public void setKwhDisadvantageFactor(String kwhDisadvantageFactor) {
    this.kwhDisadvantageFactor = kwhDisadvantageFactor;
  }

  /**
   * 損失補正率を取得する。
   *
   * @return 損失補正率
   */
  public String getKwhDisadvantageFactor() {
    return this.kwhDisadvantageFactor;
  }

  /**
   * 計器交換フラグを設定する。
   *
   * @param meterReplacementFlag
   *          計器交換フラグ
   */
  public void setMeterReplacementFlag(String meterReplacementFlag) {
    this.meterReplacementFlag = meterReplacementFlag;
  }

  /**
   * 計器交換フラグを取得する。
   *
   * @return 計器交換フラグ
   */
  public String getMeterReplacementFlag() {
    return this.meterReplacementFlag;
  }

  /**
   * 計器識別番号を設定する。
   *
   * @param meterIdn
   *          計器識別番号
   */
  public void setMeterIdn(String meterIdn) {
    this.meterIdn = meterIdn;
  }

  /**
   * 計器識別番号を取得する。
   *
   * @return 計器識別番号
   */
  public String getMeterIdn() {
    return this.meterIdn;
  }

  /**
   * 実量歴対象年月を設定する。
   *
   * @param coveredPeriod
   *          実量歴対象年月
   */
  public void setCoveredPeriod(String coveredPeriod) {
    this.coveredPeriod = coveredPeriod;
  }

  /**
   * 実量歴対象年月を取得する。
   *
   * @return 実量歴対象年月
   */
  public String getCoveredPeriod() {
    return this.coveredPeriod;
  }

  /**
   * 最大電力を設定する。
   *
   * @param peakKw
   *          最大電力
   */
  public void setPeakKw(String peakKw) {
    this.peakKw = peakKw;
  }

  /**
   * 最大電力を取得する。
   *
   * @return 最大電力
   */
  public String getPeakKw() {
    return this.peakKw;
  }

  /**
   * 日割１容量を設定する。
   *
   * @param contractCapacity1
   *          日割１容量
   */
  public void setContractCapacity1(String contractCapacity1) {
    this.contractCapacity1 = contractCapacity1;
  }

  /**
   * 日割１容量を取得する。
   *
   * @return 日割１容量
   */
  public String getContractCapacity1() {
    return this.contractCapacity1;
  }

  /**
   * 日割１使用量を設定する。
   *
   * @param usageQuantity1
   *          日割１使用量
   */
  public void setUsageQuantity1(String usageQuantity1) {
    this.usageQuantity1 = usageQuantity1;
  }

  /**
   * 日割１使用量を取得する。
   *
   * @return 日割１使用量
   */
  public String getUsageQuantity1() {
    return this.usageQuantity1;
  }

  /**
   * 日割２容量を設定する。
   *
   * @param contractCapacity2
   *          日割２容量
   */
  public void setContractCapacity2(String contractCapacity2) {
    this.contractCapacity2 = contractCapacity2;
  }

  /**
   * 日割２容量を取得する。
   *
   * @return 日割２容量
   */
  public String getContractCapacity2() {
    return this.contractCapacity2;
  }

  /**
   * 日割２使用量を設定する。
   *
   * @param usageQuantity2
   *          日割２使用量
   */
  public void setUsageQuantity2(String usageQuantity2) {
    this.usageQuantity2 = usageQuantity2;
  }

  /**
   * 日割２使用量を取得する。
   *
   * @return 日割２使用量
   */
  public String getUsageQuantity2() {
    return this.usageQuantity2;
  }

  /**
   * 日割３容量を設定する。
   *
   * @param contractCapacity3
   *          日割３容量
   */
  public void setContractCapacity3(String contractCapacity3) {
    this.contractCapacity3 = contractCapacity3;
  }

  /**
   * 日割３容量を取得する。
   *
   * @return 日割３容量
   */
  public String getContractCapacity3() {
    return this.contractCapacity3;
  }

  /**
   * 日割３使用量を設定する。
   *
   * @param usageQuantity3
   *          日割３使用量
   */
  public void setUsageQuantity3(String usageQuantity3) {
    this.usageQuantity3 = usageQuantity3;
  }

  /**
   * 日割３使用量を取得する。
   *
   * @return 日割３使用量
   */
  public String getUsageQuantity3() {
    return this.usageQuantity3;
  }

  /**
   * 料金メニュー名称を設定する。
   *
   * @param rmName
   *          料金メニュー名称
   */
  public void setRmName(String rmName) {
    this.rmName = rmName;
  }

  /**
   * 料金メニュー名称を取得する。
   *
   * @return 料金メニュー名称
   */
  public String getRmName() {
    return this.rmName;
  }

  /**
   * エリア名称を設定する。
   *
   * @param areaName
   *          エリア名称
   */
  public void setAreaName(String areaName) {
    this.areaName = areaName;
  }

  /**
   * エリア名称を取得する。
   *
   * @return エリア名称
   */
  public String getAreaName() {
    return this.areaName;
  }

  /**
   * 夏季使用量を設定する。
   *
   * @param summerSeasonUsage
   *          夏季使用量
   */
  public void setSummerSeasonUsage(String summerSeasonUsage) {
    this.summerSeasonUsage = summerSeasonUsage;
  }

  /**
   * 夏季使用量を取得する。
   *
   * @return 夏季使用量
   */
  public String getSummerSeasonUsage() {
    return this.summerSeasonUsage;
  }

  /**
   * 他季使用量を設定する。
   *
   * @param otherSeasonUsage
   *          他季使用量
   */
  public void setOtherSeasonUsage(String otherSeasonUsage) {
    this.otherSeasonUsage = otherSeasonUsage;
  }

  /**
   * 他季使用量を取得する。
   *
   * @return 他季使用量
   */
  public String getOtherSeasonUsage() {
    return this.otherSeasonUsage;
  }

  /**
   * 提供モデル企業名を設定する。
   *
   * @param pmCompanyName
   *          提供モデル企業名
   */
  public void setPmCompanyName(String pmCompanyName) {
    this.pmCompanyName = pmCompanyName;
  }

  /**
   * 提供モデル企業名を取得する。
   *
   * @return 提供モデル企業名
   */
  public String getPmCompanyName() {
    return this.pmCompanyName;
  }
}