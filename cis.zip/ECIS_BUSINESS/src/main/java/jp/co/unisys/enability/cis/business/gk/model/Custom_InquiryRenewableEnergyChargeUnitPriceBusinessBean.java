package jp.co.unisys.enability.cis.business.gk.model;

import java.util.List;
import java.util.Map;

import jp.co.unisys.enability.cis.entity.common.RecUpM;

/**
 * 再エネ単価情報照会BusinessBean_カスタム
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * 再エネ単価情報ビジネス_カスタム
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 *
 *         変更履歴(kg-epj) 2016.02.04 ko 新規作成
 */
public class Custom_InquiryRenewableEnergyChargeUnitPriceBusinessBean {

  /**
   * エリアコードを保有する。
   */
  private String areaCode;

  /**
   * 取得対象年月リストを保有する。
   */
  private List<String> targetPeriodList;

  /**
   * 年月単価情報マップを保有する。
   */
  private Map<String, Map<String, RecUpM>> periodUpMap;

  /**
   * リターンコードを保有する。
   */
  private String returnCode;

  /**
   * メッセージを保有する。
   */
  private String message;

  /**
   * エリアコードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * エリアコードを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return エリアコード
   */
  public String getAreaCode() {
    return this.areaCode;
  }

  /**
   * エリアコードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * エリアコードを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param areaCode
   *          エリアコード
   */
  public void setAreaCode(String areaCode) {
    this.areaCode = areaCode;
  }

  /**
   * 取得対象年月リストのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 取得対象年月リストを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 取得対象年月リスト
   */
  public List<String> getTargetPeriodList() {
    return this.targetPeriodList;
  }

  /**
   * 取得対象年月リストのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 取得対象年月リストを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param targetPeriodList
   *          取得対象年月リスト
   */
  public void setTargetPeriodList(List<String> targetPeriodList) {
    this.targetPeriodList = targetPeriodList;
  }

  /**
   * 年月単価情報マップのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 年月単価情報マップを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 年月単価情報マップ
   */
  public Map<String, Map<String, RecUpM>> getPeriodUpMap() {
    return this.periodUpMap;
  }

  /**
   * 年月単価情報マップのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 年月単価情報マップを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param periodUpMap
   *          年月単価情報マップ
   */
  public void setPeriodUpMap(Map<String, Map<String, RecUpM>> periodUpMap) {
    this.periodUpMap = periodUpMap;
  }

  /**
   * リターンコードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return リターンコード
   */
  public String getReturnCode() {
    return this.returnCode;
  }

  /**
   * リターンコードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param returnCode
   *          リターンコード
   */
  public void setReturnCode(String returnCode) {
    this.returnCode = returnCode;
  }

  /**
   * メッセージのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return メッセージ
   */
  public String getMessage() {
    return this.message;
  }

  /**
   * メッセージのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param message
   *          メッセージ
   */
  public void setMessage(String message) {
    this.message = message;
  }
}
