package jp.co.unisys.enability.cis.business.rk;

import jp.co.unisys.enability.cis.business.rk.model.RK_UsageLinkageCheckCheckDataBusinessBean;
import jp.co.unisys.enability.cis.business.rk.model.RK_UsageLinkageCheckContractBusinessBean;
import jp.co.unisys.enability.cis.business.rk.model.RK_UsageLinkageCheckTermDecisionBusinessBean;
import jp.co.unisys.enability.cis.common.util.StringConvertUtil;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;

/**
 * 次回検針予定日異常チェックビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.rk.RK_UsageLinkageCheckBusiness
 */
public class RK_CheckInvalidMeterReadingScheduledDateBusinessImpl implements
    RK_CheckFixUsageBusiness {

  /** 料金計算チェックビジネス(DI) */
  private RK_UsageLinkageCheckBusiness rkUsageLinkageCheckBusiness;

  /**
   * 次回検針予定日異常チェック。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約終了していない期間の確定使用量メッセージで、次回検針予定日が未設定でないか判定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param checkDataBusinessBean
   *          チェック対象ビジネスBean
   * @param termDecisionBusinessBean
   *          期間判定情報ビジネスBean
   * @return true:処理継続、false:処理終了
   */
  @Override
  public boolean check(
      RK_UsageLinkageCheckCheckDataBusinessBean checkDataBusinessBean,
      RK_UsageLinkageCheckTermDecisionBusinessBean termDecisionBusinessBean) {

    // 継続フラグ
    boolean continuation = true;

    // 対象期間内で最後の契約を取得
    RK_UsageLinkageCheckContractBusinessBean contract = termDecisionBusinessBean
        .getContractList().get(
            termDecisionBusinessBean.getContractList().size() - 1);

    // 次回検針予定日が未設定かつ、契約終了理由が未設定の場合、TODOを登録し、
    // 【月次実績】.月次実績エラー区分コードを"エラー"で更新する
    if (checkDataBusinessBean.getNextMeterReadingScheduledDate() == null
        && contract.getContractEndReasonCode() == null) {

      // TODOメッセージを作成するパラメータ
      String[] params = {
          // 確定使用量ファイル名
          checkDataBusinessBean.getFixUsageFileName(),
          // 地点特定番号
          checkDataBusinessBean.getSpotNo(),
          // エリアコード
          checkDataBusinessBean.getAreaCode(),
          // 処理日
          StringConvertUtil.convertDateToString(
              checkDataBusinessBean.getExecuteDate(), ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH),
          // 契約番号
          contract.getContractNo() };

      // TODO登録
      rkUsageLinkageCheckBusiness.registerTodo("todo.T1027", params, null, null, contract.getContractNo(),
          checkDataBusinessBean.getSpotNo(), null);

      // 月次実績エラー区分コードをエラーで更新
      rkUsageLinkageCheckBusiness
          .updateMonthlyUsageResultError(checkDataBusinessBean);

      // 処理を継続しない
      continuation = false;
    }

    return continuation;
  }

  /**
   * 料金計算チェックビジネスを設定します。(DI)
   *
   * @param rkUsageLinkageCheckBusiness
   *          料金計算チェックビジネス
   */
  public void setRkUsageLinkageCheckBusiness(
      RK_UsageLinkageCheckBusiness rkUsageLinkageCheckBusiness) {
    this.rkUsageLinkageCheckBusiness = rkUsageLinkageCheckBusiness;
  }

}
