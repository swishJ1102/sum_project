package jp.co.unisys.enability.cis.business.rk;

import jp.co.unisys.enability.cis.business.rk.model.RK_ChargeCalcWarningCheckBusinessBean;
import jp.co.unisys.enability.cis.common.util.constants.ECISCodeConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISKJConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;
import jp.co.unisys.enability.cis.entity.common.Contract;
import jp.co.unisys.enability.cis.entity.common.ContractHist;
import jp.co.unisys.enability.cis.entity.common.ContractHistExample;
import jp.co.unisys.enability.cis.mapper.common.ContractHistMapper;
import jp.co.unisys.enability.cis.mapper.common.ContractMapper;

/**
 * BRK0103-03実量歴取込済フラグチェックビジネス
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.common.DateBusiness
 * @see jp.co.unisys.enability.cis.dao.rk.RK_ChargeCalcWarningCheckDao
 */
public class RK_RealQuantityImportCompleteFlagCheckBusinessImpl implements
    RK_ChargeCalcWarningCheckBusiness {
  /**
   * 契約Mapper（DI）
   */
  private ContractMapper contractMapper;

  /**
   * 契約履歴Mapper（DI）
   */
  private ContractHistMapper contractHistMapper;

  /**
   * 実量歴取込済フラグチェックビジネス
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param chargeCalcWarningCheckBean
   *          《料金計算警告チェックビジネスBean》
   * @return 警告コード
   * @see jp.co.unisys.enability.cis.business.common.DateBusiness
   * @see jp.co.unisys.enability.cis.dao.rk.RK_ChargeCalcWarningCheckDao
   */
  @Override
  public String check(
      RK_ChargeCalcWarningCheckBusinessBean chargeCalcWarningCheckBean) {

    // 契約EntityBeanを取得する。
    // 変数.契約EntityBean
    // 契約Mapper.selectByPrimaryKeyを呼び出し、契約を取得する
    Contract contract = contractMapper.selectByPrimaryKey(chargeCalcWarningCheckBean
        .getContractId());

    // 契約履歴EntityBeanを取得する
    // 契約履歴Example
    ContractHistExample contractHistExample = new ContractHistExample();

    // 【契約履歴】を取得する条件を設定
    contractHistExample
        .createCriteria()
        // 契約ID
        .andContractIdEqualTo(
            chargeCalcWarningCheckBean.getContractId())
        // 適用開始日
        .andApplySdLessThanOrEqualTo(
            chargeCalcWarningCheckBean
                .getChargeCalculationStartDate())
        // 適用終了日
        .andApplyEdGreaterThanOrEqualTo(
            chargeCalcWarningCheckBean
                .getChargeCalculationStartDate());

    // 【契約履歴】取得
    ContractHist contractHis = contractHistMapper.selectByExample(
        contractHistExample).get(0);
    /**
     * チェックの判断を行う。
     */
    //変数.契約履歴EntityBean.契約電力決定区分が実量制
    if (ECISKJConstants.CC_DECISION_CATEGORY_REAL_QUANTITY
        .equals(contractHis.getCcDecisionCategoryCode())
        //変数.契約EntityBean.実量歴必須フラグがON
        && ECISCodeConstants.ACTUAL_RECORD_REQUIRED_FLAG_ON
            .equals(contract.getRealQuantityNeedFlag())
        //変数.契約EntityBean.実量歴取込済フラグがOFF
        && ECISCodeConstants.REAL_QUANTITY_IMPORT_COMPLETE_FLAG_OFF
            .equals(contract.getRealQuantityImportCompleteFlag())) {
      //戻り値に308 を設定する
      return ECISRKConstants.WARNING_CLASS_MASTER_REAL_QUANTITY_IMPORT_COMPLETE;
    }
    // 戻り値にnull を設定する。
    return null;
  }

  /**
   * 契約種別マスタMapperのsetter（DI）
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約種別マスタMapperを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param cclMMaper
   *          契約種別マスタMapper
   */
  public void setContractMapper(ContractMapper contractMapper) {
    this.contractMapper = contractMapper;
  }

  /**
   * 契約履歴マスタMapperのsetter（DI）
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約履歴マスタMapperを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param cclMMaper
   *          契約履歴マスタMapper
   */
  public void setContractHistMapper(ContractHistMapper contractHistMapper) {
    this.contractHistMapper = contractHistMapper;
  }

}
