package jp.co.unisys.enability.cis.business.sn.model;

/**
 * 料金実績一覧作成ビジネスBean. サービスに受け渡すBeanクラス名
 *
 * @author "Nihon Unisys, Ltd."
 */
public class SN0106_CreateChargeResultListBusinessBean {

  /** 卸／取次事業者向け料金実績一覧論理ファイル名 */
  private String forWsAgOpChargeResultListLogicalFileName;

  /** 卸／取次事業者向け料金実績一覧ファイルパス */
  private String forWsAgOpChargeResultListFilePath;

  /** 卸／取次事業者向け料金実績内訳論理ファイル名 */
  private String forWsAgOpChargeResultBreakdownLogicalFileName;

  /** 卸／取次事業者向け料金実績内訳ファイルパス */
  private String forWsAgOpChargeResultBreakdownFilePath;

  /** 卸／取次事業者向け料金実績一覧・内訳論理ファイル名 */
  private String forWsAgOpChargeResultListBreakdownLogicalFileName;

  /** 卸／取次事業者向け料金実績一覧・内訳ファイルパス */
  private String forWsAgOpChargeResultListBreakdownFilePath;

  /** 料金実績一覧出力件数 */
  private Integer chargeResultListOutputCount;

  /** 料金実績内訳出力件数 */
  private Integer chargeResultBreakdownOutputCount;

  /**
   * 卸／取次事業者向け料金実績一覧論理ファイル名を設定する。
   *
   * @param forWsAgOpChargeResultListLogicalFileName
   *          卸／取次事業者向け料金実績一覧論理ファイル名
   */
  public void setForWsAgOpChargeResultListLogicalFileName(String forWsAgOpChargeResultListLogicalFileName) {
    this.forWsAgOpChargeResultListLogicalFileName = forWsAgOpChargeResultListLogicalFileName;
  }

  /**
   * 卸／取次事業者向け料金実績一覧論理ファイル名を取得する。
   *
   * @return 卸／取次事業者向け料金実績一覧論理ファイル名
   */
  public String getForWsAgOpChargeResultListLogicalFileName() {
    return this.forWsAgOpChargeResultListLogicalFileName;
  }

  /**
   * 卸／取次事業者向け料金実績一覧ファイルパスを設定する。
   *
   * @param forWsAgOpChargeResultListFilePath
   *          卸／取次事業者向け料金実績一覧ファイルパス
   */
  public void setForWsAgOpChargeResultListFilePath(String forWsAgOpChargeResultListFilePath) {
    this.forWsAgOpChargeResultListFilePath = forWsAgOpChargeResultListFilePath;
  }

  /**
   * 卸／取次事業者向け料金実績一覧ファイルパスを取得する。
   *
   * @return 卸／取次事業者向け料金実績一覧ファイルパス
   */
  public String getForWsAgOpChargeResultListFilePath() {
    return this.forWsAgOpChargeResultListFilePath;
  }

  /**
   * 卸／取次事業者向け料金実績内訳論理ファイル名を設定する。
   *
   * @param forWsAgOpChargeResultBreakdownLogicalFileName
   *          卸／取次事業者向け料金実績内訳論理ファイル名
   */
  public void setForWsAgOpChargeResultBreakdownLogicalFileName(String forWsAgOpChargeResultBreakdownLogicalFileName) {
    this.forWsAgOpChargeResultBreakdownLogicalFileName = forWsAgOpChargeResultBreakdownLogicalFileName;
  }

  /**
   * 卸／取次事業者向け料金実績内訳論理ファイル名を取得する。
   *
   * @return 卸／取次事業者向け料金実績内訳論理ファイル名
   */
  public String getForWsAgOpChargeResultBreakdownLogicalFileName() {
    return this.forWsAgOpChargeResultBreakdownLogicalFileName;
  }

  /**
   * 卸／取次事業者向け料金実績内訳ファイルパスを設定する。
   *
   * @param forWsAgOpChargeResultBreakdownFilePath
   *          卸／取次事業者向け料金実績内訳ファイルパス
   */
  public void setForWsAgOpChargeResultBreakdownFilePath(String forWsAgOpChargeResultBreakdownFilePath) {
    this.forWsAgOpChargeResultBreakdownFilePath = forWsAgOpChargeResultBreakdownFilePath;
  }

  /**
   * 卸／取次事業者向け料金実績内訳ファイルパスを取得する。
   *
   * @return 卸／取次事業者向け料金実績内訳ファイルパス
   */
  public String getForWsAgOpChargeResultBreakdownFilePath() {
    return this.forWsAgOpChargeResultBreakdownFilePath;
  }

  /**
   * 卸／取次事業者向け料金実績一覧・内訳論理ファイル名を設定する。
   *
   * @param forWsAgOpChargeResultListBreakdownLogicalFileName
   *          卸／取次事業者向け料金実績一覧・内訳論理ファイル名
   */
  public void setForWsAgOpChargeResultListBreakdownLogicalFileName(
      String forWsAgOpChargeResultListBreakdownLogicalFileName) {
    this.forWsAgOpChargeResultListBreakdownLogicalFileName = forWsAgOpChargeResultListBreakdownLogicalFileName;
  }

  /**
   * 卸／取次事業者向け料金実績一覧・内訳論理ファイル名を取得する。
   *
   * @return 卸／取次事業者向け料金実績一覧・内訳論理ファイル名
   */
  public String getForWsAgOpChargeResultListBreakdownLogicalFileName() {
    return this.forWsAgOpChargeResultListBreakdownLogicalFileName;
  }

  /**
   * 卸／取次事業者向け料金実績一覧・内訳ファイルパスを設定する。
   *
   * @param forWsAgOpChargeResultListBreakdownFilePath
   *          卸／取次事業者向け料金実績一覧・内訳ファイルパス
   */
  public void setForWsAgOpChargeResultListBreakdownFilePath(String forWsAgOpChargeResultListBreakdownFilePath) {
    this.forWsAgOpChargeResultListBreakdownFilePath = forWsAgOpChargeResultListBreakdownFilePath;
  }

  /**
   * 卸／取次事業者向け料金実績一覧・内訳ファイルパスを取得する。
   *
   * @return 卸／取次事業者向け料金実績一覧・内訳ファイルパス
   */
  public String getForWsAgOpChargeResultListBreakdownFilePath() {
    return this.forWsAgOpChargeResultListBreakdownFilePath;
  }

  /**
   * 料金実績一覧出力件数を設定する。
   *
   * @param chargeResultListOutputCount
   *          料金実績一覧出力件数
   */
  public void setChargeResultListOutputCount(Integer chargeResultListOutputCount) {
    this.chargeResultListOutputCount = chargeResultListOutputCount;
  }

  /**
   * 料金実績一覧出力件数を取得する。
   *
   * @return 料金実績一覧出力件数
   */
  public Integer getChargeResultListOutputCount() {
    return this.chargeResultListOutputCount;
  }

  /**
   * 料金実績内訳出力件数を設定する。
   *
   * @param chargeResultBreakdownOutputCount
   *          料金実績内訳出力件数
   */
  public void setChargeResultBreakdownOutputCount(Integer chargeResultBreakdownOutputCount) {
    this.chargeResultBreakdownOutputCount = chargeResultBreakdownOutputCount;
  }

  /**
   * 料金実績内訳出力件数を取得する。
   *
   * @return 料金実績内訳出力件数
   */
  public Integer getChargeResultBreakdownOutputCount() {
    return this.chargeResultBreakdownOutputCount;
  }
}