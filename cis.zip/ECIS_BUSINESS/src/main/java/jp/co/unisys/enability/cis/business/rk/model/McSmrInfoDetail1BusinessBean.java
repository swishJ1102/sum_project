package jp.co.unisys.enability.cis.business.rk.model;

import java.util.List;

import jp.co.unisys.enability.cis.entity.common.McSmrDetail2;

/**
 * 計量器交換・臨時検針情報明細１を格納するビジネスBean
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * 計量器交換・臨時検針情報照会ビジネス
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class McSmrInfoDetail1BusinessBean {

  /**
   * 取替工事年月日を保有する。
   */
  private String meterChangeDate;

  /**
   * 計器区分コードを保有する。
   */
  private String meterCatCode;

  /**
   * 計器区分を保有する。
   */
  private String meterCat;

  /**
   * 最大電力を保有する。
   */
  private String pkw;

  /**
   * 全日電力量を保有する。
   */
  private String fullTimeUsage;

  /**
   * 力測有効電力量を保有する。
   */
  private String effectiveUsage;

  /**
   * 力測無効電力量を保有する。
   */
  private String reactiveUsage;

  /**
   * 明細2リストを保有する。
   */
  private List<McSmrDetail2> mcSmrInfoDetail2List;

  /**
   * 取替工事年月日のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 取替工事年月日を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 取替工事年月日
   */
  public String getMeterChangeDate() {
    return meterChangeDate;
  }

  /**
   * 取替工事年月日のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 取替工事年月日を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param meterChangeDate
   *          取替工事年月日
   */
  public void setMeterChangeDate(String meterChangeDate) {
    this.meterChangeDate = meterChangeDate;
  }

  /**
   * 計器区分コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計器区分コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 計器区分コード
   */
  public String getMeterCatCode() {
    return meterCatCode;
  }

  /**
   * 計器区分コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計器区分コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param meterCatCode
   *          計器区分コード
   */
  public void setMeterCatCode(String meterCatCode) {
    this.meterCatCode = meterCatCode;
  }

  /**
   * 計器区分のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計器区分を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 計器区分
   */
  public String getMeterCat() {
    return meterCat;
  }

  /**
   * 計器区分のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計器区分を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param meterCat
   *          計器区分
   */
  public void setMeterCat(String meterCat) {
    this.meterCat = meterCat;
  }

  /**
   * 最大電力のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 最大電力を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 最大電力
   */
  public String getPkw() {
    return pkw;
  }

  /**
   * 最大電力のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 最大電力を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param pkw
   *          最大電力
   */
  public void setPkw(String pkw) {
    this.pkw = pkw;
  }

  /**
   * 全日電力量のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 全日電力量を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 全日電力量
   */
  public String getFullTimeUsage() {
    return fullTimeUsage;
  }

  /**
   * 全日電力量のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 全日電力量を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param fullTimeUsage
   *          全日電力量
   */
  public void setFullTimeUsage(String fullTimeUsage) {
    this.fullTimeUsage = fullTimeUsage;
  }

  /**
   * 力測有効電力量のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 力測有効電力量を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 力測有効電力量
   */
  public String getEffectiveUsage() {
    return effectiveUsage;
  }

  /**
   * 力測有効電力量のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 力測有効電力量を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param effectiveUsage
   *          力測有効電力量
   */
  public void setEffectiveUsage(String effectiveUsage) {
    this.effectiveUsage = effectiveUsage;
  }

  /**
   * 力測無効電力量のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 力測無効電力量を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 力測無効電力量
   */
  public String getReactiveUsage() {
    return reactiveUsage;
  }

  /**
   * 力測無効電力量のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 力測無効電力量を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param reactiveUsage
   *          力測無効電力量
   */
  public void setReactiveUsage(String reactiveUsage) {
    this.reactiveUsage = reactiveUsage;
  }

  /**
   * 明細2リストのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 明細2リストを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 明細2リスト
   */
  public List<McSmrDetail2> getMcSmrInfoDetail2List() {
    return mcSmrInfoDetail2List;
  }

  /**
   * 明細2リストのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 明細2リストを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param mcSmrInfoDetail2List
   *          明細2リスト
   */
  public void setMcSmrInfoDetail2List(List<McSmrDetail2> mcSmrInfoDetail2List) {
    this.mcSmrInfoDetail2List = mcSmrInfoDetail2List;
  }
}
