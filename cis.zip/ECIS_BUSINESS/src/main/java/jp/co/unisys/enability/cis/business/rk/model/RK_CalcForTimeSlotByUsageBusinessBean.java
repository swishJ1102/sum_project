package jp.co.unisys.enability.cis.business.rk.model;

import java.math.BigDecimal;
import java.sql.Timestamp;

/**
 * 計算用時間帯別使用量ビジネスBean。
 *
 * <pre>
 * <p>
 * <b>【使用ビジネス】</b>
 * </p>
 * 計算用使用量登録ビジネス。
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_CalcForTimeSlotByUsageBusinessBean {

  /**
   * 契約ID
   */
  Integer contractId;

  /**
   * 利用年月
   */
  String usePeriod;

  /**
   * 時間帯コード
   */
  String timeSlotCode;

  /**
   * 時間帯名称
   */
  String timeSlotName;

  /**
   * 使用量
   */
  BigDecimal UsageQuantity;

  /**
   * 更新回数
   */
  Integer updateCount;

  /**
   * 作成日時
   */
  Timestamp createTime;

  /**
   * オンライン更新日時
   */
  Timestamp onlineUpdateTime;

  /**
   * オンライン更新ユーザID
   */
  String onlineUpdateUserId;

  /**
   * 更新日時
   */
  Timestamp updateTime;

  /**
   * 更新モジュールコード
   */
  String updateModuleCode;

  /**
   * 契約IDのgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約IDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約ID
   */
  public Integer getContractId() {
    return contractId;
  }

  /**
   * 契約IDのsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約IDを設定する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractId
   *          契約ID
   */
  public void setContractId(Integer contractId) {
    this.contractId = contractId;
  }

  /**
   * 利用年月のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 利用年月を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 利用年月
   */
  public String getUsePeriod() {
    return usePeriod;
  }

  /**
   * 利用年月のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 利用年月を設定する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param usePeriod
   *          利用年月
   */
  public void setUsePeriod(String usePeriod) {
    this.usePeriod = usePeriod;
  }

  /**
   * 時間帯コードのgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 時間帯コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 時間帯コード
   */
  public String getTimeSlotCode() {
    return timeSlotCode;
  }

  /**
   * 時間帯コードのsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 時間帯コードを設定する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param timeSlotCode
   *          時間帯コード
   */
  public void setTimeSlotCode(String timeSlotCode) {
    this.timeSlotCode = timeSlotCode;
  }

  /**
   * 時間帯名称のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 時間帯名称を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 時間帯名称
   */
  public String getTimeSlotName() {
    return timeSlotName;
  }

  /**
   * 時間帯名称のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 時間帯名称を設定する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param timeSlotName
   *          時間帯名称
   */
  public void setTimeSlotName(String timeSlotName) {
    this.timeSlotName = timeSlotName;
  }

  /**
   * 使用量のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 使用量を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 使用量
   */
  public BigDecimal getUsageQuantity() {
    return UsageQuantity;
  }

  /**
   * 使用量のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 使用量を設定する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param usageQuantity
   *          使用量
   */
  public void setUsageQuantity(BigDecimal usageQuantity) {
    UsageQuantity = usageQuantity;
  }

  /**
   * 更新回数のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 更新回数を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 更新回数
   */
  public Integer getUpdateCount() {
    return updateCount;
  }

  /**
   * 更新回数のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 更新回数を設定する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param updateCount
   *          更新回数
   */
  public void setUpdateCount(Integer updateCount) {
    this.updateCount = updateCount;
  }

  /**
   * 作成日時のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 作成日時を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 作成日時
   */
  public Timestamp getCreateTime() {
    return createTime;
  }

  /**
   * 作成日時のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 作成日時を設定する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param createTime
   *          作成日時
   */
  public void setCreateTime(Timestamp createTime) {
    this.createTime = createTime;
  }

  /**
   * オンライン更新日時のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * オンライン更新日時を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return オンライン更新日時
   */
  public Timestamp getOnlineUpdateTime() {
    return onlineUpdateTime;
  }

  /**
   * オンライン更新日時のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * オンライン更新日時を設定する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param onlineUpdateTime
   *          オンライン更新日時
   */
  public void setOnlineUpdateTime(Timestamp onlineUpdateTime) {
    this.onlineUpdateTime = onlineUpdateTime;
  }

  /**
   * オンライン更新ユーザIDのgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * オンライン更新ユーザIDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return オンライン更新ユーザID
   */
  public String getOnlineUpdateUserId() {
    return onlineUpdateUserId;
  }

  /**
   * オンライン更新ユーザIDのsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * オンライン更新ユーザIDを設定する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param onlineUpdateUserId
   *          オンライン更新ユーザID
   */
  public void setOnlineUpdateUserId(String onlineUpdateUserId) {
    this.onlineUpdateUserId = onlineUpdateUserId;
  }

  /**
   * 更新日時のgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 更新日時を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 更新日時
   */
  public Timestamp getUpdateTime() {
    return updateTime;
  }

  /**
   * 更新日時のsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 更新日時を設定する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param updateTime
   *          更新日時
   */
  public void setUpdateTime(Timestamp updateTime) {
    this.updateTime = updateTime;
  }

  /**
   * 更新モジュールコードのgetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 更新モジュールコードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 更新モジュールコード
   */
  public String getUpdateModuleCode() {
    return updateModuleCode;
  }

  /**
   * 更新モジュールコードのsetter。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 更新モジュールコードを設定する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param updateModuleCode
   *          更新モジュールコード
   */
  public void setUpdateModuleCode(String updateModuleCode) {
    this.updateModuleCode = updateModuleCode;
  }
}
