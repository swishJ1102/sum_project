package jp.co.unisys.enability.cis.business.kj;

import jp.co.unisys.enability.cis.business.kj.model.ForceUpdateContractBusinessBean;

/**
 * 契約情報更新ビジネスインターフェース。
 *
 * @author "Nihon Unisys, Ltd."
 *
 */
public interface KJ_UpdateContractBusiness {

  /**
   * 契約情報更新（強制）を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約情報を強制的に更新する。
   * 本更新はマッチング完了以降に更新されたオーダー情報のCIS連携※といった限定用途のみに留める想定。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param inquiryContractBusinessBean
   *          契約情報更新BusinessBean
   * @return 契約情報更新BusinessBean
   */
  public ForceUpdateContractBusinessBean update(ForceUpdateContractBusinessBean forceUpdateContractBusinessBean);

}
