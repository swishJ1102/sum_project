package jp.co.unisys.enability.cis.business.kj;

import jp.co.unisys.enability.cis.business.kj.model.DeleteReserveContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.InquiryReserveContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.RegistReserveContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.UpdateReserveContractBusinessBean;

/**
 * 予備契約情報ビジネスインターフェース
 *
 * @author "Nihon Unisys, Ltd."
 *
 */
public interface KJ_ReserveContractInformationBusiness {

  /**
   * 予備契約情報照会を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   *【契約】に紐付く【予備契約】の照会に利用される。
   * 指定された「契約ID」、「予備契約種別」、「照会対象日付」に該当する【予備契約】の情報を返却する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param InquiryReserveContractBusinessBean
   *          予備契約情報照会BusinessBean
   * @return 予備契約情報照会BusinessBean
   */
  public InquiryReserveContractBusinessBean inquiry(
      InquiryReserveContractBusinessBean inquiryReserveContractBusinessBean);

  /**
   * 予備契約情報登録を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約に予備契約情報を紐付ける際に利用される。
   * 指定された予備契約の情報を【予備契約】に登録する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param RegistReserveContractBusinessBean
   *          予備契約情報登録BusinessBean
   * @return 予備契約情報登録BusinessBean
   */
  public RegistReserveContractBusinessBean regist(
      RegistReserveContractBusinessBean registReserveContractBusinessBean);

  /**
   * 予備契約情報更新を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約に予備契約情報を紐付ける際に利用される。
   * 指定の契約に紐付く予備契約情報を更新する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param UpdateReserveContractBusinessBean
   *          予備契約情報更新BusinessBean
   * @return 予備契約情報更新BusinessBean
   */
  public UpdateReserveContractBusinessBean update(
      UpdateReserveContractBusinessBean updateReserveContractBusinessBean);

  /**
   * 予備契約情報削除を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 予備契約情報削除にて予備契約情報の削除時に利用される。
   * 指定の契約に紐付く予備契約情報を削除する。ただし、既に料金実績が確定している場合は、エラーとする。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param DeleteReserveContractBusinessBean
   *          予備契約情報削除BusinessBean
   * @return 予備契約情報削除BusinessBean
   */
  public DeleteReserveContractBusinessBean delete(
      DeleteReserveContractBusinessBean deleteReserveContractBusinessBean);
}
