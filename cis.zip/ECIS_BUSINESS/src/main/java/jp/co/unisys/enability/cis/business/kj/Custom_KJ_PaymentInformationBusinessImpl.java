package jp.co.unisys.enability.cis.business.kj;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.dao.DataAccessException;

import jp.co.unisys.enability.cis.business.kj.model.Custom_InquiryPaymentBusinessBean;
import jp.co.unisys.enability.cis.common.util.KJ_CommonUtil;
import jp.co.unisys.enability.cis.common.util.constants.ECISKJConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISReturnCodeConstants;
import jp.co.unisys.enability.cis.entity.kj.Custom_KJ_InquiryPaymentInformationEntityBean;
import jp.co.unisys.enability.cis.mapper.kj.Custom_PaymentInformationCommonMapper;

//[kg-epj]<d-start>
///**
// * 支払情報ビジネスクラス
// *
// * @author "Nihon Unisys, Ltd."
// * @see jp.co.unisys.enability.cis.business.kj.KJ_PaymentInformationBusiness
// *
// */
//public class KJ_PaymentInformationBusinessImpl implements
//		KJ_PaymentInformationBusiness {
//	/**
//	 * 支払番号生成用桁数
//	 */
//	private static final int CLEATE_PAYMENT_NO_LENGTH = 2;
//	/**
//	 * 支払番号最大
//	 */
//	private static final int MAX_PAYMENT_NO = 99;
//	/**
//	 * リスト先頭取得
//	 */
//	private static final int FIRST_INDEX = 0;
//	/**
//	 * リスト2つ目取得
//	 */
//	private static final int SECOND_INDEX = 1;
//	/**
//	 * updatecount設定値
//	 */
//	private static final int INT_CNT_ZERO = 0;
//
//	/**
//	 * 支払情報マッパー(DI)
//	 */
//	private PaymentMapper paymentMapper;
//	/**
//	 * 請求情報マッパー(DI)
//	 */
//	private BlMapper blMapper;
//	/**
//	 * 支払情報共通マッパー(DI)
//	 */
//	private PaymentInformationCommonMapper paymentInformationCommonMapper;
//	/**
//	 * 支払履歴情報マッパー(DI)
//	 */
//	private PaymentHistMapper paymentHistMapper;
//	/**
//	 * 口座クレカ情報マッパー(DI)
//	 */
//	private AcInformationMapper acInformationMapper;
//	/**
//	 * 支払方法マスタマッパー(DI)
//	 */
//	private PwMMapper pwMMapper;
//	/**
//	 * 個人・法人区分マスタマッパー(DI)
//	 */
//	private IlcMMapper ilcMMapper;
//	/**
//	 * 電話番号区分マッパー(DI)
//	 */
//	private PhoneNoCatMMapper phoneNoCatMMapper;
//
//	/**
//	 * 契約者情報照会ビジネス(DI)
//	 */
//	private KJ_ContractorInformationBusiness kjContractorInformationBusiness;
//	/**
//	 * 契約情報照会ビジネス(DI)
//	 */
//	private KJ_ContractInformationBusiness kjContractInformationBusiness;
//	/**
//	 * 日付関連共通ビジネス(DI)
//	 */
//	private DateBusiness dateBusiness;
//	/**
//	 * メッセージプロパティ(DI)
//	 */
//	private MessageSource messageSource;
//	/**
//	 * 契約管理情報ファイルヘッダーバリデーター(DI)
//	 */
//	private ContractManagementInformationFileHeaderValidator contractManagementInformationFileHeaderValidator;
//	/**
//	 * 支払情報ファイル登録バリデーター(DI)
//	 */
//	private PaymentInformationFileRegistValidator paymentInformationFileRegistValidator;
//	/**
//	 * 支払情報ファイル更新バリデーター(DI)
//	 */
//	private PaymentInformationFileUpdateValidator paymentInformationFileUpdateValidator;
//	/**
//	 * 支払情報ファイル削除バリデーター(DI)
//	 */
//	private PaymentInformationFileDeleteValidator paymentInformationFileDeleteValidator;
//[kg-epj]<d-end>
//[kg-epj]<i-start>
/**
 * 支払情報ビジネス_カスタムクラス
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.kj.KJ_PaymentInformationBusiness
 *
 *      変更履歴(kg-epj) 2016.02.16 liu 新規作成
 *
 */
public class Custom_KJ_PaymentInformationBusinessImpl implements
    Custom_KJ_PaymentInformationBusiness {

  /**
   * 支払情報共通マッパー_カスタム(DI)
   */
  private Custom_PaymentInformationCommonMapper customPaymentInformationCommonMapper;

  /**
   * メッセージプロパティ(DI)
   */
  private MessageSource messageSource;
  //[kg-epj]<i-end>

  /**
   * ログマネジャー
   */
  private static Logger logger = LogManager.getLogger();

  // [kg-epj]<d-start>
  //	/*
  //	 * (非 Javadoc)
  //	 *
  //	 * @see
  //	 * jp.co.unisys.enability.cis.business.kj.KJ_PaymentInformationBusiness#
  //	 * inquiry
  //	 * (jp.co.unisys.enability.cis.business.kj.model.InquiryPaymentBusinessBean)
  //	 */
  //	@Override
  //	public InquiryPaymentBusinessBean inquiry(
  //			InquiryPaymentBusinessBean inquiryPaymentBusinessBean) {
  //
  //		// 《支払情報共通Mapper》.支払情報取得のパラメーター
  //		Integer id = null;
  //		String no = null;
  //		Date date = null;
  //		String inquiryPattern = null;
  //
  //		String errMsg = null;
  //		try {
  //
  //			// システムエラーメッセージを取得
  //			errMsg = getPropertiesMesseage(ECISReturnCodeConstants.RETURN_CODE_G017);
  //
  //			// 照会パターンチェック
  //			// (《支払情報照会BusinessBean》.契約者IDがNULLではない
  //			// または、《支払情報照会BusinessBeann》.契約者番号がNULLまたは空文字のいずれでもなく、)
  //			// かつ《支払情報照会BusinessBean》.照会対象日付がNULLでない、
  //			// かつその他の《支払情報照会BusinessBean》の項目がNULLまたは空文字の場合
  //			if ((inquiryPaymentBusinessBean.getContractorId() != null || StringUtils
  //					.isNotEmpty(inquiryPaymentBusinessBean.getContractorNo()))
  //					&& inquiryPaymentBusinessBean.getInqCoveredDate() != null
  //					&& inquiryPaymentBusinessBean.getPaymentId() == null
  //					&& StringUtils.isEmpty(inquiryPaymentBusinessBean
  //							.getPaymentNo())) {
  //
  //				id = inquiryPaymentBusinessBean.getContractorId();
  //				no = inquiryPaymentBusinessBean.getContractorNo();
  //				date = inquiryPaymentBusinessBean.getInqCoveredDate();
  //				inquiryPattern = ECISKJConstants.INQUIRY_PATTERN_1;
  //			} else
  //			// (《支払情報照会BusinessBean》.支払IDがNULLではない
  //			// または、《支払情報照会BusinessBean》.支払番号がNULLまたは空文字のいずれでもなく、)
  //			// かつその他の《支払情報照会BusinessBean》の項目がNULLまたは空文字の場合
  //			if ((inquiryPaymentBusinessBean.getPaymentId() != null || StringUtils
  //					.isNotEmpty(inquiryPaymentBusinessBean.getPaymentNo()))
  //					&& inquiryPaymentBusinessBean.getContractorId() == null
  //					&& StringUtils.isEmpty(inquiryPaymentBusinessBean
  //							.getContractorNo())
  //					&& inquiryPaymentBusinessBean.getInqCoveredDate() == null) {
  //				id = inquiryPaymentBusinessBean.getPaymentId();
  //				no = inquiryPaymentBusinessBean.getPaymentNo();
  //				date = null;
  //				inquiryPattern = ECISKJConstants.INQUIRY_PATTERN_2;
  //			} else
  //			// (《支払情報照会BusinessBean》.支払IDがNULLではない
  //			// または、《支払情報照会BusinessBean》.支払番号がNULLまたは空文字のいずれでもなく、)
  //			// 《支払情報照会BusinessBean》.照会対象日付がNULLでない、
  //			// かつその他の《支払情報照会BusinessBean》の項目がNULLまたは空文字の場合
  //			if ((inquiryPaymentBusinessBean.getPaymentId() != null || StringUtils
  //					.isNotEmpty(inquiryPaymentBusinessBean.getPaymentNo()))
  //					&& inquiryPaymentBusinessBean.getInqCoveredDate() != null
  //					&& inquiryPaymentBusinessBean.getContractorId() == null
  //					&& StringUtils.isEmpty(inquiryPaymentBusinessBean
  //							.getContractorNo())) {
  //				id = inquiryPaymentBusinessBean.getPaymentId();
  //				no = inquiryPaymentBusinessBean.getPaymentNo();
  //				date = inquiryPaymentBusinessBean.getInqCoveredDate();
  //				inquiryPattern = ECISKJConstants.INQUIRY_PATTERN_3;
  //			} else {
  //				// 上記以外の場合、《支払情報照会BusinessBean》.リターンコード（P001）を設定し返却する。
  //				setMessageAndReturnCode(inquiryPaymentBusinessBean,
  //						ECISReturnCodeConstants.RETURN_CODE_P001);
  //				return inquiryPaymentBusinessBean;
  //			}
  //
  //			// 支払情報を取得する。
  //			Map<String, Object> exampleMap = new HashMap<>();
  //			exampleMap.put("id", id);
  //			exampleMap.put("no", no);
  //			exampleMap.put("date", date);
  //			exampleMap.put("inquiryPattern", inquiryPattern);
  //
  //			List<KJ_InquiryPaymentInformationEntityBean> kjInquirypaymentinformationentitybeanArray = paymentInformationCommonMapper
  //					.selectPayment(exampleMap);
  //
  //			inquiryPaymentBusinessBean
  //					.setPaymentInformationList(kjInquirypaymentinformationentitybeanArray);
  //
  //			inquiryPaymentBusinessBean
  //					.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);
  //			return inquiryPaymentBusinessBean;
  //
  //		} catch (DataAccessException e) {
  //			logger.error(messageSource.getMessage("error.E1129", null,
  //					Locale.getDefault()), e);
  //			// データアクセスでエラー
  //			inquiryPaymentBusinessBean
  //					.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
  //			inquiryPaymentBusinessBean.setMessage(errMsg);
  //			return inquiryPaymentBusinessBean;
  //		} catch (NoSuchMessageException e) {
  //			logger.error(messageSource.getMessage("error.E1129", null,
  //					Locale.getDefault()), e);
  //			// メッセージプロパティ不在
  //			inquiryPaymentBusinessBean
  //					.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
  //			inquiryPaymentBusinessBean
  //					.setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
  //			return inquiryPaymentBusinessBean;
  //		}
  //	}
  // [kg-epj]<d-end>
  // [kg-epj]<i-start>
  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.kj.KJ_PaymentInformationBusiness#
   * inquiry
   * (jp.co.unisys.enability.cis.business.kj.model.Custom_InquiryPaymentBusinessBean)
   */
  @Override
  public Custom_InquiryPaymentBusinessBean inquiry(
      Custom_InquiryPaymentBusinessBean customInquiryPaymentBusinessBean) {

    // 《支払情報共通_カスタムマッパー》.支払情報取得のパラメーター
    Integer id = null;
    String no = null;
    Date date = null;
    String inquiryPattern = null;

    String errMsg = null;
    try {

      // システムエラーメッセージを取得
      errMsg = getPropertiesMesseage(ECISReturnCodeConstants.RETURN_CODE_G017);

      // 照会パターンチェック
      // (《支払情報照会BusinessBean_カスタム》.契約者IDがNULLではない
      // または、《支払情報照会BusinessBean_カスタム》.契約者番号がNULLまたは空文字のいずれでもなく、)
      // かつ《支払情報照会BusinessBean_カスタム》.照会対象日付がNULLでない、
      // かつその他の《支払情報照会BusinessBean_カスタム》の項目がNULLまたは空文字の場合
      if ((customInquiryPaymentBusinessBean.getContractorId() != null || StringUtils
          .isNotEmpty(customInquiryPaymentBusinessBean.getContractorNo()))
          && customInquiryPaymentBusinessBean.getInqCoveredDate() != null
          && customInquiryPaymentBusinessBean.getPaymentId() == null
          && StringUtils.isEmpty(customInquiryPaymentBusinessBean
              .getPaymentNo())) {

        id = customInquiryPaymentBusinessBean.getContractorId();
        no = customInquiryPaymentBusinessBean.getContractorNo();
        date = customInquiryPaymentBusinessBean.getInqCoveredDate();
        inquiryPattern = ECISKJConstants.INQUIRY_PATTERN_1;
      } else
      // (《支払情報照会BusinessBean_カスタム》.支払IDがNULLではない
      // または、《支払情報照会BusinessBean_カスタム》.支払番号がNULLまたは空文字のいずれでもなく、)
      // かつその他の《支払情報照会BusinessBean_カスタム》の項目がNULLまたは空文字の場合
      if ((customInquiryPaymentBusinessBean.getPaymentId() != null || StringUtils
          .isNotEmpty(customInquiryPaymentBusinessBean.getPaymentNo()))
          && customInquiryPaymentBusinessBean.getContractorId() == null
          && StringUtils.isEmpty(customInquiryPaymentBusinessBean
              .getContractorNo())
          && customInquiryPaymentBusinessBean.getInqCoveredDate() == null) {
        id = customInquiryPaymentBusinessBean.getPaymentId();
        no = customInquiryPaymentBusinessBean.getPaymentNo();
        date = null;
        inquiryPattern = ECISKJConstants.INQUIRY_PATTERN_2;
      } else
      // (《支払情報照会BusinessBean_カスタム》.支払IDがNULLではない
      // または、《支払情報照会BusinessBean_カスタム》.支払番号がNULLまたは空文字のいずれでもなく、)
      // 《支払情報照会BusinessBean_カスタム》.照会対象日付がNULLでない、
      // かつその他の《支払情報照会BusinessBean_カスタム》の項目がNULLまたは空文字の場合
      if ((customInquiryPaymentBusinessBean.getPaymentId() != null || StringUtils
          .isNotEmpty(customInquiryPaymentBusinessBean.getPaymentNo()))
          && customInquiryPaymentBusinessBean.getInqCoveredDate() != null
          && customInquiryPaymentBusinessBean.getContractorId() == null
          && StringUtils.isEmpty(customInquiryPaymentBusinessBean
              .getContractorNo())) {
        id = customInquiryPaymentBusinessBean.getPaymentId();
        no = customInquiryPaymentBusinessBean.getPaymentNo();
        date = customInquiryPaymentBusinessBean.getInqCoveredDate();
        inquiryPattern = ECISKJConstants.INQUIRY_PATTERN_3;
      } else {
        // 上記以外の場合、《支払情報照会BusinessBean_カスタム》.リターンコード（P001）を設定し返却する。
        setMessageAndReturnCode(customInquiryPaymentBusinessBean,
            ECISReturnCodeConstants.RETURN_CODE_P001);
        return customInquiryPaymentBusinessBean;
      }

      // 支払情報を取得する。
      Map<String, Object> exampleMap = new HashMap<>();
      exampleMap.put("id", id);
      exampleMap.put("no", no);
      exampleMap.put("date", date);
      exampleMap.put("inquiryPattern", inquiryPattern);

      List<Custom_KJ_InquiryPaymentInformationEntityBean> customKjInquiryPaymentInformationEntityBeanArray = customPaymentInformationCommonMapper
          .selectPayment(exampleMap);

      customInquiryPaymentBusinessBean
          .setPaymentInformationList(customKjInquiryPaymentInformationEntityBeanArray);

      customInquiryPaymentBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);
      return customInquiryPaymentBusinessBean;

    } catch (DataAccessException e) {
      // [kg-epj]<d-start>
      //logger.error(messageSource.getMessage("error.E1129", null,
      //		Locale.getDefault()), e);
      // [kg-epj]<d-end>
      // [kg-epj]<i-start>
      logger.error(errMsg, e);
      // [kg-epj]<i-end>
      // データアクセスでエラー
      customInquiryPaymentBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      customInquiryPaymentBusinessBean.setMessage(errMsg);
      return customInquiryPaymentBusinessBean;
    } catch (NoSuchMessageException e) {
      // [kg-epj]<d-start>
      //logger.error(messageSource.getMessage("error.E1129", null,
      //		Locale.getDefault()), e);
      // [kg-epj]<d-end>
      // [kg-epj]<i-start>
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, e);
      // [kg-epj]<i-end>
      // メッセージプロパティ不在
      customInquiryPaymentBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      customInquiryPaymentBusinessBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
      return customInquiryPaymentBusinessBean;
    }
  }
  // [kg-epj]<i-end>

  // [kg-epj]<d-start>
  //	/*
  //	 * (非 Javadoc)
  //	 *
  //	 * @see
  //	 * jp.co.unisys.enability.cis.business.kj.KJ_PaymentInformationBusiness#
  //	 * regist
  //	 * (jp.co.unisys.enability.cis.business.kj.model.RegistPaymentBusinessBean)
  //	 */
  //	@Override
  //	public RegistPaymentBusinessBean regist(
  //			RegistPaymentBusinessBean registPaymentBusinessBean) {
  //
  //		String errMsg = null;
  //		String duplicateKeyExceptionMsg = null;
  //
  //		try {
  //
  //			// システムエラーメッセージを取得
  //			errMsg = getPropertiesMesseage(ECISReturnCodeConstants.RETURN_CODE_G017);
  //			duplicateKeyExceptionMsg = getPropertiesMesseage(ECISReturnCodeConstants.RETURN_CODE_D023);
  //
  //			// コード存在チェック
  //			String returnCode = checkMasterCode(
  //					registPaymentBusinessBean.getPaymentWayCode(),
  //					registPaymentBusinessBean
  //							.getIndividualLegalEntityCategoryCode(),
  //					registPaymentBusinessBean.getBillingPhoneCategoryCode());
  //			// エラーコードが返却された場合
  //			if (StringUtils.isNotEmpty(returnCode)) {
  //
  //				setMessageAndReturnCode(registPaymentBusinessBean, returnCode);
  //
  //				return registPaymentBusinessBean;
  //			}
  //
  //			// 親エンティティ存在チェック
  //			InquiryContractorBusinessBean inquiryContractorBusinessBean = new InquiryContractorBusinessBean();
  //			// 《契約者情報照会BusinessBean》の設定
  //			inquiryContractorBusinessBean
  //					.setContractorId(registPaymentBusinessBean
  //							.getContractorId());
  //			inquiryContractorBusinessBean
  //					.setContractorNo(registPaymentBusinessBean
  //							.getContractorNo());
  //			// 契約者情報照会（ビジネス）呼び出し
  //			inquiryContractorBusinessBean = kjContractorInformationBusiness
  //					.inquiry(inquiryContractorBusinessBean);
  //
  //			// 契約者情報照会（ビジネス）呼び出し判定
  //			if (!ECISReturnCodeConstants.RETURN_CODE_0000
  //					.equals(inquiryContractorBusinessBean.getReturnCode())) {
  //				throw new BusinessLogicException(
  //
  //						messageSource.getMessage("error.E1288", new String[] {},
  //								Locale.getDefault()));
  //			}
  //
  //			// 返却値が0件の場合
  //			if (inquiryContractorBusinessBean.getContractorInformationList()
  //					.isEmpty()) {
  //				setMessageAndReturnCode(registPaymentBusinessBean,
  //						ECISReturnCodeConstants.RETURN_CODE_D014);
  //				return registPaymentBusinessBean;
  //			}
  //
  //			// 契約者情報リストを取得する
  //			// ※検索条件が契約者IDもしくは契約者NO(PKとユニーク)のためリストは必ず1件になる。
  //			KJ_InquiryContractorInformationEntityBean inquiryContractorInformationEntityBean = inquiryContractorBusinessBean
  //					.getContractorInformationList().get(FIRST_INDEX);
  //			// 契約者利用不能チェック
  //			if (!checkUnavailableFlag(inquiryContractorInformationEntityBean
  //					.getUnavailableFlag())) {
  //				setMessageAndReturnCode(registPaymentBusinessBean,
  //						ECISReturnCodeConstants.RETURN_CODE_D013);
  //
  //				return registPaymentBusinessBean;
  //			}
  //
  //			// 契約者支払チェック
  //			if (!checkDMPaymentWay(
  //					inquiryContractorInformationEntityBean
  //							.getProvideModelCode(),
  //					registPaymentBusinessBean.getPaymentWayCode())) {
  //				setMessageAndReturnCode(registPaymentBusinessBean,
  //						ECISReturnCodeConstants.RETURN_CODE_G033);
  //
  //				return registPaymentBusinessBean;
  //			}
  //
  //			List<String> checkList = new ArrayList<>();
  //
  //			checkList.add(registPaymentBusinessBean
  //					.getDirectDebitCreditCardNextMonthBillingFlag());
  //			checkList.add(registPaymentBusinessBean.getPaymentWayCode());
  //			checkList.add(registPaymentBusinessBean
  //					.getIndividualLegalEntityCategoryCode());
  //			checkList.add(registPaymentBusinessBean.getBillingName1());
  //			checkList.add(registPaymentBusinessBean.getBillingName2());
  //			checkList.add(registPaymentBusinessBean.getPrefix());
  //			checkList.add(registPaymentBusinessBean
  //					.getBillingAddressPostalCode());
  //			checkList.add(registPaymentBusinessBean
  //					.getBillingAddressPrefectures());
  //			checkList.add(registPaymentBusinessBean
  //					.getBillingAddressMunicipality());
  //			checkList.add(registPaymentBusinessBean.getBillingAddressSection());
  //			checkList.add(registPaymentBusinessBean.getBillingAddressBlock());
  //			checkList.add(registPaymentBusinessBean
  //					.getBillingAddressBuildingName());
  //			checkList.add(registPaymentBusinessBean.getBillingAddressRoom());
  //			checkList.add(registPaymentBusinessBean.getBillingPhoneNo());
  //			checkList.add(registPaymentBusinessBean
  //					.getBillingPhoneCategoryCode());
  //			checkList.add(registPaymentBusinessBean.getBillingMailAddress1());
  //			checkList.add(registPaymentBusinessBean.getBillingMailAddress2());
  //
  //			// 支払方法チェック
  //			if (!checkPaymentMethod(checkList,
  //					inquiryContractorInformationEntityBean
  //							.getProvideModelCode(),
  //					registPaymentBusinessBean.getAccountCreditCardId())) {
  //				// 《支払情報登録BusinessBean》.リターンコードに（G011）を設定し処理を終了する。
  //				setMessageAndReturnCode(registPaymentBusinessBean,
  //						ECISReturnCodeConstants.RETURN_CODE_G011);
  //				return registPaymentBusinessBean;
  //			}
  //			AcInformation accountCreditInformation = new AcInformation();
  //
  //			// 《支払情報登録BusinessBean》.口座クレカIDがNULLでない場合
  //			if (registPaymentBusinessBean.getAccountCreditCardId() != null) {
  //
  //				// 口座クレカ情報存在チェック
  //				accountCreditInformation = acInformationMapper
  //						.selectByPrimaryKey(registPaymentBusinessBean
  //								.getAccountCreditCardId());
  //
  //				// 返却値が0件の場合、《支払情報登録BusinessBean》.リターンコードに（P012）を返却し処理を終了する。
  //				if (accountCreditInformation == null) {
  //					setMessageAndReturnCode(registPaymentBusinessBean,
  //							ECISReturnCodeConstants.RETURN_CODE_P012);
  //
  //					return registPaymentBusinessBean;
  //				}
  //
  //				// 口座クレカ区分チェック
  //				if (!accountCreditInformation.getAcCatCode().equals(
  //						registPaymentBusinessBean.getPaymentWayCode())) {
  //					setMessageAndReturnCode(registPaymentBusinessBean,
  //							ECISReturnCodeConstants.RETURN_CODE_P066);
  //					return registPaymentBusinessBean;
  //				}
  //
  //				// 口座クレカ利用不能チェック
  //				// 《口座クレカ情報Entity》.利用不能フラグが'1:利用不能'の場合、
  //				// リターンコードに（G042）を返却し処理を終了する。
  //				if (!checkUnavailableFlag(accountCreditInformation.getUnavailableFlag())) {
  //					setMessageAndReturnCode(registPaymentBusinessBean,
  //							ECISReturnCodeConstants.RETURN_CODE_G042);
  //					return registPaymentBusinessBean;
  //				}
  //			}
  //
  //			// 支払番号発番
  //			// 発番値取得
  //			Integer max = paymentInformationCommonMapper
  //					.selectMaxPaymentNo(inquiryContractorInformationEntityBean
  //							.getContractorId());
  //			// 返却値が“99”以上の場合
  //			if (max >= MAX_PAYMENT_NO) {
  //				setMessageAndReturnCode(registPaymentBusinessBean,
  //						ECISReturnCodeConstants.RETURN_CODE_G024);
  //				return registPaymentBusinessBean;
  //			}
  //
  //			// 支払番号生成
  //			max++;
  //
  //			String strMax = StringConvertUtil.fillZeroNumLeft(max,
  //					CLEATE_PAYMENT_NO_LENGTH);
  //
  //			// “P”＋（2）の文字列＋（1）の文字列
  //			StringBuilder paymentNo = new StringBuilder();
  //			paymentNo.append(ECISKJConstants.PAYMENT_NO_HEDDER);
  //			paymentNo.append(inquiryContractorInformationEntityBean
  //					.getContractorNo().substring(1));
  //			paymentNo.append(strMax);
  //			registPaymentBusinessBean.setPaymentNo(paymentNo.toString());
  //
  //			// 支払登録
  //			Date date = new Date();
  //			Timestamp sysDate = new Timestamp(date.getTime());
  //			Payment payment = new Payment();
  //
  //			// 支払情報登録
  //			// 契約者ID
  //			payment.setContractorId(inquiryContractorInformationEntityBean
  //					.getContractorId());
  //			// 支払番号
  //			payment.setPaymentNo(registPaymentBusinessBean.getPaymentNo());
  //
  //			// 口振クレカ翌月請求フラグが未入力の場合
  //			if (StringUtils.isEmpty(registPaymentBusinessBean
  //					.getDirectDebitCreditCardNextMonthBillingFlag())) {
  //				// 口振クレカ翌月請求フラグが未入力の場合
  //				payment.setDdCreNextMonthBlFlag(ECISKJConstants.DIRECT_DEBIT_CREDIT_CARD_NEXT_MONTH_BILLING_FLAG_NEXT_MONTH_BILLING);
  //			} else {
  //				// 口振クレカ翌月請求フラグが入力済みの場合
  //				payment.setDdCreNextMonthBlFlag(registPaymentBusinessBean
  //						.getDirectDebitCreditCardNextMonthBillingFlag());
  //			}
  //			// 更新回数
  //			payment.setUpdateCount(INT_CNT_ZERO);
  //			// 作成日時
  //			payment.setCreateTime(sysDate);
  //			// オンライン更新日時
  //			payment.setOnlineUpdateTime(sysDate);
  //			// オンライン更新ユーザID
  //			payment.setOnlineUpdateUserId(ThreadContext
  //					.getRequestThreadContext().get(ECISConstants.USER_ID_KEY)
  //					.toString());
  //			// 更新日時
  //			payment.setUpdateTime(sysDate);
  //			// 更新モジュールコード
  //			payment.setUpdateModuleCode(ThreadContext.getRequestThreadContext()
  //					.get(ECISConstants.CLASS_NAME_KEY).toString());
  //
  //			// 《支払情報共通Dao》.シーケンス登録
  //			paymentMapper.insertBySequence(payment);
  //
  //			// 支払履歴情報登録
  //			PaymentHist paymentHistory = new PaymentHist();
  //			insertPaymentHistory(paymentHistory, registPaymentBusinessBean,
  //					payment.getPaymentId(), sysDate);
  //
  //			// 支払ID設定
  //			registPaymentBusinessBean.setPaymentId(payment.getPaymentId());
  //
  //			registPaymentBusinessBean
  //					.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);
  //
  //			return registPaymentBusinessBean;
  //
  //		} catch (DuplicateKeyException e) {
  //			logger.error(messageSource.getMessage("error.E1129", null,
  //					Locale.getDefault()), e);
  //			// 重複エラー
  //			registPaymentBusinessBean
  //					.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D023);
  //			registPaymentBusinessBean.setMessage(duplicateKeyExceptionMsg);
  //			return registPaymentBusinessBean;
  //		} catch (BusinessLogicException | DataAccessException e) {
  //			logger.error(messageSource.getMessage("error.E1129", null,
  //					Locale.getDefault()), e);
  //			// ビジネス失敗エラー
  //			// データアクセスでエラー
  //			registPaymentBusinessBean
  //					.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
  //			registPaymentBusinessBean.setMessage(errMsg);
  //			return registPaymentBusinessBean;
  //		} catch (NoSuchMessageException e) {
  //			logger.error(messageSource.getMessage("error.E1129", null,
  //					Locale.getDefault()), e);
  //			// メッセージプロパティ不在エラー
  //			registPaymentBusinessBean
  //					.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
  //			registPaymentBusinessBean
  //					.setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
  //			return registPaymentBusinessBean;
  //		}
  //	}
  //
  //	/*
  //	 * (非 Javadoc)
  //	 *
  //	 * @see
  //	 * jp.co.unisys.enability.cis.business.kj.KJ_PaymentInformationBusiness#
  //	 * update
  //	 * (jp.co.unisys.enability.cis.business.kj.model.UpdatePaymentBusinessBean)
  //	 */
  //	@Override
  //	public UpdatePaymentBusinessBean update(
  //			UpdatePaymentBusinessBean updatePaymentBusinessBean) {
  //		String errMsg = null;
  //		try {
  //
  //			// システムエラーメッセージを取得
  //			errMsg = getPropertiesMesseage(ECISReturnCodeConstants.RETURN_CODE_G017);
  //
  //			// コード存在チェック
  //			String returnCode = checkMasterCode(
  //					updatePaymentBusinessBean.getPaymentWayCode(),
  //					updatePaymentBusinessBean
  //							.getIndividualLegalEntityCategoryCode(),
  //					updatePaymentBusinessBean.getBillingPhoneCategoryCode());
  //
  //			// 存在チェックでエラー
  //			if (StringUtils.isNotEmpty(returnCode)) {
  //
  //				setMessageAndReturnCode(updatePaymentBusinessBean, returnCode);
  //
  //				return updatePaymentBusinessBean;
  //			}
  //
  //			// 支払情報存在チェック
  //			InquiryPaymentBusinessBean updateInquiryPaymentBusinessBean = new InquiryPaymentBusinessBean();
  //			updateInquiryPaymentBusinessBean
  //					.setPaymentId(updatePaymentBusinessBean.getPaymentId());
  //			updateInquiryPaymentBusinessBean
  //					.setPaymentNo(updatePaymentBusinessBean.getPaymentNo());
  //
  //			// 支払情報照会（ビジネス）呼び出し
  //			updateInquiryPaymentBusinessBean = inquiry(updateInquiryPaymentBusinessBean);
  //
  //			// 支払情報照会（ビジネス）呼び出し判定
  //			if (!ECISReturnCodeConstants.RETURN_CODE_0000
  //					.equals(updateInquiryPaymentBusinessBean.getReturnCode())) {
  //				throw new BusinessLogicException(
  //
  //						messageSource.getMessage("error.E1288", new String[] {},
  //								Locale.getDefault()));
  //			}
  //			// 返却値が0件の場合
  //			if (updateInquiryPaymentBusinessBean.getPaymentInformationList()
  //					.isEmpty()) {
  //				setMessageAndReturnCode(updatePaymentBusinessBean,
  //						ECISReturnCodeConstants.RETURN_CODE_P007);
  //				return updatePaymentBusinessBean;
  //
  //			}
  //
  //			// 《支払情報照会EntityBean》取得
  //			KJ_InquiryPaymentInformationEntityBean inquiryPaymentInformationEntityBeanFirst = updateInquiryPaymentBusinessBean
  //					.getPaymentInformationList().get(FIRST_INDEX);
  //
  //			// 《支払情報照会EntityBean》.支払適用開始日
  //			Date paymentSdNextDay = inquiryPaymentInformationEntityBeanFirst
  //					.getPaymentStartDate();
  //
  //			// 最新履歴チェック
  //			// 《支払情報更新BusinessBean》.支払適用開始日が《支払情報照会EntityBean》.支払適用開始日前の場合、
  //			if (updatePaymentBusinessBean.getPaymentStartDate().before(paymentSdNextDay)) {
  //				setMessageAndReturnCode(updatePaymentBusinessBean,
  //						ECISReturnCodeConstants.RETURN_CODE_G001);
  //				return updatePaymentBusinessBean;
  //
  //			} else
  //			// 《支払情報更新BusinessBean》.支払適用開始日が《支払情報照会EntityBean》.支払適用開始日+1と同日
  //			if (updatePaymentBusinessBean.getPaymentStartDate().equals(
  //					DateCalculateUtil.calculateDate(paymentSdNextDay, 0, 0, 1))) {
  //				setMessageAndReturnCode(updatePaymentBusinessBean,
  //						ECISReturnCodeConstants.RETURN_CODE_G030);
  //				return updatePaymentBusinessBean;
  //			}
  //
  //			// 親エンティティ存在チェック
  //			// 《契約者情報照会BusinessBean》の設定
  //			InquiryContractorBusinessBean inquiryContractorBusinessBean = new InquiryContractorBusinessBean();
  //			inquiryContractorBusinessBean
  //					.setContractorId(inquiryPaymentInformationEntityBeanFirst
  //							.getContractorId());
  //
  //			// 契約者情報照会（ビジネス）呼び出し
  //			inquiryContractorBusinessBean = kjContractorInformationBusiness
  //					.inquiry(inquiryContractorBusinessBean);
  //
  //			// 契約者情報照会（ビジネス）呼び出し判定
  //			if (!ECISReturnCodeConstants.RETURN_CODE_0000
  //					.equals(inquiryContractorBusinessBean.getReturnCode())) {
  //				throw new BusinessLogicException(
  //
  //						messageSource.getMessage("error.E1281", new String[] {},
  //								Locale.getDefault()));
  //			}
  //
  //			// 返却値0件
  //			if (inquiryContractorBusinessBean.getContractorInformationList()
  //					.isEmpty()) {
  //				setMessageAndReturnCode(updatePaymentBusinessBean,
  //						ECISReturnCodeConstants.RETURN_CODE_D014);
  //				return updatePaymentBusinessBean;
  //
  //			}
  //
  //			// 契約者情報リストを取得する
  //			// ※検索条件が契約者IDもしくは契約者NO(PKとユニーク)のためリストは必ず1件になる。
  //			KJ_InquiryContractorInformationEntityBean inquiryContractorInformationEntityBean = inquiryContractorBusinessBean
  //					.getContractorInformationList().get(FIRST_INDEX);
  //
  //			// 《契約者情報照会BusinessBean》.利用不能フラグが“ON”の場合、
  //			// 契約者利用不能チェック
  //			if (!checkUnavailableFlag(inquiryContractorInformationEntityBean
  //					.getUnavailableFlag())) {
  //				setMessageAndReturnCode(updatePaymentBusinessBean,
  //						ECISReturnCodeConstants.RETURN_CODE_D013);
  //
  //				return updatePaymentBusinessBean;
  //			}
  //
  //			// 契約者支払チェック
  //			if (!checkDMPaymentWay(
  //					inquiryContractorInformationEntityBean
  //							.getProvideModelCode(),
  //					updatePaymentBusinessBean.getPaymentWayCode())) {
  //				setMessageAndReturnCode(updatePaymentBusinessBean,
  //						ECISReturnCodeConstants.RETURN_CODE_G033);
  //
  //				return updatePaymentBusinessBean;
  //			}
  //
  //			List<String> checkList = new ArrayList<>();
  //
  //			checkList.add(updatePaymentBusinessBean
  //					.getDirectDebitCreditCardNextMonthBillingFlag());
  //			checkList.add(updatePaymentBusinessBean.getPaymentWayCode());
  //			checkList.add(updatePaymentBusinessBean
  //					.getIndividualLegalEntityCategoryCode());
  //			checkList.add(updatePaymentBusinessBean.getBillingName1());
  //			checkList.add(updatePaymentBusinessBean.getBillingName2());
  //			checkList.add(updatePaymentBusinessBean.getPrefix());
  //			checkList.add(updatePaymentBusinessBean
  //					.getBillingAddressPostalCode());
  //			checkList.add(updatePaymentBusinessBean
  //					.getBillingAddressPrefectures());
  //			checkList.add(updatePaymentBusinessBean
  //					.getBillingAddressMunicipality());
  //			checkList.add(updatePaymentBusinessBean.getBillingAddressSection());
  //			checkList.add(updatePaymentBusinessBean.getBillingAddressBlock());
  //			checkList.add(updatePaymentBusinessBean
  //					.getBillingAddressBuildingName());
  //			checkList.add(updatePaymentBusinessBean.getBillingAddressRoom());
  //			checkList.add(updatePaymentBusinessBean.getBillingPhoneNo());
  //			checkList.add(updatePaymentBusinessBean
  //					.getBillingPhoneCategoryCode());
  //			checkList.add(updatePaymentBusinessBean.getBillingMailAddress1());
  //			checkList.add(updatePaymentBusinessBean.getBillingMailAddress2());
  //
  //			// 支払方法チェック
  //			if (!checkPaymentMethod(checkList,
  //					inquiryContractorInformationEntityBean
  //							.getProvideModelCode(),
  //					updatePaymentBusinessBean.getAccountCreditCardId())) {
  //
  //				setMessageAndReturnCode(updatePaymentBusinessBean,
  //						ECISReturnCodeConstants.RETURN_CODE_G011);
  //				return updatePaymentBusinessBean;
  //			}
  //
  //			// 《支払情報登録BusinessBean》.口座クレカIDがNULLでない場合
  //			if (updatePaymentBusinessBean.getAccountCreditCardId() != null) {
  //				AcInformation accountCreditInformation = new AcInformation();
  //				// 口座クレカ情報存在チェック
  //				accountCreditInformation = acInformationMapper
  //						.selectByPrimaryKey(updatePaymentBusinessBean
  //								.getAccountCreditCardId());
  //
  //				// 返却値が0件の場合
  //				if (accountCreditInformation == null) {
  //					setMessageAndReturnCode(updatePaymentBusinessBean,
  //							ECISReturnCodeConstants.RETURN_CODE_P012);
  //					return updatePaymentBusinessBean;
  //				}
  //
  //				// 口座クレカ区分チェック
  //				// 《口座クレカ情報Entity》.口座クレカ区分コードと《支払情報更新BusinessBean》.支払方法コードが異なる場合
  //				if (!accountCreditInformation.getAcCatCode().equals(
  //						updatePaymentBusinessBean.getPaymentWayCode())) {
  //					setMessageAndReturnCode(updatePaymentBusinessBean,
  //							ECISReturnCodeConstants.RETURN_CODE_P066);
  //
  //					return updatePaymentBusinessBean;
  //
  //				}
  //
  //				// 口座クレカ利用不能チェック
  //				// 《口座クレカ情報Entity》.利用不能フラグが'1:利用不能'の場合、
  //				// リターンコードに（G042）を返却し処理を終了する。
  //				if (!checkUnavailableFlag(accountCreditInformation.getUnavailableFlag())) {
  //					setMessageAndReturnCode(updatePaymentBusinessBean,
  //							ECISReturnCodeConstants.RETURN_CODE_G042);
  //					return updatePaymentBusinessBean;
  //				}
  //			}
  //
  //			// 最新支払履歴適用開始日と適用開始日が一致しない場合
  //			// 請求作成チェックを行う
  //			if (!inquiryPaymentInformationEntityBeanFirst.getPaymentStartDate().equals(
  //					updatePaymentBusinessBean.getPaymentStartDate())
  //					&& !checkBillingCreation(
  //							inquiryPaymentInformationEntityBeanFirst.getPaymentId(),
  //							updatePaymentBusinessBean.getPaymentStartDate())) {
  //				setMessageAndReturnCode(updatePaymentBusinessBean,
  //						ECISReturnCodeConstants.RETURN_CODE_D011);
  //
  //				return updatePaymentBusinessBean;
  //
  //			}
  //
  //			// 支払情報更新
  //			Date date = new Date();
  //			Timestamp sysDate = new Timestamp(date.getTime());
  //			Payment payment = new Payment();
  //
  //			// 口振クレカ翌月請求フラグが入力済みの場合
  //			payment.setDdCreNextMonthBlFlag(updatePaymentBusinessBean
  //					.getDirectDebitCreditCardNextMonthBillingFlag());
  //			// 更新回数
  //			payment.setUpdateCount(inquiryPaymentInformationEntityBeanFirst
  //					.getUpdateCount() + 1);
  //
  //			if (!updatePayment(payment,
  //					inquiryPaymentInformationEntityBeanFirst.getPaymentId(),
  //					updatePaymentBusinessBean.getUpdateCount(), sysDate)) {
  //				setMessageAndReturnCode(updatePaymentBusinessBean,
  //						ECISReturnCodeConstants.RETURN_CODE_H001);
  //				return updatePaymentBusinessBean;
  //			}
  //
  //			// 《支払情報更新BusinessBean》.支払適用開始日が《支払情報照会EntityBean》.支払適用開始日後の場合
  //			if (updatePaymentBusinessBean.getPaymentStartDate().after(
  //					inquiryPaymentInformationEntityBeanFirst
  //							.getPaymentStartDate())) {
  //
  //				PaymentHistKey paymentHistoryKey = new PaymentHistKey();
  //				// 支払履歴情報取得
  //				paymentHistoryKey
  //						.setPaymentId(inquiryPaymentInformationEntityBeanFirst
  //								.getPaymentId());
  //				paymentHistoryKey
  //						.setPaymentSd(inquiryPaymentInformationEntityBeanFirst
  //								.getPaymentStartDate());
  //
  //				PaymentHist paymentHist = paymentHistMapper
  //						.selectByPrimaryKey(paymentHistoryKey);
  //				Integer paymentHistUpdateCount = paymentHist.getUpdateCount();
  //				// 支払履歴情報登録
  //				insertPaymentHistory(paymentHist, updatePaymentBusinessBean,
  //						inquiryPaymentInformationEntityBeanFirst, sysDate);
  //
  //				// 初期化
  //				PaymentHist paymentHistory = new PaymentHist();
  //
  //				// 前回支払履歴情報更新
  //				Calendar cal = Calendar.getInstance();
  //				cal.setTime(updatePaymentBusinessBean.getPaymentStartDate());
  //				cal.add(Calendar.DATE, -1);
  //
  //				paymentHistory.setPaymentEd(cal.getTime());
  //				paymentHistory.setUpdateCount(paymentHistUpdateCount + 1);
  //
  //				// 支払履歴情報更新
  //				if (!updatePaymentHistoryUseUpdate(
  //						paymentHistory,
  //						sysDate,
  //						inquiryPaymentInformationEntityBeanFirst.getPaymentId(),
  //						inquiryPaymentInformationEntityBeanFirst
  //								.getPaymentStartDate(), paymentHistUpdateCount,
  //						updatePaymentBusinessBean
  //								.getAccountCreditCardIdNoUpdFlag(),
  //						inquiryPaymentInformationEntityBeanFirst
  //								.getAccountCreditCardId())) {
  //					setMessageAndReturnCode(updatePaymentBusinessBean,
  //							ECISReturnCodeConstants.RETURN_CODE_H001);
  //
  //					return updatePaymentBusinessBean;
  //				}
  //			}
  //
  //			updatePaymentBusinessBean
  //					.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);
  //
  //			return updatePaymentBusinessBean;
  //
  //		} catch (BusinessLogicException e) {
  //			logger.error(messageSource.getMessage("error.E1129", null,
  //					Locale.getDefault()), e);
  //			// ビジネス失敗エラー
  //			updatePaymentBusinessBean
  //					.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
  //			updatePaymentBusinessBean.setMessage(errMsg);
  //			return updatePaymentBusinessBean;
  //		} catch (NoSuchMessageException e) {
  //			logger.error(messageSource.getMessage("error.E1129", null,
  //					Locale.getDefault()), e);
  //			// メッセージプロパティ不在エラー
  //			updatePaymentBusinessBean
  //					.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
  //			updatePaymentBusinessBean
  //					.setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
  //			return updatePaymentBusinessBean;
  //		}
  //	}
  //
  //	/*
  //	 * (非 Javadoc)
  //	 *
  //	 * @see
  //	 * jp.co.unisys.enability.cis.business.kj.KJ_PaymentInformationBusiness#
  //	 * delete
  //	 * (jp.co.unisys.enability.cis.business.kj.model.DeletePaymentBusinessBean)
  //	 */
  //	@Override
  //	public DeletePaymentBusinessBean delete(
  //			DeletePaymentBusinessBean deletePaymentBusinessBean) {
  //
  //		String errMsg = null;
  //		try {
  //
  //			// システムエラーメッセージを取得
  //			errMsg = getPropertiesMesseage(ECISReturnCodeConstants.RETURN_CODE_G017);
  //
  //			// 支払情報存在チェック
  //			InquiryPaymentBusinessBean deleteInquiryPaymentBusinessBean = new InquiryPaymentBusinessBean();
  //			deleteInquiryPaymentBusinessBean
  //					.setPaymentId(deletePaymentBusinessBean.getPaymentId());
  //			deleteInquiryPaymentBusinessBean
  //					.setPaymentNo(deletePaymentBusinessBean.getPaymentNo());
  //
  //			// 支払情報照会（ビジネス）呼び出し
  //			deleteInquiryPaymentBusinessBean = inquiry(deleteInquiryPaymentBusinessBean);
  //
  //			// 支払情報取得結果判定
  //			// 《支払情報照会BusinessBean》.リターンコードが'0000'以外の場合
  //			if (!ECISReturnCodeConstants.RETURN_CODE_0000
  //					.equals(deleteInquiryPaymentBusinessBean.getReturnCode())) {
  //				throw new BusinessLogicException(messageSource.getMessage(
  //						"error.E1288", new String[] {}, Locale.getDefault()));
  //			}
  //			// 返却値が0件の場合
  //			if (deleteInquiryPaymentBusinessBean.getPaymentInformationList()
  //					.isEmpty()) {
  //				setMessageAndReturnCode(deletePaymentBusinessBean,
  //						ECISReturnCodeConstants.RETURN_CODE_P007);
  //
  //				return deletePaymentBusinessBean;
  //			}
  //
  //			// 《支払情報照会EntityBean》取得
  //			KJ_InquiryPaymentInformationEntityBean newInquiryPaymentInformationEntityBean = deleteInquiryPaymentBusinessBean
  //					.getPaymentInformationList().get(FIRST_INDEX);
  //			KJ_InquiryPaymentInformationEntityBean oldInquiryPaymentInformationEntityBean = new KJ_InquiryPaymentInformationEntityBean();
  //			boolean entityBeanOldFlg = false;
  //			if (deleteInquiryPaymentBusinessBean.getPaymentInformationList()
  //					.size() >= 2) {
  //				oldInquiryPaymentInformationEntityBean = deleteInquiryPaymentBusinessBean
  //						.getPaymentInformationList().get(SECOND_INDEX);
  //
  //				entityBeanOldFlg = true;
  //			}
  //
  //			// 最新履歴チェック
  //			// 《支払情報照会EntityBean》（最新）.支払適用開始日と《支払情報削除BusinessBean》.支払適用開始日が一致しない場合、
  //			if (!newInquiryPaymentInformationEntityBean.getPaymentStartDate()
  //					.equals(deletePaymentBusinessBean.getPaymentStartDate())) {
  //				setMessageAndReturnCode(deletePaymentBusinessBean,
  //						ECISReturnCodeConstants.RETURN_CODE_G009);
  //
  //				return deletePaymentBusinessBean;
  //			}
  //
  //			// 請求作成チェック
  //			if (!checkBillingCreation(
  //					newInquiryPaymentInformationEntityBean.getPaymentId(),
  //					deletePaymentBusinessBean.getPaymentStartDate())) {
  //				setMessageAndReturnCode(deletePaymentBusinessBean,
  //						ECISReturnCodeConstants.RETURN_CODE_D011);
  //
  //				return deletePaymentBusinessBean;
  //			}
  //
  //			// 契約情報存在チェック
  //			// 《支払情報照会EntityBean》(前回)がNULLの場合
  //			InquiryContractBusinessBean inquiryContractBusinessBean = new InquiryContractBusinessBean();
  //			if (!entityBeanOldFlg) {
  //				inquiryContractBusinessBean
  //						.setPaymentId(newInquiryPaymentInformationEntityBean
  //								.getPaymentId());
  //				inquiryContractBusinessBean = kjContractInformationBusiness
  //						.inquiry(inquiryContractBusinessBean);
  //
  //				// 《契約情報照会BusinessBean》.リターンコードが'0000'以外の場合
  //				if (!ECISReturnCodeConstants.RETURN_CODE_0000
  //						.equals(inquiryContractBusinessBean.getReturnCode())) {
  //					throw new BusinessLogicException(
  //							messageSource.getMessage("error.E1281",
  //									new String[] {}, Locale.getDefault()));
  //				}
  //
  //				// 返却値が1件以上
  //				if (!inquiryContractBusinessBean.getContractInformationList()
  //						.isEmpty()) {
  //					setMessageAndReturnCode(deletePaymentBusinessBean,
  //							ECISReturnCodeConstants.RETURN_CODE_D006);
  //
  //					return deletePaymentBusinessBean;
  //
  //				}
  //			}
  //
  //			// 支払履歴情報取得
  //			PaymentHistExample paymentHistoryExample = new PaymentHistExample();
  //			paymentHistoryExample.createCriteria().andPaymentIdEqualTo(
  //					newInquiryPaymentInformationEntityBean.getPaymentId());
  //			paymentHistoryExample
  //					.setOrderByClause(ECISKJConstants.PAYMENT_HIST_ORDER_BY_KEY);
  //
  //			List<PaymentHist> paymentHistoryList = paymentHistMapper
  //					.selectByExample(paymentHistoryExample);
  //
  //			// 返却値が0件の場合
  //			if (paymentHistoryList.isEmpty()) {
  //				setMessageAndReturnCode(deletePaymentBusinessBean,
  //						ECISReturnCodeConstants.RETURN_CODE_H001);
  //
  //				return deletePaymentBusinessBean;
  //			}
  //
  //			// 《支払履歴Entity》(最新)の取得
  //			PaymentHist newPaymentHistry = new PaymentHist();
  //			PaymentHist oldPaymentHistory = new PaymentHist();
  //			newPaymentHistry = paymentHistoryList.get(FIRST_INDEX);
  //			if (paymentHistoryList.size() >= 2) {
  //				// 《支払履歴Entity》(前回)の取得
  //				oldPaymentHistory = paymentHistoryList.get(SECOND_INDEX);
  //			}
  //
  //			Date date = new Date();
  //			Timestamp sysDate = new Timestamp(date.getTime());
  //			Payment payment = new Payment();
  //
  //			// 《支払情報照会EntityBean》(前回)がNULLの場合
  //			if (oldPaymentHistory == null
  //					|| oldPaymentHistory.getPaymentId() == null) {
  //
  //				// 支払情報削除
  //				PaymentExample deletePaymentExample = new PaymentExample();
  //				deletePaymentExample
  //						.createCriteria()
  //						.andPaymentIdEqualTo(
  //								newInquiryPaymentInformationEntityBean
  //										.getPaymentId())
  //						.andUpdateCountEqualTo(
  //								deletePaymentBusinessBean.getUpdateCount());
  //
  //				// 《支払Dao》.削除（選択項目）を呼び出し。
  //				int deleteByExampleCnt = paymentMapper
  //						.deleteByExample(deletePaymentExample);
  //
  //				// 削除失敗の場合
  //				if (deleteByExampleCnt == 0) {
  //					setMessageAndReturnCode(deletePaymentBusinessBean,
  //							ECISReturnCodeConstants.RETURN_CODE_H001);
  //
  //					return deletePaymentBusinessBean;
  //				}
  //
  //			} else {
  //				// 《支払情報照会EntityBean》(前回)がNULLではない場合
  //				// 支払情報更新
  //				payment.setUpdateCount(newInquiryPaymentInformationEntityBean
  //						.getUpdateCount() + 1);
  //
  //				if (!updatePayment(payment,
  //						newInquiryPaymentInformationEntityBean.getPaymentId(),
  //						deletePaymentBusinessBean.getUpdateCount(), sysDate)) {
  //					setMessageAndReturnCode(deletePaymentBusinessBean,
  //							ECISReturnCodeConstants.RETURN_CODE_H001);
  //
  //					return deletePaymentBusinessBean;
  //				}
  //			}
  //
  //			// 支払履歴削除
  //			// 最新支払履歴情報削除
  //			PaymentHistExample deletePaymentHistoryExample = new PaymentHistExample();
  //			deletePaymentHistoryExample
  //					.createCriteria()
  //					.andPaymentIdEqualTo(
  //							newInquiryPaymentInformationEntityBean
  //									.getPaymentId())
  //					.andPaymentSdEqualTo(
  //							deletePaymentBusinessBean.getPaymentStartDate())
  //					.andUpdateCountEqualTo(newPaymentHistry.getUpdateCount());
  //
  //			int deleteByExampleCnt = paymentHistMapper
  //					.deleteByExample(deletePaymentHistoryExample);
  //
  //			// 返却値が0件の場合
  //			if (deleteByExampleCnt == 0) {
  //				setMessageAndReturnCode(deletePaymentBusinessBean,
  //						ECISReturnCodeConstants.RETURN_CODE_H001);
  //
  //				return deletePaymentBusinessBean;
  //			}
  //
  //			// 《支払情報照会EntityBean》(前回)がNULLではない場合、以下の更新処理を行う。
  //			if (oldInquiryPaymentInformationEntityBean != null
  //					&& oldInquiryPaymentInformationEntityBean.getPaymentId() != null) {
  //				PaymentHist paymentHistory = new PaymentHist();
  //				// 前回支払履歴情報更新
  //				paymentHistory.setUpdateCount(oldPaymentHistory
  //						.getUpdateCount() + 1);
  //				paymentHistory.setPaymentEd(StringConvertUtil.stringToDate(
  //						ECISKJConstants.APPLY_END_DATE_MAX,
  //						ECISConstants.FORMAT_DATE_yyyyMMdd));
  //				if (!updatePaymentHistoryUseDelete(paymentHistory, sysDate,
  //						newInquiryPaymentInformationEntityBean.getPaymentId(),
  //						oldPaymentHistory.getPaymentSd(),
  //						oldPaymentHistory.getUpdateCount())) {
  //					setMessageAndReturnCode(deletePaymentBusinessBean,
  //							ECISReturnCodeConstants.RETURN_CODE_H001);
  //
  //					return deletePaymentBusinessBean;
  //				}
  //			}
  //
  //			deletePaymentBusinessBean
  //					.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);
  //
  //			return deletePaymentBusinessBean;
  //
  //		} catch (BusinessLogicException e) {
  //			logger.error(messageSource.getMessage("error.E1129", null,
  //					Locale.getDefault()), e);
  //			// ビジネス失敗エラー
  //			deletePaymentBusinessBean
  //					.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
  //			deletePaymentBusinessBean.setMessage(errMsg);
  //
  //			return deletePaymentBusinessBean;
  //
  //		} catch (NoSuchMessageException e) {
  //			logger.error(messageSource.getMessage("error.E1129", null,
  //					Locale.getDefault()), e);
  //			// メッセージプロパティ不在
  //			deletePaymentBusinessBean
  //					.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
  //			deletePaymentBusinessBean
  //					.setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
  //
  //			return deletePaymentBusinessBean;
  //		}
  //
  //	}
  //
  //	/*
  //	 * (非 Javadoc)
  //	 *
  //	 * @see
  //	 * jp.co.unisys.enability.cis.business.kj.KJ_PaymentInformationBusiness#
  //	 * download
  //	 * (jp.co.unisys.enability.cis.business.kj.model.DownloadPaymentBusinessBean
  //	 * )
  //	 */
  //	@Override
  //	public DownloadPaymentBusinessBean download(
  //			DownloadPaymentBusinessBean downloadBusinessBean) {
  //		try {
  //			// オンライン処理基準日、設定
  //			Date onlineDate = dateBusiness
  //					.getProcessBaseDate(ECISConstants.EXEC_BASE_DATE_ONLINE);
  //
  //			// CSV出力情報取得
  //			Map<String, Object> exampleMap = new HashMap<String, Object>();
  //			ContractManagementInformationDownloadSearchInformationBean searchInformationBean = downloadBusinessBean
  //					.getContractManagementInformationDownloadSearchInformationBean();
  //			// 契約者番号
  //			exampleMap.put(ECISKJConstants.S010107_SEARCH_KEY_CONTRACTOR_NO,
  //					searchInformationBean.getContractorNo());
  //			// 支払番号
  //			exampleMap.put(ECISKJConstants.S010107_SEARCH_KEY_PAYMENT_NO,
  //					searchInformationBean.getPaymentNo());
  //			// 支払方法に紐付く支払方法コード
  //			exampleMap.put(ECISKJConstants.S010107_SEARCH_KEY_PAYMENT_WAY,
  //					searchInformationBean.getPaymentWay());
  //			// 支払適用期間(開始日)
  //			if (StringUtils.isNotEmpty(searchInformationBean
  //					.getPaymentApplyTermStartDate())) {
  //				exampleMap
  //						.put(ECISKJConstants.S010107_SEARCH_KEY_PAYMENT_APPLY_TERM_START_DATE,
  //								StringConvertUtil.stringToDate(
  //										searchInformationBean
  //												.getPaymentApplyTermStartDate(),
  //										ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH));
  //			}
  //			// 支払適用期間(終了日)
  //			if (StringUtils.isNotEmpty(searchInformationBean
  //					.getPaymentApplyTermEndDate())) {
  //				exampleMap
  //						.put(ECISKJConstants.S010107_SEARCH_KEY_PAYMENT_APPLY_TERM_END_DATE,
  //								StringConvertUtil.stringToDate(
  //										searchInformationBean
  //												.getPaymentApplyTermEndDate(),
  //										ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH));
  //			}
  //			// オンライン処理基準日
  //			exampleMap
  //					.put(ECISKJConstants.S010107_SEARCH_KEY_ONLINE_EXECUTE_BASE_DATE,
  //							onlineDate);
  //
  //			List<KJ_PaymentInformationFileEntityBean> paymentInformationFileEntityBeanList = paymentInformationCommonMapper
  //					.selectPaymentInfomationFile(exampleMap);
  //
  //			// CSVファイル名生成
  //			StringBuilder fileName = new StringBuilder();
  //			fileName.append(ECISKJConstants.CONTRACT_MANAGEMENT_INFORMATION_DOWNLOAD_FILE_PREFIX_PAYMENT);
  //			fileName.append(ECISConstants.UNDERLINE);
  //			fileName.append(StringConvertUtil.convertDateToString(onlineDate,
  //					ECISConstants.FORMAT_DATE_yyyyMMdd));
  //
  //			// 返却
  //			downloadBusinessBean.setDownloadFileName(fileName.toString());
  //			downloadBusinessBean
  //					.setPaymentInformationFileEntityBeanList(paymentInformationFileEntityBeanList);
  //		} catch (Exception e) {
  //			throw new SystemException(e.getMessage(), e);
  //		}
  //		return downloadBusinessBean;
  //	}
  //
  //	/*
  //	 * (非 Javadoc)
  //	 *
  //	 * @see
  //	 * jp.co.unisys.enability.cis.business.kj.KJ_PaymentInformationBusiness#
  //	 * csvFileCheck
  //	 * (jp.co.unisys.enability.cis.business.kj.model.CsvFileCheckPaymentBusinessBean
  //	 * )
  //	 */
  //	@Override
  //	public CsvFileCheckPaymentBusinessBean csvFileCheck(
  //			CsvFileCheckPaymentBusinessBean csvFileCheckPaymentBusinessBean) {
  //		try {
  //			// 返却用オブジェクト生成
  //			CsvFileCheckPaymentBusinessBean csvResultBean = new CsvFileCheckPaymentBusinessBean();
  //
  //			// エラーリスト
  //			List<String> errorList = new ArrayList<String>();
  //			// 登録オブジェクトリスト
  //			List<Map<Integer, String>> registList = new ArrayList<Map<Integer, String>>();
  //			// 更新オブジェクトリスト
  //			List<Map<Integer, String>> updateList = new ArrayList<Map<Integer, String>>();
  //			// 削除オブジェクトリスト
  //			List<Map<Integer, String>> deleteList = new ArrayList<Map<Integer, String>>();
  //
  //			// ファイル取得
  //			File paymentFile = csvFileCheckPaymentBusinessBean.getUploadFile();
  //			String fileName = paymentFile.getName();
  //
  //			// ファイル読み込み
  //			List<Map<Integer, String>> csvMapList = Csv
  //					.load(paymentFile, ECISConstants.ENCODE_TYPE_UTF8,
  //							ContractManagementInformationFileConfigCommon
  //									.getCsvConfig(),
  //							new ColumnPositionMapListHandler());
  //
  //			/**
  //			 * ヘッダレコードチェック
  //			 */
  //			// ファイル構成チェック
  //			if (ContractManagementInformationFileConfigCommon.UPLOAD_FILE_MINIMUM_LINE_COUNT > csvMapList
  //					.size()) {
  //				errorList.add(StringConvertUtil.convertErrorListString(
  //						fileName,
  //						null,
  //						messageSource.getMessage("error.E0028", null,
  //								Locale.getDefault())));
  //				csvResultBean.setUploadFileName(fileName);
  //				csvResultBean.setErrorList(errorList);
  //				csvResultBean.setRegistList(registList);
  //				csvResultBean.setUpdateList(updateList);
  //				csvResultBean.setDeleteList(deleteList);
  //				return csvResultBean;
  //			}
  //
  //			// ヘッダレコード取得
  //			Map<Integer, String> headerRecord = csvMapList
  //					.get(ContractManagementInformationFileConfigCommon.ROW_NUMBER_HEADER);
  //			// 項目数チェック
  //			if (ContractManagementInformationFileConfigCommon.HEADER_COLUMN_COUNT != headerRecord
  //					.size()) {
  //				errorList
  //						.add(StringConvertUtil.convertErrorListString(
  //								paymentFile.getName(),
  //								ContractManagementInformationFileConfigCommon.HEADER_START_LINE_NUMBER,
  //								messageSource.getMessage("error.E0021", null,
  //										Locale.getDefault())));
  //				csvResultBean.setUploadFileName(fileName);
  //				csvResultBean.setErrorList(errorList);
  //				csvResultBean.setRegistList(registList);
  //				csvResultBean.setUpdateList(updateList);
  //				csvResultBean.setDeleteList(deleteList);
  //				return csvResultBean;
  //			}
  //
  //			// 単項目チェック
  //			List<String> headerErrorMessageList = contractManagementInformationFileHeaderValidator
  //					.validate(
  //							headerRecord,
  //							ContractManagementInformationFileConfigPayment.HEADER_FILE_KIND_MASK_STRING);
  //			if (headerErrorMessageList.size() > 0) {
  //				for (String message : headerErrorMessageList) {
  //					errorList
  //							.add(StringConvertUtil
  //									.convertErrorListString(
  //											fileName,
  //											ContractManagementInformationFileConfigCommon.HEADER_START_LINE_NUMBER,
  //											message));
  //				}
  //				csvResultBean.setUploadFileName(fileName);
  //				csvResultBean.setErrorList(errorList);
  //				csvResultBean.setRegistList(registList);
  //				csvResultBean.setUpdateList(updateList);
  //				csvResultBean.setDeleteList(deleteList);
  //				return csvResultBean;
  //			}
  //
  //			/**
  //			 * タイトルレコードチェック
  //			 */
  //			Map<Integer, String> titleRecord = csvMapList
  //					.get(ContractManagementInformationFileConfigCommon.ROW_NUMBER_TITLE);
  //			// 項目数チェック
  //			if (ContractManagementInformationFileConfigPayment.DATA_COLUMN_COUNT != titleRecord
  //					.size()) {
  //				// データレコード項目数と一致しない場合、エラー終了
  //				errorList
  //						.add(StringConvertUtil
  //								.convertErrorListString(
  //										fileName,
  //										ContractManagementInformationFileConfigCommon.TITLE_START_LINE_NUMBER,
  //										messageSource.getMessage("error.E0021",
  //												null, Locale.getDefault())));
  //				csvResultBean.setUploadFileName(fileName);
  //				csvResultBean.setErrorList(errorList);
  //				csvResultBean.setRegistList(registList);
  //				csvResultBean.setUpdateList(updateList);
  //				csvResultBean.setDeleteList(deleteList);
  //				return csvResultBean;
  //			}
  //
  //			// 各項目チェック
  //			// HashMapだと順番に揃わない可能性があるため、IteratorでKeyを取得
  //			Iterator<Integer> titleIt = titleRecord.keySet().iterator();
  //			while (titleIt.hasNext()) {
  //				// タイトルのカラム番号を取得
  //				Integer columnNo = titleIt.next();
  //				// タイトル内容を取得
  //				String titleValue = titleRecord.get(columnNo);
  //				// コンフィグの内容を取得
  //				String configValue = ContractManagementInformationFileConfigPayment.DATA_TITLE_ROW[columnNo
  //						.intValue()];
  //				// 一致していない場合、エラー終了
  //				if (!configValue.equals(titleValue)) {
  //					errorList
  //							.add(StringConvertUtil
  //									.convertErrorListString(
  //											fileName,
  //											ContractManagementInformationFileConfigCommon.TITLE_START_LINE_NUMBER,
  //											messageSource.getMessage(
  //													"error.E0028", null,
  //													Locale.getDefault())));
  //					csvResultBean.setUploadFileName(fileName);
  //					csvResultBean.setErrorList(errorList);
  //					csvResultBean.setRegistList(registList);
  //					csvResultBean.setUpdateList(updateList);
  //					csvResultBean.setDeleteList(deleteList);
  //					return csvResultBean;
  //				}
  //			}
  //
  //			/**
  //			 * マスタ情報取得
  //			 */
  //			// 支払方法コード
  //			List<PwM> paymentWayMasterList = pwMMapper.selectByExample(null);
  //			// チェック用Setに詰め替え
  //			Set<String> paymentWayCodeCheckSet = new HashSet<String>();
  //			for (PwM paymentWayMaster : paymentWayMasterList) {
  //				paymentWayCodeCheckSet.add(paymentWayMaster.getPwCode());
  //			}
  //			// エラー用メッセージ設定
  //			String paymentWayCodeErrorMessageOption = StringUtils.join(
  //					paymentWayCodeCheckSet, ",");
  //
  //			// 個人・法人区分コード
  //			List<IlcM> individualLegalEntityCategoryMasterList = ilcMMapper
  //					.selectByExample(null);
  //			// チェック用Setに詰め替え
  //			Set<String> individualLegalEntityCategoryMasterCodeCheckSet = new HashSet<String>();
  //			for (IlcM individualLegalEntityCategoryMaster : individualLegalEntityCategoryMasterList) {
  //				individualLegalEntityCategoryMasterCodeCheckSet
  //						.add(individualLegalEntityCategoryMaster.getIlcCode());
  //			}
  //			// エラー用メッセージ設定
  //			String individualLegalEntityCategoryMasterCodeErrorMessageOption = StringUtils
  //					.join(individualLegalEntityCategoryMasterCodeCheckSet, ",");
  //
  //			// 電話番号区分コード
  //			List<PhoneNoCatM> phoneNoCategoryMasterList = phoneNoCatMMapper
  //					.selectByExample(null);
  //			// チェック用Setに詰め替え
  //			Set<String> phoneNoCategoryMasterCodeCheckSet = new HashSet<String>();
  //			for (PhoneNoCatM phoneNoCategoryMaster : phoneNoCategoryMasterList) {
  //				phoneNoCategoryMasterCodeCheckSet.add(phoneNoCategoryMaster
  //						.getPhoneNoCatCode());
  //			}
  //			// エラー用メッセージ設定
  //			String phoneNoCategoryMasterCodeErrorMessageOption = StringUtils
  //					.join(phoneNoCategoryMasterCodeCheckSet, ",");
  //
  //			// 登録・更新・削除区分エラー用メッセージ設定
  //			String registUpdateDeleteCategoryErrorMessageOption = StringUtils
  //					.join(new String[] {
  //							ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER,
  //							ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_UPDATE,
  //							ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_DELETE },
  //							",");
  //
  //			/**
  //			 * データレコードチェック
  //			 */
  //			// データレコードの件数分処理を行う
  //			for (int i = ContractManagementInformationFileConfigCommon.ROW_NUMBER_DATA; i < csvMapList
  //					.size(); i++) {
  //				// 出力用行番号設定
  //				final int outputRowNumber = i + 1;
  //
  //				// データレコードエラーリスト生成
  //				List<String> dataRecordErrorList = new ArrayList<String>();
  //
  //				// データレコード取得
  //				Map<Integer, String> dataRecord = csvMapList.get(i);
  //
  //				// 項目数チェック
  //				if (ContractManagementInformationFileConfigPayment.DATA_COLUMN_COUNT != dataRecord
  //						.size()) {
  //					// 項目数が一致しない場合、エラーリストに追加し、処理を終了する
  //					dataRecordErrorList.add(StringConvertUtil
  //							.convertErrorListString(fileName, outputRowNumber,
  //									messageSource.getMessage("error.E0021",
  //											null, Locale.getDefault())));
  //					errorList.addAll(dataRecordErrorList);
  //
  //					// 処理を終了する。
  //					csvResultBean.setUploadFileName(fileName);
  //					csvResultBean.setErrorList(errorList);
  //					csvResultBean.setRegistList(registList);
  //					csvResultBean.setUpdateList(updateList);
  //					csvResultBean.setDeleteList(deleteList);
  //					return csvResultBean;
  //				}
  //
  //				// スキップ判定
  //				String registerUpdateDeleteCategory = dataRecord
  //						.get(ContractManagementInformationFileConfigPayment.DATA_REGISTER_UPDATE_DELETE_CATEGORY_INDEX);
  //				if (StringUtils.isEmpty(registerUpdateDeleteCategory)) {
  //					continue;
  //				}
  //
  //				// 単項目チェック
  //				// バリデーションエラーメッセージ用リスト生成
  //				List<String> validationErrorMessageList = new ArrayList<String>();
  //				// 登録・更新・削除区分の値により、チェックメソッドを分岐
  //				switch (registerUpdateDeleteCategory) {
  //				case ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER:
  //					// 登録バリデーション実行
  //					validationErrorMessageList = paymentInformationFileRegistValidator
  //							.validate(dataRecord);
  //					break;
  //				case ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_UPDATE:
  //					// 更新バリデーション実行
  //					validationErrorMessageList = paymentInformationFileUpdateValidator
  //							.validate(dataRecord);
  //					break;
  //				case ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_DELETE:
  //					// 削除バリデーション実行
  //					validationErrorMessageList = paymentInformationFileDeleteValidator
  //							.validate(dataRecord);
  //					break;
  //				default:
  //					// 登録・更新・削除区分が不正な場合、エラーメッセージ設定
  //					dataRecordErrorList
  //							.add(StringConvertUtil.convertErrorListString(
  //									fileName,
  //									outputRowNumber,
  //									messageSource
  //											.getMessage(
  //													"validation.range",
  //													new String[] {
  //															ContractManagementInformationFileConfigPayment.DATA_REGISTER_UPDATE_DELETE_CATEGORY_NAME,
  //															registUpdateDeleteCategoryErrorMessageOption },
  //													Locale.getDefault())));
  //				}
  //
  //				// バリデーションエラーメッセージにファイル名と行数を追加し、データレコードエラーリストに追加
  //				for (String validationErrorMessage : validationErrorMessageList) {
  //					dataRecordErrorList.add(StringConvertUtil
  //							.convertErrorListString(fileName, outputRowNumber,
  //									validationErrorMessage));
  //				}
  //
  //				// 登録・更新区分が登録または更新の場合のみチェック
  //				if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER
  //						.equals(registerUpdateDeleteCategory)
  //						|| ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_UPDATE
  //								.equals(registerUpdateDeleteCategory)) {
  //
  //					// 支払方法コードチェック
  //					String paymentWayCode = dataRecord
  //							.get(ContractManagementInformationFileConfigPayment.DATA_PAYMENT_WAY_CODE_INDEX);
  //					if (!StringUtils.isEmpty(paymentWayCode)) {
  //						if (!paymentWayCodeCheckSet.contains(paymentWayCode)) {
  //							dataRecordErrorList
  //									.add(StringConvertUtil
  //											.convertErrorListString(
  //													fileName,
  //													outputRowNumber,
  //													messageSource
  //															.getMessage(
  //																	"validation.range",
  //																	new String[] {
  //																			ContractManagementInformationFileConfigPayment.DATA_PAYMENT_WAY_CODE_NAME,
  //																			paymentWayCodeErrorMessageOption },
  //																	Locale.getDefault())));
  //						} else {
  //							/**
  //							 * 支払方法区分が正しい場合のみ、口座クレカIDチェック
  //							 */
  //							// 口座クレカID入力チェック
  //							// 支払方法がコンビニ収納で、かつ口座クレカIDが設定されている場合、エラー
  //							String accountCreditCardId = dataRecord
  //									.get(ContractManagementInformationFileConfigPayment.DATA_ACCOUNT_CREDIT_CARD_ID_INDEX);
  //							if (ECISCodeConstants.PAYMENT_WAY_CODE_CONVENI
  //									.equals(paymentWayCode)
  //									&& StringUtils
  //											.isNotEmpty(accountCreditCardId)) {
  //								dataRecordErrorList.add(StringConvertUtil
  //										.convertErrorListString(fileName,
  //												outputRowNumber,
  //												messageSource.getMessage(
  //														"error.E1009", null,
  //														Locale.getDefault())));
  //							}
  //							// 口座クレカID未入力チェック
  //							// 支払方法がコンビニ収納以外で、かつ口座クレカIDが設定されていない場合、エラー
  //							if (!ECISCodeConstants.PAYMENT_WAY_CODE_CONVENI
  //									.equals(paymentWayCode)
  //									&& StringUtils.isEmpty(accountCreditCardId)) {
  //								dataRecordErrorList.add(StringConvertUtil
  //										.convertErrorListString(fileName,
  //												outputRowNumber,
  //												messageSource.getMessage(
  //														"error.E1008", null,
  //														Locale.getDefault())));
  //							}
  //						}
  //					}
  //
  //					// 個人・法人区分コードチェック
  //					String individualLegalEntityCategoryCode = dataRecord
  //							.get(ContractManagementInformationFileConfigPayment.DATA_INDIVIDUAL_LEGAL_ENTITY_CATEGORY_CODE_INDEX);
  //					if (!StringUtils.isEmpty(individualLegalEntityCategoryCode)
  //							&& !individualLegalEntityCategoryMasterCodeCheckSet
  //									.contains(individualLegalEntityCategoryCode)) {
  //						dataRecordErrorList
  //								.add(StringConvertUtil.convertErrorListString(
  //										fileName,
  //										outputRowNumber,
  //										messageSource
  //												.getMessage(
  //														"validation.range",
  //														new String[] {
  //																ContractManagementInformationFileConfigPayment.DATA_INDIVIDUAL_LEGAL_ENTITY_CATEGORY_CODE_NAME,
  //																individualLegalEntityCategoryMasterCodeErrorMessageOption },
  //														Locale.getDefault())));
  //					}
  //
  //					// 請求先電話区分コードチェック
  //					String billingPhoneCategoryCode = dataRecord
  //							.get(ContractManagementInformationFileConfigPayment.DATA_BILLING_PHONE_CATEGORY_CODE_INDEX);
  //					if (!StringUtils.isEmpty(billingPhoneCategoryCode)
  //							&& !phoneNoCategoryMasterCodeCheckSet
  //									.contains(billingPhoneCategoryCode)) {
  //						dataRecordErrorList
  //								.add(StringConvertUtil.convertErrorListString(
  //										fileName,
  //										outputRowNumber,
  //										messageSource
  //												.getMessage(
  //														"validation.range",
  //														new String[] {
  //																ContractManagementInformationFileConfigPayment.DATA_BILLING_PHONE_CATEGORY_CODE_NAME,
  //																phoneNoCategoryMasterCodeErrorMessageOption },
  //														Locale.getDefault())));
  //					}
  //
  //					// 請求先情報チェック
  //					// Bean設定
  //					CheckBillingInformationUtilBean checkBillingInfoBean = new CheckBillingInformationUtilBean();
  //					// 個人・法人区分コード
  //					checkBillingInfoBean
  //							.setIndividualLegalEntityCategoryCode(dataRecord
  //									.get(ContractManagementInformationFileConfigPayment.DATA_INDIVIDUAL_LEGAL_ENTITY_CATEGORY_CODE_INDEX));
  //					// 請求先氏名1
  //					checkBillingInfoBean
  //							.setBillingName1(dataRecord
  //									.get(ContractManagementInformationFileConfigPayment.DATA_BILLING_NAME1_INDEX));
  //					// 請求先氏名2
  //					checkBillingInfoBean
  //							.setBillingName2(dataRecord
  //									.get(ContractManagementInformationFileConfigPayment.DATA_BILLING_NAME2_INDEX));
  //					// 敬称
  //					checkBillingInfoBean
  //							.setPrefix(dataRecord
  //									.get(ContractManagementInformationFileConfigPayment.DATA_PREFIX_INDEX));
  //					// 請求先住所（郵便番号）
  //					checkBillingInfoBean
  //							.setBillingAddressPostalCode(dataRecord
  //									.get(ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_POSTAL_CODE_INDEX));
  //					// 請求先住所（都道府県名）
  //					checkBillingInfoBean
  //							.setBillingAddressPrefectures(dataRecord
  //									.get(ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_PREFECTURES_INDEX));
  //					// 請求先住所（市区郡町村名）
  //					checkBillingInfoBean
  //							.setBillingAddressMunicipality(dataRecord
  //									.get(ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_MUNICIPALITY_INDEX));
  //					// 請求先住所（字名・丁目）
  //					checkBillingInfoBean
  //							.setBillingAddressSection(dataRecord
  //									.get(ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_SECTION_INDEX));
  //					// 請求先住所（番地･号）
  //					checkBillingInfoBean
  //							.setBillingAddressBlock(dataRecord
  //									.get(ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_BLOCK_INDEX));
  //					// 請求先住所（建物名）
  //					checkBillingInfoBean
  //							.setBillingAddressBuildingName(dataRecord
  //									.get(ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_BUILDING_NAME_INDEX));
  //					// 請求先住所（部屋名）
  //					checkBillingInfoBean
  //							.setBillingAddressRoom(dataRecord
  //									.get(ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_ROOM_INDEX));
  //					// 請求先電話番号
  //					checkBillingInfoBean
  //							.setBillingPhoneNo(dataRecord
  //									.get(ContractManagementInformationFileConfigPayment.DATA_BILLING_PHONE_NO_INDEX));
  //					// 請求先電話区分コード
  //					checkBillingInfoBean
  //							.setBillingPhoneCategoryCode1(dataRecord
  //									.get(ContractManagementInformationFileConfigPayment.DATA_BILLING_PHONE_CATEGORY_CODE_INDEX));
  //					// 請求先メールアドレス1
  //					checkBillingInfoBean
  //							.setBillingMailAddress1(dataRecord
  //									.get(ContractManagementInformationFileConfigPayment.DATA_BILLING_MAIL_ADDRESS1_INDEX));
  //					// 請求先メールアドレス2
  //					checkBillingInfoBean
  //							.setBillingMailAddress2(dataRecord
  //									.get(ContractManagementInformationFileConfigPayment.DATA_BILLING_MAIL_ADDRESS2_INDEX));
  //
  //					// 連絡先情報入力チェック
  //					if (!KJ_CommonUtil
  //							.checkBillDestinationInformation(checkBillingInfoBean)) {
  //						dataRecordErrorList.add(StringConvertUtil
  //								.convertErrorListString(fileName,
  //										outputRowNumber, messageSource
  //												.getMessage("error.E1047",
  //														null,
  //														Locale.getDefault())));
  //					}
  //
  //					// 請求先メールアドレス1、2のチェック
  //					if (!KJ_CommonUtil
  //							.checkMailAddressCorrelation(
  //									dataRecord
  //											.get(ContractManagementInformationFileConfigPayment.DATA_BILLING_MAIL_ADDRESS1_INDEX),
  //									dataRecord
  //											.get(ContractManagementInformationFileConfigPayment.DATA_BILLING_MAIL_ADDRESS2_INDEX))) {
  //						dataRecordErrorList.add(StringConvertUtil
  //								.convertErrorListString(fileName,
  //										outputRowNumber, messageSource
  //												.getMessage("error.E1220",
  //														null,
  //														Locale.getDefault())));
  //					}
  //				}
  //
  //				// データレコードエラーリストチェック
  //				if (!dataRecordErrorList.isEmpty()) {
  //					// データレコードエラーリストが存在する場合
  //					// 処理用オブジェクトには格納しない
  //					errorList.addAll(dataRecordErrorList);
  //					continue;
  //				}
  //
  //				// データレコード振分
  //				Map<Integer, String> resultDataRecordMap = new HashMap<Integer, String>(
  //						dataRecord);
  //				// 行番号設定
  //				// 実際の行数（インデックス＋１）を設定する
  //				resultDataRecordMap
  //						.put(ContractManagementInformationFileConfigCommon.DATA_ROW_NO_INDEX,
  //								String.valueOf(outputRowNumber));
  //				// 登録・更新・削除により振分
  //				if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER
  //						.equals(registerUpdateDeleteCategory)) {
  //					// 登録の場合、登録オブジェクトリストに追加
  //					registList.add(resultDataRecordMap);
  //				} else if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_UPDATE
  //						.equals(registerUpdateDeleteCategory)) {
  //					// 更新の場合、更新オブジェクトリストに追加
  //					updateList.add(resultDataRecordMap);
  //				} else if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_DELETE
  //						.equals(registerUpdateDeleteCategory)) {
  //					// 削除の場合、削除オブジェクトリストに追加
  //					deleteList.add(resultDataRecordMap);
  //				}
  //			}
  //
  //			// オブジェクト返却
  //			csvResultBean.setUploadFileName(fileName);
  //			csvResultBean.setErrorList(errorList);
  //			csvResultBean.setRegistList(registList);
  //			csvResultBean.setUpdateList(updateList);
  //			csvResultBean.setDeleteList(deleteList);
  //			return csvResultBean;
  //		} catch (Exception e) {
  //			throw new SystemException(e.getMessage(), e);
  //		}
  //	}
  //
  //	/**
  //	 * 支払方法チェック<br>
  //	 * 直営以外かつ全てが未入力かチェックし、入力されていたらエラー
  //	 *
  //	 * @param checkMap
  //	 * @return true チェックOK false チェックNG
  //	 */
  //	private boolean checkPaymentMethod(List<String> checkList,
  //			String provideModelCode, Integer accountCreditCardId) {
  //		if (!ECISCodeConstants.PROVIDE_MODEL_CODE_DIRECT_MANAGEMENT
  //				.equals(provideModelCode)
  //				&& (accountCreditCardId != null || !KJ_CommonUtil
  //						.checkKeyListIsNotEmpty(checkList))) {
  //			return false;
  //		}
  //
  //		return true;
  //	}
  //
  //	/**
  //	 * 請求作成チェックをする<br>
  //	 * 支払ID、支払適用開始日を条件に請求情報を検索し1件以上存在した場合エラーとする
  //	 *
  //	 * @param paymentId
  //	 *            支払ID
  //	 * @param paymentStartDate
  //	 *            支払適用開始日
  //	 * @return true チェックOK false チェックNG
  //	 */
  //	private boolean checkBillingCreation(Integer paymentId,
  //			Date paymentStartDate) {
  //		BlExample billingExample = new BlExample();
  //		billingExample.createCriteria().andPaymentIdEqualTo(paymentId)
  //				.andBlCreateDateGreaterThanOrEqualTo(paymentStartDate);
  //
  //		int cnt = blMapper.countByExample(billingExample);
  //
  //		// 1件以上存在
  //		if (cnt >= 1) {
  //			return false;
  //		}
  //
  //		return true;
  //
  //	}
  //
  //	/**
  //	 * 支払情報更新
  //	 *
  //	 * @param entity
  //	 * @param directDebitCreditCardNextMonthBillingFlag
  //	 * @param updateCount
  //	 * @param paymentId
  //	 * @return true 更新成功 false 更新失敗
  //	 */
  //	private boolean updatePayment(Payment entity, Integer paymentId,
  //			int updateCount, Timestamp sysDate) {
  //
  //		// 《支払Dao》.選択項目更新（主キー・更新回数）呼び出し
  //		PaymentExample updatePaymentExample = new PaymentExample();
  //		updatePaymentExample.createCriteria().andPaymentIdEqualTo(paymentId)
  //				.andUpdateCountEqualTo(updateCount);
  //		entity.setOnlineUpdateTime(sysDate);
  //		entity.setOnlineUpdateUserId(ThreadContext.getRequestThreadContext()
  //				.get(ECISConstants.USER_ID_KEY).toString());
  //		entity.setUpdateTime(sysDate);
  //		entity.setUpdateModuleCode(ThreadContext.getRequestThreadContext()
  //				.get(ECISConstants.CLASS_NAME_KEY).toString());
  //
  //		int updateByExampleSelectiveCnt = paymentMapper
  //				.updateByExampleSelective(entity, updatePaymentExample);
  //
  //		// 件数0
  //		if (updateByExampleSelectiveCnt == 0) {
  //			return false;
  //		}
  //
  //		return true;
  //	}
  //
  //	/**
  //	 * 支払履歴情報登録の呼び出しを行う
  //	 *
  //	 * @param entity
  //	 * @param bean
  //	 * @param paymentId
  //	 * @param sysdate
  //	 */
  //	private void insertPaymentHistory(PaymentHist entity,
  //			RegistPaymentBusinessBean bean, Integer paymentId, Timestamp sysdate) {
  //
  //		insertPaymentHistory(entity, paymentId, bean.getPaymentStartDate(),
  //				bean.getPaymentWayCode(), bean.getAccountCreditCardId(),
  //				bean.getIndividualLegalEntityCategoryCode(),
  //				bean.getBillingName1(), bean.getBillingName2(),
  //				bean.getPrefix(), bean.getBillingAddressPostalCode(),
  //				bean.getBillingAddressPrefectures(),
  //				bean.getBillingAddressMunicipality(),
  //				bean.getBillingAddressSection(), bean.getBillingAddressBlock(),
  //				bean.getBillingAddressBuildingName(),
  //				bean.getBillingAddressRoom(), bean.getBillingPhoneNo(),
  //				bean.getBillingPhoneCategoryCode(),
  //				bean.getBillingMailAddress1(), bean.getBillingMailAddress2(),
  //				sysdate);
  //	}
  //
  //	/**
  //	 * 支払履歴情報登録の呼び出しを行う
  //	 *
  //	 * @param entity
  //	 * @param bean
  //	 * @param paymentId
  //	 * @param sysdate
  //	 */
  //	private void insertPaymentHistory(PaymentHist paymentHist,
  //			UpdatePaymentBusinessBean bean,
  //			KJ_InquiryPaymentInformationEntityBean inquiryPaymentBusinessBean,
  //			Timestamp sysdate) {
  //
  //		String paymentWayCode = null;
  //		Integer acCreId = null;
  //		String ilcCode = null;
  //		String billingName1 = null;
  //		String prefix = null;
  //		String billingName2 = null;
  //		String billingAddressPostalCode = null;
  //		String billingAddressPrefectures = null;
  //		String billingAddressMunicipality = null;
  //		String billingAddressSection = null;
  //		String billingAddressBlock = null;
  //		String billingAddressBuildingName = null;
  //		String billingAddressRoom = null;
  //		String billingPhoneNo = null;
  //		String billingPhoneCategoryCode = null;
  //		String billingMailAddress1 = null;
  //		String billingMailAddress2 = null;
  //
  //		// nullの場合引き継ぐ項目の設定
  //		// 口座クレカID
  //		// 更新対象外フラグが0の時は入力Beanの内容で登録する
  //		if (ECISConstants.FLG_OFF
  //				.equals(bean.getAccountCreditCardIdNoUpdFlag())) {
  //			acCreId = bean.getAccountCreditCardId();
  //		} else
  //		// 更新対象外フラグが1の場合は前履歴から引き継ぐ
  //		if (ECISConstants.FLG_ON.equals(bean.getAccountCreditCardIdNoUpdFlag())) {
  //			acCreId = paymentHist.getAccountCreId();
  //		}
  //
  //		// 支払方法コード
  //		paymentWayCode = (String) setInheritingItem(bean.getPaymentWayCode(),
  //				paymentHist.getPwCode());
  //		// 請求先氏名1
  //		billingName1 = (String) setInheritingItem(bean.getBillingName1(),
  //				paymentHist.getBlName1());
  //		// 敬称
  //		prefix = (String) setInheritingItem(bean.getPrefix(),
  //				paymentHist.getPrefix());
  //		// 請求先住所（郵便番号）
  //		billingAddressPostalCode = (String) setInheritingItem(
  //				bean.getBillingAddressPostalCode(),
  //				paymentHist.getBlAddressPostalCode());
  //		// 請求先住所（都道府県名）
  //		billingAddressPrefectures = (String) setInheritingItem(
  //				bean.getBillingAddressPrefectures(),
  //				paymentHist.getBlAddressPrefectures());
  //		// 請求先住所（市区郡町村名）
  //		billingAddressMunicipality = (String) setInheritingItem(
  //				bean.getBillingAddressMunicipality(),
  //				paymentHist.getBlAddressMunicipality());
  //		// 請求先電話番号
  //		billingPhoneNo = (String) setInheritingItem(bean.getBillingPhoneNo(),
  //				paymentHist.getBlPhoneNo());
  //		// 請求先電話区分コード
  //		billingPhoneCategoryCode = (String) setInheritingItem(
  //				bean.getBillingPhoneCategoryCode(),
  //				paymentHist.getBlPhoneCatCode());
  //
  //		// 条件付必須項目
  //		// 個人・法人区分コードが入力されている場合
  //		if (bean.getIndividualLegalEntityCategoryCode() != null) {
  //			ilcCode = bean.getIndividualLegalEntityCategoryCode();
  //			billingName2 = bean.getBillingName2();
  //			billingAddressSection = bean.getBillingAddressSection();
  //			billingAddressBlock = bean.getBillingAddressBlock();
  //			billingAddressBuildingName = bean.getBillingAddressBuildingName();
  //			billingAddressRoom = bean.getBillingAddressRoom();
  //			billingMailAddress1 = bean.getBillingMailAddress1();
  //			billingMailAddress2 = bean.getBillingMailAddress2();
  //		} else {
  //			ilcCode = paymentHist.getIlcCode();
  //			billingName2 = paymentHist.getBlName2();
  //			billingAddressSection = paymentHist.getBlAddressSection();
  //			billingAddressBlock = paymentHist.getBlAddressBlock();
  //			billingAddressBuildingName = paymentHist.getBlAddressBuildingName();
  //			billingAddressRoom = paymentHist.getBlAddressRoom();
  //			billingMailAddress1 = paymentHist.getBlMailAddress1();
  //			billingMailAddress2 = paymentHist.getBlMailAddress2();
  //		}
  //
  //		insertPaymentHistory(paymentHist,
  //				inquiryPaymentBusinessBean.getPaymentId(),
  //				bean.getPaymentStartDate(), paymentWayCode, acCreId, ilcCode,
  //				billingName1, billingName2, prefix, billingAddressPostalCode,
  //				billingAddressPrefectures, billingAddressMunicipality,
  //				billingAddressSection, billingAddressBlock,
  //				billingAddressBuildingName, billingAddressRoom, billingPhoneNo,
  //				billingPhoneCategoryCode, billingMailAddress1,
  //				billingMailAddress2, sysdate);
  //	}
  // [kg-epj]<d-end>

  // [kg-epj]<d-start>
  //	/**
  //	 * ビーンに入力があった場合ビーン項目を、ない場合エンティティ項目を返す。
  //	 *
  //	 * @param beanItem
  //	 * @param oldHistItem
  //	 * @return
  //	 */
  //	public Object setInheritingItem(Object beanItem, Object oldHistItem) {
  //		// 入力ありの場合
  //		if (beanItem != null) {
  //			return beanItem;
  //		} else {
  //			// 入力なしの場合
  //			return oldHistItem;
  //		}
  //	}
  //
  //	/**
  //	 * 支払履歴情報登録を行う
  //	 *
  //	 * @param entity
  //	 * @param paymentId
  //	 * @param paymentSd
  //	 * @param pwCode
  //	 * @param accountCreId
  //	 * @param ilcCode
  //	 * @param blName1
  //	 * @param blName2
  //	 * @param prefix
  //	 * @param blAddressPostalCode
  //	 * @param blAddressPrefectures
  //	 * @param blAddressMunicipality
  //	 * @param blAddressSection
  //	 * @param blAddressBlock
  //	 * @param blAddressBuildingName
  //	 * @param blAddressRoom
  //	 * @param blPhoneNo
  //	 * @param blPhoneCatCode
  //	 * @param blMailAddress1
  //	 * @param blMailAddress2
  //	 * @param sysDate
  //	 */
  //	private void insertPaymentHistory(PaymentHist entity, Integer paymentId,
  //			Date paymentSd, String pwCode, Integer accountCreId,
  //			String ilcCode, String blName1, String blName2, String prefix,
  //			String blAddressPostalCode, String blAddressPrefectures,
  //			String blAddressMunicipality, String blAddressSection,
  //			String blAddressBlock, String blAddressBuildingName,
  //			String blAddressRoom, String blPhoneNo, String blPhoneCatCode,
  //			String blMailAddress1, String blMailAddress2, Timestamp sysDate) {
  //
  //		// 支払履歴情報登録
  //		entity.setPaymentId(paymentId);
  //		entity.setPaymentSd(paymentSd);
  //		entity.setPaymentEd(StringConvertUtil.stringToDate(
  //				ECISKJConstants.APPLY_END_DATE_MAX,
  //				ECISConstants.FORMAT_DATE_yyyyMMdd));
  //		entity.setPwCode(pwCode);
  //		entity.setAccountCreId(accountCreId);
  //		entity.setIlcCode(ilcCode);
  //		entity.setBlName1(blName1);
  //		entity.setBlName2(blName2);
  //		entity.setPrefix(prefix);
  //		entity.setBlAddressPostalCode(blAddressPostalCode);
  //		entity.setBlAddressPrefectures(blAddressPrefectures);
  //		entity.setBlAddressMunicipality(blAddressMunicipality);
  //		entity.setBlAddressSection(blAddressSection);
  //		entity.setBlAddressBlock(blAddressBlock);
  //		entity.setBlAddressBuildingName(blAddressBuildingName);
  //		entity.setBlAddressRoom(blAddressRoom);
  //		entity.setBlPhoneNo(blPhoneNo);
  //		entity.setBlPhoneCatCode(blPhoneCatCode);
  //		entity.setBlMailAddress1(blMailAddress1);
  //		entity.setBlMailAddress2(blMailAddress2);
  //		entity.setUpdateCount(INT_CNT_ZERO);
  //		entity.setCreateTime(sysDate);
  //		entity.setOnlineUpdateTime(sysDate);
  //		entity.setOnlineUpdateUserId(ThreadContext.getRequestThreadContext()
  //				.get(ECISConstants.USER_ID_KEY).toString());
  //		entity.setUpdateTime(sysDate);
  //		entity.setUpdateModuleCode(ThreadContext.getRequestThreadContext()
  //				.get(ECISConstants.CLASS_NAME_KEY).toString());
  //
  //		// インサート
  //		paymentHistMapper.insert(entity);
  //
  //		return;
  //	}
  //
  //	/**
  //	 * 支払履歴更新(削除メソッド用)
  //	 *
  //	 * @param entity
  //	 *            支払履歴エンティティ
  //	 * @param sysDate
  //	 *            システム日付
  //	 * @param paymentId
  //	 *            支払ID
  //	 * @param paymentStartDate
  //	 *            支払開始日
  //	 * @return true 更新成功 false 更新失敗
  //	 */
  //	private boolean updatePaymentHistoryUseDelete(PaymentHist entity,
  //			Timestamp sysDate, Integer paymentId, Date paymentStartDate,
  //			int updateCount) {
  //		entity.setOnlineUpdateTime(sysDate);
  //		entity.setOnlineUpdateUserId(ThreadContext.getRequestThreadContext()
  //				.get(ECISConstants.USER_ID_KEY).toString());
  //		entity.setUpdateTime(sysDate);
  //		entity.setUpdateModuleCode(ThreadContext.getRequestThreadContext()
  //				.get(ECISConstants.CLASS_NAME_KEY).toString());
  //
  //		PaymentHistExample paymentHistoryExample = new PaymentHistExample();
  //		paymentHistoryExample.createCriteria().andPaymentIdEqualTo(paymentId)
  //				.andPaymentSdEqualTo(paymentStartDate)
  //				.andUpdateCountEqualTo(updateCount);
  //
  //		int updateByExampleSelectiveCnt = paymentHistMapper
  //				.updateByExampleSelective(entity, paymentHistoryExample);
  //		// 返却値が0件の場合
  //		if (updateByExampleSelectiveCnt == 0) {
  //			return false;
  //		}
  //
  //		return true;
  //	}
  //
  //	/**
  //	 * 支払履歴更新(更新メソッド用)
  //	 *
  //	 * @param entity
  //	 *            支払履歴エンティティ
  //	 * @param sysDate
  //	 *            システム日付
  //	 * @param paymentId
  //	 *            支払ID
  //	 * @param paymentStartDate
  //	 *            支払開始日
  //	 * @param NoUpdFlag
  //	 *            更新対象外フラグ
  //	 * @return true 更新成功 false 更新失敗
  //	 */
  //	private boolean updatePaymentHistoryUseUpdate(PaymentHist entity,
  //			Timestamp sysDate, Integer paymentId, Date paymentStartDate,
  //			int updateCount, String noUpdFlag, Integer accountCreditCardId) {
  //
  //		// 更新対象外対応により、Mapper側での口座クレカIDの更新有無判定がnoUpdFlagになっているため
  //		// 口座クレカIDがnullでもnull更新されてしまうため設定する必要がある。
  //		entity.setAccountCreId(accountCreditCardId);
  //
  //		entity.setOnlineUpdateTime(sysDate);
  //		entity.setOnlineUpdateUserId(ThreadContext.getRequestThreadContext()
  //				.get(ECISConstants.USER_ID_KEY).toString());
  //		entity.setUpdateTime(sysDate);
  //		entity.setUpdateModuleCode(ThreadContext.getRequestThreadContext()
  //				.get(ECISConstants.CLASS_NAME_KEY).toString());
  //
  //		Map<String, Object> exampleMap = new HashMap<String, Object>();
  //
  //		// 更新対象外対応
  //		exampleMap.put("accountCreditCardIdNoUpdFlag", noUpdFlag);
  //
  //		exampleMap.put("conditionPaymentId", paymentId);
  //		exampleMap.put("conditionPaymentStartDate", paymentStartDate);
  //		exampleMap.put("conditionUpdateCount", updateCount);
  //
  //		int updateByExampleSelectiveCnt = paymentHistMapper
  //				.updateByNoUpdFlagSelective(entity, exampleMap);
  //		// 返却値が0件の場合
  //		if (updateByExampleSelectiveCnt == 0) {
  //			return false;
  //		}
  //
  //		return true;
  //	}
  //
  //	/**
  //	 * 支払情報照会ビジネスビーンのリターンコードとメッセージを設定する。
  //	 *
  //	 * @param prop
  //	 *            プロパティ
  //	 * @param bean
  //	 *            支払情報照会ビジネスビーン
  //	 * @param returnCode
  //	 *            リターンコード
  //	 */
  //	private void setMessageAndReturnCode(InquiryPaymentBusinessBean bean,
  //			String returnCode) throws NoSuchMessageException {
  //
  //		bean.setReturnCode(returnCode);
  //		bean.setMessage(getPropertiesMesseage(returnCode));
  //
  //	}
  //// [kg-epj]<d-start>
  //	/**
  //	 * 支払情報登録ビジネスビーンのリターンコードとメッセージを設定する。
  //	 *
  //	 * @param prop
  //	 *            プロパティ
  //	 * @param bean
  //	 *            支払情報登録ビジネスビーン
  //	 * @param returnCode
  //	 *            リターンコード
  //	 */
  //	private void setMessageAndReturnCode(RegistPaymentBusinessBean bean,
  //			String returnCode) throws NoSuchMessageException {
  //
  //		bean.setReturnCode(returnCode);
  //		bean.setMessage(getPropertiesMesseage(returnCode));
  //
  //	}
  //
  //	/**
  //	 * 支払情報更新ビジネスビーンのリターンコードとメッセージを設定する。
  //	 *
  //	 * @param prop
  //	 *            プロパティ
  //	 * @param bean
  //	 *            支払情報更新ビジネスビーン
  //	 * @param returnCode
  //	 *            リターンコード
  //	 */
  //	private void setMessageAndReturnCode(UpdatePaymentBusinessBean bean,
  //			String returnCode) throws NoSuchMessageException {
  //
  //		bean.setReturnCode(returnCode);
  //		bean.setMessage(getPropertiesMesseage(returnCode));
  //
  //	}
  //
  //	/**
  //	 * 支払情報削除ビジネスビーンのリターンコードとメッセージを設定する。
  //	 *
  //	 * @param prop
  //	 *            プロパティ
  //	 * @param bean
  //	 *            支払情報削除ビジネスビーン
  //	 * @param returnCode
  //	 *            リターンコード
  //	 */
  //	private void setMessageAndReturnCode(DeletePaymentBusinessBean bean,
  //			String returnCode) throws NoSuchMessageException {
  //
  //		bean.setReturnCode(returnCode);
  //		bean.setMessage(getPropertiesMesseage(returnCode));
  //
  //	}
  // [kg-epj]<d-end>
  // [kg-epj]<i-start>
  /**
   * 支払情報照会ビジネスビーンのリターンコードとメッセージを設定する。
   *
   * @param prop
   *          プロパティ
   * @param bean
   *          支払情報照会ビジネスビーン
   * @param returnCode
   *          リターンコード
   */
  private void setMessageAndReturnCode(Custom_InquiryPaymentBusinessBean bean,
      String returnCode) throws NoSuchMessageException {

    bean.setReturnCode(returnCode);
    bean.setMessage(getPropertiesMesseage(returnCode));

  }

  // [kg-epj]<i-end>
  /**
   * プロパティからリターンコードに対応するメッセージを取得する
   *
   * @param prop
   *          プロパティ
   * @param returnCode
   *          リターンコード
   * @return
   */
  private String getPropertiesMesseage(String returnCode)
      throws NoSuchMessageException {
    return messageSource.getMessage(KJ_CommonUtil.getMessageId(returnCode),
        new String[] {}, Locale.getDefault());
  }

  // [kg-epj]<d-start>
  //	/**
  //	 * 利用不能フラグチェック<br>
  //	 * 利用不能フラグが“ON”かチェックする
  //	 *
  //	 * @param visualizationProvideFlag
  //	 * @return true = チェックOK false = チェックNG
  //	 */
  //	private boolean checkUnavailableFlag(String visualizationProvideFlag) {
  //		if (ECISKJConstants.UNAVAILABLE_FLAG_USE_IMPOSSIBLE
  //				.equals(visualizationProvideFlag)) {
  //
  //			return false;
  //		}
  //		return true;
  //	}
  //
  //	/**
  //	 * Bean.支払方法コード、Bean.個人・法人区分コード、Bean.請求先電話区分コードのコード値存在チェックを行う
  //	 *
  //	 * @param paymentWayCode
  //	 * @param individualLegalEntityCategoryCode
  //	 * @param billingPhoneCategoryCode
  //	 * @return リターンコード = エラー null = 存在
  //	 */
  //	private String checkMasterCode(String paymentWayCode,
  //			String individualLegalEntityCategoryCode,
  //			String billingPhoneCategoryCode) {
  //		// 《支払情報登録BusinessBean》.支払方法コードがNULLまたは空文字のいずれかでない場合
  //		if (StringUtils.isNotEmpty(paymentWayCode)) {
  //			// 返却値が0件の場合
  //
  //			PwM paymentWayMaster = new PwM();
  //			paymentWayMaster = pwMMapper.selectByPrimaryKey(paymentWayCode);
  //
  //			// 返却値が0件の場合
  //			if (paymentWayMaster == null) {
  //				return ECISReturnCodeConstants.RETURN_CODE_P013;
  //			}
  //		}
  //
  //		// 《支払情報登録BusinessBean》.個人・法人区分コードがNULLまたは空文字のいずれかでない場合
  //		if (StringUtils.isNotEmpty(individualLegalEntityCategoryCode)) {
  //			IlcM individualLegalEntityCategoryMaster = new IlcM();
  //			individualLegalEntityCategoryMaster = ilcMMapper
  //					.selectByPrimaryKey(individualLegalEntityCategoryCode);
  //
  //			// 返却値が0件の場合
  //			if (individualLegalEntityCategoryMaster == null) {
  //				return ECISReturnCodeConstants.RETURN_CODE_P021;
  //			}
  //		}
  //
  //		// 《支払情報登録BusinessBean》.請求先電話区分コードがNULLまたは空文字のいずれかでない場合
  //		if (StringUtils.isNotEmpty(billingPhoneCategoryCode)) {
  //			PhoneNoCatM phoneNoCategoryMaster = new PhoneNoCatM();
  //			phoneNoCategoryMaster = phoneNoCatMMapper
  //					.selectByPrimaryKey(billingPhoneCategoryCode);
  //
  //			// 返却値が0件の場合
  //			if (phoneNoCategoryMaster == null) {
  //				return ECISReturnCodeConstants.RETURN_CODE_P019;
  //			}
  //		}
  //
  //		return null;
  //	}
  //
  //	/**
  //	 * 提供モデルコードが直営かつ支払方法コードがブランク、NULLかチェックする。
  //	 *
  //	 * @return true = チェックOK false = チェックNG
  //	 */
  //	private boolean checkDMPaymentWay(String directManagement, String paymentWay) {
  //		if (ECISCodeConstants.PROVIDE_MODEL_CODE_DIRECT_MANAGEMENT
  //				.equals(directManagement) && StringUtils.isEmpty(paymentWay)) {
  //			return false;
  //		}
  //
  //		return true;
  //	}
  //
  //	/**
  //	 * 支払情報マッパーのセッター(DI)
  //	 *
  //	 * @param 支払情報マッパー
  //	 */
  //	public void setPaymentMapper(PaymentMapper paymentMapper) {
  //		this.paymentMapper = paymentMapper;
  //	}
  //
  //	/**
  //	 * 請求情報マッパーのセッター(DI)
  //	 *
  //	 * @param 請求情報マッパー
  //	 */
  //	public void setBillingMapper(BlMapper billingMapper) {
  //		this.blMapper = billingMapper;
  //	}
  //
  //	/**
  //	 * 支払情報共通マッパーのセッター(DI)
  //	 *
  //	 * @param 支払情報共通マッパー
  //	 */
  //	public void setPaymentInformationCommonMapper(
  //			PaymentInformationCommonMapper paymentInformationCommonMapper) {
  //		this.paymentInformationCommonMapper = paymentInformationCommonMapper;
  //	}
  // [kg-epj]<d-end>
  // [kg-epj]<i-start>
  /**
   * 支払情報共通マッパーのセッター(DI)
   *
   * @param 支払情報共通マッパー
   */
  public void setCustomPaymentInformationCommonMapper(
      Custom_PaymentInformationCommonMapper customPaymentInformationCommonMapper) {
    this.customPaymentInformationCommonMapper = customPaymentInformationCommonMapper;
  }
  // [kg-epj]<i-end>
  // [kg-epj]<d-start>
  //	/**
  //	 * 支払履歴情報マッパーのセッター(DI)
  //	 *
  //	 * @param 支払履歴情報マッパー
  //	 */
  //	public void setPaymentHistoryMapper(PaymentHistMapper paymentHistoryMapper) {
  //		this.paymentHistMapper = paymentHistoryMapper;
  //	}
  //
  //	/**
  //	 * 口座クレカ情報マッパーのセッター(DI)
  //	 *
  //	 * @param 口座クレカ情報マッパー
  //	 */
  //	public void setAccountCreditInformationMapper(
  //			AcInformationMapper accountCreditInformationMapper) {
  //		this.acInformationMapper = accountCreditInformationMapper;
  //	}
  //
  //	/**
  //	 * 支払方法マスタマッパーのセッター(DI)
  //	 *
  //	 * @param 支払方法マスタマッパー
  //	 */
  //	public void setPaymentWayMasterMapper(PwMMapper paymentWayMasterMapper) {
  //		this.pwMMapper = paymentWayMasterMapper;
  //	}
  //
  //	/**
  //	 * 個人・法人区分マスタマッパーのセッター(DI)
  //	 *
  //	 * @param 個人・法人区分マスタマッパー
  //	 */
  //	public void setIndividualLegalEntityCategoryMasterMapper(
  //			IlcMMapper individualLegalEntityCategoryMasterMapper) {
  //		this.ilcMMapper = individualLegalEntityCategoryMasterMapper;
  //	}
  //
  //	/**
  //	 * 電話番号区分マッパーのセッター(DI)
  //	 *
  //	 * @param 電話番号区分マッパー
  //	 */
  //	public void setPhoneNoCategoryMasterMapper(
  //			PhoneNoCatMMapper phoneNoCategoryMasterMapper) {
  //		this.phoneNoCatMMapper = phoneNoCategoryMasterMapper;
  //	}
  //
  //	/**
  //	 * 契約者情報照会ビジネスのセッター(DI)
  //	 *
  //	 * @param 契約者情報照会ビジネス
  //	 */
  //	public void setKjContractorInformationBusiness(
  //			KJ_ContractorInformationBusiness kjContractorInformationBusiness) {
  //		this.kjContractorInformationBusiness = kjContractorInformationBusiness;
  //	}
  //
  //	/**
  //	 * 契約情報照会ビジネスのセッター(DI)
  //	 *
  //	 * @param 契約情報照会ビジネス
  //	 */
  //	public void setKjContractInformationBusiness(
  //			KJ_ContractInformationBusiness kjContractInformationBusiness) {
  //		this.kjContractInformationBusiness = kjContractInformationBusiness;
  //	}
  //
  //	/**
  //	 * 日付関連共通ビジネスのセッター(DI)
  //	 *
  //	 * @param 日付関連共通ビジネス
  //	 */
  //	public void setDateBusiness(DateBusiness dateBusiness) {
  //		this.dateBusiness = dateBusiness;
  //	}
  // [kg-epj]<d-end>

  /**
   * メッセージプロパティのセッター(DI)
   *
   * @param メッセージプロパティ
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }
  // [kg-epj]<d-start>
  //	/**
  //	 * 契約管理情報ファイルヘッダーバリデーターのセッター(DI)
  //	 *
  //	 * @param contractManagementInformationFileHeaderValidator
  //	 *            契約管理情報ファイルヘッダーバリデーター
  //	 *
  //	 */
  //	public void setContractManagementInformationFileHeaderValidator(
  //			ContractManagementInformationFileHeaderValidator contractManagementInformationFileHeaderValidator) {
  //		this.contractManagementInformationFileHeaderValidator = contractManagementInformationFileHeaderValidator;
  //	}
  //
  //	/**
  //	 * 支払情報ファイル登録バリデーターのセッター(DI)
  //	 *
  //	 * @param paymentInformationFileRegistValidator
  //	 *            支払情報ファイル登録バリデーター
  //	 *
  //	 */
  //	public void setPaymentInformationFileRegistValidator(
  //			PaymentInformationFileRegistValidator paymentInformationFileRegistValidator) {
  //		this.paymentInformationFileRegistValidator = paymentInformationFileRegistValidator;
  //	}
  //
  //	/**
  //	 * 支払情報ファイル更新バリデーターのセッター(DI)
  //	 *
  //	 * @param paymentInformationFileUpdateValidator
  //	 *            支払情報ファイル更新バリデーター
  //	 *
  //	 */
  //	public void setPaymentInformationFileUpdateValidator(
  //			PaymentInformationFileUpdateValidator paymentInformationFileUpdateValidator) {
  //		this.paymentInformationFileUpdateValidator = paymentInformationFileUpdateValidator;
  //	}
  //
  //	/**
  //	 * 支払情報ファイル削除バリデーターのセッター(DI)
  //	 *
  //	 * @param paymentInformationFileDeleteValidator
  //	 *            支払情報ファイル削除バリデーター
  //	 *
  //	 */
  //	public void setPaymentInformationFileDeleteValidator(
  //			PaymentInformationFileDeleteValidator paymentInformationFileDeleteValidator) {
  //		this.paymentInformationFileDeleteValidator = paymentInformationFileDeleteValidator;
  //	}
  // [kg-epj]<d-end>
}
