package jp.co.unisys.enability.cis.business.sn;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import jp.co.unisys.enability.cis.entity.common.Fcr;
import jp.co.unisys.enability.cis.entity.sn.SN_CreatingBillingTargetEntityBean;

/**
 * 請求入金共通請求作成ビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public interface SN_CreatingBillingCommonBusiness {

  /**
   * 請求作成対象候補編集処理。
   *
   * <pre>
   * <p><b>【内部仕様】</b></p>
   * 《請求作成対象候補EntityBean》リストからMAP<支払ID, MAP<契約ID, 《請求作成対象候補EntityBean》>>を生成する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param beanList
   *          請求作成対象候補EntityBeanリスト
   * @return Map<Integer, Map<Integer, CreatingBillingTargetEntityBean>> Map<支払ID, Map<契約ID, 《請求作成対象候補EntityBean》>>
   */
  Map<Integer, Map<Integer, SN_CreatingBillingTargetEntityBean>> createBillingTarget(
      List<SN_CreatingBillingTargetEntityBean> beanList);

  /**
   * 削除判定処理。
   *
   * <pre>
   * <p><b>【内部仕様】</b></p>
   * ”未収”確定していない【請求】の確認。
   * 債権回収対象となる【契約】の確認。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param map
   *          Map<支払ID, Map<契約ID, 《請求作成対象候補EntityBean》>>
   */
  void removeCreatingBillingTarget(
      Map<Integer, Map<Integer, SN_CreatingBillingTargetEntityBean>> map);

  /**
   * 削除判定処理（まとめ用）。
   *
   * <pre>
   * <p><b>【内部仕様】</b></p>
   * 料金ステータスコード <> ”確定”の確認。
   * 請求番号 <> 空白の確認。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param map
   *          Map<支払ID, Map<契約ID, 《請求作成対象候補EntityBean》>>
   * @param batchDate
   *          バッチ処理基準日
   */
  void removeCreatingBillingTargetSummary(
      Map<Integer, Map<Integer, SN_CreatingBillingTargetEntityBean>> map,
      String batchDate);

  /**
   * 月額料金合計値算出処理。
   *
   * <pre>
   * <p><b>【内部仕様】</b></p>
   * 当該支払の月額料金合計値算出
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param fcrList
   *          確定料金実績EntityBeanリスト
   * @return BigDecimal 月額料金合計
   */
  BigDecimal calculationMonthlyCharge(List<Fcr> fcrList);

}
