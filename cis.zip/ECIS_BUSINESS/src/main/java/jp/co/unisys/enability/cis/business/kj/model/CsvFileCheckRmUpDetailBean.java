package jp.co.unisys.enability.cis.business.kj.model;

/**
 * 契約情報CSVファイルチェック料金メニュー単価明細Bean
 *
 * <pre>
 * 料金メニュー単価明細Bean
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class CsvFileCheckRmUpDetailBean {

  /**
   * DCEC区分コードを保有する。
   */
  private String dcecCatCode;

  /**
   * 時間帯コードを保有する。
   */
  private String tsCode;

  /**
   * 枝番を保有する。
   */
  private String branchNo;

  /**
   * DCEC区分コードのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * DCEC区分コードを取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return DCEC区分コード
   */
  public String getDcecCatCode() {
    return dcecCatCode;
  }

  /**
   * DCEC区分コードのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * DCEC区分コードを設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param uploadFileName
   *          DCEC区分コード
   */
  public void setDcecCatCode(String dcecCatCode) {
    this.dcecCatCode = dcecCatCode;
  }

  /**
   * 時間帯コードのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 時間帯コードを取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 時間帯コード
   */
  public String getTsCode() {
    return tsCode;
  }

  /**
   * 時間帯コードのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 時間帯コードを設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param tsCode
   *          時間帯コード
   */
  public void setTsCode(String tsCode) {
    this.tsCode = tsCode;
  }

  /**
   * 枝番のgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 枝番を取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 枝番
   */
  public String getBranchNo() {
    return branchNo;
  }

  /**
   * 枝番のsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 枝番を設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param branchNo
   *          枝番
   */
  public void setBranchNo(String branchNo) {
    this.branchNo = branchNo;
  }

}
