package jp.co.unisys.enability.cis.business.common;

import java.util.Date;

/**
 * 日付関連共通ビジネスインタフェース。
 *
 * <pre>
 * <p><b>【仕様詳細】<b><p>
 * 共通的な以下の日付関連機能を扱う。
 * ・処理基準日取得
 * ・業務日付計算
 * ・月初営業日取得
 * ・月末営業日取得
 * </pre>
 *
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.common.DateBusinessImpl
 *
 */
public interface DateBusiness {

  /**
   * 処理基準日取得。
   *
   * <pre>
   * <p><b>【仕様詳細】<b><p>
   * 引数の処理基準日コードを基に、【処理基準日マスタ】より処理基準日を取得し、返却する。
   * 処理基準日コードがオンライン処理基準日（0）、バッチ処理基準日（1）の
   * いずれにも該当しない場合、システム例外をスローする。
   * </pre>
   *
   * @param code
   *          0:オンライン処理基準日、1:バッチ処理基準日
   * @return 処理基準日
   */
  Date getProcessBaseDate(String code);

  /**
   * 業務日付計算。
   *
   * <pre>
   * <p><b>【仕様詳細】<b><p>
   * １．引数の業務日数コードを基に、【業務日数マスタ】より業務日数情報を取得する。
   *
   * ２．業務日数情報の日数区分を参照し、区分毎に以下の処理を行う。
   *     a）{@link jp.co.unisys.enability.cis.common.util.constants.ECISConstants#WORK_DAYS_CATEGORY_CALENDAR 暦日}の場合
   *       引数の基準日に、業務日数情報の日数を足し、補正基日付を算出する。
   *       返却用業務日付に補正基日付を設定する。
   *     b）{@link jp.co.unisys.enability.cis.common.util.constants.ECISConstants#WORK_DAYS_CATEGORY_ENNET エネット営業日}の場合
   *       引数の基準日、業務日数情報の日数、事業者休日区分（{@link jp.co.unisys.enability.cis.common.util.constants.ECISConstants#OPERATOR_HOLIDAY 事業者休日}）を引数とし、
   *       {@link jp.co.unisys.enability.cis.business.gk.CalendarBusiness#calculateSalesDate(jp.co.unisys.enability.cis.business.gk.model.CalendarBusinessBean) カレンダー関連機能共通処理の営業日付計算} を呼び出す。
   *       補正基日付に計算結果日付を設定する。
   *       返却用業務日付に補正基日付を設定する。
   *     c）{@link jp.co.unisys.enability.cis.common.util.constants.ECISConstants#WORK_DAYS_CATEGORY_FINANCIAL 金融機関営業日}の場合
   *       引数の基準日、業務日数情報の日数、事業者休日区分（{@link jp.co.unisys.enability.cis.common.util.constants.ECISConstants#BANK_HOLIDAY 金融機関休日}）を引数とし、
   *       {@link jp.co.unisys.enability.cis.business.gk.CalendarBusiness#calculateSalesDate(jp.co.unisys.enability.cis.business.gk.model.CalendarBusinessBean) カレンダー関連機能共通処理の営業日付計算} を呼び出す。
   *       補正基日付に計算結果日付を設定する。
   *       返却用業務日付に補正基日付を設定する。
   *     d）上記以外の場合
   *       システム例外をスローする。
   *
   * ３．補正期間日数に0を指定する。
   *
   * ４．業務日数情報の算出日区分を参照し、区分毎に以下の処理を行う。
   *     a）{@link jp.co.unisys.enability.cis.common.util.constants.ECISConstants#WORK_DAYS_CATEGORY_CALENDAR 暦日}の場合
   *       日数区分で既に計算が行われているため、算出日区分が暦日の場合は何も処理を行わない。
   *     b）{@link jp.co.unisys.enability.cis.common.util.constants.ECISConstants#WORK_DAYS_CATEGORY_ENNET エネット営業日}の場合
   *       日数区分がエネット営業日でない場合のみ、下記の処理を行う。
   *       補正基日付、事業者休日区分（{@link jp.co.unisys.enability.cis.common.util.constants.ECISConstants#OPERATOR_HOLIDAY 事業者休日}）を引数とし、
   *       {@link jp.co.unisys.enability.cis.business.gk.CalendarBusiness#calculateSalesDate(jp.co.unisys.enability.cis.business.gk.model.CalendarBusinessBean) カレンダー関連機能共通処理の営業日付計算} を呼び出す。
   *       返却用業務日付に補正基日付を設定する。
   *     c）{@link jp.co.unisys.enability.cis.common.util.constants.ECISConstants#WORK_DAYS_CATEGORY_FINANCIAL 金融機関営業日}の場合
   *       日数区分が金融機関営業日でない場合のみ、下記の処理を行う。
   *       補正基日付、事業者休日区分（{@link jp.co.unisys.enability.cis.common.util.constants.ECISConstants#BANK_HOLIDAY 金融機関休日}）を引数とし、
   *       {@link jp.co.unisys.enability.cis.business.gk.CalendarBusiness#calculateSalesDate(jp.co.unisys.enability.cis.business.gk.model.CalendarBusinessBean)
   *       カレンダー関連機能共通処理の営業日付計算} を呼び出す。
   *       返却用業務日付に補正基日付を設定する。
   *     d）上記以外の場合
   *       システム例外をスローする。
   *
   * ５．上記処理により算出した業務日付を返却する。
   * </pre>
   *
   * @param baseDate
   *          基準日
   * @param workDaysCode
   *          業務日数コード
   * @return 業務日付
   */
  Date calcWorkDate(Date baseDate, String workDaysCode);

  /**
   * 月初営業日取得。
   *
   * <pre>
   * <p><b>【仕様詳細】<b><p>
   * 引数の基準日を当該月の1日に補正し、
   * 補正後日付、計算期間日数（0）、事業者休日区分（エネット営業日）を引数とし、
   * {@link jp.co.unisys.enability.cis.business.gk.CalendarBusiness#calculateSalesDate(jp.co.unisys.enability.cis.business.gk.model.CalendarBusinessBean)
   * カレンダー関連機能共通処理の営業日付計算} を呼び出す。
   * 上記処理により、算出した日付を月初営業日として返却する。
   * </pre>
   *
   * @param baseDate
   *          基準日
   * @return 月初営業日
   */
  Date getWorkDayforMonthBegin(Date baseDate);

  /**
   * 月末営業日取得。
   *
   * <pre>
   * <p><b>【仕様詳細】<b><p>
   * 引数の基準日を翌月の1日に補正し、
   * 補正後日付、計算期間日数（-1）、事業者休日区分（エネット営業日）を引数とし、
   * {@link jp.co.unisys.enability.cis.business.gk.CalendarBusiness#calculateSalesDate(jp.co.unisys.enability.cis.business.gk.model.CalendarBusinessBean)
   * カレンダー関連機能共通処理の営業日付計算} を呼び出す。
   * 上記処理により、算出した日付を月末営業日として返却する。
   * </pre>
   *
   * @param baseDate
   *          基準日
   * @return 月末営業日
   */
  Date getWorkDayforMonthEnd(Date baseDate);

  /**
   * バッチ実行日取得。
   *
   * <pre>
   * <p><b>【仕様詳細】<b><p>
   * 引数のバッチ処理基準日に対して判定を行い、設定済み（null以外）の場合、
   * 引数で指定された日付をバッチ実行日として返却する。また、未設定（null）の場合、
   * 処理基準日取得を呼び出し、取得した日付をバッチ実行日として返却する。
   * </pre>
   *
   * @param processBaseDate
   *          バッチ処理基準日
   * @return バッチ実行日
   */
  Date getBatchEffectiveDate(String processBaseDate);

}
