package jp.co.unisys.enability.cis.business.kj.model;

import java.util.List;

import jp.co.unisys.enability.cis.entity.common.CContractor;

/**
 * カスタム契約者情報照会BusinessBean
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * カスタム契約者情報ビジネス
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 *
 *         変更履歴(kg-epj) 2016.02.05 ko 新規作成
 */
public class Custom_InquiryCustomContractorBusinessBean {

  /**
   * 契約者IDを保有する。
   */
  private Integer contractorId;

  /**
   * カスタム契約者情報リストを保有する。
   */
  private List<CContractor> customContractorInformationList;

  /**
   * リターンコードを保有する。
   */
  private String returnCode;

  /**
   * メッセージを保有する。
   */
  private String message;

  /**
   * 契約者IDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者IDを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者ID
   */
  public Integer getContractorId() {
    return this.contractorId;
  }

  /**
   * 契約者IDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者IDを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorId
   *          契約者ID
   */
  public void setContractorId(Integer contractorId) {
    this.contractorId = contractorId;
  }

  /**
   * カスタム契約者情報リストのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * カスタム契約者情報リストを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return カスタム契約者情報リスト
   */
  public List<CContractor> getCustomContractorInformationList() {
    return this.customContractorInformationList;
  }

  /**
   * カスタム契約者情報リストのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * カスタム契約者情報リストを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param customContractorInformationList
   *          カスタム契約者情報リスト
   */
  public void setCustomContractorInformationList(List<CContractor> customContractorInformationList) {
    this.customContractorInformationList = customContractorInformationList;
  }

  /**
   * リターンコードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return リターンコード
   */
  public String getReturnCode() {
    return this.returnCode;
  }

  /**
   * リターンコードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param returnCode
   *          リターンコード
   */
  public void setReturnCode(String returnCode) {
    this.returnCode = returnCode;
  }

  /**
   * メッセージのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return メッセージ
   */
  public String getMessage() {
    return this.message;
  }

  /**
   * メッセージのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param message
   *          メッセージ
   */
  public void setMessage(String message) {
    this.message = message;
  }
}