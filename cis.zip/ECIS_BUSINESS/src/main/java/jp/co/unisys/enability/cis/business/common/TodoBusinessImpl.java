package jp.co.unisys.enability.cis.business.common;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;

import jp.co.unisys.enability.cis.business.common.model.TodoBusinessBean;
import jp.co.unisys.enability.cis.common.util.ThreadContext;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.entity.common.Contract;
import jp.co.unisys.enability.cis.entity.common.ContractExample;
import jp.co.unisys.enability.cis.entity.common.Contractor;
import jp.co.unisys.enability.cis.entity.common.Ml;
import jp.co.unisys.enability.cis.entity.common.MlContractHist;
import jp.co.unisys.enability.cis.entity.common.MlContractHistExample;
import jp.co.unisys.enability.cis.entity.common.Todo;
import jp.co.unisys.enability.cis.mapper.common.ContractMapper;
import jp.co.unisys.enability.cis.mapper.common.ContractorMapper;
import jp.co.unisys.enability.cis.mapper.common.MlContractHistMapper;
import jp.co.unisys.enability.cis.mapper.common.MlMapper;
import jp.co.unisys.enability.cis.mapper.common.TodoMapper;

/**
 * TODO共通ビジネスクラス
 *
 * <pre>
 * <p><b>【仕様詳細】<b><p>
 * TODOテーブルへの操作を行う。
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.mapper.common.TodoMapper
 */
public class TodoBusinessImpl implements TodoBusiness {

  /** TODOマッパー */
  private TodoMapper todoMapper;
  
  /** 契約マッパー */
  private ContractMapper contractMapper;

  /** 契約者マッパー */
  private ContractorMapper contractorMapper;

  /** メータ設置場所契約履歴マッパー */
  private MlContractHistMapper mlContractHistMapper;

  /** メータ設置場所マッパー */
  private MlMapper mlMapper;

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.common.TodoBusiness#registTodo(jp
   * .co.unisys.enability.cis.business.common.model.TodoBusinessBean)
   */
  @Override
  public void registTodo(TodoBusinessBean todoBean) {
  
    Contract contract = null;

    // 契約番号が設定されているが、契約者番号または地点特定番号が未設定の場合
    if (!StringUtils.isEmpty(todoBean.getContractNo())
        && (StringUtils.isEmpty(todoBean.getContractorNo()) || StringUtils.isEmpty(todoBean
            .getSpotNo()))) {

      // 契約情報取得
      ContractExample contractExample = new ContractExample();
      contractExample.createCriteria().andContractNoEqualTo(todoBean.getContractNo());
      List<Contract> contracts = contractMapper.selectByExample(contractExample);
      if (!CollectionUtils.isEmpty(contracts)) {
        contract = contracts.get(0);
      }
    }

    // 契約情報が存在、契約者番号が未設定の場合
    if (Objects.nonNull(contract) && StringUtils.isEmpty(todoBean.getContractorNo())) {

      // 契約者情報取得
      Contractor contractor = contractorMapper.selectByPrimaryKey(contract.getContractorId());
      if (Objects.nonNull(contractor)) {
        // 契約者番号を設定
        todoBean.setContractorNo(contractor.getContractorNo());
      }
    }

    // 契約情報が存在、地点特定番号が未設定の場合
    if (Objects.nonNull(contract) && StringUtils.isEmpty(todoBean.getSpotNo())) {

      // メータ設置場所契約履歴情報取得
      MlContractHistExample mlContractHisExample = new MlContractHistExample();
      mlContractHisExample.createCriteria().andContractIdEqualTo(contract.getContractId());
      List<MlContractHist> mlContractHistList = mlContractHistMapper.selectByExample(mlContractHisExample);

      if (!CollectionUtils.isEmpty(mlContractHistList)) {

        // メータ設置場所取得
        Ml ml = mlMapper.selectByPrimaryKey(mlContractHistList.get(0).getMlId());
        if (Objects.nonNull(ml)) {
          // 地点特定番号を設定
          todoBean.setSpotNo(ml.getSpotNo());
        }
      }
    }

    Todo todoInfo = new Todo();

    // システム日時の取得
    Date sysDate = new Date();
    Timestamp systime = new Timestamp(sysDate.getTime());

    // オンラインフラグの取得
    String onlineFlg = ThreadContext.getRequestThreadContext()
        .get(ECISConstants.ONLINE_FLAG_KEY).toString();

    // 発生日時
    todoInfo.setAccrualTime(systime);

    // 更新日　未設定
    todoInfo.setUpdateDate(null);
    
    // 契約者番号
    todoInfo.setContractorNo(todoBean.getContractorNo());

    // 契約番号
    todoInfo.setContractNo(todoBean.getContractNo());

    // 地点特定番号
    todoInfo.setSpotNo(todoBean.getSpotNo());

    // 次回検針予定日
    todoInfo.setNextMrScheduledDate(todoBean.getNextMrScheduledDate());

    // サブシステムID
    todoInfo.setSsysId(todoBean.getSubsystemId());

    // 機能ID
    todoInfo.setFunctionId(todoBean.getFunctionId());

    // メッセージID
    todoInfo.setMessageId(todoBean.getMessageId());

    // TODO検索キー 機能ID＋メッセージID
    todoInfo.setTodoSearchKey(StringUtils.join(todoBean.getFunctionId(),
        todoBean.getMessageId()));

    // メッセージ
    todoInfo.setMessage(todoBean.getMessage());

    // TODOステータスコード 未着手
    todoInfo.setTodoStatusCode(ECISConstants.TODO_STATUS_CODE_NOT_STARTED);

    // 対応日　未設定
    todoInfo.setDealDate(null);

    // 対応時刻　未設定
    todoInfo.setDealTime(null);

    // 対応者　未設定
    todoInfo.setDealer(null);

    // 備考
    todoInfo.setNote(todoBean.getNote());

    // 更新回数
    todoInfo.setUpdateCount(0);

    // 作成日時
    todoInfo.setCreateTime(systime);

    // オンラインフラグがオンラインの場合のみ更新する
    if (ECISConstants.ONLINE_FLAG_ONLINE.equals(onlineFlg)) {

      // オンライン更新日時
      todoInfo.setOnlineUpdateTime(systime);

      // オンライン更新ユーザID
      todoInfo.setOnlineUpdateUserId(ThreadContext
          .getRequestThreadContext().get(ECISConstants.USER_ID_KEY)
          .toString());
    }
    // 更新日時
    todoInfo.setUpdateTime(systime);

    // 更新モジュールコード
    todoInfo.setUpdateModuleCode(ThreadContext
        .getRequestThreadContext()
        .get(ECISConstants.CLASS_NAME_KEY).toString());

    // todoテーブルに挿入する
    todoMapper.insertTodoBySq(todoInfo);
  }

  public void setTodoMapper(TodoMapper todoMapper) {
    this.todoMapper = todoMapper;
  }
  
  public void setContractMapper(ContractMapper contractMapper) {
    this.contractMapper = contractMapper;
  }

  public void setContractorMapper(ContractorMapper contractorMapper) {
    this.contractorMapper = contractorMapper;
  }

  public void setMlContractHistMapper(MlContractHistMapper mlContractHistMapper) {
    this.mlContractHistMapper = mlContractHistMapper;
  }

  public void setMlMapper(MlMapper mlMapper) {
    this.mlMapper = mlMapper;
  }
}
