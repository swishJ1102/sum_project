package jp.co.unisys.enability.cis.business.gk;

import java.util.HashMap;
import java.util.Map;

import jp.co.unisys.enability.cis.business.gk.model.InquiryUserACLBusinessBean;
import jp.co.unisys.enability.cis.common.Exception.SystemException;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.entity.common.ActionM;
import jp.co.unisys.enability.cis.mapper.gk.InquiryUserACLMapper;

/**
 * ユーザ認証(ACL管理)共通処理
 *
 * @author "Nihon Unisys, Ltd."
 */
public class InquiryUserACLBusinessImpl implements InquiryUserACLBusiness {

  /**
   * ユーザ認証（ACL管理）共通マッパー(DI)
   */
  private InquiryUserACLMapper inquiryUserACLMapper;

  /*
   * @see
   * jp.co.unisys.enability.cis.business.gk.InquiryUserACLBusiness#
   * inquiryUserACL(jp.co.unisys.enability.cis.business.gk.model.InquiryUserACLBusinessBean)
   */
  @Override
  public InquiryUserACLBusinessBean inquiryUserACL(
      InquiryUserACLBusinessBean inquiryUserACLBusinessBean) {

    try {
      // 権限情報取得
      Map<String, Object> exampleMap = new HashMap<String, Object>();
      exampleMap
          .put("actionId", inquiryUserACLBusinessBean.getActionId());
      exampleMap.put("roleId", inquiryUserACLBusinessBean.getRoleId());
      ActionM actionMaster = inquiryUserACLMapper
          .selectInquiryUserACL(exampleMap);

      // 認証結果設定
      boolean result;
      if (actionMaster == null) {
        // アクションマスタが取得できない場合
        result = false;
      } else {
        if (ECISConstants.FLG_ON.equals(actionMaster.getDenialFlag())) {
          // アクションマスタの拒否フラグがONの場合
          result = false;
        } else {
          // アクションマスタの拒否フラグがOFFの場合
          result = true;
        }
      }

      // 返却
      inquiryUserACLBusinessBean.setResult(result);
    } catch (Exception e) {
      throw new SystemException(e.getMessage(), e);
    }
    return inquiryUserACLBusinessBean;
  }

  /**
   * ユーザ認証（ACL管理）共通マッパーのsetter(DI)
   *
   * @param inquiryUserACLMapper
   *          ユーザ認証（ACL管理）共通マッパー
   */
  public void setInquiryUserACLMapper(
      InquiryUserACLMapper inquiryUserACLMapper) {
    this.inquiryUserACLMapper = inquiryUserACLMapper;
  }

}
