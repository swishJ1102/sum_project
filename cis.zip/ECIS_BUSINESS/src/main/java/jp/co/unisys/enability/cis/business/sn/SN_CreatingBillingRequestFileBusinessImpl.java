package jp.co.unisys.enability.cis.business.sn;

import java.io.File;
import java.io.IOException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.config.PropertiesFactoryBean;
import org.springframework.context.MessageSource;

import jp.co.unisys.enability.cis.business.common.MailManagementBusiness;
import jp.co.unisys.enability.cis.business.common.model.MailManagementBusinessBean;
import jp.co.unisys.enability.cis.business.gk.GK_WorkCommonBusiness;
import jp.co.unisys.enability.cis.business.sn.model.SN_BillingDetailInfoBusinessBean;
import jp.co.unisys.enability.cis.business.sn.model.SN_BillingRequestDataBusinessBean;
import jp.co.unisys.enability.cis.common.Exception.BusinessLogicException;
import jp.co.unisys.enability.cis.common.Exception.SystemException;
import jp.co.unisys.enability.cis.common.util.StringConvertUtil;
import jp.co.unisys.enability.cis.common.util.constants.ECISCodeConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISSNConstants;
import jp.co.unisys.enability.cis.entity.common.Contractor;
import jp.co.unisys.enability.cis.entity.common.Fcr;
import jp.co.unisys.enability.cis.entity.common.FcrExample;
import jp.co.unisys.enability.cis.entity.common.Place;
import jp.co.unisys.enability.cis.entity.common.PmCompanyM;
import jp.co.unisys.enability.cis.entity.common.PmCompanyMExample;
import jp.co.unisys.enability.cis.entity.sn.SN_BillingInfoEntityBean;
import jp.co.unisys.enability.cis.entity.sn.SN_CancelTargetContractInfoEntityBean;
import jp.co.unisys.enability.cis.entity.sn.SN_CreatingBillingRequestFileEntityBean;
import jp.co.unisys.enability.cis.mapper.common.ContractorMapper;
import jp.co.unisys.enability.cis.mapper.common.FcrMapper;
import jp.co.unisys.enability.cis.mapper.common.PmCompanyMMapper;
import jp.co.unisys.enability.cis.mapper.sn.SN_CreatingBillingRequestFileMapper;
import jp.sf.orangesignal.csv.CsvWriter;

/**
 * 請求入金共通請求依頼ファイル作成ビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class SN_CreatingBillingRequestFileBusinessImpl implements
    SN_CreatingBillingRequestFileBusiness {

  /** プロパティファイル取得キー：請求依頼ファイル作成CSVファイル出力先ディレクトリ */
  private static final String OUTPUT_DIR = "batch.sn.billingrequestfile.output.dir";

  /** プロパティファイル取得キー：請求依頼ファイル作成CSVファイル名 */
  private static final String OUTPUT_FILE_NAME = "batch.sn.billingrequestfile";

  /** プロパティファイル取得キー：メールテンプレートファイルパス */
  private static final String MAIL_TMPLATE_FILE_DIR = "business.sn.mail.dir";

  /** プロパティファイル取得キー：メール件名テンプレートファイル名（口座振替） */
  private static final String MAIL_SUBJECT_TMPLATE_FILE_NAME_ACCOUNT = "business.sn.mailsubject.tmplate.filename.account";

  /** プロパティファイル取得キー：メール本文テンプレートファイル名（口座振替） */
  private static final String MAIL_BODY_TMPLATE_FILE_NAME_ACCOUNT = "business.sn.mailbody.tmplate.filename.account";

  /** プロパティファイル取得キー：メール件名テンプレートファイル名（クレジット） */
  private static final String MAIL_SUBJECT_TMPLATE_FILE_NAME_CREDIT = "business.sn.mailsubject.tmplate.filename.credit";

  /** プロパティファイル取得キー：メール本文テンプレートファイル名（クレジット） */
  private static final String MAIL_BODY_TMPLATE_FILE_NAME_CREDIT = "business.sn.mailbody.tmplate.filename.credit";

  /** プロパティファイル取得キー：メール件名テンプレートファイル名（コンビニ） */
  private static final String MAIL_SUBJECT_TMPLATE_FILE_NAME_CONVENI = "business.sn.mailsubject.tmplate.filename.conveni";

  /** プロパティファイル取得キー：メール本文テンプレートファイル名（コンビニ） */
  private static final String MAIL_BODY_TMPLATE_FILE_NAME_CONVENI = "business.sn.mailbody.tmplate.filename.conveni";

  /** プロパティファイル取得キー：メール件名テンプレートファイル名（振込） */
  private static final String MAIL_SUBJECT_TMPLATE_FILE_NAME_TRANSFER = "business.sn.mailsubject.tmplate.filename.transfer";

  /** プロパティファイル取得キー：メール本文テンプレートファイル名（振込） */
  private static final String MAIL_BODY_TMPLATE_FILE_NAME_TRANSFER = "business.sn.mailbody.tmplate.filename.transfer";

  /** プロパティファイル取得キー：CSVファイルレコード設定情報ファイル（口振・クレカ） */
  private static final String CSV_SETTING_INFO_FILE_NAME_ACCOUNT_AND_CREDIT = "business.sn.accountcredit.csvfilerecord.filename";

  /** プロパティファイル取得キー：CSVファイルレコード設定情報ファイル（コンビニ） */
  private static final String CSV_SETTING_INFO_FILE_NAME_CONVENI = "business.sn.conveni.csvfilerecord.filename";

  /** プロパティファイル取得キー：CSVファイルレコード設定情報ファイル（振込） */
  private static final String CSV_SETTING_INFO_FILE_NAME_TRANSFER = "business.sn.transfer.csvfilerecord.filename";

  /** プロパティファイル取得キー：CSVファイルレコード設定情報ファイル（卸・取次） */
  private static final String CSV_SETTING_INFO_FILE_NAME_WSAGOP = "business.sn.wsagop.csvfilerecord.filename";

  /** プロパティファイル取得キー：CSVファイルレコード設定情報ファイル（債権） */
  private static final String CSV_SETTING_INFO_FILE_NAME_CLAIM = "business.sn.claim.csvfilerecord.filename";

  /** プロパティファイル取得キー：0円請求依頼対象フラグ（口振・クレカ） */
  private static final String ZERO_BL_REQUEST_TARGET_FLG_FOR_ACCOUNT_AND_CREDIT = "batch.sn.billingrequestflg.zero.account.credit";

  /** プロパティファイル取得キー：0円請求依頼対象フラグ（コンビニ） */
  private static final String ZERO_BL_REQUEST_TARGET_FLG_FOR_CONVENI = "batch.sn.billingrequestflg.zero.conveni";

  /** プロパティファイル取得キー：0円請求依頼対象フラグ（振込） */
  private static final String ZERO_BL_REQUEST_TARGET_FLG_FOR_TRANSFER = "batch.sn.billingrequestflg.zero.transfer";

  /** プロパティファイル取得キー：0円請求依頼対象フラグ（卸・取次） */
  private static final String ZERO_BL_REQUEST_TARGET_FLG_FOR_WSAGOP = "batch.sn.billingrequestflg.zero.wsagop";

  /** プロパティファイル取得キー：0円請求依頼対象フラグ（債権） */
  private static final String ZERO_BL_REQUEST_TARGET_FLG_FOR_CLAIM = "batch.sn.billingrequestflg.zero.claim";

  /** プロパティファイル取得キー：委託者コード */
  private static final String CONSIGNER_CODE = "business.sn.consigner.code";

  /** データ区分：ヘッダ */
  private static final String DATA_CATEGORY_HEADER = "1";

  /** CSVファイル設定情報マップ */
  private Map<String, String> map;

  /** 請求依頼データ作成ビジネス(DI) */
  private SN_CreateBillingRequestDataBusiness snCreateBillingRequestDataBusiness;

  /** 業務共通ビジネス(DI) */
  private GK_WorkCommonBusiness gkWorkCommonBusiness;

  /** 請求入金共通ビジネス(DI) */
  private SN_BillingCommonBusiness snBillingCommonBusiness;

  /** メール管理共通ビジネス(DI) */
  private MailManagementBusiness mailManagementBusiness;

  /** 請求依頼ファイル作成マッパー(DI) */
  private SN_CreatingBillingRequestFileMapper snCreatingBillingRequestFileMapper;

  /** 提供モデル企業マスタマッパー(DI) */
  private PmCompanyMMapper pmCompanyMMapper;

  /** 契約者マッパー(DI) */
  private ContractorMapper contractorMapper;

  /** 確定料金実績(DI) */
  private FcrMapper fcrMapper;

  /** プロパティ定義クラス(DI) */
  private PropertiesFactoryBean applicationProperties;

  /** メッセージプロパティ(DI) */
  private MessageSource messageSource;

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.sn.SN_CreatingBillingRequestFileBusiness
   * #creatingBillingRequestFileForAccountAndCredit(Date, String)
   */
  @Override
  public void creatingBillingRequestFileForAccountAndCredit(Date batchDate, String blCatCode) {

    // CSVWriter
    CsvWriter csvWriter = null;
    // 請求依頼ファイル
    File file = null;
    // 0円請求依頼対象フラグ
    String zeroBlReqFlg;
    // 委託者コード
    String consignerCode;
    // CSVファイルレコード設定情報ファイル（口振・クレカ）
    String csvSettingInfoFileName;

    try {
      // ■引数のチェック
      if (batchDate == null || StringUtils.isEmpty(blCatCode)) {
        SystemException se = new SystemException(
            messageSource.getMessage("error.E1411", null, Locale.getDefault()));
        throw se;
      }

      // ■出力ファイルの設定
      Properties prop = null;
      try {
        // プロパティのオブジェクトを取得
        prop = applicationProperties.getObject();
        zeroBlReqFlg = prop.getProperty(ZERO_BL_REQUEST_TARGET_FLG_FOR_ACCOUNT_AND_CREDIT);
        consignerCode = prop.getProperty(CONSIGNER_CODE);
        csvSettingInfoFileName = prop.getProperty(CSV_SETTING_INFO_FILE_NAME_ACCOUNT_AND_CREDIT);

      } catch (IOException e) {
        SystemException se = new SystemException(
            messageSource.getMessage("error.E1278", null, Locale.getDefault()), e);
        throw se;
      }

      if (StringUtils.isEmpty(zeroBlReqFlg)
          || StringUtils.isEmpty(consignerCode)
          || StringUtils.isEmpty(csvSettingInfoFileName)) {
        // プロパティファイルの読み込みに失敗した場合、以下のメッセージを設定し、システム例外をスローする。
        throw new SystemException(messageSource.getMessage("error.E1278", null, Locale.getDefault()));
      }

      file = this.settingOutPutFile(blCatCode, prop, batchDate);

      // ■請求データ取得
      Map<String, Object> createBillingMap = new HashMap<String, Object>();
      createBillingMap.put("blCatCode", blCatCode);
      createBillingMap.put("blCreateDate", batchDate);

      // ■請求依頼ファイル作成Dao.請求依頼ファイル作成情報取得処理を呼び出す。
      List<SN_CreatingBillingRequestFileEntityBean> snCreatingBillingRequestFileEntityBeanList = snCreatingBillingRequestFileMapper
          .selectCreateBillingRequestFileInfo(createBillingMap);

      // ■請求依頼ファイル（データ）作成判定
      int blCnt = 0;
      // 《請求依頼ファイル作成EntityBean》リスト分、以下の処理を繰り返す。
      for (int i = 0; i < snCreatingBillingRequestFileEntityBeanList.size(); i++) {

        // 「0円請求依頼対象フラグ」 ＝ "OFF"
        // かつ 《請求依頼ファイル作成EntityBean》.《請求EntityBean》.請求額 ＝ 0円 の場合
        if (ECISConstants.FLG_OFF.equals(zeroBlReqFlg)
            && snCreatingBillingRequestFileEntityBeanList.get(i).getBl().getBlAmount()
                .equals(Long.valueOf(0))) {
          // 次のレコードを読み込み、繰り返し処理を継続する。
          continue;

        } else {
          // 上記以外の場合、「請求のカウント」をインクリメントする。
          blCnt++;
        }
      }

      // ■ヘッダ部を設定し、ファイル出力を呼び出す。
      List<String> header = new ArrayList<>();
      header.add(DATA_CATEGORY_HEADER);
      header.add(consignerCode);
      header.add(blCatCode);
      header.add(String.valueOf(blCnt));

      // 業務共通ビジネス.CSVWriter作成を呼び出し、CSVWriterを作成する。
      csvWriter = gkWorkCommonBusiness.createCsvWriter(ECISSNConstants.SETTLEMENT_AGENCY_LINKAGE_CSV_FILE, file,
          null);
      // CSVWriter.writerValuesを呼び出し、CSVファイルに書き込む。
      csvWriter.writeValues(header);

      // ■請求依頼処理
      // プロパテイファイル取得処理を呼び出す。
      this.map = snBillingCommonBusiness.getPropertiesData(csvSettingInfoFileName);

      // 《請求依頼ファイル作成EntityBean》リスト分、以下の処理を繰り返す。
      for (SN_CreatingBillingRequestFileEntityBean bean : snCreatingBillingRequestFileEntityBeanList) {

        // 明細情報取得
        SN_BillingDetailInfoBusinessBean snBillingDetailInfoBusinessBean = this.getDetailInfo(bean, batchDate);
        // (「0円請求依頼対象フラグ」 ＝ "OFF"
        // かつ 《請求依頼ファイル作成EntityBean》.《請求EntityBean》.請求額 ＝ 0円) ではない場合
        if (!(ECISConstants.FLG_OFF.equals(zeroBlReqFlg) && bean.getBl().getBlAmount()
            .equals(Long.valueOf(0)))) {
          // 請求依頼データ作成
          SN_BillingRequestDataBusinessBean snBillingRequestDataBusinessBean = snCreateBillingRequestDataBusiness
              .createBillingRequestDataBeanForAccountAndCredit(
                  snBillingDetailInfoBusinessBean, consignerCode, prop);
          // 請求ファイル作成
          this.createBillingRequestData(snBillingRequestDataBusinessBean, csvWriter);
        }
        // 請求メール作成
        this.createBillingMail(snBillingDetailInfoBusinessBean, blCatCode, prop);
      }

      // CSVWriter.flushを呼び出し書き込んだ内容を反映させる。
      csvWriter.flush();

    } catch (SystemException se) {
      // ■出力したCSVファイルを削除する。
      this.deleteFile(file, csvWriter);
      // ■例外をそのままスローする。
      throw se;

    } catch (Exception e) {
      // ■出力したCSVファイルを削除する。
      this.deleteFile(file, csvWriter);
      // ■異常終了ログ出力
      throw new SystemException(
          messageSource.getMessage("error.E1224", new String[] {
              blCatCode }, Locale.getDefault()),
          e);

    }
    // ■CSVWriterを閉じる。
    IOUtils.closeQuietly(csvWriter);

  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.sn.SN_CreatingBillingRequestFileBusiness
   * #creatingBillingRequestFileForConvenienceStore(Date, String)
   */
  @Override
  public void creatingBillingRequestFileForConvenienceStore(Date batchDate, String blCatCode) {

    // CSVWriter
    CsvWriter csvWriter = null;
    // 請求依頼ファイル
    File file = null;
    // 0円請求依頼対象フラグ
    String zeroBlReqFlg;
    // 委託者コード
    String consignerCode;
    // CSVファイルレコード設定情報ファイル（コンビニ）
    String csvSettingInfoFileName;

    try {
      // ■引数のチェック
      if (batchDate == null || StringUtils.isEmpty(blCatCode)) {
        SystemException se = new SystemException(
            messageSource.getMessage("error.E1411", null, Locale.getDefault()));
        throw se;
      }

      // ■出力ファイルの設定
      Properties prop = null;
      try {
        // プロパティのオブジェクトを取得
        prop = applicationProperties.getObject();
        zeroBlReqFlg = prop.getProperty(ZERO_BL_REQUEST_TARGET_FLG_FOR_CONVENI);
        consignerCode = prop.getProperty(CONSIGNER_CODE);
        csvSettingInfoFileName = prop.getProperty(CSV_SETTING_INFO_FILE_NAME_CONVENI);
      } catch (IOException e) {
        SystemException se = new SystemException(
            messageSource.getMessage("error.E1278", null, Locale.getDefault()), e);
        throw se;
      }

      if (StringUtils.isEmpty(zeroBlReqFlg)
          || StringUtils.isEmpty(consignerCode)
          || StringUtils.isEmpty(csvSettingInfoFileName)) {
        // プロパティファイルの読み込みに失敗した場合、以下のメッセージを設定し、システム例外をスローする。
        throw new SystemException(messageSource.getMessage("error.E1278", null, Locale.getDefault()));
      }

      file = this.settingOutPutFile(blCatCode, prop, batchDate);

      // ■請求データ取得
      Map<String, Object> createBillingMap = new HashMap<String, Object>();
      createBillingMap.put("blCatCode", blCatCode);
      createBillingMap.put("blCreateDate", batchDate);

      // ■請求依頼ファイル作成Dao.請求依頼ファイル作成情報取得処理を呼び出す。
      List<SN_CreatingBillingRequestFileEntityBean> snCreatingBillingRequestFileEntityBeanList = snCreatingBillingRequestFileMapper
          .selectCreateBillingRequestFileInfo(createBillingMap);

      // ■請求依頼ファイル（データ）作成判定
      int blCnt = 0;
      // 《請求依頼ファイル作成EntityBean》リスト分、以下の処理を繰り返す。
      for (int i = 0; i < snCreatingBillingRequestFileEntityBeanList.size(); i++) {

        // 「0円請求依頼対象フラグ」 ＝ "OFF"
        // かつ 《請求依頼ファイル作成EntityBean》.《請求EntityBean》.請求額 ＝ 0円 の場合
        if (ECISConstants.FLG_OFF.equals(zeroBlReqFlg)
            && snCreatingBillingRequestFileEntityBeanList.get(i).getBl().getBlAmount()
                .equals(Long.valueOf(0))) {
          // 次のレコードを読み込み、繰り返し処理を継続する。
          continue;

        } else {
          // 上記以外の場合、「請求のカウント」をインクリメントする。
          blCnt++;
        }
      }

      // ■ヘッダ部を設定し、ファイル出力を呼び出す。
      List<String> header = new ArrayList<>();
      header.add(DATA_CATEGORY_HEADER);
      header.add(consignerCode);
      header.add(blCatCode);
      header.add(String.valueOf(blCnt));

      // 業務共通ビジネス.CSVWriter作成を呼び出し、CSVWriterを作成する。
      csvWriter = gkWorkCommonBusiness.createCsvWriter(ECISSNConstants.SETTLEMENT_AGENCY_LINKAGE_CSV_FILE, file,
          null);
      // CSVWriter.writerValuesを呼び出し、CSVファイルに書き込む。
      csvWriter.writeValues(header);

      // ■請求依頼処理
      // プロパテイファイル取得処理を呼び出す。
      this.map = snBillingCommonBusiness.getPropertiesData(csvSettingInfoFileName);

      // 《請求依頼ファイル作成EntityBean》リスト分、以下の処理を繰り返す。
      for (SN_CreatingBillingRequestFileEntityBean bean : snCreatingBillingRequestFileEntityBeanList) {

        // 明細情報取得
        SN_BillingDetailInfoBusinessBean snBillingDetailInfoBusinessBean = this.getDetailInfo(bean, batchDate);
        // (「0円請求依頼対象フラグ」 ＝ "OFF"
        // かつ 《請求依頼ファイル作成EntityBean》.《請求EntityBean》.請求額 ＝ 0円) ではない場合
        if (!(ECISConstants.FLG_OFF.equals(zeroBlReqFlg) && bean.getBl().getBlAmount()
            .equals(Long.valueOf(0)))) {
          // 請求依頼データ作成
          SN_BillingRequestDataBusinessBean snBillingRequestDataBusinessBean = snCreateBillingRequestDataBusiness
              .createBillingRequestDataBeanForConveniAndTransfer(
                  snBillingDetailInfoBusinessBean, consignerCode, prop);
          // 請求ファイル作成
          this.createBillingRequestData(snBillingRequestDataBusinessBean, csvWriter);
        }
        // 請求メール作成
        this.createBillingMail(snBillingDetailInfoBusinessBean, blCatCode, prop);
      }

      // CSVWriter.flushを呼び出し書き込んだ内容を反映させる。
      csvWriter.flush();

    } catch (SystemException se) {
      // ■出力したCSVファイルを削除する。
      this.deleteFile(file, csvWriter);
      // ■例外をそのままスローする。
      throw se;

    } catch (Exception e) {
      // ■出力したCSVファイルを削除する。
      this.deleteFile(file, csvWriter);
      // ■異常終了ログ出力
      throw new SystemException(
          messageSource.getMessage("error.E1224", new String[] {
              blCatCode }, Locale.getDefault()),
          e);

    }
    // ■CSVWriterを閉じる。
    IOUtils.closeQuietly(csvWriter);

  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.sn.SN_CreatingBillingRequestFileBusiness
   * #creatingBillingRequestFileForTransfer(Date, String)
   */
  @Override
  public void creatingBillingRequestFileForTransfer(Date batchDate, String blCatCode) {

    // CSVWriter
    CsvWriter csvWriter = null;
    // 請求依頼ファイル
    File file = null;
    // 0円請求依頼対象フラグ
    String zeroBlReqFlg;
    // 委託者コード
    String consignerCode;
    // CSVファイルレコード設定情報ファイル（振込）
    String csvSettingInfoFileName;

    try {
      // ■引数のチェック
      if (batchDate == null || StringUtils.isEmpty(blCatCode)) {
        SystemException se = new SystemException(
            messageSource.getMessage("error.E1411", null, Locale.getDefault()));
        throw se;
      }

      // ■出力ファイルの設定
      Properties prop = null;
      try {
        // プロパティのオブジェクトを取得
        prop = applicationProperties.getObject();
        zeroBlReqFlg = prop.getProperty(ZERO_BL_REQUEST_TARGET_FLG_FOR_TRANSFER);
        consignerCode = prop.getProperty(CONSIGNER_CODE);
        csvSettingInfoFileName = prop.getProperty(CSV_SETTING_INFO_FILE_NAME_TRANSFER);

      } catch (IOException e) {
        SystemException se = new SystemException(
            messageSource.getMessage("error.E1278", null, Locale.getDefault()), e);
        throw se;
      }

      if (StringUtils.isEmpty(zeroBlReqFlg)
          || StringUtils.isEmpty(consignerCode)
          || StringUtils.isEmpty(csvSettingInfoFileName)) {
        // プロパティファイルの読み込みに失敗した場合、以下のメッセージを設定し、システム例外をスローする。
        throw new SystemException(messageSource.getMessage("error.E1278", null, Locale.getDefault()));
      }

      file = this.settingOutPutFile(blCatCode, prop, batchDate);

      // ■請求データ取得
      Map<String, Object> createBillingMap = new HashMap<String, Object>();
      createBillingMap.put("blCatCode", blCatCode);
      createBillingMap.put("blCreateDate", batchDate);

      // ■請求依頼ファイル作成Dao.請求依頼ファイル作成情報取得処理を呼び出す。
      List<SN_CreatingBillingRequestFileEntityBean> snCreatingBillingRequestFileEntityBeanList = snCreatingBillingRequestFileMapper
          .selectCreateBillingRequestFileInfo(createBillingMap);

      // ■請求依頼ファイル（データ）作成判定
      int blCnt = 0;
      // 《請求依頼ファイル作成EntityBean》リスト分、以下の処理を繰り返す。
      for (int i = 0; i < snCreatingBillingRequestFileEntityBeanList.size(); i++) {

        // 「0円請求依頼対象フラグ」 ＝ "OFF"
        // かつ 《請求依頼ファイル作成EntityBean》.《請求EntityBean》.請求額 ＝ 0円 の場合
        if (ECISConstants.FLG_OFF.equals(zeroBlReqFlg)
            && snCreatingBillingRequestFileEntityBeanList.get(i).getBl().getBlAmount()
                .equals(Long.valueOf(0))) {
          // 次のレコードを読み込み、繰り返し処理を継続する。
          continue;

        } else {
          // 上記以外の場合、「請求のカウント」をインクリメントする。
          blCnt++;
        }
      }

      // ■ヘッダ部を設定し、ファイル出力を呼び出す。
      List<String> header = new ArrayList<>();
      header.add(DATA_CATEGORY_HEADER);
      header.add(consignerCode);
      header.add(blCatCode);
      header.add(String.valueOf(blCnt));

      // 業務共通ビジネス.CSVWriter作成を呼び出し、CSVWriterを作成する。
      csvWriter = gkWorkCommonBusiness.createCsvWriter(ECISSNConstants.SETTLEMENT_AGENCY_LINKAGE_CSV_FILE, file,
          null);
      // CSVWriter.writerValuesを呼び出し、CSVファイルに書き込む。
      csvWriter.writeValues(header);

      // ■請求依頼処理
      // プロパテイファイル取得処理を呼び出す。
      this.map = snBillingCommonBusiness.getPropertiesData(csvSettingInfoFileName);

      // 《請求依頼ファイル作成EntityBean》リスト分、以下の処理を繰り返す。
      for (SN_CreatingBillingRequestFileEntityBean bean : snCreatingBillingRequestFileEntityBeanList) {

        // 明細情報取得
        SN_BillingDetailInfoBusinessBean snBillingDetailInfoBusinessBean = this.getDetailInfo(bean, batchDate);
        // (「0円請求依頼対象フラグ」 ＝ "OFF"
        // かつ 《請求依頼ファイル作成EntityBean》.《請求EntityBean》.請求額 ＝ 0円) ではない場合
        if (!(ECISConstants.FLG_OFF.equals(zeroBlReqFlg) && bean.getBl().getBlAmount()
            .equals(Long.valueOf(0)))) {
          // 請求依頼データ作成
          SN_BillingRequestDataBusinessBean snBillingRequestDataBusinessBean = snCreateBillingRequestDataBusiness
              .createBillingRequestDataBeanForConveniAndTransfer(
                  snBillingDetailInfoBusinessBean, consignerCode, prop);
          // 請求ファイル作成
          this.createBillingRequestData(snBillingRequestDataBusinessBean, csvWriter);
        }
        // 請求メール作成
        this.createBillingMail(snBillingDetailInfoBusinessBean, blCatCode, prop);
      }

      // CSVWriter.flushを呼び出し書き込んだ内容を反映させる。
      csvWriter.flush();

    } catch (SystemException se) {
      // ■出力したCSVファイルを削除する。
      this.deleteFile(file, csvWriter);
      // ■例外をそのままスローする。
      throw se;

    } catch (Exception e) {
      // ■出力したCSVファイルを削除する。
      this.deleteFile(file, csvWriter);
      // ■異常終了ログ出力
      throw new SystemException(
          messageSource.getMessage("error.E1224", new String[] {
              blCatCode }, Locale.getDefault()),
          e);

    }
    // ■CSVWriterを閉じる。
    IOUtils.closeQuietly(csvWriter);

  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.sn.SN_CreatingBillingRequestFileBusiness
   * #creatingBillingRequestFileForWhiteLabel(Date, String)
   */
  @Override
  public void creatingBillingRequestFileForWsAgOp(Date batchDate, String blCatCode) {

    // CSVWriter
    CsvWriter csvWriter = null;
    // 請求依頼ファイル
    File file = null;
    // 0円請求依頼対象フラグ
    String zeroBlReqFlg;
    // 委託者コード
    String consignerCode;
    // CSVファイルレコード設定情報ファイル（卸・取次）
    String csvSettingInfoFileName;

    try {
      // ■引数のチェック
      if (batchDate == null || StringUtils.isEmpty(blCatCode)) {
        SystemException se = new SystemException(
            messageSource.getMessage("error.E1411", null, Locale.getDefault()));
        throw se;
      }

      // ■出力ファイルの設定
      Properties prop = null;
      try {
        // プロパティのオブジェクトを取得
        prop = applicationProperties.getObject();
        zeroBlReqFlg = prop.getProperty(ZERO_BL_REQUEST_TARGET_FLG_FOR_WSAGOP);
        consignerCode = prop.getProperty(CONSIGNER_CODE);
        csvSettingInfoFileName = prop.getProperty(CSV_SETTING_INFO_FILE_NAME_WSAGOP);

      } catch (IOException e) {
        SystemException se = new SystemException(
            messageSource.getMessage("error.E1278", null, Locale.getDefault()), e);
        throw se;
      }

      if (StringUtils.isEmpty(zeroBlReqFlg)
          || StringUtils.isEmpty(consignerCode)
          || StringUtils.isEmpty(csvSettingInfoFileName)) {
        // プロパティファイルの読み込みに失敗した場合、以下のメッセージを設定し、システム例外をスローする。
        throw new SystemException(messageSource.getMessage("error.E1278", null, Locale.getDefault()));
      }

      file = this.settingOutPutFile(blCatCode, prop, batchDate);

      // ■請求データ取得
      Map<String, Object> createBillingMap = new HashMap<String, Object>();
      createBillingMap.put("blCatCode", blCatCode);
      createBillingMap.put("blCreateDate", batchDate);

      // ■請求依頼ファイル作成Dao.請求依頼ファイル作成情報取得処理を呼び出す。
      List<SN_CreatingBillingRequestFileEntityBean> snCreatingBillingRequestFileEntityBeanList = snCreatingBillingRequestFileMapper
          .selectCreateBillingRequestFileInfo(createBillingMap);

      // ■請求依頼ファイル（データ）作成判定
      int blCnt = 0;
      // 《請求依頼ファイル作成EntityBean》リスト分、以下の処理を繰り返す。
      for (int i = 0; i < snCreatingBillingRequestFileEntityBeanList.size(); i++) {

        // 「0円請求依頼対象フラグ」 ＝ "OFF"
        // かつ 《請求依頼ファイル作成EntityBean》.《請求EntityBean》.請求額 ＝ 0円 の場合
        if (ECISConstants.FLG_OFF.equals(zeroBlReqFlg)
            && snCreatingBillingRequestFileEntityBeanList.get(i).getBl().getBlAmount()
                .equals(Long.valueOf(0))) {
          // 次のレコードを読み込み、繰り返し処理を継続する。
          continue;

        } else {
          // 上記以外の場合、「請求のカウント」をインクリメントする。
          blCnt++;
        }
      }

      // ■ヘッダ部を設定し、ファイル出力を呼び出す。
      List<String> header = new ArrayList<>();
      header.add(DATA_CATEGORY_HEADER);
      header.add(consignerCode);
      header.add(blCatCode);
      header.add(String.valueOf(blCnt));

      // 業務共通ビジネス.CSVWriter作成を呼び出し、CSVWriterを作成する。
      csvWriter = gkWorkCommonBusiness.createCsvWriter(ECISSNConstants.SETTLEMENT_AGENCY_LINKAGE_CSV_FILE, file,
          null);
      // CSVWriter.writerValuesを呼び出し、CSVファイルに書き込む。
      csvWriter.writeValues(header);

      // ■請求依頼処理
      // プロパテイファイル取得処理を呼び出す。
      this.map = snBillingCommonBusiness.getPropertiesData(csvSettingInfoFileName);

      // 《請求依頼ファイル作成EntityBean》リスト分、以下の処理を繰り返す。
      for (SN_CreatingBillingRequestFileEntityBean bean : snCreatingBillingRequestFileEntityBeanList) {

        // (「0円請求依頼対象フラグ」 ＝ "OFF"
        // かつ 《請求依頼ファイル作成EntityBean》.《請求EntityBean》.請求額 ＝ 0円) ではない場合
        if (!(ECISConstants.FLG_OFF.equals(zeroBlReqFlg) && bean.getBl().getBlAmount()
            .equals(Long.valueOf(0)))) {
          // 明細情報取得
          SN_BillingDetailInfoBusinessBean snBillingDetailInfoBusinessBean = this.getDetailInfoForWsAgOp(
              bean,
              batchDate);
          // 請求依頼データ作成
          SN_BillingRequestDataBusinessBean snBillingRequestDataBusinessBean = snCreateBillingRequestDataBusiness
              .createBillingRequestDataBeanForWsAgOp(
                  snBillingDetailInfoBusinessBean, consignerCode, prop);
          // 請求ファイル作成
          this.createBillingRequestData(snBillingRequestDataBusinessBean, csvWriter);
        }
      }

      // CSVWriter.flushを呼び出し書き込んだ内容を反映させる。
      csvWriter.flush();

    } catch (SystemException se) {
      // ■出力したCSVファイルを削除する。
      this.deleteFile(file, csvWriter);
      // ■例外をそのままスローする。
      throw se;

    } catch (Exception e) {
      // ■出力したCSVファイルを削除する。
      this.deleteFile(file, csvWriter);
      // ■異常終了ログ出力
      throw new SystemException(
          messageSource.getMessage("error.E1224", new String[] {
              blCatCode }, Locale.getDefault()),
          e);

    }
    // ■CSVWriterを閉じる。
    IOUtils.closeQuietly(csvWriter);

  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.sn.SN_CreatingBillingRequestFileBusiness
   * #creatingBillingRequestFileForCommissionCollectionClaim(Date, String)
   */
  @Override
  public void creatingBillingRequestFileForCommissionCollectionClaim(Date batchDate, String blCatCode) {

    // CSVWriter
    CsvWriter csvWriter = null;
    // 請求依頼ファイル
    File file = null;
    // 0円請求依頼対象フラグ
    String zeroBlReqFlg;
    // 委託者コード
    String consignerCode;
    // CSVファイルレコード設定情報ファイル（債権）
    String csvSettingInfoFileName;

    try {
      // ■引数のチェック
      if (batchDate == null || StringUtils.isEmpty(blCatCode)) {
        SystemException se = new SystemException(
            messageSource.getMessage("error.E1411", null, Locale.getDefault()));
        throw se;
      }

      // ■出力ファイルの設定
      Properties prop = null;
      try {
        // プロパティのオブジェクトを取得
        prop = applicationProperties.getObject();
        zeroBlReqFlg = prop.getProperty(ZERO_BL_REQUEST_TARGET_FLG_FOR_CLAIM);
        consignerCode = prop.getProperty(CONSIGNER_CODE);
        csvSettingInfoFileName = prop.getProperty(CSV_SETTING_INFO_FILE_NAME_CLAIM);

      } catch (IOException e) {
        SystemException se = new SystemException(
            messageSource.getMessage("error.E1278", null, Locale.getDefault()), e);
        throw se;
      }

      if (StringUtils.isEmpty(zeroBlReqFlg)
          || StringUtils.isEmpty(consignerCode)
          || StringUtils.isEmpty(csvSettingInfoFileName)) {
        // プロパティファイルの読み込みに失敗した場合、以下のメッセージを設定し、システム例外をスローする。
        throw new SystemException(messageSource.getMessage("error.E1278", null, Locale.getDefault()));
      }

      file = this.settingOutPutFile(blCatCode, prop, batchDate);

      // ■請求データ取得
      Map<String, Object> createBillingMap = new HashMap<String, Object>();
      createBillingMap.put("blCatCode", blCatCode);
      createBillingMap.put("blCreateDate", batchDate);

      // ■請求依頼ファイル作成Dao.請求依頼ファイル作成情報取得処理を呼び出す。
      List<SN_CreatingBillingRequestFileEntityBean> snCreatingBillingRequestFileEntityBeanList = snCreatingBillingRequestFileMapper
          .selectCreateBillingRequestFileInfo(createBillingMap);

      // ■請求依頼ファイル（データ）作成判定
      int blCnt = 0;
      // 《請求依頼ファイル作成EntityBean》リスト分、以下の処理を繰り返す。
      for (int i = 0; i < snCreatingBillingRequestFileEntityBeanList.size(); i++) {

        // 「0円請求依頼対象フラグ」 ＝ "OFF"
        // かつ 《請求依頼ファイル作成EntityBean》.《請求EntityBean》.請求額 ＝ 0円 の場合
        if (ECISConstants.FLG_OFF.equals(zeroBlReqFlg)
            && snCreatingBillingRequestFileEntityBeanList.get(i).getBl().getBlAmount()
                .equals(Long.valueOf(0))) {
          // 次のレコードを読み込み、繰り返し処理を継続する。
          continue;

        } else {
          // 上記以外の場合、「請求のカウント」をインクリメントする。
          blCnt++;
        }
      }

      // ■ヘッダ部を設定し、ファイル出力を呼び出す。
      List<String> header = new ArrayList<>();
      header.add(DATA_CATEGORY_HEADER);
      header.add(consignerCode);
      header.add(blCatCode);
      header.add(String.valueOf(blCnt));

      // 請業務共通ビジネス.CSVWriter作成を呼び出し、CSVWriterを作成する。
      csvWriter = gkWorkCommonBusiness.createCsvWriter(ECISSNConstants.SETTLEMENT_AGENCY_LINKAGE_CSV_FILE, file,
          null);
      // CSVWriter.writerValuesを呼び出し、CSVファイルに書き込む。
      csvWriter.writeValues(header);

      // ■請求依頼処理
      // プロパテイファイル取得処理を呼び出す。
      this.map = snBillingCommonBusiness.getPropertiesData(csvSettingInfoFileName);

      // 《請求依頼ファイル作成EntityBean》リスト分、以下の処理を繰り返す。
      for (SN_CreatingBillingRequestFileEntityBean bean : snCreatingBillingRequestFileEntityBeanList) {

        // (「0円請求依頼対象フラグ」 ＝ "OFF"
        // かつ 《請求依頼ファイル作成EntityBean》.《請求EntityBean》.請求額 ＝ 0円) ではない場合
        if (!(ECISConstants.FLG_OFF.equals(zeroBlReqFlg) && bean.getBl().getBlAmount()
            .equals(Long.valueOf(0)))) {
          // 明細情報取得
          SN_BillingDetailInfoBusinessBean snBillingDetailInfoBusinessBean = this.getDetailInfo(bean,
              batchDate);
          // 請求依頼データ作成
          SN_BillingRequestDataBusinessBean snBillingRequestDataBusinessBean = snCreateBillingRequestDataBusiness
              .createBillingRequestDataBeanForReceivable(
                  snBillingDetailInfoBusinessBean, consignerCode, prop);
          // 請求ファイル作成
          this.createBillingRequestData(snBillingRequestDataBusinessBean, csvWriter);
        }
      }

      // CSVWriter.flushを呼び出し書き込んだ内容を反映させる。
      csvWriter.flush();

    } catch (SystemException se) {
      // ■出力したCSVファイルを削除する。
      this.deleteFile(file, csvWriter);
      // ■例外をそのままスローする。
      throw se;

    } catch (Exception e) {
      // ■出力したCSVファイルを削除する。
      this.deleteFile(file, csvWriter);
      // ■異常終了ログ出力
      throw new SystemException(
          messageSource.getMessage("error.E1224", new String[] {
              blCatCode }, Locale.getDefault()),
          e);

    }
    // ■CSVWriterを閉じる。
    IOUtils.closeQuietly(csvWriter);

  }

  /**
   * 請求ファイル作成
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * CSV出力用配列を生成し、ファイル出力を行う。
   * </pre>
   *
   * @param bean
   *          請求依頼データBean
   * @param csvWriter
   *          CSVWriter
   * @throws BusinessLogicException
   */
  private void createBillingRequestData(
      SN_BillingRequestDataBusinessBean bean, CsvWriter csvWriter) throws BusinessLogicException {

    // ■CSV出力用配列の生成
    // 請求入金共通ビジネス.CSV出力用配列の生成処理を呼び出す。
    List<String> csvList = snBillingCommonBusiness.createListForCsv(bean, this.map,
        ECISSNConstants.SETTLEMENT_AGENCY_LINKAGE_CSV_FILE);

    // ■ファイル出力
    try {
      csvWriter.writeValues(csvList);
    } catch (IOException ie) {
      throw new SystemException(
          messageSource.getMessage("error.E1301", null, Locale.getDefault()), ie);
    }
  }

  /**
   * 請求メール作成処理
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求区分コード毎のメールテンプレートを編集し、
   * 請求メール管理登録を行う。
   * </pre>
   *
   * @param bean
   *          請求明細情報Bean
   * @param blCatCode
   *          請求区分コード
   * @param prop
   *          プロパティオブジェクト
   */
  private void createBillingMail(
      SN_BillingDetailInfoBusinessBean bean, String blCatCode, Properties prop) {

    // ■メールテンプレート編集
    // 請求区分コードを基に、外部ファイルより、メールテンプレートのファイルパス名を取得する。
    String tmpFileSubject = null;
    String tmpFileMailBody = null;
    String tmpDir = prop.getProperty(MAIL_TMPLATE_FILE_DIR);
    if (ECISCodeConstants.BILLING_CATEGORY_CODE_ACCOUNT.equals(blCatCode)) {
      // 引数.請求区分コード ＝ ”口座振替”の場合
      // 件名テンプレート名取得
      tmpFileSubject = prop.getProperty(MAIL_SUBJECT_TMPLATE_FILE_NAME_ACCOUNT);
      // メールテンプレート名取得
      tmpFileMailBody = prop.getProperty(MAIL_BODY_TMPLATE_FILE_NAME_ACCOUNT);
    } else if (ECISCodeConstants.BILLING_CATEGORY_CODE_CREDIT.equals(blCatCode)) {
      // 引数.請求区分コード ＝ ”クレジット払い”の場合
      // 件名テンプレート名取得
      tmpFileSubject = prop.getProperty(MAIL_SUBJECT_TMPLATE_FILE_NAME_CREDIT);
      // メールテンプレート名取得
      tmpFileMailBody = prop.getProperty(MAIL_BODY_TMPLATE_FILE_NAME_CREDIT);
    } else if (ECISCodeConstants.BILLING_CATEGORY_CODE_CONVENI.equals(blCatCode)) {
      // 引数.請求区分コード ＝ ”コンビニ払い”の場合
      // 件名テンプレート名取得
      tmpFileSubject = prop.getProperty(MAIL_SUBJECT_TMPLATE_FILE_NAME_CONVENI);
      // メールテンプレート名取得
      tmpFileMailBody = prop.getProperty(MAIL_BODY_TMPLATE_FILE_NAME_CONVENI);
    } else if (ECISCodeConstants.BILLING_CATEGORY_CODE_TRANSFER.equals(blCatCode)) {
      // 引数.請求区分コード ＝ ”振込”の場合
      // 件名テンプレート名取得
      tmpFileSubject = prop.getProperty(MAIL_SUBJECT_TMPLATE_FILE_NAME_TRANSFER);
      // メールテンプレート名取得
      tmpFileMailBody = prop.getProperty(MAIL_BODY_TMPLATE_FILE_NAME_TRANSFER);
    }

    if (StringUtils.isEmpty(tmpDir)
        || StringUtils.isEmpty(tmpFileSubject)
        || StringUtils.isEmpty(tmpFileMailBody)) {
      // プロパティファイルの読み込みに失敗した場合、以下のメッセージを設定し、システム例外をスローする。
      throw new SystemException(messageSource.getMessage("error.E1278", null, Locale.getDefault()));
    }

    // ■テンプレート編集
    // 業務共通ビジネス.メールテンプレート編集処理を呼び出す。（件名）
    String editTmpFileSubject = gkWorkCommonBusiness.mailTextMaker(tmpDir + tmpFileSubject, bean);
    // 業務共通ビジネス.メールテンプレート編集処理を呼び出す。（本文）
    String editTmpFileMailBody = gkWorkCommonBusiness.mailTextMaker(tmpDir + tmpFileMailBody, bean);

    // ■メール管理登録
    MailManagementBusinessBean mailManagementBusinessBean = new MailManagementBusinessBean();
    List<String> addressToList = new ArrayList<>();
    // 契約者メールアドレス1
    if (StringUtils.isNotEmpty(bean.getContractor().getCma1())) {
      addressToList.add(bean.getContractor().getCma1());
    }
    // 契約者メールアドレス2
    if (StringUtils.isNotEmpty(bean.getContractor().getCma2())) {
      addressToList.add(bean.getContractor().getCma2());
    }
    if (bean.getPaymentHist() != null) {
      // 請求先メールアドレス1
      if (StringUtils.isNotEmpty(bean.getPaymentHist().getBlMailAddress1())) {
        addressToList.add(bean.getPaymentHist().getBlMailAddress1());
      }
      // 請求先メールアドレス2
      if (StringUtils.isNotEmpty(bean.getPaymentHist().getBlMailAddress2())) {
        addressToList.add(bean.getPaymentHist().getBlMailAddress2());
      }
    }
    // 宛先（To）
    mailManagementBusinessBean.setAddressTo(addressToList);
    // 宛先（Cc）,宛先（Bcc）は未設定
    // 件名
    mailManagementBusinessBean.setSubject(editTmpFileSubject);
    // 本文
    mailManagementBusinessBean.setMailBody(editTmpFileMailBody);
    // システム共通.メール登録機能を呼び出す。
    mailManagementBusiness.registMailManagement(mailManagementBusinessBean);

  }

  /**
   * 明細情報取得
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * DBより以下の情報を取得し、請求明細情報Beanに設定する。
   * ・請求先情報
   * ・契約先情報
   * ・契約情報
   * ・需要場所情報
   * ・解約予告対象契約情報
   * </pre>
   *
   * @param bean
   *          請求依頼ファイル作成EntityBean
   * @param batchDate
   *          バッチ処理基準日
   * @return SN_BillingDetailInfoBusinessBean 請求明細情報Bean
   */
  private SN_BillingDetailInfoBusinessBean getDetailInfo(SN_CreatingBillingRequestFileEntityBean bean,
      Date batchDate) {

    SN_BillingDetailInfoBusinessBean snBillingDetailInfoBusinessBean = new SN_BillingDetailInfoBusinessBean();

    // ■請求先情報取得
    Map<String, Object> billingInfoMap = new HashMap<String, Object>();
    billingInfoMap.put("contractorId", bean.getBl().getContractorId());
    billingInfoMap.put("paymentId", bean.getBl().getPaymentId());
    billingInfoMap.put("blCreateDate", bean.getBl().getBlCreateDate());

    // 請求依頼ファイル作成.請求先情報取得処理を呼び出す。
    SN_BillingInfoEntityBean snBillingInfoEntityBean = snCreatingBillingRequestFileMapper
        .selectBillingInfo(billingInfoMap);

    // ■契約先情報取得
    // 契約者.selectByPrimaryKeyを呼び出す。
    Contractor contractor = contractorMapper.selectByPrimaryKey(bean.getBl().getContractorId());

    // ■契約情報取得
    FcrExample fcrExample = new FcrExample();
    fcrExample.createCriteria().andBlNoEqualTo(bean.getBl().getBlNo());

    // 確定料金実績.selectByExampleを呼び出す。
    List<Fcr> fcrList = fcrMapper.selectByExample(fcrExample);

    // ■需要場所情報取得
    Map<String, Object> placeInfoMap = new HashMap<String, Object>();
    placeInfoMap.put("mlId", fcrList.get(0).getMlId());

    // 請求依頼ファイル作成.需要場所情報取得処理を呼び出す。
    Place place = snCreatingBillingRequestFileMapper.selectPlaceInfo(placeInfoMap);

    // ■解約予告対象契約情報取得
    Map<String, Object> cancelInfoMap = new HashMap<String, Object>();
    cancelInfoMap.put("cpBlId", bean.getBl().getBlId());
    cancelInfoMap.put("urgeStatusCode", ECISCodeConstants.URGE_STATUS_CODE_CANCELLATION_PREVIOUS_NOTICE);

    // 請求依頼ファイル作成.解約予告対象契約情報取得処理を呼び出す。
    List<SN_CancelTargetContractInfoEntityBean> snCancelTargetContractInfoEntityBeanList = snCreatingBillingRequestFileMapper
        .selectCancelTargetContractInfo(cancelInfoMap);

    // ■《請求明細情報Bean》に、取得した明細情報を設定する。
    // 《請求明細情報Bean》←《請求依頼ファイル作成EntityBean》
    this.setCreatingBillingRequestFile(snBillingDetailInfoBusinessBean, bean, batchDate);
    // 《請求明細情報Bean》←《請求先情報EntityBean》]
    if (snBillingInfoEntityBean != null) {
      snBillingDetailInfoBusinessBean.setAcInformation(snBillingInfoEntityBean.getAcInformation());
      snBillingDetailInfoBusinessBean.setPaymentHist(snBillingInfoEntityBean.getPaymentHist());
    }
    // 《請求明細情報Bean》←《契約者EntityBean》
    snBillingDetailInfoBusinessBean.setContractor(contractor);
    // 《請求明細情報Bean》←《確定料金実績EntityBean》リスト
    snBillingDetailInfoBusinessBean.setFcrList(fcrList);
    // 《請求明細情報Bean》←《需要場所EntityBean》
    snBillingDetailInfoBusinessBean.setPlace(place);
    // 全契約番号リスト
    List<String> cntractNoList = new ArrayList<>();
    //全利用年月リスト
    List<String> usePeriodList = new ArrayList<>();
    for (Fcr fcr : fcrList) {
      cntractNoList.add(fcr.getContractNo());
      usePeriodList.add(fcr.getUsePeriod());
    }
    // 契約番号の重複を削除する。
    cntractNoList = cntractNoList.stream().distinct()
        .collect(Collectors.toList());
    snBillingDetailInfoBusinessBean.setContractNoList(cntractNoList);
    // 契約数（契約番号の重複を削除した契約番号リスト-1の件数）
    snBillingDetailInfoBusinessBean.setTotalContractOther(cntractNoList.size() - 1);

    // 利用年月のの重複を削除する。
    usePeriodList = usePeriodList.stream().distinct()
        .collect(Collectors.toList());
    //昇順に並び替える。
    Collections.sort(usePeriodList);
    snBillingDetailInfoBusinessBean.setUsePeriodList(usePeriodList);

    // 《請求明細情報Bean》←《解約予告対象契約情報EntityBean》リスト[0]
    if (CollectionUtils.isNotEmpty(snCancelTargetContractInfoEntityBeanList)) {
      SN_CancelTargetContractInfoEntityBean snCancelTargetContractInfoEntityBean = snCancelTargetContractInfoEntityBeanList
          .get(0);
      // 《督促管理EntityBean》
      snBillingDetailInfoBusinessBean.setUrgeMng(snCancelTargetContractInfoEntityBean.getUrgeMng());
      // 《契約EntityBean》
      snBillingDetailInfoBusinessBean.setContract(snCancelTargetContractInfoEntityBean.getContract());

      // 解約予告対象全契約番号
      List<String> cancellationContrantNoList = new ArrayList<>();
      for (SN_CancelTargetContractInfoEntityBean entityBean : snCancelTargetContractInfoEntityBeanList) {
        cancellationContrantNoList.add(entityBean.getContract().getContractNo());
      }
      // 契約番号の重複を削除する。
      cancellationContrantNoList = cancellationContrantNoList.stream().distinct()
          .collect(Collectors.toList());
      snBillingDetailInfoBusinessBean.setCancellationContrantNoList(cancellationContrantNoList);

      // 解約予告対象フラグ
      snBillingDetailInfoBusinessBean.setCancellationPreviousNoticeFlg(true);
    }

    return snBillingDetailInfoBusinessBean;

  }

  /**
   * 明細情報取得（卸／取次事業者）
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * DBより以下の情報を取得し、請求明細情報Beanに設定する。
   * ・請求先情報
   * ・契約情報
   * </pre>
   *
   * @param bean
   *          請求依頼ファイル作成EntityBean
   * @param batchDate
   *          バッチ処理基準日
   * @return SN_BillingDetailInfoBusinessBean 請求明細情報Bean
   */
  private SN_BillingDetailInfoBusinessBean getDetailInfoForWsAgOp(
      SN_CreatingBillingRequestFileEntityBean bean, Date batchDate) {

    SN_BillingDetailInfoBusinessBean snBillingDetailInfoBusinessBean = new SN_BillingDetailInfoBusinessBean();
    // ■請求先情報取得
    PmCompanyMExample pmCompanyMExample = new PmCompanyMExample();
    pmCompanyMExample.createCriteria().andPmCompanyCodeEqualTo(bean.getBl().getPmCompanyCode())
        .andEffectiveSdLessThanOrEqualTo(bean.getBl().getBlCreateDate())
        .andEffectiveEdGreaterThanOrEqualTo(bean.getBl().getBlCreateDate());

    // 提供モデル企業マスタ.selectByExampleを呼び出す。
    List<PmCompanyM> pmCompanyMList = pmCompanyMMapper.selectByExample(pmCompanyMExample);

    // ■契約情報取得
    FcrExample fcrExample = new FcrExample();
    fcrExample.createCriteria().andBlNoEqualTo(bean.getBl().getBlNo());

    // 確定料金実績.selectByExampleを呼び出す。
    List<Fcr> fcrList = fcrMapper.selectByExample(fcrExample);

    // ■《請求明細情報Bean》に、取得した明細情報を設定する。
    // 《請求明細情報Bean》←《請求依頼ファイル作成EntityBean》
    this.setCreatingBillingRequestFile(snBillingDetailInfoBusinessBean, bean, batchDate);

    // ■《請求明細情報Bean》←《提供モデル企業マスタEntityBean》
    if (CollectionUtils.isNotEmpty(pmCompanyMList)) {
      snBillingDetailInfoBusinessBean.setPmCompanyM(pmCompanyMList.get(0));
    }

    // 《請求明細情報Bean》←《確定料金実績EntityBean》リスト
    snBillingDetailInfoBusinessBean.setFcrList(fcrList);

    // 全契約番号リスト
    List<String> cntractNoList = new ArrayList<>();
    for (Fcr fcr : fcrList) {
      cntractNoList.add(fcr.getContractNo());
    }
    // 契約番号の重複を削除する。
    cntractNoList = cntractNoList.stream().distinct()
        .collect(Collectors.toList());
    snBillingDetailInfoBusinessBean.setContractNoList(cntractNoList);

    return snBillingDetailInfoBusinessBean;

  }

  /**
   * 請求明細情報設定
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求明細情報Beanに請求依頼ファイル作成EntityBeanを設定する。
   * </pre>
   *
   * @param snBillingDetailInfoBusinessBean
   *          請求明細情報Bean
   * @param bean
   *          請求依頼ファイル作成EntityBean
   * @param batchDate
   *          バッチ処理基準日
   */
  private void setCreatingBillingRequestFile(
      SN_BillingDetailInfoBusinessBean snBillingDetailInfoBusinessBean,
      SN_CreatingBillingRequestFileEntityBean bean, Date batchDate) {

    // ■《請求EntityBean》
    snBillingDetailInfoBusinessBean.setBl(bean.getBl());
    // ■消費税等相当額
    snBillingDetailInfoBusinessBean.setCtEquivalent(bean.getCtEquivalent());
    // ■預り金(【請求】.ご利用金額－【請求】請求額)
    Long dpr = bean.getBl().getUseAmount() - bean.getBl().getBlAmount();
    snBillingDetailInfoBusinessBean.setDepositsReceived(dpr);

    // バッチ処理基準日＋1日を計算する
    Calendar nextDate = Calendar.getInstance();
    nextDate.setTime(batchDate);
    nextDate.add(Calendar.DATE, 1);
    // ■メール送信日
    snBillingDetailInfoBusinessBean.setMailSendDate(nextDate.getTime());
  }

  /**
   * 出力ファイル設定
   *
   * @param blCatCode
   *          請求区分コード
   * @param prop
   *          プロパティオブジェクト
   * @param batchDate
   *          バッチ処理基準日
   * @return FILE CSVファイル
   */
  private File settingOutPutFile(String blCatCode, Properties prop, Date batchDate) {

    // ■出力ファイルの生成
    // 請求依頼ファイル作成CSVファイル出力先ディレクトリを取得
    String outputDir = prop.getProperty(OUTPUT_DIR);
    // 請求依頼ファイル作成CSVファイル名を取得
    String fileName = prop.getProperty(OUTPUT_FILE_NAME);

    if (StringUtils.isEmpty(outputDir)
        || StringUtils.isEmpty(fileName)) {
      // プロパティファイルの読み込みに失敗した場合、以下のメッセージを設定し、システム例外をスローする。
      throw new SystemException(messageSource.getMessage("error.E1278", null, Locale.getDefault()));
    }
    /*
     *  外部ファイルから取得した「請求依頼ファイル作成CSVファイル」を編集する。
     *  {0}_FSN0104-01_{1}.csv
     *  	{0}：バッチ処理基準日(yyyyMMdd)
     *		{1}：請求区分コード
     *			1：クレジットカード払い
     *			2：口座振替
     *			3：コンビニ払い
     *			4：振込用請求書
     *			5：債権回収依頼
     *			9：ホワイトラベル
     */
    // ファイル名の作成
    String editFileName = MessageFormat.format(fileName,
        StringConvertUtil.convertDateToString(batchDate, ECISConstants.FORMAT_DATE_yyyyMMdd), blCatCode);

    // ファイルの生成
    File outFile = new File(outputDir + editFileName);

    // 出力ファイルが存在するか確認
    if (outFile.exists()) {
      // 同じファイルパスでファイルが存在した場合、エラーメッセージを出力
      SystemException se = new SystemException(
          messageSource.getMessage("error.E1172", new String[] {
              ECISSNConstants.BL_REQUESTFILE_CSV,
              outFile.getAbsolutePath() }, Locale.getDefault()));
      throw se;
    } else {
      // 上記以外の場合、ファイルを作成する。
      try {
        boolean createFlg = outFile.createNewFile();
        if (!createFlg) {
          // 空ファイルの作成に失敗した場合、システム例外をスローする。
          throw new SystemException(messageSource.getMessage("error.E1271", null, Locale.getDefault()));
        }
      } catch (IOException ie) {
        SystemException se = new SystemException(
            messageSource.getMessage("error.E1271", null, Locale.getDefault()), ie);
        throw se;
      }
    }

    return outFile;
  }

  /**
   * ファイル削除。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 指定されたファイルを削除する。
   *
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param file
   *          削除ファイル
   * @param csvWriter
   *          CSVWriter
   */
  private void deleteFile(File file, CsvWriter csvWriter) {
    if (csvWriter != null) {
      IOUtils.closeQuietly(csvWriter);

    }
    if (file != null && file.exists()) {
      // 指定されたファイルを削除する。
      file.delete();
    }
  }

  /**
   * 請求依頼データ作成ビジネスを設定する。（DI）
   *
   * @param snCreateBillingRequestDataBusiness
   *          請求依頼データ作成ビジネス
   */
  public void setSnCreateBillingRequestDataBusiness(
      SN_CreateBillingRequestDataBusiness snCreateBillingRequestDataBusiness) {
    this.snCreateBillingRequestDataBusiness = snCreateBillingRequestDataBusiness;
  }

  /**
   * 業務共通ビジネスを設定する。（DI）
   *
   * @param gkWorkCommonBusiness
   *          業務共通ビジネス
   */
  public void setGkWorkCommonBusiness(
      GK_WorkCommonBusiness gkWorkCommonBusiness) {
    this.gkWorkCommonBusiness = gkWorkCommonBusiness;
  }

  /**
   * 請求入金共通ビジネスを設定する。（DI）
   *
   * @param snBillingCommonBusiness
   *          請求入金共通ビジネス
   */
  public void setSnBillingCommonBusiness(
      SN_BillingCommonBusiness snBillingCommonBusiness) {
    this.snBillingCommonBusiness = snBillingCommonBusiness;
  }

  /**
   * メール管理共通ビジネスを設定する。（DI）
   *
   * @param mailManagementBusiness
   *          メール管理共通ビジネス
   */
  public void setMailManagementBusiness(
      MailManagementBusiness mailManagementBusiness) {
    this.mailManagementBusiness = mailManagementBusiness;
  }

  /**
   * 請求依頼ファイル作成マッパーを設定する。（DI）
   *
   * @param snCreatingBillingRequestFileMapper
   *          請求依頼ファイル作成マッパー
   */
  public void setSnCreatingBillingRequestFileMapper(
      SN_CreatingBillingRequestFileMapper snCreatingBillingRequestFileMapper) {
    this.snCreatingBillingRequestFileMapper = snCreatingBillingRequestFileMapper;
  }

  /**
   * 提供モデル企業マスタマッパーを設定する。（DI）
   *
   * @param pmCompanyMMapper
   *          提供モデル企業マスタマッパー
   */
  public void setPmCompanyMMapper(PmCompanyMMapper pmCompanyMMapper) {
    this.pmCompanyMMapper = pmCompanyMMapper;
  }

  /**
   * 契約者マッパーを設定する。（DI）
   *
   * @param contractorMapper
   *          契約者マッパー
   */
  public void setContractorMapper(ContractorMapper contractorMapper) {
    this.contractorMapper = contractorMapper;
  }

  /**
   * 確定料金実績マッパーを設定する。（DI）
   *
   * @param fcrMapper
   *          確定料金実績マッパー
   */
  public void setFcrMapper(FcrMapper fcrMapper) {
    this.fcrMapper = fcrMapper;
  }

  /**
   * プロパティ定義クラスを設定する。（DI）
   *
   * @param applicationProperties
   *          プロパティ定義クラス
   */
  public void setApplicationProperties(
      PropertiesFactoryBean applicationProperties) {
    this.applicationProperties = applicationProperties;
  }

  /**
   * メッセージプロパティを設定する。（DI）
   *
   * @param messageSource
   *          メッセージプロパティ
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }

}
