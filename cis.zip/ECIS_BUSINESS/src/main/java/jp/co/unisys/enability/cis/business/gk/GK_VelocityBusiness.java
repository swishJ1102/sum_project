package jp.co.unisys.enability.cis.business.gk;

import jp.co.unisys.enability.cis.business.sn.model.SN_CreateMailBusinessBean;

/**
 * Velocityビジネスインタフェース。
 * 
 * @author "Nihon Unisys, Ltd."
 *
 */
public interface GK_VelocityBusiness {

  /**
   * メールテンプレート編集
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   *  メールテンプレートを編集する。
   *  メールテンプレートファイルを読み込み、該当する置換文字列を
   *  Beanプロパティの値に置換する。
   * </pre>
   *
   * @param mailTemplate
   *          メールテンプレート
   * @param bean
   *          メール作成用ビジネスBean
   * @return 編集後テンプレート
   */
  public String mailTextMaker(String mailTemplate, SN_CreateMailBusinessBean bean);

  /**
   * 文字列フォーマット編集
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   *  文字列フォーマットを編集する。
   *  文字列フォーマットを読み込み、該当する置換文字列を
   *  Beanプロパティの値に置換する。
   *  値がnullの置換文字列は空に設定して返却する。
   * </pre>
   *
   * @param stringFormat
   *          文字列フォーマット
   * @param bean
   *          メール作成用ビジネスBean
   * @return 編集後文字列
   */
  public String evaluateStringVelocity(String stringFormat, SN_CreateMailBusinessBean bean);
}
