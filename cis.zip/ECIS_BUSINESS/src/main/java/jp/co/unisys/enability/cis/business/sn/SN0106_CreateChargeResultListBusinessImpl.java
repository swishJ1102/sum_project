package jp.co.unisys.enability.cis.business.sn;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.zip.ZipOutputStream;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.config.PropertiesFactoryBean;
import org.springframework.context.MessageSource;

import jp.co.unisys.enability.cis.business.common.TodoBusiness;
import jp.co.unisys.enability.cis.business.common.model.TodoBusinessBean;
import jp.co.unisys.enability.cis.business.gk.GK_WorkCommonBusiness;
import jp.co.unisys.enability.cis.business.sn.model.SN0106_ChargeResultBreakdownDataBusinessBean;
import jp.co.unisys.enability.cis.business.sn.model.SN0106_ChargeResultListDataBusinessBean;
import jp.co.unisys.enability.cis.business.sn.model.SN0106_CreateChargeResultListBusinessBean;
import jp.co.unisys.enability.cis.common.Exception.BusinessLogicException;
import jp.co.unisys.enability.cis.common.Exception.SystemException;
import jp.co.unisys.enability.cis.common.util.EMSConstants;
import jp.co.unisys.enability.cis.common.util.StringConvertUtil;
import jp.co.unisys.enability.cis.common.util.constants.ECISCodeConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISSNConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISTodoConstants;
import jp.co.unisys.enability.cis.entity.common.Fcr;
import jp.co.unisys.enability.cis.entity.common.FcrBreakdown;
import jp.co.unisys.enability.cis.entity.common.FixIn;
import jp.co.unisys.enability.cis.entity.common.Fu;
import jp.co.unisys.enability.cis.entity.common.PmCompanyM;
import jp.co.unisys.enability.cis.entity.common.WorkScheduleMngM;
import jp.co.unisys.enability.cis.entity.sn.SN0106_CoveredCompanyChargeResultBreakdownEntityBean;
import jp.co.unisys.enability.cis.entity.sn.SN0106_CoveredCompanyFixChargeResultEntityBean;
import jp.co.unisys.enability.cis.entity.sn.SN0106_DateSlotUsageEntityBean;
import jp.co.unisys.enability.cis.mapper.sn.SN0106_CreateChargeResultListMapper;
import jp.sf.orangesignal.csv.Csv;
import jp.sf.orangesignal.csv.CsvConfig;
import jp.sf.orangesignal.csv.CsvWriter;
import jp.sf.orangesignal.csv.QuotePolicy;
import jp.sf.orangesignal.csv.handlers.StringArrayListHandler;

/**
 * 請求入金共通料金実績一覧作成ビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.sn.SN_BillingCommonBusiness.createListForCsv
 */
public class SN0106_CreateChargeResultListBusinessImpl implements SN0106_CreateChargeResultListBusiness {

  /** プロパティファイル取得キー：提供モデル企業マスタEntityBean */
  private static final String PM_COMPANY_M_ENTITY_BEAN = "business.sn.pmcompanym.entitybean";

  /** プロパティファイル取得キー：業務日程管理マスタEntityBean */
  private static final String WORK_SCHEDULE_MNG_M_ENTITY_BEAN = "business.sn.workschedulemngm.entitybean";

  /** プロパティファイル取得キー：バッチ処理基準日 */
  private static final String BATCH_DATE = "business.sn.batchdate";

  /** プロパティファイル取得キー：月次実行フラグ */
  private static final String MONTHLY_FLAG = "business.sn.monthlyflag";

  /** プロパティファイル取得キー：料金実績一覧ヘッダ */
  private static final String CHG_RES_LIST_HEADER = "business.sn.forwsagopchargeresultlist.header";

  /** プロパティファイル取得キー：料金実績内訳ヘッダ */
  private static final String CHG_RES_BRKD_HEADER = "business.sn.forwsagopchargeresultbreakdown.header";

  /** プロパティファイル取得キー：文字コード：SJIS */
  private static final String ENCODE_TYPE_SJIS = "business.sn.encode.type.sjis";

  /** プロパティファイル取得キー：月次料金実績出力ディレクトリ */
  private static final String MONTHLY_CHG_RES_OUT_DIRECTORY = "business.sn.forwsagopchargeresult.output.dir";

  /** プロパティファイル取得キー：月次料金実績一覧論理ファイル名 */
  private static final String MONTHLY_CHG_RES_LIST_LGC_FILE_NAME = "business.sn.forwsagopchargeresultlist.logicalfilename";

  /** プロパティファイル取得キー：月次料金実績一覧物理ファイル名 */
  private static final String MONTHLY_CHG_RES_LIST_PHS_FILE_NAME = "business.sn.forwsagopchargeresultlist.filename";

  /** プロパティファイル取得キー：月次料金実績内訳論理ファイル名 */
  private static final String MONTHLY_CHG_RES_BRKD_LGC_FILE_NAME = "business.sn.forwsagopchargeresultbreakdown.logicalfilename";

  /** プロパティファイル取得キー：月次料金実績内訳物理ファイル名 */
  private static final String MONTHLY_CHG_RES_BRKD_PHS_FILE_NAME = "business.sn.forwsagopchargeresultbreakdown.filename";

  /** プロパティファイル取得キー：月次料金実績一覧・内訳論理ファイル名 */
  private static final String MONTHLY_CHG_RES_LISTBRKD_LGC_FILE_NAME = "business.sn.forwsagopchargeresultlistbreakdown.logicalfilename";

  /** プロパティファイル取得キー：月次料金実績一覧・内訳物理ファイル名 */
  private static final String MONTHLY_CHG_RES_LISTBRKD_PHS_FILE_NAME = "business.sn.forwsagopchargeresultlistbreakdown.filename";

  /** プロパティファイル取得キー：日次料金実績出力ディレクトリ */
  private static final String DAILY_CHG_RES_OUT_DIRECTORY = "business.sn.foragopchargeresult.output.dir";

  /** プロパティファイル取得キー：日次料金実績一覧物理ファイル名 */
  private static final String DAILY_CHG_RES_LIST_PHS_FILE_NAME = "business.sn.foragopchargeresultlist.filename";

  /** プロパティファイル取得キー：日次料金実績内訳物理ファイル名 */
  private static final String DAILY_CHG_RES_BRKD_PHS_FILE_NAME = "business.sn.foragopchargeresultbreakdown.filename";

  /** プロパティファイル取得キー：CSVファイルレコード設定情報ファイル（料金実績一覧） */
  private static final String LIST_CSV_FILE_SETTING_INFO = "business.sn.chargeresultlist.csvfilerecord.filename";

  /** プロパティファイル取得キー：CSVファイルレコード設定情報ファイル（料金実績内訳） */
  private static final String BREAKDOWN_CSV_FILE_SETTING_INFO = "business.sn.chargeresultbreakdown.csvfilerecord.filename";

  /** プロパティファイル取得キー：夏季時間帯コード */
  private static final String TIME_SLOT_CODE_SUMMER = "business.sn.timeslotcode.summer";

  /** プロパティファイル取得キー：その他季時間帯コード */
  private static final String TIME_SLOT_CODE_OTHER = "business.sn.timeslotcode.other";

  /** 利用年月のyyyy開始位置 */
  private static final int YYYY_START = 0;

  /** 利用年月のMM開始位置 */
  private static final int MM_START = 4;

  /** プロパティ定義クラス(DI) */
  private PropertiesFactoryBean applicationProperties;

  /** メッセージプロパティ(DI) */
  private MessageSource messageSource;

  /** Todo登録(DI) */
  private TodoBusiness todoBusiness;

  /** 請求入金共通ビジネス(DI) */
  private SN_BillingCommonBusiness snBillingCommonBusiness;

  /** 業務共通ビジネス(DI) */
  private GK_WorkCommonBusiness gkWorkCommonBusiness;

  /** 請求入金共通料金実績一覧作成マッパー(DI) */
  private SN0106_CreateChargeResultListMapper sn0106CreateChargeResultListMapper;

  /*
   *  （非 javadoc）
   *  @see jp.co.unisys.enability.cis.business.sn.SN0106_CreateChargeResultListBusiness
   *  #outputChargeResultListFile(Date, WorkScheduleMngM, PmCompanyM, String)
   */
  @Override
  public SN0106_CreateChargeResultListBusinessBean outputChargeResultListFile(Date batchDate,
      WorkScheduleMngM workScheduleMngM, PmCompanyM pmCompanyM, String monthlyFlag) {

    // 利用年月
    String usePeriod = null;

    // 確定料金実績リスト
    List<SN0106_CoveredCompanyFixChargeResultEntityBean> fixChgResList = null;

    // 料金実績一覧作成ビジネスBean
    SN0106_CreateChargeResultListBusinessBean creaChgResListBusinessBean = new SN0106_CreateChargeResultListBusinessBean();

    // 外部ファイルを生成する。
    Properties prop = null;

    // 外部ファイルを読み込む。
    try {
      prop = applicationProperties.getObject();
    } catch (IOException e) {
      throw new SystemException(messageSource.getMessage("error.E1278", null, Locale.getDefault()), e);
    }

    if (pmCompanyM == null) {
      // 《提供モデル企業マスタEntityBean》がnullの時、システム例外をスローする。
      throw new SystemException(messageSource.getMessage("error.E1325", new String[] {
          prop.getProperty(PM_COMPANY_M_ENTITY_BEAN), null }, Locale.getDefault()));
    }

    if (batchDate == null) {
      // バッチ処理基準日がnullの時、システム例外をスローする。
      throw new SystemException(messageSource.getMessage("error.E1325", new String[] {
          prop.getProperty(BATCH_DATE), null }, Locale.getDefault()));
    }

    if (ECISConstants.FLG_ON.equals(monthlyFlag)) {
      // 月次実行フラグが“ON”の場合、以下の処理を行う。

      if (workScheduleMngM == null) {
        // 《業務日程管理マスタEntityBean》がnullの時、システム例外をスローする。
        throw new SystemException(messageSource.getMessage("error.E1325", new String[] {
            prop.getProperty(WORK_SCHEDULE_MNG_M_ENTITY_BEAN), null }, Locale.getDefault()));
      }

      // バッチ処理基準日を利用年月に変換する。
      Calendar cal = Calendar.getInstance();
      cal.setTime(batchDate);
      cal.add(Calendar.MONTH, -1);
      Date previousMonthUsePeriod = cal.getTime();
      usePeriod = new SimpleDateFormat(ECISConstants.FORMAT_DATE_yyyyMM).format(previousMonthUsePeriod);

      // 月次の【確定料金実績】を取得する。
      fixChgResList = selectFixChargeResult(usePeriod, workScheduleMngM, null,
          pmCompanyM.getPmCompanyCode(), monthlyFlag);

      if (CollectionUtils.isEmpty(fixChgResList)) {
        // 確定料金実績データが取得できなかった場合、以下の処理を行う。
        // メッセージを取得する。
        String nonFcrMessage = messageSource.getMessage("todo.T1018",
            new String[] {pmCompanyM.getPmCompany() }, Locale.getDefault());

        // 《TodoビジネスBean》を生成し、以下の値を設定する。
        TodoBusinessBean todoBusinessBean = new TodoBusinessBean();
        todoBusinessBean.setSubsystemId(ECISConstants.SUBSYSTEM_ID_SN);
        todoBusinessBean.setFunctionId(ECISTodoConstants.TODO_FUNCTION_ID.SN0106.toString());
        todoBusinessBean.setMessageId("todo.T1018");
        todoBusinessBean.setMessage(nonFcrMessage);

        // Todoを登録する。
        todoBusiness.registTodo(todoBusinessBean);
        // 処理を終了する。
        return null;
      }
    } else if (ECISConstants.FLG_OFF.equals(monthlyFlag)) {
      // 月次実行フラグが“OFF”の場合、以下の処理を行う。
      // 日次の【確定料金実績】を取得する。
      fixChgResList = selectFixChargeResult(null, null, batchDate, pmCompanyM.getPmCompanyCode(),
          monthlyFlag);

    } else {
      // 月次実行フラグが“ON”でも“OFF”でもない時、システム例外をスローする。
      throw new SystemException(messageSource.getMessage("error.E1325", new String[] {
          prop.getProperty(MONTHLY_FLAG), monthlyFlag }, Locale.getDefault()));
    }

    // 料金実績データをCSVファイルに出力する。
    creaChgResListBusinessBean = outputCsvFileChargeResultData(fixChgResList, workScheduleMngM, pmCompanyM,
        batchDate, usePeriod, monthlyFlag);

    // 料金実績一覧出力件数を項目に設定する。
    creaChgResListBusinessBean.setChargeResultListOutputCount(fixChgResList.size());

    // 料金実績一覧作成ビジネスBeanを返却する。
    return creaChgResListBusinessBean;
  }

  /**
   * 確定料金実績取得。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 確定料金実績を取得する。
   *
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param usePeriod
   *          利用年月
   * @param workScheduleMngM
   *          業務日程管理マスタEntityBean
   * @param cfd
   *          料金確定日
   * @param pmCompanyCode
   *          提供モデル企業コード
   * @param monthlyFlag
   *          月次実行フラグ
   * @return List<SN0106_CoveredCompanyFixChargeResultEntityBean> 確定料金実績EntityBeanリスト
   */
  private List<SN0106_CoveredCompanyFixChargeResultEntityBean> selectFixChargeResult(String usePeriod,
      WorkScheduleMngM workScheduleMngM, Date cfd, String pmCompanyCode, String monthlyFlag) {

    // 確定料金実績取得条件Mapを作成する。
    Map<String, Object> fixChargeReslutMap = new HashMap<String, Object>();

    if (usePeriod != null) {
      // 利用年月
      fixChargeReslutMap.put("use_period", usePeriod);
    }

    if (workScheduleMngM != null) {
      // 対象開始日
      fixChargeReslutMap.put("sd", workScheduleMngM.getTargetSd());
      // 対象終了日
      fixChargeReslutMap.put("ed", workScheduleMngM.getTargetEd());
    }

    if (cfd != null) {
      // 料金確定日
      fixChargeReslutMap.put("cfd", cfd);
    }

    // 提供モデル企業コード
    fixChargeReslutMap.put("pm_company_code", pmCompanyCode);
    // 料金ステータスコード:確定(2)
    fixChargeReslutMap.put("cs_code", ECISCodeConstants.CHARGE_STATUS_CODE_FIX);
    // 計器区分コード:常用(1)
    fixChargeReslutMap.put("meter_cat_code", ECISCodeConstants.METER_CATEGORY_CODE_FOR_IN_COMMON);
    // 月次実行フラグ
    fixChargeReslutMap.put("monthly_flag", monthlyFlag);

    // 確定料金実績取得
    List<SN0106_CoveredCompanyFixChargeResultEntityBean> fixChgResList = sn0106CreateChargeResultListMapper
        .selectCoveredCompanyFixChargeResult(fixChargeReslutMap);

    return fixChgResList;
  }

  /**
   * 料金実績データCSVファイル出力。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金実績データをCSVファイルに出力する。
   *
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param fixChgResList
   *          対象企業確定料金実績EntityBeanリスト
   * @param workScheduleMngM
   *          業務日程管理マスタEntityBean
   * @param pmCompanyM
   *          提供モデル企業マスタEntityBean
   * @param batchDate
   *          バッチ処理基準日
   * @param usePeriod
   *          利用年月
   * @param monthlyFlag
   *          月次実行フラグ
   * @return SN0106_CreateChargeResultListBusinessBean 料金実績一覧作成ビジネスBean
   */
  private SN0106_CreateChargeResultListBusinessBean outputCsvFileChargeResultData(
      List<SN0106_CoveredCompanyFixChargeResultEntityBean> fixChgResList,
      WorkScheduleMngM workScheduleMngM, PmCompanyM pmCompanyM, Date batchDate, String usePeriod,
      String monthlyFlag) {

    // 卸／取次事業者向け料金実績一覧ファイル
    File forWsAgOpChgResListFile = null;
    // 卸／取次事業者向け料金実績内訳ファイル
    File forWsAgOpChgResBrkdFile = null;
    // 卸／取次ぎ事業者向け料金実績一覧・内訳ファイル
    File forWsAgOpChgResListBrkdFile = null;
    // 料金実績内訳リスト
    List<SN0106_CoveredCompanyChargeResultBreakdownEntityBean> chgResBrkdList = null;
    // 料金実績一覧作成ビジネスBean
    SN0106_CreateChargeResultListBusinessBean creaChgResListBusinessBean = null;
    // 提供モデル企業コード
    String pmCompanyCode = pmCompanyM.getPmCompanyCode();
    // 料金実績一覧のCSVWriter
    CsvWriter chgResListCsvWriter = null;
    // 料金実績内訳のCSVWriter
    CsvWriter chgResBrkdCsvWriter = null;
    // 外部ファイルを生成する。
    Properties prop = null;

    // 外部ファイルを読み込む。
    try {
      prop = applicationProperties.getObject();
    } catch (IOException e) {
      throw new SystemException(messageSource.getMessage("error.E1278", null, Locale.getDefault()), e);
    }

    try {
      if (ECISConstants.FLG_ON.equals(monthlyFlag)) {
        // 月次実行フラグが“ON”の場合、月次ファイルの名称を取得する。
        creaChgResListBusinessBean = getMonthlyFileName(pmCompanyM, usePeriod);

      } else {
        // 月次実行フラグが“OFF”の場合、日時ファイルの名称を取得する。
        String cfd = new SimpleDateFormat(EMSConstants.FORMAT_DATE_yyyyMMdd).format(batchDate);
        creaChgResListBusinessBean = getDailyFileName(pmCompanyCode, cfd);
      }

      // 外部ファイルから以下の項目を取得する。
      String forWsAgOpChgResListHeader = prop.getProperty(CHG_RES_LIST_HEADER);
      String forWsAgOpChgResBrkdHeader = prop.getProperty(CHG_RES_BRKD_HEADER);
      String encode = prop.getProperty(ENCODE_TYPE_SJIS);

      // 外部ファイルから項目を取得できたか確認する。
      if (StringUtils.isEmpty(forWsAgOpChgResListHeader)
          || StringUtils.isEmpty(forWsAgOpChgResBrkdHeader)
          || StringUtils.isEmpty(encode)) {
        throw new SystemException(messageSource.getMessage("error.E1278", null, Locale.getDefault()));
      }

      // 卸／取次事業者向け料金実績一覧の空ファイルを作成する。
      forWsAgOpChgResListFile = new File(creaChgResListBusinessBean.getForWsAgOpChargeResultListFilePath());
      boolean chgResListCreateFlg = forWsAgOpChgResListFile.createNewFile();

      // 卸／取次事業者向け料金実績内訳の空ファイルを作成する。
      forWsAgOpChgResBrkdFile = new File(
          creaChgResListBusinessBean.getForWsAgOpChargeResultBreakdownFilePath());
      boolean chgResBrkdCreateFlg = forWsAgOpChgResBrkdFile.createNewFile();

      if (!chgResListCreateFlg
          || !chgResBrkdCreateFlg) {
        throw new SystemException(messageSource.getMessage("error.E1301", null, Locale.getDefault()));
      }

      if (ECISConstants.FLG_ON.equals(monthlyFlag)) {
        // 月次実行フラグが“ON”の場合、月次の料金実績内訳を取得する。
        chgResBrkdList = selectChargeResultBreakdown(usePeriod, workScheduleMngM, null, pmCompanyCode,
            monthlyFlag);

      } else {
        // 月次実行フラグが“OFF”の場合、日次の料金実績内訳を取得する。
        chgResBrkdList = selectChargeResultBreakdown(null, null, batchDate, pmCompanyCode, monthlyFlag);
      }

      // 料金実績一覧のCSVWriterを作成する。
      chgResListCsvWriter = gkWorkCommonBusiness.createCsvWriter(ECISSNConstants.OTHER_CSV_FILE,
          forWsAgOpChgResListFile, forWsAgOpChgResListHeader);

      // 料金実績一覧CSVファイルにデータを出力、「料金実績一覧CSVファイルデータ」を取得する。
      List<String[]> chgResListCsvFileData = outputCsvFileChargeResultList(fixChgResList,
          pmCompanyM.getPmCompany(), chgResListCsvWriter, forWsAgOpChgResListHeader);

      // 料金実績内訳のCSVWriterを作成する。
      chgResBrkdCsvWriter = gkWorkCommonBusiness.createCsvWriter(ECISSNConstants.OTHER_CSV_FILE,
          forWsAgOpChgResBrkdFile, forWsAgOpChgResBrkdHeader);

      // 料金実績内訳CSVファイルにデータを出力し、「料金実績内訳CSVファイルデータ」を取得する。
      List<String[]> chgResBrkdCsvFileData = outputCsvFileChargeResultBreakdown(chgResBrkdList,
          chgResBrkdCsvWriter, forWsAgOpChgResBrkdHeader);

      // 「料金実績内訳出力回数」を以下の項目に設定する。
      creaChgResListBusinessBean.setChargeResultBreakdownOutputCount(chgResBrkdCsvFileData.size() - 1);

      if (ECISConstants.FLG_ON.equals(monthlyFlag)) {
        // 月次実行フラグが“ON”の場合、以下の処理を行う。
        // 出力するZIPファイルの設定を行う。
        CsvConfig csvconfig = outputCsvConfig();
        // ZIPファイルを作成する。
        forWsAgOpChgResListBrkdFile = new File(
            creaChgResListBusinessBean.getForWsAgOpChargeResultListBreakdownFilePath());

        // ZIP出力ストリームを生成する。
        try (FileOutputStream fos = new FileOutputStream(forWsAgOpChgResListBrkdFile);
            ZipOutputStream zos = new ZipOutputStream(fos);) {
          // 「料金実績一覧CSVファイルデータ」をZIPファイルに出力する。
          Csv.save(chgResListCsvFileData, zos, encode, csvconfig, new StringArrayListHandler(),
              forWsAgOpChgResListFile.getName());
          // 「料金実績内訳CSVファイルデータ」をZIPファイルに出力する。
          Csv.save(chgResBrkdCsvFileData, zos, encode, csvconfig, new StringArrayListHandler(),
              forWsAgOpChgResBrkdFile.getName());

        }
      }
    } catch (BusinessLogicException e) {
      // 作成した卸／取次事業者向け料金実績一覧ファイルを削除する。
      deleteFile(forWsAgOpChgResListFile, chgResListCsvWriter);
      // 作成した卸／取次事業者向け料金実績内訳ファイルを削除する。
      deleteFile(forWsAgOpChgResBrkdFile, chgResBrkdCsvWriter);
      // キャッチした業務例外をスローする
      throw new SystemException(messageSource.getMessage(e.getMessagekey(), e.getParams(), Locale.getDefault()),
          e);

    } catch (SystemException e) {
      // 作成した卸／取次事業者向け料金実績一覧ファイルを削除する。
      deleteFile(forWsAgOpChgResListFile, chgResListCsvWriter);
      // 作成した卸／取次事業者向け料金実績内訳ファイルを削除する。
      deleteFile(forWsAgOpChgResBrkdFile, chgResBrkdCsvWriter);
      // キャッチしたシステム例外をスローする
      throw e;

    } catch (Exception e) {
      // 発生した例外にかかわらず、ファイルを削除するため、全ての例外をcatchする。
      // 作成した卸／取次事業者向け料金実績一覧ファイルを削除する。
      deleteFile(forWsAgOpChgResListFile, chgResListCsvWriter);
      // 作成した卸／取次事業者向け料金実績内訳ファイルを削除する。
      deleteFile(forWsAgOpChgResBrkdFile, chgResBrkdCsvWriter);
      // 作成したZIPファイルを削除する。
      deleteFile(forWsAgOpChgResListBrkdFile, null);
      // システム例外をスローする。
      throw new SystemException(messageSource.getMessage("error.E1301", null, Locale.getDefault()), e);

    }
    // CSVWriterを閉じる。
    IOUtils.closeQuietly(chgResListCsvWriter);
    IOUtils.closeQuietly(chgResBrkdCsvWriter);

    // 《料金実績一覧作成ビジネスBean》を返却する。
    return creaChgResListBusinessBean;
  }

  /**
   * 月次ファイル名称取得。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 月次用の論理ファイル名とファイルパスを取得する。
   *
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param pmCompanyM
   *          提供モデル企業マスタEntityBean
   * @param usePeriod
   *          利用年月
   * @return SN0106_CreateChargeResultListBusinessBean 料金実績一覧作成ビジネスBean
   */
  private SN0106_CreateChargeResultListBusinessBean getMonthlyFileName(PmCompanyM pmCompanyM, String usePeriod) {

    // 外部ファイルを生成する。
    Properties prop = null;

    // 外部ファイルを読み込む。
    try {
      prop = applicationProperties.getObject();
    } catch (IOException e) {
      throw new SystemException(messageSource.getMessage("error.E1278", null, Locale.getDefault()), e);
    }

    // 外部ファイルから、以下の項目を取得する。
    String forWsAgOpChgResOutDirectory = prop.getProperty(MONTHLY_CHG_RES_OUT_DIRECTORY);
    String forWsAgOpChgResListLgcFileName = prop.getProperty(MONTHLY_CHG_RES_LIST_LGC_FILE_NAME);
    String forWsAgOpChgResListPhsFileName = prop.getProperty(MONTHLY_CHG_RES_LIST_PHS_FILE_NAME);
    String forWsAgOpChgResBrkdLgcFileName = prop.getProperty(MONTHLY_CHG_RES_BRKD_LGC_FILE_NAME);
    String forWsAgOpChgResBrkdPhsFileName = prop.getProperty(MONTHLY_CHG_RES_BRKD_PHS_FILE_NAME);
    String forWsAgOpChgResListBrkdLgcFileName = prop.getProperty(MONTHLY_CHG_RES_LISTBRKD_LGC_FILE_NAME);
    String forWsAgOpChgResListBrkdPhsFileName = prop.getProperty(MONTHLY_CHG_RES_LISTBRKD_PHS_FILE_NAME);

    // 外部ファイルから項目を取得できたか確認する。
    if (StringUtils.isEmpty(forWsAgOpChgResOutDirectory)
        || StringUtils.isEmpty(forWsAgOpChgResListLgcFileName)
        || StringUtils.isEmpty(forWsAgOpChgResListPhsFileName)
        || StringUtils.isEmpty(forWsAgOpChgResBrkdLgcFileName)
        || StringUtils.isEmpty(forWsAgOpChgResBrkdPhsFileName)
        || StringUtils.isEmpty(forWsAgOpChgResListBrkdLgcFileName)
        || StringUtils.isEmpty(forWsAgOpChgResListBrkdPhsFileName)) {
      throw new SystemException(messageSource.getMessage("error.E1278", null, Locale.getDefault()));
    }

    // 「システム日時」(YYYYMMDDHHMMSS)を取得する。
    SimpleDateFormat format = new SimpleDateFormat(EMSConstants.FORMAT_DATE_yyyyMMddHHmmss);
    String creationTime = format.format(Calendar.getInstance().getTime());

    // 「利用年月」をyyyyとMMに切り分ける
    String yyyy = usePeriod.substring(YYYY_START, MM_START);
    String mm = usePeriod.substring(MM_START);

    // 提供モデル企業を取得する。
    String pmCompanyName = pmCompanyM.getPmCompany();

    // 提供モデル企業コードを取得する。
    String pmCompanyCode = pmCompanyM.getPmCompanyCode();

    // 「卸／取次事業者向け料金実績一覧論理ファイル名」を編集する。
    forWsAgOpChgResListLgcFileName = MessageFormat.format(forWsAgOpChgResListLgcFileName, pmCompanyName, yyyy, mm);

    // 「卸／取次事業者向け料金実績一覧ファイルパス」を取得する。
    String forWsAgOpChgResListFilePath = outputChargeResultFilePath(forWsAgOpChgResOutDirectory,
        forWsAgOpChgResListPhsFileName, pmCompanyCode, usePeriod, creationTime);

    // 「卸／取次事業者向け料金実績内訳論理ファイル名」を編集する。
    forWsAgOpChgResBrkdLgcFileName = MessageFormat.format(forWsAgOpChgResBrkdLgcFileName, pmCompanyName, yyyy, mm);

    // 「卸／取次事業者向け料金実績内訳ファイルパス」を取得する。
    String forWsAgOpChgResBrkdFilePath = outputChargeResultFilePath(forWsAgOpChgResOutDirectory,
        forWsAgOpChgResBrkdPhsFileName, pmCompanyCode, usePeriod, creationTime);

    // 「卸／取次事業者向け料金実績一覧・内訳論理ファイル名」を編集する。
    forWsAgOpChgResListBrkdLgcFileName = MessageFormat.format(forWsAgOpChgResListBrkdLgcFileName, pmCompanyName,
        yyyy, mm);

    // 「卸／取次事業者向け料金実績一覧・内訳ファイルパス」を取得する。
    String forWsAgOpChgResListBrkdFilePath = outputChargeResultFilePath(forWsAgOpChgResOutDirectory,
        forWsAgOpChgResListBrkdPhsFileName, pmCompanyCode, usePeriod, creationTime);

    // 料金実績一覧作成ビジネスBeanに、以下の項目を設定する。
    SN0106_CreateChargeResultListBusinessBean creaChgResListBusinessBean = new SN0106_CreateChargeResultListBusinessBean();
    creaChgResListBusinessBean.setForWsAgOpChargeResultListLogicalFileName(forWsAgOpChgResListLgcFileName);
    creaChgResListBusinessBean.setForWsAgOpChargeResultListFilePath(forWsAgOpChgResListFilePath);
    creaChgResListBusinessBean.setForWsAgOpChargeResultBreakdownLogicalFileName(forWsAgOpChgResBrkdLgcFileName);
    creaChgResListBusinessBean.setForWsAgOpChargeResultBreakdownFilePath(forWsAgOpChgResBrkdFilePath);
    creaChgResListBusinessBean.setForWsAgOpChargeResultListBreakdownLogicalFileName(
        forWsAgOpChgResListBrkdLgcFileName);
    creaChgResListBusinessBean.setForWsAgOpChargeResultListBreakdownFilePath(forWsAgOpChgResListBrkdFilePath);

    // 料金実績一覧作成ビジネスBeanを返却する。
    return creaChgResListBusinessBean;
  }

  /**
   * 日次ファイル名称取得。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 日次用のファイルパスを取得する。
   *
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param provideModelCompanyCode
   *          提供モデル企業コード
   * @param fixChargeDate
   *          料金確定日
   * @return SN0106_CreateChargeResultListBusinessBean 料金実績一覧作成ビジネスBean
   */
  private SN0106_CreateChargeResultListBusinessBean getDailyFileName(String provideModelCompanyCode,
      String fixChargeDate) {

    // 外部ファイルを生成する。
    Properties prop = null;

    // 外部ファイルを読み込む。
    try {
      prop = applicationProperties.getObject();
    } catch (IOException e) {
      throw new SystemException(messageSource.getMessage("error.E1278", null, Locale.getDefault()), e);
    }
    // 外部ファイルから、以下の項目を取得する。
    String forWsAgOpChgResOutDirectory = prop.getProperty(DAILY_CHG_RES_OUT_DIRECTORY);
    String forWsAgOpChgResListPhsFileName = prop.getProperty(DAILY_CHG_RES_LIST_PHS_FILE_NAME);
    String forWsAgOpChgResBrkdPhsFileName = prop.getProperty(DAILY_CHG_RES_BRKD_PHS_FILE_NAME);

    // 外部ファイルから項目を取得できたか確認する。
    if (StringUtils.isEmpty(forWsAgOpChgResOutDirectory)
        || StringUtils.isEmpty(forWsAgOpChgResListPhsFileName)
        || StringUtils.isEmpty(forWsAgOpChgResBrkdPhsFileName)) {
      throw new SystemException(messageSource.getMessage("error.E1278", null, Locale.getDefault()));
    }

    // 「システム日時」(YYYYMMDDHHMMSS)を取得する。
    SimpleDateFormat format = new SimpleDateFormat(EMSConstants.FORMAT_DATE_yyyyMMddHHmmss);
    String creationTime = format.format(Calendar.getInstance().getTime());

    // 「卸／取次事業者向け料金実績一覧ファイルパス」を取得する。
    String forWsAgOpChgResListFilePath = outputChargeResultFilePath(forWsAgOpChgResOutDirectory,
        forWsAgOpChgResListPhsFileName, fixChargeDate, provideModelCompanyCode, creationTime);

    // 「卸／取次事業者向け料金実績内訳ファイルパス」を取得する。
    String forWsAgOpChgResBrkdFilePath = outputChargeResultFilePath(forWsAgOpChgResOutDirectory,
        forWsAgOpChgResBrkdPhsFileName, fixChargeDate, provideModelCompanyCode, creationTime);

    // 料金実績一覧作成ビジネスBeanに、以下の項目を設定する。
    SN0106_CreateChargeResultListBusinessBean creaChgResListBusinessBean = new SN0106_CreateChargeResultListBusinessBean();
    creaChgResListBusinessBean.setForWsAgOpChargeResultListFilePath(forWsAgOpChgResListFilePath);
    creaChgResListBusinessBean.setForWsAgOpChargeResultBreakdownFilePath(forWsAgOpChgResBrkdFilePath);

    // 料金実績一覧作成ビジネスBeanを返却する。
    return creaChgResListBusinessBean;
  }

  /**
   * 料金実績ファイルパス出力。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 渡された料金実績ファイルのファイルパスを出力する。
   *
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param chgResFileOutDir
   *          料金実績ファイル出力ディレクトリ
   * @param chgResFileName
   *          料金実績ファイル名
   * @param plcHold
   *          プレースホルダ
   * @return String 料金実績ファイルパス
   */
  private String outputChargeResultFilePath(String chgResFileOutDir, String chgResFileName, Object... plcHold) {

    // 料金実績ファイル名を編集する。
    chgResFileName = MessageFormat.format(chgResFileName, plcHold);

    // 料金実績ファイルパス文字列長を算出する。
    int chgResFilePathLength = chgResFileOutDir.length() + chgResFileName.length();

    // 料金実績ファイルパスを作成する。
    StringBuilder chgRessb = new StringBuilder(chgResFilePathLength);

    // 料金実績ファイル出力ディレクトリを出力する。
    chgRessb.append(chgResFileOutDir);

    // 料金実績ファイル名を出力する。
    chgRessb.append(chgResFileName);

    // 料金実績ファイルパスを返却する。
    return chgRessb.toString();
  }

  /**
   * 料金実績内訳取得。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金実績内訳を取得する。
   *
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param usePeriod
   *          利用年月
   * @param workScheduleMngM
   *          業務日程管理マスタEntityBean
   * @param cfd
   *          料金確定日
   * @param pmCompanyCode
   *          提供モデル企業コード
   * @param monthlyFlag
   *          月次実行フラグ
   * @return List<SN0106_CoveredCompanyChargeResultBreakdownEntityBean> 料金実績内訳EntityBeanリスト
   */
  private List<SN0106_CoveredCompanyChargeResultBreakdownEntityBean> selectChargeResultBreakdown(String usePeriod,
      WorkScheduleMngM workScheduleMngM, Date cfd, String pmCompanyCode, String monthlyFlag) {

    // 料金実績内訳取得条件Mapを作成
    Map<String, Object> chargeReslutBreakdownMap = new HashMap<String, Object>();

    if (usePeriod != null) {
      // 利用年月
      chargeReslutBreakdownMap.put("use_period", usePeriod);
    }

    if (workScheduleMngM != null) {
      // 対象開始日
      chargeReslutBreakdownMap.put("sd", workScheduleMngM.getTargetSd());
      // 対象終了日
      chargeReslutBreakdownMap.put("ed", workScheduleMngM.getTargetEd());
    }

    if (cfd != null) {
      // 料金確定日
      chargeReslutBreakdownMap.put("cfd", cfd);
    }

    // 提供モデル企業コード
    chargeReslutBreakdownMap.put("pm_company_code", pmCompanyCode);
    // 料金ステータスコード:確定(2)
    chargeReslutBreakdownMap.put("cs_code", ECISCodeConstants.CHARGE_STATUS_CODE_FIX);
    // 計器区分コード:常用(1)
    chargeReslutBreakdownMap.put("meter_cat_code", ECISCodeConstants.METER_CATEGORY_CODE_FOR_IN_COMMON);
    // 月次実行フラグ
    chargeReslutBreakdownMap.put("monthly_flag", monthlyFlag);

    // 確定料金実績取得
    List<SN0106_CoveredCompanyChargeResultBreakdownEntityBean> chgResBrkdList = sn0106CreateChargeResultListMapper
        .selectCoveredCompanyChargeResultBreakdown(chargeReslutBreakdownMap);

    return chgResBrkdList;
  }

  /**
   * 料金実績一覧CSVファイル出力。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 対象企業の「確定料金実績」を「確定料金実績一覧ファイル」に出力する。
   *
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param coveredCompanyFixChargeResultEntityBean
   *          対象企業確定料金実績EntityBean
   * @param provideModelCompanyName
   *          提供モデル企業
   * @param chgResListCSVWriter
   *          料金実績一覧のCSVWriter
   * @param header
   *          料金実績一覧ヘッダ
   * @return List<String[]> 料金実績一覧CSVファイルデータ
   * @throws Exception
   *           予期せぬエラーが発生した場合
   */
  private List<String[]> outputCsvFileChargeResultList(
      List<SN0106_CoveredCompanyFixChargeResultEntityBean> coveredCompanyFixChargeResultEntityBeanList,
      String provideModelCompanyName, CsvWriter chgResListCSVWriter, String header)
      throws BusinessLogicException, IOException {

    // 外部ファイルを読み込む。
    Properties prop = null;
    try {
      prop = applicationProperties.getObject();
    } catch (IOException e) {
      throw new SystemException(messageSource.getMessage("error.E1278", null, Locale.getDefault()), e);
    }

    // 外部ファイルから以下の項目を取得する。
    String listCsvFileSetInfo = prop.getProperty(LIST_CSV_FILE_SETTING_INFO);
    String summerSeasonTimeCode = prop.getProperty(TIME_SLOT_CODE_SUMMER);
    String otherSeasonTimeCode = prop.getProperty(TIME_SLOT_CODE_OTHER);

    // 外部ファイルから項目を取得できたか確認する。
    if (StringUtils.isEmpty(listCsvFileSetInfo)
        || StringUtils.isEmpty(summerSeasonTimeCode)
        || StringUtils.isEmpty(otherSeasonTimeCode)) {
      throw new SystemException(messageSource.getMessage("error.E1278", null, Locale.getDefault()));
    }

    // 「料金実績一覧CSVファイルデータ」を生成する。
    List<String[]> chgResListCsvFileData = outputCsvFileData(header);
    // 「CSVファイルレコード設定情報」を取得する。
    Map<String, String> csvFileSetInfo = snBillingCommonBusiness.getPropertiesData(listCsvFileSetInfo);

    // 《対象企業確定料金実績EntityBean》リストの件数分、以下の処理を繰り返す。
    for (SN0106_CoveredCompanyFixChargeResultEntityBean cvrCompFixChgResEntityBean : coveredCompanyFixChargeResultEntityBeanList) {

      // 時間帯別使用量を取得する。
      List<Map<String, Object>> byTimeSlotUsageList = selectByTimeSlotUsage(cvrCompFixChgResEntityBean,
          summerSeasonTimeCode, otherSeasonTimeCode);

      // 夏季時間帯使用量を生成する。
      BigDecimal summerUsageSum = null;
      // 他季時間帯使用量を生成する。
      BigDecimal otherUsageSum = null;

      // 取得した時間帯別使用量分、処理を繰り返す。
      for (Map<String, Object> byTimeSlotUsage : byTimeSlotUsageList) {
        if (byTimeSlotUsage.containsValue(summerSeasonTimeCode)) {
          // 夏季時間帯コードをキーに時間帯別使用量キーMapから使用量の合算値を取得する。
          summerUsageSum = (BigDecimal) byTimeSlotUsage.get("usageQuantity");
        }
        if (byTimeSlotUsage.containsValue(otherSeasonTimeCode)) {
          // その他季時間帯コードをキーに時間帯別使用量キーMapから使用量の合算値を取得する。
          otherUsageSum = (BigDecimal) byTimeSlotUsage.get("usageQuantity");
        }
      }

      // 日割別使用量取得を呼び出し、日割別使用量リストを取得する。
      List<SN0106_DateSlotUsageEntityBean> dateSlotUsageList = selectByDateSlotUsage(
          cvrCompFixChgResEntityBean.getFcr().getFuId());

      // 《対象企業確定料金実績EntityBean》から各EntityBeanを取り出す。
      Fcr fcr = cvrCompFixChgResEntityBean.getFcr();
      Fu fu = cvrCompFixChgResEntityBean.getFu();
      FixIn fixIn = cvrCompFixChgResEntityBean.getFixIn();

      // 料金実績一覧データビジネスBeanを生成する。
      SN0106_ChargeResultListDataBusinessBean chgResListDataBean = createChgResListData(fcr, fu, fixIn,
          dateSlotUsageList,
          cvrCompFixChgResEntityBean, summerUsageSum, otherUsageSum, provideModelCompanyName);

      // 確定料金実績一覧の一行分を取得する。
      List<String> outputCsvList = snBillingCommonBusiness.createListForCsv(chgResListDataBean, csvFileSetInfo,
          ECISSNConstants.OTHER_CSV_FILE);
      // 確定料金実績一覧の一行分を格納する。
      chgResListCsvFileData.add((String[]) outputCsvList.toArray(new String[0]));
      // 取得した確定料金実績一覧の一行分をCSVファイルに書き込む。
      chgResListCSVWriter.writeValues(outputCsvList);
    }

    // CSVファイルに書き込んだ内容を反映させる。
    chgResListCSVWriter.flush();

    // 料金実績一覧CSVファイルデータを返却する。
    return chgResListCsvFileData;
  }

  /**
   * 料金実績内訳CSVファイル出力。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 対象企業の「料金実績内訳」を「確定料金実績内訳ファイル」に出力する。
   *
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param cvrCompChgResBrkdEntityBeanList
   *          対象企業料金実績内訳EntityBean
   * @param chgResBrkdCSVWriter
   *          料金実績内訳のCSVWriter
   * @param header
   *          料金実績内訳ヘッダ
   * @return List<String[]> 料金実績内訳CSVファイルデータ
   * @throws Exception
   *           予期せぬエラーが発生した場合
   */
  private List<String[]> outputCsvFileChargeResultBreakdown(
      List<SN0106_CoveredCompanyChargeResultBreakdownEntityBean> cvrCompChgResBrkdEntityBeanList,
      CsvWriter chgResBrkdCSVWriter, String header) throws BusinessLogicException, IOException {

    // 外部ファイルを生成する。
    Properties prop = null;

    // 外部ファイルを読み込む。
    try {
      prop = applicationProperties.getObject();
    } catch (IOException e) {
      throw new SystemException(messageSource.getMessage("error.E1278", null, Locale.getDefault()), e);
    }

    // 外部ファイルからCSVファイルレコード設定情報ファイル（料金実績内訳）を取得する。
    String brkdCsvFileSetInfo = prop.getProperty(BREAKDOWN_CSV_FILE_SETTING_INFO);

    // 外部ファイルから項目を取得できたか確認する。
    if (StringUtils.isEmpty(brkdCsvFileSetInfo)) {
      throw new SystemException(messageSource.getMessage("error.E1278", null, Locale.getDefault()));
    }

    // 「料金実績内訳CSVファイルデータ」を生成する。
    List<String[]> chgResBrkdCsvFileData = outputCsvFileData(header);

    // 「CSVファイルレコード設定情報」を取得する。
    Map<String, String> csvFileSetInfo = snBillingCommonBusiness.getPropertiesData(brkdCsvFileSetInfo);

    // 《対象企業料金実績内訳EntityBean》リストの件数分、以下の処理を繰り返す。
    for (SN0106_CoveredCompanyChargeResultBreakdownEntityBean cvrCompChgResBrkdEntityBean : cvrCompChgResBrkdEntityBeanList) {

      // 《料金実績内訳データBean》を生成し、項目を設定する。
      SN0106_ChargeResultBreakdownDataBusinessBean chgResBrkdDataBean = new SN0106_ChargeResultBreakdownDataBusinessBean();

      // 数値フォーマット（0.00）
      DecimalFormat df12 = new DecimalFormat(ECISConstants.FORMAT_DECIMAL_SCALE_1_2);
      // 数値フォーマット（0.000）
      DecimalFormat df13 = new DecimalFormat(ECISConstants.FORMAT_DECIMAL_SCALE_1_3);

      // 確定料金実績内訳EntityBean
      FcrBreakdown fcrBrkDown = cvrCompChgResBrkdEntityBean.getFcrBreakdown();

      chgResBrkdDataBean.setFcrId(fcrBrkDown.getFcrId() != null ? fcrBrkDown.getFcrId().toString() : null);
      chgResBrkdDataBean.setDisplayOrder(
          fcrBrkDown.getDisplayOrder() != null ? fcrBrkDown.getDisplayOrder().toString() : null);
      chgResBrkdDataBean.setDetailOutputOrder(
          fcrBrkDown.getDetailOutputOrder() != null ? fcrBrkDown.getDetailOutputOrder().toString() : null);
      chgResBrkdDataBean.setDisplayName1(fcrBrkDown.getDisplayName1());
      chgResBrkdDataBean.setDisplayName2(fcrBrkDown.getDisplayName2());
      chgResBrkdDataBean.setCapacityOrUsage(
          fcrBrkDown.getCapacityOrUsage() != null ? df12.format(fcrBrkDown.getCapacityOrUsage()) : null);
      chgResBrkdDataBean.setUp(fcrBrkDown.getUp() != null ? df12.format(fcrBrkDown.getUp()) : null);
      chgResBrkdDataBean.setAmount(fcrBrkDown.getAmount() != null ? df12.format(fcrBrkDown.getAmount()) : null);
      chgResBrkdDataBean.setSplContractId(
          fcrBrkDown.getSplContractId() != null ? fcrBrkDown.getSplContractId().toString() : null);
      chgResBrkdDataBean.setSplRate(
          fcrBrkDown.getSplRate() != null ? df13.format(fcrBrkDown.getSplRate()) : null);
      chgResBrkdDataBean.setSplCoveredCatCode(fcrBrkDown.getSplCoveredCatCode());
      chgResBrkdDataBean.setFcrBreakdownCatCode(fcrBrkDown.getFcrBreakdownCatCode());
      chgResBrkdDataBean.setSupplementaryCoveredCat(cvrCompChgResBrkdEntityBean.getSupplementaryCoveredCat());
      chgResBrkdDataBean.setFcrBreakdownCat(cvrCompChgResBrkdEntityBean.getFcrBreakdownCat());

      // 確定料金実績内訳の一行分を取得する。
      List<String> outputCsvList = snBillingCommonBusiness.createListForCsv(chgResBrkdDataBean, csvFileSetInfo,
          ECISSNConstants.OTHER_CSV_FILE);

      // 確定料金実績内訳の一行分を格納する。
      chgResBrkdCsvFileData.add((String[]) outputCsvList.toArray(new String[0]));

      // 取得した確定料金実績内訳の一行分をCSVファイルに書き込む。
      chgResBrkdCSVWriter.writeValues(outputCsvList);
    }
    // CSVファイルに書き込んだ内容を反映させる。
    chgResBrkdCSVWriter.flush();

    // 「料金実績内訳CSVファイルデータ」を返却する。
    return chgResBrkdCsvFileData;
  }

  /**
   * CSVファイルデータ出力。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * ヘッダ情報からCSVファイルデータを出力する。
   *
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param header
   *          ヘッダ情報
   * @return List<String[]> CSVファイルデータ
   */
  private List<String[]> outputCsvFileData(String header) {

    // CSVファイルデータを生成する。
    List<String[]> csvFileData = new ArrayList<>();

    // ヘッダをカンマ区切り分割する。
    String[] headerSplit = header.split(EMSConstants.COMMA, -1);

    try {
      for (int i = 0; i < headerSplit.length; i++) {
        if (StringUtils.isNotEmpty(headerSplit[i])) {
          // 値が設定されている場合は文字コードをSJISに変換する。
          headerSplit[i] = StringConvertUtil.utf8ToSjis(headerSplit[i]);

        } else if ("".equals(headerSplit[i])) {
          // 空文字があった場合はnullに変換する。
          headerSplit[i] = null;
        }
      }
    } catch (UnsupportedEncodingException e) {
      // UTF-8からSJISの変換処理であるため、起こり得ない例外
      throw new SystemException(messageSource.getMessage("error.E0011", null, Locale.getDefault()), e);
    }

    // CSVファイルデータにヘッダを追加する。
    csvFileData.add(headerSplit);

    // CSVファイルデータを返却する。
    return csvFileData;
  }

  /**
   * 時間帯別使用量取得。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 時間帯別使用量を取得する。
   *
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param cvrCompFixChgResEntityBean
   *          対象企業確定料金実績EntityBean
   * @param summerSeasonTimeCode
   *          夏季時間帯コード
   * @param otherSeasonTimeCode
   *          他季時間帯コード
   * @return List<Map<String,BigDecimal>> 時間帯別使用量キーMapリスト
   */
  private List<Map<String, Object>> selectByTimeSlotUsage(
      SN0106_CoveredCompanyFixChargeResultEntityBean cvrCompFixChgResEntityBean, String summerSeasonTimeCode,
      String otherSeasonTimeCode) {

    // 時間帯別使用量取得Mapを作成
    Map<String, Object> selectByTimeSlotUsageMap = new HashMap<String, Object>();
    // 確定使用量ID
    selectByTimeSlotUsageMap.put("fu_id", cvrCompFixChgResEntityBean.getFu().getFuId());
    // 夏季時間帯コード
    selectByTimeSlotUsageMap.put("ts_code1", summerSeasonTimeCode);
    // 他季時間帯コード
    selectByTimeSlotUsageMap.put("ts_code2", otherSeasonTimeCode);
    // 時間帯別使用量取得
    List<Map<String, Object>> byTimeSlotUsageList = sn0106CreateChargeResultListMapper
        .selectByTimeSlotUsage(selectByTimeSlotUsageMap);

    return byTimeSlotUsageList;
  }

  /**
   * 日割別使用量取得。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 日割別使用量を取得する。
   *
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param String
   *          確定使用量ID
   * @return List<Map<String, Object>> 日割別使用量キーMapリスト
   */
  private List<SN0106_DateSlotUsageEntityBean> selectByDateSlotUsage(
      Integer fuId) {

    // 日割別使用量取得Mapを作成
    Map<String, Object> selectByDateSlotUsageMap = new HashMap<String, Object>();
    // 確定使用量ID
    selectByDateSlotUsageMap.put("fu_id", fuId);
    // 日割別使用量取得
    List<SN0106_DateSlotUsageEntityBean> byDateSlotUsageList = sn0106CreateChargeResultListMapper
        .selectByDateSlotUsage(selectByDateSlotUsageMap);

    return byDateSlotUsageList;
  }

  /**
   * 料金実績一覧データビジネスBean生成。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 対象企業の「確定料金実績」を「確定料金実績一覧データビジネスBean」に出力する。
   *
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param fcr
   *          確定料金実績
   * @param fu
   *          確定使用量
   * @param fixIn
   *          確定指示数
   * @param dateSlotUsageEntityBean
   *          日割別使用量EntityBean
   * @param cvrCompFixChgResEntityBean
   *          対象企業確定料金実績EntityBean
   * @param summerUsageSum
   *          夏季使用量合算値
   * @param otherUsageSum
   *          他季使用量合算値
   * @param provideModelCompanyName
   *          提供モデル企業
   * @return SN0106_ChargeResultListDataBusinessBean 料金実績一覧データビジネスBean
   */
  private SN0106_ChargeResultListDataBusinessBean createChgResListData(Fcr fcr, Fu fu, FixIn fixIn,
      List<SN0106_DateSlotUsageEntityBean> dateSlotUsageEntityBean,
      SN0106_CoveredCompanyFixChargeResultEntityBean cvrCompFixChgResEntityBean,
      BigDecimal summerUsageSum, BigDecimal otherUsageSum, String provideModelCompanyName) {

    // 利用年月に/を付与する。
    String usePeriod = (fcr.getUsePeriod().substring(YYYY_START, MM_START)) + ECISConstants.SLASH
        + (fcr.getUsePeriod().substring(MM_START));

    // 実量歴の対象年月
    String coveredPeriod = null;
    if (StringUtils.isNotEmpty(cvrCompFixChgResEntityBean.getCoveredPeriod())) {
      coveredPeriod = (cvrCompFixChgResEntityBean.getCoveredPeriod().substring(YYYY_START, MM_START))
          + ECISConstants.SLASH
          + (cvrCompFixChgResEntityBean.getCoveredPeriod().substring(MM_START));
    }

    // 日付フォーマット
    SimpleDateFormat sdfYmdSlash = new SimpleDateFormat(ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH);

    // 数値フォーマット（0.##）
    DecimalFormat df1n2 = new DecimalFormat(ECISConstants.FORMAT_DECIMAL_SCALE_1_N2);
    // 数値フォーマット（0.00）
    DecimalFormat df12 = new DecimalFormat(ECISConstants.FORMAT_DECIMAL_SCALE_1_2);
    // 数値フォーマット（0.000）
    DecimalFormat df13 = new DecimalFormat(ECISConstants.FORMAT_DECIMAL_SCALE_1_3);
    // 数値フォーマット（0.0000）
    DecimalFormat df14 = new DecimalFormat(ECISConstants.FORMAT_DECIMAL_SCALE_1_4);

    SN0106_ChargeResultListDataBusinessBean chgResListDataBean = new SN0106_ChargeResultListDataBusinessBean();
    chgResListDataBean.setFcrId(fcr.getFcrId() != null ? fcr.getFcrId().toString() : null);
    chgResListDataBean.setContractId(fcr.getContractId() != null ? fcr.getContractId().toString() : null);
    chgResListDataBean.setContractNo(fcr.getContractNo());
    chgResListDataBean.setApplySd(fcr.getApplySd() != null ? sdfYmdSlash.format(fcr.getApplySd()) : null);
    chgResListDataBean.setUsePeriod(usePeriod);
    chgResListDataBean.setContractorId(fcr.getContractorId() != null ? fcr.getContractorId().toString() : null);
    chgResListDataBean.setContractorNo(fcr.getContractorNo());
    chgResListDataBean.setSectionCode(fcr.getSectionCode());
    chgResListDataBean.setCustomerCode(fcr.getCustomerCode());
    chgResListDataBean.setPmCode(fcr.getPmCode());
    chgResListDataBean.setPmCompanyCode(fcr.getPmCompanyCode());
    chgResListDataBean.setMlId(fcr.getMlId() != null ? fcr.getMlId().toString() : null);
    chgResListDataBean.setAreaCode(fcr.getAreaCode());
    chgResListDataBean.setOurMngAreaCode(fcr.getOurMngAreaCode());
    chgResListDataBean.setSpotNo(fcr.getSpotNo());
    chgResListDataBean.setNextMrScheduledDate(
        fcr.getNextMrScheduledDate() != null ? sdfYmdSlash.format(fcr.getNextMrScheduledDate()) : null);
    chgResListDataBean.setRmId(fcr.getRmId());
    chgResListDataBean.setCca(fcr.getCca() != null ? df1n2.format(fcr.getCca()) : null);
    chgResListDataBean.setConsignmentCca(
        fcr.getConsignmentCca() != null ? df1n2.format(fcr.getConsignmentCca()) : null);
    chgResListDataBean.setDealClassCode(fcr.getDealClassCode());
    chgResListDataBean.setFuId(fcr.getFuId() != null ? fcr.getFuId().toString() : null);
    chgResListDataBean.setMrDate(fcr.getMrDate() != null ? sdfYmdSlash.format(fcr.getMrDate()) : null);
    chgResListDataBean.setMrReasonCode(fcr.getMrReasonCode());
    chgResListDataBean.setCcSd(fcr.getCcSd() != null ? sdfYmdSlash.format(fcr.getCcSd()) : null);
    chgResListDataBean.setCcEd(fcr.getCcEd() != null ? sdfYmdSlash.format(fcr.getCcEd()) : null);
    chgResListDataBean.setCfd(fcr.getCfd() != null ? sdfYmdSlash.format(fcr.getCfd()) : null);
    chgResListDataBean.setCalculatingPowerFactor(
        fcr.getCalculatingPowerFactor() != null ? fcr.getCalculatingPowerFactor().toString() : null);
    chgResListDataBean.setFixCharge(fcr.getMonthlyCharge() != null ? fcr.getMonthlyCharge().toString() : null);
    chgResListDataBean.setCtEquivalent(fcr.getCtEquivalent() != null ? fcr.getCtEquivalent().toString() : null);
    chgResListDataBean.setCtRate(fcr.getCtRate() != null ? fcr.getCtRate().toString() : null);
    chgResListDataBean.setCtIc(fcr.getCtIc());
    chgResListDataBean.setBasicCharge(fcr.getBasicCharge() != null ? df12.format(fcr.getBasicCharge()) : null);
    chgResListDataBean.setPowerConsumptionCharge(
        fcr.getUsageCharge() != null ? df12.format(fcr.getUsageCharge()) : null);
    chgResListDataBean.setFca(fcr.getFca() != null ? df12.format(fcr.getFca()) : null);
    chgResListDataBean.setRec(fcr.getRec() != null ? df12.format(fcr.getRec()) : null);
    chgResListDataBean.setContractExcessCharge(fcr.getCec() != null ? df12.format(fcr.getCec()) : null);
    chgResListDataBean.setSplAmount(fcr.getSplAmount() != null ? df12.format(fcr.getSplAmount()) : null);
    chgResListDataBean.setSp1Correction(
        fcr.getSp1Correction() != null ? df12.format(fcr.getSp1Correction()) : null);
    chgResListDataBean.setSp2Correction(
        fcr.getSp2Correction() != null ? df12.format(fcr.getSp2Correction()) : null);
    chgResListDataBean.setSp3Correction(
        fcr.getSp3Correction() != null ? df12.format(fcr.getSp3Correction()) : null);
    chgResListDataBean.setSpRecordedDate(
        fcr.getSpRecordedDate() != null ? sdfYmdSlash.format(fcr.getSpRecordedDate()) : null);
    chgResListDataBean.setSpRecordedExecuteDate(
        fcr.getSpRecordedExecuteDate() != null ? sdfYmdSlash.format(fcr.getSpRecordedExecuteDate()) : null);
    chgResListDataBean.setSpIc1(fcr.getSpIc1());
    chgResListDataBean.setSp1(fcr.getSp1() != null ? fcr.getSp1().toString() : null);
    chgResListDataBean.setSpIc2(fcr.getSpIc2());
    chgResListDataBean.setSp2(fcr.getSp2() != null ? fcr.getSp2().toString() : null);
    chgResListDataBean.setSpIc3(fcr.getSpIc3());
    chgResListDataBean.setSp3(fcr.getSp3() != null ? fcr.getSp3().toString() : null);
    chgResListDataBean.setArIc(fcr.getArIc());
    chgResListDataBean.setArAmount(fcr.getArAmount() != null ? fcr.getArAmount().toString() : null);
    chgResListDataBean.setArRccRecordedDate(
        fcr.getArRccRecordedDate() != null ? sdfYmdSlash.format(fcr.getArRccRecordedDate()) : null);
    chgResListDataBean.setArRccBaseDate(
        fcr.getArRccBaseDate() != null ? sdfYmdSlash.format(fcr.getArRccBaseDate()) : null);
    chgResListDataBean.setArRccExecuteDate(
        fcr.getArRccExecuteDate() != null ? sdfYmdSlash.format(fcr.getArRccExecuteDate()) : null);
    chgResListDataBean.setBlNo(fcr.getBlNo());
    chgResListDataBean.setBlRccAppropriationFlag(fcr.getBlRccAppropriationFlag());
    chgResListDataBean.setArRccTransferIc(fcr.getArRccTransferIc());
    chgResListDataBean.setCompletedFlag(fcr.getCompletedFlag());
    chgResListDataBean.setCsCode(fcr.getCsCode());
    chgResListDataBean.setCcccFlag(fcr.getCcccFlag());
    chgResListDataBean.setContractGroupNo(fcr.getContractGroupNo());
    chgResListDataBean.setWarningDealCatCode(fcr.getWarningDealCatCode());
    chgResListDataBean.setFcrCreateDate(
        fcr.getCreateDate() != null ? sdfYmdSlash.format(fcr.getCreateDate()) : null);
    chgResListDataBean.setCssCatCode(fcr.getCssCatCode());
    chgResListDataBean.setConsignmentChargeEquivalent(
        fcr.getConsignmentChargeEquivalent() != null ? fcr.getConsignmentChargeEquivalent().toString() : null);
    chgResListDataBean.setNote(fcr.getNote());
    chgResListDataBean.setCcaUnit(fcr.getCcaUnit());
    chgResListDataBean.setConsignmentCcaUnit(fcr.getConsignmentCcaUnit());
    chgResListDataBean.setConsignmentCcaDecisionDate(
        fcr.getConsignmentCcaDecisionDate() != null ? sdfYmdSlash.format(fcr.getConsignmentCcaDecisionDate())
            : null);
    chgResListDataBean.setScCode(fcr.getScCode());
    chgResListDataBean.setBusinessTypeCode(fcr.getBusinessTypeCode());
    chgResListDataBean.setUsageQuantity(fu.getUsageQuantity() != null ? df12.format(fu.getUsageQuantity()) : null);
    chgResListDataBean.setPdReference(fu.getPdReference() != null ? fu.getPdReference().toString() : null);
    chgResListDataBean.setUsageSd(fu.getUsageSd() != null ? sdfYmdSlash.format(fu.getUsageSd()) : null);
    chgResListDataBean.setUsageEd(fu.getUsageEd() != null ? sdfYmdSlash.format(fu.getUsageEd()) : null);
    chgResListDataBean.setCcDays(fu.getCcDays() != null ? fu.getCcDays().toString() : null);
    chgResListDataBean.setFuCreateDate(fu.getCreateDate() != null ? sdfYmdSlash.format(fu.getCreateDate()) : null);
    chgResListDataBean.setPowerFactor(fu.getPowerFactor() != null ? fu.getPowerFactor().toString() : null);
    chgResListDataBean.setMeterCatCode(fixIn.getMeterCatCode());

    // 全日電力量当月指示数
    chgResListDataBean.setCurrentIn(fixIn.getFtuCurrentIn() != null ? df13.format(fixIn.getFtuCurrentIn()) : null);

    // 全日電力量前月指示数
    chgResListDataBean.setPreviousIn(
        fixIn.getFtuPreviousIn() != null ? df13.format(fixIn.getFtuPreviousIn()) : null);

    // 全日電力量指示数差（差引）
    chgResListDataBean.setInDifference(
        fixIn.getInDifference() != null ? df13.format(fixIn.getInDifference()) : null);

    // 乗率
    chgResListDataBean.setMultiplyingFactor(
        fixIn.getMultiplyingFactor() != null ? fixIn.getMultiplyingFactor().toString() : null);

    // 全日電力量指示数算出使用量
    chgResListDataBean.setInCalculationUsage(
        fixIn.getInCalculationUsage() != null ? df12.format(fixIn.getInCalculationUsage()) : null);

    // 計器交換フラグ
    chgResListDataBean.setMeterReplacementFlag(fixIn.getMeterReplacementFlag());

    // 計器識別番号
    chgResListDataBean.setMeterIdn(fixIn.getMeterIdn());

    // 力測有効電力量当月指示数
    chgResListDataBean.setEffectiveCurrentIndicationNo(
        fixIn.getEffectiveCurrentIndicationNo() != null ? df13.format(fixIn.getEffectiveCurrentIndicationNo())
            : null);

    // 力測有効電力量前月指示数
    chgResListDataBean.setEffectivePreviousIndicationNo(
        fixIn.getEffectivePreviousIndicationNo() != null ? df13.format(fixIn.getEffectivePreviousIndicationNo())
            : null);

    // 力測有効電力量指示数差（差引）
    chgResListDataBean.setEffectiveIndicationNoDifference(
        fixIn.getEffectiveIndicationNoDifference() != null
            ? df13.format(fixIn.getEffectiveIndicationNoDifference())
            : null);

    // 力測無効電力量指示数算出使用量
    chgResListDataBean.setEffectiveIndicationNoCalculationUsage(
        fixIn.getEffectiveIndicationNoCalculationUsage() != null
            ? df12.format(fixIn.getEffectiveIndicationNoCalculationUsage())
            : null);

    // 力測無効電力量当月指示数
    chgResListDataBean.setReactiveCurrentIndicationNo(
        fixIn.getReactiveCurrentIndicationNo() != null ? df13.format(fixIn.getReactiveCurrentIndicationNo())
            : null);

    // 力測無効電力量前月指示数
    chgResListDataBean.setReactivePreviousIndicationNo(
        fixIn.getReactivePreviousIndicationNo() != null ? df13.format(fixIn.getReactivePreviousIndicationNo())
            : null);

    // 力測無効電力量指示数差（差引）
    chgResListDataBean.setReactiveIndicationNoDifference(
        fixIn.getReactiveIndicationNoDifference() != null
            ? df13.format(fixIn.getReactiveIndicationNoDifference())
            : null);

    // 力測無効電力量指示数算出使用量
    chgResListDataBean.setReactiveIndicationNoCalculationUsage(
        fixIn.getReactiveIndicationNoCalculationUsage() != null
            ? df12.format(fixIn.getReactiveIndicationNoCalculationUsage())
            : null);

    // 損失補正率
    chgResListDataBean.setKwhDisadvantageFactor(
        fixIn.getKwhDisadvantageFactor() != null ? df14.format(fixIn.getKwhDisadvantageFactor()) : null);

    // 実量歴対象年月
    chgResListDataBean.setCoveredPeriod(coveredPeriod);

    // 実量歴最大電力
    chgResListDataBean.setPeakKw(
        cvrCompFixChgResEntityBean.getPkw() != null ? df12.format(cvrCompFixChgResEntityBean.getPkw()) : null);

    // 日割別1
    if (dateSlotUsageEntityBean != null && dateSlotUsageEntityBean.size() > 0) {
      chgResListDataBean.setContractCapacity1(df12.format(dateSlotUsageEntityBean.get(0).getContractCapacity()));
      chgResListDataBean.setUsageQuantity1(df12.format(dateSlotUsageEntityBean.get(0).getUsageQuantity()));
    }

    // 日割別2
    if (dateSlotUsageEntityBean != null && dateSlotUsageEntityBean.size() > 1) {
      chgResListDataBean.setContractCapacity2(df12.format(dateSlotUsageEntityBean.get(1).getContractCapacity()));
      chgResListDataBean.setUsageQuantity2(df12.format(dateSlotUsageEntityBean.get(1).getUsageQuantity()));
    }

    // 日割別3
    if (dateSlotUsageEntityBean != null && dateSlotUsageEntityBean.size() > 2) {
      chgResListDataBean.setContractCapacity3(df12.format(dateSlotUsageEntityBean.get(2).getContractCapacity()));
      chgResListDataBean.setUsageQuantity3(df12.format(dateSlotUsageEntityBean.get(2).getUsageQuantity()));
    }
    chgResListDataBean.setRmName(cvrCompFixChgResEntityBean.getDisplayName());
    chgResListDataBean.setAreaName(cvrCompFixChgResEntityBean.getAreaName());
    chgResListDataBean.setSummerSeasonUsage(summerUsageSum != null ? df12.format(summerUsageSum) : null);
    chgResListDataBean.setOtherSeasonUsage(otherUsageSum != null ? df12.format(otherUsageSum) : null);
    chgResListDataBean.setPmCompanyName(provideModelCompanyName);

    return chgResListDataBean;
  }

  /**
   * ZIPファイル出力設定。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * ZIPファイルを出力する際の設定を行う。
   *
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return CsvConfig ZIPファイル出力設定
   */
  private CsvConfig outputCsvConfig() {

    // ZIPファイル出力設定を生成する。
    CsvConfig csvconfig = new CsvConfig();

    // 全ての項目に対して囲み文字ダブルクォートが有効。
    csvconfig.setQuoteDisabled(false);
    csvconfig.setQuotePolicy(QuotePolicy.ALL);
    csvconfig.setQuote(CsvConfig.DEFAULT_QUOTE);
    // エスケープ文字ダブルクォートが有効。
    csvconfig.setEscapeDisabled(false);
    csvconfig.setEscape(CsvConfig.DEFAULT_QUOTE);
    // 改行コードの設定。
    csvconfig.setLineSeparator(EMSConstants.ENTER_CODE);

    return csvconfig;
  }

  /**
   * ファイル削除。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 指定されたファイルを削除する。
   *
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param file
   *          削除ファイル
   */
  private void deleteFile(File file, CsvWriter csvWriter) {
    if (csvWriter != null) {
      IOUtils.closeQuietly(csvWriter);

    }
    if (file != null && file.exists()) {
      // 指定されたファイルを削除する。
      file.delete();
    }
  }

  /**
   * プロパティ定義クラスを設定する。(DI)
   *
   * @author "Nihon Unisys, Ltd."
   * @param applicationProperties
   */
  public void setApplicationProperties(
      PropertiesFactoryBean applicationProperties) {
    this.applicationProperties = applicationProperties;
  }

  /**
   * メッセージプロパティを設定する。(DI)
   *
   * @author "Nihon Unisys, Ltd."
   * @param messageSource
   */
  public void setMessageSource(
      MessageSource messageSource) {
    this.messageSource = messageSource;
  }

  /**
   * Todo登録を設定する。(DI)
   *
   * @author "Nihon Unisys, Ltd."
   * @param todoBusiness
   */
  public void setTodoBusiness(
      TodoBusiness todoBusiness) {
    this.todoBusiness = todoBusiness;
  }

  /**
   * 請求入金共通ビジネスを設定する。(DI)
   *
   * @author "Nihon Unisys, Ltd."
   * @param snSN_BillingCommonBusinessCommonBusiness
   */
  public void setSnBillingCommonBusiness(
      SN_BillingCommonBusiness snBillingCommonBusiness) {
    this.snBillingCommonBusiness = snBillingCommonBusiness;
  }

  /**
   * 業務共通ビジネスを設定する。(DI)
   *
   * @author "Nihon Unisys, Ltd."
   * @param gkWorkCommonBusiness
   */
  public void setGkWorkCommonBusiness(
      GK_WorkCommonBusiness gkWorkCommonBusiness) {
    this.gkWorkCommonBusiness = gkWorkCommonBusiness;
  }

  /**
   * 請求入金共通料金実績一覧作成マッパーを設定する。(DI)
   *
   * @author "Nihon Unisys, Ltd."
   * @param sn0106CreateChargeResultListMapper
   */
  public void setSn0106CreateChargeResultListMapper(
      SN0106_CreateChargeResultListMapper sn0106CreateChargeResultListMapper) {
    this.sn0106CreateChargeResultListMapper = sn0106CreateChargeResultListMapper;
  }
}
