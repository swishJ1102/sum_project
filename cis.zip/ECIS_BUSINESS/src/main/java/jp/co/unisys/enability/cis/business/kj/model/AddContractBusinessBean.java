package jp.co.unisys.enability.cis.business.kj.model;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import jp.co.unisys.enability.cis.entity.kj.KJ_SupplementaryContractBean;

/**
 * 契約情報追加で、登録条件および登録結果を格納するビジネスBean
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * 契約情報ビジネス
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class AddContractBusinessBean {

  /**
   * 契約者IDを保有する。
   */
  private Integer contractorId;

  /**
   * 契約者番号を保有する。
   */
  private String contractorNo;

  /**
   * 支払IDを保有する。
   */
  private Integer paymentId;

  /**
   * 支払番号を保有する。
   */
  private String paymentNo;

  /**
   * 需要場所住所（郵便番号）を保有する。
   */
  private String placeAddressPostalCode;

  /**
   * 需要場所住所（住所）を保有する。
   */
  private String placeAddressFull;

  /**
   * 需要場所住所（建物・部屋名）を保有する。
   */
  private String placeAddressBuilding;

  /**
   * エリアコードを保有する。
   */
  private String areaCode;

  /**
   * 地点特定番号を保有する。
   */
  private String spotNo;

  /**
   * 需要家識別番号を保有する。
   */
  private String contractorIdentificationNo;

  /**
   * 送受電区分コードを保有する。
   */
  private String transmissionCategoryCode;

  /**
   * 基本検針日を保有する。
   */
  private String basicMeterReadingDate;

  /**
   * 次回検針予定日を保有する。
   */
  private Date nextMeterReadingScheduledDate;

  /**
   * 前回検針日を保有する。
   */
  private Date lastTimeMeterReadingDate;

  /**
   * 自家発連携有無コードを保有する。
   */
  private String generatorLinkageCheckCode;

  /**
   * 供給方式コードを保有する。
   */
  private String supplyMethodCode;

  /**
   * 計器識別番号1を保有する。
   */
  private String meterIdentificationNo1;

  /**
   * 計器識別番号2を保有する。
   */
  private String meterIdentificationNo2;

  /**
   * 計器識別番号3を保有する。
   */
  private String meterIdentificationNo3;

  /**
   * 計器識別番号4を保有する。
   */
  private String meterIdentificationNo4;

  /**
   * 計器識別番号5を保有する。
   */
  private String meterIdentificationNo5;

  /**
   * 30分値収集可否・自動検針可否コード1を保有する。
   */
  private String automaticMeterReadingCkeckCode1;

  /**
   * 30分値収集可否・自動検針可否コード2を保有する。
   */
  private String automaticMeterReadingCkeckCode2;

  /**
   * 30分値収集可否・自動検針可否コード3を保有する。
   */
  private String automaticMeterReadingCkeckCode3;

  /**
   * 30分値収集可否・自動検針可否コード4を保有する。
   */
  private String automaticMeterReadingCkeckCode4;

  /**
   * 30分値収集可否・自動検針可否コード5を保有する。
   */
  private String automaticMeterReadingCkeckCode5;

  /**
   * 契約番号を保有する。
   */
  private String contractNo;

  /**
   * 契約開始日を保有する。
   */
  private Date contractStartDate;

  /**
   * 契約終了日を保有する。
   */
  private Date contractEndDate;

  /**
   * 契約終了理由コードを保有する。
   */
  private String contractEndReasonCode;

  /**
   * 料金チェックフラグを保有する。
   */
  private String chargeCheckFlag;

  /**
   * 託送契約容量を保有する。
   */
  private BigDecimal consignmentContractCapacity;

  /**
   * 託送契約容量単位コードを保有する。
   */
  private String consignmentcontractCapacityUnitCode;

  /**
   * 託送契約容量判定日を保有する。
   */
  private Date consignmentContractCapacityDecisionDate;

  /**
   * 契約グループ番号を保有する。
   */
  private String contractGroupNo;

  /**
   * 連絡先個人・法人区分コードを保有する。
   */
  private String contactInformationindividualLegalEntityCategoryCode;

  /**
   * 連絡先氏名（カナ）を保有する。
   */
  private String contractInformationNameKana;

  /**
   * 連絡先氏名1を保有する。
   */
  private String contractInformationName1;

  /**
   * 連絡先氏名2を保有する。
   */
  private String contractInformationName2;

  /**
   * 連絡先住所（郵便番号）を保有する。
   */
  private String contractInformationAddressPostalCode;

  /**
   * 連絡先住所（住所）を保有する。
   */
  private String contractInformationAddressFull;

  /**
   * 連絡先住所（建物・部屋名）を保有する。
   */
  private String contractInformationAddressBuilding;

  /**
   * 連絡先電話区分コードを保有する。
   */
  private String contractInformationCategoryCode;

  /**
   * 連絡先電話（市外局番）を保有する。
   */
  private String contractInformationAreaCode;

  /**
   * 連絡先電話（市内局番）を保有する。
   */
  private String contractInformationLocalNo;

  /**
   * 連絡先電話（加入者番号）を保有する。
   */
  private String contractInformationDirectoryNo;

  /**
   * 需要者窓口連絡先所属を保有する。
   */
  private String consumerContractAffiliation;

  /**
   * 需要者窓口連絡先氏名を保有する。
   */
  private String consumerContractName;

  /**
   * 需要者窓口連絡先電話番号（市外局番）を保有する。
   */
  private String consumerContractAreaCode;

  /**
   * 需要者窓口連絡先電話番号（市内局番）を保有する。
   */
  private String consumerContractLocalNo;

  /**
   * 需要者窓口連絡先電話番号（加入者番号）を保有する。
   */
  private String consumerContractDirectoryNo;

  /**
   * 主任技術者連絡先所属を保有する。
   */
  private String chiefEngineerOfficerAffiliation;

  /**
   * 主任技術者連絡先氏名を保有する。
   */
  private String chiefEngineerOfficerName;

  /**
   * 主任技術者連絡先電話番号（市外局番）を保有する。
   */
  private String chiefEngineerOfficerAreaCode;

  /**
   * 主任技術者連絡先電話番号（市内局番）を保有する。
   */
  private String chiefEngineerOfficerLocalNo;

  /**
   * 主任技術者連絡先電話番号（加入者番号）を保有する。
   */
  private String chiefEngineerOfficerDirectoryNo;

  /**
   * 接続送電サービス区分コードを保有する。
   */
  private String connectedSupplyServiceCategoryCode;

  /**
   * 部分供給区分コードを保有する。
   */
  private String psInfoCatCode;

  /**
   * 再エネ電源種別コードを保有する。
   */
  private String renewableEnergyPowerSourceClassCode;

  /**
   * 再エネ設備容量を保有する。
   */
  private String renewableEnergyFcltCapacity;

  /**
   * 再エネ設備認定年度を保有する。
   */
  private String renewableEnergyFcltAprvFiscalYear;

  /**
   * 設備IDを保有する。
   */
  private String facilitiesId;

  /**
   * 設備IDを保有する。
   */
  private String free9;

  /**
   * 申込日を保有する。
   */
  private String entryDate;

  /**
   * 調達開始年月を保有する。
   */
  private String supplyStartPeriod;

  /**
   * 事業税算定対象フラグを保有する。
   */
  private String bizTaxCalculationCoveredFlag;

  /**
   * 振込先金融機関コードを保有する。
   */
  private String transferBankCode;

  /**
   * 振込先金融機関名称（カナ）を保有する。
   */
  private String transferBankNameKana;

  /**
   * 振込先金融機関支店コードを保有する。
   */
  private String transferBankBranchCode;

  /**
   * 振込先金融機関支店名称（カナ）を保有する。
   */
  private String transferBankBranchNameKana;

  /**
   * 振込先預金種目コードを保有する。
   */
  private String transferTypeOfAccountCode;

  /**
   * 振込先口座番号を保有する。
   */
  private String transferAccountNo;

  /**
   * 振込先口座名義（カナ）を保有する。
   */
  private String transferAccountHolderNameKana;

  /**
   * 業種コードを保有する。
   */
  private String businessTypeCode;

  /**
   * 営業委託先コードを保有する。
   */
  private String salesConsignmentCode;

  /**
   * 委託先使用項目1を保有する。
   */
  private String consignmentUseItem1;

  /**
   * 委託先使用項目2を保有する。
   */
  private String consignmentUseItem2;

  /**
   * 委託先使用項目3を保有する。
   */
  private String consignmentUseItem3;

  /**
   * 自社担当者コードを保有する。
   */
  private String ourManagementPersonInChargeCode;

  /**
   * 自社部署コードを保有する。
   */
  private String ourManagementDepartmentCode;

  /**
   * 契約終了分確定使用量連携済フラグを保有する。
   */
  private String contractEndFixUsageSentFlag;

  /**
   * 契約備考を保有する。
   */
  private String contractNote;

  /**
   * 料金メニューIDを保有する。
   */
  private String chargeMenuId;

  /**
   * 契約容量を保有する。
   */
  private BigDecimal contractCapacity;

  /**
   * 更新回数を保有する。
   */
  private Integer updateCount;

  /**
   * 付帯契約情報リストを保有する。
   */
  private List<KJ_SupplementaryContractBean> supplementaryContractList;

  /**
   * リターンコードを保有する。
   */
  private String returnCode;

  /**
   * メッセージを保有する。
   */
  private String message;

  /**
   * 需要場所IDを保有する。
   */
  private Integer placeId;

  /**
   * メータ設置場所IDを保有する。
   */
  private Integer meterLocationId;

  /**
   * 契約IDを保有する。
   */
  private Integer contractId;

  /**
   * 付帯契約IDリストを保有する。
   */
  private List<Integer> supplementaryContractIdList;

  /**
   * 付帯契約IDを保有する。
   */
  private Integer supplementaryContractId;

  /**
   * 契約者IDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者IDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者ID
   */
  public Integer getContractorId() {
    return this.contractorId;
  }

  /**
   * 契約者IDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者IDを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorId
   *          契約者ID
   */
  public void setContractorId(Integer contractorId) {
    this.contractorId = contractorId;
  }

  /**
   * 契約者番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者番号を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者番号
   */
  public String getContractorNo() {
    return this.contractorNo;
  }

  /**
   * 契約者番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者番号を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorNo
   *          契約者番号
   */
  public void setContractorNo(String contractorNo) {
    this.contractorNo = contractorNo;
  }

  /**
   * 支払IDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 支払IDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 支払ID
   */
  public Integer getPaymentId() {
    return this.paymentId;
  }

  /**
   * 支払IDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 支払IDを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param paymentId
   *          支払ID
   */
  public void setPaymentId(Integer paymentId) {
    this.paymentId = paymentId;
  }

  /**
   * 支払番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 支払番号を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 支払番号
   */
  public String getPaymentNo() {
    return this.paymentNo;
  }

  /**
   * 支払番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 支払番号を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param paymentNo
   *          支払番号
   */
  public void setPaymentNo(String paymentNo) {
    this.paymentNo = paymentNo;
  }

  /**
   * 需要場所住所（郵便番号）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 需要場所住所（郵便番号）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 需要場所住所（郵便番号）
   */
  public String getPlaceAddressPostalCode() {
    return this.placeAddressPostalCode;
  }

  /**
   * 需要場所住所（郵便番号）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 需要場所住所（郵便番号）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param placeAddressPostalCode
   *          需要場所住所（郵便番号）
   */
  public void setPlaceAddressPostalCode(String placeAddressPostalCode) {
    this.placeAddressPostalCode = placeAddressPostalCode;
  }

  /**
   * 需要場所住所（住所）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 需要場所住所（住所）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 需要場所住所（住所）
   */
  public String getPlaceAddressFull() {
    return this.placeAddressFull;
  }

  /**
   * 需要場所住所（住所）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 需要場所住所（住所）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param placeAddressFull
   *          需要場所住所（住所）
   */
  public void setPlaceAddressFull(String placeAddressFull) {
    this.placeAddressFull = placeAddressFull;
  }

  /**
   * 需要場所住所（建物・部屋名）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 需要場所住所（建物・部屋名）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 需要場所住所（建物・部屋名）
   */
  public String getPlaceAddressBuilding() {
    return this.placeAddressBuilding;
  }

  /**
   * 需要場所住所（建物・部屋名）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 需要場所住所（建物・部屋名）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param placeAddressBuilding
   *          需要場所住所（建物・部屋名）
   */
  public void setPlaceAddressBuilding(String placeAddressBuilding) {
    this.placeAddressBuilding = placeAddressBuilding;
  }

  /**
   * エリアコードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * エリアコードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return エリアコード
   */
  public String getAreaCode() {
    return this.areaCode;
  }

  /**
   * エリアコードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * エリアコードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param areaCode
   *          エリアコード
   */
  public void setAreaCode(String areaCode) {
    this.areaCode = areaCode;
  }

  /**
   * 地点特定番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 地点特定番号を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 地点特定番号
   */
  public String getSpotNo() {
    return this.spotNo;
  }

  /**
   * 地点特定番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 地点特定番号を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param spotNo
   *          地点特定番号
   */
  public void setSpotNo(String spotNo) {
    this.spotNo = spotNo;
  }

  /**
   * 需要家識別番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 需要家識別番号を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 需要家識別番号
   */
  public String getContractorIdentificationNo() {
    return this.contractorIdentificationNo;
  }

  /**
   * 需要家識別番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 需要家識別番号を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorIdentificationNo
   *          需要家識別番号
   */
  public void setContractorIdentificationNo(String contractorIdentificationNo) {
    this.contractorIdentificationNo = contractorIdentificationNo;
  }

  /**
   * 送受電区分コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 送受電区分コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 送受電区分コード
   */
  public String getTransmissionCategoryCode() {
    return this.transmissionCategoryCode;
  }

  /**
   * 送受電区分コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 送受電区分コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param transmissionCategoryCode
   *          送受電区分コード
   */
  public void setTransmissionCategoryCode(String transmissionCategoryCode) {
    this.transmissionCategoryCode = transmissionCategoryCode;
  }

  /**
   * 基本検針日のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 基本検針日を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 基本検針日
   */
  public String getBasicMeterReadingDate() {
    return this.basicMeterReadingDate;
  }

  /**
   * 基本検針日のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 基本検針日を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param basicMeterReadingDate
   *          基本検針日
   */
  public void setBasicMeterReadingDate(String basicMeterReadingDate) {
    this.basicMeterReadingDate = basicMeterReadingDate;
  }

  /**
   * 次回検針予定日のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 次回検針予定日を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 次回検針予定日
   */
  public Date getNextMeterReadingScheduledDate() {
    return this.nextMeterReadingScheduledDate;
  }

  /**
   * 次回検針予定日のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 次回検針予定日を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param nextMeterReadingScheduledDate
   *          次回検針予定日
   */
  public void setNextMeterReadingScheduledDate(
      Date nextMeterReadingScheduledDate) {
    this.nextMeterReadingScheduledDate = nextMeterReadingScheduledDate;
  }

  /**
   * 前回検針日のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 前回検針日を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 前回検針日
   */
  public Date getLastTimeMeterReadingDate() {
    return this.lastTimeMeterReadingDate;
  }

  /**
   * 前回検針日のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 前回検針日を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param lastTimeMeterReadingDate
   *          前回検針日
   */
  public void setLastTimeMeterReadingDate(Date lastTimeMeterReadingDate) {
    this.lastTimeMeterReadingDate = lastTimeMeterReadingDate;
  }

  /**
   * 自家発連携有無コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 自家発連携有無コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 自家発連携有無コード
   */
  public String getGeneratorLinkageCheckCode() {
    return this.generatorLinkageCheckCode;
  }

  /**
   * 自家発連携有無コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 自家発連携有無コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param generatorLinkageCheckCode
   *          自家発連携有無コード
   */
  public void setGeneratorLinkageCheckCode(String generatorLinkageCheckCode) {
    this.generatorLinkageCheckCode = generatorLinkageCheckCode;
  }

  /**
   * 供給方式コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 供給方式コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 供給方式コード
   */
  public String getSupplyMethodCode() {
    return this.supplyMethodCode;
  }

  /**
   * 供給方式コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 供給方式コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param supplyMethodCode
   *          供給方式コード
   */
  public void setSupplyMethodCode(String supplyMethodCode) {
    this.supplyMethodCode = supplyMethodCode;
  }

  /**
   * 計器識別番号1のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計器識別番号1を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 計器識別番号1
   */
  public String getMeterIdentificationNo1() {
    return this.meterIdentificationNo1;
  }

  /**
   * 計器識別番号1のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計器識別番号1を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param meterIdentificationNo1
   *          計器識別番号1
   */
  public void setMeterIdentificationNo1(String meterIdentificationNo1) {
    this.meterIdentificationNo1 = meterIdentificationNo1;
  }

  /**
   * 計器識別番号2のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計器識別番号2を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 計器識別番号2
   */
  public String getMeterIdentificationNo2() {
    return this.meterIdentificationNo2;
  }

  /**
   * 計器識別番号2のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計器識別番号2を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param meterIdentificationNo2
   *          計器識別番号2
   */
  public void setMeterIdentificationNo2(String meterIdentificationNo2) {
    this.meterIdentificationNo2 = meterIdentificationNo2;
  }

  /**
   * 計器識別番号3のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計器識別番号3を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 計器識別番号3
   */
  public String getMeterIdentificationNo3() {
    return this.meterIdentificationNo3;
  }

  /**
   * 計器識別番号3のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計器識別番号3を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param meterIdentificationNo3
   *          計器識別番号3
   */
  public void setMeterIdentificationNo3(String meterIdentificationNo3) {
    this.meterIdentificationNo3 = meterIdentificationNo3;
  }

  /**
   * 計器識別番号4のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計器識別番号4を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 計器識別番号4
   */
  public String getMeterIdentificationNo4() {
    return this.meterIdentificationNo4;
  }

  /**
   * 計器識別番号4のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計器識別番号4を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param meterIdentificationNo4
   *          計器識別番号4
   */
  public void setMeterIdentificationNo4(String meterIdentificationNo4) {
    this.meterIdentificationNo4 = meterIdentificationNo4;
  }

  /**
   * 計器識別番号5のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計器識別番号5を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 計器識別番号5
   */
  public String getMeterIdentificationNo5() {
    return this.meterIdentificationNo5;
  }

  /**
   * 計器識別番号5のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計器識別番号5を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param meterIdentificationNo5
   *          計器識別番号5
   */
  public void setMeterIdentificationNo5(String meterIdentificationNo5) {
    this.meterIdentificationNo5 = meterIdentificationNo5;
  }

  /**
   * 30分値収集可否・自動検針可否コード1のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 30分値収集可否・自動検針可否コード1を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 30分値収集可否・自動検針可否コード1
   */
  public String getAutomaticMeterReadingCkeckCode1() {
    return this.automaticMeterReadingCkeckCode1;
  }

  /**
   * 30分値収集可否・自動検針可否コード1のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 30分値収集可否・自動検針可否コード1を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param automaticMeterReadingCkeckCode1
   *          30分値収集可否・自動検針可否コード1
   */
  public void setAutomaticMeterReadingCkeckCode1(
      String automaticMeterReadingCkeckCode1) {
    this.automaticMeterReadingCkeckCode1 = automaticMeterReadingCkeckCode1;
  }

  /**
   * 30分値収集可否・自動検針可否コード2のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 30分値収集可否・自動検針可否コード2を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 30分値収集可否・自動検針可否コード2
   */
  public String getAutomaticMeterReadingCkeckCode2() {
    return this.automaticMeterReadingCkeckCode2;
  }

  /**
   * 30分値収集可否・自動検針可否コード2のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 30分値収集可否・自動検針可否コード2を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param automaticMeterReadingCkeckCode2
   *          30分値収集可否・自動検針可否コード2
   */
  public void setAutomaticMeterReadingCkeckCode2(
      String automaticMeterReadingCkeckCode2) {
    this.automaticMeterReadingCkeckCode2 = automaticMeterReadingCkeckCode2;
  }

  /**
   * 30分値収集可否・自動検針可否コード3のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 30分値収集可否・自動検針可否コード3を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 30分値収集可否・自動検針可否コード3
   */
  public String getAutomaticMeterReadingCkeckCode3() {
    return this.automaticMeterReadingCkeckCode3;
  }

  /**
   * 30分値収集可否・自動検針可否コード3のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 30分値収集可否・自動検針可否コード3を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param automaticMeterReadingCkeckCode3
   *          30分値収集可否・自動検針可否コード3
   */
  public void setAutomaticMeterReadingCkeckCode3(
      String automaticMeterReadingCkeckCode3) {
    this.automaticMeterReadingCkeckCode3 = automaticMeterReadingCkeckCode3;
  }

  /**
   * 30分値収集可否・自動検針可否コード4のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 30分値収集可否・自動検針可否コード4を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 30分値収集可否・自動検針可否コード4
   */
  public String getAutomaticMeterReadingCkeckCode4() {
    return this.automaticMeterReadingCkeckCode4;
  }

  /**
   * 30分値収集可否・自動検針可否コード4のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 30分値収集可否・自動検針可否コード4を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param automaticMeterReadingCkeckCode4
   *          30分値収集可否・自動検針可否コード4
   */
  public void setAutomaticMeterReadingCkeckCode4(
      String automaticMeterReadingCkeckCode4) {
    this.automaticMeterReadingCkeckCode4 = automaticMeterReadingCkeckCode4;
  }

  /**
   * 30分値収集可否・自動検針可否コード5のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 30分値収集可否・自動検針可否コード5を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 30分値収集可否・自動検針可否コード5
   */
  public String getAutomaticMeterReadingCkeckCode5() {
    return this.automaticMeterReadingCkeckCode5;
  }

  /**
   * 30分値収集可否・自動検針可否コード5のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 30分値収集可否・自動検針可否コード5を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param automaticMeterReadingCkeckCode5
   *          30分値収集可否・自動検針可否コード5
   */
  public void setAutomaticMeterReadingCkeckCode5(
      String automaticMeterReadingCkeckCode5) {
    this.automaticMeterReadingCkeckCode5 = automaticMeterReadingCkeckCode5;
  }

  /**
   * 契約番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約番号を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約番号
   */
  public String getContractNo() {
    return this.contractNo;
  }

  /**
   * 契約番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約番号を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractNo
   *          契約番号
   */
  public void setContractNo(String contractNo) {
    this.contractNo = contractNo;
  }

  /**
   * 契約開始日のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約開始日を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約開始日
   */
  public Date getContractStartDate() {
    return this.contractStartDate;
  }

  /**
   * 契約開始日のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約開始日を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractStartDate
   *          契約開始日
   */
  public void setContractStartDate(Date contractStartDate) {
    this.contractStartDate = contractStartDate;
  }

  /**
   * 契約終了日のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約終了日を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約終了日
   */
  public Date getContractEndDate() {
    return this.contractEndDate;
  }

  /**
   * 契約終了日のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約終了日を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractEndDate
   *          契約終了日
   */
  public void setContractEndDate(Date contractEndDate) {
    this.contractEndDate = contractEndDate;
  }

  /**
   * 契約終了理由コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約終了理由コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約終了理由コード
   */
  public String getContractEndReasonCode() {
    return this.contractEndReasonCode;
  }

  /**
   * 契約終了理由コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約終了理由コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractEndReasonCode
   *          契約終了理由コード
   */
  public void setContractEndReasonCode(String contractEndReasonCode) {
    this.contractEndReasonCode = contractEndReasonCode;
  }

  /**
   * 料金チェックフラグのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金チェックフラグを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 料金チェックフラグ
   */
  public String getChargeCheckFlag() {
    return this.chargeCheckFlag;
  }

  /**
   * 料金チェックフラグのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金チェックフラグを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param chargeCheckFlag
   *          料金チェックフラグ
   */
  public void setChargeCheckFlag(String chargeCheckFlag) {
    this.chargeCheckFlag = chargeCheckFlag;
  }

  /**
   * 託送契約容量のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 託送契約容量を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 託送契約容量
   */
  public BigDecimal getConsignmentContractCapacity() {
    return this.consignmentContractCapacity;
  }

  /**
   * 託送契約容量のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 託送契約容量を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param consignmentContractCapacity
   *          託送契約容量
   */
  public void setConsignmentContractCapacity(
      BigDecimal consignmentContractCapacity) {
    this.consignmentContractCapacity = consignmentContractCapacity;
  }

  /**
   * 託送契約容量単位コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 託送契約容量単位コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 託送契約容量単位コード
   */
  public String getConsignmentcontractCapacityUnitCode() {
    return this.consignmentcontractCapacityUnitCode;
  }

  /**
   * 託送契約容量単位コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 託送契約容量単位コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param consignmentcontractCapacityUnitCode
   *          託送契約容量単位コード
   */
  public void setConsignmentcontractCapacityUnitCode(
      String consignmentcontractCapacityUnitCode) {
    this.consignmentcontractCapacityUnitCode = consignmentcontractCapacityUnitCode;
  }

  /**
   * 託送契約容量判定日のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 託送契約容量判定日を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 託送契約容量判定日
   */
  public Date getConsignmentContractCapacityDecisionDate() {
    return this.consignmentContractCapacityDecisionDate;
  }

  /**
   * 託送契約容量判定日のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 託送契約容量判定日を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param consignmentContractCapacityDecisionDate
   *          託送契約容量判定日
   */
  public void setConsignmentContractCapacityDecisionDate(
      Date consignmentContractCapacityDecisionDate) {
    this.consignmentContractCapacityDecisionDate = consignmentContractCapacityDecisionDate;
  }

  /**
   * 契約グループ番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約グループ番号を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約グループ番号
   */
  public String getContractGroupNo() {
    return this.contractGroupNo;
  }

  /**
   * 契約グループ番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約グループ番号を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractGroupNo
   *          契約グループ番号
   */
  public void setContractGroupNo(String contractGroupNo) {
    this.contractGroupNo = contractGroupNo;
  }

  /**
   * 連絡先個人・法人区分コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先個人・法人区分コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 連絡先個人・法人区分コード
   */
  public String getContactInformationindividualLegalEntityCategoryCode() {
    return this.contactInformationindividualLegalEntityCategoryCode;
  }

  /**
   * 連絡先個人・法人区分コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先個人・法人区分コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contactInformationindividualLegalEntityCategoryCode
   *          連絡先個人・法人区分コード
   */
  public void setContactInformationindividualLegalEntityCategoryCode(
      String contactInformationindividualLegalEntityCategoryCode) {
    this.contactInformationindividualLegalEntityCategoryCode = contactInformationindividualLegalEntityCategoryCode;
  }

  /**
   * 連絡先氏名（カナ）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先氏名（カナ）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 連絡先氏名（カナ）
   */
  public String getContractInformationNameKana() {
    return this.contractInformationNameKana;
  }

  /**
   * 連絡先氏名（カナ）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先氏名（カナ）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractInformationNameKana
   *          連絡先氏名（カナ）
   */
  public void setContractInformationNameKana(
      String contractInformationNameKana) {
    this.contractInformationNameKana = contractInformationNameKana;
  }

  /**
   * 連絡先氏名1のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先氏名1を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 連絡先氏名1
   */
  public String getContractInformationName1() {
    return this.contractInformationName1;
  }

  /**
   * 連絡先氏名1のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先氏名1を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractInformationName1
   *          連絡先氏名1
   */
  public void setContractInformationName1(String contractInformationName1) {
    this.contractInformationName1 = contractInformationName1;
  }

  /**
   * 連絡先氏名2のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先氏名2を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 連絡先氏名2
   */
  public String getContractInformationName2() {
    return this.contractInformationName2;
  }

  /**
   * 連絡先氏名2のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先氏名2を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractInformationName2
   *          連絡先氏名2
   */
  public void setContractInformationName2(String contractInformationName2) {
    this.contractInformationName2 = contractInformationName2;
  }

  /**
   * 連絡先住所（郵便番号）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先住所（郵便番号）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 連絡先住所（郵便番号）
   */
  public String getContractInformationAddressPostalCode() {
    return this.contractInformationAddressPostalCode;
  }

  /**
   * 連絡先住所（郵便番号）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先住所（郵便番号）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractInformationAddressPostalCode
   *          連絡先住所（郵便番号）
   */
  public void setContractInformationAddressPostalCode(
      String contractInformationAddressPostalCode) {
    this.contractInformationAddressPostalCode = contractInformationAddressPostalCode;
  }

  /**
   * 連絡先住所（住所）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先住所（住所）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 連絡先住所（住所）
   */
  public String getContractInformationAddressFull() {
    return this.contractInformationAddressFull;
  }

  /**
   * 連絡先住所（住所）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先住所（住所）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractInformationAddressFull
   *          連絡先住所（住所）
   */
  public void setContractInformationAddressFull(
      String contractInformationAddressFull) {
    this.contractInformationAddressFull = contractInformationAddressFull;
  }

  /**
   * 連絡先住所（建物・部屋名）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先住所（建物・部屋名）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 連絡先住所（建物・部屋名）
   */
  public String getContractInformationAddressBuilding() {
    return this.contractInformationAddressBuilding;
  }

  /**
   * 連絡先住所（建物・部屋名）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先住所（建物・部屋名）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractInformationAddressBuilding
   *          連絡先住所（建物・部屋名）
   */
  public void setContractInformationAddressBuilding(
      String contractInformationAddressBuilding) {
    this.contractInformationAddressBuilding = contractInformationAddressBuilding;
  }

  /**
   * 連絡先電話区分コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先電話区分コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 連絡先電話区分コード
   */
  public String getContractInformationCategoryCode() {
    return this.contractInformationCategoryCode;
  }

  /**
   * 連絡先電話区分コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先電話区分コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractInformationCategoryCode
   *          連絡先電話区分コード
   */
  public void setContractInformationCategoryCode(
      String contractInformationCategoryCode) {
    this.contractInformationCategoryCode = contractInformationCategoryCode;
  }

  /**
   * 連絡先電話（市外局番）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先電話（市外局番）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 連絡先電話（市外局番）
   */
  public String getContractInformationAreaCode() {
    return this.contractInformationAreaCode;
  }

  /**
   * 連絡先電話（市外局番）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先電話（市外局番）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractInformationAreaCode
   *          連絡先電話（市外局番）
   */
  public void setContractInformationAreaCode(
      String contractInformationAreaCode) {
    this.contractInformationAreaCode = contractInformationAreaCode;
  }

  /**
   * 連絡先電話（市内局番）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先電話（市内局番）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 連絡先電話（市内局番）
   */
  public String getContractInformationLocalNo() {
    return this.contractInformationLocalNo;
  }

  /**
   * 連絡先電話（市内局番）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先電話（市内局番）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractInformationLocalNo
   *          連絡先電話（市内局番）
   */
  public void setContractInformationLocalNo(String contractInformationLocalNo) {
    this.contractInformationLocalNo = contractInformationLocalNo;
  }

  /**
   * 連絡先電話（加入者番号）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先電話（加入者番号）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 連絡先電話（加入者番号）
   */
  public String getContractInformationDirectoryNo() {
    return this.contractInformationDirectoryNo;
  }

  /**
   * 連絡先電話（加入者番号）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先電話（加入者番号）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractInformationDirectoryNo
   *          連絡先電話（加入者番号）
   */
  public void setContractInformationDirectoryNo(
      String contractInformationDirectoryNo) {
    this.contractInformationDirectoryNo = contractInformationDirectoryNo;
  }

  /**
   * 需要者窓口連絡先所属のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 需要者窓口連絡先所属を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 需要者窓口連絡先所属
   */
  public String getConsumerContractAffiliation() {
    return this.consumerContractAffiliation;
  }

  /**
   * 需要者窓口連絡先所属のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 需要者窓口連絡先所属を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param consumerContractAffiliation
   *          需要者窓口連絡先所属
   */
  public void setConsumerContractAffiliation(String consumerContractAffiliation) {
    this.consumerContractAffiliation = consumerContractAffiliation;
  }

  /**
   * 需要者窓口連絡先氏名のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 需要者窓口連絡先氏名を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 需要者窓口連絡先氏名
   */
  public String getConsumerContractName() {
    return this.consumerContractName;
  }

  /**
   * 需要者窓口連絡先氏名のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 需要者窓口連絡先氏名を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param consumerContractName
   *          需要者窓口連絡先氏名
   */
  public void setConsumerContractName(String consumerContractName) {
    this.consumerContractName = consumerContractName;
  }

  /**
   * 需要者窓口連絡先電話番号（市外局番）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 需要者窓口連絡先電話番号（市外局番）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 需要者窓口連絡先電話番号（市外局番）
   */
  public String getConsumerContractAreaCode() {
    return this.consumerContractAreaCode;
  }

  /**
   * 需要者窓口連絡先電話番号（市外局番）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 需要者窓口連絡先電話番号（市外局番）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param consumerContractAreaCode
   *          需要者窓口連絡先電話番号（市外局番）
   */
  public void setConsumerContractAreaCode(
      String consumerContractAreaCode) {
    this.consumerContractAreaCode = consumerContractAreaCode;
  }

  /**
   * 需要者窓口連絡先電話番号（市内局番）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 需要者窓口連絡先電話番号（市内局番）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 需要者窓口連絡先電話番号（市内局番）
   */
  public String getConsumerContractLocalNo() {
    return this.consumerContractLocalNo;
  }

  /**
   * 需要者窓口連絡先電話番号（市内局番）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 需要者窓口連絡先電話番号（市内局番）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param consumerContractLocalNo
   *          需要者窓口連絡先電話番号（市内局番）
   */
  public void setConsumerContractLocalNo(String consumerContractLocalNo) {
    this.consumerContractLocalNo = consumerContractLocalNo;
  }

  /**
   * 需要者窓口連絡先電話番号（加入者番号）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 需要者窓口連絡先電話番号（加入者番号）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 需要者窓口連絡先電話番号（加入者番号）
   */
  public String getConsumerContractDirectoryNo() {
    return this.consumerContractDirectoryNo;
  }

  /**
   * 需要者窓口連絡先電話番号（加入者番号）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 需要者窓口連絡先電話番号（加入者番号）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param consumerContractDirectoryNo
   *          需要者窓口連絡先電話番号（加入者番号）
   */
  public void setConsumerContractDirectoryNo(
      String consumerContractDirectoryNo) {
    this.consumerContractDirectoryNo = consumerContractDirectoryNo;
  }

  /**
   * 主任技術者連絡先所属のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 主任技術者連絡先所属を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 主任技術者連絡先所属
   */
  public String getChiefEngineerOfficerAffiliation() {
    return this.chiefEngineerOfficerAffiliation;
  }

  /**
   * 主任技術者連絡先所属のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 主任技術者連絡先所属を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param chiefEngineerOfficerAffiliation
   *          主任技術者連絡先所属
   */
  public void setChiefEngineerOfficerAffiliation(String chiefEngineerOfficerAffiliation) {
    this.chiefEngineerOfficerAffiliation = chiefEngineerOfficerAffiliation;
  }

  /**
   * 主任技術者連絡先氏名のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 主任技術者連絡先氏名を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 主任技術者連絡先氏名
   */
  public String getChiefEngineerOfficerName() {
    return this.chiefEngineerOfficerName;
  }

  /**
   * 主任技術者連絡先氏名のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 主任技術者連絡先氏名を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param chiefEngineerOfficerName
   *          主任技術者連絡先氏名
   */
  public void setChiefEngineerOfficerName(String chiefEngineerOfficerName) {
    this.chiefEngineerOfficerName = chiefEngineerOfficerName;
  }

  /**
   * 主任技術者連絡先電話番号（市外局番）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 主任技術者連絡先電話番号（市外局番）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 主任技術者連絡先電話番号（市外局番）
   */
  public String getChiefEngineerOfficerAreaCode() {
    return this.chiefEngineerOfficerAreaCode;
  }

  /**
   * 主任技術者連絡先電話番号（市外局番）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 主任技術者連絡先電話番号（市外局番）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param chiefEngineerOfficerAreaCode
   *          主任技術者連絡先電話番号（市外局番）
   */
  public void setChiefEngineerOfficerAreaCode(
      String chiefEngineerOfficerAreaCode) {
    this.chiefEngineerOfficerAreaCode = chiefEngineerOfficerAreaCode;
  }

  /**
   * 主任技術者連絡先電話番号（市内局番）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 主任技術者連絡先電話番号（市内局番）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 主任技術者連絡先電話番号（市内局番）
   */
  public String getChiefEngineerOfficerLocalNo() {
    return this.chiefEngineerOfficerLocalNo;
  }

  /**
   * 主任技術者連絡先電話番号（市内局番）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 主任技術者連絡先電話番号（市内局番）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param chiefEngineerOfficerLocalNo
   *          主任技術者連絡先電話番号（市内局番）
   */
  public void setChiefEngineerOfficerLocalNo(String chiefEngineerOfficerLocalNo) {
    this.chiefEngineerOfficerLocalNo = chiefEngineerOfficerLocalNo;
  }

  /**
   * 主任技術者連絡先電話番号（加入者番号）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 主任技術者連絡先電話番号（加入者番号）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 主任技術者連絡先電話番号（加入者番号）
   */
  public String getChiefEngineerOfficerDirectoryNo() {
    return this.chiefEngineerOfficerDirectoryNo;
  }

  /**
   * 主任技術者連絡先電話番号（加入者番号）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 主任技術者連絡先電話番号（加入者番号）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param chiefEngineerOfficerDirectoryNo
   *          主任技術者連絡先電話番号（加入者番号）
   */
  public void setChiefEngineerOfficerDirectoryNo(
      String chiefEngineerOfficerDirectoryNo) {
    this.chiefEngineerOfficerDirectoryNo = chiefEngineerOfficerDirectoryNo;
  }

  /**
   * 接続送電サービス区分コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 接続送電サービス区分コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 接続送電サービス区分コード
   */
  public String getConnectedSupplyServiceCategoryCode() {
    return this.connectedSupplyServiceCategoryCode;
  }

  /**
   * 接続送電サービス区分コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 接続送電サービス区分コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param connectedSupplyServiceCategoryCode
   *          接続送電サービス区分コード
   */
  public void setConnectedSupplyServiceCategoryCode(
      String connectedSupplyServiceCategoryCode) {
    this.connectedSupplyServiceCategoryCode = connectedSupplyServiceCategoryCode;
  }

  /**
   * 部分供給区分コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 部分供給区分コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 部分供給区分コード
   */
  public String getPsInfoCatCode() {
    return this.psInfoCatCode;
  }

  /**
   * 部分供給区分コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 部分供給区分コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param psInfoCatCode
   *          部分供給区分コード
   */
  public void setPsInfoCatCode(
      String psInfoCatCode) {
    this.psInfoCatCode = psInfoCatCode;
  }

  /**
   * 再エネ電源種別コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 再エネ電源種別コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 再エネ電源種別コード
   */
  public String getRenewableEnergyPowerSourceClassCode() {
    return this.renewableEnergyPowerSourceClassCode;
  }

  /**
   * 再エネ電源種別コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 再エネ電源種別コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param renewableEnergyPowerSourceClassCode
   *          再エネ電源種別コード
   */
  public void setRenewableEnergyPowerSourceClassCode(
      String renewableEnergyPowerSourceClassCode) {
    this.renewableEnergyPowerSourceClassCode = renewableEnergyPowerSourceClassCode;
  }

  /**
   * 再エネ設備容量のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 再エネ設備容量を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 再エネ設備容量
   */
  public String getRenewableEnergyFcltCapacity() {
    return this.renewableEnergyFcltCapacity;
  }

  /**
   * 再エネ設備容量のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 再エネ設備容量を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param renewableEnergyFcltCapacity
   *          再エネ設備容量
   */
  public void setRenewableEnergyFcltCapacity(
      String renewableEnergyFcltCapacity) {
    this.renewableEnergyFcltCapacity = renewableEnergyFcltCapacity;
  }

  /**
   * 再エネ設備認定年度のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 再エネ設備認定年度を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 再エネ設備認定年度
   */
  public String getRenewableEnergyFcltAprvFiscalYear() {
    return this.renewableEnergyFcltAprvFiscalYear;
  }

  /**
   * 再エネ設備認定年度のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 再エネ設備認定年度を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param renewableEnergyFcltAprvFiscalYear
   *          再エネ設備認定年度
   */
  public void setRenewableEnergyFcltAprvFiscalYear(
      String renewableEnergyFcltAprvFiscalYear) {
    this.renewableEnergyFcltAprvFiscalYear = renewableEnergyFcltAprvFiscalYear;
  }

  /**
   * 設備IDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 設備IDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 設備ID
   */
  public String getFacilitiesId() {
    return this.facilitiesId;
  }

  /**
   * 設備IDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 設備IDを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param facilitiesId
   *          設備ID
   */
  public void setFacilitiesId(String facilitiesId) {
    this.facilitiesId = facilitiesId;
  }

  /**
   * 申込日のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 申込日を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 申込日
   */
  public String getEntryDate() {
    return this.entryDate;
  }

  /**
   * 申込日のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 申込日を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param entryDate
   *          申込日
   */
  public void setEntryDate(String entryDate) {
    this.entryDate = entryDate;
  }

  /**
   * 調達開始年月のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 調達開始年月を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 調達開始年月
   */
  public String getSupplyStartPeriod() {
    return this.supplyStartPeriod;
  }

  /**
   * 調達開始年月のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 調達開始年月を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param supplyStartPeriod
   *          調達開始年月
   */
  public void setSupplyStartPeriod(String supplyStartPeriod) {
    this.supplyStartPeriod = supplyStartPeriod;
  }

  /**
   * 事業税算定対象フラグのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 事業税算定対象フラグを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 事業税算定対象フラグ
   */
  public String getBizTaxCalculationCoveredFlag() {
    return this.bizTaxCalculationCoveredFlag;
  }

  /**
   * 事業税算定対象フラグのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 事業税算定対象フラグを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param bizTaxCalculationCoveredFlag
   *          事業税算定対象フラグ
   */
  public void setBizTaxCalculationCoveredFlag(
      String bizTaxCalculationCoveredFlag) {
    this.bizTaxCalculationCoveredFlag = bizTaxCalculationCoveredFlag;
  }

  /**
   * 振込先金融機関コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 振込先金融機関コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 振込先金融機関コード
   */
  public String getTransferBankCode() {
    return this.transferBankCode;
  }

  /**
   * 振込先金融機関コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 振込先金融機関コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param transferBankCode
   *          振込先金融機関コード
   */
  public void setTransferBankCode(String transferBankCode) {
    this.transferBankCode = transferBankCode;
  }

  /**
   * 振込先金融機関名称（カナ）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 振込先金融機関名称（カナ）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 振込先金融機関名称（カナ）
   */
  public String getTransferBankNameKana() {
    return this.transferBankNameKana;
  }

  /**
   * 振込先金融機関名称（カナ）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 振込先金融機関名称（カナ）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param transferBankNameKana
   *          振込先金融機関名称（カナ）
   */
  public void setTransferBankNameKana(String transferBankNameKana) {
    this.transferBankNameKana = transferBankNameKana;
  }

  /**
   * 振込先金融機関支店コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 振込先金融機関支店コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 振込先金融機関支店コード
   */
  public String getTransferBankBranchCode() {
    return this.transferBankBranchCode;
  }

  /**
   * 振込先金融機関支店コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 振込先金融機関支店コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param transferBankBranchCode
   *          振込先金融機関支店コード
   */
  public void setTransferBankBranchCode(String transferBankBranchCode) {
    this.transferBankBranchCode = transferBankBranchCode;
  }

  /**
   * 振込先金融機関支店名称（カナ）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 振込先金融機関支店名称（カナ）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 振込先金融機関支店名称（カナ）
   */
  public String getTransferBankBranchNameKana() {
    return this.transferBankBranchNameKana;
  }

  /**
   * 振込先金融機関支店名称（カナ）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 振込先金融機関支店名称（カナ）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param transferBankBranchNameKana
   *          振込先金融機関支店名称（カナ）
   */
  public void setTransferBankBranchNameKana(String transferBankBranchNameKana) {
    this.transferBankBranchNameKana = transferBankBranchNameKana;
  }

  /**
   * 振込先預金種目コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 振込先預金種目コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 振込先預金種目コード
   */
  public String getTransferTypeOfAccountCode() {
    return this.transferTypeOfAccountCode;
  }

  /**
   * 振込先預金種目コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 振込先預金種目コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param transferTypeOfAccountCode
   *          振込先預金種目コード
   */
  public void setTransferTypeOfAccountCode(String transferTypeOfAccountCode) {
    this.transferTypeOfAccountCode = transferTypeOfAccountCode;
  }

  /**
   * 振込先口座番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 振込先口座番号を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 振込先口座番号
   */
  public String getTransferAccountNo() {
    return this.transferAccountNo;
  }

  /**
   * 振込先口座番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 振込先口座番号を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param transferAccountNo
   *          振込先口座番号
   */
  public void setTransferAccountNo(String transferAccountNo) {
    this.transferAccountNo = transferAccountNo;
  }

  /**
   * 振込先口座名義（カナ）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 振込先口座名義（カナ）を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 振込先口座名義（カナ）
   */
  public String getTransferAccountHolderNameKana() {
    return this.transferAccountHolderNameKana;
  }

  /**
   * 振込先口座名義（カナ）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 振込先口座名義（カナ）を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param transferAccountHolderNameKana
   *          振込先口座名義（カナ）
   */
  public void setTransferAccountHolderNameKana(
      String transferAccountHolderNameKana) {
    this.transferAccountHolderNameKana = transferAccountHolderNameKana;
  }

  /**
   * 業種コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 業種コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 業種コード
   */
  public String getBusinessTypeCode() {
    return this.businessTypeCode;
  }

  /**
   * 業種コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 業種コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param businessTypeCode
   *          業種コード
   */
  public void setBusinessTypeCode(String businessTypeCode) {
    this.businessTypeCode = businessTypeCode;
  }

  /**
   * 営業委託先コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 営業委託先コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 営業委託先コード
   */
  public String getSalesConsignmentCode() {
    return this.salesConsignmentCode;
  }

  /**
   * 営業委託先コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 営業委託先コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param salesConsignmentCode
   *          営業委託先コード
   */
  public void setSalesConsignmentCode(String salesConsignmentCode) {
    this.salesConsignmentCode = salesConsignmentCode;
  }

  /**
   * 委託先使用項目1のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 委託先使用項目1を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 委託先使用項目1
   */
  public String getConsignmentUseItem1() {
    return this.consignmentUseItem1;
  }

  /**
   * 委託先使用項目1のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 委託先使用項目1を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param consignmentUseItem1
   *          委託先使用項目1
   */
  public void setConsignmentUseItem1(String consignmentUseItem1) {
    this.consignmentUseItem1 = consignmentUseItem1;
  }

  /**
   * 委託先使用項目2のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 委託先使用項目2を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 委託先使用項目2
   */
  public String getConsignmentUseItem2() {
    return this.consignmentUseItem2;
  }

  /**
   * 委託先使用項目2のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 委託先使用項目2を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param consignmentUseItem2
   *          委託先使用項目2
   */
  public void setConsignmentUseItem2(String consignmentUseItem2) {
    this.consignmentUseItem2 = consignmentUseItem2;
  }

  /**
   * 委託先使用項目3のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 委託先使用項目3を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 委託先使用項目3
   */
  public String getConsignmentUseItem3() {
    return this.consignmentUseItem3;
  }

  /**
   * 委託先使用項目3のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 委託先使用項目3を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param consignmentUseItem3
   *          委託先使用項目3
   */
  public void setConsignmentUseItem3(String consignmentUseItem3) {
    this.consignmentUseItem3 = consignmentUseItem3;
  }

  /**
   * 自社担当者コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 自社担当者コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 自社担当者コード
   */
  public String getOurManagementPersonInChargeCode() {
    return this.ourManagementPersonInChargeCode;
  }

  /**
   * 自社担当者コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 自社担当者コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param ourManagementPersonInChargeCode
   *          自社担当者コード
   */
  public void setOurManagementPersonInChargeCode(
      String ourManagementPersonInChargeCode) {
    this.ourManagementPersonInChargeCode = ourManagementPersonInChargeCode;
  }

  /**
   * 自社部署コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 自社部署コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 自社部署コード
   */
  public String getOurManagementDepartmentCode() {
    return this.ourManagementDepartmentCode;
  }

  /**
   * 自社部署コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 自社部署コードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param ourManagementDepartmentCode
   *          自社部署コード
   */
  public void setOurManagementDepartmentCode(
      String ourManagementDepartmentCode) {
    this.ourManagementDepartmentCode = ourManagementDepartmentCode;
  }

  /**
   * 契約終了分確定使用量連携済フラグのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約終了分確定使用量連携済フラグを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約終了分確定使用量連携済フラグ
   */
  public String getContractEndFixUsageSentFlag() {
    return this.contractEndFixUsageSentFlag;
  }

  /**
   * 契約終了分確定使用量連携済フラグのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約終了分確定使用量連携済フラグを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractEndFixUsageSentFlag
   *          契約終了分確定使用量連携済フラグ
   */
  public void setContractEndFixUsageSentFlag(
      String contractEndFixUsageSentFlag) {
    this.contractEndFixUsageSentFlag = contractEndFixUsageSentFlag;
  }

  /**
   * 契約備考のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約備考を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約備考
   */
  public String getContractNote() {
    return this.contractNote;
  }

  /**
   * 契約備考のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約備考を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractNote
   *          契約備考
   */
  public void setContractNote(String contractNote) {
    this.contractNote = contractNote;
  }

  /**
   * 料金メニューIDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金メニューIDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 料金メニューID
   */
  public String getChargeMenuId() {
    return this.chargeMenuId;
  }

  /**
   * 料金メニューIDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金メニューIDを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param chargeMenuId
   *          料金メニューID
   */
  public void setChargeMenuId(String chargeMenuId) {
    this.chargeMenuId = chargeMenuId;
  }

  /**
   * 契約容量のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約容量を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約容量
   */
  public BigDecimal getContractCapacity() {
    return this.contractCapacity;
  }

  /**
   * 契約容量のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約容量を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractCapacity
   *          契約容量
   */
  public void setContractCapacity(BigDecimal contractCapacity) {
    this.contractCapacity = contractCapacity;
  }

  /**
   * 更新回数のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 更新回数を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 更新回数
   */
  public Integer getUpdateCount() {
    return this.updateCount;
  }

  /**
   * 更新回数のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 更新回数を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param updateCount
   *          更新回数
   */
  public void setUpdateCount(Integer updateCount) {
    this.updateCount = updateCount;
  }

  /**
   * 付帯契約情報リストのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 付帯契約情報リストを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 付帯契約情報リスト
   */
  public List<KJ_SupplementaryContractBean> getSupplementaryContractList() {
    return this.supplementaryContractList;
  }

  /**
   * 付帯契約情報リストのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 付帯契約情報リストを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param supplementaryContractList
   *          付帯契約情報リスト
   */
  public void setSupplementaryContractList(List<KJ_SupplementaryContractBean> supplementaryContractList) {
    this.supplementaryContractList = supplementaryContractList;
  }

  /**
   * リターンコードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return リターンコード
   */
  public String getReturnCode() {
    return this.returnCode;
  }

  /**
   * リターンコードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param returnCode
   *          リターンコード
   */
  public void setReturnCode(String returnCode) {
    this.returnCode = returnCode;
  }

  /**
   * メッセージのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return メッセージ
   */
  public String getMessage() {
    return this.message;
  }

  /**
   * メッセージのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param message
   *          メッセージ
   */
  public void setMessage(String message) {
    this.message = message;
  }

  /**
   * 需要場所IDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 需要場所IDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 需要場所ID
   */
  public Integer getPlaceId() {
    return this.placeId;
  }

  /**
   * 需要場所IDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 需要場所IDを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param placeId
   *          需要場所ID
   */
  public void setPlaceId(Integer placeId) {
    this.placeId = placeId;
  }

  /**
   * メータ設置場所IDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メータ設置場所IDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return メータ設置場所ID
   */
  public Integer getMeterLocationId() {
    return this.meterLocationId;
  }

  /**
   * メータ設置場所IDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メータ設置場所IDを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param meterLocationId
   *          メータ設置場所ID
   */
  public void setMeterLocationId(Integer meterLocationId) {
    this.meterLocationId = meterLocationId;
  }

  /**
   * 契約IDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約IDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約ID
   */
  public Integer getContractId() {
    return this.contractId;
  }

  /**
   * 契約IDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約IDを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractId
   *          契約ID
   */
  public void setContractId(Integer contractId) {
    this.contractId = contractId;
  }

  /**
   * 付帯契約IDリストのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 付帯契約IDリストを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 付帯契約IDリスト
   */
  public List<Integer> getSupplementaryContractIdList() {
    return this.supplementaryContractIdList;
  }

  /**
   * 付帯契約IDリストのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 付帯契約IDリストを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param supplementaryContractIdList
   *          付帯契約IDリスト
   */
  public void setSupplementaryContractIdList(List<Integer> supplementaryContractIdList) {
    this.supplementaryContractIdList = supplementaryContractIdList;
  }

  /**
   * 付帯契約IDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 付帯契約IDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 付帯契約ID
   */
  public Integer getSupplementaryContractId() {
    return this.supplementaryContractId;
  }

  /**
   * 付帯契約IDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 付帯契約IDを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param supplementaryContractId
   *          付帯契約ID
   */
  public void setSupplementaryContractId(Integer supplementaryContractId) {
    this.supplementaryContractId = supplementaryContractId;
  }

  /**
   * 設備ID のgetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 設備IDを取得する。
   * </pre>
   * 
   * * @author "Nihon Unisys, Ltd."
   * 
   * @return 設備ID
   */
  public String getFree9() {
    return free9;
  }

  /**
   * 設備ID のsetter
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 設備IDを設定する。
   * </pre>
   * 
   * * @author "Nihon Unisys, Ltd."
   * 
   * @param free9
   *          設備ID
   */
  public void setFree9(String free9) {
    this.free9 = free9;
  }
}
