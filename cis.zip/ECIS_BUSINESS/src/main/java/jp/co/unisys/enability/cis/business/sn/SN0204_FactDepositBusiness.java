package jp.co.unisys.enability.cis.business.sn;

import java.util.Date;

/**
 * 請求入金共通本入金ビジネスインターフェース。
 *
 * @author "Nihon Unisys, Ltd."
 */
public interface SN0204_FactDepositBusiness {

  /**
   * 入金更新。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 手動入金理由コードが指定されている場合、【手動入金理由マスタ】より
   * 手動入金理由名称を取得する。
   * 入金ID、計上日をもとに【入金】を“本入金”に更新する。
   *
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param depositId
   *          入金ID
   * @param recordedDate
   *          計上日
   * @param batchBaseDate
   *          バッチ処理基準日
   * @param depositDate
   *          入金日
   * @param manuallyDepositReasonCode
   *          手動入金理由コード
   */
  public void updateDeposit(Integer depositId, Date recordedDate, Date batchBaseDate,
      Date depositDate, String manuallyDepositReasonCode);

}
