package jp.co.unisys.enability.cis.business.rk;

import jp.co.unisys.enability.cis.business.rk.model.Custom_InquiryFixChargeResultDetailInformationBusinessBean;

/**
 * 確定料金実績明細情報ビジネス_カスタムインターフェース
 *
 * @author "Nihon Unisys, Ltd."
 *
 *         変更履歴(kg-epj) 2016.02.05 ko 新規作成
 */
public interface Custom_InquiryFixChargeResultDetailInformationBusiness {

  /**
   * 確定料金実績明細情報を取得する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 確定料金実績明細情報の取得を行う。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param businessBean
   *          確定料金実績明細情報照会BusinessBean_カスタム
   * @return 確定料金実績明細情報照会BusinessBean_カスタム
   */
  public Custom_InquiryFixChargeResultDetailInformationBusinessBean inquiryFixChargeResultDetail(
      Custom_InquiryFixChargeResultDetailInformationBusinessBean businessBean);
}
