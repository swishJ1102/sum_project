package jp.co.unisys.enability.cis.business.sn;

import java.beans.PropertyDescriptor;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.sql.Timestamp;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.config.PropertiesFactoryBean;
import org.springframework.context.MessageSource;

import jp.co.unisys.enability.cis.business.common.TodoBusiness;
import jp.co.unisys.enability.cis.business.common.model.TodoBusinessBean;
import jp.co.unisys.enability.cis.business.gk.GK_WorkCommonBusiness;
import jp.co.unisys.enability.cis.business.sn.model.SN_CreateCsvBusinessBean;
import jp.co.unisys.enability.cis.business.sn.model.SN_ScreenBillingInfoBusinessBean;
import jp.co.unisys.enability.cis.common.Exception.BusinessLogicException;
import jp.co.unisys.enability.cis.common.Exception.SystemException;
import jp.co.unisys.enability.cis.common.util.CheckDigit;
import jp.co.unisys.enability.cis.common.util.StringConvertUtil;
import jp.co.unisys.enability.cis.common.util.ThreadContext;
import jp.co.unisys.enability.cis.common.util.constants.ECISCodeConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISSNConstants;
import jp.co.unisys.enability.cis.entity.common.Bl;
import jp.co.unisys.enability.cis.entity.common.BlStatusM;
import jp.co.unisys.enability.cis.entity.common.Fcr;
import jp.co.unisys.enability.cis.entity.common.FcrExample;
import jp.co.unisys.enability.cis.entity.common.FixChargeBlLinkage;
import jp.co.unisys.enability.cis.entity.common.FixChargeBlLinkageExample;
import jp.co.unisys.enability.cis.entity.common.UrgeStatusM;
import jp.co.unisys.enability.cis.entity.sn.SN_BillingContractorBean;
import jp.co.unisys.enability.cis.entity.sn.SN_BillingFixChargeResultBillingLinkageBean;
import jp.co.unisys.enability.cis.entity.sn.SN_ContractFixChargeResultPaymentEntityBean;
import jp.co.unisys.enability.cis.entity.sn.SN_IndividualMngContractBean;
import jp.co.unisys.enability.cis.entity.sn.SN_MaxUsePeriodEntityBean;
import jp.co.unisys.enability.cis.entity.sn.SN_ScreenBillingEntityBean;
import jp.co.unisys.enability.cis.entity.sn.SN_UncollectedBillingFlgEntityBean;
import jp.co.unisys.enability.cis.mapper.common.BlMapper;
import jp.co.unisys.enability.cis.mapper.common.BlStatusMMapper;
import jp.co.unisys.enability.cis.mapper.common.FcrMapper;
import jp.co.unisys.enability.cis.mapper.common.FixChargeBlLinkageMapper;
import jp.co.unisys.enability.cis.mapper.common.UrgeStatusMMapper;
import jp.co.unisys.enability.cis.mapper.gk.GK_WorkCommonMapper;
import jp.co.unisys.enability.cis.mapper.sn.SN_BillingCommonMapper;

/**
 * 請求入金共通ビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 *
 */
public class SN_BillingCommonBusinessImpl implements SN_BillingCommonBusiness {

  /** 請求のマッパー(DI) */
  private BlMapper blMapper;
  /** 請求ステータスマスタのマッパー(DI) */
  private BlStatusMMapper blStatusMMapper;
  /** 督促ステータスマスタのマッパー(DI) */
  private UrgeStatusMMapper urgeStatusMMapper;
  /** 請求入金共通のマッパー(DI) */
  private SN_BillingCommonMapper snBillingCommonMapper;
  /** シーケンス取得用共通マッパー(DI) */
  private GK_WorkCommonMapper gkWorkCommonMapper;
  /** 確定料金実績のマッパー(DI) */
  private FcrMapper fcrMapper;
  /** プロパティのファクトリーBean(DI) */
  private PropertiesFactoryBean applicationProperties;
  /** 確定料金・請求連携のマッパー(DI) */
  private FixChargeBlLinkageMapper fixChargeBlLinkageMapper;
  /** メッセージソース(DI) */
  private MessageSource messageSource;
  /** 業務共通ビジネス(DI) */
  private GK_WorkCommonBusiness gkWorkCommonBusiness;
  /** Todo共通ビジネス(DI) */
  private TodoBusiness todoBusiness;
  /** 請求番号を表す種類 */
  private static final String TYPE_BILLINGDEPOSITS = "type.billingdeposits";

  /*
   * (非 Javadoc)
   * @see jp.co.unisys.enability.cis.business.sn.SN_BillingCommonBusiness#
   * updateUncollectedRevenue(Integer)
   */
  @Override
  public SN_BillingContractorBean updateUncollectedRevenue(Integer billingId) throws BusinessLogicException {

    // 更新用のパラメータを設定する
    Bl billingEntity = new Bl();

    // 請求IDを設定する
    billingEntity.setBlId(billingId);
    // 請求ステータスコード(未収)を設定する
    billingEntity
        .setBlStatusCode(ECISCodeConstants.BILLING_STATUS_CODE_UNPAID);
    // 更新モジュールコードを設定する
    // コンテキストからモジュールコードを取得する
    String moduleCode = ThreadContext.getRequestThreadContext()
        .get(ECISConstants.CLASS_NAME_KEY).toString();
    billingEntity.setUpdateModuleCode(moduleCode);

    // 更新日時を設定する
    billingEntity.setUpdateTime(new Timestamp(System.currentTimeMillis()));

    // 請求を未収に更新する
    blMapper.updateByPrimaryKeySelective(billingEntity);

    // 請求・契約者情報を取得する
    Map<String, Object> exampleMap = new HashMap<String, Object>();
    // 取得条件を設定する
    exampleMap.put("billingId", billingId);
    // 請求・契約者情報を取得する
    SN_BillingContractorBean snBillingContractorBean = snBillingCommonMapper
        .selectBillingContractorInfo(exampleMap);

    // 請求・契約者情報が取得できない(nullが返ってきている)場合、SystemExceptionをスローする
    if (null == snBillingContractorBean) {
      throw new SystemException(messageSource.getMessage("error.E1312",
          new Object[] {billingId.toString() }, Locale.getDefault()));
    }

    /*
     * 請求区分が"債権回収依頼"、もしくは督促対象外フラグがONの場合、 請求・契約者情報Beanを返却する
     */
    if (ECISCodeConstants.BILLING_CATEGORY_CODE_COMMISSION_COLLECTION_CLAIM_COVERED
        .equals(snBillingContractorBean.getBillingCategoryCode())
        || ECISConstants.FLG_ON.equals(snBillingContractorBean
            .getUrgeNotCoveredFlag())) {
      return snBillingContractorBean;
    }

    // 契約が廃止、または解約になった確定料金実績を取得する
    Map<String, Object> exampleAbolitionMap = new HashMap<String, Object>();

    // 請求IDをMapに設定する
    exampleAbolitionMap.put("billingId", billingId);
    // 検針理由コード(廃止、解約)を設定する
    List<String> meterReasonCodeList = new ArrayList<String>();
    meterReasonCodeList
        .add(ECISCodeConstants.METER_READING_REASON_CODE_ABOLITION);
    meterReasonCodeList
        .add(ECISCodeConstants.METER_READING_REASON_CODE_CANCELLATION);
    // 契約終了理由コード(廃止(スイッチング)、廃止(転居)、廃止(利用停止)、解約(未収)、解約(契約不履行))を設定
    List<String> contractEndReasonList = new ArrayList<String>();
    contractEndReasonList
        .add(ECISCodeConstants.CONTRACT_END_REASON_CODE_ABOLITION_SWITCHING);
    contractEndReasonList
        .add(ECISCodeConstants.CONTRACT_END_REASON_CODE_ABOLITION_MOVE);
    contractEndReasonList
        .add(ECISCodeConstants.CONTRACT_END_REASON_CODE_ABOLITION_SUSPENSION_OF_USE);
    contractEndReasonList
        .add(ECISCodeConstants.CONTRACT_END_REASON_CODE_CANCELLATION_UNPAID);
    contractEndReasonList
        .add(ECISCodeConstants.CONTRACT_END_REASON_CODE_CANCELLATION_AGREEMENT_NONPERFORMANCE);

    // 検針理由コード、契約終了理由コードをMapに設定する
    exampleAbolitionMap.put("meterReadingReasonCode", meterReasonCodeList);
    exampleAbolitionMap.put("contractEndReasonCode", contractEndReasonList);

    // 請求・契約者情報を取得する
    List<SN_BillingFixChargeResultBillingLinkageBean> billingFixChargeResultEntityBeanList = snBillingCommonMapper
        .selectAbolitionCancellationInfo(exampleAbolitionMap);

    // 確定料金実績が取得出来た場合、契約が廃止または解約になった請求すべての
    // 確定料金実績IDを抽出する
    if (billingFixChargeResultEntityBeanList.size() > 0) {

      for (int i = 0; i < billingFixChargeResultEntityBeanList.size(); i++) {

        // 契約が廃止、または解約になった【確定料金実績】を抽出する
        Map<String, Object> exampleBillingLinkageMap = new HashMap<String, Object>();

        // 取得条件を設定
        exampleBillingLinkageMap.put("contractId",
            billingFixChargeResultEntityBeanList.get(i)
                .getContractId());
        exampleBillingLinkageMap.put("blStatusCodeUnpaid", ECISCodeConstants.BILLING_STATUS_CODE_UNPAID);
        exampleBillingLinkageMap.put("blStatusCodeInvalid", ECISCodeConstants.BILLING_STATUS_CODE_INVALID);
        exampleBillingLinkageMap.put("invalidFlagOff", ECISConstants.FLG_OFF);

        List<SN_BillingFixChargeResultBillingLinkageBean> billingFixChargeBillingLinkageEntityBeanList = snBillingCommonMapper
            .selectFixChargeBillingLinkageInfo(exampleBillingLinkageMap);

        // 確定料金実績のエンティティ
        Fcr fixChargeResultEntity = null;

        // 取得した件数分、確定料金実績を"債権回収依頼対象"に更新する
        for (int j = 0; j < billingFixChargeBillingLinkageEntityBeanList
            .size(); j++) {
          // 確定料金実績エンティティを初期化
          fixChargeResultEntity = new Fcr();

          // 更新条件(確定料金実績ID)を設定
          FcrExample example = new FcrExample();
          example.createCriteria().andFcrIdEqualTo(
              billingFixChargeBillingLinkageEntityBeanList.get(j)
                  .getFixChargeResultId());
          // 更新内容を設定
          fixChargeResultEntity.setCcccFlag(ECISConstants.FLG_ON);
          fixChargeResultEntity.setUpdateTime(new Timestamp(System
              .currentTimeMillis()));
          fixChargeResultEntity.setUpdateModuleCode(moduleCode);

          // 確定料金実績を更新
          fcrMapper.updateByExampleSelective(
              fixChargeResultEntity, example);
        }
      }
    }

    return snBillingContractorBean;
  }

  /*
   * (非 Javadoc)
   * @see jp.co.unisys.enability.cis.business.sn.SN_BillingCommonBusiness#
   * getScreenBillingInfo(Integer)
   */
  @Override
  public SN_ScreenBillingInfoBusinessBean getScreenBillingInfo(
      Integer billingId) throws BusinessLogicException {

    // 取得条件を設定
    Map<String, Object> screenInfoMap = new HashMap<String, Object>();

    // 請求IDを条件に設定
    screenInfoMap.put("billingId", billingId);
    // 提供モデルコード(直営)を設定
    screenInfoMap.put("provideModelCode",
        ECISCodeConstants.PROVIDE_MODEL_CODE_DIRECT_MANAGEMENT);

    SN_ScreenBillingEntityBean screenEntityBean = snBillingCommonMapper
        .selectScreenBillingInfo(screenInfoMap);

    // 表示情報が取得できなかった場合はシステム例外をスローする
    if (screenEntityBean == null) {
      throw new SystemException(messageSource.getMessage("error.E1275",
          null, Locale.getDefault()));
    }

    // 業務共通の請求番号編集を呼出し、請求番号を編集する。
    String billingNoEdit = "";
    try {
      billingNoEdit = gkWorkCommonBusiness.editBillingNo(screenEntityBean
          .getBillingNo());
    } catch (Exception e) {
      throw new SystemException(messageSource.getMessage("error.E1293",
          null, Locale.getDefault()), e);
    }

    // 取得した請求ステータスの名称を取得する。
    BlStatusM billingStatusMasterEntity = blStatusMMapper
        .selectByPrimaryKey(screenEntityBean.getBillingStatusCode());

    // 取得した督促ステータスの名称を取得する。
    UrgeStatusM urgeStatusMasterEntity = urgeStatusMMapper
        .selectByPrimaryKey(screenEntityBean.getUrgeStatusCode());

    // 取得した値を請求入金画面表示請求情報ビシネスBeanに設定し返却する。
    SN_ScreenBillingInfoBusinessBean screenBillingInfoBusinessBean = new SN_ScreenBillingInfoBusinessBean();
    // 請求ID
    screenBillingInfoBusinessBean.setBillingId(billingId);
    // 請求番号
    screenBillingInfoBusinessBean.setBillingNo(billingNoEdit);
    // 利用年月
    screenBillingInfoBusinessBean.setUsePeriod(screenEntityBean
        .getUsePeriod());
    // 請求額
    screenBillingInfoBusinessBean.setBillingAmount(screenEntityBean
        .getBillingAmount());
    // 支払期日
    screenBillingInfoBusinessBean.setPaymentFixedDate(screenEntityBean
        .getPaymentFixedDate());
    // 請求ステータス
    screenBillingInfoBusinessBean
        .setBillingStatus(billingStatusMasterEntity != null ? billingStatusMasterEntity
            .getBlStatus() : "");
    // 請求ステータスコード
    screenBillingInfoBusinessBean.setBillingStatusCode(screenEntityBean
        .getBillingStatusCode());

    // 督促ステータス
    screenBillingInfoBusinessBean
        .setUrgeStatus(urgeStatusMasterEntity != null ? urgeStatusMasterEntity.getUrgeStatus()
            : "");
    // 督促ステータスコード
    screenBillingInfoBusinessBean.setUrgeStatusCode(screenEntityBean.getUrgeStatusCode() != null ? screenEntityBean
        .getUrgeStatusCode() : "");

    // 督促管理更新回数
    screenBillingInfoBusinessBean
        .setUrgeMngUpdateCnt(screenEntityBean.getUrgeUpdateCount() != null ? screenEntityBean
            .getUrgeUpdateCount() : 0);

    // ご利用金額
    screenBillingInfoBusinessBean.setUseAmount(screenEntityBean
        .getUseAmount());
    // 請求更新回数
    screenBillingInfoBusinessBean.setBillingUpdateCnt(screenEntityBean
        .getBillingUpdateCount());

    return screenBillingInfoBusinessBean;
  }

  /*
   * (非 Javadoc)
   * @see jp.co.unisys.enability.cis.business.sn.SN_BillingCommonBusiness#
   * getBillingNumbering(String)
   */
  @Override
  public String getBillingNumbering(String batchBaseDate)
      throws BusinessLogicException {

    // 請求番号のシーケンス番号採番処理
    // シーケンス取得条件Mapを作成
    Map<String, Object> exampleMap = new HashMap<>();
    // シーケンステーブル名を設定
    exampleMap.put("sqName", ECISConstants.SEQUENCE_NAME_BL_NO);

    // 請求番号のシーケンスを取得
    String sqNo = String.valueOf(gkWorkCommonMapper
        .selectSequenceId(exampleMap));

    // プロパティから、「種類(請求入金)」を取得し、引数のバッチ処理基準日の年と
    // 先に取得したシーケンス番号の3つを連結してチェックディジットを取得する。
    Properties prop = null;
    try {
      prop = applicationProperties.getObject();
    } catch (IOException e) {
      throw new SystemException(messageSource.getMessage("error.E1265",
          null, Locale.getDefault()), e);
    }

    String propertyParam = prop.getProperty(TYPE_BILLINGDEPOSITS);

    StringBuilder paramStr = new StringBuilder();

    // 西暦の下二桁を取得
    String year = String.format(
        "%2s",
        batchBaseDate.substring(ECISSNConstants.YEAR_DIGITS_START_LOCATION,
            ECISSNConstants.YEAR_DIGITS_END_LOCATION))
        .replace(' ',
            ECISSNConstants.BILLING_FREE_DIGIT_FILL_CHARACTER);
    // シーケンスが8桁未満の場合は8桁になるように先頭を0埋めする
    String formatedSqNo = String.format("%8s", sqNo)
        .replace(' ', ECISSNConstants.BILLING_FREE_DIGIT_FILL_CHARACTER);

    paramStr.append(propertyParam);
    paramStr.append(year);
    paramStr.append(formatedSqNo);

    String checkDigit = "";

    try {
      checkDigit = CheckDigit.calcCheckDigitByModulas10Weight3(paramStr
          .toString());

    } catch (Exception e) {
      throw new SystemException(messageSource.getMessage(
          "error.E1277", null, Locale.getDefault()), e);
    }

    return checkDigit;
  }

  /*
   * (非 Javadoc)
   * @see jp.co.unisys.enability.cis.business.sn.SN_BillingCommonBusiness#
   * clearUncollectedBillingFlg(Integer)
   */
  @Override
  public void clearUncollectedBillingFlg(Integer billingId)
      throws BusinessLogicException {

    // 請求IDに紐付く確定料金・請求連携情報を取得
    Map<String, Object> exampleMap = new HashMap<String, Object>();
    exampleMap.put("billingId", billingId);

    List<SN_UncollectedBillingFlgEntityBean> uncollectedBillingList = snBillingCommonMapper
        .selectUncollectedBillingFlg(exampleMap);

    // 更新日付用TimeStamp変数
    Timestamp nowTime;

    // 取得した対象の合算要否フラグ、債権回収依頼対象フラグを初期化する
    for (int i = 0; i < uncollectedBillingList.size(); i++) {

      // 更新件数
      int result = 0;

      // コンテキストからオンラインフラグを取得する
      String onlineFlg = ThreadContext.getRequestThreadContext()
          .get(ECISConstants.ONLINE_FLAG_KEY).toString();

      // コンテキストからモジュールコードを取得する
      String moduleCode = ThreadContext.getRequestThreadContext()
          .get(ECISConstants.CLASS_NAME_KEY).toString();

      // 合算要否フラグがONの場合、以下の処理を行う
      if (ECISConstants.FLG_ON.equals(uncollectedBillingList.get(i)
          .getAddUpNeedFlag())) {

        // 更新日時を取得
        nowTime = new Timestamp(System.currentTimeMillis());

        // 更新内容を設定
        FixChargeBlLinkage record = new FixChargeBlLinkage();
        record.setAddUpNeedFlag(ECISConstants.FLG_OFF);
        record.setUpdateTime(nowTime);
        record.setUpdateModuleCode(moduleCode);

        // 更新条件を設定
        FixChargeBlLinkageExample example = new FixChargeBlLinkageExample();
        example.createCriteria()
            .andBlIdEqualTo(billingId)
            .andFcrIdEqualTo(
                uncollectedBillingList.get(i)
                    .getFixChargeResultId())
            .andUpdateCountEqualTo(
                uncollectedBillingList.get(i)
                    .getLinkageUpdateCount());

        // オンラインフラグが「オンライン」の場合、更新回数を条件に追加し、 更新内容を追加する
        if (ECISConstants.ONLINE_FLAG_ONLINE.equals(onlineFlg)) {

          // コンテキストからユーザIDを取得する
          String userId = ThreadContext.getRequestThreadContext()
              .get(ECISConstants.USER_ID_KEY).toString();

          // 更新内容を設定
          record.setUpdateCount(uncollectedBillingList.get(i)
              .getFixUpdateCount() + 1);
          record.setOnlineUpdateTime(nowTime);
          record.setOnlineUpdateUserId(userId);

          // 確定料金・請求連携を更新
          result = fixChargeBlLinkageMapper
              .updateByExampleSelective(record, example);

        } else {
          // 更新条件を設定
          record.setBlId(billingId);
          record.setFcrId(uncollectedBillingList.get(i)
              .getFixChargeResultId());

          // 確定料金・請求連携を更新
          result = fixChargeBlLinkageMapper
              .updateByPrimaryKeySelective(record);
        }

        // 更新出来なかった場合は業務例外をスローする
        if (result == 0) {
          throw new BusinessLogicException("warn.W1011");
        }
      }

      // 債権回収依頼対象フラグがONの場合、以下の処理を行う
      if (ECISConstants.FLG_ON.equals(uncollectedBillingList.get(i)
          .getCommissionCollectionClaimCoveredFlag())) {

        // 更新日時を取得
        nowTime = new Timestamp(System.currentTimeMillis());

        // 更新内容を設定
        Fcr record = new Fcr();
        record.setCcccFlag(ECISConstants.FLG_OFF);
        record.setUpdateTime(nowTime);
        record.setUpdateModuleCode(moduleCode);

        // オンラインフラグが「オンライン」の場合、更新回数を条件に追加し、
        // 更新内容を追加する
        if (ECISConstants.ONLINE_FLAG_ONLINE.equals(onlineFlg)) {

          // 更新条件を設定
          FcrExample example = new FcrExample();
          example.createCriteria()
              .andFcrIdEqualTo(
                  uncollectedBillingList.get(i)
                      .getFixChargeResultId())
              .andUpdateCountEqualTo(
                  uncollectedBillingList.get(i)
                      .getFixUpdateCount());

          // コンテキストからユーザIDを取得する
          String userId = ThreadContext.getRequestThreadContext()
              .get(ECISConstants.USER_ID_KEY).toString();

          // 更新内容を設定
          record.setUpdateCount(uncollectedBillingList.get(i)
              .getFixUpdateCount() + 1);
          record.setOnlineUpdateUserId(userId);
          record.setOnlineUpdateTime(nowTime);

          // 確定料金実績を更新
          result = fcrMapper.updateByExampleSelective(
              record, example);

        } else {

          // 更新条件を設定
          record.setFcrId(uncollectedBillingList.get(i)
              .getFixChargeResultId());

          // 確定料金実績を更新
          result = fcrMapper
              .updateByPrimaryKeySelective(record);

        }

        // 更新出来なかった場合は業務例外をスローする
        if (result == 0) {
          throw new BusinessLogicException("warn.W1011");
        }
      }
    }
  }

  /*
   * (非 Javadoc)
   * @see jp.co.unisys.enability.cis.business.sn.SN_BillingCommonBusiness#
   * getPropertiesData(String)
   */
  @Override
  public Map<String, String> getPropertiesData(String fileName)
      throws BusinessLogicException {

    // プロパティファイルのオブジェクトを生成
    Properties prop = new Properties();

    // プロパティの情報を格納するMap
    Map<String, String> infoMap = new HashMap<String, String>();

    // 入力ストリームに読み込み対象のプロパティファイルを設定
    try (InputStream inputStream = ClassLoader
        .getSystemResourceAsStream(fileName)) {

      // 読み込み対象のプロパティファイルをロード
      prop.load(inputStream);
      // ロードしたプロパティファイルの要素を取得
      Enumeration<?> en = prop.propertyNames();

      // ロードしたプロパティに設定されている全てのキーとValueを取得し、
      // Mapに格納する
      while (en.hasMoreElements()) {

        // キーを取得
        String key = (String) en.nextElement();

        // 取得したキーが空、もしくはnullの場合エラーとする
        if (StringUtils.isEmpty(key)) {
          throw new BusinessLogicException("error.E1308", new String[] {fileName });
        }

        // 取得したキーに設定されているValueを取得
        String value = prop.getProperty(key);

        // 取得したキーとValueをMapに設定
        infoMap.put(key, value);
      }

    } catch (BusinessLogicException be) {
      // BusinessLogicExceptionの場合(プロパティファイルの書式エラー)は、そのままスローする。
      throw be;
    } catch (Exception e) {
      // BusinessLogicExeption以外はSystemExceptionとしてスローする。
      throw new SystemException(messageSource.getMessage("error.E1278",
          null, Locale.getDefault()), e);
    }

    return infoMap;
  }

  /*
   * (非 Javadoc)
   * @see jp.co.unisys.enability.cis.business.sn.SN_BillingCommonBusiness#
   * createListForCsv(jp.co.unisys.enability.cis.business.sn.model.SN_CreateCsvBusinessBean, Map, String)
   */
  @Override
  public List<String> createListForCsv(SN_CreateCsvBusinessBean bean,
      Map<String, String> map, String csvCategory) {

    // 返却するCSV出力用配列
    List<String> csvList = new ArrayList<String>();

    // 引数のCSVファイルレコード設定情報マップのサイズ分、処理を繰り返す
    for (int i = 1; i < map.size() + 1; i++) {
      if (!ECISSNConstants.CSV_RECORD_SET_NULL.equals(map.get(String.valueOf(i)))) {
        // 該当するマップの値がNULLで無い場合は、
        // 対応する値を引数のCSV作成用ビジネスBeanから取得し設定する

        // Valueと等しい名称のフィールドにアクセスする
        try {
          PropertyDescriptor propDesc = new PropertyDescriptor(
              map.get(String.valueOf(i)), bean.getClass());

          // Valueと等しい名称のフィールドのゲッターを取得
          Method getter = propDesc.getReadMethod();
          // 取得したゲッターから値を取得し、リストに設定
          if (StringUtils.isEmpty((String) getter.invoke(bean,
              (Object[]) null))) {
            csvList.add(null);
          } else {
            // ファイルの区分がその他ファイルの場合は文字コードをSJISに変換
            if (ECISSNConstants.OTHER_CSV_FILE.equals(csvCategory)) {
              csvList.add(StringConvertUtil.utf8ToSjis((String) getter.invoke(bean, (Object[]) null)));
            } else if (ECISSNConstants.SETTLEMENT_AGENCY_LINKAGE_CSV_FILE.equals(csvCategory)) {
              //決済代行連携ファイルの場合はUTF8(そのまま)で設定
              csvList.add((String) getter.invoke(bean, (Object[]) null));
            } else {
              // 上記以外の場合
              // システム例外をスローする。
              throw new SystemException(
                  messageSource.getMessage("error.E1300", null, Locale.getDefault()));
            }
          }
        } catch (Exception e) {
          throw new SystemException(messageSource.getMessage(
              "error.E1279", null, Locale.getDefault()), e);
        }

      } else {
        // 該当するマップの値が文字列の"null"の場合は
        // nullを配列に追加する
        csvList.add(null);
      }

    }

    return csvList;
  }

  /*
   * (非 Javadoc)
   * @see jp.co.unisys.enability.cis.business.sn.SN_BillingCommonBusiness#
   * getSumDepositAppropriation(String)
   */
  @Override
  public Long getSumDepositAppropriation(String billingNo)
      throws BusinessLogicException {

    // 入金の合計金額を取得する条件を設定する
    Map<String, Object> exampleDepositMap = new HashMap<String, Object>();
    // 請求番号を設定する
    exampleDepositMap.put("billingNo", billingNo);
    // 入金ステータスコード(収納)を設定する
    exampleDepositMap.put("depositStatusCode",
        ECISCodeConstants.DEPOSIT_STATUS_CODE_RECEIPT);
    // 入金の合計金額を取得する
    Long depositAmont = snBillingCommonMapper
        .selectSumDepositAppropriation(exampleDepositMap);

    // 預り金等の合計金額を取得する条件を設定する
    Map<String, Object> exampleReceivedMap = new HashMap<String, Object>();
    // 請求番号を設定する
    exampleReceivedMap.put("billingNo", billingNo);
    // 預り金等ステータスコード(充当予約)を設定する
    exampleReceivedMap
        .put("depositReceivedStatusCode",
            ECISCodeConstants.DEPOSITS_RECEIVED_STATUS_CODE_APPROPRIATION_RESERVATION);
    // 預り金等の合計金額を取得する
    Long depositReceived = snBillingCommonMapper
        .selectSumReceivedAppropriation(exampleReceivedMap);

    // 入金額合計と預り金等合計の合算を返却する
    return depositAmont + depositReceived;
  }

  /*
   * (非 Javadoc)
   * @see jp.co.unisys.enability.cis.business.sn.SN_BillingCommonBusiness#
   * updateReceiptRelation(Integer,String,String,Integer,String,String,String,String)
   */
  @Override
  public void updateReceiptRelation(Integer blId, String blNo, String contractorNo,
      Integer paymentId, String usePeriod, String previousBlAddUpFlag,
      String receivablesFlag, String functionId)
      throws BusinessLogicException {

    if (ECISConstants.FLG_OFF.equals(receivablesFlag)) {
      // 引数.債権回収依頼フラグが“OFF”の場合

      List<SN_IndividualMngContractBean> snIndividualMngContractBeanList = new ArrayList<SN_IndividualMngContractBean>();

      // 条件Map生成
      Map<String, Object> exampleMap = new HashMap<String, Object>();
      exampleMap.put("blId", blId);

      // 請求IDに紐づく【確定料金実績】【契約】【支払】取得を呼び出す。
      List<SN_ContractFixChargeResultPaymentEntityBean> snContractFixChargeResultPaymentEntityBeanList = snBillingCommonMapper
          .selectContractFixChargeResultPayment(exampleMap);

      for (SN_ContractFixChargeResultPaymentEntityBean snContractFixChargeResultPaymentEntityBean : snContractFixChargeResultPaymentEntityBeanList) {
        if (ECISConstants.FLG_ON.equals(snContractFixChargeResultPaymentEntityBean.getPreviousBlAddUpFlag())) {
          //  取得した【支払】.前月請求合算フラグ ＝ “ON”である場合、取得した【確定料金実績】.確定料金実績IDに紐づく
          // 【確定料金・請求連携】.合算要否フラグを"ON"に更新する。

          // 確定料金・請求連携EntityBeanを生成
          FixChargeBlLinkageExample fixChargeBlLinkageExample = new FixChargeBlLinkageExample();
          FixChargeBlLinkage fixChargeBlLinkage = new FixChargeBlLinkage();

          // 請求ID、確定料金実績ID
          fixChargeBlLinkageExample.createCriteria()
              .andBlIdEqualTo(blId)
              .andFcrIdEqualTo(snContractFixChargeResultPaymentEntityBean.getFcrId());

          // 合算要否フラグ
          fixChargeBlLinkage.setAddUpNeedFlag(ECISConstants.FLG_ON);
          // 更新日時
          fixChargeBlLinkage.setUpdateTime(new Timestamp(System.currentTimeMillis()));
          // 更新モジュールコード
          fixChargeBlLinkage.setUpdateModuleCode(
              ThreadContext.getRequestThreadContext().get(ECISConstants.CLASS_NAME_KEY).toString());

          // 合算要否フラグ更新処理（確定料金・請求連携マッパー.選択項目更新（主キー）呼び出し）
          fixChargeBlLinkageMapper.updateByExampleSelective(fixChargeBlLinkage, fixChargeBlLinkageExample);
        } else {
          //	取得した【契約】.契約番号と【確定料金実績】.利用年月を内部変数の「個別管理契約リスト」に格納する。

          SN_IndividualMngContractBean snIndividualMngContractBean = new SN_IndividualMngContractBean();
          snIndividualMngContractBean
              .setContractNo(snContractFixChargeResultPaymentEntityBean.getContractNo());
          snIndividualMngContractBean.setUsePeriod(snContractFixChargeResultPaymentEntityBean.getUsePeriod());
          snIndividualMngContractBeanList.add(snIndividualMngContractBean);
        }
      }

      if (snIndividualMngContractBeanList.size() > 0) {
        // リストに登録されている場合、合算対象外の契約が未収となっている旨をTODOに登録する。
        // 《TODOビジネスBean》生成
        TodoBusinessBean todoBusinessBean = new TodoBusinessBean();

        if (snContractFixChargeResultPaymentEntityBeanList.size() != snIndividualMngContractBeanList.size()) {
          // 請求IDに紐づく【確定料金実績】【契約】【支払】取得で取得したリストの件数と
          // 内部変数「個別管理契約リスト」の件数が異なる場合
          StringBuilder note = new StringBuilder().append(
              messageSource.getMessage("info.I1037", null, Locale.getDefault()));

          for (SN_IndividualMngContractBean snIndividualMngContractBean : snIndividualMngContractBeanList) {
            // リストに登録されている数分、メッセージを連結する。
            note.append(ECISConstants.ENTER_CODE);
            note.append(messageSource.getMessage(
                "info.I1038",
                new String[] {
                    snIndividualMngContractBean.getContractNo(),
                    snIndividualMngContractBean.getUsePeriod() },
                Locale.getDefault()));
          }

          // 備考を設定する。
          todoBusinessBean.setNote(note.toString());
        }
        // 内部変数「個別管理契約リスト」が作成されている場合、合算対象外の契約が未収となっている旨をTODOに登録する。
        // TODO用メッセージ
        String todoMessage = messageSource.getMessage(
            "todo.T1049",
            new String[] {
                blNo,
                contractorNo },
            Locale.getDefault());

        // サブシステムID
        todoBusinessBean.setSubsystemId(ECISConstants.SUBSYSTEM_ID_SN);
        // 機能ID
        todoBusinessBean.setFunctionId(functionId);
        // メッセージID
        todoBusinessBean.setMessageId("todo.T1049");
        // メッセージ設定
        todoBusinessBean.setMessage(todoMessage);

        // TODO登録実行（Todo共通ビジネス.TODO登録呼び出し）
        todoBusiness.registTodo(todoBusinessBean);
      }
      if (ECISConstants.FLG_ON.equals(previousBlAddUpFlag)) {
        // 引数.前月請求合算フラグ = “ON”である場合
        // 翌々月以降の合算請求通知TODO登録する。
        this.registToDoAddUpBilling(
            paymentId,
            usePeriod,
            functionId,
            blNo,
            contractorNo);
      }
    }
    // 請求ステータス（“未収”）、及び債権回収依頼対象フラグ（“債権回収対象”）の更新
    // （請求入金共通ビジネス.未収および債権回収依頼対象登録処理呼び出し）
    SN_BillingContractorBean snBillingContractorBean = this.updateUncollectedRevenue(blId);

    // 《請求入金請求・契約者EntityBean》.督促対象外フラグ ＝ ON（督促対象外）の場合
    if (ECISConstants.FLG_ON.equals(snBillingContractorBean.getUrgeNotCoveredFlag())) {
      // TODO登録
      //   督促対象とならない契約者への請求が”未収”
      // TODO用メッセージ
      String todoMessage = messageSource.getMessage(
          "todo.T1009",
          new String[] {
              snBillingContractorBean.getBillingNo(),
              snBillingContractorBean.getContractorNo() },
          Locale.getDefault());

      // 《TODOビジネスBean》生成
      TodoBusinessBean todoBusinessBean = new TodoBusinessBean();

      // サブシステムID
      todoBusinessBean.setSubsystemId(ECISConstants.SUBSYSTEM_ID_SN);
      // 機能ID
      todoBusinessBean.setFunctionId(functionId);
      // メッセージID
      todoBusinessBean.setMessageId("todo.T1009");
      // メッセージ設定
      todoBusinessBean.setMessage(todoMessage);

      // TODO登録実行（Todo共通ビジネス.TODO登録呼び出し）
      todoBusiness.registTodo(todoBusinessBean);
    }
  }

  /*
   * (非 Javadoc)
   * @see jp.co.unisys.enability.cis.business.sn.SN_BillingCommonBusiness#
   * registToDoAddUpBilling(Integer,String,String,String,String)
   */
  private void registToDoAddUpBilling(Integer paymentId, String usePeriod, String functionId, String blNo,
      String contractorNo) {

    // 同一の支払を持つ請求の利用年月の最大値を取得する。
    // 検索条件を条件Mapに設定する。
    Map<String, Object> exampleMap = new HashMap<String, Object>();
    exampleMap.put("paymentId", paymentId);
    exampleMap.put("usePeriod", usePeriod);

    // 請求入金共通Mapper.利用年月最大値取得を呼び出す。
    List<SN_MaxUsePeriodEntityBean> snMaxUsePeriodEntityBeanList = snBillingCommonMapper
        .selectMaxUsePeriod(exampleMap);

    // 利用年月の最大値が取得できた場合、以下を行う。
    if (snMaxUsePeriodEntityBeanList != null && snMaxUsePeriodEntityBeanList.size() > 0) {

      // 通常検針有無フラグをOFFで生成する。
      String normalFlg = ECISConstants.FLG_OFF;
      String todoId = "";
      String todoMessage = null;
      // 《利用年月最大値EntityBean》リストの数分以下を行う。
      for (SN_MaxUsePeriodEntityBean snMaxUsePeriodEntityBean : snMaxUsePeriodEntityBeanList) {
        if (ECISCodeConstants.METER_READING_REASON_CODE_NORMAL.equals(
            snMaxUsePeriodEntityBean.getMrReasonCode())) {
          // 通常検針有無フラグをONに設定する。
          normalFlg = ECISConstants.FLG_ON;

          if (snMaxUsePeriodEntityBean.getUsePeriod().compareTo(usePeriod) > 0) {
            String nnYM = "";
            try {
              // 利用年月に1ヶ月を足す。
              nnYM = StringConvertUtil.calcMonth(snMaxUsePeriodEntityBean.getUsePeriod(), 1,
                  ECISConstants.FORMAT_DATE_yyyyMM);
            } catch (ParseException e) {
              // エラーメッセージの出力
              SystemException se = new SystemException(
                  messageSource.getMessage("error.E1294", null, Locale.getDefault()), e);
              throw se;
            }

            // 翌々月請求に合算される旨をTODOに登録する。
            todoId = "todo.T1050";
            // TODO用メッセージ
            todoMessage = messageSource.getMessage(
                todoId,
                new String[] {
                    nnYM,
                    blNo,
                    contractorNo },
                Locale.getDefault());
            break;
          }
        }
      }

      if (ECISConstants.FLG_OFF.equals(normalFlg)) {
        // 翌月以降の請求に合算されない旨をTODOに登録する。
        todoId = "todo.T1051";
        // TODO用メッセージ
        todoMessage = messageSource.getMessage(
            todoId,
            new String[] {
                blNo,
                usePeriod,
                contractorNo },
            Locale.getDefault());
      }
      if (todoMessage != null) {
        // 《TODOビジネスBean》生成
        TodoBusinessBean todoBusinessBean = new TodoBusinessBean();
        // サブシステムID
        todoBusinessBean.setSubsystemId(ECISConstants.SUBSYSTEM_ID_SN);
        // 機能ID
        todoBusinessBean.setFunctionId(functionId);
        // メッセージID
        todoBusinessBean.setMessageId(todoId);
        // メッセージ設定
        todoBusinessBean.setMessage(todoMessage);
        // 契約者番号
        todoBusinessBean.setContractorNo(contractorNo);
        // TODO登録実行（Todo共通ビジネス.TODO登録呼び出し）
        todoBusiness.registTodo(todoBusinessBean);
      }
    }
  }

  /**
   * 請求のマッパーを設定する。(DI)
   *
   * @param blMapper
   *          請求のマッパー(DI)
   */
  public void setBlMapper(BlMapper blMapper) {
    this.blMapper = blMapper;
  }

  /**
   * 請求ステータスマスタのマッパーを設定する。(DI)
   *
   * @param blStatusMMapper
   *          請求ステータスマスタのマッパー(DI)
   */
  public void setBlStatusMMapper(
      BlStatusMMapper blStatusMMapper) {
    this.blStatusMMapper = blStatusMMapper;
  }

  /**
   * 督促ステータスマスタのマッパーを設定する。(DI)
   *
   * @param urgeStatusMMapper
   *          督促ステータスマスタのマッパー(DI)
   */
  public void setUrgeStatusMMapper(
      UrgeStatusMMapper urgeStatusMMapper) {
    this.urgeStatusMMapper = urgeStatusMMapper;
  }

  /**
   * 請求入金共通のマッパーを設定する。(DI)
   *
   * @param snBillingCommonMapper
   *          請求入金共通のマッパー(DI)
   */
  public void setSnBillingCommonMapper(
      SN_BillingCommonMapper snBillingCommonMapper) {
    this.snBillingCommonMapper = snBillingCommonMapper;
  }

  /**
   * 確定料金実績のマッパーを設定する。(DI)
   *
   * @param fcrMapper
   *          確定料金実績のマッパー(DID
   */
  public void setFcrMapper(FcrMapper fcrMapper) {
    this.fcrMapper = fcrMapper;
  }

  /**
   * プロパティのファクトリーBeanを設定する。(DI)
   *
   * @param applicationProperties
   *          プロパティのファクトリーBean(DI)
   */

  public void setApplicationProperties(
      PropertiesFactoryBean applicationProperties) {
    this.applicationProperties = applicationProperties;
  }

  /**
   * 確定料金・請求連携のマッパーを設定する。(DI)
   *
   * @param fixChargeBlLinkageMapper
   *          確定料金・請求連携のマッパー(DI)
   */
  public void setFixChargeBlLinkageMapper(
      FixChargeBlLinkageMapper fixChargeBlLinkageMapper) {
    this.fixChargeBlLinkageMapper = fixChargeBlLinkageMapper;
  }

  /**
   * 業務共通ビジネスを設定する。(DI)
   *
   * @param gkWorkCommonBusiness
   *          業務共通ビジネス(DI)
   */
  public void setGkWorkCommonBusiness(
      GK_WorkCommonBusiness gkWorkCommonBusiness) {
    this.gkWorkCommonBusiness = gkWorkCommonBusiness;
  }

  /**
   * Todo共通ビジネスを設定する。(DI)
   *
   * @param todoBusiness
   *          Todo共通ビジネス
   */
  public void setTodoBusiness(
      TodoBusiness todoBusiness) {
    this.todoBusiness = todoBusiness;
  }

  /**
   * シーケンス取得用マッパーを設定する。(DI)
   *
   * @param gkWorkCommonMapper
   *          シーケンス取得用マッパー(DI)
   */
  public void setGkWorkCommonMapper(GK_WorkCommonMapper gkWorkCommonMapper) {
    this.gkWorkCommonMapper = gkWorkCommonMapper;
  }

  /**
   * メッセージソースを設定する。(DI)
   *
   * @param messageSource
   *          メッセージソース
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }

}
