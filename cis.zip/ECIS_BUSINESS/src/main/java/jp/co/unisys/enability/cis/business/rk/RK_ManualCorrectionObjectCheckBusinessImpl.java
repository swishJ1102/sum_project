package jp.co.unisys.enability.cis.business.rk;

import jp.co.unisys.enability.cis.business.rk.model.RK_ChargeCalcWarningCheckBusinessBean;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;
import jp.co.unisys.enability.cis.entity.common.Contract;
import jp.co.unisys.enability.cis.mapper.common.ContractMapper;

/**
 * BRK0103-03手動補正対象チェックビジネス
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.mapper.common.ContractMapper
 */
public class RK_ManualCorrectionObjectCheckBusinessImpl implements RK_ChargeCalcWarningCheckBusiness {

  /**
   * 契約Mapper(DI)
   */
  private ContractMapper contractMapper;

  /**
   * 手動補正対象チェック。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 【契約】.料金チェックフラグによりチェックを行う。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param chargeCalcWarningCheckBean
   *          《料金計算警告チェックビジネスBean》
   * @return 警告コード
   * @see jp.co.unisys.enability.cis.mapper.common.ContractMapper
   */
  @Override
  public String check(RK_ChargeCalcWarningCheckBusinessBean chargeCalcWarningCheckBean) {
    // 契約エンティティをPK検索
    Contract contract = contractMapper.selectByPrimaryKey(chargeCalcWarningCheckBean.getContractId());
    // 契約.料金チェックフラグがONの場合、手動補正警告を返却する
    if (ECISConstants.FLG_ON.equals(contract.getChargeCheckFlag())) {
      return ECISRKConstants.WARNING_CLASS_MASTER_MANUAL_CORRECTION_COVERED;
    }
    // 料金チェックフラグがONでない場合は警告コードは無し
    return null;
  }

  /**
   * 契約Mapperのsetter（DI）
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約Mapperを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractMapper
   *          契約Mapper
   */
  public void setContractMapper(ContractMapper contractMapper) {
    this.contractMapper = contractMapper;
  }

}
