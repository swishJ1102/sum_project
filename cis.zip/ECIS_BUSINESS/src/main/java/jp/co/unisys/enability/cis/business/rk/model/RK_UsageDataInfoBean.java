/*-------------------------------------------------------------------------------
 * All Rights Reserved. Copyright(C) Nihon Unisys, Ltd.
 * vendor : Nihon Unisys, Ltd.
 * create : 2016/04/20
 *-----------------------------------------------------------------------------*/
package jp.co.unisys.enability.cis.business.rk.model;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * 使用量CSV仕訳ビジネスの使用量データ情報を保持するBeanクラス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_UsageDataInfoBean {

  /**
   * 計器番号を保有する。
   */
  private String meterNo;

  /**
   * 対象年月日を保有する。
   */
  private Date usageDate;

  /**
   * 使用量リストを保有する。
   */
  private List<BigDecimal> usageQuantityList;

  /**
   * 低圧使用量ファイル.計器番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 低圧使用量ファイル.計器番号を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 低圧使用量ファイル.計器番号
   */
  public String getMeterno() {
    return meterNo;
  }

  /**
   * 低圧使用量ファイル.計器番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 低圧使用量ファイル.計器番号を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return meterNo 低圧使用量ファイル.計器番号
   */
  public void setMeterno(String meterNo) {
    this.meterNo = meterNo;

  }

  /**
   * 低圧使用量ファイル.対象年月日のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 低圧使用量ファイル.対象年月日を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 低圧使用量ファイル.対象年月日
   */
  public Date getUsagedate() {
    return usageDate;
  }

  /**
   * 低圧使用量ファイル.対象年月日のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 低圧使用量ファイル.対象年月日を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return usageDate 低圧使用量ファイル.対象年月日
   */
  public void setUsagedate(Date usageDate) {
    this.usageDate = usageDate;

  }

  /**
   * 低圧使用量ファイル.計量時間帯01使用量～計量時間帯48使用量のリスト 未設定の場合nullを設定する。のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 低圧使用量ファイル.計量時間帯01使用量～計量時間帯48使用量のリスト
   * 未設定の場合nullを設定する。を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 低圧使用量ファイル.計量時間帯01使用量～計量時間帯48使用量のリスト 未設定の場合null。
   */
  public List<BigDecimal> getUsagequantitylist() {
    return usageQuantityList;
  }

  /**
   * 低圧使用量ファイル.計量時間帯01使用量～計量時間帯48使用量のリスト 未設定の場合nullを設定する。のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 低圧使用量ファイル.計量時間帯01使用量～計量時間帯48使用量のリスト
   * 未設定の場合nullを設定する。を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return usageQuantityList 低圧使用量ファイル.計量時間帯01使用量～計量時間帯48使用量のリスト 未設定の場合null。
   */
  public void setUsagequantitylist(List<BigDecimal> usageQuantityList) {
    this.usageQuantityList = usageQuantityList;

  }
}
