package jp.co.unisys.enability.cis.business.rk.model;

import java.math.BigDecimal;

/**
 * 料金メニュー検索APIの検索結果で、従量料金単価明細の情報を保持するビジネスクラス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_SearchRateMenuUsageChargeUPDetailBusinessBean {

  /**
   * 閾値を保有する。
   */
  private String threshold;

  /**
   * 単価を保有する。
   */
  private BigDecimal unitPrice;

  /**
   * 表示名称1を保有する。
   */
  private String displayName1;

  /**
   * 表示名称2を保有する。
   */
  private String displayName2;

  /**
   * 明細出力順を保有する。
   */
  private Integer detailOutputOrder;

  /**
   * DCEC区分コードを保有する。
   */
  private String dcecCatCode;

  /**
   * 時間帯コードを保有する。
   */
  private String tsCode;

  /**
   * 枝番を保有する。
   */
  private Short brandNo;

  /**
   * 閾値名称を保有する。
   */
  private String thresholdName;

  /**
   * 表示順を保有する。
   */
  private Short displayOrder;

  /**
   * 閾値のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 閾値を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 閾値
   */
  public String getThreshold() {
    return this.threshold;
  }

  /**
   * 閾値のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 閾値を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param threshold
   *          閾値
   */
  public void setThreshold(String threshold) {
    this.threshold = threshold;
  }

  /**
   * 単価のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 単価を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 単価
   */
  public BigDecimal getUnitPrice() {
    return this.unitPrice;
  }

  /**
   * 単価のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 単価を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param unitPrice
   *          単価
   */
  public void setUnitPrice(BigDecimal unitPrice) {
    this.unitPrice = unitPrice;
  }

  /**
   * 表示名称1のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 表示名称1を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 表示名称1
   */
  public String getDisplayName1() {
    return this.displayName1;
  }

  /**
   * 表示名称1のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 表示名称1を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param displayName1
   *          表示名称1
   */
  public void setDisplayName1(String displayName1) {
    this.displayName1 = displayName1;
  }

  /**
   * 表示名称2のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 表示名称2を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 表示名称2
   */
  public String getDisplayName2() {
    return this.displayName2;
  }

  /**
   * 表示名称2のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 表示名称2を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param displayName2
   *          表示名称2
   */
  public void setDisplayName2(String displayName2) {
    this.displayName2 = displayName2;
  }

  /**
   * 明細出力順のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 明細出力順を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 明細出力順
   */
  public Integer getDetailOutputOrder() {
    return this.detailOutputOrder;
  }

  /**
   * 明細出力順のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 明細出力順を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param detailOutputOrder
   *          明細出力順
   */
  public void setDetailOutputOrder(Integer detailOutputOrder) {
    this.detailOutputOrder = detailOutputOrder;
  }

  /**
   * DCEC区分コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * DCEC区分コードを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return DCEC区分コード
   */
  public String getDcecCatCode() {
    return dcecCatCode;
  }

  /**
   * DCEC区分コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * DCEC区分コードを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param dcecCatCode
   *          DCEC区分コード
   */
  public void setDcecCatCode(String dcecCatCode) {
    this.dcecCatCode = dcecCatCode;
  }

  /**
   * 時間帯コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 時間帯コードを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 時間帯コード
   */
  public String getTsCode() {
    return tsCode;
  }

  /**
   * 時間帯コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 時間帯コードを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param tsCode
   *          時間帯コード
   */
  public void setTsCode(String tsCode) {
    this.tsCode = tsCode;
  }

  /**
   * 枝番のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 枝番を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 枝番
   */
  public Short getBrandNo() {
    return brandNo;
  }

  /**
   * 枝番のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 枝番を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param brandNo
   *          枝番
   */
  public void setBrandNo(Short brandNo) {
    this.brandNo = brandNo;
  }

  /**
   * 閾値名称のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 閾値名称を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 閾値名称
   */
  public String getThresholdName() {
    return thresholdName;
  }

  /**
   * 閾値名称のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 閾値名称を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param thresholdName
   *          閾値名称
   */
  public void setThresholdName(String thresholdName) {
    this.thresholdName = thresholdName;
  }

  /**
   * 表示順のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 表示順を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 表示順
   */
  public Short getDisplayOrder() {
    return displayOrder;
  }

  /**
   * 表示順のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 表示順を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param displayOrder
   *          表示順
   */
  public void setDisplayOrder(Short displayOrder) {
    this.displayOrder = displayOrder;
  }

}
