package jp.co.unisys.enability.cis.business.rk.model;

import java.util.Date;
import java.util.List;

/**
 * 料金メニュー検索APIの、料金メニュー検索条件を保持するビジネスクラス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_SearchRateMenuRateMenuConditionsBusinessBean {

  /**
   * 売買区分コードを保有する。
   */
  private String saleCategoryCode;

  /**
   * 基準日_自を保有する。
   */
  private Date baseDateStart;

  /**
   * 基準日_至を保有する。
   */
  private Date baseDateEnd;

  /**
   * エリアコードを保有する。
   */
  private String areaCode;

  /**
   * 提供モデルコードを保有する。
   */
  private String provideModelCode;

  /**
   * 提供モデル企業コードを保有する。
   */
  private String provideModelCompanyCode;

  /**
   * 料金メニューエリアリストを保有する。
   */
  private List<RK_SearchRateMenuRateMenuAreaBusinessBean> rateMenuAreaList;

  /**
   * リターンコードを保有する。
   */
  private String returnCode;

  /**
   * メッセージを保有する。
   */
  private String message;

  /**
   * 電圧区分コードを保有する。
   */
  private String voltageCatCode;

  /**
   * 契約電力決定区分コードを保有する。
   */
  private String ccDecisionCategoryCode;

  /**
   * 売買区分コードのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 売買区分コードを取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 売買区分コード
   */
  public String getSaleCategoryCode() {
    return this.saleCategoryCode;
  }

  /**
   * 売買区分コードのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 売買区分コードを設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param saleCategoryCode
   *          売買区分コード
   */
  public void setSaleCategoryCode(String saleCategoryCode) {
    this.saleCategoryCode = saleCategoryCode;
  }

  /**
   * 基準日_自のgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 基準日_自を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 基準日_自
   */
  public Date getBaseDateStart() {
    return this.baseDateStart;
  }

  /**
   * 基準日_自のsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 基準日_自を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param baseDateStart
   *          基準日_自
   */
  public void setBaseDateStart(Date baseDateStart) {
    this.baseDateStart = baseDateStart;
  }

  /**
   * 基準日_至のgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 基準日_至を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 基準日_至
   */
  public Date getBaseDateEnd() {
    return this.baseDateEnd;
  }

  /**
   * 基準日_至のsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 基準日_至を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param baseDateEnd
   *          基準日_至
   */
  public void setBaseDateEnd(Date baseDateEnd) {
    this.baseDateEnd = baseDateEnd;
  }

  /**
   * エリアコードのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * エリアコードを取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return エリアコード
   */
  public String getAreaCode() {
    return this.areaCode;
  }

  /**
   * エリアコードのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * エリアコードを設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param areaCode
   *          エリアコード
   */
  public void setAreaCode(String areaCode) {
    this.areaCode = areaCode;
  }

  /**
   * 提供モデルコードのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 提供モデルコードを取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 提供モデルコード
   */
  public String getProvideModelCode() {
    return this.provideModelCode;
  }

  /**
   * 提供モデルコードのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 提供モデルコードを設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param provideModelCode
   *          提供モデルコード
   */
  public void setProvideModelCode(String provideModelCode) {
    this.provideModelCode = provideModelCode;
  }

  /**
   * 提供モデル企業コードのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 提供モデル企業コードを取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 提供モデル企業コード
   */
  public String getProvideModelCompanyCode() {
    return this.provideModelCompanyCode;
  }

  /**
   * 提供モデル企業コードのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 提供モデル企業コードを設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param provideModelCompanyCode
   *          提供モデル企業コード
   */
  public void setProvideModelCompanyCode(String provideModelCompanyCode) {
    this.provideModelCompanyCode = provideModelCompanyCode;
  }

  /**
   * 料金メニューエリアリストのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 料金メニューエリアリストを取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 料金メニューエリアリスト
   */
  public List<RK_SearchRateMenuRateMenuAreaBusinessBean> getRateMenuAreaList() {
    return this.rateMenuAreaList;
  }

  /**
   * 料金メニューエリアリストのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 料金メニューエリアリストを設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param rateMenuAreaList
   *          料金メニューエリアリスト
   */
  public void setRateMenuAreaList(List<RK_SearchRateMenuRateMenuAreaBusinessBean> rateMenuAreaList) {
    this.rateMenuAreaList = rateMenuAreaList;
  }

  /**
   * リターンコードのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * リターンコードを取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return リターンコード
   */
  public String getReturnCode() {
    return this.returnCode;
  }

  /**
   * リターンコードのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * リターンコードを設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param returnCode
   *          リターンコード
   */
  public void setReturnCode(String returnCode) {
    this.returnCode = returnCode;
  }

  /**
   * メッセージのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * メッセージを取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return メッセージ
   */
  public String getMessage() {
    return this.message;
  }

  /**
   * メッセージのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * メッセージを設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param message
   *          メッセージ
   */
  public void setMessage(String message) {
    this.message = message;
  }

  /**
   * 電圧区分コードのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 電圧区分コードを取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 電圧区分コード
   */
  public String getVoltageCatCode() {
    return voltageCatCode;
  }

  /**
   * 電圧区分コードのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 電圧区分コードを設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param voltageCatCode
   *          電圧区分コード
   */
  public void setVoltageCatCode(String voltageCatCode) {
    this.voltageCatCode = voltageCatCode;
  }

  /**
   * 契約電力決定区分コードのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 契約電力決定区分コードを取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 契約電力決定区分コード
   */
  public String getCcDecisionCategoryCode() {
    return ccDecisionCategoryCode;
  }

  /**
   * 契約電力決定区分コードのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 契約電力決定区分コードを設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param ccDecisionCategoryCode
   *          契約電力決定区分コード
   */
  public void setCcDecisionCategoryCode(String ccDecisionCategoryCode) {
    this.ccDecisionCategoryCode = ccDecisionCategoryCode;
  }

}
