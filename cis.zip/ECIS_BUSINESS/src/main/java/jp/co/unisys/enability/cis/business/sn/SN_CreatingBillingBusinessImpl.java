package jp.co.unisys.enability.cis.business.sn;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.stream.Collectors;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.ConvertUtils;
import org.apache.commons.beanutils.converters.IntegerConverter;
import org.apache.commons.beanutils.converters.SqlTimestampConverter;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.config.PropertiesFactoryBean;
import org.springframework.context.MessageSource;

import jp.co.unisys.enability.cis.business.common.DateBusiness;
import jp.co.unisys.enability.cis.business.common.MailManagementBusiness;
import jp.co.unisys.enability.cis.business.common.TodoBusiness;
import jp.co.unisys.enability.cis.business.common.model.MailManagementBusinessBean;
import jp.co.unisys.enability.cis.business.common.model.TodoBusinessBean;
import jp.co.unisys.enability.cis.business.gk.CalendarBusiness;
import jp.co.unisys.enability.cis.business.gk.GK_WorkCommonBusiness;
import jp.co.unisys.enability.cis.business.gk.model.CalendarBusinessBean;
import jp.co.unisys.enability.cis.business.sn.model.SN_BlCODetailInfoBusinessBean;
import jp.co.unisys.enability.cis.common.Exception.SystemException;
import jp.co.unisys.enability.cis.common.util.DateCalculateUtil;
import jp.co.unisys.enability.cis.common.util.EMSConstants;
import jp.co.unisys.enability.cis.common.util.StringConvertUtil;
import jp.co.unisys.enability.cis.common.util.ThreadContext;
import jp.co.unisys.enability.cis.common.util.constants.ECISCodeConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISReturnCodeConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISSNConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISTodoConstants;
import jp.co.unisys.enability.cis.entity.common.Bl;
import jp.co.unisys.enability.cis.entity.common.Contract;
import jp.co.unisys.enability.cis.entity.common.ContractExample;
import jp.co.unisys.enability.cis.entity.common.Contractor;
import jp.co.unisys.enability.cis.entity.common.Dpr;
import jp.co.unisys.enability.cis.entity.common.DprExample;
import jp.co.unisys.enability.cis.entity.common.Fcr;
import jp.co.unisys.enability.cis.entity.common.FixChargeBlLinkage;
import jp.co.unisys.enability.cis.entity.common.FixChargeBlLinkageExample;
import jp.co.unisys.enability.cis.entity.common.Payment;
import jp.co.unisys.enability.cis.entity.common.WorkScheduleMngM;
import jp.co.unisys.enability.cis.entity.common.WorkScheduleMngMExample;
import jp.co.unisys.enability.cis.entity.sn.SN_BankInfoEntityBean;
import jp.co.unisys.enability.cis.entity.sn.SN_BillingFixChargeResultBillingLinkageBean;
import jp.co.unisys.enability.cis.entity.sn.SN_BillingInfoEntityBean;
import jp.co.unisys.enability.cis.entity.sn.SN_CreatingBillingTargetEntityBean;
import jp.co.unisys.enability.cis.entity.sn.SN_NextMonthBillableEntityBean;
import jp.co.unisys.enability.cis.mapper.common.BlMapper;
import jp.co.unisys.enability.cis.mapper.common.ContractMapper;
import jp.co.unisys.enability.cis.mapper.common.ContractorMapper;
import jp.co.unisys.enability.cis.mapper.common.DprMapper;
import jp.co.unisys.enability.cis.mapper.common.FcrMapper;
import jp.co.unisys.enability.cis.mapper.common.FixChargeBlLinkageMapper;
import jp.co.unisys.enability.cis.mapper.common.PaymentMapper;
import jp.co.unisys.enability.cis.mapper.common.WorkScheduleMngMMapper;
import jp.co.unisys.enability.cis.mapper.gk.GK_WorkCommonMapper;
import jp.co.unisys.enability.cis.mapper.sn.SN_BillingCommonMapper;
import jp.co.unisys.enability.cis.mapper.sn.SN_CreatingBillingCommonMapper;
import jp.co.unisys.enability.cis.mapper.sn.SN_CreatingBillingRequestFileMapper;

/**
 * 請求入金共通請求作成ビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class SN_CreatingBillingBusinessImpl implements
    SN_CreatingBillingBusiness {

  /** システム日時 */
  private Timestamp systime;
  /** 機能ID */
  private String funcId;
  /** 更新モジュールコード */
  private String updateModuleCode;
  /** 《請求EntityBean》 */
  private Bl bl;
  /** バッチ処理基準日 */
  private Date mBatchDate;
  /** 支払方法コード */
  private String mPaymentWayCode;
  /** 計上年月日 */
  private Date mRecordedDate;
  /** 支払ID */
  private Integer mPaymentId;
  /** 業務共通ビジネス(DI) */
  private GK_WorkCommonBusiness gkWorkCommonBusiness;
  /** 請求入金共通請求作成ビジネス(DI) */
  private SN_CreatingBillingCommonBusiness snCreatingBillingCommonBusiness;
  /** 請求入金共通ビジネス(DI) */
  private SN_BillingCommonBusiness snBillingCommonBusiness;
  /** 日付関連機能(DI) */
  private DateBusiness dateBusiness;
  /** カレンダー関連機能共通処理(DI) */
  private CalendarBusiness calendarBusiness;
  /** Todo共通ビジネス(DI) */
  private TodoBusiness todoBusiness;
  /** 請求入金請求作成共通マッパー(DI) */
  private SN_CreatingBillingCommonMapper snCreatingBillingCommonMapper;
  /** 請求入金共通マッパー(DI) */
  private SN_BillingCommonMapper snBillingCommonMapper;
  /** 業務共通共通マッパー(DI) */
  private GK_WorkCommonMapper gkWorkCommonMapper;
  /** 請求(DI) */
  private BlMapper blMapper;
  /** 確定料金実績(DI) */
  private FcrMapper fcrMapper;
  /** 確定料金・請求連携(DI) */
  private FixChargeBlLinkageMapper fixChargeBlLinkageMapper;
  /** 預り金等(DI) */
  private DprMapper dprMapper;
  /** 契約(DI) */
  private ContractMapper contractMapper;
  /** 支払(DI) */
  private PaymentMapper paymentMapper;
  /** 業務日程管理マスタ(DI) */
  private WorkScheduleMngMMapper workScheduleMngMMapper;
  /** メッセージプロパティ(DI) */
  private MessageSource messageSource;
  /** プロパティ定義クラス(DI) */
  private PropertiesFactoryBean applicationProperties;
  /** 契約者マッパー(DI) */
  private ContractorMapper contractorMapper;
  /** メール管理共通ビジネス(DI) */
  private MailManagementBusiness mailManagementBusiness;
  /** 請求依頼ファイル作成マッパー(DI) */
  private SN_CreatingBillingRequestFileMapper snCreatingBillingRequestFileMapper;

  /** プロパティファイル取得キー：#メッセージ用文字列：営業日取得 */
  private static final String LOG_STR_BUSINESS_DAY_GET = "message.str.business.day.get";

  /** プロパティファイル取得キー：複数月まとめ請求有無 */
  private static final String MULTI_MON_SUMMARIZE_BL_EXIST = "multiple.months.summarize.billing.existence";

  /** プロパティファイル取得キー：複数月まとめ請求最大月数 */
  private static final String MULTI_MON_SUMMARIZE_BL_MAX_MON = "multiple.months.summarize.billing.max.months";

  /** プロパティファイル取得キー：複数月まとめ請求額閾値 */
  private static final String MULTI_MON_SUM_BL_BL_T = "multiple.months.summarize.billing.billing.threshold";

  /** プロパティファイル取得キー：複数月まとめ送金額閾値 */
  private static final String MULTI_MON_SUM_BL_RE_T = "multiple.months.summarize.billing.remittance.threshold";

  /** プロパティファイル取得キー：繰越メール送信有無 */
  private static final String BL_CO_NOTICE_MAIL_SEND_EXIST = "billing.carryover.notice.mail.send.existence";

  /** プロパティファイル取得キー：メールテンプレートファイルパス */
  private static final String MAIL_TMPLATE_FILE_DIR = "business.sn.mail.dir";

  /** プロパティファイル取得キー：メール件名テンプレートファイル名 */
  private static final String MAIL_SUBJECT_TMPLATE_FILE_NAME = "business.sn.mailsubject.tmplate.filename.bl.carry.forward";

  /** プロパティファイル取得キー：メール本文テンプレートファイル名 */
  private static final String MAIL_BODY_TMPLATE_FILE_NAME = "business.sn.mailbody.tmplate.filename.bl.carry.forward";

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.sn.SN_CreatingBillingBusiness
   * #createBilling(Map<Integer,
   * jp.co.unisys.enability.cis.entity.sn.SN_CreatingBillingTargetEntityBean>,
   * String, String)
   */
  @Override
  public void createBilling(
      Map<Integer, SN_CreatingBillingTargetEntityBean> map,
      String batchDate, String paymentWayCode, boolean multipleMcBlFlag) {

    // Map<契約ID, 《請求作成対象候補EntityBean》リスト>
    Map<Integer, List<SN_CreatingBillingTargetEntityBean>> targetMap = new LinkedHashMap<>();
    // 契約ID
    Integer cntractId = Integer.valueOf(0);
    // 利用年月
    String usePeriod = null;
    // 前月請求合算フラグ
    String previousBlAddUpFlag = null;
    // 支払期限個別設定フラグ
    String peIndividualSettingFlag = null;
    // 支払期限加算月数
    Integer peAddMonths = null;
    // 支払期限日
    Integer peDate = null;

    try {
      // ■オブジェクト生成
      // 引数.Map<契約ID, 《請求作成対象候補EntityBean》>をMap<契約ID,
      // 《請求作成対象候補EntityBean》リスト>に設定する。
      for (Map.Entry<Integer, SN_CreatingBillingTargetEntityBean> entry : map.entrySet()) {
        // Map<契約ID, 《請求作成対象候補EntityBean》リスト>に設定
        List<SN_CreatingBillingTargetEntityBean> list = new ArrayList<>();
        list.add(entry.getValue());
        targetMap.put(entry.getKey(), list);

        // 契約IDを設定（メッセージ用）
        cntractId = entry.getValue().getContractId();
        // 利用年月を設定
        usePeriod = entry.getValue().getUsePeriod();
        // 支払IDを設定
        this.mPaymentId = entry.getValue().getPaymentId();
        // 前月請求合算フラグを設定
        previousBlAddUpFlag = entry.getValue().getPreviousBlAddUpFlag();
        // 支払期限個別設定フラグを設定
        peIndividualSettingFlag = entry.getValue().getPeIndividualSettingFlag();
        // 支払期限加算月数を設定
        peAddMonths = entry.getValue().getPeAddMonths();
        // 支払期限日を設定
        peDate = entry.getValue().getPeDate();
      }

      // 支払方法コードを設定
      this.mPaymentWayCode = paymentWayCode;
      // バッチ処理基準日をDate型に変換して設定
      this.mBatchDate = StringConvertUtil.stringToDate(batchDate,
          EMSConstants.FORMAT_DATE_yyyyMMdd);
      // システム日時の取得
      Date sysDate = new Date();
      this.systime = new Timestamp(sysDate.getTime());
      // 機能ID
      this.funcId = ECISTodoConstants.TODO_FUNCTION_ID.SN0101.toString();
      // 更新モジュールコード
      this.updateModuleCode = ThreadContext.getRequestThreadContext()
          .get(ECISConstants.CLASS_NAME_KEY).toString();
      // 請求EntityBean初期化
      this.bl = new Bl();
      this.initBilling();

      // ■計上年月日の取得
      this.mRecordedDate = gkWorkCommonBusiness.getRecordedDate(
          this.mBatchDate, this.mBatchDate);

      if (ECISConstants.FLG_ON.equals(previousBlAddUpFlag)) {
        // 前月請求合算フラグがON（合算要）である場合に以下を実施する。
        // ■契約単位の金額合算処理
        for (Map.Entry<Integer, SN_CreatingBillingTargetEntityBean> entry : map.entrySet()) {
          List<SN_CreatingBillingTargetEntityBean> addingTargetList = this.addUpContract(
              entry.getValue().getContractId(), entry.getValue().getUsePeriod());

          // 合算対象が取得できた場合、マップにリストをマージする。
          List<SN_CreatingBillingTargetEntityBean> list = new ArrayList<>();
          list.addAll(targetMap.get(entry.getKey()));
          if (CollectionUtils.isNotEmpty(addingTargetList)) {
            // リストに合算対象リストを設定
            list.addAll(addingTargetList);
            // マップにリストをマージする。
            targetMap.put(entry.getKey(), list);
            // 合算請求フラグを《請求EntityBean》に設定する。
            this.bl.setAddUpBlFlag(ECISConstants.FLG_ON);
          }
        }
      }

      // プロパティ
      Properties prop = null;
      try {
        // プロパティを取得する。
        prop = applicationProperties.getObject();
      } catch (IOException e) {
        // コード定義プロパティから取得できない場合、システムエラーをスローする。
        SystemException se = new SystemException(
            messageSource.getMessage("error.E1278", null, Locale.getDefault()), e);
        throw se;
      }

      if (ECISConstants.FLG_ON.equals(prop.getProperty(MULTI_MON_SUMMARIZE_BL_EXIST))) {
        // 複数月まとめ請求有無が有である場合に以下を実施する。

        for (Map.Entry<Integer, SN_CreatingBillingTargetEntityBean> entry : map.entrySet()) {
          List<SN_CreatingBillingTargetEntityBean> addingTargetList = this.selectMultipleMonthsSummarizeBilling(
              entry.getValue().getContractId(), entry.getValue().getUsePeriod());
          // 複数月まとめ請求対象が取得できた場合、マップにリストをマージする。
          List<SN_CreatingBillingTargetEntityBean> list = new ArrayList<>();
          list.addAll(targetMap.get(entry.getKey()));
          if (CollectionUtils.isNotEmpty(addingTargetList)) {
            // 複数月まとめ請求対象リストを設定
            list.addAll(addingTargetList);
            // マップにリストをマージする。
            targetMap.put(entry.getKey(), list);
          }
        }

        if (multipleMcBlFlag) {
          //まとめ請求の場合

          //複数月まとめ請求対象(廃止契約用)取得
          List<SN_CreatingBillingTargetEntityBean> addingTargetListAM = this.selectMultipleMonthsSummarizeBillingAM(
              mPaymentId, usePeriod);
          if (CollectionUtils.isNotEmpty(addingTargetListAM)) {
            for (SN_CreatingBillingTargetEntityBean bean : addingTargetListAM) {
              List<SN_CreatingBillingTargetEntityBean> list = new ArrayList<>();
              if (targetMap.get(bean.getContractId()) != null) {
                list.addAll(targetMap.get(bean.getContractId()));
              }
              // 複数月まとめ請求対象(廃止契約用)リストを設定
              list.add(bean);
              // マップにリストをマージする。
              targetMap.put(bean.getContractId(), list);
            }
          }
        }
      }

      // ■【確定料金実績】の取得
      List<Fcr> fcrList = new ArrayList<>();
      for (Map.Entry<Integer, List<SN_CreatingBillingTargetEntityBean>> entry : targetMap.entrySet()) {
        // リスト分、以下の処理を繰り返す。
        for (SN_CreatingBillingTargetEntityBean bean : entry.getValue()) {
          // 【確定料金実績】の取得
          Fcr fcr = fcrMapper.selectByPrimaryKey(bean.getFixChargeResultId());
          fcrList.add(fcr);
        }
      }

      //月額料金料金と繰越金合計算出処理
      BigDecimal totalMonAndCarryOverCharge = snCreatingBillingCommonBusiness
          .calculationMonthlyCharge(fcrList);

      //繰越判定処理
      boolean carryOverFlag = this.isCarryOver(fcrList, bl, mPaymentId, totalMonAndCarryOverCharge.longValue(),
          prop);

      // ■請求金額等の算出
      // 請求金額等の算出を呼び出す
      if (StringUtils.equals(bl.getAddUpBlFlag(), ECISConstants.FLG_ON)) {
        this.calculationBillingAmount(fcrList);
      } else {
        this.calculationBillingAmountForMMSumBl(fcrList, carryOverFlag, totalMonAndCarryOverCharge);
      }

      // ■支払方法の判定
      this.paymentDecision(fcrList.get(0).getContractorId());

      // ■支払期日の決定
      if (ECISConstants.FLG_ON.equals(peIndividualSettingFlag)) {
        this.bl.setPfd(this.calcPfd(usePeriod, peAddMonths, peDate));
      } else {
        this.getPaymentFixedDate(this.mPaymentId, usePeriod);
      }
      // ■請求の作成
      // 《確定料金実績EntityBean》リスト分、以下の処理を繰り返し実施する。
      for (Fcr bean : fcrList) {
        // 確定料金・請求連携登録処理を呼び出す。
        this.insertFixChargeBillingLinkage(bean.getFcrId(), carryOverFlag);
      }

      // 【請求】の登録
      // 引数.Map<契約ID>が複数ある場合
      if (map.size() > 1) {
        this.bl.setCombinedBlFlag(ECISConstants.FLG_ON);
      }
      this.insertBillingForMultipleMonSummarizeBilling(fcrList, carryOverFlag, prop);

      // 【ToDo】の登録
      // 解約（破産）の契約番号取得処理を呼び出す。
      List<String> constractorList = this
          .getBankruptcyContractNoList(fcrList);

      // 「契約番号リスト」が空でない場合
      if (CollectionUtils.isNotEmpty(constractorList)) {
        // TODO登録処理を呼び出す。
        this.insertTodo(constractorList);
      }

    } catch (SystemException e) {
      // 例外をそのままスローする。
      throw e;

    } catch (Exception e) {
      // ■異常終了ログ出力
      SystemException se = new SystemException(
          messageSource.getMessage("error.E1166", new String[] {
              this.funcId, cntractId.toString() }, Locale.getDefault()),
          e);
      throw se;
    }
  }

  /**
   * 契約単位の金額合算処理。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 前月以前の確定料金実績に未収が存在するかチェックし、
   * 存在する場合は合算対象無効化および充当予約済の預り金の無効化を行う。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractId
   *          契約ID
   * @param usePeriod
   *          利用年月
   * @return 《請求作成対象候補EntityBean(合算対象)》リスト
   */
  private List<SN_CreatingBillingTargetEntityBean> addUpContract(
      Integer contractId, String usePeriod) {

    // ■「請求作成対象」の【契約】の前月以前の【確定料金実績】に”未収”が存在するかをチェックする。
    Map<String, Object> exampleMap = new HashMap<String, Object>();
    exampleMap.put("contractId", contractId);
    exampleMap.put("usePeriod", usePeriod);
    exampleMap.put("csCode", ECISCodeConstants.CHARGE_STATUS_CODE_FIX);
    exampleMap.put("completedFlag", ECISConstants.FLG_OFF);
    exampleMap.put("addUpNeedFlag", ECISConstants.FLG_ON);
    exampleMap.put("invalidFlag", ECISConstants.FLG_OFF);

    List<SN_CreatingBillingTargetEntityBean> beanList = snCreatingBillingCommonMapper
        .selectAccrued(exampleMap);

    // ■《請求作成対象候補EntityBean(合算対象)》リスト分、以下の処理を繰り返す。
    for (SN_CreatingBillingTargetEntityBean bean : beanList) {
      // 合算対象無効化更新
      this.updateInvalidationAddUpTarget(bean.getBillingId(),
          bean.getFixChargeResultId());

      // 充当予約済の預り金の無効化
      this.invalidationDepositsReceived(bean.getBillingNo());
    }

    // ■《請求作成対象候補EntityBean(合算対象)》リストを設定して返却する。
    return beanList;

  }

  /**
   * 契約単位の複数月まとめ請求処理
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約単位で複数月まとめ請求を行っているか、チェックし
   * 存在する場合は複数月まとめ対象無効化および請求の無効化を行う。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractId
   *          契約ID
   * @param usePeriod
   *          利用年月
   * @return 《請求作成対象候補EntityBean》リスト
   */
  private List<SN_CreatingBillingTargetEntityBean> selectMultipleMonthsSummarizeBilling(
      Integer contractId, String usePeriod) {

    // ■「請求作成対象」の【契約】の前月以前の【確定料金実績】に繰越が存在するかをチェックする。
    Map<String, Object> exampleMap = new HashMap<String, Object>();
    exampleMap.put("contractId", contractId);
    exampleMap.put("usePeriod", usePeriod);
    exampleMap.put("csCode", ECISCodeConstants.CHARGE_STATUS_CODE_FIX);
    exampleMap.put("completedFlag", ECISConstants.FLG_OFF);
    exampleMap.put("smallBlTransFlag", ECISConstants.FLG_ON);
    exampleMap.put("invalidFlag", ECISConstants.FLG_OFF);

    List<SN_CreatingBillingTargetEntityBean> beanList = snCreatingBillingCommonMapper
        .selectMultipleMonthsSummarizeBilling(exampleMap);

    // ■《請求作成対象候補EntityBean》リスト分、以下の処理を繰り返す。
    for (SN_CreatingBillingTargetEntityBean bean : beanList) {
      // 合算対象無効化更新
      this.updateInvalidationAddUpTarget(bean.getBillingId(),
          bean.getFixChargeResultId());
    }

    // ■《請求作成対象候補EntityBean》リストを設定して返却する。
    return beanList;

  }

  /**
   * 複数月まとめ対象情報取得処理(廃止契約用)
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 廃止契約において複数月まとめ請求を行っているか、チェックし
   * 存在する場合は複数月まとめ対象の無効化および請求の無効化を行う。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param paymentId
   *          支払ID
   * @return 《請求作成対象候補EntityBean》リスト
   */
  private List<SN_CreatingBillingTargetEntityBean> selectMultipleMonthsSummarizeBillingAM(
      Integer paymentId, String usePeriod) {

    // ■「請求作成対象」と同じ支払IDの契約廃止分の【確定料金実績】に繰越が存在するかをチェックする。
    Map<String, Object> exampleMap = new HashMap<String, Object>();
    exampleMap.put("paymentId", paymentId);
    exampleMap.put("usePeriod", usePeriod);
    exampleMap.put("csCode", ECISCodeConstants.CHARGE_STATUS_CODE_FIX);
    exampleMap.put("completedFlag", ECISConstants.FLG_OFF);
    exampleMap.put("smallBlTransFlag", ECISConstants.FLG_ON);
    exampleMap.put("invalidFlag", ECISConstants.FLG_OFF);

    List<SN_CreatingBillingTargetEntityBean> beanList = snCreatingBillingCommonMapper
        .selectMultipleMonthsSummarizeBillingAM(exampleMap);

    // ■《請求作成対象候補EntityBean》リスト分、以下の処理を繰り返す。
    for (SN_CreatingBillingTargetEntityBean bean : beanList) {
      // 合算対象無効化更新
      this.updateInvalidationAddUpTarget(bean.getBillingId(),
          bean.getFixChargeResultId());
    }

    // ■《請求作成対象候補EntityBean》リストを設定して返却する。
    return beanList;

  }

  /**
   * 充当予約済の預り金の無効化。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 充当予約されている【預り金等】を取得し、
   * 【預り金等】の無効化および未充当の【預り金等】を作成する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param blNo
   *          請求番号
   */
  private void invalidationDepositsReceived(String blNo) {

    try {
      // ■”充当予約”されている【預り金等】の取得
      List<Dpr> dprList = this.selectAppropriatedReservation(blNo);

      // ■《預り金等EntityBean》リスト分、以下の処理を繰り返し行う。
      for (Dpr dpr : dprList) {
        // ■”充当予約”されている【預り金等】を”無効”にする。
        this.updateInvalidationDepositsReceived(dpr.getDprId());

        // ■”無効”にした【預り金等】を、”未充当”の【預り金等】として作成する。
        this.insertInvalidationDepositsReceived(dpr);

      }
    } catch (RuntimeException e) {
      // 異常終了ログ出力
      SystemException se = new SystemException(
          messageSource.getMessage("error.E1167", new String[] {
              this.funcId, blNo }, Locale.getDefault()),
          e);
      throw se;
    }

  }

  /**
   * 請求金額等の算出。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 月額料金合計値を算出し、請求ID、請求番号の採番後、預り金充当処理を行う。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param fcrList
   *          《確定料金実績EntityBean》リスト
   * @throws Exception
   *           予期せぬエラーが発生した場合
   */
  private void calculationBillingAmount(List<Fcr> fcrList) throws Exception {

    // ■ 月額料金合計値算出処理
    BigDecimal totalMonthlyCharge = snCreatingBillingCommonBusiness
        .calculationMonthlyCharge(fcrList);
    this.bl.setUseAmount(totalMonthlyCharge.longValue());

    // ■ 請求IDの採番
    // 請求Dao.請求ID採番を呼び出す。
    Map<String, Object> exampleMap = new HashMap<String, Object>();
    exampleMap.put("sqName", ECISConstants.SEQUENCE_NAME_BL_ID);
    Integer blId = gkWorkCommonMapper.selectSequenceId(exampleMap);
    this.bl.setBlId(blId);

    // ■ 請求番号の採番
    String blNo = snBillingCommonBusiness
        .getBillingNumbering(new SimpleDateFormat(
            ECISConstants.FORMAT_DATE_yyyyMMddHHmmssSSS_OutputFormat)
                .format(this.mBatchDate));
    this.bl.setBlNo(blNo);

    if (totalMonthlyCharge.compareTo(BigDecimal.ZERO) == 0) {
      // 充当済の請求EntityBean設定処理を呼び出す。
      this.setBillingAppropriationAlready(0);
      for (Fcr fcr : fcrList) {
        // 【確定料金実績】の更新
        this.updateFixChargeResult(fcr.getFcrId(), false);
      }
    } else {
      // ■ 預り金充当処理
      this.contactAppropriatedDepositsReceived(fcrList, totalMonthlyCharge);
    }
  }

  /**
   * 請求金額等の算出(複数月まとめ請求用)
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 月額料金合計値を算出し、請求ID、請求番号の採番後、預り金充当処理を行う。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param fcrList
   *          《確定料金実績EntityBean》リスト
   * @param carryOverFlag
   *          繰越判定結果
   * @param totalMonAndCarryOverCharge
   *          月額料金と繰越金合計算出処理
   * @throws Exception
   *           予期せぬエラーが発生した場合
   */
  private void calculationBillingAmountForMMSumBl(List<Fcr> fcrList,
      boolean carryOverFlag, BigDecimal totalMonAndCarryOverCharge) throws Exception {

    // ■ 月額料金の設定
    this.bl.setUseAmount(totalMonAndCarryOverCharge.longValue());

    // ■ 請求IDの採番
    // 請求Dao.請求ID採番を呼び出す。
    Map<String, Object> exampleMap = new HashMap<String, Object>();
    exampleMap.put("sqName", ECISConstants.SEQUENCE_NAME_BL_ID);
    Integer blId = gkWorkCommonMapper.selectSequenceId(exampleMap);
    this.bl.setBlId(blId);

    // ■ 請求番号の採番
    String blNo = snBillingCommonBusiness
        .getBillingNumbering(new SimpleDateFormat(
            ECISConstants.FORMAT_DATE_yyyyMMddHHmmssSSS_OutputFormat)
                .format(this.mBatchDate));
    this.bl.setBlNo(blNo);

    if (totalMonAndCarryOverCharge.compareTo(BigDecimal.ZERO) == 0) {
      // 充当済の請求EntityBean設定処理を呼び出す。
      this.setBillingAppropriationAlready(0);
      for (Fcr fcr : fcrList) {
        // 【確定料金実績】の更新
        this.updateFixChargeResult(fcr.getFcrId(), false);
      }
    } else {
      if (carryOverFlag) {
        bl.setBlAmount(Long.valueOf(0));
        bl.setTransAmount(totalMonAndCarryOverCharge.longValue());
        bl.setBlStatusCode(ECISCodeConstants.BILLING_STATUS_CODE_CALLY_OVER);
        for (Fcr fcr : fcrList) {
          // 【確定料金実績】の更新
          this.updateFixChargeResult(fcr.getFcrId(), true);
        }
      } else {
        // ■ 預り金充当処理
        this.contactAppropriatedDepositsReceived(fcrList, totalMonAndCarryOverCharge);
      }

    }
  }

  /**
   * 預り金の取得および充当処理。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 未充当の【預り金等】を取得し、取得できた場合は
   * 預り金充当処理、【確定料金実績】の更新を行う。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param fcrList《確定料金実績EntityBean》リスト
   * @param totalMonthlyCharge
   *          月額料金合計
   * @throws Exception
   *           予期せぬエラーが発生した場合
   */
  private void contactAppropriatedDepositsReceived(List<Fcr> fcrList,
      BigDecimal totalMonthlyCharge) throws Exception {

    // ■ ”未充当”の【預り金等】の取得
    List<Dpr> dprList = this.selectAppropriatedNotYet(fcrList.get(0)
        .getContractorNo());

    // ■《預り金等EntityBean》リストが空の場合
    if (CollectionUtils.isEmpty(dprList)) {
      // 請求額、請求ステータスコードを《請求EntityBean》に設定する。
      this.bl.setBlAmount(totalMonthlyCharge.longValue());
      this.bl.setBlStatusCode(ECISCodeConstants.BILLING_STATUS_CODE_BILLING);

    } else {
      // 預り金充当処理を呼び出す。
      this.appropriatedDepositsReceived(dprList, totalMonthlyCharge);
    }

    // 引数.《確定料金実績EntityBean》リスト分、以下の処理を繰り返し実施する。
    for (Fcr fcr : fcrList) {
      // 【確定料金実績】の更新
      this.updateFixChargeResult(fcr.getFcrId(), false);
    }
  }

  /**
   * 預り金充当処理。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 預り金等金額の合計値を算出し、引数の月額料金合計と比較する。
   * 引数.月額料金合計 ＞ 「預り金等金額合計」 の場合、
   * 未充当の【預り金等】を充当予約に更新する。
   * 引数.月額料金合計 ＝ 「預り金等金額合計」 の場合、
   * 未充当の【預り金等】を充当済に更新する。
   * 引数.月額料金合計 ＜ 「預り金等金額合計」 の場合、
   * 預り金充当処理（預り金額の超過）を呼び出す。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param dprList《預り金等EntityBean》リスト
   * @param totalMonthlyCharge
   *          月額料金合計
   * @throws Exception
   *           予期せぬエラーが発生した場合
   */
  private void appropriatedDepositsReceived(List<Dpr> dprList,
      BigDecimal totalMonthlyCharge) throws Exception {

    // ■ 預り金等金額の合計値算出
    BigDecimal totalDepositsReceivedCharge = BigDecimal.ZERO;
    for (Dpr dpr : dprList) {
      totalDepositsReceivedCharge = totalDepositsReceivedCharge
          .add(BigDecimal.valueOf(dpr.getAmount()));
    }

    // ■ 引数.月額料金合計 ＞ 「預り金等金額合計」 の場合
    if (totalMonthlyCharge.compareTo(totalDepositsReceivedCharge) > 0) {

      // 《預り金等EntityBean》リスト分、以下の処理を繰り返す。
      for (Dpr dpr : dprList) {
        // 預り金等情報更新処理（充当予約更新）を呼び出す。
        this.updateAppropriatedReservation(dpr.getDprId());
      }
      // 請求額、請求ステータスコードを《請求EntityBean》に設定する。
      this.bl.setBlAmount(totalMonthlyCharge.subtract(
          totalDepositsReceivedCharge).longValue());
      this.bl.setBlStatusCode(ECISCodeConstants.BILLING_STATUS_CODE_BILLING);

      // ■ 引数.月額料金合計 ＝ 「預り金等金額合計」 の場合
    } else if (totalMonthlyCharge.compareTo(totalDepositsReceivedCharge) == 0) {

      // 《預り金等EntityBean》リスト分、以下の処理を繰り返す。
      for (Dpr dpr : dprList) {
        // 預り金等情報更新処理（充当済更新）を呼び出す。
        this.updateAppropriatedSettled(dpr.getDprId());
      }
      // 充当済の請求EntityBean設定処理を呼び出す。
      this.setBillingAppropriationAlready(dprList.size());

      // ■ 引数.月額料金合計 ＜ 「預り金等金額合計」 の場合
    } else if (totalMonthlyCharge.compareTo(totalDepositsReceivedCharge) < 0) {

      // 預り金充当処理（預り金額の超過）を呼び出す。
      this.appropriatedDeposits(dprList, totalMonthlyCharge);
      // 充当済の請求EntityBean設定処理を呼び出す。
      this.setBillingAppropriationAlready(dprList.size());
    }

  }

  /**
   * 預り金充当処理（預り金額の超過）。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 未充当の【預り金等】を順番に預り金等金額の合計し、
   * 月額料金合計を超えるまで【預り金等】を充当済に更新する。
   * 超えた分は預り金等無効化および預り金消し込み処理を行う。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param dprList《預り金等EntityBean》リスト
   * @param totalMonthlyCharge
   *          月額料金合計
   * @throws Exception
   *           予期せぬエラーが発生した場合
   */
  private void appropriatedDeposits(List<Dpr> dprList,
      BigDecimal totalMonthlyCharge) throws Exception {

    // ■ 《預り金等EntityBean》リスト分、以下の処理を繰り返す。
    BigDecimal totalDepositsReceivedCharge = BigDecimal.ZERO;
    for (Dpr dpr : dprList) {
      totalDepositsReceivedCharge = totalDepositsReceivedCharge
          .add(BigDecimal.valueOf(dpr.getAmount()));

      // 引数.月額料金合計 ＞ 「合算した預り金等合計値」 の場合
      if (totalMonthlyCharge.compareTo(totalDepositsReceivedCharge) > 0) {

        // 預り金等情報更新処理（充当済更新）を呼び出す。
        this.updateAppropriatedSettled(dpr.getDprId());

        // 引数.月額料金合計 ＝ 「合算した預り金等合計値」 の場合
      } else if (totalMonthlyCharge
          .compareTo(totalDepositsReceivedCharge) == 0) {

        // 預り金等情報更新処理（充当済更新）を呼び出す。
        this.updateAppropriatedSettled(dpr.getDprId());

        // 処理を終了する。
        return;

        // 引数.月額料金合計 ＜ 「合算した預り金等合計値」 の場合
      } else if (totalMonthlyCharge
          .compareTo(totalDepositsReceivedCharge) < 0) {

        // 預り金等情報更新処理（預り金等無効化）を呼び出す。
        this.updateInvalidationDepositsReceived(dpr.getDprId());

        // 預り金消し込み処理を呼び出す。
        this.reconcileDeposits(dpr, totalMonthlyCharge,
            totalDepositsReceivedCharge);

        // 処理を終了する。
        return;
      }
    }
  }

  /**
   * 預り金消し込み処理。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 月額料金の合計値分、【預り金等】を充当済に登録する。
   * 超過分の【預り金等】を”未充当”で作成する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param dpr
   *          《預り金等EntityBean》
   * @param totalMonthlyCharge
   *          月額料金合計
   * @param totalDepositsReceivedCharge
   *          預り金等合計
   * @throws Exception
   *           予期せぬエラーが発生した場合
   */
  private void reconcileDeposits(Dpr dpr, BigDecimal totalMonthlyCharge,
      BigDecimal totalDepositsReceivedCharge) throws Exception {

    // ■ 【確定料金実績】．月額料金の合計値分の【預り金等】を消し込む。
    Dpr reconcileBean = new Dpr();
    ConvertUtils.register(new IntegerConverter(null), Integer.class);
    ConvertUtils.register(new SqlTimestampConverter(null), Timestamp.class);
    BeanUtils.copyProperties(reconcileBean, dpr);
    // 預り金等IDの採番
    Map<String, Object> reconcileExampleMap = new HashMap<String, Object>();
    reconcileExampleMap.put("sqName", ECISConstants.SEQUENCE_NAME_DPR_ID);
    Integer reconcileDprId = gkWorkCommonMapper.selectSequenceId(reconcileExampleMap);
    reconcileBean.setDprId(reconcileDprId);

    // 預り金等ステータスコード
    reconcileBean
        .setDprStatusCode(ECISCodeConstants.DEPOSITS_RECEIVED_STATUS_CODE_APPROPRIATION);
    // 預り金等発生契機区分コード
    reconcileBean
        .setDprAoSegmentCode(ECISCodeConstants.DEPOSITS_RECEIVED_AO_SEGMENT_CODE_APPROPRIATED);
    // 金額
    reconcileBean.setAmount(BigDecimal
        .valueOf(dpr.getAmount())
        .subtract(
            totalDepositsReceivedCharge
                .subtract(totalMonthlyCharge))
        .longValue());
    // 預り金等消込計上日
    reconcileBean.setDprRccRecordedDate(this.mRecordedDate);
    // 預り金等消込基準日
    reconcileBean.setDprRccBaseDate(this.mBatchDate);
    // 預り金等消込処理日
    reconcileBean.setDprRccExecuteDate(this.mBatchDate);
    // 充当先請求番号
    reconcileBean.setAppropriatedBlNo(this.bl.getBlNo());
    // 預り金等特別消込理由コード
    reconcileBean.setDprSrReasonCode(null);
    // 預り金等振替先科目コード
    reconcileBean.setDprTransferIc(null);
    // 完了フラグ
    reconcileBean.setCompletedFlag(ECISConstants.FLG_ON);
    // 更新回数
    reconcileBean.setUpdateCount(0);
    // 作成日時
    reconcileBean.setCreateTime(this.systime);
    // オンライン更新日時
    reconcileBean.setOnlineUpdateTime(null);
    // オンライン更新ユーザID
    reconcileBean.setOnlineUpdateUserId(null);
    // 更新日時
    reconcileBean.setUpdateTime(this.systime);
    // 更新モジュールコード
    reconcileBean.setUpdateModuleCode(this.updateModuleCode);

    // 預り金等DAO.insertSelectiveを呼び出し、【預り金等】を登録する。
    dprMapper.insertSelective(reconcileBean);

    // ■ 超過分の【預り金等】を”未充当”で作成する。
    Dpr excessBean = new Dpr();
    BeanUtils.copyProperties(excessBean, dpr);
    ConvertUtils.deregister();
    // 預り金等IDの採番
    Map<String, Object> excessExampleMap = new HashMap<String, Object>();
    excessExampleMap.put("sqName", ECISConstants.SEQUENCE_NAME_DPR_ID);
    Integer excessDprId = gkWorkCommonMapper.selectSequenceId(excessExampleMap);
    excessBean.setDprId(excessDprId);

    // 預り金等ステータスコード
    excessBean
        .setDprStatusCode(ECISCodeConstants.DEPOSITS_RECEIVED_STATUS_CODE_NOT_APPROPRIATION);
    // 預り金等発生契機区分コード
    excessBean
        .setDprAoSegmentCode(ECISCodeConstants.DEPOSITS_RECEIVED_AO_SEGMENT_CODE_APPROPRIATED);
    // 金額
    excessBean.setAmount(totalDepositsReceivedCharge.subtract(
        totalMonthlyCharge).longValue());
    // 預り金等消込計上日
    excessBean.setDprRccRecordedDate(null);
    // 預り金等消込基準日
    excessBean.setDprRccBaseDate(null);
    // 預り金等消込処理日
    excessBean.setDprRccExecuteDate(null);
    // 充当先請求番号
    excessBean.setAppropriatedBlNo(null);
    // 預り金等特別消込理由コード
    excessBean.setDprSrReasonCode(null);
    // 預り金等振替先科目コード
    excessBean.setDprTransferIc(null);
    // 完了フラグ
    excessBean.setCompletedFlag(ECISConstants.FLG_OFF);
    // 更新回数
    excessBean.setUpdateCount(0);
    // 作成日時
    excessBean.setCreateTime(this.systime);
    // オンライン更新日時
    excessBean.setOnlineUpdateTime(null);
    // オンライン更新ユーザID
    excessBean.setOnlineUpdateUserId(null);
    // 更新日時
    excessBean.setUpdateTime(this.systime);
    // 更新モジュールコード
    excessBean.setUpdateModuleCode(this.updateModuleCode);

    // 預り金等DAO.insertSelectiveを呼び出し、【預り金等】を登録する。
    dprMapper.insertSelective(excessBean);

  }

  /**
   * 支払方法判定。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 支払方法コードがコンビニ払いで請求額が30万円超または0円の場合、
   * 支払方法コードを振込用請求書に変更する。
   * また、請求額が30万円超の場合は【自社口座管理マスタ】および
   * 【金融機関預金種目マスタ】より、振込先金融機関情報を取得し、
   * 請求EntityBeanに設定する。
   * 支払方法コードが振込用請求書の場合、
   * 【口座クレカ情報】および【自社金融機関マスタ】および【金融機関預金種目マスタ】より
   * 振込先金融機関情報を取得し、請求EntityBeanに設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorId
   *          契約者ID
   */
  private void paymentDecision(Integer contractorId) {

    // ■ コンビニ払い上限金額判定と口座情報の取得
    // 「支払方法コード」がコンビニ払い かつ（請求額 ＞ 30万円 または 請求額 ＝ 0円）の場合
    if (ECISCodeConstants.PAYMENT_WAY_CODE_CONVENI
        .equals(this.mPaymentWayCode)
        && (this.bl.getBlAmount().compareTo(
            ECISSNConstants.CONVENI_BILLING_AMOUNT_UPPER_LIMIT) > 0 || this.bl
                .getBlAmount().equals(Long.valueOf(0)))) {

      // 「支払方法コード」を”振込用請求書”に置き換える。
      this.mPaymentWayCode = ECISCodeConstants.PAYMENT_WAY_CODE_TRANSFER;

      // 【自社口座管理マスタ】および【金融機関預金種目マスタ】より、振込先金融機関情報を取得する。
      Map<String, Object> exampleMap = new HashMap<String, Object>();
      exampleMap.put("batchDate", this.mBatchDate);
      exampleMap.put("blCatCode",
          ECISCodeConstants.BILLING_CATEGORY_CODE_TRANSFER);

      SN_BankInfoEntityBean bankInfoEntityBean = snCreatingBillingCommonMapper
          .selectBankInfoFromMaster(exampleMap);

      // 《請求EntityBean》に《振込先金融機関情報》を設定する。
      // 金融機関コード
      this.bl.setBankCode(bankInfoEntityBean.getBankCode());
      // 金融機関名
      this.bl.setBankName(bankInfoEntityBean.getBankName());
      // 金融機関支店コード
      this.bl.setBankBranchCode(bankInfoEntityBean
          .getBankBranchCode());
      // 金融機関支店名
      this.bl.setBankBranchName(bankInfoEntityBean
          .getBankBranchName());
      // 金融機関預金種目コード
      this.bl.setBtOfAccountCode(bankInfoEntityBean
          .getBankTypeOfAccountCode());
      // 金融機関預金種目
      this.bl.setBtOfAccount(bankInfoEntityBean
          .getBankTypeOfAccount());
      // 口座番号
      this.bl.setAccountNo(bankInfoEntityBean.getAccountNo());
      // 口座名義
      this.bl.setAccountHolderName(bankInfoEntityBean
          .getAccountHolderName());

      // 「支払方法コード」が振込用請求書の場合
    } else if (ECISCodeConstants.PAYMENT_WAY_CODE_TRANSFER
        .equals(this.mPaymentWayCode)) {

      // 【口座クレカ情報】および【自社金融機関マスタ】および【金融機関預金種目マスタ】より、振込先金融機関情報を取得する。
      Map<String, Object> exampleMap = new HashMap<String, Object>();
      exampleMap.put("paymentId", this.mPaymentId);
      exampleMap.put("batchDate", this.mBatchDate);
      exampleMap.put("acCatCode",
          ECISCodeConstants.ACCOUNT_CREDIT_CATEGORY_CODE_TRANSFER);
      exampleMap.put("unavailableFlag", ECISConstants.FLG_OFF);

      SN_BankInfoEntityBean bankInfoEntityBean = snCreatingBillingCommonMapper
          .selectBankInfo(exampleMap);

      // 《請求EntityBean》に《振込先金融機関情報》を設定する。
      // 金融機関コード
      this.bl.setBankCode(bankInfoEntityBean.getBankCode());
      // 金融機関名
      this.bl.setBankName(bankInfoEntityBean.getBankName());
      // 金融機関支店コード
      this.bl.setBankBranchCode(bankInfoEntityBean.getBankBranchCode());
      // 金融機関支店名
      this.bl.setBankBranchName(bankInfoEntityBean.getBankBranchName());
      // 金融機関預金種目コード
      this.bl.setBtOfAccountCode(bankInfoEntityBean
          .getBankTypeOfAccountCode());
      // 金融機関預金種目
      this.bl.setBtOfAccount(bankInfoEntityBean.getBankTypeOfAccount());
      // 口座番号
      this.bl.setAccountNo(bankInfoEntityBean.getAccountNo());
      // 口座名義
      this.bl.setAccountHolderName(bankInfoEntityBean
          .getAccountHolderName());
    }
  }

  /**
   * 支払期日算定(個別設定用)。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 支払期限個別設定がある場合に用いる支払期日の算定を行う。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param usePeriod
   *          利用年月
   * @param paymentExpirationAddMonths
   *          支払期限加算月数
   * @param paymentExpirationDate
   *          支払期限日
   * @return 支払期日
   */
  private Date calcPfd(String usePeriod, Integer paymentExpirationAddMonths, Integer paymentExpirationDate) {

    // 支払期日
    Date resultDate = null;

    // プロパティ
    Properties prop = null;
    try {
      // プロパティを取得する。
      prop = applicationProperties.getObject();
    } catch (IOException e) {
      // コード定義プロパティから取得できない場合、システムエラーをスローする。
      SystemException se = new SystemException(
          messageSource.getMessage("error.E1278", null, Locale.getDefault()), e);
      throw se;
    }

    // 支払期日（営業日考慮前）の作成
    Date beforeOperatorHolidayDate = null;
    try {
      // 利用年月に支払期限加算月数を加算
      String expireYM = StringConvertUtil.calcMonth(usePeriod,
          paymentExpirationAddMonths.intValue(),
          ECISConstants.FORMAT_DATE_yyyyMM);

      if (ECISConstants.MATSUJITSU == paymentExpirationDate) {
        // 支払期日日数が「末日」の場合月末日を設定
        beforeOperatorHolidayDate = DateCalculateUtil.getEndOfMonth(StringConvertUtil.stringToDate(expireYM));

      } else {
        // Utilクラスの日付変換はLenient(false)なので使用しない
        SimpleDateFormat df = new SimpleDateFormat(ECISConstants.FORMAT_DATE_yyyyMMdd);
        // あいまい設定（2016/02/31⇒2016/03/02）
        df.setLenient(true);
        String dd = StringUtils.leftPad(paymentExpirationDate.toString(), 2, "0");
        beforeOperatorHolidayDate = df.parse(expireYM + dd);
      }

    } catch (ParseException e) {
      // エラーメッセージの出力
      SystemException se = new SystemException(
          messageSource.getMessage("error.E1294", null, Locale.getDefault()), e);
      throw se;
    }

    // カレンダービジネスBeanを生成
    CalendarBusinessBean resultBean = new CalendarBusinessBean();

    // 基準日に支払期日（営業日考慮前）を設定
    resultBean.setBaseDate(beforeOperatorHolidayDate);

    // 補正のため、期間指定を0日に指定
    resultBean.setTermNumberOfDays(0);

    // 事業者休日区分に金融機関休日を設定し、営業日付計算を呼び出す
    resultBean.setOperatorHolidayCategory(ECISConstants.BANK_HOLIDAY);
    resultBean = calendarBusiness.calculateSalesDate(resultBean);

    // リターンコードが正常終了以外の場合、システムエラーをスローする。
    if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(resultBean.getReturnCode())) {
      SystemException se = new SystemException(messageSource.getMessage("error.E0001",
          new String[] {prop.getProperty(LOG_STR_BUSINESS_DAY_GET) },
          Locale.getDefault()));
      throw se;
    }

    // 《カレンダービジネスBean》.処理結果日付をDate型に変換し「支払期日」に設定
    try {
      resultDate = DateUtils.parseDateStrictly(resultBean.getProcessingResult(),
          ECISConstants.FORMAT_DATE_yyyyMMdd);

    } catch (ParseException pe) {
      // 支払期日の形式が正しくない場合、システムエラーをスローする。
      SystemException se = new SystemException(
          messageSource.getMessage("error.E1397", new Object[] {resultBean.getProcessingResult() },
              Locale.getDefault()),
          pe);
      throw se;
    }
    return resultDate;

  }

  /**
   * 支払期日算定。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 支払方法コードが”コンビニ払い”または”振込用請求書”の場合、
   * 基準日を基に業務日付を取得し、支払期日とする。
   * 支払方法コードが”口座振替”または”クレジット払い”の場合、
   * 支払期日算定（口座振替、クレジット払い）を呼び出す。
   * 支払方法コードがnullの場合(債権回収）、
   * 基準日を基に業務日付を取得し、支払期日とする。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param paymentId
   *          支払ID
   * @param usePeriod
   *          利用年月
   * @throws ParseException
   */
  private void getPaymentFixedDate(Integer paymentId, String usePeriod) throws ParseException {

    if (ECISCodeConstants.PAYMENT_WAY_CODE_CONVENI
        .equals(this.mPaymentWayCode)
        || ECISCodeConstants.PAYMENT_WAY_CODE_TRANSFER
            .equals(this.mPaymentWayCode)) {
      // ■ 支払方法コードが”コンビニ払い”または”振込用請求書”の場合
      // 業務日付計算を呼び出す。
      Date paymentFixedDate = dateBusiness.calcWorkDate(this.mBatchDate,
          ECISCodeConstants.WORK_DAYS_FOR_PAYMENT_FIXED_DATE_DAYS);

      // 支払期日
      this.bl.setPfd(paymentFixedDate);

    } else if (ECISCodeConstants.PAYMENT_WAY_CODE_ACCOUNT
        .equals(this.mPaymentWayCode)
        || ECISCodeConstants.PAYMENT_WAY_CODE_CREDIT
            .equals(this.mPaymentWayCode)) {
      // ■ 支払方法コードが”口座振替”または”クレジット払い”の場合
      this.getPaymentFixedDateForAccountTransferAndCredit(paymentId,
          usePeriod);

    } else if (ECISCodeConstants.PAYMENT_WAY_CODE_REMITTANCE.equals(this.mPaymentWayCode)) {
      // ■ 支払方法コードが”送金”の場合

      // 支払期日(ダミー値設定)
      this.bl.setPfd(DateUtils.parseDate("20501231", ECISConstants.FORMAT_DATE_yyyyMMdd));

    } else if (StringUtils.isEmpty(this.mPaymentWayCode)) {
      // ■ 支払方法コードがnullの場合(債権回収）
      // 業務日付計算を呼び出す。
      Date paymentFixedDate = dateBusiness
          .calcWorkDate(
              this.mBatchDate,
              ECISCodeConstants.WORK_DAYS_FOR_COL_OF_CLAIM_PAYMENT_DEADLINE_DATES);

      // 支払期日
      this.bl.setPfd(paymentFixedDate);
    }
  }

  /**
   * 支払期日算定（口座振替、クレジット払い）。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 口振クレカ翌月請求フラグ および 先延ばし支払期日フラグを基に
   * 「支払期日基準年月」を決定する。
   * 「支払期日基準年月」を基に、【業務日程管理マスタ】を参照し、「口座振替日」を取得する。
   * また、バッチ処理基準日を基に、「連携期限日」を取得する。
   * 「口座振替日」と「連携期限日」を比較し、支払期日を算定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param paymentId
   *          支払ID
   * @param usePeriod
   *          利用年月
   * @throws ParseException
   */
  private void getPaymentFixedDateForAccountTransferAndCredit(
      Integer paymentId, String usePeriod) throws ParseException {

    // 業務日程区分コードを保持する。
    String workScheduleCategory;
    if (ECISCodeConstants.PAYMENT_WAY_CODE_ACCOUNT.equals(this.mPaymentWayCode)) {
      // 支払方法コードが”口座振替”の場合
      workScheduleCategory = ECISCodeConstants.WORK_SCHEDULE_CATEGORY_CODE_ACCOUNT_TRANSFER_DATE;
    } else {
      // 支払方法コードが”クレジット払い”の場合
      workScheduleCategory = ECISCodeConstants.WORK_SCHEDULE_CATEGORY_CODE_CREDIT_DATE;
    }

    // 口振クレカ翌月請求フラグ および 先延ばし支払期日フラグの取得
    // 支払期日基準年月
    String baseYm = null;
    // 支払取得
    Payment payment = this.paymentMapper.selectByPrimaryKey(paymentId);

    // 口振クレカ翌月請求フラグ ＝ ON（翌月請求）
    if (ECISConstants.FLG_ON.equals(payment.getDdCreNextMonthBlFlag())) {
      // 先延ばし支払期日フラグ
      this.bl.setProcrastinationPfdFlag(ECISConstants.FLG_ON);
      // 翌月の利用年月取得し、「支払期日基準年月」とする
      baseYm = StringConvertUtil.calcMonth(usePeriod, 1,
          EMSConstants.FORMAT_DATE_YYYYMM);
    } else {
      // 前月の利用年月取得
      String previousMonth = StringConvertUtil.calcMonth(usePeriod, -1,
          EMSConstants.FORMAT_DATE_YYYYMM);

      // 翌月請求対象判定情報を取得する。
      Map<String, Object> exampleMap = new HashMap<String, Object>();
      exampleMap.put("paymentId", paymentId);
      exampleMap.put("usePeriod", previousMonth);

      List<SN_NextMonthBillableEntityBean> nextMonthBillableEntityBeanList = snCreatingBillingCommonMapper
          .selectNextMonthBillable(exampleMap);

      // 翌月請求対象判定情報が取得できた場合
      if (CollectionUtils.isNotEmpty(nextMonthBillableEntityBeanList)) {
        SN_NextMonthBillableEntityBean nextMonthBillableEntityBean = nextMonthBillableEntityBeanList
            .get(0);
        // 《翌月請求対象判定EntityBean》.口振クレカ翌月請求フラグ ＝ ON（翌月請求）
        // または、《翌月請求対象判定EntityBean》.先延ばし支払期日フラグ ＝ ON（先延ばし）の場合
        if (ECISConstants.FLG_ON.equals(nextMonthBillableEntityBean
            .getDirectDebitCreditCardNextMonthBillingFlag())
            || ECISConstants.FLG_ON.equals(nextMonthBillableEntityBean
                .getProcrastinationPaymentFixedDateFlag())) {
          // 翌月の利用年月取得し、「支払期日基準年月」とする
          baseYm = StringConvertUtil.calcMonth(usePeriod, 1,
              EMSConstants.FORMAT_DATE_YYYYMM);

          // 先延ばし支払期日フラグ
          this.bl.setProcrastinationPfdFlag(ECISConstants.FLG_ON);
        } else {
          // 引数.利用年月を「支払期日基準年月」とする
          baseYm = usePeriod;
        }
      } else {
        // 翌月請求対象判定情報が取得できない場合、引数.利用年月を「支払期日基準年月」とする
        baseYm = usePeriod;
      }
    }

    // 「支払期日基準年月」を基に、【業務日程管理マスタ】を参照し、該当年月の日付を取得する。
    WorkScheduleMngMExample workScheduleMngMExample = new WorkScheduleMngMExample();
    workScheduleMngMExample
        .createCriteria()
        .andWorkScheduleCatCodeEqualTo(workScheduleCategory)
        .andWorkSchedulePointEqualTo(
            baseYm);

    List<WorkScheduleMngM> workScheduleMngMList = workScheduleMngMMapper
        .selectByExample(workScheduleMngMExample);

    // 共通処理を呼び出し、決済代行サービスへ連携する連携期限日を取得する。
    Date requestExpirationDate;
    // 支払方法コードが”口座振替”の場合
    if (ECISCodeConstants.PAYMENT_WAY_CODE_ACCOUNT
        .equals(this.mPaymentWayCode)) {
      // 日付関連機能.業務日付計算を呼び出し、「連携期限日」を取得する。
      requestExpirationDate = dateBusiness
          .calcWorkDate(
              this.mBatchDate,
              ECISCodeConstants.WORK_DAYS_FOR_MOUTH_VIBRATION_REQUEST_DEADLINE_DATES);
      // 支払方法コードが”クレジット払い”の場合
    } else {
      // 日付関連機能.業務日付計算を呼び出し、「連携期限日」を取得する。
      requestExpirationDate = dateBusiness
          .calcWorkDate(
              this.mBatchDate,
              ECISCodeConstants.WORK_DAYS_FOR_CREDIT_REQUEST_DEADLINE_DATES);
    }

    Date paymentFixedDate;
    // 「口座振替日」または「クレジットカード決済日」と「連携期限日」を基に、支払期日を算定する。
    // 「口座振替日」または「クレジットカード決済日」 ≧ 「連携期限日」の場合
    if (workScheduleMngMList.get(0).getWorkScheduleDate()
        .compareTo(requestExpirationDate) >= 0) {
      paymentFixedDate = workScheduleMngMList.get(0)
          .getWorkScheduleDate();
    } else {
      // 「バッチ処理基準日＋期限日数」を越える、直近の【業務日程管理マスタ】.業務日付を支払期日とする。
      // 翌月の利用年月取得
      String nextMonth = StringConvertUtil.calcMonth(baseYm, 1,
          EMSConstants.FORMAT_DATE_YYYYMM);

      Map<String, Object> exampleMapWkScDate = new HashMap<String, Object>();
      exampleMapWkScDate.put("workScheduleCatCode", workScheduleCategory);
      exampleMapWkScDate.put("workSchedulePoint", nextMonth);
      exampleMapWkScDate.put("workScheduleDate", requestExpirationDate);

      // 口座振替日またはクレジットカード決済日
      paymentFixedDate = snCreatingBillingCommonMapper
          .selectWorkScheduleDateMostRecent(exampleMapWkScDate);

      // 先延ばし支払期日フラグ
      this.bl.setProcrastinationPfdFlag(ECISConstants.FLG_ON);
    }

    // メンバ変数.支払方法コードが”口座振替”の場合
    if (ECISCodeConstants.PAYMENT_WAY_CODE_ACCOUNT
        .equals(this.mPaymentWayCode)) {

      // 金融機関営業日の取得
      CalendarBusinessBean calendarBusinessBean = new CalendarBusinessBean();
      calendarBusinessBean.setBaseDate(paymentFixedDate);
      calendarBusinessBean.setTermNumberOfDays(0);
      calendarBusinessBean.setOperatorHolidayCategory(ECISConstants.BANK_HOLIDAY);
      // カレンダー関連機能の営業日算出処理を呼び出す。
      calendarBusinessBean = calendarBusiness.calculateSalesDate(calendarBusinessBean);
      paymentFixedDate = DateUtils.parseDate(calendarBusinessBean.getProcessingResult(),
          ECISConstants.FORMAT_DATE_yyyyMMdd);
    }

    // 支払期日
    this.bl.setPfd(paymentFixedDate);
    // 決済予定日
    this.bl.setSettlementScheduledDate(paymentFixedDate);
  }

  /**
   * 合算対象無効化更新。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 【確定料金・請求連携】の無効化および【請求】の無効化を行う。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param blId
   *          請求ID
   * @param fcrId
   *          確定料金実績ID
   */
  private void updateInvalidationAddUpTarget(Integer blId, Integer fcrId) {

    try {
      // ■【確定料金・請求連携】の無効化
      this.updateInvalidationFixChargeBillingLinkage(blId, fcrId);

      // ■【請求】の無効化
      this.updateInvalidationBilling(blId);

    } catch (RuntimeException e) {
      // 異常終了ログ出力
      SystemException se = new SystemException(
          messageSource.getMessage("error.E1168", new String[] {
              this.funcId, blId.toString() }, Locale.getDefault()),
          e);
      throw se;
    }
  }

  /**
   * 確定料金実績更新処理。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 【確定料金実績】を更新する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param fcrId
   *          確定料金実績ID
   * @param carryOverFlag
   *          繰越フラグ
   */
  private void updateFixChargeResult(Integer fcrId, boolean carryOverFlag) {
    try {
      // ■ 《確定料金実績EntityBean》設定
      Fcr fcr = new Fcr();
      // 確定料金実績ID
      fcr.setFcrId(fcrId);
      // 請求番号
      fcr.setBlNo(this.bl.getBlNo());
      // 更新日時
      fcr.setUpdateTime(this.systime);
      // 更新モジュールコード
      fcr.setUpdateModuleCode(this.updateModuleCode);

      // ■ 《請求EntityBean》.請求額＝0円 かつ繰越しない場合
      if (this.bl.getBlAmount() == 0 && !carryOverFlag) {
        // 売掛金消込計上日
        fcr.setArRccRecordedDate(this.mRecordedDate);
        // 売掛金消込基準日
        fcr.setArRccBaseDate(this.mBatchDate);
        // 売掛金消込処理日
        fcr.setArRccExecuteDate(this.mBatchDate);
        if (this.bl.getUseAmount() == 0) {
          // 請求消込時充当有無フラグ
          fcr.setBlRccAppropriationFlag(ECISConstants.FLG_OFF);
        } else {
          // 請求消込時充当有無フラグ
          fcr.setBlRccAppropriationFlag(ECISConstants.FLG_ON);
        }
        // 完了フラグ
        fcr.setCompletedFlag(ECISConstants.FLG_ON);
      }

      // ■ 確定料金実績DAO.updateByPrimaryKeySelectiveを呼び出し、【確定料金実績】を更新する。
      fcrMapper.updateByPrimaryKeySelective(fcr);

    } catch (RuntimeException e) {
      // 異常終了ログ出力
      SystemException se = new SystemException(
          messageSource.getMessage("error.E1169", new String[] {
              this.funcId, fcrId.toString() }, Locale.getDefault()),
          e);
      throw se;
    }

  }

  /**
   * 確定料金・請求連携登録処理。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 【確定料金・請求連携】を登録する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param fcrId
   *          確定料金実績ID
   * @param carryOverFlag
   *          繰越フラグ
   */
  private void insertFixChargeBillingLinkage(Integer fcrId, boolean carryOverFlag) {
    try {
      FixChargeBlLinkage fixChargeBlLinkage = new FixChargeBlLinkage();
      // 請求ID
      fixChargeBlLinkage.setBlId(this.bl.getBlId());
      // 確定料金実績ID
      fixChargeBlLinkage.setFcrId(fcrId);

      if (carryOverFlag) {
        //料金を繰り越す場合、少額請求繰越フラグをONにする。
        fixChargeBlLinkage.setSmallBlTransFlag(ECISConstants.FLG_ON);
      } else {
        //上記以外の場合、少額請求繰越フラグをOFFにする。
        fixChargeBlLinkage.setSmallBlTransFlag(ECISConstants.FLG_OFF);
      }

      // 合算要否フラグ
      fixChargeBlLinkage.setAddUpNeedFlag(ECISConstants.FLG_OFF);
      // 無効フラグ
      fixChargeBlLinkage.setInvalidFlag(ECISConstants.FLG_OFF);
      // 更新回数
      fixChargeBlLinkage.setUpdateCount(0);
      // 作成日時
      fixChargeBlLinkage.setCreateTime(this.systime);
      // 更新日時
      fixChargeBlLinkage.setUpdateTime(this.systime);
      // 更新モジュールコード
      fixChargeBlLinkage.setUpdateModuleCode(this.updateModuleCode);

      // ■ 確定料金・請求連携DAO.insertSelectiveを呼び出し、【確定料金・請求連携】を登録する。
      fixChargeBlLinkageMapper.insertSelective(fixChargeBlLinkage);

    } catch (RuntimeException e) {
      // 異常終了ログ出力
      SystemException se = new SystemException(
          messageSource.getMessage("error.E1170", new String[] {
              this.funcId, fcrId.toString() }, Locale.getDefault()),
          e);
      throw se;
    }

  }

  /**
   * 請求登録処理。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 【請求】を登録する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param fcr
   *          確定料金実績
   */
  private void insertBilling(Fcr fcr) {
    try {
      // ■ 《請求EntityBean》設定
      // 契約者ID
      this.bl.setContractorId(fcr.getContractorId());
      // 契約者番号
      this.bl.setContractorNo(fcr.getContractorNo());
      // 取引先コード
      this.bl.setCustomerCode(fcr.getCustomerCode());
      // 提供モデルコード
      this.bl.setPmCode(fcr.getPmCode());
      // 提供モデル企業コード
      this.bl.setPmCompanyCode(fcr.getPmCompanyCode());
      // 利用年月
      this.bl.setUsePeriod(fcr.getUsePeriod());
      //複数月まとめ請求
      this.bl.setMultipleMcBlFlag(ECISConstants.FLG_OFF);
      //繰越額
      this.bl.setTransAmount(0L);
      // 支払方法コード ≠ nullの場合（単独・まとめ）
      if (StringUtils.isNotEmpty(this.mPaymentWayCode)) {
        // 請求区分コード
        this.bl.setBlCatCode(this.mPaymentWayCode);
        // 上記以外の場合（債権回収依頼）
      } else {
        // 請求区分コード
        this.bl.setBlCatCode(ECISCodeConstants.BILLING_CATEGORY_CODE_COMMISSION_COLLECTION_CLAIM_COVERED);
      }
      // 更新回数
      this.bl.setUpdateCount(0);
      // 作成日時
      this.bl.setCreateTime(this.systime);
      // 更新日時
      this.bl.setUpdateTime(this.systime);
      // 更新モジュールコード
      this.bl.setUpdateModuleCode(this.updateModuleCode);

      // ■ 【請求】の登録
      // 請求Dao.insertSelectiveを呼び出す。
      blMapper.insertSelective(this.bl);

    } catch (RuntimeException e) {
      // 異常終了ログ出力
      SystemException se = new SystemException(
          messageSource.getMessage("error.E1171", new String[] {
              this.funcId, this.bl.getPaymentId().toString(),
              fcr.getContractorId().toString() }, Locale.getDefault()),
          e);
      throw se;
    }

  }

  /**
   * 請求登録処理。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 【請求】を登録する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param fcrList
   *          確定料金実績リスト
   * @param carryOverFlag
   *          繰越フラグ
   * @param prop
   *          プロパティーオブジェクト
   */
  private void insertBillingForMultipleMonSummarizeBilling(List<Fcr> fcrList, boolean carryOverFlag,
      Properties prop) {
    try {
      // ■ 《請求EntityBean》設定
      // 契約者ID
      this.bl.setContractorId(fcrList.get(0).getContractorId());
      // 契約者番号
      this.bl.setContractorNo(fcrList.get(0).getContractorNo());
      // 取引先コード
      this.bl.setCustomerCode(fcrList.get(0).getCustomerCode());
      // 提供モデルコード
      this.bl.setPmCode(fcrList.get(0).getPmCode());
      // 提供モデル企業コード
      this.bl.setPmCompanyCode(fcrList.get(0).getPmCompanyCode());
      // 利用年月
      this.bl.setUsePeriod(fcrList.get(0).getUsePeriod());

      //複数月まとめ請求判定処理の結果を複数月まとめ請求に代入
      if (this.isMultipleMonSummarizeBilling(fcrList)) {
        this.bl.setMultipleMcBlFlag(ECISConstants.FLG_ON);
      } else {
        this.bl.setMultipleMcBlFlag(ECISConstants.FLG_OFF);
      }

      if (!carryOverFlag) {
        //繰り越さない場合、繰越額0円を設定する。
        this.bl.setTransAmount(0L);
      }

      // 請求区分コード
      this.bl.setBlCatCode(this.mPaymentWayCode);
      // 更新回数
      this.bl.setUpdateCount(0);
      // 作成日時
      this.bl.setCreateTime(this.systime);
      // 更新日時
      this.bl.setUpdateTime(this.systime);
      // 更新モジュールコード
      this.bl.setUpdateModuleCode(this.updateModuleCode);

      // ■ 【請求】の登録
      // 請求Dao.insertSelectiveを呼び出す。
      blMapper.insertSelective(this.bl);

      if (carryOverFlag &&
          StringUtils.equals(prop.getProperty(BL_CO_NOTICE_MAIL_SEND_EXIST), ECISConstants.FLG_ON)) {
        //繰越があり、請求繰越お知らせメールの送信有無が「有」の場合

        //請求メールの明細情報を取得
        SN_BlCODetailInfoBusinessBean snBlCODetailInfoBusinessBean = this.getDetailInfo(fcrList, bl, prop);
        //請求メールの作成
        this.createBillingCarryOverMail(snBlCODetailInfoBusinessBean, prop);
      }

    } catch (RuntimeException e) {
      // 異常終了ログ出力
      SystemException se = new SystemException(
          messageSource.getMessage("error.E1171", new String[] {
              this.funcId, this.bl.getPaymentId().toString(),
              fcrList.get(0).getContractorId().toString() }, Locale.getDefault()),
          e);
      throw se;
    }

  }

  /**
   * TODO登録処理。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 【ToDo】を登録する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractNoList
   *          契約番号リスト
   */
  private void insertTodo(List<String> contractNoList) {

    // ■ <システム共通>Todo登録処理
    // メッセージ編集
    StringBuilder editContractNo = new StringBuilder();
    for (String contractNo : contractNoList) {
      editContractNo.append(contractNo);
      editContractNo.append(EMSConstants.COMMA);
    }
    editContractNo.deleteCharAt(editContractNo.length() - 1);

    TodoBusinessBean todoBusinessBean = new TodoBusinessBean();
    // サブシステムID
    todoBusinessBean.setSubsystemId(ECISConstants.SUBSYSTEM_ID_SN);
    // 機能ID
    todoBusinessBean.setFunctionId(this.funcId);
    // メッセージID
    todoBusinessBean.setMessageId("todo.T1015");
    // メッセージ
    todoBusinessBean.setMessage(messageSource.getMessage("todo.T1015", null, Locale.getDefault()));
    // 備考
    todoBusinessBean.setNote(messageSource.getMessage("todo.T1033", new String[] {
        this.bl.getBlNo(), editContractNo.toString() }, Locale.getDefault()));

    // Todo登録処理を呼び出す
    todoBusiness.registTodo(todoBusinessBean);
  }

  /**
   * 充当済の請求EntityBean設定処理。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 充当済の《請求EntityBean》を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param cntAppropriationDeposits
   *          預り金充当の件数
   */
  private void setBillingAppropriationAlready(int cntAppropriationDeposits) {
    // ■ 《請求EntityBean》設定
    // 請求額
    this.bl.setBlAmount(Long.valueOf(0));
    // 請求ステータスコード
    this.bl.setBlStatusCode(ECISCodeConstants.BILLING_STATUS_CODE_RECONCILE);
    // 完了フラグ
    this.bl.setCompletedFlag(ECISConstants.FLG_ON);

    // 預り金充当の件数 ≧ 2件 の場合
    if (cntAppropriationDeposits >= 2) {
      // 複合消込フラグ（ON）
      this.bl.setMultipleRccFlag(ECISConstants.FLG_ON);
    }
  }

  /**
   * 請求EntityBean初期設定処理。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 《請求EntityBean》の初期設定をする。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   */
  private void initBilling() {

    // ■ 《請求EntityBean》設定
    // 支払ID
    this.bl.setPaymentId(this.mPaymentId);
    // 合算請求フラグ
    this.bl.setAddUpBlFlag(ECISConstants.FLG_OFF);
    // 先延ばし支払期日フラグ
    this.bl.setProcrastinationPfdFlag(ECISConstants.FLG_OFF);
    // 請求作成日
    this.bl.setBlCreateDate(this.mBatchDate);
    // 複合消込フラグ
    this.bl.setMultipleRccFlag(ECISConstants.FLG_OFF);
    // まとめ請求フラグ
    this.bl.setCombinedBlFlag(ECISConstants.FLG_OFF);
    // 完了フラグ
    this.bl.setCompletedFlag(ECISConstants.FLG_OFF);

  }

  /**
   * 確定料金・請求連携無効化更新処理。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 【確定料金・請求連携】の無効化を行う。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param blId
   *          請求ID
   * @param fcrId
   *          確定料金実績ID
   */
  private void updateInvalidationFixChargeBillingLinkage(Integer blId,
      Integer fcrId) {

    // ■ 《確定料金・請求連携EntityBean》設定
    FixChargeBlLinkage fixChargeBlLinkage = new FixChargeBlLinkage();
    // 請求ID
    fixChargeBlLinkage.setBlId(blId);
    // 確定料金実績ID
    fixChargeBlLinkage.setFcrId(fcrId);
    // 無効フラグ
    fixChargeBlLinkage.setInvalidFlag(ECISConstants.FLG_ON);
    // 更新日時
    fixChargeBlLinkage.setUpdateTime(this.systime);
    // 更新モジュールコード
    fixChargeBlLinkage.setUpdateModuleCode(this.updateModuleCode);

    // ■ 確定料金・請求連携DAO.updateByPrimaryKeySelectiveを呼び出し、【確定料金・請求連携】を更新する。
    fixChargeBlLinkageMapper
        .updateByPrimaryKeySelective(fixChargeBlLinkage);
  }

  /**
   * 請求無効化更新処理。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 【請求】の無効化を行う。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param blId
   *          請求ID
   */
  private void updateInvalidationBilling(Integer blId) {

    // ■ 《請求EntityBean》設定
    Bl bill = new Bl();
    // 請求ID
    bill.setBlId(blId);
    // 請求ステータスコード
    bill.setBlStatusCode(ECISCodeConstants.BILLING_STATUS_CODE_INVALID);
    // 完了フラグ
    bill.setCompletedFlag(ECISConstants.FLG_ON);
    // 更新日時
    bill.setUpdateTime(this.systime);
    // 更新モジュールコード
    bill.setUpdateModuleCode(this.updateModuleCode);

    // ■ 請求DAO.updateByPrimaryKeySelectiveを呼び出し、【請求】を更新する。
    blMapper.updateByPrimaryKeySelective(bill);
  }

  /**
   * 預り金等情報取得処理（充当予約情報取得）。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 【預り金等】より、充当予約のレコードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param blNo
   *          請求番号
   * @return 《預り金等EntityBean》リスト
   */
  private List<Dpr> selectAppropriatedReservation(String blNo) {

    // ■ 《預り金等EntityBean》設定
    DprExample dprExample = new DprExample();
    // 充当先請求番号、預り金等ステータスコード、完了フラグ
    dprExample.createCriteria().andAppropriatedBlNoEqualTo(blNo).andDprStatusCodeEqualTo(
        ECISCodeConstants.DEPOSITS_RECEIVED_STATUS_CODE_APPROPRIATION_RESERVATION).andCompletedFlagEqualTo(
            ECISConstants.FLG_OFF);

    // ■ 預り金等DAO.selectByExampleを呼び出し、【預り金等】を取得する。
    List<Dpr> dprList = dprMapper.selectByExample(dprExample);
    return dprList;

  }

  /**
   * 預り金等情報更新処理（預り金等無効化）。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 預り金等ステータスコードを無効に更新する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param dprId
   *          預り金等ID
   */
  private void updateInvalidationDepositsReceived(Integer dprId) {

    // ■ 《預り金等EntityBean》設定
    Dpr dpr = new Dpr();
    // 預り金等ID
    dpr.setDprId(dprId);
    // 預り金等ステータスコード
    dpr.setDprStatusCode(ECISCodeConstants.DEPOSITS_RECEIVED_STATUS_CODE_INVALID);
    // 完了フラグ
    dpr.setCompletedFlag(ECISConstants.FLG_ON);
    // 更新日時
    dpr.setUpdateTime(this.systime);
    // 更新モジュールコード
    dpr.setUpdateModuleCode(this.updateModuleCode);

    // ■ 預り金等DAO.updateByPrimaryKeySelectiveを呼び出し、【預り金等】を更新する。
    dprMapper.updateByPrimaryKeySelective(dpr);
  }

  /**
   * 預り金等情報登録処理（預り金等無効化）。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 未充当の預り金を登録する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param dpr《預り金等EntityBean》
   */
  private void insertInvalidationDepositsReceived(Dpr dpr) {

    // ■ 《預り金等EntityBean》設定
    // 預り金等IDの採番
    Map<String, Object> exampleMap = new HashMap<String, Object>();
    exampleMap.put("sqName", ECISConstants.SEQUENCE_NAME_DPR_ID);
    Integer dprId = gkWorkCommonMapper.selectSequenceId(exampleMap);
    dpr.setDprId(dprId);
    // 預り金等ステータスコード
    dpr.setDprStatusCode(ECISCodeConstants.DEPOSITS_RECEIVED_STATUS_CODE_NOT_APPROPRIATION);
    // 預り金等消込計上日
    dpr.setDprRccRecordedDate(null);
    // 預り金等消込基準日
    dpr.setDprRccBaseDate(null);
    // 預り金等消込処理日
    dpr.setDprRccExecuteDate(null);
    // 充当先請求番号
    dpr.setAppropriatedBlNo(null);
    // 預り金等特別消込理由コード
    dpr.setDprSrReasonCode(null);
    // 預り金等振替先科目コード
    dpr.setDprTransferIc(null);
    // 完了フラグ
    dpr.setCompletedFlag(ECISConstants.FLG_OFF);
    // 更新回数
    dpr.setUpdateCount(0);
    // 作成日時
    dpr.setCreateTime(this.systime);
    // オンライン更新日時
    dpr.setOnlineUpdateTime(null);
    // オンライン更新ユーザID
    dpr.setOnlineUpdateUserId(null);
    // 更新日時
    dpr.setUpdateTime(this.systime);
    // 更新モジュールコード
    dpr.setUpdateModuleCode(this.updateModuleCode);

    // ■預り金等DAO.insertSelectiveを呼び出し、【預り金等】を登録する。
    dprMapper.insertSelective(dpr);

  }

  /**
   * 預り金等情報取得処理（未充当情報取得）。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 【預り金等】より、未充当の情報を預り金等発生日の昇順で取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorNo
   *          契約者番号
   * @return 《預り金等EntityBean》リスト
   */
  private List<Dpr> selectAppropriatedNotYet(String contractorNo) {

    // ■ 《預り金等EntityBean》設定
    DprExample dprExample = new DprExample();
    // 契約者番号、預り金等ステータスコード、完了フラグ
    dprExample.createCriteria().andContractorNoEqualTo(contractorNo).andDprStatusCodeEqualTo(
        ECISCodeConstants.DEPOSITS_RECEIVED_STATUS_CODE_NOT_APPROPRIATION).andCompletedFlagEqualTo(
            ECISConstants.FLG_OFF);
    // 預り金等発生日（昇順）
    dprExample.setOrderByClause("dpr_date asc");

    // ■ 預り金等DAO.selectByExampleを呼び出し、【預り金等】を取得する。
    List<Dpr> dprList = dprMapper.selectByExample(dprExample);
    return dprList;

  }

  /**
   * 預り金等情報更新処理（充当予約更新）。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 預り金等情報を充当予約に更新する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param dprId
   *          預り金等ID
   */
  private void updateAppropriatedReservation(Integer dprId) {

    // ■ 《預り金等EntityBean》設定
    Dpr dpr = new Dpr();
    // 預り金等ID
    dpr.setDprId(dprId);
    // 充当先請求番号
    dpr.setAppropriatedBlNo(this.bl.getBlNo());
    // 預り金等ステータスコード
    dpr.setDprStatusCode(ECISCodeConstants.DEPOSITS_RECEIVED_STATUS_CODE_APPROPRIATION_RESERVATION);
    // 更新日時
    dpr.setUpdateTime(this.systime);
    // 更新モジュールコード
    dpr.setUpdateModuleCode(this.updateModuleCode);

    // ■ 預り金等DAO.updateByPrimaryKeySelectiveを呼び出し、【預り金等】を更新する。
    dprMapper.updateByPrimaryKeySelective(dpr);

  }

  /**
   * 預り金等情報更新処理（充当済更新）。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 預り金等情報を充当済に更新する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param dprId
   *          預り金等ID
   */
  private void updateAppropriatedSettled(Integer dprId) {

    // ■ 《預り金等EntityBean》設定
    Dpr dpr = new Dpr();
    // 預り金等ID
    dpr.setDprId(dprId);
    // 充当先請求番号
    dpr.setAppropriatedBlNo(this.bl.getBlNo());
    // 預り金等ステータスコード
    dpr.setDprStatusCode(ECISCodeConstants.DEPOSITS_RECEIVED_STATUS_CODE_APPROPRIATION);
    // 預り金等消込計上日
    dpr.setDprRccRecordedDate(this.mRecordedDate);
    // 預り金等消込基準日
    dpr.setDprRccBaseDate(this.mBatchDate);
    // 預り金等消込処理日
    dpr.setDprRccExecuteDate(this.mBatchDate);
    // 完了フラグ
    dpr.setCompletedFlag(ECISConstants.FLG_ON);
    // 更新日時
    dpr.setUpdateTime(this.systime);
    // 更新モジュールコード
    dpr.setUpdateModuleCode(this.updateModuleCode);

    // ■ 預り金等DAO.updateByPrimaryKeySelectiveを呼び出し、【預り金等】を更新する。
    dprMapper.updateByPrimaryKeySelective(dpr);

  }

  /**
   * 解約（破産）の契約番号取得処理。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 解約（破産）の契約番号を取得し、リストで返却する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param fcrList《確定料金実績EntityBean》リスト
   * @return 契約番号リスト
   */
  private List<String> getBankruptcyContractNoList(List<Fcr> fcrList) {

    // ■ 引数.《確定料金実績EntityBean》リスト分、以下の処理を繰り返す。
    List<String> contractNoList = new ArrayList<>();
    for (Fcr fcr : fcrList) {

      ContractExample contractExample = new ContractExample();
      // 契約ID、約終了理由コード
      contractExample
          .createCriteria()
          .andContractIdEqualTo(
              fcr.getContractId())
          .andContractEndReasonCodeEqualTo(
              ECISCodeConstants.CONTRACT_END_REASON_CODE_CANCELLATION_BANKRUPTCY);

      // 契約DAO.selectByExampleを呼び出し、【契約】を取得する。
      List<Contract> contractList = contractMapper
          .selectByExample(contractExample);

      // 取得できた場合、契約番号リストに《契約EntityBean》.契約番号を格納する。
      if (CollectionUtils.isNotEmpty(contractList)) {
        contractNoList.add(contractList.get(0).getContractNo());
      }
    }

    // 契約番号の重複を削除する。
    contractNoList = contractNoList.stream().distinct()
        .collect(Collectors.toList());

    return contractNoList;

  }

  /**
   * 繰越判定処理
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 複数月まとめ請求において月額料金を繰越か判定する
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param fcrList《確定料金実績EntityBean》リスト
   * @param bl《請求EntityBean》
   * @param paymentId
   *          支払ID
   * @param totalMonAndCarryOverCharge
   *          月額料金と繰越金合計
   * @param prop
   *          プロパティーオブジェクト
   * @return 繰越判定結果
   */
  private boolean isCarryOver(List<Fcr> fcrList, Bl bl, Integer paymentId, Long totalMonAndCarryOverCharge,
      Properties prop) {
    if (StringUtils.equals(bl.getAddUpBlFlag(), ECISConstants.FLG_ON)) {
      //《請求EntityBean》.合算請求フラグがONの時、falseを返却する。
      return false;
    }

    if (StringUtils.equals(prop.getProperty(MULTI_MON_SUMMARIZE_BL_EXIST), ECISConstants.FLG_OFF)) {
      //複数月まとめ請求有無が「無」のときfalseを返却する。
      return false;
    }

    //利用年月の重複を排除した利用年月リストを取得する。
    List<String> usePeriodList = new ArrayList<>();
    for (Fcr fcr : fcrList) {
      usePeriodList.add(fcr.getUsePeriod());
    }
    // 利用年月のの重複を削除する。
    usePeriodList = usePeriodList.stream().distinct()
        .collect(Collectors.toList());

    if (usePeriodList.size() >= Integer.parseInt(prop.getProperty(MULTI_MON_SUMMARIZE_BL_MAX_MON))) {
      //利用年月リストの要素数 ＞= 複数月まとめ請求最大月数(プロパティーより取得)の場合falseを返却する。
      return false;
    }

    if (totalMonAndCarryOverCharge.longValue() > 0L
        && totalMonAndCarryOverCharge.longValue() >= Long.parseLong(prop.getProperty(MULTI_MON_SUM_BL_BL_T))) {
      //月額料金と繰越金合計 ＞0かつ月額料金と繰越金合計＞＝複数月まとめ請求額閾値の場合、falseを返却する。
      return false;
    }

    if (totalMonAndCarryOverCharge.longValue() < 0L
        && totalMonAndCarryOverCharge.longValue() <= Long.parseLong(prop.getProperty(MULTI_MON_SUM_BL_RE_T))) {
      //月額料金と繰越金合計 ＜0かつ月額料金と繰越金合計」＜＝複数月まとめ送金額閾値、falseを返却する。
      return false;
    }

    if (totalMonAndCarryOverCharge.longValue() == 0L) {
      return false;
    }

    ContractExample contractExample = new ContractExample();
    // 契約ID、契約約終了理由コード
    contractExample
        .createCriteria()
        .andPaymentIdEqualTo(paymentId)
        .andContractEndReasonCodeIsNull();

    // 契約DAO.selectByExampleを呼び出し、【契約】を取得する。
    List<Contract> contractList = contractMapper
        .selectByExample(contractExample);

    if (CollectionUtils.isEmpty(contractList)) {
      //支払IDに紐づく契約がすべて契約廃止であればfalseを返却する。
      return false;
    }

    return true;

  }

  /**
   * 複数月まとめ請求判定処理
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 確定料金・請求連携の複数月まとめ請求フラグのON、OFFを判定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param fcrList《確定料金実績EntityBean》リスト
   * @param bl《請求EntityBean》
   * @param carryOverFlag
   *          繰越判定
   * @return 複数月まとめ請求判定結果
   */
  private boolean isMultipleMonSummarizeBilling(List<Fcr> fcrList) {
    for (Fcr fcr : fcrList) {
      FixChargeBlLinkageExample fixChargeBlLinkageExample = new FixChargeBlLinkageExample();
      fixChargeBlLinkageExample
          .createCriteria()
          .andFcrIdEqualTo(fcr.getFcrId())
          .andInvalidFlagEqualTo(ECISConstants.FLG_ON)
          .andSmallBlTransFlagEqualTo(ECISConstants.FLG_ON);
      List<FixChargeBlLinkage> fixChargeBlLinkageList = fixChargeBlLinkageMapper
          .selectByExample(fixChargeBlLinkageExample);

      //【確定料金・請求連携】の取得ができかつ合算請求フラグがOFFあるとき、複数月まとめ請求フラグはONとする。
      if (!CollectionUtils.isEmpty(fixChargeBlLinkageList) &&
          StringUtils.equals(bl.getAddUpBlFlag(), ECISConstants.FLG_OFF)) {
        return true;
      }
    }
    return false;
  }

  /**
   * 明細情報処理
   *
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 請求繰越メールの明細情報処理。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param fcrList《確定料金実績EntityBean》リスト
   * @param bl《請求EntityBean》
   * @param prop
   *          プロパティーオブジェクト
   * @return 複数月まとめ請求判定結果
   */
  private SN_BlCODetailInfoBusinessBean getDetailInfo(List<Fcr> fcrList, Bl bl, Properties prop) {
    SN_BlCODetailInfoBusinessBean snBlCODetailInfoBusinessBean = new SN_BlCODetailInfoBusinessBean();

    snBlCODetailInfoBusinessBean.setBl(bl);

    // ■請求先情報取得
    Map<String, Object> billingInfoMap = new HashMap<String, Object>();
    billingInfoMap.put("contractorId", bl.getContractorId());
    billingInfoMap.put("paymentId", bl.getPaymentId());
    billingInfoMap.put("blCreateDate", bl.getBlCreateDate());

    // 請求依頼ファイル作成.請求先情報取得処理を呼び出す。
    SN_BillingInfoEntityBean snBillingInfoEntityBean = snCreatingBillingRequestFileMapper
        .selectBillingInfo(billingInfoMap);

    // 《請求明細情報Bean》←《請求先情報EntityBean》]
    if (snBillingInfoEntityBean != null) {
      snBlCODetailInfoBusinessBean.setPaymentHist(snBillingInfoEntityBean.getPaymentHist());
    }

    //契約者情報を取得する。
    Contractor contractor = contractorMapper.selectByPrimaryKey(bl.getContractorId());
    snBlCODetailInfoBusinessBean.setContractor(contractor);

    //消費税相当額を取得する
    Long CtEquivalent = 0L;
    for (Fcr fcr : fcrList) {
      CtEquivalent = Long.valueOf(CtEquivalent.longValue() + fcr.getCtEquivalent().longValue());
    }
    snBlCODetailInfoBusinessBean.setCtEquivalent(CtEquivalent);

    //メール送信日
    Calendar nextDate = Calendar.getInstance();
    nextDate.setTime(mBatchDate);
    nextDate.add(Calendar.DATE, 1);
    snBlCODetailInfoBusinessBean.setMailSendDate(nextDate.getTime());

    //複数月まとめ請求額閾値
    if (bl.getTransAmount().longValue() > 0L) {
      //請求
      snBlCODetailInfoBusinessBean.setThreshold(Long.parseLong(prop.getProperty(MULTI_MON_SUM_BL_BL_T)));
    }

    if (bl.getTransAmount().longValue() < 0L) {
      //送金
      snBlCODetailInfoBusinessBean.setThreshold(Long.parseLong(prop.getProperty(MULTI_MON_SUM_BL_RE_T)));
      snBlCODetailInfoBusinessBean.setCtEquivalent(0L);

    }

    // 全契約番号リスト
    List<String> cntractNoList = new ArrayList<>();
    //全利用年月リスト
    List<String> usePeriodList = new ArrayList<>();
    for (Fcr fcr : fcrList) {
      cntractNoList.add(fcr.getContractNo());
      usePeriodList.add(fcr.getUsePeriod());
    }
    // 契約番号の重複を削除する。
    cntractNoList = cntractNoList.stream().distinct()
        .collect(Collectors.toList());
    snBlCODetailInfoBusinessBean.setContractNoList(cntractNoList);

    // 利用年月のの重複を削除する。
    usePeriodList = usePeriodList.stream().distinct()
        .collect(Collectors.toList());
    //昇順に並び替える。
    Collections.sort(usePeriodList);
    snBlCODetailInfoBusinessBean.setUsePeriodList(usePeriodList);

    return snBlCODetailInfoBusinessBean;
  }

  /**
   * 請求繰越メール作成処理
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メールテンプレートを編集し、
   * メール管理登録を行う。
   * </pre>
   *
   * @param bean
   *          請求明細情報Bean
   * @param prop
   *          プロパティオブジェクト
   */
  private void createBillingCarryOverMail(
      SN_BlCODetailInfoBusinessBean bean, Properties prop) {

    // ■メールテンプレート編集
    // 請求区分コードを基に、外部ファイルより、メールテンプレートのファイルパス名を取得する。
    String tmpFileSubject = null;
    String tmpFileMailBody = null;
    String tmpDir = prop.getProperty(MAIL_TMPLATE_FILE_DIR);
    // 件名テンプレート名取得
    tmpFileSubject = prop.getProperty(MAIL_SUBJECT_TMPLATE_FILE_NAME);
    // メールテンプレート名取得
    tmpFileMailBody = prop.getProperty(MAIL_BODY_TMPLATE_FILE_NAME);

    if (StringUtils.isEmpty(tmpDir)
        || StringUtils.isEmpty(tmpFileSubject)
        || StringUtils.isEmpty(tmpFileMailBody)) {
      // プロパティファイルの読み込みに失敗した場合、以下のメッセージを設定し、システム例外をスローする。
      throw new SystemException(messageSource.getMessage("error.E1278", null, Locale.getDefault()));
    }

    // ■テンプレート編集
    // 業務共通ビジネス.メールテンプレート編集処理を呼び出す。（件名）
    String editTmpFileSubject = gkWorkCommonBusiness.mailTextMaker(tmpDir + tmpFileSubject, bean);
    // 業務共通ビジネス.メールテンプレート編集処理を呼び出す。（本文）
    String editTmpFileMailBody = gkWorkCommonBusiness.mailTextMaker(tmpDir + tmpFileMailBody, bean);

    // ■メール管理登録
    MailManagementBusinessBean mailManagementBusinessBean = new MailManagementBusinessBean();
    List<String> addressToList = new ArrayList<>();
    // 契約者メールアドレス1
    if (StringUtils.isNotEmpty(bean.getContractor().getCma1())) {
      addressToList.add(bean.getContractor().getCma1());
    }
    // 契約者メールアドレス2
    if (StringUtils.isNotEmpty(bean.getContractor().getCma2())) {
      addressToList.add(bean.getContractor().getCma2());
    }
    if (bean.getPaymentHist() != null) {
      // 請求先メールアドレス1
      if (StringUtils.isNotEmpty(bean.getPaymentHist().getBlMailAddress1())) {
        addressToList.add(bean.getPaymentHist().getBlMailAddress1());
      }
      // 請求先メールアドレス2
      if (StringUtils.isNotEmpty(bean.getPaymentHist().getBlMailAddress2())) {
        addressToList.add(bean.getPaymentHist().getBlMailAddress2());
      }
    }
    // 宛先（To）
    mailManagementBusinessBean.setAddressTo(addressToList);
    // 宛先（Cc）,宛先（Bcc）は未設定
    // 件名
    mailManagementBusinessBean.setSubject(editTmpFileSubject);
    // 本文
    mailManagementBusinessBean.setMailBody(editTmpFileMailBody);
    // システム共通.メール登録機能を呼び出す。
    mailManagementBusiness.registMailManagement(mailManagementBusinessBean);

  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.sn.SN_CreatingBillingBusiness
   * #claimCollectionCreateBilling
   * (jp.co.unisys.enability.cis.entity.sn.SN_CreatingBillingTargetEntityBean,
   * String, String)
   */
  @Override
  public void claimCollectionCreateBilling(
      SN_CreatingBillingTargetEntityBean creatingBillingTargetEntityBean,
      String batchDate, String processFlg) {

    try {

      // ■オブジェクト生成
      List<SN_CreatingBillingTargetEntityBean> beanList = new ArrayList<>();
      // リストに請求作成対象候補EntityBeanを設定
      beanList.add(creatingBillingTargetEntityBean);
      // バッチ処理基準日をDate型に変換して設定
      this.mBatchDate = StringConvertUtil.stringToDate(batchDate,
          EMSConstants.FORMAT_DATE_yyyyMMdd);
      // システム日時の取得
      Date sysDate = new Date();
      this.systime = new Timestamp(sysDate.getTime());
      // 機能ID
      this.funcId = ECISTodoConstants.TODO_FUNCTION_ID.SN0101.toString();
      // 更新モジュールコード
      this.updateModuleCode = ThreadContext.getRequestThreadContext()
          .get(ECISConstants.CLASS_NAME_KEY).toString();
      this.mPaymentId = creatingBillingTargetEntityBean.getPaymentId();
      // 請求EntityBean初期化
      this.bl = new Bl();
      this.initBilling();

      // ■計上年月日の取得
      // 請求入金共通ビジネス.計上年月日取得を呼び出す
      this.mRecordedDate = gkWorkCommonBusiness.getRecordedDate(
          this.mBatchDate, this.mBatchDate);

      // ■ 引数.処理フラグ=”解約決定”の場合
      if (ECISSNConstants.CLAIM_COLLECTION_CREATE_BILLING_PROCESSFLG_CANCELLATION_DECISION
          .equals(processFlg)) {

        // ■ 未請求分の【確定料金実績】の取得
        // 請求作成共通DAO.未請求分確定料金実績取得処理を呼び出す。
        Map<String, Object> exampleMap = new HashMap<String, Object>();
        exampleMap.put("contractId", creatingBillingTargetEntityBean.getContractId());
        exampleMap.put("usePeriod", creatingBillingTargetEntityBean.getUsePeriod());
        exampleMap.put("csCode", ECISCodeConstants.CHARGE_STATUS_CODE_FIX);
        exampleMap.put("pmCode", ECISCodeConstants.PROVIDE_MODEL_CODE_DIRECT_MANAGEMENT);
        exampleMap.put("mrReasonCode", ECISCodeConstants.METER_READING_REASON_CODE_NORMAL);
        exampleMap.put("completedFlag", ECISConstants.FLG_OFF);

        List<SN_CreatingBillingTargetEntityBean> unclaimedFixChargeList = snCreatingBillingCommonMapper
            .selectUnclaimedFixCharge(exampleMap);

        // 取得できた場合、リストをマージする。
        if (CollectionUtils.isNotEmpty(unclaimedFixChargeList)) {
          beanList.addAll(unclaimedFixChargeList);
          // 合算請求フラグを《請求EntityBean》に設定する。
          this.bl.setAddUpBlFlag(ECISConstants.FLG_ON);
        }
      }

      // 解約になった契約すべての確定料金実績IDを抽出し、合算要否フラグを更新する。
      // 取得条件を設定
      Map<String, Object> exampleBillingLinkageMap = new HashMap<String, Object>();
      exampleBillingLinkageMap.put("contractId", creatingBillingTargetEntityBean.getContractId());
      exampleBillingLinkageMap.put("blStatusCodeUnpaid", ECISCodeConstants.BILLING_STATUS_CODE_UNPAID);
      exampleBillingLinkageMap.put("blStatusCodeInvalid", ECISCodeConstants.BILLING_STATUS_CODE_INVALID);
      exampleBillingLinkageMap.put("invalidFlagOff", ECISConstants.FLG_OFF);

      List<SN_BillingFixChargeResultBillingLinkageBean> billingFixChargeBillingLinkageEntityBeanList = snBillingCommonMapper
          .selectFixChargeBillingLinkageInfo(exampleBillingLinkageMap);

      // 抽出したレコード分以下を繰り返す。
      for (SN_BillingFixChargeResultBillingLinkageBean fcrBlLnkEntityBean : billingFixChargeBillingLinkageEntityBeanList) {
        // 確定料金・請求連携EntityBeanを生成
        FixChargeBlLinkageExample fixChargeBlLinkageExample = new FixChargeBlLinkageExample();
        FixChargeBlLinkage fixChargeBlLinkage = new FixChargeBlLinkage();

        // 請求ID、確定料金実績ID
        fixChargeBlLinkageExample.createCriteria()
            .andBlIdEqualTo(fcrBlLnkEntityBean.getBillingId())
            .andFcrIdEqualTo(fcrBlLnkEntityBean.getFixChargeResultId());

        // 合算要否フラグ
        fixChargeBlLinkage.setAddUpNeedFlag(ECISConstants.FLG_ON);
        // 更新日時
        fixChargeBlLinkage.setUpdateTime(new Timestamp(System.currentTimeMillis()));
        // 更新モジュールコード
        fixChargeBlLinkage.setUpdateModuleCode(
            ThreadContext.getRequestThreadContext().get(ECISConstants.CLASS_NAME_KEY).toString());

        // 合算要否フラグ更新処理（確定料金・請求連携マッパー.選択項目更新（主キー）呼び出し）
        fixChargeBlLinkageMapper.updateByExampleSelective(fixChargeBlLinkage, fixChargeBlLinkageExample);
      }

      // ■ 契約単位の金額合算処理
      List<SN_CreatingBillingTargetEntityBean> addUpContractList = this
          .addUpContract(
              creatingBillingTargetEntityBean.getContractId(),
              creatingBillingTargetEntityBean.getUsePeriod());

      // 取得できた場合、リストをマージする。
      if (CollectionUtils.isNotEmpty(addUpContractList)) {
        beanList.addAll(addUpContractList);
        // 合算請求フラグを《請求EntityBean》に設定する。
        this.bl.setAddUpBlFlag(ECISConstants.FLG_ON);
      }

      // ■ 引数.処理フラグ=”廃止・解約検針”の場合
      if (ECISSNConstants.CLAIM_COLLECTION_CREATE_BILLING_PROCESSFLG_ABOLITION
          .equals(processFlg)) {

        // 《請求作成対象候補EntityBean》リスト分、以下の処理を繰り返す。
        for (SN_CreatingBillingTargetEntityBean bean : beanList) {
          // ■ 合算対象無効化更新
          this.updateInvalidationAddUpTarget(bean.getBillingId(),
              bean.getFixChargeResultId());

          // ■ 充当予約済の預り金の無効化処理
          this.invalidationDepositsReceived(bean.getBillingNo());
        }

      }

      // ■【確定料金実績】の取得
      List<Fcr> fcrList = new ArrayList<>();
      // リスト分、以下の処理を繰り返す。
      for (SN_CreatingBillingTargetEntityBean bean : beanList) {
        // 【確定料金実績】の取得
        Fcr fcr = fcrMapper.selectByPrimaryKey(bean
            .getFixChargeResultId());
        fcrList.add(fcr);
      }

      // ■請求金額等の算出
      // 請求金額等の算出を呼び出す
      this.calculationBillingAmount(fcrList);

      // ■支払期日の決定
      this.getPaymentFixedDate(null, null);

      // ■請求の作成
      // 《確定料金実績EntityBean》リスト分、以下の処理を繰り返し実施する。
      for (Fcr fcr : fcrList) {
        // 確定料金・請求連携登録処理を呼び出す。
        this.insertFixChargeBillingLinkage(fcr.getFcrId(), false);
      }

      // 請求登録処理
      this.insertBilling(fcrList.get(0));

    } catch (SystemException e) {
      // 例外をそのままスローする。
      throw e;

    } catch (Exception e) {
      // ■異常終了ログ出力
      SystemException se = new SystemException(
          messageSource.getMessage("error.E1166", new String[] {
              this.funcId,
              creatingBillingTargetEntityBean.getContractId()
                  .toString() },
              Locale.getDefault()),
          e);
      throw se;
    }

  }

  /**
   * プロパティ定義クラスを設定する。(DI)
   *
   * @author "Nihon Unisys, Ltd."
   * @param applicationProperties
   *          プロパティ定義クラス
   */
  public void setApplicationProperties(PropertiesFactoryBean applicationProperties) {
    this.applicationProperties = applicationProperties;
  }

  /**
   * 業務共通ビジネスを設定する。（DI）
   *
   * @param gkWorkCommonBusiness
   *          業務共通ビジネス
   */
  public void setGkWorkCommonBusiness(
      GK_WorkCommonBusiness gkWorkCommonBusiness) {
    this.gkWorkCommonBusiness = gkWorkCommonBusiness;
  }

  /**
   * 請求入金共通請求作成ビジネスを設定する。（DI）
   *
   * @param snCreatingBillingCommonBusiness
   *          請求入金共通請求作成ビジネス
   */
  public void setSnCreatingBillingCommonBusiness(
      SN_CreatingBillingCommonBusiness snCreatingBillingCommonBusiness) {
    this.snCreatingBillingCommonBusiness = snCreatingBillingCommonBusiness;
  }

  /**
   * 請求入金共通ビジネスを設定する。（DI）
   *
   * @param snBillingCommonBusiness
   *          請求入金共通ビジネス
   */
  public void setSnBillingCommonBusiness(
      SN_BillingCommonBusiness snBillingCommonBusiness) {
    this.snBillingCommonBusiness = snBillingCommonBusiness;
  }

  /**
   * 日付関連機能ビジネスを設定する。（DI）
   *
   * @param dateBusiness
   *          日付関連機能ビジネス
   */
  public void setDateBusiness(DateBusiness dateBusiness) {
    this.dateBusiness = dateBusiness;
  }

  /**
   * カレンダー関連機能共通ビジネスを設定する。（DI）
   *
   * @param calendarBusiness
   *          カレンダー関連機能共通ビジネス
   */
  public void setCalendarBusiness(CalendarBusiness calendarBusiness) {
    this.calendarBusiness = calendarBusiness;
  }

  /**
   * Todo共通ビジネスを設定する。（DI）
   *
   * @param todoBusiness
   *          Todo共通ビジネス
   */
  public void setTodoBusiness(TodoBusiness todoBusiness) {
    this.todoBusiness = todoBusiness;
  }

  /**
   * 請求入金請求作成共通マッパーを設定する。（DI）
   *
   * @param snCreatingBillingCommonMapper
   *          請求入金請求作成共通マッパー
   */
  public void setSnCreatingBillingCommonMapper(
      SN_CreatingBillingCommonMapper snCreatingBillingCommonMapper) {
    this.snCreatingBillingCommonMapper = snCreatingBillingCommonMapper;
  }

  /**
   * 請求入金共通マッパーを設定する。（DI）
   *
   * @param snCreatingBillingCommonMapper
   *          請求入金請求作成共通マッパー
   */
  public void setSnBillingCommonMapper(
      SN_BillingCommonMapper snBillingCommonMapper) {
    this.snBillingCommonMapper = snBillingCommonMapper;
  }

  /**
   * 業務共通共通マッパーを設定する。（DI）
   *
   * @param gkWorkCommonMapper
   *          業務共通共通マッパー
   */
  public void setGkWorkCommonMapper(
      GK_WorkCommonMapper gkWorkCommonMapper) {
    this.gkWorkCommonMapper = gkWorkCommonMapper;
  }

  /**
   * 請求マッパーを設定する。（DI）
   *
   * @param blMapper
   *          請求マッパー
   */
  public void setBlMapper(BlMapper blMapper) {
    this.blMapper = blMapper;
  }

  /**
   * 確定料金実績マッパーを設定する。（DI）
   *
   * @param fcrMapper
   *          確定料金実績マッパー
   */
  public void setFcrMapper(FcrMapper fcrMapper) {
    this.fcrMapper = fcrMapper;
  }

  /**
   * 確定料金・請求連携マッパーを設定する。（DI）
   *
   * @param fixChargeBlLinkageMapper
   *          確定料金・請求連携マッパー
   */
  public void setFixChargeBlLinkageMapper(
      FixChargeBlLinkageMapper fixChargeBlLinkageMapper) {
    this.fixChargeBlLinkageMapper = fixChargeBlLinkageMapper;
  }

  /**
   * 預り金等マッパーを設定する。（DI）
   *
   * @param dprMapper
   *          預り金等マッパー
   */
  public void setDprMapper(DprMapper dprMapper) {
    this.dprMapper = dprMapper;
  }

  /**
   * 契約マッパーを設定する。（DI）
   *
   * @param contractMapper
   *          契約マッパー
   */
  public void setContractMapper(ContractMapper contractMapper) {
    this.contractMapper = contractMapper;
  }

  /**
   * 支払マッパーを設定する。（DI）
   *
   * @param paymentMapper
   *          支払マッパー
   */
  public void setPaymentMapper(PaymentMapper paymentMapper) {
    this.paymentMapper = paymentMapper;
  }

  /**
   * 業務日程管理マスタマッパーを設定する。（DI）
   *
   * @param workScheduleMngMMapper
   *          業務日程管理マスタマッパー
   */
  public void setWorkScheduleMngMMapper(
      WorkScheduleMngMMapper workScheduleMngMMapper) {
    this.workScheduleMngMMapper = workScheduleMngMMapper;
  }

  /**
   * メッセージソースを設定する。（DI）
   *
   * @param messageSource
   *          メッセージソース
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }

  /**
   * 契約者マッパーを設定する。（DI）
   *
   * @param contractorMapper
   *          契約者マッパー
   */
  public void setContractorMapper(ContractorMapper contractorMapper) {
    this.contractorMapper = contractorMapper;
  }

  /**
   * メール管理共通ビジネスを設定する。（DI）
   *
   * @param mailManagementBusiness
   *          メール管理共通ビジネス
   */
  public void setMailManagementBusiness(
      MailManagementBusiness mailManagementBusiness) {
    this.mailManagementBusiness = mailManagementBusiness;
  }

  /**
   * 請求依頼ファイル作成マッパーを設定する。（DI）
   *
   * @param snCreatingBillingRequestFileMapper
   *          請求依頼ファイル作成マッパー
   */
  public void setSnCreatingBillingRequestFileMapper(
      SN_CreatingBillingRequestFileMapper snCreatingBillingRequestFileMapper) {
    this.snCreatingBillingRequestFileMapper = snCreatingBillingRequestFileMapper;
  }
}
