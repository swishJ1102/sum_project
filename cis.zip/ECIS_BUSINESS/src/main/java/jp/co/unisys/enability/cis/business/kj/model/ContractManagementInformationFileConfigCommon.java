/*-------------------------------------------------------------------------------
 * All Rights Reserved. Copyright(C) Nihon Unisys, Ltd.
 * vendor : Nihon Unisys, Ltd.
 * since : 2015/02/06
 *-----------------------------------------------------------------------------*/
package jp.co.unisys.enability.cis.business.kj.model;

import jp.co.unisys.enability.cis.common.util.EMSConstants;
import jp.sf.orangesignal.csv.CsvConfig;
import jp.sf.orangesignal.csv.QuotePolicy;

/**
 * 契約管理情報アップロードの共通ファイル設定クラス<br>
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * 契約者情報ビジネス<br>
 * 口座クレカ情報ビジネス<br>
 * メータ設置場所情報ビジネス<br>
 * 付帯契約情報ビジネス<br>
 * 契約情報ビジネス<br>
 * 支払情報ビジネス<br>
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class ContractManagementInformationFileConfigCommon {

  /** 共通csvコンフィグ */
  private static CsvConfig csvConfig;

  /** 共通行番号：ヘッダレコード */
  public static final int ROW_NUMBER_HEADER = 0;
  /** 共通行番号：タイトル */
  public static final int ROW_NUMBER_TITLE = 1;
  /** 共通行番号：データレコード */
  public static final int ROW_NUMBER_DATA = 2;

  // ヘッダレコード定義
  /** 共通ヘッダレコード：項目数 */
  public static final int HEADER_COLUMN_COUNT = 2;

  /** 共通ヘッダレコード：レコード種別-インデックス */
  public static final int HEADER_RECORD_KIND_INDEX = 0;
  /** 共通ヘッダレコード：レコード種別-名称 */
  public static final String HEADER_RECORD_KIND_NAME = "ヘッダレコード種別";
  /** 共通ヘッダレコード：レコード種別チェック用文字列 */
  public static final String HEADER_RECORD_KIND_MASK_STRING = "^0$";

  /** 共通ヘッダレコード：ファイル種別-インデックス */
  public static final int HEADER_FILE_KIND_INDEX = 1;
  /** 共通ヘッダレコード：ファイル種別-名称 */
  public static final String HEADER_FILE_KIND_NAME = "ファイル種別";
  /** 共通ヘッダレコード：ファイル種別チェック用文字列 */
  public static final String HEADER_FILE_KIND_MASK_STRING = "^[1-6]+$";

  // データレコード定義
  /** 共通データレコード：行番号(アップロード処理用)-インデックス */
  public static final int DATA_ROW_NO_INDEX = -1;

  /** 共通データレコード：レコード種別-インデックス */
  public static final int DATA_RECORD_KIND_INDEX = 0;
  /** 共通データレコード：レコード種別-名称 */
  public static final String DATA_RECORD_KIND_NAME = "レコード種別";
  /** 共通データレコード：レコード種別-パラメータ */
  public static final String DATA_RECORD_KIND_PARAM = "1";

  /** 共通データレコード：レコード種別チェック用文字列 */
  public static final String DATA_KIND_MASK_STRING = "^1$";

  /** アップロードファイル最小行数 */
  public static final int UPLOAD_FILE_MINIMUM_LINE_COUNT = 3;

  /** ヘッダ行開始行数(実ファイルの行数) */
  public static final int HEADER_START_LINE_NUMBER = 1;

  /** タイトル行開始行数(実ファイルの行数) */
  public static final int TITLE_START_LINE_NUMBER = 2;

  /** データ行開始行数(実ファイルの行数) */
  public static final int DATA_START_LINE_NUMBER = 3;

  /**
   * staticイニシャライザ<br>
   * 共通のCSVコンフィグを設定する
   */
  static {
    CsvConfig config = new CsvConfig();
    // 空行無視
    config.setIgnoreEmptyLines(true);
    // NULL項目はダブルクォートのみで表示
    config.setNullString("\"\"");
    // 改行コードの設定
    config.setLineSeparator(EMSConstants.ENTER_CODE);
    // 囲み文字有効
    config.setQuoteDisabled(false);
    config.setQuotePolicy(QuotePolicy.ALL);
    // 囲み文字をクォートに設定
    config.setQuote(CsvConfig.DEFAULT_QUOTE);
    // エスケープ文字有効
    config.setEscapeDisabled(false);
    // エスケープ文字ダブルクォートを設定
    config.setEscape(CsvConfig.DEFAULT_QUOTE);

    csvConfig = config;
  }

  /** 共通のcsvConfigを取得する */
  public static CsvConfig getCsvConfig() {
    return csvConfig;
  }
}
