package jp.co.unisys.enability.cis.business.sn;

import java.util.Date;

/**
 * 請求入金共通請求依頼ファイル作成ビジネス。
 *
 * @author "Nihon Unisys, Ltd."
 *
 */
public interface SN_CreatingBillingRequestFileBusiness {

  /**
   * 請求依頼ファイル作成処理（口振・クレカ）。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求区分コードが口振またはクレカの請求依頼ファイル対象データを
   * DBより取得し、件数分の請求依頼CSVファイルおよびメール登録を行う。
   * データがない場合はヘッダ部の請求依頼CSVファイルを出力する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param batchDate
   *          バッチ処理基準日
   * @param blCatCode
   *          請求区分コード
   */
  void creatingBillingRequestFileForAccountAndCredit(Date batchDate,
      String blCatCode);

  /**
   * 請求依頼ファイル作成処理（コンビニ）。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求区分コードがコンビニの請求依頼ファイル対象データを
   * DBより取得し、件数分の請求依頼CSVファイルおよびメール登録を行う。
   * データがない場合はヘッダ部の請求依頼CSVファイルを出力する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param batchDate
   *          バッチ処理基準日
   * @param blCatCode
   *          請求区分コード
   */
  void creatingBillingRequestFileForConvenienceStore(Date batchDate,
      String blCatCode);

  /**
   * 請求依頼ファイル作成処理（振込）。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求区分コードが振込の請求依頼ファイル対象データを
   * DBより取得し、件数分の請求依頼CSVファイルおよびメール登録を行う。
   * データがない場合はヘッダ部の請求依頼CSVファイルを出力する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param batchDate
   *          バッチ処理基準日
   * @param blCatCode
   *          請求区分コード
   */
  void creatingBillingRequestFileForTransfer(Date batchDate,
      String blCatCode);

  /**
   * 請求依頼ファイル作成処理（卸／取次事業者）。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求区分コードが卸／取次事業者の請求依頼ファイル対象データを
   * DBより取得し、件数分の請求依頼CSVファイルを行う。
   * データがない場合はヘッダ部の請求依頼CSVファイルを出力する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param batchDate
   *          バッチ処理基準日
   * @param blCatCode
   *          請求区分コード
   */
  void creatingBillingRequestFileForWsAgOp(Date batchDate,
      String blCatCode);

  /**
   * 請求依頼ファイル作成処理（債権回収依頼）。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求区分コードが債権回収依頼の請求依頼ファイル対象データを
   * DBより取得し、件数分の請求依頼CSVファイルを行う。
   * データがない場合はヘッダ部の請求依頼CSVファイルを出力する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param batchDate
   *          バッチ処理基準日
   * @param blCatCode
   *          請求区分コード
   */
  void creatingBillingRequestFileForCommissionCollectionClaim(
      Date batchDate, String blCatCode);
}
