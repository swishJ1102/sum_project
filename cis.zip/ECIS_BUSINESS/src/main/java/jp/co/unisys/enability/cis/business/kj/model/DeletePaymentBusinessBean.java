package jp.co.unisys.enability.cis.business.kj.model;

import java.util.Date;

/**
 * 支払情報削除で、削除条件を格納するビジネスBean
 * 
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * 支払情報ビジネス
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class DeletePaymentBusinessBean {

  /**
   * 支払IDを保有する。
   */
  private Integer paymentId;

  /**
   * 支払番号を保有する。
   */
  private String paymentNo;

  /**
   * 支払適用開始日を保有する。
   */
  private Date paymentStartDate;

  /**
   * 更新回数を保有する。
   */
  private Integer updateCount;

  /**
   * リターンコードを保有する。
   */
  private String returnCode;

  /**
   * メッセージを保有する。
   */
  private String message;

  /**
   * 支払IDのgetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 支払IDを取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 支払ID
   */
  public Integer getPaymentId() {
    return this.paymentId;
  }

  /**
   * 支払IDのsetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 支払IDを設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param paymentId
   *          支払ID
   */
  public void setPaymentId(Integer paymentId) {
    this.paymentId = paymentId;
  }

  /**
   * 支払番号のgetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 支払番号を取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 支払番号
   */
  public String getPaymentNo() {
    return this.paymentNo;
  }

  /**
   * 支払番号のsetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 支払番号を設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param paymentNo
   *          支払番号
   */
  public void setPaymentNo(String paymentNo) {
    this.paymentNo = paymentNo;
  }

  /**
   * 支払適用開始日のgetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 支払適用開始日を取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 支払適用開始日
   */
  public Date getPaymentStartDate() {
    return this.paymentStartDate;
  }

  /**
   * 支払適用開始日のsetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 支払適用開始日を設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param paymentStartDate
   *          支払適用開始日
   */
  public void setPaymentStartDate(Date paymentStartDate) {
    this.paymentStartDate = paymentStartDate;
  }

  /**
   * 更新回数のgetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 更新回数を取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 更新回数
   */
  public Integer getUpdateCount() {
    return this.updateCount;
  }

  /**
   * 更新回数のsetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 更新回数を設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param updateCount
   *          更新回数
   */
  public void setUpdateCount(Integer updateCount) {
    this.updateCount = updateCount;
  }

  /**
   * リターンコードのgetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return リターンコード
   */
  public String getReturnCode() {
    return this.returnCode;
  }

  /**
   * リターンコードのsetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param returnCode
   *          リターンコード
   */
  public void setReturnCode(String returnCode) {
    this.returnCode = returnCode;
  }

  /**
   * メッセージのgetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return メッセージ
   */
  public String getMessage() {
    return this.message;
  }

  /**
   * メッセージのsetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param message
   *          メッセージ
   */
  public void setMessage(String message) {
    this.message = message;
  }

}
