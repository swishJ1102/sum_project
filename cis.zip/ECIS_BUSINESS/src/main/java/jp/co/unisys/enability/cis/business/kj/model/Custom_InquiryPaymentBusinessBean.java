package jp.co.unisys.enability.cis.business.kj.model;

import java.util.Date;
import java.util.List;

import jp.co.unisys.enability.cis.entity.kj.Custom_KJ_InquiryPaymentInformationEntityBean;

//[kg-epj]<d-start>
///**
// * 支払情報照会で、照会結果を格納するビジネスBean
// *
// * <pre>
// * <p><b>【使用ビジネス】</b></p>
// * 支払情報ビジネス
// * 契約情報ビジネス
// * </pre>
// *
// * @author "Nihon Unisys, Ltd."
// */
//public class InquiryPaymentBusinessBean {
//[kg-epj]<d-end>
//[kg-epj]<i-start>
/**
 * 支払情報照会_カスタム
 *
 * @author "Nihon Unisys, Ltd."
 *
 *         変更履歴(kg-epj) 2016.02.15 liu 新規作成
 *
 */
public class Custom_InquiryPaymentBusinessBean {
  //[kg-epj]<i-end>

  /**
   * 支払IDを保有する。
   */
  private Integer paymentId;

  /**
   * 支払番号を保有する。
   */
  private String paymentNo;

  /**
   * 契約者IDを保有する。
   */
  private Integer contractorId;

  /**
   * 契約者番号を保有する。
   */
  private String contractorNo;

  /**
   * 照会対象日付を保有する。
   */
  private Date inqCoveredDate;

  // [kg-epj]<d-start>
  //	/**
  //	 * 支払情報リストを保有する。
  //	 */
  //	private List<KJ_InquiryPaymentInformationEntityBean> paymentInformationList;
  // [kg-epj]<d-end>
  // [kg-epj]<i-start>
  /**
   * 支払情報リストを保有する。
   */
  private List<Custom_KJ_InquiryPaymentInformationEntityBean> paymentInformationList;
  // [kg-epj]<i-end>

  /**
   * リターンコードを保有する。
   */
  private String returnCode;

  /**
   * メッセージを保有する。
   */
  private String message;

  /**
   * 支払IDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 支払IDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 支払ID
   */
  public Integer getPaymentId() {
    return this.paymentId;
  }

  /**
   * 支払IDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 支払IDを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param paymentId
   *          支払ID
   */
  public void setPaymentId(Integer paymentId) {
    this.paymentId = paymentId;
  }

  /**
   * 支払番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 支払番号を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 支払番号
   */
  public String getPaymentNo() {
    return this.paymentNo;
  }

  /**
   * 支払番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 支払番号を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param paymentNo
   *          支払番号
   */
  public void setPaymentNo(String paymentNo) {
    this.paymentNo = paymentNo;
  }

  /**
   * 契約者IDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者IDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者ID
   */
  public Integer getContractorId() {
    return this.contractorId;
  }

  /**
   * 契約者IDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者IDを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorId
   *          契約者ID
   */
  public void setContractorId(Integer contractorId) {
    this.contractorId = contractorId;
  }

  /**
   * 契約者番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者番号を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約者番号
   */
  public String getContractorNo() {
    return this.contractorNo;
  }

  /**
   * 契約者番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者番号を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractorNo
   *          契約者番号
   */
  public void setContractorNo(String contractorNo) {
    this.contractorNo = contractorNo;
  }

  /**
   * 照会対象日付のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 照会対象日付を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 照会対象日付
   */
  public Date getInqCoveredDate() {
    return this.inqCoveredDate;
  }

  /**
   * 照会対象日付のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 照会対象日付を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param inqCoveredDate
   *          照会対象日付
   */
  public void setInqCoveredDate(Date inqCoveredDate) {
    this.inqCoveredDate = inqCoveredDate;
  }

  // [kg-epj]<d-start>
  //	/**
  //	 * 支払情報リストのgetter
  //	 *
  //	 * <pre>
  //	 * <p><b>【仕様詳細】</b></p>
  //	 * 支払情報リストを取得する。
  //	 * </pre>
  //	 *
  //	 * @author "Nihon Unisys, Ltd."
  //	 * @return 支払情報リスト
  //	 */
  //	public List<KJ_InquiryPaymentInformationEntityBean> getPaymentInformationList() {
  //		return this.paymentInformationList;
  //	}
  //
  //	/**
  //	 * 支払情報リストのsetter
  //	 *
  //	 * <pre>
  //	 * <p><b>【仕様詳細】</b></p>
  //	 * 支払情報リストを設定する。
  //	 * </pre>
  //	 *
  //	 * @author "Nihon Unisys, Ltd."
  //	 * @param paymentInformationList
  //	 *            支払情報リスト
  //	 */
  //	public void setPaymentInformationList(
  //			List<KJ_InquiryPaymentInformationEntityBean> paymentInformationList) {
  //		this.paymentInformationList = paymentInformationList;
  //	}
  // [kg-epj]<d-end>
  // [kg-epj]<i-start>
  /**
   * 支払情報リストのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 支払情報リストを取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 支払情報リスト
   */
  public List<Custom_KJ_InquiryPaymentInformationEntityBean> getPaymentInformationList() {
    return this.paymentInformationList;
  }

  /**
   * 支払情報リストのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 支払情報リストを設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param paymentInformationList
   *          支払情報リスト
   */
  public void setPaymentInformationList(
      List<Custom_KJ_InquiryPaymentInformationEntityBean> paymentInformationList) {
    this.paymentInformationList = paymentInformationList;
  }
  // [kg-epj]<i-end>

  /**
   * リターンコードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return リターンコード
   */
  public String getReturnCode() {
    return this.returnCode;
  }

  /**
   * リターンコードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param returnCode
   *          リターンコード
   */
  public void setReturnCode(String returnCode) {
    this.returnCode = returnCode;
  }

  /**
   * メッセージのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return メッセージ
   */
  public String getMessage() {
    return this.message;
  }

  /**
   * メッセージのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param message
   *          メッセージ
   */
  public void setMessage(String message) {
    this.message = message;
  }

}
