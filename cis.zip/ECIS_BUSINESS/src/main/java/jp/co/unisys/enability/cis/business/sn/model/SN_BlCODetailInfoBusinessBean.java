package jp.co.unisys.enability.cis.business.sn.model;

import java.util.Date;
import java.util.List;

import jp.co.unisys.enability.cis.entity.common.Bl;
import jp.co.unisys.enability.cis.entity.common.Contractor;
import jp.co.unisys.enability.cis.entity.common.PaymentHist;

public class SN_BlCODetailInfoBusinessBean extends SN_CreateMailBusinessBean {

  /** 《請求EntityBean》 */
  private Bl bl;

  /** 《契約者EntityBean》 */
  private Contractor contractor;

  /** 《支払履歴EntityBean》 */
  private PaymentHist paymentHist;

  /** 複数月まとめ請求額閾値 */
  private Long threshold;

  /** メール送信日 */
  private Date mailSendDate;

  /** 消費税等相当額 */
  private Long ctEquivalent;

  /** 全契約番号リスト */
  private List<String> contractNoList;

  /** 全利用年月リスト */
  private List<String> usePeriodList;

  /**
   * 《請求EntityBean》を設定する。
   *
   * @param bl
   *          《請求EntityBean》
   */
  public void setBl(Bl bl) {
    this.bl = bl;
  }

  /**
   * 《請求EntityBean》を取得する。
   *
   * @return 《請求EntityBean》
   */
  public Bl getBl() {
    return this.bl;
  }

  /**
   * 《契約者EntityBean》を設定する。
   *
   * @param contractor
   *          《契約者EntityBean》
   */
  public void setContractor(Contractor contractor) {
    this.contractor = contractor;
  }

  /**
   * 《契約者EntityBean》を取得する。
   *
   * @return 《契約者EntityBean》
   */
  public Contractor getContractor() {
    return this.contractor;
  }

  /**
   * 《支払履歴EntityBean》を設定する。
   *
   * @param paymentHist
   *          《支払履歴EntityBean》
   */
  public void setPaymentHist(PaymentHist paymentHist) {
    this.paymentHist = paymentHist;
  }

  /**
   * 《支払履歴EntityBean》を取得する。
   *
   * @return 《支払履歴EntityBean》
   */
  public PaymentHist getPaymentHist() {
    return this.paymentHist;
  }

  /**
   * メール送信日を設定する。
   *
   * @param mailSendDate
   *          メール送信日
   */
  public void setMailSendDate(Date mailSendDate) {
    this.mailSendDate = mailSendDate;
  }

  /**
   * メール送信日を取得する。
   *
   * @return メール送信日
   */
  public Date getMailSendDate() {
    return this.mailSendDate;
  }

  /**
   * 複数月まとめ請求額閾値を設定する。
   *
   * @param Threshold
   *          複数月まとめ請求額閾値
   */
  public Long getThreshold() {
    return threshold;
  }

  /**
   * 複数月まとめ請求額閾値を取得する。
   *
   * @return 複数月まとめ請求額閾値
   */
  public void setThreshold(Long threshold) {
    this.threshold = threshold;
  }

  /**
   * 消費税等相当額を設定する。
   *
   * @param ctEquivalent
   *          消費税等相当額
   */
  public void setCtEquivalent(Long ctEquivalent) {
    this.ctEquivalent = ctEquivalent;
  }

  /**
   * 消費税等相当額を取得する。
   *
   * @return 消費税等相当額
   */
  public Long getCtEquivalent() {
    return this.ctEquivalent;
  }

  /**
   * 全契約番号リストを設定する。
   *
   * @param contractNoList
   *          全契約番号リスト
   */
  public void setContractNoList(List<String> contractNoList) {
    this.contractNoList = contractNoList;
  }

  /**
   * 全契約番号リストを取得する。
   *
   * @return 全契約番号リスト
   */
  public List<String> getContractNoList() {
    return this.contractNoList;
  }

  /**
   * 全利用年月を取得する。
   *
   * @return 全利用年月
   */
  public List<String> getUsePeriodList() {
    return usePeriodList;
  }

  /**
   * 全利用年月リストを設定する。
   *
   * @param usePeriodList
   *          全利用年月リスト
   */
  public void setUsePeriodList(List<String> usePeriodList) {
    this.usePeriodList = usePeriodList;
  }

}
