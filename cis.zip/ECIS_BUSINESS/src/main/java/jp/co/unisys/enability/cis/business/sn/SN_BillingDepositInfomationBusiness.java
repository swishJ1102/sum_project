package jp.co.unisys.enability.cis.business.sn;

import jp.co.unisys.enability.cis.business.sn.model.InquiryBillingDepositBusinessBean;

/**
 * 請求入金情報ビジネスインターフェース。
 *
 * @author "Nihon Unisys, Ltd."
 *
 */
public interface SN_BillingDepositInfomationBusiness {

  /**
   * 請求入金情報の取得を行う。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者毎の請求、入金および督促の情報を返却する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param inquiryBillingDepositBusinessBean
   *          請求入金情報照会BusinessBean
   * @return 請求入金情報照会BusinessBean
   */
  public InquiryBillingDepositBusinessBean inquiry(
      InquiryBillingDepositBusinessBean inquiryBillingDepositBusinessBean);
}
