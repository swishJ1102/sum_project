package jp.co.unisys.enability.cis.business.gk;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.dao.DataAccessException;

import jp.co.unisys.enability.cis.business.gk.model.Custom_InquiryRenewableEnergyChargeUnitPriceBusinessBean;
import jp.co.unisys.enability.cis.common.util.KJ_CommonUtil;
import jp.co.unisys.enability.cis.common.util.constants.ECISKJConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISReturnCodeConstants;
import jp.co.unisys.enability.cis.entity.common.RecUpM;
import jp.co.unisys.enability.cis.entity.common.RecUpMExample;
import jp.co.unisys.enability.cis.mapper.common.RecUpMMapper;

/**
 * 再エネ単価情報ビジネス_カスタム
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.gk.Custom_RenewableEnergyChargeUnitPriceInformationBusiness
 *
 *      変更履歴(kg-epj) 2016.02.04 ko 新規作成
 */
public class Custom_RenewableEnergyChargeUnitPriceInformationBusinessImpl
    implements Custom_RenewableEnergyChargeUnitPriceInformationBusiness {

  /**
   * 再エネ単価マッパー(DI)
   */
  private RecUpMMapper recUpMMapper;

  /**
   * メッセージプロパティ(DI)
   */
  private MessageSource messageSource;

  /**
   * ログマネジャー
   */
  private static Logger logger = LogManager.getLogger();

  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.business.gk.Custom_RenewableEnergyChargeUnitPriceInformationBusiness#inquiryRenewableEnergyChargeUnitPrice(jp.co.unisys.enability.cis.business.gk.model.Custom_InquiryRenewableEnergyChargeUnitPriceBusinessBean)
   */
  @Override
  public Custom_InquiryRenewableEnergyChargeUnitPriceBusinessBean inquiryRenewableEnergyChargeUnitPrice(
      Custom_InquiryRenewableEnergyChargeUnitPriceBusinessBean businessBean) {

    // エラーメッセージを定義する。
    String errorMessage = null;
    // 返却用ビジネスBeanを生成する。
    Custom_InquiryRenewableEnergyChargeUnitPriceBusinessBean returnBusinessBean = new Custom_InquiryRenewableEnergyChargeUnitPriceBusinessBean();

    try {
      // 引数取得
      // エリアコードを取得する
      String areaCode = businessBean.getAreaCode();
      // 取得対象年月リストを取得する
      List<String> targetPeriodList = businessBean.getTargetPeriodList();

      // リターンコード(G017)に対応するメッセージを取得する。
      errorMessage = messageSource.getMessage(KJ_CommonUtil.getMessageId(
          ECISReturnCodeConstants.RETURN_CODE_G017), new String[] {},
          Locale.getDefault());

      // パラメータチェック
      // 引数.取得対象年月リストがNULLまたは0件の場合、以下の処理を行う
      if (CollectionUtils.isEmpty(targetPeriodList)) {
        // リターンコード（P001）と対応するメッセージを設定し、返却する。
        returnBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P001);
        returnBusinessBean.setMessage(messageSource.getMessage(KJ_CommonUtil.getMessageId(
            ECISReturnCodeConstants.RETURN_CODE_P001),
            new String[] {}, Locale.getDefault()));

        return returnBusinessBean;
      }

      // 戻り値.年月単価情報マップを生成する。
      Map<String, Map<String, RecUpM>> periodUpMap = new HashMap<String, Map<String, RecUpM>>();

      // 引数.取得対象年月リストの件数分、以下の処理を行う。
      for (String targetPeriod : targetPeriodList) {

        // 再エネ単価Exampleを生成し、以下の検索条件を設定する。
        RecUpMExample example = new RecUpMExample();
        // エリアコードを判定し、nullまたは空文字の場合、利用年月のみ設定する。
        if (StringUtils.isEmpty(areaCode)) {
          // 利用年月を設定する
          example.createCriteria().andUsePeriodEqualTo(targetPeriod);

          // 指定された場合、利用年月とエリアコードを設定する。
        } else {
          // 利用年月とエリアコードを設定する
          example.createCriteria().andUsePeriodEqualTo(targetPeriod).andAreaCodeEqualTo(areaCode);
        }

        // 再エネ単価情報リストを取得する。
        List<RecUpM> recUpMList = recUpMMapper.selectByExample(example);

        // 変数.再エネ単価マップを生成する
        Map<String, RecUpM> recUpMMap = new HashMap<String, RecUpM>();

        // 取得した再エネ単価情報リストの件数分、以下の処理を行う。
        for (RecUpM recUpM : recUpMList) {
          // 再エネ単価情報.エリアコードをキーに、変数.再エネ単価マップに再エネ単価情報を設定する。
          recUpMMap.put(recUpM.getAreaCode(), recUpM);
        }

        // 処理中の取得対象利用年月をキーに、変数.再エネ単価マップを戻り値.年月単価情報マップに設定する。
        periodUpMap.put(targetPeriod, recUpMMap);
      }

      // 戻り値設定
      // 戻り値.年月単価情報マップをBusinessBeanに設定する。
      returnBusinessBean.setPeriodUpMap(periodUpMap);
      // リターンコード(0000)を設定する。
      returnBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);

    } catch (NoSuchMessageException e) {
      // メッセージ検索例外が発生した場合、以下の処理を行う。
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, e);
      returnBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      returnBusinessBean.setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);

    } catch (DataAccessException e) {
      // データアクセスエラーが発生した場合、以下の処理を行う。
      logger.error(errorMessage, e);
      returnBusinessBean.setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      returnBusinessBean.setMessage(errorMessage);
    }

    // 返却する
    return returnBusinessBean;
  }

  /**
   * 再エネ単価マッパーのセッター(DI)
   *
   * @param recUpMMapper
   *          再エネ単価マッパー
   */
  public void setRecUpMMapper(RecUpMMapper recUpMMapper) {
    this.recUpMMapper = recUpMMapper;
  }

  /**
   * messageSourceのセッター(DI)
   *
   * @param messageSource
   *          メッセージソース
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }
}
