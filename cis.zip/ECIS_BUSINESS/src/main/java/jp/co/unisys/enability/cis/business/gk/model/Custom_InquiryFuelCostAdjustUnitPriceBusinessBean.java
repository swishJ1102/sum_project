package jp.co.unisys.enability.cis.business.gk.model;

import java.util.Date;
import java.util.List;
import java.util.Map;

import jp.co.unisys.enability.cis.entity.common.FcaUpM;

/**
 * 燃調単価情報照会BusinessBean_カスタム
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * 燃調単価情報ビジネス_カスタム
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 *
 *         変更履歴(kg-epj) 2016.02.04 ko 新規作成
 */
public class Custom_InquiryFuelCostAdjustUnitPriceBusinessBean {

  /**
   * エリアコードを保有する。
   */
  private String areaCode;

  /**
   * 契約IDを保有する。
   */
  private Integer contractId;

  /**
   * 取得対象日リストを保有する。
   */
  private List<Date> targetDateList;

  /**
   * 対象日付単価情報マップを保有する。
   */
  private Map<Date, Map<String, FcaUpM>> dateUpMap;

  /**
   * 燃調単価取得方法区分を保有する。
   */
  private String fcaUpGetWayCategory;

  /**
   * 利用年月マップを保有する。
   */
  private Map<Date, String> usePeriodMap;

  /**
   * リターンコードを保有する。
   */
  private String returnCode;

  /**
   * メッセージを保有する。
   */
  private String message;

  /**
   * エリアコードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * エリアコードを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return エリアコード
   */
  public String getAreaCode() {
    return this.areaCode;
  }

  /**
   * エリアコードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * エリアコードを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param areaCode
   *          エリアコード
   */
  public void setAreaCode(String areaCode) {
    this.areaCode = areaCode;
  }

  /**
   * 契約IDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約IDを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約ID
   */
  public Integer getContractId() {
    return this.contractId;
  }

  /**
   * 契約IDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約IDを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractId
   *          契約ID
   */
  public void setContractId(Integer contractId) {
    this.contractId = contractId;
  }

  /**
   * 取得対象日リストのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 取得対象日リストを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 取得対象日リスト
   */
  public List<Date> getTargetDateList() {
    return this.targetDateList;
  }

  /**
   * 取得対象日リストのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 取得対象日リストを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param targetDateList
   *          取得対象日リスト
   */
  public void setTargetDateList(List<Date> targetDateList) {
    this.targetDateList = targetDateList;
  }

  /**
   * 対象日付単価情報マップのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 対象日付単価情報マップを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 対象日付単価情報マップ
   */
  public Map<Date, Map<String, FcaUpM>> getDateUpMap() {
    return this.dateUpMap;
  }

  /**
   * 対象日付単価情報マップのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 対象日付単価情報マップを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param dateUpMap
   *          対象日付単価情報マップ
   */
  public void setDateUpMap(Map<Date, Map<String, FcaUpM>> dateUpMap) {
    this.dateUpMap = dateUpMap;
  }

  /**
   * 燃調単価取得方法区分のgetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 燃調単価取得方法区分を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 燃調単価取得方法区分
   */
  public String getFcaUpGetWayCategory() {
    return this.fcaUpGetWayCategory;
  }

  /**
   * 燃調単価取得方法区分のsetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 燃調単価取得方法区分を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param fcaUpGetWayCategory
   *          燃調単価取得方法区分
   */
  public void setFcaUpGetWayCategory(String fcaUpGetWayCategory) {
    this.fcaUpGetWayCategory = fcaUpGetWayCategory;
  }

  /**
   * 利用年月マップのgetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 利用年月マップを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 利用年月マップ
   */
  public Map<Date, String> getUsePeriodMap() {
    return this.usePeriodMap;
  }

  /**
   * 利用年月マップのsetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 利用年月マップを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param usePeriodMap
   *          利用年月マップ
   */
  public void setUsePeriodMap(Map<Date, String> usePeriodMap) {
    this.usePeriodMap = usePeriodMap;
  }

  /**
   * リターンコードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return リターンコード
   */
  public String getReturnCode() {
    return this.returnCode;
  }

  /**
   * リターンコードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param returnCode
   *          リターンコード
   */
  public void setReturnCode(String returnCode) {
    this.returnCode = returnCode;
  }

  /**
   * メッセージのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return メッセージ
   */
  public String getMessage() {
    return this.message;
  }

  /**
   * メッセージのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param message
   *          メッセージ
   */
  public void setMessage(String message) {
    this.message = message;
  }
}