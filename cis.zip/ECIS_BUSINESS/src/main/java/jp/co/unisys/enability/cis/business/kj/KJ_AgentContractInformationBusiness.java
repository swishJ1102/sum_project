package jp.co.unisys.enability.cis.business.kj;

import jp.co.unisys.enability.cis.business.kj.model.AddAgentContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.DeleteAgentContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.InquiryAgentContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.RegistAgentContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.UpdateAgentContractBusinessBean;

/**
 * 契約情報ビジネスインターフェース。
 *
 * @author "Nihon Unisys, Ltd."
 *
 */
public interface KJ_AgentContractInformationBusiness {

  /**
   * 契約情報照会を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者に紐付く契約情報の一覧、または指定された契約情報を取得する。
   * 一覧の場合、指定により、現在以降有効な契約情報、または過去を含む全履歴の契約情報を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param inquiryContractBusinessBean
   *          契約情報照会BusinessBean
   * @return 契約情報照会BusinessBean
   */
  public InquiryAgentContractBusinessBean inquiry(
      InquiryAgentContractBusinessBean inquiryContractBusinessBean);

  /**
   * 契約情報エンティティより契約情報を登録する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約情報エンティティより契約情報を登録する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param registContractBusinessBean
   *          契約情報登録BusinessBean
   * @return 契約情報登録BusinessBean
   *
   */
  public RegistAgentContractBusinessBean regist(
      RegistAgentContractBusinessBean registContractBusinessBean);

  /**
   * 契約情報更新を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 指定された契約情報を更新する。確定された料金実績が存在しているかどうかをチェックし、
   * 存在していた場合、更新不可とする。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param updateContractBusinessBean
   *          契約情報更新BusinessBean
   * @return 契約情報更新BusinessBean
   */
  public UpdateAgentContractBusinessBean update(
      UpdateAgentContractBusinessBean updateContractBusinessBean);

  /**
   * 契約情報削除を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 指定された契約情報を削除する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param deleteContractBusinessBean
   *          契約情報削除BusinessBean
   * @return 契約情報削除BusinessBean
   */
  public DeleteAgentContractBusinessBean delete(
      DeleteAgentContractBusinessBean deleteContractBusinessBean);

  /**
   * 契約情報追加を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 既に契約をしているお客様が別需要場所で契約申込をする際に契約情報を追加登録する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param addContractBusinessBean
   *          契約情報追加BusinessBean
   * @return 契約情報追加BusinessBean
   */
  public AddAgentContractBusinessBean add(
      AddAgentContractBusinessBean addContractBusinessBean);
}
