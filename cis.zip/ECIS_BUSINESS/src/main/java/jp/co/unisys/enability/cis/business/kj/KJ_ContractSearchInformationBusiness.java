package jp.co.unisys.enability.cis.business.kj;

import jp.co.unisys.enability.cis.business.kj.model.SearchContractBusinessBean;

/**
 * 契約情報ビジネスインターフェース。
 *
 * @author "Nihon Unisys, Ltd."
 *
 */
public interface KJ_ContractSearchInformationBusiness {

  /**
   * 契約情報の検索を行う。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * CRMや低圧CISからのオーダーにより、契約者および契約を特定するように検索し、検索結果を返却する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param searchContractBusinessn
   *          契約情報検索BusinessBean
   * @return 契約情報検索BusinessBean
   */
  public SearchContractBusinessBean search(SearchContractBusinessBean searchContractBusiness);

}
