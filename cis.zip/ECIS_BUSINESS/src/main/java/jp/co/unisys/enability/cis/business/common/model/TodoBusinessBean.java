/*-------------------------------------------------------------------------------
 * All Rights Reserved. Copyright(C) Nihon Unisys, Ltd.
 * vendor : Nihon Unisys, Ltd.
 * since : 2015/07/10
 *-----------------------------------------------------------------------------*/
package jp.co.unisys.enability.cis.business.common.model;

import java.io.Serializable;
import java.util.Date;

/**
 * TODO共通で、登録条件を格納するビジネスBean
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * TODO共通ビジネス
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class TodoBusinessBean implements Serializable {

  /**
   * サブシステムID
   */
  private String subsystemId;

  /**
   * 機能ID
   */
  private String functionId;

  /**
   * メッセージID
   */
  private String messageId;

  /**
   * メッセージ
   */
  private String message;

  /**
   * 備考
   */
  private String note;
  
  /**
   * 契約者番号
   */
  private String contractorNo;

  /**
   * 契約番号
   */
  private String contractNo;

  /**
   * 地点特定番号
   */
  private String spotNo;

  /**
   * 次回検針予定日
   */
  private Date nextMrScheduledDate;

  public String getSubsystemId() {
    return subsystemId;
  }

  public void setSubsystemId(String subsystemId) {
    this.subsystemId = subsystemId;
  }

  public String getFunctionId() {
    return functionId;
  }

  public void setFunctionId(String functionId) {
    this.functionId = functionId;
  }

  public String getMessageId() {
    return messageId;
  }

  public void setMessageId(String messageId) {
    this.messageId = messageId;
  }

  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  public String getNote() {
    return note;
  }

  public void setNote(String note) {
    this.note = note;
  }
  
  public String getContractorNo() {
    return contractorNo;
  }

  public void setContractorNo(String contractorNo) {
    this.contractorNo = contractorNo;
  }

  public String getContractNo() {
    return contractNo;
  }

  public void setContractNo(String contractNo) {
    this.contractNo = contractNo;
  }

  public String getSpotNo() {
    return spotNo;
  }

  public void setSpotNo(String spotNo) {
    this.spotNo = spotNo;
  }

  public Date getNextMrScheduledDate() {
    return nextMrScheduledDate;
  }

  public void setNextMrScheduledDate(Date nextMrScheduledDate) {
    this.nextMrScheduledDate = nextMrScheduledDate;
  }
}
