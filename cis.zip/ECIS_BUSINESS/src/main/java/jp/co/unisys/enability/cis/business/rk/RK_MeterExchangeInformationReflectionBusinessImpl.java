package jp.co.unisys.enability.cis.business.rk;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.MessageSource;

import jp.co.unisys.enability.cis.common.util.ThreadContext;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;
import jp.co.unisys.enability.cis.entity.common.FixIn;
import jp.co.unisys.enability.cis.entity.common.FixInExample;
import jp.co.unisys.enability.cis.entity.common.Fu;
import jp.co.unisys.enability.cis.entity.common.FuExample;
import jp.co.unisys.enability.cis.entity.common.McSmrDetail2;
import jp.co.unisys.enability.cis.entity.common.McSmrDetail2Example;
import jp.co.unisys.enability.cis.entity.common.McSmrInfo;
import jp.co.unisys.enability.cis.entity.common.McSmrInfoExample;
import jp.co.unisys.enability.cis.mapper.common.FixInMapper;
import jp.co.unisys.enability.cis.mapper.common.FuMapper;
import jp.co.unisys.enability.cis.mapper.common.McSmrDetail2Mapper;
import jp.co.unisys.enability.cis.mapper.common.McSmrInfoMapper;

/**
 * 計量器交換情報反映ビジネスクラス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_MeterExchangeInformationReflectionBusinessImpl implements
    RK_MeterExchangeInformationReflectionBusiness {

  /** 確定使用量共通ビジネス(DI) */
  private RK_FixUsageCommonBusiness rkFixUsageCommonBusiness;

  /** 計器交換・臨時検針情報Mapper(DI) */
  private McSmrInfoMapper mcSmrInfoMapper;

  /** 計器交換・臨時検針情報明細2Mapper(DI) */
  private McSmrDetail2Mapper mcSmrDetail2Mapper;

  /** 確定使用量Mapper(DI) */
  private FuMapper fuMapper;

  /** 確定指示数Mapper(DI) */
  private FixInMapper fixInMapper;

  /** メッセージリソース(DI) */
  private MessageSource messageSource;

  /** ロガーインスタンス */
  private static final Logger logger = LogManager.getLogger();

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.rk.
   * RK_MeterExchangeInformationReflectionBusiness
   * #meterExchangeInformationReflection(jp.co.unisys.enability
   * .cis.business.rk.model.RK_FixUsageApplyDataBusinessBean)
   */
  @Override
  public void meterExchangeInformationReflection(Integer contractId,
      String coveredPeriod) {

    // 更新用のシステム日付・モジュールコード・ユーザIDを取得
    Timestamp timestamp = new Timestamp(new Date().getTime());
    String moduleCode = (String) ThreadContext.getRequestThreadContext()
        .get(ECISConstants.CLASS_NAME_KEY);
    String userId = ThreadContext.getRequestThreadContext()
        .get(ECISConstants.USER_ID_KEY).toString();

    // 計器交換・臨時検針情報を取得する
    // 計器交換・臨時検針情報Example
    McSmrInfoExample mcSmrInfoExample = new McSmrInfoExample();

    // 【計器交換・臨時検針情報】の取得条件を設定
    mcSmrInfoExample.createCriteria()
        // 契約ID
        .andContractIdEqualTo(contractId)
        // 対象年月
        .andCoveredPeriodEqualTo(coveredPeriod)
        // ファイル名(先頭4桁)
        .andFileNameLike("W513%");
    // 並び替え：ファイル名（降順）
    mcSmrInfoExample.setOrderByClause(ECISRKConstants.FILE_NAME_DESC);

    // 【計器交換・臨時検針情報】を取得
    List<McSmrInfo> mcSmrInfoList = mcSmrInfoMapper
        .selectByExample(mcSmrInfoExample);

    // 変数定義
    int mcmrId = 0;

    // 計器交換・臨時検針情報リストの件数チェック
    if (mcSmrInfoList.size() == 0) {
      // 件数が0件の場合
      // 処理終了
      return;
    }
    // 1件目を取得
    mcmrId = mcSmrInfoList.get(0).getMcMrId();
    if (mcSmrInfoList.size() >= 2) {
      // 件数が2件以上の場合
      Date mrDate = mcSmrInfoList.get(0).getMrDate();
      for (int i = 1; i < mcSmrInfoList.size(); i++) {
        if (mrDate.compareTo(mcSmrInfoList.get(i).getMrDate()) != 0) {
          // 検針日が一致しない場合
          logger.info(messageSource.getMessage("info.I1041",
              new Object[] {contractId, coveredPeriod },
              Locale.getDefault()));
          return;
        }
      }
    }

    // 計器交換・臨時検針情報明細２を取得する
    // 計器交換・臨時検針情報明細２Example
    McSmrDetail2Example mcSmrDetail2Example = new McSmrDetail2Example();

    // 【計器交換・臨時検針情報明細2】の取得条件を設定
    mcSmrDetail2Example.createCriteria()
        // 計器交換・臨時検針情報ID
        .andMcMrIdEqualTo(mcmrId);

    // 【計器交換・臨時検針情報明細2】を取得
    List<McSmrDetail2> mcSmrDetail2List = mcSmrDetail2Mapper
        .selectByExample(mcSmrDetail2Example);

    // 計器交換・臨時検針情報明細2リストの件数チェック
    if (mcSmrDetail2List.size() == 2) {
      // 件数が2件の場合
      // 計器交換・臨時検針情報明細2リストの要素数毎にチェックを行う。
      for (int i = 0; i < mcSmrDetail2List.size(); i++) {
        if (mcSmrDetail2List.get(i).getEffectiveIn() == null
            || mcSmrDetail2List.get(i).getReactiveIn() == null) {
          // 力測有効電力量指示数 または 力測無効電力量指示数がnullの場合
          logger.info(messageSource.getMessage("info.I1042",
              new Object[] {contractId, coveredPeriod, mcSmrInfoList.get(0).getFileName() },
              Locale.getDefault()));
          return;
        }
      }
    } else {
      // 上記以外の場合
      logger.info(messageSource.getMessage("info.I1040",
          new Object[] {contractId, coveredPeriod },
          Locale.getDefault()));
      return;
    }

    // 確定使用量を取得
    // 確定使用量Example
    FuExample fuExample = new FuExample();

    // 【確定使用量】の取得条件を設定
    fuExample.createCriteria()
        // 計器交換・臨時検針情報ID
        .andContractIdEqualTo(contractId)
        // 計器交換・臨時検針情報ID
        .andUsePeriodEqualTo(coveredPeriod);
    // 並び替え：確定使用量ID（降順）
    fuExample.setOrderByClause(ECISRKConstants.FU_ID_DESC);
    // 【確定使用量】を取得
    List<Fu> fuList = fuMapper.selectByExample(fuExample);

    // 確定使用量リストの件数チェック
    if (fuList.size() == 0) {
      // 処理終了
      return;
    }
    // 確定使用量リストからもっとも最新の確定使用量IDを取得する
    Fu fu = fuList.get(0);
    // 最新の確定使用量から確定使用量IDを取得する
    int fuId = fu.getFuId();

    // 確定指示数を取得する
    // 確定指示数Example
    FixInExample fixInExample = new FixInExample();

    // 【確定指示数】の取得条件を設定
    fixInExample.createCriteria()
        // 計器交換・臨時検針情報ID
        .andFuIdEqualTo(fuId)
        .andMeterCatCodeEqualTo(ECISRKConstants.METER_CATEGORY_CODE_FOR_IN_COMMON);

    // 【確定指示数】を取得
    List<FixIn> fixInList = fixInMapper.selectByExample(fixInExample);

    // 確定指示数リストの件数チェック
    if (fixInList.size() != 1) {
      // 1件以外の場合
      // エラーログを出力
      logger.error(messageSource.getMessage("error.E1613",
          new Object[] {contractId, coveredPeriod },
          Locale.getDefault()));
      return;
    }

    // 「力測有効電力量指示数算出使用量」および「力測無効電力量指示数算出使用量」を算出
    // 力測有効電力量前月指示数設定
    BigDecimal effectivePreviousIndicationNo = fixInList.get(0)
        .getEffectivePreviousIndicationNo();
    // 力測無効電力量前月指示数設定
    BigDecimal reactivePreviousIndicationNo = fixInList.get(0)
        .getReactivePreviousIndicationNo();
    // 力測有効電力量当月指示数設定
    BigDecimal effectiveCurrentIndicationNo = fixInList.get(0)
        .getEffectiveCurrentIndicationNo();
    // 力測無効電力量当月指示数設定
    BigDecimal reactiveCurrentIndicationNo = fixInList.get(0)
        .getReactiveCurrentIndicationNo();
    // 変数定義
    BigDecimal oldMeterUseElectrical1 = BigDecimal.ZERO;
    BigDecimal oldMeterUseElectrical2 = BigDecimal.ZERO;
    BigDecimal newMeterUseElectrical1 = BigDecimal.ZERO;
    BigDecimal newMeterUseElectrical2 = BigDecimal.ZERO;
    // リスト要素毎に処理を行う
    for (int i = 0; i < mcSmrDetail2List.size(); i++) {
      // 変数定義
      int multiplyingFactor = 0;
      BigDecimal kwhdisAdvantageFactor = BigDecimal.ZERO;
      // 乗率の判定
      if (mcSmrDetail2List.get(i).getMultiplyingFactor() == null) {
        // nullの場合
        multiplyingFactor = 1;
      } else {
        // null以外の場合
        multiplyingFactor = mcSmrDetail2List.get(i).getMultiplyingFactor();
      }

      // 損失補正率の計算
      if (mcSmrDetail2List.get(i).getKwhDisadvantageFactor() == null) {
        // nullの場合
        kwhdisAdvantageFactor = BigDecimal.ONE;
      } else {
        // null以外の場合
        kwhdisAdvantageFactor = mcSmrDetail2List.get(i)
            .getKwhDisadvantageFactor()
            .divide(new BigDecimal("100")).add(BigDecimal.ONE);
      }

      // 取付取外区分コードチェック
      if (ECISRKConstants.METER_CHANGE_CATEGORY_CODE_DETACHING_2
          .equals(mcSmrDetail2List.get(i).getMeterChangeCategoryCode())) {
        // 取付取外区分コードが"2"(取外)の場合
        // 旧計器使用電力量1
        oldMeterUseElectrical1 = rkFixUsageCommonBusiness
            .roundUsage(this.calcDiffIn(
                mcSmrDetail2List.get(i).getEffectiveIn(),
                effectivePreviousIndicationNo).multiply(
                    new BigDecimal(String
                        .valueOf(multiplyingFactor))
                            .multiply(kwhdisAdvantageFactor)));
        // 旧計器使用電力量2
        oldMeterUseElectrical2 = rkFixUsageCommonBusiness
            .roundUsage(this.calcDiffIn(
                mcSmrDetail2List.get(i).getReactiveIn(),
                reactivePreviousIndicationNo).multiply(
                    new BigDecimal(String
                        .valueOf(multiplyingFactor))
                            .multiply(kwhdisAdvantageFactor)));

      } else if (ECISRKConstants.METER_CHANGE_CATEGORY_CODE_MOUNTING_1
          .equals(mcSmrDetail2List.get(i).getMeterChangeCategoryCode())) {
        // 取付取外区分コードが"1"(取付)の場合
        // 新計器使用電力量1
        newMeterUseElectrical1 = rkFixUsageCommonBusiness
            .roundUsage(this
                .calcDiffIn(
                    effectiveCurrentIndicationNo,
                    mcSmrDetail2List.get(i)
                        .getEffectiveIn())
                .multiply(
                    new BigDecimal(
                        String.valueOf(multiplyingFactor))
                            .multiply(kwhdisAdvantageFactor)));

        // 新計器使用電力量2
        newMeterUseElectrical2 = rkFixUsageCommonBusiness
            .roundUsage(this
                .calcDiffIn(
                    reactiveCurrentIndicationNo,
                    mcSmrDetail2List.get(i)
                        .getReactiveIn())
                .multiply(
                    new BigDecimal(
                        String.valueOf(multiplyingFactor))
                            .multiply(kwhdisAdvantageFactor)));
      }
    }

    // 力測有効電力量指示数算出使用量算出
    BigDecimal effectiveIndicationNoCalculationUsage = oldMeterUseElectrical1
        .add(newMeterUseElectrical1);
    // 力測無効電力量指示数算出使用量算出
    BigDecimal reactiveIndicationNoCalculationUsage = oldMeterUseElectrical2
        .add(newMeterUseElectrical2);

    // リストから更新対象のレコードを1件取得
    FixIn fixIn = fixInList.get(0);

    // 更新対象の値を設定する。
    // 全日電力量指示数差
    fixIn.setInDifference(null);
    // 乗率
    fixIn.setMultiplyingFactor(null);
    // 損失補正率
    fixIn.setKwhDisadvantageFactor(null);
    // 力測有効電力量指示数差
    fixIn.setEffectiveIndicationNoDifference(null);
    // 力測有効電力量指示数算出使用量
    fixIn.setEffectiveIndicationNoCalculationUsage(effectiveIndicationNoCalculationUsage);
    // 力測無効電力量指示数差
    fixIn.setReactiveIndicationNoDifference(null);
    // 力測無効電力量指示数算出使用量
    fixIn.setReactiveIndicationNoCalculationUsage(reactiveIndicationNoCalculationUsage);
    // 更新回数
    fixIn.setUpdateCount(fixInList.get(0).getUpdateCount() + 1);
    // オンライン更新日時
    fixIn.setOnlineUpdateTime(timestamp);
    // オンライン更新ユーザID
    fixIn.setOnlineUpdateUserId(userId);
    // 更新日時
    fixIn.setUpdateTime(timestamp);
    // 更新モジュールコード
    fixIn.setUpdateModuleCode(moduleCode);

    // 更新処理
    fixInMapper.updateByExample(fixIn, fixInExample);
  }

  /**
   * 指示数差補正メソッド<br>
   * 指示数差がマイナスの場合にメータ一周加算値を加算して、指示数差を補正する
   *
   * @param base
   *          当月指示数
   * @param previous
   *          前月指示数
   * @return メータ一周加算値を加算した指示数差
   */
  private BigDecimal calcDiffIn(BigDecimal base, BigDecimal previous) {

    // 当月指示数、前月指示数のどちらかがnullの場合
    if (base == null || previous == null) {

      // 当月指示数がnullの場合、0を設定する。
      if (base == null) {
        base = BigDecimal.ZERO;
      }
      // 前月指示数がnullの場合、0を設定する。
      if (previous == null) {
        previous = BigDecimal.ZERO;
      }
    }

    // 当月指示数から前月指示数を引いた値を指示数差に設定
    BigDecimal dif = base.subtract(previous);
    // 指示数差がマイナスの場合には、メータが一周している状態のため、
    // メータ一周加算値を加算して、指示数差を補正する
    if (dif.compareTo(BigDecimal.ZERO) < 0) {

      // 絶対値をとり、小数点以下を切り捨て
      long value = previous.abs().setScale(0, BigDecimal.ROUND_DOWN)
          .longValue();

      // 加算値、デフォルトは10
      long addVal = 10;

      // 整数値を10で割れるだけ繰り返す
      while ((value /= 10) != 0) {
        // 加算値を10倍
        addVal *= 10;
      }

      // メータ一周加算値を指示数差に加算して返す
      return dif.add(new BigDecimal(addVal));
    } else {
      return dif;
    }

  }

  /**
   * 確定使用量共通ビジネスを設定します。(DI)
   *
   * @param rkFixUsageCommonBusiness
   *          確定使用量共通ビジネス
   */
  public void setRkFixUsageCommonBusiness(
      RK_FixUsageCommonBusiness rkFixUsageCommonBusiness) {
    this.rkFixUsageCommonBusiness = rkFixUsageCommonBusiness;
  }

  /**
   * 計器交換・臨時検針情報Mapperを設定します。(DI)
   *
   * @param mcSmrInfoMapper
   *          計器交換・臨時検針情報Mapper
   */
  public void setMcSmrInfoMapper(McSmrInfoMapper mcSmrInfoMapper) {
    this.mcSmrInfoMapper = mcSmrInfoMapper;
  }

  /**
   * 計器交換・臨時検針情報明細２Mapperを設定します。(DI)
   *
   * @param mcSmrDetail2Mapper
   *          計器交換・臨時検針情報明細２Mapper
   */
  public void setMcSmrDetail2Mapper(McSmrDetail2Mapper mcSmrDetail2Mapper) {
    this.mcSmrDetail2Mapper = mcSmrDetail2Mapper;
  }

  /**
   * 確定使用量Mapperを設定します。(DI)
   *
   * @param fuMapper
   *          確定使用量Mapper
   */
  public void setFuMapper(FuMapper fuMapper) {
    this.fuMapper = fuMapper;
  }

  /**
   * 確定指示数Mapperを設定します。(DI)
   *
   * @param fixInMapper
   *          確定指示数Mapper
   */
  public void setFixInMapper(FixInMapper fixInMapper) {
    this.fixInMapper = fixInMapper;
  }

  /**
   * メッセージリソースを設定します。(DI)
   *
   * @param messageSource
   *          メッセージリソース
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }

}
