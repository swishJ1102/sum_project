package jp.co.unisys.enability.cis.business.rk.model;

import java.util.List;

/**
 * 計量器交換・臨時検針情報照会ビジネスBean
 *
 * <pre>
 * <p><b>【使用ビジネス】</b></p>
 * 計量器交換・臨時検針情報照会ビジネス
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class InquiryMcSmrInfoBusinessBean {

  /**
   * 地点特定番号を保有する。
   */
  private String spotNo;

  /**
   * 契約IDを保有する。
   */
  private Integer contractId;

  /**
   * 対象年月を保有する。
   */
  private String coveredPeriod;

  /**
   * 計量器交換情報リストを保有する。
   */
  private List<McSmrInfoBusinessBean> meterChangeInformationList;

  /**
   * 臨時検針情報リストを保有する。
   */
  private List<McSmrInfoBusinessBean> specialMeterReadingInformationList;

  /**
   * リターンコードを保有する。
   */
  private String returnCode;

  /**
   * メッセージを保有する。
   */
  private String message;

  /**
   * 地点特定番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 地点特定番号を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 地点特定番号
   */
  public String getSpotNo() {
    return spotNo;
  }

  /**
   * 地点特定番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 地点特定番号を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param spotNo
   *          地点特定番号
   */
  public void setSpotNo(String spotNo) {
    this.spotNo = spotNo;
  }

  /**
   * 契約IDのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約IDを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 契約ID
   */
  public Integer getContractId() {
    return contractId;
  }

  /**
   * 契約IDのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約IDを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractId
   *          契約ID
   */
  public void setContractId(Integer contractId) {
    this.contractId = contractId;
  }

  /**
   * 対象年月のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 対象年月を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 対象年月
   */
  public String getCoveredPeriod() {
    return coveredPeriod;
  }

  /**
   * 対象年月のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 対象年月を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param coveredPeriod
   *          対象年月
   */
  public void setCoveredPeriod(String coveredPeriod) {
    this.coveredPeriod = coveredPeriod;
  }

  /**
   * 計量器交換情報リストのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計量器交換情報リストを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 計量器交換情報リスト
   */
  public List<McSmrInfoBusinessBean> getMeterChangeInformationList() {
    return meterChangeInformationList;
  }

  /**
   * 計量器交換情報リストのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計量器交換情報リストを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param meterChangeInformationList
   *          計量器交換情報リスト
   */
  public void setMeterChangeInformationList(
      List<McSmrInfoBusinessBean> meterChangeInformationList) {
    this.meterChangeInformationList = meterChangeInformationList;
  }

  /**
   * 臨時検針情報リストのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 臨時検針情報リストを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 臨時検針情報リスト
   */
  public List<McSmrInfoBusinessBean> getSpecialMeterReadingInformationList() {
    return specialMeterReadingInformationList;
  }

  /**
   * 臨時検針情報リストのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 臨時検針情報リストを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param specialMeterReadingInformationList
   *          臨時検針情報リスト
   */
  public void setSpecialMeterReadingInformationList(
      List<McSmrInfoBusinessBean> specialMeterReadingInformationList) {
    this.specialMeterReadingInformationList = specialMeterReadingInformationList;
  }

  /**
   * リターンコードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return リターンコード
   */
  public String getReturnCode() {
    return returnCode;
  }

  /**
   * リターンコードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * リターンコードを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param returnCode
   *          リターンコード
   */
  public void setReturnCode(String returnCode) {
    this.returnCode = returnCode;
  }

  /**
   * メッセージのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return メッセージ
   */
  public String getMessage() {
    return message;
  }

  /**
   * メッセージのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージを設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param message
   *          メッセージ
   */
  public void setMessage(String message) {
    this.message = message;
  }
}
