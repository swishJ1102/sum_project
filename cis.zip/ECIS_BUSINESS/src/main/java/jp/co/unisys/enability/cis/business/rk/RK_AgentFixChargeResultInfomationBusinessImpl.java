package jp.co.unisys.enability.cis.business.rk;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.MessageSource;
import org.springframework.dao.DataAccessException;

import jp.co.unisys.enability.cis.business.rk.model.InquiryAgentFixChargeResultBusinessBean;
import jp.co.unisys.enability.cis.common.util.KJ_CommonUtil;
import jp.co.unisys.enability.cis.common.util.constants.ECISReturnCodeConstants;
import jp.co.unisys.enability.cis.entity.rk.RK_InquiryAgentFixChargeResultEntityBean;
import jp.co.unisys.enability.cis.mapper.rk.AgentFixChargeResultInformationCommonMapper;

/**
 * 確定料金実績情報ビジネス
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.rk.RK_AgentFixChargeResultInfomationBusiness
 *
 */
public class RK_AgentFixChargeResultInfomationBusinessImpl implements
    RK_AgentFixChargeResultInfomationBusiness {

  /** 複数契約番号で渡せるリスト最大サイズ */
  private static final int MAX_LIST_SIZE = 2000;

  /**
   * 確定料金実績情報共通Mapper(DI)
   */
  private AgentFixChargeResultInformationCommonMapper fixChargeResultInformationCommonMapper;

  /**
   * メッセージプロパティ(DI)
   */
  private MessageSource messageSource;

  /**
   * ログマネジャー
   */
  private static Logger logger = LogManager.getLogger();

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.rk.RK_AgentFixChargeResultInfomationBusiness
   * #inquiry(jp.co.unisys.enability.cis.business.kj.model.
   * InquiryAgentFixChargeResultBusinessBean)
   */
  @Override
  public InquiryAgentFixChargeResultBusinessBean inquiry(
      InquiryAgentFixChargeResultBusinessBean inquiryFixChargeResultBusinessBean) {

    try {
      // 請求ID
      Integer billingId = inquiryFixChargeResultBusinessBean
          .getBillingId();
      // 請求番号
      String billingNo = inquiryFixChargeResultBusinessBean
          .getBillingNo();
      // 契約ID
      Integer contractId = inquiryFixChargeResultBusinessBean
          .getContractId();
      // 契約番号
      String contractNo = inquiryFixChargeResultBusinessBean
          .getContractNo();
      // ご利用年月FROM
      String usePeriodFrom = inquiryFixChargeResultBusinessBean
          .getUsePeriodFrom();

      // ご利用年月TO
      String usePeriodTo = inquiryFixChargeResultBusinessBean
          .getUsePeriodTo();

      // 契約番号リスト
      List<String> contractNoList = inquiryFixChargeResultBusinessBean
          .getContractNoList();

      // 変数定義
      List<RK_InquiryAgentFixChargeResultEntityBean> fixChargeResultList = new ArrayList<RK_InquiryAgentFixChargeResultEntityBean>();
      Map<String, Object> map = new LinkedHashMap<String, Object>();

      // 照会パターンチェック
      if ((billingId != null || StringUtils.isNotEmpty(billingNo))
          && contractId == null && StringUtils.isEmpty(contractNo)
          && StringUtils.isEmpty(usePeriodFrom)
          && StringUtils.isEmpty(usePeriodTo)) {
        // 確定料金実績明細（KEY：請求）取得
        map.put("billingId", billingId);
        map.put("billingNo", billingNo);
        fixChargeResultList = fixChargeResultInformationCommonMapper
            .selectFixChargeResultKeyBilling(map);

      } else if (billingId == null && StringUtils.isEmpty(billingNo)
          && (contractId != null || StringUtils.isNotEmpty(contractNo))
          && StringUtils.isNotEmpty(usePeriodFrom)
          && StringUtils.isNotEmpty(usePeriodTo)) {
        // 確定料金実績明細（KEY:契約と日付）取得
        map.put("contractId", contractId);
        map.put("contractNo", contractNo);
        map.put("usePeriodFrom", usePeriodFrom);
        map.put("usePeriodTo", usePeriodTo);
        fixChargeResultList = fixChargeResultInformationCommonMapper
            .selectFixChargeResultKeyContractAndDate(map);

      } else if (billingId == null && StringUtils.isEmpty(billingNo)
          && (contractId != null || StringUtils.isNotEmpty(contractNo))
          && StringUtils.isNotEmpty(usePeriodFrom)
          && StringUtils.isEmpty(usePeriodTo)) {
        // 確定料金実績明細（KEY：契約と日付イコール）取得
        map.put("contractId", contractId);
        map.put("contractNo", contractNo);
        map.put("usePeriodFrom", usePeriodFrom);
        fixChargeResultList = fixChargeResultInformationCommonMapper
            .selectFixChargeResultKeyContractAndEqualDate(map);

      } else if (Objects.isNull(billingId) && StringUtils.isEmpty(billingNo)
          && Objects.isNull(contractId) && StringUtils.isEmpty(contractNo)
          && Objects.nonNull(contractNoList)
          && StringUtils.isNotEmpty(usePeriodFrom)) {

        // 確定料金実績明細（KEY：複数契約と日付）取得
        fixChargeResultList = selectMultiContract(usePeriodFrom, usePeriodTo, contractNoList);

      } else {
        // 照会結果設定
        inquiryFixChargeResultBusinessBean
            .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_P001);
        inquiryFixChargeResultBusinessBean
            .setMessage(messageSource.getMessage(
                KJ_CommonUtil
                    .getMessageId(ECISReturnCodeConstants.RETURN_CODE_P001),
                new String[] {}, Locale.getDefault()));

        return inquiryFixChargeResultBusinessBean;
      }

      // 照会結果設定
      inquiryFixChargeResultBusinessBean
          .setAgentFixChargeResultList(fixChargeResultList);
      inquiryFixChargeResultBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);

    } catch (DataAccessException e) {
      logger.error(messageSource.getMessage("error.E1129", null,
          Locale.getDefault()), e);
      // 照会結果設定
      inquiryFixChargeResultBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      inquiryFixChargeResultBusinessBean
          .setMessage(messageSource.getMessage(
              KJ_CommonUtil
                  .getMessageId(ECISReturnCodeConstants.RETURN_CODE_G017),
              new String[] {}, Locale.getDefault()));
    }

    return inquiryFixChargeResultBusinessBean;
  }

  /**
   * 複数契約の検索
   *
   * @param usePeriodFrom
   *          利用年月FROM
   * @param usePeriodTo
   *          利用年月TO
   * @param contractNoList
   *          契約番号リスト
   * @return
   */
  private List<RK_InquiryAgentFixChargeResultEntityBean> selectMultiContract(String usePeriodFrom,
      String usePeriodTo, List<String> contractNoList) {

    List<RK_InquiryAgentFixChargeResultEntityBean> allFixChargeResultList = new ArrayList<>();
    List<List<String>> contractNoSubList = chunk(contractNoList, MAX_LIST_SIZE);

    // 確定料金実績明細（KEY：複数契約と日付）取得
    for (List<String> subList : contractNoSubList) {
      Map<String, Object> map = new HashMap<String, Object>();
      map.put("contractNoList", subList);
      map.put("usePeriodFrom", usePeriodFrom);
      map.put("usePeriodTo", usePeriodTo);
      List<RK_InquiryAgentFixChargeResultEntityBean> fixChargeResultList = fixChargeResultInformationCommonMapper
          .selectFixChargeResultKeyMultiContractAndDate(map);
      allFixChargeResultList.addAll(fixChargeResultList);
    }
    return allFixChargeResultList;
  }

  /**
   * 確定料金実績情報共通マッパーのセッター(DI)
   *
   * @param fixChargeResultInformationCommonMapper
   *          セットする fixChargeResultInformationCommonMapper
   */
  public void setAgentFixChargeResultInformationCommonMapper(
      AgentFixChargeResultInformationCommonMapper fixChargeResultInformationCommonMapper) {
    this.fixChargeResultInformationCommonMapper = fixChargeResultInformationCommonMapper;
  }

  /**
   * メッセージプロパティのセッター(DI)
   *
   * @param messageSource
   *          messageSourceをセットする
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }

  /**
   * Listを指定したサイズ毎に分割します。
   *
   * @param origin
   *          分割元のList
   * @param size
   *          Listの分割単位
   * @return サイズ毎に分割されたList。但し、Listがnullまたは空の場合、もしくはsizeが0以下の場合は空のListを返す。
   */
  public <T> List<List<T>> chunk(List<T> origin, int size) {
    if (origin == null || origin.isEmpty() || size <= 0) {
      return Collections.emptyList();
    }

    int block = origin.size() / size + (origin.size() % size > 0 ? 1 : 0);

    return IntStream.range(0, block)
        .boxed()
        .map(i -> {
          int start = i * size;
          int end = Math.min(start + size, origin.size());
          return origin.subList(start, end);
        })
        .collect(Collectors.toList());
  }
}