package jp.co.unisys.enability.cis.business.gk;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import java.util.Properties;

import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.sax.SAXResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.fop.apps.Fop;
import org.apache.fop.apps.FopFactory;
import org.apache.fop.apps.MimeConstants;
import org.springframework.beans.factory.config.PropertiesFactoryBean;
import org.springframework.context.MessageSource;
import org.springframework.core.io.ClassPathResource;
import org.xml.sax.SAXException;

import jp.co.unisys.enability.cis.common.Exception.BusinessLogicException;
import jp.co.unisys.enability.cis.common.Exception.SystemException;

/**
 * PDF作成共通ビジネス_カスタム<br>
 *
 * このクラスはApache License, Version 2.0 のライセンスで<br>
 * 配布されている成果物を利用しています。<br>
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @author "Nihon Unisys, Ltd."
 *
 *         変更履歴(kg-epj) 2016.02.23 T.Hori 新規作成
 */
public class Custom_CreatePdfBusinessImpl implements Custom_CreatePdfBusiness {

  /**
   * プロパティ(DI)
   */
  private PropertiesFactoryBean applicationProperties;

  /**
   * メッセージプロパティ(DI)
   */
  private MessageSource messageSource;

  /*
   * (非 Javadoc)
   * @see jp.co.unisys.enability.cis.business.gk.Custom_CreatePdfBusiness#create(java.nio.file.Path, java.nio.file.Path, java.nio.file.Path)
   */
  @Override
  public void create(Path pdfFilePath, Path xsltFilePath, Path xmlFilePath)
      throws BusinessLogicException {

    // プロパティ取得
    Properties prop = null;
    try {
      prop = applicationProperties.getObject();
    } catch (IOException e) {
      throw new SystemException(messageSource.getMessage("error.E1265",
          null, Locale.getDefault()), e);
    }

    // fop.xconfファイルのクラスパス取得
    String fopConfFileClassPath = prop.getProperty("custom.classpath.fop.font.config.file");

    // FopFactoryオブジェクトの生成
    FopFactory fopFactory = FopFactory.newInstance();

    // 出力先の指定
    try (OutputStream output = new BufferedOutputStream(Files.newOutputStream(pdfFilePath))) {

      // 日本語フォントの設定の追加
      URL url = ClassPathResource.class.getResource(fopConfFileClassPath);
      fopFactory.setUserConfig(url.toURI().toString());

      // 基底ディレクトリ設定
      // xslファイルの配置ディレクトリを基準にする
      fopFactory.setBaseURL(xsltFilePath.getParent().toAbsolutePath().toString());

      // 出力フォーマットを指定してFopオブジェクトを生成
      Fop fop = fopFactory.newFop(MimeConstants.MIME_PDF, output);

      // XMLファイルの指定
      Source source = new StreamSource(xmlFilePath.toAbsolutePath().toUri().toString());

      // XSLTファイルの指定
      Source xsltSource = new StreamSource(xsltFilePath.toAbsolutePath().toUri().toString());

      // 変換用オブジェクトの生成
      TransformerFactory factory = TransformerFactory.newInstance();
      Transformer transformer = factory.newTransformer(xsltSource);

      // 結果格納用のResultオブジェクトを生成
      Result result = new SAXResult(fop.getDefaultHandler());

      // 変換を実行
      transformer.transform(source, result);
      // エラーは一括でcatchし、BusinessLogicExceptionとして返却する。
    } catch (IOException | SAXException | TransformerException | URISyntaxException ex) {
      // Exceptionを詰める時は、キーとパラメータの形式しかできない
      // "PDFファイル作成に失敗しました。"
      throw new BusinessLogicException("error.E0001", ex,
          prop.getProperty("custom.business.error.message.create.pdf.file"));
    }
  }

  /**
   * プロパティのsetter(DI)
   *
   * @param applicationProperties
   *          プロパティ
   */
  public void setApplicationProperties(PropertiesFactoryBean applicationProperties) {
    this.applicationProperties = applicationProperties;
  }

  /**
   * メッセージプロパティのsetter(DI)
   *
   * @param messageSource
   *          メッセージプロパティ
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }

}
