package jp.co.unisys.enability.cis.business.gk;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import jp.co.unisys.enability.cis.business.kj.model.ContractManagementInformationFileConfigCommon;
import jp.co.unisys.enability.cis.business.kj.model.ContractManagementInformationFileConfigSupplementaryContract;
import jp.co.unisys.enability.cis.common.util.CommonValidationUtil;
import jp.co.unisys.enability.cis.common.util.EMSMessageResource;

/**
 * バリデーション
 *
 * @author "Nihon Unisys, Ltd."
 */
public class SupplementaryContractInformationFileRegistValidator {

  /** プロパティクラスを定義 */
  private EMSMessageResource emsMessageResource;

  /**
   * メッセージプロパティキー管理のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージプロパティキー管理を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param emsMessageResource
   *          メッセージプロパティキー管理
   */
  public void setEmsMessageResource(EMSMessageResource emsMessageResource) {
    this.emsMessageResource = emsMessageResource;
  }

  /**
   * のバリデーションを実施、チェック結果のメッセージListを返却する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 1 引数のバリデーションを行う。
   * 2 チェック結果がNGの場合、戻り値のメッセージListにエラーメッセージを詰めて返却する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param args
   *          バッチ引数
   * @return メッセージList
   */
  public List<String> validate(Map<Integer, String> dataRecord) {

    List<String> messageList = new ArrayList<String>();

    String dataRecordClass = dataRecord
        .get(ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_INDEX);
    // データレコード種別：必須チェック
    if (CommonValidationUtil.isNull(dataRecordClass)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_NAME }));

      // データレコード種別：正規表現チェック
    } else if (dataRecordClass != null
        && !CommonValidationUtil
            .checkByPattern(
                dataRecordClass,
                ContractManagementInformationFileConfigCommon.DATA_KIND_MASK_STRING)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_ITEM_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_NAME }));
    }

    String contractNo = dataRecord
        .get(ContractManagementInformationFileConfigSupplementaryContract.DATA_CONTRACT_NO_INDEX);
    // 契約番号：必須チェック
    if (CommonValidationUtil.isNull(contractNo)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigSupplementaryContract.DATA_CONTRACT_NO_NAME }));

      // 契約番号：文字種別チェック（半角英数字）
    } else if (contractNo != null
        && !CommonValidationUtil.isAlphabetNumric(contractNo)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_ALPHANUMERIC_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigSupplementaryContract.DATA_CONTRACT_NO_NAME }));

      // 契約番号：文字種別チェック（半角英数字　低圧CISシステム許容文字）
    } else if (contractNo != null
        && !CommonValidationUtil.isRangeWordByECIS(contractNo)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigSupplementaryContract.DATA_CONTRACT_NO_NAME,
                      "半角英数字（低圧CISシステム許容文字）" }));

      // 契約番号：文字列最大長チェック
    } else if (contractNo != null
        && !CommonValidationUtil
            .maxLength(
                contractNo,
                ContractManagementInformationFileConfigSupplementaryContract.DATA_CONTRACT_NO_LENGTH)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MAXLENGTH_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigSupplementaryContract.DATA_CONTRACT_NO_NAME,
                      ContractManagementInformationFileConfigSupplementaryContract.DATA_CONTRACT_NO_LENGTH_STRING }));
    }

    String supplementaryMenuId = dataRecord
        .get(ContractManagementInformationFileConfigSupplementaryContract.DATA_SUPPLEMENTARY_MENU_ID_INDEX);
    // 付帯メニューID：必須チェック
    if (CommonValidationUtil.isNull(supplementaryMenuId)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigSupplementaryContract.DATA_SUPPLEMENTARY_MENU_ID_NAME }));
    }

    String supplementaryContractStartDate = dataRecord
        .get(ContractManagementInformationFileConfigSupplementaryContract.DATA_SUPPLEMENTARY_CONTRACT_START_DATE_INDEX);
    // 付帯契約開始日：必須チェック
    if (CommonValidationUtil.isNull(supplementaryContractStartDate)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigSupplementaryContract.DATA_SUPPLEMENTARY_CONTRACT_START_DATE_NAME }));

      // 付帯契約開始日：日付フォーマットチェック
    } else if (supplementaryContractStartDate != null
        && !CommonValidationUtil.checkDateFormat(
            supplementaryContractStartDate, "yyyy/MM/dd")) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigSupplementaryContract.DATA_SUPPLEMENTARY_CONTRACT_START_DATE_NAME,
                      "日付形式（yyyy/MM/dd）" }));
    }

    String supplementaryContractEndDate = dataRecord
        .get(ContractManagementInformationFileConfigSupplementaryContract.DATA_SUPPLEMENTARY_CONTRACT_END_DATE_INDEX);
    // 付帯契約終了日：日付フォーマットチェック
    if (supplementaryContractEndDate != null
        && !CommonValidationUtil.checkDateFormat(
            supplementaryContractEndDate, "yyyy/MM/dd")) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigSupplementaryContract.DATA_SUPPLEMENTARY_CONTRACT_END_DATE_NAME,
                      "日付形式（yyyy/MM/dd）" }));
    }

    String amountOrRate = dataRecord
        .get(ContractManagementInformationFileConfigSupplementaryContract.DATA_AMOUNT_OR_RATE_INDEX);
    // 額・率：数値フォーマットチェック
    if (amountOrRate != null
        && !CommonValidationUtil.checkByPattern(amountOrRate,
            "^(([1-9][0-9]*|0){1}(\\.[0-9]+)?)?$")) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigSupplementaryContract.DATA_AMOUNT_OR_RATE_NAME,
                      "数値形式（マイナス符号：否、カンマ：否、小数：可）" }));

      // 額・率：数値桁数チェック
    } else if (amountOrRate != null
        && !CommonValidationUtil
            .checkBigDecimalDigit(
                amountOrRate,
                ContractManagementInformationFileConfigSupplementaryContract.DATA_AMOUNT_OR_RATE_AMOUNT_DIGIT_INTEGER,
                ContractManagementInformationFileConfigSupplementaryContract.DATA_AMOUNT_OR_RATE_AMOUNT_DIGIT_FLOAT)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_MONEYRANGE,
                  new String[] {
                      ContractManagementInformationFileConfigSupplementaryContract.DATA_AMOUNT_OR_RATE_NAME,
                      ContractManagementInformationFileConfigSupplementaryContract.DATA_AMOUNT_OR_RATE_AMOUNT_DIGIT_INTEGER_STRING,
                      ContractManagementInformationFileConfigSupplementaryContract.DATA_AMOUNT_OR_RATE_AMOUNT_DIGIT_FLOAT_STRING }));
    }
    return messageList;
  }
}
