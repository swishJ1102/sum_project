package jp.co.unisys.enability.cis.business.kj;

import jp.co.unisys.enability.cis.business.kj.model.CsvFileCheckAccountCreditCardBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.DeleteAccountCreditCardBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.DownloadAccountCreditCardBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.InquiryAccountCreditCardBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.RegistAccountCreditCardBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.UpdateAccountCreditCardBusinessBean;
import jp.co.unisys.enability.cis.common.Exception.SystemException;

/**
 * 口座クレカ情報一覧ビジネスインターフェース。
 *
 * @author "Nihon Unisys, Ltd."
 *
 */
public interface KJ_AccountCreditCardInformationBusiness {

  /**
   * 口座クレカ情報の照会を行う。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * CRMや低圧CISで、【口座クレカ情報】を特定する場合に、
   * 指定された「契約者番号」に紐付く【口座クレカ】の一覧情報を返却する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param inquiryAccountCreditCardBusinessBean
   *          口座クレカ情報照会BusinessBean
   * @return 口座クレカ情報照会BusinessBean
   */
  public InquiryAccountCreditCardBusinessBean inquiry(
      InquiryAccountCreditCardBusinessBean inquiryAccountCreditCardBusinessBean);

  /**
   * 口座クレカ情報登録を行う。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * CRMや低圧CISから、「契約者」に紐付く【口座クレカ情報】を登録する場合に使用される。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param registAccountCreditCardBusinessBean
   *          口座クレカ情報登録RequestBean
   * @return 口座クレカ情報登録BusinessBeaninquiryAccountCreditCardBusinessBea
   */
  public RegistAccountCreditCardBusinessBean regist(
      RegistAccountCreditCardBusinessBean registAccountCreditCardBusinessBean);

  /**
   * アップロードファイルのヘッダレコード、データレコードをチェックし、チェックでエラーにならない場合、DB更新用のオブジェクトを返却する。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   *         返却用オブジェクトを生成する。
   * 1       ヘッダレコードチェック処理を行い、入力内容に誤りがある場合、エラー情報を返却用オブジェクトに設定し、処理を終了する。
   * 2       データレコードチェック処理を全てのデータレコード行数分、チェックを行う。
   * 3       入力内容に誤りがある場合、エラー情報を全て返却用オブジェクトに設定し、処理を終了する。
   * 4       入力内容に誤りがない場合、データレコードの情報を返却用オブジェクトに設定し、処理を終了する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param csvFileCheckBusinessBean
   *          口座クレカ情報CSVファイルチェックBusinessBean
   * @return CsvFileCheckAccountCreditCardBusinessBean 口座クレカ情報CSVファイルチェックBusinessBean
   *
   */
  public CsvFileCheckAccountCreditCardBusinessBean csvFileCheck(
      CsvFileCheckAccountCreditCardBusinessBean csvFileCheckBusinessBean);

  /**
   * ダウンロードファイルの情報を取得する処理を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 1       ダウンロードファイル情報取得のMapperを呼び出し、ダウンロードファイル情報を取得する。
   * 2       CSVファイル名を生成する。
   * 3       DownloadAccountCreditCardBusinessBeanにダウンロードファイル情報とCSVファイル名を設定する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param downloadAccountCreditCardBusinessBean
   *          口座クレカ情報ダウンロードBusinessBean
   * @return DownloadAccountCreditCardBusinessBean 口座クレカ情報ダウンロードBusinessBean
   * @throws SystemException
   *           予期せぬエラーが発生した場合
   * @see jp.co.unisys.enability.cis.mapper.kj.AccountCreditCardInformationCommonMapper
   */
  public DownloadAccountCreditCardBusinessBean download(
      DownloadAccountCreditCardBusinessBean downloadAccountCreditCardBusinessBean)
      throws SystemException;

  /**
   * 口座クレカ情報更新を行う。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 口座クレカ情報更新を行う。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param UpdateAccountCreditCardBusinessBean
   *          口座クレカ情報更新BusinessBean
   * @return UpdateAccountCreditCardBusinessBean 口座クレカ情報更新BusinessBean
   */
  public UpdateAccountCreditCardBusinessBean update(
      UpdateAccountCreditCardBusinessBean updateAccountCreditCardBusinessBean);

  /**
   * 口座クレカ情報削除を行う。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 口座クレカ情報削除を行う。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param DeleteAccountCreditCardBusinessBean
   *          口座クレカ情報削除BusinessBean
   * @return DeleteAccountCreditCardBusinessBean 口座クレカ情報削除BusinessBean
   */
  public DeleteAccountCreditCardBusinessBean delete(
      DeleteAccountCreditCardBusinessBean deletetAccountCreditCardBusinessBean);
}
