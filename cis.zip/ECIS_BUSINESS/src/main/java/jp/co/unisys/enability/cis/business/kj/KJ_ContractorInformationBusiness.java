package jp.co.unisys.enability.cis.business.kj;

import jp.co.unisys.enability.cis.business.kj.model.CsvFileCheckContractorBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.DownloadContractorBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.InquiryContractorBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.RegistContractorBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.UpdateContractorBusinessBean;

/**
 * 契約者情報ビジネスインターフェース。
 *
 * @author "Nihon Unisys, Ltd."
 *
 */
public interface KJ_ContractorInformationBusiness {

  /**
   * 契約者情報照会を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * CRMや低圧CISで、【契約者】を特定する場合に、指定された「契約者番号」に紐付く【契約者】の情報を返却する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param inquiryContractorBusinessBean
   *          契約者情報照会BusinessBean
   * @return 契約者情報照会BusinessBean
   */
  public InquiryContractorBusinessBean inquiry(
      InquiryContractorBusinessBean inquiryContractorBusinessBean);

  /**
   * 契約者情報登録を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * CRMまたは、低圧CISにて契約者の更新時に利用される。指定された「契約者番号」に該当する【契約者】を登録する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param registContractorBusinessBean
   *          契約者情報登録BusinessBean
   * @return 契約者情報登録BusinessBean
   */
  public RegistContractorBusinessBean regist(
      RegistContractorBusinessBean registContractorBusinessBean);

  /**
   * 契約者情報更新を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * CRMまたは、低圧CISにて契約者の更新時に利用される。指定された「契約者番号」に該当する【契約者】を更新する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param updateContractorBusinessBean
   *          契約者情報更新BusinessBean
   * @return 契約者情報更新BusinessBean
   */
  public UpdateContractorBusinessBean update(
      UpdateContractorBusinessBean updateContractorBusinessBean);

  /**
   * ダウンロードを行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者情報のダウンロードを行う。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param downloadContractorBusinessBean
   *          契約者情報ダウンロードBusinessBean
   * @return 契約者情報ダウンロードBusinessBean
   */
  public DownloadContractorBusinessBean download(
      DownloadContractorBusinessBean downloadContractorBusinessBean);

  /**
   * ダウンロードを行う。 （カスタム仕様のダウンロード項目対応）
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約者情報のダウンロードを行う。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param downloadContractorBusinessBean
   *          契約者情報ダウンロードBusinessBean
   * @return 契約者情報ダウンロードBusinessBean
   */
  public DownloadContractorBusinessBean downloadCustom(
      DownloadContractorBusinessBean downloadContractorBusinessBean);

  /**
   * CSVファイルチェックを行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * アップロードを行うCSVファイルのチェックを行う。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param csvFileCheckContractorBusinessBean
   *          契約者情報CSVファイルチェックBusinessBean
   * @return 契約者情報CSVファイルチェックBusinessBean
   */
  public CsvFileCheckContractorBusinessBean csvFileCheck(
      CsvFileCheckContractorBusinessBean csvFileCheckContractorBusinessBean);

  /**
   * CSVファイルチェックを行う。 （カスタム仕様のアップロード項目対応）
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * アップロードを行うCSVファイルのチェックを行う。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param csvFileCheckContractorBusinessBean
   *          契約者情報CSVファイルチェックBusinessBean
   * @return 契約者情報CSVファイルチェックBusinessBean
   */
  public CsvFileCheckContractorBusinessBean csvFileCheckCustom(
      CsvFileCheckContractorBusinessBean csvFileCheckContractorBusinessBean);
}