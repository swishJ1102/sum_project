package jp.co.unisys.enability.cis.business.rk;

import jp.co.unisys.enability.cis.business.rk.model.RK_FixUsageApplyDataBusinessBean;

/**
 * 確定指示数登録ビジネスインターフェース。
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.mapper.common.InResultMapper
 * @see jp.co.unisys.enability.cis.mapper.common.FixInMapper
 * @see jp.co.unisys.enability.cis.mapper.common.MlMapper
 */
public interface RK_FixUsageApplyRegisterFixIndicationNoBusiness {

  /**
   * メータに関する情報を取得し、【確定指示数】の登録処理等を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 確定使用量メッセージからメータに関する情報を取得し、
   * 【確定指示数】の登録や、TODOの登録等を行う。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param applyDataBusinessBean
   *          確定使用量メッセージの情報を保持するBean
   * @see jp.co.unisys.enability.cis.mapper.common.InResultMapper
   * @see jp.co.unisys.enability.cis.mapper.common.FixInMapper
   * @see jp.co.unisys.enability.cis.mapper.common.MlMapper
   */
  public abstract void register(RK_FixUsageApplyDataBusinessBean applyDataBusinessBean);
}
