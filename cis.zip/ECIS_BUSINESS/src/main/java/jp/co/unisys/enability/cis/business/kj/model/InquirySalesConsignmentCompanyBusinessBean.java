package jp.co.unisys.enability.cis.business.kj.model;

import java.util.List;

import jp.co.unisys.enability.cis.entity.kj.KJ_SalesConsignmentCompanyEntityBean;

/**
 * 営業委託先企業一覧照会で、検索条件および検索結果を格納するビジネスBean
 * 
 * <pre>
* <p><b>【使用ビジネス】</b></p>
* 営業委託先企業一覧照会ビジネス
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class InquirySalesConsignmentCompanyBusinessBean {

  /**
   * 営業委託先コードを保有する。
   */
  private String salesConsignmentCode;

  /**
   * 営業委託先企業有効フラグを保有する。
   */
  private String salesConsignmentCompanyEffectiveFlag;

  /**
   * 営業委託先企業情報リストを保有する。
   */
  private List<KJ_SalesConsignmentCompanyEntityBean> salesConsignmentCompanyList;

  /**
   * リターンコードを保有する。
   */
  private String returnCode;

  /**
   * メッセージを保有する。
   */
  private String message;

  /**
   * 営業委託先コードのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 営業委託先コードを取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 営業委託先コード
   */
  public String getSalesConsignmentCode() {
    return this.salesConsignmentCode;
  }

  /**
   * 営業委託先コードのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 営業委託先コードを設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param salesConsignmentCode
   *          営業委託先コード
   */
  public void setSalesConsignmentCode(String salesConsignmentCode) {
    this.salesConsignmentCode = salesConsignmentCode;
  }

  /**
   * 営業委託先企業有効フラグのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 営業委託先企業有効フラグを取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 営業委託先企業有効フラグ
   */
  public String getSalesConsignmentCompanyEffectiveFlag() {
    return this.salesConsignmentCompanyEffectiveFlag;
  }

  /**
   * 営業委託先企業有効フラグのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 営業委託先企業有効フラグを設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param salesConsignmentCompanyEffectiveFlag
   *          営業委託先企業有効フラグ
   */
  public void setSalesConsignmentCompanyEffectiveFlag(String salesConsignmentCompanyEffectiveFlag) {
    this.salesConsignmentCompanyEffectiveFlag = salesConsignmentCompanyEffectiveFlag;
  }

  /**
   * 営業委託先企業情報リストのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 営業委託先企業情報リストを取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 営業委託先企業情報リスト
   */
  public List<KJ_SalesConsignmentCompanyEntityBean> getSalesConsignmentCompanyList() {
    return this.salesConsignmentCompanyList;
  }

  /**
   * 営業委託先企業情報リストのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 営業委託先企業情報リストを設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param salesConsignmentCompanyList
   *          営業委託先企業情報リスト
   */
  public void setSalesConsignmentCompanyList(List<KJ_SalesConsignmentCompanyEntityBean> salesConsignmentCompanyList) {
    this.salesConsignmentCompanyList = salesConsignmentCompanyList;
  }

  /**
   * リターンコードのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * リターンコードを取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return リターンコード
   */
  public String getReturnCode() {
    return this.returnCode;
  }

  /**
   * リターンコードのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * リターンコードを設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param returnCode
   *          リターンコード
   */
  public void setReturnCode(String returnCode) {
    this.returnCode = returnCode;
  }

  /**
   * メッセージのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * メッセージを取得する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return メッセージ
   */
  public String getMessage() {
    return this.message;
  }

  /**
   * メッセージのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * メッセージを設定する。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param message
   *          メッセージ
   */
  public void setMessage(String message) {
    this.message = message;
  }

}
