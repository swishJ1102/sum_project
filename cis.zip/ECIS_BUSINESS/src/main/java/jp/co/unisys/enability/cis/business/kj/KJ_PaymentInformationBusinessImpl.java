package jp.co.unisys.enability.cis.business.kj;

import java.io.File;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.config.PropertiesFactoryBean;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DuplicateKeyException;

import jp.co.unisys.enability.cis.business.common.DateBusiness;
import jp.co.unisys.enability.cis.business.common.TodoBusiness;
import jp.co.unisys.enability.cis.business.common.model.TodoBusinessBean;
import jp.co.unisys.enability.cis.business.gk.ContractManagementInformationFileHeaderValidator;
import jp.co.unisys.enability.cis.business.gk.Custom_PaymentInformationFileDeleteValidator;
import jp.co.unisys.enability.cis.business.gk.Custom_PaymentInformationFileRegistValidator;
import jp.co.unisys.enability.cis.business.gk.Custom_PaymentInformationFileUpdateValidator;
import jp.co.unisys.enability.cis.business.gk.PaymentInformationFileDeleteValidator;
import jp.co.unisys.enability.cis.business.gk.PaymentInformationFileRegistValidator;
import jp.co.unisys.enability.cis.business.gk.PaymentInformationFileUpdateValidator;
import jp.co.unisys.enability.cis.business.kj.model.ContractManagementInformationFileConfigCommon;
import jp.co.unisys.enability.cis.business.kj.model.ContractManagementInformationFileConfigPayment;
import jp.co.unisys.enability.cis.business.kj.model.CsvFileCheckPaymentBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.Custom_ContractManagementInformationFileConfigPayment;
import jp.co.unisys.enability.cis.business.kj.model.DeletePaymentBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.DownloadPaymentBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.InquiryContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.InquiryContractorBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.InquiryPaymentBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.RegistPaymentBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.UpdatePaymentBusinessBean;
import jp.co.unisys.enability.cis.common.Exception.BusinessLogicException;
import jp.co.unisys.enability.cis.common.Exception.SystemException;
import jp.co.unisys.enability.cis.common.util.DateCalculateUtil;
import jp.co.unisys.enability.cis.common.util.EMSConstants;
import jp.co.unisys.enability.cis.common.util.KJ_CommonUtil;
import jp.co.unisys.enability.cis.common.util.RK_PropertyUtil;
import jp.co.unisys.enability.cis.common.util.StringConvertUtil;
import jp.co.unisys.enability.cis.common.util.ThreadContext;
import jp.co.unisys.enability.cis.common.util.constants.ECISCodeConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISKJConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISReturnCodeConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISTodoConstants;
import jp.co.unisys.enability.cis.common.util.model.CheckBillingInformationUtilBean;
import jp.co.unisys.enability.cis.dao.kj.ContractManagementInformationDownloadSearchInformationBean;
import jp.co.unisys.enability.cis.entity.common.AcInformation;
import jp.co.unisys.enability.cis.entity.common.BlExample;
import jp.co.unisys.enability.cis.entity.common.FixChargeBlLinkageExample;
import jp.co.unisys.enability.cis.entity.common.IlcM;
import jp.co.unisys.enability.cis.entity.common.Payment;
import jp.co.unisys.enability.cis.entity.common.PaymentExample;
import jp.co.unisys.enability.cis.entity.common.PaymentHist;
import jp.co.unisys.enability.cis.entity.common.PaymentHistExample;
import jp.co.unisys.enability.cis.entity.common.PaymentHistKey;
import jp.co.unisys.enability.cis.entity.common.PhoneNoCatM;
import jp.co.unisys.enability.cis.entity.common.PwM;
import jp.co.unisys.enability.cis.entity.kj.KJ_InquiryContractorInformationEntityBean;
import jp.co.unisys.enability.cis.entity.kj.KJ_InquiryPaymentInformationEntityBean;
import jp.co.unisys.enability.cis.entity.kj.KJ_PaymentInformationFileEntityBean;
import jp.co.unisys.enability.cis.entity.sn.SN_CurrentMonthBillingInformationEntityBean;
import jp.co.unisys.enability.cis.entity.sn.SN_FixChargeResultInformationEntityBean;
import jp.co.unisys.enability.cis.entity.sn.SN_PastBillingInformationEntityBean;
import jp.co.unisys.enability.cis.mapper.common.AcInformationMapper;
import jp.co.unisys.enability.cis.mapper.common.BlMapper;
import jp.co.unisys.enability.cis.mapper.common.FixChargeBlLinkageMapper;
import jp.co.unisys.enability.cis.mapper.common.IlcMMapper;
import jp.co.unisys.enability.cis.mapper.common.PaymentHistMapper;
import jp.co.unisys.enability.cis.mapper.common.PaymentMapper;
import jp.co.unisys.enability.cis.mapper.common.PhoneNoCatMMapper;
import jp.co.unisys.enability.cis.mapper.common.PwMMapper;
import jp.co.unisys.enability.cis.mapper.kj.FixChargeBillingLinkageInformationCommonMapper;
import jp.co.unisys.enability.cis.mapper.kj.PaymentInformationCommonMapper;
import jp.co.unisys.enability.cis.mapper.sn.BillingInformationCommonMapper;
import jp.sf.orangesignal.csv.Csv;
import jp.sf.orangesignal.csv.handlers.ColumnPositionMapListHandler;

/**
 * 支払情報ビジネスクラス
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.kj.KJ_PaymentInformationBusiness
 *
 */
public class KJ_PaymentInformationBusinessImpl implements
    KJ_PaymentInformationBusiness {
  /**
   * 支払番号生成用桁数
   */
  private static final int CLEATE_PAYMENT_NO_LENGTH = 2;
  /**
   * 支払番号最大
   */
  private static final int MAX_PAYMENT_NO = 99;
  /**
   * リスト先頭取得
   */
  private static final int FIRST_INDEX = 0;
  /**
   * リスト2つ目取得
   */
  private static final int SECOND_INDEX = 1;
  /**
   * updatecount設定値
   */
  private static final int INT_CNT_ZERO = 0;
  /**
   * 請求合算要否登録制御値
   */
  private static final String STRING_ZERO = "0";
  /**
   * 支払情報マッパー(DI)
   */
  private PaymentMapper paymentMapper;
  /**
   * 請求情報マッパー(DI)
   */
  private BlMapper blMapper;
  /**
   * 支払情報共通マッパー(DI)
   */
  private PaymentInformationCommonMapper paymentInformationCommonMapper;
  /**
   * 支払履歴情報マッパー(DI)
   */
  private PaymentHistMapper paymentHistMapper;
  /**
   * 口座クレカ情報マッパー(DI)
   */
  private AcInformationMapper acInformationMapper;
  /**
   * 支払方法マスタマッパー(DI)
   */
  private PwMMapper pwMMapper;
  /**
   * 個人・法人区分マスタマッパー(DI)
   */
  private IlcMMapper ilcMMapper;
  /**
   * 電話番号区分マッパー(DI)
   */
  private PhoneNoCatMMapper phoneNoCatMMapper;
  /**
   * 確定料金・請求連携情報マッパー(DI)
   */
  private FixChargeBlLinkageMapper fixChargeBlLinkageMapper;
  /**
   * 契約者情報照会ビジネス(DI)
   */
  private KJ_ContractorInformationBusiness kjContractorInformationBusiness;
  /**
   * 契約情報照会ビジネス(DI)
   */
  private KJ_ContractInformationBusiness kjContractInformationBusiness;
  /**
   * 日付関連共通ビジネス(DI)
   */
  private DateBusiness dateBusiness;
  /**
   * メッセージプロパティ(DI)
   */
  private MessageSource messageSource;
  /**
   * 契約管理情報ファイルヘッダーバリデーター(DI)
   */
  private ContractManagementInformationFileHeaderValidator contractManagementInformationFileHeaderValidator;
  /**
   * 支払情報ファイル登録バリデーター(DI)
   */
  private PaymentInformationFileRegistValidator paymentInformationFileRegistValidator;
  /**
   * 支払情報ファイル更新バリデーター(DI)
   */
  private PaymentInformationFileUpdateValidator paymentInformationFileUpdateValidator;
  /**
   * カスタム支払情報ファイル登録バリデーター(DI)
   */
  private Custom_PaymentInformationFileRegistValidator customPaymentInformationFileRegistValidator;
  /**
   * カスタム支払情報ファイル更新バリデーター(DI)
   */
  private Custom_PaymentInformationFileUpdateValidator customPaymentInformationFileUpdateValidator;
  /**
   * 支払情報ファイル削除バリデーター(DI)
   */
  private PaymentInformationFileDeleteValidator paymentInformationFileDeleteValidator;
  /**
   * カスタム支払情報ファイル削除バリデーター(DI)
   */
  private Custom_PaymentInformationFileDeleteValidator customPaymentInformationFileDeleteValidator;

  /**
   * ログマネジャー
   */
  private static Logger logger = LogManager.getLogger();

  /**
   * 請求入金共通マッパー(DI)
   */
  private BillingInformationCommonMapper billingInformationCommonMapper;

  /**
   * TODOビジネス(DI)
   */
  private TodoBusiness todoBusiness;

  /**
   * 確定料金・請求連携情報共通マッパー(DI)
   */
  private FixChargeBillingLinkageInformationCommonMapper fixChargeBillingLinkageInformationCommonMapper;

  /** プロパティ定義クラス(DI) */
  private PropertiesFactoryBean applicationProperties;

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.kj.KJ_PaymentInformationBusiness#
   * inquiry
   * (jp.co.unisys.enability.cis.business.kj.model.InquiryPaymentBusinessBean)
   */
  @Override
  public InquiryPaymentBusinessBean inquiry(
      InquiryPaymentBusinessBean inquiryPaymentBusinessBean) {

    // 《支払情報共通Mapper》.支払情報取得のパラメーター
    Integer id = null;
    String no = null;
    Date date = null;
    String inquiryPattern = null;

    String errMsg = null;
    try {

      // システムエラーメッセージを取得
      errMsg = getPropertiesMesseage(ECISReturnCodeConstants.RETURN_CODE_G017);

      // 照会パターンチェック
      // (《支払情報照会BusinessBean》.契約者IDがNULLではない
      // または、《支払情報照会BusinessBeann》.契約者番号がNULLまたは空文字のいずれでもなく、)
      // かつ《支払情報照会BusinessBean》.照会対象日付がNULLでない、
      // かつその他の《支払情報照会BusinessBean》の項目がNULLまたは空文字の場合
      if ((inquiryPaymentBusinessBean.getContractorId() != null || StringUtils
          .isNotEmpty(inquiryPaymentBusinessBean.getContractorNo()))
          && inquiryPaymentBusinessBean.getInqCoveredDate() != null
          && inquiryPaymentBusinessBean.getPaymentId() == null
          && StringUtils.isEmpty(inquiryPaymentBusinessBean
              .getPaymentNo())) {

        id = inquiryPaymentBusinessBean.getContractorId();
        no = inquiryPaymentBusinessBean.getContractorNo();
        date = inquiryPaymentBusinessBean.getInqCoveredDate();
        inquiryPattern = ECISKJConstants.INQUIRY_PATTERN_1;
      } else
      // (《支払情報照会BusinessBean》.支払IDがNULLではない
      // または、《支払情報照会BusinessBean》.支払番号がNULLまたは空文字のいずれでもなく、)
      // かつその他の《支払情報照会BusinessBean》の項目がNULLまたは空文字の場合
      if ((inquiryPaymentBusinessBean.getPaymentId() != null || StringUtils
          .isNotEmpty(inquiryPaymentBusinessBean.getPaymentNo()))
          && inquiryPaymentBusinessBean.getContractorId() == null
          && StringUtils.isEmpty(inquiryPaymentBusinessBean
              .getContractorNo())
          && inquiryPaymentBusinessBean.getInqCoveredDate() == null) {
        id = inquiryPaymentBusinessBean.getPaymentId();
        no = inquiryPaymentBusinessBean.getPaymentNo();
        date = null;
        inquiryPattern = ECISKJConstants.INQUIRY_PATTERN_2;
      } else
      // (《支払情報照会BusinessBean》.支払IDがNULLではない
      // または、《支払情報照会BusinessBean》.支払番号がNULLまたは空文字のいずれでもなく、)
      // 《支払情報照会BusinessBean》.照会対象日付がNULLでない、
      // かつその他の《支払情報照会BusinessBean》の項目がNULLまたは空文字の場合
      if ((inquiryPaymentBusinessBean.getPaymentId() != null || StringUtils
          .isNotEmpty(inquiryPaymentBusinessBean.getPaymentNo()))
          && inquiryPaymentBusinessBean.getInqCoveredDate() != null
          && inquiryPaymentBusinessBean.getContractorId() == null
          && StringUtils.isEmpty(inquiryPaymentBusinessBean
              .getContractorNo())) {
        id = inquiryPaymentBusinessBean.getPaymentId();
        no = inquiryPaymentBusinessBean.getPaymentNo();
        date = inquiryPaymentBusinessBean.getInqCoveredDate();
        inquiryPattern = ECISKJConstants.INQUIRY_PATTERN_3;
      } else {
        // 上記以外の場合、《支払情報照会BusinessBean》.リターンコード（P001）を設定し返却する。
        setMessageAndReturnCode(inquiryPaymentBusinessBean,
            ECISReturnCodeConstants.RETURN_CODE_P001);
        return inquiryPaymentBusinessBean;
      }

      // 支払情報を取得する。
      Map<String, Object> exampleMap = new HashMap<>();
      exampleMap.put("id", id);
      exampleMap.put("no", no);
      exampleMap.put("date", date);
      exampleMap.put("inquiryPattern", inquiryPattern);

      List<KJ_InquiryPaymentInformationEntityBean> kjInquirypaymentinformationentitybeanArray = paymentInformationCommonMapper
          .selectPayment(exampleMap);

      inquiryPaymentBusinessBean
          .setPaymentInformationList(kjInquirypaymentinformationentitybeanArray);

      inquiryPaymentBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);
      return inquiryPaymentBusinessBean;

    } catch (DataAccessException e) {
      logger.error(
          messageSource.getMessage("error.E1129", null,
              Locale.getDefault()),
          e);
      // データアクセスでエラー
      inquiryPaymentBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      inquiryPaymentBusinessBean.setMessage(errMsg);
      return inquiryPaymentBusinessBean;
    } catch (NoSuchMessageException e) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, e);
      // メッセージプロパティ不在
      inquiryPaymentBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      inquiryPaymentBusinessBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
      return inquiryPaymentBusinessBean;
    }
  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.kj.KJ_PaymentInformationBusiness#
   * regist
   * (jp.co.unisys.enability.cis.business.kj.model.RegistPaymentBusinessBean)
   */
  @Override
  public RegistPaymentBusinessBean regist(
      RegistPaymentBusinessBean registPaymentBusinessBean) {

    String errMsg = null;
    String duplicateKeyExceptionMsg = null;

    try {

      // システムエラーメッセージを取得
      errMsg = getPropertiesMesseage(ECISReturnCodeConstants.RETURN_CODE_G017);
      duplicateKeyExceptionMsg = getPropertiesMesseage(ECISReturnCodeConstants.RETURN_CODE_D023);

      // コード存在チェック
      String returnCode = checkMasterCode(
          registPaymentBusinessBean.getPaymentWayCode(),
          registPaymentBusinessBean
              .getIndividualLegalEntityCategoryCode(),
          registPaymentBusinessBean.getBillingPhoneCategoryCode());
      // エラーコードが返却された場合
      if (StringUtils.isNotEmpty(returnCode)) {

        setMessageAndReturnCode(registPaymentBusinessBean, returnCode);

        return registPaymentBusinessBean;
      }

      // 親エンティティ存在チェック
      InquiryContractorBusinessBean inquiryContractorBusinessBean = new InquiryContractorBusinessBean();
      // 《契約者情報照会BusinessBean》の設定
      inquiryContractorBusinessBean
          .setContractorId(registPaymentBusinessBean
              .getContractorId());
      inquiryContractorBusinessBean
          .setContractorNo(registPaymentBusinessBean
              .getContractorNo());
      // 契約者情報照会（ビジネス）呼び出し
      inquiryContractorBusinessBean = kjContractorInformationBusiness
          .inquiry(inquiryContractorBusinessBean);

      // 契約者情報照会（ビジネス）呼び出し判定
      if (!ECISReturnCodeConstants.RETURN_CODE_0000
          .equals(inquiryContractorBusinessBean.getReturnCode())) {
        throw new BusinessLogicException(

            messageSource.getMessage("error.E1288", new String[] {},
                Locale.getDefault()));
      }

      // 返却値が0件の場合
      if (inquiryContractorBusinessBean.getContractorInformationList()
          .isEmpty()) {
        setMessageAndReturnCode(registPaymentBusinessBean,
            ECISReturnCodeConstants.RETURN_CODE_D014);
        return registPaymentBusinessBean;
      }

      // 契約者情報リストを取得する
      // ※検索条件が契約者IDもしくは契約者NO(PKとユニーク)のためリストは必ず1件になる。
      KJ_InquiryContractorInformationEntityBean inquiryContractorInformationEntityBean = inquiryContractorBusinessBean
          .getContractorInformationList().get(FIRST_INDEX);
      // 契約者利用不能チェック
      if (!checkUnavailableFlag(inquiryContractorInformationEntityBean
          .getUnavailableFlag())) {
        setMessageAndReturnCode(registPaymentBusinessBean,
            ECISReturnCodeConstants.RETURN_CODE_D013);

        return registPaymentBusinessBean;
      }

      // 契約者支払チェック
      if (!checkDMPaymentWay(
          inquiryContractorInformationEntityBean
              .getProvideModelCode(),
          registPaymentBusinessBean.getPaymentWayCode())) {
        setMessageAndReturnCode(registPaymentBusinessBean,
            ECISReturnCodeConstants.RETURN_CODE_G033);

        return registPaymentBusinessBean;
      }
      // 契約者督促対象チェック
      // 《支払情報登録BusinessBean》.支払期限区分が"個別"、または《支払情報登録BusinessBean》前月請求合算に"否"の場合、
      if (ECISKJConstants.PAYMENT_EXPIRATION_CATEGORY_FLAG_INDIVIDUAL
          .equals(registPaymentBusinessBean
              .getPaymentExpirationIndividualSettingFlag())
          || ECISKJConstants.BILLING_ADD_UP_FLAG_UNNECESSARY
              .equals(registPaymentBusinessBean
                  .getPreviousBillingAddUpFlag())) {

        // 督促対象外フラグチェック
        boolean urgeNotCoveredFlagCheckResult = checkUrgeNotCoveredFlag(inquiryContractorInformationEntityBean
            .getUrgeNotCoveredFlag());

        // 支払期限個別設定フラグが定数.支払期限区分:個別(1)の場合
        if (!urgeNotCoveredFlagCheckResult
            && ECISKJConstants.PAYMENT_EXPIRATION_CATEGORY_FLAG_INDIVIDUAL
                .equals(registPaymentBusinessBean
                    .getPaymentExpirationIndividualSettingFlag())) {

          setMessageAndReturnCode(registPaymentBusinessBean,
              ECISReturnCodeConstants.RETURN_CODE_G047);

          return registPaymentBusinessBean;
        }

        // 前月請求合算フラグが定数.請求合算:否(0)の場合
        if (!urgeNotCoveredFlagCheckResult
            && ECISKJConstants.BILLING_ADD_UP_FLAG_UNNECESSARY
                .equals(registPaymentBusinessBean
                    .getPreviousBillingAddUpFlag())) {

          setMessageAndReturnCode(registPaymentBusinessBean,
              ECISReturnCodeConstants.RETURN_CODE_G048);

          return registPaymentBusinessBean;
        }

      }

      List<String> checkList = new ArrayList<>();

      checkList.add(registPaymentBusinessBean
          .getDirectDebitCreditCardNextMonthBillingFlag());
      checkList.add(registPaymentBusinessBean.getPaymentWayCode());
      checkList.add(registPaymentBusinessBean
          .getIndividualLegalEntityCategoryCode());
      checkList.add(registPaymentBusinessBean.getBillingName1());
      checkList.add(registPaymentBusinessBean.getBillingName2());
      checkList.add(registPaymentBusinessBean.getPrefix());
      checkList.add(registPaymentBusinessBean
          .getBillingAddressPostalCode());
      checkList.add(registPaymentBusinessBean
          .getBillingAddressPrefectures());
      checkList.add(registPaymentBusinessBean
          .getBillingAddressMunicipality());
      checkList.add(registPaymentBusinessBean.getBillingAddressSection());
      checkList.add(registPaymentBusinessBean.getBillingAddressBlock());
      checkList.add(registPaymentBusinessBean
          .getBillingAddressBuildingName());
      checkList.add(registPaymentBusinessBean.getBillingAddressRoom());
      checkList.add(registPaymentBusinessBean.getBillingPhoneNo());
      checkList.add(registPaymentBusinessBean
          .getBillingPhoneCategoryCode());
      checkList.add(registPaymentBusinessBean.getBillingMailAddress1());
      checkList.add(registPaymentBusinessBean.getBillingMailAddress2());
      checkList.add(registPaymentBusinessBean.getFree1());
      checkList.add(registPaymentBusinessBean.getFree2());

      // 支払方法チェック
      if (!checkPaymentMethod(checkList,
          inquiryContractorInformationEntityBean
              .getProvideModelCode(),
          registPaymentBusinessBean.getAccountCreditCardId())) {
        // 《支払情報登録BusinessBean》.リターンコードに（G011）を設定し処理を終了する。
        setMessageAndReturnCode(registPaymentBusinessBean,
            ECISReturnCodeConstants.RETURN_CODE_G011);
        return registPaymentBusinessBean;
      }
      AcInformation accountCreditInformation = new AcInformation();

      // 《支払情報登録BusinessBean》.口座クレカIDがNULLでない場合
      if (registPaymentBusinessBean.getAccountCreditCardId() != null) {

        // 口座クレカ情報存在チェック
        accountCreditInformation = acInformationMapper
            .selectByPrimaryKey(registPaymentBusinessBean
                .getAccountCreditCardId());

        // 返却値が0件の場合、《支払情報登録BusinessBean》.リターンコードに（P012）を返却し処理を終了する。
        if (accountCreditInformation == null) {
          setMessageAndReturnCode(registPaymentBusinessBean,
              ECISReturnCodeConstants.RETURN_CODE_P012);

          return registPaymentBusinessBean;
        }

        // 口座クレカ情報照会した際の契約者IDチェック
        if (!inquiryContractorInformationEntityBean.getContractorId()
            .equals(accountCreditInformation.getContractorId())) {
          setMessageAndReturnCode(registPaymentBusinessBean,
              ECISReturnCodeConstants.RETURN_CODE_P012);

          return registPaymentBusinessBean;
        }

        // 口座クレカ区分チェック
        if (!accountCreditInformation.getAcCatCode().equals(
            registPaymentBusinessBean.getPaymentWayCode())) {
          setMessageAndReturnCode(registPaymentBusinessBean,
              ECISReturnCodeConstants.RETURN_CODE_P066);
          return registPaymentBusinessBean;
        }

        // 口座クレカ利用不能チェック
        // 《口座クレカ情報Entity》.利用不能フラグが'1:利用不能'の場合、
        // リターンコードに（G042）を返却し処理を終了する。
        if (!checkUnavailableFlag(accountCreditInformation
            .getUnavailableFlag())) {
          setMessageAndReturnCode(registPaymentBusinessBean,
              ECISReturnCodeConstants.RETURN_CODE_G042);
          return registPaymentBusinessBean;
        }
      }

      // 対象契約者で契約者テーブルのロックを取得し、支払番号発番での重複を防止する
      paymentInformationCommonMapper.lockContractorForInsertPayment(inquiryContractorInformationEntityBean
          .getContractorId());

      // 支払番号発番
      // 発番値取得
      Integer max = paymentInformationCommonMapper
          .selectMaxPaymentNo(inquiryContractorInformationEntityBean
              .getContractorId());
      // 返却値が“99”以上の場合
      if (max >= MAX_PAYMENT_NO) {
        setMessageAndReturnCode(registPaymentBusinessBean,
            ECISReturnCodeConstants.RETURN_CODE_G024);
        return registPaymentBusinessBean;
      }

      // 支払番号生成
      max++;

      String strMax = StringConvertUtil.fillZeroNumLeft(max,
          CLEATE_PAYMENT_NO_LENGTH);

      // “P”＋（2）の文字列＋（1）の文字列
      StringBuilder paymentNo = new StringBuilder();
      paymentNo.append(ECISKJConstants.PAYMENT_NO_HEDDER);
      paymentNo.append(inquiryContractorInformationEntityBean
          .getContractorNo().substring(1));
      paymentNo.append(strMax);
      registPaymentBusinessBean.setPaymentNo(paymentNo.toString());

      // 支払登録
      Date date = new Date();
      Timestamp sysDate = new Timestamp(date.getTime());
      Payment payment = new Payment();

      // 支払情報登録
      // 契約者ID
      payment.setContractorId(inquiryContractorInformationEntityBean
          .getContractorId());
      // 支払番号
      payment.setPaymentNo(registPaymentBusinessBean.getPaymentNo());
      // 前月請求合算フラグ
      // 前月請求合算フラグがNULLまたは空文字のいずれかの場合
      if (StringUtils.isEmpty(registPaymentBusinessBean
          .getPreviousBillingAddUpFlag())) {
        payment.setPreviousBlAddUpFlag(ECISKJConstants.BILLING_ADD_UP_FLAG_NECESSARY);
      } else {
        payment.setPreviousBlAddUpFlag(registPaymentBusinessBean
            .getPreviousBillingAddUpFlag());
      }
      // 支払期限個別設定フラグ
      // 支払期限個別設定フラグがNULLまたは空文字のいずれかの場合
      if (StringUtils.isEmpty(registPaymentBusinessBean
          .getPaymentExpirationIndividualSettingFlag())) {
        payment.setPeIndividualSettingFlag(ECISKJConstants.PAYMENT_EXPIRATION_CATEGORY_FLAG_DEFAULT);
      } else {
        payment.setPeIndividualSettingFlag(registPaymentBusinessBean
            .getPaymentExpirationIndividualSettingFlag());
      }
      // 支払期限加算月数
      payment.setPeAddMonths(registPaymentBusinessBean
          .getPaymentExpirationAddMonths());
      // 支払期限日
      payment.setPeDate(registPaymentBusinessBean
          .getPaymentExpirationDate());
      // 口振クレカ翌月請求フラグが未入力の場合
      if (StringUtils.isEmpty(registPaymentBusinessBean
          .getDirectDebitCreditCardNextMonthBillingFlag())) {
        // 口振クレカ翌月請求フラグが未入力の場合
        payment.setDdCreNextMonthBlFlag(
            ECISKJConstants.DIRECT_DEBIT_CREDIT_CARD_NEXT_MONTH_BILLING_FLAG_NEXT_MONTH_BILLING);
      } else {
        // 口振クレカ翌月請求フラグが入力済みの場合
        payment.setDdCreNextMonthBlFlag(registPaymentBusinessBean
            .getDirectDebitCreditCardNextMonthBillingFlag());
      }
      // 更新回数
      payment.setUpdateCount(INT_CNT_ZERO);
      // 作成日時
      payment.setCreateTime(sysDate);
      // オンライン更新日時
      payment.setOnlineUpdateTime(sysDate);
      // オンライン更新ユーザID
      payment.setOnlineUpdateUserId(ThreadContext
          .getRequestThreadContext().get(ECISConstants.USER_ID_KEY)
          .toString());
      // 更新日時
      payment.setUpdateTime(sysDate);
      // 更新モジュールコード
      payment.setUpdateModuleCode(ThreadContext.getRequestThreadContext()
          .get(ECISConstants.CLASS_NAME_KEY).toString());

      // 《支払情報共通Dao》.シーケンス登録
      paymentMapper.insertBySequence(payment);

      // 支払履歴情報登録
      PaymentHist paymentHistory = new PaymentHist();
      insertPaymentHistory(paymentHistory, registPaymentBusinessBean,
          payment.getPaymentId(), sysDate);

      // 支払ID設定
      registPaymentBusinessBean.setPaymentId(payment.getPaymentId());

      registPaymentBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);

      return registPaymentBusinessBean;

    } catch (DuplicateKeyException e) {
      logger.error(
          messageSource.getMessage("error.E1129", null,
              Locale.getDefault()),
          e);
      // 重複エラー
      registPaymentBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_D023);
      registPaymentBusinessBean.setMessage(duplicateKeyExceptionMsg);
      return registPaymentBusinessBean;
    } catch (BusinessLogicException | DataAccessException e) {
      logger.error(
          messageSource.getMessage("error.E1129", null,
              Locale.getDefault()),
          e);
      // ビジネス失敗エラー
      // データアクセスでエラー
      registPaymentBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      registPaymentBusinessBean.setMessage(errMsg);
      return registPaymentBusinessBean;
    } catch (NoSuchMessageException e) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, e);
      // メッセージプロパティ不在エラー
      registPaymentBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      registPaymentBusinessBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
      return registPaymentBusinessBean;
    }
  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.kj.KJ_PaymentInformationBusiness#
   * update
   * (jp.co.unisys.enability.cis.business.kj.model.UpdatePaymentBusinessBean)
   */
  @Override
  public UpdatePaymentBusinessBean update(
      UpdatePaymentBusinessBean updatePaymentBusinessBean) {
    String errMsg = null;
    try {

      // システムエラーメッセージを取得
      errMsg = getPropertiesMesseage(ECISReturnCodeConstants.RETURN_CODE_G017);

      // コード存在チェック
      String returnCode = checkMasterCode(
          updatePaymentBusinessBean.getPaymentWayCode(),
          updatePaymentBusinessBean
              .getIndividualLegalEntityCategoryCode(),
          updatePaymentBusinessBean.getBillingPhoneCategoryCode());

      // 存在チェックでエラー
      if (StringUtils.isNotEmpty(returnCode)) {

        setMessageAndReturnCode(updatePaymentBusinessBean, returnCode);

        return updatePaymentBusinessBean;
      }

      // 支払情報存在チェック
      InquiryPaymentBusinessBean updateInquiryPaymentBusinessBean = new InquiryPaymentBusinessBean();
      updateInquiryPaymentBusinessBean
          .setPaymentId(updatePaymentBusinessBean.getPaymentId());
      updateInquiryPaymentBusinessBean
          .setPaymentNo(updatePaymentBusinessBean.getPaymentNo());

      // 支払情報照会（ビジネス）呼び出し
      updateInquiryPaymentBusinessBean = inquiry(updateInquiryPaymentBusinessBean);

      // 支払情報照会（ビジネス）呼び出し判定
      if (!ECISReturnCodeConstants.RETURN_CODE_0000
          .equals(updateInquiryPaymentBusinessBean.getReturnCode())) {
        throw new BusinessLogicException(

            messageSource.getMessage("error.E1288", new String[] {},
                Locale.getDefault()));
      }
      // 返却値が0件の場合
      if (updateInquiryPaymentBusinessBean.getPaymentInformationList()
          .isEmpty()) {
        setMessageAndReturnCode(updatePaymentBusinessBean,
            ECISReturnCodeConstants.RETURN_CODE_P007);
        return updatePaymentBusinessBean;

      }

      // 《支払情報照会EntityBean》取得
      KJ_InquiryPaymentInformationEntityBean inquiryPaymentInformationEntityBeanFirst = updateInquiryPaymentBusinessBean
          .getPaymentInformationList().get(FIRST_INDEX);
      // 支払ID
      Integer paymentId = inquiryPaymentInformationEntityBeanFirst
          .getPaymentId();
      // 契約者ID
      Integer contractorId = inquiryPaymentInformationEntityBeanFirst
          .getContractorId();
      List<Integer> paymentIdList = new ArrayList<Integer>();
      // 支払ID
      paymentIdList.add(paymentId);
      Map<String, Object> paymentParam = new HashMap<String, Object>();
      paymentParam.put("paymentIdList", paymentIdList);
      // 対象支払で支払テーブルのロックを取得し、契約更新時の同一支払への同時読み取りを防止する
      paymentInformationCommonMapper.lockPaymentForUpdatePayment(paymentParam);
      // 当月請求情報取得
      List<SN_CurrentMonthBillingInformationEntityBean> snCurrentMonthBillingInformationList = billingInformationCommonMapper
          .selectCurrentMonthBilling(paymentId);
      // 過去分請求情報取得
      List<SN_PastBillingInformationEntityBean> snPastBillingInformationEntityBeanList = billingInformationCommonMapper
          .selectPastBilling(contractorId, paymentId);
      // 更新対象当月確定料金・請求連携件数取得
      int updateTargetCurrentFixChargeBillingLinkageCount = 0;
      for (SN_CurrentMonthBillingInformationEntityBean currentMonthBillingInformationEntityBean : snCurrentMonthBillingInformationList) {
        Integer returnCount = fixChargeBillingLinkageInformationCommonMapper
            .countByUpdateTargetCurrentFixChargeBillingLinkage(currentMonthBillingInformationEntityBean
                .getBillingId());
        updateTargetCurrentFixChargeBillingLinkageCount = updateTargetCurrentFixChargeBillingLinkageCount
            + returnCount;
      }
      // 更新対象過去分確定料金・請求連携件数取得
      int updateTargetPastFixChargeBillingLinkageCount = 0;
      for (SN_PastBillingInformationEntityBean pastBillingInformationEntityBean : snPastBillingInformationEntityBeanList) {
        for (SN_FixChargeResultInformationEntityBean fixChargeResultInformationEntityBean : pastBillingInformationEntityBean
            .getFixChargeResultInformationList()) {
          Map<String, Object> exampleMap = new HashMap<String, Object>();
          exampleMap.put("billingId", pastBillingInformationEntityBean.getBillingId());
          exampleMap.put("contractId", fixChargeResultInformationEntityBean.getContractId());
          exampleMap.put("usePeriod", fixChargeResultInformationEntityBean.getUsePeriod());
          Integer returnCount = fixChargeBillingLinkageInformationCommonMapper
              .countByUpdateTargetPastFixChargeBillingLinkage(exampleMap);
          updateTargetPastFixChargeBillingLinkageCount = updateTargetPastFixChargeBillingLinkageCount
              + returnCount;
        }
      }
      // 更新対象確定料金・請求連携件数の合計値算出
      int updateTargetFixChargeBillingLinkageCount = updateTargetCurrentFixChargeBillingLinkageCount
          + updateTargetPastFixChargeBillingLinkageCount;

      // 《支払情報照会EntityBean》.支払適用開始日
      Date paymentSdNextDay = inquiryPaymentInformationEntityBeanFirst
          .getPaymentStartDate();

      // 最新履歴チェック
      // 《支払情報更新BusinessBean》.支払適用開始日が《支払情報照会EntityBean》.支払適用開始日前の場合、
      if (updatePaymentBusinessBean.getPaymentStartDate().before(
          paymentSdNextDay)) {
        setMessageAndReturnCode(updatePaymentBusinessBean,
            ECISReturnCodeConstants.RETURN_CODE_G001);
        return updatePaymentBusinessBean;

      } else
      // 《支払情報更新BusinessBean》.支払適用開始日が《支払情報照会EntityBean》.支払適用開始日と同日で、
      // 変更されている項目が存在する場合、エラーとする
      if (updatePaymentBusinessBean.getPaymentStartDate().compareTo(
          paymentSdNextDay) == 0) {
        // 履歴更新可否がfalseの場合のみチェックする
        if (!updatePaymentBusinessBean.isHistoryUpdate()) {

          boolean historyUpdateFlag = false;

          // 口座クレカIDが更新対象かつ変更されているか
          if (ECISConstants.FLG_OFF.equals(updatePaymentBusinessBean
              .getAccountCreditCardIdNoUpdFlag())
              && ((updatePaymentBusinessBean.getAccountCreditCardId() != null
                  && !updatePaymentBusinessBean
                      .getAccountCreditCardId().equals(
                          inquiryPaymentInformationEntityBeanFirst
                              .getAccountCreditCardId()))
                  || (updatePaymentBusinessBean
                      .getAccountCreditCardId() == null
                      && inquiryPaymentInformationEntityBeanFirst
                          .getAccountCreditCardId() != null))) {
            historyUpdateFlag = true;
          } else
          // 支払方法コードが更新対象かつ変更されているか
          if (updatePaymentBusinessBean.getPaymentWayCode() != null
              && !updatePaymentBusinessBean
                  .getPaymentWayCode()
                  .equals(StringUtils
                      .defaultString(inquiryPaymentInformationEntityBeanFirst
                          .getPaymentWayCode()))) {
            historyUpdateFlag = true;
          } else
          // 個人・法人区分コードが更新対象かつ変更されているか
          if (updatePaymentBusinessBean
              .getIndividualLegalEntityCategoryCode() != null
              && !updatePaymentBusinessBean
                  .getIndividualLegalEntityCategoryCode()
                  .equals(StringUtils
                      .defaultString(inquiryPaymentInformationEntityBeanFirst
                          .getIndividualLegalEntityCategoryCode()))) {
            historyUpdateFlag = true;
          } else
          // 請求先氏名1が更新対象かつ変更されているか
          if (updatePaymentBusinessBean.getBillingName1() != null
              && !updatePaymentBusinessBean
                  .getBillingName1()
                  .equals(StringUtils
                      .defaultString(inquiryPaymentInformationEntityBeanFirst
                          .getBillingName1()))) {
            historyUpdateFlag = true;
          } else
          // 請求先氏名2が更新対象かつ変更されているか
          if (updatePaymentBusinessBean.getBillingName2() != null
              && !updatePaymentBusinessBean
                  .getBillingName2()
                  .equals(StringUtils
                      .defaultString(inquiryPaymentInformationEntityBeanFirst
                          .getBillingName2()))) {
            historyUpdateFlag = true;
          } else
          // 敬称が更新対象かつ変更されているか
          if (updatePaymentBusinessBean.getPrefix() != null
              && !updatePaymentBusinessBean
                  .getPrefix()
                  .equals(StringUtils
                      .defaultString(inquiryPaymentInformationEntityBeanFirst
                          .getPrefix()))) {
            historyUpdateFlag = true;
          } else
          // 請求先住所（郵便番号）が更新対象かつ変更されているか
          if (updatePaymentBusinessBean.getBillingAddressPostalCode() != null
              && !updatePaymentBusinessBean
                  .getBillingAddressPostalCode()
                  .equals(StringUtils
                      .defaultString(inquiryPaymentInformationEntityBeanFirst
                          .getBillingAddressPostalCode()))) {
            historyUpdateFlag = true;
          } else
          // 請求先住所（都道府県名）が更新対象かつ変更されているか
          if (updatePaymentBusinessBean.getBillingAddressPrefectures() != null
              && !updatePaymentBusinessBean
                  .getBillingAddressPrefectures()
                  .equals(StringUtils
                      .defaultString(inquiryPaymentInformationEntityBeanFirst
                          .getBillingAddressPrefectures()))) {
            historyUpdateFlag = true;
          } else
          // 請求先住所（市区郡町村名）が更新対象かつ変更されているか
          if (updatePaymentBusinessBean.getBillingAddressMunicipality() != null
              && !updatePaymentBusinessBean
                  .getBillingAddressMunicipality()
                  .equals(StringUtils
                      .defaultString(inquiryPaymentInformationEntityBeanFirst
                          .getBillingAddressMunicipality()))) {
            historyUpdateFlag = true;
          } else
          // 請求先住所（字名・丁目）が更新対象かつ変更されているか
          if (updatePaymentBusinessBean.getBillingAddressSection() != null
              && !updatePaymentBusinessBean
                  .getBillingAddressSection()
                  .equals(StringUtils
                      .defaultString(inquiryPaymentInformationEntityBeanFirst
                          .getBillingAddressSection()))) {
            historyUpdateFlag = true;
          } else
          // 請求先住所（番地･号）が更新対象かつ変更されているか
          if (updatePaymentBusinessBean.getBillingAddressBlock() != null
              && !updatePaymentBusinessBean
                  .getBillingAddressBlock()
                  .equals(StringUtils
                      .defaultString(inquiryPaymentInformationEntityBeanFirst
                          .getBillingAddressBlock()))) {
            historyUpdateFlag = true;
          } else
          // 請求先住所（建物名）が更新対象かつ変更されているか
          if (updatePaymentBusinessBean.getBillingAddressBuildingName() != null
              && !updatePaymentBusinessBean
                  .getBillingAddressBuildingName()
                  .equals(StringUtils
                      .defaultString(inquiryPaymentInformationEntityBeanFirst
                          .getBillingAddressBuildingName()))) {
            historyUpdateFlag = true;
          } else
          // 請求先住所（部屋名）が更新対象かつ変更されているか
          if (updatePaymentBusinessBean.getBillingAddressRoom() != null
              && !updatePaymentBusinessBean
                  .getBillingAddressRoom()
                  .equals(StringUtils
                      .defaultString(inquiryPaymentInformationEntityBeanFirst
                          .getBillingAddressRoom()))) {
            historyUpdateFlag = true;
          } else
          // 請求先電話番号が更新対象かつ変更されているか
          if (updatePaymentBusinessBean.getBillingPhoneNo() != null
              && !updatePaymentBusinessBean
                  .getBillingPhoneNo()
                  .equals(StringUtils
                      .defaultString(inquiryPaymentInformationEntityBeanFirst
                          .getBillingPhoneNo()))) {
            historyUpdateFlag = true;
          } else
          // 請求先電話区分コードが更新対象かつ変更されているか
          if (updatePaymentBusinessBean.getBillingPhoneCategoryCode() != null
              && !updatePaymentBusinessBean
                  .getBillingPhoneCategoryCode()
                  .equals(StringUtils
                      .defaultString(inquiryPaymentInformationEntityBeanFirst
                          .getBillingPhoneCategoryCode()))) {
            historyUpdateFlag = true;
          } else
          // 請求先メールアドレス1が更新対象かつ変更されているか
          if (updatePaymentBusinessBean.getBillingMailAddress1() != null
              && !updatePaymentBusinessBean
                  .getBillingMailAddress1()
                  .equals(StringUtils
                      .defaultString(inquiryPaymentInformationEntityBeanFirst
                          .getBillingMailAddress1()))) {
            historyUpdateFlag = true;
          } else
          // 請求先メールアドレス2が更新対象かつ変更されているか
          if (updatePaymentBusinessBean.getBillingMailAddress2() != null
              && !updatePaymentBusinessBean
                  .getBillingMailAddress2()
                  .equals(StringUtils
                      .defaultString(inquiryPaymentInformationEntityBeanFirst
                          .getBillingMailAddress2()))) {
            historyUpdateFlag = true;
          } else
          // フリー項目1が更新対象かつ変更されているか
          if (updatePaymentBusinessBean.getFree1() != null
              && !updatePaymentBusinessBean
                  .getFree1()
                  .equals(StringUtils
                      .defaultString(inquiryPaymentInformationEntityBeanFirst
                          .getFree1()))) {
            historyUpdateFlag = true;
          } else
          // フリー項目2が更新対象かつ変更されているか
          if (updatePaymentBusinessBean.getFree2() != null
              && !updatePaymentBusinessBean
                  .getFree2()
                  .equals(StringUtils
                      .defaultString(inquiryPaymentInformationEntityBeanFirst
                          .getFree2()))) {
            historyUpdateFlag = true;
          }

          // 変更されていた場合
          if (historyUpdateFlag) {
            setMessageAndReturnCode(updatePaymentBusinessBean,
                ECISReturnCodeConstants.RETURN_CODE_G044);
            return updatePaymentBusinessBean;
          }
        }

      } else if (updatePaymentBusinessBean.getPaymentStartDate().equals(
          DateCalculateUtil.calculateDate(paymentSdNextDay, 0, 0, 1))) {
        // 《支払情報更新BusinessBean》.支払適用開始日が《支払情報照会EntityBean》.支払適用開始日+1と同日
        setMessageAndReturnCode(updatePaymentBusinessBean,
            ECISReturnCodeConstants.RETURN_CODE_G030);
        return updatePaymentBusinessBean;
      }

      // 親エンティティ存在チェック
      // 《契約者情報照会BusinessBean》の設定
      InquiryContractorBusinessBean inquiryContractorBusinessBean = new InquiryContractorBusinessBean();
      inquiryContractorBusinessBean
          .setContractorId(inquiryPaymentInformationEntityBeanFirst
              .getContractorId());

      // 契約者情報照会（ビジネス）呼び出し
      inquiryContractorBusinessBean = kjContractorInformationBusiness
          .inquiry(inquiryContractorBusinessBean);

      // 契約者情報照会（ビジネス）呼び出し判定
      if (!ECISReturnCodeConstants.RETURN_CODE_0000
          .equals(inquiryContractorBusinessBean.getReturnCode())) {
        throw new BusinessLogicException(

            messageSource.getMessage("error.E1281", new String[] {},
                Locale.getDefault()));
      }

      // 返却値0件
      if (inquiryContractorBusinessBean.getContractorInformationList()
          .isEmpty()) {
        setMessageAndReturnCode(updatePaymentBusinessBean,
            ECISReturnCodeConstants.RETURN_CODE_D014);
        return updatePaymentBusinessBean;

      }

      // 契約者情報リストを取得する
      // ※検索条件が契約者IDもしくは契約者NO(PKとユニーク)のためリストは必ず1件になる。
      KJ_InquiryContractorInformationEntityBean inquiryContractorInformationEntityBean = inquiryContractorBusinessBean
          .getContractorInformationList().get(FIRST_INDEX);

      // 《契約者情報照会BusinessBean》.利用不能フラグが“ON”の場合、
      // 契約者利用不能チェック
      if (!checkUnavailableFlag(inquiryContractorInformationEntityBean
          .getUnavailableFlag())) {
        setMessageAndReturnCode(updatePaymentBusinessBean,
            ECISReturnCodeConstants.RETURN_CODE_D013);

        return updatePaymentBusinessBean;
      }

      // 契約者支払チェック
      if (!checkDMPaymentWay(
          inquiryContractorInformationEntityBean
              .getProvideModelCode(),
          updatePaymentBusinessBean.getPaymentWayCode())) {
        setMessageAndReturnCode(updatePaymentBusinessBean,
            ECISReturnCodeConstants.RETURN_CODE_G033);

        return updatePaymentBusinessBean;
      }

      // 契約者督促対象チェック
      // 《支払情報更新BusinessBean》.支払期限区分が"個別"、または《支払情報更新BusinessBean》前月請求合算に"否"の場合、
      if (ECISKJConstants.PAYMENT_EXPIRATION_CATEGORY_FLAG_INDIVIDUAL
          .equals(updatePaymentBusinessBean
              .getPaymentExpirationIndividualSettingFlag())
          || ECISKJConstants.BILLING_ADD_UP_FLAG_UNNECESSARY
              .equals(updatePaymentBusinessBean
                  .getPreviousBillingAddUpFlag())) {

        // 督促対象外フラグチェック
        boolean urgeNotCoveredFlagCheckResult = checkUrgeNotCoveredFlag(inquiryContractorInformationEntityBean
            .getUrgeNotCoveredFlag());

        // 支払期限個別設定フラグが定数.支払期限区分:個別(1)かつチェック結果がfalseの場合、
        if (!urgeNotCoveredFlagCheckResult
            && ECISKJConstants.PAYMENT_EXPIRATION_CATEGORY_FLAG_INDIVIDUAL
                .equals(updatePaymentBusinessBean
                    .getPaymentExpirationIndividualSettingFlag())) {
          setMessageAndReturnCode(updatePaymentBusinessBean,
              ECISReturnCodeConstants.RETURN_CODE_G047);

          return updatePaymentBusinessBean;
        }
        // 前月請求合算フラグが定数.請求合算:否(0)かつチェック結果がfalseの場合、
        if (!urgeNotCoveredFlagCheckResult
            && ECISKJConstants.BILLING_ADD_UP_FLAG_UNNECESSARY
                .equals(updatePaymentBusinessBean
                    .getPreviousBillingAddUpFlag())) {
          setMessageAndReturnCode(updatePaymentBusinessBean,
              ECISReturnCodeConstants.RETURN_CODE_G048);

          return updatePaymentBusinessBean;
        }
      }

      List<String> checkList = new ArrayList<>();

      checkList.add(updatePaymentBusinessBean
          .getDirectDebitCreditCardNextMonthBillingFlag());
      checkList.add(updatePaymentBusinessBean.getPaymentWayCode());
      checkList.add(updatePaymentBusinessBean
          .getIndividualLegalEntityCategoryCode());
      checkList.add(updatePaymentBusinessBean.getBillingName1());
      checkList.add(updatePaymentBusinessBean.getBillingName2());
      checkList.add(updatePaymentBusinessBean.getPrefix());
      checkList.add(updatePaymentBusinessBean
          .getBillingAddressPostalCode());
      checkList.add(updatePaymentBusinessBean
          .getBillingAddressPrefectures());
      checkList.add(updatePaymentBusinessBean
          .getBillingAddressMunicipality());
      checkList.add(updatePaymentBusinessBean.getBillingAddressSection());
      checkList.add(updatePaymentBusinessBean.getBillingAddressBlock());
      checkList.add(updatePaymentBusinessBean
          .getBillingAddressBuildingName());
      checkList.add(updatePaymentBusinessBean.getBillingAddressRoom());
      checkList.add(updatePaymentBusinessBean.getBillingPhoneNo());
      checkList.add(updatePaymentBusinessBean
          .getBillingPhoneCategoryCode());
      checkList.add(updatePaymentBusinessBean.getBillingMailAddress1());
      checkList.add(updatePaymentBusinessBean.getBillingMailAddress2());
      checkList.add(updatePaymentBusinessBean.getFree1());
      checkList.add(updatePaymentBusinessBean.getFree2());

      // 支払方法チェック
      if (!checkPaymentMethod(checkList,
          inquiryContractorInformationEntityBean
              .getProvideModelCode(),
          updatePaymentBusinessBean.getAccountCreditCardId())) {

        setMessageAndReturnCode(updatePaymentBusinessBean,
            ECISReturnCodeConstants.RETURN_CODE_G011);
        return updatePaymentBusinessBean;
      }

      // コンテキスト.モジュールコード
      String contextModuleCode = ThreadContext.getRequestThreadContext()
          .get(ECISConstants.CLASS_NAME_KEY).toString();
      // 前月請求合算フラグおよび支払期限個別設定フラグチェック
      //  モジュールコードがCIS0006の場合かつ、
      // 《支払情報更新BusinessBean》.支払方法コードが定数.支払方法コード:振込用請求書(4)以外の場合、
      if (ECISConstants.MODULE_CODE_CUSTOM_CIS0006C
          .equals(contextModuleCode)
          && !ECISCodeConstants.PAYMENT_WAY_CODE_TRANSFER
              .equals(updatePaymentBusinessBean.getPaymentWayCode())) {
        // 支払期限個別設定フラグが定数.支払期限区分:個別(1)かつチェック結果がfalseの場合、
        if (!checkPreviousBillingAddUpFlagAndPaymentExpirationIndividualSettingFlag(
            inquiryPaymentInformationEntityBeanFirst
                .getPreviousBillingAddUpFlag(),
            inquiryPaymentInformationEntityBeanFirst
                .getPaymentExpirationIndividualSettingFlag())) {
          setMessageAndReturnCode(updatePaymentBusinessBean,
              ECISReturnCodeConstants.RETURN_CODE_G049);

          return updatePaymentBusinessBean;
        }
      }

      // 《支払情報登録BusinessBean》.口座クレカIDがNULLでない場合
      if (updatePaymentBusinessBean.getAccountCreditCardId() != null) {
        AcInformation accountCreditInformation = new AcInformation();
        // 口座クレカ情報存在チェック
        accountCreditInformation = acInformationMapper
            .selectByPrimaryKey(updatePaymentBusinessBean
                .getAccountCreditCardId());

        // 返却値が0件の場合
        if (accountCreditInformation == null) {
          setMessageAndReturnCode(updatePaymentBusinessBean,
              ECISReturnCodeConstants.RETURN_CODE_P012);
          return updatePaymentBusinessBean;
        }

        // 口座クレカ情報照会した際の契約者IDチェック
        if (!inquiryContractorInformationEntityBean.getContractorId()
            .equals(accountCreditInformation.getContractorId())) {
          setMessageAndReturnCode(updatePaymentBusinessBean,
              ECISReturnCodeConstants.RETURN_CODE_P012);
          return updatePaymentBusinessBean;
        }

        // 口座クレカ区分チェック
        // 《口座クレカ情報Entity》.口座クレカ区分コードと《支払情報更新BusinessBean》.支払方法コードが異なる場合
        if (!accountCreditInformation.getAcCatCode().equals(
            updatePaymentBusinessBean.getPaymentWayCode())) {
          setMessageAndReturnCode(updatePaymentBusinessBean,
              ECISReturnCodeConstants.RETURN_CODE_P066);

          return updatePaymentBusinessBean;

        }

        // 口座クレカ利用不能チェック
        // 《口座クレカ情報Entity》.利用不能フラグが'1:利用不能'の場合、
        // リターンコードに（G042）を返却し処理を終了する。
        if (!checkUnavailableFlag(accountCreditInformation
            .getUnavailableFlag())) {
          setMessageAndReturnCode(updatePaymentBusinessBean,
              ECISReturnCodeConstants.RETURN_CODE_G042);
          return updatePaymentBusinessBean;
        }
      }

      // 最新支払履歴適用開始日と適用開始日が一致しない場合
      // 請求作成チェックを行う
      if (!inquiryPaymentInformationEntityBeanFirst.getPaymentStartDate()
          .equals(updatePaymentBusinessBean.getPaymentStartDate())
          && !checkBillingCreation(
              inquiryPaymentInformationEntityBeanFirst
                  .getPaymentId(),
              updatePaymentBusinessBean.getPaymentStartDate())) {
        setMessageAndReturnCode(updatePaymentBusinessBean,
            ECISReturnCodeConstants.RETURN_CODE_D011);

        return updatePaymentBusinessBean;

      }
      // 支払期日取得
      Date paymentFixedDate = billingInformationCommonMapper
          .selectMaxPaymentFixedDate(paymentId);
      String paymentExpirationComparisonCheckFlag = null;
      if (paymentFixedDate == null) {
        // 支払期限比較チェックフラグ（変数）に定数.オフ(0)を設定する。
        paymentExpirationComparisonCheckFlag = ECISConstants.FLG_OFF;
      } else {
        // 支払期限比較チェックフラグ（変数）に定数.オン(1)を設定する。
        paymentExpirationComparisonCheckFlag = ECISConstants.FLG_ON;
      }

      // 次回作成する請求の支払期日（日）取得
      Date nextPaymentFixedDate = null;

      // 機能ID取得
      String functionId = null;
      // コンテキスト.モジュールコードが定数.モジュールコード定義：契約管理情報アップロード画面の場合
      if (ECISConstants.MODULE_CODE_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD_SCREEN
          .equals(contextModuleCode)) {
        functionId = ECISTodoConstants.TODO_FUNCTION_ID.S0101
            .toString();
        // コンテキスト.モジュールコードが定数.モジュールコード定義：支払情報更新画面の場合
      } else if (ECISConstants.MODULE_CODE_PAYMENT_INFORMATION_UPDATE_SCREEN
          .equals(contextModuleCode)) {
        functionId = ECISTodoConstants.TODO_FUNCTION_ID.KJ0305
            .toString();
      }

      // 《支払情報照会EntityBean》.支払期限加算月数取得
      Integer inquiryPaymentExpirationAddMonths = inquiryPaymentInformationEntityBeanFirst
          .getPaymentExpirationAddMonths();
      // 《支払情報照会EntityBean》.支払期限日取得
      Integer inquiryPaymentExpirationDate = inquiryPaymentInformationEntityBeanFirst.getPaymentExpirationDate();
      // 《支払情報更新BusinessBean》.支払期限加算月数取得
      Integer updatePaymentExpirationAddMonths = updatePaymentBusinessBean.getPaymentExpirationAddMonths();
      // 《支払情報更新BusinessBean》.支払期限日取得
      Integer updatePaymentExpirationDate = updatePaymentBusinessBean.getPaymentExpirationDate();

      // 支払期限比較チェックフラグ（変数）が定数.オン(1)かつ
      // 《支払情報更新BusinessBean》.支払期限個別設定フラグが定数.支払期限区分:個別(1)かつ
      // 《支払情報照会EntityBean》.支払期限加算月数が《支払情報更新BusinessBean》.支払期限加算月数と一致しない
      // または《支払情報照会EntityBean》.支払期限日が《支払情報更新BusinessBean》.支払期限日と一致しない場合
      if (ECISConstants.FLG_ON
          .equals(paymentExpirationComparisonCheckFlag)
          && ECISKJConstants.PAYMENT_EXPIRATION_CATEGORY_FLAG_INDIVIDUAL
              .equals(updatePaymentBusinessBean
                  .getPaymentExpirationIndividualSettingFlag())
          && (!updatePaymentExpirationAddMonths.equals(inquiryPaymentExpirationAddMonths)
              || !updatePaymentExpirationDate.equals(inquiryPaymentExpirationDate))) {
        // オンライン処理基準日
        Date onlineDate = dateBusiness
            .getProcessBaseDate(ECISConstants.EXEC_BASE_DATE_ONLINE);
        String onlineDateString = StringConvertUtil
            .convertDateToString(onlineDate, null);
        // 次回作成する請求の支払期日（年月）取得
        String nextPaymentFixedMothsAndYears = null;
        try {
          nextPaymentFixedMothsAndYears = StringConvertUtil
              .calcMonth(onlineDateString,
                  updatePaymentBusinessBean
                      .getPaymentExpirationAddMonths(),
                  EMSConstants.FORMAT_DATE_YYYYMM);
        } catch (ParseException e) {
          // エラーメッセージの出力
          SystemException se = new SystemException(
              messageSource.getMessage("error.E1294", null,
                  Locale.getDefault()),
              e);
          throw se;
        }
        // 支払期限日が定数.末日の場合
        if (ECISConstants.MATSUJITSU == updatePaymentBusinessBean
            .getPaymentExpirationDate()) {
          nextPaymentFixedDate = DateCalculateUtil
              .getEndOfMonth(StringConvertUtil.stringToDate(
                  nextPaymentFixedMothsAndYears + "01", null));
        } else {
          String paymentExpirationDate = StringConvertUtil
              .integerToString(updatePaymentBusinessBean
                  .getPaymentExpirationDate());
          nextPaymentFixedDate = StringConvertUtil.stringToDate(
              nextPaymentFixedMothsAndYears
                  + paymentExpirationDate,
              null);
        }

        // 次回作成する請求の支払期日より現在の支払期日が後である場合
        if (paymentFixedDate.after(nextPaymentFixedDate)) {
          // TODOに登録するメッセージのパラメータ
          String[] params = {
              // 契約者番号
              inquiryContractorInformationEntityBean.getContractorNo(),
              // 支払番号
              inquiryPaymentInformationEntityBeanFirst
                  .getPaymentNo() };
          // TODOビジネスBean
          TodoBusinessBean todoBean = new TodoBusinessBean();
          // サブシステムID
          todoBean.setSubsystemId(ECISConstants.SUBSYSTEM_ID_KJ);
          // 機能ID
          todoBean.setFunctionId(functionId);
          // メッセージID
          todoBean.setMessageId("todo.T1054");
          // メッセージ
          todoBean.setMessage(messageSource.getMessage(
              todoBean.getMessageId(), params,
              Locale.getDefault()));
          todoBusiness.registTodo(todoBean);
        }
      }

      // 《支払情報照会EntityBean》.前月請求合算フラグが《支払情報更新BusinessBean》.前月請求合算フラグと一致しない
      // かつ《支払情報更新BusinessBean》.前月請求合算フラグが定数.請求合算:否(0)の場合
      if (!inquiryPaymentInformationEntityBeanFirst
          .getPreviousBillingAddUpFlag().equals(
              updatePaymentBusinessBean
                  .getPreviousBillingAddUpFlag())
          && ECISKJConstants.BILLING_ADD_UP_FLAG_UNNECESSARY
              .equals(updatePaymentBusinessBean
                  .getPreviousBillingAddUpFlag())) {

        // 当月請求存在チェック
        for (SN_CurrentMonthBillingInformationEntityBean currentMonthBillingInformationEntityBean : snCurrentMonthBillingInformationList) {
          // TODOに登録するメッセージのパラメータ
          String[] params = {
              // 契約者番号
              currentMonthBillingInformationEntityBean
                  .getContractorNo(),
              // 支払番号
              currentMonthBillingInformationEntityBean
                  .getPaymentNo(),
              // 請求番号
              currentMonthBillingInformationEntityBean
                  .getBillingNo() };
          // TODOビジネスBean
          TodoBusinessBean todoBean = new TodoBusinessBean();
          // サブシステムID
          todoBean.setSubsystemId(ECISConstants.SUBSYSTEM_ID_KJ);
          // 機能ID
          todoBean.setFunctionId(functionId);
          // メッセージID
          todoBean.setMessageId("todo.T1055");
          // メッセージ
          todoBean.setMessage(messageSource.getMessage(
              todoBean.getMessageId(), params,
              Locale.getDefault()));
          todoBusiness.registTodo(todoBean);

        }

        // 過去分請求存在チェック
        for (SN_PastBillingInformationEntityBean pastBillingInformationEntityBean : snPastBillingInformationEntityBeanList) {
          // TODOに登録するメッセージのパラメータ
          String[] params = {
              // 契約者番号
              pastBillingInformationEntityBean.getContractorNo(),
              // 支払番号
              pastBillingInformationEntityBean.getPaymentNo(),
              // 請求番号
              pastBillingInformationEntityBean.getBillingNo() };

          //請求に紐付く確定料金実績の件数を取得
          FixChargeBlLinkageExample exampleMap = new FixChargeBlLinkageExample();
          exampleMap.createCriteria().andBlIdEqualTo(pastBillingInformationEntityBean.getBillingId());
          Integer fixChargeResultCount = fixChargeBlLinkageMapper
              .countByExample(exampleMap);

          //個別管理となる契約の件数を取得
          Integer individualManagementContractCount = pastBillingInformationEntityBean
              .getFixChargeResultInformationList().size();

          //備考用変数
          StringBuilder note = new StringBuilder();

          //請求に紐付く確定料金実績の件数と個別管理となる契約の件数が異なる場合
          if (!Objects.equals(fixChargeResultCount, individualManagementContractCount)) {
            //備考のメッセージを設定
            note.append(messageSource.getMessage("info.I1039", null, Locale.getDefault()));

            for (SN_FixChargeResultInformationEntityBean fixChargeResultInformationEntityBean : pastBillingInformationEntityBean
                .getFixChargeResultInformationList()) {
              //備考の作成
              note.append(ECISConstants.ENTER_CODE);
              note.append(messageSource.getMessage(
                  "info.I1038",
                  new String[] {
                      fixChargeResultInformationEntityBean.getContractNo(),
                      fixChargeResultInformationEntityBean.getUsePeriod() },
                  Locale.getDefault()));
            }
          }

          // TODOビジネスBean
          TodoBusinessBean todoBean = new TodoBusinessBean();
          // サブシステムID
          todoBean.setSubsystemId(ECISConstants.SUBSYSTEM_ID_KJ);
          // 機能ID
          todoBean.setFunctionId(functionId);
          // メッセージID
          todoBean.setMessageId("todo.T1055");
          // メッセージ
          todoBean.setMessage(messageSource.getMessage(
              todoBean.getMessageId(), params,
              Locale.getDefault()));
          // 備考
          todoBean.setNote(note.toString());
          todoBusiness.registTodo(todoBean);

        }
      }
      // 支払情報更新
      Date date = new Date();
      Timestamp sysDate = new Timestamp(date.getTime());
      Payment payment = new Payment();

      // 口振クレカ翌月請求フラグが入力済みの場合
      payment.setDdCreNextMonthBlFlag(updatePaymentBusinessBean
          .getDirectDebitCreditCardNextMonthBillingFlag());
      // 前月請求合算フラグ
      payment.setPreviousBlAddUpFlag(updatePaymentBusinessBean
          .getPreviousBillingAddUpFlag());
      // 支払期限個別設定フラグ
      payment.setPeIndividualSettingFlag(updatePaymentBusinessBean
          .getPaymentExpirationIndividualSettingFlag());
      // 支払期限加算月数
      payment.setPeAddMonths(updatePaymentBusinessBean
          .getPaymentExpirationAddMonths());
      // 支払期限日
      payment.setPeDate(updatePaymentBusinessBean
          .getPaymentExpirationDate());
      // 更新回数
      payment.setUpdateCount(inquiryPaymentInformationEntityBeanFirst
          .getUpdateCount() + 1);

      if (!updatePayment(payment,
          inquiryPaymentInformationEntityBeanFirst.getPaymentId(),
          inquiryPaymentInformationEntityBeanFirst.getUpdateCount(), sysDate)) {
        setMessageAndReturnCode(updatePaymentBusinessBean,
            ECISReturnCodeConstants.RETURN_CODE_H001);
        return updatePaymentBusinessBean;
      }

      // 《支払情報更新BusinessBean》.支払適用開始日が《支払情報照会EntityBean》.支払適用開始日後の場合
      if (updatePaymentBusinessBean.getPaymentStartDate().after(
          inquiryPaymentInformationEntityBeanFirst
              .getPaymentStartDate())) {

        PaymentHistKey paymentHistoryKey = new PaymentHistKey();
        // 支払履歴情報取得
        paymentHistoryKey
            .setPaymentId(inquiryPaymentInformationEntityBeanFirst
                .getPaymentId());
        paymentHistoryKey
            .setPaymentSd(inquiryPaymentInformationEntityBeanFirst
                .getPaymentStartDate());

        PaymentHist paymentHist = paymentHistMapper
            .selectByPrimaryKey(paymentHistoryKey);
        Integer paymentHistUpdateCount = paymentHist.getUpdateCount();
        // 支払履歴情報登録
        insertPaymentHistory(paymentHist, updatePaymentBusinessBean,
            inquiryPaymentInformationEntityBeanFirst, sysDate);

        // 初期化
        PaymentHist paymentHistory = new PaymentHist();

        // 前回支払履歴情報更新
        Calendar cal = Calendar.getInstance();
        cal.setTime(updatePaymentBusinessBean.getPaymentStartDate());
        cal.add(Calendar.DATE, -1);

        paymentHistory.setPaymentEd(cal.getTime());
        paymentHistory.setUpdateCount(paymentHistUpdateCount + 1);

        // 支払履歴情報更新
        if (!updatePaymentHistoryUseUpdate(
            paymentHistory,
            sysDate,
            inquiryPaymentInformationEntityBeanFirst.getPaymentId(),
            inquiryPaymentInformationEntityBeanFirst
                .getPaymentStartDate(),
            paymentHistUpdateCount,
            updatePaymentBusinessBean
                .getAccountCreditCardIdNoUpdFlag(),
            inquiryPaymentInformationEntityBeanFirst
                .getAccountCreditCardId())) {
          setMessageAndReturnCode(updatePaymentBusinessBean,
              ECISReturnCodeConstants.RETURN_CODE_H001);

          return updatePaymentBusinessBean;
        }
      }

      // 《支払情報更新BusinessBean》.履歴更新可否がtrueの場合
      if (updatePaymentBusinessBean.isHistoryUpdate()) {

        PaymentHistKey paymentHistoryKey = new PaymentHistKey();
        // 支払履歴情報取得

        paymentHistoryKey
            .setPaymentId(updatePaymentBusinessBean.getPaymentId());
        paymentHistoryKey
            .setPaymentSd(updatePaymentBusinessBean.getPaymentStartDate());

        PaymentHist paymentHist = paymentHistMapper
            .selectByPrimaryKey(paymentHistoryKey);
        Integer paymentHistUpdateCount = paymentHist.getUpdateCount();

        // 初期化
        PaymentHist paymentHistory = new PaymentHist();
        paymentHistory.setPwCode(updatePaymentBusinessBean.getPaymentWayCode());
        paymentHistory.setAccountCreId(updatePaymentBusinessBean.getAccountCreditCardId());
        paymentHistory.setIlcCode(updatePaymentBusinessBean.getIndividualLegalEntityCategoryCode());
        paymentHistory.setBlName1(updatePaymentBusinessBean.getBillingName1());
        paymentHistory.setBlName2(updatePaymentBusinessBean.getBillingName2());
        paymentHistory.setPrefix(updatePaymentBusinessBean.getPrefix());
        paymentHistory.setBlAddressPostalCode(updatePaymentBusinessBean.getBillingAddressPostalCode());
        paymentHistory.setBlAddressPrefectures(updatePaymentBusinessBean.getBillingAddressPrefectures());
        paymentHistory.setBlAddressMunicipality(updatePaymentBusinessBean.getBillingAddressMunicipality());
        paymentHistory.setBlAddressSection(updatePaymentBusinessBean.getBillingAddressSection());
        paymentHistory.setBlAddressBlock(updatePaymentBusinessBean.getBillingAddressBlock());
        paymentHistory.setBlAddressBuildingName(updatePaymentBusinessBean.getBillingAddressBuildingName());
        paymentHistory.setBlAddressRoom(updatePaymentBusinessBean.getBillingAddressRoom());
        paymentHistory.setBlPhoneNo(updatePaymentBusinessBean.getBillingPhoneNo());
        paymentHistory.setBlPhoneCatCode(updatePaymentBusinessBean.getBillingPhoneCategoryCode());
        paymentHistory.setBlMailAddress1(updatePaymentBusinessBean.getBillingMailAddress1());
        paymentHistory.setBlMailAddress2(updatePaymentBusinessBean.getBillingMailAddress2());
        paymentHistory.setFree1(updatePaymentBusinessBean.getFree1());
        paymentHistory.setFree2(updatePaymentBusinessBean.getFree2());
        paymentHistory.setRtAccountId(updatePaymentBusinessBean.getRemittanceAccountId());
        paymentHistory.setRtAccountBankCode(updatePaymentBusinessBean.getRemittanceAccountBankCode());
        paymentHistory.setRtAccountBankBranchCode(updatePaymentBusinessBean
            .getRemittanceAccountBankBranchCode());
        paymentHistory.setRtBtOfAccountCode(updatePaymentBusinessBean
            .getRemittanceAccountBankTypeOfAccountCode());
        paymentHistory.setRtAccountAccountNo(updatePaymentBusinessBean.getRemittanceAccountAccountNo());
        paymentHistory.setRtAccountAccountHolderName(updatePaymentBusinessBean
            .getRemittanceAccountAccountHolderName());
        paymentHistory.setRtAccountSymbol(updatePaymentBusinessBean.getRemittanceAccountSymbol());
        paymentHistory.setRtAccountNo(updatePaymentBusinessBean.getRemittanceAccountNo());

        paymentHistory.setUpdateCount(paymentHistUpdateCount + 1);

        // 支払履歴情報更新
        if (!updatePaymentHistoryUseAllUpdate(
            paymentHistory,
            sysDate,
            updatePaymentBusinessBean.getPaymentId(),
            updatePaymentBusinessBean
                .getPaymentStartDate(),
            paymentHistUpdateCount,
            updatePaymentBusinessBean
                .getAccountCreditCardIdNoUpdFlag(),
            updatePaymentBusinessBean
                .getAccountCreditCardId())) {
          setMessageAndReturnCode(updatePaymentBusinessBean,
              ECISReturnCodeConstants.RETURN_CODE_H001);

          return updatePaymentBusinessBean;
        }
      }

      // 確定料金・請求連携更新
      // 《支払情報更新BusinessBean》.前月請求合算フラグが"0"（否）の場合
      if (ECISKJConstants.BILLING_ADD_UP_FLAG_UNNECESSARY
          .equals(updatePaymentBusinessBean
              .getPreviousBillingAddUpFlag())) {
        int updateCurrentFixChargeBillingLinkageCount = 0;
        int updatePastFixChargeBillingLinkageCount = 0;
        // システム日時
        Timestamp systemTime = new Timestamp(System.currentTimeMillis());
        // コンテキスト・ユーザID
        String contextUserId = ThreadContext.getRequestThreadContext()
            .get(ECISConstants.USER_ID_KEY).toString();
        // 当月確定料金・請求連携更新
        for (SN_CurrentMonthBillingInformationEntityBean currentMonthBillingInformationEntityBean : snCurrentMonthBillingInformationList) {
          Map<String, Object> exampleMap = new HashMap<String, Object>();
          exampleMap.put("billingId", currentMonthBillingInformationEntityBean.getBillingId());
          exampleMap.put("systemTime", systemTime);
          exampleMap.put("contextUserId", contextUserId);
          exampleMap.put("contextModuleCode", contextModuleCode);
          Integer returnCount = fixChargeBillingLinkageInformationCommonMapper
              .updateCurrentFixChargeBillingLinkage(exampleMap);
          updateCurrentFixChargeBillingLinkageCount = updateCurrentFixChargeBillingLinkageCount
              + returnCount;
        }
        // 過去分確定料金・請求連携更新
        for (SN_PastBillingInformationEntityBean pastBillingInformationEntityBean : snPastBillingInformationEntityBeanList) {
          for (SN_FixChargeResultInformationEntityBean fixChargeResultInformationEntityBean : pastBillingInformationEntityBean
              .getFixChargeResultInformationList()) {
            Map<String, Object> exampleMap = new HashMap<String, Object>();
            exampleMap.put("billingId", pastBillingInformationEntityBean.getBillingId());
            exampleMap.put("contractId", fixChargeResultInformationEntityBean.getContractId());
            exampleMap.put("usePeriod", fixChargeResultInformationEntityBean.getUsePeriod());
            exampleMap.put("systemTime", systemTime);
            exampleMap.put("contextUserId", contextUserId);
            exampleMap.put("contextModuleCode", contextModuleCode);
            Integer returnCount = fixChargeBillingLinkageInformationCommonMapper
                .updatePastFixChargeBillingLinkage(exampleMap);
            updatePastFixChargeBillingLinkageCount = updatePastFixChargeBillingLinkageCount
                + returnCount;
          }
        }
        // 確定料金・請求連携更新件数の合計値算出
        int updateFixChargeBillingLinkageCount = updateCurrentFixChargeBillingLinkageCount
            + updatePastFixChargeBillingLinkageCount;
        if (updateTargetFixChargeBillingLinkageCount != updateFixChargeBillingLinkageCount) {
          setMessageAndReturnCode(updatePaymentBusinessBean,
              ECISReturnCodeConstants.RETURN_CODE_H001);
          return updatePaymentBusinessBean;
        }
      }

      updatePaymentBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);
      updatePaymentBusinessBean
          .setPaymentId(inquiryPaymentInformationEntityBeanFirst
              .getPaymentId());

      return updatePaymentBusinessBean;

    } catch (BusinessLogicException e) {
      logger.error(
          messageSource.getMessage("error.E1129", null,
              Locale.getDefault()),
          e);
      // ビジネス失敗エラー
      updatePaymentBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      updatePaymentBusinessBean.setMessage(errMsg);
      return updatePaymentBusinessBean;
    } catch (NoSuchMessageException e) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, e);
      // メッセージプロパティ不在エラー
      updatePaymentBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      updatePaymentBusinessBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);
      return updatePaymentBusinessBean;
    }
  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.kj.KJ_PaymentInformationBusiness#
   * delete
   * (jp.co.unisys.enability.cis.business.kj.model.DeletePaymentBusinessBean)
   */
  @Override
  public DeletePaymentBusinessBean delete(
      DeletePaymentBusinessBean deletePaymentBusinessBean) {

    String errMsg = null;
    try {

      // システムエラーメッセージを取得
      errMsg = getPropertiesMesseage(ECISReturnCodeConstants.RETURN_CODE_G017);

      // 支払情報存在チェック
      InquiryPaymentBusinessBean deleteInquiryPaymentBusinessBean = new InquiryPaymentBusinessBean();
      deleteInquiryPaymentBusinessBean
          .setPaymentId(deletePaymentBusinessBean.getPaymentId());
      deleteInquiryPaymentBusinessBean
          .setPaymentNo(deletePaymentBusinessBean.getPaymentNo());

      // 支払情報照会（ビジネス）呼び出し
      deleteInquiryPaymentBusinessBean = inquiry(deleteInquiryPaymentBusinessBean);

      // 支払情報取得結果判定
      // 《支払情報照会BusinessBean》.リターンコードが'0000'以外の場合
      if (!ECISReturnCodeConstants.RETURN_CODE_0000
          .equals(deleteInquiryPaymentBusinessBean.getReturnCode())) {
        throw new BusinessLogicException(messageSource.getMessage(
            "error.E1288", new String[] {}, Locale.getDefault()));
      }
      // 返却値が0件の場合
      if (deleteInquiryPaymentBusinessBean.getPaymentInformationList()
          .isEmpty()) {
        setMessageAndReturnCode(deletePaymentBusinessBean,
            ECISReturnCodeConstants.RETURN_CODE_P007);

        return deletePaymentBusinessBean;
      }

      // 《支払情報照会EntityBean》取得
      KJ_InquiryPaymentInformationEntityBean newInquiryPaymentInformationEntityBean = deleteInquiryPaymentBusinessBean
          .getPaymentInformationList().get(FIRST_INDEX);
      KJ_InquiryPaymentInformationEntityBean oldInquiryPaymentInformationEntityBean = new KJ_InquiryPaymentInformationEntityBean();
      boolean entityBeanOldFlg = false;
      if (deleteInquiryPaymentBusinessBean.getPaymentInformationList()
          .size() >= 2) {
        oldInquiryPaymentInformationEntityBean = deleteInquiryPaymentBusinessBean
            .getPaymentInformationList().get(SECOND_INDEX);

        entityBeanOldFlg = true;
      }

      // 最新履歴チェック
      // 《支払情報照会EntityBean》（最新）.支払適用開始日と《支払情報削除BusinessBean》.支払適用開始日が一致しない場合、
      if (!newInquiryPaymentInformationEntityBean.getPaymentStartDate()
          .equals(deletePaymentBusinessBean.getPaymentStartDate())) {
        setMessageAndReturnCode(deletePaymentBusinessBean,
            ECISReturnCodeConstants.RETURN_CODE_G009);

        return deletePaymentBusinessBean;
      }

      // 請求作成チェック
      if (!checkBillingCreation(
          newInquiryPaymentInformationEntityBean.getPaymentId(),
          deletePaymentBusinessBean.getPaymentStartDate())) {
        setMessageAndReturnCode(deletePaymentBusinessBean,
            ECISReturnCodeConstants.RETURN_CODE_D011);

        return deletePaymentBusinessBean;
      }

      // 契約情報存在チェック
      // 《支払情報照会EntityBean》(前回)がNULLの場合
      InquiryContractBusinessBean inquiryContractBusinessBean = new InquiryContractBusinessBean();
      if (!entityBeanOldFlg) {
        inquiryContractBusinessBean
            .setPaymentId(newInquiryPaymentInformationEntityBean
                .getPaymentId());
        inquiryContractBusinessBean = kjContractInformationBusiness
            .inquiry(inquiryContractBusinessBean);

        // 《契約情報照会BusinessBean》.リターンコードが'0000'以外の場合
        if (!ECISReturnCodeConstants.RETURN_CODE_0000
            .equals(inquiryContractBusinessBean.getReturnCode())) {
          throw new BusinessLogicException(
              messageSource.getMessage("error.E1281",
                  new String[] {}, Locale.getDefault()));
        }

        // 返却値が1件以上
        if (!inquiryContractBusinessBean.getContractInformationList()
            .isEmpty()) {
          setMessageAndReturnCode(deletePaymentBusinessBean,
              ECISReturnCodeConstants.RETURN_CODE_D006);

          return deletePaymentBusinessBean;

        }
      }

      // 支払履歴情報取得
      PaymentHistExample paymentHistoryExample = new PaymentHistExample();
      paymentHistoryExample.createCriteria().andPaymentIdEqualTo(
          newInquiryPaymentInformationEntityBean.getPaymentId());
      paymentHistoryExample
          .setOrderByClause(ECISKJConstants.PAYMENT_HIST_ORDER_BY_KEY);

      List<PaymentHist> paymentHistoryList = paymentHistMapper
          .selectByExample(paymentHistoryExample);

      // 返却値が0件の場合
      if (paymentHistoryList.isEmpty()) {
        setMessageAndReturnCode(deletePaymentBusinessBean,
            ECISReturnCodeConstants.RETURN_CODE_H001);

        return deletePaymentBusinessBean;
      }

      // 《支払履歴Entity》(最新)の取得
      PaymentHist newPaymentHistry = new PaymentHist();
      PaymentHist oldPaymentHistory = new PaymentHist();
      newPaymentHistry = paymentHistoryList.get(FIRST_INDEX);
      if (paymentHistoryList.size() >= 2) {
        // 《支払履歴Entity》(前回)の取得
        oldPaymentHistory = paymentHistoryList.get(SECOND_INDEX);
      }

      Date date = new Date();
      Timestamp sysDate = new Timestamp(date.getTime());
      Payment payment = new Payment();

      // 《支払情報照会EntityBean》(前回)がNULLの場合
      if (oldPaymentHistory == null
          || oldPaymentHistory.getPaymentId() == null) {

        // 支払情報削除
        PaymentExample deletePaymentExample = new PaymentExample();
        deletePaymentExample
            .createCriteria()
            .andPaymentIdEqualTo(
                newInquiryPaymentInformationEntityBean
                    .getPaymentId())
            .andUpdateCountEqualTo(
                deletePaymentBusinessBean.getUpdateCount());

        // 《支払Dao》.削除（選択項目）を呼び出し。
        int deleteByExampleCnt = paymentMapper
            .deleteByExample(deletePaymentExample);

        // 削除失敗の場合
        if (deleteByExampleCnt == 0) {
          setMessageAndReturnCode(deletePaymentBusinessBean,
              ECISReturnCodeConstants.RETURN_CODE_H001);

          return deletePaymentBusinessBean;
        }

      } else {
        // 《支払情報照会EntityBean》(前回)がNULLではない場合
        // 支払情報更新
        payment.setUpdateCount(newInquiryPaymentInformationEntityBean
            .getUpdateCount() + 1);

        if (!updatePayment(payment,
            newInquiryPaymentInformationEntityBean.getPaymentId(),
            deletePaymentBusinessBean.getUpdateCount(), sysDate)) {
          setMessageAndReturnCode(deletePaymentBusinessBean,
              ECISReturnCodeConstants.RETURN_CODE_H001);

          return deletePaymentBusinessBean;
        }
      }

      // 支払履歴削除
      // 最新支払履歴情報削除
      PaymentHistExample deletePaymentHistoryExample = new PaymentHistExample();
      deletePaymentHistoryExample
          .createCriteria()
          .andPaymentIdEqualTo(
              newInquiryPaymentInformationEntityBean
                  .getPaymentId())
          .andPaymentSdEqualTo(
              deletePaymentBusinessBean.getPaymentStartDate())
          .andUpdateCountEqualTo(newPaymentHistry.getUpdateCount());

      int deleteByExampleCnt = paymentHistMapper
          .deleteByExample(deletePaymentHistoryExample);

      // 返却値が0件の場合
      if (deleteByExampleCnt == 0) {
        setMessageAndReturnCode(deletePaymentBusinessBean,
            ECISReturnCodeConstants.RETURN_CODE_H001);

        return deletePaymentBusinessBean;
      }

      // 《支払情報照会EntityBean》(前回)がNULLではない場合、以下の更新処理を行う。
      if (oldInquiryPaymentInformationEntityBean != null
          && oldInquiryPaymentInformationEntityBean.getPaymentId() != null) {
        PaymentHist paymentHistory = new PaymentHist();
        // 前回支払履歴情報更新
        paymentHistory.setUpdateCount(oldPaymentHistory
            .getUpdateCount() + 1);
        paymentHistory.setPaymentEd(StringConvertUtil.stringToDate(
            ECISKJConstants.APPLY_END_DATE_MAX,
            ECISConstants.FORMAT_DATE_yyyyMMdd));
        if (!updatePaymentHistoryUseDelete(paymentHistory, sysDate,
            newInquiryPaymentInformationEntityBean.getPaymentId(),
            oldPaymentHistory.getPaymentSd(),
            oldPaymentHistory.getUpdateCount())) {
          setMessageAndReturnCode(deletePaymentBusinessBean,
              ECISReturnCodeConstants.RETURN_CODE_H001);

          return deletePaymentBusinessBean;
        }
      }

      deletePaymentBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_0000);
      deletePaymentBusinessBean
          .setPaymentId(newInquiryPaymentInformationEntityBean
              .getPaymentId());

      return deletePaymentBusinessBean;

    } catch (BusinessLogicException e) {
      logger.error(
          messageSource.getMessage("error.E1129", null,
              Locale.getDefault()),
          e);
      // ビジネス失敗エラー
      deletePaymentBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      deletePaymentBusinessBean.setMessage(errMsg);

      return deletePaymentBusinessBean;

    } catch (NoSuchMessageException e) {
      logger.error(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG, e);
      // メッセージプロパティ不在
      deletePaymentBusinessBean
          .setReturnCode(ECISReturnCodeConstants.RETURN_CODE_G017);
      deletePaymentBusinessBean
          .setMessage(ECISKJConstants.NO_SUCH_MESSAGE_EXCEPTION_EMSG);

      return deletePaymentBusinessBean;
    }

  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.kj.KJ_PaymentInformationBusiness#
   * download
   * (jp.co.unisys.enability.cis.business.kj.model.DownloadPaymentBusinessBean
   * )
   */
  @Override
  public DownloadPaymentBusinessBean download(
      DownloadPaymentBusinessBean downloadBusinessBean) {
    try {
      // オンライン処理基準日、設定
      Date onlineDate = dateBusiness
          .getProcessBaseDate(ECISConstants.EXEC_BASE_DATE_ONLINE);

      // CSV出力情報取得
      Map<String, Object> exampleMap = new HashMap<String, Object>();
      ContractManagementInformationDownloadSearchInformationBean searchInformationBean = downloadBusinessBean
          .getContractManagementInformationDownloadSearchInformationBean();
      // 契約者番号
      exampleMap.put(ECISKJConstants.S010107_SEARCH_KEY_CONTRACTOR_NO,
          searchInformationBean.getContractorNo());
      // 支払番号
      exampleMap.put(ECISKJConstants.S010107_SEARCH_KEY_PAYMENT_NO,
          searchInformationBean.getPaymentNo());
      // 支払方法に紐付く支払方法コード
      exampleMap.put(ECISKJConstants.S010107_SEARCH_KEY_PAYMENT_WAY,
          searchInformationBean.getPaymentWay());
      // 支払適用期間(開始日)
      if (StringUtils.isNotEmpty(searchInformationBean
          .getPaymentApplyTermStartDate())) {
        exampleMap
            .put(ECISKJConstants.S010107_SEARCH_KEY_PAYMENT_APPLY_TERM_START_DATE,
                StringConvertUtil.stringToDate(
                    searchInformationBean
                        .getPaymentApplyTermStartDate(),
                    ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH));
      }
      // 支払適用期間(終了日)
      if (StringUtils.isNotEmpty(searchInformationBean
          .getPaymentApplyTermEndDate())) {
        exampleMap
            .put(ECISKJConstants.S010107_SEARCH_KEY_PAYMENT_APPLY_TERM_END_DATE,
                StringConvertUtil.stringToDate(
                    searchInformationBean
                        .getPaymentApplyTermEndDate(),
                    ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH));
      }
      // オンライン処理基準日
      exampleMap
          .put(ECISKJConstants.S010107_SEARCH_KEY_ONLINE_EXECUTE_BASE_DATE,
              onlineDate);

      List<KJ_PaymentInformationFileEntityBean> paymentInformationFileEntityBeanList = paymentInformationCommonMapper
          .selectPaymentInfomationFile(exampleMap);

      // CSVファイル名生成
      StringBuilder fileName = new StringBuilder();
      fileName.append(ECISKJConstants.CONTRACT_MANAGEMENT_INFORMATION_DOWNLOAD_FILE_PREFIX_PAYMENT);
      fileName.append(ECISConstants.UNDERLINE);
      fileName.append(StringConvertUtil.convertDateToString(onlineDate,
          ECISConstants.FORMAT_DATE_yyyyMMdd));

      // 返却
      downloadBusinessBean.setDownloadFileName(fileName.toString());
      downloadBusinessBean
          .setPaymentInformationFileEntityBeanList(paymentInformationFileEntityBeanList);
    } catch (Exception e) {
      throw new SystemException(e.getMessage(), e);
    }
    return downloadBusinessBean;
  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.kj.KJ_PaymentInformationBusiness#
   * download
   * (jp.co.unisys.enability.cis.business.kj.model.DownloadPaymentBusinessBean
   * )
   */
  @Override
  public DownloadPaymentBusinessBean downloadCustom(
      DownloadPaymentBusinessBean downloadBusinessBean) {
    try {
      // オンライン処理基準日、設定
      Date onlineDate = dateBusiness
          .getProcessBaseDate(ECISConstants.EXEC_BASE_DATE_ONLINE);

      // CSV出力情報取得
      Map<String, Object> exampleMap = new HashMap<String, Object>();
      ContractManagementInformationDownloadSearchInformationBean searchInformationBean = downloadBusinessBean
          .getContractManagementInformationDownloadSearchInformationBean();
      // 契約者番号
      exampleMap.put(ECISKJConstants.S010107_SEARCH_KEY_CONTRACTOR_NO,
          searchInformationBean.getContractorNo());
      // 支払番号
      exampleMap.put(ECISKJConstants.S010107_SEARCH_KEY_PAYMENT_NO,
          searchInformationBean.getPaymentNo());
      // 支払方法に紐付く支払方法コード
      exampleMap.put(ECISKJConstants.S010107_SEARCH_KEY_PAYMENT_WAY,
          searchInformationBean.getPaymentWay());
      // 支払適用期間(開始日)
      if (StringUtils.isNotEmpty(searchInformationBean
          .getPaymentApplyTermStartDate())) {
        exampleMap
            .put(ECISKJConstants.S010107_SEARCH_KEY_PAYMENT_APPLY_TERM_START_DATE,
                StringConvertUtil.stringToDate(
                    searchInformationBean
                        .getPaymentApplyTermStartDate(),
                    ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH));
      }
      // 支払適用期間(終了日)
      if (StringUtils.isNotEmpty(searchInformationBean
          .getPaymentApplyTermEndDate())) {
        exampleMap
            .put(ECISKJConstants.S010107_SEARCH_KEY_PAYMENT_APPLY_TERM_END_DATE,
                StringConvertUtil.stringToDate(
                    searchInformationBean
                        .getPaymentApplyTermEndDate(),
                    ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH));
      }
      // オンライン処理基準日
      exampleMap
          .put(ECISKJConstants.S010107_SEARCH_KEY_ONLINE_EXECUTE_BASE_DATE,
              onlineDate);

      List<KJ_PaymentInformationFileEntityBean> paymentInformationFileEntityBeanList = paymentInformationCommonMapper
          .selectPaymentInfomationFileCustom(exampleMap);

      // CSVファイル名生成
      StringBuilder fileName = new StringBuilder();
      fileName.append(ECISKJConstants.CONTRACT_MANAGEMENT_INFORMATION_DOWNLOAD_FILE_PREFIX_PAYMENT);
      fileName.append(ECISConstants.UNDERLINE);
      fileName.append(StringConvertUtil.convertDateToString(onlineDate,
          ECISConstants.FORMAT_DATE_yyyyMMdd));

      // 返却
      downloadBusinessBean.setDownloadFileName(fileName.toString());
      downloadBusinessBean
          .setPaymentInformationFileEntityBeanList(paymentInformationFileEntityBeanList);
    } catch (Exception e) {
      throw new SystemException(e.getMessage(), e);
    }
    return downloadBusinessBean;
  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.kj.KJ_PaymentInformationBusiness#
   * csvFileCheck
   * (jp.co.unisys.enability.cis.business.kj.model.CsvFileCheckPaymentBusinessBean
   * )
   */
  @Override
  public CsvFileCheckPaymentBusinessBean csvFileCheck(
      CsvFileCheckPaymentBusinessBean csvFileCheckPaymentBusinessBean) {
    try {
      // 返却用オブジェクト生成
      CsvFileCheckPaymentBusinessBean csvResultBean = new CsvFileCheckPaymentBusinessBean();

      // エラーリスト
      List<String> errorList = new ArrayList<String>();
      // 登録オブジェクトリスト
      List<Map<Integer, String>> registList = new ArrayList<Map<Integer, String>>();
      // 更新オブジェクトリスト
      List<Map<Integer, String>> updateList = new ArrayList<Map<Integer, String>>();
      // 削除オブジェクトリスト
      List<Map<Integer, String>> deleteList = new ArrayList<Map<Integer, String>>();

      // ファイル取得
      File paymentFile = csvFileCheckPaymentBusinessBean.getUploadFile();
      String fileName = paymentFile.getName();

      // ファイル読み込み
      List<Map<Integer, String>> csvMapList = Csv
          .load(paymentFile, ECISConstants.ENCODE_TYPE_UTF8,
              ContractManagementInformationFileConfigCommon
                  .getCsvConfig(),
              new ColumnPositionMapListHandler());

      /**
       * ヘッダレコードチェック
       */
      // ファイル構成チェック
      if (ContractManagementInformationFileConfigCommon.UPLOAD_FILE_MINIMUM_LINE_COUNT > csvMapList
          .size()) {
        errorList.add(StringConvertUtil.convertErrorListString(
            fileName,
            null,
            messageSource.getMessage("error.E0028", null,
                Locale.getDefault())));
        csvResultBean.setUploadFileName(fileName);
        csvResultBean.setErrorList(errorList);
        csvResultBean.setRegistList(registList);
        csvResultBean.setUpdateList(updateList);
        csvResultBean.setDeleteList(deleteList);
        return csvResultBean;
      }

      // ヘッダレコード取得
      Map<Integer, String> headerRecord = csvMapList
          .get(ContractManagementInformationFileConfigCommon.ROW_NUMBER_HEADER);
      // 項目数チェック
      if (ContractManagementInformationFileConfigCommon.HEADER_COLUMN_COUNT != headerRecord
          .size()) {
        errorList
            .add(StringConvertUtil.convertErrorListString(
                paymentFile.getName(),
                ContractManagementInformationFileConfigCommon.HEADER_START_LINE_NUMBER,
                messageSource.getMessage("error.E0021", null,
                    Locale.getDefault())));
        csvResultBean.setUploadFileName(fileName);
        csvResultBean.setErrorList(errorList);
        csvResultBean.setRegistList(registList);
        csvResultBean.setUpdateList(updateList);
        csvResultBean.setDeleteList(deleteList);
        return csvResultBean;
      }

      // 単項目チェック
      List<String> headerErrorMessageList = contractManagementInformationFileHeaderValidator
          .validate(
              headerRecord,
              ContractManagementInformationFileConfigPayment.HEADER_FILE_KIND_MASK_STRING);
      if (headerErrorMessageList.size() > 0) {
        for (String message : headerErrorMessageList) {
          errorList
              .add(StringConvertUtil
                  .convertErrorListString(
                      fileName,
                      ContractManagementInformationFileConfigCommon.HEADER_START_LINE_NUMBER,
                      message));
        }
        csvResultBean.setUploadFileName(fileName);
        csvResultBean.setErrorList(errorList);
        csvResultBean.setRegistList(registList);
        csvResultBean.setUpdateList(updateList);
        csvResultBean.setDeleteList(deleteList);
        return csvResultBean;
      }

      /**
       * タイトルレコードチェック
       */
      Map<Integer, String> titleRecord = csvMapList
          .get(ContractManagementInformationFileConfigCommon.ROW_NUMBER_TITLE);
      // 項目数チェック
      if (ContractManagementInformationFileConfigPayment.DATA_COLUMN_COUNT != titleRecord
          .size()) {
        // データレコード項目数と一致しない場合、エラー終了
        errorList
            .add(StringConvertUtil
                .convertErrorListString(
                    fileName,
                    ContractManagementInformationFileConfigCommon.TITLE_START_LINE_NUMBER,
                    messageSource.getMessage("error.E0021",
                        null, Locale.getDefault())));
        csvResultBean.setUploadFileName(fileName);
        csvResultBean.setErrorList(errorList);
        csvResultBean.setRegistList(registList);
        csvResultBean.setUpdateList(updateList);
        csvResultBean.setDeleteList(deleteList);
        return csvResultBean;
      }

      // 各項目チェック
      // HashMapだと順番に揃わない可能性があるため、IteratorでKeyを取得
      Iterator<Integer> titleIt = titleRecord.keySet().iterator();
      while (titleIt.hasNext()) {
        // タイトルのカラム番号を取得
        Integer columnNo = titleIt.next();
        // タイトル内容を取得
        String titleValue = titleRecord.get(columnNo);
        // コンフィグの内容を取得
        String configValue = ContractManagementInformationFileConfigPayment.DATA_TITLE_ROW[columnNo
            .intValue()];
        // 一致していない場合、エラー終了
        if (!configValue.equals(titleValue)) {
          errorList
              .add(StringConvertUtil
                  .convertErrorListString(
                      fileName,
                      ContractManagementInformationFileConfigCommon.TITLE_START_LINE_NUMBER,
                      messageSource.getMessage(
                          "error.E0028", null,
                          Locale.getDefault())));
          csvResultBean.setUploadFileName(fileName);
          csvResultBean.setErrorList(errorList);
          csvResultBean.setRegistList(registList);
          csvResultBean.setUpdateList(updateList);
          csvResultBean.setDeleteList(deleteList);
          return csvResultBean;
        }
      }

      /**
       * マスタ情報取得
       */
      // 支払方法コード
      List<PwM> paymentWayMasterList = pwMMapper.selectByExample(null);
      // チェック用Setに詰め替え
      Set<String> paymentWayCodeCheckSet = new HashSet<String>();
      for (PwM paymentWayMaster : paymentWayMasterList) {
        paymentWayCodeCheckSet.add(paymentWayMaster.getPwCode());
      }
      // エラー用メッセージ設定
      String paymentWayCodeErrorMessageOption = StringUtils.join(
          paymentWayCodeCheckSet, ",");

      // 個人・法人区分コード
      List<IlcM> individualLegalEntityCategoryMasterList = ilcMMapper
          .selectByExample(null);
      // チェック用Setに詰め替え
      Set<String> individualLegalEntityCategoryMasterCodeCheckSet = new HashSet<String>();
      for (IlcM individualLegalEntityCategoryMaster : individualLegalEntityCategoryMasterList) {
        individualLegalEntityCategoryMasterCodeCheckSet
            .add(individualLegalEntityCategoryMaster.getIlcCode());
      }
      // エラー用メッセージ設定
      String individualLegalEntityCategoryMasterCodeErrorMessageOption = StringUtils
          .join(individualLegalEntityCategoryMasterCodeCheckSet, ",");

      // 電話番号区分コード
      List<PhoneNoCatM> phoneNoCategoryMasterList = phoneNoCatMMapper
          .selectByExample(null);
      // チェック用Setに詰め替え
      Set<String> phoneNoCategoryMasterCodeCheckSet = new HashSet<String>();
      for (PhoneNoCatM phoneNoCategoryMaster : phoneNoCategoryMasterList) {
        phoneNoCategoryMasterCodeCheckSet.add(phoneNoCategoryMaster
            .getPhoneNoCatCode());
      }
      // エラー用メッセージ設定
      String phoneNoCategoryMasterCodeErrorMessageOption = StringUtils
          .join(phoneNoCategoryMasterCodeCheckSet, ",");

      // 登録・更新・削除区分エラー用メッセージ設定
      String registUpdateDeleteCategoryErrorMessageOption = StringUtils
          .join(new String[] {
              ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER,
              ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_UPDATE,
              ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_DELETE },
              ",");

      /**
       * データレコードチェック
       */
      // データレコードの件数分処理を行う
      for (int i = ContractManagementInformationFileConfigCommon.ROW_NUMBER_DATA; i < csvMapList
          .size(); i++) {
        // 出力用行番号設定
        final int outputRowNumber = i + 1;

        // データレコードエラーリスト生成
        List<String> dataRecordErrorList = new ArrayList<String>();

        // データレコード取得
        Map<Integer, String> dataRecord = csvMapList.get(i);

        // 項目数チェック
        if (ContractManagementInformationFileConfigPayment.DATA_COLUMN_COUNT != dataRecord
            .size()) {
          // 項目数が一致しない場合、エラーリストに追加し、処理を終了する
          dataRecordErrorList.add(StringConvertUtil
              .convertErrorListString(fileName, outputRowNumber,
                  messageSource.getMessage("error.E0021",
                      null, Locale.getDefault())));
          errorList.addAll(dataRecordErrorList);

          // 処理を終了する。
          csvResultBean.setUploadFileName(fileName);
          csvResultBean.setErrorList(errorList);
          csvResultBean.setRegistList(registList);
          csvResultBean.setUpdateList(updateList);
          csvResultBean.setDeleteList(deleteList);
          return csvResultBean;
        }

        // スキップ判定
        String registerUpdateDeleteCategory = dataRecord
            .get(ContractManagementInformationFileConfigPayment.DATA_REGISTER_UPDATE_DELETE_CATEGORY_INDEX);
        if (StringUtils.isEmpty(registerUpdateDeleteCategory)) {
          continue;
        }

        // 単項目チェック
        // バリデーションエラーメッセージ用リスト生成
        List<String> validationErrorMessageList = new ArrayList<String>();
        // 登録・更新・削除区分の値により、チェックメソッドを分岐
        switch (registerUpdateDeleteCategory) {
          case ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER:
            // 登録バリデーション実行
            validationErrorMessageList = paymentInformationFileRegistValidator
                .validate(dataRecord);
            break;
          case ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_UPDATE:
            // 更新バリデーション実行
            validationErrorMessageList = paymentInformationFileUpdateValidator
                .validate(dataRecord);
            break;
          case ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_DELETE:
            // 削除バリデーション実行
            validationErrorMessageList = paymentInformationFileDeleteValidator
                .validate(dataRecord);
            break;
          default:
            // 登録・更新・削除区分が不正な場合、エラーメッセージ設定
            dataRecordErrorList
                .add(StringConvertUtil.convertErrorListString(
                    fileName,
                    outputRowNumber,
                    messageSource
                        .getMessage(
                            "validation.range",
                            new String[] {
                                ContractManagementInformationFileConfigPayment.DATA_REGISTER_UPDATE_DELETE_CATEGORY_NAME,
                                registUpdateDeleteCategoryErrorMessageOption },
                            Locale.getDefault())));
        }

        // バリデーションエラーメッセージにファイル名と行数を追加し、データレコードエラーリストに追加
        for (String validationErrorMessage : validationErrorMessageList) {
          dataRecordErrorList.add(StringConvertUtil
              .convertErrorListString(fileName, outputRowNumber,
                  validationErrorMessage));
        }

        // 登録・更新区分が登録または更新の場合のみチェック
        if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER
            .equals(registerUpdateDeleteCategory)
            || ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_UPDATE
                .equals(registerUpdateDeleteCategory)) {

          // 支払方法コードチェック
          String paymentWayCode = dataRecord
              .get(ContractManagementInformationFileConfigPayment.DATA_PAYMENT_WAY_CODE_INDEX);
          if (!StringUtils.isEmpty(paymentWayCode)) {
            if (!paymentWayCodeCheckSet.contains(paymentWayCode)) {
              dataRecordErrorList
                  .add(StringConvertUtil
                      .convertErrorListString(
                          fileName,
                          outputRowNumber,
                          messageSource
                              .getMessage(
                                  "validation.range",
                                  new String[] {
                                      ContractManagementInformationFileConfigPayment.DATA_PAYMENT_WAY_CODE_NAME,
                                      paymentWayCodeErrorMessageOption },
                                  Locale.getDefault())));
            } else {
              /**
               * 支払方法区分が正しい場合のみ、口座クレカIDチェック
               */
              // 口座クレカID入力チェック
              // 支払方法がコンビニ収納で、かつ口座クレカIDが設定されている場合、エラー
              String accountCreditCardId = dataRecord
                  .get(ContractManagementInformationFileConfigPayment.DATA_ACCOUNT_CREDIT_CARD_ID_INDEX);
              if (ECISCodeConstants.PAYMENT_WAY_CODE_CONVENI
                  .equals(paymentWayCode)
                  && StringUtils
                      .isNotEmpty(accountCreditCardId)) {
                dataRecordErrorList.add(StringConvertUtil
                    .convertErrorListString(fileName,
                        outputRowNumber,
                        messageSource.getMessage(
                            "error.E1009", null,
                            Locale.getDefault())));
              }
              // 口座クレカID未入力チェック
              // 支払方法がコンビニ収納以外で、かつ口座クレカIDが設定されていない場合、エラー
              if (!ECISCodeConstants.PAYMENT_WAY_CODE_CONVENI
                  .equals(paymentWayCode)
                  && StringUtils.isEmpty(accountCreditCardId)) {
                dataRecordErrorList.add(StringConvertUtil
                    .convertErrorListString(fileName,
                        outputRowNumber,
                        messageSource.getMessage(
                            "error.E1008", null,
                            Locale.getDefault())));
              }
            }
          }

          // 個人・法人区分コードチェック
          String individualLegalEntityCategoryCode = dataRecord
              .get(ContractManagementInformationFileConfigPayment.DATA_INDIVIDUAL_LEGAL_ENTITY_CATEGORY_CODE_INDEX);
          if (!StringUtils.isEmpty(individualLegalEntityCategoryCode)
              && !individualLegalEntityCategoryMasterCodeCheckSet
                  .contains(individualLegalEntityCategoryCode)) {
            dataRecordErrorList
                .add(StringConvertUtil.convertErrorListString(
                    fileName,
                    outputRowNumber,
                    messageSource
                        .getMessage(
                            "validation.range",
                            new String[] {
                                ContractManagementInformationFileConfigPayment.DATA_INDIVIDUAL_LEGAL_ENTITY_CATEGORY_CODE_NAME,
                                individualLegalEntityCategoryMasterCodeErrorMessageOption },
                            Locale.getDefault())));
          }

          // 請求先電話区分コードチェック
          String billingPhoneCategoryCode = dataRecord
              .get(ContractManagementInformationFileConfigPayment.DATA_BILLING_PHONE_CATEGORY_CODE_INDEX);
          if (!StringUtils.isEmpty(billingPhoneCategoryCode)
              && !phoneNoCategoryMasterCodeCheckSet
                  .contains(billingPhoneCategoryCode)) {
            dataRecordErrorList
                .add(StringConvertUtil.convertErrorListString(
                    fileName,
                    outputRowNumber,
                    messageSource
                        .getMessage(
                            "validation.range",
                            new String[] {
                                ContractManagementInformationFileConfigPayment.DATA_BILLING_PHONE_CATEGORY_CODE_NAME,
                                phoneNoCategoryMasterCodeErrorMessageOption },
                            Locale.getDefault())));
          }

          // 請求先情報チェック
          // Bean設定
          CheckBillingInformationUtilBean checkBillingInfoBean = new CheckBillingInformationUtilBean();
          // 個人・法人区分コード
          checkBillingInfoBean
              .setIndividualLegalEntityCategoryCode(dataRecord
                  .get(ContractManagementInformationFileConfigPayment.DATA_INDIVIDUAL_LEGAL_ENTITY_CATEGORY_CODE_INDEX));
          // 請求先氏名1
          checkBillingInfoBean
              .setBillingName1(dataRecord
                  .get(ContractManagementInformationFileConfigPayment.DATA_BILLING_NAME1_INDEX));
          // 請求先氏名2
          checkBillingInfoBean
              .setBillingName2(dataRecord
                  .get(ContractManagementInformationFileConfigPayment.DATA_BILLING_NAME2_INDEX));
          // 敬称
          checkBillingInfoBean
              .setPrefix(dataRecord
                  .get(ContractManagementInformationFileConfigPayment.DATA_PREFIX_INDEX));
          // 請求先住所（郵便番号）
          checkBillingInfoBean
              .setBillingAddressPostalCode(dataRecord
                  .get(ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_POSTAL_CODE_INDEX));
          // 請求先住所（都道府県名）
          checkBillingInfoBean
              .setBillingAddressPrefectures(dataRecord
                  .get(ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_PREFECTURES_INDEX));
          // 請求先住所（市区郡町村名）
          checkBillingInfoBean
              .setBillingAddressMunicipality(dataRecord
                  .get(ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_MUNICIPALITY_INDEX));
          // 請求先住所（字名・丁目）
          checkBillingInfoBean
              .setBillingAddressSection(dataRecord
                  .get(ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_SECTION_INDEX));
          // 請求先住所（番地･号）
          checkBillingInfoBean
              .setBillingAddressBlock(dataRecord
                  .get(ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_BLOCK_INDEX));
          // 請求先住所（建物名）
          checkBillingInfoBean
              .setBillingAddressBuildingName(dataRecord
                  .get(ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_BUILDING_NAME_INDEX));
          // 請求先住所（部屋名）
          checkBillingInfoBean
              .setBillingAddressRoom(dataRecord
                  .get(ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_ROOM_INDEX));
          // 請求先電話番号
          checkBillingInfoBean
              .setBillingPhoneNo(dataRecord
                  .get(ContractManagementInformationFileConfigPayment.DATA_BILLING_PHONE_NO_INDEX));
          // 請求先電話区分コード
          checkBillingInfoBean
              .setBillingPhoneCategoryCode1(dataRecord
                  .get(ContractManagementInformationFileConfigPayment.DATA_BILLING_PHONE_CATEGORY_CODE_INDEX));
          // 請求先メールアドレス1
          checkBillingInfoBean
              .setBillingMailAddress1(dataRecord
                  .get(ContractManagementInformationFileConfigPayment.DATA_BILLING_MAIL_ADDRESS1_INDEX));
          // 請求先メールアドレス2
          checkBillingInfoBean
              .setBillingMailAddress2(dataRecord
                  .get(ContractManagementInformationFileConfigPayment.DATA_BILLING_MAIL_ADDRESS2_INDEX));

          // 連絡先情報入力チェック
          if (!KJ_CommonUtil
              .checkBillDestinationInformation(checkBillingInfoBean)) {
            dataRecordErrorList.add(StringConvertUtil
                .convertErrorListString(fileName,
                    outputRowNumber, messageSource
                        .getMessage("error.E1047",
                            null,
                            Locale.getDefault())));
          }

          // 請求先メールアドレス1、2のチェック
          if (!KJ_CommonUtil
              .checkMailAddressCorrelation(
                  dataRecord
                      .get(ContractManagementInformationFileConfigPayment.DATA_BILLING_MAIL_ADDRESS1_INDEX),
                  dataRecord
                      .get(ContractManagementInformationFileConfigPayment.DATA_BILLING_MAIL_ADDRESS2_INDEX))) {
            dataRecordErrorList.add(StringConvertUtil
                .convertErrorListString(fileName,
                    outputRowNumber, messageSource
                        .getMessage("error.E1220",
                            null,
                            Locale.getDefault())));
          }
        }

        // データレコードエラーリストチェック
        if (!dataRecordErrorList.isEmpty()) {
          // データレコードエラーリストが存在する場合
          // 処理用オブジェクトには格納しない
          errorList.addAll(dataRecordErrorList);
          continue;
        }

        // データレコード振分
        Map<Integer, String> resultDataRecordMap = new HashMap<Integer, String>(
            dataRecord);
        // 行番号設定
        // 実際の行数（インデックス＋１）を設定する
        resultDataRecordMap
            .put(ContractManagementInformationFileConfigCommon.DATA_ROW_NO_INDEX,
                String.valueOf(outputRowNumber));
        // 登録・更新・削除により振分
        if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER
            .equals(registerUpdateDeleteCategory)) {
          // 登録の場合、登録オブジェクトリストに追加
          registList.add(resultDataRecordMap);
        } else if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_UPDATE
            .equals(registerUpdateDeleteCategory)) {
          // 更新の場合、更新オブジェクトリストに追加
          updateList.add(resultDataRecordMap);
        } else if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_DELETE
            .equals(registerUpdateDeleteCategory)) {
          // 削除の場合、削除オブジェクトリストに追加
          deleteList.add(resultDataRecordMap);
        }
      }

      // オブジェクト返却
      csvResultBean.setUploadFileName(fileName);
      csvResultBean.setErrorList(errorList);
      csvResultBean.setRegistList(registList);
      csvResultBean.setUpdateList(updateList);
      csvResultBean.setDeleteList(deleteList);
      return csvResultBean;
    } catch (Exception e) {
      throw new SystemException(e.getMessage(), e);
    }
  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.business.kj.KJ_PaymentInformationBusiness#
   * csvFileCheck
   * (jp.co.unisys.enability.cis.business.kj.model.CsvFileCheckPaymentBusinessBean
   * )
   */
  @Override
  public CsvFileCheckPaymentBusinessBean csvFileCheckCustom(
      CsvFileCheckPaymentBusinessBean csvFileCheckPaymentBusinessBean) {
    try {
      // 返却用オブジェクト生成
      CsvFileCheckPaymentBusinessBean csvResultBean = new CsvFileCheckPaymentBusinessBean();

      // エラーリスト
      List<String> errorList = new ArrayList<String>();
      // 登録オブジェクトリスト
      List<Map<Integer, String>> registList = new ArrayList<Map<Integer, String>>();
      // 更新オブジェクトリスト
      List<Map<Integer, String>> updateList = new ArrayList<Map<Integer, String>>();
      // 削除オブジェクトリスト
      List<Map<Integer, String>> deleteList = new ArrayList<Map<Integer, String>>();

      // ファイル取得
      File paymentFile = csvFileCheckPaymentBusinessBean.getUploadFile();
      String fileName = paymentFile.getName();

      // ファイル読み込み
      List<Map<Integer, String>> csvMapList = Csv
          .load(paymentFile, ECISConstants.ENCODE_TYPE_UTF8,
              ContractManagementInformationFileConfigCommon
                  .getCsvConfig(),
              new ColumnPositionMapListHandler());

      /**
       * ヘッダレコードチェック
       */
      // ファイル構成チェック
      if (ContractManagementInformationFileConfigCommon.UPLOAD_FILE_MINIMUM_LINE_COUNT > csvMapList
          .size()) {
        errorList.add(StringConvertUtil.convertErrorListString(
            fileName,
            null,
            messageSource.getMessage("error.E0028", null,
                Locale.getDefault())));
        csvResultBean.setUploadFileName(fileName);
        csvResultBean.setErrorList(errorList);
        csvResultBean.setRegistList(registList);
        csvResultBean.setUpdateList(updateList);
        csvResultBean.setDeleteList(deleteList);
        return csvResultBean;
      }

      // ヘッダレコード取得
      Map<Integer, String> headerRecord = csvMapList
          .get(ContractManagementInformationFileConfigCommon.ROW_NUMBER_HEADER);
      // 項目数チェック
      if (ContractManagementInformationFileConfigCommon.HEADER_COLUMN_COUNT != headerRecord
          .size()) {
        errorList
            .add(StringConvertUtil.convertErrorListString(
                paymentFile.getName(),
                ContractManagementInformationFileConfigCommon.HEADER_START_LINE_NUMBER,
                messageSource.getMessage("error.E0021", null,
                    Locale.getDefault())));
        csvResultBean.setUploadFileName(fileName);
        csvResultBean.setErrorList(errorList);
        csvResultBean.setRegistList(registList);
        csvResultBean.setUpdateList(updateList);
        csvResultBean.setDeleteList(deleteList);
        return csvResultBean;
      }

      // 単項目チェック
      List<String> headerErrorMessageList = contractManagementInformationFileHeaderValidator
          .validate(
              headerRecord,
              Custom_ContractManagementInformationFileConfigPayment.HEADER_FILE_KIND_MASK_STRING);
      if (headerErrorMessageList.size() > 0) {
        for (String message : headerErrorMessageList) {
          errorList
              .add(StringConvertUtil
                  .convertErrorListString(
                      fileName,
                      ContractManagementInformationFileConfigCommon.HEADER_START_LINE_NUMBER,
                      message));
        }
        csvResultBean.setUploadFileName(fileName);
        csvResultBean.setErrorList(errorList);
        csvResultBean.setRegistList(registList);
        csvResultBean.setUpdateList(updateList);
        csvResultBean.setDeleteList(deleteList);
        return csvResultBean;
      }

      /**
       * タイトルレコードチェック
       */
      Map<Integer, String> titleRecord = csvMapList
          .get(ContractManagementInformationFileConfigCommon.ROW_NUMBER_TITLE);
      // 項目数チェック
      if (Custom_ContractManagementInformationFileConfigPayment.DATA_COLUMN_COUNT != titleRecord
          .size()) {
        // データレコード項目数と一致しない場合、エラー終了
        errorList
            .add(StringConvertUtil
                .convertErrorListString(
                    fileName,
                    ContractManagementInformationFileConfigCommon.TITLE_START_LINE_NUMBER,
                    messageSource.getMessage("error.E0021",
                        null, Locale.getDefault())));
        csvResultBean.setUploadFileName(fileName);
        csvResultBean.setErrorList(errorList);
        csvResultBean.setRegistList(registList);
        csvResultBean.setUpdateList(updateList);
        csvResultBean.setDeleteList(deleteList);
        return csvResultBean;
      }

      // 各項目チェック
      // HashMapだと順番に揃わない可能性があるため、IteratorでKeyを取得
      Iterator<Integer> titleIt = titleRecord.keySet().iterator();
      while (titleIt.hasNext()) {
        // タイトルのカラム番号を取得
        Integer columnNo = titleIt.next();
        // タイトル内容を取得
        String titleValue = titleRecord.get(columnNo);
        // コンフィグの内容を取得
        String configValue = Custom_ContractManagementInformationFileConfigPayment.DATA_TITLE_ROW[columnNo
            .intValue()];
        // 一致していない場合、エラー終了
        if (!configValue.equals(titleValue)) {
          errorList
              .add(StringConvertUtil
                  .convertErrorListString(
                      fileName,
                      ContractManagementInformationFileConfigCommon.TITLE_START_LINE_NUMBER,
                      messageSource.getMessage(
                          "error.E0028", null,
                          Locale.getDefault())));
          csvResultBean.setUploadFileName(fileName);
          csvResultBean.setErrorList(errorList);
          csvResultBean.setRegistList(registList);
          csvResultBean.setUpdateList(updateList);
          csvResultBean.setDeleteList(deleteList);
          return csvResultBean;
        }
      }

      /**
       * マスタ情報取得
       */
      // 支払方法コード
      List<PwM> paymentWayMasterList = pwMMapper.selectByExample(null);
      // チェック用Setに詰め替え
      Set<String> paymentWayCodeCheckSet = new HashSet<String>();
      for (PwM paymentWayMaster : paymentWayMasterList) {
        paymentWayCodeCheckSet.add(paymentWayMaster.getPwCode());
      }
      // エラー用メッセージ設定
      String paymentWayCodeErrorMessageOption = StringUtils.join(
          paymentWayCodeCheckSet, ",");

      // 個人・法人区分コード
      List<IlcM> individualLegalEntityCategoryMasterList = ilcMMapper
          .selectByExample(null);
      // チェック用Setに詰め替え
      Set<String> individualLegalEntityCategoryMasterCodeCheckSet = new HashSet<String>();
      for (IlcM individualLegalEntityCategoryMaster : individualLegalEntityCategoryMasterList) {
        individualLegalEntityCategoryMasterCodeCheckSet
            .add(individualLegalEntityCategoryMaster.getIlcCode());
      }
      // エラー用メッセージ設定
      String individualLegalEntityCategoryMasterCodeErrorMessageOption = StringUtils
          .join(individualLegalEntityCategoryMasterCodeCheckSet, ",");

      // 電話番号区分コード
      List<PhoneNoCatM> phoneNoCategoryMasterList = phoneNoCatMMapper
          .selectByExample(null);
      // チェック用Setに詰め替え
      Set<String> phoneNoCategoryMasterCodeCheckSet = new HashSet<String>();
      for (PhoneNoCatM phoneNoCategoryMaster : phoneNoCategoryMasterList) {
        phoneNoCategoryMasterCodeCheckSet.add(phoneNoCategoryMaster
            .getPhoneNoCatCode());
      }
      // エラー用メッセージ設定
      String phoneNoCategoryMasterCodeErrorMessageOption = StringUtils
          .join(phoneNoCategoryMasterCodeCheckSet, ",");

      // 登録・更新・削除区分エラー用メッセージ設定
      String registUpdateDeleteCategoryErrorMessageOption = StringUtils
          .join(new String[] {
              ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER,
              ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_UPDATE,
              ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_DELETE },
              ",");

      /**
       * データレコードチェック
       */
      // データレコードの件数分処理を行う
      for (int i = ContractManagementInformationFileConfigCommon.ROW_NUMBER_DATA; i < csvMapList
          .size(); i++) {
        // 出力用行番号設定
        final int outputRowNumber = i + 1;

        // データレコードエラーリスト生成
        List<String> dataRecordErrorList = new ArrayList<String>();

        // データレコード取得
        Map<Integer, String> dataRecord = csvMapList.get(i);

        // 項目数チェック
        if (Custom_ContractManagementInformationFileConfigPayment.DATA_COLUMN_COUNT != dataRecord
            .size()) {
          // 項目数が一致しない場合、エラーリストに追加し、処理を終了する
          dataRecordErrorList.add(StringConvertUtil
              .convertErrorListString(fileName, outputRowNumber,
                  messageSource.getMessage("error.E0021",
                      null, Locale.getDefault())));
          errorList.addAll(dataRecordErrorList);

          // 処理を終了する。
          csvResultBean.setUploadFileName(fileName);
          csvResultBean.setErrorList(errorList);
          csvResultBean.setRegistList(registList);
          csvResultBean.setUpdateList(updateList);
          csvResultBean.setDeleteList(deleteList);
          return csvResultBean;
        }

        // スキップ判定
        String registerUpdateDeleteCategory = dataRecord
            .get(Custom_ContractManagementInformationFileConfigPayment.DATA_REGISTER_UPDATE_DELETE_CATEGORY_INDEX);
        if (StringUtils.isEmpty(registerUpdateDeleteCategory)) {
          continue;
        }

        // 単項目チェック
        // バリデーションエラーメッセージ用リスト生成
        List<String> validationErrorMessageList = new ArrayList<String>();
        // 登録・更新・削除区分の値により、チェックメソッドを分岐
        switch (registerUpdateDeleteCategory) {
          case ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER:
            // 登録バリデーション実行
            validationErrorMessageList = customPaymentInformationFileRegistValidator
                .validate(dataRecord);
            break;
          case ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_UPDATE:
            // 更新バリデーション実行
            validationErrorMessageList = customPaymentInformationFileUpdateValidator
                .validate(dataRecord);
            break;
          case ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_DELETE:
            // 削除バリデーション実行
            validationErrorMessageList = customPaymentInformationFileDeleteValidator
                .validate(dataRecord);
            break;
          default:
            // 登録・更新・削除区分が不正な場合、エラーメッセージ設定
            dataRecordErrorList
                .add(StringConvertUtil.convertErrorListString(
                    fileName,
                    outputRowNumber,
                    messageSource
                        .getMessage(
                            "validation.range",
                            new String[] {
                                Custom_ContractManagementInformationFileConfigPayment.DATA_REGISTER_UPDATE_DELETE_CATEGORY_NAME,
                                registUpdateDeleteCategoryErrorMessageOption },
                            Locale.getDefault())));
        }

        // バリデーションエラーメッセージにファイル名と行数を追加し、データレコードエラーリストに追加
        for (String validationErrorMessage : validationErrorMessageList) {
          dataRecordErrorList.add(StringConvertUtil
              .convertErrorListString(fileName, outputRowNumber,
                  validationErrorMessage));
        }

        // 登録・更新区分が登録または更新の場合のみチェック
        if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER
            .equals(registerUpdateDeleteCategory)
            || ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_UPDATE
                .equals(registerUpdateDeleteCategory)) {

          // プロパティ.請求合算要否登録制御を取得
          String billingaddupcontrol = RK_PropertyUtil.getProperty(applicationProperties,
              "billing.add.up.control");

          // 支払方法コードチェック
          String paymentWayCode = dataRecord
              .get(Custom_ContractManagementInformationFileConfigPayment.DATA_PAYMENT_WAY_CODE_INDEX);
          // 支払期限区分チェック
          String paymentExpirationCategory = dataRecord
              .get(Custom_ContractManagementInformationFileConfigPayment.DATA_PAYMENT_EXPIRATION_CATEGORY_INDEX);
          // 請求合算フラグチェック
          String billingAddUpFlag = dataRecord
              .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADD_UP_FLAG_INDEX);
          // 口振クレカ翌月請求フラグチェック
          String directDebitCreditCardNextMonthBillingFlag = dataRecord
              .get(Custom_ContractManagementInformationFileConfigPayment.DATA_DIRECT_DEBIT_CREDIT_CARD_NEXT_MONTH_BILLING_FLAG_INDEX);

          if (!StringUtils.isEmpty(paymentWayCode)) {
            if (!paymentWayCodeCheckSet.contains(paymentWayCode)) {
              dataRecordErrorList
                  .add(StringConvertUtil
                      .convertErrorListString(
                          fileName,
                          outputRowNumber,
                          messageSource
                              .getMessage(
                                  "validation.range",
                                  new String[] {
                                      Custom_ContractManagementInformationFileConfigPayment.DATA_PAYMENT_WAY_CODE_NAME,
                                      paymentWayCodeErrorMessageOption },
                                  Locale.getDefault())));
            } else {
              /**
               * 支払方法区分が正しい場合のみ、口座クレカIDチェック
               */
              // 口座クレカID入力チェック
              // 支払方法がコンビニ収納で、かつ口座クレカIDが設定されている場合、エラー
              String accountCreditCardId = dataRecord
                  .get(Custom_ContractManagementInformationFileConfigPayment.DATA_ACCOUNT_CREDIT_CARD_ID_INDEX);
              if (ECISCodeConstants.PAYMENT_WAY_CODE_CONVENI
                  .equals(paymentWayCode)
                  && StringUtils
                      .isNotEmpty(accountCreditCardId)) {
                dataRecordErrorList.add(StringConvertUtil
                    .convertErrorListString(fileName,
                        outputRowNumber,
                        messageSource.getMessage(
                            "error.E1009", null,
                            Locale.getDefault())));
              }
              // 口座クレカID未入力チェック
              // 支払方法がコンビニ収納以外で、かつ口座クレカIDが設定されていない場合、エラー
              if (!ECISCodeConstants.PAYMENT_WAY_CODE_CONVENI
                  .equals(paymentWayCode)
                  && StringUtils.isEmpty(accountCreditCardId)) {
                dataRecordErrorList.add(StringConvertUtil
                    .convertErrorListString(fileName,
                        outputRowNumber,
                        messageSource.getMessage(
                            "error.E1008", null,
                            Locale.getDefault())));
              }
              // 支払期限区分チェック
              if (!ECISCodeConstants.PAYMENT_WAY_CODE_TRANSFER
                  .equals(paymentWayCode)
                  && ECISKJConstants.PAYMENT_EXPIRATION_CATEGORY_FLAG_INDIVIDUAL
                      .equals(paymentExpirationCategory)
                  && ECISConstants.BILLING_ADD_UP_CONTROL_0.equals(billingaddupcontrol)) {
                dataRecordErrorList.add(StringConvertUtil
                    .convertErrorListString(fileName,
                        outputRowNumber,
                        messageSource.getMessage(
                            "error.E1581", null,
                            Locale.getDefault())));

              }

              // 口振クレカ翌月請求フラグ
              if (ECISKJConstants.PAYMENT_EXPIRATION_CATEGORY_FLAG_INDIVIDUAL
                  .equals(paymentExpirationCategory)
                  && ECISKJConstants.DIRECT_DEBIT_CREDIT_CARD_NEXT_MONTH_BILLING_FLAG_NEXT_MONTH_BILLING
                      .equals(directDebitCreditCardNextMonthBillingFlag)
                  && ECISConstants.BILLING_ADD_UP_CONTROL_1.equals(billingaddupcontrol)) {
                dataRecordErrorList.add(StringConvertUtil
                    .convertErrorListString(fileName,
                        outputRowNumber,
                        messageSource.getMessage(
                            "error.E1609", null,
                            Locale.getDefault())));
              }

              // 請求合算フラグチェック
              if (!ECISCodeConstants.PAYMENT_WAY_CODE_TRANSFER
                  .equals(paymentWayCode)
                  && ECISKJConstants.BILLING_ADD_UP_FLAG_UNNECESSARY
                      .equals(billingAddUpFlag)
                  && ECISConstants.BILLING_ADD_UP_CONTROL_0.equals(billingaddupcontrol)) {
                dataRecordErrorList.add(StringConvertUtil
                    .convertErrorListString(fileName,
                        outputRowNumber,
                        messageSource.getMessage(
                            "error.E1584", null,
                            Locale.getDefault())));

              }
            }
          }
          // 個別支払期限（月数）
          String individualPaymentExpirationMonths = dataRecord
              .get(Custom_ContractManagementInformationFileConfigPayment.DATA_INDIVIDUAL_PAYMENT_EXPIRATION_MONTHS_INDEX);
          // 個別支払期限（日）
          String individualPaymentExpirationDate = dataRecord
              .get(Custom_ContractManagementInformationFileConfigPayment.DATA_INDIVIDUAL_PAYMENT_EXPIRATION_DATE_INDEX);
          // 支払期限区分相関チェック
          if (ECISKJConstants.PAYMENT_EXPIRATION_CATEGORY_FLAG_INDIVIDUAL
              .equals(paymentExpirationCategory)
              && (StringUtils
                  .isEmpty(individualPaymentExpirationMonths)
                  || StringUtils
                      .isEmpty(individualPaymentExpirationDate))) {
            dataRecordErrorList.add(StringConvertUtil
                .convertErrorListString(fileName,
                    outputRowNumber, messageSource
                        .getMessage("error.E1582",
                            null,
                            Locale.getDefault())));
          }
          if (ECISKJConstants.PAYMENT_EXPIRATION_CATEGORY_FLAG_DEFAULT
              .equals(paymentExpirationCategory)
              && (StringUtils
                  .isNotEmpty(individualPaymentExpirationMonths)
                  || StringUtils
                      .isNotEmpty(individualPaymentExpirationDate))) {
            dataRecordErrorList.add(StringConvertUtil
                .convertErrorListString(fileName,
                    outputRowNumber, messageSource
                        .getMessage("error.E1583",
                            null,
                            Locale.getDefault())));
          }
          // 個人・法人区分コードチェック
          String individualLegalEntityCategoryCode = dataRecord
              .get(Custom_ContractManagementInformationFileConfigPayment.DATA_INDIVIDUAL_LEGAL_ENTITY_CATEGORY_CODE_INDEX);
          if (!StringUtils.isEmpty(individualLegalEntityCategoryCode)
              && !individualLegalEntityCategoryMasterCodeCheckSet
                  .contains(individualLegalEntityCategoryCode)) {
            dataRecordErrorList
                .add(StringConvertUtil.convertErrorListString(
                    fileName,
                    outputRowNumber,
                    messageSource
                        .getMessage(
                            "validation.range",
                            new String[] {
                                Custom_ContractManagementInformationFileConfigPayment.DATA_INDIVIDUAL_LEGAL_ENTITY_CATEGORY_CODE_NAME,
                                individualLegalEntityCategoryMasterCodeErrorMessageOption },
                            Locale.getDefault())));
          }

          // 請求先電話区分コードチェック
          String billingPhoneCategoryCode = dataRecord
              .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_PHONE_CATEGORY_CODE_INDEX);
          if (!StringUtils.isEmpty(billingPhoneCategoryCode)
              && !phoneNoCategoryMasterCodeCheckSet
                  .contains(billingPhoneCategoryCode)) {
            dataRecordErrorList
                .add(StringConvertUtil.convertErrorListString(
                    fileName,
                    outputRowNumber,
                    messageSource
                        .getMessage(
                            "validation.range",
                            new String[] {
                                Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_PHONE_CATEGORY_CODE_NAME,
                                phoneNoCategoryMasterCodeErrorMessageOption },
                            Locale.getDefault())));
          }

          // 請求先情報チェック
          // Bean設定
          CheckBillingInformationUtilBean checkBillingInfoBean = new CheckBillingInformationUtilBean();
          // 個人・法人区分コード
          checkBillingInfoBean
              .setIndividualLegalEntityCategoryCode(dataRecord
                  .get(Custom_ContractManagementInformationFileConfigPayment.DATA_INDIVIDUAL_LEGAL_ENTITY_CATEGORY_CODE_INDEX));
          // 請求先氏名1
          checkBillingInfoBean
              .setBillingName1(dataRecord
                  .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_NAME1_INDEX));
          // 請求先氏名2
          checkBillingInfoBean
              .setBillingName2(dataRecord
                  .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_NAME2_INDEX));
          // 敬称
          checkBillingInfoBean
              .setPrefix(dataRecord
                  .get(Custom_ContractManagementInformationFileConfigPayment.DATA_PREFIX_INDEX));
          // 請求先住所（郵便番号）
          checkBillingInfoBean
              .setBillingAddressPostalCode(dataRecord
                  .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_POSTAL_CODE_INDEX));
          // 請求先住所（都道府県名）
          checkBillingInfoBean
              .setBillingAddressPrefectures(dataRecord
                  .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_PREFECTURES_INDEX));
          // 請求先住所（市区郡町村名）
          checkBillingInfoBean
              .setBillingAddressMunicipality(dataRecord
                  .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_MUNICIPALITY_INDEX));
          // 請求先住所（字名・丁目）
          checkBillingInfoBean
              .setBillingAddressSection(dataRecord
                  .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_SECTION_INDEX));
          // 請求先住所（番地･号）
          checkBillingInfoBean
              .setBillingAddressBlock(dataRecord
                  .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_BLOCK_INDEX));
          // 請求先住所（建物名）
          checkBillingInfoBean
              .setBillingAddressBuildingName(dataRecord
                  .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_BUILDING_NAME_INDEX));
          // 請求先住所（部屋名）
          checkBillingInfoBean
              .setBillingAddressRoom(dataRecord
                  .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_ROOM_INDEX));
          // 請求先電話番号
          checkBillingInfoBean
              .setBillingPhoneNo(dataRecord
                  .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_PHONE_NO_INDEX));
          // 請求先電話区分コード
          checkBillingInfoBean
              .setBillingPhoneCategoryCode1(dataRecord
                  .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_PHONE_CATEGORY_CODE_INDEX));
          // 請求先メールアドレス1
          checkBillingInfoBean
              .setBillingMailAddress1(dataRecord
                  .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_MAIL_ADDRESS1_INDEX));
          // 請求先メールアドレス2
          checkBillingInfoBean
              .setBillingMailAddress2(dataRecord
                  .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_MAIL_ADDRESS2_INDEX));
          // フリー項目1
          checkBillingInfoBean
              .setFree1(dataRecord
                  .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_FREE1_INDEX));
          // フリー項目2
          checkBillingInfoBean
              .setFree2(dataRecord
                  .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_FREE2_INDEX));

          // 連絡先情報入力チェック
          if (!KJ_CommonUtil
              .checkBillDestinationInformation(checkBillingInfoBean)) {
            dataRecordErrorList.add(StringConvertUtil
                .convertErrorListString(fileName,
                    outputRowNumber, messageSource
                        .getMessage("error.E1047",
                            null,
                            Locale.getDefault())));
          }

          // 請求先メールアドレス1、2のチェック
          if (!KJ_CommonUtil
              .checkMailAddressCorrelation(
                  dataRecord
                      .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_MAIL_ADDRESS1_INDEX),
                  dataRecord
                      .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_MAIL_ADDRESS2_INDEX))) {
            dataRecordErrorList.add(StringConvertUtil
                .convertErrorListString(fileName,
                    outputRowNumber, messageSource
                        .getMessage("error.E1220",
                            null,
                            Locale.getDefault())));
          }

          // 外部システム契約番号、外部システム支払番号チェック
          // 排他指定チェック
          if (!StringUtils
              .isEmpty(dataRecord
                  .get(Custom_ContractManagementInformationFileConfigPayment.DATA_EXTERNAL_MANAGE_CONTRACT_NO_INDEX))) {
            if (!StringUtils
                .isEmpty(dataRecord
                    .get(Custom_ContractManagementInformationFileConfigPayment.DATA_EXTERNAL_MANAGE_PAYMENT_NO_INDEX))) {
              dataRecordErrorList.add(StringConvertUtil
                  .convertErrorListString(fileName,
                      outputRowNumber,
                      messageSource.getMessage(
                          "error.E1517", null,
                          Locale.getDefault())));
            }
          }

          // 外部システム契約番号必須チェック
          if (ECISCodeConstants.CUSTOM_ADD_UP_INDICATION_CATEGORY_CODE_GAS_ADD_UP
              .equals(paymentWayCode)) {
            if (StringUtils
                .isEmpty(dataRecord
                    .get(Custom_ContractManagementInformationFileConfigPayment.DATA_EXTERNAL_MANAGE_CONTRACT_NO_INDEX))) {
              dataRecordErrorList.add(StringConvertUtil
                  .convertErrorListString(fileName,
                      outputRowNumber,
                      messageSource.getMessage(
                          "error.E1518", null,
                          Locale.getDefault())));
            }
          }

          // 外部システム支払番号必須チェック
          if (ECISCodeConstants.CUSTOM_ADD_UP_INDICATION_CATEGORY_CODE_ELECTRIC_SINGLE
              .equals(paymentWayCode)) {
            if (StringUtils
                .isEmpty(dataRecord
                    .get(Custom_ContractManagementInformationFileConfigPayment.DATA_EXTERNAL_MANAGE_PAYMENT_NO_INDEX))) {
              dataRecordErrorList.add(StringConvertUtil
                  .convertErrorListString(fileName,
                      outputRowNumber,
                      messageSource.getMessage(
                          "error.E1519", null,
                          Locale.getDefault())));
            }
          }
        }

        // データレコードエラーリストチェック
        if (!dataRecordErrorList.isEmpty()) {
          // データレコードエラーリストが存在する場合
          // 処理用オブジェクトには格納しない
          errorList.addAll(dataRecordErrorList);
          continue;
        }

        // データレコード振分
        Map<Integer, String> resultDataRecordMap = new HashMap<Integer, String>(
            dataRecord);
        // 行番号設定
        // 実際の行数（インデックス＋１）を設定する
        resultDataRecordMap
            .put(ContractManagementInformationFileConfigCommon.DATA_ROW_NO_INDEX,
                String.valueOf(outputRowNumber));
        // 登録・更新・削除により振分
        if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER
            .equals(registerUpdateDeleteCategory)) {
          // 登録の場合、登録オブジェクトリストに追加
          registList.add(resultDataRecordMap);
        } else if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_UPDATE
            .equals(registerUpdateDeleteCategory)) {
          // 更新の場合、更新オブジェクトリストに追加
          updateList.add(resultDataRecordMap);
        } else if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_DELETE
            .equals(registerUpdateDeleteCategory)) {
          // 削除の場合、削除オブジェクトリストに追加
          deleteList.add(resultDataRecordMap);
        }
      }

      // オブジェクト返却
      csvResultBean.setUploadFileName(fileName);
      csvResultBean.setErrorList(errorList);
      csvResultBean.setRegistList(registList);
      csvResultBean.setUpdateList(updateList);
      csvResultBean.setDeleteList(deleteList);
      return csvResultBean;
    } catch (Exception e) {
      throw new SystemException(e.getMessage(), e);
    }
  }

  /**
   * 支払方法チェック<br>
   * 直営以外かつ全てが未入力かチェックし、入力されていたらエラー
   *
   * @param checkMap
   * @return true チェックOK false チェックNG
   */
  private boolean checkPaymentMethod(List<String> checkList,
      String provideModelCode, Integer accountCreditCardId) {
    if (!ECISCodeConstants.PROVIDE_MODEL_CODE_DIRECT_MANAGEMENT
        .equals(provideModelCode)
        && (accountCreditCardId != null || !KJ_CommonUtil
            .checkKeyListIsNotEmpty(checkList))) {
      return false;
    }

    return true;
  }

  /**
   * 請求作成チェックをする<br>
   * 支払ID、支払適用開始日を条件に請求情報を検索し1件以上存在した場合エラーとする
   *
   * @param paymentId
   *          支払ID
   * @param paymentStartDate
   *          支払適用開始日
   * @return true チェックOK false チェックNG
   */
  private boolean checkBillingCreation(Integer paymentId,
      Date paymentStartDate) {
    BlExample billingExample = new BlExample();
    billingExample.createCriteria().andPaymentIdEqualTo(paymentId)
        .andBlCreateDateGreaterThanOrEqualTo(paymentStartDate);

    int cnt = blMapper.countByExample(billingExample);

    // 1件以上存在
    if (cnt >= 1) {
      return false;
    }

    return true;

  }

  /**
   * 支払情報更新
   *
   * @param entity
   * @param directDebitCreditCardNextMonthBillingFlag
   * @param updateCount
   * @param paymentId
   * @return true 更新成功 false 更新失敗
   */
  private boolean updatePayment(Payment entity, Integer paymentId,
      int updateCount, Timestamp sysDate) {

    // 《支払Dao》.選択項目更新（主キー・更新回数）呼び出し
    PaymentExample updatePaymentExample = new PaymentExample();
    updatePaymentExample.createCriteria().andPaymentIdEqualTo(paymentId)
        .andUpdateCountEqualTo(updateCount);
    entity.setOnlineUpdateTime(sysDate);
    entity.setOnlineUpdateUserId(ThreadContext.getRequestThreadContext()
        .get(ECISConstants.USER_ID_KEY).toString());
    entity.setUpdateTime(sysDate);
    entity.setUpdateModuleCode(ThreadContext.getRequestThreadContext()
        .get(ECISConstants.CLASS_NAME_KEY).toString());

    int updateByExampleSelectiveCnt = paymentMapper
        .updateByPaymentExpirationIndividualSettingFlagSelective(entity, updatePaymentExample);

    // 件数0
    if (updateByExampleSelectiveCnt == 0) {
      return false;
    }

    return true;
  }

  /**
   * 支払履歴情報登録の呼び出しを行う
   *
   * @param entity
   * @param bean
   * @param paymentId
   * @param sysdate
   */
  private void insertPaymentHistory(PaymentHist entity,
      RegistPaymentBusinessBean bean, Integer paymentId, Timestamp sysdate) {

    insertPaymentHistory(entity, paymentId, bean.getPaymentStartDate(),
        bean.getPaymentWayCode(), bean.getAccountCreditCardId(),
        bean.getIndividualLegalEntityCategoryCode(),
        bean.getBillingName1(), bean.getBillingName2(),
        bean.getPrefix(), bean.getBillingAddressPostalCode(),
        bean.getBillingAddressPrefectures(),
        bean.getBillingAddressMunicipality(),
        bean.getBillingAddressSection(), bean.getBillingAddressBlock(),
        bean.getBillingAddressBuildingName(),
        bean.getBillingAddressRoom(), bean.getBillingPhoneNo(),
        bean.getBillingPhoneCategoryCode(),
        bean.getBillingMailAddress1(), bean.getBillingMailAddress2(),
        bean.getRemittanceAccountId(), bean.getRemittanceAccountBankCode(),
        bean.getRemittanceAccountBankBranchCode(), bean.getRemittanceAccountBankTypeOfAccountCode(),
        bean.getRemittanceAccountAccountNo(), bean.getRemittanceAccountAccountHolderName(),
        bean.getRemittanceAccountSymbol(), bean.getRemittanceAccountNo(),
        bean.getFree1(), bean.getFree2(),
        sysdate);
  }

  /**
   * 支払履歴情報登録の呼び出しを行う
   *
   * @param entity
   * @param bean
   * @param paymentId
   * @param sysdate
   */
  private void insertPaymentHistory(PaymentHist paymentHist,
      UpdatePaymentBusinessBean bean,
      KJ_InquiryPaymentInformationEntityBean inquiryPaymentBusinessBean,
      Timestamp sysdate) {

    String paymentWayCode = null;
    Integer acCreId = null;
    String ilcCode = null;
    String billingName1 = null;
    String prefix = null;
    String billingName2 = null;
    String billingAddressPostalCode = null;
    String billingAddressPrefectures = null;
    String billingAddressMunicipality = null;
    String billingAddressSection = null;
    String billingAddressBlock = null;
    String billingAddressBuildingName = null;
    String billingAddressRoom = null;
    String billingPhoneNo = null;
    String billingPhoneCategoryCode = null;
    String billingMailAddress1 = null;
    String billingMailAddress2 = null;
    String remittanceAccountId = null;
    String remittanceAccountBankCode = null;
    String remittanceAccountBankBranchCode = null;
    String remittanceAccountBankTypeOfAccountCode = null;
    String remittanceAccountAccountNo = null;
    String remittanceAccountAccountHolderName = null;
    String remittanceAccountSymbol = null;
    String remittanceAccountNo = null;
    String free1 = null;
    String free2 = null;

    // nullの場合引き継ぐ項目の設定
    // 口座クレカID
    // 更新対象外フラグが0の時は入力Beanの内容で登録する
    if (ECISConstants.FLG_OFF
        .equals(bean.getAccountCreditCardIdNoUpdFlag())) {
      acCreId = bean.getAccountCreditCardId();
    } else
    // 更新対象外フラグが1の場合は前履歴から引き継ぐ
    if (ECISConstants.FLG_ON.equals(bean.getAccountCreditCardIdNoUpdFlag())) {
      acCreId = paymentHist.getAccountCreId();
    }

    // 支払方法コード
    paymentWayCode = (String) setInheritingItem(bean.getPaymentWayCode(),
        paymentHist.getPwCode());
    // 請求先氏名1
    billingName1 = (String) setInheritingItem(bean.getBillingName1(),
        paymentHist.getBlName1());
    // 敬称
    prefix = (String) setInheritingItem(bean.getPrefix(),
        paymentHist.getPrefix());
    // 請求先住所（郵便番号）
    billingAddressPostalCode = (String) setInheritingItem(
        bean.getBillingAddressPostalCode(),
        paymentHist.getBlAddressPostalCode());
    // 請求先住所（都道府県名）
    billingAddressPrefectures = (String) setInheritingItem(
        bean.getBillingAddressPrefectures(),
        paymentHist.getBlAddressPrefectures());
    // 請求先住所（市区郡町村名）
    billingAddressMunicipality = (String) setInheritingItem(
        bean.getBillingAddressMunicipality(),
        paymentHist.getBlAddressMunicipality());
    // 請求先電話番号
    billingPhoneNo = (String) setInheritingItem(bean.getBillingPhoneNo(),
        paymentHist.getBlPhoneNo());
    // 請求先電話区分コード
    billingPhoneCategoryCode = (String) setInheritingItem(
        bean.getBillingPhoneCategoryCode(),
        paymentHist.getBlPhoneCatCode());

    // 条件付必須項目
    // 個人・法人区分コードが入力されている場合
    if (bean.getIndividualLegalEntityCategoryCode() != null) {
      ilcCode = bean.getIndividualLegalEntityCategoryCode();
      billingName2 = bean.getBillingName2();
      billingAddressSection = bean.getBillingAddressSection();
      billingAddressBlock = bean.getBillingAddressBlock();
      billingAddressBuildingName = bean.getBillingAddressBuildingName();
      billingAddressRoom = bean.getBillingAddressRoom();
      billingMailAddress1 = bean.getBillingMailAddress1();
      billingMailAddress2 = bean.getBillingMailAddress2();
    } else {
      ilcCode = paymentHist.getIlcCode();
      billingName2 = paymentHist.getBlName2();
      billingAddressSection = paymentHist.getBlAddressSection();
      billingAddressBlock = paymentHist.getBlAddressBlock();
      billingAddressBuildingName = paymentHist.getBlAddressBuildingName();
      billingAddressRoom = paymentHist.getBlAddressRoom();
      billingMailAddress1 = paymentHist.getBlMailAddress1();
      billingMailAddress2 = paymentHist.getBlMailAddress2();
    }

    // 送金口座ID
    remittanceAccountId = bean.getRemittanceAccountId();
    // 送金口座金融機関コード
    remittanceAccountBankCode = bean.getRemittanceAccountBankCode();
    // 送金口座支店コード
    remittanceAccountBankBranchCode = bean.getRemittanceAccountBankBranchCode();
    // 送金口座預金種目
    remittanceAccountBankTypeOfAccountCode = bean.getRemittanceAccountBankTypeOfAccountCode();
    // 送金口座口座番号
    remittanceAccountAccountNo = bean.getRemittanceAccountAccountNo();
    // 送金口座口座名義
    remittanceAccountAccountHolderName = bean.getRemittanceAccountAccountHolderName();
    // 送金口座記号
    remittanceAccountSymbol = bean.getRemittanceAccountSymbol();
    // 送金口座番号
    remittanceAccountNo = bean.getRemittanceAccountNo();

    // フリー項目1
    free1 = bean.getFree1();
    // フリー項目2
    free2 = bean.getFree2();

    insertPaymentHistory(paymentHist,
        inquiryPaymentBusinessBean.getPaymentId(),
        bean.getPaymentStartDate(), paymentWayCode, acCreId, ilcCode,
        billingName1, billingName2, prefix, billingAddressPostalCode,
        billingAddressPrefectures, billingAddressMunicipality,
        billingAddressSection, billingAddressBlock,
        billingAddressBuildingName, billingAddressRoom, billingPhoneNo,
        billingPhoneCategoryCode, billingMailAddress1,
        billingMailAddress2, remittanceAccountId, remittanceAccountBankCode,
        remittanceAccountBankBranchCode, remittanceAccountBankTypeOfAccountCode,
        remittanceAccountAccountNo, remittanceAccountAccountHolderName,
        remittanceAccountSymbol, remittanceAccountNo, free1, free2, sysdate);
  }

  /**
   * ビーンに入力があった場合ビーン項目を、ない場合エンティティ項目を返す。
   *
   * @param beanItem
   * @param oldHistItem
   * @return
   */
  public Object setInheritingItem(Object beanItem, Object oldHistItem) {
    // 入力ありの場合
    if (beanItem != null) {
      return beanItem;
    } else {
      // 入力なしの場合
      return oldHistItem;
    }
  }

  /**
   * 支払履歴情報登録を行う
   *
   * @param entity
   * @param paymentId
   * @param paymentSd
   * @param pwCode
   * @param accountCreId
   * @param ilcCode
   * @param blName1
   * @param blName2
   * @param prefix
   * @param blAddressPostalCode
   * @param blAddressPrefectures
   * @param blAddressMunicipality
   * @param blAddressSection
   * @param blAddressBlock
   * @param blAddressBuildingName
   * @param blAddressRoom
   * @param blPhoneNo
   * @param blPhoneCatCode
   * @param blMailAddress1
   * @param blMailAddress2
   * @param remittanceAccountId
   * @param remittanceAccountBankCode
   * @param remittanceAccountBankBranchCode
   * @param remittanceAccountBankTypeOfAccountCode
   * @param remittanceAccountAccountNo
   * @param remittanceAccountAccountHolderName
   * @param remittanceAccountSymbol
   * @param remittanceAccountNo
   * @param free1
   * @param free2
   * @param sysDate
   */
  private void insertPaymentHistory(PaymentHist entity, Integer paymentId,
      Date paymentSd, String pwCode, Integer accountCreId,
      String ilcCode, String blName1, String blName2, String prefix,
      String blAddressPostalCode, String blAddressPrefectures,
      String blAddressMunicipality, String blAddressSection,
      String blAddressBlock, String blAddressBuildingName,
      String blAddressRoom, String blPhoneNo, String blPhoneCatCode,
      String blMailAddress1, String blMailAddress2, String remittanceAccountId,
      String remittanceAccountBankCode, String remittanceAccountBankBranchCode,
      String remittanceAccountBankTypeOfAccountCode, String remittanceAccountAccountNo,
      String remittanceAccountAccountHolderName, String remittanceAccountSymbol,
      String remittanceAccountNo, String free1, String free2, Timestamp sysDate) {

    // 支払履歴情報登録
    entity.setPaymentId(paymentId);
    entity.setPaymentSd(paymentSd);
    entity.setPaymentEd(StringConvertUtil.stringToDate(
        ECISKJConstants.APPLY_END_DATE_MAX,
        ECISConstants.FORMAT_DATE_yyyyMMdd));
    entity.setPwCode(pwCode);
    entity.setAccountCreId(accountCreId);
    entity.setIlcCode(ilcCode);
    entity.setBlName1(blName1);
    entity.setBlName2(blName2);
    entity.setPrefix(prefix);
    entity.setBlAddressPostalCode(blAddressPostalCode);
    entity.setBlAddressPrefectures(blAddressPrefectures);
    entity.setBlAddressMunicipality(blAddressMunicipality);
    entity.setBlAddressSection(blAddressSection);
    entity.setBlAddressBlock(blAddressBlock);
    entity.setBlAddressBuildingName(blAddressBuildingName);
    entity.setBlAddressRoom(blAddressRoom);
    entity.setBlPhoneNo(blPhoneNo);
    entity.setBlPhoneCatCode(blPhoneCatCode);
    entity.setBlMailAddress1(blMailAddress1);
    entity.setBlMailAddress2(blMailAddress2);
    entity.setRtAccountId(remittanceAccountId);
    entity.setRtAccountBankCode(remittanceAccountBankCode);
    entity.setRtAccountBankBranchCode(remittanceAccountBankBranchCode);
    entity.setRtBtOfAccountCode(remittanceAccountBankTypeOfAccountCode);
    entity.setRtAccountAccountNo(remittanceAccountAccountNo);
    entity.setRtAccountAccountHolderName(remittanceAccountAccountHolderName);
    entity.setRtAccountSymbol(remittanceAccountSymbol);
    entity.setRtAccountNo(remittanceAccountNo);
    entity.setFree1(free1);
    entity.setFree2(free2);
    entity.setUpdateCount(INT_CNT_ZERO);
    entity.setCreateTime(sysDate);
    entity.setOnlineUpdateTime(sysDate);
    entity.setOnlineUpdateUserId(ThreadContext.getRequestThreadContext()
        .get(ECISConstants.USER_ID_KEY).toString());
    entity.setUpdateTime(sysDate);
    entity.setUpdateModuleCode(ThreadContext.getRequestThreadContext()
        .get(ECISConstants.CLASS_NAME_KEY).toString());

    // インサート
    paymentHistMapper.insert(entity);

    return;
  }

  /**
   * 支払履歴更新(削除メソッド用)
   *
   * @param entity
   *          支払履歴エンティティ
   * @param sysDate
   *          システム日付
   * @param paymentId
   *          支払ID
   * @param paymentStartDate
   *          支払開始日
   * @return true 更新成功 false 更新失敗
   */
  private boolean updatePaymentHistoryUseDelete(PaymentHist entity,
      Timestamp sysDate, Integer paymentId, Date paymentStartDate,
      int updateCount) {
    entity.setOnlineUpdateTime(sysDate);
    entity.setOnlineUpdateUserId(ThreadContext.getRequestThreadContext()
        .get(ECISConstants.USER_ID_KEY).toString());
    entity.setUpdateTime(sysDate);
    entity.setUpdateModuleCode(ThreadContext.getRequestThreadContext()
        .get(ECISConstants.CLASS_NAME_KEY).toString());

    PaymentHistExample paymentHistoryExample = new PaymentHistExample();
    paymentHistoryExample.createCriteria().andPaymentIdEqualTo(paymentId)
        .andPaymentSdEqualTo(paymentStartDate)
        .andUpdateCountEqualTo(updateCount);

    int updateByExampleSelectiveCnt = paymentHistMapper
        .updateByExampleSelective(entity, paymentHistoryExample);
    // 返却値が0件の場合
    if (updateByExampleSelectiveCnt == 0) {
      return false;
    }

    return true;
  }

  /**
   * 支払履歴更新(更新メソッド用)
   *
   * @param entity
   *          支払履歴エンティティ
   * @param sysDate
   *          システム日付
   * @param paymentId
   *          支払ID
   * @param paymentStartDate
   *          支払開始日
   * @param NoUpdFlag
   *          更新対象外フラグ
   * @return true 更新成功 false 更新失敗
   */
  private boolean updatePaymentHistoryUseUpdate(PaymentHist entity,
      Timestamp sysDate, Integer paymentId, Date paymentStartDate,
      int updateCount, String noUpdFlag, Integer accountCreditCardId) {

    // 更新対象外対応により、Mapper側での口座クレカIDの更新有無判定がnoUpdFlagになっているため
    // 口座クレカIDがnullでもnull更新されてしまうため設定する必要がある。
    entity.setAccountCreId(accountCreditCardId);

    entity.setOnlineUpdateTime(sysDate);
    entity.setOnlineUpdateUserId(ThreadContext.getRequestThreadContext()
        .get(ECISConstants.USER_ID_KEY).toString());
    entity.setUpdateTime(sysDate);
    entity.setUpdateModuleCode(ThreadContext.getRequestThreadContext()
        .get(ECISConstants.CLASS_NAME_KEY).toString());

    Map<String, Object> exampleMap = new HashMap<String, Object>();

    // 更新対象外対応
    exampleMap.put("accountCreditCardIdNoUpdFlag", noUpdFlag);

    exampleMap.put("conditionPaymentId", paymentId);
    exampleMap.put("conditionPaymentStartDate", paymentStartDate);
    exampleMap.put("conditionUpdateCount", updateCount);

    int updateByExampleSelectiveCnt = paymentHistMapper
        .updateByNoUpdFlagSelective(entity, exampleMap);
    // 返却値が0件の場合
    if (updateByExampleSelectiveCnt == 0) {
      return false;
    }

    return true;
  }

  /**
   * 支払履歴更新(更新メソッド用)(全項目更新)
   *
   * @param entity
   *          支払履歴エンティティ
   * @param sysDate
   *          システム日付
   * @param paymentId
   *          支払ID
   * @param paymentStartDate
   *          支払開始日
   * @param NoUpdFlag
   *          更新対象外フラグ
   * @return true 更新成功 false 更新失敗
   */
  private boolean updatePaymentHistoryUseAllUpdate(PaymentHist entity,
      Timestamp sysDate, Integer paymentId, Date paymentStartDate,
      int updateCount, String noUpdFlag, Integer accountCreditCardId) {

    entity.setAccountCreId(accountCreditCardId);
    entity.setOnlineUpdateTime(sysDate);
    entity.setOnlineUpdateUserId(ThreadContext.getRequestThreadContext()
        .get(ECISConstants.USER_ID_KEY).toString());
    entity.setUpdateTime(sysDate);
    entity.setUpdateModuleCode(ThreadContext.getRequestThreadContext()
        .get(ECISConstants.CLASS_NAME_KEY).toString());

    Map<String, Object> exampleMap = new HashMap<String, Object>();
    exampleMap.put("conditionPaymentId", paymentId);
    exampleMap.put("conditionPaymentStartDate", paymentStartDate);
    exampleMap.put("conditionUpdateCount", updateCount);

    int updateByExampleSelectiveCnt = paymentHistMapper
        .updateByNoUpdFlagAllSelective(entity, exampleMap);
    // 返却値が0件の場合
    if (updateByExampleSelectiveCnt == 0) {
      return false;
    }

    return true;
  }

  /**
   * 支払情報照会ビジネスビーンのリターンコードとメッセージを設定する。
   *
   * @param prop
   *          プロパティ
   * @param bean
   *          支払情報照会ビジネスビーン
   * @param returnCode
   *          リターンコード
   */
  private void setMessageAndReturnCode(InquiryPaymentBusinessBean bean,
      String returnCode) throws NoSuchMessageException {

    bean.setReturnCode(returnCode);
    bean.setMessage(getPropertiesMesseage(returnCode));

  }

  /**
   * 支払情報登録ビジネスビーンのリターンコードとメッセージを設定する。
   *
   * @param prop
   *          プロパティ
   * @param bean
   *          支払情報登録ビジネスビーン
   * @param returnCode
   *          リターンコード
   */
  private void setMessageAndReturnCode(RegistPaymentBusinessBean bean,
      String returnCode) throws NoSuchMessageException {

    bean.setReturnCode(returnCode);
    bean.setMessage(getPropertiesMesseage(returnCode));

  }

  /**
   * 支払情報更新ビジネスビーンのリターンコードとメッセージを設定する。
   *
   * @param prop
   *          プロパティ
   * @param bean
   *          支払情報更新ビジネスビーン
   * @param returnCode
   *          リターンコード
   */
  private void setMessageAndReturnCode(UpdatePaymentBusinessBean bean,
      String returnCode) throws NoSuchMessageException {

    bean.setReturnCode(returnCode);
    bean.setMessage(getPropertiesMesseage(returnCode));

  }

  /**
   * 支払情報削除ビジネスビーンのリターンコードとメッセージを設定する。
   *
   * @param prop
   *          プロパティ
   * @param bean
   *          支払情報削除ビジネスビーン
   * @param returnCode
   *          リターンコード
   */
  private void setMessageAndReturnCode(DeletePaymentBusinessBean bean,
      String returnCode) throws NoSuchMessageException {

    bean.setReturnCode(returnCode);
    bean.setMessage(getPropertiesMesseage(returnCode));

  }

  /**
   * プロパティからリターンコードに対応するメッセージを取得する
   *
   * @param prop
   *          プロパティ
   * @param returnCode
   *          リターンコード
   * @return
   */
  private String getPropertiesMesseage(String returnCode)
      throws NoSuchMessageException {
    return messageSource.getMessage(KJ_CommonUtil.getMessageId(returnCode),
        new String[] {}, Locale.getDefault());
  }

  /**
   * 利用不能フラグチェック<br>
   * 利用不能フラグが“ON”かチェックする
   *
   * @param visualizationProvideFlag
   * @return true = チェックOK false = チェックNG
   */
  private boolean checkUnavailableFlag(String visualizationProvideFlag) {
    if (ECISKJConstants.UNAVAILABLE_FLAG_USE_IMPOSSIBLE
        .equals(visualizationProvideFlag)) {

      return false;
    }
    return true;
  }

  /**
   * 督促対象外フラグチェック<br>
   * 督促対象外フラグ が“督促対象(0)”かチェックする
   *
   * @param visualizationProvideFlag
   * @return true = チェックOK false = チェックNG
   */
  private boolean checkUrgeNotCoveredFlag(String urgeNotCoveredFlag) {
    if (ECISKJConstants.URGE_NOT_COVERED_FLAG_URGE_COVERED
        .equals(urgeNotCoveredFlag)) {

      return false;
    }
    return true;
  }

  /**
   * 前月請求合算フラグおよび支払期限個別設定フラグチェック<br>
   *
   * @param previousBillingAddUpFlag
   * @param paymentExpirationIndividualSettingFlag
   * @return true = チェックOK false = チェックNG
   */
  private boolean checkPreviousBillingAddUpFlagAndPaymentExpirationIndividualSettingFlag(
      String previousBillingAddUpFlag,
      String paymentExpirationIndividualSettingFlag) {
    if (ECISKJConstants.BILLING_ADD_UP_FLAG_UNNECESSARY
        .equals(previousBillingAddUpFlag)
        || ECISKJConstants.PAYMENT_EXPIRATION_CATEGORY_FLAG_INDIVIDUAL
            .equals(paymentExpirationIndividualSettingFlag)) {

      return false;
    }
    return true;
  }

  /**
   * Bean.支払方法コード、Bean.個人・法人区分コード、Bean.請求先電話区分コードのコード値存在チェックを行う
   *
   * @param paymentWayCode
   * @param individualLegalEntityCategoryCode
   * @param billingPhoneCategoryCode
   * @return リターンコード = エラー null = 存在
   */
  private String checkMasterCode(String paymentWayCode,
      String individualLegalEntityCategoryCode,
      String billingPhoneCategoryCode) {
    // 《支払情報登録BusinessBean》.支払方法コードがNULLまたは空文字のいずれかでない かつ 送金以外の場合
    if (StringUtils.isNotEmpty(paymentWayCode)
        && !ECISCodeConstants.PAYMENT_WAY_CODE_REMITTANCE.equals(paymentWayCode)) {
      // 返却値が0件の場合

      PwM paymentWayMaster = new PwM();
      paymentWayMaster = pwMMapper.selectByPrimaryKey(paymentWayCode);

      // 返却値が0件の場合
      if (paymentWayMaster == null) {
        return ECISReturnCodeConstants.RETURN_CODE_P013;
      }
    }

    // 《支払情報登録BusinessBean》.個人・法人区分コードがNULLまたは空文字のいずれかでない場合
    if (StringUtils.isNotEmpty(individualLegalEntityCategoryCode)) {
      IlcM individualLegalEntityCategoryMaster = new IlcM();
      individualLegalEntityCategoryMaster = ilcMMapper
          .selectByPrimaryKey(individualLegalEntityCategoryCode);

      // 返却値が0件の場合
      if (individualLegalEntityCategoryMaster == null) {
        return ECISReturnCodeConstants.RETURN_CODE_P021;
      }
    }

    // 《支払情報登録BusinessBean》.請求先電話区分コードがNULLまたは空文字のいずれかでない場合
    if (StringUtils.isNotEmpty(billingPhoneCategoryCode)) {
      PhoneNoCatM phoneNoCategoryMaster = new PhoneNoCatM();
      phoneNoCategoryMaster = phoneNoCatMMapper
          .selectByPrimaryKey(billingPhoneCategoryCode);

      // 返却値が0件の場合
      if (phoneNoCategoryMaster == null) {
        return ECISReturnCodeConstants.RETURN_CODE_P019;
      }
    }

    return null;
  }

  /**
   * 提供モデルコードが直営かつ支払方法コードがブランク、NULLかチェックする。
   *
   * @return true = チェックOK false = チェックNG
   */
  private boolean checkDMPaymentWay(String directManagement, String paymentWay) {
    if (ECISCodeConstants.PROVIDE_MODEL_CODE_DIRECT_MANAGEMENT
        .equals(directManagement) && StringUtils.isEmpty(paymentWay)) {
      return false;
    }

    return true;
  }

  /**
   * 支払情報マッパー(DI)を設定します。
   *
   * @param paymentMapper
   *          支払情報マッパー(DI)
   */
  public void setPaymentMapper(PaymentMapper paymentMapper) {
    this.paymentMapper = paymentMapper;
  }

  /**
   * 請求情報マッパーのセッター(DI)
   *
   * @param 請求情報マッパー
   */
  public void setBillingMapper(BlMapper billingMapper) {
    this.blMapper = billingMapper;
  }

  /**
   * 支払情報共通マッパー(DI)を設定します。
   *
   * @param paymentInformationCommonMapper
   *          支払情報共通マッパー(DI)
   */
  public void setPaymentInformationCommonMapper(
      PaymentInformationCommonMapper paymentInformationCommonMapper) {
    this.paymentInformationCommonMapper = paymentInformationCommonMapper;
  }

  /**
   * 支払履歴情報マッパーのセッター(DI)
   *
   * @param 支払履歴情報マッパー
   */
  public void setPaymentHistoryMapper(PaymentHistMapper paymentHistoryMapper) {
    this.paymentHistMapper = paymentHistoryMapper;
  }

  /**
   * 口座クレカ情報マッパーのセッター(DI)
   *
   * @param 口座クレカ情報マッパー
   */
  public void setAccountCreditInformationMapper(
      AcInformationMapper accountCreditInformationMapper) {
    this.acInformationMapper = accountCreditInformationMapper;
  }

  /**
   * 支払方法マスタマッパーのセッター(DI)
   *
   * @param 支払方法マスタマッパー
   */
  public void setPaymentWayMasterMapper(PwMMapper paymentWayMasterMapper) {
    this.pwMMapper = paymentWayMasterMapper;
  }

  /**
   * 個人・法人区分マスタマッパーのセッター(DI)
   *
   * @param 個人・法人区分マスタマッパー
   */
  public void setIndividualLegalEntityCategoryMasterMapper(
      IlcMMapper individualLegalEntityCategoryMasterMapper) {
    this.ilcMMapper = individualLegalEntityCategoryMasterMapper;
  }

  /**
   * 電話番号区分マッパーのセッター(DI)
   *
   * @param 電話番号区分マッパー
   */
  public void setPhoneNoCategoryMasterMapper(
      PhoneNoCatMMapper phoneNoCategoryMasterMapper) {
    this.phoneNoCatMMapper = phoneNoCategoryMasterMapper;
  }

  /**
   * 契約者情報照会ビジネス(DI)を設定します。
   *
   * @param kjContractorInformationBusiness
   *          契約者情報照会ビジネス(DI)
   */
  public void setKjContractorInformationBusiness(
      KJ_ContractorInformationBusiness kjContractorInformationBusiness) {
    this.kjContractorInformationBusiness = kjContractorInformationBusiness;
  }

  /**
   * 確定料金・請求連携情報マッパー(DI)を設定します。
   *
   * @param FixChargeBlLinkageMapper
   *          確定料金・請求連携情報マッパー(DI)
   */
  public void setFixChargeBlLinkageMapper(
      FixChargeBlLinkageMapper fixChargeBlLinkageMapper) {
    this.fixChargeBlLinkageMapper = fixChargeBlLinkageMapper;
  }

  /**
   * 契約情報照会ビジネス(DI)を設定します。
   *
   * @param kjContractInformationBusiness
   *          契約情報照会ビジネス(DI)
   */
  public void setKjContractInformationBusiness(
      KJ_ContractInformationBusiness kjContractInformationBusiness) {
    this.kjContractInformationBusiness = kjContractInformationBusiness;
  }

  /**
   * 日付関連共通ビジネス(DI)を設定します。
   *
   * @param dateBusiness
   *          日付関連共通ビジネス(DI)
   */
  public void setDateBusiness(DateBusiness dateBusiness) {
    this.dateBusiness = dateBusiness;
  }

  /**
   * メッセージプロパティ(DI)を設定します。
   *
   * @param messageSource
   *          メッセージプロパティ(DI)
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }

  /**
   * 契約管理情報ファイルヘッダーバリデーター(DI)を設定します。
   *
   * @param contractManagementInformationFileHeaderValidator
   *          契約管理情報ファイルヘッダーバリデーター(DI)
   */
  public void setContractManagementInformationFileHeaderValidator(
      ContractManagementInformationFileHeaderValidator contractManagementInformationFileHeaderValidator) {
    this.contractManagementInformationFileHeaderValidator = contractManagementInformationFileHeaderValidator;
  }

  /**
   * 支払情報ファイル登録バリデーター(DI)を設定します。
   *
   * @param paymentInformationFileRegistValidator
   *          支払情報ファイル登録バリデーター(DI)
   */
  public void setPaymentInformationFileRegistValidator(
      PaymentInformationFileRegistValidator paymentInformationFileRegistValidator) {
    this.paymentInformationFileRegistValidator = paymentInformationFileRegistValidator;
  }

  /**
   * カスタム支払情報ファイル登録バリデーター(DI)を設定します。
   *
   * @param customPaymentInformationFileRegistValidator
   *          カスタム支払情報ファイル登録バリデーター(DI)
   */
  public void setCustomPaymentInformationFileRegistValidator(
      Custom_PaymentInformationFileRegistValidator customPaymentInformationFileRegistValidator) {
    this.customPaymentInformationFileRegistValidator = customPaymentInformationFileRegistValidator;
  }

  /**
   * 支払情報ファイル更新バリデーター(DI)を設定します。
   *
   * @param paymentInformationFileUpdateValidator
   *          支払情報ファイル更新バリデーター(DI)
   */
  public void setPaymentInformationFileUpdateValidator(
      PaymentInformationFileUpdateValidator paymentInformationFileUpdateValidator) {
    this.paymentInformationFileUpdateValidator = paymentInformationFileUpdateValidator;
  }

  /**
   * カスタム支払情報ファイル更新バリデーター(DI)を設定します。
   *
   * @param customPaymentInformationFileUpdateValidator
   *          カスタム支払情報ファイル更新バリデーター(DI)
   */
  public void setCustomPaymentInformationFileUpdateValidator(
      Custom_PaymentInformationFileUpdateValidator customPaymentInformationFileUpdateValidator) {
    this.customPaymentInformationFileUpdateValidator = customPaymentInformationFileUpdateValidator;
  }

  /**
   * 支払情報ファイル削除バリデーター(DI)を設定します。
   *
   * @param paymentInformationFileDeleteValidator
   *          支払情報ファイル削除バリデーター(DI)
   */
  public void setPaymentInformationFileDeleteValidator(
      PaymentInformationFileDeleteValidator paymentInformationFileDeleteValidator) {
    this.paymentInformationFileDeleteValidator = paymentInformationFileDeleteValidator;
  }

  /**
   * カスタム支払情報ファイル削除バリデーター(DI)を設定します。
   *
   * @param customPaymentInformationFileDeleteValidator
   *          カスタム支払情報ファイル削除バリデーター(DI)
   */
  public void setCustomPaymentInformationFileDeleteValidator(
      Custom_PaymentInformationFileDeleteValidator customPaymentInformationFileDeleteValidator) {
    this.customPaymentInformationFileDeleteValidator = customPaymentInformationFileDeleteValidator;
  }

  /**
   * TODOビジネス(DI)を設定します。
   *
   * @param todoBusiness
   *          TODOビジネス(DI)
   */
  public void setTodoBusiness(TodoBusiness todoBusiness) {
    this.todoBusiness = todoBusiness;
  }

  /**
   * 確定料金・請求連携情報共通マッパー(DI)を設定します。
   *
   * @param fixChargeBillingLinkageInformationCommonMapper
   *          確定料金・請求連携情報共通マッパー(DI)
   */
  public void setFixChargeBillingLinkageInformationCommonMapper(
      FixChargeBillingLinkageInformationCommonMapper fixChargeBillingLinkageInformationCommonMapper) {
    this.fixChargeBillingLinkageInformationCommonMapper = fixChargeBillingLinkageInformationCommonMapper;
  }

  /**
   * プロパティ定義クラス(DI)を設定します。
   *
   * @param applicationProperties
   *          プロパティ定義クラス(DI)
   */
  public void setApplicationProperties(
      PropertiesFactoryBean applicationProperties) {
    this.applicationProperties = applicationProperties;
  }

  /**
   * プロパティ定義を取得する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 外部ファイルのプロパティ定義を取得する。
   *
   * </pre>
   *
   * @return プロパティ定義を返却する。
   */
  private Properties getProperties() {
    Properties prop = null;
    try {
      prop = applicationProperties.getObject();
    } catch (IOException e) {
      throw new SystemException(messageSource.getMessage("error.E1283",
          null, Locale.getDefault()), e);
    }

    return prop;
  }

  /**
   * 請求入金共通マッパー(DI)を設定します。
   *
   * @param billingInformationCommonMapper
   *          請求入金共通マッパー(DI)
   */
  public void setBillingInformationCommonMapper(
      BillingInformationCommonMapper billingInformationCommonMapper) {
    this.billingInformationCommonMapper = billingInformationCommonMapper;
  }

  public void setBlMapper(BlMapper blMapper) {
    this.blMapper = blMapper;
  }

  public void setPaymentHistMapper(PaymentHistMapper paymentHistMapper) {
    this.paymentHistMapper = paymentHistMapper;
  }

  public void setAcInformationMapper(AcInformationMapper acInformationMapper) {
    this.acInformationMapper = acInformationMapper;
  }

  public void setPwMMapper(PwMMapper pwMMapper) {
    this.pwMMapper = pwMMapper;
  }

  public void setIlcMMapper(IlcMMapper ilcMMapper) {
    this.ilcMMapper = ilcMMapper;
  }

  public void setPhoneNoCatMMapper(PhoneNoCatMMapper phoneNoCatMMapper) {
    this.phoneNoCatMMapper = phoneNoCatMMapper;
  }
}
