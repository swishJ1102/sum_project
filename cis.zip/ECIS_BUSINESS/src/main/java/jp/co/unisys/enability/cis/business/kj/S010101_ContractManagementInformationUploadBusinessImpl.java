package jp.co.unisys.enability.cis.business.kj;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.config.PropertiesFactoryBean;
import org.springframework.context.MessageSource;
import org.springframework.scheduling.annotation.Async;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import jp.co.unisys.enability.cis.business.kj.model.AddSupplementaryContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.ContractManagementInformationFileConfigAccountCreditCard;
import jp.co.unisys.enability.cis.business.kj.model.ContractManagementInformationFileConfigCommon;
import jp.co.unisys.enability.cis.business.kj.model.ContractManagementInformationFileConfigContract;
import jp.co.unisys.enability.cis.business.kj.model.ContractManagementInformationFileConfigContractor;
import jp.co.unisys.enability.cis.business.kj.model.ContractManagementInformationFileConfigMeterLocation;
import jp.co.unisys.enability.cis.business.kj.model.ContractManagementInformationFileConfigPayment;
import jp.co.unisys.enability.cis.business.kj.model.ContractManagementInformationFileConfigSupplementaryContract;
import jp.co.unisys.enability.cis.business.kj.model.CsvFileCheckAccountCreditCardBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.CsvFileCheckContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.CsvFileCheckContractorBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.CsvFileCheckMeterLocationBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.CsvFileCheckPaymentBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.CsvFileCheckSupplementaryContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.Custom_AddCustomContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.Custom_ContractManagementInformationFileConfigContract;
import jp.co.unisys.enability.cis.business.kj.model.Custom_ContractManagementInformationFileConfigContractor;
import jp.co.unisys.enability.cis.business.kj.model.Custom_ContractManagementInformationFileConfigMeterLocation;
import jp.co.unisys.enability.cis.business.kj.model.Custom_ContractManagementInformationFileConfigPayment;
import jp.co.unisys.enability.cis.business.kj.model.Custom_DeleteCustomContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.Custom_DeleteCustomPaymentBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.Custom_RegistCustomContractorBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.Custom_RegistCustomPaymentBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.Custom_UpdateCustomContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.Custom_UpdateCustomContractorBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.Custom_UpdateCustomPaymentBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.DeleteAgentContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.DeletePaymentBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.DeleteReserveContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.DeleteSupplementaryContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.InquiryAgentContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.RegistAccountCreditCardBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.RegistAgentContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.RegistAgentContractorBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.RegistAgentMeterLocationBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.RegistPaymentBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.RegistReserveContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.S010101_ContractManagementInformationUploadBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.UpdateAgentContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.UpdateAgentContractorBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.UpdateAgentMeterLocationBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.UpdatePaymentBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.UpdateReserveContractBusinessBean;
import jp.co.unisys.enability.cis.business.kj.model.UpdateSupplementaryContractBusinessBean;
import jp.co.unisys.enability.cis.common.Exception.SystemException;
import jp.co.unisys.enability.cis.common.util.CommonFileUtil;
import jp.co.unisys.enability.cis.common.util.KJ_CommonUtil;
import jp.co.unisys.enability.cis.common.util.StringConvertUtil;
import jp.co.unisys.enability.cis.common.util.ThreadContext;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISKJConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISReturnCodeConstants;
import jp.co.unisys.enability.cis.entity.common.BulkRegisterControl;
import jp.co.unisys.enability.cis.entity.common.BulkRegisterControlExample;
import jp.co.unisys.enability.cis.entity.common.RmUp;
import jp.co.unisys.enability.cis.entity.common.RmUpDetail;
import jp.co.unisys.enability.cis.entity.common.RmUpDetailExample;
import jp.co.unisys.enability.cis.mapper.common.BulkRegisterControlMapper;
import jp.co.unisys.enability.cis.mapper.common.RmUpDetailMapper;

/**
 * 契約管理情報ファイルアップロード画面ビジネスクラス
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.business.kj.KJ_ContractorInformationBusiness
 * @see jp.co.unisys.enability.cis.business.kj.KJ_AccountCreditCardInformationBusiness
 * @see jp.co.unisys.enability.cis.business.kj.KJ_PaymentInformationBusiness
 * @see jp.co.unisys.enability.cis.business.kj.KJ_ContractInformationBusiness
 * @see jp.co.unisys.enability.cis.business.kj.KJ_SupplementaryContractInformationBusiness
 * @see jp.co.unisys.enability.cis.business.kj.KJ_MeterLocationInformationBusiness
 * @see jp.co.unisys.enability.cis.business.kj.KJ_ReserveContractInformationBusiness
 * @see jp.co.unisys.enability.cis.mapper.common.BulkRegisterControlMapper
 */
public class S010101_ContractManagementInformationUploadBusinessImpl implements
    S010101_ContractManagementInformationUploadBusiness {

  /**
   * 非同期処理用ロガー
   */
  private static final Logger LOGGER = LogManager.getLogger();

  /**
   * 契約者情報ビジネス(DI)
   */
  private KJ_ContractorInformationBusiness contractorInformationBusiness;

  /**
   * 卸取次店向け契約者情報ビジネス(DI)
   */
  private KJ_AgentContractorInformationBusiness agentContractorInformationBusiness;

  /**
   * カスタム契約者情報ビジネス(DI)
   */
  private Custom_KJ_CustomContractorInformationBusiness customContractorInformationBusiness;

  /**
   * 口座クレカ情報ビジネス(DI)
   */
  private KJ_AccountCreditCardInformationBusiness accountCreditCardInformationBusiness;

  /**
   * 支払情報ビジネス(DI)
   */
  private KJ_PaymentInformationBusiness paymentInformationBusiness;

  /**
   * カスタム支払履歴報ビジネス(DI)
   */
  private Custom_KJ_CustomPaymentInformationBusiness customPaymentInformationBusiness;

  /**
   * 契約情報ビジネス(DI)
   */
  private KJ_ContractInformationBusiness contractInformationBusiness;

  /**
   * 卸取次店向け契約情報ビジネス(DI)
   */
  private KJ_AgentContractInformationBusiness agentContractInformationBusiness;

  /**
   * カスタム契約情報ビジネス(DI)
   */
  private Custom_KJ_CustomContractInformationBusiness customContractInformationBusiness;

  /**
   * 付帯契約情報ビジネス(DI)
   */
  private KJ_SupplementaryContractInformationBusiness supplementaryContractInformationBusiness;

  /**
   * メータ設置場所情報ビジネス(DI)
   */
  private KJ_MeterLocationInformationBusiness meterLocationInformationBusiness;

  /**
   * 卸取次店向けメータ設置場所情報ビジネス(DI)
   */
  private KJ_AgentMeterLocationInformationBusiness agentMeterLocationInformationBusiness;

  /**
   * 予備契約情報ビジネス(DI)
   */
  private KJ_ReserveContractInformationBusiness reserveContractInformationBusiness;

  /**
   * 一括登録制御マッパー（DI）
   */
  private BulkRegisterControlMapper bulkRegisterControlMapper;

  /**
   * 料金メニュー単価明細マッパー(DI)
   */
  private RmUpDetailMapper rmUpDetailMapper;

  /**
   * プロパティ（DI）
   */
  private PropertiesFactoryBean applicationProperties;

  /**
   * メッセージソース（DI）
   */
  private MessageSource messageSource;

  /**
   * トランザクションテンプレート（DI）
   */
  private TransactionTemplate transactionTemplateRequired;

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.business.kj.
   * S010101_ContractManagementInformationUploadBusiness
   * #asyncProcess(jp.co.unisys.enability.cis.business.kj.model.
   * S010101_ContractManagementInformationUploadBusinessBean)
   */
  @Override
  @Async
  public void asyncProcess(
      S010101_ContractManagementInformationUploadBusinessBean contractManagementInformationUploadBusinessBean) {
    // エラーリストオブジェクト生成
    final List<String> errorList = new ArrayList<String>();
    String errorListDir = null;
    String errorListFullPath = null;

    try {
      // プロパティ取得
      Properties prop = applicationProperties.getObject();
      errorListDir = prop.getProperty("download.contract.manegement.infomation.errorlistfile.work.dir");

      // エラーリストファイルパス設定
      StringBuilder errorListPathBuilder = new StringBuilder();
      errorListPathBuilder.append(errorListDir);
      errorListPathBuilder.append(ECISKJConstants.CONTRACT_MANAGEMENT_INFORMATION_PREFIX_ERRORLIST_FILE);
      errorListPathBuilder.append(ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD);
      errorListPathBuilder.append(ECISConstants.UNDERLINE);
      errorListPathBuilder.append(contractManagementInformationUploadBusinessBean.getUserId());
      errorListPathBuilder.append(ECISConstants.FILE_EXTENSION_TXT);
      // 変数に設定
      errorListFullPath = errorListPathBuilder.toString();
      errorListPathBuilder = null;

      // エラーリスト削除
      this.deleteErrorFile(errorListFullPath);

      // エラーリスト削除までにエラーがある場合
    } catch (Exception e) {
      // エラーログ出力し、処理を終了する。
      LOGGER.catching(e);
      this.finallyOperationForAsync(contractManagementInformationUploadBusinessBean);
      return;
    }

    /**
     * ThreadContext情報設定
     */
    // 非同期処理ではThreadContextの情報が引き継げないため、再設定する
    // モジュールコード（クラス名）
    ThreadContext.getRequestThreadContext().put(ECISConstants.CLASS_NAME_KEY,
        contractManagementInformationUploadBusinessBean.getModuleCode());
    // ユーザID
    ThreadContext.getRequestThreadContext().put(ECISConstants.USER_ID_KEY,
        contractManagementInformationUploadBusinessBean.getUserId());
    // セッションID
    ThreadContext.getRequestThreadContext().put(ECISConstants.SESSION_ID_KEY,
        contractManagementInformationUploadBusinessBean.getSessionId());
    // オンラインフラグ
    ThreadContext.getRequestThreadContext().put(ECISConstants.ONLINE_FLAG_KEY,
        contractManagementInformationUploadBusinessBean.getOnlineFlag());

    /**
     * メイン処理
     */
    // トランザクション開始
    transactionTemplateRequired.execute(new TransactionCallbackWithoutResult() {

      @Override
      protected void doInTransactionWithoutResult(TransactionStatus status) {
        try {
          errorList.addAll(transactUploadAction(contractManagementInformationUploadBusinessBean));
          // エラーリストが存在する場合、ロールバック
          if (!errorList.isEmpty()) {
            status.setRollbackOnly();
          }
          // 例外をキャッチした場合
        } catch (Exception e) {
          // エラートレースをログ出力し、想定外エラーメッセージをエラーリストに設定する。
          LOGGER.catching(e);
          errorList.add(messageSource.getMessage("error.E0011", null, Locale.getDefault()));
          // ロールバック
          status.setRollbackOnly();
        }
      }
    });

    // エラーリスト生成
    this.createErrorFile(errorList, errorListDir, errorListFullPath);

    // 終了処理
    this.finallyOperationForAsync(contractManagementInformationUploadBusinessBean);
  }

  /**
   * エラーリスト削除処理を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 1 エラーリストを削除する。
   * 2 削除に失敗した場合、規定のリトライ間隔・回数でリトライを行う。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param errorListFullPath
   *          エラーリストのフルパス
   * @throws InterruptedException
   *           スレッドスリープエラー発生時
   */
  private void deleteErrorFile(String errorListFullPath) throws InterruptedException {
    // サーバ側のファイル設定
    File errorListFile = new File(errorListFullPath);

    // エラーリスト削除
    int retryCount = 0;
    do {
      // エラーリストが無い場合、終了
      if (!errorListFile.exists()) {
        return;
      }

      // 削除成功の場合、処理を抜ける
      if (errorListFile.delete()) {
        return;
      }

      // 失敗の場合、リトライ回数加算
      // リトライ回数を超過した場合、システム例外
      if (retryCount >= ECISKJConstants.CONTRACT_MANAGEMENT_INFORMATION_ERRORLIST_FILE_DOWNLOAD_MAX_RETRY_COUNT) {
        throw new SystemException(messageSource.getMessage("error.E0001",
            new String[] {"エラーリストの削除" }, Locale.getDefault()));
      }
      retryCount++;
      // 規定の待機を行う
      Thread.sleep(ECISKJConstants.CONTRACT_MANAGEMENT_INFORMATION_ERRORLIST_FILE_RETRY_INTERVAL_MSEC);
    } while (true);
  }

  /**
   * エラーリスト作成処理を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 1 エラーリストを作成する。
   * 2 作成に失敗した場合、ログ出力を行い、処理を抜ける。
   * 例外はThrowしない。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param errorList
   *          エラーリスト内容
   * @param errorListDir
   *          エラーリスト出力先パス
   * @param errorListFullPath
   *          エラーリストフルパス
   */
  private void createErrorFile(List<String> errorList, String errorListDir, String errorListFullPath) {
    // エラーリストが無い場合、処理しない
    if (errorList == null || errorList.isEmpty()) {
      return;
    }

    // 出力処理
    BufferedWriter bw = null;
    try {
      new File(errorListDir).mkdirs();

      // 出力場所の定義
      bw = new BufferedWriter(new FileWriter(new File(errorListFullPath.toString())));

      for (String line : errorList) {
        bw.write(line);
        bw.newLine();
      }
    } catch (IOException e) {
      // 作成失敗の場合、エラーログ出力を行う
      LOGGER.catching(e);
      LOGGER.error(messageSource.getMessage("error.E0001", new String[] {"エラーリストの作成" }, Locale.getDefault()), e);
    } finally {
      // ライターのクローズ処理
      if (bw != null) {
        try {
          bw.close();
        } catch (IOException e) {
        }
      }
    }
  }

  /**
   * 非同期終了処理を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 1 アップロードファイルを一括削除する。
   * 2 一括登録制御のロックを解除する。
   * エラー発生時は、エラートレースをログに出力し、呼び出し元へ例外は返さない。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param businessBean
   *          契約管理情報アップロードBusinessBean
   */
  private void finallyOperationForAsync(S010101_ContractManagementInformationUploadBusinessBean businessBean) {

    // アップロードファイル削除
    try {
      CommonFileUtil.deleteDirectoryRecurse(businessBean.getUploadFilePath());
    } catch (Exception e) {
      LOGGER.catching(e);
    }

    // 一括登録制御ロック解除
    try {
      // トランザクション開始
      transactionTemplateRequired.execute(new TransactionCallbackWithoutResult() {

        @Override
        protected void doInTransactionWithoutResult(TransactionStatus status) {

          // 無条件で一括登録制御を取得
          List<BulkRegisterControl> bulkRegisterControlList = bulkRegisterControlMapper.selectByExample(null);
          BulkRegisterControl currentBulkRegisterControl = bulkRegisterControlList.get(0);

          // コンテキスト情報取得
          // ユーザID
          String contextUserId = businessBean.getUserId();
          // モジュールコード
          String contextModuleCode = businessBean.getModuleCode();

          // 実行日時取得
          Timestamp systemTime = new Timestamp(System.currentTimeMillis());

          // 更新情報設定
          BulkRegisterControl bulkRegisterControl = new BulkRegisterControl();
          // ロックフラグをオフにする
          bulkRegisterControl.setLockFlag(ECISConstants.FLG_OFF);
          // 更新回数を＋１する
          bulkRegisterControl.setUpdateCount(currentBulkRegisterControl.getUpdateCount().intValue() + 1);
          // オンライン更新日時
          bulkRegisterControl.setOnlineUpdateTime(systemTime);
          // オンライン更新ユーザID
          bulkRegisterControl.setOnlineUpdateUserId(contextUserId);
          // 更新日時
          bulkRegisterControl.setUpdateTime(systemTime);
          // 更新モジュールコード
          bulkRegisterControl.setUpdateModuleCode(contextModuleCode);

          // 条件設定
          // 更新回数が取得時の更新回数、かつロックフラグがON
          BulkRegisterControlExample example = new BulkRegisterControlExample();
          example.createCriteria()
              .andUpdateCountEqualTo(currentBulkRegisterControl.getUpdateCount().intValue())
              .andLockFlagEqualTo(ECISConstants.FLG_ON);

          // 一括登録制御更新
          int result = bulkRegisterControlMapper.updateByExampleSelective(bulkRegisterControl, example);

          // 結果判定
          // 0件の場合、ロールバック
          if (result == 0) {
            status.setRollbackOnly();
          }
        }
      });
    } catch (Exception e) {
      LOGGER.catching(e);
    }
  }

  /**
   * 契約管理情報アップロード非同期処理の本処理を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * トランザクション内のメイン処理を行う。
   * 1 アップロードファイル順に読み込み、ファイルバリデーションを行う。
   * 2 一括登録、更新、削除の順に処理を行う。
   * </pre>
   *
   * @param businessBean
   *          契約管理情報アップロードBusinessBean
   * @return エラーリスト
   */
  private List<String> transactUploadAction(S010101_ContractManagementInformationUploadBusinessBean businessBean) {

    // 返却用エラーリスト作成
    List<String> outErrorList = new ArrayList<String>();

    // 処理情報取得
    // アップロードファイル保存先パス
    String uploadFilePath = businessBean.getUploadFilePath();

    // 処理継続フラグを定義する。
    String execFlag;

    /**
     * ファイルチェック処理
     */
    // 処理用オブジェクト生成
    // 契約者情報CSVファイルチェックBeanリスト
    List<CsvFileCheckContractorBusinessBean> csvFileCheckContractorBusinessBeanList = new ArrayList<CsvFileCheckContractorBusinessBean>();
    // 口座クレカ情報CSVファイルチェックBeanリスト
    List<CsvFileCheckAccountCreditCardBusinessBean> csvFileCheckAccountCreditCardBusinessBeanList = new ArrayList<CsvFileCheckAccountCreditCardBusinessBean>();
    // 支払情報CSVファイルチェックBeanリスト
    List<CsvFileCheckPaymentBusinessBean> csvFileCheckPaymentBusinessBeanList = new ArrayList<CsvFileCheckPaymentBusinessBean>();
    // 契約情報CSVファイルチェックBeanリスト
    List<CsvFileCheckContractBusinessBean> csvFileCheckContractBusinessBeanList = new ArrayList<CsvFileCheckContractBusinessBean>();
    // 付帯契約情報CSVファイルチェックBeanリスト
    List<CsvFileCheckSupplementaryContractBusinessBean> csvFileCheckSupplementaryContractBusinessBeanList = new ArrayList<CsvFileCheckSupplementaryContractBusinessBean>();
    // メータ設置場所情報CSVファイルチェックBeanリスト
    List<CsvFileCheckMeterLocationBusinessBean> csvFileCheckMeterLocationBusinessBeanList = new ArrayList<CsvFileCheckMeterLocationBusinessBean>();

    // ファイルチェック
    File[] files = new File(uploadFilePath).listFiles();
    // FindBugs避けチェック
    if (files == null) {
      throw new SystemException("アップロードファイルがありません。");
    }

    for (File uploadFile : files) {
      // ファイル名取得
      String fileName = uploadFile.getName();
      // ファイル名接頭辞取得
      // 定数がアンダーラインつきのため、アンダーラインを付与する
      String filePrefix = new StringBuilder(fileName.split(ECISConstants.UNDERLINE)[0]).append(
          ECISConstants.UNDERLINE).toString();

      // チェック処理
      // 接頭辞が各ファイルコンフィグクラスの接頭辞と一致するかチェックする
      switch (filePrefix) {
        // 契約者情報ファイルチェック
        case ContractManagementInformationFileConfigContractor.FILE_NAME_PREFIX:
          CsvFileCheckContractorBusinessBean contractorCsvCheckBean = new CsvFileCheckContractorBusinessBean();
          contractorCsvCheckBean.setUploadFile(uploadFile);
          // CSVファイルチェック実行
          CsvFileCheckContractorBusinessBean contractorResultBean = contractorInformationBusiness
              .csvFileCheckCustom(contractorCsvCheckBean);
          // エラーリストが無い場合、処理用リストに追加する
          if (contractorResultBean.getErrorList().isEmpty()) {
            csvFileCheckContractorBusinessBeanList.add(contractorResultBean);
            // エラーリストがある場合、エラーリストを設定する
          } else {
            outErrorList.addAll(contractorResultBean.getErrorList());
          }
          break;
        // 口座クレカ情報ファイルチェック
        case ContractManagementInformationFileConfigAccountCreditCard.FILE_NAME_PREFIX:
          CsvFileCheckAccountCreditCardBusinessBean accountCreditCardCsvCheckBean = new CsvFileCheckAccountCreditCardBusinessBean();
          accountCreditCardCsvCheckBean.setUploadFile(uploadFile);
          // CSVファイルチェック実行
          CsvFileCheckAccountCreditCardBusinessBean accountCreditCardResultBean = accountCreditCardInformationBusiness
              .csvFileCheck(accountCreditCardCsvCheckBean);
          // エラーリストが無い場合、処理用リストに追加する
          if (accountCreditCardResultBean.getErrorList().isEmpty()) {
            csvFileCheckAccountCreditCardBusinessBeanList.add(accountCreditCardResultBean);
            // エラーリストがある場合、エラーリストを設定する
          } else {
            outErrorList.addAll(accountCreditCardResultBean.getErrorList());
          }
          break;
        // 支払情報ファイルチェック
        case ContractManagementInformationFileConfigPayment.FILE_NAME_PREFIX:
          CsvFileCheckPaymentBusinessBean paymentCsvCheckBean = new CsvFileCheckPaymentBusinessBean();
          paymentCsvCheckBean.setUploadFile(uploadFile);
          // CSVファイルチェック実行
          CsvFileCheckPaymentBusinessBean paymentResultBean = paymentInformationBusiness
              .csvFileCheckCustom(paymentCsvCheckBean);
          // エラーリストが無い場合、処理用リストに追加する
          if (paymentResultBean.getErrorList().isEmpty()) {
            csvFileCheckPaymentBusinessBeanList.add(paymentResultBean);
            // エラーリストがある場合、エラーリストを設定する
          } else {
            outErrorList.addAll(paymentResultBean.getErrorList());
          }
          break;
        // 契約情報ファイルチェック
        case ContractManagementInformationFileConfigContract.FILE_NAME_PREFIX:
          CsvFileCheckContractBusinessBean contractCsvCheckBean = new CsvFileCheckContractBusinessBean();
          contractCsvCheckBean.setUploadFile(uploadFile);
          // CSVファイルチェック実行
          CsvFileCheckContractBusinessBean contractResultBean = contractInformationBusiness
              .csvFileCheckCustom(contractCsvCheckBean);
          // エラーリストが無い場合、処理用リストに追加する
          if (contractResultBean.getErrorList().isEmpty()) {
            csvFileCheckContractBusinessBeanList.add(contractResultBean);
            // エラーリストがある場合、エラーリストを設定する
          } else {
            outErrorList.addAll(contractResultBean.getErrorList());
          }
          break;
        // 付帯契約情報ファイルチェック
        case ContractManagementInformationFileConfigSupplementaryContract.FILE_NAME_PREFIX:
          CsvFileCheckSupplementaryContractBusinessBean supplementaryContractCsvCheckBean = new CsvFileCheckSupplementaryContractBusinessBean();
          supplementaryContractCsvCheckBean.setUploadFile(uploadFile);
          // CSVファイルチェック実行
          CsvFileCheckSupplementaryContractBusinessBean supplementaryContractResultBean = supplementaryContractInformationBusiness
              .csvFileCheck(supplementaryContractCsvCheckBean);
          // エラーリストが無い場合、処理用リストに追加する
          if (supplementaryContractResultBean.getErrorList().isEmpty()) {
            csvFileCheckSupplementaryContractBusinessBeanList.add(supplementaryContractResultBean);
            // エラーリストがある場合、エラーリストを設定する
          } else {
            outErrorList.addAll(supplementaryContractResultBean.getErrorList());
          }
          break;
        // メータ設置場所情報ファイルチェック
        case ContractManagementInformationFileConfigMeterLocation.FILE_NAME_PREFIX:
          CsvFileCheckMeterLocationBusinessBean meterLocationCsvCheckBean = new CsvFileCheckMeterLocationBusinessBean();
          meterLocationCsvCheckBean.setUploadFile(uploadFile);
          // CSVファイルチェック実行
          CsvFileCheckMeterLocationBusinessBean meterLocationResultBean = meterLocationInformationBusiness
              .csvFileCheckCustom(meterLocationCsvCheckBean);
          // エラーリストが無い場合、処理用リストに追加する
          if (meterLocationResultBean.getErrorList().isEmpty()) {
            csvFileCheckMeterLocationBusinessBeanList.add(meterLocationResultBean);
            // エラーリストがある場合、エラーリストを設定する
          } else {
            outErrorList.addAll(meterLocationResultBean.getErrorList());
          }
          break;
        // ファイル種別が不正な場合、エラー
        default:
          outErrorList.add(messageSource.getMessage("error.E0025", null, Locale.getDefault()));
          break;
      }
    }

    /**
     * エラーリストチェック処理
     */
    // エラーリストがある場合、エラーリストを返却
    if (!outErrorList.isEmpty()) {
      return outErrorList;
    }

    /**
     * 削除処理
     */
    // 付帯契約情報削除
    for (CsvFileCheckSupplementaryContractBusinessBean deleteBean : csvFileCheckSupplementaryContractBusinessBeanList) {

      // 付帯契約情報削除処理を呼出し。
      execFlag = this.uploadDeleteSupplementaryContract(deleteBean.getDeleteList(),
          deleteBean.getUploadFileName(), outErrorList);
      // 返却した処理継続フラグを判定し、0(処理継続不可)の場合、エラーリストを返却して処理を終了する。
      if (ECISConstants.FLG_OFF.equals(execFlag)) {
        return outErrorList;
      }
    }
    // 契約情報削除
    for (CsvFileCheckContractBusinessBean deleteBean : csvFileCheckContractBusinessBeanList) {

      // 契約情報削除処理を呼出し。
      execFlag = this.uploadDeleteContract(deleteBean.getDeleteList(), deleteBean.getUploadFileName(),
          outErrorList);
      // 返却した処理継続フラグを判定し、0(処理継続不可)の場合、エラーリストを返却して処理を終了する。
      if (ECISConstants.FLG_OFF.equals(execFlag)) {
        return outErrorList;
      }
    }
    // 支払情報削除
    for (CsvFileCheckPaymentBusinessBean deleteBean : csvFileCheckPaymentBusinessBeanList) {

      // 支払情報削除処理を呼出し
      execFlag = this.uploadDeletePayment(deleteBean.getDeleteList(), deleteBean.getUploadFileName(),
          outErrorList);
      // 返却した処理継続フラグを判定し、0(処理継続不可)の場合、エラーリストを返却して処理を終了する。
      if (ECISConstants.FLG_OFF.equals(execFlag)) {
        return outErrorList;
      }
    }

    /**
     * エラーリストチェック処理
     */
    // エラーリストがある場合、エラーリストを返却
    if (!outErrorList.isEmpty()) {
      return outErrorList;
    }

    /**
     * 登録処理
     */
    // 契約者情報登録
    for (CsvFileCheckContractorBusinessBean registBean : csvFileCheckContractorBusinessBeanList) {

      // 契約者情報登録処理を呼出し。
      execFlag = this.uploadRegistContractor(registBean.getRegistList(), registBean.getUploadFileName(),
          outErrorList);
      // 返却した処理継続フラグを判定し、0(処理継続不可)の場合、エラーリストを返却して処理を終了する。
      if (ECISConstants.FLG_OFF.equals(execFlag)) {
        return outErrorList;
      }
    }
    // 口座クレカ情報登録
    for (CsvFileCheckAccountCreditCardBusinessBean registBean : csvFileCheckAccountCreditCardBusinessBeanList) {

      // 口座クレカ情報登録処理を呼出し。
      execFlag = this.uploadRegistAccountCreditCard(registBean.getRegistList(), registBean.getUploadFileName(),
          outErrorList);
      // 返却した処理継続フラグを判定し、0(処理継続不可)の場合、エラーリストを返却して処理を終了する。
      if (ECISConstants.FLG_OFF.equals(execFlag)) {
        return outErrorList;
      }
    }
    // 支払情報登録
    for (CsvFileCheckPaymentBusinessBean registBean : csvFileCheckPaymentBusinessBeanList) {

      // 支払情報登録処理を呼出し。
      execFlag = this.uploadRegistPayment(registBean.getRegistList(), registBean.getUploadFileName(),
          outErrorList);
      // 返却した処理継続フラグを判定し、0(処理継続不可)の場合、エラーリストを返却して処理を終了する。
      if (ECISConstants.FLG_OFF.equals(execFlag)) {
        return outErrorList;
      }
    }
    // 契約情報登録
    for (CsvFileCheckContractBusinessBean registBean : csvFileCheckContractBusinessBeanList) {

      // 契約情報登録処理を呼出し。
      execFlag = this.uploadRegistContract(registBean.getRegistList(), registBean.getUploadFileName(),
          outErrorList);
      // 返却した処理継続フラグを判定し、0(処理継続不可)の場合、エラーリストを返却して処理を終了する。
      if (ECISConstants.FLG_OFF.equals(execFlag)) {
        return outErrorList;
      }
    }
    // 付帯契約情報登録
    for (CsvFileCheckSupplementaryContractBusinessBean registBean : csvFileCheckSupplementaryContractBusinessBeanList) {

      // 付帯契約情報登録処理を呼出し。
      execFlag = this.uploadRegistSupplementaryContract(registBean.getRegistList(),
          registBean.getUploadFileName(), outErrorList);
      // 返却した処理継続フラグを判定し、0(処理継続不可)の場合、エラーリストを返却して処理を終了する。
      if (ECISConstants.FLG_OFF.equals(execFlag)) {
        return outErrorList;
      }
    }
    // メータ設置場所情報登録
    for (CsvFileCheckMeterLocationBusinessBean registBean : csvFileCheckMeterLocationBusinessBeanList) {

      // メータ設置場所情報登録処理を呼出し。
      execFlag = this.uploadRegistMeterLocation(registBean.getRegistList(), registBean.getUploadFileName(),
          outErrorList);
      // 返却した処理継続フラグを判定し、0(処理継続不可)の場合、エラーリストを返却して処理を終了する。
      if (ECISConstants.FLG_OFF.equals(execFlag)) {
        return outErrorList;
      }
    }

    /**
     * エラーリストチェック処理
     */
    // エラーリストがある場合、エラーリストを返却
    if (!outErrorList.isEmpty()) {
      return outErrorList;
    }

    /**
     * 更新処理
     */
    // 契約者情報更新
    for (CsvFileCheckContractorBusinessBean updateBean : csvFileCheckContractorBusinessBeanList) {

      // 契約者情報更新処理を呼出し。
      execFlag = this.uploadUpdateContractor(updateBean.getUpdateList(), updateBean.getUploadFileName(),
          outErrorList);
      // 返却した処理継続フラグを判定し、0(処理継続不可)の場合、エラーリストを返却して処理を終了する。
      if (ECISConstants.FLG_OFF.equals(execFlag)) {
        return outErrorList;
      }
    }
    // 支払情報更新
    for (CsvFileCheckPaymentBusinessBean updateBean : csvFileCheckPaymentBusinessBeanList) {

      //支払情報更新処理を呼出し。
      execFlag = this.uploadUpdatePayment(updateBean.getUpdateList(), updateBean.getUploadFileName(),
          outErrorList);
      // 返却した処理継続フラグを判定し、0(処理継続不可)の場合、エラーリストを返却して処理を終了する。
      if (ECISConstants.FLG_OFF.equals(execFlag)) {
        return outErrorList;
      }
    }
    // 契約情報更新
    for (CsvFileCheckContractBusinessBean updateBean : csvFileCheckContractBusinessBeanList) {

      // 契約情報更新処理を呼出し。
      execFlag = this.uploadUpdateContract(updateBean.getUpdateList(), updateBean.getUploadFileName(),
          outErrorList);
      // 返却した処理継続フラグを判定し、0(処理継続不可)の場合、エラーリストを返却して処理を終了する。
      if (ECISConstants.FLG_OFF.equals(execFlag)) {
        return outErrorList;
      }
    }
    // 付帯契約情報更新
    for (CsvFileCheckSupplementaryContractBusinessBean updateBean : csvFileCheckSupplementaryContractBusinessBeanList) {

      // 付帯契約情報更新処理を呼出し。
      execFlag = this.uploadUpdateSupplementaryContract(updateBean.getUpdateList(),
          updateBean.getUploadFileName(), outErrorList);
      // 返却した処理継続フラグを判定し、0(処理継続不可)の場合、エラーリストを返却して処理を終了する。
      if (ECISConstants.FLG_OFF.equals(execFlag)) {
        return outErrorList;
      }
    }
    // メータ設置場所情報更新
    for (CsvFileCheckMeterLocationBusinessBean updateBean : csvFileCheckMeterLocationBusinessBeanList) {

      // メータ設置場所情報更新処理を呼出し。
      execFlag = this.uploadUpdateMeterLocation(updateBean.getUpdateList(), updateBean.getUploadFileName(),
          outErrorList);
      // 返却した処理継続フラグを判定し、0(処理継続不可)の場合、エラーリストを返却して処理を終了する。
      if (ECISConstants.FLG_OFF.equals(execFlag)) {
        return outErrorList;
      }
    }

    /**
     * エラーリスト返却
     */
    return outErrorList;
  }

  /**
   * 契約者情報登録処理を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 1 処理継続フラグに初期値(ON)を設定する。
   * 2 登録オブジェクトリストの件数分、契約者情報Businessの登録メソッドを呼び出す。
   *   登録メソッドの戻り値のリターンコードが0000以外の場合、
   *   エラー情報を引数.エラーリストオブジェクトに設定する。
   *   登録メソッドの戻り値のリターンコードがD023またはG017の場合、
   *   繰り返し処理を中断し、処理継続フラグにOFFに設定する。
   * 3 処理継続フラグを返却する。
   * </pre>
   *
   * @param registDataList
   *          契約者情報登録オブジェクトリスト
   * @param uploadFileName
   *          アップロードファイル名
   * @param errorList
   *          エラーリスト
   * @return 処理継続フラグ
   */
  private String uploadRegistContractor(List<Map<Integer, String>> registDataList, String uploadFileName,
      List<String> errorList) {

    // リターンコードを定義する。
    String returnCode;
    // 処理継続フラグ（初期値）を設定する
    String execFlag = ECISConstants.FLG_ON;

    // 登録処理
    // 登録オブジェクトリストの件数分実施する
    for (Map<Integer, String> registData : registDataList) {
      // 登録情報設定
      RegistAgentContractorBusinessBean registBean = new RegistAgentContractorBusinessBean();

      // 契約者番号
      registBean.setContractorNo(registData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NO_INDEX));
      // 契約者名1（カナ）
      registBean.setContractorName1Kana(registData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME1_KANA_INDEX));
      // 契約者名1
      registBean.setContractorName1(registData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME1_INDEX));
      // 契約者名2
      registBean.setContractorName2(registData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME2_INDEX));
      // 契約者名1（宛名用）
      registBean.setContractorName1MailingName(registData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME1_MAILING_NAME_INDEX));
      // 契約者名2（宛名用）
      registBean.setContractorName2MailingName(registData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME2_MAILING_NAME_INDEX));
      // 敬称
      registBean.setPrefix(registData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_PREFIX_INDEX));
      // 契約者住所（郵便番号）
      registBean.setContractorAddressPostalCode(registData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_POSTAL_CODE_INDEX));
      // 契約者住所（都道府県名）
      registBean.setContractorAddressPrefectures(registData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_PREFECTURES_INDEX));
      // 契約者住所（市区郡町村名）
      registBean.setContractorAddressMunicipality(registData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_MUNICIPALITY_INDEX));
      // 契約者住所（字名・丁目）
      registBean.setContractorAddressSection(registData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_SECTION_INDEX));
      // 契約者住所（番地・号）
      registBean.setContractorAddressBlock(registData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_BLOCK_INDEX));
      // 契約者住所（建物名）
      registBean
          .setContractorAddressBuildingName(registData
              .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_BUILDING_NAME_INDEX));
      // 契約者住所（部屋名）
      registBean.setContractorAddressRoom(registData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_ROOM_INDEX));
      // 契約者電話番号区分コード1
      registBean.setContractorPhoneCategoryCode1(registData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_CATEGORY_CODE1_INDEX));
      // 契約者電話1（市外局番）
      registBean.setContractorPhoneAreaCode1(registData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_AREA_CODE1_INDEX));
      // 契約者電話1（市内局番）
      registBean.setContractorPhoneLocalNo1(registData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_LOCAL_NO_INDEX));
      // 契約者電話1（加入者番号）
      registBean.setContractorPhoneDirectoryNo1(registData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_DIRECTORY_NO_INDEX));
      // 契約者電話番号区分コード2
      registBean.setContractorPhoneCategoryCode2(registData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_CATEGORY_CODE2_INDEX));
      // 契約者電話2（市外局番）
      registBean.setContractorPhoneAreaCode2(registData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_AREA_CODE2_INDEX));
      // 契約者電話2（市内局番）
      registBean.setContractorPhoneLocalNo2(registData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_LOCAL_NO2_INDEX));
      // 契約者電話2（加入者番号）
      registBean.setContractorPhoneDirectoryNo2(registData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_DIRECTORY_NO2_INDEX));
      // 契約者メールアドレス1
      registBean.setContractorMailAddress1(registData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_MAIL_ADDRESS1_INDEX));
      // 契約者メールアドレス2
      registBean.setContractorMailAddress2(registData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_MAIL_ADDRESS2_INDEX));
      // 提供モデルコード
      registBean.setProvideModelCode(registData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_PROVIDE_MODEL_CODE_INDEX));
      // 提供モデル企業コード
      registBean.setProvideModelCompanyCode(registData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_PROVIDE_MODEL_COMPANY_CODE_INDEX));
      // 利用不能フラグ
      registBean.setUnavailableFlag(registData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_UNAVAILABLE_FLAG_INDEX));
      // 取引先コード
      registBean.setCustomerCode(registData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CUSTOMER_CODE_INDEX));
      // 督促対象外フラグ
      registBean.setUrgeNotCoveredFlag(registData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_URGE_NOT_COVERED_FLAG_INDEX));
      // 個人・法人区分コード
      registBean
          .setIndividualLegalEntityCategoryCode(registData
              .get(Custom_ContractManagementInformationFileConfigContractor.DATA_INDIVIDUAL_LEGAL_ENTITY_CATEGORY_CODE_INDEX));
      // 見える化提供フラグ
      registBean.setVisualizationProvideFlag(registData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_VISUALIZATION_PROVIDE_FLAG_INDEX));
      // 備考
      registBean.setNote(registData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_NOTE_INDEX));
      // 卸取次店契約者番号
      registBean.setAgentContractorNo(registData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_AGENT_CONTRACTOR_NO_INDEX));
      // 契約者フリー項目1
      registBean.setContractorFree1(registData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_01_INDEX));
      // 契約者フリー項目2
      registBean.setContractorFree2(registData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_02_INDEX));
      // 契約者フリー項目3
      registBean.setContractorFree3(registData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_03_INDEX));
      // 契約者フリー項目4
      registBean.setContractorFree4(registData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_04_INDEX));
      // 契約者フリー項目5
      registBean.setContractorFree5(registData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_05_INDEX));
      // 契約者フリー項目6
      registBean.setContractorFree6(registData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_06_INDEX));
      // 契約者フリー項目7
      registBean.setContractorFree7(registData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_07_INDEX));
      // 契約者フリー項目8
      registBean.setContractorFree8(registData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_08_INDEX));
      // 契約者フリー項目9
      registBean.setContractorFree9(registData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_09_INDEX));
      // 契約者フリー項目10
      registBean.setContractorFree10(registData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_10_INDEX));

      // 登録処理実行
      RegistAgentContractorBusinessBean resultBean = agentContractorInformationBusiness.regist(registBean);

      // リターンコードを取得する。
      returnCode = resultBean.getReturnCode();
      // リターンコードが0000（正常終了）以外の場合、エラーリストにメッセージを設定する
      if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(returnCode)) {
        errorList.add(StringConvertUtil.convertErrorListString(
            uploadFileName,
            StringConvertUtil.stringToInteger(registData
                .get(ContractManagementInformationFileConfigCommon.DATA_ROW_NO_INDEX)),
            messageSource.getMessage(
                KJ_CommonUtil.getDisplayMessageId(
                    ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD,
                    returnCode),
                null, Locale.getDefault())));

        // リターンコード判定メソッドを呼出し、処理継続フラグを取得する
        execFlag = checkReturnCode(returnCode);
        // 処理継続フラグが"定数.オフ(0)(処理継続不能)"の場合、処理を終了し、処理継続フラグを返却する
        if (ECISConstants.FLG_OFF.equals(execFlag)) {
          break;
        }
      } else {
        /*
         * カスタム契約者情報登録
         */

        // カスタム登録情報設定
        Custom_RegistCustomContractorBusinessBean customRegistBean = new Custom_RegistCustomContractorBusinessBean();
        // 契約者ID
        customRegistBean.setContractorId(resultBean.getContractorId());
        // 外部システム契約者番号
        customRegistBean.setGasCustomerNo(registData
            .get(Custom_ContractManagementInformationFileConfigContractor.DATA_EXTERNAL_MANAGE_CONTRACTOR_NO_INDEX));

        // カスタム契約者情報登録処理実行
        Custom_RegistCustomContractorBusinessBean customResultBean = customContractorInformationBusiness
            .regist(customRegistBean);

        // リターンコードを取得する。
        returnCode = customResultBean.getReturnCode();
        // リターンコードが0000（正常終了）以外の場合、エラーリストにメッセージを設定する
        if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(returnCode)) {
          errorList.add(StringConvertUtil.convertErrorListString(
              uploadFileName,
              StringConvertUtil.stringToInteger(registData
                  .get(ContractManagementInformationFileConfigCommon.DATA_ROW_NO_INDEX)),
              messageSource.getMessage(
                  KJ_CommonUtil.getDisplayMessageId(
                      ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD,
                      returnCode),
                  null, Locale.getDefault())));

          // リターンコード判定メソッドを呼出し、処理継続フラグを取得する
          execFlag = checkReturnCode(returnCode);
          // 処理継続フラグが"定数.オフ(0)(処理継続不能)"の場合、処理を終了し、処理継続フラグを返却する
          if (ECISConstants.FLG_OFF.equals(execFlag)) {
            break;
          }
        }
      }
    }

    // 処理継続フラグを返却する
    return execFlag;
  }

  /**
   * 契約者情報更新処理を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 1 処理継続フラグに初期値(ON)を設定する。
   * 2 更新オブジェクトリストの件数分、契約者情報Businessの更新メソッドを呼び出す。
   *   更新メソッドの戻り値のリターンコードが0000以外の場合、
   *   エラー情報を引数.エラーリストオブジェクトに設定する。
   *   更新メソッドの戻り値のリターンコードがD023またはG017の場合、
   *   繰り返し処理を中断し、処理継続フラグにOFFに設定する。
   * 3 処理継続フラグを返却する。
   * </pre>
   *
   * @param updateDataList
   *          契約者情報更新オブジェクトリスト
   * @param uploadFileName
   *          アップロードファイル名
   * @param errorList
   *          エラーリスト
   * @return 処理継続フラグ
   */
  private String uploadUpdateContractor(List<Map<Integer, String>> updateDataList, String uploadFileName,
      List<String> errorList) {

    // リターンコードを定義する。
    String returnCode;
    // 処理継続フラグ（初期値）を設定する
    String execFlag = ECISConstants.FLG_ON;

    // 更新処理
    // 更新オブジェクトリストの件数分実施する
    for (Map<Integer, String> updateData : updateDataList) {
      // 更新情報設定
      UpdateAgentContractorBusinessBean updateBean = new UpdateAgentContractorBusinessBean();

      // 契約者ID
      updateBean.setContractorId(null);
      // 契約者番号
      updateBean.setContractorNo(updateData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NO_INDEX));
      // 契約者名1（カナ）
      updateBean.setContractorName1Kana(updateData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME1_KANA_INDEX));
      // 契約者名1
      updateBean.setContractorName1(updateData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME1_INDEX));
      // 契約者名2
      updateBean.setContractorName2(updateData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME2_INDEX));
      // 契約者名1（宛名用）
      updateBean.setContractorName1MailingName(updateData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME1_MAILING_NAME_INDEX));
      // 契約者名2（宛名用）
      updateBean.setContractorName2MailingName(updateData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_NAME2_MAILING_NAME_INDEX));
      // 敬称
      updateBean.setPrefix(updateData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_PREFIX_INDEX));
      // 契約者住所（郵便番号）
      updateBean.setContractorAddressPostalCode(updateData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_POSTAL_CODE_INDEX));
      // 契約者住所（都道府県名）
      updateBean.setContractorAddressPrefectures(updateData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_PREFECTURES_INDEX));
      // 契約者住所（市区郡町村名）
      updateBean.setContractorAddressMunicipality(updateData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_MUNICIPALITY_INDEX));
      // 契約者住所（字名・丁目）
      updateBean.setContractorAddressSection(updateData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_SECTION_INDEX));
      // 契約者住所（番地・号）
      updateBean.setContractorAddressBlock(updateData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_BLOCK_INDEX));
      // 契約者住所（建物名）
      updateBean
          .setContractorAddressBuildingName(updateData
              .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_BUILDING_NAME_INDEX));
      // 契約者住所（部屋名）
      updateBean.setContractorAddressRoom(updateData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_ADDRESS_ROOM_INDEX));
      // 契約者電話番号区分コード1
      updateBean.setContractorPhoneCategoryCode1(updateData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_CATEGORY_CODE1_INDEX));
      // 契約者電話1（市外局番）
      updateBean.setContractorPhoneAreaCode1(updateData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_AREA_CODE1_INDEX));
      // 契約者電話1（市内局番）
      updateBean.setContractorPhoneLocalNo1(updateData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_LOCAL_NO_INDEX));
      // 契約者電話1（加入者番号）
      updateBean.setContractorPhoneDirectoryNo1(updateData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_DIRECTORY_NO_INDEX));
      // 契約者電話番号区分コード2
      updateBean.setContractorPhoneCategoryCode2(updateData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_CATEGORY_CODE2_INDEX));
      // 契約者電話2（市外局番）
      updateBean.setContractorPhoneAreaCode2(updateData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_AREA_CODE2_INDEX));
      // 契約者電話2（市内局番）
      updateBean.setContractorPhoneLocalNo2(updateData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_LOCAL_NO2_INDEX));
      // 契約者電話2（加入者番号）
      updateBean.setContractorPhoneDirectoryNo2(updateData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_PHONE_DIRECTORY_NO2_INDEX));
      // 契約者メールアドレス1
      updateBean.setContractorMailAddress1(updateData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_MAIL_ADDRESS1_INDEX));
      // 契約者メールアドレス2
      updateBean.setContractorMailAddress2(updateData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CONTRACTOR_MAIL_ADDRESS2_INDEX));
      // 利用不能フラグ
      updateBean.setUnavailableFlag(updateData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_UNAVAILABLE_FLAG_INDEX));
      // 取引先コード
      updateBean.setCustomerCode(updateData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_CUSTOMER_CODE_INDEX));
      // 督促対象外フラグ
      updateBean.setUrgeNotCoveredFlag(updateData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_URGE_NOT_COVERED_FLAG_INDEX));
      // 個人・法人区分コード
      updateBean
          .setIndividualLegalEntityCategoryCode(updateData
              .get(Custom_ContractManagementInformationFileConfigContractor.DATA_INDIVIDUAL_LEGAL_ENTITY_CATEGORY_CODE_INDEX));
      // 見える化提供フラグ
      updateBean.setVisualizationProvideFlag(updateData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_VISUALIZATION_PROVIDE_FLAG_INDEX));
      // 備考
      updateBean.setNote(updateData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_NOTE_INDEX));
      // 更新回数
      updateBean.setUpdateCount(StringConvertUtil.stringToInteger(updateData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_UPDATE_COUNT_INDEX)));
      // 卸取次店契約者番号
      updateBean.setAgentContractorNo(updateData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_AGENT_CONTRACTOR_NO_INDEX));
      // 契約者フリー項目1
      updateBean.setContractorFree1(updateData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_01_INDEX));
      // 契約者フリー項目2
      updateBean.setContractorFree2(updateData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_02_INDEX));
      // 契約者フリー項目3
      updateBean.setContractorFree3(updateData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_03_INDEX));
      // 契約者フリー項目4
      updateBean.setContractorFree4(updateData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_04_INDEX));
      // 契約者フリー項目5
      updateBean.setContractorFree5(updateData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_05_INDEX));
      // 契約者フリー項目6
      updateBean.setContractorFree6(updateData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_06_INDEX));
      // 契約者フリー項目7
      updateBean.setContractorFree7(updateData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_07_INDEX));
      // 契約者フリー項目8
      updateBean.setContractorFree8(updateData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_08_INDEX));
      // 契約者フリー項目9
      updateBean.setContractorFree9(updateData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_09_INDEX));
      // 契約者フリー項目10
      updateBean.setContractorFree10(updateData
          .get(Custom_ContractManagementInformationFileConfigContractor.DATA_FREE_10_INDEX));

      // 更新処理実行
      UpdateAgentContractorBusinessBean resultBean = agentContractorInformationBusiness.update(updateBean);

      // リターンコードを取得する。
      returnCode = resultBean.getReturnCode();
      // リターンコードが0000（正常終了）以外の場合、エラーリストにメッセージを設定する
      if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(returnCode)) {
        errorList.add(StringConvertUtil.convertErrorListString(
            uploadFileName,
            StringConvertUtil.stringToInteger(updateData
                .get(ContractManagementInformationFileConfigCommon.DATA_ROW_NO_INDEX)),
            messageSource.getMessage(
                KJ_CommonUtil.getDisplayMessageId(
                    ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD,
                    returnCode),
                null, Locale.getDefault())));

        // リターンコード判定メソッドを呼出し、処理継続フラグを取得する
        execFlag = checkReturnCode(returnCode);
        // 処理継続フラグが"定数.オフ(0)(処理継続不能)"の場合、処理を終了し、処理継続フラグを返却する
        if (ECISConstants.FLG_OFF.equals(execFlag)) {
          break;
        }
      } else {
        /*
         * カスタム契約者情報更新
         */
        // カスタム更新情報設定
        Custom_UpdateCustomContractorBusinessBean customUpdateBean = new Custom_UpdateCustomContractorBusinessBean();
        // 契約者ID
        customUpdateBean.setContractorId(resultBean.getContractorId());
        // 外部システム契約者番号
        customUpdateBean.setGasCustomerNo(updateData
            .get(Custom_ContractManagementInformationFileConfigContractor.DATA_EXTERNAL_MANAGE_CONTRACTOR_NO_INDEX));

        // カスタム契約者情報更新処理実行
        Custom_UpdateCustomContractorBusinessBean customResultBean = customContractorInformationBusiness
            .update(customUpdateBean);

        // リターンコードを取得する。
        returnCode = customResultBean.getReturnCode();
        // リターンコードが0000（正常終了）以外の場合、エラーリストにメッセージを設定する
        if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(returnCode)) {
          errorList.add(StringConvertUtil.convertErrorListString(
              uploadFileName,
              StringConvertUtil.stringToInteger(updateData
                  .get(ContractManagementInformationFileConfigCommon.DATA_ROW_NO_INDEX)),
              messageSource.getMessage(
                  KJ_CommonUtil.getDisplayMessageId(
                      ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD,
                      returnCode),
                  null, Locale.getDefault())));

          // リターンコード判定メソッドを呼出し、処理継続フラグを取得する
          execFlag = checkReturnCode(returnCode);
          // 処理継続フラグが"定数.オフ(0)(処理継続不能)"の場合、処理を終了し、処理継続フラグを返却する
          if (ECISConstants.FLG_OFF.equals(execFlag)) {
            break;
          }
        }
      }
    }

    // 処理継続フラグを返却する
    return execFlag;
  }

  /**
   * 口座クレカ情報登録処理を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 1 処理継続フラグに初期値(ON)を設定する。
   * 2 登録オブジェクトリストの件数分、口座クレカ情報Businessの登録メソッドを呼び出す。
   *   登録メソッドの戻り値のリターンコードが0000以外の場合、
   *   エラー情報を引数.エラーリストオブジェクトに設定する。
   *   登録メソッドの戻り値のリターンコードがD023またはG017の場合、
   *   繰り返し処理を中断し、処理継続フラグにOFFに設定する。
   * 3 処理継続フラグを返却する。
   * </pre>
   *
   * @param registDataList
   *          口座クレカ情報登録オブジェクトリスト
   * @param uploadFileName
   *          アップロードファイル名
   * @param errorList
   *          エラーリスト
   * @return 処理継続フラグ
   */
  private String uploadRegistAccountCreditCard(List<Map<Integer, String>> registDataList,
      String uploadFileName, List<String> errorList) {

    // リターンコードを定義する。
    String returnCode;
    // 処理継続フラグ（初期値）を設定する
    String execFlag = ECISConstants.FLG_ON;

    // 登録処理
    // 登録オブジェクトリストの件数分実施する
    for (Map<Integer, String> registData : registDataList) {
      // 登録情報設定
      RegistAccountCreditCardBusinessBean registBean = new RegistAccountCreditCardBusinessBean();

      // 契約者番号
      registBean.setContractorNo(registData
          .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_CONTRACTOR_NO_INDEX));
      // 決済アクセスキー
      registBean.setAccessKey(registData
          .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_ACCESS_KEY_INDEX));
      // 口座クレカ区分コード
      registBean
          .setAccountCreditCategoryCode(registData
              .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_ACCOUNT_CREDIT_CARD_CATEGORY_CODE_INDEX));
      // 金融機関コード
      registBean.setBankCode(registData
          .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_BANK_CODE_INDEX));
      // 金融機関支店コード
      registBean.setBankBranchCode(registData
          .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_BANK_BRANCH_CODE_INDEX));
      // 金融期間預金種目コード
      registBean
          .setBankTypeOfAccountCode(registData
              .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_BANK_TYPE_OF_ACCOUNT_CODE_INDEX));
      // 口座番号
      registBean.setAccountNo(registData
          .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_ACCOUNT_NO_INDEX));
      // 口座名義
      registBean.setAccountHolderName(registData
          .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_ACCOUNT_HOLDER_NAME_INDEX));
      // クレカ番号
      registBean.setCreditCardNo(registData
          .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_CREDIT_CARD_NO_INDEX));
      // クレカ有効期限
      registBean
          .setCreditCardExpirationDate(registData
              .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_CREDIT_CARD_EXPIRATION_DATE_INDEX));
      // クレカブランドコード
      registBean.setCreditCardBrandCode(registData
          .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_CREDIT_CARD_BRAND_CODE_INDEX));
      // 利用不能フラグ
      registBean.setUnavailableFlag(registData
          .get(ContractManagementInformationFileConfigAccountCreditCard.DATA_UNAVAILABLE_FLAG_INDEX));

      // 登録処理実行
      RegistAccountCreditCardBusinessBean resultBean = accountCreditCardInformationBusiness.regist(registBean);

      // リターンコードを取得する。
      returnCode = resultBean.getReturnCode();
      // リターンコードが0000（正常終了）以外の場合、エラーリストにメッセージを設定する
      if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(returnCode)) {
        errorList.add(StringConvertUtil.convertErrorListString(
            uploadFileName,
            StringConvertUtil.stringToInteger(registData
                .get(ContractManagementInformationFileConfigCommon.DATA_ROW_NO_INDEX)),
            messageSource.getMessage(
                KJ_CommonUtil.getDisplayMessageId(
                    ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD,
                    returnCode),
                null, Locale.getDefault())));

        // リターンコード判定メソッドを呼出し、処理継続フラグを取得する
        execFlag = checkReturnCode(returnCode);
        // 処理継続フラグが"定数.オフ(0)(処理継続不能)"の場合、処理を終了し、処理継続フラグを返却する
        if (ECISConstants.FLG_OFF.equals(execFlag)) {
          break;
        }
      }
    }

    // 処理継続フラグを返却する
    return execFlag;
  }

  /**
   * 支払情報登録処理を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 1 処理継続フラグに初期値(ON)を設定する。
   * 2 登録オブジェクトリストの件数分、支払情報Businessの登録メソッドを呼び出す。
   *   登録メソッドの戻り値のリターンコードが0000以外の場合、
   *   エラー情報を引数.エラーリストオブジェクトに設定する。
   *   登録メソッドの戻り値のリターンコードがD023またはG017の場合、
   *   繰り返し処理を中断し、処理継続フラグにOFFに設定する。
   * 3 処理継続フラグを返却する。
   * </pre>
   *
   * @param registDataList
   *          支払情報登録オブジェクトリスト
   * @param uploadFileName
   *          アップロードファイル名
   * @param errorList
   *          エラーリスト
   * @return 処理継続フラグ
   */
  private String uploadRegistPayment(List<Map<Integer, String>> registDataList, String uploadFileName,
      List<String> errorList) {

    // リターンコードを定義する。
    String returnCode;
    // 処理継続フラグ（初期値）を設定する
    String execFlag = ECISConstants.FLG_ON;

    // 登録処理
    // 登録オブジェクトリストの件数分実施する
    for (Map<Integer, String> registData : registDataList) {
      // 登録情報設定
      RegistPaymentBusinessBean registBean = new RegistPaymentBusinessBean();

      // 契約者ID
      registBean.setContractorId(null);
      // 契約者番号
      registBean.setContractorNo(registData
          .get(Custom_ContractManagementInformationFileConfigPayment.DATA_CONTRACTOR_NO_INDEX));
      // 口座クレカID
      registBean.setAccountCreditCardId(StringConvertUtil.stringToInteger(registData
          .get(Custom_ContractManagementInformationFileConfigPayment.DATA_ACCOUNT_CREDIT_CARD_ID_INDEX)));
      // 口振クレカ翌月請求フラグ
      registBean
          .setDirectDebitCreditCardNextMonthBillingFlag(registData
              .get(Custom_ContractManagementInformationFileConfigPayment.DATA_DIRECT_DEBIT_CREDIT_CARD_NEXT_MONTH_BILLING_FLAG_INDEX));
      // 支払期限区分
      registBean.setPaymentExpirationIndividualSettingFlag(registData
          .get(Custom_ContractManagementInformationFileConfigPayment.DATA_PAYMENT_EXPIRATION_CATEGORY_INDEX));
      // 個別支払期限（月数）
      registBean
          .setPaymentExpirationAddMonths(StringConvertUtil.stringToInteger(registData
              .get(Custom_ContractManagementInformationFileConfigPayment.DATA_INDIVIDUAL_PAYMENT_EXPIRATION_MONTHS_INDEX)));
      // 個別支払期限（日）
      registBean
          .setPaymentExpirationDate(StringConvertUtil.stringToInteger(registData
              .get(Custom_ContractManagementInformationFileConfigPayment.DATA_INDIVIDUAL_PAYMENT_EXPIRATION_DATE_INDEX)));
      // 請求合算フラグ
      registBean.setPreviousBillingAddUpFlag(registData
          .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADD_UP_FLAG_INDEX));
      // 支払適用開始日
      registBean.setPaymentStartDate(StringConvertUtil.stringToDate(
          registData
              .get(Custom_ContractManagementInformationFileConfigPayment.DATA_PAYMENT_START_DATE_INDEX),
          Custom_ContractManagementInformationFileConfigPayment.DATA_PAYMENT_START_DATE_FORMAT));
      // 支払方法コード
      registBean.setPaymentWayCode(registData
          .get(Custom_ContractManagementInformationFileConfigPayment.DATA_PAYMENT_WAY_CODE_INDEX));
      // 個人・法人区分コード
      registBean
          .setIndividualLegalEntityCategoryCode(registData
              .get(Custom_ContractManagementInformationFileConfigPayment.DATA_INDIVIDUAL_LEGAL_ENTITY_CATEGORY_CODE_INDEX));
      // 請求先氏名1
      registBean.setBillingName1(registData
          .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_NAME1_INDEX));
      // 請求先氏名2
      registBean.setBillingName2(registData
          .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_NAME2_INDEX));
      // 敬称
      registBean.setPrefix(registData
          .get(Custom_ContractManagementInformationFileConfigPayment.DATA_PREFIX_INDEX));
      // 請求先住所（郵便番号）
      registBean.setBillingAddressPostalCode(registData
          .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_POSTAL_CODE_INDEX));
      // 請求先住所（都道府県名）
      registBean.setBillingAddressPrefectures(registData
          .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_PREFECTURES_INDEX));
      // 請求先住所（市区郡町村名）
      registBean.setBillingAddressMunicipality(registData
          .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_MUNICIPALITY_INDEX));
      // 請求先住所（字名・丁目）
      registBean.setBillingAddressSection(registData
          .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_SECTION_INDEX));
      // 請求先住所（番地･号）
      registBean.setBillingAddressBlock(registData
          .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_BLOCK_INDEX));
      // 請求先住所（建物名）
      registBean.setBillingAddressBuildingName(registData
          .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_BUILDING_NAME_INDEX));
      // 請求先住所（部屋名）
      registBean.setBillingAddressRoom(registData
          .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_ROOM_INDEX));
      // 請求先電話番号
      registBean.setBillingPhoneNo(registData
          .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_PHONE_NO_INDEX));
      // 請求先電話区分コード
      registBean.setBillingPhoneCategoryCode(registData
          .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_PHONE_CATEGORY_CODE_INDEX));
      // 請求先メールアドレス1
      registBean.setBillingMailAddress1(registData
          .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_MAIL_ADDRESS1_INDEX));
      // 請求先メールアドレス2
      registBean.setBillingMailAddress2(registData
          .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_MAIL_ADDRESS2_INDEX));
      // フリー項目1
      registBean.setFree1(registData
          .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_FREE1_INDEX));
      // フリー項目2
      registBean.setFree2(registData
          .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_FREE2_INDEX));

      // 登録処理実行
      RegistPaymentBusinessBean resultBean = paymentInformationBusiness.regist(registBean);

      // リターンコードを取得する。
      returnCode = resultBean.getReturnCode();
      // リターンコードが0000（正常終了）以外の場合、エラーリストにメッセージを設定する
      if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(returnCode)) {
        errorList.add(StringConvertUtil.convertErrorListString(
            uploadFileName,
            StringConvertUtil.stringToInteger(registData
                .get(ContractManagementInformationFileConfigCommon.DATA_ROW_NO_INDEX)),
            messageSource.getMessage(
                KJ_CommonUtil.getDisplayMessageId(
                    ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD,
                    returnCode),
                null, Locale.getDefault())));

        // リターンコード判定メソッドを呼出し、処理継続フラグを取得する
        execFlag = checkReturnCode(returnCode);
        // 処理継続フラグが"定数.オフ(0)(処理継続不能)"の場合、処理を終了し、処理継続フラグを返却する
        if (ECISConstants.FLG_OFF.equals(execFlag)) {
          break;
        }
      } else {

        /*
         * カスタム支払履歴情報登録
         */

        // カスタム支払履歴情報生成
        Custom_RegistCustomPaymentBusinessBean customRegistBean = new Custom_RegistCustomPaymentBusinessBean();
        // 支払ID
        customRegistBean.setPaymentId(resultBean.getPaymentId());
        // 支払適用開始日
        customRegistBean.setPaymentStartDate(StringConvertUtil.stringToDate(
            registData
                .get(Custom_ContractManagementInformationFileConfigPayment.DATA_PAYMENT_START_DATE_INDEX),
            Custom_ContractManagementInformationFileConfigPayment.DATA_PAYMENT_START_DATE_FORMAT));
        // 外部システム契約番号
        customRegistBean.setGasSupplyContractNo(registData
            .get(Custom_ContractManagementInformationFileConfigPayment.DATA_EXTERNAL_MANAGE_CONTRACT_NO_INDEX));

        // 外部システム支払番号
        customRegistBean.setGasPaymentNo(registData
            .get(Custom_ContractManagementInformationFileConfigPayment.DATA_EXTERNAL_MANAGE_PAYMENT_NO_INDEX));

        // 登録処理実行
        Custom_RegistCustomPaymentBusinessBean customResultBean = customPaymentInformationBusiness
            .regist(customRegistBean);

        // リターンコードを取得する。
        returnCode = customResultBean.getReturnCode();
        // リターンコードが0000（正常終了）以外の場合、エラーリストにメッセージを設定する
        if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(returnCode)) {
          errorList.add(StringConvertUtil.convertErrorListString(
              uploadFileName,
              StringConvertUtil.stringToInteger(registData
                  .get(ContractManagementInformationFileConfigCommon.DATA_ROW_NO_INDEX)),
              messageSource.getMessage(
                  KJ_CommonUtil.getDisplayMessageId(
                      ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD,
                      returnCode),
                  null, Locale.getDefault())));

          // リターンコード判定メソッドを呼出し、処理継続フラグを取得する
          execFlag = checkReturnCode(returnCode);
          // 処理継続フラグが"定数.オフ(0)(処理継続不能)"の場合、処理を終了し、処理継続フラグを返却する
          if (ECISConstants.FLG_OFF.equals(execFlag)) {
            break;
          }
        }
      }
    }

    // 処理継続フラグを返却する
    return execFlag;
  }

  /**
   * 支払情報更新処理を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 1 処理継続フラグに初期値(ON)を設定する。
   * 2 更新オブジェクトリストの件数分、支払情報Businessの更新メソッドを呼び出す。
   *   更新メソッドの戻り値のリターンコードが0000以外の場合、
   *   エラー情報を引数.エラーリストオブジェクトに設定する。
   *   更新メソッドの戻り値のリターンコードがD023またはG017の場合、
   *   繰り返し処理を中断し、処理継続フラグにOFFに設定する。
   * 3 処理継続フラグを返却する。
   * </pre>
   *
   * @param updateDataList
   *          支払情報更新オブジェクトリスト
   * @param uploadFileName
   *          アップロードファイル名
   * @param errorList
   *          エラーリスト
   * @return 処理継続フラグ
   */
  private String uploadUpdatePayment(List<Map<Integer, String>> updateDataList, String uploadFileName,
      List<String> errorList) {

    // リターンコードを定義する。
    String returnCode;
    // 処理継続フラグ（初期値）を設定する
    String execFlag = ECISConstants.FLG_ON;

    // 更新処理
    // 更新オブジェクトリストの件数分実施する
    for (Map<Integer, String> updateData : updateDataList) {
      // 更新情報設定
      UpdatePaymentBusinessBean updateBean = new UpdatePaymentBusinessBean();

      // 支払ID
      updateBean.setPaymentId(null);
      // 支払番号
      updateBean.setPaymentNo(updateData
          .get(Custom_ContractManagementInformationFileConfigPayment.DATA_PAYMENT_NO_INDEX));
      // 口座クレカID
      updateBean.setAccountCreditCardId(StringConvertUtil.stringToInteger(updateData
          .get(Custom_ContractManagementInformationFileConfigPayment.DATA_ACCOUNT_CREDIT_CARD_ID_INDEX)));
      // 口座クレカID更新対象外フラグ
      updateBean.setAccountCreditCardIdNoUpdFlag(ECISConstants.FLG_OFF);
      // 口振クレカ翌月請求フラグ
      updateBean
          .setDirectDebitCreditCardNextMonthBillingFlag(updateData
              .get(Custom_ContractManagementInformationFileConfigPayment.DATA_DIRECT_DEBIT_CREDIT_CARD_NEXT_MONTH_BILLING_FLAG_INDEX));
      // 支払期限区分
      updateBean.setPaymentExpirationIndividualSettingFlag(updateData
          .get(Custom_ContractManagementInformationFileConfigPayment.DATA_PAYMENT_EXPIRATION_CATEGORY_INDEX));
      // 個別支払期限（月数）
      updateBean
          .setPaymentExpirationAddMonths(StringConvertUtil.stringToInteger(updateData
              .get(Custom_ContractManagementInformationFileConfigPayment.DATA_INDIVIDUAL_PAYMENT_EXPIRATION_MONTHS_INDEX)));
      // 個別支払期限（日）
      updateBean
          .setPaymentExpirationDate(StringConvertUtil.stringToInteger(updateData
              .get(Custom_ContractManagementInformationFileConfigPayment.DATA_INDIVIDUAL_PAYMENT_EXPIRATION_DATE_INDEX)));
      // 請求合算フラグ
      updateBean.setPreviousBillingAddUpFlag(updateData
          .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADD_UP_FLAG_INDEX));
      // 支払適用開始日
      updateBean.setPaymentStartDate(StringConvertUtil.stringToDate(
          updateData
              .get(Custom_ContractManagementInformationFileConfigPayment.DATA_PAYMENT_START_DATE_INDEX),
          Custom_ContractManagementInformationFileConfigPayment.DATA_PAYMENT_START_DATE_FORMAT));
      // 支払方法コード
      updateBean.setPaymentWayCode(updateData
          .get(Custom_ContractManagementInformationFileConfigPayment.DATA_PAYMENT_WAY_CODE_INDEX));
      // 個人・法人区分コード
      updateBean
          .setIndividualLegalEntityCategoryCode(updateData
              .get(Custom_ContractManagementInformationFileConfigPayment.DATA_INDIVIDUAL_LEGAL_ENTITY_CATEGORY_CODE_INDEX));
      // 請求先氏名1
      updateBean.setBillingName1(updateData
          .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_NAME1_INDEX));
      // 請求先氏名2
      updateBean.setBillingName2(updateData
          .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_NAME2_INDEX));
      // 敬称
      updateBean.setPrefix(updateData
          .get(Custom_ContractManagementInformationFileConfigPayment.DATA_PREFIX_INDEX));
      // 請求先住所（郵便番号）
      updateBean.setBillingAddressPostalCode(updateData
          .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_POSTAL_CODE_INDEX));
      // 請求先住所（都道府県名）
      updateBean.setBillingAddressPrefectures(updateData
          .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_PREFECTURES_INDEX));
      // 請求先住所（市区郡町村名）
      updateBean.setBillingAddressMunicipality(updateData
          .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_MUNICIPALITY_INDEX));
      // 請求先住所（字名・丁目）
      updateBean.setBillingAddressSection(updateData
          .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_SECTION_INDEX));
      // 請求先住所（番地･号）
      updateBean.setBillingAddressBlock(updateData
          .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_BLOCK_INDEX));
      // 請求先住所（建物名）
      updateBean.setBillingAddressBuildingName(updateData
          .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_BUILDING_NAME_INDEX));
      // 請求先住所（部屋名）
      updateBean.setBillingAddressRoom(updateData
          .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_ADDRESS_ROOM_INDEX));
      // 請求先電話番号
      updateBean.setBillingPhoneNo(updateData
          .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_PHONE_NO_INDEX));
      // 請求先電話区分コード
      updateBean.setBillingPhoneCategoryCode(updateData
          .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_PHONE_CATEGORY_CODE_INDEX));
      // 請求先メールアドレス1
      updateBean.setBillingMailAddress1(updateData
          .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_MAIL_ADDRESS1_INDEX));
      // 請求先メールアドレス2
      updateBean.setBillingMailAddress2(updateData
          .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_MAIL_ADDRESS2_INDEX));
      // フリー項目1
      updateBean.setFree1(updateData
          .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_FREE1_INDEX));
      // フリー項目2
      updateBean.setFree2(updateData
          .get(Custom_ContractManagementInformationFileConfigPayment.DATA_BILLING_FREE2_INDEX));
      // 更新回数
      updateBean.setUpdateCount(StringConvertUtil.stringToInteger(updateData
          .get(Custom_ContractManagementInformationFileConfigPayment.DATA_UPDATE_COUNT_INDEX)));

      // 更新処理実行
      UpdatePaymentBusinessBean resultBean = paymentInformationBusiness.update(updateBean);

      // リターンコードを取得する。
      returnCode = resultBean.getReturnCode();
      // リターンコードが0000（正常終了）以外の場合、エラーリストにメッセージを設定する
      if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(returnCode)) {
        errorList.add(StringConvertUtil.convertErrorListString(
            uploadFileName,
            StringConvertUtil.stringToInteger(updateData
                .get(ContractManagementInformationFileConfigCommon.DATA_ROW_NO_INDEX)),
            messageSource.getMessage(
                KJ_CommonUtil.getDisplayMessageId(
                    ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD,
                    returnCode),
                null, Locale.getDefault())));

        // リターンコード判定メソッドを呼出し、処理継続フラグを取得する
        execFlag = checkReturnCode(returnCode);
        // 処理継続フラグが"定数.オフ(0)(処理継続不能)"の場合、処理を終了し、処理継続フラグを返却する
        if (ECISConstants.FLG_OFF.equals(execFlag)) {
          break;
        }
      } else {
        /*
         * カスタム支払履歴情報更新
         */

        // カスタム支払履歴情報生成
        Custom_UpdateCustomPaymentBusinessBean customUpdateBean = new Custom_UpdateCustomPaymentBusinessBean();
        // 支払ID
        customUpdateBean.setPaymentId(resultBean.getPaymentId());
        // 支払適用開始日
        customUpdateBean.setPaymentStartDate(StringConvertUtil.stringToDate(
            updateData
                .get(Custom_ContractManagementInformationFileConfigPayment.DATA_PAYMENT_START_DATE_INDEX),
            Custom_ContractManagementInformationFileConfigPayment.DATA_PAYMENT_START_DATE_FORMAT));
        // 外部システム契約番号
        customUpdateBean.setGasSupplyContractNo(updateData
            .get(Custom_ContractManagementInformationFileConfigPayment.DATA_EXTERNAL_MANAGE_CONTRACT_NO_INDEX));

        // 外部システム支払番号
        customUpdateBean.setGasPaymentNo(updateData
            .get(Custom_ContractManagementInformationFileConfigPayment.DATA_EXTERNAL_MANAGE_PAYMENT_NO_INDEX));

        // 更新処理実行
        Custom_UpdateCustomPaymentBusinessBean customResultBean = customPaymentInformationBusiness
            .update(customUpdateBean);

        // リターンコードを取得する。
        returnCode = customResultBean.getReturnCode();
        // リターンコードが0000（正常終了）以外の場合、エラーリストにメッセージを設定する
        if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(returnCode)) {
          errorList.add(StringConvertUtil.convertErrorListString(
              uploadFileName,
              StringConvertUtil.stringToInteger(updateData
                  .get(ContractManagementInformationFileConfigCommon.DATA_ROW_NO_INDEX)),
              messageSource.getMessage(
                  KJ_CommonUtil.getDisplayMessageId(
                      ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD,
                      returnCode),
                  null, Locale.getDefault())));

          // リターンコード判定メソッドを呼出し、処理継続フラグを取得する
          execFlag = checkReturnCode(returnCode);
          // 処理継続フラグが"定数.オフ(0)(処理継続不能)"の場合、処理を終了し、処理継続フラグを返却する
          if (ECISConstants.FLG_OFF.equals(execFlag)) {
            break;
          }
        }
      }
    }

    // 処理継続フラグを返却する
    return execFlag;
  }

  /**
   * 支払情報削除処理を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 1 処理継続フラグに初期値(ON)を設定する。
   * 2 削除オブジェクトリストの件数分、支払情報Businessの削除メソッドを呼び出す。
   *   削除メソッドの戻り値のリターンコードが0000以外の場合、
   *   エラー情報を引数.エラーリストオブジェクトに設定する。
   *   削除メソッドの戻り値のリターンコードがD023またはG017の場合、
   *   繰り返し処理を中断し、処理継続フラグにOFFに設定する。
   * 3 処理継続フラグを返却する。
   * </pre>
   *
   * @param deleteDataList
   *          支払情報削除オブジェクトリスト
   * @param uploadFileName
   *          アップロードファイル名
   * @param errorList
   *          エラーリスト
   * @return 処理継続フラグ
   */
  private String uploadDeletePayment(List<Map<Integer, String>> deleteDataList, String uploadFileName,
      List<String> errorList) {

    // リターンコードを定義する。
    String returnCode;
    // 処理継続フラグ（初期値）を設定する
    String execFlag = ECISConstants.FLG_ON;

    // 削除処理
    // 削除オブジェクトリストの件数分実施する
    for (Map<Integer, String> deleteData : deleteDataList) {
      // 削除情報設定
      DeletePaymentBusinessBean deleteBean = new DeletePaymentBusinessBean();

      // 支払ID
      deleteBean.setPaymentId(null);
      // 支払番号
      deleteBean.setPaymentNo(deleteData
          .get(Custom_ContractManagementInformationFileConfigPayment.DATA_PAYMENT_NO_INDEX));
      // 支払適用開始日
      deleteBean.setPaymentStartDate(StringConvertUtil.stringToDate(
          deleteData
              .get(Custom_ContractManagementInformationFileConfigPayment.DATA_PAYMENT_START_DATE_INDEX),
          Custom_ContractManagementInformationFileConfigPayment.DATA_PAYMENT_START_DATE_FORMAT));
      // 更新回数
      deleteBean.setUpdateCount(StringConvertUtil.stringToInteger(deleteData
          .get(Custom_ContractManagementInformationFileConfigPayment.DATA_UPDATE_COUNT_INDEX)));

      // 更新処理実行
      DeletePaymentBusinessBean resultBean = paymentInformationBusiness.delete(deleteBean);

      // リターンコードを取得する。
      returnCode = resultBean.getReturnCode();
      // リターンコードが0000（正常終了）以外の場合、エラーリストにメッセージを設定する
      if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(returnCode)) {
        errorList.add(StringConvertUtil.convertErrorListString(
            uploadFileName,
            StringConvertUtil.stringToInteger(deleteData
                .get(ContractManagementInformationFileConfigCommon.DATA_ROW_NO_INDEX)),
            messageSource.getMessage(
                KJ_CommonUtil.getDisplayMessageId(
                    ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD,
                    returnCode),
                null, Locale.getDefault())));

        // リターンコード判定メソッドを呼出し、処理継続フラグを取得する
        execFlag = checkReturnCode(returnCode);
        // 処理継続フラグが"定数.オフ(0)(処理継続不能)"の場合、処理を終了し、処理継続フラグを返却する
        if (ECISConstants.FLG_OFF.equals(execFlag)) {
          break;
        }
      } else {

        // カスタム支払履歴情報生成
        Custom_DeleteCustomPaymentBusinessBean customDeleteBean = new Custom_DeleteCustomPaymentBusinessBean();
        // 支払ID
        customDeleteBean.setPaymentId(resultBean.getPaymentId());
        // 支払適用開始日
        customDeleteBean.setPaymentStartDate(StringConvertUtil.stringToDate(
            deleteData
                .get(Custom_ContractManagementInformationFileConfigPayment.DATA_PAYMENT_START_DATE_INDEX),
            Custom_ContractManagementInformationFileConfigPayment.DATA_PAYMENT_START_DATE_FORMAT));
        // 削除処理実行
        Custom_DeleteCustomPaymentBusinessBean customResultBean = customPaymentInformationBusiness
            .delete(customDeleteBean);

        // リターンコードを取得する。
        returnCode = customResultBean.getReturnCode();
        // リターンコードが0000（正常終了）以外の場合、エラーリストにメッセージを設定する
        if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(returnCode)) {
          errorList.add(StringConvertUtil.convertErrorListString(
              uploadFileName,
              StringConvertUtil.stringToInteger(deleteData
                  .get(ContractManagementInformationFileConfigCommon.DATA_ROW_NO_INDEX)),
              messageSource.getMessage(
                  KJ_CommonUtil.getDisplayMessageId(
                      ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD,
                      returnCode),
                  null, Locale.getDefault())));

          // リターンコード判定メソッドを呼出し、処理継続フラグを取得する
          execFlag = checkReturnCode(returnCode);
          // 処理継続フラグが"定数.オフ(0)(処理継続不能)"の場合、処理を終了し、処理継続フラグを返却する
          if (ECISConstants.FLG_OFF.equals(execFlag)) {
            break;
          }
        }
      }
    }

    return execFlag;
  }

  /**
   * 契約情報登録処理を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 1 処理継続フラグに初期値(ON)を設定する。
   * 2 登録オブジェクトリストの件数分、契約情報Businessの登録メソッドを呼び出す。
   *   登録メソッドの戻り値のリターンコードが0000以外の場合、
   *   エラー情報を引数.エラーリストオブジェクトに設定する。
   *   登録メソッドの戻り値のリターンコードがD023またはG017の場合、
   *   繰り返し処理を中断し、処理継続フラグにOFFに設定する。
   * 3 処理継続フラグを返却する。
   * </pre>
   *
   * @param registDataList
   *          契約情報登録オブジェクトリスト
   * @param uploadFileName
   *          アップロードファイル名
   * @param errorList
   *          エラーリスト
   * @return 処理継続フラグ
   */
  private String uploadRegistContract(List<Map<Integer, String>> registDataList, String uploadFileName,
      List<String> errorList) {

    // リターンコードを定義する。
    String returnCode;
    // 処理継続フラグ（初期値）を設定する
    String execFlag = ECISConstants.FLG_ON;

    // 登録処理
    // 登録オブジェクトリストの件数分実施する
    for (Map<Integer, String> registData : registDataList) {
      // 登録情報設定
      RegistAgentContractBusinessBean registBean = new RegistAgentContractBusinessBean();

      String contractNo = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_NO_INDEX);
      String contractorNo = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACTOR_NO_INDEX);
      String paymentNo = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_PAYMENT_NO_INDEX);
      Integer meterLocationId = Integer
          .valueOf(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_METER_LOCATION_ID_INDEX));
      Date contractStartDate = StringConvertUtil
          .stringToDate(
              registData
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_START_DATE_INDEX),
              ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH);
      Date contractEndDate = StringConvertUtil
          .stringToDate(
              registData
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_END_DATE_INDEX),
              ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH);
      String contractEndReasonCode = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_END_REASON_CODE_INDEX);

      // 託送契約容量は必須でないので値がある場合のみ変換する
      String consContractCapStr = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_CONTRACT_CAPACITY_INDEX);
      BigDecimal consignmentContractCapacity = StringUtils
          .isEmpty(consContractCapStr) ? null
              : new BigDecimal(
                  consContractCapStr);

      String consignmentcontractCapacityUnitCode = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_CONTRACT_CAPACITY_UNIT_INDEX);
      Date consignmentContractCapacityDecisionDate = StringConvertUtil
          .stringToDate(
              registData
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_CONTRACT_CAPACITY_DECISION_DATE_INDEX),
              ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH);
      String chargeCheckFlag = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CHARGE_CHECK_FLAG_INDEX);
      String contractGroupNo = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_GROUP_NO_INDEX);
      String contactInformationinDividualLegalEntityCategoryCode = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_INDIVIDUAL_LEGAL_ENTITY_CATEGORY_CODE_INDEX);
      String contractInformationNameKana = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_NAME_KANA_INDEX);
      String contractInformationName1 = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_NAME1_INDEX);
      String contractInformationName2 = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_NAME2_INDEX);
      String contractInformationAddressPostalCode = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_ADDRESS_POSTAL_CODE_INDEX);
      String contractInformationAddressFull = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_ADDRESS_FULL_INDEX);
      String contractInformationAddressBuilding = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_ADDRESS_BUILDING_INDEX);
      String contractInformationCategoryCode = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_CATEGORY_CODE_INDEX);
      String contractInformationAreaCode = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_AREA_CODE_INDEX);
      String contractInformationLocalNo = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_LOCAL_NO_INDEX);
      String contractInformationDirectoryNo = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_DIRECTORY_NO_INDEX);
      String consumerContractAffiliation = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_AFFILIATION_INDEX);
      String consumerContractName = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_NAME_INDEX);
      String consumerContractAreaCode = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_AREA_CODE_INDEX);
      String consumerContractLocalNo = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_LOCAL_NO_INDEX);
      String consumerContractDirectoryNo = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_DIRECTORY_NO_INDEX);
      String chiefEngineerOfficerAffiliation = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_AFFILIATION_INDEX);
      String chiefEngineerOfficerName = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_NAME_INDEX);
      String chiefEngineerOfficerAreaCode = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_AREA_CODE_INDEX);
      String chiefEngineerOfficerLocalNo = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_LOCAL_NO_INDEX);
      String chiefEngineerOfficerDirectoryNo = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_DIRECTORY_NO_INDEX);
      String connectedSupplyServiceCategoryCode = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONNECTED_SUPPLY_SERVICE_CATEGORY_CODE_INDEX);
      String psInfoCatCode = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_PS_INFO_CODE_INDEX);
      String free1 = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_FREE1_INDEX);
      String free2 = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_FREE2_INDEX);
      String free3 = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_FREE3_INDEX);
      String free4 = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_FREE4_INDEX);
      String free5 = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_FREE5_INDEX);
      String free6 = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_FREE6_INDEX);
      String free7 = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_FREE7_INDEX);
      String free8 = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_FREE8_INDEX);
      String free9 = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_FREE9_INDEX);
      String free10 = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_FREE10_INDEX);
      String free11 = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_FREE11_INDEX);
      String free12 = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_FREE12_INDEX);
      String free13 = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_FREE13_INDEX);
      String free14 = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_FREE14_INDEX);
      String consignmentUseItem1 = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_USE_ITEM1_INDEX);
      String consignmentUseItem2 = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_USE_ITEM2_INDEX);
      String consignmentUseItem3 = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_USE_ITEM3_INDEX);
      String ourManagementPersonInChargeCode = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_OUR_MANAGEMENT_PERSON_IN_CHARGE_CODE_INDEX);
      String ourManagementDepartmentCode = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_OUR_MANAGEMENT_DEPARTMENT_CODE_INDEX);
      String businessTypeCode = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_BUSINESS_TYPE_CODE_INDEX);
      String salesConsignmentCode = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_SALES_CONSIGNMENT_CODE_INDEX);
      String contractNote = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_NOTE_INDEX);
      // 実量歴必須フラグ
      String realQuantityNeedflag = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_REAL_QUANTITY_NEED_FLAG_INDEX);
      // 料金メニューID
      String chargeMenuId = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_RATE_MENU_ID_INDEX);
      // 料金メニュー単価
      RmUp rmUp = new RmUp();
      rmUp.setMmc(StringConvertUtil.stringToBigDecimal(registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_MMC_INDEX)));
      // 単価設定区分コード
      String upCatcode = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_UP_CAT_CODE_INDEX);

      // 料金メニュー単価明細リスト
      List<RmUpDetail> rmUpDetailList = new ArrayList<RmUpDetail>();

      // 個別単価の場合
      if (ECISConstants.UNIT_PRICE_SETTING_CATEGORY_INDIV.equals(upCatcode)) {

        if (StringUtils.isNotEmpty(registData
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE1_INDEX))
            && StringUtils.isNotEmpty(registData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE1_INDEX))
            && StringUtils.isNotEmpty(registData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO1_INDEX))) {
          RmUpDetail rmupDetail1 = new RmUpDetail();
          // 料金メニューID
          rmupDetail1.setRmId(chargeMenuId);
          // DCEC区分コード
          rmupDetail1.setDcecCatCode(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE1_INDEX));
          //時間帯コード
          rmupDetail1.setTsCode(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE1_INDEX));
          //枝番
          rmupDetail1.setBranchNo(StringConvertUtil.stringToInteger(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO1_INDEX))
              .shortValue());
          //単価明細金額
          rmupDetail1.setUp(StringConvertUtil.stringToBigDecimal(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_UP1_INDEX)));

          // 料金メニュー単価明細の項目内容を補足する。
          this.fillRmUpDetail(rmupDetail1, contractStartDate);

          rmUpDetailList.add(rmupDetail1);
        }

        if (StringUtils.isNotEmpty(registData
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE2_INDEX))
            && StringUtils.isNotEmpty(registData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE2_INDEX))
            && StringUtils.isNotEmpty(registData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO2_INDEX))) {
          RmUpDetail rmupDetail2 = new RmUpDetail();
          // 料金メニューID
          rmupDetail2.setRmId(chargeMenuId);
          // DCEC区分コード
          rmupDetail2.setDcecCatCode(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE2_INDEX));
          //時間帯コード
          rmupDetail2.setTsCode(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE2_INDEX));
          //枝番
          rmupDetail2.setBranchNo(StringConvertUtil.stringToInteger(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO2_INDEX))
              .shortValue());
          //単価明細金額
          rmupDetail2.setUp(StringConvertUtil.stringToBigDecimal(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_UP2_INDEX)));

          // 料金メニュー単価明細の項目内容を補足する。
          this.fillRmUpDetail(rmupDetail2, contractStartDate);

          rmUpDetailList.add(rmupDetail2);
        }

        if (StringUtils.isNotEmpty(registData
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE3_INDEX))
            && StringUtils.isNotEmpty(registData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE3_INDEX))
            && StringUtils.isNotEmpty(registData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO3_INDEX))) {
          RmUpDetail rmupDetail3 = new RmUpDetail();
          // 料金メニューID
          rmupDetail3.setRmId(chargeMenuId);
          // DCEC区分コード
          rmupDetail3.setDcecCatCode(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE3_INDEX));
          //時間帯コード
          rmupDetail3.setTsCode(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE3_INDEX));
          //枝番
          rmupDetail3.setBranchNo(StringConvertUtil.stringToInteger(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO3_INDEX))
              .shortValue());
          //単価明細金額
          rmupDetail3.setUp(StringConvertUtil.stringToBigDecimal(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_UP3_INDEX)));
          // 料金メニュー単価明細の項目内容を補足する。
          this.fillRmUpDetail(rmupDetail3, contractStartDate);
          rmUpDetailList.add(rmupDetail3);
        }

        if (StringUtils.isNotEmpty(registData
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE4_INDEX))
            && StringUtils.isNotEmpty(registData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE4_INDEX))
            && StringUtils.isNotEmpty(registData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO4_INDEX))) {
          RmUpDetail rmupDetail4 = new RmUpDetail();
          // 料金メニューID
          rmupDetail4.setRmId(chargeMenuId);
          // DCEC区分コード
          rmupDetail4.setDcecCatCode(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE4_INDEX));
          //時間帯コード
          rmupDetail4.setTsCode(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE4_INDEX));
          //枝番
          rmupDetail4.setBranchNo(StringConvertUtil.stringToInteger(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO4_INDEX))
              .shortValue());
          //単価明細金額
          rmupDetail4.setUp(StringConvertUtil.stringToBigDecimal(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_UP4_INDEX)));
          // 料金メニュー単価明細の項目内容を補足する。
          this.fillRmUpDetail(rmupDetail4, contractStartDate);
          rmUpDetailList.add(rmupDetail4);
        }

        if (StringUtils.isNotEmpty(registData
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE5_INDEX))
            && StringUtils.isNotEmpty(registData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE5_INDEX))
            && StringUtils.isNotEmpty(registData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO5_INDEX))) {
          RmUpDetail rmupDetail5 = new RmUpDetail();
          // 料金メニューID
          rmupDetail5.setRmId(chargeMenuId);
          // DCEC区分コード
          rmupDetail5.setDcecCatCode(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE5_INDEX));
          //時間帯コード
          rmupDetail5.setTsCode(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE5_INDEX));
          //枝番
          rmupDetail5.setBranchNo(StringConvertUtil.stringToInteger(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO5_INDEX))
              .shortValue());
          //単価明細金額
          rmupDetail5.setUp(StringConvertUtil.stringToBigDecimal(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_UP5_INDEX)));
          // 料金メニュー単価明細の項目内容を補足する。
          this.fillRmUpDetail(rmupDetail5, contractStartDate);
          rmUpDetailList.add(rmupDetail5);
        }

        if (StringUtils.isNotEmpty(registData
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE6_INDEX))
            && StringUtils.isNotEmpty(registData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE6_INDEX))
            && StringUtils.isNotEmpty(registData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO6_INDEX))) {
          RmUpDetail rmupDetail6 = new RmUpDetail();
          // 料金メニューID
          rmupDetail6.setRmId(chargeMenuId);
          // DCEC区分コード
          rmupDetail6.setDcecCatCode(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE6_INDEX));
          //時間帯コード
          rmupDetail6.setTsCode(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE6_INDEX));
          //枝番
          rmupDetail6.setBranchNo(StringConvertUtil.stringToInteger(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO6_INDEX))
              .shortValue());
          //単価明細金額
          rmupDetail6.setUp(StringConvertUtil.stringToBigDecimal(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_UP6_INDEX)));
          // 料金メニュー単価明細の項目内容を補足する。
          this.fillRmUpDetail(rmupDetail6, contractStartDate);
          rmUpDetailList.add(rmupDetail6);
        }

        if (StringUtils.isNotEmpty(registData
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE7_INDEX))
            && StringUtils.isNotEmpty(registData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE7_INDEX))
            && StringUtils.isNotEmpty(registData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO7_INDEX))) {
          RmUpDetail rmupDetail7 = new RmUpDetail();
          // 料金メニューID
          rmupDetail7.setRmId(chargeMenuId);
          // DCEC区分コード
          rmupDetail7.setDcecCatCode(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE7_INDEX));
          //時間帯コード
          rmupDetail7.setTsCode(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE7_INDEX));
          //枝番
          rmupDetail7.setBranchNo(StringConvertUtil.stringToInteger(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO7_INDEX))
              .shortValue());
          //単価明細金額
          rmupDetail7.setUp(StringConvertUtil.stringToBigDecimal(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_UP7_INDEX)));
          // 料金メニュー単価明細の項目内容を補足する。
          this.fillRmUpDetail(rmupDetail7, contractStartDate);
          rmUpDetailList.add(rmupDetail7);
        }

        if (StringUtils.isNotEmpty(registData
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE8_INDEX))
            && StringUtils.isNotEmpty(registData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE8_INDEX))
            && StringUtils.isNotEmpty(registData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO8_INDEX))) {
          RmUpDetail rmupDetail8 = new RmUpDetail();
          // 料金メニューID
          rmupDetail8.setRmId(chargeMenuId);
          // DCEC区分コード
          rmupDetail8.setDcecCatCode(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE8_INDEX));
          //時間帯コード
          rmupDetail8.setTsCode(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE8_INDEX));
          //枝番
          rmupDetail8.setBranchNo(StringConvertUtil.stringToInteger(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO8_INDEX))
              .shortValue());
          //単価明細金額
          rmupDetail8.setUp(StringConvertUtil.stringToBigDecimal(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_UP8_INDEX)));
          // 料金メニュー単価明細の項目内容を補足する。
          this.fillRmUpDetail(rmupDetail8, contractStartDate);
          rmUpDetailList.add(rmupDetail8);
        }

        if (StringUtils.isNotEmpty(registData
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE9_INDEX))
            && StringUtils.isNotEmpty(registData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE9_INDEX))
            && StringUtils.isNotEmpty(registData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO9_INDEX))) {
          RmUpDetail rmupDetail9 = new RmUpDetail();
          // 料金メニューID
          rmupDetail9.setRmId(chargeMenuId);
          // DCEC区分コード
          rmupDetail9.setDcecCatCode(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE9_INDEX));
          //時間帯コード
          rmupDetail9.setTsCode(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE9_INDEX));
          //枝番
          rmupDetail9.setBranchNo(StringConvertUtil.stringToInteger(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO9_INDEX))
              .shortValue());
          //単価明細金額
          rmupDetail9.setUp(StringConvertUtil.stringToBigDecimal(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_UP9_INDEX)));
          // 料金メニュー単価明細の項目内容を補足する。
          this.fillRmUpDetail(rmupDetail9, contractStartDate);
          rmUpDetailList.add(rmupDetail9);
        }

        if (StringUtils.isNotEmpty(registData
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE10_INDEX))
            && StringUtils.isNotEmpty(registData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE10_INDEX))
            && StringUtils.isNotEmpty(registData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO10_INDEX))) {
          RmUpDetail rmupDetail10 = new RmUpDetail();
          // 料金メニューID
          rmupDetail10.setRmId(chargeMenuId);
          // DCEC区分コード
          rmupDetail10.setDcecCatCode(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE10_INDEX));
          //時間帯コード
          rmupDetail10.setTsCode(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE10_INDEX));
          //枝番
          rmupDetail10.setBranchNo(StringConvertUtil.stringToInteger(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO10_INDEX))
              .shortValue());
          //単価明細金額
          rmupDetail10.setUp(StringConvertUtil.stringToBigDecimal(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_UP10_INDEX)));
          // 料金メニュー単価明細の項目内容を補足する。
          this.fillRmUpDetail(rmupDetail10, contractStartDate);
          rmUpDetailList.add(rmupDetail10);
        }

        if (StringUtils.isNotEmpty(registData
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE11_INDEX))
            && StringUtils.isNotEmpty(registData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE11_INDEX))
            && StringUtils.isNotEmpty(registData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO11_INDEX))) {
          RmUpDetail rmupDetail11 = new RmUpDetail();
          // 料金メニューID
          rmupDetail11.setRmId(chargeMenuId);
          // DCEC区分コード
          rmupDetail11.setDcecCatCode(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE11_INDEX));
          //時間帯コード
          rmupDetail11.setTsCode(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE11_INDEX));
          //枝番
          rmupDetail11.setBranchNo(StringConvertUtil.stringToInteger(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO11_INDEX))
              .shortValue());
          //単価明細金額
          rmupDetail11.setUp(StringConvertUtil.stringToBigDecimal(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_UP11_INDEX)));
          // 料金メニュー単価明細の項目内容を補足する。
          this.fillRmUpDetail(rmupDetail11, contractStartDate);
          rmUpDetailList.add(rmupDetail11);
        }

        if (StringUtils.isNotEmpty(registData
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE12_INDEX))
            && StringUtils.isNotEmpty(registData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE12_INDEX))
            && StringUtils.isNotEmpty(registData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO12_INDEX))) {
          RmUpDetail rmupDetail12 = new RmUpDetail();
          // 料金メニューID
          rmupDetail12.setRmId(chargeMenuId);
          // DCEC区分コード
          rmupDetail12.setDcecCatCode(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE12_INDEX));
          //時間帯コード
          rmupDetail12.setTsCode(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE12_INDEX));
          //枝番
          rmupDetail12.setBranchNo(StringConvertUtil.stringToInteger(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO12_INDEX))
              .shortValue());
          //単価明細金額
          rmupDetail12.setUp(StringConvertUtil.stringToBigDecimal(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_UP12_INDEX)));
          // 料金メニュー単価明細の項目内容を補足する。
          this.fillRmUpDetail(rmupDetail12, contractStartDate);
          rmUpDetailList.add(rmupDetail12);
        }

        if (StringUtils.isNotEmpty(registData
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE13_INDEX))
            && StringUtils.isNotEmpty(registData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE13_INDEX))
            && StringUtils.isNotEmpty(registData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO13_INDEX))) {
          RmUpDetail rmupDetail13 = new RmUpDetail();
          // 料金メニューID
          rmupDetail13.setRmId(chargeMenuId);
          // DCEC区分コード
          rmupDetail13.setDcecCatCode(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE13_INDEX));
          //時間帯コード
          rmupDetail13.setTsCode(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE13_INDEX));
          //枝番
          rmupDetail13.setBranchNo(StringConvertUtil.stringToInteger(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO13_INDEX))
              .shortValue());
          //単価明細金額
          rmupDetail13.setUp(StringConvertUtil.stringToBigDecimal(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_UP13_INDEX)));
          // 料金メニュー単価明細の項目内容を補足する。
          this.fillRmUpDetail(rmupDetail13, contractStartDate);
          rmUpDetailList.add(rmupDetail13);
        }

        if (StringUtils.isNotEmpty(registData
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE14_INDEX))
            && StringUtils.isNotEmpty(registData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE14_INDEX))
            && StringUtils.isNotEmpty(registData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO14_INDEX))) {
          RmUpDetail rmupDetail14 = new RmUpDetail();
          // 料金メニューID
          rmupDetail14.setRmId(chargeMenuId);
          // DCEC区分コード
          rmupDetail14.setDcecCatCode(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE14_INDEX));
          //時間帯コード
          rmupDetail14.setTsCode(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE14_INDEX));
          //枝番
          rmupDetail14.setBranchNo(StringConvertUtil.stringToInteger(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO14_INDEX))
              .shortValue());
          //単価明細金額
          rmupDetail14.setUp(StringConvertUtil.stringToBigDecimal(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_UP14_INDEX)));
          // 料金メニュー単価明細の項目内容を補足する。
          this.fillRmUpDetail(rmupDetail14, contractStartDate);
          rmUpDetailList.add(rmupDetail14);
        }

        if (StringUtils.isNotEmpty(registData
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE15_INDEX))
            && StringUtils.isNotEmpty(registData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE15_INDEX))
            && StringUtils.isNotEmpty(registData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO15_INDEX))) {
          RmUpDetail rmupDetail15 = new RmUpDetail();
          // 料金メニューID
          rmupDetail15.setRmId(chargeMenuId);
          // DCEC区分コード
          rmupDetail15.setDcecCatCode(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE15_INDEX));
          //時間帯コード
          rmupDetail15.setTsCode(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE15_INDEX));
          //枝番
          rmupDetail15.setBranchNo(StringConvertUtil.stringToInteger(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO15_INDEX))
              .shortValue());
          //単価明細金額
          rmupDetail15.setUp(StringConvertUtil.stringToBigDecimal(registData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_UP15_INDEX)));
          // 料金メニュー単価明細の項目内容を補足する。
          this.fillRmUpDetail(rmupDetail15, contractStartDate);
          rmUpDetailList.add(rmupDetail15);
        }
      }

      // 契約容量は必須ではないので値があるときのみ変換する
      String contCap = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_CAPACITY_INDEX);
      BigDecimal contractCapacity = StringUtils.isEmpty(contCap) ? null
          : new BigDecimal(contCap);
      // 電圧区分コード
      String voltageCatCode = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_VOLTAGE_CAT_CODE_INDEX);
      // 契約電力決定区分コード
      String ccdecisionCategoryCode = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CCDECISION_CATEGORY_CODE_INDEX);
      // 卸取次店契約番号
      String agentContractNo = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_AGENT_CONTRACT_NO_INDEX);
      // 契約付加情報フリー項目1
      String contractFree1 = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_01_INDEX);
      // 契約付加情報フリー項目2
      String contractFree2 = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_02_INDEX);
      // 契約付加情報フリー項目3
      String contractFree3 = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_03_INDEX);
      // 契約付加情報フリー項目4
      String contractFree4 = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_04_INDEX);
      // 契約付加情報フリー項目5
      String contractFree5 = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_05_INDEX);
      // 契約付加情報フリー項目6
      String contractFree6 = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_06_INDEX);
      // 契約付加情報フリー項目7
      String contractFree7 = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_07_INDEX);
      // 契約付加情報フリー項目8
      String contractFree8 = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_08_INDEX);
      // 契約付加情報フリー項目9
      String contractFree9 = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_09_INDEX);
      // 契約付加情報フリー項目10
      String contractFree10 = registData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_10_INDEX);

      // 契約番号
      registBean.setContractNo(contractNo);
      // 契約者ID
      registBean.setContractorId(null);
      // 契約者番号
      registBean.setContractorNo(contractorNo);
      // 支払ID
      registBean.setPaymentId(null);
      // 支払番号
      registBean.setPaymentNo(paymentNo);
      // メータ設置場所ID
      registBean.setMeterLocationId(meterLocationId);
      // 契約開始日
      registBean.setContractStartDate(contractStartDate);
      // 契約終了日
      registBean.setContractEndDate(contractEndDate);
      // 契約終了理由コード
      registBean.setContractEndReasonCode(contractEndReasonCode);
      // 託送契約容量
      registBean.setConsignmentContractCapacity(consignmentContractCapacity);
      // 託送契約容量単位コード
      registBean
          .setConsignmentcontractCapacityUnitCode(consignmentcontractCapacityUnitCode);
      // 託送契約容量判定日
      registBean
          .setConsignmentContractCapacityDecisionDate(consignmentContractCapacityDecisionDate);
      // 料金チェックフラグ
      registBean.setChargeCheckFlag(chargeCheckFlag);
      // 契約グループ番号
      registBean.setContractGroupNo(contractGroupNo);
      // 連絡先個人・法人区分
      registBean
          .setContactInformationinDividualLegalEntityCategoryCode(
              contactInformationinDividualLegalEntityCategoryCode);
      // 連絡先氏名（カナ）
      registBean.setContractInformationNameKana(contractInformationNameKana);
      // 連絡先氏名1
      registBean.setContractInformationName1(contractInformationName1);
      // 連絡先氏名2
      registBean.setContractInformationName2(contractInformationName2);
      // 連絡先住所（郵便番号）
      registBean
          .setContractInformationAddressPostalCode(contractInformationAddressPostalCode);
      // 連絡先住所（住所）
      registBean
          .setContractInformationAddressFull(contractInformationAddressFull);
      // 連絡先住所（建物・部屋名）
      registBean
          .setContractInformationAddressBuilding(contractInformationAddressBuilding);
      // 連絡先電話区分コード
      registBean
          .setContractInformationCategoryCode(contractInformationCategoryCode);
      // 連絡先電話（市外局番）
      registBean.setContractInformationAreaCode(contractInformationAreaCode);
      // 連絡先電話（市内局番）
      registBean.setContractInformationLocalNo(contractInformationLocalNo);
      // 連絡先電話（加入者番号）
      registBean
          .setContractInformationDirectoryNo(contractInformationDirectoryNo);
      // 需要者窓口連絡先所属
      registBean.setConsumerContractAffiliation(consumerContractAffiliation);
      // 需要者窓口連絡先氏名
      registBean.setConsumerContractName(consumerContractName);
      // 需要者窓口連絡先電話番号（市外局番）
      registBean.setConsumerContractAreaCode(consumerContractAreaCode);
      // 需要者窓口連絡先電話番号（市内局番）
      registBean.setConsumerContractLocalNo(consumerContractLocalNo);
      // 需要者窓口連絡先電話番号（加入者番号）
      registBean
          .setConsumerContractDirectoryNo(consumerContractDirectoryNo);
      // 主任技術者連絡先所属
      registBean.setChiefEngineerOfficerAffiliation(chiefEngineerOfficerAffiliation);
      // 主任技術者連絡先氏名
      registBean.setChiefEngineerOfficerName(chiefEngineerOfficerName);
      // 主任技術者連絡先電話番号（市外局番）
      registBean.setChiefEngineerOfficerAreaCode(chiefEngineerOfficerAreaCode);
      // 主任技術者連絡先電話番号（市内局番）
      registBean.setChiefEngineerOfficerLocalNo(chiefEngineerOfficerLocalNo);
      // 主任技術者連絡先電話番号（加入者番号）
      registBean
          .setChiefEngineerOfficerDirectoryNo(chiefEngineerOfficerDirectoryNo);
      // 接続送電サービス区分コード
      registBean
          .setConnectedSupplyServiceCategoryCode(connectedSupplyServiceCategoryCode);
      // 部分供給区分コード
      registBean.setPartialSupplyInformationCategoryCode(psInfoCatCode);
      // フリー項目1
      registBean.setFree1(free1);
      // フリー項目2
      registBean.setFree2(free2);
      // フリー項目3
      registBean.setFree3(free3);
      // フリー項目4
      registBean.setFree4(free4);
      // フリー項目5
      registBean.setFree5(free5);
      // フリー項目6
      registBean.setFree6(free6);
      // フリー項目7
      registBean.setFree7(free7);
      // フリー項目8
      registBean.setFree8(free8);
      // 設備ID
      registBean.setFree9(free9);
      // フリー項目10
      registBean.setFree10(free10);
      // フリー項目11
      registBean.setFree11(free11);
      // フリー項目12
      registBean.setFree12(free12);
      // フリー項目13
      registBean.setFree13(free13);
      // フリー項目14
      registBean.setFree14(free14);
      // 委託先使用項目1
      registBean.setConsignmentUseItem1(consignmentUseItem1);
      // 委託先使用項目2
      registBean.setConsignmentUseItem2(consignmentUseItem2);
      // 委託先使用項目3
      registBean.setConsignmentUseItem3(consignmentUseItem3);
      // 自社担当者コード
      registBean.setOurManagementPersonInChargeCode(ourManagementPersonInChargeCode);
      // 自社部署コード
      registBean.setOurManagementDepartmentCode(ourManagementDepartmentCode);
      // 業種コード
      registBean.setBusinessTypeCode(businessTypeCode);
      // 営業委託先コード
      registBean.setSalesConsignmentCode(salesConsignmentCode);
      // 契約備考
      registBean.setContractNote(contractNote);
      // 実量歴必須フラグ
      registBean.setRealQuantityNeed(realQuantityNeedflag);
      // 料金メニューID
      registBean.setChargeMenuId(chargeMenuId);
      // 契約容量
      registBean.setContractCapacity(contractCapacity);
      // 料金メニュー単価
      registBean.setRmUp(rmUp);
      // 料金メニュー単価明細リスト
      registBean.setRmUpDetailList(rmUpDetailList);
      // 電圧区分コード
      registBean.setVoltageCatCode(voltageCatCode);
      // 契約電力決定区分コード
      registBean.setCcDecisionCategoryCode(ccdecisionCategoryCode);
      // 単価設定区分コード
      registBean.setUpCatCode(upCatcode);
      // 卸取次店契約番号
      registBean.setAgentContractNo(agentContractNo);
      // 契約付加情報フリー項目1
      registBean.setContractFree1(contractFree1);
      // 契約付加情報フリー項目2
      registBean.setContractFree2(contractFree2);
      // 契約付加情報フリー項目3
      registBean.setContractFree3(contractFree3);
      // 契約付加情報フリー項目4
      registBean.setContractFree4(contractFree4);
      // 契約付加情報フリー項目5
      registBean.setContractFree5(contractFree5);
      // 契約付加情報フリー項目6
      registBean.setContractFree6(contractFree6);
      // 契約付加情報フリー項目7
      registBean.setContractFree7(contractFree7);
      // 契約付加情報フリー項目8
      registBean.setContractFree8(contractFree8);
      // 契約付加情報フリー項目9
      registBean.setContractFree9(contractFree9);
      // 契約付加情報フリー項目10
      registBean.setContractFree10(contractFree10);

      // 登録処理実行
      RegistAgentContractBusinessBean registResultBean = agentContractInformationBusiness.regist(registBean);

      // リターンコードを取得する。
      returnCode = registResultBean.getReturnCode();
      // リターンコードが0000（正常終了）以外の場合、エラーリストにメッセージを設定する
      if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(returnCode)) {
        errorList.add(StringConvertUtil.convertErrorListString(
            uploadFileName,
            StringConvertUtil.stringToInteger(registData
                .get(ContractManagementInformationFileConfigCommon.DATA_ROW_NO_INDEX)),
            messageSource.getMessage(
                KJ_CommonUtil.getDisplayMessageId(
                    ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD,
                    returnCode),
                null, Locale.getDefault())));

        // リターンコード判定メソッドを呼出し、処理継続フラグを取得する
        execFlag = checkReturnCode(returnCode);
        // 処理継続フラグが"定数.オフ(0)(処理継続不能)"の場合、処理を終了し、処理継続フラグを返却する
        if (ECISConstants.FLG_OFF.equals(execFlag)) {
          break;
        }
      } else {

        // カスタム契約情報追加
        Custom_AddCustomContractBusinessBean customRegistBean = new Custom_AddCustomContractBusinessBean();
        Integer contractId = registResultBean.getContractId();
        String salesDepartmentCd = registData
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_SALES_DEPARTMENT_CODE_INDEX);
        String contactCd = registData
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_SALES_CONTACT_CODE_INDEX);

        // 契約ID
        customRegistBean.setContractId(contractId);
        // 営業担当者・組織コード
        customRegistBean.setSalesDepartmentCd(salesDepartmentCd);
        // 問い合わせ先コード
        customRegistBean.setContactCd(contactCd);

        // 追加処理実行
        Custom_AddCustomContractBusinessBean customResultBean = customContractInformationBusiness
            .add(customRegistBean);

        // リターンコードを取得する。
        returnCode = customResultBean.getReturnCode();
        // リターンコードが0000（正常終了）以外の場合、エラーリストにメッセージを設定する
        if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(returnCode)) {
          errorList.add(StringConvertUtil.convertErrorListString(
              uploadFileName,
              StringConvertUtil.stringToInteger(registData
                  .get(ContractManagementInformationFileConfigCommon.DATA_ROW_NO_INDEX)),
              messageSource.getMessage(
                  KJ_CommonUtil.getDisplayMessageId(
                      ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD,
                      returnCode),
                  null, Locale.getDefault())));

          // リターンコード判定メソッドを呼出し、処理継続フラグを取得する
          execFlag = checkReturnCode(returnCode);
          // 処理継続フラグが"定数.オフ(0)(処理継続不能)"の場合、処理を終了し、処理継続フラグを返却する
          if (ECISConstants.FLG_OFF.equals(execFlag)) {
            break;
          }
        }

        // 予備契約情報の登録
        returnCode = uploadReserveContract(registData,
            registResultBean.getContractId());

        // リターンコードが0000（正常終了）以外の場合、エラーリストにメッセージを設定する
        if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(returnCode)) {
          errorList.add(StringConvertUtil.convertErrorListString(
              uploadFileName,
              StringConvertUtil.stringToInteger(registData
                  .get(ContractManagementInformationFileConfigCommon.DATA_ROW_NO_INDEX)),
              messageSource.getMessage(
                  KJ_CommonUtil.getDisplayMessageId(
                      ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD,
                      returnCode),
                  null, Locale.getDefault())));

          // リターンコード判定メソッドを呼出し、処理継続フラグを取得する
          execFlag = checkReturnCode(returnCode);
          // 処理継続フラグが"定数.オフ(0)(処理継続不能)"の場合、処理を終了し、処理継続フラグを返却する
          if (ECISConstants.FLG_OFF.equals(execFlag)) {
            break;
          }
        }
      }
    }

    // 処理継続フラグを返却する
    return execFlag;
  }

  /**
   * 契約情報更新処理を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 1 処理継続フラグに初期値(ON)を設定する。
   * 2 更新オブジェクトリストの件数分、契約情報Businessの更新メソッドを呼び出す。
   *   更新メソッドの戻り値のリターンコードが0000以外の場合、
   *   エラー情報を引数.エラーリストオブジェクトに設定する。
   *   更新メソッドの戻り値のリターンコードがD023またはG017の場合、
   *   繰り返し処理を中断し、処理継続フラグにOFFに設定する。
   * 3 処理継続フラグを返却する。
   * </pre>
   *
   * @param updateDataList
   *          契約情報更新オブジェクトリスト
   * @param uploadFileName
   *          アップロードファイル名
   * @param errorList
   *          エラーリスト
   * @return 処理継続フラグ
   */
  private String uploadUpdateContract(List<Map<Integer, String>> updateDataList, String uploadFileName,
      List<String> errorList) {

    // リターンコードを定義する。
    String returnCode;
    // 処理継続フラグ（初期値）を設定する
    String execFlag = ECISConstants.FLG_ON;

    // 更新処理
    // 更新オブジェクトリストの件数分実施する
    for (Map<Integer, String> updateData : updateDataList) {
      // 更新情報設定
      UpdateAgentContractBusinessBean updateBean = new UpdateAgentContractBusinessBean();

      String contractNo = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_NO_INDEX);
      String paymentNo = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_PAYMENT_NO_INDEX);
      Date contractEndDate = StringConvertUtil
          .stringToDate(
              updateData
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_END_DATE_INDEX),
              ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH);
      String contractEndReasonCode = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_END_REASON_CODE_INDEX);

      // 託送契約容量は必須でないので値がある場合のみ変換する
      String consContractCapStr = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_CONTRACT_CAPACITY_INDEX);
      BigDecimal consignmentContractCapacity = StringUtils
          .isEmpty(consContractCapStr) ? null
              : new BigDecimal(
                  consContractCapStr);

      String consignmentcontractCapacityUnitCode = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_CONTRACT_CAPACITY_UNIT_INDEX);
      Date consignmentContractCapacityDecisionDate = StringConvertUtil
          .stringToDate(
              updateData
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_CONTRACT_CAPACITY_DECISION_DATE_INDEX),
              ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH);
      String chargeCheckFlag = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CHARGE_CHECK_FLAG_INDEX);
      String contractGroupNo = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_GROUP_NO_INDEX);
      String contactInformationinDividualLegalEntityCategoryCode = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_INDIVIDUAL_LEGAL_ENTITY_CATEGORY_CODE_INDEX);
      String contractInformationNameKana = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_NAME_KANA_INDEX);
      String contractInformationName1 = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_NAME1_INDEX);
      String contractInformationName2 = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_NAME2_INDEX);
      String contractInformationAddressPostalCode = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_ADDRESS_POSTAL_CODE_INDEX);
      String contractInformationAddressFull = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_ADDRESS_FULL_INDEX);
      String contractInformationAddressBuilding = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_ADDRESS_BUILDING_INDEX);
      String contractInformationCategoryCode = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_CATEGORY_CODE_INDEX);
      String contractInformationAreaCode = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_AREA_CODE_INDEX);
      String contractInformationLocalNo = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_LOCAL_NO_INDEX);
      String contractInformationDirectoryNo = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_INFORMATION_DIRECTORY_NO_INDEX);
      String consumerContractAffiliation = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_AFFILIATION_INDEX);
      String consumerContractName = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_NAME_INDEX);
      String consumerContractAreaCode = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_AREA_CODE_INDEX);
      String consumerContractLocalNo = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_LOCAL_NO_INDEX);
      String consumerContractDirectoryNo = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONSUMER_CONTRACT_DIRECTORY_NO_INDEX);
      String chiefEngineerOfficerAffiliation = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_AFFILIATION_INDEX);
      String chiefEngineerOfficerName = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_NAME_INDEX);
      String chiefEngineerOfficerAreaCode = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_AREA_CODE_INDEX);
      String chiefEngineerOfficerLocalNo = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_LOCAL_NO_INDEX);
      String chiefEngineerOfficerDirectoryNo = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CHIEF_ENGINEER_OFFICER_DIRECTORY_NO_INDEX);
      String connectedSupplyServiceCategoryCode = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONNECTED_SUPPLY_SERVICE_CATEGORY_CODE_INDEX);
      String psInfoCatCode = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_PS_INFO_CODE_INDEX);
      String free1 = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_FREE1_INDEX);
      String free2 = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_FREE2_INDEX);
      String free3 = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_FREE3_INDEX);
      String free4 = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_FREE4_INDEX);
      String free5 = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_FREE5_INDEX);
      String free6 = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_FREE6_INDEX);
      String free7 = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_FREE7_INDEX);
      String free8 = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_FREE8_INDEX);
      String free9 = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_FREE9_INDEX);
      String free10 = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_FREE10_INDEX);
      String free11 = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_FREE11_INDEX);
      String free12 = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_FREE12_INDEX);
      String free13 = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_FREE13_INDEX);
      String free14 = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_FREE14_INDEX);
      String consignmentUseItem1 = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_USE_ITEM1_INDEX);
      String consignmentUseItem2 = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_USE_ITEM2_INDEX);
      String consignmentUseItem3 = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONSIGNMENT_USE_ITEM3_INDEX);
      String ourManagementPersonInChargeCode = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_OUR_MANAGEMENT_PERSON_IN_CHARGE_CODE_INDEX);
      String ourManagementDepartmentCode = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_OUR_MANAGEMENT_DEPARTMENT_CODE_INDEX);
      String businessTypeCode = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_BUSINESS_TYPE_CODE_INDEX);
      String salesConsignmentCode = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_SALES_CONSIGNMENT_CODE_INDEX);
      String contractNote = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_NOTE_INDEX);
      Date applyStartDate = StringConvertUtil
          .stringToDate(
              updateData
                  .get(Custom_ContractManagementInformationFileConfigContract.DATA_APPLY_START_DATE_INDEX),
              ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH);
      // 実量歴必須フラグ
      String realQuantityNeedflag = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_REAL_QUANTITY_NEED_FLAG_INDEX);
      // 料金メニューID
      String chargeMenuId = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_RATE_MENU_ID_INDEX);

      // 料金メニュー単価
      RmUp rmUp = new RmUp();
      rmUp.setMmc(StringConvertUtil.stringToBigDecimal(updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_MMC_INDEX)));

      // 単価設定区分コード
      String upCatcode = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_UP_CAT_CODE_INDEX);

      // 料金メニュー単価明細リスト
      List<RmUpDetail> rmUpDetailList = new ArrayList<RmUpDetail>();

      // 個別単価の場合
      if (ECISConstants.UNIT_PRICE_SETTING_CATEGORY_INDIV.equals(upCatcode)) {

        if (StringUtils.isNotEmpty(updateData
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE1_INDEX))
            && StringUtils.isNotEmpty(updateData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE1_INDEX))
            && StringUtils.isNotEmpty(updateData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO1_INDEX))) {

          RmUpDetail rmupDetail1 = new RmUpDetail();
          // 料金メニューID
          rmupDetail1.setRmId(chargeMenuId);
          // DCEC区分コード
          rmupDetail1.setDcecCatCode(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE1_INDEX));
          //時間帯コード
          rmupDetail1.setTsCode(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE1_INDEX));
          //枝番
          rmupDetail1.setBranchNo(StringConvertUtil.stringToInteger(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO1_INDEX))
              .shortValue());
          //単価明細金額
          rmupDetail1.setUp(StringConvertUtil.stringToBigDecimal(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_UP1_INDEX)));
          // 料金メニュー単価明細の項目内容を補足する。
          this.fillRmUpDetail(rmupDetail1, applyStartDate);
          rmUpDetailList.add(rmupDetail1);
        }

        if (StringUtils.isNotEmpty(updateData
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE2_INDEX))
            && StringUtils.isNotEmpty(updateData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE2_INDEX))
            && StringUtils.isNotEmpty(updateData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO2_INDEX))) {

          RmUpDetail rmupDetail2 = new RmUpDetail();
          // 料金メニューID
          rmupDetail2.setRmId(chargeMenuId);
          // DCEC区分コード
          rmupDetail2.setDcecCatCode(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE2_INDEX));
          //時間帯コード
          rmupDetail2.setTsCode(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE2_INDEX));
          //枝番
          rmupDetail2.setBranchNo(StringConvertUtil.stringToInteger(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO2_INDEX))
              .shortValue());
          //単価明細金額
          rmupDetail2.setUp(StringConvertUtil.stringToBigDecimal(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_UP2_INDEX)));
          // 料金メニュー単価明細の項目内容を補足する。
          this.fillRmUpDetail(rmupDetail2, applyStartDate);
          rmUpDetailList.add(rmupDetail2);
        }

        if (StringUtils.isNotEmpty(updateData
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE3_INDEX))
            && StringUtils.isNotEmpty(updateData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE3_INDEX))
            && StringUtils.isNotEmpty(updateData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO3_INDEX))) {

          RmUpDetail rmupDetail3 = new RmUpDetail();
          // 料金メニューID
          rmupDetail3.setRmId(chargeMenuId);
          // DCEC区分コード
          rmupDetail3.setDcecCatCode(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE3_INDEX));
          //時間帯コード
          rmupDetail3.setTsCode(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE3_INDEX));
          //枝番
          rmupDetail3.setBranchNo(StringConvertUtil.stringToInteger(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO3_INDEX))
              .shortValue());
          //単価明細金額
          rmupDetail3.setUp(StringConvertUtil.stringToBigDecimal(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_UP3_INDEX)));
          // 料金メニュー単価明細の項目内容を補足する。
          this.fillRmUpDetail(rmupDetail3, applyStartDate);
          rmUpDetailList.add(rmupDetail3);
        }

        if (StringUtils.isNotEmpty(updateData
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE4_INDEX))
            && StringUtils.isNotEmpty(updateData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE4_INDEX))
            && StringUtils.isNotEmpty(updateData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO4_INDEX))) {
          RmUpDetail rmupDetail4 = new RmUpDetail();
          // 料金メニューID
          rmupDetail4.setRmId(chargeMenuId);
          // DCEC区分コード
          rmupDetail4.setDcecCatCode(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE4_INDEX));
          //時間帯コード
          rmupDetail4.setTsCode(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE4_INDEX));
          //枝番
          rmupDetail4.setBranchNo(StringConvertUtil.stringToInteger(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO4_INDEX))
              .shortValue());
          //単価明細金額
          rmupDetail4.setUp(StringConvertUtil.stringToBigDecimal(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_UP4_INDEX)));
          // 料金メニュー単価明細の項目内容を補足する。
          this.fillRmUpDetail(rmupDetail4, applyStartDate);
          rmUpDetailList.add(rmupDetail4);
        }

        if (StringUtils.isNotEmpty(updateData
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE5_INDEX))
            && StringUtils.isNotEmpty(updateData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE5_INDEX))
            && StringUtils.isNotEmpty(updateData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO5_INDEX))) {
          RmUpDetail rmupDetail5 = new RmUpDetail();
          // 料金メニューID
          rmupDetail5.setRmId(chargeMenuId);
          // DCEC区分コード
          rmupDetail5.setDcecCatCode(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE5_INDEX));
          //時間帯コード
          rmupDetail5.setTsCode(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE5_INDEX));
          //枝番
          rmupDetail5.setBranchNo(StringConvertUtil.stringToInteger(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO5_INDEX))
              .shortValue());
          //単価明細金額
          rmupDetail5.setUp(StringConvertUtil.stringToBigDecimal(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_UP5_INDEX)));
          // 料金メニュー単価明細の項目内容を補足する。
          this.fillRmUpDetail(rmupDetail5, applyStartDate);
          rmUpDetailList.add(rmupDetail5);
        }

        if (StringUtils.isNotEmpty(updateData
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE6_INDEX))
            && StringUtils.isNotEmpty(updateData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE6_INDEX))
            && StringUtils.isNotEmpty(updateData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO6_INDEX))) {

          RmUpDetail rmupDetail6 = new RmUpDetail();
          // 料金メニューID
          rmupDetail6.setRmId(chargeMenuId);
          // DCEC区分コード
          rmupDetail6.setDcecCatCode(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE6_INDEX));
          //時間帯コード
          rmupDetail6.setTsCode(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE6_INDEX));
          //枝番
          rmupDetail6.setBranchNo(StringConvertUtil.stringToInteger(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO6_INDEX))
              .shortValue());
          //単価明細金額
          rmupDetail6.setUp(StringConvertUtil.stringToBigDecimal(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_UP6_INDEX)));
          // 料金メニュー単価明細の項目内容を補足する。
          this.fillRmUpDetail(rmupDetail6, applyStartDate);
          rmUpDetailList.add(rmupDetail6);
        }

        if (StringUtils.isNotEmpty(updateData
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE7_INDEX))
            && StringUtils.isNotEmpty(updateData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE7_INDEX))
            && StringUtils.isNotEmpty(updateData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO7_INDEX))) {

          RmUpDetail rmupDetail7 = new RmUpDetail();
          // 料金メニューID
          rmupDetail7.setRmId(chargeMenuId);
          // DCEC区分コード
          rmupDetail7.setDcecCatCode(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE7_INDEX));
          //時間帯コード
          rmupDetail7.setTsCode(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE7_INDEX));
          //枝番
          rmupDetail7.setBranchNo(StringConvertUtil.stringToInteger(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO7_INDEX))
              .shortValue());
          //単価明細金額
          rmupDetail7.setUp(StringConvertUtil.stringToBigDecimal(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_UP7_INDEX)));
          // 料金メニュー単価明細の項目内容を補足する。
          this.fillRmUpDetail(rmupDetail7, applyStartDate);
          rmUpDetailList.add(rmupDetail7);
        }

        if (StringUtils.isNotEmpty(updateData
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE8_INDEX))
            && StringUtils.isNotEmpty(updateData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE8_INDEX))
            && StringUtils.isNotEmpty(updateData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO8_INDEX))) {

          RmUpDetail rmupDetail8 = new RmUpDetail();
          // 料金メニューID
          rmupDetail8.setRmId(chargeMenuId);
          // DCEC区分コード
          rmupDetail8.setDcecCatCode(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE8_INDEX));
          //時間帯コード
          rmupDetail8.setTsCode(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE8_INDEX));
          //枝番
          rmupDetail8.setBranchNo(StringConvertUtil.stringToInteger(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO8_INDEX))
              .shortValue());
          //単価明細金額
          rmupDetail8.setUp(StringConvertUtil.stringToBigDecimal(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_UP8_INDEX)));
          // 料金メニュー単価明細の項目内容を補足する。
          this.fillRmUpDetail(rmupDetail8, applyStartDate);
          rmUpDetailList.add(rmupDetail8);
        }

        if (StringUtils.isNotEmpty(updateData
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE9_INDEX))
            && StringUtils.isNotEmpty(updateData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE9_INDEX))
            && StringUtils.isNotEmpty(updateData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO9_INDEX))) {

          RmUpDetail rmupDetail9 = new RmUpDetail();
          // 料金メニューID
          rmupDetail9.setRmId(chargeMenuId);
          // DCEC区分コード
          rmupDetail9.setDcecCatCode(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE9_INDEX));
          //時間帯コード
          rmupDetail9.setTsCode(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE9_INDEX));
          //枝番
          rmupDetail9.setBranchNo(StringConvertUtil.stringToInteger(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO9_INDEX))
              .shortValue());
          //単価明細金額
          rmupDetail9.setUp(StringConvertUtil.stringToBigDecimal(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_UP9_INDEX)));
          // 料金メニュー単価明細の項目内容を補足する。
          this.fillRmUpDetail(rmupDetail9, applyStartDate);
          rmUpDetailList.add(rmupDetail9);
        }

        if (StringUtils.isNotEmpty(updateData
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE10_INDEX))
            && StringUtils.isNotEmpty(updateData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE10_INDEX))
            && StringUtils.isNotEmpty(updateData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO10_INDEX))) {

          RmUpDetail rmupDetail10 = new RmUpDetail();
          // 料金メニューID
          rmupDetail10.setRmId(chargeMenuId);
          // DCEC区分コード
          rmupDetail10.setDcecCatCode(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE10_INDEX));
          //時間帯コード
          rmupDetail10.setTsCode(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE10_INDEX));
          //枝番
          rmupDetail10.setBranchNo(StringConvertUtil.stringToInteger(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO10_INDEX))
              .shortValue());
          //単価明細金額
          rmupDetail10.setUp(StringConvertUtil.stringToBigDecimal(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_UP10_INDEX)));
          // 料金メニュー単価明細の項目内容を補足する。
          this.fillRmUpDetail(rmupDetail10, applyStartDate);
          rmUpDetailList.add(rmupDetail10);
        }

        if (StringUtils.isNotEmpty(updateData
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE11_INDEX))
            && StringUtils.isNotEmpty(updateData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE11_INDEX))
            && StringUtils.isNotEmpty(updateData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO11_INDEX))) {

          RmUpDetail rmupDetail11 = new RmUpDetail();
          // 料金メニューID
          rmupDetail11.setRmId(chargeMenuId);
          // DCEC区分コード
          rmupDetail11.setDcecCatCode(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE11_INDEX));
          //時間帯コード
          rmupDetail11.setTsCode(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE11_INDEX));
          //枝番
          rmupDetail11.setBranchNo(StringConvertUtil.stringToInteger(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO11_INDEX))
              .shortValue());
          //単価明細金額
          rmupDetail11.setUp(StringConvertUtil.stringToBigDecimal(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_UP11_INDEX)));
          // 料金メニュー単価明細の項目内容を補足する。
          this.fillRmUpDetail(rmupDetail11, applyStartDate);
          rmUpDetailList.add(rmupDetail11);
        }

        if (StringUtils.isNotEmpty(updateData
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE12_INDEX))
            && StringUtils.isNotEmpty(updateData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE12_INDEX))
            && StringUtils.isNotEmpty(updateData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO12_INDEX))) {

          RmUpDetail rmupDetail12 = new RmUpDetail();
          // 料金メニューID
          rmupDetail12.setRmId(chargeMenuId);
          // DCEC区分コード
          rmupDetail12.setDcecCatCode(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE12_INDEX));
          //時間帯コード
          rmupDetail12.setTsCode(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE12_INDEX));
          //枝番
          rmupDetail12.setBranchNo(StringConvertUtil.stringToInteger(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO12_INDEX))
              .shortValue());
          //単価明細金額
          rmupDetail12.setUp(StringConvertUtil.stringToBigDecimal(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_UP12_INDEX)));
          // 料金メニュー単価明細の項目内容を補足する。
          this.fillRmUpDetail(rmupDetail12, applyStartDate);
          rmUpDetailList.add(rmupDetail12);
        }

        if (StringUtils.isNotEmpty(updateData
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE13_INDEX))
            && StringUtils.isNotEmpty(updateData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE13_INDEX))
            && StringUtils.isNotEmpty(updateData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO13_INDEX))) {

          RmUpDetail rmupDetail13 = new RmUpDetail();
          // 料金メニューID
          rmupDetail13.setRmId(chargeMenuId);
          // DCEC区分コード
          rmupDetail13.setDcecCatCode(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE13_INDEX));
          //時間帯コード
          rmupDetail13.setTsCode(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE13_INDEX));
          //枝番
          rmupDetail13.setBranchNo(StringConvertUtil.stringToInteger(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO13_INDEX))
              .shortValue());
          //単価明細金額
          rmupDetail13.setUp(StringConvertUtil.stringToBigDecimal(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_UP13_INDEX)));
          // 料金メニュー単価明細の項目内容を補足する。
          this.fillRmUpDetail(rmupDetail13, applyStartDate);
          rmUpDetailList.add(rmupDetail13);
        }

        if (StringUtils.isNotEmpty(updateData
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE14_INDEX))
            && StringUtils.isNotEmpty(updateData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE14_INDEX))
            && StringUtils.isNotEmpty(updateData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO14_INDEX))) {

          RmUpDetail rmupDetail14 = new RmUpDetail();
          // 料金メニューID
          rmupDetail14.setRmId(chargeMenuId);
          // DCEC区分コード
          rmupDetail14.setDcecCatCode(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE14_INDEX));
          //時間帯コード
          rmupDetail14.setTsCode(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE14_INDEX));
          //枝番
          rmupDetail14.setBranchNo(StringConvertUtil.stringToInteger(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO14_INDEX))
              .shortValue());
          //単価明細金額
          rmupDetail14.setUp(StringConvertUtil.stringToBigDecimal(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_UP14_INDEX)));
          // 料金メニュー単価明細の項目内容を補足する。
          this.fillRmUpDetail(rmupDetail14, applyStartDate);
          rmUpDetailList.add(rmupDetail14);
        }

        if (StringUtils.isNotEmpty(updateData
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE15_INDEX))
            && StringUtils.isNotEmpty(updateData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE15_INDEX))
            && StringUtils.isNotEmpty(updateData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO15_INDEX))) {

          RmUpDetail rmupDetail15 = new RmUpDetail();
          // 料金メニューID
          rmupDetail15.setRmId(chargeMenuId);
          // DCEC区分コード
          rmupDetail15.setDcecCatCode(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_DCEC_CAT_CODE15_INDEX));
          //時間帯コード
          rmupDetail15.setTsCode(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_TS_CODE15_INDEX));
          //枝番
          rmupDetail15.setBranchNo(StringConvertUtil.stringToInteger(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_BRANCH_NO15_INDEX))
              .shortValue());
          //単価明細金額
          rmupDetail15.setUp(StringConvertUtil.stringToBigDecimal(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_UP15_INDEX)));
          // 料金メニュー単価明細の項目内容を補足する。
          this.fillRmUpDetail(rmupDetail15, applyStartDate);
          rmUpDetailList.add(rmupDetail15);
        }
      }

      // 契約容量は必須ではないので値があるときのみ変換する
      String contCap = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_CAPACITY_INDEX);
      BigDecimal contractCapacity = StringUtils.isEmpty(contCap) ? null
          : new BigDecimal(contCap);
      // 電圧区分コード
      String voltageCatCode = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_VOLTAGE_CAT_CODE_INDEX);
      // 契約電力決定区分コード
      String ccdecisionCategoryCode = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CCDECISION_CATEGORY_CODE_INDEX);
      String contractChangeReason = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_CHANGE_REASON_INDEX);
      Integer updateCount = Integer
          .valueOf(updateData
              .get(Custom_ContractManagementInformationFileConfigContract.DATA_UPDATE_COUNT_INDEX));
      // 卸取次店契約番号
      String agentContractNo = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_AGENT_CONTRACT_NO_INDEX);
      // 契約付加情報フリー項目1
      String contractFree1 = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_01_INDEX);
      // 契約付加情報フリー項目2
      String contractFree2 = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_02_INDEX);
      // 契約付加情報フリー項目3
      String contractFree3 = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_03_INDEX);
      // 契約付加情報フリー項目4
      String contractFree4 = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_04_INDEX);
      // 契約付加情報フリー項目5
      String contractFree5 = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_05_INDEX);
      // 契約付加情報フリー項目6
      String contractFree6 = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_06_INDEX);
      // 契約付加情報フリー項目7
      String contractFree7 = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_07_INDEX);
      // 契約付加情報フリー項目8
      String contractFree8 = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_08_INDEX);
      // 契約付加情報フリー項目9
      String contractFree9 = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_09_INDEX);
      // 契約付加情報フリー項目10
      String contractFree10 = updateData
          .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_ADDINFO_FREE_10_INDEX);

      // 契約ID
      updateBean.setContractId(null);
      // 契約番号
      updateBean.setContractNo(contractNo);
      // 支払ID
      updateBean.setPaymentId(null);
      // 支払番号
      updateBean.setPaymentNo(paymentNo);
      // 契約終了日
      updateBean.setContractEndDate(contractEndDate);
      // 契約終了理由コード
      updateBean.setContractEndReasonCode(contractEndReasonCode);
      // 託送契約容量
      updateBean.setConsignmentContractCapacity(consignmentContractCapacity);
      // 託送契約容量フラグ
      updateBean.setConsignmentContractCapacityNoUpdFlag(ECISConstants.FLG_OFF);
      // 託送契約容量単位コード
      updateBean
          .setConsignmentcontractCapacityUnitCode(consignmentcontractCapacityUnitCode);
      // 託送契約容量判定日
      updateBean
          .setConsignmentContractCapacityDecisionDate(consignmentContractCapacityDecisionDate);
      // 託送契約容量判定日フラグ
      updateBean
          .setConsignmentContractCapacityDecisionDateNoUpdFlag(ECISConstants.FLG_OFF);
      // 料金チェックフラグ
      updateBean.setChargeCheckFlag(chargeCheckFlag);
      // 契約グループ番号
      updateBean.setContractGroupNo(contractGroupNo);
      // 連絡先個人・法人区分
      updateBean
          .setContactInformationinDividualLegalEntityCategoryCode(
              contactInformationinDividualLegalEntityCategoryCode);
      // 連絡先氏名（カナ）
      updateBean.setContractInformationNameKana(contractInformationNameKana);
      // 連絡先氏名1
      updateBean.setContractInformationName1(contractInformationName1);
      // 連絡先氏名2
      updateBean.setContractInformationName2(contractInformationName2);
      // 連絡先住所（郵便番号）
      updateBean
          .setContractInformationAddressPostalCode(contractInformationAddressPostalCode);
      // 連絡先住所（住所）
      updateBean
          .setContractInformationAddressFull(contractInformationAddressFull);
      // 連絡先住所（建物・部屋名）
      updateBean
          .setContractInformationAddressBuilding(contractInformationAddressBuilding);
      // 連絡先電話区分コード
      updateBean
          .setContractInformationCategoryCode(contractInformationCategoryCode);
      // 連絡先電話（市外局番）
      updateBean.setContractInformationAreaCode(contractInformationAreaCode);
      // 連絡先電話（市内局番）
      updateBean.setContractInformationLocalNo(contractInformationLocalNo);
      // 連絡先電話（加入者番号）
      updateBean
          .setContractInformationDirectoryNo(contractInformationDirectoryNo);
      // 需要者窓口連絡先所属
      updateBean.setConsumerContractAffiliation(consumerContractAffiliation);
      // 需要者窓口連絡先氏名
      updateBean.setConsumerContractName(consumerContractName);
      // 需要者窓口連絡先電話番号（市外局番）
      updateBean.setConsumerContractAreaCode(consumerContractAreaCode);
      // 需要者窓口連絡先電話番号（市内局番）
      updateBean.setConsumerContractLocalNo(consumerContractLocalNo);
      // 需要者窓口連絡先電話番号（加入者番号）
      updateBean
          .setConsumerContractDirectoryNo(consumerContractDirectoryNo);
      // 主任技術者連絡先所属
      updateBean.setChiefEngineerOfficerAffiliation(chiefEngineerOfficerAffiliation);
      // 主任技術者連絡先氏名
      updateBean.setChiefEngineerOfficerName(chiefEngineerOfficerName);
      // 主任技術者連絡先電話番号（市外局番）
      updateBean.setChiefEngineerOfficerAreaCode(chiefEngineerOfficerAreaCode);
      // 主任技術者連絡先電話番号（市内局番）
      updateBean.setChiefEngineerOfficerLocalNo(chiefEngineerOfficerLocalNo);
      // 主任技術者連絡先電話番号（加入者番号）
      updateBean
          .setChiefEngineerOfficerDirectoryNo(chiefEngineerOfficerDirectoryNo);
      // 接続送電サービス区分コード
      updateBean
          .setConnectedSupplyServiceCategoryCode(connectedSupplyServiceCategoryCode);
      // 部分供給区分コード
      updateBean.setPartialSupplyInformationCategoryCode(psInfoCatCode);
      // フリー項目1
      updateBean.setFree1(free1);
      // フリー項目2
      updateBean.setFree2(free2);
      // フリー項目3
      updateBean.setFree3(free3);
      // フリー項目4
      updateBean.setFree4(free4);
      // フリー項目5
      updateBean.setFree5(free5);
      // フリー項目6
      updateBean.setFree6(free6);
      // フリー項目7
      updateBean.setFree7(free7);
      // フリー項目8
      updateBean.setFree8(free8);
      // フリー項目9
      updateBean.setFree9(free9);
      // フリー項目10
      updateBean.setFree10(free10);
      // フリー項目11
      updateBean.setFree11(free11);
      // フリー項目12
      updateBean.setFree12(free12);
      // フリー項目13
      updateBean.setFree13(free13);
      // フリー項目14
      updateBean.setFree14(free14);
      // 委託先使用項目1
      updateBean.setConsignmentUseItem1(consignmentUseItem1);
      // 委託先使用項目2
      updateBean.setConsignmentUseItem2(consignmentUseItem2);
      // 委託先使用項目3
      updateBean.setConsignmentUseItem3(consignmentUseItem3);
      // 自社担当者コード
      updateBean.setOurManagementPersonInChargeCode(ourManagementPersonInChargeCode);
      // 自社部署コード
      updateBean.setOurManagementDepartmentCode(ourManagementDepartmentCode);
      // 業種コード
      updateBean.setBusinessTypeCode(businessTypeCode);
      // 営業委託先コード
      updateBean.setSalesConsignmentCode(salesConsignmentCode);
      // 契約備考
      updateBean.setContractNote(contractNote);
      // 適用開始日
      updateBean.setApplyStartDate(applyStartDate);
      // 実量歴必須フラグ
      updateBean.setRealQuantityNeed(realQuantityNeedflag);
      // 料金メニューID
      updateBean.setChargeMenuId(chargeMenuId);
      // 契約容量
      updateBean.setContractCapacity(contractCapacity);
      // 料金メニュー単価
      updateBean.setRmUp(rmUp);
      // 料金メニュー単価明細リスト
      updateBean.setRmUpDetailList(rmUpDetailList);
      // 電圧区分コード
      updateBean.setVoltageCatCode(voltageCatCode);
      // 契約電力決定区分コード
      updateBean.setCcDecisionCategoryCode(ccdecisionCategoryCode);
      // 単価設定区分コード
      updateBean.setUpCatCode(upCatcode);
      // 契約容量フラグ
      updateBean.setContractCapacityNoUpdFlag(ECISConstants.FLG_OFF);
      // 契約変更理由
      updateBean.setContractChangeReason(contractChangeReason);
      // 更新回数
      updateBean.setUpdateCount(updateCount);
      // 卸取次店契約番号
      updateBean.setAgentContractNo(agentContractNo);
      // 契約付加情報フリー項目1
      updateBean.setContractFree1(contractFree1);
      // 契約付加情報フリー項目2
      updateBean.setContractFree2(contractFree2);
      // 契約付加情報フリー項目3
      updateBean.setContractFree3(contractFree3);
      // 契約付加情報フリー項目4
      updateBean.setContractFree4(contractFree4);
      // 契約付加情報フリー項目5
      updateBean.setContractFree5(contractFree5);
      // 契約付加情報フリー項目6
      updateBean.setContractFree6(contractFree6);
      // 契約付加情報フリー項目7
      updateBean.setContractFree7(contractFree7);
      // 契約付加情報フリー項目8
      updateBean.setContractFree8(contractFree8);
      // 契約付加情報フリー項目9
      updateBean.setContractFree9(contractFree9);
      // 契約付加情報フリー項目10
      updateBean.setContractFree10(contractFree10);

      // 更新処理実行
      UpdateAgentContractBusinessBean updateResultBean = agentContractInformationBusiness.update(updateBean);

      // リターンコードを取得する。
      returnCode = updateResultBean.getReturnCode();
      // リターンコードが0000（正常終了）以外の場合、エラーリストにメッセージを設定する
      if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(returnCode)) {
        errorList.add(StringConvertUtil.convertErrorListString(
            uploadFileName,
            StringConvertUtil.stringToInteger(updateData
                .get(ContractManagementInformationFileConfigCommon.DATA_ROW_NO_INDEX)),
            messageSource.getMessage(
                KJ_CommonUtil.getDisplayMessageId(
                    ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD,
                    returnCode),
                null, Locale.getDefault())));

        // リターンコード判定メソッドを呼出し、処理継続フラグを取得する
        execFlag = checkReturnCode(returnCode);
        // 処理継続フラグが"定数.オフ(0)(処理継続不能)"の場合、処理を終了し、処理継続フラグを返却する
        if (ECISConstants.FLG_OFF.equals(execFlag)) {
          break;
        }
      } else {

        // カスタム契約情報更新
        Custom_UpdateCustomContractBusinessBean customUpdateBean = new Custom_UpdateCustomContractBusinessBean();

        Integer contractId = updateResultBean.getContractId();
        String salesDepartmentCd = updateData
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_SALES_DEPARTMENT_CODE_INDEX);
        String contactCd = updateData
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_SALES_CONTACT_CODE_INDEX);
        // 契約ID
        customUpdateBean.setContractId(contractId);
        // 営業担当者・組織コード
        customUpdateBean.setSalesDepartmentCd(salesDepartmentCd);
        // 問い合わせ先コード
        customUpdateBean.setContactCd(contactCd);

        // 更新処理実行
        Custom_UpdateCustomContractBusinessBean customResultBean = customContractInformationBusiness
            .update(customUpdateBean);

        // リターンコードを取得する。
        returnCode = customResultBean.getReturnCode();
        // リターンコードが0000（正常終了）以外の場合、エラーリストにメッセージを設定する
        if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(returnCode)) {
          errorList.add(StringConvertUtil.convertErrorListString(
              uploadFileName,
              StringConvertUtil.stringToInteger(updateData
                  .get(ContractManagementInformationFileConfigCommon.DATA_ROW_NO_INDEX)),
              messageSource.getMessage(
                  KJ_CommonUtil.getDisplayMessageId(
                      ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD,
                      returnCode),
                  null, Locale.getDefault())));

          // リターンコード判定メソッドを呼出し、処理継続フラグを取得する
          execFlag = checkReturnCode(returnCode);
          // 処理継続フラグが"定数.オフ(0)(処理継続不能)"の場合、処理を終了し、処理継続フラグを返却する
          if (ECISConstants.FLG_OFF.equals(execFlag)) {
            break;
          }
        }

        // 予備契約情報の登録・更新・削除
        returnCode = uploadReserveContract(updateData, updateResultBean.getContractId());

        // リターンコードが0000（正常終了）以外の場合、エラーリストにメッセージを設定する
        if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(returnCode)) {
          errorList.add(StringConvertUtil.convertErrorListString(
              uploadFileName,
              StringConvertUtil.stringToInteger(updateData
                  .get(ContractManagementInformationFileConfigCommon.DATA_ROW_NO_INDEX)),
              messageSource.getMessage(
                  KJ_CommonUtil.getDisplayMessageId(
                      ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD,
                      returnCode),
                  null, Locale.getDefault())));

          // リターンコード判定メソッドを呼出し、処理継続フラグを取得する
          execFlag = checkReturnCode(returnCode);
          // 処理継続フラグが"定数.オフ(0)(処理継続不能)"の場合、処理を終了し、処理継続フラグを返却する
          if (ECISConstants.FLG_OFF.equals(execFlag)) {
            break;
          }
        }
      }
    }

    // 処理継続フラグを返却する
    return execFlag;
  }

  /**
   * 契約情報削除処理を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 1 処理継続フラグに初期値(ON)を設定する。
   * 2 削除オブジェクトリストの件数分、契約情報Businessの削除メソッドを呼び出す。
   *   削除メソッドの戻り値のリターンコードが0000以外の場合、
   *   エラー情報を引数.エラーリストオブジェクトに設定する。
   *   削除メソッドの戻り値のリターンコードがD023またはG017の場合、
   *   繰り返し処理を中断し、処理継続フラグにOFFに設定する。
   * 3 処理継続フラグを返却する。
   * </pre>
   *
   * @param deleteDataList
   *          契約情報削除オブジェクトリスト
   * @param uploadFileName
   *          アップロードファイル名
   * @param errorList
   *          エラーリスト
   * @return 処理継続フラグ
   */
  private String uploadDeleteContract(List<Map<Integer, String>> deleteDataList, String uploadFileName,
      List<String> errorList) {

    // リターンコードを定義する。
    String returnCode;
    // 処理継続フラグ（初期値）を設定する
    String execFlag = ECISConstants.FLG_ON;

    // 削除処理
    // 削除オブジェクトリストの件数分実施する
    for (Map<Integer, String> deleteData : deleteDataList) {

      // 予備契約情報の削除
      returnCode = uploadReserveContract(deleteData, null);

      // リターンコードが0000（正常終了）以外の場合、エラーリストにメッセージを設定する
      if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(returnCode)) {
        errorList.add(StringConvertUtil.convertErrorListString(
            uploadFileName,
            StringConvertUtil.stringToInteger(deleteData
                .get(ContractManagementInformationFileConfigCommon.DATA_ROW_NO_INDEX)),
            messageSource.getMessage(
                KJ_CommonUtil.getDisplayMessageId(
                    ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD,
                    returnCode),
                null, Locale.getDefault())));

        // リターンコード判定メソッドを呼出し、処理継続フラグを取得する
        execFlag = checkReturnCode(returnCode);
        // 処理継続フラグが"定数.オフ(0)(処理継続不能)"の場合、処理を終了し、処理継続フラグを返却する
        if (ECISConstants.FLG_OFF.equals(execFlag)) {
          break;
        }

        // 削除情報設定
        DeleteAgentContractBusinessBean deleteBean = new DeleteAgentContractBusinessBean();

        // 契約ID
        deleteBean.setContractId(null);
        // 契約番号
        deleteBean.setContractNo(deleteData
            .get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_NO_INDEX));
        // 適用開始日
        Date applyStartDate = StringConvertUtil
            .stringToDate(
                deleteData
                    .get(Custom_ContractManagementInformationFileConfigContract.DATA_APPLY_START_DATE_INDEX),
                ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH);
        deleteBean.setApplyStartDate(applyStartDate);
        // 更新回数
        Integer updateCnt = Integer
            .valueOf(deleteData
                .get(Custom_ContractManagementInformationFileConfigContract.DATA_UPDATE_COUNT_INDEX));
        deleteBean.setUpdateCount(updateCnt);

        // 削除処理実行
        DeleteAgentContractBusinessBean deleteResultBean = agentContractInformationBusiness.delete(deleteBean);

        // リターンコードを取得する。
        returnCode = deleteResultBean.getReturnCode();
        // リターンコードが0000（正常終了）以外の場合、エラーリストにメッセージを設定する
        if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(returnCode)) {
          errorList.add(StringConvertUtil.convertErrorListString(
              uploadFileName,
              StringConvertUtil.stringToInteger(deleteData
                  .get(ContractManagementInformationFileConfigCommon.DATA_ROW_NO_INDEX)),
              messageSource.getMessage(
                  KJ_CommonUtil.getDisplayMessageId(
                      ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD,
                      returnCode),
                  null, Locale.getDefault())));

          // リターンコード判定メソッドを呼出し、処理継続フラグを取得する
          execFlag = checkReturnCode(returnCode);
          // 処理継続フラグが"定数.オフ(0)(処理継続不能)"の場合、処理を終了し、処理継続フラグを返却する
          if (ECISConstants.FLG_OFF.equals(execFlag)) {
            break;
          }
        } else {

          // カスタム契約情報削除処理
          Custom_DeleteCustomContractBusinessBean customDeleteBean = new Custom_DeleteCustomContractBusinessBean();
          // 契約ID
          customDeleteBean.setContractId(deleteResultBean.getContractId());

          // 追加処理実行
          Custom_DeleteCustomContractBusinessBean customResultBean = customContractInformationBusiness
              .delete(customDeleteBean);

          // リターンコードを取得する。
          returnCode = customResultBean.getReturnCode();
          // リターンコードが0000（正常終了）以外の場合、エラーリストにメッセージを設定する
          if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(returnCode)) {
            errorList.add(StringConvertUtil.convertErrorListString(
                uploadFileName,
                StringConvertUtil.stringToInteger(deleteData
                    .get(ContractManagementInformationFileConfigCommon.DATA_ROW_NO_INDEX)),
                messageSource.getMessage(
                    KJ_CommonUtil.getDisplayMessageId(
                        ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD,
                        returnCode),
                    null, Locale.getDefault())));

            // リターンコード判定メソッドを呼出し、処理継続フラグを取得する
            execFlag = checkReturnCode(returnCode);
            // 処理継続フラグが"定数.オフ(0)(処理継続不能)"の場合、処理を終了し、処理継続フラグを返却する
            if (ECISConstants.FLG_OFF.equals(execFlag)) {
              break;
            }
          }
        }
      }
    }

    // 処理継続フラグを返却する
    return execFlag;
  }

  /**
   * 付帯契約情報登録処理を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 1 処理継続フラグに初期値(ON)を設定する。
   * 2 登録オブジェクトリストの件数分、付帯契約情報Businessの登録メソッドを呼び出す。
   *   登録メソッドの戻り値のリターンコードが0000以外の場合、
   *   エラー情報を引数.エラーリストオブジェクトに設定する。
   *   登録メソッドの戻り値のリターンコードがD023またはG017の場合、
   *   繰り返し処理を中断し、処理継続フラグにOFFに設定する。
   * 3 処理継続フラグを返却する。
   * </pre>
   *
   * @param registDataList
   *          付帯契約情報登録オブジェクトリスト
   * @param uploadFileName
   *          アップロードファイル名
   * @param errorList
   *          エラーリスト
   * @return 処理継続フラグ
   */
  private String uploadRegistSupplementaryContract(List<Map<Integer, String>> registDataList, String uploadFileName,
      List<String> errorList) {

    // リターンコードを定義する。
    String returnCode;
    // 処理継続フラグ（初期値）を設定する
    String execFlag = ECISConstants.FLG_ON;

    // 登録処理
    // 登録オブジェクトリストの件数分実施する
    for (Map<Integer, String> registData : registDataList) {
      // 登録情報設定
      AddSupplementaryContractBusinessBean registBean = new AddSupplementaryContractBusinessBean();

      // 契約ID
      registBean.setContractId(null);
      // 契約番号
      registBean.setContractNo(registData
          .get(ContractManagementInformationFileConfigSupplementaryContract.DATA_CONTRACT_NO_INDEX));
      // 付帯メニューID
      registBean
          .setSupplementaryMenuId(registData
              .get(ContractManagementInformationFileConfigSupplementaryContract.DATA_SUPPLEMENTARY_MENU_ID_INDEX));
      // 付帯契約開始日
      Date suppContractStartDate = StringConvertUtil
          .stringToDate(
              registData
                  .get(ContractManagementInformationFileConfigSupplementaryContract.DATA_SUPPLEMENTARY_CONTRACT_START_DATE_INDEX),
              ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH);
      registBean.setSupplementaryContractStartDate(suppContractStartDate);
      // 付帯契約終了日
      Date suppContractEndDate = StringConvertUtil
          .stringToDate(
              registData
                  .get(ContractManagementInformationFileConfigSupplementaryContract.DATA_SUPPLEMENTARY_CONTRACT_END_DATE_INDEX),
              ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH);
      registBean.setSupplementaryContractEndDate(suppContractEndDate);
      // 額・率
      String amountOrRateStr = registData
          .get(ContractManagementInformationFileConfigSupplementaryContract.DATA_AMOUNT_OR_RATE_INDEX);
      BigDecimal amountOrRate = StringUtils
          .isEmpty(amountOrRateStr) ? null
              : new BigDecimal(
                  amountOrRateStr);
      registBean.setAmountOrRate(amountOrRate);

      // 登録処理実行
      AddSupplementaryContractBusinessBean addResultBean = supplementaryContractInformationBusiness
          .add(registBean);

      // リターンコードを取得する。
      returnCode = addResultBean.getReturnCode();
      // リターンコードが0000（正常終了）以外の場合、エラーリストにメッセージを設定する
      if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(returnCode)) {
        errorList.add(StringConvertUtil.convertErrorListString(
            uploadFileName,
            StringConvertUtil.stringToInteger(registData
                .get(ContractManagementInformationFileConfigCommon.DATA_ROW_NO_INDEX)),
            messageSource.getMessage(
                KJ_CommonUtil.getDisplayMessageId(
                    ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD,
                    returnCode),
                null, Locale.getDefault())));

        // リターンコード判定メソッドを呼出し、処理継続フラグを取得する
        execFlag = checkReturnCode(returnCode);
        // 処理継続フラグが"定数.オフ(0)(処理継続不能)"の場合、処理を終了し、処理継続フラグを返却する
        if (ECISConstants.FLG_OFF.equals(execFlag)) {
          break;
        }
      }
    }

    // 処理継続フラグを返却する
    return execFlag;
  }

  /**
   * 付帯契約情報更新処理を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 1 処理継続フラグに初期値(ON)を設定する。
   * 2 更新オブジェクトリストの件数分、付帯契約情報Businessの更新メソッドを呼び出す。
   *   更新メソッドの戻り値のリターンコードが0000以外の場合、
   *   エラー情報を引数.エラーリストオブジェクトに設定する。
   *   更新メソッドの戻り値のリターンコードがD023またはG017の場合、
   *   繰り返し処理を中断し、処理継続フラグにOFFに設定する。
   * 3 処理継続フラグを返却する。
   * </pre>
   *
   * @param updateDataList
   *          付帯契約情報更新オブジェクトリスト
   * @param uploadFileName
   *          アップロードファイル名
   * @param errorList
   *          エラーリスト
   * @return 処理継続フラグ
   */
  private String uploadUpdateSupplementaryContract(List<Map<Integer, String>> updateDataList, String uploadFileName,
      List<String> errorList) {

    // リターンコードを定義する。
    String returnCode;
    // 処理継続フラグ（初期値）を設定する
    String execFlag = ECISConstants.FLG_ON;

    // 更新処理
    // 更新オブジェクトリストの件数分実施する
    for (Map<Integer, String> updateData : updateDataList) {
      // 更新情報設定
      UpdateSupplementaryContractBusinessBean updateBean = new UpdateSupplementaryContractBusinessBean();

      // 付帯契約ID
      updateBean
          .setSupplementaryContractId(StringConvertUtil.stringToInteger(updateData
              .get(ContractManagementInformationFileConfigSupplementaryContract.DATA_SUPPLEMENTARY_CONTRACT_ID_INDEX)));
      // 付帯契約終了日
      Date suppContractEndDate = StringConvertUtil
          .stringToDate(
              updateData
                  .get(ContractManagementInformationFileConfigSupplementaryContract.DATA_SUPPLEMENTARY_CONTRACT_END_DATE_INDEX),
              ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH);
      updateBean.setSupplementaryContractEndDate(suppContractEndDate);
      // 更新回数
      updateBean.setUpdateCount(StringConvertUtil.stringToInteger(updateData
          .get(ContractManagementInformationFileConfigSupplementaryContract.DATA_UPDATE_COUNT_INDEX)));

      // 更新処理実行
      UpdateSupplementaryContractBusinessBean updateResultBean = supplementaryContractInformationBusiness
          .update(updateBean);

      // リターンコードを取得する。
      returnCode = updateResultBean.getReturnCode();
      // リターンコードが0000（正常終了）以外の場合、エラーリストにメッセージを設定する
      if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(returnCode)) {
        errorList.add(StringConvertUtil.convertErrorListString(
            uploadFileName,
            StringConvertUtil.stringToInteger(updateData
                .get(ContractManagementInformationFileConfigCommon.DATA_ROW_NO_INDEX)),
            messageSource.getMessage(
                KJ_CommonUtil.getDisplayMessageId(
                    ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD,
                    returnCode),
                null, Locale.getDefault())));

        // リターンコード判定メソッドを呼出し、処理継続フラグを取得する
        execFlag = checkReturnCode(returnCode);
        // 処理継続フラグが"定数.オフ(0)(処理継続不能)"の場合、処理を終了し、処理継続フラグを返却する
        if (ECISConstants.FLG_OFF.equals(execFlag)) {
          break;
        }
      }
    }

    // 処理継続フラグを返却する
    return execFlag;
  }

  /**
   * 付帯契約情報削除処理を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 1 処理継続フラグに初期値(ON)を設定する。
   * 2 削除オブジェクトリストの件数分、付帯契約情報Businessの削除メソッドを呼び出す。
   *   削除メソッドの戻り値のリターンコードが0000以外の場合、
   *   エラー情報を引数.エラーリストオブジェクトに設定する。
   *   削除メソッドの戻り値のリターンコードがD023またはG017の場合、
   *   繰り返し処理を中断し、処理継続フラグにOFFに設定する。
   * 3 処理継続フラグを返却する。
   * </pre>
   *
   * @param deleteDataList
   *          付帯契約情報削除オブジェクトリスト
   * @param uploadFileName
   *          アップロードファイル名
   * @param errorList
   *          エラーリスト
   * @return 処理継続フラグ
   */
  private String uploadDeleteSupplementaryContract(List<Map<Integer, String>> deleteDataList, String uploadFileName,
      List<String> errorList) {

    // リターンコードを定義する。
    String returnCode;
    // 処理継続フラグ（初期値）を設定する
    String execFlag = ECISConstants.FLG_ON;

    // 削除処理
    // 削除オブジェクトリストの件数分実施する
    for (Map<Integer, String> dataRecord : deleteDataList) {
      // 削除情報設定
      DeleteSupplementaryContractBusinessBean deleteBean = new DeleteSupplementaryContractBusinessBean();

      // 付帯契約ID
      deleteBean
          .setSupplementaryContractId(StringConvertUtil.stringToInteger(dataRecord
              .get(ContractManagementInformationFileConfigSupplementaryContract.DATA_SUPPLEMENTARY_CONTRACT_ID_INDEX)));
      // 更新回数
      deleteBean.setUpdateCount(StringConvertUtil.stringToInteger(dataRecord
          .get(ContractManagementInformationFileConfigSupplementaryContract.DATA_UPDATE_COUNT_INDEX)));

      // 削除処理実行
      DeleteSupplementaryContractBusinessBean deleteResultBean = supplementaryContractInformationBusiness
          .delete(deleteBean);

      // リターンコードを取得する。
      returnCode = deleteResultBean.getReturnCode();
      // リターンコードが0000（正常終了）以外の場合、エラーリストにメッセージを設定する
      if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(returnCode)) {
        errorList.add(StringConvertUtil.convertErrorListString(
            uploadFileName,
            StringConvertUtil.stringToInteger(dataRecord
                .get(ContractManagementInformationFileConfigCommon.DATA_ROW_NO_INDEX)),
            messageSource.getMessage(
                KJ_CommonUtil.getDisplayMessageId(
                    ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD,
                    returnCode),
                null, Locale.getDefault())));

        // リターンコード判定メソッドを呼出し、処理継続フラグを取得する
        execFlag = checkReturnCode(returnCode);
        // 処理継続フラグが"定数.オフ(0)(処理継続不能)"の場合、処理を終了し、処理継続フラグを返却する
        if (ECISConstants.FLG_OFF.equals(execFlag)) {
          break;
        }
      }
    }

    // 処理継続フラグを返却する
    return execFlag;
  }

  /**
   * メータ設置場所情報登録処理を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 1 処理継続フラグに初期値(ON)を設定する。
   * 2 登録オブジェクトリストの件数分、メータ設置場所情報Businessの登録メソッドを呼び出す。
   *   登録メソッドの戻り値のリターンコードが0000以外の場合、
   *   エラー情報を引数.エラーリストオブジェクトに設定する。
   *   登録メソッドの戻り値のリターンコードがD023またはG017の場合、
   *   繰り返し処理を中断し、処理継続フラグにOFFに設定する。
   * 3 処理継続フラグを返却する。
   * </pre>
   *
   * @param registDataList
   *          メータ設置場所情報登録オブジェクトリスト
   * @param uploadFileName
   *          アップロードファイル名
   * @param errorList
   *          エラーリスト
   * @return 処理継続フラグ
   */
  private String uploadRegistMeterLocation(List<Map<Integer, String>> registDataList, String uploadFileName,
      List<String> errorList) {

    // リターンコードを定義する。
    String returnCode;
    // 処理継続フラグ（初期値）を設定する
    String execFlag = ECISConstants.FLG_ON;

    // 登録処理
    // 登録オブジェクトリストの件数分実施する
    for (Map<Integer, String> registData : registDataList) {
      // 登録情報設定
      RegistAgentMeterLocationBusinessBean registBean = new RegistAgentMeterLocationBusinessBean();

      // 需要場所住所（郵便番号）
      registBean.setPlaceAddressPostalCode(registData
          .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_PLACE_ADDRESS_POSTAL_CODE_INDEX));
      // 需要場所住所（住所）
      registBean.setPlaceAddressFull(registData
          .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_PLACE_ADDRESS_FULL_INDEX));
      // 需要場所住所（建物・部屋名）
      registBean.setPlaceAddressBuilding(registData
          .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_PLACE_ADDRESS_BUILDING_INDEX));
      // エリアコード
      registBean.setAreaCode(registData
          .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_AREA_CODE_INDEX));
      // 地点特定番号
      registBean.setSpotNo(registData
          .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_SPOT_NO_INDEX));
      // 需要家識別番号
      registBean.setContractorIdentificationNo(registData
          .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_CONTRACTOR_IDENTIFICATION_NO_INDEX));
      // 送受電区分コード
      registBean.setTransmissionCategoryCode(registData
          .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_TRANSMISSION_CATEGORY_CODE_INDEX));
      // 基本検針日
      registBean.setBasicMeterReadingDate(registData
          .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_BASIC_METER_READING_DATE_INDEX));
      // 次回検針予定日
      registBean
          .setNextMeterReadingScheduledDate(StringConvertUtil.stringToDate(
              registData
                  .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_NEXT_METER_READING_SCHEDULED_DATE_INDEX),
              Custom_ContractManagementInformationFileConfigMeterLocation.DATA_NEXT_METER_READING_SCHEDULED_DATE_FORMAT));
      // 前回検針日
      registBean
          .setLastTimeMeterReadingDate(StringConvertUtil.stringToDate(
              registData
                  .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_LAST_TIME_METER_READING_DATE_INDEX),
              Custom_ContractManagementInformationFileConfigMeterLocation.DATA_LAST_TIME_METER_READING_DATE_FORMAT));
      // 自家発連携有無コード
      registBean.setGeneratorLinkageCheckCode(registData
          .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_GENERATOR_LINKAGE_CHECK_CODE_INDEX));
      // 供給方式コード
      registBean.setMethodCode(registData
          .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_SUPPLY_METHOD_CODE_INDEX));
      // 計器識別番号1
      registBean.setMeterIdentificationNo1(registData
          .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO1_INDEX));
      // 計器識別番号2
      registBean.setMeterIdentificationNo2(registData
          .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO2_INDEX));
      // 計器識別番号3
      registBean.setMeterIdentificationNo3(registData
          .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO3_INDEX));
      // 計器識別番号4
      registBean.setMeterIdentificationNo4(registData
          .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO4_INDEX));
      // 計器識別番号5
      registBean.setMeterIdentificationNo5(registData
          .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO5_INDEX));
      // 30分値収集可否・自動検針可否コード1
      registBean
          .setAutomaticMeterReadingCkeckCode1(registData
              .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_AUTOMATIC_METER_READING_CHECK_CODE1_INDEX));
      // 30分値収集可否・自動検針可否コード2
      registBean
          .setAutomaticMeterReadingCkeckCode2(registData
              .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_AUTOMATIC_METER_READING_CHECK_CODE2_INDEX));
      // 30分値収集可否・自動検針可否コード3
      registBean
          .setAutomaticMeterReadingCkeckCode3(registData
              .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_AUTOMATIC_METER_READING_CHECK_CODE3_INDEX));
      // 30分値収集可否・自動検針可否コード4
      registBean
          .setAutomaticMeterReadingCkeckCode4(registData
              .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_AUTOMATIC_METER_READING_CHECK_CODE4_INDEX));
      // 30分値収集可否・自動検針可否コード5
      registBean
          .setAutomaticMeterReadingCkeckCode5(registData
              .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_AUTOMATIC_METER_READING_CHECK_CODE5_INDEX));
      // 検針日区分コード
      registBean
          .setMeterReadingDateCategoryCode(registData
              .get(Custom_ContractManagementInformationFileConfigMeterLocation.METER_READING_DATE_CATEGORY_CODE_INDEX));
      // メータ設置場所フリー項目1
      registBean
          .setMeterLocationFree1(registData
              .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_01_INDEX));
      // メータ設置場所フリー項目2
      registBean
          .setMeterLocationFree2(registData
              .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_02_INDEX));
      // メータ設置場所フリー項目3
      registBean
          .setMeterLocationFree3(registData
              .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_03_INDEX));
      // メータ設置場所フリー項目4
      registBean
          .setMeterLocationFree4(registData
              .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_04_INDEX));
      // メータ設置場所フリー項目5
      registBean
          .setMeterLocationFree5(registData
              .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_05_INDEX));
      // メータ設置場所フリー項目6
      registBean
          .setMeterLocationFree6(registData
              .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_06_INDEX));
      // メータ設置場所フリー項目7
      registBean
          .setMeterLocationFree7(registData
              .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_07_INDEX));
      // メータ設置場所フリー項目8
      registBean
          .setMeterLocationFree8(registData
              .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_08_INDEX));
      // メータ設置場所フリー項目9
      registBean
          .setMeterLocationFree9(registData
              .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_09_INDEX));
      // メータ設置場所フリー項目10
      registBean
          .setMeterLocationFree10(registData
              .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_10_INDEX));

      // 登録処理実行
      RegistAgentMeterLocationBusinessBean resultBean = agentMeterLocationInformationBusiness.regist(registBean);

      // リターンコードを取得する。
      returnCode = resultBean.getReturnCode();
      // リターンコードが0000（正常終了）以外の場合、エラーリストにメッセージを設定する
      if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(returnCode)) {
        errorList.add(StringConvertUtil.convertErrorListString(
            uploadFileName,
            StringConvertUtil.stringToInteger(registData
                .get(ContractManagementInformationFileConfigCommon.DATA_ROW_NO_INDEX)),
            messageSource.getMessage(
                KJ_CommonUtil.getDisplayMessageId(
                    ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD,
                    returnCode),
                null, Locale.getDefault())));

        // リターンコード判定メソッドを呼出し、処理継続フラグを取得する
        execFlag = checkReturnCode(returnCode);
        // 処理継続フラグが"定数.オフ(0)(処理継続不能)"の場合、処理を終了し、処理継続フラグを返却する
        if (ECISConstants.FLG_OFF.equals(execFlag)) {
          break;
        }
      }
    }

    // 処理継続フラグを返却する
    return execFlag;
  }

  /**
   * メータ設置場所情報更新処理を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 1 処理継続フラグに初期値(ON)を設定する。
   * 2 更新オブジェクトリストの件数分、メータ設置場所情報Businessの更新メソッドを呼び出す。
   *   更新メソッドの戻り値のリターンコードが0000以外の場合、
   *   エラー情報を引数.エラーリストオブジェクトに設定する。
   *   更新メソッドの戻り値のリターンコードがD023またはG017の場合、
   *   繰り返し処理を中断し、処理継続フラグにOFFに設定する。
   * 3 処理継続フラグを返却する。
   * </pre>
   *
   * @param updateDataList
   *          メータ設置場所情報更新オブジェクトリスト
   * @param uploadFileName
   *          アップロードファイル名
   * @param errorList
   *          エラーリスト
   * @return 処理継続フラグ
   */
  private String uploadUpdateMeterLocation(List<Map<Integer, String>> updateDataList, String uploadFileName,
      List<String> errorList) {

    // リターンコードを定義する。
    String returnCode;
    // 処理継続フラグ（初期値）を設定する
    String execFlag = ECISConstants.FLG_ON;

    // 更新処理
    // 更新オブジェクトリストの件数分実施する
    for (Map<Integer, String> updateData : updateDataList) {
      // 更新情報設定
      UpdateAgentMeterLocationBusinessBean updateBean = new UpdateAgentMeterLocationBusinessBean();

      // メータ設置場所ID
      updateBean.setMeterLocationId(StringConvertUtil.stringToInteger(updateData
          .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_METER_LOCATION_ID_INDEX)));
      // 需要場所住所（郵便番号）
      updateBean.setPlaceAddressPostalCode(updateData
          .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_PLACE_ADDRESS_POSTAL_CODE_INDEX));
      // 需要場所住所（住所）
      updateBean.setPlaceAddressFull(updateData
          .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_PLACE_ADDRESS_FULL_INDEX));
      // 需要場所住所（建物・部屋名）
      updateBean.setPlaceAddressBuilding(updateData
          .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_PLACE_ADDRESS_BUILDING_INDEX));
      // エリアコード
      updateBean.setAreaCode(updateData
          .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_AREA_CODE_INDEX));
      // 地点特定番号
      updateBean.setSpotNo(updateData
          .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_SPOT_NO_INDEX));
      // 需要家識別番号
      updateBean.setContractorIdentificationNo(updateData
          .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_CONTRACTOR_IDENTIFICATION_NO_INDEX));
      // 送受電区分コード
      updateBean.setTransmissionCategoryCode(updateData
          .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_TRANSMISSION_CATEGORY_CODE_INDEX));
      // 基本検針日
      updateBean.setBasicMeterReadingDate(updateData
          .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_BASIC_METER_READING_DATE_INDEX));
      // 次回検針予定日
      updateBean
          .setNextMeterReadingScheduledDate(StringConvertUtil.stringToDate(
              updateData
                  .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_NEXT_METER_READING_SCHEDULED_DATE_INDEX),
              Custom_ContractManagementInformationFileConfigMeterLocation.DATA_NEXT_METER_READING_SCHEDULED_DATE_FORMAT));
      // 次回検針予定日更新対象外フラグ
      updateBean.setNextMeterReadingScheduledDateNoUpdFlag(ECISConstants.FLG_OFF);

      // 前回検針日
      updateBean
          .setLastTimeMeterReadingDate(StringConvertUtil.stringToDate(
              updateData
                  .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_LAST_TIME_METER_READING_DATE_INDEX),
              Custom_ContractManagementInformationFileConfigMeterLocation.DATA_LAST_TIME_METER_READING_DATE_FORMAT));
      // 前回検針日更新対象外フラグ
      updateBean.setLastTimeMeterReadingDateNoUpdFlag(ECISConstants.FLG_OFF);

      // 自家発連携有無コード
      updateBean.setGeneratorLinkageCheckCode(updateData
          .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_GENERATOR_LINKAGE_CHECK_CODE_INDEX));
      // 供給方式コード
      updateBean.setMethodCode(updateData
          .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_SUPPLY_METHOD_CODE_INDEX));
      // 計器識別番号1
      updateBean.setMeterIdentificationNo1(updateData
          .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO1_INDEX));
      // 計器識別番号2
      updateBean.setMeterIdentificationNo2(updateData
          .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO2_INDEX));
      // 計器識別番号3
      updateBean.setMeterIdentificationNo3(updateData
          .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO3_INDEX));
      // 計器識別番号4
      updateBean.setMeterIdentificationNo4(updateData
          .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO4_INDEX));
      // 計器識別番号5
      updateBean.setMeterIdentificationNo5(updateData
          .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_METER_IDENTIFICATION_NO5_INDEX));
      // 30分値収集可否・自動検針可否コード1
      updateBean
          .setAutomaticMeterReadingCkeckCode1(updateData
              .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_AUTOMATIC_METER_READING_CHECK_CODE1_INDEX));
      // 30分値収集可否・自動検針可否コード2
      updateBean
          .setAutomaticMeterReadingCkeckCode2(updateData
              .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_AUTOMATIC_METER_READING_CHECK_CODE2_INDEX));
      // 30分値収集可否・自動検針可否コード3
      updateBean
          .setAutomaticMeterReadingCkeckCode3(updateData
              .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_AUTOMATIC_METER_READING_CHECK_CODE3_INDEX));
      // 30分値収集可否・自動検針可否コード4
      updateBean
          .setAutomaticMeterReadingCkeckCode4(updateData
              .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_AUTOMATIC_METER_READING_CHECK_CODE4_INDEX));
      // 30分値収集可否・自動検針可否コード5
      updateBean
          .setAutomaticMeterReadingCkeckCode5(updateData
              .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_AUTOMATIC_METER_READING_CHECK_CODE5_INDEX));
      // 検針日区分コード
      updateBean
          .setMeterReadingDateCategoryCode(updateData
              .get(Custom_ContractManagementInformationFileConfigMeterLocation.METER_READING_DATE_CATEGORY_CODE_INDEX));
      // 更新回数
      updateBean.setUpdateCount(StringConvertUtil.stringToInteger(updateData
          .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_UPDATE_COUNT_INDEX)));
      // メータ設置場所フリー項目1
      updateBean
          .setMeterLocationFree1(updateData
              .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_01_INDEX));
      // メータ設置場所フリー項目2
      updateBean
          .setMeterLocationFree2(updateData
              .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_02_INDEX));
      // メータ設置場所フリー項目3
      updateBean
          .setMeterLocationFree3(updateData
              .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_03_INDEX));
      // メータ設置場所フリー項目4
      updateBean
          .setMeterLocationFree4(updateData
              .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_04_INDEX));
      // メータ設置場所フリー項目5
      updateBean
          .setMeterLocationFree5(updateData
              .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_05_INDEX));
      // メータ設置場所フリー項目6
      updateBean
          .setMeterLocationFree6(updateData
              .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_06_INDEX));
      // メータ設置場所フリー項目7
      updateBean
          .setMeterLocationFree7(updateData
              .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_07_INDEX));
      // メータ設置場所フリー項目8
      updateBean
          .setMeterLocationFree8(updateData
              .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_08_INDEX));
      // メータ設置場所フリー項目9
      updateBean
          .setMeterLocationFree9(updateData
              .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_09_INDEX));
      // メータ設置場所フリー項目10
      updateBean
          .setMeterLocationFree10(updateData
              .get(Custom_ContractManagementInformationFileConfigMeterLocation.DATA_FREE_10_INDEX));
      // 更新処理実行
      UpdateAgentMeterLocationBusinessBean resultBean = agentMeterLocationInformationBusiness.update(updateBean);

      // リターンコードを取得する。
      returnCode = resultBean.getReturnCode();
      // リターンコードが0000（正常終了）以外の場合、エラーリストにメッセージを設定する
      if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(returnCode)) {
        errorList.add(StringConvertUtil.convertErrorListString(
            uploadFileName,
            StringConvertUtil.stringToInteger(updateData
                .get(ContractManagementInformationFileConfigCommon.DATA_ROW_NO_INDEX)),
            messageSource.getMessage(
                KJ_CommonUtil.getDisplayMessageId(
                    ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD,
                    returnCode),
                null, Locale.getDefault())));

        // リターンコード判定メソッドを呼出し、処理継続フラグを取得する
        execFlag = checkReturnCode(returnCode);
        // 処理継続フラグが"定数.オフ(0)(処理継続不能)"の場合、処理を終了し、処理継続フラグを返却する
        if (ECISConstants.FLG_OFF.equals(execFlag)) {
          break;
        }
      }
    }

    // 処理継続フラグを返却する
    return execFlag;
  }

  /**
   * 予備契約登録・更新・削除処理
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 予備契約履歴に対して登録・更新・削除を行う。
   * </pre>
   *
   * @param contractInfo
   *          契約情報
   * @param paraContractId
   *          契約ID
   * @return リターンコード
   */
  private String uploadReserveContract(Map<Integer, String> contractInfo, Integer paraContractId) {

    // リターンコードを定義する。
    String returnCode = ECISReturnCodeConstants.RETURN_CODE_0000;

    // 予備線登録・更新・削除区分
    String reserveLineRegisterUpdateDelete = contractInfo.get(
        Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_LINE_REGISTER_UPDATE_DELETE_INDEX);
    // 予備電源登録・更新・削除区分
    String reservePowerRegisterUpdateDelete = contractInfo.get(
        Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_POWER_REGISTER_UPDATE_DELETE_INDEX);

    // 予備線登録・更新・削除区分が空文字
    // 予備電源登録・更新・削除区分が空文字の場合は、処理対象外
    if (StringUtils.isEmpty(reserveLineRegisterUpdateDelete)
        && StringUtils.isEmpty(reservePowerRegisterUpdateDelete)) {
      return returnCode;
    }

    // 契約IDの取得
    Integer contractId = paraContractId;

    // 契約IDがnullの場合
    if (contractId == null) {

      // 契約照会情報設定
      InquiryAgentContractBusinessBean inquiryBean = new InquiryAgentContractBusinessBean();
      // 契約番号
      inquiryBean.setContractNo(
          contractInfo.get(Custom_ContractManagementInformationFileConfigContract.DATA_CONTRACT_NO_INDEX));
      // 適用開始日
      inquiryBean.setInqCoveredDate(
          StringConvertUtil.stringToDate(contractInfo.get(
              Custom_ContractManagementInformationFileConfigContract.DATA_APPLY_START_DATE_INDEX),
              ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH));

      // 契約照会処理実行
      InquiryAgentContractBusinessBean inquiryResultBean = agentContractInformationBusiness.inquiry(inquiryBean);

      // リターンコードを取得する。
      returnCode = inquiryResultBean.getReturnCode();
      // リターンコードが0000（正常終了）以外の場合、エラーリストにメッセージを設定する
      if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(returnCode)) {
        return returnCode;
      }

      // 契約ID
      contractId = inquiryResultBean.getAgentContractInformationList().get(0).getContractId();
    }

    // 予備線契約情報の登録
    if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER.equals(reserveLineRegisterUpdateDelete)) {

      // 予備契約情報の取得
      RegistReserveContractBusinessBean registReserveBean = new RegistReserveContractBusinessBean();
      // 契約ID
      registReserveBean.setContractId(contractId);
      // 予備契約種別:予備線(0)
      registReserveBean.setReserveContractClass(
          StringConvertUtil.stringToInteger(ECISKJConstants.RESERVE_CONTRACT_CLASS_LINE));
      // 予備契約開始日
      registReserveBean.setReserveContractSd(
          StringConvertUtil.stringToDate(contractInfo.get(
              Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_LINE_CONTRACT_START_DATE_INDEX),
              ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH));
      // 予備契約終了日
      String reserveEndDate = contractInfo.get(
          Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_LINE_CONTRACT_END_DATE_INDEX);
      if (StringUtils.isNotEmpty(reserveEndDate)) {
        registReserveBean.setReserveContractEd(
            StringConvertUtil.stringToDate(reserveEndDate, ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH));
      }
      // 容量
      registReserveBean.setCapacity(
          StringConvertUtil.stringToBigDecimal(contractInfo.get(
              Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_LINE_CONTRACT_CAPACITY_INDEX)));

      // 予備契約情報登録実行
      RegistReserveContractBusinessBean registResultBean = reserveContractInformationBusiness
          .regist(registReserveBean);

      // リターンコードを取得する。
      returnCode = registResultBean.getReturnCode();
      // リターンコードが0000（正常終了）以外の場合、エラーリストにメッセージを設定する
      if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(returnCode)) {
        return returnCode;
      }
    }

    // 予備電源契約情報の登録
    if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_REGISTER.equals(reservePowerRegisterUpdateDelete)) {

      // 予備契約情報の取得
      RegistReserveContractBusinessBean registReserveBean = new RegistReserveContractBusinessBean();
      // 契約ID
      registReserveBean.setContractId(contractId);
      // 予備契約種別:予備電源(1)
      registReserveBean.setReserveContractClass(
          StringConvertUtil.stringToInteger(ECISKJConstants.RESERVE_CONTRACT_CLASS_POWER));
      // 予備契約開始日
      registReserveBean.setReserveContractSd(
          StringConvertUtil.stringToDate(contractInfo.get(
              Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_POWER_CONTRACT_START_DATE_INDEX),
              ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH));
      // 予備契約終了日
      String reserveEndDate = contractInfo.get(
          Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_POWER_CONTRACT_END_DATE_INDEX);
      if (StringUtils.isNotEmpty(reserveEndDate)) {
        registReserveBean.setReserveContractEd(
            StringConvertUtil.stringToDate(reserveEndDate, ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH));
      }
      // 容量
      registReserveBean.setCapacity(
          StringConvertUtil.stringToBigDecimal(contractInfo.get(
              Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_POWER_CONTRACT_CAPACITY_INDEX)));

      // 予備契約情報登録実行
      RegistReserveContractBusinessBean registResultBean = reserveContractInformationBusiness
          .regist(registReserveBean);

      // リターンコードを取得する。
      returnCode = registResultBean.getReturnCode();
      // リターンコードが0000（正常終了）以外の場合、エラーリストにメッセージを設定する
      if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(returnCode)) {
        return returnCode;
      }
    }

    // 予備線契約情報の更新
    if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_UPDATE.equals(reserveLineRegisterUpdateDelete)) {

      // 予備契約情報の取得
      UpdateReserveContractBusinessBean updateReserveBean = new UpdateReserveContractBusinessBean();
      // 契約ID
      updateReserveBean.setContractId(contractId);
      // 予備契約種別:予備線(0)
      updateReserveBean.setReserveContractClass(
          StringConvertUtil.stringToInteger(ECISKJConstants.RESERVE_CONTRACT_CLASS_LINE));
      // 予備契約開始日
      updateReserveBean.setReserveContractSd(
          StringConvertUtil.stringToDate(contractInfo.get(
              Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_LINE_CONTRACT_START_DATE_INDEX),
              ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH));
      // 予備契約終了日
      String reserveEndDate = contractInfo.get(
          Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_LINE_CONTRACT_END_DATE_INDEX);
      if (StringUtils.isNotEmpty(reserveEndDate)) {
        updateReserveBean.setReserveContractEd(
            StringConvertUtil.stringToDate(reserveEndDate, ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH));
      }
      // 容量
      updateReserveBean.setReserveContractCapacity(
          StringConvertUtil.stringToBigDecimal(contractInfo.get(
              Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_LINE_CONTRACT_CAPACITY_INDEX)));
      // 更新回数
      updateReserveBean.setUpdateCount(
          StringConvertUtil.stringToInteger(contractInfo.get(
              Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_LINE_UPDATE_COUNT_INDEX)));

      // 予備契約情報更新実行
      UpdateReserveContractBusinessBean updateResultBean = reserveContractInformationBusiness
          .update(updateReserveBean);

      // リターンコードを取得する。
      returnCode = updateResultBean.getReturnCode();
      // リターンコードが0000（正常終了）以外の場合、エラーリストにメッセージを設定する
      if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(returnCode)) {
        return returnCode;
      }
    }

    // 予備電源契約情報の更新
    if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_UPDATE.equals(reservePowerRegisterUpdateDelete)) {

      // 予備契約情報の取得
      UpdateReserveContractBusinessBean updateReserveBean = new UpdateReserveContractBusinessBean();

      // 契約ID
      updateReserveBean.setContractId(contractId);
      // 予備契約種別:予備電源(1)
      updateReserveBean.setReserveContractClass(
          StringConvertUtil.stringToInteger(ECISKJConstants.RESERVE_CONTRACT_CLASS_POWER));
      // 予備契約開始日
      updateReserveBean.setReserveContractSd(
          StringConvertUtil.stringToDate(contractInfo.get(
              Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_POWER_CONTRACT_START_DATE_INDEX),
              ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH));
      // 予備契約終了日
      String reserveEndDate = contractInfo.get(
          Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_POWER_CONTRACT_END_DATE_INDEX);
      if (StringUtils.isNotEmpty(reserveEndDate)) {
        updateReserveBean.setReserveContractEd(
            StringConvertUtil.stringToDate(reserveEndDate, ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH));
      }
      // 容量
      updateReserveBean.setReserveContractCapacity(
          StringConvertUtil.stringToBigDecimal(contractInfo.get(
              Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_POWER_CONTRACT_CAPACITY_INDEX)));
      // 更新回数
      updateReserveBean.setUpdateCount(
          StringConvertUtil.stringToInteger(contractInfo.get(
              Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_POWER_UPDATE_COUNT_INDEX)));

      // 予備契約情報更新実行
      UpdateReserveContractBusinessBean updateResultBean = reserveContractInformationBusiness
          .update(updateReserveBean);

      // リターンコードを取得する。
      returnCode = updateResultBean.getReturnCode();
      // リターンコードが0000（正常終了）以外の場合、エラーリストにメッセージを設定する
      if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(returnCode)) {
        return returnCode;
      }
    }

    // 予備線契約情報の削除
    if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_DELETE.equals(reserveLineRegisterUpdateDelete)) {

      // 予備契約情報の取得
      DeleteReserveContractBusinessBean deleteReserveBean = new DeleteReserveContractBusinessBean();
      // 契約ID
      deleteReserveBean.setContractId(contractId);
      // 予備契約種別:予備線(0)
      deleteReserveBean.setReserveContractClass(
          StringConvertUtil.stringToInteger(ECISKJConstants.RESERVE_CONTRACT_CLASS_LINE));
      // 予備契約開始日
      deleteReserveBean.setReserveContractSd(
          StringConvertUtil.stringToDate(contractInfo.get(
              Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_LINE_CONTRACT_START_DATE_INDEX),
              ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH));
      // 更新回数
      deleteReserveBean.setUpdateCount(
          StringConvertUtil.stringToInteger(contractInfo.get(
              Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_LINE_UPDATE_COUNT_INDEX)));

      // 予備契約情報削除実行
      DeleteReserveContractBusinessBean deleteResultBean = reserveContractInformationBusiness
          .delete(deleteReserveBean);

      // リターンコードを取得する。
      returnCode = deleteResultBean.getReturnCode();
      // リターンコードが0000（正常終了）以外の場合、エラーリストにメッセージを設定する
      if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(returnCode)) {
        return returnCode;
      }
    }

    // 予備電源契約情報の削除
    if (ECISKJConstants.REGISTER_UPDATE_DELETE_CATEGORY_DELETE.equals(reservePowerRegisterUpdateDelete)) {

      // 予備契約情報の取得
      DeleteReserveContractBusinessBean deleteReserveBean = new DeleteReserveContractBusinessBean();
      // 契約ID
      deleteReserveBean.setContractId(contractId);
      // 予備契約種別:予備電源(1)
      deleteReserveBean.setReserveContractClass(
          StringConvertUtil.stringToInteger(ECISKJConstants.RESERVE_CONTRACT_CLASS_POWER));
      // 予備契約開始日
      deleteReserveBean.setReserveContractSd(
          StringConvertUtil.stringToDate(contractInfo.get(
              Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_POWER_CONTRACT_START_DATE_INDEX),
              ECISConstants.FORMAT_DATE_yyyyMMdd_SLASH));
      // 更新回数
      deleteReserveBean.setUpdateCount(
          StringConvertUtil.stringToInteger(contractInfo.get(
              Custom_ContractManagementInformationFileConfigContract.DATA_RESERVE_POWER_UPDATE_COUNT_INDEX)));

      // 予備契約情報削除実行
      DeleteReserveContractBusinessBean deleteResultBean = reserveContractInformationBusiness
          .delete(deleteReserveBean);

      // リターンコードを取得する。
      returnCode = deleteResultBean.getReturnCode();
      // リターンコードが0000（正常終了）以外の場合、エラーリストにメッセージを設定する
      if (!ECISReturnCodeConstants.RETURN_CODE_0000.equals(returnCode)) {
        return returnCode;
      }
    }

    return returnCode;
  }

  /**
   * APIから返却したリターンコードを判定し、処理継続フラグを設定する。
   *
   * @param returnCode
   *          リターンコード
   * @return 処理継続フラグ
   */
  private String checkReturnCode(String returnCode) {

    // 処理継続フラグに初期値を設定する。
    String execFlag = ECISConstants.FLG_ON;

    // 引数.リターンコードを判定し、D023またはG017の場合、定数.オフ(0)(処理継続不能)を設定する。
    if (ECISReturnCodeConstants.RETURN_CODE_D023.equals(returnCode)
        || ECISReturnCodeConstants.RETURN_CODE_G017.equals(returnCode)) {

      execFlag = ECISConstants.FLG_OFF;
    }

    // 処理継続フラグを返却する
    return execFlag;
  }

  /**
   * 料金メニュー単価明細の内容を補足する。。
   *
   * @param rmUpDetail
   *          料金メニュー単価明細キー
   * @param applySd
   *          適用開始日
   */
  private void fillRmUpDetail(RmUpDetail rmUpDetail, Date applySd) {

    RmUpDetailExample rmUpDetailExample = new RmUpDetailExample();
    rmUpDetailExample.createCriteria()
        .andRmIdEqualTo(rmUpDetail.getRmId())
        .andDcecCatCodeEqualTo(rmUpDetail.getDcecCatCode())
        .andTsCodeEqualTo(rmUpDetail.getTsCode())
        .andBranchNoEqualTo(rmUpDetail.getBranchNo())
        .andUpApplySdLessThanOrEqualTo(applySd)
        .andUpCatCodeEqualTo(ECISConstants.UNIT_PRICE_SETTING_CATEGORY_DEF);

    List<RmUpDetail> rmUpDetailList = rmUpDetailMapper.selectByExample(rmUpDetailExample);
    ;

    if (rmUpDetailList.size() != 0) {
      rmUpDetail.setDisplayName1(rmUpDetailList.get(0).getDisplayName1());
      rmUpDetail.setDisplayName2(rmUpDetailList.get(0).getDisplayName2());
      rmUpDetail.setThreshold(rmUpDetailList.get(0).getThreshold());
      rmUpDetail.setThresholdName(rmUpDetailList.get(0).getThresholdName());
      rmUpDetail.setDisplayOrder(rmUpDetailList.get(0).getDisplayOrder());
      rmUpDetail.setDetailOutputOrder(rmUpDetailList.get(0).getDetailOutputOrder());
    }
  }

  /**
   * 契約者情報ビジネスのsetter（DI）
   *
   * @param contractorInformationBusiness
   *          契約者情報ビジネス
   */
  public void setContractorInformationBusiness(KJ_ContractorInformationBusiness contractorInformationBusiness) {
    this.contractorInformationBusiness = contractorInformationBusiness;
  }

  /**
   * 卸取次店向け契約者情報ビジネスのsetter(DI)
   * 
   * @param agentContractorInformationBusiness
   *          卸取次店向け契約者情報ビジネス
   */
  public void setAgentContractorInformationBusiness(
      KJ_AgentContractorInformationBusiness agentContractorInformationBusiness) {
    this.agentContractorInformationBusiness = agentContractorInformationBusiness;
  }

  /**
   * カスタム契約者情報ビジネスのsetter(DI)
   * 
   * @param agentContractorInformationBusiness
   *          カスタム契約者情報ビジネス
   */
  public void setCustomContractorInformationBusiness(
      Custom_KJ_CustomContractorInformationBusiness customContractorInformationBusiness) {
    this.customContractorInformationBusiness = customContractorInformationBusiness;
  }

  /**
   * 口座クレカ情報ビジネスのsetter（DI）
   *
   * @param accountCreditCardInformationBusiness
   *          口座クレカ情報ビジネス
   */
  public void setAccountCreditCardInformationBusiness(
      KJ_AccountCreditCardInformationBusiness accountCreditCardInformationBusiness) {
    this.accountCreditCardInformationBusiness = accountCreditCardInformationBusiness;
  }

  /**
   * 支払情報ビジネスのsetter（DI）
   *
   * @param paymentInformationBusiness
   *          支払情報ビジネス
   */
  public void setPaymentInformationBusiness(KJ_PaymentInformationBusiness paymentInformationBusiness) {
    this.paymentInformationBusiness = paymentInformationBusiness;
  }

  /**
   * カスタム支払履歴報ビジネスのsetter(DI)
   * 
   * @param customPaymentInformationBusiness
   *          カスタム支払履歴報ビジネス
   */
  public void setCustomPaymentInformationBusiness(
      Custom_KJ_CustomPaymentInformationBusiness customPaymentInformationBusiness) {
    this.customPaymentInformationBusiness = customPaymentInformationBusiness;
  }

  /**
   * 契約情報ビジネスのsetter（DI）
   *
   * @param contractInformationBusiness
   *          契約情報ビジネス
   */
  public void setContractInformationBusiness(KJ_ContractInformationBusiness contractInformationBusiness) {
    this.contractInformationBusiness = contractInformationBusiness;
  }

  /**
   * 卸取次店向け契約情報ビジネスのsetter(DI)
   * 
   * @param agentContractInformationBusiness
   *          卸取次店向け契約情報ビジネス
   */
  public void setAgentContractInformationBusiness(
      KJ_AgentContractInformationBusiness agentContractInformationBusiness) {
    this.agentContractInformationBusiness = agentContractInformationBusiness;
  }

  /**
   * カスタム契約情報ビジネスのsetter(DI)
   * 
   * @param customContractInformationBusiness
   *          カスタム契約情報ビジネス
   */
  public void setCustomContractInformationBusiness(
      Custom_KJ_CustomContractInformationBusiness customContractInformationBusiness) {
    this.customContractInformationBusiness = customContractInformationBusiness;
  }

  /**
   * 付帯契約情報ビジネスのsetter（DI）
   *
   * @param supplementaryContractInformationBusiness
   *          付帯契約情報ビジネス
   */
  public void setSupplementaryContractInformationBusiness(
      KJ_SupplementaryContractInformationBusiness supplementaryContractInformationBusiness) {
    this.supplementaryContractInformationBusiness = supplementaryContractInformationBusiness;
  }

  /**
   * メータ設置場所情報ビジネスのsetter（DI）
   *
   * @param meterLocationInformationBusiness
   *          メータ設置場所情報ビジネス
   */
  public void setMeterLocationInformationBusiness(
      KJ_MeterLocationInformationBusiness meterLocationInformationBusiness) {
    this.meterLocationInformationBusiness = meterLocationInformationBusiness;
  }

  /**
   * 卸取次店向けメータ設置場所情報ビジネスsetter(DI)
   * 
   * @param agentMeterLocationInformationBusiness
   *          卸取次店向けメータ設置場所情報ビジネス
   */
  public void setAgentMeterLocationInformationBusiness(
      KJ_AgentMeterLocationInformationBusiness agentMeterLocationInformationBusiness) {
    this.agentMeterLocationInformationBusiness = agentMeterLocationInformationBusiness;
  }

  /**
   * 予備契約情報ビジネスsetter(DI)
   * 
   * @param reserveContractInformationBusiness
   *          予備契約情報ビジネス
   */
  public void setReserveContractInformationBusiness(
      KJ_ReserveContractInformationBusiness reserveContractInformationBusiness) {
    this.reserveContractInformationBusiness = reserveContractInformationBusiness;
  }

  /**
   * 一括登録制御マッパーのsetter（DI）
   *
   * @param bulkRegisterControlMapper
   *          一括登録制御マッパー
   */
  public void setBulkRegisterControlMapper(
      BulkRegisterControlMapper bulkRegisterControlMapper) {
    this.bulkRegisterControlMapper = bulkRegisterControlMapper;
  }

  /**
   * 料金メニュー単価明細マスタマッパーのセッター(DI)
   *
   * @param rmUpDetailMapper
   *          料金メニュー単価明細マスタマッパー
   */
  public void setRmUpDetailMapper(RmUpDetailMapper rmUpDetailMapper) {
    this.rmUpDetailMapper = rmUpDetailMapper;
  }

  /**
   * プロパティのsetter（DI）
   *
   * @param applicationProperties
   *          プロパティ
   */
  public void setApplicationProperties(
      PropertiesFactoryBean applicationProperties) {
    this.applicationProperties = applicationProperties;
  }

  /**
   * メッセージソースのsetter（DI）
   *
   * @param messageSource
   *          メッセージソース
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }

  /**
   * トランザクションテンプレートのsetter（DI）
   *
   * @param transactionTemplateRequired
   *          トランザクションテンプレート
   */
  public void setTransactionTemplateRequired(TransactionTemplate transactionTemplateRequired) {
    this.transactionTemplateRequired = transactionTemplateRequired;
  }
}
