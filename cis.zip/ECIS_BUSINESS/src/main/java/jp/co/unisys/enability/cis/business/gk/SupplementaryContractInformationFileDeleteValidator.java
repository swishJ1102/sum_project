package jp.co.unisys.enability.cis.business.gk;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import jp.co.unisys.enability.cis.business.kj.model.ContractManagementInformationFileConfigCommon;
import jp.co.unisys.enability.cis.business.kj.model.ContractManagementInformationFileConfigSupplementaryContract;
import jp.co.unisys.enability.cis.common.util.CommonValidationUtil;
import jp.co.unisys.enability.cis.common.util.EMSMessageResource;

/**
 * バリデーション
 *
 * @author "Nihon Unisys, Ltd."
 */
public class SupplementaryContractInformationFileDeleteValidator {

  /** プロパティクラスを定義 */
  private EMSMessageResource emsMessageResource;

  /**
   * メッセージプロパティキー管理のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * メッセージプロパティキー管理を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param emsMessageResource
   *          メッセージプロパティキー管理
   */
  public void setEmsMessageResource(EMSMessageResource emsMessageResource) {
    this.emsMessageResource = emsMessageResource;
  }

  /**
   * のバリデーションを実施、チェック結果のメッセージListを返却する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 1 引数のバリデーションを行う。
   * 2 チェック結果がNGの場合、戻り値のメッセージListにエラーメッセージを詰めて返却する。
   *
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param args
   *          バッチ引数
   * @return メッセージList
   */
  public List<String> validate(Map<Integer, String> dataRecord) {

    List<String> messageList = new ArrayList<String>();

    String dataRecordClass = dataRecord
        .get(ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_INDEX);
    // データレコード種別：必須チェック
    if (CommonValidationUtil.isNull(dataRecordClass)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_NAME }));

      // データレコード種別：正規表現チェック
    } else if (dataRecordClass != null
        && !CommonValidationUtil
            .checkByPattern(
                dataRecordClass,
                ContractManagementInformationFileConfigCommon.DATA_KIND_MASK_STRING)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_ITEM_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigCommon.DATA_RECORD_KIND_NAME }));
    }

    String supplementaryContractId = dataRecord
        .get(ContractManagementInformationFileConfigSupplementaryContract.DATA_SUPPLEMENTARY_CONTRACT_ID_INDEX);
    // 付帯契約ID：必須チェック
    if (CommonValidationUtil.isNull(supplementaryContractId)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigSupplementaryContract.DATA_SUPPLEMENTARY_CONTRACT_ID_NAME }));

      // 付帯契約ID：文字種別チェック（半角数字）
    } else if (supplementaryContractId != null
        && !CommonValidationUtil.isNumric(supplementaryContractId)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigSupplementaryContract.DATA_SUPPLEMENTARY_CONTRACT_ID_NAME,
                      "半角数字" }));

      // 付帯契約ID：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (supplementaryContractId != null
        && !CommonValidationUtil
            .isRangeWordByECIS(supplementaryContractId)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigSupplementaryContract.DATA_SUPPLEMENTARY_CONTRACT_ID_NAME,
                      "半角数字（低圧CISシステム許容文字）" }));

      // 付帯契約ID：数値範囲チェック
    } else if (supplementaryContractId != null
        && !CommonValidationUtil.checkRange(supplementaryContractId, 1,
            2147483647)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_RANGE_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigSupplementaryContract.DATA_SUPPLEMENTARY_CONTRACT_ID_NAME,
                      "1～2147483647" }));
    }

    String updateCount = dataRecord
        .get(ContractManagementInformationFileConfigSupplementaryContract.DATA_UPDATE_COUNT_INDEX);
    // 更新回数：必須チェック
    if (CommonValidationUtil.isNull(updateCount)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REQUIREDSTRING_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigSupplementaryContract.DATA_UPDATE_COUNT_NAME }));

      // 更新回数：文字種別チェック（半角数字）
    } else if (updateCount != null
        && !CommonValidationUtil.isNumric(updateCount)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigSupplementaryContract.DATA_UPDATE_COUNT_NAME,
                      "半角数字" }));

      // 更新回数：文字種別チェック（半角数字　低圧CISシステム許容文字）
    } else if (updateCount != null
        && !CommonValidationUtil
            .isRangeWordByECIS(updateCount)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_REGEX_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigSupplementaryContract.DATA_UPDATE_COUNT_NAME,
                      "半角数字（低圧CISシステム許容文字）" }));

      // 更新回数：数値範囲チェック
    } else if (updateCount != null
        && !CommonValidationUtil.checkRange(updateCount, 0, 2147483647)) {
      messageList
          .add(emsMessageResource
              .getMessage(
                  EMSMessageResource.VALIDATION_RANGE_KEY,
                  new String[] {
                      ContractManagementInformationFileConfigSupplementaryContract.DATA_UPDATE_COUNT_NAME,
                      "0～2147483647" }));
    }
    return messageList;
  }
}
