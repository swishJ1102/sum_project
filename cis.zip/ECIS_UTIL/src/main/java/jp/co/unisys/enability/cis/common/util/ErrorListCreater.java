package jp.co.unisys.enability.cis.common.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.util.List;

import com.ibm.icu.text.SimpleDateFormat;
import com.ibm.icu.util.Calendar;

/**
 * メッセージ転換クラス.<br>
 * メッセージ文言と引数合わせて、表示用メッセージ生成する
 *
 */
public class ErrorListCreater {

  /**
   * 引数の情報を元にエラーリストファイルを出力する
   * 
   * @param moduleNumber
   *          モジュール番号
   * @param errorList
   *          エラーリスト内容
   * @param errorListDir
   *          出力先
   */
  public static String createErrorListTextFile(String moduleNumber, List<String> errorList, String errorListDir) {

    StringBuilder fileName = new StringBuilder();

    try {

      // ファイルname作成
      SimpleDateFormat sdFormat = new SimpleDateFormat(EMSConstants.FORMAT_DATE_yyyyMMddHHmmssSSS);
      String systemDate = sdFormat.format(Calendar.getInstance().getTime());

      fileName.append(EMSConstants.ERROR_LIST_PREFIX);
      fileName.append(moduleNumber);
      fileName.append(EMSConstants.UNDERLINE);
      fileName.append(EMSConstants.BATCH_USER);
      fileName.append(EMSConstants.UNDERLINE);
      fileName.append(systemDate);
      fileName.append(EMSConstants.FILE_EXTENSION_TXT);

      // ファイル存在チェック
      File direc = new File(errorListDir);
      // ディレクトリー存在チェックを行う。
      if (!direc.exists()) {
        // 存在しない場合、ディレクトリーを生成する。
        direc.mkdirs();
      }

      // ファイルを生成する。
      File file = new File(direc, fileName.toString());
      // ファイル存在チェックを行う。存在した場合、削除して、新規する。
      if (file.exists()) {
        file.delete();
      }

      file.createNewFile();

      // ファイル作成用出力ストリームを生成する。
      OutputStreamWriter outWriter = new OutputStreamWriter(new FileOutputStream(file), EMSConstants.ENCODE_TYPE_UTF8);
      StringBuffer stringBuf = new StringBuffer();

      for (int i = 0; i < errorList.size(); i++) {

        // エラー内容記入
        stringBuf.append(errorList.get(i)).append(EMSConstants.ENTER_CODE);
      }
      outWriter.write(stringBuf.toString());

      outWriter.close();

    } catch (Exception e) {

    }
    return fileName.toString();
  }

}
