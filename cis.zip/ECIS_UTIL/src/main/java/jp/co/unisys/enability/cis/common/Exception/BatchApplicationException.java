/*-------------------------------------------------------------------------------
 * All Rights Reserved. Copyright(C) Nihon Unisys, Ltd.
 * vendor : Nihon Unisys, Ltd.
 * since : 2015/02/06
 *-----------------------------------------------------------------------------*/
package jp.co.unisys.enability.cis.common.Exception;

/**
 * Batch例外クラス.<br>
 * Batchでの例外を通知するのに使用するクラスです。
 *
 */
public class BatchApplicationException extends ApplicationException {

  /** 処理結果コード */
  private int resultStatus;

  /**
   * 引数の例外を元にBatch例外を生成します。
   * 
   * @param t
   *          例外
   */
  public BatchApplicationException(Throwable t) {
    super(t);
  }

  /**
   * 引数の例外と処理結果コードを元にBatch例外を生成します。
   *
   * @param t
   *          例外
   * @param resultStatus
   *          処理結果コード
   */
  public BatchApplicationException(Throwable t, int resultStatus) {
    super(t);
    this.resultStatus = resultStatus;

  }

  /**
   * 引数の処理結果コードを元にBatch例外を生成します。
   * 
   * @param resultStatus
   *          処理結果コード
   */
  public BatchApplicationException(int resultStatus) {
    super();
    this.resultStatus = resultStatus;
  }

  /**
   * 引数の処理結果コードとメッセージを元にBatch例外を生成します。
   * 
   * @param resultStatus
   *          処理結果コード
   * @param logMessage
   *          メッセージ
   */
  public BatchApplicationException(int resultStatus, String logMessage) {
    super(logMessage);
    this.resultStatus = resultStatus;
  }

  /**
   * 引数の処理結果コードとメッセージを元にBatch例外を生成します。
   * 
   * @param t
   *          例外
   * @param resultStatus
   *          処理結果コード
   * @param logMessage
   *          メッセージ
   */
  public BatchApplicationException(Throwable t, int resultStatus, String logMessage) {
    super(logMessage, t);
    this.resultStatus = resultStatus;
  }

  /**
   * 処理結果コードのゲッター
   * 
   * @return resultStatus
   */
  public int getResultStatus() {
    return resultStatus;
  }

}
