package jp.co.unisys.enability.cis.common.util.constants;

import java.math.BigDecimal;

/**
 * 定数クラス
 *
 * @author "Nihon Unisys, Ltd."
 */
public class ECISRKConstants {

  /** 料金計算結果修正・補正 画面モード-編集モード */
  public static final String CORRECT_SCREEN_MODE_EDIT = "0";
  /** 料金計算結果修正・補正 画面モード-確認モード */
  public static final String CORRECT_SCREEN_MODE_CONFIRMATION = "1";
  /** 料金計算結果修正・補正 補正選択-選択 */
  public static final String CORRECTION_SELECTION_SELECTION = "1";
  /** 料金計算結果修正・補正 補正選択-未選択 */
  public static final String CORRECTION_SELECTION_UNSELECTION = "0";
  /** 料金計算結果修正・補正 補正追加有効-有効 */
  public static final Integer CORRECTION_ADD_ENABLE = 1;
  /** 料金計算結果修正・補正 補正追加有効-無効 */
  public static final Integer CORRECTION_ADD_DISABLE = 0;
  /** 料金計算結果修正・補正 削除対象外警告種別コード区切り文字 */
  public static final String CORRECTION_DELETE_EXCLUDED_WARNING_CLASS_CODE_DELIMITER = ",";
  /** 料金再現計算 結果-有効 */
  public static final int REPRODUCTION_CALCULATE_RESULT_FLAG_EFFECTIVE = 1;
  /** 料金再現計算 結果-無効 */
  public static final int REPRODUCTION_CALCULATE_RESULT_FLAG_REACTIVE = 0;
  /** 料金単価設定 単価選択-料金メニュー単価 */
  public static final String UNIT_PRICE_SETTING_SELECTION_RATE_MENU = "0";
  /** 料金単価設定 単価選択-燃調単価 */
  public static final String UNIT_PRICE_SETTING_SELECTION_FUEL_COST_ADJUST = "1";
  /** 料金単価設定 単価選択-再エネ単価 */
  public static final String UNIT_PRICE_SETTING_SELECTION_RENEWABLE_ENERGY = "2";
  /** 料金単価設定 単価選択-託送メニュー単価 */
  public static final String UNIT_PRICE_SETTING_SELECTION_CONSIGNMENT_RATE = "3";
  /** 料金単価設定 単価選択-予備契約単価 */
  public static final String UNIT_PRICE_SETTING_SELECTION_RESERVE_CONTRACT = "4";
  /** 料金単価設定 履歴表示-有効 */
  public static final String UNIT_PRICE_SETTING_HISTORY_DISPLAY_FLAG_EFFECTIVE = "1";
  /** 料金単価設定 履歴表示-無効 */
  public static final String UNIT_PRICE_SETTING_HISTORY_DISPLAY_FLAG_REACTIVE = "0";
  /** 料金ステータスマスタ 未確定 */
  public static final String CHARGE_STATUS_MASTER_UNFIXED = "1";
  /** 料金ステータスマスタ 確定 */
  public static final String CHARGE_STATUS_MASTER_FIXED = "2";
  /** 日割山最大数超過チェックビジネス 日割山最大数 */
  public static final int MAX_PRORATED_UNIT = 4;
  /** 警告種別マスタ 確定使用量訂正データ受信 */
  public static final String WARNING_CLASS_MASTER_FIX_USAGE_CORRECT_DATA_LINKAGE = "101";
  /** 警告種別マスタ 手動補正対象 */
  public static final String WARNING_CLASS_MASTER_MANUAL_CORRECTION_COVERED = "301";
  /** 警告種別マスタ 月額料金マイナス */
  public static final String WARNING_CLASS_MASTER_MONTHLY_CHARGE_MINUS = "302";
  /** 警告種別マスタ 指示数使用量不一致 */
  public static final String WARNING_CLASS_MASTER_INDICATION_NO_USAGE_NOT_EQUAL = "303";
  /** 警告種別マスタ 力率未設定 */
  public static final String WARNING_CLASS_MASTER_POWER_FACTOR_NOT_SETTING = "304";
  /** 警告種別マスタ クレカ有効期限間近 */
  public static final String WARNING_CLASS_MASTER_CREDIT_CARD_EXPIRATION_DATE_NEAR = "305";
  /** 警告種別マスタ 検針日数暦日数不一致 */
  public static final String WARNING_CLASS_MASTER_METER_READING_DAYS_MONTH_DAYS_NOT_EQUAL = "351";
  /** 警告種別マスタ 高圧協議制の契約電力超過 */
  public static final String WARNING_CLASS_MASTER_HIGH_VOLT_DISCUSS_POWER_EXCESS = "355";
  /** 警告種別マスタ 高圧協議制の契約電力超過（複数日割山） */
  public static final String WARNING_CLASS_MASTER_HIGH_VOLT_DISCUSS_POWER_EXCESS_MULTI_PRORATED = "356";
  /** 警告種別マスタ 高圧協議制の契約電力超過（予備契約あり） */
  public static final String WARNING_CLASS_MASTER_HIGH_VOLT_DISCUSS_POWER_EXCESS_RESERVE_CONTRACT = "357";
  /** 警告種別マスタ 日割山最大数超過 */
  public static final String WARNING_CLASS_MASTER_PRORATED_UNIT_MAX = "358";
  /** 警告種別マスタ 過去分未請求停電情報あり */
  public static final String WARNING_CLASS_MASTER_PAST_UNCLAIMED_BLACKOUT_EXIST = "359";
  /** 警告種別マスタ 高圧協議制の契約超過金計算済み */
  public static final String WARNING_CLASS_MASTER_HIGH_VOLT_DISCUSS_EXCESS_CHARGE = "363";
  /** 警告対応区分マスタ：対応不要 */
  public static final String WARNING_DEAL_CATEGORY_MASTER_UNNECESSARY = "1";
  /** 警告対応区分マスタ：対応要 */
  public static final String WARNING_DEAL_CATEGORY_MASTER_NECESSARY = "2";
  /** 警告対応区分マスタ：対応済み */
  public static final String WARNING_DEAL_CATEGORY_MASTER_COMPLETED = "3";
  /** 確定料金実績内訳区分コード：(101：基本料金) */
  public static final String FIX_CHARGE_RESULT_BREAKDOWN_CATEGORY_CODE_FOR_BASIC_CHARGE = "101";
  /** 確定料金実績内訳区分コード：(102：最低料金) */
  public static final String FIX_CHARGE_RESULT_BREAKDOWN_CATEGORY_CODE_FOR_MINIMUM_CHARGE = "102";
  /** 確定料金実績内訳区分コード：(201：従量料金) */
  public static final String FIX_CHARGE_RESULT_BREAKDOWN_CATEGORY_CODE_FOR_USAGE_CHARGE = "201";
  /** 確定料金実績内訳区分コード：(202：燃料費調整額) */
  public static final String FIX_CHARGE_RESULT_BREAKDOWN_CATEGORY_CODE_FOR_FUEL_COST_ADJUSTMENT = "202";
  /** 確定料金実績内訳区分コード：(301：最低金額適用前付帯金額) */
  public static final String FIX_CHARGE_RESULT_BREAKDOWN_CATEGORY_CODE_FOR_BEFORE_MINIMUM_CHARGE_APPLY_SUPPLEMENTARY_AMOUNT = "301";
  /** 確定料金実績内訳区分コード：(302：最低金額適用後付帯金額) */
  public static final String FIX_CHARGE_RESULT_BREAKDOWN_CATEGORY_CODE_FOR_AFTER_MINIMUM_CHARGE_APPLY_SUPPLEMENTARY_AMOUNT = "302";
  /** 確定料金実績内訳区分コード：(401：最低月額料金) */
  public static final String FIX_CHARGE_RESULT_BREAKDOWN_CATEGORY_CODE_FOR_MINIMUM_MONTHLY_CHARGE = "401";
  /** 確定料金実績内訳区分コード：(501：再エネ賦課金) */
  public static final String FIX_CHARGE_RESULT_BREAKDOWN_CATEGORY_CODE_FOR_RENEWABLE_ENERGY_CHARGE = "501";
  /** 確定料金実績内訳区分コード：(801：制限中止割引額) */
  public static final String FIX_CHARGE_RESULT_BREAKDOWN_CATEGORY_CODE_FOR_RESTRICTION_DISCOUNT_CHARGE = "801";
  /** 確定料金実績内訳区分コード：(901：電気料金補正額) */
  public static final String FIX_CHARGE_RESULT_BREAKDOWN_CATEGORY_CODE_FOR_ELEC_CHARGE_CRT_AMOUNT = "901";
  /** 確定料金実績内訳区分コード：(902：再エネ賦課金補正額) */
  public static final String FIX_CHARGE_RESULT_BREAKDOWN_CATEGORY_CODE_FOR_RENEWABLE_ENERGY_CHARGE_CRT_AMOUNT = "902";
  /** 確定料金実績内訳区分コード：(903：契約超過金補正額) */
  public static final String FIX_CHARGE_RESULT_BREAKDOWN_CATEGORY_CODE_FOR_CONTRACT_EXCEEDED_AMOUNT = "903";
  /** 計器区分コード：(1：常用) */
  public static final String METER_CATEGORY_CODE_FOR_IN_COMMON = "1";
  /** 計器区分コード：(2：予備A) */
  public static final String METER_CATEGORY_CODE_FOR_RESERVE_A = "2";
  /** 計器区分コード：(3：予備B) */
  public static final String METER_CATEGORY_CODE_FOR_RESERVE_B = "3";
  /** 計器区分コード：(4：付帯) */
  public static final String METER_CATEGORY_CODE_FOR_SUPPLEMENTARY = "4";
  /** 計器区分コード：(5：付帯外) */
  public static final String METER_CATEGORY_CODE_FOR_SUPPLEMENTARY_OUTSIDE = "5";
  /** 計器区分コード：(9：その他) */
  public static final String METER_CATEGORY_CODE_FOR_OTHER = "9";
  /** 月次実績エラー区分マスタ 通常（エラーなし） */
  public static final String MONTHLY_USAGE_RESULT_ERROR_CATEGORY_MASTER_NO_ERROR = "0";
  /** 月次実績エラー区分マスタ 無視 */
  public static final String MONTHLY_USAGE_RESULT_ERROR_CATEGORY_MASTER_IGNORE = "1";
  /** 月次実績エラー区分マスタ エラー */
  public static final String MONTHLY_USAGE_RESULT_ERROR_CATEGORY_MASTER_ERROR = "2";
  /** 個別設定：必須 */
  public static final String INDIVIDUAL_SETTING_REQUIRED = "必須";
  /** 個別設定：不可 */
  public static final String INDIVIDUAL_SETTING_IMPOSSIBLE = "不可";
  /** 付帯種別コード：定額（1） */
  public static final String SUPPLEMENTARY_CLASS_CODE_FIXED_AMOUNT = "1";
  /** 付帯種別コード：定率（2） */
  public static final String SUPPLEMENTARY_CLASS_CODE_FIXED_RATE = "2";
  /** 付帯単価設定 単価履歴表示数 */
  public static final int SUPPLEMENTARY_MENU_UNIT_PRICE_HISTORY_SIZE = 13;
  /** 登録最大日付 */
  public static final String REGISTER_MAX_DATE = "9999/12/31";
  /** 率取得時の除算値 */
  public static final BigDecimal RATE_DIVIDE_VAL = BigDecimal.valueOf(100);
  /** 仕訳マスタ：仕訳なし（全量） */
  public static final String CATEGORIZE_MASTER_NOT_CATEGORIZE = "1";
  /** 提供可否コード：可 */
  public static final String PROVIDE_CHECK_MASTER_APPLICABLE = "0";
  /** 提供可否コード：否 */
  public static final String PROVIDE_CHECK_MASTER_NOT_APPLICABLE = "1";
  /** 電圧区分：低圧 */
  public static final String VOLTAGE_CATEGORY_LOW_TENSION = "低圧";
  /** 乗率：CTなし */
  public static final Integer MULTIPLYING_FACTOR_NO_CT = 1;
  /** 付帯単価設定 フィールド名：額 */
  public static final String SUPPLEMENTARY_UNIT_PRICE_FIELD_NAME_AMOUNT = "額";
  /** 付帯単価設定 フィールド名：率 */
  public static final String SUPPLEMENTARY_UNIT_PRICE_FIELD_NAME_RATE = "率";
  /** 切り捨て */
  public static final int ROUNDMODE_DOWN = 1;
  /** 切り上げ */
  public static final int ROUNDMODE_UP = 2;
  /** 四捨五入 */
  public static final int ROUNDMODE_HALF_UP = 3;
  /** 最低月額料金適用 */
  public static final String MONTHLY_MIN_FEE_APPLY = "1";
  /** 最低月額料金適用外 */
  public static final String MONTHLY_MIN_FEE_APPLY_NOT = "0";
  /** 力率：80 */
  public static final long POWER_FACTOR_EIGHTY = 80;
  /** 力率：85 */
  public static final long POWER_FACTOR_EIGHTY_FIVE = 85;
  /** 力率：90 */
  public static final long POWER_FACTOR_NINETY = 90;
  /** 計算係数：1 */
  public static final String CALCULATION_COEFFICIENT = "1";
  /** 計算係数：0.5 */
  public static final String CALCULATION_COEFFICIENT_HALF = "0.5";
  /** 料金単価設定 単価履歴表示数 */
  public static final int RATE_MENU_UNIT_PRICE_HISTORY_SIZE = 13;
  /** 連動セレクトボックス用区切り文字：コロン */
  public static final String INTERLOCK_SELECTBOX_DELIMITER_COLON = ":";
  /** 連動セレクトボックス用区切り文字：カンマ */
  public static final String INTERLOCK_SELECTBOX_DELIMITER_COMMA = ",";
  /** 計器区分コード正常値分割用：カンマ */
  public static final String DELIMITER_METER_CATEGORY_CODE_COMMA = ",";
  /** 期間を表す文字列：全角波線 */
  public static final String TERM_NAMISEN_ZENKAKU = "～";
  /** メッセージ内項目区切り文字：カンマ */
  public static final String DELIMITER_ITEMS_COMMA = ",";
  /** メッセージ内項目区切り文字：全角空白 */
  public static final String DELIMITER_ITEMS_SPACE_ZENKAKU = "　";
  /** 取得元情報名のプロパティ名 */
  public static final String CALC_DETAIL_PREFIX_DATA = "getInformation";
  /** 取得元項目名のプロパティ名 */
  public static final String CALC_DETAIL_PREFIX_ITEM = "getItemName";
  /** 取得元情報名と項目名のセットの最大数 */
  public static final int CALC_DETAIL_ITEM_NUM = 20;
  /** 日付フォーマット：yyyy-MM-dd */
  public static final String CALC_FORMAT_DATE_yyyyMMdd_HYPHEN = "yyyy-MM-dd";
  /** 演算方式代入：無条件に代入 */
  public static final String CALC_WRITE_UNCONDITIONAL = "0";
  /** 演算方式代入：nullの場合、代入しない */
  public static final String CALC_WRITE_NOT_NULL_PROC = "1";
  /** 演算方式代入：0の場合、代入しない */
  public static final String CALC_WRITE_NOT_ZERO_PROC = "2";
  /** 演算方式代入：nullか0の場合、代入しない */
  public static final String CALC_WRITE_NOT_NULL_OR_ZERO_PROC = "3";
  /** 演算方式代入 */
  public static final String CALC_RESERVED_OPERATION_SET = "SET";
  /** 処理結果へのアクセス */
  public static final String CALC_RESERVED_DATA_RESULT = "RESULT";
  /** 予約後定数 */
  public static final String CALC_RESERVED_DATA_CONST = "CONST";
  /** 適用される割引契約をすべて取得する定数 */
  public static final String CALC_RESERVED_DATA_ALL_RECORD = "ALL";
  /** 契約容量：範囲指定区切り文字 */
  public static final String CAPACITY_SELECTABLE_RANGE_DELIMITER = ",";
  /** 契約容量：範囲指定文字 */
  public static final String CAPACITY_SELECTABLE_RANGE_RANGE_SYMBOL = "-";
  /** 契約容量：範囲指定最大数 */
  public static final int CAPACITY_SELECTABLE_RANGE_MAX_BOUNDS = 2;
  /** 連動リストボックスタグ文字：span（開始） */
  public static final String INTERLOCK_SELECTBOX_TAG_SPAN_START = "<span>";
  /** 連動リストボックスタグ文字：span（終了） */
  public static final String INTERLOCK_SELECTBOX_TAG_SPAN_END = "</span>";
  /** 連動リストボックスタグ文字：ul（開始） */
  public static final String INTERLOCK_SELECTBOX_TAG_UL_START = "<ul>";
  /** 連動リストボックスタグ文字：ul（終了） */
  public static final String INTERLOCK_SELECTBOX_TAG_UL_END = "</ul>";
  /** 連動リストボックスタグ文字：li（開始）及び値の開始 */
  public static final String INTERLOCK_SELECTBOX_TAG_LI_AND_VALUE_START = "<li data-value='";
  /** 連動リストボックスタグ文字：li（終了） */
  public static final String INTERLOCK_SELECTBOX_TAG_LI_END = "</li>";
  /** 連動リストボックスタグ文字：値の終了 */
  public static final String INTERLOCK_SELECTBOX_TAG_VALUE_END = "'>";
  /** DB更新項目名：オンライン更新ユーザID */
  public static final String UPDATE_ITEM_NAME_ONLINE_UPDATE_USER_ID = "onlineUpdateUserId";
  /** DB更新項目名：オンライン更新日時 */
  public static final String UPDATE_ITEM_NAME_ONLINE_UPDATE_TIME = "onlineUpdateTime";
  /** 料金計算結果修正・補正 表示名称1 */
  public static final String CORRECTION_FIX_CHARGE_RESULT_BREAKDOWN_DISPLAY_NAME_CORRECTION_AMOUNT = "補正額";
  /** 料金計算結果修正・補正 補正分類コード:電気料金補正額 */
  public static final String CORRECTION_FIX_CHARGE_CATEGORY_CODE_FOR_ELEC_CHARGE = "1";
  /** 料金計算結果修正・補正 補正分類コード:再エネ賦課金補正額 */
  public static final String CORRECTION_FIX_CHARGE_CATEGORY_CODE_FOR_RENEWABLE_ENERGY_CHARGE = "2";
  /** 料金計算結果修正・補正 補正分類コード:契約超過金補正額 */
  public static final String CORRECTION_FIX_CHARGE_CATEGORY_CODE_FOR_CONTRACT_EXCEEDED_CHARGE = "3";
  /** 料金計算結果修正・補正 計器交換有無:有 */
  public static final String CORRECTION_METER_REPLACEMENT_CHECK_TRUE = "有";
  /** 料金計算結果修正・補正 計器交換有無:無 */
  public static final String CORRECTION_METER_REPLACEMENT_CHECK_FALSE = "無";
  /** 料金計算結果修正・補正 アクション戻り値：検索 */
  public static final String CORRECTION_ACTION_RESALUT_STRING_SEARCH = "search";
  /** 料金計算結果修正・補正 アクション戻り値：更新 */
  public static final String CORRECTION_ACTION_RESALUT_STRING_UPDATE = "update";
  /** 料金計算結果修正・補正 画目項目物理名：使用量（変更後） */
  public static final String CORRECTION_SCREEN_PHYSICAL_USAGE_QUANTITY_CHG_AFT = "usageQuantityChgAft";
  /** 料金計算結果修正・補正 画目項目物理名：金額（変更後） */
  public static final String CORRECTION_SCREEN_PHYSICAL_AMOUNT_CHG_AFT = "amountChgAft";
  /** 料金計算結果修正・補正 画目項目物理名：補正選択 */
  public static final String CORRECTION_SCREEN_PHYSICAL_CRT_SELECTION = "crtSelection";
  /** 料金計算結果修正・補正 画目項目物理名：補正分類 */
  public static final String CORRECTION_SCREEN_PHYSICAL_CORRECTION_CATEGOY = "correctionCategoy";
  /** 料金計算結果修正・補正 画目項目物理名：補正額 */
  public static final String CORRECTION_SCREEN_PHYSICAL_AMOUNT_CHGAFT = "amountChgAft";
  /** 料金計算結果修正・補正 画目項目物理名：項目名称 */
  public static final String CORRECTION_SCREEN_PHYSICAL_DISPLAY_NAME2 = "displayName2";
  /** DECIMALフォーマット：#,###,###,##0 */
  public static final String FORMAT_DECIMAL_COMMA_SCALE_10_0 = "#,###,###,##0";
  /** DECIMALフォーマット：#,###,###,##0.00 */
  public static final String FORMAT_DECIMAL_COMMA_SCALE_10_2 = "#,###,###,##0.00";
  /** validasionチェック用：最大文字数(1) */
  public static final int MAX_DEGIT_1 = 1;
  /** validasionチェック用：最大文字数(5) */
  public static final int MAX_DEGIT_5 = 5;
  /** validasionチェック用：最大文字数(30) */
  public static final int MAX_DEGIT_30 = 30;
  /** validasionチェック用：整数部桁数(7) */
  public static final int PRECISION_7 = 7;
  /** validasionチェック用：整数部桁数(9) */
  public static final int PRECISION_9 = 9;
  /** validasionチェック用：整数部桁数(10) */
  public static final int PRECISION_10 = 10;
  /** validasionチェック用：小数部桁数(0) */
  public static final int SCALE_0 = 0;
  /** validasionチェック用：小数部桁数(2) */
  public static final int SCALE_2 = 2;
  /** validasionチェック用：小数部桁数(3) */
  public static final int SCALE_3 = 3;
  /** validasionチェックプレースホルダ用：最大文字数(1) */
  public static final String MAX_DEGIT_PLACEHOLDER_1 = "1";
  /** validasionチェックプレースホルダ用：最大文字数(5) */
  public static final String MAX_DEGIT_PLACEHOLDER_5 = "5";
  /** validasionチェックプレースホルダ用：最大文字数(30) */
  public static final String MAX_DEGIT_PLACEHOLDER_30 = "30";
  /** validasionチェックプレースホルダ用：整数部桁数(7) */
  public static final String PRECISION_PLACEHOLDER_7 = "7";
  /** validasionチェックプレースホルダ用：整数部桁数(9) */
  public static final String PRECISION_PLACEHOLDER_9 = "9";
  /** validasionチェックプレースホルダ用：整数部桁数(10) */
  public static final String PRECISION_PLACEHOLDER_10 = "10";
  /** validasionチェックプレースホルダ用：小数部桁数(0) */
  public static final String SCALE_PLACEHOLDER_0 = "0";
  /** validasionチェックプレースホルダ用：小数部桁数(2) */
  public static final String SCALE_PLACEHOLDER_2 = "2";
  /** validasionチェックプレースホルダ用：小数部桁数(3) */
  public static final String SCALE_PLACEHOLDER_3 = "3";
  /** validasionチェック用：数値フォーマット(数値形式（マイナス符号：可、カンマ：否、小数：可）) */
  public static final String NUMBER_FORMAT_CHECK_REGEX_SIGN1_COMMA0_SCALE1 = "^([-]?([1-9][0-9]*|0){1}(\\.[0-9]+)?)?$";
  /** validasionチェック用：数値フォーマット(数値形式（マイナス符号：可、カンマ：可、小数：可）) */
  public static final String NUMBER_FORMAT_CHECK_REGEX_SIGN1_COMMA1_SCALE1 = "^([-]?(0|([1-9][0-9]{0,2}(,[0-9]{3})*)){1}(\\.[0-9]+)?)?$|^([-]?([1-9][0-9]*|0){1}(\\.[0-9]+)?)?$";
  /** validasionチェック用：数値フォーマット(数値形式（マイナス符号：可、カンマ：否、小数：否）) */
  public static final String NUMBER_FORMAT_CHECK_REGEX_SIGN1_COMMA0_SCALE0 = "^([-]?([1-9][0-9]*|0){1})?$";
  /** validasionチェック用：数値フォーマット(数値形式（マイナス符号：可、カンマ：可、小数：否）) */
  public static final String NUMBER_FORMAT_CHECK_REGEX_SIGN1_COMMA1_SCALE0 = "^([-]?(0|([1-9][0-9]{0,2}(,[0-9]{3})*)){1})?$|^([-]?([1-9][0-9]*|0){1})?$";
  /** validasionチェック用：数値フォーマット(数値形式（マイナス符号：否、カンマ：可、小数：否）) */
  public static final String NUMBER_FORMAT_CHECK_REGEX_SIGN0_COMMA1_SCALE0 = "^((0|([1-9][0-9]{0,2}(,[0-9]{3}))*){1})?$|^(([1-9][0-9]*|0){1})?$";
  /** validasionチェック用：数値フォーマット(数値形式（マイナス符号：否、カンマ：可、小数：可）) */
  public static final String NUMBER_FORMAT_CHECK_REGEX_SIGN0_COMMA1_SCALE1 = "^((0|([1-9][0-9]{0,2}(,[0-9]{3})*)){1}(\\.[0-9]+)?)?$|^(([1-9][0-9]*|0){1}(\\.[0-9]+)?)?$";
  /** validasionチェック用：数値フォーマット(数値形式（マイナス符号：否、カンマ：否、小数：否）) */
  public static final String NUMBER_FORMAT_CHECK_REGEX_SIGN0_COMMA0_SCALE0 = "^(([1-9][0-9]*|0){1})?$";
  /** validasionチェック用：数値フォーマット(数値形式（マイナス符号：否、カンマ：否、小数：可）) */
  public static final String NUMBER_FORMAT_CHECK_REGEX_SIGN0_COMMA0_SCALE1 = "^(([1-9][0-9]*|0){1}(\\.[0-9]+)?)?$";
  /** validasionチェック用：半角英字 */
  public static final String HALF_ALPHABET_REGEX = "^[a-zA-Z]*$";
  /** validasionチェックプレースホルダ用：最大文字数(9) */
  public static final String MAX_DEGIT_PLACEHOLDER_9 = "9";
  /** validasionチェックプレースホルダ用：最大文字数(2) */
  public static final String MAX_DEGIT_PLACEHOLDER_2 = "2";
  /** validasionチェック用：整数部桁数(4) */
  public static final int PRECISION_4 = 4;
  /** validasionチェックプレースホルダ用：整数部桁数(4) */
  public static final String PRECISION_PLACEHOLDER_4 = "4";
  /** 単価履歴削除可能最低件数(2) */
  public static final int POSSIBLE_DELETE_UNIT_PRICE_HISTORY_MIN_SIZE = 2;
  /** 丸めしない */
  public static final int ROUNDMODE_OFF = 99;
  /** DECIMALフォーマット：#,###,###,##0.## */
  public static final String FORMAT_DECIMAL_COMMA_SCALE_10_2_SHARP = "#,###,###,##0.##";
  /** 再現計算画面 付帯メニュー名区切り文字 */
  public static final String SUPPLEMENTARY_MENU_NAME_DELIMITER = "、";
  /** 料金実績情報ダウンロード：エリアマスタ_ソート条件 */
  public static final String SRK040101_AREAM_ORDER_BY_CLAUSE = "area_code ASC";
  /** 料金実績情報ダウンロード：ファイル名接頭辞_確定料金実績情報ファイル */
  public static final String SRK040101_FILENAME_PREFIX_FIX_CHARGE_RESULT_INFO = "FRK0401-01_";
  /** 料金実績情報ダウンロード：ファイル名接頭辞_確定料金実績内訳ファイル */
  public static final String SRK040101_FILENAME_PREFIX_FIX_CHARGE_RESULT_BREAKDOWN = "FRK0401-02_";
  /** 空文字 */
  public static final String EMPTY_STRING = "";
  /** 外部ファイル取得失敗エラーメッセージ */
  public static final String IO_EXCEPTION = "外部ファイルが取得できません";
  /** DECIMALフォーマット（カンマなし）小数部2桁：#######0.00 */
  public static final String FORMAT_DECIMAL_SCALE_10_2 = "#######0.00";
  /** DECIMALフォーマット（カンマなし）小数部3桁：#######0.000 */
  public static final String FORMAT_DECIMAL_SCALE_10_3 = "#######0.000";
  /** validasionチェック用：最大文字数(200) */
  public static final int MAX_DEGIT_200 = 200;
  /** validasionチェックプレースホルダ用：最大文字数(200) */
  public static final String MAX_DEGIT_PLACEHOLDER_200 = "200";
  /** 数値フォーマット：FMB999990.99 */
  public static final String FORMAT_DECIMAL_SCALE_6_2_FMB = "FMB999990.99";
  /** DECIMALフォーマット：###,##0.## */
  public static final String FORMAT_DECIMAL_COMMA_SCALE_6_2_SHARP = "###,##0.##";
  /** 割り算、小数点以下桁数 */
  public static final int DIVIDE_DECIMAL_SCALE = 5;
  /** 計算結果検索：警告対応区分マスタ_ソート条件 */
  public static final String SRK010501_WARNING_DEAL_CAT_M_ORDER_BY_CLAUSE = "warning_deal_cat_code ASC";
  /** 計算結果検索：電圧区分マスタ_ソート条件 */
  public static final String SRK010501_VOLTAGE_CAT_M_ORDER_BY_CLAUSE = "voltage_cat_code ASC";
  /** 計算結果検索：契約電力決定区分マスタ_ソート条件 */
  public static final String SRK010501_CCD_CATEGORY_M_ORDER_BY_CLAUSE = "cc_decision_category_code ASC";
  /** 計算結果検索：料金ステータスマスタ_ソート条件 */
  public static final String SRK010501_CMS_M_ORDER_BY_CLAUSE = "cs_code ASC";
  /** 計算結果検索：送受電区分マスタ_ソート条件 */
  public static final String SRK010501_TRANSMISSION_CAT_M_ORDER_BY_CLAUSE = "transmission_cat_code ASC";
  /** 計算結果検索：警告種別マスタ_ソート条件 */
  public static final String SRK010501_WARNING_CLASS_M_ORDER_BY_CLAUSE = "warning_class_code ASC";
  /** 計算結果検索：確定料金実績_ソート条件 */
  public static final String SRK010501_FCR_ORDER_BY_CLAUSE = "fcr_id ASC";
  /** 計算結果検索：アクション戻り値：確定 */
  public static final String CORRECTION_ACTION_RESALUT_STRING_CONFIRM = "confirm";
  /** 計算結果検索：アクション戻り値：確定取消 */
  public static final String CORRECTION_ACTION_RESALUT_STRING_CONFIRM_CANCEL = "confirmCancel";
  /** JSONリスト名：計算結果検索 */
  public static final String JSON_LIST_NAME_CALCULATE_RESULT_SEARCH = "calculateResultSearchListJson";
  /** CSV取得結果項目名接頭辞 */
  public static final String CSV_RESULT_COLUMN_NAME_PREFIX = "column_";
  /** 消費税率判定方法：基準日1 */
  public static final String CONSUMPTION_TAX_RATE_JUDGE_FLAG_DATE1 = "1";
  /** BigDecimal初期値：0.00 */
  public static final BigDecimal BIG_DECIMAL_ZERO_SCALE2 = new BigDecimal("0.00");
  /** 料金実績情報ダウンロード：ファイル名接頭辞_確定料金実績情報ZIPファイル */
  public static final String SRK040101_FILENAME_PREFIX_FIX_CHARGE_RESULT_INFO_ZIP_FILE = "FRK0401_";
  /** 30分電力量異常チェックビジネス：需要実績ソート順 */
  public static final String CHECK_INVALID_POWER_CONSUMPTION_DEMAND_RESULT_ORDER_BY_CLAUSE = "fu_covered_date ASC";
  /** 契約期間外チェックビジネス：需要実績ソート順 */
  public static final String CHECK_OUTSIDE_CONTRACT_TERM_DEMAND_RESULT_ORDER_BY_CLAUSE = "fu_covered_date ASC";
  /** 確定使用量情報反映ビジネス：需要実績ソート順 */
  public static final String FIX_USAGE_APPLY_DEMAND_RESULT_ORDER_BY_CLAUSE = "fu_covered_date ASC";
  /** 料金単価設定：料金メニュー単価取得_ソート条件 */
  public static final String SRK020201_RM_UP_ORDER_BY_CLAUSE = "up_apply_sd DESC";
  /** 料金単価設定：料金メニュー単価明細取得_ソート条件 */
  public static final String SRK020201_RM_UP_DETAIL_ORDER_BY_CLAUSE = "dcec_cat_code ASC, display_order ASC, detail_output_order ASC";
  /** 料金単価設定：託送メニュー単価取得_ソート条件 */
  public static final String SRK020201_CR_UP_ORDER_BY_CLAUSE = "up_apply_sd DESC";
  /** 料金単価設定：託送メニュー単価明細取得_ソート条件 */
  public static final String SRK020201_CR_UP_DETAIL_ORDER_BY_CLAUSE = "dcec_cat_code ASC, ts_code ASC, branch_no ASC";
  /** 料金単価設定：燃調単価取得_ソート条件 */
  public static final String SRK020201_FCA_UP_M_ORDER_BY_CLAUSE = "up_apply_sd DESC";
  /** 料金単価設定：再エネ単価取得_ソート条件 */
  public static final String SRK020201_REC_UP_M_ORDER_BY_CLAUSE = "up_apply_sd DESC";
  /** 料金単価設定：予備契約単価取得_ソート条件 */
  public static final String SRK020201_RC_UP_M_ORDER_BY_CLAUSE = "up_apply_sd DESC";
  /** 付帯単価設定：付帯メニュー取得_ソート条件 */
  public static final String SRK020202_SPM_ORDER_BY_CLAUSE = "display_order ASC";
  /** 付帯単価設定：付帯メニュー単価取得_ソート条件 */
  public static final String SRK020202_SPM_UP_ORDER_BY_CLAUSE = "up_apply_sd DESC";
  /** 付帯単価：金額 小数点以下桁数 */
  public static final int SUPPLEMENTARY_UNIT_PRICE_AMOUNT_DECIMAL_SCALE = 2;
  /** 付帯単価：率 小数点以下桁数 */
  public static final int SUPPLEMENTARY_UNIT_PRICE_RATE_DECIMAL_SCALE = 1;
  /** 料金計算結果修正・補正：警告対応区分マスタ取得_ソート条件 */
  public static final String SRK010601_WARNING_DEAL_CAT_M_ORDER_BY_CLAUSE = "warning_deal_cat_code ASC";
  /** 料金計算結果修正・補正：補正分類マスタ取得_ソート条件 */
  public static final String SRK010601_CORRECTION_CATEGOY_M_ORDER_BY_CLAUSE = "correction_cat_code ASC";
  /** 料金計算オンライン共通：確定料金実績内訳取得_ソート条件 */
  public static final String RK_ONLINE_COMMON_FCRBREAKDOWN_ORDER_BY_CLAUSE = "display_order ASC, detail_output_order ASC";
  /** 料金計算オンライン共通：確定使用量取得_ソート条件 */
  public static final String RK_ONLINE_COMMON_FU_ORDER_BY_CLAUSE = "fu_id DESC";
  /** 確定使用量情報反映ビジネス：確定使用量ソート順 */
  public static final String FIX_USAGE_APPLY_FIX_USAGE_ORDER_BY_CLAUSE = "usage_ed DESC";
  /** 確定料金実績の利用年月最大値取得_ソート条件 */
  public static final String SRK020201_FCR_ORDER_BY_CLAUSE = "use_period DESC";
  /** validasionチェック用：整数部桁数(3) */
  public static final int PRECISION_3 = 3;
  /** validasionチェック用：整数部桁数(5) */
  public static final int PRECISION_5 = 5;
  /** validasionチェックプレースホルダ用：整数部桁数(3) */
  public static final String PRECISION_PLACEHOLDER_3 = "3";
  /** validasionチェックプレースホルダ用：整数部桁数(5) */
  public static final String PRECISION_PLACEHOLDER_5 = "5";
  /** 確定使用量前処理：自社管理エリアコード（関西） */
  public static final String OUR_MANAGE_AREA_CODE_KANSAI = "6";
  /** 確定使用量前処理：エリアコード（関西） */
  public static final String AREA_CODE_KANSAI = "06";
  /** 半角コロン */
  public static final String HANKAKU_COLON = ":";
  /** 全角コロン */
  public static final String ZENKAKU_COLON = "：";
  /** リスト置換文字列 */
  public static final String LIST_REPLACE_STRING = "\\{|\\}|\"";
  /** 地点特定番号:検索文字列長 */
  public static final int SPOT_NO_COLON_STRING_LEN = 7;
  /** 地点特定番号:データ長 */
  public static final int SPOT_NO_LEN = 22;
  /** 検索キーワード:地点特定番号 */
  public static final String SERCH_KEYWORD_SPOT_NO = "地点特定番号";
  /** 日割日数 */
  public static final String PER_DIEM_DAYS = "30";
  /** 日時フォーマット：yyyy/MM/dd HH:mm:ss.SSS */
  public static final String FORMAT_DATE_yyyyMMddHHmmssSS = "yyyy/MM/dd HH:mm:ss.SS";
  /** 料金計算エラー通知_TODO */
  public static final String TODO_SUBJECT = "charge.calculate.error.todo.subject.";
  /** 料金計算エラー通知_FCR */
  public static final String FCR_SUBJECT = "charge.calculate.error.fcrwarning.subject.";
  /** 確定使用量データ未到達 */
  public static final String TODO_T1019 = "todo.T1019";
  /** 不明地点データあり */
  public static final String TODO_T1020 = "todo.T1020";
  /** 契約期間外データ到達 */
  public static final String TODO_T1021 = "todo.T1021";
  /** 料金算定期間異常 */
  public static final String TODO_T1022 = "todo.T1022";
  /** 同一地点廃止分未到達 */
  public static final String TODO_T1023 = "todo.T1023";
  /** 30分電力量異常 */
  public static final String TODO_T1024 = "todo.T1024";
  /** 仕訳コード不正 */
  public static final String TODO_T1025 = "todo.T1025";
  /** 計器区分コード不正 */
  public static final String TODO_T1026 = "todo.T1026";
  /** 次回検針予定日異常 */
  public static final String TODO_T1027 = "todo.T1027";
  /** 計器識別番号不正 */
  public static final String TODO_T1028 = "todo.T1028";
  /** 全日指示数不正 */
  public static final String TODO_T1029 = "todo.T1029";
  /** 訂正データ到達（確定済み） */
  public static final String TODO_T1030 = "todo.T1030";
  /** 確定使用量訂正データ受信 */
  public static final String FCR_WOANING_101 = "101";
  /** 手動補正対象 */
  public static final String FCR_WOANING_301 = "301";
  /** 月額料金マイナス */
  public static final String FCR_WOANING_302 = "302";
  /** 指示数使用量不一致 */
  public static final String FCR_WOANING_303 = "303";
  /** 料金計算エンジン：削除キー種別（1：付帯種別コード） */
  public static final String DELETE_TARGET_KEY_TYPE_SPL_CLASS_CODE = "1";
  /** 料金計算エンジン：削除キー種別（2：付帯メニューID） */
  public static final String DELETE_TARGET_KEY_TYPE_SPM_ID = "2";
  /** 料金計算エラー */
  public static final String RATE_CALUC_ERROR = "料金計算エラー";
  /** 使用量CSV仕訳：ダミー値 */
  public static final int USAGE_CSV_CALCULATE_DUMMY_VALUE = 0;
  /** 使用量CSV仕訳：地点特定番号行 */
  public static final int USAGE_FILE_SPOT_NO_LINE = 1;
  /** 使用量CSV仕訳用：ヘッダー行 */
  public static final int USAGE_FILE_HEDDER_LINE = 6;
  /** 使用量CSV仕訳用：使用量リスト開始位置 */
  public static final int USAGE_FILE_USAGE_QUANTITY_LIST_START = 2;
  /** 使用量CSV仕訳用：使用量リスト数 */
  public static final int USAGEQUANTITY_COUNT = 48;
  /**  */
  public static final BigDecimal USAGEQUANTITY_ADJUSTQUANTITY = BigDecimal.valueOf(0.01);
  /**  */
  public static final Integer EXECUTE_RESULT_ONE = new Integer(1);
  /** JSONリスト名：確定料金実績情報一覧JSON */
  public static final String CUSTOM_JSON_CUSTOM_FIX_CHARGE_RESULT_INFO_LIST_NAME = "fixChargeResultJsonList";
  /** 料金計算エンジン：単価適用日（最小） */
  public static final String UP_APPLY_MIN_DATE = "19000101";
  /** 料金計算エンジン：単価適用日（最大） */
  public static final String UP_APPLY_MAX_DATE = "99991231";
  /** 確定使用量情報反映ビジネス：検針カレンダーソート順 */
  public static final String FIX_USAGE_APPLY_METER_READIN_CALENDAR_ORDER_BY_CLAUSE = "use_period ASC";
  /** 料金実績情報ダウンロード：ファイル名接頭辞_実量歴内訳ファイル */
  public static final String SRK040101_FILENAME_PREFIX_FIX_REAL_QUANTITY_HISTORY = "FRK0401-03_";
  /** 警告種別マスタ 最大需要電力チェックビジネス */
  public static final String WARNING_CLASS_MASTER_PEAK_KW = "352";
  /** 警告種別マスタ 実量歴取込済フラグチェックビジネス */
  public static final String WARNING_CLASS_MASTER_REAL_QUANTITY_IMPORT_COMPLETE = "353";
  /** 警告種別マスタ 計量器交換、臨時検針情報の取込チェックビジネス */
  public static final String WARNING_CLASS_MASTER_MC_SMR_INFO = "354";
  /** 燃調単価取得方法区分:算定期間開始日 */
  public static final String FUEL_COST_ADJUST_GET_WAY_CAT_CALC_PERIOD_START = "0";
  /** 燃調単価取得方法区分:利用年月 */
  public static final String FUEL_COST_ADJUST_GET_WAY_CAT_USE_PERIOD = "1";
  /** 料金実績情報ダウンロード：ファイル名接頭辞_確定指示数ファイル */
  public static final String SRK040101_FILENAME_PREFIX_FIX_IN = "FRK0401-04_";
  /** 小数点以下切り捨て桁数（第3位指定） */
  public static final int ROUNDSCALE_THREE = 3;
  /** 計量器交換情報反映フラグ（0：無効） */
  public static final String METER_CHANGE_REFLECT_INVALID_0 = "0";
  /** 計量器交換情報反映フラグ（1：有効） */
  public static final String METER_CHANGE_REFLECT_EFFECTIVE_1 = "1";
  /** 全日電力量指示数算出使用量登録値（0：全日電力量指示数算出使用量） */
  public static final String CALCULATION_USAGE_REGISTRATION_ALL_DAY_0 = "0";
  /** 全日電力量指示数算出使用量登録値（1：合計使用量） */
  public static final String CALCULATION_USAGE_REGISTRATION_TOTAL_1 = "1";
  /** 計器交換・臨時検針情報：ファイル名（降順） */
  public static final String FILE_NAME_DESC = "file_name DESC";
  /** 確定使用量：確定使用量ID(降順) */
  public static final String FU_ID_DESC = "fu_id DESC";
  /** 取付取外区分コード（1：取付） */
  public static final String METER_CHANGE_CATEGORY_CODE_MOUNTING_1 = "1";
  /** 取付取外区分コード（2：取外） */
  public static final String METER_CHANGE_CATEGORY_CODE_DETACHING_2 = "2";
  /** 警告種別マスタ 算定期間内メニュー変更あり */
  public static final String WARNING_CLASS_MASTER_CALC_MENU_CHANGE = "360";
  /** 警告種別マスタ 制限中止割引情報と契約の不整合あり */
  public static final String WARNING_CLASS_MASTER_RES_DISCOUNT_INFO_INCONSISTENCY = "361";
  /** 日割山作成有無（1：有） */
  public static final String DATE_SLOT_MAKE_EXIST = "1";
  /** 制限中止割引単位：日 */
  public static final String DISCOUNT_COVERED_UNIT_DAYS = "日";
  /** 制限中止割引単位：時間 */
  public static final String DISCOUNT_COVERED_UNIT_TIME = "時間";
  /**  */
  public static final String PRORATED_UNIT_BRACKETS = "(日割";
  /** 括弧閉じ */
  public static final String BRACKETS_CLOSE = "）";
  /** 日割山作成有 */
  public static final String PRORATED_UNIT_MAKE = "有";
  /** 一時退避条件(1：連続していない確定使用量が連携） */
  public static final String FIX_USAGE_TEMP_EVACUATE_MSG_NOT_CONTINUOUS = "連続していない確定使用量が連携";
  /** 一時退避条件(2：契約開始日と開始月の使用量対象期間開始日が不一致） */
  public static final String FIX_USAGE_TEMP_EVACUATE_MSG_ST_UNMATCH = "契約開始日と開始月の使用量対象期間開始日が不一致";
  /** 一時退避条件(3：廃止月の使用量対象期間終了日が契約終了日から２日以上超過した確定使用量が連携） */
  public static final String FIX_USAGE_TEMP_EVACUATE_MSG_ED_OVER_2_DAYS = "廃止月の使用量対象期間終了日が契約終了日から２日以上超過した確定使用量が連携";
  /** 一時退避条件(4：契約廃止前に廃止月の確定使用量が連携） */
  public static final String FIX_USAGE_TEMP_EVACUATE_MSG_NOT_ABOLISHED = "契約廃止前に廃止月の確定使用量が連携";
  /** 一時退避条件(5：契約廃止後に契約終了日を超過した確定使用量が連携） */
  public static final String FIX_USAGE_TEMP_EVACUATE_MSG_ALREADY_ABOLISHED = "契約廃止後に契約終了日を超過した確定使用量が連携";
  /** 一時退避条件(6：契約の部分供給区分コードと連携された使用量の仕訳コードが矛盾） */
  public static final String FIX_USAGE_TEMP_EVACUATE_MSG_CATEGORIZE_UNMATCH = "契約の部分供給区分コードと連携された使用量の仕訳コードが矛盾";
  /** 料金ステータス(1:未計算) */
  public static final String CHARGE_STATUS_1 = "未計算";
  /** 料金ステータス(2:未確定(警告対応要)) */
  public static final String CHARGE_STATUS_2 = "未確定(警告対応要)";
  /** 料金ステータス(3:未確定(確定待ち)) */
  public static final String CHARGE_STATUS_3 = "未確定(確定待ち)";
  /** 料金ステータス(4:確定) */
  public static final String CHARGE_STATUS_4 = "確定";
  /** 年月時点の契約状況(1:開始前) */
  public static final String CONTRACT_STATUS_1 = "開始前";
  /** 年月時点の契約状況(2:開始月) */
  public static final String CONTRACT_STATUS_2 = "開始月";
  /** 年月時点の契約状況(3:契約中) */
  public static final String CONTRACT_STATUS_3 = "契約中";
  /** 年月時点の契約状況(4:終了月) */
  public static final String CONTRACT_STATUS_4 = "終了月";
  /** 年月時点の契約状況(5:終了(最終検針なし)) */
  public static final String CONTRACT_STATUS_5 = "終了(最終検針なし)";
  /** 年月時点の契約状況(6:終了(最終検針あり)) */
  public static final String CONTRACT_STATUS_6 = "終了(最終検針あり)";
  /** 料金計算請求状況検索：エリアマスタ_ソート条件 */
  public static final String SRK010801_AREAM_ORDER_BY_CLAUSE = "area_code ASC";
  /** 料金計算請求状況検索：送受電区分マスタ_ソート条件 */
  public static final String SRK010801_TRANSMISSIONCATM_ORDER_BY_CLAUSE = "transmission_cat_code ASC";
  /** 料金計算請求状況検索：請求ステータスマスタ_ソート条件 */
  public static final String SRK010801_BL_STATUS_M_ORDER_BY_CLAUSE = "bl_status_code ASC";
  /** JSONリスト名：料金計算請求状況検索 */
  public static final String JSON_LIST_NAME_BILLING_STATUS_SEARCH = "billingStatusSearchListJson";
  /** 消費税率「0」 */
  public static final Short CONSUMPTION_TAX_RATE_ZERO = 0;
}
