/*-------------------------------------------------------------------------------
 * All Rights Reserved. Copyright(C) Nihon Unisys, Ltd.
 * vendor : Nihon Unisys, Ltd.
 * since : 2014/09/01
 *-----------------------------------------------------------------------------*/
package jp.co.unisys.enability.cis.common.util.logging;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.aspectj.lang.JoinPoint;

import jp.co.unisys.enability.cis.common.Exception.BusinessLogicException;
import jp.co.unisys.enability.cis.common.util.EMSConstants;

/**
 * ログ出力Advice.<br>
 * Spring管理下のbeanが呼ばれた際のログ出力を行うクラスです。<br>
 * 動作範囲は別途XMLファイルで定義します。<br>
 * <p>
 * <h2>処理概要</h2> ・処理開始ログ<br>
 * ・処理終了ログ<br>
 * ・エラーログ<br>
 * </p>
 *
 */
public class CommonLoggingAdvice {

  /** ロガーインスタンス */
  public static final Logger logger = LogManager.getLogger();

  /**
   * 処理開始ログをinfo出力します<br>
   * 出力するポイントは別途設定ファイルに定義します
   * 
   * @param joinPoint
   *          割り込みポイント
   */
  public void beforeLog(JoinPoint joinPoint) {
    logger.info("{} | {} | {} | START", joinPoint.getTarget().getClass().getName(), joinPoint.getSignature().getName(), joinPoint.getArgs());
  }

  /**
   * 処理終了ログをinfo出力します<br>
   * 出力するポイントは別途設定ファイルに定義します
   * 
   * @param joinPoint
   *          割り込みポイント
   */
  public void afterLog(JoinPoint joinPoint) {
    logger.info("{} | {} | {} | END", joinPoint.getTarget().getClass().getName(), joinPoint.getSignature().getName(), joinPoint.getArgs());
  }

  /**
   * 例外発生時にエラーログを出力します<br>
   * 出力するポイントは別途設定ファイルに定義します
   * 
   * @param joinPoint
   *          割り込みポイント
   * @param th
   *          発生例外
   */
  public void afterThrowingLog(JoinPoint joinPoint, Throwable th) {
    if (th instanceof BusinessLogicException) {
      // 業務例外の場合はログ表示しない
    } else {
      //		logger.error(joinPoint.getTarget().getClass().getName());
      // クラス名を元に画面IDを取得
      String viewId = EMSConstants.getScreenIdMap().get(joinPoint.getTarget().getClass().getSimpleName());
      logger.error("ViewId {} : Caused by {} : Message - {}", viewId, th.getCause(), th.getMessage());
      logger.catching(th);
    }
  }

  /**
   * 処理開始ログをdebug出力します<br>
   * 出力するポイントは別途設定ファイルに定義します
   * 
   * @param joinPoint
   *          割り込みポイント
   */
  public void beforeLogDebug(JoinPoint joinPoint) {
    logger.debug("{} | {} | {} | START", joinPoint.getTarget().getClass().getName(), joinPoint.getSignature().getName(), joinPoint.getArgs());
  }

  /**
   * 処理終了ログをdebug出力します<br>
   * 出力するポイントは別途設定ファイルに定義します
   * 
   * @param joinPoint
   *          割り込みポイント
   */
  public void afterLogDebug(JoinPoint joinPoint) {
    logger.debug("{} | {} | {} | END", joinPoint.getTarget().getClass().getName(), joinPoint.getSignature().getName(), joinPoint.getArgs());
  }

}
