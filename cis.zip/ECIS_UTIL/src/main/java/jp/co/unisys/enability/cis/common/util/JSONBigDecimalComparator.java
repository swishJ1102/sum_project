/*-------------------------------------------------------------------------------
 * All Rights Reserved. Copyright(C) Nihon Unisys, Ltd.
 * vendor : Nihon Unisys, Ltd.
 * since : 2015/02/06
 *-----------------------------------------------------------------------------*/
package jp.co.unisys.enability.cis.common.util;

import java.math.BigDecimal;
import java.util.Comparator;

import org.json.JSONObject;

/**
 * JSONオブジェクト用コンパレータインタフェース実装クラス.<br>
 * datatableからのソートリクエストに対応するための並べ替えクラス.<br>
 * BigDecimal型の項目はBigDecimalにして比較を行う.
 */
public class JSONBigDecimalComparator implements Comparator<JSONObject> {

  /**
   * カラム名
   */
  private String columName;

  /**
   * コンパレータのコンストラクタ.<br>
   * インスタンス生成時の初期化を行う
   * 
   * @param columName
   *          カラム名
   */
  public JSONBigDecimalComparator(String columName) {
    this.columName = columName;
  }

  /*
   * (非 Javadoc)
   * @see java.util.Comparator#compare(java.lang.Object, java.lang.Object)
   */
  @Override
  public int compare(JSONObject ja, JSONObject jb) {
    String sa = ja.optString(columName, "").toLowerCase();
    String sb = jb.optString(columName, "").toLowerCase();

    if (sa.isEmpty() && sb.isEmpty()) {
      // 両方空なら、同じ
      return 0;
    } else if (sa.isEmpty()) {
      // 比較前が空なら、前
      return -1;
    } else if (sb.isEmpty()) {
      // 比較後が空なら、後
      return 1;
    }

    // 数値に変換して比較する
    BigDecimal ia = new BigDecimal(sa.replace(EMSConstants.COMMA, ""));
    BigDecimal ib = new BigDecimal(sb.replace(EMSConstants.COMMA, ""));
    int result = ia.compareTo(ib);
    return result;
  }

}
