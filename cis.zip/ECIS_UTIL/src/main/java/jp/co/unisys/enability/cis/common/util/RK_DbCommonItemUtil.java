package jp.co.unisys.enability.cis.common.util;

import java.sql.Timestamp;
import java.util.Date;
import java.util.Map;
import java.util.Objects;

import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;

/**
 * 料金計算DB共通ユーティリティクラス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_DbCommonItemUtil {

  /***
   * オンライン更新ユーザIDを取得する。
   *
   * @return オンライン更新ユーザID
   */
  public static String getOnlineUpdateUserId() {

    // オンライン処理であるか判定
    if (!isOnline()) {
      return null;
    }

    // オンライン更新ユーザID
    Object onlineUpdateUserId = ThreadContext.getRequestThreadContext()
        .get(ECISConstants.USER_ID_KEY);

    // オンライン更新ユーザIDがNULLでない場合
    if (onlineUpdateUserId != null) {
      return (String) onlineUpdateUserId;
    } else {
      // オンライン更新ユーザIDがNULLの場合
      return null;
    }
  }

  /***
   * オンライン更新日を取得する。
   *
   * @return オンライン更新日
   */
  public static Date getOnlineUpdateDate() {
    // オンライン処理であるか判定
    if (!isOnline()) {
      return null;
    }

    // システム共通部品ではなく、自身で取得した値を返却
    return new Date();
  }

  /***
   * オンライン更新日時を取得する。
   *
   * @return オンライン更新日時
   */
  public static Timestamp getOnlineUpdateTimeStamp() {
    // オンライン更新日を取得
    Date onlineDate = getOnlineUpdateDate();

    // 取得した結果を変換して返却
    if (onlineDate != null) {
      return new Timestamp(onlineDate.getTime());
    } else {
      // NULLの場合はそのまま返却
      return null;
    }
  }

  /***
   * 更新モジュールコードを取得する。
   *
   * @return 更新モジュールコード
   */
  public static String getUpdateModuleCode() {
    // スレッドコンテキストから値を取得
    Object moduleCode = ThreadContext.getRequestThreadContext().get(
        ECISConstants.CLASS_NAME_KEY);

    // 更新モジュールコードがNULLでない場合
    if (moduleCode != null) {
      return (String) moduleCode;
    } else {
      // 更新モジュールコードがNULLの場合
      return null;
    }
  }

  /***
   * オンライン更新ユーザIDを設定する。
   *
   * @param targetMap
   *          更新エンティティデータMap
   */
  public static void setOnlineUpdateUserId(Map<String, Object> targetMap) {
    // オンライン更新ユーザIDを取得
    String onlineUpdateUserId = getOnlineUpdateUserId();

    // 取得した値がNULLだった場合、処理を終了
    if (onlineUpdateUserId == null) {
      return;
    }

    // Mapにオンライン更新ユーザIDが含まれている場合
    if (targetMap
        .containsKey(ECISRKConstants.UPDATE_ITEM_NAME_ONLINE_UPDATE_USER_ID)) {
      targetMap.put(
          ECISRKConstants.UPDATE_ITEM_NAME_ONLINE_UPDATE_USER_ID,
          onlineUpdateUserId);
    }
  }

  /***
   * オンライン更新日時を設定する。
   *
   * @param targetMap
   *          更新エンティティデータMap
   */
  public static void setOnlineUpdateTime(Map<String, Object> targetMap) {
    // オンライン更新日時を取得
    Timestamp onlineUpdateTimeStamp = getOnlineUpdateTimeStamp();

    // 取得した値がNULLだった場合、処理を終了
    if (onlineUpdateTimeStamp == null) {
      return;
    }

    // Mapにオンライン更新日時が含まれている場合
    if (targetMap
        .containsKey(ECISRKConstants.UPDATE_ITEM_NAME_ONLINE_UPDATE_TIME)) {
      targetMap.put(
          ECISRKConstants.UPDATE_ITEM_NAME_ONLINE_UPDATE_TIME,
          onlineUpdateTimeStamp);
    }
  }

  /***
   * オンライン処理であるか判定する。
   *
   * @return 判定結果（true:オンライン／false:オンラインでない）
   */
  public static boolean isOnline() {
    // スレッドコンテキストから値を取得
    Object onlineFlag = ThreadContext.getRequestThreadContext().get(
        ECISConstants.ONLINE_FLAG_KEY);

    // フラグがNULLでない、かつ、ONの場合
    if (onlineFlag != null && (Objects.equals((String) onlineFlag, ECISConstants.FLG_ON))) {
      // オンライン
      return true;
    } else {
      // オンラインでない
      return false;
    }
  }
}
