/*-------------------------------------------------------------------------------
 * All Rights Reserved. Copyright(C) Nihon Unisys, Ltd.
 * vendor : Nihon Unisys, Ltd.
 * since : 2014/09/01
 *-----------------------------------------------------------------------------*/
package jp.co.unisys.enability.cis.common.Exception;

/**
 * API例外クラス.<br>
 * APIの業務処理にて利用するAPI業務例外クラス.
 *
 */
public class ApiBusinessLogicException extends Exception {

  /**
   * リターンコード
   */
  private String returnCode;

  /**
   * returnCodeのゲッター
   * 
   * @return returnCode
   */
  public String getReturnCode() {
    return returnCode;
  }

  /**
   * 引数のメッセージ、リターンコードを元に共通例外クラスを生成します
   * 
   * @param message
   * @param returnCode
   */
  public ApiBusinessLogicException(String message, String returnCode) {
    super(message);
    this.returnCode = returnCode;
  }

  /**
   * 引数のメッセージ、例外クラス、リターンコードを元に共通例外クラスを生成します
   * 
   * @param message
   * @param cause
   * @param returnCode
   */
  public ApiBusinessLogicException(String message, Throwable cause, String returnCode) {
    super(message, cause);
    this.returnCode = returnCode;
  }

}
