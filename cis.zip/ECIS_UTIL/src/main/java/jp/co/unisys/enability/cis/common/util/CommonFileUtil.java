/*-------------------------------------------------------------------------------
 * All Rights Reserved. Copyright(C) Nihon Unisys, Ltd.
 * vendor : Nihon Unisys, Ltd.
 * since : 2015/02/06
 *-----------------------------------------------------------------------------*/
package jp.co.unisys.enability.cis.common.util;

import java.io.IOException;
import java.nio.file.FileVisitor;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * ファイル操作に関する共通処理を定義するクラス<br>
 * 基本的に、nioパッケージのクラスを使用した処理を定義する
 */
public class CommonFileUtil {

  /**
   * 指定された引数のディレクトリの中身を再帰的に削除するメソッド<br>
   * 最終的に指定したディレクトリの削除も行う<br>
   * 
   * @param targetPath
   *          削除対象ディレクトリ
   * @throws IOException
   *           入出力エラー
   */
  public static void deleteDirectoryRecurse(String targetPath) throws IOException {
    Path target = Paths.get(targetPath);
    FileVisitor<Path> visitor = new RecurseDirecotyRemoveFileVisitor();

    Files.walkFileTree(target, visitor);
  }
}
