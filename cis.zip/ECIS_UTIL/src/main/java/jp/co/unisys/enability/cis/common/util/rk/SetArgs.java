package jp.co.unisys.enability.cis.common.util.rk;

/**
 * 代入演算データクラス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class SetArgs {
  /** 設定先情報名 */
  private String destData;

  /** 設定先項目名 */
  private String destItem;

  /** 設定元情報名 */
  private String originData;

  /** 設定元項目名 */
  private String originItem;

  /** 代入フラグ情報名 */
  private String assignData;

  /** 代入フラグ */
  private String assignFlg;

  /** 付帯情報名 */
  private String spmData;

  /** 付帯項目名 */
  private String spmItem;

  /** 付帯額追加情報名(料金算定日数) */
  private String spmDataCcDays;

  /** 付帯額追加項目名(料金算定日数) */
  private String spmItemCcDays;

  /** 付帯額追加情報名(日割日数) */
  private String spmDataProratedDays;

  /** 付帯額追加項目名(日割日数) */
  private String spmItemProratedDays;

  /**
   * 設定先情報名を取得する。
   *
   * @author "Nihon Unisys, Ltd."
   * @return 設定先情報名
   */
  public String getDestData() {
    return destData;
  }

  /**
   * 設定先情報名を設定する。
   *
   * @author "Nihon Unisys, Ltd."
   * @param destData
   *          設定先情報名
   */
  public void setDestData(String destData) {
    this.destData = destData;
  }

  /**
   * 設定先項目名を取得する。
   *
   * @author "Nihon Unisys, Ltd."
   * @return 設定先項目名.
   */
  public String getDestItem() {
    return destItem;
  }

  /**
   * 設定先項目名を設定する。
   *
   * @author "Nihon Unisys, Ltd."
   * @param destItem
   *          設定先項目名
   */
  public void setDestItem(String destItem) {
    this.destItem = destItem;
  }

  /**
   * 設定元情報名を取得する。
   *
   * @author "Nihon Unisys, Ltd."
   * @return 設定元情報名
   */
  public String getOriginData() {
    return originData;
  }

  /**
   * 設定元情報名を設定する。
   *
   * @author "Nihon Unisys, Ltd."
   * @param originData
   *          設定元情報名
   */
  public void setOriginData(String originData) {
    this.originData = originData;
  }

  /**
   * 設定元項目名を取得する。
   *
   * @author "Nihon Unisys, Ltd."
   * @return 設定元項目名
   */
  public String getOriginItem() {
    return originItem;
  }

  /**
   * 設定元項目名を設定する。
   *
   * @author "Nihon Unisys, Ltd."
   * @param originItem
   *          設定元項目名
   */
  public void setOriginItem(String originItem) {
    this.originItem = originItem;
  }

  /**
   * 代入フラグ情報名を取得する。
   *
   * @author "Nihon Unisys, Ltd."
   * @return 代入フラグ情報名
   */
  public String getAssignData() {
    return assignData;
  }

  /**
   * 代入フラグ情報名を設定する。
   *
   * @author "Nihon Unisys, Ltd."
   * @param assignData
   *          代入フラグ情報名
   */
  public void setAssignData(String assignData) {
    this.assignData = assignData;
  }

  /**
   * 代入フラグを取得する。
   *
   * @author "Nihon Unisys, Ltd."
   * @return 代入フラグ
   */
  public String getAssignFlg() {
    return assignFlg;
  }

  /**
   * 代入フラグを設定する。
   *
   * @author "Nihon Unisys, Ltd."
   * @param assignFlg
   *          代入フラグ
   */
  public void setAssignFlg(String assignFlg) {
    this.assignFlg = assignFlg;
  }

  /**
   * 付帯情報名を取得する。
   *
   * @author "Nihon Unisys, Ltd."
   * @return 付帯情報名
   */
  public String getSpmData() {
    return spmData;
  }

  /**
   * 付帯情報名を設定する。
   *
   * @author "Nihon Unisys, Ltd."
   * @param assignFlg
   *          付帯情報名
   */
  public void setSpmData(String spmData) {
    this.spmData = spmData;
  }

  /**
   * 付帯項目名を取得する。
   *
   * @author "Nihon Unisys, Ltd."
   * @return 付帯項目名
   */
  public String getSpmItem() {
    return spmItem;
  }

  /**
   * 付帯項目名を設定する。
   *
   * @author "Nihon Unisys, Ltd."
   * @param assignFlg
   *          付帯項目名
   */
  public void setSpmItem(String spmItem) {
    this.spmItem = spmItem;
  }

  /**
   * 付帯額追加情報名(料金算定日数)を取得する。
   *
   * @author "Nihon Unisys, Ltd."
   * @return 設定先情報名
   */
  public String getSpmDataCcDays() {
    return spmDataCcDays;
  }

  /**
   * 付帯額追加情報名(料金算定日数)を設定する。
   *
   * @author "Nihon Unisys, Ltd."
   * @return 設定先情報名
   */
  public void setSpmDataCcDays(String spmDataCcDays) {
    this.spmDataCcDays = spmDataCcDays;
  }

  /**
   * 付帯額追加項目名(料金算定日数)を取得する。
   *
   * @author "Nihon Unisys, Ltd."
   * @return 設定先情報名
   */
  public String getSpmItemCcDays() {
    return spmItemCcDays;
  }

  /**
   * 付帯額追加項目名(料金算定日数)を設定する。
   *
   * @author "Nihon Unisys, Ltd."
   * @return 設定先情報名
   */
  public void setSpmItemCcDays(String spmItemCcDays) {
    this.spmItemCcDays = spmItemCcDays;
  }

  /**
   * 付帯額追加情報名(日割日数)を取得する。
   *
   * @author "Nihon Unisys, Ltd."
   * @return 設定先情報名
   */
  public String getSpmDataProratedDays() {
    return spmDataProratedDays;
  }

  /**
   * 付帯額追加情報名(日割日数)を設定する。
   *
   * @author "Nihon Unisys, Ltd."
   * @return 設定先情報名
   */
  public void setSpmDataProratedDays(String spmDataProratedDays) {
    this.spmDataProratedDays = spmDataProratedDays;
  }

  /**
   * 付帯額追加項目名(日割日数)を取得する。
   *
   * @author "Nihon Unisys, Ltd."
   * @return 設定先情報名
   */
  public String getSpmItemProratedDays() {
    return spmItemProratedDays;
  }

  /**
   * 付帯額追加項目名(日割日数)を設定する。
   *
   * @author "Nihon Unisys, Ltd."
   * @return 設定先情報名
   */
  public void setSpmItemProratedDays(String spmItemProratedDays) {
    this.spmItemProratedDays = spmItemProratedDays;
  }
}
