/*-------------------------------------------------------------------------------
 * All Rights Reserved. Copyright(C) Nihon Unisys, Ltd.
 * vendor : Nihon Unisys, Ltd.
 * since : 2015/04/20 【ph3開発】経理帳票対応
 *-----------------------------------------------------------------------------*/
package jp.co.unisys.enability.cis.common.util;

import java.text.SimpleDateFormat;

/**
 * 独自列挙体定義クラス.<br>
 * コード定義以外に関する、プロパティファイルに定義されない<br>
 * 定数enumを定義するクラス
 */
public class EcisPersonalEnums {

  /**
   * 列挙体：ONOFFフラグ
   */
  public enum OnOffFlag implements Encodable<String> {
    OFF("0"), ON("1");

    private String code;

    private OnOffFlag(String code) {
      this.code = code;
    }

    @Override
    public String encode() {
      return this.code;
    }

  }

  /**
   * 列挙体：Ajaxリクエストパラメータ名
   */
  public enum AjaxRequestParameterNames implements Encodable<String> {
    /** 開始インデックス */
    DISPLAY_START_IDX("iDisplayStart"),
    /** エコー番号 */
    ECHO_NO("sEcho"),
    /** 1ページの表示件数 */
    DISPLAY_LENGTH("iDisplayLength"),
    /** カラム名（番号） */
    SORT_COL("iSortCol_0"),
    /** ソート順 */
    SORT_DIR("sSortDir_0");

    private String code;

    private AjaxRequestParameterNames(String code) {
      this.code = code;
    }

    @Override
    public String encode() {
      return this.code;
    }
  }

  /**
   * 列挙体：モジュールコード<br>
   * Controllerクラス名、ServiceImplクラス名を定義する<br>
   * エラーログ出力用
   */
  public enum ModuleCode {
    /** 経理帳票ダウンロード */
    DOWNLOAD_ACCOUNTING_REPORT("F0103_DownloadAccountingReportAction", "F0103_DownloadAccountingReportServiceImpl");

    private String actionClassName;
    private String serviceImplName;

    private ModuleCode(String actionClassName, String serviceImplName) {
      this.actionClassName = actionClassName;
      this.serviceImplName = serviceImplName;
    }

    public String getActionName() {
      return this.actionClassName;
    }

    public String getServiceName() {
      return this.serviceImplName;
    }
  }

  /**
   * 列挙体：画面ID
   */
  public enum ScreenId implements Encodable<String> {
    /** 経理帳票ダウンロード */
    DOWNLOAD_ACCOUNTING_REPORT("S0103-02");

    private String code;

    private ScreenId(String code) {
      this.code = code;
    }

    @Override
    public String encode() {
      return this.code;
    }
  }

  /**
   * 列挙体：ファイル名接頭辞<br>
   * ファイル名の先頭にくる文字を定義する
   */
  public enum FilePrefix implements Encodable<String> {
    /** 経理帳票ダウンロードファイル名接頭辞 */
    ACCOUNTING_REPORT("accounting_report_");

    private String code;

    private FilePrefix(String code) {
      this.code = code;
    }

    @Override
    public String encode() {
      return this.code;
    }
  }

  /**
   * 列挙体：日付フォーマット文字列<br>
   * DateFormatクラスで使用するフォーマット文字列を定義する<br>
   * 定義した文字列を元にSimpleDateFormatクラスを保持し、取得することも可能
   */
  public enum DateFormatConfig implements Encodable<String> {
    /** 年月（スラッシュ無し） */
    yyyyMM("yyyyMM"),
    /** 年月（スラッシュあり） */
    yyyyMM_SLASH("yyyy/MM"),
    /** 年月日（スラッシュ無し） */
    yyyyMMdd("yyyyMMdd"),
    /** 年月日（スラッシュあり） */
    yyyyMMdd_SLASH("yyyy/MM/dd"),
    /** 年月日時分（年月日スラッシュ無し、半角スペース区切り、時分コロン区切り） */
    yyyyMMdd_HHmm("yyyyMMdd HH:mm"),
    /** 年月日時分（年月日スラッシュあり、半角スペース区切り、時分コロン区切り） */
    yyyyMMdd_HHmm_SLASH("yyyy/MM/dd HH:mm"),
    /** 年月日時分秒（年月日スラッシュ無し、アンダーバー区切り、時分秒区切りなし） */
    yyyyMMdd_underline_HHmmss("yyyyMMdd_HHmmss"),
    /** 年月日時分秒（区切り無し） */
    yyyyMMddHHmmss("yyyyMMddHHmmss"),
    /** 年月日時分秒ミリ秒（区切り無し） */
    yyyyMMddHHmmssSSS("yyyyMMddHHmmssSSS");

    private String code;

    private DateFormatConfig(String code) {
      this.code = code;
    }

    @Override
    public String encode() {
      return this.code;
    }

    /**
     * 定義されたキーを元に、SimpleDateFormatを作成し返却する
     */
    public SimpleDateFormat getSimpleDateFormat() {
      return new SimpleDateFormat(this.code);
    }
  }

  /**
   * 列挙体：文字列フォーマット群<br>
   * 各種文字用のフォーマットを定義する<br>
   */
  public enum WordingFormatConfig implements Encodable<String> {
    /** SQL(to_char関数)用数値型フォーマット */
    SQL_NUMERIC_SEPARATE_COMMA("FM999,999,999,999,999,999");

    private String code;

    private WordingFormatConfig(String code) {
      this.code = code;
    }

    @Override
    public String encode() {
      return this.code;
    }
  }

  /**
   * 列挙体：ファイル拡張子
   */
  public enum FileExtension implements Encodable<String> {
    /** txt形式 */
    TXT(".txt"),
    /** csv形式 */
    CSV(".csv"),
    /** zip形式 */
    ZIP(".zip"),
    /** json形式 */
    JSON(".json"),
    /** lock形式 */
    LOCK(".lock"),
    /** tmp形式 */
    TEMP(".tmp"),
    /** err形式 */
    ERROR(".err"),
    /** xml形式 */
    XML(".xml");

    private String code;

    private FileExtension(String code) {
      this.code = code;
    }

    @Override
    public String encode() {
      return this.code;
    }
  }

  /**
   * 列挙体：文字定数群
   */
  public enum WordingConstants implements Encodable<String> {
    /** スラッシュ */
    SLASH("/"),
    /** アンダーバー */
    UNDERLINE("_"),
    /** ダブルクォート */
    DOUBLE_QUOTE("\""),
    /** 空文字 */
    EMPTY(""),
    /** カンマ */
    COMMA(","),
    /** 改行コード */
    ENTER_CODE("\r\n"),
    /** 半角スペース */
    BLANK_HALF(" "),
    /** 全角スペース */
    BLANK_FULL("　"),
    /** 半角左丸括弧 */
    PARENTHESES_LEFT_HALF("("),
    /** 半角右丸括弧 */
    PARENTHESES_RIGHT_HALF(")");

    private String code;

    private WordingConstants(String code) {
      this.code = code;
    }

    @Override
    public String encode() {
      return this.code;
    }
  }

  /**
   * 列挙体：JSONファイルの行単位のキー定義<br>
   * 数値の連番とrowidを持つ
   */
  public enum JsonColumns implements Encodable<String> {
    NO_0("0"), NO_1("1"), NO_2("2"), NO_3("3"), NO_4("4"), NO_5("5"), NO_6("6"), NO_7("7"), NO_8("8"), NO_9("9"), NO_10("10"), NO_11("11"), NO_12("12"),
    /** カラム名：行番号 */
    ROWID("rowid");

    private String code;

    private JsonColumns(String code) {
      this.code = code;
    }

    @Override
    public String encode() {
      return this.code;
    }
  }

  /**
   * 列挙体：Ajaxソート順
   */
  public enum AjaxSortOrder implements Encodable<String> {
    ASC("asc"), DESC("desc");

    private String code;

    private AjaxSortOrder(String code) {
      this.code = code;
    }

    @Override
    public String encode() {
      return this.code;
    }
  }

  /**
   * 列挙体：画面戻り値<br>
   * strutsのresultに対応する画面の戻り値
   */
  public enum ResultParams implements Encodable<String> {
    /** 登録・更新 */
    ADD("add"),
    /** 削除 */
    DELETE("delete"),
    /** ダウンロード */
    DOWNLOAD("download"),
    /** 初期表示 */
    INIT("init"),
    /** ログイン画面に戻る */
    LOGOUT("logout"),
    /** Ajax成功 */
    SUCCESS_AJAX("successAjax");

    private String code;

    private ResultParams(String code) {
      this.code = code;
    }

    @Override
    public String encode() {
      return this.code;
    }
  }

  /**
   * 列挙体：エンコードタイプ
   */
  public enum EncodingType implements Encodable<String> {
    UTF8("UTF-8"), SJIS("SJIS");

    private String code;

    private EncodingType(String code) {
      this.code = code;
    }

    @Override
    public String encode() {
      return this.code;
    }
  }
}
