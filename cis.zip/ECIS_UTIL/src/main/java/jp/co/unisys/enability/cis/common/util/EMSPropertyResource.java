/*-------------------------------------------------------------------------------
 * All Rights Reserved. Copyright(C) Nihon Unisys, Ltd.
 * vendor : Nihon Unisys, Ltd.
 * since : 2014/09/01
 * revision：2015/02/06 【ph2開発】督促状の対応、空室（ダミー）契約の対応
 *           2015/04/20 【ph3開発】ブランドの対応、経理帳票の対応
 *-----------------------------------------------------------------------------*/
package jp.co.unisys.enability.cis.common.util;

import java.io.Serializable;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;
import java.util.TreeMap;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import javassist.NotFoundException;

/**
 * EMSコード定義クラス.<br>
 * 料金計算システムで使用するコードプロパティ値を保持する
 *
 */
@Configuration
public class EMSPropertyResource {

  /**
   * 処理パラメータ定義 START
   */

  /** 最大検索数 */
  @Value("${maxsearchcount}")
  private int maxSearchCount;
  public static final String MAXSEARCHCOUNT_KEY = "maxsearchcount";

  /** ページ内一覧表示件数 */
  @Value("${pagedisplaycount}")
  private int pageDisplayCount;
  public static final String PAGEDISPLAYCOUNT_KEY = "pagedisplaycount";

  /** 検針情報登録のコミット単位 */
  public static final String S0102_02_COMMITUNIT_KEY = "s0102_02.commitunit";

  /** ログイン失敗最大回数 */
  @Value("${loginlimittimes.max}")
  private int loginLimitTimesMax;
  public static final String LOGINLIMITIMES_MAX_KEY = "loginlimittimes.max";

  /** パスワード変更日数 */
  public static final String PASSWORDPERMITTEDDAYS_MAX_KEY = "passwordpermitteddays.max";

  /** パスワード変更不可日数 */
  public static final String PASSWORDNOTCHANGEDAYS_MAX_KEY = "passwordnotchangedays.max";

  /** パスワード世代管理数 */
  public static final String PASSWORDHISTORY_MAX_KEY = "passwordhistory.max";

  /** バッチ請求基準日 */
  @Value("${batch.billingbaseday}")
  private String batchBillingBaseDay;
  public static final String BILLINGBASEDAY_KEY = "batch.billingbaseday";

  /** 電力量閾値 */
  public static final String POWER_CONSUMPTION_THRESHOLD_KEY = "powerConsumption.threshold";

  /** 口座振替日 */
  public static final String ACCOUNT_TRANSFER_DAY_KEY = "accounttransfer.day";

  /** 未確定詳細ステータス：確定待ち */
  @Value("${fixfeecalc.undecidecmessage.0}")
  private String fixfeecalcUndecidecMessage_0;
  public static final String FIXFEECALC_UNDECIDEC_MESSAGE_0_KEY = "fixfeecalc.undecidecmessage.0";

  /** 未確定詳細ステータス：未取込使用量有 */
  @Value("${fixfeecalc.undecidecmessage.1}")
  private String fixfeecalcUndecidecMessage_1;
  public static final String FIXFEECALC_UNDECIDEC_MESSAGE_1_KEY = "fixfeecalc.undecidecmessage.1";

  /** 未確定詳細ステータス：未補正エラーデータ有 */
  @Value("${fixfeecalc.undecidecmessage.2}")
  private String fixfeecalcUndecidecMessage_2;
  public static final String FIXFEECALC_UNDECIDEC_MESSAGE_2_KEY = "fixfeecalc.undecidecmessage.2";

  /** 未確定詳細ステータス：未承認補正データ有 */
  @Value("${fixfeecalc.undecidecmessage.3}")
  private String fixfeecalcUndecidecMessage_3;
  public static final String FIXFEECALC_UNDECIDEC_MESSAGE_3_KEY = "fixfeecalc.undecidecmessage.3";

  /** 仮加盟店番号 */
  public static final String MEMBER_STORE_NO_KEY = "memberStoreNo";

  /** エラーリスト出力先 */
  public static final String ERRORLIST_DIR_KEY = "errorlist.dir";

  /** c-premix用収納結果情報IFファイル配置ディレクトリ */
  public static final String C_PREMIX_RECEIPT_DIR_KEY = "cpremix.receipt.dir";

  /** c-premix用有効性確認結果IFファイル配置ディレクトリ */
  public static final String C_PREMIX_CREDIT_VALIDITY_DIR_KEY = "cpremix.credit.validity.dir";

  /** 顧客情報IFファイル配置ディレクトリ */
  public static final String CUSTOMER_IF_DIR_KEY = "customerif.dir";

  /** 債権譲渡依頼IFファイル配置ディレクトリ */
  public static final String ARTRANSFER_IF_DIR_KEY = "artransferif.dir";

  /** Enability用ファイル配置ディレクトリ */
  public static final String ENABILITY_DIR_KEY = "enability.dir";

  /** 契約・物件情報ダウンロードワークディレクトリ */
  public static final String DOWNLOAD_CONTRACT_BUILDING_WORK_DIR_KEY = "download.contract.building.work.dir";

  /** 料金情報ダウンロードワークディレクトリ */
  public static final String DOWNLOAD_AMOUNT_WORK_DIR_KEY = "download.amount.work.dir";

  /** 契約・物件情報アップロードワークディレクトリ */
  public static final String UPLOAD_CONTRACTBUILDING_WORK_DIR_KEY = "upload.contractbuiliding.work.dir";

  /** 正規表現:：顧客番号 */
  public static final String FORMAT_CONTRACTOR_NO = "format.contractorNo";

  /** 正規表現:：支払番号 */
  public static final String FORMAT_PAYMENT_NO = "format.paymentNo";

  /** 正規表現:：契約番号 */
  public static final String FORMAT_CONTRACT_NO = "format.contractNo";

  /** 検索に使用するJSON形式データファイルの出力先 */
  public static final String SEARCHFILE_JSONDATA_WORK_DIR_KEY = "jsondata.work.dir";

  /** 処理状況照会の処理履歴最大検索数 */
  public static final String S0100_06_MAXSEARCHCOUNT_KEY = "s0100_06.maxsearchcount";

  /** アクセスログファイル：出力ディレクトリ */
  public static final String ACCESSLOGFILE_OUTPUT_DIRECTORY_KEY = "accesslogfile.output.directory";

  /** アクセスログファイル：出力ファイル最大サイズ */
  public static final String ACCESSLOG_MAX_FILE_SIZE = "accesslogfile.output.filesize";

  /**
   * 処理パラメータ定義 END
   */

  /**
   * BATCH定義 START
   */
  @Value("${batch.info.I0001}")
  private String batchInfoI0001;

  @Value("${batch.info.I0002}")
  private String batchInfoI0002;

  @Value("${batch.info.E0001}")
  private String batchInfoE0001;

  @Value("${batch.info.E0002}")
  private String batchInfoE0002;

  @Value("${batch.info.E0003}")
  private String batchInfoE0003;

  @Value("${batch.info.E0004}")
  private String batchInfoE0004;

  @Value("${batch.info.E0005}")
  private String batchInfoE0005;

  @Value("${batch.info.E0006}")
  private String batchInfoE0006;

  @Value("${batch.info.E0007}")
  private String batchInfoE0007;

  @Value("${batch.info.E0008}")
  private String batchInfoE0008;

  @Value("${batch.info.E0009}")
  private String batchInfoE0009;

  @Value("${batch.info.E0010}")
  private String batchInfoE0010;

  @Value("${batch.info.E0011}")
  private String batchInfoE0011;

  @Value("${batch.info.E0012}")
  private String batchInfoE0012;

  @Value("${batch.info.E0013}")
  private String batchInfoE0013;

  @Value("${batch.info.E0014}")
  private String batchInfoE0014;

  @Value("${batch.info.E0015}")
  private String batchInfoE0015;

  @Value("${batch.info.E0016}")
  private String batchInfoE0016;

  @Value("${batch.info.E0017}")
  private String batchInfoE0017;

  @Value("${batch.info.E0018}")
  private String batchInfoE0018;

  @Value("${batch.info.E0019}")
  private String batchInfoE0019;

  @Value("${batch.payment.format}")
  private String batchPaymentFormat;

  /** info系メッセージ */
  @Value("${info.I0001}")
  private String infoI0001;

  @Value("${info.I0002}")
  private String infoI0002;

  @Value("${info.I0003}")
  private String infoI0003;

  @Value("${info.I0004}")
  private String infoI0004;

  @Value("${info.I0005}")
  private String infoI0005;

  @Value("${info.I0006}")
  private String infoI0006;

  /** error系メッセージ */
  @Value("${error.E0001}")
  private String errorE0001;

  @Value("${error.E0001}")
  private String errorE0002;

  @Value("${error.E0003}")
  private String errorE0003;

  @Value("${error.E0004}")
  private String errorE0004;

  @Value("${error.E0005}")
  private String errorE0005;

  @Value("${error.E0006}")
  private String errorE0006;

  @Value("${error.E0007}")
  private String errorE0007;

  @Value("${error.E0008}")
  private String errorE0008;

  @Value("${error.E0009}")
  private String errorE0009;

  @Value("${error.E0010}")
  private String errorE0010;

  @Value("${error.E0011}")
  private String errorE0011;

  @Value("${error.E0012}")
  private String errorE0012;

  @Value("${error.E0013}")
  private String errorE0013;

  @Value("${error.E0014}")
  private String errorE0014;

  @Value("${error.E0015}")
  private String errorE0015;

  @Value("${error.E0016}")
  private String errorE0016;

  @Value("${error.E0017}")
  private String errorE0017;
  /**
   * BATCH定義 END
   */

  /**
   * 督促文言 START
   */

  /** 解約通知期限 */
  public static final String DEMANDWORDS_TERMINATIONADVICETIME_KEY = "demandWords.terminationAdviceTime";

  /** 解約予告期限 */
  public static final String DEMANDWORDS_TERMINATIONNOTICETIME_KEY = "demandWords.terminationNoticeTime";

  /** 利用停止予告期限 */
  public static final String DEMANDWORDS_USAGESTOPNOTICETIME_KEY = "demandWords.usageStopNoticeTime";

  /** 支払通知期限 */
  public static final String DEMANDWORDS_PAYMENTADVICETIME = "demandWords.paymentAdviceTime";

  /**
   * 督促文言 END
   */

  /** 支払基準日 */
  @Value("${paymentRecodeDate}")
  private String paymentRecodeDate_01;
  public static final String PAYMENTRECODEDATE_01 = "paymentRecodeDate";

  /** 処理名称：顧客情報出力 */
  @Value("${inqmngcond.procnm.B010101}")
  private String processname_b0101_01;
  public static final String PROCESS_NAME_B0101_01_KEY = "inqmngcond.procnm.B010101";

  /** 処理名称：債権譲渡依頼情報出力 */
  @Value("${inqmngcond.procnm.B010102}")
  private String processname_b0101_02;
  public static final String PROCESS_NAME_B0101_02_KEY = "inqmngcond.procnm.B010102";

  /** 処理名称：収納結果情報受信 */
  @Value("${inqmngcond.procnm.B010103}")
  private String processname_b0101_03;
  public static final String PROCESS_NAME_B0101_03_KEY = "inqmngcond.procnm.B010103";

  /** 処理名称：有効性チェック結果受信 */
  @Value("${inqmngcond.procnm.B010104}")
  private String processname_b0101_04;
  public static final String PROCESS_NAME_B0101_04_KEY = "inqmngcond.procnm.B010104";

  /** 処理名称：契約存在チェック */
  @Value("${inqmngcond.procnm.B010105}")
  private String processname_b0101_05;
  public static final String PROCESS_NAME_B0101_05_KEY = "inqmngcond.procnm.B010105";

  /** 処理名称：MEMS自動連携 */
  @Value("${inqmngcond.procnm.B010106}")
  private String processname_b0101_06;
  public static final String PROCESS_NAME_B0101_06_KEY = "inqmngcond.procnm.B010106";

  /** 処理名称：請求データ作成 */
  @Value("${inqmngcond.procnm.B010203}")
  private String processname_b0102_03;
  public static final String PROCESS_NAME_B0102_03_KEY = "inqmngcond.procnm.B010203";

  /** 処理名称：請求対象外契約経理ステータス更新 */
  @Value("${inqmngcond.procnm.B010301}")
  private String processname_b0103_01;
  public static final String PROCESS_NAME_B0103_01_KEY = "inqmngcond.procnm.B010301";

  /**
   * コード定義 START
   */
  /** DCEC区分-DC */
  public static final String DCECCATEGORY_1_KEY = "dceccategory.1";

  /** DCEC区分-EC */
  public static final String DCECCATEGORY_2_KEY = "dceccategory.2";

  /** エラーコード-基本料金マイナス値エラー */
  @Value("${errorcode.E0011}")
  private String errorcode_E0011;

  /** エラーコード-基本料金桁数超過エラー */
  @Value("${errorcode.E0012}")
  private String errorcode_E0012;

  /** エラーコード-電力量料金マイナス値エラー */
  @Value("${errorcode.E0021}")
  private String errorcode_E0021;

  /** エラーコード-電力量料金桁数超過エラー */
  @Value("${errorcode.E0022}")
  private String errorcode_E0022;

  /** エラーコード-燃料調整額桁数超過エラー */
  @Value("${errorcode.E0032}")
  private String errorcode_E0032;

  /** エラーコード-割引額桁数超過エラー */
  @Value("${errorcode.E0042}")
  private String errorcode_E0042;

  /** エラーコード-再エネ発電賦課金等マイナス値エラー */
  @Value("${errorcode.E0051}")
  private String errorcode_E0051;

  /** エラーコード-再エネ発電賦課金等桁数超過エラー */
  @Value("${errorcode.E0052}")
  private String errorcode_E0052;

  /** エラーコード-請求予定額マイナス値エラー */
  @Value("${errorcode.E0061}")
  private String errorcode_E0061;

  /** エラーコード-請求予定額桁数超過エラー */
  @Value("${errorcode.E0062}")
  private String errorcode_E0062;

  /** エラーコード-料金実績明細金額桁数超過エラー */
  @Value("${errorcode.E0082}")
  private String errorcode_E0082;

  /** エラーコード-請求額マイナス値エラー */
  @Value("${errorcode.E0101}")
  private String errorcode_E0101;
  public static final String ERRORCODE_E0101_KEY = "errorcode.E0101";

  /** 割引プラン種別-電力会社提供メニュー */
  @Value("${discountplanclass.1}")
  private String discountplanclass_1;

  /** 割引プラン種別-一括受電事業者提供メニュー */
  @Value("${discountplanclass.2}")
  private String discountplanclass_2;

  /** 割引種別-定額 */
  @Value("${discountclass.1}")
  private String discountclass_1;

  /** 割引種別-単位額 */
  @Value("${discountclass.2}")
  private String discountclass_2;

  /** 割引種別-割合 */
  @Value("${discountclass.3}")
  private String discountclass_3;

  /** 供給区分-低圧 */
  @Value("${supplycategory.1}")
  private String supplycategory_1;

  /** 供給区分-高圧 */
  @Value("${supplycategory.2}")
  private String supplycategory_2;

  /** 供給停止区分-停止なし */
  @Value("${supplystopcategory.0}")
  private String supplystopcategory_0;

  /** 供給停止区分-停止 */
  @Value("${supplystopcategory.1}")
  private String supplystopcategory_1;
  public static final String SUPPLYSTOPCATEGORY_1_KEY = "supplystopcategory.1";

  /** 計算単位区分-日割単位 */
  @Value("${calcunitcategory.1}")
  private String calcunitcategory_1;

  /** 計算単位区分-合算単位 */
  @Value("${calcunitcategory.2}")
  private String calcunitcategory_2;

  /** 欠測フラグ-欠測なし */
  @Value("${missingflag.0}")
  private String missingflag_0;
  public static final String MISSINGFLAG_0_KEY = "missingflag.0";

  /** 欠測フラグ-欠測あり */
  @Value("${missingflag.1}")
  private String missingflag_1;
  public static final String MISSINGFLAG_1_KEY = "missingflag.1";

  /** 権限区分-管理者 */
  @Value("${authorizationscategory.0}")
  private String authorizationscategory_0;

  /** 権限区分-オペレータ */
  @Value("${authorizationscategory.1}")
  private String authorizationscategory_1;

  /** 権限区分-参照ユーザ */
  @Value("${authorizationscategory.2}")
  private String authorizationscategory_2;

  /** 個人・法人区分-個人 */
  @Value("${personalcorporationcategory.1}")
  private String personalcorporationcategory_1;

  /** 個人・法人区分-法人 */
  @Value("${personalcorporationcategory.2}")
  private String personalcorporationcategory_2;

  /** 口座種別-普通 */
  @Value("${accountclass.1}")
  private String accountclass_1;

  /** 口座種別-当座 */
  @Value("${accountclass.2}")
  private String accountclass_2;

  /** 債権ステータス-未収納 */
  @Value("${claimstatus.0}")
  private String claimstatus_0;

  /** 債権ステータス-収納済 */
  @Value("${claimstatus.1}")
  private String claimstatus_1;

  /** 債権ステータス-部分収納 */
  @Value("${claimstatus.2}")
  private String claimstatus_2;

  /** 債権ステータス-過剰収納 */
  @Value("${claimstatus.3}")
  private String claimstatus_3;

  /** 支払方法区分-コンビニ収納 */
  @Value("${paymentwaycategory.1}")
  private String paymentwaycategory_1;

  /** 支払方法区分-口座振替 */
  @Value("${paymentwaycategory.2}")
  private String paymentwaycategory_2;

  /** 支払方法区分-クレジット */
  @Value("${paymentwaycategory.4}")
  private String paymentwaycategory_4;

  /** 取消フラグ-未取消 */
  @Value("${cancelflag.0}")
  private String cancelflag_0;

  /** 取消フラグ-取消 */
  @Value("${cancelflag.1}")
  private String cancelflag_1;
  public static final String CANCELFLAG_1_KEY = "cancelflag.1";

  /** 収納ステータス-請求未反映 */
  @Value("${receiptstatus.0}")
  private String receiptstatus_0;

  /** 収納ステータス-請求反映済 */
  @Value("${receiptstatus.1}")
  private String receiptstatus_1;

  /** 収納ステータス-請求反映対象外 */
  @Value("${receiptstatus.2}")
  private String receiptstatus_2;

  /** 収納ステータス-エラー */
  @Value("${receiptstatus.9}")
  private String receiptstatus_9;

  /** 収納結果コード-成功 */
  @Value("${receiptresultcode.00}")
  private String receiptresultcode_00;

  /** 収納結果コード-資金不足 */
  @Value("${receiptresultcode.01}")
  private String receiptresultcode_01;

  /** 収納結果コード-取引なし */
  @Value("${receiptresultcode.02}")
  private String receiptresultcode_02;

  /** 収納結果コード-預金者都合振替停止 */
  @Value("${receiptresultcode.03}")
  private String receiptresultcode_03;

  /** 収納結果コード-口座振替依頼書なし */
  @Value("${receiptresultcode.04}")
  private String receiptresultcode_04;

  /** 収納結果コード-名義相違 */
  @Value("${receiptresultcode.07}")
  private String receiptresultcode_07;

  /** 収納結果コード-委託者都合振替停止 */
  @Value("${receiptresultcode.08}")
  private String receiptresultcode_08;

  /** 収納結果コード-その他 */
  @Value("${receiptresultcode.09}")
  private String receiptresultcode_09;

  /** 収納結果コード-エラー */
  @Value("${receiptresultcode.0E}")
  private String receiptresultcode_0E;

  /** 収納結果コード-振替結果未着 */
  @Value("${receiptresultcode.0N}")
  private String receiptresultcode_0N;

  /** 収納結果コード-ポイント */
  @Value("${receiptresultcode.10}")
  private String receiptresultcode_10;

  /** 収納結果コード-不足入金 */
  @Value("${receiptresultcode.12}")
  private String receiptresultcode_12;

  /** 収納結果コード-入金取消 */
  @Value("${receiptresultcode.21}")
  private String receiptresultcode_21;

  /** 収納結果コード-0円請求 */
  @Value("${receiptresultcode.99}")
  private String receiptresultcode_99;

  /** 収納方法コード-クレジット */
  @Value("${receiptwaycode.01}")
  private String receiptwaycode_01;

  /** 収納方法コード-口座振替 */
  @Value("${receiptwaycode.02}")
  private String receiptwaycode_02;

  /** 収納方法コード-コンビニ */
  @Value("${receiptwaycode.03}")
  private String receiptwaycode_03;

  /** 収納方法コード-総合振込 */
  @Value("${receiptwaycode.04}")
  private String receiptwaycode_04;

  /** 収納方法コード-現金書留 */
  @Value("${receiptwaycode.05}")
  private String receiptwaycode_05;

  /** 収納方法コード-訪問徴収 */
  @Value("${receiptwaycode.06}")
  private String receiptwaycode_06;

  /** 収納方法コード-窓口払い */
  @Value("${receiptwaycode.07}")
  private String receiptwaycode_07;

  /** 収納方法コード-補正入金 */
  @Value("${receiptwaycode.08}")
  private String receiptwaycode_08;

  /** 収納方法コード-小切手／手形 */
  @Value("${receiptwaycode.09}")
  private String receiptwaycode_09;

  /** 収納方法コード-局総合振込 */
  @Value("${receiptwaycode.14}")
  private String receiptwaycode_14;

  /** 収納方法コード-局現金書留 */
  @Value("${receiptwaycode.15}")
  private String receiptwaycode_15;

  /** 収納方法コード-局訪問徴収 */
  @Value("${receiptwaycode.16}")
  private String receiptwaycode_16;

  /** 収納方法コード-局窓口払い */
  @Value("${receiptwaycode.17}")
  private String receiptwaycode_17;

  /** 収納方法コード-振込手数料 */
  @Value("${receiptwaycode.21}")
  private String receiptwaycode_21;

  /** 収納方法コード-清算調整金 */
  @Value("${receiptwaycode.70}")
  private String receiptwaycode_70;

  /** 収納方法コード-サービサー */
  @Value("${receiptwaycode.80}")
  private String receiptwaycode_80;

  /** 収納方法コード-買戻し */
  @Value("${receiptwaycode.90}")
  private String receiptwaycode_90;

  /** 収納方法コード-0円請求 */
  @Value("${receiptwaycode.99}")
  private String receiptwaycode_99;

  /** 処理区分-登録 */
  @Value("${processcategory.I}")
  private String processcategory_I;

  /** 処理区分-更新 */
  @Value("${processcategory.U}")
  private String processcategory_U;

  /** 電話番号区分-固定 */
  @Value("${phonecategory.0}")
  private String phonecategory_0;

  /** 電話番号区分-携帯 */
  @Value("${phonecategory.1}")
  private String phonecategory_1;

  /** 文言コード-明細-基本料金 */
  @Value("${wordingcode.00010001}")
  private String wordingcode_00010001;

  /** 文言コード-明細-燃料費調整額 */
  @Value("${wordingcode.00010002}")
  private String wordingcode_00010002;

  /** 文言コード-明細-再エネ発電賦課金等 */
  @Value("${wordingcode.00010003}")
  private String wordingcode_00010003;

  /** 文言コード-明細-一括受電割引額 */
  @Value("${wordingcode.00010004}")
  private String wordingcode_00010004;

  /** 文言コード-明細-ポイント割引額 */
  @Value("${wordingcode.00010005}")
  private String wordingcode_00010005;

  /** 平日休日区分-区分なし */
  @Value("${weekdayholidaycategory.0}")
  private String weekdayholidaycategory_0;
  public static final String WEEKDAYHOLIDAYCATEGORY_0_KEY = "weekdayholidaycategory.0";

  /** 平日休日区分-平日（祝日除く） */
  @Value("${weekdayholidaycategory.1}")
  private String weekdayholidaycategory_1;
  public static final String WEEKDAYHOLIDAYCATEGORY_1_KEY = "weekdayholidaycategory.1";

  /** 平日休日区分-平日（祝日含む） */
  @Value("${weekdayholidaycategory.2}")
  private String weekdayholidaycategory_2;
  public static final String WEEKDAYHOLIDAYCATEGORY_2_KEY = "weekdayholidaycategory.2";

  /** 平日休日区分-休日（祝日除く） */
  @Value("${weekdayholidaycategory.3}")
  private String weekdayholidaycategory_3;
  public static final String WEEKDAYHOLIDAYCATEGORY_3_KEY = "weekdayholidaycategory.3";

  /** 平日休日区分-休日（祝日含む） */
  @Value("${weekdayholidaycategory.4}")
  private String weekdayholidaycategory_4;
  public static final String WEEKDAYHOLIDAYCATEGORY_4_KEY = "weekdayholidaycategory.4";

  /** 補正ステータス-未補正 */
  @Value("${correctstatus.0}")
  private String correctstatus_0;

  /** 補正ステータス-補正前 */
  @Value("${correctstatus.1}")
  private String correctstatus_1;

  /** 補正ステータス-補正済 */
  @Value("${correctstatus.2}")
  private String correctstatus_2;

  /** 補正ステータス-補正承認済 */
  @Value("${correctstatus.3}")
  private String correctstatus_3;

  /** 補正ステータス-削除登録済 */
  @Value("${correctstatus.4}")
  private String correctstatus_4;

  /** 明細区分-明細行 */
  @Value("${detailcategory.1}")
  private String detailcategory_1;

  /** 明細区分-合計行 */
  @Value("${detailcategory.2}")
  private String detailcategory_2;

  /** 明細区分-空白行 */
  @Value("${detailcategory.3}")
  private String detailcategory_3;

  /** 明細区分-見出し行 */
  @Value("${detailcategory.4}")
  private String detailcategory_4;

  /** 有効性判定結果-有効性OK */
  @Value("${efficacyjudgeresult.0}")
  private String efficacyjudgeresult_0;
  public static final String EFFICACYJUDGERESULT_0_KEY = "efficacyjudgeresult.0";

  /** 有効性判定結果-有効性NG */
  @Value("${efficacyjudgeresult.1}")
  private String efficacyjudgeresult_1;
  public static final String EFFICACYJUDGERESULT_1_KEY = "efficacyjudgeresult.1";

  /** 有効性判定結果-照合エラー */
  @Value("${efficacyjudgeresult.2}")
  private String efficacyjudgeresult_2;
  public static final String EFFICACYJUDGERESULT_2_KEY = "efficacyjudgeresult.2";

  /** 料金計算結果確定ステータス-未確定 */
  @Value("${billingfixstatus.0}")
  private String billingfixstatus_0;

  /** 料金計算結果確定ステータス-料金確定済 */
  @Value("${billingfixstatus.1}")
  private String billingfixstatus_1;

  /** 料金計算結果確定ステータス-請求作成済 */
  @Value("${billingfixstatus.2}")
  private String billingfixstatus_2;

  /** 料金計算結果確定ステータス-債権譲渡指示済 */
  @Value("${billingfixstatus.3}")
  private String billingfixstatus_3;

  /** 料金計算結果確定ステータス-債権譲渡済 */
  @Value("${billingfixstatus.4}")
  private String billingfixstatus_4;

  /** 料金計算結果確定ステータス-料金確定エラー */
  @Value("${billingfixstatus.A}")
  private String billingfixstatus_A;

  /** 料金計算結果確定ステータス-債権譲渡エラー */
  @Value("${billingfixstatus.B}")
  private String billingfixstatus_B;

  /** 部屋種別-専有部 */
  @Value("${roomClass.01}")
  private String roomClass_01;

  /** 部屋種別-共用部 */
  @Value("${roomClass.02}")
  private String roomClass_02;

  /** 部屋種別-店舗・事務所 */
  @Value("${roomClass.03}")
  private String roomClass_03;

  /** 請求対象区分-請求対象 */
  @Value("${billingTargetCategory.0}")
  private String billingTargetCategory_0;
  public static final String BILLINGTARGETCATEGORY_0_KEY = "billingTargetCategory.0";

  /** 請求対象区分-請求対象外 */
  @Value("${billingTargetCategory.1}")
  private String billingTargetCategory_1;
  public static final String BILLINGTARGETCATEGORY_1_KEY = "billingTargetCategory.1";

  /** バッチステータス：正常終了 */
  @Value("${batchstatus.0}")
  private String batchStatus_0;
  public static final String BATCHSTATUS_0_KEY = "batchstatus.0";

  /** バッチステータス：異常終了 */
  @Value("${batchstatus.1}")
  private String batchStatus_1;
  public static final String BATCHSTATUS_1_KEY = "batchstatus.1";

  /** バッチステータス：テーブルロックエラー */
  @Value("${batchstatus.2}")
  private String batchStatus_2;
  public static final String BATCHSTATUS_2_KEY = "batchstatus.2";

  /** バッチステータス：ファイル送信エラー */
  @Value("${batchstatus.3}")
  private String batchStatus_3;
  public static final String BATCHSTATUS_3_KEY = "batchstatus.3";

  /** バッチステータス：ファイル送信エラー */
  @Value("${batchstatus.9}")
  private String batchStatus_9;
  public static final String BATCHSTTUS_9_KEY = "batchstatus.9";

  /** バッチステータス：実行中 */
  @Value("${batchstatus.minus1}")
  private String batchStatus_minus1;
  public static final String BATCHSTATUS_MINUS1_KEY = "batchstatus.minus1";

  /**
   * コード定義 END
   */

  /**
   * ゲッター START
   */

  public int getMaxSearchCount() {
    return maxSearchCount;
  }

  public int getPageDisplayCount() {
    return pageDisplayCount;
  }

  public String getErrorcode_E0011() {
    return errorcode_E0011;
  }

  public String getErrorcode_E0012() {
    return errorcode_E0012;
  }

  public String getErrorcode_E0021() {
    return errorcode_E0021;
  }

  public String getErrorcode_E0022() {
    return errorcode_E0022;
  }

  public String getErrorcode_E0032() {
    return errorcode_E0032;
  }

  public String getErrorcode_E0042() {
    return errorcode_E0042;
  }

  public String getErrorcode_E0051() {
    return errorcode_E0051;
  }

  public String getErrorcode_E0052() {
    return errorcode_E0052;
  }

  public String getErrorcode_E0061() {
    return errorcode_E0061;
  }

  public String getErrorcode_E0062() {
    return errorcode_E0062;
  }

  public String getErrorcode_E0082() {
    return errorcode_E0082;
  }

  public String getErrorcode_E0101() {
    return errorcode_E0101;
  }

  public String getDiscountplanclass_1() {
    return discountplanclass_1;
  }

  public String getDiscountplanclass_2() {
    return discountplanclass_2;
  }

  public String getDiscountclass_1() {
    return discountclass_1;
  }

  public String getDiscountclass_2() {
    return discountclass_2;
  }

  public String getDiscountclass_3() {
    return discountclass_3;
  }

  public String getSupplycategory_1() {
    return supplycategory_1;
  }

  public String getSupplycategory_2() {
    return supplycategory_2;
  }

  public String getSupplystopcategory_0() {
    return supplystopcategory_0;
  }

  public String getSupplystopcategory_1() {
    return supplystopcategory_1;
  }

  public String getCalcunitcategory_1() {
    return calcunitcategory_1;
  }

  public String getCalcunitcategory_2() {
    return calcunitcategory_2;
  }

  public String getMissingflag_0() {
    return missingflag_0;
  }

  public String getMissingflag_1() {
    return missingflag_1;
  }

  public String getAuthorizationscategory_0() {
    return authorizationscategory_0;
  }

  public String getAuthorizationscategory_1() {
    return authorizationscategory_1;
  }

  public String getAuthorizationscategory_2() {
    return authorizationscategory_2;
  }

  public String getPersonalcorporationcategory_1() {
    return personalcorporationcategory_1;
  }

  public String getPersonalcorporationcategory_2() {
    return personalcorporationcategory_2;
  }

  public String getAccountclass_1() {
    return accountclass_1;
  }

  public String getAccountclass_2() {
    return accountclass_2;
  }

  public String getClaimstatus_0() {
    return claimstatus_0;
  }

  public String getClaimstatus_1() {
    return claimstatus_1;
  }

  public String getClaimstatus_2() {
    return claimstatus_2;
  }

  public String getClaimstatus_3() {
    return claimstatus_3;
  }

  public String getPaymentwaycategory_1() {
    return paymentwaycategory_1;
  }

  public String getPaymentwaycategory_2() {
    return paymentwaycategory_2;
  }

  public String getPaymentwaycategory_4() {
    return paymentwaycategory_4;
  }

  public String getCancelflag_0() {
    return cancelflag_0;
  }

  public String getCancelflag_1() {
    return cancelflag_1;
  }

  public String getReceiptstatus_0() {
    return receiptstatus_0;
  }

  public String getReceiptstatus_1() {
    return receiptstatus_1;
  }

  public String getReceiptstatus_2() {
    return receiptstatus_2;
  }

  public String getReceiptstatus_9() {
    return receiptstatus_9;
  }

  public String getReceiptresultcode_00() {
    return receiptresultcode_00;
  }

  public String getReceiptresultcode_01() {
    return receiptresultcode_01;
  }

  public String getReceiptresultcode_02() {
    return receiptresultcode_02;
  }

  public String getReceiptresultcode_03() {
    return receiptresultcode_03;
  }

  public String getReceiptresultcode_04() {
    return receiptresultcode_04;
  }

  public String getReceiptresultcode_07() {
    return receiptresultcode_07;
  }

  public String getReceiptresultcode_08() {
    return receiptresultcode_08;
  }

  public String getReceiptresultcode_09() {
    return receiptresultcode_09;
  }

  public String getReceiptresultcode_0E() {
    return receiptresultcode_0E;
  }

  public String getReceiptresultcode_0N() {
    return receiptresultcode_0N;
  }

  public String getReceiptresultcode_10() {
    return receiptresultcode_10;
  }

  public String getReceiptresultcode_12() {
    return receiptresultcode_12;
  }

  public String getReceiptresultcode_21() {
    return receiptresultcode_21;
  }

  public String getReceiptresultcode_99() {
    return receiptresultcode_99;
  }

  public String getReceiptwaycode_01() {
    return receiptwaycode_01;
  }

  public String getReceiptwaycode_02() {
    return receiptwaycode_02;
  }

  public String getReceiptwaycode_03() {
    return receiptwaycode_03;
  }

  public String getReceiptwaycode_04() {
    return receiptwaycode_04;
  }

  public String getReceiptwaycode_05() {
    return receiptwaycode_05;
  }

  public String getReceiptwaycode_06() {
    return receiptwaycode_06;
  }

  public String getReceiptwaycode_07() {
    return receiptwaycode_07;
  }

  public String getReceiptwaycode_08() {
    return receiptwaycode_08;
  }

  public String getReceiptwaycode_09() {
    return receiptwaycode_09;
  }

  public String getReceiptwaycode_14() {
    return receiptwaycode_14;
  }

  public String getReceiptwaycode_15() {
    return receiptwaycode_15;
  }

  public String getReceiptwaycode_16() {
    return receiptwaycode_16;
  }

  public String getReceiptwaycode_17() {
    return receiptwaycode_17;
  }

  public String getReceiptwaycode_21() {
    return receiptwaycode_21;
  }

  public String getReceiptwaycode_70() {
    return receiptwaycode_70;
  }

  public String getReceiptwaycode_80() {
    return receiptwaycode_80;
  }

  public String getReceiptwaycode_90() {
    return receiptwaycode_90;
  }

  public String getReceiptwaycode_99() {
    return receiptwaycode_99;
  }

  public String getProcesscategory_I() {
    return processcategory_I;
  }

  public String getProcesscategory_U() {
    return processcategory_U;
  }

  public String getPhonecategory_0() {
    return phonecategory_0;
  }

  public String getPhonecategory_1() {
    return phonecategory_1;
  }

  public String getWordingcode_00010001() {
    return wordingcode_00010001;
  }

  public String getWordingcode_00010002() {
    return wordingcode_00010002;
  }

  public String getWordingcode_00010003() {
    return wordingcode_00010003;
  }

  public String getWordingcode_00010004() {
    return wordingcode_00010004;
  }

  public String getWordingcode_00010005() {
    return wordingcode_00010005;
  }

  public String getWeekdayholidaycategory_0() {
    return weekdayholidaycategory_0;
  }

  public String getWeekdayholidaycategory_1() {
    return weekdayholidaycategory_1;
  }

  public String getWeekdayholidaycategory_2() {
    return weekdayholidaycategory_2;
  }

  public String getWeekdayholidaycategory_3() {
    return weekdayholidaycategory_3;
  }

  public String getWeekdayholidaycategory_4() {
    return weekdayholidaycategory_4;
  }

  public String getCorrectstatus_0() {
    return correctstatus_0;
  }

  public String getCorrectstatus_1() {
    return correctstatus_1;
  }

  public String getCorrectstatus_2() {
    return correctstatus_2;
  }

  public String getCorrectstatus_3() {
    return correctstatus_3;
  }

  public String getCorrectstatus_4() {
    return correctstatus_4;
  }

  public String getDetailcategory_1() {
    return detailcategory_1;
  }

  public String getDetailcategory_2() {
    return detailcategory_2;
  }

  public String getDetailcategory_3() {
    return detailcategory_3;
  }

  public String getDetailcategory_4() {
    return detailcategory_4;
  }

  public String getEfficacyjudgeresult_0() {
    return efficacyjudgeresult_0;
  }

  public String getEfficacyjudgeresult_1() {
    return efficacyjudgeresult_1;
  }

  public String getEfficacyjudgeresult_2() {
    return efficacyjudgeresult_2;
  }

  public String getBillingfixstatus_0() {
    return billingfixstatus_0;
  }

  public String getBillingfixstatus_1() {
    return billingfixstatus_1;
  }

  public String getBillingfixstatus_2() {
    return billingfixstatus_2;
  }

  public String getBillingfixstatus_3() {
    return billingfixstatus_3;
  }

  public String getRoomClass_01() {
    return roomClass_01;
  }

  public String getRoomClass_02() {
    return roomClass_02;
  }

  public String getRoomClass_03() {
    return roomClass_03;
  }

  /**
   * @return batchStatus_0
   */
  public String getBatchStatus_0() {
    return batchStatus_0;
  }

  /**
   * @return batchStatus_1
   */
  public String getBatchStatus_1() {
    return batchStatus_1;
  }

  /**
   * @return batchStatus_2
   */
  public String getBatchStatus_2() {
    return batchStatus_2;
  }

  /**
   * @return batchStatus_3
   */
  public String getBatchStatus_3() {
    return batchStatus_3;
  }

  /**
   * @return batchStatus_9
   */
  public String getBatchStatus_9() {
    return batchStatus_9;
  }

  /**
   * @return batchStatus_minus1
   */
  public String getBatchStatus_minus1() {
    return batchStatus_minus1;
  }

  public String getPaymentRecodeDate_01() {
    return paymentRecodeDate_01;
  }

  /**
   * loginlimittimesmaxのゲッター
   * 
   * @return loginlimittimesmax
   */
  public int getLoginLimitTimesMax() {
    return loginLimitTimesMax;
  }

  /**
   * batchBillingBaseDayのゲッター
   * 
   * @return batchBillingBaseDay
   */
  public String getBatchBillingBaseDay() {
    return batchBillingBaseDay;
  }

  public String getFixfeecalcUndecidecMessage_0() {
    return fixfeecalcUndecidecMessage_0;
  }

  public String getFixfeecalcUndecidecMessage_1() {
    return fixfeecalcUndecidecMessage_1;
  }

  public String getFixfeecalcUndecidecMessage_2() {
    return fixfeecalcUndecidecMessage_2;
  }

  public String getFixfeecalcUndecidecMessage_3() {
    return fixfeecalcUndecidecMessage_3;
  }

  public String getProcessname_b0101_01() {
    return processname_b0101_01;
  }

  public String getProcessname_b0101_02() {
    return processname_b0101_02;
  }

  public String getProcessname_b0101_03() {
    return processname_b0101_03;
  }

  public String getProcessname_b0101_04() {
    return processname_b0101_04;
  }

  public String getProcessname_b0101_05() {
    return processname_b0101_05;
  }

  public String getProcessname_b0101_06() {
    return processname_b0101_06;
  }

  public String getProcessname_b0102_03() {
    return processname_b0102_03;
  }

  public String getProcessname_b0103_01() {
    return processname_b0103_01;
  }

  /**
   * @return batchInfoI0001
   */
  public String getBatchInfoI0001() {
    return batchInfoI0001;
  }

  /**
   * @return batchInfoI0002
   */
  public String getBatchInfoI0002() {
    return batchInfoI0002;
  }

  /**
   * @return batchInfoE0001
   */
  public String getBatchInfoE0001() {
    return batchInfoE0001;
  }

  /**
   * @return batchInfoE0002
   */
  public String getBatchInfoE0002() {
    return batchInfoE0002;
  }

  /**
   * @return batchInfoE0003
   */
  public String getBatchInfoE0003() {
    return batchInfoE0003;
  }

  /**
   * @return batchInfoE0004
   */
  public String getBatchInfoE0004() {
    return batchInfoE0004;
  }

  /**
   * @return batchInfoE0005
   */
  public String getBatchInfoE0005() {
    return batchInfoE0005;
  }

  /**
   * @return batchInfoE0006
   */
  public String getBatchInfoE0006() {
    return batchInfoE0006;
  }

  /**
   * @return batchInfoE0007
   */
  public String getBatchInfoE0007() {
    return batchInfoE0007;
  }

  /**
   * @return batchInfoE0008
   */
  public String getBatchInfoE0008() {
    return batchInfoE0008;
  }

  /**
   * @return batchInfoE0009
   */
  public String getBatchInfoE0009() {
    return batchInfoE0009;
  }

  /**
   * @return batchInfoE0010
   */
  public String getBatchInfoE0010() {
    return batchInfoE0010;
  }

  /**
   * @return batchInfoE0011
   */
  public String getBatchInfoE0011() {
    return batchInfoE0011;
  }

  /**
   * @return batchInfoE0012
   */
  public String getBatchInfoE0012() {
    return batchInfoE0012;
  }

  /**
   * @return batchInfoE0013
   */
  public String getBatchInfoE0013() {
    return batchInfoE0013;
  }

  /**
   * @return batchInfoE0014
   */
  public String getBatchInfoE0014() {
    return batchInfoE0014;
  }

  /**
   * @return batchInfoE0015
   */
  public String getBatchInfoE0015() {
    return batchInfoE0015;
  }

  /**
   * @return batchInfoE0016
   */
  public String getBatchInfoE0016() {
    return batchInfoE0016;
  }

  /**
   * @return batchInfoE0017
   */
  public String getBatchInfoE0017() {
    return batchInfoE0017;
  }

  /**
   * @return batchInfoE0018
   */
  public String getBatchInfoE0018() {
    return batchInfoE0018;
  }

  /**
   * @return batchInfoE0019
   */
  public String getBatchInfoE0019() {
    return batchInfoE0019;
  }

  /**
   * @return batchPaymentFormat
   */
  public String getBatchPaymentFormat() {
    return batchPaymentFormat;
  }

  public String getInfoI0001() {
    return infoI0001;
  }

  public String getInfoI0002() {
    return infoI0002;
  }

  public String getInfoI0003() {
    return infoI0003;
  }

  public String getInfoI0004() {
    return infoI0004;
  }

  public String getInfoI0005() {
    return infoI0005;
  }

  public String getInfoI0006() {
    return infoI0006;
  }

  public String getErrorE0001() {
    return errorE0001;
  }

  public String getErrorE0002() {
    return errorE0002;
  }

  public String getErrorE0003() {
    return errorE0003;
  }

  public String getErrorE0004() {
    return errorE0004;
  }

  public String getErrorE0005() {
    return errorE0005;
  }

  public String getErrorE0006() {
    return errorE0006;
  }

  public String getErrorE0007() {
    return errorE0007;
  }

  public String getErrorE0008() {
    return errorE0008;
  }

  public String getErrorE0009() {
    return errorE0009;
  }

  public String getErrorE0010() {
    return errorE0010;
  }

  public String getErrorE0011() {
    return errorE0011;
  }

  public String getErrorE0012() {
    return errorE0012;
  }

  public String getErrorE0013() {
    return errorE0013;
  }

  public String getErrorE0014() {
    return errorE0014;
  }

  public String getErrorE0015() {
    return errorE0015;
  }

  public String getErrorE0016() {
    return errorE0016;
  }

  public String getErrorE0017() {
    return errorE0017;
  }

  /**
   * ゲッター END
   */

  /**
   * エラー種別の一覧マップを生成する
   * 
   * @return エラー種別マップ
   */
  public Map<String, String> createErrorCodeMap() {
    Map<String, String> errorCodeMap = new TreeMap<String, String>();
    errorCodeMap.put("E0011", errorcode_E0011);
    errorCodeMap.put("E0012", errorcode_E0012);
    errorCodeMap.put("E0021", errorcode_E0021);
    errorCodeMap.put("E0022", errorcode_E0022);
    errorCodeMap.put("E0032", errorcode_E0032);
    errorCodeMap.put("E0042", errorcode_E0042);
    errorCodeMap.put("E0051", errorcode_E0051);
    errorCodeMap.put("E0052", errorcode_E0052);
    errorCodeMap.put("E0061", errorcode_E0061);
    errorCodeMap.put("E0062", errorcode_E0062);
    errorCodeMap.put("E0082", errorcode_E0082);
    errorCodeMap.put("E0101", errorcode_E0101);
    return errorCodeMap;
  }

  /**
   * エラー種別のグループ化したマップを生成する
   * 
   * @return エラーグループマップ
   */
  public Map<String, String> createErrorClassGroupMap() {
    Map<String, String> errorGroupMap = new TreeMap<String, String>();
    errorGroupMap.put("E0011,E0012", "基本料金エラー");
    errorGroupMap.put("E0021,E0022", "電力量料金エラー");
    errorGroupMap.put("E0032", "燃料調整額エラー");
    errorGroupMap.put("E0042", "割引額エラー");
    errorGroupMap.put("E0051,E0052", "再エネ発電賦課金等エラー");
    errorGroupMap.put("E0061,E0062", "請求予定額エラー");
    errorGroupMap.put("E0082", "料金実績明細金額エラー");
    errorGroupMap.put("E0101", "請求額エラー");
    return errorGroupMap;
  }

  /**
   * 部屋種別の一覧マップを生成する
   * 
   * @return 部屋種別マップ
   */
  public Map<String, String> createRoomClassMap() {
    Map<String, String> roomClassMap = new TreeMap<String, String>();
    roomClassMap.put("01", roomClass_01);
    roomClassMap.put("02", roomClass_02);
    roomClassMap.put("03", roomClass_03);
    return roomClassMap;
  }

  /**
   * 補正ステータスの一覧マップを生成する
   * 
   * @return 補正ステータスマップ
   */
  public Map<String, String> createCorrectStatusMap() {
    Map<String, String> correctStatusMap = new TreeMap<String, String>();
    correctStatusMap.put("0", correctstatus_0);
    correctStatusMap.put("1", correctstatus_1);
    correctStatusMap.put("2", correctstatus_2);
    correctStatusMap.put("3", correctstatus_3);
    correctStatusMap.put("4", correctstatus_4);
    return correctStatusMap;
  }

  /**
   * 料金確定状況の一覧マップを生成する
   * 
   * @return 料金確定状況マップ
   */
  public Map<String, String> createBillingFixStatusMap() {
    Map<String, String> billingFixStatusMap = new TreeMap<String, String>();
    billingFixStatusMap.put(EMSConstants.BILLING_FIX_STATUS_UNDECIDEC, billingfixstatus_0);
    billingFixStatusMap.put(EMSConstants.BILLING_FIX_STATUS_DECISION, billingfixstatus_1);
    billingFixStatusMap.put(EMSConstants.BILLING_FIX_STATUS_CLAIMED, billingfixstatus_2);
    billingFixStatusMap.put(EMSConstants.BILLING_FIX_STATUS_ASSAIGNMENT_CLAIMED, billingfixstatus_3);
    billingFixStatusMap.put(EMSConstants.BILLING_FIX_STATUS_ASSAIGNMENT_CLAIMED_FIX, billingfixstatus_4);
    billingFixStatusMap.put(EMSConstants.BILLING_FIX_STATUS_DECISION_ERROR, billingfixstatus_A);
    billingFixStatusMap.put(EMSConstants.BILLING_FIX_STATUS_ASSAIGNMENT_CLAIMED_ERROR, billingfixstatus_B);
    return billingFixStatusMap;
  }

  /**
   * 支払方法区分の一覧マップを生成する
   * 
   * @return 支払方法区分マップ
   */
  public Map<String, String> getPaymentWayCategoryMap() {
    Map<String, String> paymentWayCategoryMap = new TreeMap<String, String>();
    paymentWayCategoryMap.put(EMSConstants.PAYMENT_WAY_CATEGORY_CONVENI, paymentwaycategory_1);
    paymentWayCategoryMap.put(EMSConstants.PAYMENT_WAY_CATEGORY_ACCOUNT, paymentwaycategory_2);
    paymentWayCategoryMap.put(EMSConstants.PAYMENT_WAY_CATEGORY_CREDIT, paymentwaycategory_4);
    return paymentWayCategoryMap;
  }

  /**
   * 割引種別の一覧マップを生成する
   * 
   * @return 割引種別マップ
   */
  public Map<String, String> getDiscountClassMap() {
    Map<String, String> discountClassMap = new TreeMap<String, String>();
    discountClassMap.put("1", discountclass_1);
    discountClassMap.put("2", discountclass_2);
    discountClassMap.put("3", discountclass_3);
    return discountClassMap;
  }

  /**
   * 収納結果の一覧マップを生成する
   * 
   * @return 収納結果マップ
   */
  public Map<String, String> getReceiptResultCodeMap() {
    Map<String, String> receiptResultCodeMap = new TreeMap<String, String>();
    receiptResultCodeMap.put(EMSConstants.RECEIPT_RESULT_CODE_SUCCESS, receiptresultcode_00);
    receiptResultCodeMap.put(EMSConstants.RECEIPT_RESULT_CODE_MISSING_FUND, receiptresultcode_01);
    receiptResultCodeMap.put(EMSConstants.RECEIPT_RESULT_CODE_NO_EXCHANGE, receiptresultcode_02);
    receiptResultCodeMap.put(EMSConstants.RECEIPT_RESULT_CODE_STOP_TRANSFER_DEPOSITOR, receiptresultcode_03);
    receiptResultCodeMap.put(EMSConstants.RECEIPT_RESULT_CODE_NO_ACCOUNT_TRANSFER_REQUEST, receiptresultcode_04);
    receiptResultCodeMap.put(EMSConstants.RECEIPT_RESULT_NAME_INVALID, receiptresultcode_07);
    receiptResultCodeMap.put(EMSConstants.RECEIPT_RESULT_CODE_STOP_TRANSFER_CLIENT, receiptresultcode_08);
    receiptResultCodeMap.put(EMSConstants.RECEIPT_RESULT_CODE_OTHER, receiptresultcode_09);
    receiptResultCodeMap.put(EMSConstants.RECEIPT_RESULT_CODE_ERROR, receiptresultcode_0E);
    receiptResultCodeMap.put(EMSConstants.RECEIPT_RESULT_CODE_TRANSFER_RESULT_NOT_ARRIVED, receiptresultcode_0N);
    receiptResultCodeMap.put(EMSConstants.RECEIPT_RESULT_CODE_POINT, receiptresultcode_10);
    receiptResultCodeMap.put(EMSConstants.RECEIPT_RESULT_CODE_RECEIPT_DEFICIT, receiptresultcode_12);
    receiptResultCodeMap.put(EMSConstants.RECEIPT_RESULT_CODE_RECEIPT_CANCEL, receiptresultcode_21);
    receiptResultCodeMap.put(EMSConstants.RECEIPT_RESULT_CODE_ZERO_BILLING, receiptresultcode_99);
    return receiptResultCodeMap;
  }

  /**
   * 料金確定状況未確定詳細コードマップを生成する
   * 
   * @return 料金確定状況未確定詳細コードマップ
   */
  public Map<Integer, String> getUndecidecDetailCodeMap() {
    // 料金計算結果確定画面用
    Map<Integer, String> undecidecDetailCodeMap = new HashMap<Integer, String>();
    undecidecDetailCodeMap.put(EMSConstants.UNDECIDEC_DETAIL_CODE_FIX_WAIT, fixfeecalcUndecidecMessage_0);
    undecidecDetailCodeMap.put(EMSConstants.UNDECIDEC_DETAIL_CODE_EXISTS_UN_IMPORT, fixfeecalcUndecidecMessage_1);
    undecidecDetailCodeMap.put(EMSConstants.UNDECIDEC_DETAIL_CODE_EXISTS_UN_CORRECT_ERROR, fixfeecalcUndecidecMessage_2);
    undecidecDetailCodeMap.put(EMSConstants.UNDECIDEC_DETAIL_CODE_EXISTS_UN_APPROVED_DATA, fixfeecalcUndecidecMessage_3);
    return undecidecDetailCodeMap;
  }

  /**
   * 電話番号区分の一覧マップを生成する
   * 
   * @return 電話番号区分マップ
   */
  public Map<String, String> getPhoneCategoryMap() {
    Map<String, String> phoneCategoryMap = new TreeMap<String, String>();
    phoneCategoryMap.put("0", phonecategory_0);
    phoneCategoryMap.put("1", phonecategory_1);
    return phoneCategoryMap;
  }

  /**
   * 口座種別の一覧マップを生成する
   * 
   * @return 口座種別マップ
   */
  public Map<String, String> getAccountClassMap() {
    Map<String, String> accountClassMap = new TreeMap<String, String>();
    accountClassMap.put("1", accountclass_1);
    accountClassMap.put("2", accountclass_2);
    return accountClassMap;
  }

  /**
   * 収納方法コードの一覧マップを生成する
   * 
   * @return 収納方法コード
   */
  public Map<String, String> getReceiptWayCodeMap() {
    Map<String, String> receiptWayCodeMap = new TreeMap<String, String>();
    receiptWayCodeMap.put(EMSConstants.RECEIPT_WAY_CODE_CREDIT, receiptwaycode_01);
    receiptWayCodeMap.put(EMSConstants.RECEIPT_WAY_CODE_ACCOUNT, receiptwaycode_02);
    receiptWayCodeMap.put(EMSConstants.RECEIPT_WAY_CODE_CONVENI, receiptwaycode_03);
    receiptWayCodeMap.put(EMSConstants.RECEIPT_WAY_CODE_COMP_TRANSFER, receiptwaycode_04);
    receiptWayCodeMap.put(EMSConstants.RECEIPT_WAY_CODE_REGISTERED_MAIL, receiptwaycode_05);
    receiptWayCodeMap.put(EMSConstants.RECEIPT_WAY_CODE_VISIT_COLLECTION, receiptwaycode_06);
    receiptWayCodeMap.put(EMSConstants.RECEIPT_WAY_CODE_WINDOW_PAYMENT, receiptwaycode_07);
    receiptWayCodeMap.put(EMSConstants.RECEIPT_WAY_CODE_COMPENSATION_PAYMENT, receiptwaycode_08);
    receiptWayCodeMap.put(EMSConstants.RECEIPT_WAY_CODE_CHECK, receiptwaycode_09);
    receiptWayCodeMap.put(EMSConstants.RECEIPT_WAY_CODE_OFFICE_SYNTHESIS_TRANSFER, receiptwaycode_14);
    receiptWayCodeMap.put(EMSConstants.RECEIPT_WAY_CODE_OFFICE_REGISTERED_MAIL, receiptwaycode_15);
    receiptWayCodeMap.put(EMSConstants.RECEIPT_WAY_CODE_OFFICE_VISIT_COLLECTION, receiptwaycode_16);
    receiptWayCodeMap.put(EMSConstants.RECEIPT_WAY_CODE_OFFICE_WINDOW_PAYMENT, receiptwaycode_17);
    receiptWayCodeMap.put(EMSConstants.RECEIPT_WAY_CODE_TRANSFER_COMMISSION, receiptwaycode_21);
    receiptWayCodeMap.put(EMSConstants.RECEIPT_WAY_CODE_LIQUIDATION_ADJUST_MONEY, receiptwaycode_70);
    receiptWayCodeMap.put(EMSConstants.RECEIPT_WAY_CODE_SERVICER, receiptwaycode_80);
    receiptWayCodeMap.put(EMSConstants.RECEIPT_WAY_CODE_REPURCHASE, receiptwaycode_90);
    receiptWayCodeMap.put(EMSConstants.RECEIPT_WAY_CODE_ZERO_BILLING, receiptwaycode_99);
    return receiptWayCodeMap;
  }

  /**
   * 有効性判定結果の一覧マップを生成する
   * 
   * @return 有効性判定結果マップ
   */
  public Map<String, String> getEfficacyJudgeResultMap() {
    Map<String, String> efficacyJudgeResultMap = new TreeMap<String, String>();
    efficacyJudgeResultMap.put(EMSConstants.EFFICACY_JUDGE_RESULT_OK, efficacyjudgeresult_0);
    efficacyJudgeResultMap.put(EMSConstants.EFFICACY_JUDGE_RESULT_NG, efficacyjudgeresult_1);
    efficacyJudgeResultMap.put(EMSConstants.EFFICACY_JUDGE_RESULT_ERROR, efficacyjudgeresult_2);
    return efficacyJudgeResultMap;
  }

  /**
   * 欠測有無の一覧マップを生成する
   * 
   * @return 欠測有無マップ
   */
  public Map<String, String> getMissingFlagMap() {
    Map<String, String> missingFlagMap = new TreeMap<String, String>();
    missingFlagMap.put("0", missingflag_0);
    missingFlagMap.put("1", missingflag_1);
    return missingFlagMap;
  }

  /**
   * 割引プラン種別の一覧マップを生成する
   * 
   * @return 割引プラン種別マップ
   */
  public Map<String, String> getDiscountPlanClassMap() {
    Map<String, String> discountPlanClassMap = new TreeMap<String, String>();
    discountPlanClassMap.put("1", discountplanclass_1);
    discountPlanClassMap.put("2", discountplanclass_2);
    return discountPlanClassMap;
  }

  /**
   * 債権ステータスの一覧マップを生成する
   * 
   * @return 債権ステータスマップ
   */
  public Map<String, String> getClaimStatusMap() {
    Map<String, String> claimStatusMap = new TreeMap<String, String>();
    claimStatusMap.put(EMSConstants.CLAIM_STATUS_UNDELIVERED, claimstatus_0);
    claimStatusMap.put(EMSConstants.CLAIM_STATUS_DELIVERED, claimstatus_1);
    claimStatusMap.put(EMSConstants.CLAIM_STATUS_PARTIAL_DELIVERED, claimstatus_2);
    claimStatusMap.put(EMSConstants.CLAIM_STATUS_SURPLUS_DELIVERED, claimstatus_3);
    return claimStatusMap;
  }

  /**
   * 請求対象区分の一覧マップを生成する
   * 
   * @return billingTargetCategoryMap
   */
  public Map<String, String> getBillingTargetCategoryMap() {
    Map<String, String> billingTargetCategoryMap = new TreeMap<String, String>();
    billingTargetCategoryMap.put(EMSConstants.BILLING_TARGET_CATEGORY_YES, billingTargetCategory_0);
    billingTargetCategoryMap.put(EMSConstants.BILLING_TARGET_CATEGORY_NOT, billingTargetCategory_1);

    return billingTargetCategoryMap;
  }

  /**
   * 処理名称コードマップを生成する
   * 
   * @return 処理名称コードマップ
   */
  public Map<String, String> getProcessNameCodeMap() {
    // 処理状況照会画面用
    Map<String, String> processNameCodeMap = new TreeMap<String, String>();
    processNameCodeMap.put(EMSConstants.BATCH_ID_B0101_01, processname_b0101_01);
    processNameCodeMap.put(EMSConstants.BATCH_ID_B0101_02, processname_b0101_02);
    processNameCodeMap.put(EMSConstants.BATCH_ID_B0101_03, processname_b0101_03);
    processNameCodeMap.put(EMSConstants.BATCH_ID_B0101_04, processname_b0101_04);
    processNameCodeMap.put(EMSConstants.BATCH_ID_B0101_05, processname_b0101_05);
    processNameCodeMap.put(EMSConstants.BATCH_ID_B0101_06, processname_b0101_06);
    processNameCodeMap.put(EMSConstants.BATCH_ID_B0102_03, processname_b0102_03);
    processNameCodeMap.put(EMSConstants.BATCH_ID_B0103_01, processname_b0103_01);
    return processNameCodeMap;
  }

  public Map<Integer, String> getBatchStatusNameMap() {
    Map<Integer, String> batchStatusNameMap = new TreeMap<Integer, String>();
    batchStatusNameMap.put(EMSConstants.BATCH_RESULT_CODE_SUCCESS, batchStatus_0);
    batchStatusNameMap.put(EMSConstants.BATCH_RESULT_CODE_ERROR, batchStatus_1);
    batchStatusNameMap.put(EMSConstants.BATCH_RESULT_CODE_TABLELOCK_ERROR, batchStatus_2);
    batchStatusNameMap.put(EMSConstants.BATCH_RESULT_CODE_SENDFILE_ERROR, batchStatus_3);
    batchStatusNameMap.put(EMSConstants.BATCH_RESULT_CODE_WARNING, batchStatus_9);
    batchStatusNameMap.put(EMSConstants.BATCH_RESULT_CODE_EXECUTTION, batchStatus_minus1);

    return batchStatusNameMap;
  }

  //++++++++++++++
  // enum用定義
  //++++++++++++++
  /**
   * プロパティファイルから、指定されたenumのプロパティキーに該当する値を取得する<br>
   * キーが定義ファイルに見つからない場合、NotFoundExceptionをスローする<br>
   * 指定されたenumがnullの場合、nullをリターンする
   * 
   * @param en
   *          列挙体
   * @param prop
   *          プロパティファイルを読み込んだPropertiesオブジェクト
   * @return 取得したプロパティファイルの値、引数のenumがnullの場合、null
   * @throws NotFoundException
   */
  public static <E extends DefinedProperties> String getPropertyValue(E en, Properties prop)
      throws NotFoundException {
    if (en == null) {
      return null;
    }
    String propertyValue = prop.getProperty(en.getPropertyKey());
    if (propertyValue == null) {
      throw new NotFoundException("定義ファイルのキー：" + en.getPropertyKey() + "が見つかりません");
    }
    return propertyValue;
  }

  /**
   * プロパティファイルから、指定されたenum配列の定義から<br>
   * キー：enumに定義されたキー値、値：プロパティファイルの値の<br>
   * Mapを作成し返却する<br>
   * Mapの順序は、isKeepOrder変数により保証する・しないを変動する<br>
   * キーが定義ファイルに見つからない場合、NotFoundExceptionをスローする
   * 
   * @param enumValues
   *          enumの配列（enum.values())
   * @param prop
   *          プロパティファイルを読み込んだPropertiesオブジェクト
   * @param isKeepOrder
   *          順序を保持するか否かのフラグ true:保持する false:保持しない
   * @return キー：enumに定義されたキー値、値：プロパティファイルの値の順序を保持したMap
   * @throws NotFoundException
   */
  public static <K extends Serializable, E extends Encodable<K> & DefinedProperties> Map<K, String> getPropertyMap(E[] enumValues, Properties prop,
      boolean isKeepOrder)
      throws NotFoundException {
    Map<K, String> propertyMap;
    if (isKeepOrder) {
      // ソート順を保持する場合、enumに定義された順番に設定
      propertyMap = new LinkedHashMap<K, String>(enumValues.length);
    } else {
      // ソート順を保持しない場合、ランダムに設定（高速）
      propertyMap = new HashMap<K, String>(enumValues.length);
    }
    // enumから値を取得し、プロパティファイルからMapにセット
    for (E en : enumValues) {
      String propertyValue = prop.getProperty(en.getPropertyKey());
      if (propertyValue == null) {
        throw new NotFoundException("定義ファイルのキー：" + en.getPropertyKey() + "が見つかりません");
      }
      propertyMap.put(en.encode(), propertyValue);
    }
    return propertyMap;
  }
}
