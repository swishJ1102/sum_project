package jp.co.unisys.enability.cis.common.util.rk;

import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.text.DecimalFormat;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import jp.co.unisys.enability.cis.common.Exception.RateEngineException;

/**
 * 料金計算エンジンリフレクションユーティリティクラス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RateEngineReflectionUtil {

  /** ロガー */
  private static final Logger LOGGER = LogManager.getLogger(RateEngineCommonUtil.class);

  /**
   * 指定されたオブジェクトから指定された名称のプロパティの値の取得を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 指定されたオブジェクトから指定された名称のプロパティの値を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param bean
   *          データオブジェクト
   * @param propertyName
   *          プロパティ名
   * @return プロパティの値
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   */
  public static Object getProperty(Object bean, String propertyName)
      throws RateEngineException {
    Object property = null;

    try {
      property = PropertyUtils.getProperty(bean, propertyName);
    } catch (NoSuchMethodException e) {
      LOGGER.error("RateEngineReflectionUtil＞指定されたプロパティが見つかりません。 データオブジェクト={} プロパティ={}", bean.toString(),
          propertyName);
      throw new RateEngineException("指定されたプロパティが見つかりません。プロパティ:{0}", e, propertyName);
    } catch (InvocationTargetException e) {
      LOGGER.error("RateEngineReflectionUtil＞指定されたプロパティの呼び出しに失敗しました。 データオブジェクト={} プロパティ={}", bean.toString(),
          propertyName);
      throw new RateEngineException("指定されたプロパティの呼び出しに失敗しました。プロパティ:{0}", e, propertyName);
    } catch (IllegalAccessException e) {
      LOGGER.error("RateEngineReflectionUtil＞指定されたプロパティへのアクセスが失敗しました。 データオブジェクト={} プロパティ={}", bean.toString(),
          propertyName);
      throw new RateEngineException("指定されたプロパティへのアクセスが失敗しました。プロパティ:{0}", e, propertyName);
    } catch (IllegalArgumentException e) {
      LOGGER.error("RateEngineReflectionUtil＞指定されたプロパティの呼び出しの引数が不正です。 データオブジェクト={} プロパティ={}", bean, propertyName);
      throw new RateEngineException("指定されたプロパティの呼び出しの引数が不正です。プロパティ:{0}", e, propertyName);
    }

    return property;
  }

  /**
   * 指定されたオブジェクトの指定された名称のプロパティに値を設定する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 設定先プロパティと設定値の型が一致する場合、そのまま設定する。<br>
   * 設定先プロパティの型が[String, int, long, double, BigDecimal]のいずれかで、<br>
   * 設定値の型が[BigDecimal, String]のいずれかの場合、設定先の型に変換する。<br>
   * 当メソッドは「代入」演算時に使用される想定なので、設定元オブジェクトの型は基本的にBigDecimalであることを前提とする。<br>
   * 加えて「代入」演算のパラメータに定数値を設定できるように文字列型もサポート。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param bean
   *          設定先データオブジェクト
   * @param propertyName
   *          設定先プロパティ名
   * @param value
   *          設定値
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   */
  @SuppressWarnings("rawtypes")
  public static void setProperty(Object bean, String propertyName,
      Object value) throws RateEngineException {
    try {
      PropertyDescriptor pd = PropertyUtils.getPropertyDescriptor(bean,
          propertyName);
      if (pd == null) {
        LOGGER.error("RateEngineReflectionUtil＞書き込み元プロパティの型は処理が行えません。 プロパティ={}", propertyName);
        // 書き込み元プロパティの型は処理が行えません。型.{0}
        throw new RateEngineException("error.E1342", propertyName);
      }

      if (value == null) {
        // 設定値がnullの場合はそのまま設定
        PropertyUtils.setProperty(bean, propertyName, value);
      } else {
        // 設定値がnullではない場合は、型を判定して処理を行う
        Class valueType = value.getClass();
        if (pd.getPropertyType() == valueType) {
          PropertyUtils.setProperty(bean, propertyName, value);
        } else if (valueType == BigDecimal.class) {
          // 設定値がBigDecimal型で設定先がそうじゃない数値型の場合はコンバート
          Object converted = convertFromDecimal((BigDecimal) value,
              pd.getPropertyType());
          PropertyUtils.setProperty(bean, propertyName, converted);
        } else if (valueType == String.class) {
          // 設定値がString型(予約後「定数」の場合を想定)
          Object converted = convertFromString((String) value,
              pd.getPropertyType());
          PropertyUtils.setProperty(bean, propertyName, converted);
        } else if (valueType == Integer.class) {
          // 設定値がString型(予約後「定数」の場合を想定)
          Object converted = convertFromString(String.valueOf(value),
              pd.getPropertyType());
          PropertyUtils.setProperty(bean, propertyName, converted);
        } else {
          LOGGER.error("RateEngineReflectionUtil＞書き込み元プロパティの型は処理が行えません。 プロパティ={} 型={}", propertyName,
              valueType);
          // 書き込み元プロパティの型は処理が行えません。型.{0}
          throw new RateEngineException("error.E1342",
              propertyName + " " + valueType);
        }
      }
    } catch (NoSuchMethodException e) {
      LOGGER.error("RateEngineReflectionUtil＞指定されたプロパティが見つかりません。 データオブジェクト={} プロパティ={}", bean.toString(),
          propertyName);
      throw new RateEngineException("指定されたプロパティが見つかりません。プロパティ:{0}", e, propertyName);
    } catch (InvocationTargetException e) {
      LOGGER.error("RateEngineReflectionUtil＞指定されたプロパティの呼び出しに失敗しました。 データオブジェクト={} プロパティ={}", bean.toString(),
          propertyName);
      throw new RateEngineException("指定されたプロパティの呼び出しに失敗しました。プロパティ:{0}", e, propertyName);
    } catch (IllegalAccessException e) {
      LOGGER.error("RateEngineReflectionUtil＞指定されたプロパティへのアクセスが失敗しました。 データオブジェクト={} プロパティ={}", bean.toString(),
          propertyName);
      throw new RateEngineException("指定されたプロパティへのアクセスが失敗しました。プロパティ:{0}", e, propertyName);
    } catch (IllegalArgumentException e) {
      LOGGER.error("RateEngineReflectionUtil＞指定されたプロパティの呼び出しの引数が不正です。 データオブジェクト={} プロパティ={}", bean, propertyName);
      throw new RateEngineException("指定されたプロパティの呼び出しの引数が不正です。プロパティ:{0}", e, propertyName);
    }
  }

  /**
   * BigDecimal型の値を指定された型への変換を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * BigDecimal型の値を指定された型に変換する。<br>
   * 変換先の型は[String, int, long, double]に対応。<br>
   * 変換先の型もBigDecimalだった場合は、引数の値をそのまま返却する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param decimal
   *          BigDecimal型の値
   * @param type
   *          変換先の型
   * @return 変換後の値
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   */
  @SuppressWarnings("rawtypes")
  private static Object convertFromDecimal(BigDecimal decimal, Class type)
      throws RateEngineException {
    Object ret = null;

    if (type == String.class) {
      ret = decimal.toString();
    } else if (type == int.class || type == Integer.class) {
      ret = decimal.intValue();
    } else if (type == long.class || type == Long.class) {
      ret = decimal.longValue();
    } else if (type == double.class || type == Double.class) {
      ret = decimal.doubleValue();
    } else {
      LOGGER.error("RateEngineReflectionUtil＞指定された型BigDecimalから変換できません。 型={}", type.getSimpleName());
      // 指定された型はBigDecimalに変換できません。型:{0}
      throw new RateEngineException("error.E1343",
          type.getSimpleName());
    }

    return ret;
  }

  /**
   * String型の値を指定された型への変換を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * String型の値を指定された型に変換する。<br>
   * 変換先の型は[BigDecimal, int, long, double]に対応してます。<br>
   * 変換先の型もStringだった場合は、引数の値をそのまま返却する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param numStr
   *          数値の文字列
   * @param type
   *          変換先の型
   * @return 変換後の値
   * @throws RateEngineException
   *           例外
   */
  @SuppressWarnings("rawtypes")
  private static Object convertFromString(String numStr, Class type)
      throws RateEngineException {
    Object ret = null;

    if (type == DecimalFormat.class) {
      ret = new BigDecimal(numStr);
    } else if (type == BigDecimal.class) {
      ret = new BigDecimal(numStr);
    } else if (type == Short.class) {
      ret = new Short(numStr);
    } else if (type == int.class || type == Integer.class) {
      ret = Integer.valueOf(numStr);
    } else if (type == long.class || type == Long.class) {
      ret = Long.valueOf(numStr);
    } else if (type == double.class || type == Double.class) {
      ret = Double.valueOf(numStr);
    } else {
      // 指定された型はStringに変換できません。型:{0}
      LOGGER.error("RateEngineReflectionUtil＞指定された型Stringから変換できません。 型={}", type.getSimpleName());
      throw new RateEngineException("error.E1344",
          type.getSimpleName());
    }

    return ret;
  }
}
