/*-------------------------------------------------------------------------------
 * All Rights Reserved. Copyright(C) Nihon Unisys, Ltd.
 * vendor : Nihon Unisys, Ltd.
 * since : 2014/09/01
 *-----------------------------------------------------------------------------*/
package jp.co.unisys.enability.cis.common.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.nio.charset.Charset;
import java.nio.charset.CharsetEncoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;

/**
 * チェックユーティリティクラス.<br>
 * CSVや固定長ファイルのvalidationチェックに使用するチェックメソッドを有する
 *
 */
public class CommonValidationUtil {

  /**
   * NULL、空文字チェック.<br>
   * 引数の文字列がNULLまたは空文字かどうかを判定する
   *
   * @param colum
   *          チェック対象文字列
   * @return true:nullまたは空文字 false:文字列有
   */
  public static boolean isNull(String colum) {
    boolean result = false;
    if (StringUtils.isBlank(colum)) {
      result = true;
    }
    return result;
  }

  /**
   * 桁数チェック.<br>
   * 引数の文字列が、引数で指定された桁数以内かをチェックする
   *
   * @param colum
   *          チェック対象文字列
   * @param digit
   *          最大桁数
   * @return true:範囲内 false:範囲外
   */
  public static boolean checkDigit(String colum, int digit) {
    if (colum == null || colum.equals("")) {
      return true;
    }
    boolean result = true;
    if (colum.length() > digit) {
      result = false;
    }
    return result;
  }

  /**
   * 整数部、小数部桁数チェック.<br>
   * 引数で指定した文字列が小数点を含んだ形の場合、BigDecimal型に変換し<br>
   * 整数部と小数部の桁数チェックを行う
   *
   * @param colum
   *          チェック対象の数字文字列
   * @param precision
   *          整数部最大桁数
   * @param scale
   *          小数部最大桁数
   * @return true:範囲内 false:範囲外
   */
  public static boolean checkBigDecimalDigit(String colum, int precision,
      int scale) {
    if (colum == null || colum.equals("")) {
      return true;
    }
    boolean result = true;
    BigDecimal bigdecimal = new BigDecimal(colum);
    if (bigdecimal.precision() - bigdecimal.scale() > precision) {
      result = false;
    } else if (bigdecimal.scale() > scale) {
      result = false;
    }
    return result;
  }

  /**
   * 日付フォーマットチェック.<br>
   * 引数の文字列が指定フォーマットの日付形式であるかのチェックを行う
   *
   * @param colum
   *          チェック対象の日付形式文字列
   * @param format
   *          フォーマット
   * @return true:OK false:NG
   */
  public static boolean checkDateFormat(String colum, String format) {
    if (colum == null || colum.equals("")) {
      return true;
    }
    boolean result = true;
    SimpleDateFormat dateformat = new SimpleDateFormat(format);
    dateformat.setLenient(false);
    try {
      Date parseDate = dateformat.parse(colum);
      if (!dateformat.format(parseDate).equals(colum)) {
        result = false;
      }
    } catch (ParseException e) {
      result = false;
    }
    return result;
  }

  /**
   * 日付範囲チェック.<br>
   * 引数1の日付文字列が引数2の日付文字列より小さいかのチェックを行う
   *
   * @param date1
   *          日付文字列1
   * @param date2
   *          日付文字列2
   * @return true:日付文字列2と同じまたは日付文字列2より小さい false:日付文字列2より大きい
   */
  public static boolean checkDateRange(String date1, String date2) {
    if (date1 == null || date1.equals("") || date2 == null
        || date2.equals("")) {
      return true;
    }
    boolean result = false;
    SimpleDateFormat dateformat = new SimpleDateFormat(
        EMSConstants.FORMAT_DATE_yyyyMMdd_SLASH);
    try {
      Date dateobj1 = dateformat.parse(date1);
      Date dateobj2 = dateformat.parse(date2);

      if (dateobj1.compareTo(dateobj2) <= 0) {
        result = true;
      }
    } catch (ParseException e) {
      result = false;
    }
    return result;
  }

  /**
   * 数値チェック.<br>
   * 引数の文字列が数値であるかチェックします
   *
   * @param colum
   *          チェック対象の数字文字列
   * @return true:数値 false:文字列
   */
  public static boolean isNumric(String colum) {
    if (colum == null || colum.equals("")) {
      return true;
    }
    boolean result = true;
    try {
      result = colum.matches("[0-9]+");
    } catch (Exception e) {
      result = false;
    }
    return result;
  }

  /**
   * 英数字チェック.<br>
   * 引数の文字列が英数字であるかチェックします
   *
   * @param colum
   *          チェック対象の英数字文字列
   * @return true:英数字 false:英数字以外
   */
  public static boolean isAlphabetNumric(String colum) {
    if (colum == null || colum.equals("")) {
      return true;
    }
    boolean result = true;
    try {
      result = colum.matches("[0-9a-zA-Z]+");
    } catch (Exception e) {
      result = false;
    }
    return result;
  }

  /**
   * 英数字記号チェック.<br>
   * 引数の文字列が英数字記号であるかチェックします
   *
   * @param colum
   *          チェック対象の英数字記号文字列
   * @return true:英数字記号 false:英数字記号以外
   */
  public static boolean isAlphabetNumricSignal(String colum) {
    if (colum == null || colum.equals("")) {
      return true;
    }
    boolean result = true;
    try {
      result = colum.matches("^[a-zA-Z0-9 -/:-@\\[-\\`\\{-\\~]+$");
    } catch (Exception e) {
      result = false;
    }
    return result;
  }

  /**
   * 英数字半角ハイフンチェック.<br>
   * 引数の文字列が英数字または半角ハイフンであるかチェックします
   *
   * @param colum
   *          チェック対象の英数字記号文字列
   * @return true:英数字半角ハイフン false:英数字半角ハイフン以外
   */
  public static boolean isAlphabetNumricHyphen(String colum) {
    if (colum == null || colum.equals("")) {
      return true;
    }
    boolean result = true;
    try {
      result = colum.matches("^[a-zA-Z0-9-]+$");
    } catch (Exception e) {
      result = false;
    }
    return result;
  }

  /**
   * 範囲チェック.<br>
   * 引数の文字列（数字）が引数の範囲内であるかチェックします
   *
   * @param colum
   *          チェック対象数字文字列
   * @param offset
   *          最小値
   * @param limit
   *          最大値
   * @return true:範囲内 false:範囲外
   */
  public static boolean checkRange(String colum, long offset, long limit) {
    if (colum == null || colum.equals("")) {
      return true;
    }
    boolean result = true;
    try {
      long no = Long.valueOf(colum);
      if (no < offset || no > limit) {
        result = false;
      }
    } catch (NumberFormatException e) {
      // 変換できなかった場合はNGとする
      result = false;
    }
    return result;
  }

  /**
   * 半角チェック.<br>
   * 引数の文字列が半角であるかチェックします
   *
   * @param colum
   *          チェック対象の文字列
   *
   * @return true:半角false:半角ではない
   *
   */
  public static boolean isHankakuType(String str) {
    if (str == null || str.equals("")) {
      return true;
    }
    return isRangeWordByJISX0201(str);
  }

  /**
   * 全角チェック.<br>
   * 引数の文字列が全角であるかチェックします
   *
   * @param source
   *          対象文字列
   * @return trueなら全角文字のみ 空の場合は常にtrueとなる
   */
  public static boolean isZenkakuType(String str) {
    if (str == null || str.equals("")) {
      return true;
    }
    String regText = "[^ -~｡-ﾟ]+";
    Pattern pattern = Pattern.compile(regText);
    return pattern.matcher(str).matches();
  }

  /**
   * パターンチェック.<br>
   * 引数の文字列がパターンで合わせるがどうかチェックします
   *
   * @param str
   *          チェック対象の数字文字列
   * @param checkPattern
   *          チェックパターン
   *
   * @return true:合わせる false:合わせない
   *
   */
  public static boolean checkByPattern(String str, String checkPattern) {
    if (str == null || str.equals("")) {
      return true;
    }
    boolean result = str.matches(checkPattern);
    return result;
  }

  /**
   * パターンチェック.<br>
   * 引数の文字列がパターンで合わせるがどうかチェックします
   *
   * @param str
   *          チェック対象の数字文字列
   * @param checkPattern
   *          チェックパターン
   *
   * @return true:合わせる false:合わせない
   *
   */
  public static boolean isInCodeList(String str, String[] codeList) {
    if (str == null || str.equals("")) {
      return true;
    }
    boolean checkResult = false;
    for (int i = 0; i < codeList.length; i++) {
      if (str.equals(codeList[i])) {
        checkResult = true;
        return checkResult;
      }
    }
    return checkResult;
  }

  /**
   * パターンチェック.<br>
   * 引数の文字列がパターンで合わせるがどうかチェックします
   *
   * @param str
   *          チェック対象の数字文字列
   * @param checkPattern
   *          チェックパターン
   *
   * @return true:合わせる false:合わせない
   *
   */
  public static Map<String, List<String>> batchFileFormatCheck(
      Map<String, Object> fileInfo) throws Exception {

    List<String> batchErrorList = new ArrayList<String>();
    List<String> checkOkList = new ArrayList<String>();
    List<String> rowNumberList = new ArrayList<String>();

    String fileName = (String) fileInfo.get("fileName");
    // プロパティクラスを取得する。
    EMSMessageResource emsMessageResource = (EMSMessageResource) fileInfo
        .get("emsMessageResource");
    String trailerCd = (String) fileInfo.get("trailerCd");
    Integer fileLength = (Integer) fileInfo.get("fileLength");
    String cPremixDir = (String) fileInfo.get("cPremixDir");

    Map<String, List<String>> checkResult = new HashMap<String, List<String>>();

    List<String> fileContent = new ArrayList<String>();

    String encoding = EMSConstants.ENCODE_TYPE_SJIS;

    // ログ出力用
    Integer fileLenLog = fileLength + 2;

    // ファイル情報
    File direc = new File(cPremixDir);
    File file = new File(direc, fileName);
    if (file.isFile() && file.exists()) {
      InputStreamReader read = new InputStreamReader(new FileInputStream(
          file), encoding);
      BufferedReader bufferedReader = new BufferedReader(read);

      // IF情報ファイル読込
      String lineTxt = null;

      int count = 1;
      while ((lineTxt = bufferedReader.readLine()) != null) {

        // readLineは改行コードを切り捨てるため、規定バイト数-2byteで判定
        if (lineTxt.getBytes(encoding).length != fileLength) {

          // 規定のbyte数以外の場合、エラー
          String errorContent = MessageCreater
              .makeErrorLog(
                  fileName,
                  String.valueOf(count),
                  emsMessageResource
                      .getMessage(
                          EMSMessageResource.VALIDATION_BYTELENGTH_KEY,
                          new String[] {fileLenLog
                              .toString() }));
          // エラーリスト出力準備
          batchErrorList.add(errorContent);
        }

        fileContent.add(lineTxt);
        count++;
      }

      bufferedReader.close();
      read.close();

      // IF情報ファイルフォーマットチェック
      // 行数が3行未満の場合、レコードが不足しているため、エラー
      if (fileContent.size() < 3) {
        String errorContent = MessageCreater.makeErrorLog(fileName,
            EMSConstants.ENABILITY_HEADER_RECORD,
            emsMessageResource.getMessage(
                EMSMessageResource.E0019_MSG_KEY, null));
        // エラーリスト出力準備
        batchErrorList.add(errorContent);
      } else {
        // 3行以上ある場合、各行のフォーマットをチェックする
        // ヘッダレコードチェック
        if (!(EMSConstants.CPREMIX_HEADER_RECORD.equals(fileContent
            .get(0).substring(0, 1)))) {
          String errorContent = MessageCreater
              .makeErrorLog(
                  fileName,
                  EMSConstants.ENABILITY_HEADER_RECORD,
                  emsMessageResource
                      .getMessage(
                          EMSMessageResource.VALIDATION_RANGE_KEY,
                          new String[] {
                              "ヘッダレコードのレコード識別子",
                              EMSConstants.CPREMIX_HEADER_RECORD }));
          // エラーリスト出力準備
          batchErrorList.add(errorContent);
        }

        // データレコードチェック
        for (int i = 1; i < (fileContent.size() - 2); i++) {

          // レコード識別子チェック
          if (!(EMSConstants.CPREMIX_DATA_RECORD.equals(fileContent
              .get(i).substring(0, 1)))) {
            String errorContent = MessageCreater
                .makeErrorLog(
                    fileName,
                    String.valueOf(i + 1),
                    emsMessageResource
                        .getMessage(
                            EMSMessageResource.VALIDATION_RANGE_KEY,
                            new String[] {
                                "データレコードのレコード識別子",
                                EMSConstants.CPREMIX_DATA_RECORD }));
            // エラーリスト出力準備
            batchErrorList.add(errorContent);

          } else if (!isHankakuType(fileContent.get(i))) {
            // 半角チェック
            String errorContent = MessageCreater
                .makeErrorLog(
                    fileName,
                    String.valueOf(i + 1),
                    emsMessageResource
                        .getMessage(
                            EMSMessageResource.VALIDATION_HALFWIDTH_KEY,
                            new String[] {"データレコード" }));
            // エラーリスト出力準備
            batchErrorList.add(errorContent);
          } else {
            checkOkList.add(fileContent.get(i));
            rowNumberList.add(String.valueOf(i));
          }
        }

        // トレーラレコードチェック
        if (!(trailerCd.equals(fileContent.get(fileContent.size() - 2)
            .substring(0, 1)))) {
          String errorContent = MessageCreater.makeErrorLog(fileName,
              String.valueOf(fileContent.size() - 1),
              emsMessageResource.getMessage(
                  EMSMessageResource.VALIDATION_RANGE_KEY,
                  new String[] {"トレーラレコードのレコード識別子",
                      trailerCd }));
          // エラーリスト出力準備
          batchErrorList.add(errorContent);
        }

        // エンドレコードチェック
        if (!(EMSConstants.CPREMIX_END_RECORD.equals(fileContent.get(
            fileContent.size() - 1).substring(0, 1)))) {
          String errorContent = MessageCreater.makeErrorLog(fileName,
              String.valueOf(fileContent.size()),
              emsMessageResource.getMessage(
                  EMSMessageResource.VALIDATION_RANGE_KEY,
                  new String[] {"エンドレコードのレコード識別子",
                      EMSConstants.CPREMIX_END_RECORD }));
          // エラーリスト出力準備
          batchErrorList.add(errorContent);
        }
      }
    }

    checkResult.put("batchErrorList", batchErrorList);
    checkResult.put("checkOkList", checkOkList);
    checkResult.put("rowNumberList", rowNumberList);

    return checkResult;
  }

  /**
   * 独自validation用BigDecimal型文字列桁数チェック<br>
   * 正規表現で以下の桁数を判定する<br>
   * 整数部：0～整数部桁数-1<br>
   * 小数部：指定された桁数まで
   *
   * @param input
   *          入力文字列
   * @param precision
   *          整数部桁数
   * @param scale
   *          少数桁数
   * @return
   */
  public static boolean checkBigDecimalStringDigit(String input,
      int precision, int scale) {
    // 空文字列はチェックしない
    if (StringUtils.isBlank(input)) {
      return true;
    }
    // 正規表現設定
    String regex = "^-?(0|[1-9]\\d{0,".concat(String.valueOf(precision - 1))
        .concat("})(\\.\\d{0");
    if (scale > 1) {
      regex = regex.concat(",").concat(String.valueOf(scale));
    }
    regex = regex.concat("})?$");
    // 判定
    if (input.matches(regex)) {
      return true;
    } else {
      return false;
    }
  }

  /**
   * 引数に指定された文字列がBigDecimal型に変換可能かを判定する
   *
   * @param input
   *          判定する文字列
   * @return 変換可否
   */
  public static boolean isBigDecimal(String input) {
    try {
      new BigDecimal(input);
      return true;
    } catch (NumberFormatException ne) {
      return false;
    }
  }

  /**
   * 引数に指定された文字列がInteger型に変換可能かを判定する
   *
   * @param input
   *          判定する文字列
   * @return 変換可否
   */
  public static boolean isInteger(String input) {
    try {
      new Integer(input);
      return true;
    } catch (NumberFormatException ne) {
      return false;
    }
  }

  /**
   * 引数の文字列をBigDecimal型へ変換し、正の値のチェックを行う
   *
   * @param inputStr
   *          入力文字列
   * @return true:0以上 false:0未満
   */
  public static boolean checkBigDecimalPlus(String inputStr) {
    // 空の場合は正常リターン
    if (StringUtils.isEmpty(inputStr)) {
      return true;
    }

    // BigDecimal型へ変換しチェック
    double zeroDouble = 0;
    BigDecimal input = new BigDecimal(inputStr);

    if (input.doubleValue() < zeroDouble) {
      return false;
    } else {
      return true;
    }
  }

  /**
   * 引数の文字列をInteger型へ変換し、正の値のチェックを行う
   *
   * @param inputStr
   *          入力文字列
   * @return true:0以上 false:0未満
   */
  public static boolean checkIntegerPlus(String inputStr) {
    // 空の場合は正常リターン
    if (StringUtils.isEmpty(inputStr)) {
      return true;
    }

    // Integer型へ変換しチェック
    Integer input = new Integer(inputStr);

    if (input < 0) {
      return false;
    } else {
      return true;
    }
  }

  /**
   * 指定された Date 型 が 同一日かを返します。
   *
   * @param date1
   *          対象日付
   * @param date2
   *          対象日付
   * @return true: 同一日付である, false:同一日付ではない
   */
  public static Boolean equalDate(Date date1, Date date2) {
    if (date1 == null) {
      date1 = StringConvertUtil.stringToDate("19000101",
          EMSConstants.FORMAT_DATE_yyyyMMdd);
    }
    if (date2 == null) {
      date2 = StringConvertUtil.stringToDate("19000101",
          EMSConstants.FORMAT_DATE_yyyyMMdd);
    }
    if (date1.compareTo(date2) == 0) {
      return true;
    } else {
      return false;
    }
  }

  /**
   * 指定された BigDecimal 型 が 同一かを返します。
   *
   * @param value1
   *          対象値
   * @param value2
   *          対象値
   * @return true: 同一である, false:同一ではない
   */
  public static Boolean equalBigDecimal(BigDecimal value1, BigDecimal value2) {
    if (value1 == null) {
      value1 = BigDecimal.ZERO;
    }
    if (value2 == null) {
      value2 = BigDecimal.ZERO;
    }
    if (value1.compareTo(value2) == 0) {
      return true;
    } else {
      return false;
    }
  }

  /**
   * 指定された Integer 型 が 同一かを返します。
   *
   * @param value1
   *          対象値
   * @param value2
   *          対象値
   * @return true: 同一である, false:同一ではない
   */
  public static Boolean equalInteger(Integer value1, Integer value2) {
    if (value1 == null) {
      value1 = 0;
    }
    if (value2 == null) {
      value2 = 0;
    }
    if (value1.compareTo(value2) == 0) {
      return true;
    } else {
      return false;
    }
  }

  /**
   * 指定された Short 型 が 同一かを返します。
   *
   * @param value1
   *          対象値
   * @param value2
   *          対象値
   * @return true: 同一である, false:同一ではない
   */
  public static Boolean equalShort(Short value1, Short value2) {
    if (value1 == null) {
      value1 = 0;
    }
    if (value2 == null) {
      value2 = 0;
    }
    if (value1.compareTo(value2) == 0) {
      return true;
    } else {
      return false;
    }
  }

  /**
   * 低圧CIS許容文字チェック。
   *
   * <pre>
   * <p><b>【仕様詳細】<b><p>
   * 引数の文字列が、低圧CISで許容する以下の範囲であるかチェックする。
   * ・ASCII（半角英数字記号）
   * ・JISX0208（JIS1区-8区、JIS第一水準漢字、JIS第二水準漢字）
   *   ※ただし、半角引用符(ダブルクォート)は許容文字から除外する。
   * </pre>
   *
   * @param str
   *          チェック対象文字列
   * @return 引数の文字列が許容文字で構成されていればtrue、許容されない文字を含む場合はfalse
   */
  public static Boolean isRangeWordByECIS(String str) {
    if (str == null) {
      return false;
    }

    // 半角引用符チェック
    int halfDq = str.indexOf("\"");
    if (halfDq != -1) {
      return false;
    }

    char[] chararray = str.toCharArray();

    // 半角英数字記号、JIS0208チェック
    for (int cnt = 0; cnt < chararray.length; cnt++) {
      if (!canEncodeByCharset(String.valueOf(chararray[cnt]), "ASCII")
          && !isRangeWordByJISX0208(String.valueOf(chararray[cnt]))) {
        return false;
      }

    }

    return true;
  }

  /**
   * MDMS許容文字チェック。
   *
   * <pre>
   * <p><b>【仕様詳細】<b><p>
   * 引数の文字列が、MDMSで許容する以下の範囲であるかチェックする。
   * ・JISX0201（半角英数字記号、半角カタカナ）
   * ・JISX0208（JIS1区-8区、JIS第一水準漢字、JIS第二水準漢字）
   * </pre>
   *
   * @param str
   *          チェック対象文字列
   * @return 引数の文字列が許容文字で構成されていればtrue、許容されない文字を含む場合はfalse
   */
  public static Boolean isRangeWordByJISX0201_0208(String str) {
    if (str == null) {
      return false;
    }

    char[] chararray = str.toCharArray();

    // JISX0201、JISX0208チェック
    for (int cnt = 0; cnt < chararray.length; cnt++) {
      if (!isRangeWordByJISX0201(String.valueOf(chararray[cnt]))
          && !isRangeWordByJISX0208(String.valueOf(chararray[cnt]))) {
        return false;
      }
    }

    return true;
  }

  /**
   * MDMS許容文字置き換え。
   *
   * <pre>
   * <p><b>【仕様詳細】<b><p>
   * 引数の文字列が、MDMSで許容する以下の範囲であるかチェックする。
   * ・JISX0201（半角英数字記号、半角カタカナ）
   * ・JISX0208（JIS1区-8区、JIS第一水準漢字、JIS第二水準漢字）
   * 許容しない文字は置き換え用文字に変更する
   * </pre>
   *
   * @param str
   *          チェック対象文字列
   * @param rep
   *          置き換え用文字
   * @return 置き換え後文字列
   */
  public static String changeRangeWordByJISX0201_0208(String str, char rep) {

    char[] chararray = str.toCharArray();

    // JISX0201、JISX0208チェック
    for (int cnt = 0; cnt < chararray.length; cnt++) {
      if (!isRangeWordByJISX0201(String.valueOf(chararray[cnt]))
          && !isRangeWordByJISX0208(String.valueOf(chararray[cnt]))) {
        chararray[cnt] = rep;
      }
    }
    return String.valueOf(chararray);
  }

  /**
   * 決済代行許容文字チェック。
   *
   * <pre>
   * <p><b>【仕様詳細】<b><p>
   * 引数の文字列が、決済代行で許容する以下の範囲であるかチェックする。
   * ・JISX0201（半角英数字記号、半角カタカナ）
   * </pre>
   *
   * @param str
   *          チェック対象文字列
   * @return 引数の文字列が許容文字で構成されていればtrue、許容されない文字を含む場合はfalse
   */
  public static Boolean isRangeWordByJISX0201(String str) {
    return canEncodeByCharset(str, "JIS_X0201");
  }

  /**
   * JISX0208文字チェック。
   *
   * <pre>
   * <p><b>【仕様詳細】<b><p>
   * 引数の文字列が、以下の文字セットで構成されているかチェックする。
   * ・JISX0208（JIS1区-8区、JIS第一水準漢字、JIS第二水準漢字）
   * チェック対象文字列がUTF-8の場合、SJISに変換してからチェックを行う。
   * </pre>
   *
   * @param str
   *          チェック対象文字列
   * @return 引数の文字列が許容文字で構成されていればtrue、許容されない文字を含む場合はfalse
   */
  public static Boolean isRangeWordByJISX0208(String str) {
    // チェック対象の文字列がunicodeの場合、特定の文字列をJISに変換後にチェックする
    try {
      str = StringConvertUtil.utf8ToSjis(str);
    } catch (UnsupportedEncodingException e) {
      // サポートされていない文字コードの場合はNGを返却
      return false;
    }
    return canEncodeByCharset(str, "x-JIS0208");
  }

  /**
   * 指定文字セットエンコード可否チェック。
   *
   * <pre>
   * <p><b>【仕様詳細】<b><p>
   * 引数の文字列が、引数の文字セットでエンコード可能かをチェックします。
   * {@link CharsetEncoder#canEncode(CharSequence)}のラッパーメソッドです。
   * </pre>
   *
   * @param str
   *          チェック対象文字列
   * @param charSet
   *          文字セット
   * @return エンコード可能な場合はtrue、エンコードできない場合はfalse
   */
  private static Boolean canEncodeByCharset(String str, String charSet) {
    if (str == null) {
      return false;
    }

    CharsetEncoder encoder = Charset.forName(charSet).newEncoder();

    return encoder.canEncode(str);
  }

  /**
   * 文字列指定長チェック。
   *
   * <pre>
   * <p><b>【仕様詳細】<b><p>
   * 引数の文字列が、引数で指定された長さで構成されているかチェックする。
   * （空文字は許容する）
   * </pre>
   *
   * @param str
   *          チェック対象文字列
   * @param justDigit
   *          指定桁数
   * @return true:指定桁数,false:指定桁数外
   */
  public static boolean justLength(String str, int justDigit) {
    boolean result = true;

    if (str == null || (str.length() > 0 && str.length() != justDigit)) {
      result = false;
    }
    return result;
  }

  /**
   * 文字列最小長チェック。
   *
   * <pre>
   * <p><b>【仕様詳細】<b><p>
   * 引数の文字列が、引数で指定された長さ以上で構成されているかチェックする
   * </pre>
   *
   * @param str
   *          チェック対象文字列
   * @param minDigit
   *          最小桁数
   * @return true：最小桁数以上,false：最小桁数未満
   */
  public static boolean minLength(String str, int minDigit) {
    boolean result = true;

    if (str == null || str.length() < minDigit) {
      result = false;
    }

    return result;
  }

  /**
   * 文字列最大長チェック。
   *
   * <pre>
   * <p><b>【仕様詳細】<b><p>
   * 引数の文字列が、引数で指定された長さ以下で構成されているかチェックする。
   * </pre>
   *
   * @param str
   *          チェック対象文字列
   * @param maxDigit
   *          最大桁数
   * @return true：最大桁数以下,false：最大桁数超過
   */
  public static boolean maxLength(String str, int maxDigit) {
    boolean result = true;

    if (str == null || str.length() > maxDigit) {
      result = false;
    }

    return result;
  }

}
