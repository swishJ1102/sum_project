/*-------------------------------------------------------------------------------
 * All Rights Reserved. Copyright(C) Nihon Unisys, Ltd.
 * vendor : Nihon Unisys, Ltd.
 * since : 2014/09/01
 *-----------------------------------------------------------------------------*/
package jp.co.unisys.enability.cis.common.util;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Map;

import org.apache.struts2.util.StrutsTypeConverter;

import com.opensymphony.xwork2.conversion.TypeConversionException;

/**
 * タイムスタンプ型コンバータ.<br>
 * 画面とBeanの間の型変換を行うクラス
 * <p>
 * <h2>Beanから画面用の型変換</h2> Bean引数のjava.sql.Timestamp型をyyyy/MM/dd HH:mm:ssフォーマットのString型に変換<br>
 * <h2>画面からBean用の型変換</h2> 画面入力項目のString型をBeanのjava.sql.Timestamp型にyyyy/MM/dd HH:mm:ssフォーマットで変換<br>
 * </p>
 */
public class TimestampConverter extends StrutsTypeConverter {

  /** タイムスタンプのフォーマット */
  private static final String TIMESTAMP_FORMAT = "yyyy/MM/dd HH:mm:ss";

  /* (非 Javadoc)
   * @see org.apache.struts2.util.StrutsTypeConverter#convertFromString(java.util.Map, java.lang.String[], java.lang.Class)
   */
  @Override
  public Object convertFromString(Map context, String[] values, Class toClass) {
    Object result = null;
    if (values != null) {
      result = convertDateValue(context, values[0], toClass);
    }
    return result;
  }

  /**
   * 引数のオブジェクトを指定フォーマット(yyyy/MM/dd HH:mm:ss)の文字列へ変換する<br>
   * 変換に失敗した場合はTypeConversionExceptionをスローする<br>
   * 
   * @param context
   *          コンテキスト
   * @param valueObj
   *          引数
   * @param toClass
   *          変換後の型
   *
   * @return タイムスタンプオブジェクト
   */
  protected Object convertDateValue(Map context, Object valueObj, Class toClass) {
    Timestamp result = null;

    SimpleDateFormat format = new SimpleDateFormat(TIMESTAMP_FORMAT);
    String value = valueObj.toString();

    try {
      if (value.length() != 0) {
        result = new Timestamp(format.parse(value).getTime());
      }
    } catch (ParseException e) {
      super.performFallbackConversion(context, value, toClass);
      throw new TypeConversionException();

    }

    return result;
  }

  /* (非 Javadoc)
   * @see org.apache.struts2.util.StrutsTypeConverter#convertToString(java.util.Map, java.lang.Object)
   */
  @Override
  public String convertToString(Map context, Object o) {
    String result = null;
    SimpleDateFormat format = new SimpleDateFormat(TIMESTAMP_FORMAT);
    result = format.format(o);
    return result;
  }

}
