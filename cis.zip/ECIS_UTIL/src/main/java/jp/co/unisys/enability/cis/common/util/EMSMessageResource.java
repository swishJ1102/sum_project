/*-------------------------------------------------------------------------------
 * All Rights Reserved. Copyright(C) Nihon Unisys, Ltd.
 * vendor : Nihon Unisys, Ltd.
 * since : 2014/09/01
 * revision：2015/04/20 【ph3開発】経理帳票対応
 *-----------------------------------------------------------------------------*/
package jp.co.unisys.enability.cis.common.util;

import java.util.Locale;

import org.springframework.context.MessageSource;

/**
 * EMSプロパティキー.<br>
 * プロパティファイルのキー情報を管理します
 */
public class EMSMessageResource {

  /** メッセージプロパティ */
  private MessageSource messageSource;

  /**
   * messageSourceのセッター
   * 
   * @param messageSource
   *          セットする messageSource
   */
  public void setMessageSource(MessageSource messageSource) {
    this.messageSource = messageSource;
  }

  /**
   * プロパティからメッセージを取得する。 パラメータがある場合はバインドさせたメッセージとなる。
   * 
   * @param messageKey
   *          メッセージキー
   * @param params
   *          パラメータ配列
   * @return メッセージ
   */
  public String getMessage(String messageKey, Object[] params) {
    return messageSource.getMessage(messageKey, params, MESSAGE_LOCALE);
  }

  /** メッセージプロパティのロケール設定 */
  public static final Locale MESSAGE_LOCALE = Locale.getDefault();

  public static final String I0001_MSG_KEY = "info.I0001";

  public static final String I0002_MSG_KEY = "info.I0002";

  public static final String I0003_MSG_KEY = "info.I0003";

  public static final String I0004_MSG_KEY = "info.I0004";

  public static final String I0005_MSG_KEY = "info.I0005";

  public static final String I0006_MSG_KEY = "info.I0006";

  public static final String I0007_MSG_KEY = "info.I0007";

  public static final String I0008_MSG_KEY = "info.I0008";

  public static final String I0009_MSG_KEY = "info.I0009";

  public static final String I0010_MSG_KEY = "info.I0010";

  public static final String I0011_MSG_KEY = "info.I0011";

  public static final String I0012_MSG_KEY = "info.I0012";

  public static final String W0001_MSG_KEY = "warn.W0001";

  public static final String W0002_MSG_KEY = "warn.W0002";

  public static final String W0003_MSG_KEY = "warn.W0003";

  public static final String W0004_MSG_KEY = "warn.W0004";

  public static final String W0005_MSG_KEY = "warn.W0005";

  public static final String W0006_MSG_KEY = "warn.W0006";

  public static final String E0001_MSG_KEY = "error.E0001";

  public static final String E0002_MSG_KEY = "error.E0002";

  public static final String E0003_MSG_KEY = "error.E0003";

  public static final String E0004_MSG_KEY = "error.E0004";

  public static final String E0005_MSG_KEY = "error.E0005";

  public static final String E0006_MSG_KEY = "error.E0006";

  public static final String E0007_MSG_KEY = "error.E0007";

  public static final String E0008_MSG_KEY = "error.E0008";

  public static final String E0009_MSG_KEY = "error.E0009";

  public static final String E0010_MSG_KEY = "error.E0010";

  public static final String E0011_MSG_KEY = "error.E0011";

  public static final String E0012_MSG_KEY = "error.E0012";

  public static final String E0013_MSG_KEY = "error.E0013";

  public static final String E0014_MSG_KEY = "error.E0014";

  public static final String E0015_MSG_KEY = "error.E0015";

  public static final String E0016_MSG_KEY = "error.E0016";

  public static final String E0017_MSG_KEY = "error.E0017";

  public static final String E0018_MSG_KEY = "error.E0018";

  public static final String E0019_MSG_KEY = "error.E0019";

  public static final String E0020_MSG_KEY = "error.E0020";

  public static final String E0021_MSG_KEY = "error.E0021";

  public static final String E0022_MSG_KEY = "error.E0022";

  public static final String E0023_MSG_KEY = "error.E0023";

  public static final String E0024_MSG_KEY = "error.E0024";

  public static final String E0025_MSG_KEY = "error.E0025";

  public static final String E0026_MSG_KEY = "error.E0026";

  public static final String E0027_MSG_KEY = "error.E0027";

  public static final String E0028_MSG_KEY = "error.E0028";

  public static final String E0029_MSG_KEY = "error.E0029";

  public static final String E0030_MSG_KEY = "error.E0030";

  public static final String E0031_MSG_KEY = "error.E0031";

  public static final String E0032_MSG_KEY = "error.E0032";

  public static final String E0033_MSG_KEY = "error.E0033";

  public static final String E0034_MSG_KEY = "error.E0034";

  public static final String E0035_MSG_KEY = "error.E0035";

  public static final String E0036_MSG_KEY = "error.E0036";

  public static final String E0037_MSG_KEY = "error.E0037";

  public static final String E0038_MSG_KEY = "error.E0038";

  public static final String E0039_MSG_KEY = "error.E0039";

  public static final String E0040_MSG_KEY = "error.E0040";

  public static final String E0041_MSG_KEY = "error.E0041";

  public static final String E0042_MSG_KEY = "error.E0042";

  public static final String E0043_MSG_KEY = "error.E0043";

  public static final String VALIDATION_REQUIREDSTRING_KEY = "validation.requiredstring";

  public static final String VALIDATION_MINLENGTH_KEY = "validation.minlength";

  public static final String VALIDATION_MAXLENGTH_KEY = "validation.maxlength";

  public static final String VALIDATION_STRINGLENGTH_KEY = "validation.stringlength";

  public static final String VALIDATION_REGEX_KEY = "validation.regex";

  public static final String VALIDATION_REGEX_ITEM_KEY = "validation.regexitem";

  public static final String VALIDATION_INT_KEY = "validation.int";

  public static final String VALIDATION_PERIOD_KEY = "validation.period";

  public static final String VALIDATION_FULLWIDTH_KEY = "validation.fullwidth";

  public static final String VALIDATION_HALFWIDTH_KEY = "validation.halfwidth";

  public static final String VALIDATION_RANGE_KEY = "validation.range";

  public static final String VALIDATION_ALPHANUMERIC_KEY = "validation.alphanumeric";

  public static final String VALIDATION_ALPHANUMERICSIGNAL_KEY = "validation.alphanumericsignal";

  public static final String VALIDATION_ALPHANUMERICHYPHEN_KEY = "validation.alphanumerichyphen";

  public static final String VALIDATION_COMPARE_KEY = "validation.compare";

  public static final String VALIDATION_MONEYRANGE = "validation.moneyrange";

  public static final String VALIDATION_ARGUMENT_REGEX_KEY = "validation.argumentregex";

  public static final String VALIDATION_ARGUMENT_REQUIRED_KEY = "validation.argumentrequired";

  public static final String VALIDATION_ARGUMENT_LENGTH_KEY = "validation.argumentlength";

  public static final String VALIDATION_NOT_ENTERED_KEY = "validation.notentered";

  public static final String VALIDATION_EITHER_KEY = "validation.either";

  public static final String VALIDATION_BYTELENGTH_KEY = "validation.bytelength";

  public static final String VALIDATION_REQUIREDRELATE_KEY = "validation.requiredrelate";

  public static final String VALIDATION_NOTENTEREDRELATE_KEY = "validation.notenteredrelate";

  public static final String VALIDATION_ILLEGALRELATE_KEY = "validation.illegalrelate";

  public static final String VALIDATION_DUPLICATE_KEY = "validation.duplicate";

  public static final String VALIDATION_REQUIRED_CHECK = "validation.requiredcheck";

  /**
   * 列挙体：INFOメッセージのプロパティキー
   */
  public enum MessageKeyInfo implements DefinedProperties {
    I0001("info.I0001"), I0002("info.I0002"), I0003("info.I0003"), I0004("info.I0004"), I0005("info.I0005"), I0006("info.I0006"), I0007("info.I0007"), I0008(
        "info.I0008"), I0009("info.I0009"), I0010("info.I0010"), I0011("info.I0011"), I0012("info.I0012"),
        ;

    private String propertyKey;

    private MessageKeyInfo(String propertyKey) {
      this.propertyKey = propertyKey;
    }

    @Override
    public String getPropertyKey() {
      return this.propertyKey;
    }
  }

  /**
   * 列挙体：WARNメッセージのプロパティキー
   */
  public enum MessageKeyWarning implements DefinedProperties {
    W0001("warn.W0001"), W0002("warn.W0002"), W0003("warn.W0003"), W0004("warn.W0004"), W0005("warn.W0005"), W0006("warn.W0006"),
    ;

    private String propertyKey;

    private MessageKeyWarning(String propertyKey) {
      this.propertyKey = propertyKey;
    }

    @Override
    public String getPropertyKey() {
      return this.propertyKey;
    }
  }

  /**
   * 列挙体：ERRORメッセージのプロパティキー
   */
  public enum MessageKeyError implements DefinedProperties {
    E0001("error.E0001"), E0002("error.E0002"), E0003("error.E0003"), E0004("error.E0004"), E0005("error.E0005"), E0006("error.E0006"), E0007(
        "error.E0007"), E0008("error.E0008"), E0009("error.E0009"), E0010("error.E0010"), E0011("error.E0011"), E0012("error.E0012"), E0013(
            "error.E0013"), E0014("error.E0014"), E0015("error.E0015"), E0016("error.E0016"), E0017("error.E0017"), E0018("error.E0018"), E0019(
                "error.E0019"), E0020("error.E0020"), E0021("error.E0021"), E0022("error.E0022"), E0023("error.E0023"), E0024("error.E0024"), E0025(
                    "error.E0025"), E0026("error.E0026"), E0027("error.E0027"), E0028("error.E0028"), E0029("error.E0029"), E0030("error.E0030"), E0031(
                        "error.E0031"), E0032("error.E0032"), E0033("error.E0033"), E0034("error.E0034"), E0035("error.E0035"), E0036("error.E0036"), E0037(
                            "error.E0037"), E0038("error.E0038"), E0039(
                                "error.E0039"), E0040("error.E0040"), E0041("error.E0041"), E0042("error.E0042"), E0043("error.E0043"), E0044("error.E0044"),
                                ;

    private String propertyKey;

    private MessageKeyError(String propertyKey) {
      this.propertyKey = propertyKey;
    }

    @Override
    public String getPropertyKey() {
      return this.propertyKey;
    }
  }

  /**
   * 列挙体：validationメッセージのプロパティキー
   */
  public enum MessageKeyValidation implements DefinedProperties {
    REQUIRED_STRING("validation.requiredstring"), MIN_LENGTH("validation.minlength"), MAX_LENGTH("validation.maxlength"), STRING_LENGTH(
        "validation.stringlength"), REGEX("validation.regex"), REGEX_ITEM("validation.regexitem"), INT("validation.int"), PERIOD(
            "validation.period"), FULL_WIDTH("validation.fullwidth"), HALF_WIDTH("validation.halfwidth"), RANGE("validation.range"), ALPHA_NUMERIC(
                "validation.alphanumeric"), ALPHA_NUMERIC_SIGNAL("validation.alphanumericsignal"), COMPARE("validation.compare"), MONEY_RANGE(
                    "validation.moneyrange"), ARGUMENT_REGEX("validation.argumentregex"), ARGUMENT_REQUIRED("validation.argumentrequired"), ARGUMENT_LENGTH(
                        "validation.argumentlength"), NOT_ENTERED(
                            "validation.notentered"), EITHER("validation.either"), BYTE_LENGTH("validation.bytelength"), REQUIRED_RELATE(
                                "validation.requiredrelate"), NOTENTERED_RELATE("validation.notenteredrelate"), ILLEGAL_RELATE(
                                    "validation.illegalrelate"), DUPLICATE("validation.duplicate"), REQUIRED_CHECK("validation.requiredcheck"),
                                    ;

    private String propertyKey;

    private MessageKeyValidation(String propertyKey) {
      this.propertyKey = propertyKey;
    }

    @Override
    public String getPropertyKey() {
      return this.propertyKey;
    }
  }
}