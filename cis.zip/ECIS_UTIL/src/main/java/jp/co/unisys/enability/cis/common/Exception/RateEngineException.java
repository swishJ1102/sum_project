package jp.co.unisys.enability.cis.common.Exception;

/**
 * 料金計算エンジン例外クラス.<br>
 * 料金計算エンジンの処理にて利用する料金計算エンジン例外クラス.
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RateEngineException extends Exception {

  /**
   * メッセージパラメータ
   */
  private String[] parameters;

  /**
   * parametersのゲッター
   *
   * @return parameters
   */
  public String[] getParameters() {
    return parameters;
  }

  /**
   * 引数のメッセージ、パラメータを元にエンジン例外クラスを生成します
   * 
   * @param messageKey
   * @param parameters
   */
  public RateEngineException(String messageKey, String... parameters) {
    super(messageKey);
    this.parameters = parameters;
  }

  /**
   * 引数のメッセージ、例外クラス、パラメータを元にエンジン例外クラスを生成します
   * 
   * @param messageKey
   * @param cause
   * @param parameters
   */
  public RateEngineException(String messageKey, Throwable cause, String... parameters) {
    super(messageKey, cause);
    this.parameters = parameters;
  }

}
