package jp.co.unisys.enability.cis.common.util.model;

/**
 * 連絡先情報チェックUtilBean
 *
 * @author "Nihon Unisys, Ltd."
 */
public class CheckContactInformationUtilBean {

  /**
   * 連絡先個人・法人区分コードを保有する。
   */
  private String contactInformationinDividualLegalEntityCategoryCode;

  /**
   * 連絡先氏名（カナ）を保有する。
   */
  private String contractInformationNameKana;

  /**
   * 連絡先氏名1を保有する。
   */
  private String contractInformationName1;

  /**
   * 連絡先氏名2を保有する。
   */
  private String contractInformationName2;

  /**
   * 連絡先住所（郵便番号）を保有する。
   */
  private String contractInformationAddressPostalCode;

  /**
   * 連絡先住所（住所）を保有する。
   */
  private String contractInformationAddressFull;

  /**
   * 連絡先住所（建物・部屋名）を保有する。
   */
  private String contractInformationAddressBuilding;

  /**
   * 連絡先電話区分コードを保有する。
   */
  private String contractInformationCategoryCode;

  /**
   * 連絡先電話（市外局番）を保有する。
   */
  private String contractInformationAreaCode;

  /**
   * 連絡先電話（市内局番）を保有する。
   */
  private String contractInformationLocalNo;

  /**
   * 連絡先電話（加入者番号）を保有する。
   */
  private String contractInformationDirectoryNo;

  /**
   * 連絡先個人・法人区分コードのgetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先個人・法人区分コードを取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 連絡先個人・法人区分コード
   */
  public String getContactInformationinDividualLegalEntityCategoryCode() {
    return this.contactInformationinDividualLegalEntityCategoryCode;
  }

  /**
   * 連絡先個人・法人区分コードのsetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先個人・法人区分コードを設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param contactInformationinDividualLegalEntityCategoryCode
   *          連絡先個人・法人区分コード
   */
  public void setContactInformationinDividualLegalEntityCategoryCode(String contactInformationinDividualLegalEntityCategoryCode) {
    this.contactInformationinDividualLegalEntityCategoryCode = contactInformationinDividualLegalEntityCategoryCode;
  }

  /**
   * 連絡先氏名（カナ）のgetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先氏名（カナ）を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 連絡先氏名（カナ）
   */
  public String getContractInformationNameKana() {
    return this.contractInformationNameKana;
  }

  /**
   * 連絡先氏名（カナ）のsetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先氏名（カナ）を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param contractInformationNameKana
   *          連絡先氏名（カナ）
   */
  public void setContractInformationNameKana(String contractInformationNameKana) {
    this.contractInformationNameKana = contractInformationNameKana;
  }

  /**
   * 連絡先氏名1のgetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先氏名1を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 連絡先氏名1
   */
  public String getContractInformationName1() {
    return this.contractInformationName1;
  }

  /**
   * 連絡先氏名1のsetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先氏名1を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param contractInformationName1
   *          連絡先氏名1
   */
  public void setContractInformationName1(String contractInformationName1) {
    this.contractInformationName1 = contractInformationName1;
  }

  /**
   * 連絡先氏名2のgetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先氏名2を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 連絡先氏名2
   */
  public String getContractInformationName2() {
    return this.contractInformationName2;
  }

  /**
   * 連絡先氏名2のsetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先氏名2を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param contractInformationName2
   *          連絡先氏名2
   */
  public void setContractInformationName2(String contractInformationName2) {
    this.contractInformationName2 = contractInformationName2;
  }

  /**
   * 連絡先住所（郵便番号）のgetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先住所（郵便番号）を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 連絡先住所（郵便番号）
   */
  public String getContractInformationAddressPostalCode() {
    return this.contractInformationAddressPostalCode;
  }

  /**
   * 連絡先住所（郵便番号）のsetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先住所（郵便番号）を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param contractInformationAddressPostalCode
   *          連絡先住所（郵便番号）
   */
  public void setContractInformationAddressPostalCode(String contractInformationAddressPostalCode) {
    this.contractInformationAddressPostalCode = contractInformationAddressPostalCode;
  }

  /**
   * 連絡先住所（住所）のgetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先住所（住所）を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 連絡先住所（住所）
   */
  public String getContractInformationAddressFull() {
    return this.contractInformationAddressFull;
  }

  /**
   * 連絡先住所（住所）のsetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先住所（住所）を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param contractInformationAddressFull
   *          連絡先住所（住所）
   */
  public void setContractInformationAddressFull(String contractInformationAddressFull) {
    this.contractInformationAddressFull = contractInformationAddressFull;
  }

  /**
   * 連絡先住所（建物・部屋名）のgetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先住所（建物・部屋名）を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 連絡先住所（建物・部屋名）
   */
  public String getContractInformationAddressBuilding() {
    return this.contractInformationAddressBuilding;
  }

  /**
   * 連絡先住所（建物・部屋名）のsetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先住所（建物・部屋名）を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param contractInformationAddressBuilding
   *          連絡先住所（建物・部屋名）
   */
  public void setContractInformationAddressBuilding(String contractInformationAddressBuilding) {
    this.contractInformationAddressBuilding = contractInformationAddressBuilding;
  }

  /**
   * 連絡先電話区分コードのgetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先電話区分コードを取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 連絡先電話区分コード
   */
  public String getContractInformationCategoryCode() {
    return this.contractInformationCategoryCode;
  }

  /**
   * 連絡先電話区分コードのsetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先電話区分コードを設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param contractInformationCategoryCode
   *          連絡先電話区分コード
   */
  public void setContractInformationCategoryCode(String contractInformationCategoryCode) {
    this.contractInformationCategoryCode = contractInformationCategoryCode;
  }

  /**
   * 連絡先電話（市外局番）のgetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先電話（市外局番）を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 連絡先電話（市外局番）
   */
  public String getContractInformationAreaCode() {
    return this.contractInformationAreaCode;
  }

  /**
   * 連絡先電話（市外局番）のsetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先電話（市外局番）を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param contractInformationAreaCode
   *          連絡先電話（市外局番）
   */
  public void setContractInformationAreaCode(String contractInformationAreaCode) {
    this.contractInformationAreaCode = contractInformationAreaCode;
  }

  /**
   * 連絡先電話（市内局番）のgetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先電話（市内局番）を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 連絡先電話（市内局番）
   */
  public String getContractInformationLocalNo() {
    return this.contractInformationLocalNo;
  }

  /**
   * 連絡先電話（市内局番）のsetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先電話（市内局番）を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param contractInformationLocalNo
   *          連絡先電話（市内局番）
   */
  public void setContractInformationLocalNo(String contractInformationLocalNo) {
    this.contractInformationLocalNo = contractInformationLocalNo;
  }

  /**
   * 連絡先電話（加入者番号）のgetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先電話（加入者番号）を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 連絡先電話（加入者番号）
   */
  public String getContractInformationDirectoryNo() {
    return this.contractInformationDirectoryNo;
  }

  /**
   * 連絡先電話（加入者番号）のsetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 連絡先電話（加入者番号）を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param contractInformationDirectoryNo
   *          連絡先電話（加入者番号）
   */
  public void setContractInformationDirectoryNo(String contractInformationDirectoryNo) {
    this.contractInformationDirectoryNo = contractInformationDirectoryNo;
  }

}
