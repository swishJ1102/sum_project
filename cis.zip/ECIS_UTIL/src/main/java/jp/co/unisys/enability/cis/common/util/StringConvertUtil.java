/*-------------------------------------------------------------------------------
 * All Rights Reserved. Copyright(C) Nihon Unisys, Ltd.
 * vendor : Nihon Unisys, Ltd.
 * since : 2014/09/01
 * revision : 2015/02/06 【ph2開発】督促状の対応
 *-----------------------------------------------------------------------------*/
package jp.co.unisys.enability.cis.common.util;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.beanutils.ConvertUtils;
import org.apache.commons.beanutils.converters.BigDecimalConverter;
import org.apache.commons.beanutils.converters.IntegerConverter;
import org.apache.commons.beanutils.converters.ShortConverter;
import org.apache.commons.beanutils.converters.SqlDateConverter;
import org.apache.commons.beanutils.converters.SqlTimestampConverter;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;

import jp.co.unisys.enability.cis.common.Exception.ApplicationException;
import jp.co.unisys.enability.cis.common.Exception.SystemException;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;

/**
 * 文字列変換ユーティリティクラス.<br>
 *
 * 変更履歴(kg-epj) 2016.02.23 T.Hori 新規作成
 */
public class StringConvertUtil {

  /** 半角文字列Flg */
  public static final String FLG_HANKAKU = "1";

  /** 全角文字列Flg */
  public static final String FLG_ZENKAKU = "2";

  /** 分割判定区切り文字数:8 */
  private static final int DIV_LENGTH_8 = 8;

  /** 分割判定区切り文字数:6 */
  private static final int DIV_LENGTH_6 = 6;

  /** 分割位置 */
  private static enum splitPosition {
    POS_0, POS_1, POS_2, POS_3, POS_4, POS_5, POS_6, POS_7
  }

  /**
   * 文字列[str]に対して、文字列区分により、半角スペースまたは全角スペースを [length]に満たすまで 右側に 挿入します。
   * 
   * @param str
   *          対象文字列
   * @param strFlg
   *          文字列区分（1:半角、2:全角）
   * @param length
   *          補充するまでの桁数
   * @return 変換後の文字列
   */
  public static String fillSpaceStringRight(String str, String strFlg, int length)
      throws UnsupportedEncodingException, Exception {

    if (CommonValidationUtil.isNull(str)) {
      str = "";
    }
    str = StringConvertUtil.utf8ToSjis(str.trim());//UTF-8をSJISに変更する。

    byte[] oldBytes = str.getBytes(EMSConstants.ENCODE_TYPE_SJIS);

    StringBuffer result = new StringBuffer(str);

    // 桁数を補足
    if (FLG_HANKAKU.equals(strFlg)) {
      for (int i = oldBytes.length; i < length;) {
        result.append(EMSConstants.SPACE_HANKAKU);
        i = i + 1;
      }

    } else if (FLG_ZENKAKU.equals(strFlg)) {
      for (int i = oldBytes.length; i < length;) {
        result.append(EMSConstants.SPACE_ZENKAKU);
        i = i + 2;
      }
    } else {
      throw new ApplicationException("文字列区分が入力不正です。");
    }

    return result.toString();
  }

  /**
   * 半角スペースを[length]に満たすまで追加します。
   * 
   * @param length
   *          補充するまでの桁数
   * @param String
   *          「length」桁の半角スペース文字列
   */
  public static String addSpace(int Length) {

    StringBuffer strBuf = new StringBuffer();
    for (int i = 1; i <= Length; i++) {
      strBuf.append(EMSConstants.SPACE_HANKAKU);
    }

    return strBuf.toString();
  }

  /**
   * 数字[num]に対して、半角ゼロを [length]に満たすまで 先頭に挿入します。
   * 
   * @param num
   *          対象数字
   * @param length
   *          補充するまでの桁数
   * @return 変換後の文字列
   */
  public static String fillZeroNumLeft(int num, int length) {

    String value;

    if (num > 0) {
      value = String.valueOf(num);
    } else {
      value = "";
    }

    StringBuffer stringBuf = new StringBuffer();

    int addLength = length - value.length();

    for (int i = 1; i <= addLength; i++) {
      stringBuf.append("0");
    }
    stringBuf.append(value);

    return stringBuf.toString();
  }

  /**
   * 引数の文字列(Shift_JIS)を、UTF-8にエンコードする。
   *
   * @param value
   *          変換対象の文字列
   * @return エンコードされた文字列
   */
  public static String sjisToUtf8(String value) throws UnsupportedEncodingException {

    byte[] srcStream = value.getBytes("SJIS");
    byte[] destStream = (new String(srcStream, "SJIS")).getBytes("UTF-8");

    value = new String(destStream, "UTF-8");

    value = StringConvertUtil.convert(value, "SJIS", "UTF-8");
    return value;
  }

  /**
   * 引数の文字列(UTF-8)を、Shift_JISにエンコードする。
   *
   * @param value
   *          変換対象の文字列
   * @return エンコードされた文字列
   */
  public static String utf8ToSjis(String value) throws UnsupportedEncodingException {
    byte[] srcStream = value.getBytes("UTF-8");
    value = convert(new String(srcStream, "UTF-8"), "UTF-8", "SJIS");
    byte[] destStream = value.getBytes("SJIS");
    value = new String(destStream, "SJIS");
    return value;
  }

  /**
   * SQLのLIKE文の正規表現を置換する
   * 
   * @param param
   *          置換対象パラメータ
   * @return 置換後のエスケープ文字付きパラメータ
   */
  public static String convertLikeSqlParam(String param) {
    // パラメータが無ければ処理をしない
    if (StringUtils.isEmpty(param)) {
      return param;
    }

    String convertParam = param;
    String escapeChar = EMSConstants.SQL_ESCAPE_CHAR;
    // 置換文字を二重にする
    convertParam = convertParam.replaceAll(escapeChar, escapeChar.concat(escapeChar));

    // 定義ファイルに指定した文字をエスケープ文字付きに置換する
    for (String escTarget : EMSConstants.SQL_ESCAPE_TARGETS) {
      convertParam = convertParam.replaceAll(escTarget, escapeChar.concat(escTarget));
    }
    return convertParam;
  }

  /**
   * ConvertUtilsのNull変換設定を行う<br>
   * NullはNullのまま変換先に設定されるようにする<br>
   * 対応クラス：Short Integer BigDecimal Date Timestamp
   */
  public static void registConvertNullConfig() {
    // Short
    ConvertUtils.register(new ShortConverter(null), Short.class);
    // Integer
    ConvertUtils.register(new IntegerConverter(null), Integer.class);
    // BigDecimal
    ConvertUtils.register(new BigDecimalConverter(null), BigDecimal.class);
    // Date
    ConvertUtils.register(new SqlDateConverter(null), java.sql.Date.class);
    // Timestamp
    ConvertUtils.register(new SqlTimestampConverter(null), Timestamp.class);
  }

  /**
   * 年月計算用メソッド<br>
   * 引数の文字列を日付型に変換し、指定された期間分<br>
   * 月を増減した値を返却する
   * 
   * @param input
   *          入力文字列 (yyyymm) or (yyyymmdd)
   * @param diff
   *          計算期間
   * @param returnFotmat
   *          返却する文字型
   * @return 入力文字列を変換した文字列、入力値が6or8桁で無い場合は入力値
   * @throws ParseException
   */
  public static String calcMonth(String input, int diff, String returnFotmat) throws ParseException {
    if (StringUtils.isEmpty(input)) {
      return input;
    }

    int inputLength = input.length();

    String dateStr;
    if (inputLength == 6) {
      // 年月型が指定された場合は、計算用に01を付加する
      dateStr = input.concat("01");
    } else if (inputLength == 8) {
      // 年月日なので、そのまま設定
      dateStr = input;
    } else {
      // 異常値の場合、inputをそのまま返却する
      return input;
    }

    SimpleDateFormat toDateFormat = new SimpleDateFormat(EMSConstants.FORMAT_DATE_yyyyMMdd);
    SimpleDateFormat returnDateFormat = new SimpleDateFormat(returnFotmat);

    Calendar cal = Calendar.getInstance();
    cal.setTime(toDateFormat.parse(dateStr));
    cal.add(Calendar.MONTH, diff);

    return returnDateFormat.format(cal.getTime());
  }

  /**
   * 年月計算用メソッド<br>
   * 引数の文字列を日付型に変換し、指定された期間分<br>
   * 月を増減した値を返却する。<br>
   * ただし、変換または計算が行えなかった場合、nullを返却する。
   * 
   * @param input
   *          入力文字列 (yyyymm) or (yyyymmdd)
   * @param diff
   *          計算期間
   * @param returnFotmat
   *          返却する文字型
   * @return 入力文字列を変換した文字列、入力値が6or8桁で無い場合は入力値
   */
  public static String calcMonthNoException(String input, int diff, String returnFotmat) {
    String calcedMonth = null;
    try {
      calcedMonth = calcMonth(input, diff, returnFotmat);
    } catch (ParseException pe) {
      // 何も設定されないため、nullを返却
      return calcedMonth;
    }

    return calcedMonth;
  }

  /**
   * 引数の文字列を、エンコードする。
   *
   * @param value
   *          変換対象の文字列
   * @param src
   *          変換前の文字コード
   * @param dest
   *          変換後の文字コード
   * @return エンコードされた文字列
   */
  private static String convert(String value, String src, String dest) throws UnsupportedEncodingException {
    Map<String, String> conversion = createConversionMap(src, dest);
    char oldChar;
    char newChar;
    String key;
    for (Iterator<String> itr = conversion.keySet().iterator(); itr.hasNext();) {
      key = itr.next();
      oldChar = toChar(key);
      newChar = toChar(conversion.get(key));
      value = value.replace(oldChar, newChar);
    }
    return value;
  }

  /**
   * エンコード情報を作成する
   *
   * @param src
   *          変換前の文字コード
   * @param dest
   *          変換後の文字コード
   * @return エンコードされた文字列
   */
  private static Map<String, String> createConversionMap(String src, String dest) throws UnsupportedEncodingException {
    Map<String, String> conversion = new HashMap<String, String>();
    if ((src.equals("UTF-8")) && (dest.equals("SJIS"))) {
      // －（全角マイナス）
      conversion.put("U+FF0D", "U+2212");
      // ～（全角チルダ）
      conversion.put("U+FF5E", "U+301C");
      // ￠（セント）
      conversion.put("U+FFE0", "U+00A2");
      // ￡（ポンド）
      conversion.put("U+FFE1", "U+00A3");
      // ￢（ノット）
      conversion.put("U+FFE2", "U+00AC");
      // ―（全角マイナスより少し幅のある文字）
      conversion.put("U+2015", "U+2014");
      // ∥（半角パイプが2つ並んだような文字）
      conversion.put("U+2225", "U+2016");

    } else if ((src.equals("SJIS")) && (dest.equals("UTF-8"))) {
      // －（全角マイナス）
      conversion.put("U+2212", "U+FF0D");
      // ～（全角チルダ）
      conversion.put("U+301C", "U+FF5E");
      // ￠（セント）
      conversion.put("U+00A2", "U+FFE0");
      // ￡（ポンド）
      conversion.put("U+00A3", "U+FFE1");
      // ￢（ノット）
      conversion.put("U+00AC", "U+FFE2");
      // ―（全角マイナスより少し幅のある文字）
      conversion.put("U+2014", "U+2015");
      // ∥（半角パイプが2つ並んだような文字）
      conversion.put("U+2016", "U+2225");

    } else {
      throw new UnsupportedEncodingException("この文字コードはサポートしていません。\n・src=" + src + ",dest=" + dest);
    }
    return conversion;
  }

  /**
   * 16進表記の文字を取得する。
   *
   * @param value
   *          変換対象の文字列
   * @return 16進表記の文字
   */
  private static char toChar(String value) {
    return (char) Integer.parseInt(value.trim().substring("U+".length()), 16);
  }

  /**
   * 型式変更：文字型→日付型
   * 
   * @param str
   *          文字型(調定年月)
   * @return 日付型(調定年月) yyyyMM
   * @throws ParseException
   */
  public static Date stringToDate(String str) throws ParseException {

    SimpleDateFormat df = new SimpleDateFormat(EMSConstants.FORMAT_DATE_YYYYMM);
    df.setLenient(false);

    return df.parse(str);
  }

  /**
   * 型式変更：文字型→日付型<br>
   * エラーをハンドリングし、例外はスローしない
   * 
   * @param value
   *          変換する文字列
   * @param format
   *          フォーマット
   * @return 変換した日付文字列、失敗した場合はnull
   */
  public static Date stringToDate(String value, String format) {
    if (StringUtils.isEmpty(value)) {
      return null;
    }
    if (StringUtils.isEmpty(format)) {
      format = EMSConstants.FORMAT_DATE_yyyyMMdd;
    }
    // 日付フォーマットを作成
    SimpleDateFormat dateFormat = new SimpleDateFormat(format);
    // 日付の厳密チェックを指定
    dateFormat.setLenient(false);
    try {
      // 日付値を返す
      return dateFormat.parse(value);
    } catch (ParseException e) {
      // 日付値なしを返す
      return null;
    } finally {
      dateFormat = null;
    }
  }

  /**
   * 型式変更：文字型→数値型<br>
   * エラーをハンドリングし、例外はスローしない
   * 
   * @param value
   *          変換する文字列
   * @return 変換した数字、失敗した場合はnull
   */
  public static Integer stringToInteger(String value) {
    // 引数がnullまたは空文字の場合、nullを返却する。
    if (StringUtils.isEmpty(value)) {
      return null;
    }
    try {
      // int型に変換する。
      return Integer.valueOf(value);

    } catch (NumberFormatException e) {
      // nullを返却する。
      return null;
    }
  }

  /**
   * 型式変更：文字型→数値型<br>
   * エラーをハンドリングし、例外はスローしない
   * 
   * @param value
   *          変換する文字列
   * @return 変換した数字、失敗した場合はnull
   */
  public static Short stringToShort(String value) {
    // 引数がnullまたは空文字の場合、nullを返却する。
    if (StringUtils.isEmpty(value)) {
      return null;
    }
    try {
      // short型に変換する。
      return Short.parseShort(value);

    } catch (NumberFormatException e) {
      // nullを返却する。
      return null;
    }
  }

  /**
   * 型式変更：文字型→BigDecimal型<br>
   * エラーをハンドリングし、例外はスローしない
   * 
   * @param value
   *          変換する文字列
   * @return 変換した数字、失敗した場合はnull
   */
  public static BigDecimal stringToBigDecimal(String value) {
    // 引数がnullまたは空文字の場合、nullを返却する。
    if (StringUtils.isEmpty(value)) {
      return null;
    }
    try {
      // BigDecimal型に変換する。
      return new BigDecimal(value);

    } catch (NumberFormatException e) {
      // nullを返却する。
      return null;
    }
  }

  /**
   * 型式変更：数値型→文字型（主に画面用）<br>
   * 
   * @param value
   *          変換する数字
   * @return 変換した文字列、nullの場合は空文字を返却する
   */
  public static String integerToString(Integer value) {
    // 引数がnullの場合、空文字を返却する。
    if (value == null) {
      return "";
    }
    // int型に変換する。
    return String.valueOf(value);
  }

  /**
   * 型式変更：数値型→文字型（主にAPI用）<br>
   * 
   * @param value
   *          変換する数字
   * @return 変換した文字列、nullの場合はnullを返却する
   */
  public static String integerToStringNull(Integer value) {
    // 引数がnullの場合、空文字を返却する。
    if (value == null) {
      return null;
    }
    // int型に変換する。
    return String.valueOf(value);
  }

  /**
   * 日付の表示変換
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 日付の画面表示用に変換します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param target
   *          変換対象
   * @param delimitor
   *          区切り文字
   * @return 画面表示日付
   */
  public static String convertDateFormatAddDelimitor(String target, String delimitor) {
    if (target == null) {
      return null;
    }

    StringBuilder sb = new StringBuilder();
    // 文字列長で判定
    switch (target.length()) {
      case DIV_LENGTH_8:
        sb.append(target.substring(splitPosition.POS_0.ordinal(), splitPosition.POS_4.ordinal()))
            .append(delimitor)
            .append(target.substring(splitPosition.POS_4.ordinal(), splitPosition.POS_6.ordinal()))
            .append(delimitor)
            .append(target.substring(splitPosition.POS_6.ordinal()));
        break;
      case DIV_LENGTH_6:
        sb.append(target.substring(splitPosition.POS_0.ordinal(), splitPosition.POS_4.ordinal()))
            .append(delimitor)
            .append(target.substring(splitPosition.POS_4.ordinal(), splitPosition.POS_6.ordinal()));
        break;
      default:
        return target;
    }

    // 変換結果を返却
    return sb.toString();
  }

  /**
   * 日付の表示変換
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 日付の画面表示用に変換します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param target
   *          変換対象
   * @param targetFormat
   *          変換対象フォーマット
   * @pamra convertedFormat 変換後のフォーマット
   * @return 画面表示日付
   */
  public static String convertDateObjectToString(Object target, String targetFormat, String convertedFormat) {
    if (target == null) {
      return null;
    }

    SimpleDateFormat toDateFormat = new SimpleDateFormat(targetFormat);

    try {
      return convertDateToString(toDateFormat.parse(String.valueOf(target)), convertedFormat);
    } catch (ParseException e) {
      throw new SystemException("日付形式のデータが変換できませんでした。", e);
    }
  }

  /**
   * 日付の画面表示変換
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 日付の画面表示用に変換します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param target
   *          変換対象
   * @param targetFormat
   *          変換対象フォーマット
   * @return 画面表示日付
   */
  public static String convertDateToString(Date target, String targetFormat) {
    if (target == null) {
      return null;
    }
    if (StringUtils.isEmpty(targetFormat)) {
      targetFormat = EMSConstants.FORMAT_DATE_yyyyMMdd;
    }
    return DateFormatUtils.format(target, targetFormat);
  }

  /**
   * 数値の画面表示変換
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 数値の画面表示用に変換します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param target
   *          変換対象
   * @param df
   *          変換対象フォーマット
   * @return 画面表示数値
   */
  public static String convertBigDecimalToString(Object target, String targetFormat) {
    if (target == null) {
      return null;
    }
    if (StringUtils.isEmpty(targetFormat)) {
      return target.toString();
    }
    DecimalFormat df = new DecimalFormat(targetFormat);
    return df.format(target);
  }

  /**
   * 日付の月差を計算する。
   * 
   * @param date1
   *          yyyyMMの日付引数１
   * @param date2
   *          yyyyMMの日付引数２
   * @return 月差
   */
  public static int differenceMonth(Date date1, Date date2) {

    int count = 0;
    Calendar cal1 = Calendar.getInstance();
    Calendar cal2 = Calendar.getInstance();

    cal1.setTime(date1);
    cal1.set(Calendar.DAY_OF_MONTH, 1);

    cal2.setTime(date2);
    cal2.set(Calendar.DAY_OF_MONTH, 1);

    if (cal2.after(cal1)) {
      while (cal2.after(cal1)) {
        cal1.add(Calendar.MONTH, 1);
        count++;
      }
    } else {
      while (cal1.after(cal2)) {
        cal2.add(Calendar.MONTH, 1);
        count++;
      }
    }

    return count;
  }

  /**
   * エラーリストメッセージ作成メソッド<br>
   * ファイル名、行番号、メッセージを結合し、文字列にして返却する<br>
   * nullの項目は、値・カンマどちらも設定しない
   * 
   * @param fileName
   *          ファイル名(null可)
   * @param row
   *          行番号(null可)
   * @param message
   *          メッセージ(null不可)
   * @return 引数をカンマ区切りで結合した文字列
   */
  public static String convertErrorListString(String fileName, Integer row, String message) {
    StringBuilder sb = new StringBuilder();
    if (!StringUtils.isEmpty(fileName)) {
      sb.append(fileName);
      sb.append(EMSConstants.COMMA);
    }
    if (row != null) {
      sb.append(row);
      sb.append(EMSConstants.COMMA);
    }
    sb.append(message);
    return sb.toString();
  }

  // [kg-epj]<i-start>
  /**
   * ガスお客様番号の出力フォーマット変換<br>
   * ガスお客様番号を4桁-3桁-4桁のフォーマットに変換します<br>
   * 引数が未設定の場合はinputをそのまま返却する
   * 
   * @param gasCustomerNo
   *          ガスお客様番号
   * @return 4桁-3桁-4桁に区切ったガスお客様番号
   */
  public static String formatOutputGasCustomerNo(String gasCustomerNo) {
    if (StringUtils.isEmpty(gasCustomerNo)) {
      return gasCustomerNo;
    }
    StringBuilder sb = new StringBuilder();
    sb.append(gasCustomerNo.substring(0, 4));
    sb.append(ECISConstants.HYPHEN);
    sb.append(gasCustomerNo.substring(4, 7));
    sb.append(ECISConstants.HYPHEN);
    sb.append(gasCustomerNo.substring(7));
    return sb.toString();
  }

  /**
   * 地点特定番号の出力フォーマット変換<br>
   * 地点特定番号を2桁-4桁-4桁-4桁-4桁-4桁のフォーマットに変換します<br>
   * 引数が未設定の場合はinputをそのまま返却する
   * 
   * @param 地点特定番号
   * @return 2桁-4桁-4桁-4桁-4桁-4桁に区切った地点特定番号
   */
  public static String formatOutputSpotNo(String spotNo) {
    if (StringUtils.isEmpty(spotNo)) {
      return spotNo;
    }
    StringBuilder sb = new StringBuilder();
    sb.append(spotNo.substring(0, 2));
    sb.append(ECISConstants.HYPHEN);
    sb.append(spotNo.substring(2, 6));
    sb.append(ECISConstants.HYPHEN);
    sb.append(spotNo.substring(6, 10));
    sb.append(ECISConstants.HYPHEN);
    sb.append(spotNo.substring(10, 14));
    sb.append(ECISConstants.HYPHEN);
    sb.append(spotNo.substring(14, 18));
    sb.append(ECISConstants.HYPHEN);
    sb.append(spotNo.substring(18));
    return sb.toString();
  }
  // [kg-epj]<i-end>
}
