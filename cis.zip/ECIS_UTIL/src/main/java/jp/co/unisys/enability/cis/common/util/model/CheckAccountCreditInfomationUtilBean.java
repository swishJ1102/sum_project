package jp.co.unisys.enability.cis.common.util.model;

/**
 * 口座クレカ情報チェックUtilBean
 *
 * @author "Nihon Unisys, Ltd."
 */
public class CheckAccountCreditInfomationUtilBean {

  /**
   * 口座クレカ区分コードを保有する。
   */
  private String accountCreditCategoryCode;

  /**
   * 決済アクセスキーを保有する。
   */
  private String accessKey;

  /**
   * 金融機関コードを保有する。
   */
  private String bankCode;

  /**
   * 金融機関支店コードを保有する。
   */
  private String bankBranchCode;

  /**
   * 金融機関預金種目コードを保有する。
   */
  private String bankTypeOfAccountCode;

  /**
   * 口座番号を保有する。
   */
  private String accountNo;

  /**
   * 口座名義を保有する。
   */
  private String accountHolderName;

  /**
   * クレカ番号を保有する。
   */
  private String creditCardNo;

  /**
   * クレカ有効期限を保有する。
   */
  private String creditCardExpirationDate;

  /**
   * クレカブランドコードを保有する。
   */
  private String creditCardBrandCode;

  /**
   * 口座クレカ区分コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 口座クレカ区分コードを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 口座クレカ区分コード
   */
  public String getAccountCreditCategoryCode() {
    return this.accountCreditCategoryCode;
  }

  /**
   * 口座クレカ区分コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 口座クレカ区分コードを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param accountCreditCategoryCode
   *          口座クレカ区分コード
   */
  public void setAccountCreditCategoryCode(String accountCreditCategoryCode) {
    this.accountCreditCategoryCode = accountCreditCategoryCode;
  }

  /**
   * 決済アクセスキーのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 決済アクセスキーを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 決済アクセスキー
   */
  public String getAccessKey() {
    return this.accessKey;
  }

  /**
   * 決済アクセスキーのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 決済アクセスキーを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param accessKey
   *          決済アクセスキー
   */
  public void setAccessKey(String accessKey) {
    this.accessKey = accessKey;
  }

  /**
   * 金融機関コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 金融機関コードを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 金融機関コード
   */
  public String getBankCode() {
    return this.bankCode;
  }

  /**
   * 金融機関コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 金融機関コードを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param bankCode
   *          金融機関コード
   */
  public void setBankCode(String bankCode) {
    this.bankCode = bankCode;
  }

  /**
   * 金融機関支店コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 金融機関支店コードを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 金融機関支店コード
   */
  public String getBankBranchCode() {
    return this.bankBranchCode;
  }

  /**
   * 金融機関支店コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 金融機関支店コードを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param bankBranchCode
   *          金融機関支店コード
   */
  public void setBankBranchCode(String bankBranchCode) {
    this.bankBranchCode = bankBranchCode;
  }

  /**
   * 金融機関預金種目コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 金融機関預金種目コードを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 金融機関預金種目コード
   */
  public String getBankTypeOfAccountCode() {
    return this.bankTypeOfAccountCode;
  }

  /**
   * 金融機関預金種目コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 金融機関預金種目コードを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param bankTypeOfAccountCode
   *          金融機関預金種目コード
   */
  public void setBankTypeOfAccountCode(String bankTypeOfAccountCode) {
    this.bankTypeOfAccountCode = bankTypeOfAccountCode;
  }

  /**
   * 口座番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 口座番号を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 口座番号
   */
  public String getAccountNo() {
    return this.accountNo;
  }

  /**
   * 口座番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 口座番号を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param accountNo
   *          口座番号
   */
  public void setAccountNo(String accountNo) {
    this.accountNo = accountNo;
  }

  /**
   * 口座名義のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 口座名義を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 口座名義
   */
  public String getAccountHolderName() {
    return this.accountHolderName;
  }

  /**
   * 口座名義のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 口座名義を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param accountHolderName
   *          口座名義
   */
  public void setAccountHolderName(String accountHolderName) {
    this.accountHolderName = accountHolderName;
  }

  /**
   * クレカ番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * クレカ番号を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return クレカ番号
   */
  public String getCreditCardNo() {
    return this.creditCardNo;
  }

  /**
   * クレカ番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * クレカ番号を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param creditCardNo
   *          クレカ番号
   */
  public void setCreditCardNo(String creditCardNo) {
    this.creditCardNo = creditCardNo;
  }

  /**
   * クレカ有効期限のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * クレカ有効期限を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return クレカ有効期限
   */
  public String getCreditCardExpirationDate() {
    return this.creditCardExpirationDate;
  }

  /**
   * クレカ有効期限のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * クレカ有効期限を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param creditCardExpirationDate
   *          クレカ有効期限
   */
  public void setCreditCardExpirationDate(String creditCardExpirationDate) {
    this.creditCardExpirationDate = creditCardExpirationDate;
  }

  /**
   * クレカブランドコードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * クレカブランドコードを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return クレカブランドコード
   */
  public String getCreditCardBrandCode() {
    return this.creditCardBrandCode;
  }

  /**
   * クレカブランドコードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * クレカブランドコードを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param creditCardBrandCode
   *          クレカブランドコード
   */
  public void setCreditCardBrandCode(String creditCardBrandCode) {
    this.creditCardBrandCode = creditCardBrandCode;
  }

}
