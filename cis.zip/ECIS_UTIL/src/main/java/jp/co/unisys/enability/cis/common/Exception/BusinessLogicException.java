/*-------------------------------------------------------------------------------
 * All Rights Reserved. Copyright(C) Nihon Unisys, Ltd.
 * vendor : Nihon Unisys, Ltd.
 * since : 2014/09/01
 *-----------------------------------------------------------------------------*/
package jp.co.unisys.enability.cis.common.Exception;

/**
 * 共通例外クラス.<br>
 * メッセージキーとパラメータを引数に生成する共通業務例外クラス.
 *
 */
public class BusinessLogicException extends Exception {

  /**
   * メッセージキー
   */
  private String messagekey;

  /**
   * メッセージパラメータ
   */
  private String[] params;

  /**
   * キーフラグ
   */
  private boolean keyFlag;

  /**
   * messagekeyのゲッター
   * 
   * @return messagekey
   */
  public String getMessagekey() {
    return messagekey;
  }

  /**
   * paramsのゲッター
   * 
   * @return params
   */
  public String[] getParams() {
    return params;
  }

  /**
   * keyFlagのゲッター
   * 
   * @return keyFlag
   */
  public boolean getKeyFlag() {
    return keyFlag;
  }

  /**
   * 引数のメッセージキーを元に共通例外クラスを生成します ※既存ソースで利用している
   * 
   * @param messageKey
   *          メッセージキー
   */
  public BusinessLogicException(String messageKey) {
    super(messageKey);
    this.messagekey = messageKey;
    this.keyFlag = true;
    this.params = null;
  }

  /**
   * 引数のメッセージキー、パラメータ名を元に共通例外クラスを生成します ※既存ソースで利用していない
   * 
   * @param messageKey
   *          メッセージキー
   * @param paramName
   *          パラメータ名
   */
  public BusinessLogicException(String messageKey, String... paramName) {
    super(messageKey);
    this.messagekey = messageKey;
    this.keyFlag = true;
    this.params = paramName;
  }

  /**
   * 引数のメッセージキー、例外クラス、パラメータ名を元に共通例外クラスを生成します ※既存ソースで利用していない
   * 
   * @param messageKey
   *          メッセージキー
   * @param cause
   *          例外クラス
   * @param paramName
   *          パラメータ名
   */
  public BusinessLogicException(String messageKey, Throwable cause, String... paramName) {
    super(messageKey, cause);
    this.messagekey = messageKey;
    this.keyFlag = true;
    this.params = paramName;
  }

  /**
   * 引数のmessageとkeyFlagを元に共通例外クラスを生成します keyFlag：TRUEの場合、messageにキー情報を格納する。 ：FALSEの場合、messageにメッセージ（文字列）を格納する。
   * 
   * @param message
   * @param keyFlag
   */
  public BusinessLogicException(String message, boolean keyFlag) {
    super(message);
    this.messagekey = message;
    this.keyFlag = keyFlag;
    this.params = null;
  }
}
