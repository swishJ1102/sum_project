/*-------------------------------------------------------------------------------
 * All Rights Reserved. Copyright(C) Nihon Unisys, Ltd.
 * vendor : Nihon Unisys, Ltd.
 * since : 2014/09/01
 *-----------------------------------------------------------------------------*/
package jp.co.unisys.enability.cis.common.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.opensymphony.xwork2.validator.ValidationException;
import com.opensymphony.xwork2.validator.validators.FieldValidatorSupport;

/**
 * Date型フィールドバリデータ.<br>
 * Struts2バリデーションで使用するDate型用カスタムバリデーションクラス<br>
 * チェック対象がHH:mm形式であるかをチェックする
 *
 */
public class DateFormateHmValidator extends FieldValidatorSupport {

  /** フィールド名 */
  private String fieldName;
  /** HMの長さ */
  private static final int HMLEN = 4;

  /*
   * (非 Javadoc)
   * @see com.opensymphony.xwork2.validator.Validator#validate(java.lang.Object)
   */
  @Override
  public void validate(Object object) throws ValidationException {

    // フィールド名を取得する。
    String fieldName = this.getFieldName();

    // 入力値を取得する。
    Object value = this.getFieldValue(fieldName, object);

    // 入力値がある場合、チェックを行う。
    if (value != null && !String.valueOf(value).isEmpty()) {

      String dateStr = String.valueOf(value);

      if (dateStr.length() != 5) {

        this.addFieldError(fieldName, object);
        return;
      } else {
        // TODO 定数化
        SimpleDateFormat format = new SimpleDateFormat("HH:mm");
        format.setLenient(false);

        try {
          format.parse(dateStr);
        } catch (ParseException e) {
          this.addFieldError(fieldName, object);
        }
      }

    }
  }

  /**
   * 時分チェック
   *
   * @param value
   *          文字列
   * @return true/false
   */
  public static boolean checkHM(String value) {

    if (value == null) {
      // nullならエラー
      return false;
    }

    if (value.length() != HMLEN) {
      // 4バイト以外はエラー
      return false;
    }

    // 時分取得
    String hour = value.substring(0, 2);
    String minute = value.substring(2, HMLEN);

    // 対象時間
    String[] targetHour = {"00", "01", "02", "03", "04", "05", "06", "07",
        "08", "09", "10", "11", "12", "13", "14", "15", "16", "17",
        "18", "19", "20", "21", "22", "23" };

    // 対象分
    String[] targetMinute = {"00", "30" };

    // 時間存在チェック
    for (int i = 0; i < targetHour.length; i++) {
      if (hour.equals(targetHour[i])) {
        // 時が実在する場合
        for (int j = 0; j < targetMinute.length; j++) {
          if (minute.equals(targetMinute[j])) {
            // 分が実在する場合
            return true;
          }
        }
        return false;
      }
    }
    return false;
  }

  /**
   * 時分フォーマットチェック
   * 
   * @param value
   *          時分(HHMM)
   * @return 00:30～24:00(30分刻み)の範囲に存在する時刻であればtrue
   */
  public static boolean isValidHM(String value) {
    if (value == null) {
      // nullならエラー
      return false;
    }

    if (value.length() != HMLEN) {
      // 4バイト以外はエラー
      return false;
    }

    // 時分取得
    String hour = value.substring(0, 2);
    String minute = value.substring(2, HMLEN);

    // 対象時間
    String[] targetHours = {"00", "01", "02", "03", "04", "05", "06", "07",
        "08", "09", "10", "11", "12", "13", "14", "15", "16", "17",
        "18", "19", "20", "21", "22", "23", "24" };

    // 対象分
    String[] targetMinutes = {"00", "30" };

    // 除外する時刻
    List<String> excludes = new ArrayList<String>();
    excludes.add("0000");
    excludes.add("2430");

    // 時間存在チェック
    for (int i = 0; i < targetHours.length; i++) {
      String targetHour = targetHours[i];
      for (int j = 0; j < targetMinutes.length; j++) {
        String targetMinute = targetMinutes[j];
        if (excludes.contains(targetHour + targetMinute)) {
          // 除外リストに存在する時刻の時は飛ばす
          continue;
        }

        if (targetHour.equals(hour) && targetMinute.equals(minute)) {
          // 存在する時刻である場合
          return true;
        }
      }
    }
    return false;
  }

  /**
   * fieldNameのゲッター
   * 
   * @return fieldName
   */
  public String getFieldName() {
    return fieldName;
  }

  /**
   * fieldNameのセッター
   * 
   * @param fieldName
   *          セットする fieldName
   */
  public void setFieldName(String fieldName) {
    this.fieldName = fieldName;
  }

}
