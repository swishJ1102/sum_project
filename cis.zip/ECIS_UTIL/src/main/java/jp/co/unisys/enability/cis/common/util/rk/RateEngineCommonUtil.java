package jp.co.unisys.enability.cis.common.util.rk;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Map;
import java.util.TreeMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import jp.co.unisys.enability.cis.common.Exception.RateEngineException;
import jp.co.unisys.enability.cis.common.util.StringConvertUtil;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;

/**
 * 料金計算エンジン共通ユーティリティクラス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RateEngineCommonUtil {

  /** ロガー */
  private static final Logger LOGGER = LogManager.getLogger(RateEngineCommonUtil.class);

  /**
   * 引数に対してチェックを行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * パラメータの要素数をチェックして想定外の個数の場合はRateEngineExceptionをthrowする。<br>
   * 要素数が期待数と一致した場合でも各要素にnullが含まれる場合はRateEngineExceptionをthrowする。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param args
   *          チェック対象のパラメータ配列
   * @param length
   *          引数長
   * @throws RateEngineException
   *           パラメータの要素がエラーの場合
   */
  public static void checkArgsLength(Object[] args, int length) throws RateEngineException {
    checkArgsLengthAndArgsNullVal(args, length, true);
  }

  /**
   * 引数に対してNull値チェックを行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * パラメータの要素数をチェックして想定外の個数の場合はRateEngineExceptionをthrowする。<br>
   * nullCheckパラメータにtrueが設定された場合には、要素数が期待数と一致した場合でも各要素のnullチェックする。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param args
   *          チェック対象のパラメータ配列
   * @param length
   *          引数長
   * @param nullCheck
   *          nullチェックを行うかどうか
   * @throws RateEngineException
   *           パラメータの要素がエラーの場合
   */
  public static void checkArgsLengthAndArgsNullVal(Object[] args, int length, boolean nullCheck)
      throws RateEngineException {
    if (args.length != length) {
      LOGGER.error("RateEngineCommonUtil＞パラメータエラー 期待引数={} 結果引数={}", length, args.length);
      // ソッドの引数が想定の個数ではありません。想定数：x、入力数：x
      throw new RateEngineException("error.E1255",
          new String[] {String.valueOf(length), String.valueOf(args.length) });
    }

    if (!nullCheck) {
      return;
    }

    for (int i = 0; i < args.length; i++) {
      if (args[i] == null) {
        LOGGER.error("RateEngineCommonUtil＞パラメータエラー(NULL) インデックス={}", i);
        throw new RateEngineException("error.E1256", new String[] {String.valueOf(i) });
      }
    }
  }

  /**
   * 引数に対してNull許可判定チェックを行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * パラメータの要素数をチェックして想定外の個数の場合はRateEngineExceptionをthrowする。<br>
   * 要素数の各要素のnullチェックを行い、Null許可リストに指定された要素を除外し、nullチェックする。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param args
   *          チェック対象のパラメータ配列
   * @param length
   *          引数長
   * @param nullPermitIndexs
   *          Null許可リスト
   * @throws RateEngineException
   *           パラメータの要素がエラーの場合
   */
  public static void checkArgsLengthPermitNullVal(Object[] args, int length, int[] nullPermitIndexs)
      throws RateEngineException {
    if (args.length != length) {
      LOGGER.error("RateEngineCommonUtil＞パラメータエラー 期待引数={} 結果引数={}", length, args.length);
      // メソッドの引数が想定の個数ではありません。想定数：x、入力数：x
      throw new RateEngineException("error.E1255",
          new String[] {String.valueOf(length), String.valueOf(args.length) });
    }

    if (args.length != nullPermitIndexs.length) {
      LOGGER.error("RateEngineCommonUtil＞パラメータエラー(NULL許可リスト) 期待引数={} 結果引数={}", nullPermitIndexs.length,
          args.length);
      // :チェック対象のパラメータの個数とNull許可リストの個数が合っていません。チェック対象のパラメータ数：x、Null許可リスト：x
      throw new RateEngineException("error.E1257",
          new String[] {String.valueOf(nullPermitIndexs.length), String.valueOf(args.length) });
    }

    for (int i = 0; i < args.length; i++) {
      if (nullPermitIndexs[i] != 0 && args[i] == null) {
        LOGGER.error("RateEngineCommonUtil＞パラメータエラー(NULL) インデックス={}", i);
        throw new RateEngineException("error.E1256", new String[] {String.valueOf(i) });
      }
    }
  }

  /**
   * パラメータの型をBigDecimalへの変換を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 変換の必要のない場合(変換前の型がBigDecimal型)の場合は、型キャストのみ実施する。<br>
   * 変換前の型は[String, Integer, Long, Short, Double]に対応。<br>
   * パラメータに想定外の型が設定された場合はRateEngineExceptionをthrowする。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param args
   *          パラメータ
   * @return BigDecimalに変換後のパラメータ
   * @throws RateEngineException
   *           パラメータが想定外の型など、BigDecimalに変換できない場合
   */
  public static BigDecimal[] convertToDecimals(Object... args) throws RateEngineException {
    BigDecimal[] ret = new BigDecimal[args.length];

    for (int i = 0; i < args.length; i++) {
      ret[i] = convertToDecimal(args[i]);
    }

    return ret;
  }

  /**
   * パラメータの型をBigDecimalへの変換を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 変換の必要のない場合(変換前の型がBigDecimal型)の場合は、型キャスト実施する。<br>
   * 変換前の型は[String, Integer, Long, Short, Double]に対応。<br>
   * パラメータに想定外の型が設定された場合はRateEngineExceptionがthrowされる。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param arg
   *          パラメータ
   * @return BigDecimalに変換後のパラメータ
   * @throws RateEngineException
   *           パラメータが想定外の型など、BigDecimalに変換できない場合
   */
  public static BigDecimal convertToDecimal(Object arg) throws RateEngineException {
    if (arg == null) {
      return BigDecimal.valueOf(0);
    }

    if (arg instanceof BigDecimal) {
      return (BigDecimal) arg;
    }

    if (arg instanceof String) {
      try {
        return new BigDecimal((String) arg);
      } catch (NumberFormatException e) {
        LOGGER.error("RateEngineCommonUtil＞パラメータ変換エラー 対象={}", arg);
        // パラメータに変換できない文字列が含まれています。
        throw new RateEngineException("error.E1258");
      }
    }

    if (arg instanceof Integer) {
      return BigDecimal.valueOf((Integer) arg);
    }

    if (arg instanceof Long) {
      return BigDecimal.valueOf((Long) arg);
    }

    if (arg instanceof Short) {
      return BigDecimal.valueOf((Short) arg);
    }

    if (arg instanceof Double) {
      return BigDecimal.valueOf((Double) arg);
    }

    LOGGER.error("RateEngineCommonUtil＞パラメータ変換エラー 対象={}", arg.getClass().getName());
    // パラメータに変換できない文字列が含まれています。
    throw new RateEngineException("error.E1259", new String[] {arg.getClass().getName() });
  }

  /**
   * Mapのキー用に各構成要素を"_"で連結を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * Mapのキー用に各構成要素を"_"で連結する。<br>
   * keyの構成要素がDate型の場合は"yyyy-MM-dd"の文字列に変換する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param keys
   *          キーの構成要素
   * @return 連結後のキー用文字列
   */
  public static String createMapKey(Object... keys) {
    StringBuilder sb = new StringBuilder();

    for (Object key : keys) {

      if (key instanceof Date) {
        // 引数.Object の型が日付型（Date）の場合
        sb.append(StringConvertUtil.convertDateToString((Date) key,
            ECISRKConstants.CALC_FORMAT_DATE_yyyyMMdd_HYPHEN));
      } else {
        // 引数.Object の型が日付型（Date）ではない場合
        sb.append(key);
      }

      sb.append(ECISConstants.UNDERLINE);
    }
    sb.deleteCharAt(sb.length() - 1);

    return sb.toString();
  }

  /**
   * 契約容量インデックスの取得を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約容量の配列中に該当の契約容量が含まれる場合、そのインデックスを返却する。<br>
   * 見つからない場合は-1を返却する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param compareObj
   *          契約容量
   * @param obj
   *          契約容量リスト
   * @return 契約容量インデックス
   */
  public static int getIndexByContractCapacity(Object compareObj, Object obj) throws RateEngineException {
    int index = -1;
    BigDecimal compareCapacity = convertToDecimal(compareObj);
    BigDecimal[] contractCapacityList = convertToDecimals((Object[]) obj);

    // 容量のインデックス数分処理を行う
    for (int i = 0; i < contractCapacityList.length; i++) {
      if (compareCapacity.compareTo(contractCapacityList[i]) == 0) {
        index = i;
        break;
      }
    }

    // インデックスを返却
    return index;
  }

  /**
   * 契約容量に対応する料金単価の取得を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 契約容量インデックスに従い、該当する要素の料金単価を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param index
   *          契約容量料金インデックス
   * @param obj
   *          契約容量料金リスト
   * @return 契約容量料金
   */
  public static BigDecimal getContractCapacityPrice(int index, Object obj) throws RateEngineException {
    BigDecimal price;
    BigDecimal[] contractPriceList = convertToDecimals((Object[]) obj);

    price = contractPriceList[index];

    return price;
  }

  /**
   * 部品のパラメータの型をBigDecimalに変換する(Null許可) 。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 変換の必要のない場合(変換前の型がBigDecimal型)の場合は、型キャストのみ実施する。<br>
   * 変換前の型は[String, Integer, Long, Short, Double]に対応。<br>
   * パラメータに想定外の型が設定された場合はRateEngineExceptionをthrowする。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param args
   *          部品のパラメータ
   * @return BigDecimalに変換後のパラメータ
   * @throws RateEngineException
   *           パラメータが想定外の型など、BigDecimalに変換できない場合
   */
  public static BigDecimal[] convertToDecimalsNullable(Object... args) throws RateEngineException {
    BigDecimal[] ret = new BigDecimal[args.length];
    for (int i = 0; i < args.length; i++) {
      Object arg = args[i];

      if (arg == null) {
        ret[i] = BigDecimal.ZERO;
      } else if (arg instanceof BigDecimal) {
        ret[i] = (BigDecimal) arg;
      } else if (arg instanceof String) {
        BigDecimal converted = null;
        try {
          converted = new BigDecimal((String) arg);
        } catch (NumberFormatException e) {
          LOGGER.error("RateEngineCommonUtil＞BigDicimal変換エラー 対象={}", arg.getClass().getName());
          // BigDicimalに変換できない文字列です。文字列:{0}
          throw new RateEngineException("error.E1338", arg.toString());
        }
        ret[i] = converted;
      } else if (arg instanceof Number) {
        ret[i] = new BigDecimal(arg.toString());
      } else {
        LOGGER.warn("RateEngineCommonUtil＞BigDicimal変換エラー arg:{} type:{}", arg.toString(), arg.getClass()
            .getName());
        throw new RateEngineException("error.E1339", arg.toString());
      }
    }
    return ret;
  }

  /**
   * パラメータの型をMapへの変換を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * * 変換前の型はMap<String, Integer>を想定して変換を行う。<br>
   * パラメータに想定外の型が設定された場合はRateEngineExceptionをthrowする。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param args
   *          パラメータ
   * @return Mapに変換後のパラメータ
   * @throws RateEngineException
   *           パラメータが想定外の型など、Mapに変換できない場合
   */
  public static TreeMap<String, Integer> convertToMapKeyStringValueInteger(Object args) throws RateEngineException {

    //渡ってきたオブジェクトがTreeMapか確認
    if (!(args instanceof TreeMap<?, ?>)) {
      LOGGER.error("RateEngineCommonUtil＞HashMap<String, Integer>変換エラー 対象={}", args.getClass().getName());
      // TreeMapに変換できない文字列です。文字列:{0}
      throw new RateEngineException("error.E1556", new String[] {"TreeMap", args.toString() });
    }
    TreeMap<String, Integer> map = (TreeMap<String, Integer>) args;

    //TreeMapのキーとバリューの型チェック
    for (Map.Entry<String, Integer> mapdetail : map.entrySet()) {
      if (!(mapdetail.getKey() instanceof String)) {
        LOGGER.error("RateEngineCommonUtil＞HashMap<String, Integer>変換エラー 対象={}", args.getClass().getName());
        // 変換できない型です。{0}
        throw new RateEngineException("error.E1557", "Key : " + mapdetail.getKey());

      }

      if (!(mapdetail.getValue() instanceof Integer)) {
        LOGGER.error("RateEngineCommonUtil＞HashMap<String, Integer>変換エラー 対象={}", args.getClass().getName());
        // 変換できない型です。{0}
        throw new RateEngineException("error.E1557", "Value : " + mapdetail.getValue());
      }
    }

    return map;
  }

  /**
   * 文字列として想定されているパラメータを整数型への変換を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 文字列として想定されているパラメータを整数型に変換する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param object
   *          パラメータ
   * @return 変換後の数値
   * @throws RateEngineException
   *           パラメータが文字列ではない場合、あるいは数値に変換できない場合
   */
  public static int convertStringToInt(Object object) throws RateEngineException {
    if (!(object instanceof String)) {
      LOGGER.error("RateEngineCommonUtil＞変換エラー（型違い） 対象={}", object.toString());
      throw new RateEngineException("error.E1340", object.toString());
    }

    int ret = 0;
    try {
      ret = Integer.parseInt((String) object);
    } catch (NumberFormatException e) {
      LOGGER.error("RateEngineCommonUtil＞int変換エラー 対象={}", object.toString());
      throw new RateEngineException("error.E1341", e, object.toString());
    }
    return ret;
  }

  /**
   * 丸め方法の取得を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 定義済みの丸め方法を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param int
   *          roundMode 定義された丸め方法
   * @return BigDecimalの定数
   * @throws RateEngineException
   *           丸め方法が取得できない場合
   */
  public static int getRoundMode(int roundMode) throws RateEngineException {
    // 丸めモード初期化
    int judgedRoundMode = ECISRKConstants.ROUNDMODE_OFF;

    // -- 丸め処理判定 --
    switch (roundMode) {
      // 切捨て
      case ECISRKConstants.ROUNDMODE_DOWN:
        judgedRoundMode = BigDecimal.ROUND_DOWN;
        break;
      // 四捨五入
      case ECISRKConstants.ROUNDMODE_HALF_UP:
        judgedRoundMode = BigDecimal.ROUND_HALF_UP;
        break;
      // 切り上げ
      case ECISRKConstants.ROUNDMODE_UP:
        judgedRoundMode = BigDecimal.ROUND_UP;
        break;
      // 上記以外の場合
      default:
        // 念のため
        judgedRoundMode = ECISRKConstants.ROUNDMODE_OFF;
        break;
    }

    // 結果を返却
    return judgedRoundMode;
  }

}
