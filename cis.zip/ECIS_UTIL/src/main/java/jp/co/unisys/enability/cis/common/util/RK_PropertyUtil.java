package jp.co.unisys.enability.cis.common.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.springframework.beans.factory.config.PropertiesFactoryBean;

import jp.co.unisys.enability.cis.common.Exception.SystemException;

/***
 * Springプロパティの取り扱いに関するユーティリティ。
 *
 * @author "Nihon Unisys, Ltd."
 *
 */
public class RK_PropertyUtil {

  /***
   * 引数で指定されたプロパティファクトリによりgetObjectした結果の返却を行う。
   *
   * @param propertiesFactoryBean
   *          プロパティファクトリ
   * @return プロパティオブジェクト
   */
  public static Properties getPropertiesFactory(PropertiesFactoryBean propertiesFactoryBean) {
    // プロパティを宣言
    Properties prop = null;

    try {
      // オブジェクトを取得
      prop = propertiesFactoryBean.getObject();
    } catch (IOException ex) {
      // システム例外をスロー（プロパティから取ることができないためリテラルのまま）
      throw new SystemException("外部ファイルが取得できません", ex);
    }

    // プロパティオブジェクトを返却
    return prop;
  }

  /***
   * 引数で指定されたプロパティファクトリ、キーによりプロパティから取得した結果の返却を行う。
   *
   * @param propertiesFactoryBean
   *          プロパティファクトリ
   * @param key
   *          キー
   * @return 取得結果
   */
  public static String getProperty(PropertiesFactoryBean propertiesFactoryBean, String key) {
    // リスト形式のメソッドに引き渡すため、処理を行う
    List<String> keys = new ArrayList<String>();
    keys.add(key);

    // リスト形式のメソッドを呼び出し
    Map<String, String> properties = getProperty(propertiesFactoryBean, keys);

    // 結果を返却
    return properties.get(key);
  }

  /***
   * 引数で指定されたプロパティファクトリ、キーによりプロパティから取得した結果の返却を行う。
   *
   * @param propertiesFactoryBean
   *          プロパティファクトリ
   * @param keys
   *          キー
   * @return 取得結果Map
   */
  public static Map<String, String> getProperty(PropertiesFactoryBean propertiesFactoryBean, List<String> keys) {
    // プロパティを宣言
    Properties prop = null;

    try {
      // オブジェクトを取得
      prop = propertiesFactoryBean.getObject();
    } catch (IOException ex) {
      // システム例外をスロー（プロパティから取ることができないためリテラルのまま）
      throw new SystemException("外部ファイルが取得できません", ex);
    }

    // 結果Mapを生成
    Map<String, String> properties = new HashMap<String, String>();

    // キーの数分処理を行う
    String property = null;
    for (String key : keys) {
      // キーの取得
      property = prop.getProperty(key);
      // NULLだった場合はエラー
      if (property == null) {
        throw new SystemException("プロパティの値が取得できません。プロパティキー：" + key);
      }

      // Mapに追加
      properties.put(key, property);
    }

    // 結果を返却
    return properties;
  }
}
