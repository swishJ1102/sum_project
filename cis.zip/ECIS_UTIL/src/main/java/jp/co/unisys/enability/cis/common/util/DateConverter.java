/*-------------------------------------------------------------------------------
 * All Rights Reserved. Copyright(C) Nihon Unisys, Ltd.
 * vendor : Nihon Unisys, Ltd.
 * since : 2014/09/01
 *-----------------------------------------------------------------------------*/
package jp.co.unisys.enability.cis.common.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.struts2.util.StrutsTypeConverter;

import com.opensymphony.xwork2.conversion.TypeConversionException;

/**
 * 日付型コンバータ.<br>
 * 画面とBeanの間の型変換を行うクラス
 * <p>
 * <h2>Beanから画面用の型変換</h2> Bean引数のjava.util.Date型をyyyyMMddフォーマットのString型に変換<br>
 * <h2>画面からBean用の型変換</h2> 画面入力項目のString型をBeanのjava.util.Data型にyyyyMMddフォーマットで変換(変換前に01日付を付与）<br>
 * </p>
 */
public class DateConverter extends StrutsTypeConverter {

  /*
   * (非 Javadoc)
   *
   * @see
   * org.apache.struts2.util.StrutsTypeConverter#convertFromString(java.util
   * .Map, java.lang.String[], java.lang.Class)
   */
  @Override
  public Object convertFromString(Map context, String[] values, Class toClass) {
    Object result = null;
    if (values != null) {
      result = convertDateValue(context, values[0], toClass);
    }
    return result;
  }

  /**
   * 引数のオブジェクトを指定フォーマット(yyyyMMdd)の文字列へ変換する<br>
   * 変換に失敗した場合はTypeConversionExceptionをスローする<br>
   *
   * @param context
   *          コンテキスト
   * @param valueObj
   *          引数
   * @param toClass
   *          変換後の型
   *
   * @return 日付オブジェクト
   */
  protected Object convertDateValue(Map context, Object valueObj, Class toClass) {
    Date result = null;

    SimpleDateFormat format = new SimpleDateFormat(EMSConstants.FORMAT_DATE_yyyyMMdd);
    format.setLenient(false);

    // 値を取得する
    String value = valueObj.toString();

    // 値が空なら処理しない
    if (StringUtils.isEmpty(value)) {
      return result;
    }

    // スラッシュを取り除く
    value = value.replace(EMSConstants.SLASH, "");

    // 6文字だった場合、年月型のため01を付加する
    if (value.length() == 6) {
      value = value.concat("01");
    }

    try {
      result = format.parse(value);
    } catch (ParseException e) {
      super.performFallbackConversion(context, value, toClass);
      throw new TypeConversionException();

    }

    return result;
  }

  /*
   * (非 Javadoc)
   *
   * @see
   * org.apache.struts2.util.StrutsTypeConverter#convertToString(java.util
   * .Map, java.lang.Object)
   */
  @Override
  public String convertToString(Map context, Object param) {

    String convertStr = null;
    if (param instanceof Date) {
      Date date = (Date) param;
      SimpleDateFormat format = new SimpleDateFormat(EMSConstants.FORMAT_DATE_yyyyMMdd_SLASH);
      convertStr = format.format(date);
    } else {
      convertStr = param.toString();
    }
    return convertStr;
  }
}
