/*-------------------------------------------------------------------------------
 * All Rights Reserved. Copyright(C) Nihon Unisys, Ltd.
 * vendor : Nihon Unisys, Ltd.
 * since : 2014/09/01
 *-----------------------------------------------------------------------------*/
package jp.co.unisys.enability.cis.common.util;

import org.apache.commons.lang3.StringUtils;

import com.opensymphony.xwork2.validator.ValidationException;
import com.opensymphony.xwork2.validator.validators.FieldValidatorSupport;

/**
 * 同値比較バリデータクラス.<br>
 * Struts2のバリデータサポートを拡張し、2つのフィールド値が同値か否かを判定する
 *
 */
public class EqualsStringValidator extends FieldValidatorSupport {

  /** 比較対象のフィールド名 */
  private String secondFieldName;

  /**
   * secondFieldNameのゲッター
   * 
   * @return secondFieldName
   */
  public String getSecondFieldName() {
    return secondFieldName;
  }

  /**
   * secondFieldNameのセッター
   * 
   * @param secondFieldName
   *          セットする secondFieldName
   */
  public void setSecondFieldName(String secondFieldName) {
    this.secondFieldName = secondFieldName;
  }

  /* (非 Javadoc)
   * @see com.opensymphony.xwork2.validator.Validator#validate(java.lang.Object)
   */
  @Override
  public void validate(Object object) throws ValidationException {

    String fieldName = this.getFieldName();
    String secondFieldName = this.getSecondFieldName();

    Object value1 = this.getFieldValue(fieldName, object);
    Object value2 = this.getFieldValue(secondFieldName, object);

    // どちらかが空ならチェックしない
    if (value1 == null
        || value2 == null) {
      return;
    }

    if (!(value1 instanceof String) || !(value2 instanceof String)) {
      this.addFieldError(fieldName, object);
    }

    String s1 = (String) value1;
    String s2 = (String) value2;

    // どたらかが空ならチェックしない
    if (StringUtils.isEmpty(s1)
        || StringUtils.isEmpty(s2)) {
      return;
    }

    if (!s1.equals(s2)) {
      this.addFieldError(fieldName, object);
    }

  }

}
