package jp.co.unisys.enability.cis.common.util.constants;

/**
 * 定数クラス
 *
 * @author "Nihon Unisys, Ltd."
 */
public class ECISGKConstants {

  /** メール管理カラム名：メールID */
  public static final String MAIL_MANAGEMENT_COLUMN_NAME_MAIL_ID = "mail_id";
  /** Velocity置換文字列（始まり）：${ */
  public static final String REPLACEMENT_STRING_START = "${";
  /** Velocity置換文字列（終わり）：} */
  public static final String REPLACEMENT_STRING_END = "}";
  /** 業務分類マスタカラム名：業務分類コード */
  public static final String WORK_CAT_M_COLUMN_NAME_WORK_CAT_CODE = "work_cat_code";
  /** TODOステータスマスタカラム名：TODOステータスコード */
  public static final String TODO_STATUS_M_COLUMN_NAME_TODO_STATUS_CODE = "todo_status_code";
  /** サブシステムマスタカラム名：サブシステムID */
  public static final String SSYS_M_COLUMN_NAME_SSYS_ID = "ssys_id";
  /** ファイル分類マスタカラム名：ファイル分類コード */
  public static final String FILE_CAT_M_COLUMN_NAME_FILE_CAT_CODE = "file_cat_code";
  /** 提供モデル企業マスタカラム名：提供モデル企業コード */
  public static final String FILE_PM_COMPANY_M_COLUMN_NAME_PM_COMPANY_CODE = "pm_company_code";
  /** 提供モデルマスタカラム名：提供モデルコード */
  public static final String FILE_PM_M_COLUMN_NAME_PM_CODE = "pm_code";
  /** 連動セレクトボックス用区切り文字：コロン */
  public static final String INTERLOCK_SELECTBOX_DELIMITER_COLON = ":";
  /** 連動セレクトボックス用区切り文字：カンマ */
  public static final String INTERLOCK_SELECTBOX_DELIMITER_COMMA = ",";
  /** 空文字 */
  public static final String EMPTY_STRING = "";
  /** ユーザ認証（ACL管理） 検索条件 アクションID */
  public static final String INQUIRY_USER_ACL_SEARCH_CONDITION_ACTION_ID = "actionId";
  /** ユーザ認証（ACL管理） 検索条件 ロールID */
  public static final String INQUIRY_USER_ACL_SEARCH_CONDITION_ROLE_ID = "roleId";
  /** 排他制御テーブル更新バッチ 引数の数： 3 */
  public static final int GK910101_UPDATE_EXCLUSIVE_CONTROL_TABLE_BATCH_ARGUMENT_LENGTH = 3;
  /** 排他制御テーブル更新バッチ 引数の処理IDの最大文字列： 20 */
  public static final int GK910101_UPDATE_EXCLUSIVE_CONTROL_TABLE_BATCH_ARGUMENT_PROCESS_ID_MAX_LENGTH = 20;

}
