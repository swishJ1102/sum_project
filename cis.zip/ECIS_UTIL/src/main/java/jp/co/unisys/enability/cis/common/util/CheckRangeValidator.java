package jp.co.unisys.enability.cis.common.util;

import com.opensymphony.xwork2.validator.ValidationException;
import com.opensymphony.xwork2.validator.validators.FieldValidatorSupport;

/**
 * Struts用数字範囲チェックバリデータ。
 *
 * <pre>
 * <p><b>【仕様詳細】<b><p>
 * 文字列として定義されている数字の範囲チェックを行うバリデータ。
 * </pre>
 *
 *
 * @author "Nihon Unisys, Ltd."
 *
 */
public class CheckRangeValidator extends FieldValidatorSupport {

  /** 最小値名 */
  private Long min;

  /** 最大値名 */
  private Long max;

  /**
   * 最小値名取得
   *
   * @return 最小値名
   */
  public Long getMin() {
    return min;
  }

  /**
   * 最小値名設定
   *
   */
  public void setMin(Long min) {
    this.min = min;
  }

  /**
   * 最大値名取得
   *
   * @return 最大値名
   */
  public Long getMax() {
    return max;
  }

  /**
   * 最大値名設定
   *
   */
  public void setMax(Long max) {
    this.max = max;
  }

  /*
   * (非 Javadoc)
   * @see com.opensymphony.xwork2.validator.Validator#validate(java.lang.Object)
   */
  @Override
  public void validate(Object object) throws ValidationException {

    /* フィールド名取得 */
    String fieldName = this.getFieldName();
    /* フィールド値取得 */
    Object value1 = this.getFieldValue(fieldName, object);

    /* 型変換 */
    String colum = (String) value1;

    /* 範囲チェック */
    if (!CommonValidationUtil.checkRange(colum, this.getMin(), this.getMax())) {
      this.addFieldError(fieldName, object);
    }
  }

}
