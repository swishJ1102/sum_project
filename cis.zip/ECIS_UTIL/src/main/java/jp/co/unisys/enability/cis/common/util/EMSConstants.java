/*-------------------------------------------------------------------------------
 * All Rights Reserved. Copyright(C) Nihon Unisys, Ltd.
 * vendor : Nihon Unisys, Ltd.
 * since : 2014/09/01
 * revision：2015/02/06 【ph2開発】CPX利用フラグ制御、空室（ダミー）契約、督促状の対応、MEMS連携汎用項目の対応
 *           2015/04/20 【ph3開発】ブランドの対応、経理帳票の対応
 *-----------------------------------------------------------------------------*/
package jp.co.unisys.enability.cis.common.util;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import jp.co.unisys.enability.cis.common.util.EcisPersonalEnums.ModuleCode;
import jp.co.unisys.enability.cis.common.util.EcisPersonalEnums.ScreenId;

/**
 * EMS定数クラス.<br>
 * システム内部で共通的に使用する定数を保持します
 */
public class EMSConstants {

  /** エラーリスト名前 */
  public static final String ERROR_LIST_PREFIX = "errorlist_";

  /** エラーリストリトライ間隔（ミリ秒） */
  public static final int ERRORLIST_RETRY_INTERVAL = 3000;
  /** エラーリストリトライ回数 */
  public static final int ERRORLIST_RETRY_COUNT = 3;

  /** 料金情報ダウンロード：明細超過フラグ-未超過 */
  public static final String DOWNLOAD_DETAIL_OVER_FLAG_OFF = "0";
  /** 料金情報ダウンロード：明細超過フラグ-超過 */
  public static final String DOWNLOAD_DETAIL_OVER_FLAG_ON = "1";
  /** 料金情報ダウンロード：CSVファイル接頭辞 */
  public static final String DOWNLOAD_CSVFILE_PREFIX = "meisai_";
  /** 料金情報ダウンロード：エラーファイル接尾辞 */
  public static final String DOWNLOAD_CSVFILE_ERROR_SUFFIX = "_error";
  /** 料金情報ダウンロード：zipファイル-料金確定状況が未確定の場合の接尾辞(未確定) */
  public static final String DOWNLOAD_ZIPFILE_UNDECIDEC = "_noFixed";
  /** 料金情報ダウンロード：zipファイル-料金確定状況が確定済の場合の接尾辞(請求未反映) */
  public static final String DOWNLOAD_ZIPFILE_DECISION = "_noBillinged";
  /** 料金情報ダウンロード：明細情報区分-DCEC */
  public static final Integer DOWNLOAD_DETAIL_CATEGORY_DCEC = 1;
  /** 料金情報ダウンロード：明細情報区分-割引 */
  public static final Integer DOWNLOAD_DETAIL_CATEGORY_DISCOUNT = 2;
  /** 料金情報ダウンロード：明細情報区分-調整 */
  public static final Integer DOWNLOAD_DETAIL_CATEGORY_ADJUSTMENT = 3;
  /** 料金情報ダウンロード：明細割引プラン種別-電力会社 */
  public static final Integer DOWNLOAD_DETAIL_DISCOUNT_CLASS_JPC = 1;
  /** 料金情報ダウンロード：明細割引プラン種別-一括受電事業者 */
  public static final Integer DOWNLOAD_DETAIL_DISCOUNT_CLASS_BRO = 2;
  /** 料金情報ダウンロード：明細割引プラン種別-その他 */
  public static final Integer DOWNLOAD_DETAIL_DISCOUNT_CLASS_OTHER = 9;

  /** バッチID：B0100-01 */
  public static final String BATCH_ID_B0001_01 = "B0100-01";
  /** バッチID：B0100-02 */
  public static final String BATCH_ID_B0001_02 = "B0100-02";
  /** バッチID：B0101-01 */
  public static final String BATCH_ID_B0101_01 = "B0101-01";
  /** バッチID：B0101-02 */
  public static final String BATCH_ID_B0101_02 = "B0101-02";
  /** バッチID：B0101-03 */
  public static final String BATCH_ID_B0101_03 = "B0101-03";
  /** バッチID：B0101-04 */
  public static final String BATCH_ID_B0101_04 = "B0101-04";
  /** バッチID：B0101-05 */
  public static final String BATCH_ID_B0101_05 = "B0101-05";
  /** バッチID：B0101-06 */
  public static final String BATCH_ID_B0101_06 = "B0101-06";
  /** バッチID：B0102-01 */
  public static final String BATCH_ID_B0102_01 = "B0102-01";
  /** バッチID：B0102-02 */
  public static final String BATCH_ID_B0102_02 = "B0102-02";
  /** バッチID：B0102-03 */
  public static final String BATCH_ID_B0102_03 = "B0102-03";
  /** バッチID：B0103-01 */
  public static final String BATCH_ID_B0103_01 = "B0103-01";

  /** バッチステータス：正常 */
  public static final int BATCH_RESULT_CODE_SUCCESS = 0;
  /** バッチステータス：異常 */
  public static final int BATCH_RESULT_CODE_ERROR = 1;
  /** バッチステータス：テーブルロックエラー */
  public static final Integer BATCH_RESULT_CODE_TABLELOCK_ERROR = 2;
  /** バッチステータス：ファイル送信エラー */
  public static final Integer BATCH_RESULT_CODE_SENDFILE_ERROR = 3;
  /** バッチステータス：警告終了 */
  public static final Integer BATCH_RESULT_CODE_WARNING = 9;
  /** バッチステータス：実行中 */
  public static final Integer BATCH_RESULT_CODE_EXECUTTION = -1;

  /** バッチB0101-04論理名称 */
  public static final String BATCH_NAMW_B0101_04 = "有効性結果チェック受信";

  /** バッチファイルレコード固定長：B0101-03 */
  public static final Integer BATCH_B0101_03_FILE_RECORD_LENGTH = 98;
  /** バッチファイルレコード固定長：B0101-04 */
  public static final Integer BATCH_B0101_04_FILE_RECORD_LENGTH = 118;

  /** B0101-04バリデーション用ファイル項目名 */
  public static final String BATCH_B0101_04_DATA_RECORD = "データレコード";
  public static final String BATCH_B0101_04_DATA_INPUT_MEMBER_NUMBER = "入力会員番号";
  public static final String BATCH_B0101_04_DATA_NEW_EFFECTIVE_RESULT = "新有効性判定結果";

  /** DCEC区分(DC) */
  public static final String DCEC_CATEGORY_DC = "1";

  /** DCEC区分(EC) */
  public static final String DCEC_CATEGORY_EC = "2";

  /** 請求対象区分:請求対象 */
  public static final String BILLING_TARGET_CATEGORY_YES = "0";

  /** 請求対象区分:請求対象外 */
  public static final String BILLING_TARGET_CATEGORY_NOT = "1";

  /** 料金単価設定：備考の最大長 */
  public static final int NOTE_MAX_LENGTH = 200;
  /** 料金単価設定：単価整数部最大値 */
  public static final int UNIT_PRICE_MAX_LENGTH = 5;
  /** 料金単価設定：最低月額料金整数部最大値 */
  public static final int MONTHLY_AMOUNT_MAX_LENGTH = 8;
  /** 料金単価設定：最低月額料金・単価小数部最大値 */
  public static final int UNIT_PRICE_MIN_LENGTH = 2;

  /** 検針情報登録のエラーリストファイル接頭辞 */
  public static final String S0102_ERROR_LIST_FILE_NAME_PREFIX = "errorlist_S0102-02_";

  /** ファイルダウンロード時のバッファサイズ */
  public static final int DOWNLOAD_BUFFER_SIZE = 1024;

  /** エンコード：UTF-8 */
  public static final String ENCODE_TYPE_UTF8 = "UTF-8";

  /** エンコード：SJIS */
  public static final String ENCODE_TYPE_SJIS = "SJIS";

  /** 画面遷移：登録・更新 */
  public static final String VIEW_RESULT_ADD_OR_UPDATE = "add";
  /** 画面遷移：削除 */
  public static final String VIEW_RESULT_DELETE = "delete";
  /** 画面遷移：ファイルダウンロード */
  public static final String VIEW_RESULT_DOWNLOAD = "download";
  /** 画面遷移：初期化 */
  public static final String VIEW_RESULT_INITIAL = "initial";

  /** 改行コード：CRLF */
  public static final String ENTER_CODE = "\r\n";

  /** CPREMIXレコード識別：ヘッダレコード:「1」 */
  public static final String CPREMIX_HEADER_RECORD = "1";

  /** CPREMIXレコード識別：データレコード:「2」 */
  public static final String CPREMIX_DATA_RECORD = "2";

  /** CPREMIXレコード識別：トレーラレコード:「3」 */
  public static final String CPREMIX_TRAILER_RECORD = "3";

  /** CPREMIXレコード識別：トレーラレコード:「8」 */
  public static final String CPREMIX_YUUKOUKEKKA_TRAILER_RECORD = "8";

  /** CPREMIXレコード識別：エンドレコード:「9」 */
  public static final String CPREMIX_END_RECORD = "9";

  /** CPREMIXバッチファイル先頭名 */
  public static final String CPREMIX_FILE_TOP = "PC_T";

  /** ENABILITYレコード識別：ヘッダレコード:「1」 */
  public static final String ENABILITY_HEADER_RECORD = "1";

  /** ENABILITYレコード識別：データレコード:「2」 */
  public static final String ENABILITY_DATA_RECORD = "2";

  /** ENABILITYレコード識別：トレーラレコード:「3」 */
  public static final String ENABILITY_TRAILER_RECORD = "3";

  /** ENABILITYレコード識別：エンドレコード:「4」 */
  public static final String ENABILITY_END_RECORD = "4";

  /** ENABILITYレコード識別：エラーレコード:「9」 */
  public static final String ENABILITY_ERROR_RECORD = "9";

  /** インターフェース種別識別 B0101_01 */
  public static final String B0101_01_INTERFACE_KIND = "KOKYAKU";
  /** インターフェース種別識別 B0101_02 */
  public static final String B0101_02_INTERFACE_KIND = "SAIKENJYOUTO";
  /** インターフェース種別識別 B0101_03 */
  public static final String B0101_03_INTERFACE_KIND = "SHUUNOU";
  /** インターフェース種別識別 B0101_04 */
  public static final String B0101_04_INTERFACE_KIND = "YUUKOUKEKKA";

  /** underline 定数 */
  public static final String UNDERLINE = "_";

  /** 定数 */
  public static final String OCTOTHORPE = "###";

  /** 半角スペース 定数 */
  public static final String SPACE_HANKAKU = " ";
  /** 全角スペース 定数 */
  public static final String SPACE_ZENKAKU = "　";
  /** 全角波形 定数 */
  public static final String NAMISEN_ZENKAKU = "～";
  /** SQLエスケープ文字 */
  public static final String SQL_ESCAPE_CHAR = "#";
  /** SQLエスケープ対象文字 */
  public static final String[] SQL_ESCAPE_TARGETS = new String[] {"_", "%" };

  /** 文言コード：明細-基本料金 */
  public static final String WORDING_MST_KEY_00010001 = "00010001";

  /** 文言コード：明細-燃料費調整額 */
  public static final String WORDING_MST_KEY_00010002 = "00010002";

  /** 文言コード：明細-再エネ発電賦課金等 */
  public static final String WORDING_MST_KEY_00010003 = "00010003";

  /** 文言コード：明細-一括受電割引額 */
  public static final String WORDING_MST_KEY_00010004 = "00010004";

  /** 文言コード：明細-ポイント割引額 */
  public static final String WORDING_MST_KEY_00010005 = "00010005";

  /** ポイント反映フラグ：未反映 */
  public static final String POINT_REFLECTION_FLAG_NOREFLECTED = "0";
  /** ポイント反映フラグ：反映済 */
  public static final String POINT_REFLECTION_FLAG_REFLECTED = "1";

  /** 割引プラン種別コード：電力会社提供メニュー */
  public static final String DISCOUNT_PLAN_CLASS_ECOMPANY = "1";

  /** 割引プラン種別コード：一括受電事業者提供メニュー */
  public static final String DISCOUNT_PLAN_CLASS_BROPERATOR = "2";

  /** 料金計算結果確定ステータス：未確定 */
  public static final String BILLING_FIX_STATUS_UNDECIDEC = "0";

  /** 料金計算結果確定ステータス：料金確定済 */
  public static final String BILLING_FIX_STATUS_DECISION = "1";

  /** 料金計算結果確定ステータス：請求作成済 */
  public static final String BILLING_FIX_STATUS_CLAIMED = "2";

  /** 料金計算結果確定ステータス：債権譲渡指示済 */
  public static final String BILLING_FIX_STATUS_ASSAIGNMENT_CLAIMED = "3";

  /** 料金計算結果確定ステータス：債権譲渡済 */
  public static final String BILLING_FIX_STATUS_ASSAIGNMENT_CLAIMED_FIX = "4";

  /** 料金計算結果確定ステータス：料金確定エラー */
  public static final String BILLING_FIX_STATUS_DECISION_ERROR = "A";

  /** 料金計算結果確定ステータス：債権譲渡エラー */
  public static final String BILLING_FIX_STATUS_ASSAIGNMENT_CLAIMED_ERROR = "B";

  /** CPX利用フラグ：未利用 */
  public static final String CPX_USAGE_FLAG_UNDERUSE = "0";

  /** CPX利用フラグ：利用 */
  public static final String CPX_USAGE_FLAG_USE = "1";

  /** 文書識別区分:未納あり */
  public static final String DOC_DISCRIMINATION_CATEGORY = "3";

  /** 文書分類区分：未納あり */
  public static final String DOC_CLASSIFICATION_CATEGORY = "1";

  /** 文書分類区分２:解約通知書 */
  public static final String DOC_CLASSIFICATION_CATEGORY_2_E = "E";

  /** 文書分類区分２:解約予告書 */
  public static final String DOC_CLASSIFICATION_CATEGORY_2_D = "D";

  /** 文書分類区分２:利用停止予告書 */
  public static final String DOC_CLASSIFICATION_CATEGORY_2_C = "C";

  /** 文書分類区分２:支払通知書 */
  public static final String DOC_CLASSIFICATION_CATEGORY_2_B = "B";

  /** 経理ステータス:通常 */
  public static final String ACCOUNTING_STATUS_NORMAL = "0";

  /** 経理ステータス:償却 */
  public static final String ACCOUNTING_STATUS_REPAYMENT = "1";

  /** 経理ステータス:社内利用 */
  public static final String ACCOUNTING_STATUS_COMPANY_USAGE = "2";

  /** MEMS自動連携利用フラグ：未利用 */
  public static final String MEMS_AUTOLINK_FLG_OFF = "0";

  /** MEMS自動連携利用フラグ：利用 */
  public static final String MEMS_AUTOLINK_FLG_ON = "1";

  /** 契約・物件情報ダウンロード：レコード種別：ヘッダー */
  public static final String BUILDING_CONTRACT_HEADER_RECORD = "0";
  /** 契約・物件情報ダウンロード：レコード種別：ヘッダー */
  public static final String BUILDING_CONTRACT_DATA_RECORD = "1";
  /** 契約・物件情報ダウンロード：項目種別：建物情報 */
  public static final String BUILDING_CONTRACT_CLASS_BUILDING = "h";
  /** 契約・物件情報ダウンロード：項目種別：棟・集約機器情報 */
  public static final String BUILDING_CONTRACT_CLASS_RIDGE = "t";
  /** 契約・物件情報ダウンロード：項目種別：部屋情報 */
  public static final String BUILDING_CONTRACT_CLASS_ROOM = "r";
  /** 契約・物件情報ダウンロード：項目種別：契約者情報 */
  public static final String BUILDING_CONTRACT_CLASS_CONTRACTOR = "c";
  /** 契約・物件情報ダウンロード：項目種別：契約料金メニュー情報 */
  public static final String BUILDING_CONTRACT_HEADER_CONTRACTPRICE = "p";
  /** 契約・物件情報ダウンロード：項目種別：契約割引メニュー情報 */
  public static final String BUILDING_CONTRACT_HEADER_DISCOUNTCONTRACT = "d";
  /** 契約・物件情報ダウンロード：ファイル名接頭辞：契約者 */
  public static final String BUILDING_CONTRACT_FILE_PREFIX_CUSTOMER = "Customer_";
  /** 契約・物件情報ダウンロード：ファイル名接頭辞：支払 */
  public static final String BUILDING_CONTRACT_FILE_PREFIX_PAYMENT = "Payment_";
  /** 契約・物件情報ダウンロード：ファイル名接頭辞：契約 */
  public static final String BUILDING_CONTRACT_FILE_PREFIX_CONTRACT = "Contract_";
  /** 契約・物件情報ダウンロード：ファイル名接頭辞：割引契約 */
  public static final String BUILDING_CONTRACT_FILE_PREFIX_DISCOUNT = "Discount_";
  /** 契約・物件情報ダウンロード：ファイル名接頭辞：メータ設置場所 */
  public static final String BUILDING_CONTRACT_FILE_PREFIX_METER = "Meter_";
  /** 契約・物件情報ダウンロード：ファイル名接頭辞：物件 */
  public static final String BUILDING_CONTRACT_FILE_PREFIX_PROPERTY = "Property_";
  /** 契約・物件情報ダウンロード：ファイル名接頭辞：棟・部屋 */
  public static final String BUILDING_CONTRACT_FILE_PREFIX_BUILDING = "Building_";
  /** 契約・物件情報ダウンロード：ファイル名接頭辞：結合 */
  public static final String BUILDING_CONTRACT_FILE_PREFIX_COMBINATION = "Combination_";
  /** 契約・物件情報ダウンロード：ファイル名接頭辞：Enability連携用基本 */
  public static final String BUILDING_CONTRACT_FILE_PREFIX_ENABILITY = "kihon_";
  /** 契約・物件情報ダウンロード：項目名：契約者 */
  public static final String BUILDING_CONTRACT_COLUMS_NAME_CUSTOMER = "レコード種別,顧客番号,氏名（漢字）,氏名（カナ）,電話番号1区分,電話番号1,電話番号2区分,電話番号2,メールアドレス,郵便番号,住所,番地・号,物件名,棟名,部屋番号,備考,取消フラグ,登録・更新区分";
  /** 契約・物件情報ダウンロード：項目名：支払 */
  public static final String BUILDING_CONTRACT_COLUMS_NAME_PAYMENT = "レコード種別,支払番号,顧客番号,適用開始年月日,適用終了年月日,支払方法区分,個人・法人区分,請求書発送止め区分,連携用クレジットカード番号,支払先氏名（漢字）,支払先氏名（カナ）,支払先・郵便番号,支払先・住所,支払先・番地・号,支払先・物件名,支払先・棟名,支払先・部屋番号,支払先・電話番号1区分,支払先・電話番号1,支払先・電話番号2区分,支払先・電話番号2,金融機関コード,金融機関名称,金融機関支店コード,金融機関支店名称,口座種別,口座番号,口座名義人名,請求対象区分,備考,登録・更新区分";
  /** 契約・物件情報ダウンロード：項目名：契約 */
  public static final String BUILDING_CONTRACT_COLUMS_NAME_CONTRACT = "レコード種別,契約番号,支払番号,物件番号,棟番号,SM集約機器番号,部屋番号,料金プランコード,契約開始年月日,契約終了年月日,MEMS契約開始年月日,MEMS契約終了年月日,適用開始年月日,適用終了年月日,契約容量,力率,融雪契約月,請求対象区分,MEMS連携汎用項目1,MEMS連携汎用項目2,MEMS連携汎用項目3,備考,登録・更新区分";
  /** 契約・物件情報ダウンロード：項目名：割引契約 */
  public static final String BUILDING_CONTRACT_COLUMS_NAME_DISCOUNT = "レコード種別,割引契約番号,契約番号,割引プランコード,契約開始年月日,契約終了年月日,契約容量,登録・更新区分";
  /** 契約・物件情報ダウンロード：項目名：メータ設置場所 */
  public static final String BUILDING_CONTRACT_COLUMS_NAME_METER = "レコード種別,部屋番号,物件番号,棟番号,SM集約機器番号,部屋種別,部屋・共有部名,メータ番号,メータ管理番号,メータ乗率,供給停止区分,供給停止日,供給停止解除日,メータ取替前計量値,メータ取替年月日,備考,取消フラグ,登録・更新区分";
  /** 契約・物件情報ダウンロード：項目名：物件 */
  public static final String BUILDING_CONTRACT_COLUMS_NAME_PROPERTY = "レコード種別,物件番号,物件名,都道府県名,管轄電力会社名,物件契約電力,物件契約種別,インターホンメーカ番号,MEMSサービス開始日,検針日開始年月,検針日,専有部分割引率,専有部分割引額,共有部分割引率,共有部分割引額,管理会社名,管理会社電話番号,ブランドコード,サービスコード,備考,取消フラグ,登録・更新区分";
  /** 契約・物件情報ダウンロード：項目名：棟・部屋 */
  public static final String BUILDING_CONTRACT_COLUMS_NAME_BUILDING = "レコード種別,棟番号,物件番号,SM集約機器番号,棟名,マンションゲートウェイMACアドレス,付加情報1,付加情報2,SM集約機器メーカ種別,SM集約機器名,SM集約機器IPアドレス,管理人室電話番号,備考,取消フラグ,登録・更新区分";
  /** 契約・物件情報ダウンロード：項目名：結合 */
  public static final String BUILDING_CONTRACT_COLUMS_NAME_COMBINATION = "レコード種別,契約番号,料金プランコード,契約開始年月日,契約終了年月日,MEMS契約開始年月日,MEMS契約終了年月日,契約適用開始年月日,契約適用終了年月日,契約容量,力率,融雪契約月,請求対象区分,MEMS連携汎用項目1,MEMS連携汎用項目2,MEMS連携汎用項目3,契約備考,割引契約番号,割引プランコード,割引契約開始年月日,割引契約終了年月日,割引契約容量,支払番号,支払適用開始年月日,支払適用終了年月日,支払方法区分,個人・法人区分,請求書発送止め区分,連携用クレジットカード番号,支払先氏名（漢字）,支払先氏名（カナ）,支払先・郵便番号,支払先・住所,支払先・番地・号,支払先・物件名,支払先・棟名,支払先・部屋番号,支払先・電話番号1区分,支払先・電話番号1,支払先・電話番号2区分,支払先・電話番号2,金融機関コード,金融機関名称,金融機関支店コード,金融機関支店名称,口座種別,口座番号,口座名義人名,支払備考,顧客番号,氏名（漢字）,氏名（カナ）,電話番号1区分,電話番号1,電話番号2区分,電話番号2,メールアドレス,郵便番号,住所,番地・号,契約者備考,契約者取消フラグ,物件番号,物件名,都道府県名,管轄電力会社名,物件契約電力,物件契約種別,インターホンメーカ番号,MEMSサービス開始日,検針日開始年月,検針日,専有部分割引率,専有部分割引額,共用部分割引率,共用部分割引額,管理会社名,管理会社電話番号,ブランドコード,サービスコード,物件備考,物件取消フラグ,棟番号,SM集約機器番号,棟名,マンションゲートウェイMACアドレス,付加情報1,付加情報2,SM集約機器メーカ種別,SM集約機器名,SM集約機器IPアドレス,管理人室電話番号,棟備考,棟取消フラグ,部屋番号,部屋種別,部屋・共有部名,メータ番号,メータ管理番号,メータ乗率,供給停止区分,供給停止日,供給停止解除日,メータ取替前計量値,メータ取替年月日,メータ設置場所備考,メータ設置場所取消フラグ";

  /** 割引率算出用計算値(100) */
  public static final BigDecimal MULTIPLY_VALUE = new BigDecimal(100);

  /** 収納方法コード-クレジット */
  public static final String RECEIPT_WAY_CODE_CREDIT = "01";
  /** 収納方法コード-口座振替 */
  public static final String RECEIPT_WAY_CODE_ACCOUNT = "02";
  /** 収納方法コード-コンビニ */
  public static final String RECEIPT_WAY_CODE_CONVENI = "03";
  /** 収納方法コード-総合振込 */
  public static final String RECEIPT_WAY_CODE_COMP_TRANSFER = "04";
  /** 収納方法コード-現金書留 */
  public static final String RECEIPT_WAY_CODE_REGISTERED_MAIL = "05";
  /** 収納方法コード-訪問徴収 */
  public static final String RECEIPT_WAY_CODE_VISIT_COLLECTION = "06";
  /** 収納方法コード-窓口払い */
  public static final String RECEIPT_WAY_CODE_WINDOW_PAYMENT = "07";
  /** 収納方法コード-補正入金 */
  public static final String RECEIPT_WAY_CODE_COMPENSATION_PAYMENT = "08";
  /** 収納方法コード-小切手／手形 */
  public static final String RECEIPT_WAY_CODE_CHECK = "09";
  /** 収納方法コード-局総合振込 */
  public static final String RECEIPT_WAY_CODE_OFFICE_SYNTHESIS_TRANSFER = "14";
  /** 収納方法コード-局現金書留 */
  public static final String RECEIPT_WAY_CODE_OFFICE_REGISTERED_MAIL = "15";
  /** 収納方法コード-局訪問徴収 */
  public static final String RECEIPT_WAY_CODE_OFFICE_VISIT_COLLECTION = "16";
  /** 収納方法コード-局窓口払い */
  public static final String RECEIPT_WAY_CODE_OFFICE_WINDOW_PAYMENT = "17";
  /** 収納方法コード-振込手数料 */
  public static final String RECEIPT_WAY_CODE_TRANSFER_COMMISSION = "21";
  /** 収納方法コード-清算調整金 */
  public static final String RECEIPT_WAY_CODE_LIQUIDATION_ADJUST_MONEY = "70";
  /** 収納方法コード-サービサー */
  public static final String RECEIPT_WAY_CODE_SERVICER = "80";
  /** 収納方法コード-買戻し */
  public static final String RECEIPT_WAY_CODE_REPURCHASE = "90";
  /** 収納方法コード-0円請求 */
  public static final String RECEIPT_WAY_CODE_ZERO_BILLING = "99";

  /** 収納結果コード-成功 */
  public static final String RECEIPT_RESULT_CODE_SUCCESS = "00";
  /** 収納結果コード-資金不足 */
  public static final String RECEIPT_RESULT_CODE_MISSING_FUND = "01";
  /** 収納結果コード-取引なし */
  public static final String RECEIPT_RESULT_CODE_NO_EXCHANGE = "02";
  /** 収納結果コード-預金者都合振替停止 */
  public static final String RECEIPT_RESULT_CODE_STOP_TRANSFER_DEPOSITOR = "03";
  /** 収納結果コード-口座振替依頼書なし */
  public static final String RECEIPT_RESULT_CODE_NO_ACCOUNT_TRANSFER_REQUEST = "04";
  /** 収納結果コード-名義相違 */
  public static final String RECEIPT_RESULT_NAME_INVALID = "07";
  /** 収納結果コード-委託者都合振替停止 */
  public static final String RECEIPT_RESULT_CODE_STOP_TRANSFER_CLIENT = "08";
  /** 収納結果コード-その他 */
  public static final String RECEIPT_RESULT_CODE_OTHER = "09";
  /** 収納結果コード-エラー */
  public static final String RECEIPT_RESULT_CODE_ERROR = "0E";
  /** 収納結果コード-振替結果未着 */
  public static final String RECEIPT_RESULT_CODE_TRANSFER_RESULT_NOT_ARRIVED = "0N";
  /** 収納結果コード-ポイント */
  public static final String RECEIPT_RESULT_CODE_POINT = "10";
  /** 収納結果コード-不足入金 */
  public static final String RECEIPT_RESULT_CODE_RECEIPT_DEFICIT = "12";
  /** 収納結果コード-入金取消 */
  public static final String RECEIPT_RESULT_CODE_RECEIPT_CANCEL = "21";
  /** 収納結果コード-0円請求 */
  public static final String RECEIPT_RESULT_CODE_ZERO_BILLING = "99";

  /** 有効性判定結果コード- 有効性OK */
  public static final String EFFICACY_JUDGE_RESULT_OK = "0";

  /** 有効性判定結果コード- 有効性NG */
  public static final String EFFICACY_JUDGE_RESULT_NG = "1";

  /** 有効性判定結果コード- 照合エラー */
  public static final String EFFICACY_JUDGE_RESULT_ERROR = "2";

  /** 収納ステータス-請求未反映 */
  public static final String RECEIPT_STATUS_NO_REFLECTED = "0";
  /** 収納ステータス-請求反映済 */
  public static final String RECEIPT_STATUS_REFLECTED = "1";
  /** 収納ステータス-請求反映対象外 */
  public static final String RECEIPT_STATUS_NO_TARGET = "2";
  /** 収納ステータス-エラー */
  public static final String RECEIPT_STATUS_ERROR = "9";

  /** 債権ステータス：未収納 */
  public static final String CLAIM_STATUS_UNDELIVERED = "0";
  /** 債権ステータス：収納済 */
  public static final String CLAIM_STATUS_DELIVERED = "1";
  /** 債権ステータス：部分収納 */
  public static final String CLAIM_STATUS_PARTIAL_DELIVERED = "2";
  /** 債権ステータス：過剰収納 */
  public static final String CLAIM_STATUS_SURPLUS_DELIVERED = "3";

  /** インターホンメーカ番号-アイホンVIXUS */
  public static final String INTER_COMMAKER_MAKER_NO_VIXUS = "001";
  /** インターホンメーカ番号-パナソニック */
  public static final String INTER_COMMAKER_MAKER_NO_WINDEA = "002";
  /** インターホンメーカ番号-アイホンVIXUS 1Pr */
  public static final String INTER_COMMAKER_MAKER_NO_VIXUS_1PR = "003";

  /** 支払方法区分-コンビニ収納 */
  public static final String PAYMENT_WAY_CATEGORY_CONVENI = "1";
  /** 支払方法区分-口座振替 */
  public static final String PAYMENT_WAY_CATEGORY_ACCOUNT = "2";
  /** 支払方法区分-クレジット */
  public static final String PAYMENT_WAY_CATEGORY_CREDIT = "4";

  /** 文言グループコード-明細基本項目 */
  public static final String WORDING_GROUP_CODE_DETAIL_BASIC_ITEM = "0001";

  /** 文言グループコード-基本料金 */
  public static final String WORDING_GROUP_CODE_BASIC_RATE = "0002";

  /** 文言グループコード-電力量料金 */
  public static final String WORDING_GROUP_CODE_POWER_CONSUMPTION_RATE = "0003";

  /** 文言グループコード-調整種別 */
  public static final String WORDING_GROUP_CODE_ADJUSTMENT_CLASS = "0004";

  /** バッチ起動ユーザ */
  public static final String BATCH_USER = "batch_user";

  /** 権限区分-管理者 */
  public static final String AUTHORIZATIONS_CATEGORY_ADMIN = "0";
  /** 権限区分-オペレータ */
  public static final String AUTHORIZATIONS_CATEGORY_OPERATOR = "1";
  /** 権限区分-ユーザ */
  public static final String AUTHORIZATIONS_CATEGORY_USER = "2";

  /** 補正ステータス-補正対象外 */
  public static final String CORRECT_STATUS_NOT_CORRECTTARGET = "0";
  /** 補正ステータス-補正前 */
  public static final String CORRECT_STATUS_BEFORE_CORRECT = "1";
  /** 補正ステータス-補正済 */
  public static final String CORRECT_STATUS_CORRECTED = "2";
  /** 補正ステータス-補正承認済 */
  public static final String CORRECT_STATUS_CORRECT_APPROVED = "3";
  /** 補正ステータス-削除登録済 */
  public static final String CORRECT_STATUS_DELETE_REGISTED = "4";

  /** 個人・法人区分-個人 */
  public static final String PERSONAL_CORPORATION_CATEGORY_PERSONAL = "1";
  /** 個人・法人区分-法人 */
  public static final String PERSONAL_CORPORATION_CATEGORY_CORPORATION = "2";

  /** 請求書発送止め区分-通常発送 */
  public static final String BILLING_SEND_STOP_CATEGORY_NORMAL = "0";
  /** 請求書発送止め区分-発送止め */
  public static final String BILLING_SEND_STOP_CATEGORY_STOP = "1";
  /** 請求書発送止め区分-発行無し */
  public static final String BILLING_SEND_STOP_CATEGORY_NONE = "2";

  /** 口座種別-普通 */
  public static final String ACCOUNT_CLASS_NORMAL = "1";
  /** 口座種別-当座 */
  public static final String ACCOUNT_CLASS_CURRENT = "2";

  /** 部屋種別-専有部 */
  public static final String ROOM_CLASS_EXCLUSIVE = "01";
  /** 部屋種別-共用部 */
  public static final String ROOM_CLASS_COMMON = "02";
  /** 部屋種別-店舗・事務所 */
  public static final String ROOM_CLASS_OFFICE = "03";

  /** 電話番号区分-固定 */
  public static final String PHONE_NO_CATEGORY_FIX = "0";
  /** 電話番号区分-携帯 */
  public static final String PHONE_NO_CATEGORY_MOBILE = "1";

  /** MEMS処理区分-登録 */
  public static final String MEMS_PROCESS_CATEGORY_INSERT = "I";
  /** MEMS処理区分-更新 */
  public static final String MEMS_PROCESS_CATEGORY_UPDATE = "U";
  /** MEMS処理区分-削除 */
  public static final String MEMS_PROCESS_CATEGORY_DELETE = "D";

  /** 料金単価設定：再エネ単価判断用コード接頭辞 */
  public static final String RENEWAL_CODE_PREFIX = "RN";
  /** 料金単価設定：燃調単価判断用コード接頭辞 */
  public static final String FUEL_CODE_PREFIX = "FL";
  /** 料金単価設定：再エネ単価プラン名 */
  public static final String RENEWAL_UNIT_PRICE_NAME = "再エネ単価";
  /** 料金単価設定：燃調単価プラン名 */
  public static final String FUEL_UNIT_PRICE_NAME = "燃調単価";
  /** 料金単価設定：左括弧 */
  public static final String PARENTHESIS_LEFT = "（";
  /** 料金単価設定：右括弧 */
  public static final String PARENTHESIS_RIGHT = "）";
  /** 供給区分-低圧 */
  public static final String SUPPLY_CATEGORY_LOW = "1";
  /** 供給区分-高圧 */
  public static final String SUPPLY_CATEGORY_HIGH = "2";

  /** 契約情報照会 検索条件キー */
  public static final String MAPKEY_CONTRACT_ID = "contractId";
  public static final String MAPKEY_CONTRACTOR_ID = "contractorId";

  /** 収納結果情報受信 検索条件キー */
  public static final String MAPKEY_SETTLEMENT_YM = "settlementYm";
  public static final String MAPKEY_PAYMENT_NO = "paymentNo";

  /** 建物情報照会 検索条件キー */
  public static final String MAPKEY_BUILDING_ID = "buildingId";
  public static final String MAPKEY_RIDGE_ID = "ridgeId";

  /** パスワード初期化フラグ：オフ(0) */
  public static final String USER_PASSWORD_INITIALIZATION_FLG_OFF = "0";
  /** パスワード初期化フラグ：オン(1) */
  public static final String USER_PASSWORD_INITIALIZATION_FLG_ON = "1";
  /** パスワード失敗回数：初期値(0) */
  public static final short USER_PASSWORD_FAILER_COUNT_RESET = 0;
  /** パスワードロックフラグ：オフ(0) */
  public static final String USER_PASSWORD_LOCK_FLG_OFF = "0";
  /** パスワードロックフラグ：オン(1) */
  public static final String USER_PASSWORD_LOCK_FLG_ON = "1";
  /** パスワード更新関数処理結果：失敗履歴チェック(1) */
  public static final String USER_PASSWORD_UPDATE_HISTORY_ERROR = "1";
  /** パスワード更新関数処理結果：失敗排他エラー(2) */
  public static final String USER_PASSWORD_UPDATE_LOCK_ERROR = "2";
  /** パスワード更新関数処理結果：失敗その他(9) */
  public static final String USER_PASSWORD_UPDATE_OTHER_ERROR = "9";
  /** パスワード照合関数処理結果：成功(0) */
  public static final String USER_PASSWORD_UPDATE_SUCCESS = "0";
  /** パスワード照合関数処理結果：失敗(1) */
  public static final String USER_PASSWORD_COLLATION_ERROR = "1";
  /** パスワード照合関数処理結果：失敗その他(9) */
  public static final String USER_PASSWORD_COLLATION_OTHER_ERROR = "9";

  /** 1日(ミリ秒) java上での日付比較用 */
  public static final long ONE_DAY_MILLI_SECONDS = 24 * 60 * 60 * 1000;

  /** セッションキー：ユーザ情報 */
  public static final String SESSION_KEY_USER_INFO = "uvo";

  /** メッセージへのバインド用文言：登録 */
  public static final String BIND_PARAM_WORD_ADD = "登録";
  /** メッセージへのバインド用文言：更新 */
  public static final String BIND_PARAM_WORD_UPDATE = "更新";
  /** メッセージへのバインド用文言：登録・更新 */
  public static final String BIND_PARAM_WORD_ADD_AND_UPDATE = "登録・更新";
  /** メッセージへのバインド用文言：削除 */
  public static final String BIND_PARAM_WORD_DELTE = "削除";
  /** メッセージへのバインド用文言：補正 */
  public static final String BIND_PARAM_WORD_CORRECT = "補正";
  /** メッセージへのバインド用文言：承認 */
  public static final String BIND_PARAM_WORD_APPROVE = "承認";
  /** メッセージへのバインド用文言：削除登録 */
  public static final String BIND_PARAM_WORD_DELETE_REGIST = "削除登録";
  /** メッセージへのバインド用文言：否認 */
  public static final String BIND_PARAM_WORD_DENIAL = "否認";
  /** メッセージへのバインド用文言：ZIPファイル取得 */
  public static final String BIND_WORD_ZIPFILE = "ZIPファイル取得";
  /** メッセージへのバインド用文言：確定 */
  public static final String BIND_PARAM_WORD_FIX = "確定";
  /** メッセージへのバインド用文言：一括登録 */
  public static final String BIND_PARAM_WORD_LUMP = "一括登録";

  /** 取消フラグ */
  public static final String CANCEL_FLAG_CODE_CANCEL = "1";
  public static final String CANCEL_FLAG_CODE_NOT_CANCEL = "0";

  /** 供給停止区分 */
  public static final String SUPPLY_STOP_CATEGORY_CODE_CANCEL = "1";
  public static final String SUPPLY_STOP_CATEGORY_CODE_NOT_CANCEL = "0";

  /** ラジオボタンキー：すべて */
  public static final String RADIO_BUTTON_ALL_KEY = "";
  /** ラジオボタン値：すべて */
  public static final String RADIO_BUTTON_ALL_VALUE = "すべて";

  /** セレクトボックスキー：すべて */
  public static final String SELECT_BOX_ALL_KEY = "すべて";

  // 料金計算結果訂正・承認画面用
  /** 画面制御区分：補正 */
  public static final char DISPLAY_MODE_CORRECT = 'C';
  /** 画面制御区分：訂正承認 */
  public static final char DISPLAY_MODE_APPROVE_CORRECT = 'A';
  /** 画面制御区分：削除承認 */
  public static final char DISPLAY_MODE_APPROVE_DELETE = 'D';
  /** 画面制御区分：閲覧 */
  public static final char DISPLAY_MODE_SHOW = 'S';

  // 料金計算結果確定画面用
  /** 料金確定状況未確定詳細コード：確定待ち */
  public static final Integer UNDECIDEC_DETAIL_CODE_FIX_WAIT = 0;
  /** 料金確定状況未確定詳細コード：未取込使用量有 */
  public static final Integer UNDECIDEC_DETAIL_CODE_EXISTS_UN_IMPORT = 1;
  /** 料金確定状況未確定詳細コード：未補正エラーデータ有 */
  public static final Integer UNDECIDEC_DETAIL_CODE_EXISTS_UN_CORRECT_ERROR = 2;
  /** 料金確定状況未確定詳細コード：未承認補正データ有 */
  public static final Integer UNDECIDEC_DETAIL_CODE_EXISTS_UN_APPROVED_DATA = 3;

  /** 日付フォーマット：yyyyMM */
  public static final String FORMAT_DATE_YYYYMM = "yyyyMM";
  /** 日付フォーマット：yyyyMMdd */
  public static final String FORMAT_DATE_yyyyMMdd = "yyyyMMdd";
  /** 日付フォーマット：yyyy/MM */
  public static final String FORMAT_DATE_yyyyMM_SLASH = "yyyy/MM";
  /** 日付フォーマット：yyyy/MM/dd */
  public static final String FORMAT_DATE_yyyyMMdd_SLASH = "yyyy/MM/dd";
  /** 日時フォーマット：yyyyMMdd hh:mm */
  public static final String FORMAT_DATE_yyyyMMdd_HHmm = "yyyyMMdd HH:mm";
  /** 日時フォーマット(ファイル名用)：yyyyMMdd_hhmmss */
  public static final String FORMAT_DATE_yyyyMMdd_underline_HHmmss = "yyyyMMdd_HHmmss";
  /** 日時フォーマット（料金情報ダウンロードワークディレクトリ用）：yyyyMMddHHmmss */
  public static final String FORMAT_DATE_yyyyMMddHHmmss = "yyyyMMddHHmmss";
  /** 日時フォーマット：yyyyMMddHHmmssSSS */
  public static final String FORMAT_DATE_yyyyMMddHHmmssSSS = "yyyyMMddHHmmssSSS";
  /** 日時フォーマット：yyyy/MM/dd HH:mm:ss.SSS */
  public static final String FORMAT_DATE_yyyyMMddHHmmssSSS_OutputFormat = "yyyy/MM/dd HH:mm:ss.SSS";
  /** 日時フォーマット：HHmmss */
  public static final String FORMAT_DATE_HHmmss = "HHmmss";
  /** 正規表現:：電話番号 */
  public static final String FORMAT_PHONE_NO = "^\\d{2,4}-\\d{2,4}-\\d{4}$";
  /** 正規表現:：メールアドレス */
  public static final String FORMAT_EMAIL = "(?:[-!#-'*+/-9=?A-Z^-~]+(?:\\.[-!#-'*+/-9=?A-Z^-~]+)*|\"(?:[!#-\\[\\]-~]|\\\\[\\x09 -~])*\")@[-!#-'*+/-9=?A-Z^-~]+(?:\\.[-!#-'*+/-9=?A-Z^-~]+)*";
  /** 正規表現:：郵便番号 */
  public static final String FORMAT_POSTAL_CODE = "^\\d{7}$";
  /** 正規表現:：登録・更新区分 */
  public static final String FORMAT_INSERT_UPDATE_CATEGORY = "^([I]|[U])$";
  /** 正規表現:：全銀フォーマット */
  public static final String FORMAT_ZENGIN = "^([0-9A-Zｦｱ-ﾝﾞﾟ\\\\｢｣,\\.\\(\\)/ -]*)$";
  /** 正規表現:：インターホンメーカ番号 */
  public static final String FORMAT_INTERCOM_MAKER_MAKER_NO = "^[0][0][1-3]$";
  /** 正規表現:：検針日 */
  public static final String FORMAT_METER_READING_DATE = "^([0][1-9]|[1-2][0-9]|[3][0-1])$";
  /** 正規表現:：IPアドレス */
  public static final String FORMAT_IP_ADDRESS = "^([0-9]|[1]?\\d\\d|2[0-4]\\d|25[0-5])\\.([0-9]|[1]?\\d\\d|2[0-4]\\d|25[0-5])\\.([0-9]|[1]?\\d\\d|2[0-4]\\d|25[0-5])\\.([0-9]|[1]?\\d\\d|2[0-4]\\d|25[0-5])$";
  /** 正規表現:：MACアドレス */
  public static final String FORMAT_MAC_ADDRESS = "^([0-9A-Fa-f]{2}[-]){5}[0-9A-Fa-f]{2}$";
  /** 正規表現:：英数字記号 */
  public static final String FORMAT_ALPHA_NUMERIC_SYMBOL = "^[a-zA-Z0-9 -/:-@\\[-\\`\\{-\\~]+$";
  /** 正規表現:：英数字+ハイフン */
  public static final String FORMAT_ALPHA_NUMERIC_PLUS_HYPHEN = "^[a-zA-Z0-9\\-]+$";
  /** 正規表現:：百分率 */
  public static final String FORMAT_PERCENT = "^\\d{1,3}\\.\\d$";
  /** 正規表現:：契約容量 */
  public static final String FORMAT_CONTRACT_CAPACITY = "^[0-9]{1,3}\\.[0-9]{1}$";

  /** B0101-03バリデーション用ファイル項目名 */
  public static final String BATCH_B0101_03_DATA_RECORD = "データレコード";
  public static final String BATCH_B0101_03_ITEM_BILLING_ID = "請求先ID";
  public static final String BATCH_B0101_03_ITEM_BILLING_MONTH = "請求月";
  public static final String BATCH_B0101_03_ITEM_RECEIPT_WAY = "収納方法";
  public static final String BATCH_B0101_03_ITEM_RECEIPT_RESULT = "収納結果";
  public static final String BATCH_B0101_03_ITEM_RECEIPT_DATE = "収納年月日";
  public static final String BATCH_B0101_03_ITEM_TOTAL_RECEIPT_AMOUNT = "総収納金額";
  public static final String BATCH_B0101_03_ITEM_RECEIPT_AMOUNT = "収納金額";
  public static final String BATCH_B0101_03_ITEM_UNPAID_RECEIPT_AMOUNT = "不足金額";

  /*
   * コードチェック定義
   * コード定義のチェック用配列を宣言する
   */
  /** コードチェック：：支払方法区分 */
  public static final String[] CODE_PAYMENT_WAY_CATEGORY = {
      PAYMENT_WAY_CATEGORY_CONVENI,
      PAYMENT_WAY_CATEGORY_ACCOUNT,
      PAYMENT_WAY_CATEGORY_CREDIT
  };
  /** コードチェック：：個人・法人区分 */
  public static final String[] CODE_PERSONAL_CORPORATION_CATEGORY = {
      PERSONAL_CORPORATION_CATEGORY_PERSONAL,
      PERSONAL_CORPORATION_CATEGORY_CORPORATION
  };
  /** コードチェック：：請求書発送止め区分 */
  public static final String[] CODE_BILLING_SEND_STOP_CATEGORY = {
      BILLING_SEND_STOP_CATEGORY_NORMAL,
      BILLING_SEND_STOP_CATEGORY_STOP,
      BILLING_SEND_STOP_CATEGORY_NONE
  };
  /** コードチェック：：口座種別 */
  public static final String[] CODE_ACCOUNT_CLASS = {
      ACCOUNT_CLASS_NORMAL,
      ACCOUNT_CLASS_CURRENT
  };
  /** コードチェック：：部屋種別 */
  public static final String[] CODE_ROOM_CLASS = {
      ROOM_CLASS_EXCLUSIVE,
      ROOM_CLASS_COMMON,
      ROOM_CLASS_OFFICE
  };
  /** コードチェック：：供給停止区分 */
  public static final String[] CODE_SUPPLY_STOP_CATEGORY = {
      SUPPLY_STOP_CATEGORY_CODE_NOT_CANCEL,
      SUPPLY_STOP_CATEGORY_CODE_CANCEL
  };
  /** コードチェック：：電話番号区分 */
  public static final String[] CODE_PHONE_NO_CATEGORY = {
      PHONE_NO_CATEGORY_FIX,
      PHONE_NO_CATEGORY_MOBILE
  };
  /** コードチェック：：取消フラグ */
  public static final String[] CODE_CANCEL_FLAG = {
      CANCEL_FLAG_CODE_NOT_CANCEL,
      CANCEL_FLAG_CODE_CANCEL
  };
  /** コードチェック：：登録・更新区分 */
  public static final String[] CODE_INPUT_PROCESS_CATEGORY = {
      MEMS_PROCESS_CATEGORY_INSERT,
      MEMS_PROCESS_CATEGORY_UPDATE
  };
  /** コードチェック：：請求対象区分 */
  public static final String[] CODE_BILLING_TARGET_CATEGORY = {
      BILLING_TARGET_CATEGORY_YES,
      BILLING_TARGET_CATEGORY_NOT
  };

  /** B0101-03バリデーション用コードリスト */
  /** 収納方法コードバリデーションリスト */
  public static final String BATCH_B0101_03_RECEIPT_WAY_CODE_VALIDATE_LIST[] = {
      RECEIPT_WAY_CODE_CREDIT,
      RECEIPT_WAY_CODE_ACCOUNT,
      RECEIPT_WAY_CODE_CONVENI,
      RECEIPT_WAY_CODE_COMP_TRANSFER,
      RECEIPT_WAY_CODE_REGISTERED_MAIL,
      RECEIPT_WAY_CODE_VISIT_COLLECTION,
      RECEIPT_WAY_CODE_WINDOW_PAYMENT,
      RECEIPT_WAY_CODE_COMPENSATION_PAYMENT,
      RECEIPT_WAY_CODE_CHECK,
      RECEIPT_WAY_CODE_OFFICE_SYNTHESIS_TRANSFER,
      RECEIPT_WAY_CODE_OFFICE_REGISTERED_MAIL,
      RECEIPT_WAY_CODE_OFFICE_VISIT_COLLECTION,
      RECEIPT_WAY_CODE_OFFICE_WINDOW_PAYMENT,
      RECEIPT_WAY_CODE_TRANSFER_COMMISSION,
      RECEIPT_WAY_CODE_LIQUIDATION_ADJUST_MONEY,
      RECEIPT_WAY_CODE_SERVICER,
      RECEIPT_WAY_CODE_REPURCHASE
  };
  /** 収納結果コード */
  public static final String BATCH_B0101_03_RECEIPT_RESULT_CODE_VALIDATE_LIST[] = {
      RECEIPT_RESULT_CODE_SUCCESS,
      RECEIPT_RESULT_CODE_MISSING_FUND,
      RECEIPT_RESULT_CODE_NO_EXCHANGE,
      RECEIPT_RESULT_CODE_STOP_TRANSFER_DEPOSITOR,
      RECEIPT_RESULT_CODE_NO_ACCOUNT_TRANSFER_REQUEST,
      RECEIPT_RESULT_NAME_INVALID,
      RECEIPT_RESULT_CODE_STOP_TRANSFER_CLIENT,
      RECEIPT_RESULT_CODE_OTHER,
      RECEIPT_RESULT_CODE_ERROR,
      RECEIPT_RESULT_CODE_POINT,
      RECEIPT_RESULT_CODE_TRANSFER_RESULT_NOT_ARRIVED,
      RECEIPT_RESULT_CODE_RECEIPT_DEFICIT,
      RECEIPT_RESULT_CODE_RECEIPT_CANCEL
  };
  /**
   * 請求反映対象収納結果コードリスト<br>
   * 成功、不足入金、ポイント、入金取消が対象
   */
  public static final String BATCH_B0101_03_RECEIPT_RESULT_CODE_LIST_BILLING_REFLECT_TARGET[] = {
      RECEIPT_RESULT_CODE_SUCCESS,
      RECEIPT_RESULT_CODE_RECEIPT_DEFICIT,
      RECEIPT_RESULT_CODE_POINT,
      RECEIPT_RESULT_CODE_RECEIPT_CANCEL
  };

  /** SM集約機器メーカ種別：：三菱SM */
  public static final String SM_INTEGRATE_DEVICE_MAKER_CLASS_MITSU = "MITSU";

  /** SM集約機器メーカ種別：：大崎電気SM */
  public static final String SM_INTEGRATE_DEVICE_MAKER_CLASS_OSAKI = "OSAKI";

  /** SM集約機器メーカ種別：：東光東芝SM */
  public static final String SM_INTEGRATE_DEVICE_MAKER_CLASS_TOKOU = "TOKOU";

  /** SM集約機器メーカ種別、一意チェック対象配列 */
  public static final String[] SM_INTEGRATE_DEVICE_MAKER_UNIQUE_TARGET = new String[] {
      SM_INTEGRATE_DEVICE_MAKER_CLASS_TOKOU
  };

  /**
   * モジュールコード定義
   */
  public static final String F0002_LOGINACTION = "F0002_LoginAction";
  public static final String F0100_CHANGEPASSWORDACTION = "F0100_ChangePasswordAction";
  public static final String F0100_TOPPAGEACTION = "F0100_TopPageAction";
  public static final String F0100_INQUIRYMANAGEMENTCONDITIONSACTION = "F0100_InquiryManagementConditionsAction";
  public static final String F0101_DOWNLOADCONTRACTBUILDINGINFOACTION = "F0101_DownloadContractBuildingInfoAction";
  public static final String F0101_INQUIRYBUILDINGINFOACTION = "F0101_InquiryBuildingInfoAction";
  public static final String F0101_INQUIRYCONTRACTINFOACTION = "F0101_InquiryContractInfoAction";
  public static final String F0101_INQUIRYCONTRACTORINFOACTION = "F0101_InquiryContractorInfoAction";
  public static final String F0101_SEARCHBUILDINGINFOACTION = "F0101_SearchBuildingInfoAction";
  public static final String F0101_SEARCHCONTRACTORINFOACTION = "F0101_SearchContractorInfoAction";
  public static final String F0101_UPLOADCONTRACTBUILDINGINFOACTION = "F0101_UploadContractBuildingInfoAction";
  public static final String F0102_CORRECTFEECALCACTION = "F0102_CorrectFeeCalcAction";
  public static final String F0102_DISCOUNTPRICESETUPACTION = "F0102_DiscountPriceSetupAction";
  public static final String F0102_DOWNLOADAMOUNTINFOACTION = "F0102_DownloadAmountInfoAction";
  public static final String F0102_FIXFEECALCACTION = "F0102_FixFeeCalcAction";
  public static final String F0102_REGISTINSPECTIONMETERINFOACTION = "F0102_RegistInspectionMeterInfoAction";
  public static final String F0102_SEARCHFEECALCACTION = "F0102_SearchFeeCalcAction";
  public static final String F0102_SETUPUNITPRICEACTION = "F0102_SetupUnitPriceAction";
  public static final String F0103_SEARCHBILLINGINFOACTION = "F0103_SearchBillingInfoAction";

  public static final String F0100_SYSTEMOPERATIONDATEBATCH = "F0100_SystemOperationDateBatch";
  public static final String F0100_FTPPUTBATCH = "F0100_FTPPutBatch";
  public static final String F0101_RECEIVERECEIPTRESULTBATCH = "F0101_ReceiveReceiptResultBatch";
  public static final String F0101_RECEIVEVALIDITYCHECKRESULTBATCH = "F0101_ReceiveValidityCheckResultBatch";
  public static final String F0101_SENDCUSTOMERINFOBATCH = "F0101_SendCustomerInfoBatch";
  public static final String F0101_AUTOCOOPERATEWITHENABILITYBATCH = "F0101_AutoCooperateWithEnabilityBatch";
  public static final String F0102_CREATEBILLINGDATABATCH = "F0102_CreateBillingDataBatch";
  public static final String F0102_POWCONSUMPTIONCALCRESULTIMPORTBATCH = "F0102_PowConsumptionCalcResultImportBatch";
  public static final String F0102_SENDASSIGNMENTOFCLAIMREQINFOBATCH = "F0101_SendAssignmentOfClaimReqInfoBatch";
  public static final String F0103_UPDATEACCOUNTINGSTATUSBATCH = "F0103_UpdateAccountingStatusBatch";
  public static final String F0101_CONTRACTEXISTCHECKBATCH = "F0101_ContractExistCheckBatch";

  /**
   * 参照ユーザ権限チェック用<br>
   * Action単位で実行可能な機能を配列で定義する
   */
  public static final String[] AUTH_USER_SUCCESS_FUNCTIONS = new String[] {
      F0100_TOPPAGEACTION,
      F0101_SEARCHCONTRACTORINFOACTION,
      F0101_INQUIRYCONTRACTINFOACTION,
      F0101_INQUIRYCONTRACTORINFOACTION,
      F0101_SEARCHBUILDINGINFOACTION,
      F0101_INQUIRYBUILDINGINFOACTION,
      F0102_SEARCHFEECALCACTION,
      F0103_SEARCHBILLINGINFOACTION
  };

  /** スラッシュ */
  public static final String SLASH = "/";
  /** コンマ */
  public static final String COMMA = ",";
  /** マイナス */
  public static final String MINUS = "-";
  /** ファイル拡張子：.txt */
  public static final String FILE_EXTENSION_TXT = ".txt";
  /** ファイル拡張子：.csv */
  public static final String FILE_EXTENSION_CSV = ".csv";
  /** ファイル拡張子：.zip */
  public static final String FILE_EXTENSION_ZIP = ".zip";
  /** ファイル拡張子：.json */
  public static final String FILE_EXTENSION_JSON = ".json";
  /** ファイル拡張子：.lock */
  public static final String FILE_EXTENSION_LOCK = ".lock";
  /** ファイル拡張子：.tmp */
  public static final String FILE_EXTENSION_TEMP = ".tmp";
  /** ファイル拡張子：.err */
  public static final String FILE_EXTENSION_ERROR = ".err";
  /** コンテントタイプ：ファイルダウンロード */
  public static final String CONTENT_TYPE_FILE_DOWNLOAD = "application/octet-stream";
  /** コンテントディスポジション：ファイルダウンロード時にダイアログに表示するファイル名 */
  public static final String CONTENT_DISPOSITION_FILE_DOWNLOAD = "attachment;filename=";
  /** ダブルクォート */
  public static final char DOUBLE_QUOTE = '"';
  /** HTML改行コード */
  public static final String HTML_BR = "<BR>";

  /**
   * ajax用定数定義
   */
  /** ソート順:asc */
  public static final String VIEW_SORT_ASC = "asc";
  /** ソート順：desc */
  public static final String VIEW_SORT_DESC = "desc";
  /** カラム名：０ */
  public static final String COLUMN_NO_0 = "0";
  /** カラム名：１ */
  public static final String COLUMN_NO_1 = "1";
  /** カラム名：２ */
  public static final String COLUMN_NO_2 = "2";
  /** カラム名：３ */
  public static final String COLUMN_NO_3 = "3";
  /** カラム名：４ */
  public static final String COLUMN_NO_4 = "4";
  /** カラム名：５ */
  public static final String COLUMN_NO_5 = "5";
  /** カラム名：６ */
  public static final String COLUMN_NO_6 = "6";
  /** カラム名：７ */
  public static final String COLUMN_NO_7 = "7";
  /** カラム名：８ */
  public static final String COLUMN_NO_8 = "8";
  /** カラム名：９ */
  public static final String COLUMN_NO_9 = "9";
  /** カラム名：１０ */
  public static final String COLUMN_NO_10 = "10";
  /** カラム名：１１ */
  public static final String COLUMN_NO_11 = "11";
  /** カラム名：１２ */
  public static final String COLUMN_NO_12 = "12";
  /** カラム名：行番号 */
  public static final String COLUMN_NAME_ROWID = "rowid";
  /** AJAX実行フラグ：ON */
  public static final String AJAXFLG_ON = "1";
  /** AJAX実行フラグ：OFF */
  public static final String AJAXFLG_OFF = "0";
  /** AJAXリクエストパラメータ：開始インデックス */
  public static final String AJAX_IDISPLAY_START = "iDisplayStart";
  /** AJAXリクエストパラメータ：エコー番号 */
  public static final String AJAX_SECHO = "sEcho";
  /** AJAXリクエストパラメータ：1ページの表示件数 */
  public static final String AJAX_IDISPLAY_LENGTH = "iDisplayLength";
  /** AJAXリクエストパラメータ：カラム名（番号） */
  public static final String AJAX_ISORTCOL_0 = "iSortCol_0";
  /** AJAXリクエストパラメータ：ソート順 */
  public static final String AJAX_SSORTDIR_0 = "sSortDir_0";

  /*
   * 画面ID定義 START
   */
  /** ログ出力に使用する画面IDマップ */
  private static Map<String, String> screenIdMap;

  /** 画面ID：パスワード変更 */
  public static final String SCREEN_ID_LOGIN = "S0001-01";
  /** 画面ID：パスワード変更 */
  public static final String SCREEN_ID_CHANGE_PASSWORD = "S0004-01";
  /** 画面ID：処理状況照会 */
  public static final String SCREEN_ID_INQUIRY_MANAGEMENT_CONDITIONS = "S0006-01";
  /** 画面ID：契約・物件情報登録・更新 */
  public static final String SCREEN_ID_UPLOAD_CONTRACT_BUILDING_INFO = "S0101-01";
  /** 画面ID：顧客・契約情報検索・一覧 */
  public static final String SCREEN_ID_SEARCH_CONTORS_CALC = "S0101-02";
  /** 画面ID：顧客情報照会 */
  public static final String SCREEN_ID_INQUIRY_CONTRACTOR_INFO = "S0101-03";
  /** 画面ID：契約情報照会 */
  public static final String SCREEN_ID_INQUIRY_CONTRACT_INFO = "S0101-04";
  /** 画面ID：建物情報検索・一覧 */
  public static final String SCREEN_ID_SEARCH_BUILDING_INFO = "S0101-05";
  /** 画面ID：建物情報照会 */
  public static final String SCREEN_ID_INQUIRY_BUILDING_INFO = "S0101-06";
  /** 画面ID：建物・契約情報ダウンロード */
  public static final String SCREEN_ID_DOWNLOAD_CONTRACT_BUILDING_INFO = "S0101-07";
  /** 画面ID：料金単価設定 */
  public static final String SCREEN_ID_SETUP_UNIT_PRICE = "S0102-01";
  /** 画面ID：検針情報登録 */
  public static final String SCREEN_ID_REGIST_INSPECTION_METER_INFO = "S0102-02";
  /** 画面ID：料金計算結果検索・一覧 */
  public static final String SCREEN_ID_SEARCH_FEE_CALC = "S0102-03";
  /** 画面ID：料金計算結果訂正・承認 */
  public static final String SCREEN_ID_CORRECT_FEE_CALC = "S0102-04";
  /** 画面ID：料金計算結果確定 */
  public static final String SCREEN_ID_FIX_FEE_CALC = "S0102-05";
  /** 画面ID：料金情報ダウンロード */
  public static final String SCREEN_ID_DOWNLOAD_AMOUNT_INFO = "S0102-06";
  /** 画面ID：割引単価設定 */
  public static final String SCREEN_ID_DISCOUNT_UNIT_PRICE_CALC = "S0102-07";
  /** 画面ID：請求情報検索・一覧 */
  public static final String SCREEN_ID_SEARCH_BILLING_INFO = "S0103-01";

  /*
   * 画面ID定義 END
   */

  /*
   * 検索条件セッションキー定義 START
   * ヘッダー + 画面IDで定義する
   */
  /** 検索条件キーの共通ヘッダー */
  private static final String SEARCH_CONDITION_HEADER = "condition_";

  /** 料金計算結果検索・一覧 */
  public static final String SEARCH_CONDITION_SEARCH_FEE_CALC = SEARCH_CONDITION_HEADER.concat(SCREEN_ID_SEARCH_FEE_CALC);
  /** 料金計算結果訂正・承認 */
  public static final String SEARCH_CONDITION_CORRECT_FEE_CALC = SEARCH_CONDITION_HEADER.concat(SCREEN_ID_CORRECT_FEE_CALC);
  /** 料金計算結果確定 */
  public static final String SEARCH_CONDITION_FIX_FEE_CALC = SEARCH_CONDITION_HEADER.concat(SCREEN_ID_FIX_FEE_CALC);

  /** 顧客・契約情報検索・一覧 */
  public static final String SEARCH_CONDITION_SEARCH_CONTORS_CALC = SEARCH_CONDITION_HEADER.concat(SCREEN_ID_SEARCH_CONTORS_CALC);
  /** 顧客情報照会 */
  public static final String SEARCH_CONDITION_INQUIRY_CONTRACTOR_INFO = SEARCH_CONDITION_HEADER.concat(SCREEN_ID_INQUIRY_CONTRACTOR_INFO);

  /** 物件情報検索・一覧 */
  public static final String SEARCH_CONDITION_SERCH_BUILDING_INFO = SEARCH_CONDITION_HEADER.concat(SCREEN_ID_SEARCH_BUILDING_INFO);
  /** 物件情報照会 */
  public static final String SEARCH_CONDITION_INQUIRY_BUILDING_INFO = SEARCH_CONDITION_HEADER.concat(SCREEN_ID_INQUIRY_BUILDING_INFO);

  /** 請求情報検索・一覧 */
  public static final String SEARCH_CONDITION_SEARCH_BILLING_INFO = SEARCH_CONDITION_HEADER.concat(SCREEN_ID_SEARCH_BILLING_INFO);
  /** 経理帳票ダウンロード */
  public static final String SEARCH_CONDITION_DOWNLOAD_ACCOUNTING_REPORT = SEARCH_CONDITION_HEADER.concat(ScreenId.DOWNLOAD_ACCOUNTING_REPORT.encode());

  /** 処理状況照会 */
  public static final String SEARCH_CONDITION_INQUIRY_MANAGEMENT_CONDITIONS = SEARCH_CONDITION_HEADER.concat(SCREEN_ID_INQUIRY_MANAGEMENT_CONDITIONS);

  /*
   * 検索条件セッションキー定義 END
   */

  /*
   * 画面遷移セッションキー定義 START
   * ヘッダー＋画面IDで定義する
   */
  /** 画面遷移キーの共通ヘッダー */
  private static final String TRANSFER_KEY_HEADER = "transfer_";

  /** 画面遷移セッションキー：料金計算結果検索・一覧⇒訂正・承認 */
  public static final String TRANSFER_KEY_FEE_CALC = TRANSFER_KEY_HEADER.concat(SCREEN_ID_SEARCH_FEE_CALC);

  /** 画面遷移セッションキー：顧客・契約情報検索・一覧⇒顧客情報照会 */
  public static final String TRANSFER_KEY_CONTORS_CALC = TRANSFER_KEY_HEADER.concat(SCREEN_ID_SEARCH_CONTORS_CALC);
  /** 画面セッションキー：建物情報検索・一覧⇒建物情報照会 */
  public static final String TRANSFER_KEY_BUILDING_INFO = TRANSFER_KEY_HEADER.concat(SCREEN_ID_SEARCH_BUILDING_INFO);

  /** 画面セッションキー：顧客情報照会⇒契約情報照会 */
  public static final String TRANSFER_KEY_CONTRACT_INFO = TRANSFER_KEY_HEADER.concat(SCREEN_ID_INQUIRY_CONTRACTOR_INFO);
  /*
   * 画面遷移セッションキー定義 END
   */

  /*
   * 遷移元セッションキー定義 START
   * 遷移元キー＋画面遷移セッションキー＋画面IDで定義する
   */
  /** 遷移元キーの共通ヘッダー */
  private static final String BEFORE_TRANSFER_KEY_HEADER = "before_";

  /** 遷移元セッションキー：顧客情報照会 */
  public static final String BEFORE_TRANSFER_KEY_INQUIRY_CONTRACTOR_INFO = BEFORE_TRANSFER_KEY_HEADER.concat(TRANSFER_KEY_HEADER)
      .concat(SCREEN_ID_INQUIRY_CONTRACTOR_INFO);
  /*
   * 遷移元セッションキー定義 END
   */

  /** 顧客情報照会遷移元フラグ：顧客・契約情報検索・一覧 */
  public static final String INQUIRY_CONTRACTOR_INFO_BEFORE_SCREEN_SEARCH_CONTRACTOR = "0";
  /** 顧客情報照会遷移元フラグ：請求情報検索・一覧 */
  public static final String INQUIRY_CONTRACTOR_INFO_BEFORE_SCREEN_SEARCH_BILLING = "1";

  /** 契約情報照会遷移元フラグ：顧客・契約情報検索・一覧 */
  public static final String INQUIRY_CONTRACT_INFO_BEFORE_SCREEN_SEARCH_CONTRACTOR = "0";
  /** 契約情報照会遷移元フラグ：顧客情報照会 */
  public static final String INQUIRY_CONTRACT_INFO_BEFORE_SCREEN_INQUIRY_CONTRACTOR = "1";

  /** ・契約・物件情報ダウンロード：ファイル種別 */
  private static Map<String, String> kindOfFileMap;
  /** 契約・物件情報ダウンロード：ファイル種別キー：契約者情報 */
  public static final String FILE_CATEGORY_CONTRACTOR_INFO = "0";
  /** 契約・物件情報ダウンロード：ファイル種別キー：支払情報 */
  public static final String FILE_CATEGORY_PAY_INFO = "1";
  /** 契約・物件情報ダウンロード：ファイル種別キー：契約情報j */
  public static final String FILE_CATEGORY_CONTRACT_INFO = "2";
  /** 契約・物件情報ダウンロード：ファイル種別キー：割引契約情報 */
  public static final String FILE_CATEGORY_DISCOUNT_CONTRACT_INFO = "3";
  /** 契約・物件情報ダウンロード：ファイル種別キー：メータ設置場所情報 */
  public static final String FILE_CATEGORY_METER_INFO = "4";
  /** 契約・物件情報ダウンロード：ファイル種別キー：物件情報 */
  public static final String FILE_CATEGORY_BUILDING_INFO = "5";
  /** 契約・物件情報ダウンロード：ファイル種別キー：棟情報 */
  public static final String FILE_CATEGORY_RIDGE_INFO = "6";
  /** 契約・物件情報ダウンロード：ファイル種別キー：上記を結合したファイル */
  public static final String FILE_CATEGORY_ALL_JOIN = "7";
  /** 契約・物件情報ダウンロード：ファイル種別キー：基本情報-Enability連携用 */
  public static final String FILE_CATEGORY_COOPERATION_ENABILITY = "8";

  /** 契約・物件情報ダウンロード：基本情報-Enability連携用バージョン情報 */
  public static final String FILE_VERSION_COOPERATION_ENABILITY = "01";

  /** 契約・物件情報ダウンロード：時間リスト */
  private static Map<String, String> hourMap;
  /** 契約・物件情報ダウンロード：分リスト */
  private static Map<String, String> minuteMap;

  /** 請求データ作成バッチ：支払基準日(ベースの30日) */
  public static final String PAYMENT_RECORD_DATE = "30";

  /** ThreadContext格納用キー： クラス名 */
  public static final String CLASS_NAME_KEY = "classname";
  /** ThreadContext格納用キー：ユーザーID */
  public static final String USER_ID_KEY = "userid";
  /** ThreadContext格納用キー：セッションID */
  public static final String SESSION_ID_KEY = "sessionid";
  /** ThreadContext格納用キー：オンラインフラグ */
  public static final String ONLINE_FLAG_KEY = "onlineflag";
  /** オンラインフラグ：オンライン */
  public static final String ONLINE_FLAG_ONLINE = "0";
  /** オンラインフラグ：非オンライン */
  public static final String ONLINE_FLAG_NOTONLINE = "1";

  /** APIリクエスト項目タグ：ユーザID */
  public static final String REQ_USERID_TAG = "userId";

  /** SOAPリクエスト・レスポンス出力先パス */
  public static final String API_XML_PATH = "/root/work/";

  /** 処理基準日コード：オンライン処理基準日 */
  public static final String EXEC_BASE_DATE_ONLINE = "0";
  /** 処理基準日コード：バッチ処理基準日 */
  public static final String EXEC_BASE_DATE_BATCH = "1";
  /** 処理基準日コード：全て */
  public static final String EXEC_BASE_DATE_ALL = "99";

  /** ユーザID：システム */
  public static final String USER_ID_SYSTEM = "SYSTEM";

  /**
   * staticイニシャライザ<br>
   * ログ出力に使用する、Action・Serviceクラス名と画面IDのMapを定義する<br>
   * キー：Serviceクラス名(Impl) 値 ：画面ID 本クラス内に定数で定義する
   */
  static {
    screenIdMap = new HashMap<String, String>();

    // ログイン S0001-01
    screenIdMap.put(F0002_LOGINACTION, SCREEN_ID_LOGIN);
    screenIdMap.put("F0002_UserServiceImpl", SCREEN_ID_LOGIN);
    // パスワード変更 S0004-01
    screenIdMap.put(F0100_CHANGEPASSWORDACTION, SCREEN_ID_CHANGE_PASSWORD);
    screenIdMap.put("F0100_ChangePasswordServiceImpl", SCREEN_ID_CHANGE_PASSWORD);
    // 処理状況照会 S0006-01
    screenIdMap.put(F0100_INQUIRYMANAGEMENTCONDITIONSACTION, SCREEN_ID_INQUIRY_MANAGEMENT_CONDITIONS);
    screenIdMap.put("F0100_InquiryManagementConditionsServiceImpl", SCREEN_ID_INQUIRY_MANAGEMENT_CONDITIONS);
    // 契約・物件情報アップロード S0101-01
    screenIdMap.put(F0101_UPLOADCONTRACTBUILDINGINFOACTION, SCREEN_ID_UPLOAD_CONTRACT_BUILDING_INFO);
    screenIdMap.put("F0101_UploadContractBuildingInfoServiceImpl", SCREEN_ID_UPLOAD_CONTRACT_BUILDING_INFO);
    // 顧客・契約情報検索・一覧 S0101-02
    screenIdMap.put(F0101_SEARCHCONTRACTORINFOACTION, SCREEN_ID_SEARCH_CONTORS_CALC);
    screenIdMap.put("F0101_SearchContractorInfoServiceImpl", SCREEN_ID_SEARCH_CONTORS_CALC);
    // 顧客情報照会 S0101-03
    screenIdMap.put(F0101_INQUIRYCONTRACTORINFOACTION, SCREEN_ID_INQUIRY_CONTRACTOR_INFO);
    screenIdMap.put("F0101_InquiryContractorInfoServiceImpl", SCREEN_ID_INQUIRY_CONTRACTOR_INFO);
    // 契約情報照会 S0101-04
    screenIdMap.put(F0101_INQUIRYCONTRACTINFOACTION, SCREEN_ID_INQUIRY_CONTRACT_INFO);
    screenIdMap.put("F0101_InquiryContractInfoServiceImpl", SCREEN_ID_INQUIRY_CONTRACT_INFO);
    // 物件情報検索・一覧 S0101-05
    screenIdMap.put(F0101_SEARCHBUILDINGINFOACTION, SCREEN_ID_SEARCH_BUILDING_INFO);
    screenIdMap.put("F0101_SearchBuildingInfoServiceImpl", SCREEN_ID_SEARCH_BUILDING_INFO);
    // 物件情報照会 S0101-06
    screenIdMap.put(F0101_INQUIRYBUILDINGINFOACTION, SCREEN_ID_INQUIRY_BUILDING_INFO);
    screenIdMap.put("F0101_InquiryBuildingInfoServiceImpl", SCREEN_ID_INQUIRY_BUILDING_INFO);
    // 契約・物件情報ダウンロード S0101-07
    screenIdMap.put(F0101_DOWNLOADCONTRACTBUILDINGINFOACTION, SCREEN_ID_DOWNLOAD_CONTRACT_BUILDING_INFO);
    screenIdMap.put("F0101_DownloadContractBuildingInfoServiceImpl", SCREEN_ID_DOWNLOAD_CONTRACT_BUILDING_INFO);

    // 料金単価設定 S0102-01
    screenIdMap.put(F0102_SETUPUNITPRICEACTION, SCREEN_ID_SETUP_UNIT_PRICE);
    screenIdMap.put("F0102_SetupUnitPriceServiceImpl", SCREEN_ID_SETUP_UNIT_PRICE);
    // 検針情報アップロード S0102-02
    screenIdMap.put(F0102_REGISTINSPECTIONMETERINFOACTION, SCREEN_ID_REGIST_INSPECTION_METER_INFO);
    screenIdMap.put("F0102_RegistInspectionMeterInfoServiceImpl", SCREEN_ID_REGIST_INSPECTION_METER_INFO);
    // 料金計算結果検索・一覧 S0102-03
    screenIdMap.put(F0102_SEARCHFEECALCACTION, SCREEN_ID_SEARCH_FEE_CALC);
    screenIdMap.put("F0102_SearchFeeCalcServiceImpl", SCREEN_ID_SEARCH_FEE_CALC);
    // 料金計算結果補正・承認 S0102-04
    screenIdMap.put(F0102_CORRECTFEECALCACTION, SCREEN_ID_CORRECT_FEE_CALC);
    screenIdMap.put("F0102_CorrectFeeCalcServiceImpl", SCREEN_ID_CORRECT_FEE_CALC);
    // 料金計算結果確定 S0102-05
    screenIdMap.put(F0102_FIXFEECALCACTION, SCREEN_ID_FIX_FEE_CALC);
    screenIdMap.put("F0102_FixFeeCalcServiceImpl", SCREEN_ID_FIX_FEE_CALC);
    // 料金情報ダウンロード S0102-06
    screenIdMap.put(F0102_DOWNLOADAMOUNTINFOACTION, SCREEN_ID_DOWNLOAD_AMOUNT_INFO);
    screenIdMap.put("F0102_DownloadAmountInfoServiceImpl", SCREEN_ID_DOWNLOAD_AMOUNT_INFO);
    // 割引単価設定 S0102-07
    screenIdMap.put(F0102_DISCOUNTPRICESETUPACTION, SCREEN_ID_DISCOUNT_UNIT_PRICE_CALC);
    screenIdMap.put("F0102_DiscountPriceSetupServiceImpl", SCREEN_ID_DISCOUNT_UNIT_PRICE_CALC);

    // 請求情報検索・一覧 S0103-01
    screenIdMap.put(F0103_SEARCHBILLINGINFOACTION, SCREEN_ID_SEARCH_BILLING_INFO);
    screenIdMap.put("F0103_SearchBillingInfoServiceImpl", SCREEN_ID_SEARCH_BILLING_INFO);
    // 経理帳票ダウンロード S0103-02
    screenIdMap.put(ModuleCode.DOWNLOAD_ACCOUNTING_REPORT.getActionName(), ScreenId.DOWNLOAD_ACCOUNTING_REPORT.encode());
    screenIdMap.put(ModuleCode.DOWNLOAD_ACCOUNTING_REPORT.getServiceName(), ScreenId.DOWNLOAD_ACCOUNTING_REPORT.encode());

    // 契約・物件情報ダウンロード：ファイル種別マップ生成
    kindOfFileMap = new LinkedHashMap<String, String>();
    kindOfFileMap.put(FILE_CATEGORY_CONTRACTOR_INFO, "契約者情報");
    kindOfFileMap.put(FILE_CATEGORY_PAY_INFO, "支払情報");
    kindOfFileMap.put(FILE_CATEGORY_CONTRACT_INFO, "契約情報");
    kindOfFileMap.put(FILE_CATEGORY_DISCOUNT_CONTRACT_INFO, "割引契約情報");
    kindOfFileMap.put(FILE_CATEGORY_METER_INFO, "メータ設置場所情報");
    kindOfFileMap.put(FILE_CATEGORY_BUILDING_INFO, "物件情報");
    kindOfFileMap.put(FILE_CATEGORY_RIDGE_INFO, "棟情報");
    kindOfFileMap.put(FILE_CATEGORY_ALL_JOIN, "上記を結合したファイル");
    kindOfFileMap.put(FILE_CATEGORY_COOPERATION_ENABILITY, "基本情報-Enability連携用");

    // 契約・物件情報ダウンロード：時・分マップ生成
    hourMap = new LinkedHashMap<String, String>();
    minuteMap = new LinkedHashMap<String, String>();

    for (int hour = 0; hour <= 23; hour++) {
      String hourKeyValue = String.valueOf(hour);
      hourMap.put(hourKeyValue, hourKeyValue);
    }
    for (int minute = 0; minute <= 59; minute++) {
      String minuteKeyValue = String.valueOf(minute);
      minuteMap.put(minuteKeyValue, minuteKeyValue);
    }

  }

  /**
   * 画面IDマップのゲッター
   * 
   * @return
   */
  public static Map<String, String> getScreenIdMap() {
    return screenIdMap;
  }

  /**
   * kindOfFileMapのゲッター
   * 
   * @return kindOfFileMap
   */
  public static Map<String, String> getKindOfFileMap() {
    return kindOfFileMap;
  }

  /**
   * hourMapのゲッター
   * 
   * @return hourMap
   */
  public static Map<String, String> getHourMap() {
    return hourMap;
  }

  /**
   * minuteMapのゲッター
   * 
   * @return minuteMap
   */
  public static Map<String, String> getMinuteMap() {
    return minuteMap;
  }

}
