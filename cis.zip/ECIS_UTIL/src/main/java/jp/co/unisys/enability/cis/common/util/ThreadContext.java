/*
 * Copyright (C) 2006-2008, Nihon Unisys, Ltd. All rights reserved.
 */

package jp.co.unisys.enability.cis.common.util;

import java.util.HashMap;

/**
 * 各種情報を保持するスレッドコンテキストクラス.<br>
 * 内部には以下のスレッドローカルクラスがあり、情報をセットします.<br>
 * <ul>
 * <li>Sessionスコープのスレッドコンテキストを格納するThreadLocalクラス.
 * <li>Requestスコープのスレッドコンテキストを格納するThreadLocalクラス.
 * </ul>
 *
 * @author Nihon Unisys, Ltd.
 * @version $Date: 2008-10-22 14:58:37 +0900 (Wed, 22 Oct 2008) $ $Rev: 1949 $
 */
public class ThreadContext extends HashMap<String, Object> {

  /** シリアルID */
  static final long serialVersionUID = -318496599336520574L;

  /** SessionスコープのThreadContextを格納するThreadLocalクラス */
  private static ThreadLocal<ThreadContext> sessionThreadContext = new ThreadLocal<ThreadContext>();

  /** RequestスコープのThreadContextを格納するThreadLocalクラス */
  private static ThreadLocal<ThreadContext> requestThreadContext = new ThreadLocal<ThreadContext>();

  /**
   * 空コンテキストを返します．
   *
   * @return ThreadContext
   */
  public static ThreadContext getInstance() {
    return new ThreadContext();
  }

  /**
   * SessionスコープのThreadContextを返します.
   *
   * @return ThreadContext ThreadContextオブジェクト
   */
  public static ThreadContext getSessionThreadContext() {
    ThreadContext threadContext = sessionThreadContext.get();

    if (threadContext == null) {
      threadContext = new ThreadContext();
      setSessionThreadContext(threadContext);
    }

    return threadContext;
  }

  /**
   * SessionスコープのThreadContextをセットします.
   *
   * @param threadContext
   *          ThreadContextオブジェクト
   */
  public static void setSessionThreadContext(ThreadContext threadContext) {
    sessionThreadContext.set(threadContext);
  }

  /**
   * RequestスコープのThreadContextを返します.
   *
   * @return ThreadContextオブジェクト
   */
  public static ThreadContext getRequestThreadContext() {
    ThreadContext threadContext = requestThreadContext.get();

    if (threadContext == null) {
      threadContext = new ThreadContext();
      setRequestThreadContext(threadContext);
    }

    return threadContext;
  }

  /**
   * RequestスコープのThreadContextをセットします.
   *
   * @param threadContext
   *          ThreadContextオブジェクト
   */
  public static void setRequestThreadContext(ThreadContext threadContext) {
    requestThreadContext.set(threadContext);
  }

}
