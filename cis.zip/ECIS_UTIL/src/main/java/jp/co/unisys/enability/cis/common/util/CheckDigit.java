package jp.co.unisys.enability.cis.common.util;

import org.apache.commons.lang3.math.NumberUtils;

/**
 * チェックディジット計算共通クラス。
 *
 * <pre>
 * <p><b>【仕様詳細】<b><p>
 * 引数の情報を基にチェックディジットの計算を行う。
 * </pre>
 *
 *
 * @author "Nihon Unisys, Ltd."
 *
 */
public class CheckDigit {

  /** モジュラス10による計算でベースとなる数値 */
  private static final long BASEVALUE_FOR_MODULAS10 = 10;
  /** モジュラス10による計算で偶数桁の乗算に用いる数値 */
  private static final long PRODUCTVALUE_FOR_MODULAS10 = 3;

  /**
   * チェックディジット取得。
   *
   * <pre>
   * <p>
   * <b>【仕様詳細】</b>
   * </p>
   * １．入力値に対してチェックディジットの桁を含めて、最右桁を奇数とし、 偶数桁の数値の和を3倍したものと奇数桁の和の和を求める。 ２．１０から２で求めた和の1桁目を引く。ただし、引き算の結果が１０場合、次の計算で使用する値を０とする。
   * ３．入力値を１０倍した値と２で求めた値の和を戻り値として返却する。
   *
   * 以下の場合、戻り値が0で返却される。 ・引数がLongの最大値を超える数字の場合 ・引数が0の場合 また、先頭に0が含まれる場合、0はないものとして計算され、 戻り値にも含まれない。
   *
   * @param target
   *          数字
   * @return チェックディジット
   * @throws Exception
   *           引数に数字以外の文字列を渡した場合
   */
  public static String calcCheckDigitByModulas10Weight3(String target)
      throws Exception {

    long[] digit = new long[target.length()];

    // 引数が数字で構成されているかチェック
    if (!NumberUtils.isDigits(target)) {
      throw new NumberFormatException();
    }

    long targetNo = NumberUtils.toLong(target);

    // 奇数
    long odd = 0;
    // 偶数
    long even = 0;

    for (int i = 0; i < digit.length; i++) {
      boolean evenOrOdd = (i) % 2 == 0 ? true : false;
      digit[i] = targetNo % BASEVALUE_FOR_MODULAS10;
      targetNo /= BASEVALUE_FOR_MODULAS10;

      if (evenOrOdd) {
        even += Long.valueOf(digit[i]);
      } else {
        odd += Long.valueOf(digit[i]);
      }

    }

    // 偶数和×3と奇数和の合計
    long sum = even * PRODUCTVALUE_FOR_MODULAS10 + odd;
    // チェックディジットを求める
    long result = NumberUtils.toLong(target)
        * BASEVALUE_FOR_MODULAS10
        + (BASEVALUE_FOR_MODULAS10 - (sum % BASEVALUE_FOR_MODULAS10 == 0 ? BASEVALUE_FOR_MODULAS10
            : sum % BASEVALUE_FOR_MODULAS10));

    return String.valueOf(result);
  }
}
