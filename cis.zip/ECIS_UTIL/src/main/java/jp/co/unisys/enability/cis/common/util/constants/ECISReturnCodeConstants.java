package jp.co.unisys.enability.cis.common.util.constants;

/**
 * 定数クラス
 *
 * @author "Nihon Unisys, Ltd."
 */
public class ECISReturnCodeConstants {

  /** リターンコード：0000 */
  public static final String RETURN_CODE_0000 = "0000";
  /** リターンコード：P000 */
  public static final String RETURN_CODE_P000 = "P000";
  /** リターンコード：P001 */
  public static final String RETURN_CODE_P001 = "P001";
  /** リターンコード：P002 */
  public static final String RETURN_CODE_P002 = "P002";
  /** リターンコード：P003 */
  public static final String RETURN_CODE_P003 = "P003";
  /** リターンコード：P004 */
  public static final String RETURN_CODE_P004 = "P004";
  /** リターンコード：P005 */
  public static final String RETURN_CODE_P005 = "P005";
  /** リターンコード：P006 */
  public static final String RETURN_CODE_P006 = "P006";
  /** リターンコード：P007 */
  public static final String RETURN_CODE_P007 = "P007";
  /** リターンコード：P008 */
  public static final String RETURN_CODE_P008 = "P008";
  /** リターンコード：P009 */
  public static final String RETURN_CODE_P009 = "P009";
  /** リターンコード：P010 */
  public static final String RETURN_CODE_P010 = "P010";
  /** リターンコード：P011 */
  public static final String RETURN_CODE_P011 = "P011";
  /** リターンコード：P012 */
  public static final String RETURN_CODE_P012 = "P012";
  /** リターンコード：P013 */
  public static final String RETURN_CODE_P013 = "P013";
  /** リターンコード：P014 */
  public static final String RETURN_CODE_P014 = "P014";
  /** リターンコード：P015 */
  public static final String RETURN_CODE_P015 = "P015";
  /** リターンコード：P016 */
  public static final String RETURN_CODE_P016 = "P016";
  /** リターンコード：P017 */
  public static final String RETURN_CODE_P017 = "P017";
  /** リターンコード：P018 */
  public static final String RETURN_CODE_P018 = "P018";
  /** リターンコード：P019 */
  public static final String RETURN_CODE_P019 = "P019";
  /** リターンコード：P020 */
  public static final String RETURN_CODE_P020 = "P020";
  /** リターンコード：P021 */
  public static final String RETURN_CODE_P021 = "P021";
  /** リターンコード：P022 */
  public static final String RETURN_CODE_P022 = "P022";
  /** リターンコード：P023 */
  public static final String RETURN_CODE_P023 = "P023";
  /** リターンコード：P024 */
  public static final String RETURN_CODE_P024 = "P024";
  /** リターンコード：P025 */
  public static final String RETURN_CODE_P025 = "P025";
  /** リターンコード：P026 */
  public static final String RETURN_CODE_P026 = "P026";
  /** リターンコード：P027 */
  public static final String RETURN_CODE_P027 = "P027";
  /** リターンコード：P028 */
  public static final String RETURN_CODE_P028 = "P028";
  /** リターンコード：P029 */
  public static final String RETURN_CODE_P029 = "P029";
  /** リターンコード：P030 */
  public static final String RETURN_CODE_P030 = "P030";
  /** リターンコード：P031 */
  public static final String RETURN_CODE_P031 = "P031";
  /** リターンコード：P032 */
  public static final String RETURN_CODE_P032 = "P032";
  /** リターンコード：P033 */
  public static final String RETURN_CODE_P033 = "P033";
  /** リターンコード：P034 */
  public static final String RETURN_CODE_P034 = "P034";
  /** リターンコード：P035 */
  public static final String RETURN_CODE_P035 = "P035";
  /** リターンコード：P036 */
  public static final String RETURN_CODE_P036 = "P036";
  /** リターンコード：P037 */
  public static final String RETURN_CODE_P037 = "P037";
  /** リターンコード：P038 */
  public static final String RETURN_CODE_P038 = "P038";
  /** リターンコード：P039 */
  public static final String RETURN_CODE_P039 = "P039";
  /** リターンコード：P040 */
  public static final String RETURN_CODE_P040 = "P040";
  /** リターンコード：P041 */
  public static final String RETURN_CODE_P041 = "P041";
  /** リターンコード：P042 */
  public static final String RETURN_CODE_P042 = "P042";
  /** リターンコード：P043 */
  public static final String RETURN_CODE_P043 = "P043";
  /** リターンコード：P044 */
  public static final String RETURN_CODE_P044 = "P044";
  /** リターンコード：P049 */
  public static final String RETURN_CODE_P049 = "P049";
  /** リターンコード：P050 */
  public static final String RETURN_CODE_P050 = "P050";
  /** リターンコード：P051 */
  public static final String RETURN_CODE_P051 = "P051";
  /** リターンコード：P052 */
  public static final String RETURN_CODE_P052 = "P052";
  /** リターンコード：P053 */
  public static final String RETURN_CODE_P053 = "P053";
  /** リターンコード：P054 */
  public static final String RETURN_CODE_P054 = "P054";
  /** リターンコード：P055 */
  public static final String RETURN_CODE_P055 = "P055";
  /** リターンコード：P056 */
  public static final String RETURN_CODE_P056 = "P056";
  /** リターンコード：P057 */
  public static final String RETURN_CODE_P057 = "P057";
  /** リターンコード：P058 */
  public static final String RETURN_CODE_P058 = "P058";
  /** リターンコード：P061 */
  public static final String RETURN_CODE_P061 = "P061";
  /** リターンコード：P062 */
  public static final String RETURN_CODE_P062 = "P062";
  /** リターンコード：P064 */
  public static final String RETURN_CODE_P064 = "P064";
  /** リターンコード：P065 */
  public static final String RETURN_CODE_P065 = "P065";
  /** リターンコード：P066 */
  public static final String RETURN_CODE_P066 = "P066";
  /** リターンコード：P067 */
  public static final String RETURN_CODE_P067 = "P067";
  /** リターンコード：P068 */
  public static final String RETURN_CODE_P068 = "P068";
  /** リターンコード：P069 */
  public static final String RETURN_CODE_P069 = "P069";
  /** リターンコード：P070 */
  public static final String RETURN_CODE_P070 = "P070";
  /** リターンコード：P071 */
  public static final String RETURN_CODE_P071 = "P071";
  /** リターンコード：G001 */
  public static final String RETURN_CODE_G001 = "G001";
  /** リターンコード：G002 */
  public static final String RETURN_CODE_G002 = "G002";
  /** リターンコード：G003 */
  public static final String RETURN_CODE_G003 = "G003";
  /** リターンコード：G004 */
  public static final String RETURN_CODE_G004 = "G004";
  /** リターンコード：G005 */
  public static final String RETURN_CODE_G005 = "G005";
  /** リターンコード：G006 */
  public static final String RETURN_CODE_G006 = "G006";
  /** リターンコード：G009 */
  public static final String RETURN_CODE_G009 = "G009";
  /** リターンコード：G010 */
  public static final String RETURN_CODE_G010 = "G010";
  /** リターンコード：G011 */
  public static final String RETURN_CODE_G011 = "G011";
  /** リターンコード：G017 */
  public static final String RETURN_CODE_G017 = "G017";
  /** リターンコード：G018 */
  public static final String RETURN_CODE_G018 = "G018";
  /** リターンコード：G019 */
  public static final String RETURN_CODE_G019 = "G019";
  /** リターンコード：G024 */
  public static final String RETURN_CODE_G024 = "G024";
  /** リターンコード：G026 */
  public static final String RETURN_CODE_G026 = "G026";
  /** リターンコード：G027 */
  public static final String RETURN_CODE_G027 = "G027";
  /** リターンコード：G028 */
  public static final String RETURN_CODE_G028 = "G028";
  /** リターンコード：G029 */
  public static final String RETURN_CODE_G029 = "G029";
  /** リターンコード：D001 */
  public static final String RETURN_CODE_D001 = "D001";
  /** リターンコード：D002 */
  public static final String RETURN_CODE_D002 = "D002";
  /** リターンコード：D003 */
  public static final String RETURN_CODE_D003 = "D003";
  /** リターンコード：D005 */
  public static final String RETURN_CODE_D005 = "D005";
  /** リターンコード：D006 */
  public static final String RETURN_CODE_D006 = "D006";
  /** リターンコード：D007 */
  public static final String RETURN_CODE_D007 = "D007";
  /** リターンコード：D008 */
  public static final String RETURN_CODE_D008 = "D008";
  /** リターンコード：D009 */
  public static final String RETURN_CODE_D009 = "D009";
  /** リターンコード：D011 */
  public static final String RETURN_CODE_D011 = "D011";
  /** リターンコード：D013 */
  public static final String RETURN_CODE_D013 = "D013";
  /** リターンコード：D014 */
  public static final String RETURN_CODE_D014 = "D014";
  /** リターンコード：D016 */
  public static final String RETURN_CODE_D016 = "D016";
  /** リターンコード：D017 */
  public static final String RETURN_CODE_D017 = "D017";
  /** リターンコード：D018 */
  public static final String RETURN_CODE_D018 = "D018";
  /** リターンコード：D019 */
  public static final String RETURN_CODE_D019 = "D019";
  /** リターンコード：D022 */
  public static final String RETURN_CODE_D022 = "D022";
  /** リターンコード：D023 */
  public static final String RETURN_CODE_D023 = "D023";
  /** リターンコード：D024 */
  public static final String RETURN_CODE_D024 = "D024";
  /** リターンコード：H001 */
  public static final String RETURN_CODE_H001 = "H001";
  /** リターンコード：P059 */
  public static final String RETURN_CODE_P059 = "P059";
  /** リターンコード：P060 */
  public static final String RETURN_CODE_P060 = "P060";
  /** リターンコード：G014 */
  public static final String RETURN_CODE_G014 = "G014";
  /** リターンコード：G015 */
  public static final String RETURN_CODE_G015 = "G015";
  /** リターンコード：G016 */
  public static final String RETURN_CODE_G016 = "G016";
  /** リターンコード：P072 */
  public static final String RETURN_CODE_P072 = "P072";
  /** リターンコード：P073 */
  public static final String RETURN_CODE_P073 = "P073";
  /** リターンコード：P074 */
  public static final String RETURN_CODE_P074 = "P074";
  /** リターンコード：P075 */
  public static final String RETURN_CODE_P075 = "P075";
  /** リターンコード：G030 */
  public static final String RETURN_CODE_G030 = "G030";
  /** リターンコード：G031 */
  public static final String RETURN_CODE_G031 = "G031";
  /** リターンコード：G032 */
  public static final String RETURN_CODE_G032 = "G032";
  /** リターンコード：P076 */
  public static final String RETURN_CODE_P076 = "P076";
  /** リターンコード：P077 */
  public static final String RETURN_CODE_P077 = "P077";
  /** リターンコード：P078 */
  public static final String RETURN_CODE_P078 = "P078";
  /** リターンコード：G033 */
  public static final String RETURN_CODE_G033 = "G033";
  /** リターンコード：G034 */
  public static final String RETURN_CODE_G034 = "G034";
  /** リターンコード：G035 */
  public static final String RETURN_CODE_G035 = "G035";
  /** リターンコード：P079 */
  public static final String RETURN_CODE_P079 = "P079";
  /** リターンコード：P080 */
  public static final String RETURN_CODE_P080 = "P080";
  /** リターンコード：G036 */
  public static final String RETURN_CODE_G036 = "G036";
  /** リターンコード：G037 */
  public static final String RETURN_CODE_G037 = "G037";
  /** リターンコード：P081 */
  public static final String RETURN_CODE_P081 = "P081";
  /** リターンコード：D025 */
  public static final String RETURN_CODE_D025 = "D025";
  /** リターンコード：G038 */
  public static final String RETURN_CODE_G038 = "G038";
  /** リターンコード：G039 */
  public static final String RETURN_CODE_G039 = "G039";
  /** リターンコード：G040 */
  public static final String RETURN_CODE_G040 = "G040";
  /** リターンコード：G041 */
  public static final String RETURN_CODE_G041 = "G041";
  /** リターンコード：G042 */
  public static final String RETURN_CODE_G042 = "G042";
  /** リターンコード：G043 */
  public static final String RETURN_CODE_G043 = "G043";
  /** リターンコード：D026 */
  public static final String RETURN_CODE_D026 = "D026";
  /** リターンコード：GC001 */
  public static final String CUSTOM_RETURN_CODE_GC001 = "GC001";
  /** リターンコード：PC001 */
  public static final String CUSTOM_RETURN_CODE_PC001 = "PC001";
  /** リターンコード：PC002 */
  public static final String CUSTOM_RETURN_CODE_PC002 = "PC002";
  /** リターンコード：PC003 */
  public static final String CUSTOM_RETURN_CODE_PC003 = "PC003";
  /** リターンコード：P082 */
  public static final String RETURN_CODE_P082 = "P082";
  /** リターンコード：P083 */
  public static final String RETURN_CODE_P083 = "P083";
  /** リターンコード：G044 */
  public static final String RETURN_CODE_G044 = "G044";
  /** リターンコード：G045 */
  public static final String RETURN_CODE_G045 = "G045";
  /** リターンコード：P084 */
  public static final String RETURN_CODE_P084 = "P084";
  /** リターンコード：P085 */
  public static final String RETURN_CODE_P085 = "P085";
  /** リターンコード：P086 */
  public static final String RETURN_CODE_P086 = "P086";
  /** リターンコード：P087 */
  public static final String RETURN_CODE_P087 = "P087";
  /** リターンコード：0001 */
  public static final String RETURN_CODE_0001 = "0001";
  /** リターンコード：G046 */
  public static final String RETURN_CODE_G046 = "G046";
  /** リターンコード：G047 */
  public static final String RETURN_CODE_G047 = "G047";
  /** リターンコード：G048 */
  public static final String RETURN_CODE_G048 = "G048";
  /** リターンコード：P091 */
  public static final String RETURN_CODE_P091 = "P091";
  /** リターンコード：P092 */
  public static final String RETURN_CODE_P092 = "P092";
  /** リターンコード：P093 */
  public static final String RETURN_CODE_P093 = "P093";
  /** リターンコード：P094 */
  public static final String RETURN_CODE_P094 = "P094";
  /** リターンコード：P095 */
  public static final String RETURN_CODE_P095 = "P095";
  /** リターンコード：P096 */
  public static final String RETURN_CODE_P096 = "P096";
  /** リターンコード：G049 */
  public static final String RETURN_CODE_G049 = "G049";
  /** リターンコード：G050 */
  public static final String RETURN_CODE_G050 = "G050";
  /** リターンコード：P097 */
  public static final String RETURN_CODE_P097 = "P097";
  /** リターンコード：P098 */
  public static final String RETURN_CODE_P098 = "P098";
  /** リターンコード：P099 */
  public static final String RETURN_CODE_P099 = "P099";
  /** リターンコード：P100 */
  public static final String RETURN_CODE_P100 = "P100";
  /** リターンコード：G051 */
  public static final String RETURN_CODE_G051 = "G051";
  /** リターンコード：G052 */
  public static final String RETURN_CODE_G052 = "G052";
  /** リターンコード：G053 */
  public static final String RETURN_CODE_G053 = "G053";
  /** リターンコード：P101 */
  public static final String RETURN_CODE_P101 = "P101";
  /** リターンコード：P102 */
  public static final String RETURN_CODE_P102 = "P102";
  /** リターンコード：P103 */
  public static final String RETURN_CODE_P103 = "P103";
  /** リターンコード：P104 */
  public static final String RETURN_CODE_P104 = "P104";
  /** リターンコード：P105 */
  public static final String RETURN_CODE_P105 = "P105";
  /** リターンコード：P107 */
  public static final String RETURN_CODE_P107 = "P107";
  /** リターンコード：G054 */
  public static final String RETURN_CODE_G054 = "G054";
  /** リターンコード：G055 */
  public static final String RETURN_CODE_G055 = "G055";
  /** リターンコード：G056 */
  public static final String RETURN_CODE_G056 = "G056";
  /** リターンコード：G057 */
  public static final String RETURN_CODE_G057 = "G057";
  /** リターンコード：D027 */
  public static final String RETURN_CODE_D027 = "D027";
  /** リターンコード：D028 */
  public static final String RETURN_CODE_D028 = "D028";
  /** リターンコード：D029 */
  public static final String RETURN_CODE_D029 = "D029";
  /** リターンコード：D030 */
  public static final String RETURN_CODE_D030 = "D030";
  /** リターンコード：D031 */
  public static final String RETURN_CODE_D031 = "D031";
  /** リターンコード：D032 */
  public static final String RETURN_CODE_D032 = "D032";
  /** リターンコード：D033 */
  public static final String RETURN_CODE_D033 = "D033";
  /** リターンコード：P106 */
  public static final String RETURN_CODE_P106 = "P106";
  /** リターンコード：G058 */
  public static final String RETURN_CODE_G058 = "G058";

}
