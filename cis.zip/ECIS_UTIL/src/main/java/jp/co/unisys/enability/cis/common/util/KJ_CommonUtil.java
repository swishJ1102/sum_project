package jp.co.unisys.enability.cis.common.util;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import jp.co.unisys.enability.cis.common.util.constants.ECISCodeConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISKJConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISReturnCodeConstants;
import jp.co.unisys.enability.cis.common.util.model.CheckAccountCreditInfomationUtilBean;
import jp.co.unisys.enability.cis.common.util.model.CheckBillingInformationUtilBean;
import jp.co.unisys.enability.cis.common.util.model.CheckContactInformationUtilBean;

/**
 * 契約情報管理共通Utilクラス。
 *
 * @author "Nihon Unisys, Ltd."
 *
 *         変更履歴(kg-epj) 2016.02.04 ko リターンコードとメッセージIDを追加
 */
public class KJ_CommonUtil {

  /**
   * 電話番号の桁数チェックを行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   *        市外局番、市内局番、加入者番号を連結した文字列の桁が14桁より大きいか否かをチェックする。
   *        チェック結果を返却する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param phoneNo
   *          契約者の電話番号1,2、契約の請求先番号
   * @return true 電話番号の桁数が14桁より大きい<br>
   *         false 電話番号の桁数が14桁以下<br>
   */
  public static boolean checkPhoneLength(StringBuilder phoneNo) {

    boolean result = false;

    if (phoneNo.length() > ECISKJConstants.PHONE_MAX) {
      result = true;
    }

    return result;
  }

  /**
   * 契約の連絡先情報チェックする。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 1       条件付必須項目と任意項目をリストに設定し、チェック処理を呼び出す。
   * 2       チェック結果を返却する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param checkContactInformationUtilBean
   *          契約の連絡先情報
   * @return true（チェックOK） 条件付入力必須項目が全て入力なし、かつ任意入力項目が全て未入力なし<br>
   *         または、条件付入力必須項目が全て入力あり、かつ任意入力項目が全て未入力なし<br>
   *         または、条件付入力必須項目が全て入力あり、かつ任意入力項目が全て未入力あり<br>
   *         false（チェックNG） 条件付入力必須項目が入力、未入力が混在<br>
   *         または、条件付入力必須項目が全て入力なし、かつ任意入力項目が入力あり<br>
   */
  public static boolean checkContactInformation(
      CheckContactInformationUtilBean checkContactInformationUtilBean) {

    // 条件付入力必須項目生成
    ArrayList<String> conditioningRequiredItemList = new ArrayList<String>();
    // 連絡先個人・法人区分コード
    conditioningRequiredItemList.add(checkContactInformationUtilBean
        .getContactInformationinDividualLegalEntityCategoryCode());
    // 連絡先氏名（カナ）
    conditioningRequiredItemList.add(checkContactInformationUtilBean
        .getContractInformationNameKana());
    // 連絡先氏名1
    conditioningRequiredItemList.add(checkContactInformationUtilBean
        .getContractInformationName1());
    // 連絡先住所（郵便番号）
    conditioningRequiredItemList.add(checkContactInformationUtilBean
        .getContractInformationAddressPostalCode());
    // 連絡先住所（住所）
    conditioningRequiredItemList.add(checkContactInformationUtilBean
        .getContractInformationAddressFull());
    // 連絡先電話区分コード
    conditioningRequiredItemList.add(checkContactInformationUtilBean
        .getContractInformationCategoryCode());
    // 連絡先電話（市外局番）
    conditioningRequiredItemList.add(checkContactInformationUtilBean
        .getContractInformationAreaCode());
    // 連絡先電話（市内局番）
    conditioningRequiredItemList.add(checkContactInformationUtilBean
        .getContractInformationLocalNo());
    // 連絡先電話（加入者番号）
    conditioningRequiredItemList.add(checkContactInformationUtilBean
        .getContractInformationDirectoryNo());

    // 連絡先情報(任意入力項目)生成
    ArrayList<String> arbitraryInputItemList = new ArrayList<String>();
    // 連絡先氏名2
    arbitraryInputItemList.add(checkContactInformationUtilBean
        .getContractInformationName2());
    // 連絡先住所（建物・部屋名）
    arbitraryInputItemList.add(checkContactInformationUtilBean
        .getContractInformationAddressBuilding());

    // 連絡先情報チェック
    boolean result = checkContractInformation(conditioningRequiredItemList,
        arbitraryInputItemList);

    return result;
  }

  /**
   * 支払の請求先情報チェックする。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 1       条件付必須項目と任意項目をリストに設定し、チェック処理を呼び出す。
   * 2       チェック結果を返却する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param checkBillingInformationUtilBean
   *          支払の請求先情報
   * @return true（チェックOK） 条件付入力必須項目が全て入力なし、かつ任意入力項目が全て未入力なし<br>
   *         または、条件付入力必須項目が全て入力あり、かつ任意入力項目が全て未入力なし<br>
   *         または、条件付入力必須項目が全て入力あり、かつ任意入力項目が全て未入力あり<br>
   *         false（チェックNG） 条件付入力必須項目が入力、未入力が混在<br>
   *         または、条件付入力必須項目が全て入力なし、かつ任意入力項目が入力あり<br>
   */
  public static boolean checkBillDestinationInformation(
      CheckBillingInformationUtilBean checkBillingInformationUtilBean) {

    // 条件付入力必須項目生成
    ArrayList<String> conditioningRequiredItemList = new ArrayList<String>();

    // 個人・法人区分コード
    conditioningRequiredItemList.add(checkBillingInformationUtilBean
        .getIndividualLegalEntityCategoryCode());
    // 請求先氏名1
    conditioningRequiredItemList.add(checkBillingInformationUtilBean
        .getBillingName1());
    // 敬称
    conditioningRequiredItemList.add(checkBillingInformationUtilBean
        .getPrefix());
    // 請求先住所（郵便番号）
    conditioningRequiredItemList.add(checkBillingInformationUtilBean
        .getBillingAddressPostalCode());
    // 請求先住所（都道府県名）
    conditioningRequiredItemList.add(checkBillingInformationUtilBean
        .getBillingAddressPrefectures());
    // 請求先住所（市区郡町村名）
    conditioningRequiredItemList.add(checkBillingInformationUtilBean
        .getBillingAddressMunicipality());
    // 請求先電話番号
    conditioningRequiredItemList.add(checkBillingInformationUtilBean
        .getBillingPhoneNo());
    // 請求先電話区分コード
    conditioningRequiredItemList.add(checkBillingInformationUtilBean
        .getBillingPhoneCategoryCode1());

    // 連絡先情報(任意入力項目)生成
    ArrayList<String> arbitraryInputItemList = new ArrayList<String>();
    // 請求先氏名2
    arbitraryInputItemList.add(checkBillingInformationUtilBean
        .getBillingName2());
    // 請求先住所（字名・丁目）
    arbitraryInputItemList.add(checkBillingInformationUtilBean
        .getBillingAddressSection());
    // 請求先住所（番地･号）
    arbitraryInputItemList.add(checkBillingInformationUtilBean
        .getBillingAddressBlock());
    // 請求先住所（建物名）
    arbitraryInputItemList.add(checkBillingInformationUtilBean
        .getBillingAddressBuildingName());
    // 請求先住所（部屋名）
    arbitraryInputItemList.add(checkBillingInformationUtilBean
        .getBillingAddressRoom());
    // 請求先メールアドレス1
    arbitraryInputItemList.add(checkBillingInformationUtilBean
        .getBillingMailAddress1());
    // 請求先メールアドレス2
    arbitraryInputItemList.add(checkBillingInformationUtilBean
        .getBillingMailAddress2());

    // 連絡先情報チェック
    boolean result = checkContractInformation(conditioningRequiredItemList,
        arbitraryInputItemList);

    return result;
  }

  /**
   * 条件付必須入力、任意入力の項目の入力チェックを行う。
   *
   * <pre>
   *  <p><b>【仕様詳細】</b></p>
   *  条件付入力必須項目入力チェックを行い、条件付入力必須項目に一部入力されていない項目が存在する場合、<br>
   * false（チェックNG）を返却する。<br>
   * 条件付入力必須項目が全て入力されていない場合、連絡先情報(任意入力項目)入力チェックを行い、<br>
   * 連絡先情報(任意入力項目)に入力されている項目が存在する場合、false（チェックNG）を返却する。<br>
   * 上記条件を満たさない場合、true(チェックOK)を返却する。<br>
   * </pre>
   *
   * @param conditioningRequiredItemList
   * @param arbitraryInputItemList
   * @return true（チェックOK） 条件付入力必須項目が全て入力なし、かつ任意入力項目が全て未入力なし<br>
   *         または、条件付入力必須項目が全て入力あり、かつ任意入力項目が全て未入力なし<br>
   *         または、条件付入力必須項目が全て入力あり、かつ任意入力項目が全て未入力あり<br>
   *         false（チェックNG） 条件付入力必須項目が入力、未入力が混在<br>
   *         または、条件付入力必須項目が全て入力なし、かつ任意入力項目が入力あり<br>
   *
   */
  private static boolean checkContractInformation(
      ArrayList<String> conditioningRequiredItemList,
      ArrayList<String> arbitraryInputItemList) {
    // 入力フラグ
    boolean inputFlag = false;
    // 未入力フラグ
    boolean noInputFlag = false;

    // 条件付入力必須項目入力チェック
    for (String conditioningRequiredItem : conditioningRequiredItemList) {
      if (StringUtils.isEmpty(conditioningRequiredItem)) {
        noInputFlag = true;
      } else {
        inputFlag = true;
      }
      // 条件付入力必須項目に入力、未入力が混在している場合
      if (noInputFlag && inputFlag) {
        return false;
      }
    }

    if (noInputFlag) {
      // 連絡先情報(任意入力項目)入力チェック
      for (String arbitraryInputItem : arbitraryInputItemList) {
        // 条件付入力必須項目が未入力、かつ連絡先情報(任意入力項目)が入力ありの場合
        if (!StringUtils.isEmpty(arbitraryInputItem)) {
          return false;
        }
      }
    }
    return true;
  }

  /**
   * キーチェック項目の全項目がNullまたは空文字かチェックする。
   *
   * @param keyList
   *          キーのリスト
   * @return true (チェックOK) 1つでも入力があった。<br>
   *         false (チェックNG) 全てNullまたは空文字。
   */
  public static boolean checkKeyListIsEmpty(List<String> keyList) {

    for (String key : keyList) {
      // 一つでも入力があればチェックOK
      if (StringUtils.isNotEmpty(key)) {
        return true;
      }
    }

    return false;
  }

  /**
   * キーチェック項目に一つでも入力があるかチェックする。
   *
   * @param keyList
   *          キーのリスト
   * @return true (チェックOK) 全てNullまたは空文字。<br>
   *         false (チェックNG) 1つでも入力があった。
   */
  public static boolean checkKeyListIsNotEmpty(List<String> keyList) {

    for (String key : keyList) {
      // 一つでも入力があればチェックNG
      if (StringUtils.isNotEmpty(key)) {
        return false;
      }
    }

    return true;
  }

  /**
   * キーリストに空文字があれば、tureを返却する
   *
   * @param keyList
   * @return true (OK) 空文字がある。 false (NG) 空文字がなし。
   */
  public static boolean checkKeyListHaveBlank(List<String> keyList) {
    return keyList.contains(ECISKJConstants.EMPTY_STRING);
  }

  /**
   * 支払方法コードが“コンビニ払い”以外かチェックする 支払方法コードが入力されている時のみチェックする。
   *
   * @param paymentWayCode
   *          支払方法コード
   * @return true (チェックOK) 支払方法コードが“コンビニ払い”。 false (チェックNG)支払方法コードが“コンビニ払い”以外。
   */
  public static boolean checkPayToComvini(String paymentWayCode) {
    if (StringUtils.isNotEmpty(paymentWayCode)
        && !ECISCodeConstants.PAYMENT_WAY_CODE_CONVENI
            .equals(paymentWayCode)) {
      return false;
    }
    return true;
  }

  /**
   * メールアドレス1が未入力でメールドレス2が入力されていないかチェック
   *
   * @param mailAddress1
   *          メールドレス1
   * @param mailAddress2
   *          メールドレス2
   * @return true (チェックOK) メールアドレス1またはメールアドレス1とメールアドレス2が同時に入力されている。 false (チェックNG) メールアドレス1がNULLまたは空文字かつメールアドレス2がNULLまたは空文字。
   */
  public static boolean checkMailAddressCorrelation(String mailAddress1,
      String mailAddress2) {

    if (StringUtils.isEmpty(mailAddress1)
        && !StringUtils.isEmpty(mailAddress2)) {
      return false;

    }

    return true;
  }

  /**
   * 契約者電話区分コード2がNULLまたは空文字の場合、契約者電話2（市外局番）、契約者番号2（市内局番）、契約者番号2（加入者番号） がNULLまたは空文字のいずれでもないかチェックする。
   * 上記以外（契約者電話区分コード2がNULLまたは空文字ではない）の場合、契約者電話2（市外局番 ）、契約者番号2（市内局番）、契約者番号2（加入者番号） いずれかがNULLまたは空文字であるかチェックする。
   *
   * @param contractorPhoneCategoryCode2
   *          契約者電話区分コード2
   * @param contractorPhoneAreaCode2
   *          契約者電話2（市外局番）
   * @param contractorPhoneLocalNo2
   *          契約者番号2（市内局番）
   * @param contractorPhoneDirectoryNo2
   *          契約者番号2（加入者番号）
   * @return true (チェックOK) 契約者電話区分コード2に入力されている場合、契約者電話2（市外局番）、契約者番号2（市内局番）、契約者番号2 （加入者番号）がNULLまたは空文字ではない。
   *         たまは、契約者電話区分コード2に入力されていない場合、契約者電話2（市外局番）、契約者番号2 （市内局番）、契約者番号2（加入者番号）がNULLまたは空文字。 false (チェックNG)
   *         契約者電話区分コード2に入力されている場合、 契約者電話2（市外局番）、契約者番号2（市内局番）、契約者番号2（加入者番号）がNULLまたは空文字。 たまは、契約者電話区分コード2に入力されていない場合、
   *         契約者電話2（市外局番）、契約者番号2（市内局番）、契約者番号2（加入者番号）がNULLまたは空文字ではない。
   */
  public static boolean checkContractorPhone2(
      String contractorPhoneCategoryCode2,
      String contractorPhoneAreaCode2, String contractorPhoneLocalNo2,
      String contractorPhoneDirectoryNo2) {

    // 契約者電話区分コード2がNULLまたは空文字の場合、以下の処理を行う
    if (StringUtils.isEmpty(contractorPhoneCategoryCode2)) {
      // 契約者電話2（市外局番）、契約者電話2（市内局番）、契約者電話2（加入者番号）
      // がNULLまたは空文字のいずれでもない場合、以下の処理を行う
      if (StringUtils.isNotEmpty(contractorPhoneAreaCode2)
          || StringUtils.isNotEmpty(contractorPhoneLocalNo2)
          || StringUtils.isNotEmpty(contractorPhoneDirectoryNo2)) {
        return false;
      }
    } else {
      // 契約者電話2（市外局番）、契約者電話2（市内局番）、契約者電話2（加入者番号）
      // いずれかがNULLまたは空文字の場合、以下の処理を行う
      if (StringUtils.isEmpty(contractorPhoneAreaCode2)
          || StringUtils.isEmpty(contractorPhoneLocalNo2)
          || StringUtils.isEmpty(contractorPhoneDirectoryNo2)) {
        return false;
      }
    }
    return true;
  }

  /**
   * 口座クレカ情報相関チェック共通化メソッド
   *
   * @param bean
   *          口座クレカ情報チェックUtilBean
   * @return リターンコード チェックOKの場合、ブランクを返却する。
   */
  public static String checkAccountCredit(
      CheckAccountCreditInfomationUtilBean bean) {
    // リターンコード初期化
    String returnCode = "";

    // パラメータ相関チェック
    // 口座クレカ区分
    String accountCreditCategory = bean.getAccountCreditCategoryCode();
    // 決済アクセスキー
    String accessKey = bean.getAccessKey();
    // クレカ番号
    String creditCardNo = bean.getCreditCardNo();
    // クレカ有効期限
    String creditCardExpirationDate = bean.getCreditCardExpirationDate();
    // クレカブランドコード
    String creditCardBrandCode = bean.getCreditCardBrandCode();
    // 口座番号
    String accountNo = bean.getAccountNo();
    // 金融機関コード
    String bankCode = bean.getBankCode();
    // 金融機関支店コード、
    String bankBranchCode = bean.getBankBranchCode();
    // 金融機関預金種目コード、
    String bankTypeOfAccountCode = bean.getBankTypeOfAccountCode();
    // 口座名義
    String accountHolderName = bean.getAccountHolderName();

    // クレカ部分リスト
    List<String> cardCheckList = new ArrayList<String>();
    cardCheckList.add(creditCardNo);
    cardCheckList.add(creditCardExpirationDate);
    cardCheckList.add(creditCardBrandCode);

    // 口座部分リスト
    List<String> accountCheckList = new ArrayList<String>();
    accountCheckList.add(bankCode);
    accountCheckList.add(bankBranchCode);
    accountCheckList.add(bankTypeOfAccountCode);
    accountCheckList.add(accountHolderName);

    // 口座クレカ区分が”1”（クレジットカード払い）の場合。
    if (ECISCodeConstants.ACCOUNT_CREDIT_CATEGORY_CODE_CREDIT
        .equals(accountCreditCategory)) {

      // 決済アクセスキー、クレカ番号、クレカ有効期限が指定されている、かつ
      if (!(StringUtils.isNotEmpty(accessKey)
          && StringUtils.isNotEmpty(creditCardNo)
          && StringUtils.isNotEmpty(creditCardExpirationDate)
          // 口座番号、金融機関コード、金融機関支店コード、
          // 金融機関預金種目コード、口座名義が指定されていないこと。
          && StringUtils.isEmpty(accountNo) && KJ_CommonUtil
              .checkKeyListIsNotEmpty(accountCheckList))) {
        // 上記以外の場合、リターンコードにP035を設定する。
        returnCode = ECISReturnCodeConstants.RETURN_CODE_P035;
      }

    } else if (ECISCodeConstants.ACCOUNT_CREDIT_CATEGORY_CODE_ACCOUNT
        .equals(accountCreditCategory)) {
      // 口座クレカ区分が”2”（口座振替）の場合。

      // 決済アクセスキー、口座番号が指定されている、かつ
      if (!(StringUtils.isNotEmpty(accessKey)
          && StringUtils.isNotEmpty(accountNo)
          // クレカ番号、クレカ有効期限、クレカブランドコードが指定されていないこと。
          && KJ_CommonUtil.checkKeyListIsNotEmpty(cardCheckList)
          // 口座番号、金融機関コード、金融機関支店コード、
          // 金融機関預金種目コード、口座名義が指定されている場合、全ての項目が指定されて
          // いること。
          && KJ_CommonUtil.checkListIsSameState(accountCheckList))) {
        // 上記以外の場合、リターンコードにP036を設定する。
        returnCode = ECISReturnCodeConstants.RETURN_CODE_P036;
      }

    } else if (ECISCodeConstants.ACCOUNT_CREDIT_CATEGORY_CODE_TRANSFER
        .equals(accountCreditCategory)
        || ECISCodeConstants.ACCOUNT_CREDIT_CATEGORY_CODE_TRANSFER_BUY
            .equals(accountCreditCategory)) {
      // 口座クレカ区分が”4”（請求時振込先（自社口座））または、”5”（購入時振込先）の場合。

      // 口座番号、金融機関コード、金融機関支店コード、金融機関預金種目コード、口座名義が指定されている、
      if (!(StringUtils.isNotEmpty(accountNo)
          && StringUtils.isNotEmpty(bankCode)
          && StringUtils.isNotEmpty(bankBranchCode)
          && StringUtils.isNotEmpty(bankTypeOfAccountCode)
          && StringUtils.isNotEmpty(accountHolderName)
          // かつ決済アクセスキー、クレカ番号、クレカ有効期限、、クレカブランドコードが指定されていないこと
          && StringUtils.isEmpty(accessKey) && KJ_CommonUtil
              .checkKeyListIsNotEmpty(cardCheckList))) {
        // 上記以外の場合、リターンコードにP037を設定する。
        returnCode = ECISReturnCodeConstants.RETURN_CODE_P037;
      }
    }

    return returnCode;
  }

  /**
   * リスト内容同状態チェック
   *
   * @param list
   *          List<String>
   * @return true 全Null or 全あり false 混在あり
   */
  public static boolean checkListIsSameState(List<String> list) {

    // 入力フラグ
    boolean inputFlag = false;
    // 未入力フラグ
    boolean noInputFlag = false;

    // 入力チェック
    for (String str : list) {
      if (StringUtils.isEmpty(str)) {
        noInputFlag = true;
      } else {
        inputFlag = true;
      }
      // 入力、未入力が混在している場合
      if (noInputFlag && inputFlag) {
        return false;
      }
    }
    return true;
  }

  /**
   * リターンコードからメッセージIDを取得
   *
   * @param returnCode
   *          リターンコード
   * @return メッセージID
   */
  public static String getMessageId(String returnCode) {

    if (StringUtils.isEmpty(returnCode)) {
      return "error.E1129";
    }

    switch (returnCode) {
      case ECISReturnCodeConstants.RETURN_CODE_P001:
        return "error.E1065";
      case ECISReturnCodeConstants.RETURN_CODE_P002:
        return "error.E1066";
      case ECISReturnCodeConstants.RETURN_CODE_P003:
        return "error.E1067";
      case ECISReturnCodeConstants.RETURN_CODE_P004:
        return "error.E1068";
      case ECISReturnCodeConstants.RETURN_CODE_P005:
        return "error.E1069";
      case ECISReturnCodeConstants.RETURN_CODE_P006:
        return "error.E1070";
      case ECISReturnCodeConstants.RETURN_CODE_P007:
        return "error.E1071";
      case ECISReturnCodeConstants.RETURN_CODE_P008:
        return "error.E1072";
      case ECISReturnCodeConstants.RETURN_CODE_P009:
        return "error.E1369";
      case ECISReturnCodeConstants.RETURN_CODE_P010:
        return "error.E1074";
      case ECISReturnCodeConstants.RETURN_CODE_P011:
        return "error.E1075";
      case ECISReturnCodeConstants.RETURN_CODE_P012:
        return "error.E1076";
      case ECISReturnCodeConstants.RETURN_CODE_P013:
        return "error.E1077";
      case ECISReturnCodeConstants.RETURN_CODE_P014:
        return "error.E1078";
      case ECISReturnCodeConstants.RETURN_CODE_P015:
        return "error.E1079";
      case ECISReturnCodeConstants.RETURN_CODE_P016:
        return "error.E1080";
      case ECISReturnCodeConstants.RETURN_CODE_P017:
        return "error.E1081";
      case ECISReturnCodeConstants.RETURN_CODE_P018:
        return "error.E1082";
      case ECISReturnCodeConstants.RETURN_CODE_P019:
        return "error.E1083";
      case ECISReturnCodeConstants.RETURN_CODE_P020:
        return "error.E1084";
      case ECISReturnCodeConstants.RETURN_CODE_P021:
        return "error.E1085";
      case ECISReturnCodeConstants.RETURN_CODE_P022:
        return "error.E1086";
      case ECISReturnCodeConstants.RETURN_CODE_P023:
        return "error.E1087";
      case ECISReturnCodeConstants.RETURN_CODE_P024:
        return "error.E1088";
      case ECISReturnCodeConstants.RETURN_CODE_P025:
        return "error.E1089";
      case ECISReturnCodeConstants.RETURN_CODE_P026:
        return "error.E1090";
      case ECISReturnCodeConstants.RETURN_CODE_P027:
        return "error.E1091";
      case ECISReturnCodeConstants.RETURN_CODE_P028:
        return "error.E1092";
      case ECISReturnCodeConstants.RETURN_CODE_P029:
        return "error.E1093";
      case ECISReturnCodeConstants.RETURN_CODE_P030:
        return "error.E1174";
      case ECISReturnCodeConstants.RETURN_CODE_P031:
        return "error.E1175";
      case ECISReturnCodeConstants.RETURN_CODE_P032:
        return "error.E1176";
      case ECISReturnCodeConstants.RETURN_CODE_P033:
        return "error.E1094";
      case ECISReturnCodeConstants.RETURN_CODE_P034:
        return "error.E1095";
      case ECISReturnCodeConstants.RETURN_CODE_P035:
        return "error.E1177";
      case ECISReturnCodeConstants.RETURN_CODE_P036:
        return "error.E1178";
      case ECISReturnCodeConstants.RETURN_CODE_P037:
        return "error.E1096";
      case ECISReturnCodeConstants.RETURN_CODE_P038:
        return "error.E1097";
      case ECISReturnCodeConstants.RETURN_CODE_P039:
        return "error.E1179";
      case ECISReturnCodeConstants.RETURN_CODE_P040:
        return "error.E1098";
      case ECISReturnCodeConstants.RETURN_CODE_P041:
        return "error.E1180";
      case ECISReturnCodeConstants.RETURN_CODE_P042:
        return "error.E1099";
      case ECISReturnCodeConstants.RETURN_CODE_P043:
        return "error.E1100";
      case ECISReturnCodeConstants.RETURN_CODE_P044:
        return "error.E1101";
      case ECISReturnCodeConstants.RETURN_CODE_P049:
        return "error.E1181";
      case ECISReturnCodeConstants.RETURN_CODE_P050:
        return "error.E1372";
      case ECISReturnCodeConstants.RETURN_CODE_P051:
        return "error.E1373";
      case ECISReturnCodeConstants.RETURN_CODE_P052:
        return "error.E1105";
      case ECISReturnCodeConstants.RETURN_CODE_P053:
        return "error.E1106";
      case ECISReturnCodeConstants.RETURN_CODE_P054:
        return "error.E1107";
      case ECISReturnCodeConstants.RETURN_CODE_P055:
        return "error.E1108";
      case ECISReturnCodeConstants.RETURN_CODE_P056:
        return "error.E1109";
      case ECISReturnCodeConstants.RETURN_CODE_P057:
        return "error.E1110";
      case ECISReturnCodeConstants.RETURN_CODE_P058:
        return "error.E1111";
      case ECISReturnCodeConstants.RETURN_CODE_P059:
        return "error.E1112";
      case ECISReturnCodeConstants.RETURN_CODE_P060:
        return "error.E1113";
      case ECISReturnCodeConstants.RETURN_CODE_P061:
        return "error.E1184";
      case ECISReturnCodeConstants.RETURN_CODE_P062:
        return "error.E1114";
      case ECISReturnCodeConstants.RETURN_CODE_P064:
        return "error.E1185";
      case ECISReturnCodeConstants.RETURN_CODE_P065:
        return "error.E1186";
      case ECISReturnCodeConstants.RETURN_CODE_P066:
        return "error.E1187";
      case ECISReturnCodeConstants.RETURN_CODE_P067:
        return "error.E1217";
      case ECISReturnCodeConstants.RETURN_CODE_P068:
        return "error.E1218";
      case ECISReturnCodeConstants.RETURN_CODE_P069:
        return "error.E1230";
      case ECISReturnCodeConstants.RETURN_CODE_P070:
        return "error.E1365";
      case ECISReturnCodeConstants.RETURN_CODE_P071:
        return "error.E1370";
      case ECISReturnCodeConstants.RETURN_CODE_P072:
        return "error.E1374";
      case ECISReturnCodeConstants.RETURN_CODE_P073:
        return "error.E1380";
      case ECISReturnCodeConstants.RETURN_CODE_P074:
        return "error.E1381";
      case ECISReturnCodeConstants.RETURN_CODE_P075:
        return "error.E1382";
      case ECISReturnCodeConstants.RETURN_CODE_P076:
        return "error.E1440";
      case ECISReturnCodeConstants.RETURN_CODE_P077:
        return "error.E1441";
      case ECISReturnCodeConstants.RETURN_CODE_P078:
        return "error.E1442";
      case ECISReturnCodeConstants.RETURN_CODE_P079:
        return "error.E1486";
      case ECISReturnCodeConstants.RETURN_CODE_P080:
        return "error.E1487";
      case ECISReturnCodeConstants.RETURN_CODE_P081:
        return "error.E1493";
      case ECISReturnCodeConstants.RETURN_CODE_P082:
        return "error.E1520";
      case ECISReturnCodeConstants.RETURN_CODE_P083:
        return "error.E1521";
      // [kg-epj]<i-start>
      case ECISReturnCodeConstants.CUSTOM_RETURN_CODE_PC001:
        return "error.EC0002";
      case ECISReturnCodeConstants.CUSTOM_RETURN_CODE_PC002:
        return "error.EC0003";
      case ECISReturnCodeConstants.CUSTOM_RETURN_CODE_PC003:
        return "error.EC0004";
      // [kg-epj]<i-end>
      case ECISReturnCodeConstants.RETURN_CODE_G001:
        return "error.E1116";
      case ECISReturnCodeConstants.RETURN_CODE_G002:
        return "error.E1117";
      case ECISReturnCodeConstants.RETURN_CODE_G003:
        return "error.E1118";
      case ECISReturnCodeConstants.RETURN_CODE_G004:
        return "error.E1119";
      case ECISReturnCodeConstants.RETURN_CODE_G005:
        return "error.E1120";
      case ECISReturnCodeConstants.RETURN_CODE_G006:
        return "error.E1188";
      case ECISReturnCodeConstants.RETURN_CODE_G009:
        return "error.E1122";
      case ECISReturnCodeConstants.RETURN_CODE_G010:
        return "error.E1123";
      case ECISReturnCodeConstants.RETURN_CODE_G011:
        return "error.E1189";
      case ECISReturnCodeConstants.RETURN_CODE_G014:
        return "error.E1126";
      case ECISReturnCodeConstants.RETURN_CODE_G015:
        return "error.E1127";
      case ECISReturnCodeConstants.RETURN_CODE_G016:
        return "error.E1128";
      case ECISReturnCodeConstants.RETURN_CODE_G017:
        return "error.E1129";
      case ECISReturnCodeConstants.RETURN_CODE_G018:
        return "error.E1130";
      case ECISReturnCodeConstants.RETURN_CODE_G019:
        return "error.E1131";
      case ECISReturnCodeConstants.RETURN_CODE_G024:
        return "error.E1136";
      case ECISReturnCodeConstants.RETURN_CODE_G026:
        return "error.E1495";
      case ECISReturnCodeConstants.RETURN_CODE_G027:
        return "error.E1228";
      case ECISReturnCodeConstants.RETURN_CODE_G028:
        return "error.E1229";
      case ECISReturnCodeConstants.RETURN_CODE_G029:
        return "error.E1231";
      case ECISReturnCodeConstants.RETURN_CODE_G030:
        return "error.E1415";
      case ECISReturnCodeConstants.RETURN_CODE_G031:
        return "error.E1416";
      case ECISReturnCodeConstants.RETURN_CODE_G032:
        return "error.E1417";
      case ECISReturnCodeConstants.RETURN_CODE_G033:
        return "error.E1443";
      case ECISReturnCodeConstants.RETURN_CODE_G034:
        return "error.E1444";
      case ECISReturnCodeConstants.RETURN_CODE_G035:
        return "error.E1445";
      case ECISReturnCodeConstants.RETURN_CODE_G036:
        return "error.E1489";
      case ECISReturnCodeConstants.RETURN_CODE_G037:
        return "error.E1491";
      case ECISReturnCodeConstants.RETURN_CODE_G038:
        return "error.E1497";
      case ECISReturnCodeConstants.RETURN_CODE_G039:
        return "error.E1498";
      case ECISReturnCodeConstants.RETURN_CODE_G040:
        return "error.E1499";
      case ECISReturnCodeConstants.RETURN_CODE_G041:
        return "error.E1500";
      case ECISReturnCodeConstants.RETURN_CODE_G042:
        return "error.E1505";
      case ECISReturnCodeConstants.RETURN_CODE_G043:
        return "error.E1507";
      case ECISReturnCodeConstants.RETURN_CODE_G044:
        return "error.E1522";
      case ECISReturnCodeConstants.RETURN_CODE_G045:
        return "error.E1523";
      case ECISReturnCodeConstants.RETURN_CODE_G046:
        return "error.E1576";
      case ECISReturnCodeConstants.RETURN_CODE_G047:
        return "error.E1578";
      case ECISReturnCodeConstants.RETURN_CODE_G048:
        return "error.E1579";
      case ECISReturnCodeConstants.RETURN_CODE_G049:
        return "error.E1580";
      // [kg-epj]<i-start>
      case ECISReturnCodeConstants.CUSTOM_RETURN_CODE_GC001:
        return "error.EC0001";
      // [kg-epj]<i-end>
      case ECISReturnCodeConstants.RETURN_CODE_D001:
        return "error.E1137";
      case ECISReturnCodeConstants.RETURN_CODE_D002:
        return "error.E1190";
      case ECISReturnCodeConstants.RETURN_CODE_D003:
        return "error.E1138";
      case ECISReturnCodeConstants.RETURN_CODE_D005:
        return "error.E1191";
      case ECISReturnCodeConstants.RETURN_CODE_D006:
        return "error.E1140";
      case ECISReturnCodeConstants.RETURN_CODE_D007:
        return "error.E1192";
      case ECISReturnCodeConstants.RETURN_CODE_D008:
        return "error.E1193";
      case ECISReturnCodeConstants.RETURN_CODE_D009:
        return "error.E1141";
      case ECISReturnCodeConstants.RETURN_CODE_D011:
        return "error.E1143";
      case ECISReturnCodeConstants.RETURN_CODE_D013:
        return "error.E1145";
      case ECISReturnCodeConstants.RETURN_CODE_D014:
        return "error.E1146";
      case ECISReturnCodeConstants.RETURN_CODE_D016:
        return "error.E1148";
      case ECISReturnCodeConstants.RETURN_CODE_D017:
        return "error.E1149";
      case ECISReturnCodeConstants.RETURN_CODE_D018:
        return "error.E1150";
      case ECISReturnCodeConstants.RETURN_CODE_D019:
        return "error.E1151";
      case ECISReturnCodeConstants.RETURN_CODE_D022:
        return "error.E1154";
      case ECISReturnCodeConstants.RETURN_CODE_D023:
        return "error.E1155";
      case ECISReturnCodeConstants.RETURN_CODE_D024:
        return "error.E1194";
      case ECISReturnCodeConstants.RETURN_CODE_D025:
        return "error.E1494";
      case ECISReturnCodeConstants.RETURN_CODE_H001:
        return "error.E1195";
      case ECISReturnCodeConstants.RETURN_CODE_D026:
        return "error.E1511";
      case ECISReturnCodeConstants.RETURN_CODE_P085:
        return "error.E1549";
      case ECISReturnCodeConstants.RETURN_CODE_P091:
        return "error.E1563";
      case ECISReturnCodeConstants.RETURN_CODE_P092:
        return "error.E1566";
      case ECISReturnCodeConstants.RETURN_CODE_P093:
        return "error.E1568";
      case ECISReturnCodeConstants.RETURN_CODE_P094:
        return "error.E1570";
      case ECISReturnCodeConstants.RETURN_CODE_P095:
        return "error.E1562";
      case ECISReturnCodeConstants.RETURN_CODE_P096:
        return "error.E1608";
      case ECISReturnCodeConstants.RETURN_CODE_G050:
        return "error.E1586";
      case ECISReturnCodeConstants.RETURN_CODE_P098:
        return "error.E1611";
      case ECISReturnCodeConstants.RETURN_CODE_P100:
        return "error.E1614";
      case ECISReturnCodeConstants.RETURN_CODE_G051:
        return "error.E1615";
      case ECISReturnCodeConstants.RETURN_CODE_G052:
        return "error.E1616";
      case ECISReturnCodeConstants.RETURN_CODE_G053:
        return "error.E1617";
      case ECISReturnCodeConstants.RETURN_CODE_P101:
        return "error.E1663";
      case ECISReturnCodeConstants.RETURN_CODE_P102:
        return "error.E1657";
      case ECISReturnCodeConstants.RETURN_CODE_P103:
        return "error.E1660";
      case ECISReturnCodeConstants.RETURN_CODE_P104:
        return "error.E1661";
      case ECISReturnCodeConstants.RETURN_CODE_P105:
        return "error.E1662";
      case ECISReturnCodeConstants.RETURN_CODE_G054:
        return "error.E1628";
      case ECISReturnCodeConstants.RETURN_CODE_G055:
        return "error.E1630";
      case ECISReturnCodeConstants.RETURN_CODE_G056:
        return "error.E1629";
      case ECISReturnCodeConstants.RETURN_CODE_G057:
        return "error.E1632";
      case ECISReturnCodeConstants.RETURN_CODE_D027:
        return "error.E1652";
      case ECISReturnCodeConstants.RETURN_CODE_D028:
        return "error.E1651";
      case ECISReturnCodeConstants.RETURN_CODE_D029:
        return "error.E1655";
      case ECISReturnCodeConstants.RETURN_CODE_D030:
        return "error.E1631";
      case ECISReturnCodeConstants.RETURN_CODE_D031:
        return "error.E1658";
      case ECISReturnCodeConstants.RETURN_CODE_D032:
        return "error.E1656";
      case ECISReturnCodeConstants.RETURN_CODE_D033:
        return "error.E1494";
      case ECISReturnCodeConstants.RETURN_CODE_P106:
        return "error.E1758";
      case ECISReturnCodeConstants.RETURN_CODE_P107:
        return "error.E1759";
      case ECISReturnCodeConstants.RETURN_CODE_G058:
        return "error.E1873";
      default:
        return "error.E1129";
    }
  }

  /**
   * リターンコードに対応する画面表示メッセージIDを取得
   *
   * @param screenId
   *          スクリーンID
   * @param returnCode
   *          リターンコード
   * @return メッセージID
   */
  public static String getDisplayMessageId(String screenId, String returnCode) {
    switch (returnCode) {
      case ECISReturnCodeConstants.RETURN_CODE_D001:
        if (ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD
            .equals(screenId)) {
          return "error.E1467";
        } else {
          return "error.E1307";
        }
      case ECISReturnCodeConstants.RETURN_CODE_D002:
        if (ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD
            .equals(screenId)) {
          return "error.E1473";
        } else {
          return "error.E1062";
        }
      case ECISReturnCodeConstants.RETURN_CODE_D005:
        return "error.E1421";
      case ECISReturnCodeConstants.RETURN_CODE_D006:
        return "error.E1249";
      case ECISReturnCodeConstants.RETURN_CODE_D007:
        if (ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD
            .equals(screenId)) {
          return "error.E1474";
        } else {
          return "error.E1306";
        }
      case ECISReturnCodeConstants.RETURN_CODE_D008:
        if (ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD
            .equals(screenId)) {
          return "error.E1475";
        } else {
          return "error.E1241";
        }
      case ECISReturnCodeConstants.RETURN_CODE_D009:
        if (ECISConstants.SCREEN_ID_INQUIRY_CONTRACT.equals(screenId)) {
          return "error.E1240";
        } else if (ECISConstants.SCREEN_ID_UPDATE_CONTRACT.equals(screenId)) {
          return "error.E1222";
        } else if (ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD
            .equals(screenId)) {
          return "error.E1482";
        } else {
          return "error.E1129";
        }
      case ECISReturnCodeConstants.RETURN_CODE_D011:
        if (ECISConstants.SCREEN_ID_INQUIRY_PAYMENT.equals(screenId)) {
          return "error.E1513";
        } else if (ECISConstants.SCREEN_ID_UPDATE_PAYMENT_INFORMATION
            .equals(screenId)) {
          return "error.E1305";
        } else if (ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD
            .equals(screenId)) {
          return "error.E1248";
        } else {
          return "error.E1129";
        }
      case ECISReturnCodeConstants.RETURN_CODE_D013:
        if (ECISConstants.SCREEN_ID_UPDATE_CONTRACT.equals(screenId)) {
          return "error.E1246";
        } else if (ECISConstants.SCREEN_ID_UPDATE_PAYMENT_INFORMATION
            .equals(screenId)) {
          return "error.E1250";
        } else if (ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD
            .equals(screenId)) {
          return "error.E1456";
        } else {
          return "error.E1129";
        }
      case ECISReturnCodeConstants.RETURN_CODE_D014:
        if (ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD
            .equals(screenId)) {
          return "error.E1448";
        } else {
          return "error.E1129";
        }
      case ECISReturnCodeConstants.RETURN_CODE_D016:
        if (ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD
            .equals(screenId)) {
          return "error.E1468";
        } else {
          return "error.E1062";
        }
      case ECISReturnCodeConstants.RETURN_CODE_D017:
        if (ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD
            .equals(screenId)) {
          return "error.E1471";
        } else {
          return "error.E1251";
        }
      case ECISReturnCodeConstants.RETURN_CODE_D018:
        if (ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD
            .equals(screenId)) {
          return "error.E1453";
        } else {
          return "error.E1129";
        }
      case ECISReturnCodeConstants.RETURN_CODE_D019:
        if (ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD
            .equals(screenId)) {
          return "error.E1466";
        } else {
          return "error.E1222";
        }
      case ECISReturnCodeConstants.RETURN_CODE_D022:
        if (ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD
            .equals(screenId)) {
          return "error.E1476";
        } else if (ECISConstants.SCREEN_ID_REGIST_METER_LOCATION
            .equals(screenId)) {
          return "error.E1592";
        } else {
          return "error.E1253";
        }
      case ECISReturnCodeConstants.RETURN_CODE_D023:
        if (ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD
            .equals(screenId)) {
          return "error.E1447";
        } else if (ECISConstants.SCREEN_ID_REGIST_CONTRACTOR_INFOMATION
            .equals(screenId)) {
          return "error.E1591";
        } else if (ECISConstants.SCREEN_ID_ADD_CONTRACT.equals(screenId)
            || ECISConstants.SCREEN_ID_REGIST_METER_LOCATION.equals(screenId)) {
          return "error.E1592";
        } else {
          return "error.E1252";
        }
      case ECISReturnCodeConstants.RETURN_CODE_D024:
        if (ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD
            .equals(screenId)) {
          return "error.E1459";
        } else if (ECISConstants.SCREEN_ID_ADD_CONTRACT
            .equals(screenId)) {
          return "error.E1597";
        } else {
          return "error.E1129";
        }
      case ECISReturnCodeConstants.RETURN_CODE_D025:
        return "error.E1496";
      case ECISReturnCodeConstants.RETURN_CODE_G001:
        if (ECISConstants.SCREEN_ID_INQUIRY_CONTRACT.equals(screenId)
            || ECISConstants.SCREEN_ID_UPDATE_CONTRACT.equals(screenId)) {
          return "error.E1239";
        } else if (ECISConstants.SCREEN_ID_UPDATE_PAYMENT_INFORMATION
            .equals(screenId)) {
          return "error.E1247";
        } else if (ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD
            .equals(screenId)) {
          return "error.E1483";
        } else {
          return "error.E1129";
        }
      case ECISReturnCodeConstants.RETURN_CODE_G002:
        if (ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD
            .equals(screenId)) {
          return "error.E1031";
        } else {
          return "error.E1129";
        }
      case ECISReturnCodeConstants.RETURN_CODE_G005:
        if (ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD
            .equals(screenId)) {
          return "error.E1048";
        } else {
          return "error.E1244";
        }
      case ECISReturnCodeConstants.RETURN_CODE_G006:
        if (ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD
            .equals(screenId)) {
          return "error.E1510";
        } else if (ECISConstants.SCREEN_ID_ADD_CONTRACT
            .equals(screenId)) {
          return "error.E1600";
        } else {
          return "error.E1245";
        }
      case ECISReturnCodeConstants.RETURN_CODE_G003:
        return "error.E1035";
      case ECISReturnCodeConstants.RETURN_CODE_G004:
        return "error.E1032";
      case ECISReturnCodeConstants.RETURN_CODE_G009:
        return "error.E1247";
      case ECISReturnCodeConstants.RETURN_CODE_G010:
        if (ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD
            .equals(screenId)) {
          return "error.E1470";
        } else {
          return "error.E1129";
        }
      case ECISReturnCodeConstants.RETURN_CODE_G011:
        if (ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD
            .equals(screenId)) {
          return "error.E1449";
        } else if (ECISConstants.SCREEN_ID_REGIST_PAYMENT_INFORMATION
            .equals(screenId)) {
          return "error.E1189";
        } else {
          return "error.E1129";
        }
      case ECISReturnCodeConstants.RETURN_CODE_G017:
        if (ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD
            .equals(screenId)) {
          return "error.E1129";
        } else {
          return "error.E1129";
        }
      case ECISReturnCodeConstants.RETURN_CODE_G024:
        if (ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD
            .equals(screenId)) {
          return "error.E1452";
        } else if (ECISConstants.SCREEN_ID_REGIST_PAYMENT_INFORMATION
            .equals(screenId)) {
          return "error.E1452";
        } else {
          return "error.E1129";
        }
      case ECISReturnCodeConstants.RETURN_CODE_G026:
        return "error.E1223";
      case ECISReturnCodeConstants.RETURN_CODE_G027:
        if (ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD
            .equals(screenId)) {
          return "error.E1462";
        }
      case ECISReturnCodeConstants.RETURN_CODE_G028:
        if (ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD
            .equals(screenId)) {
          return "error.E1463";
        } else if (ECISConstants.SCREEN_ID_ADD_CONTRACT
            .equals(screenId)) {
          return "error.E1595";
        } else {
          return "error.E1129";
        }
      case ECISReturnCodeConstants.RETURN_CODE_G029:
        if (ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD
            .equals(screenId)) {
          return "error.E1465";
        } else {
          return "error.E1129";
        }
      case ECISReturnCodeConstants.RETURN_CODE_G030:
        return "error.E1418";
      case ECISReturnCodeConstants.RETURN_CODE_G031:
        return "error.E1419";
      case ECISReturnCodeConstants.RETURN_CODE_G032:
        return "error.E1420";
      case ECISReturnCodeConstants.RETURN_CODE_G033:
        return "error.E1485";
      case ECISReturnCodeConstants.RETURN_CODE_G036:
        return "error.E1490";
      case ECISReturnCodeConstants.RETURN_CODE_G037:
        return "error.E1492";
      case ECISReturnCodeConstants.RETURN_CODE_G038:
        return "error.E1501";
      case ECISReturnCodeConstants.RETURN_CODE_G039:
        if (ECISConstants.SCREEN_ID_ADD_CONTRACT
            .equals(screenId)) {
          return "error.E1596";
        } else {
          return "error.E1502";
        }
      case ECISReturnCodeConstants.RETURN_CODE_G040:
        return "error.E1503";
      case ECISReturnCodeConstants.RETURN_CODE_G041:
        return "error.E1504";
      case ECISReturnCodeConstants.RETURN_CODE_G042:
        return "error.E1508";
      case ECISReturnCodeConstants.RETURN_CODE_G043:
        return "error.E1506";
      case ECISReturnCodeConstants.RETURN_CODE_G044:
        if (ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD
            .equals(screenId)) {
          return "error.E1526";
        } else {
          return "error.E1524";
        }
      case ECISReturnCodeConstants.RETURN_CODE_G045:
        if (ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD
            .equals(screenId)) {
          return "error.E1527";
        } else {
          return "error.E1525";
        }
      case ECISReturnCodeConstants.RETURN_CODE_G046:
        return "error.E1575";
      case ECISReturnCodeConstants.RETURN_CODE_P003:
        if (ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD
            .equals(screenId)) {
          return "error.E1448";
        } else {
          return "error.E1129";
        }
      case ECISReturnCodeConstants.RETURN_CODE_P005:
        if (ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD
            .equals(screenId)) {
          return "error.E1461";
        } else {
          return "error.E1129";
        }
      case ECISReturnCodeConstants.RETURN_CODE_P007:
        if (ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD
            .equals(screenId)) {
          return "error.E1453";
        } else {
          return "error.E1129";
        }
      case ECISReturnCodeConstants.RETURN_CODE_P008:
        if (ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD
            .equals(screenId)) {
          return "error.E1457";
        } else {
          return "error.E1129";
        }
      case ECISReturnCodeConstants.RETURN_CODE_P010:
        if (ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD
            .equals(screenId)) {
          return "error.E1472";
        } else {
          return "error.E1129";
        }
      case ECISReturnCodeConstants.RETURN_CODE_P011:
        if (ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD
            .equals(screenId)) {
          return "error.E1469";
        } else {
          return "error.E1129";
        }
      case ECISReturnCodeConstants.RETURN_CODE_P012:
        if (ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD.equals(screenId)
            || ECISConstants.SCREEN_ID_UPDATE_ACCOUNTCREDIT.equals(screenId)) {
          return "error.E1455";
        } else {
          return "error.E1129";
        }
      case ECISReturnCodeConstants.RETURN_CODE_P026:
        return "error.E1593";
      case ECISReturnCodeConstants.RETURN_CODE_P064:
        return "error.E1242";
      case ECISReturnCodeConstants.RETURN_CODE_P065:
        return "error.E1243";
      case ECISReturnCodeConstants.RETURN_CODE_P066:
        if (ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD
            .equals(screenId)) {
          return "error.E1451";
        } else if (ECISConstants.SCREEN_ID_REGIST_PAYMENT_INFORMATION
            .equals(screenId)) {
          return "error.E1598";
        } else {
          return "error.E1129";
        }
      case ECISReturnCodeConstants.RETURN_CODE_P069:
        if (ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD
            .equals(screenId)) {
          return "error.E1464";
        } else {
          return "error.E1129";
        }
      case ECISReturnCodeConstants.RETURN_CODE_H001:
        return "warn.W1011";
      case ECISReturnCodeConstants.RETURN_CODE_P091:
        return "error.E1563";
      case ECISReturnCodeConstants.RETURN_CODE_P092:
        return "error.E1566";
      case ECISReturnCodeConstants.RETURN_CODE_P093:
        return "error.E1568";
      case ECISReturnCodeConstants.RETURN_CODE_P094:
        return "error.E1570";
      case ECISReturnCodeConstants.RETURN_CODE_P095:
        return "error.E1562";
      case ECISReturnCodeConstants.RETURN_CODE_G047:
        if (ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD
            .equals(screenId)) {
          return "error.E1602";
        } else {
          return "error.E1560";
        }
      case ECISReturnCodeConstants.RETURN_CODE_G048:
        if (ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD
            .equals(screenId)) {
          return "error.E1603";
        } else {
          return "error.E1561";
        }
      case ECISReturnCodeConstants.RETURN_CODE_G050:
        if (ECISConstants.SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD
            .equals(screenId)) {
          return "error.E1587";
        } else {
          return "error.E1585";
        }
      case ECISReturnCodeConstants.RETURN_CODE_P001:
        return "error.E1065";
      case ECISReturnCodeConstants.RETURN_CODE_P101:
        return "error.E1663";
      case ECISReturnCodeConstants.RETURN_CODE_P102:
        return "error.E1657";
      case ECISReturnCodeConstants.RETURN_CODE_P103:
        return "error.E1660";
      case ECISReturnCodeConstants.RETURN_CODE_P104:
        return "error.E1661";
      case ECISReturnCodeConstants.RETURN_CODE_P105:
        return "error.E1662";
      case ECISReturnCodeConstants.RETURN_CODE_G054:
        return "error.E1628";
      case ECISReturnCodeConstants.RETURN_CODE_G055:
        return "error.E1630";
      case ECISReturnCodeConstants.RETURN_CODE_G056:
        return "error.E1629";
      case ECISReturnCodeConstants.RETURN_CODE_G057:
        return "error.E1632";
      case ECISReturnCodeConstants.RETURN_CODE_D027:
        return "error.E1652";
      case ECISReturnCodeConstants.RETURN_CODE_D028:
        return "error.E1651";
      case ECISReturnCodeConstants.RETURN_CODE_D029:
        return "error.E1655";
      case ECISReturnCodeConstants.RETURN_CODE_D030:
        return "error.E1631";
      case ECISReturnCodeConstants.RETURN_CODE_D031:
        return "error.E1658";
      case ECISReturnCodeConstants.RETURN_CODE_D032:
        return "error.E1656";
      case ECISReturnCodeConstants.RETURN_CODE_D033:
        return "error.E1494";
      case ECISReturnCodeConstants.RETURN_CODE_P107:
        return "error.E1759";
      case ECISReturnCodeConstants.RETURN_CODE_G058:
        return "error.E1873";

      default:
        return "error.E1129";
    }
  }
}
