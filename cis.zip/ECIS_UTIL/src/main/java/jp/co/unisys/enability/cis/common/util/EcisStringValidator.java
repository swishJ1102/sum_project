package jp.co.unisys.enability.cis.common.util;

import com.opensymphony.xwork2.validator.ValidationException;
import com.opensymphony.xwork2.validator.validators.FieldValidatorSupport;

/**
 * 低圧CIS許容文字バリデータ。
 *
 * <pre>
 * <p><b>【仕様詳細】<b><p>
 * strutsバリデーションで低圧CIS許容文字チェックを行うためのクラス。
 * </pre>
 *
 *
 * @author "Nihon Unisys, Ltd."
 *
 */
public class EcisStringValidator extends FieldValidatorSupport {

  /*
   * (非 Javadoc)
   *
   * @see
   * com.opensymphony.xwork2.validator.Validator#validate(java.lang.Object)
   */
  @Override
  public void validate(Object object) throws ValidationException {

    Object value = this.getFieldValue(this.getFieldName(), object);
    if (value != null
        && !CommonValidationUtil.isRangeWordByECIS(value.toString())) {
      addFieldError(getFieldName(), object);
    }

  }

}
