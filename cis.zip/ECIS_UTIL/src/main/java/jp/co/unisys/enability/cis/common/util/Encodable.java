/*-------------------------------------------------------------------------------
 * All Rights Reserved. Copyright(C) Nihon Unisys, Ltd.
 * vendor : Nihon Unisys, Ltd.
 * since : 2015/04/20 【ph3開発】経理帳票対応
 *-----------------------------------------------------------------------------*/
package jp.co.unisys.enability.cis.common.util;

import java.io.Serializable;

/**
 * enumのキー値の型を宣言するインターフェース<br>
 * ジェネリクスで指定された型をキーに持つことを保証する
 * 
 * @param <T>
 *          コードのキー値型
 */
public interface Encodable<T extends Serializable> {

  /**
   * 宣言された型のコードを返す
   * 
   * @return
   */
  T encode();
}
