package jp.co.unisys.enability.cis.common.util;

import java.util.Calendar;
import java.util.Date;

/**
 *
 * 日付計算ユーティリティ<br>
 * <p>
 * <p>
 * <b>【仕様詳細】<b>
 * <p>
 * 引数の情報を基に日付の計算を行う。
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 *
 */
public class DateCalculateUtil {

  /**
   * 引数の日付を指定された年、月、日の数分、加算した結果を返却する。<br>
   * 減算する場合はマイナス値を設定して使用する。
   *
   * @param targetDate
   *          コンテキスト
   * @param valueObj
   *          引数
   * @param toClass
   *          変換後の型
   *
   * @return 日付オブジェクト
   */
  public static Date calculateDate(Date targetDate, int yearAmount, int monthAmount, int dayAmount) {
    // インスタンス取得
    Calendar calendar = Calendar.getInstance();
    // 対象の日付を設定
    calendar.setTime(targetDate);

    // 年を加算
    calendar.add(Calendar.YEAR, yearAmount);
    // 月を加算
    calendar.add(Calendar.MONTH, monthAmount);
    // 日を加算
    calendar.add(Calendar.DATE, dayAmount);

    // 計算結果を返却
    return calendar.getTime();
  }

  /**
   * 引数の日付の月末日を返却する。
   *
   * @param targetDate
   *          日付
   *
   * @return 日付オブジェクト
   */
  public static Date getEndOfMonth(Date targetDate) {
    // インスタンス取得
    Calendar calendar = Calendar.getInstance();
    // 対象の日付を設定
    calendar.setTime(targetDate);

    // 月末日を取得して設定
    int lastDay = calendar.getActualMaximum(Calendar.DATE);
    calendar.set(Calendar.DATE, lastDay);

    // 計算結果を返却
    return calendar.getTime();
  }
}
