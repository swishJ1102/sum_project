/*-------------------------------------------------------------------------------
 * All Rights Reserved. Copyright(C) Nihon Unisys, Ltd.
 * vendor : Nihon Unisys, Ltd.
 * since : 2014/09/01
 *-----------------------------------------------------------------------------*/
package jp.co.unisys.enability.cis.common.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.config.PropertiesFactoryBean;

/**
 * JSON用ユーティリティクラス。
 *
 * <pre>
 * <p><b>【仕様詳細】<b><p>
 * JSONに係る以下の共通処理を行う。
 * ・ソート
 * ・JSONファイル出力
 * ・JSONファイル入力
 * ・一覧チェックボックス制御
 * </pre>
 *
 *
 * @author "Nihon Unisys, Ltd."
 *
 */
public class JSONUtil {

  /** プロパティ */
  private static PropertiesFactoryBean applicationProperties;

  /**
   * 引数のJSONリストを引数のコンパレータに従って並べ替えを行う.
   *
   * @param array
   *          ソート対象JSONArray
   * @param c
   *          コンパレータ
   * @return ソート実行後のJSONArray
   */
  public static JSONArray sort(JSONArray array, Comparator<JSONObject> c) {
    List asList = new ArrayList(array.length());
    for (int i = 0; i < array.length(); i++) {
      asList.add(array.opt(i));
    }
    Collections.sort(asList, c);
    JSONArray res = new JSONArray();
    for (Object o : asList) {
      res.put(o);
    }
    return res;
  }

  /**
   * JSONファイル出力。
   *
   * <pre>
   * <p><b>【仕様詳細】<b><p>
   * 検索結果をAJAXが利用できるようにJSON形式に変換してファイル出力する。
   * １．プロパティファイルより{@link
   * EMSPropertyResource
   * #SEARCHFILE_JSONDATA_WORK_DIR_KEY JSONファイル出力パスKEY}を基にJSONファイル出力パスを取得する。
   * ２．ディレクトリ存在チェックを行い、存在しない場合はディレクトリを生成する。
   * ３．引数のリストハッシュマップをJSONObjectに変換し、
   * {@link EMSConstants#COLUMN_NAME_ROWID 行番号}を追加する。
   * 生成したJSONObjectをJSONArrayに追加する。
   * 引数のリストハッシュマップの長さ分、本処理を繰り返す。
   * ４．３で生成したJSONArrayを引数のJSONリスト名でJSONObjectに設定し、
   * JSONObjectを引数のJSONファイル名のファイルに出力する。
   *
   * </pre>
   *
   * @param jsonBaseList
   *          JSON形式変換対象リスト
   * @param fileName
   *          JSONファイル名
   * @param jsonListName
   *          JSONリスト名
   * @throws Exception
   */
  public static void createJSONDataFile(
      List<HashMap<String, String>> jsonBaseList, String fileName,
      String jsonListName) throws Exception {

    // プロパティファイルから取得
    Properties prop = applicationProperties.getObject();
    String filepath = prop
        .getProperty(EMSPropertyResource.SEARCHFILE_JSONDATA_WORK_DIR_KEY);

    File dir = null;
    dir = new File(filepath);
    if (!dir.exists()) {
      dir.mkdirs();
    }

    try (BufferedWriter bw = new BufferedWriter(new FileWriter(new File(
        filepath.concat(fileName))))) {

      JSONArray json = new JSONArray();

      for (int i = 0; i < jsonBaseList.size(); i++) {
        Map<String, String> recordMap = jsonBaseList.get(i);

        JSONObject jsonObj = new JSONObject(recordMap);

        // 行番号
        jsonObj.put(EMSConstants.COLUMN_NAME_ROWID, String.valueOf(i));

        json.put(jsonObj);

      }

      JSONObject obj = new JSONObject();
      obj.put(jsonListName, json);
      obj.write(bw);
      bw.flush();
    }

  }

  /**
   * JSONファイル入力。
   *
   * <pre>
   * <p><b>【仕様詳細】<b><p>
   * JSON形式データの読み込み共通処理。
   * １．プロパティファイルより{@link
   * EMSPropertyResource
   * #SEARCHFILE_JSONDATA_WORK_DIR_KEY JSONファイル出力パスKEY}を基にJSONファイル出力パスを取得する。
   * ２．１で取得したJSONファイル出力パスから、引数のJSONファイル名のファイルを読み込む。
   * ファイルが存在しない場合は処理を終了し、空のリストハッシュマップを返却する。
   * ３．２で読み込んだ内容をJSONObjectに変換する。
   * 変換したJSONObjectから引数のJSONリスト名でJSONArrayを取得する。
   * ４．引数のソートクラスタイプを基に、以下のコンパレータ生成処理を行う。
   *     ・ソートクラスタイプがStringの場合
   *       {@link JSONComparator}を生成する。
   *     ・ソートクラスタイプがIntegerの場合
   *       {@link JSONIntegerComparator}を生成する。
   *     ・ソートクラスタイプがBigDecimalの場合
   *       {@link JSONBigDecimalComparator}を生成する。
   *     ・上記以外の場合
   *       例外をスローする。
   * ５．引数のソート順と４で生成したコンパレータを利用して、３で取得したJSONArrayのソートを行う。
   * ６．JSONArrayからJSONObjectを取得し、JSONObjectのキーと値をリストハッシュマップに
   * 詰め替えていく。JSONArrayの長さ分、本処理を繰り返す。
   * ７．６で詰め替えたリストハッシュマップを返却する。
   * </pre>
   *
   * @param fileName
   *          JSONファイル名
   * @param jsonListName
   *          JSONリスト名
   * @param sortColum
   *          ソート対象カラム
   * @param sortDir
   *          ソート順（ASC or DESC）
   * @param classType
   *          ソートクラスタイプ（String or Integer or BigDecimal）
   * @return 画面表示用リストマップデータ
   * @throws Exception
   *           引数のソートクラスタイプに許容外のクラスを指定した場合
   */
  public static List<HashMap<String, String>> readJSONDataFile(
      String fileName, String jsonListName, String sortColum,
      String sortDir, Class<?> classType) throws Exception {

    // プロパティファイルから取得
    Properties prop = applicationProperties.getObject();
    String filepath = prop
        .getProperty(EMSPropertyResource.SEARCHFILE_JSONDATA_WORK_DIR_KEY);

    List<HashMap<String, String>> result = new ArrayList<HashMap<String, String>>();

    String line = null;
    StringBuilder sb = new StringBuilder();

    try (BufferedReader br = new BufferedReader(new FileReader(new File(
        filepath.concat(fileName))))) {

      while ((line = br.readLine()) != null) {
        sb.append(line);
      }
    } catch (FileNotFoundException fnfe) {
      return result;
    }

    JSONObject obj = new JSONObject(sb.toString());
    JSONArray array = obj.getJSONArray(jsonListName);

    // コンパレータオブジェクトの生成
    // 数値比較対象とそれ以外でオブジェクトを分ける
    Comparator<JSONObject> c;
    if (classType.isAssignableFrom(String.class)) {
      c = new JSONComparator(sortColum);
    } else if (classType.isAssignableFrom(Integer.class)) {
      c = new JSONIntegerComparator(sortColum);
    } else if (classType.isAssignableFrom(BigDecimal.class)) {
      c = new JSONBigDecimalComparator(sortColum);
    } else {
      // String, Integer, BigDecimal以外の指定がなされた場合はエラーとする
      throw new IllegalArgumentException();
    }

    // ソート順序の指定
    if (sortDir.equals(EMSConstants.VIEW_SORT_ASC)) {
      array = JSONUtil.sort(array, c);
    } else {
      array = JSONUtil.sort(array, Collections.reverseOrder(c));
    }

    for (int i = 0; i < array.length(); i++) {
      JSONObject json = array.getJSONObject(i);
      Set<String> keys = json.keySet();

      Iterator<String> it = keys.iterator();
      HashMap<String, String> map = new HashMap<String, String>();
      while (it.hasNext()) {
        String key = it.next();
        map.put(key, json.getString(key));
      }

      result.add(map);
    }

    return result;
  }

  /**
   * 一覧チェックボックス制御。
   *
   * <pre>
   * <p><b>【仕様詳細】<b><p>
   * チェックボックス含有JSON形式データの再出力処理を行う。
   * １．プロパティファイルより{@link
   * EMSPropertyResource
   * #SEARCHFILE_JSONDATA_WORK_DIR_KEY JSONファイル出力パスKEY}を基にJSONファイル出力パスを取得する。
   * ２．１で取得したJSONファイル出力パスから引数のJSONデータファイル名のファイルを読み込む。
   * ファイルが存在しない場合は処理を終了し、nullを返却する。
   * ３．２で読み込んだ内容をJSONObjectに変換する。
   * 変換したJSONObjectから引数のJSONリスト名でJSONArray（以降、旧JSONArray）を取得する。
   * 上記とは別のJSONArray（以降、新JSONArray）のインスタンスを生成する。
   * ４．引数の全項目チェックフラグおよび、引数の項目チェックマップの状態により、
   * 以下の処理を行う。
   *     ・全項目チェックフラグがNULL、空文字である
   *       かつ
   *       項目チェックマップがNULLまたは空でない場合
   *         新JSONArrayに旧JSONArrayの内容を設定する。
   *     ・全項目チェックフラグがNULL、空文字でない場合
   *         旧JSONArrayからJSONObjectを取得し、チェックボックスカラムの値を全てON（1)に書き換えて
   *         新JSONArrayに設定する。旧JSONArrayの長さ分、本処理を繰り返す。
   *     ・上記以外の場合
   *         旧JSONArrayからJSONObjectを取得し、項目チェックマップのチェックON（1）となっている項目に該当する
   *         JSONObjectのみを書き換えて新JSONArrayに設定する。旧JSONArrayの長さ分、本処理を繰り返す。
   * ５．４で値を設定した新JSONArrayでJSONデータファイルを上書きする。
   * ６．新JSONArrayを返却する。
   * </pre>
   *
   * @param fileName
   *          JSONデータファイル名
   * @param jsonListName
   *          JOSNリストファイル名
   * @param allCheckFlag
   *          全項目チェックフラグ
   * @param checkMap
   *          項目チェックマップ
   * @param checkBoxColum
   *          チェックボックスカラム
   * @return チェック状態反映後のJSONArray
   * @throws Exception
   */
  public static JSONArray rewriteJSONDataFileForCheckBoxColumn(
      String fileName, String jsonListName, String allCheckFlag,
      Map<String, String> checkMap, String checkBoxColum)
      throws Exception {

    // プロパティから取得
    Properties prop = applicationProperties.getObject();
    String filePath = prop
        .getProperty(EMSPropertyResource.SEARCHFILE_JSONDATA_WORK_DIR_KEY);

    String fileFullPath = filePath.concat(fileName);

    // JSONファイル読み込み処理
    String line = null;
    StringBuilder sb = new StringBuilder();

    try (BufferedReader br = new BufferedReader(new FileReader(new File(
        fileFullPath)));) {

      while ((line = br.readLine()) != null) {
        sb.append(line);
      }
    } catch (FileNotFoundException fnfe) {
      return null;
    }

    JSONObject obj = new JSONObject(sb.toString());
    JSONArray oldArray = obj.getJSONArray(jsonListName);
    JSONArray newArray = new JSONArray();

    // JSONファイル書き換え
    if (StringUtils.isEmpty(allCheckFlag)
        && (checkMap == null || checkMap.isEmpty())) {
      newArray = oldArray;
    } else if (!StringUtils.isEmpty(allCheckFlag)) {
      // 全選択フラグ値あり
      for (int i = 0; i < oldArray.length(); i++) {
        JSONObject tempObj = oldArray.getJSONObject(i);
        tempObj.put(checkBoxColum, allCheckFlag);
        newArray.put(tempObj);
      }
    } else {
      for (int i = 0; i < oldArray.length(); i++) {
        JSONObject tempObj = oldArray.getJSONObject(i);
        String rowid = String.valueOf(tempObj
            .get(EMSConstants.COLUMN_NAME_ROWID));
        if (checkMap.containsKey(rowid)) {
          tempObj.put(checkBoxColum, checkMap.get(rowid));
        }
        newArray.put(tempObj);
      }
    }

    try (BufferedWriter bw = new BufferedWriter(new FileWriter(new File(
        fileFullPath)))) {
      JSONObject writer = new JSONObject();
      writer.put(jsonListName, newArray);

      writer.write(bw);

      bw.flush();
    }

    return newArray;
  }

  public void setApplicationProperties(
      PropertiesFactoryBean applicationProperties) {
    this.applicationProperties = applicationProperties;
  }

}
