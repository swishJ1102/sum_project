/*-------------------------------------------------------------------------------
 * All Rights Reserved. Copyright(C) Nihon Unisys, Ltd.
 * vendor : Nihon Unisys, Ltd.
 * since : 2014/09/01
 *-----------------------------------------------------------------------------*/
package jp.co.unisys.enability.cis.common.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import com.opensymphony.xwork2.validator.ValidationException;
import com.opensymphony.xwork2.validator.validators.FieldValidatorSupport;

public class DateFormateYmValidator extends FieldValidatorSupport {

  /** フィールド名 */
  private String fieldName;

  @Override
  public void validate(Object object) throws ValidationException {

    // 入力値を取得する。
    Object value = this.getFieldValue(fieldName, object);

    // 入力値がある場合、チェックを行う。
    if (value != null && !String.valueOf(value).isEmpty()) {

      //			String inputStr = String.valueOf(value).trim().replace("/", "");
      String inputStr = String.valueOf(value);

      // 年月の入力形式は6文字
      //			if (inputStr.length() != 6) {
      if (inputStr.length() != 7) {

        this.addFieldError(fieldName, object);
        return;
      } else {

        // 01を付加してyyyyMMdd形式にする
        String dateStr = inputStr.concat("/01");

        // yyyy/MM/dd形式チェック
        //				SimpleDateFormat format = new SimpleDateFormat(EMSConstants.FORMAT_DATE_yyyyMMdd);
        SimpleDateFormat format = new SimpleDateFormat(EMSConstants.FORMAT_DATE_yyyyMMdd_SLASH);

        format.setLenient(false);

        try {

          format.parse(dateStr);

        } catch (ParseException e) {

          this.addFieldError(fieldName, object);
        }
      }

    }
  }

  /**
   * fieldNameのゲッター
   * 
   * @return fieldName
   */
  public String getFieldName() {
    return fieldName;
  }

  /**
   * fieldNameのセッター
   * 
   * @param fieldName
   *          セットする fieldName
   */
  public void setFieldName(String fieldName) {
    this.fieldName = fieldName;
  }

}
