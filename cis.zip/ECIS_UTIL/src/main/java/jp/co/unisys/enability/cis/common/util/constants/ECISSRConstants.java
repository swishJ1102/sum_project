package jp.co.unisys.enability.cis.common.util.constants;

/**
 * 定数クラス
 *
 * @author "Nihon Unisys, Ltd."
 */
public class ECISSRConstants {

  /** MDMS連携ステータスコード：連携未 */
  public static final String MDMS_LINKAGE_STATUS_CODE_NOLINKAGE = "0";
  /** MDMS連携ステータスコード：連携済 */
  public static final String MDMS_LINKAGE_STATUS_CODE_LINKAGE = "1";
  /** MDMS連携ステータスコード：連携失敗 */
  public static final String MDMS_LINKAGE_STATUS_CODE_ERROR = "9";
  /** MDMS連携ファイル種別コード：低圧月間確定使用量CSVファイル */
  public static final String MDMS_LINKAGE_FILE_CATEGORY_M_LOW_TENSION_FIXUSAGE = "W51220";
  /** DB取込ステータスコード：取込未 */
  public static final String DB_IMPORT_STATUS_CODE_NOIMPORT = "0";
  /** DB取込ステータスコード：取込済 */
  public static final String DB_IMPORT_STATUS_CODE_IMPORT = "1";
  /** DB取込ステータスコード：取込失敗 */
  public static final String DB_IMPORT_STATUS_CODE_ERROR = "9";
  /** 連携ファイル一覧CSVの連携ファイル名のファイルセパレータ */
  public static final String LINKAGE_FILE_PATH_SEPARATOR = "/";
  /** 低圧月間確定使用量集信対象一覧作成バッチ：MDMS連携管理情報取得_ソート条件定数 */
  public static final String SR010206_SELECT_MDMSLINKAGE_ORDER_QUERY = "pps_cat ASC, area_code ASC, mdms_file_name ASC";
  /** ハイフンなし処理ID：契約電力算定結果内訳帳票アップロード */
  public static final String NO_HYPHEN_PRCESS_ID_SR050101 = "SR050101";
  /** ハイフンなし処理ID：調定データアップロード */
  public static final String NO_HYPHEN_PRCESS_ID_SR050201 = "SR050201";
  /** 契約電力算定結果内訳帳票ファイル：CSVファイルリスト項目順：レコード区分 */
  public static final int CONSIGNMENTCCAFILE_CSV_REC_CATEGORY = 0;
  /** 契約電力算定結果内訳帳票ファイル：CSVファイルリスト項目順（ヘッダ）：情報区分 */
  public static final int CONSIGNMENTCCAFILE_CSV_HEADER_INFO = 1;
  /** 契約電力算定結果内訳帳票ファイル：CSVファイルリスト項目順（ヘッダ）：対象年月 */
  public static final int CONSIGNMENTCCAFILE_CSV_TARGET_DATE = 2;
  /** 契約電力算定結果内訳帳票ファイル：CSVファイルリスト項目順（ヘッダ）：送信者名称 */
  public static final int CONSIGNMENTCCAFILE_CSV_SENDER_NAME = 4;
  /** 契約電力算定結果内訳帳票ファイル：CSVファイルリスト項目順（データ）：供給地点特定番号 */
  public static final int CONSIGNMENTCCAFILE_CSV_PROVIDE_POINT_NO = 1;
  /** 契約電力算定結果内訳帳票ファイル：CSVファイルリスト項目順（データ）：算定期間開始日 */
  public static final int CONSIGNMENTCCAFILE_CSV_CALC_PERIOD_START = 3;
  /** 契約電力算定結果内訳帳票ファイル：CSVファイルリスト項目順（データ）：接続送電サービス契約電力 */
  public static final int CONSIGNMENTCCAFILE_CSV_AGR_ELEC_ENE = 5;
  /** 契約電力算定結果内訳帳票ファイル：ヘッダレコード終了行 */
  public static final int CONSIGNMENTCCAFILE_CSV_HEADER_REC_END = 2;
  /** 契約電力算定結果内訳帳票ファイル：タイトルレコード終了行 */
  public static final int CONSIGNMENTCCAFILE_CSV_TITLE_REC_END = 3;
  /** 契約電力算定結果内訳帳票ファイル：データレコード開始行 */
  public static final int CONSIGNMENTCCAFILE_CSV_DATA_REC_START = 4;
  /** 契約電力算定結果内訳帳票ファイル：ヘッダレコード行（データ） */
  public static final int CONSIGNMENTCCAFILE_CSV_HEADER_REC_DATA = 1;
  /** 契約容量単位コード：アンペア */
  public static final String CCA_UNIT_CODE_AMPERE = "A";
  /** 仕訳フラグ：実施する */
  public static final String SKIP_CATEGORIZE_ON = "0";
  /** 情報区分コード：共通情報 */
  public static final String INFO_CAT_CODE_COMMON = "1220";
  /** 識別コード：供給地点特定番号情報 */
  public static final String CLASS_CODE_SPOTNO_INFO = "001";
  /** 識別コード：計器情報 */
  public static final String CLASS_CODE_METER_INFO = "011";
  /** 識別コード：確定使用量 */
  public static final String CLASS_CODE_FIX_USAGE = "012";
  /** 識別コード：月間使用量 */
  public static final String CLASS_CODE_MONTHLY_USAGE = "013";
  /** 連携ファイルxmlタグ 対象年月 */
  public static final String XML_TAG_COVERED_PERIOD = "JP06401";
  /** 連携ファイルxmlタグ 送信者コード */
  public static final String XML_TAG_COMPANY_CODE = "JP06110";
  /** 連携ファイルxmlタグ 送信者名称 */
  public static final String XML_TAG_COMPANY_NAME = "JP06111";
  /** 連携ファイルxmlタグ 受信者コード */
  public static final String XML_TAG_RETAILER_CODE = "JP06112";
  /** 連携ファイルxmlタグ 受信者名称 */
  public static final String XML_TAG_RETAILER_NAME = "JP06113";
  /** 連携ファイルxmlタグ 供給地点特定番号情報 */
  public static final String XML_TAG_SPOTNO_INFO = "JPM00010";
  /** 連携ファイルxmlタグ 供給地点特定番号情報リスト */
  public static final String XML_TAG_SPOTNO_INFO_LIST = "JPMR00010";
  /** 連携ファイルxmlタグ 供給地点特定番号 */
  public static final String XML_TAG_SPOTNO = "JP06400";
  /** 連携ファイルxmlタグ 需要家識別番号 */
  public static final String XML_TAG_CONTRACTOR_ID_NO = "JP06119";
  /** 連携ファイルxmlタグ 需要者名称 */
  public static final String XML_TAG_CONTRACTOR_NAME = "JP06120";
  /** 連携ファイルxmlタグ 供給場所 */
  public static final String XML_TAG_PLACE = "JP06402";
  /** 連携ファイルxmlタグ 電圧区分 */
  public static final String XML_TAG_VOLTAGE_CAT_NAME = "JP06403";
  /** 連携ファイルxmlタグ 仕訳コード */
  public static final String XML_TAG_CATEGORIZE_CODE = "JP06404";
  /** 連携ファイルxmlタグ 提供可否コード */
  public static final String XML_TAG_PROVIDE_CHECK_CODE = "JP06405";
  /** 連携ファイルxmlタグ 更新コード */
  public static final String XML_TAG_UPDATE_CODE = "JP06444";
  /** 連携ファイルxmlタグ 計器情報 */
  public static final String XML_TAG_METER_INFO = "JPM00011";
  /** 連携ファイルxmlタグ 計器情報リスト */
  public static final String XML_TAG_METER_INFO_LIST = "JPMR00011";
  /** 連携ファイルxmlタグ 計器区分コード */
  public static final String XML_TAG_METER_CATEGORY_CODE = "JP06407";
  /** 連携ファイルxmlタグ 全量 */
  public static final String XML_TAG_All_METER = "JPM00012";
  /** 連携ファイルxmlタグ 全量リスト */
  public static final String XML_TAG_All_METER_LIST = "JPMR00012";
  /** 連携ファイルxmlタグ 計器識別番号 */
  public static final String XML_TAG_METER_ID_NO = "JP06408";
  /** 連携ファイルxmlタグ 乗率 */
  public static final String XML_TAG_MULTIPLYING_FACTOR = "JP06409";
  /** 連携ファイルxmlタグ 電力損失補正率 */
  public static final String XML_TAG_KW_DISADVANTAGE_FACTOR = "JP06410";
  /** 連携ファイルxmlタグ 電力量損失補正率 */
  public static final String XML_TAG_KWH_DISADVANTAGEFACTOR = "JP06411";
  /** 連携ファイルxmlタグ 最大需要電力 */
  public static final String XML_TAG_PEAK_DEMAND = "JP06412";
  /** 連携ファイルxmlタグ 最大需要電力当月指示数 */
  public static final String XML_TAG_PEAK_DEMAND_CURRENT_INDICATIONNO = "JP06413";
  /** 連携ファイルxmlタグ 全日電力量指示数 */
  public static final String XML_TAG_FULL_TIME_USAGE_INDICATIONNO = "JPM00015";
  /** 連携ファイルxmlタグ 全日電力量指示数リスト */
  public static final String XML_TAG_FULL_TIME_USAGE_INDICATIONNO_LIST = "JPMR00015";
  /** 連携ファイルxmlタグ 全日電力量前月指示数 */
  public static final String XML_TAG_FULL_TIME_USAGE_PREVIOUS_INDICATIONNO = "JP06414";
  /** 連携ファイルxmlタグ 全日電力量当月指示数 */
  public static final String XML_TAG_FULL_TIME_USAGE_CURRENT_INDICATIONNO = "JP06415";
  /** 連携ファイルxmlタグ 力測有効電力量前月末指示数 */
  public static final String XML_TAG_EFFECTIVE_PREVIOUS_INDICATIONNO = "JP06416";
  /** 連携ファイルxmlタグ 力測有効電力量当月末指示数 */
  public static final String XML_TAG_EFFECTIVE_CURRENT_INDICATIONNO = "JP06417";
  /** 連携ファイルxmlタグ 力測無効電力量前月末指示数 */
  public static final String XML_TAG_REACTIVE_PREVIOUS_INDICATIONNO = "JP06418";
  /** 連携ファイルxmlタグ 力測無効電力量当月末指示数 */
  public static final String XML_TAG_REACTIVE_CURRENT_INDICATIONNO = "JP06419";
  /** 連携ファイルxmlタグ 最大需要電力仕訳後 */
  public static final String XML_TAG_CATEGORIZED_PEAK_DEMAND = "JP06420";
  /** 連携ファイルxmlタグ 力測有効電力量 */
  public static final String XML_TAG_EFFECTIVE_POWER_CONSUMPTION = "JP06421";
  /** 連携ファイルxmlタグ 力測無効電力量 */
  public static final String XML_TAG_REACTIVE_POWER_CONSUMPTION = "JP06422";
  /** 連携ファイルxmlタグ 確定使用量情報 */
  public static final String XML_TAG_FIX_USAGE_INFO = "JPM00013";
  /** 連携ファイルxmlタグ 確定使用量リスト */
  public static final String XML_TAG_FIX_USAGE_INFO_LIST = "JPMR00013";
  /** 連携ファイルxmlタグ 確定使用量対象年月日 */
  public static final String XML_TAG_FIX_USAGE_COVERED_PERIOD = "JP06423";
  /** 連携ファイルxmlタグ 確定使用量詳細 */
  public static final String XML_TAG_FIX_USAGE_DETAILS = "JPM00014";
  /** 連携ファイルxmlタグ 確定使用量詳細リスト */
  public static final String XML_TAG_FIX_USAGE_DETAILS_LIST = "JPMR00014";
  /** 連携ファイルxmlタグ 時刻コード */
  public static final String XML_TAG_TIME_CODE = "JP06219";
  /** 連携ファイルxmlタグ 30分電力量全量 */
  public static final String XML_TAG_TOTAL_KWH = "JP06424";
  /** 連携ファイルxmlタグ 30分電力量仕訳後 */
  public static final String XML_TAG_CATEGORIZED_KWH = "JP06425";
  /** 連携ファイルxmlタグ 月間電力量全量 */
  public static final String XML_TAG_MONTHLY_TOTAL_KWH = "JP06426";
  /** 連携ファイルxmlタグ 月間電力量仕訳後 */
  public static final String XML_TAG_MONTHLY_CATEGORIZED_KWH = "JP06427";
  /** 連携ファイルxmlタグ 力率 */
  public static final String XML_TAG_POWER_FACTOR = "JP06406";
  /** 連携ファイルxmlタグ 地点の最大需要電力 */
  public static final String XML_TAG_SPOT_PEAK_DEMAND = "JP06445";
  /** 連携ファイルxmlタグ 次回検針日 */
  public static final String XML_TAG_NEXT_METER_READING_DATE = "JP06446";
  /** 確定使用量連携ファイル 0バイトファイル名 */
  public static final String LINKAGEFILE_DUMMY_FILE_NAME = "dummy.zip";
  /** 供電種別:低圧 */
  public static final String SUPPLY_POWER_CLASS_LOW_VOLTAGE = "10";
  /** グルーピングIDの接頭辞:"G" */
  public static final String GROUPING_ID_PREFIX = "G";
  /** MDMS連携ファイル種別コード：高圧月間確定使用量CSVファイル */
  public static final String MDMS_LINKAGE_FILE_CATEGORY_M_HIGH_TENSION_FIXUSAGE = "W51210";
  /** 連携ファイル管理種別コード：高圧計量器交換ファイル */
  public static final String LINKAGE_FILE_CATEGORY_M_HIGH_TENSION_METER_CHANGE_FILE = "W51310";
  /** 連携ファイル管理種別コード：高圧臨時検針ファイル */
  public static final String LINKAGE_FILE_CATEGORY_M_HIGH_TENSION_SPECIAL_METER_READING_FILE = "W51410";
  /** 連携ファイル管理種別コード：低圧計量器交換ファイル */
  public static final String LINKAGE_FILE_CATEGORY_M_LOW_TENSION_METER_CHANGE_FILE = "W51320";
  /** 連携ファイル管理種別コード：低圧臨時検針ファイル */
  public static final String LINKAGE_FILE_CATEGORY_M_LOW_TENSION_SPECIAL_METER_READING_FILE = "W51420";
  /** MDMS連携ファイル種別コード：低圧月間確定発電量CSVファイル */
  public static final String MDMS_LINKAGE_FILE_CATEGORY_M_LOW_TENSION_FIXGENERATION = "W51920";
  /** MDMS連携ファイル種別コード：高圧月間確定発電量CSVファイル */
  public static final String MDMS_LINKAGE_FILE_CATEGORY_M_HIGH_TENSION_FIXGENERATION = "W51910";
  /** 連携ファイル管理受信ステータス：連携済 */
  public static final String LINKAGE_STATUS_CODE_LINKAGE = "1";
  /** 使用量XMLファイル連係受信ファイル種別：特高・高圧30分電力量ファイル */
  public static final String USAGE_XML_RECEIVED_FILE_CODE_HIGH_VOLTAGE_30MIN = "0110";
  /** 使用量XMLファイル連係受信ファイル種別：特高・高圧日毎30分電力量ファイル */
  public static final String USAGE_XML_RECEIVED_FILE_CODE_HIGH_VOLTAGE_EVERYDAY_30MIN = "0120";
  /** 使用量XMLファイル連係受信ファイル種別：低圧30分電力量ファイル */
  public static final String USAGE_XML_RECEIVED_FILE_CODE_LOW_VOLTAGE_30MIN = "1110";
  /** 使用量XMLファイル連係受信ファイル種別：低圧日毎30分電力量ファイル */
  public static final String USAGE_XML_RECEIVED_FILE_CODE_LOW_VOLTAGE_EVERYDAY_30MIN = "1120";
  /** 使用量XMLファイル連係受信ファイル種別：特高・高圧月間確定使用量ファイル */
  public static final String USAGE_XML_RECEIVED_FILE_CODE_HIGH_VOLTAGE_MONTH = "1210";
  /** 使用量XMLファイル連係受信ファイル種別：低圧月間確定使用量ファイル */
  public static final String USAGE_XML_RECEIVED_FILE_CODE_LOW_VOLTAGE_MONTH = "1220";
  /** 使用量XMLファイル連係受信ファイル種別：高圧計量器交換ファイル */
  public static final String USAGE_XML_RECEIVED_FILE_CODE_HIGH_VOLTAGE_REPLACEMENT = "1310";
  /** 使用量XMLファイル連係受信ファイル種別：低圧計量器交換ファイル */
  public static final String USAGE_XML_RECEIVED_FILE_CODE_LOW_VOLTAGE_REPLACEMENT = "1320";
  /** 使用量XMLファイル連係受信ファイル種別：高圧臨時検針ファイル */
  public static final String USAGE_XML_RECEIVED_FILE_CODE_HIGH_VOLTAGE_EXTRAORDINARY_METER_READING = "1410";
  /** 使用量XMLファイル連係受信ファイル種別：低圧臨時検針ファイル */
  public static final String USAGE_XML_RECEIVED_FILE_CODE_LOW_VOLTAGE_EXTRAORDINARY_METER_READING = "1420";
  /** 電圧区分名称:低圧 */
  public static final String CUSTOM_VOLTAGE_CAT_NAME_LOW_TENSION = "低圧";
  /** 電圧区分名称:高圧 */
  public static final String CUSTOM_VOLTAGE_CAT_NAME_HIGH_TENSION = "高圧";
  /** 電圧区分名称:特高 */
  public static final String CUSTOM_VOLTAGE_CAT_NAME_SPECIALLY_HIGH = "特高";
  /** 連携ファイル管理受信ステータス：受信未 */
  public static final String TRANSFER_STATUS_NORECEPTION = "0";
  /** 連携ファイル管理受信ステータス：受信済 */
  public static final String TRANSFER_STATUS_RECEPTION = "1";
  /** 連携ファイル管理受信ステータス：受付棄却 */
  public static final String TRANSFER_STATUS_REJECRECEPTION = "2";
  /** 連携ファイル管理種別コード：特高・高圧30分電力量ファイル */
  public static final String LINKAGE_FILE_CATEGORY_M_HIGH_VOLTAGE_30MIN = "W40110";
  /** 連携ファイル管理種別コード：特高・高圧日毎30分電力量ファイル */
  public static final String LINKAGE_FILE_CATEGORY_M_HIGH_VOLTAGE_EVERYDAY_30MIN = "W40120";
  /** 連携ファイル管理種別コード：低圧30分電力量ファイル */
  public static final String LINKAGE_FILE_CATEGORY_M_LOW_VOLTAGE_30MIN = "W41110";
  /** 連携ファイル管理種別コード：低圧日毎30分電力量ファイル */
  public static final String LINKAGE_FILE_CATEGORY_M_LOW_VOLTAGE_EVERYDAY_30MIN = "W41120";
  /** 連携ファイル管理種別コード：特高・高圧月間確定使用量ファイル */
  public static final String LINKAGE_FILE_CATEGORY_M_HIGH_VOLTAGE_MONTH = "W51210";
  /** 連携ファイル管理種別コード：低圧月間確定使用量ファイル */
  public static final String LINKAGE_FILE_CATEGORY_M_LOW_VOLTAGE_MONTH = "W51220";
  /** SSL接続：正常 */
  public static final String SSL_ACCESS_OK = "0";
  /** SSL接続：接続先なし */
  public static final String SSL_ACCESS_NOACCESS = "1";
  /** SSL接続：予期せぬエラー */
  public static final String SSL_ACCESS_ERROR = "9";
  /** SSL接続：ファイル受信成功 */
  public static final String SSL_ACCESS_FILE_RECEPTION_OK = "0";
  /** SSL接続：ファイル受付棄却 */
  public static final String SSL_ACCESS_FILE_RECEPTION_REJECT = "1";
  /** SSL接続：ファイル受信失敗 */
  public static final String SSL_ACCESS_FILE_RECEPTION_NO = "9";
  /** 契約電力算定結果内訳帳票ファイル：CSVファイルリスト項目順（データ）：最大需要電力当月 */
  public static final int CONSIGNMENTCCAFILE_CSV_PEAK_KW_1 = 9;
  /** 契約電力算定結果内訳帳票ファイル：CSVファイルリスト項目順（データ）：最大需要電力-1月 */
  public static final int CONSIGNMENTCCAFILE_CSV_PEAK_KW_2 = 10;
  /** 契約電力算定結果内訳帳票ファイル：CSVファイルリスト項目順（データ）：最大需要電力-2月 */
  public static final int CONSIGNMENTCCAFILE_CSV_PEAK_KW_3 = 11;
  /** 契約電力算定結果内訳帳票ファイル：CSVファイルリスト項目順（データ）：最大需要電力-3月 */
  public static final int CONSIGNMENTCCAFILE_CSV_PEAK_KW_4 = 12;
  /** 契約電力算定結果内訳帳票ファイル：CSVファイルリスト項目順（データ）：最大需要電力-4月 */
  public static final int CONSIGNMENTCCAFILE_CSV_PEAK_KW_5 = 13;
  /** 契約電力算定結果内訳帳票ファイル：CSVファイルリスト項目順（データ）：最大需要電力-5月 */
  public static final int CONSIGNMENTCCAFILE_CSV_PEAK_KW_6 = 14;
  /** 契約電力算定結果内訳帳票ファイル：CSVファイルリスト項目順（データ）：最大需要電力-6月 */
  public static final int CONSIGNMENTCCAFILE_CSV_PEAK_KW_7 = 15;
  /** 契約電力算定結果内訳帳票ファイル：CSVファイルリスト項目順（データ）：最大需要電力-7月 */
  public static final int CONSIGNMENTCCAFILE_CSV_PEAK_KW_8 = 16;
  /** 契約電力算定結果内訳帳票ファイル：CSVファイルリスト項目順（データ）：最大需要電力-8月 */
  public static final int CONSIGNMENTCCAFILE_CSV_PEAK_KW_9 = 17;
  /** 契約電力算定結果内訳帳票ファイル：CSVファイルリスト項目順（データ）：最大需要電力-9月 */
  public static final int CONSIGNMENTCCAFILE_CSV_PEAK_KW_10 = 18;
  /** 契約電力算定結果内訳帳票ファイル：CSVファイルリスト項目順（データ）：最大需要電力-10月 */
  public static final int CONSIGNMENTCCAFILE_CSV_PEAK_KW_11 = 19;
  /** 契約電力算定結果内訳帳票ファイル：CSVファイルリスト項目順（データ）：最大需要電力-11月 */
  public static final int CONSIGNMENTCCAFILE_CSV_PEAK_KW_12 = 20;
  /** 連携ファイルxmlタグ 供給地点特定番号情報コード */
  public static final int XML_TAG_CLASS_CODE_SPOTNO_INFO = 1000;
  /** 連携ファイルxmlタグ 供給地点特定番号情報-インデックス */
  public static final int XML_TAG_SPOTNO_INFO_INDEX = 1;
  /** 連携ファイルxmlタグ 計器情報リストコード */
  public static final int XML_TAG_METER_INFO_LIST_INDEX = 5;
  /** 連携ファイルxmlタグ 共通情報 */
  public static final String XML_TAG_COMMON = "JPTRM";
  /** 連携ファイルxmlタグ 取替工事年月日 */
  public static final String XML_TAG_METER_CHANGE_DATAMETER = "JP06428";
  /** 計器区分コード：(1：常用) */
  public static final String METER_CATEGORY_CODE_FOR_IN_COMMON = "1";
  /** 連携ファイルxmlタグ 最大電力 */
  public static final String XML_TAG_PKW = "JP06440";
  /** 連携ファイルxmlタグ 全日電力量 */
  public static final String XML_TAG_FULL_TIME_USAGE = "JP06441";
  /** 連携ファイルxmlタグ 力測有効電力量 */
  public static final String XML_TAG_EFFECTIVE_USAGE = "JP06442";
  /** 連携ファイルxmlタグ 力測無効電力量 */
  public static final String XML_TAG_REACTIVE_USAGE = "JP06443";
  /** 連携ファイルxmlタグ 取付/取外区分コード */
  public static final String XML_TAG_METER_CHANGE_CATEGORY_CODE = "JP06429";
  /** 連携ファイルxmlタグ 計器識別番号 */
  public static final String XML_TAG_METER_IDENTIFICATION_NO = "JP06431";
  /** 連携ファイルxmlタグ 乗率 */
  public static final String XML_TAG_MULTIPLYING_FACTO = "JP06432";
  /** 連携ファイルxmlタグ 電力損失補正率 */
  public static final String XML_TAG_KW_DISADVANTAGE_FACTO = "JP06433";
  /** 連携ファイルxmlタグ 電力量損失補正率 */
  public static final String XML_TAG_KWH_DISADVANTAGE_FACTOR = "JP06434";
  /** 連携ファイルxmlタグ 最大需要電力 */
  public static final String XML_TAG_PEAK_DEMAN = "JP06435";
  /** 連携ファイルxmlタグ 最大需要電力指示数 */
  public static final String XML_TAG_PEAK_DEMAND_INDICATION_NO = "JP06436";
  /** 連携ファイルxmlタグ 力測有効電力量指示数 */
  public static final String XML_TAG_EFFECTIVE_INDICATION_NO = "JP06438";
  /** 連携ファイルxmlタグ 力測無効電力量指示数 */
  public static final String XML_TAG_REACTIVE_INDICATION_NO = "JP06439";
  /** 連携ファイルxmlタグ 全日電力量指示数 */
  public static final String XML_TAG_FT_KWH_IN = "JP06437";
  /** 連携ファイルxmlタグ 情報区分コード */
  public static final String XML_TAG_HEADER_INFO = "JP00002";
  /** 連携ファイルxmlタグ 共通情報コード-インデックス */
  public static final int XML_TAG_COMMON_INFO_KINDCODE_INDEX = 0;
  /** 契約ID：名称 */
  public static final String COMMON_INFO_NAME = "契約ID";
  /** 対象年月：名称 */
  public static final String TARGET_DATE_NAME = "対象年月";
  /** 供給地点特定番号：名称 */
  public static final String SPOT_NO_NAME = "供給地点特定番号";
  /** 情報区分コード1 */
  public static final String XML_TAG_HEADER_INFO1 = "1310";
  /** 情報区分コード2 */
  public static final String XML_TAG_HEADER_INFO2 = "1320";
  /** ファイル種別：計量器交換情報 */
  public static final String FILE_CLASS_CODE_MC = "0";
  /** ファイル種別：臨時検針情報 */
  public static final String FILE_CLASS_CODE_SMR = "1";
  /** 計器区分Max数 */
  public static final Integer METER_MAX_COUNT_MC = 9;
  /** 計器情報Max数 */
  public static final Integer METER_MAX_COUNT_DETAIL_MC = 2;
  /** 計器区分Max数 */
  public static final Integer METER_MAX_COUNT_SMR = 20;
  /** 全日電力量指示数情報MAX件数 */
  public static final Integer PD_IN_MAX_COUNT = 10;
  /** 「供給地点特定番号情報」行：最大件数 */
  public static final Integer SPOT_NO_LINE_MAX_COUNT = 1000;
  /** 情報区分コード：共通情報(高圧) */
  public static final String INFO_CAT_CODE_COMMON_HIGH_TENSION = "1210";
  /** 情報区分コード：共通情報(低圧発電) */
  public static final String INFO_CAT_CODE_COMMON_LOW_TENSION_GENERATION = "1920";
  /** 情報区分コード：共通情報(高圧発電) */
  public static final String INFO_CAT_CODE_COMMON_HIGH_TENSION_GENERATION = "1910";
  /** 接続先区分：処理対象外 */
  public static final String CONNECT_URL_NOTARGET = "0";
  /** 接続先区分：デフォルト */
  public static final String CONNECT_URL_DEFAULT = "1";
  /** 接続先区分：プロパティ */
  public static final String CONNECT_URL_PROPERTIES = "2";
  /** 確定使用量ファイルダウンロード：エリアマスタ_ソート条件 */
  public static final String SSR060101_AREAM_ORDER_BY_CLAUSE = "area_code ASC";
  /** 確定使用量ファイルダウンロード：電圧区分マスタ_ソート条件 */
  public static final String SSR060101_VOLCATM_ORDER_BY_CLAUSE = "voltage_cat_code ASC";
  /** 確定使用量ファイルダウンロード：送受電区分マスタ_ソート条件 */
  public static final String SSR060101_TRANSMISSIONCATM_ORDER_BY_CLAUSE = "transmission_cat_code ASC";
  /** 空文字 */
  public static final String EMPTY_STRING = "";
  /** すべて */
  public static final String ALL_NAME = "すべて";

}
