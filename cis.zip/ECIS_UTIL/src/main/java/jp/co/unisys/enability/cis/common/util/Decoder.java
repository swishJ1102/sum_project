/*-------------------------------------------------------------------------------
 * All Rights Reserved. Copyright(C) Nihon Unisys, Ltd.
 * vendor : Nihon Unisys, Ltd.
 * since : 2015/04/20 【ph3開発】経理帳票対応
 *-----------------------------------------------------------------------------*/
package jp.co.unisys.enability.cis.common.util;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * キーを元にenumを逆引きする処理を定義する
 * 
 * @param <K>
 *          enumのキー
 * @param <V>
 *          キーの値。enumのオブジェクト
 */
public class Decoder<K extends Serializable, V extends Encodable<K>> {

  private Map<K, V> map;

  private Decoder(V[] values) {
    map = new HashMap<K, V>(values.length);

    for (V value : values) {
      V old = map.put(value.encode(), value);

      // コード値の重複はエラーにする
      if (old != null) {
        throw new IllegalArgumentException("キーが重複しています：" + value);
      }
    }
  }

  /**
   * キーを元に指定されたenumを逆引きする
   * 
   * @param code
   *          enumのキー値
   * @return enumオブジェクト。そのキーのマッピングがのこマップに含まれていない場合はnull
   */
  public V decode(K code) {
    return map.get(code);
  }

  /**
   * enumの配列を元に、キー=enumオブジェクトのmapを生成する
   * 
   * @param values
   *          enumのvalues()
   * @return キー：encodable.encode()、値：enumオブジェクト
   */
  public static <K1 extends Serializable, V1 extends Encodable<K1>> Decoder<K1, V1> create(V1[] values) {
    return new Decoder<K1, V1>(values);
  }
}
