/*-------------------------------------------------------------------------------
 * All Rights Reserved. Copyright(C) Nihon Unisys, Ltd.
 * vendor : Nihon Unisys, Ltd.
 * since : 2015/04/20 【ph3開発】経理帳票対応
 *-----------------------------------------------------------------------------*/
package jp.co.unisys.enability.cis.common.util;

/**
 * 指定されたクラスがプロパティファイルに定義されていることを表す
 */
public interface DefinedProperties {

  /**
   * リターン値を元にプロパティファイルから値を<br>
   * 取得することが可能なプロパティファイルキーを返却する
   * 
   * @return プロパティファイルのキー
   */
  String getPropertyKey();
}
