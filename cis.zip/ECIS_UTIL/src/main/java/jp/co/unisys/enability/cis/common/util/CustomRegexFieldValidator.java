package jp.co.unisys.enability.cis.common.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.opensymphony.xwork2.validator.ValidationException;
import com.opensymphony.xwork2.validator.validators.FieldValidatorSupport;

/**
 * 正規表現文字列チェックバリデータ。
 *
 * <pre>
 * <p><b>【仕様詳細】<b><p>
 * 文字列として定義されている値の正規表現チェックを行うバリデータ。
 * </pre>
 *
 *
 * @author "Nihon Unisys, Ltd."
 *
 */
public class CustomRegexFieldValidator extends FieldValidatorSupport {

  /** 正規表現文字列 */
  private String expression;

  /** 正規表現パターンのオプション設定フラグ */
  private boolean caseSensitive = true;

  /** 入力値トリムフラグ */
  private boolean trim = true;

  /*
   * (非 Javadoc)
   * @see com.opensymphony.xwork2.validator.Validator#validate(java.lang.Object)
   */
  @Override
  public void validate(Object object) throws ValidationException {

    String fieldName = getFieldName();
    Object value = this.getFieldValue(fieldName, object);

    // 入力値と正規表現文字列nullチェック
    if (value == null || expression == null) {
      return;
    }

    // 入力値型チェック
    if (!(value instanceof String)) {
      return;
    }

    // 入力値空文字チェック
    String str = ((String) value);
    if (str.length() == 0) {
      return;
    }

    // パターン設定
    Pattern pattern;
    if (isCaseSensitive()) {
      pattern = Pattern.compile(expression);
    } else {
      pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
    }

    String compare = (String) value;
    if (trim) {
      compare = compare.trim();
    }
    Matcher matcher = pattern.matcher(compare);

    if (!matcher.matches()) {
      addFieldError(fieldName, object);
    }
  }

  /**
   * 正規表現文字列を取得します。
   *
   * @return 正規表現文字列
   */
  public String getExpression() {
    return expression;
  }

  /**
   * 正規表現文字列を設定します。
   *
   * @param expression
   *          正規表現文字列
   */
  public void setExpression(String expression) {
    this.expression = expression;
  }

  /**
   * 正規表現パターンのオプション設定フラグを取得します。
   *
   * @return 正規表現パターンのオプション設定フラグ
   */
  public boolean isCaseSensitive() {
    return caseSensitive;
  }

  /**
   * 正規表現パターンのオプション設定フラグを設定します。
   *
   * @param caseSensitive
   *          正規表現パターンのオプション設定フラグ
   */
  public void setCaseSensitive(boolean caseSensitive) {
    this.caseSensitive = caseSensitive;
  }

  /**
   * 入力値トリムフラグを取得します。
   *
   * @return 入力値トリムフラグ
   */
  public boolean isTrimed() {
    return trim;
  }

  /**
   * 入力値トリムフラグを設定します。
   *
   * @param trim
   *          入力値トリムフラグ
   */
  public void setTrim(boolean trim) {
    this.trim = trim;
  }
}
