package jp.co.unisys.enability.cis.common.Exception;

/**
 * 処理を中断するような（処理を継続できない）場合に生成して投げること。
 *
 * @author UNiSYS
 *
 */
public class SystemException extends RuntimeException {

  /**
   * 元の原因がない場合はこちらのコンストラクタを使用する。
   *
   * @param message
   */
  public SystemException(String message) {
    super(message);
  }

  /**
   * 元の原因がある場合は必ずこちらのコンストラクタを使用する。
   *
   * @param message
   * @param cause
   */
  public SystemException(String message, Throwable cause) {
    super(message, cause);
  }
}
