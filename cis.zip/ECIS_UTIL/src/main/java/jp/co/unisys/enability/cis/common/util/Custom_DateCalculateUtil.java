package jp.co.unisys.enability.cis.common.util;

import java.util.Date;

/**
 *
 * 日付計算ユーティリティ_カスタム<br>
 * <p>
 * <p>
 * <b>【仕様詳細】<b>
 * <p>
 * 引数の情報を基に日付の計算を行う。
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 *
 *         変更履歴(kg-epj) 2016.02.26 T.Hori 新規作成
 */
public class Custom_DateCalculateUtil {

  /**
   * 基準日 - 対象日の日数を返却する<br>
   * 日付はどちらとも設定されていなければならない<br>
   * また、日未満の情報が設定されていた場合は考慮しない
   *
   * @param baseDate
   *          基準日
   * @param otherDate
   *          対象日
   * @return 差分日数
   */
  public static int getDifferenceDate(Date baseDate, Date otherDate) {
    // 日付のミリ秒を取得
    long baseDateMilliSec = baseDate.getTime();
    long otherDateMilliSec = otherDate.getTime();

    // 日付の差(ミリ秒)を取得する
    long dateDiff = baseDateMilliSec - otherDateMilliSec;
    // 一日分のミリ秒で割った値を返却する
    return (int) (dateDiff / EMSConstants.ONE_DAY_MILLI_SECONDS);
  }

}
