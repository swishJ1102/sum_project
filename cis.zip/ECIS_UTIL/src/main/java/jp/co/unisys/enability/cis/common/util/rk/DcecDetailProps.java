package jp.co.unisys.enability.cis.common.util.rk;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import jp.co.unisys.enability.cis.common.Exception.RateEngineException;

/**
 * 項目データクラス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class DcecDetailProps {

  /** ロガー */
  private static final Logger LOGGER = LogManager.getLogger(RateEngineCommonUtil.class);

  /** 項目名 */
  private String itemName;

  /** DCEC区分 */
  private String dcecCategory;

  /** 時間帯コード */
  private String timeSlotCode;

  /** 枝番 */
  private int branchNo;

  /**
   * 項目名を取得する。
   *
   * @author "Nihon Unisys, Ltd."
   * @return 項目名
   */
  public String getItemName() {
    return itemName;
  }

  /**
   * 項目名を設定する。
   *
   * @author "Nihon Unisys, Ltd."
   * @param itemName
   *          項目名
   */
  public void setItemName(String itemName) {
    this.itemName = itemName;
  }

  /**
   * DCEC区分を取得する。
   *
   * @author "Nihon Unisys, Ltd."
   * @return DCEC区分
   */
  public String getDcecCategory() {
    return dcecCategory;
  }

  /**
   * DCEC区分を設定する。
   *
   * @author "Nihon Unisys, Ltd."
   * @param dcecCategory
   *          DCEC区分
   */
  public void setDcecCategory(String dcecCategory) {
    this.dcecCategory = dcecCategory;
  }

  /**
   * 時間帯コードを取得する。
   *
   * @author "Nihon Unisys, Ltd."
   * @return 時間帯コード
   */
  public String getTimeSlotCode() {
    return timeSlotCode;
  }

  /**
   * 時間帯コードを設定する。
   *
   * @author "Nihon Unisys, Ltd."
   * @param timeSlotCode
   *          時間帯コード
   */
  public void setTimeSlotCode(String timeSlotCode) {
    this.timeSlotCode = timeSlotCode;
  }

  /**
   * 枝番を取得する。
   *
   * @author "Nihon Unisys, Ltd."
   * @return 枝番
   */
  public int getBranchNo() {
    return branchNo;
  }

  /**
   * 枝番を設定する。
   *
   * @author "Nihon Unisys, Ltd."
   * @param branchNo
   *          枝番
   */
  public void setBranchNo(int branchNo) {
    this.branchNo = branchNo;
  }

  /**
   * [項目名/DCEC区分/時間帯コード/枝番]の書式の取得元項目の文字列を解析して分割を行う。
   *
   * @author "Nihon Unisys, Ltd."
   * @param propertyName
   *          DCEC区分系明細データの取得元項目の値
   * @return 分割後のデータ
   * @throws RateEngineException
   *           計算処理が継続不能な状態となった場合
   */
  public static DcecDetailProps parseDcecProps(String propertyName) throws RateEngineException {
    String[] props = propertyName.split("/");

    if (props.length != ArrayIndex.FOUR.ordinal()) {
      LOGGER.error("DcecDetailProps＞取得元項目の書式エラー 取得元項目={} 書式(数)={}", propertyName, props.length);
      throw new RateEngineException("error.E1337", propertyName);
    }
    DcecDetailProps parsedProps = new DcecDetailProps();
    parsedProps.itemName = props[0];
    parsedProps.dcecCategory = props[1];
    parsedProps.timeSlotCode = props[2];
    int branchNum = 0;
    try {
      branchNum = Integer.parseInt(props[ArrayIndex.THREE.ordinal()]);
    } catch (NumberFormatException e) {
      LOGGER.error("DcecDetailProps＞取得元項目の文字列を解析エラー 取得元項目={}", propertyName);
      // プロパティ名称を変換できません。取得元項目:{0}
      throw new RateEngineException("error.E1337", e, propertyName);
    }
    parsedProps.branchNo = branchNum;
    return parsedProps;
  }

  /**
   * 配列のインデックス
   *
   * @author "Nihon Unisys, Ltd."
   */
  enum ArrayIndex {
    /** インデックス：0 */
    ZERO,
    /** インデックス：1 */
    ONE,
    /** インデックス：2 */
    TWO,
    /** インデックス：3 */
    THREE,
    /** インデックス：4 */
    FOUR;
  }

}
