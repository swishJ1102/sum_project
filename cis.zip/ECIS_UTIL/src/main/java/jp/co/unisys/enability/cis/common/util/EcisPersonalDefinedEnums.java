/*-------------------------------------------------------------------------------
 * All Rights Reserved. Copyright(C) Nihon Unisys, Ltd.
 * vendor : Nihon Unisys, Ltd.
 * since : 2015/04/20 【ph3開発】経理帳票対応
 *-----------------------------------------------------------------------------*/
package jp.co.unisys.enability.cis.common.util;

/**
 * 独自列挙体定義クラス.<br>
 * コード定義以外に関する、プロパティファイルに定義された<br>
 * 値を持つenumを定義するクラス<br>
 * DefinedPropertiesインタフェースを実装した独自のenumを定義する
 */
public class EcisPersonalDefinedEnums {

  /**
   * 列挙体：経理帳票プロパティ<br>
   * 共通で使用するキーの一覧定義
   */
  public enum AccountingReportPublicProperties implements DefinedProperties {
    /** ワークディレクトリ */
    WORK_DIR("accounting.report.download.work.dir"),
    /** 出力先ディレクトリ */
    OUTPUT_DIR("accounting.report.download.output.dir"),
    /** 出力ファイル移動先ディレクトリ */
    FILE_MOVE_DIR("accounting.report.download.move.dir"),
    /** 最大検索数 */
    MAX_SEARCH_COUNT("accounting.report.maxsearchcount"),
    /** ページ内一覧表示件数 */
    PAGE_DISPLAY_COUNT("accounting.report.pagedisplaycount");

    private String propertyKey;

    private AccountingReportPublicProperties(String propertyKey) {
      this.propertyKey = propertyKey;
    }

    @Override
    public String getPropertyKey() {
      return this.propertyKey;
    }
  }

  /**
   * 列挙体：利用フラグプロパティ<br>
   * プロパティファイルのキー一覧定義
   */
  public enum UsageFlagPropertyKeys implements DefinedProperties {
    /** ブランド利用フラグ */
    BRAND_USAGE_FLAG("usageflag.brand"), SERVICE_USAGE_FLAG("usageflag.service");

    private String propertyKey;

    private UsageFlagPropertyKeys(String propertyKey) {
      this.propertyKey = propertyKey;
    }

    @Override
    public String getPropertyKey() {
      return this.propertyKey;
    }
  }

}
