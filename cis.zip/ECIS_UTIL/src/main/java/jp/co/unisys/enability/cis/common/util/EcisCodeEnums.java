/*-------------------------------------------------------------------------------
 * All Rights Reserved. Copyright(C) Nihon Unisys, Ltd.
 * vendor : Nihon Unisys, Ltd.
 * since : 2015/04/20 【ph3開発】経理帳票対応
 *-----------------------------------------------------------------------------*/
package jp.co.unisys.enability.cis.common.util;

/**
 * コード定義列挙体クラス.<br>
 * ECISのコード定義に関するenumを定義するクラス
 */
public class EcisCodeEnums {

  /**
   * 列挙体：料金計算結果確定ステータス
   */
  public enum BillingFixStatusCode implements Encodable<String>, DefinedProperties {
    /** 未確定 */
    UNDECIDEC("0", "billingfixstatus.0"),
    /** 料金確定済 */
    DECISION("1", "billingfixstatus.1"),
    /** 請求作成済 */
    CLAIMED("2", "billingfixstatus.2"),
    /** 債権譲渡指示済 */
    ASSAIGNMENT_CLAIMED("3", "billingfixstatus.3"),
    /** 債権譲渡済 */
    ASSAIGNMENT_CLAIMED_FIX("4", "billingfixstatus.4"),
    /** 料金確定エラー */
    DECISION_ERROR("A", "billingfixstatus.A"),
    /** 債権譲渡エラー */
    ASSAIGNMENT_CLAIMED_ERROR("B", "billingfixstatus.B");

    private String code;
    private String propertyKey;
    private static final Decoder<String, BillingFixStatusCode> DECODER = Decoder.create(values());

    private BillingFixStatusCode(String code, String propertyKey) {
      this.code = code;
      this.propertyKey = propertyKey;
    }

    /**
     * 逆引きメソッド
     * 
     * @param code
     * @return
     */
    public static BillingFixStatusCode decode(String code) {
      return DECODER.decode(code);
    }

    @Override
    public String getPropertyKey() {
      return this.propertyKey;
    }

    @Override
    public String encode() {
      return this.code;
    }
  }

  /**
   * 列挙体：自社他社種別
   */
  public enum SelfOtherClass implements Encodable<String>, DefinedProperties {
    SELF_CAMPANY("1", "selfotherclass.1"), OTHER_COMPANY("2", "selfotherclass.2");

    private String code;
    private String propertyKey;
    private static final Decoder<String, SelfOtherClass> DECODER = Decoder.create(values());

    private SelfOtherClass(String code, String propertyKey) {
      this.code = code;
      this.propertyKey = propertyKey;
    }

    /**
     * 逆引きメソッド
     * 
     * @param code
     * @return
     */
    public static SelfOtherClass decode(String code) {
      return DECODER.decode(code);
    }

    @Override
    public String getPropertyKey() {
      return this.propertyKey;
    }

    @Override
    public String encode() {
      return this.code;
    }
  }

  /**
   * 列挙体：新築既築種別
   */
  public enum NewOldClass implements Encodable<String>, DefinedProperties {
    NEW("1", "newoldclass.1"), OLD("2", "newoldclass.2");

    private String code;
    private String propertyKey;
    private static final Decoder<String, NewOldClass> DECODER = Decoder.create(values());

    private NewOldClass(String code, String propertyKey) {
      this.code = code;
      this.propertyKey = propertyKey;
    }

    /**
     * 逆引きメソッド
     * 
     * @param code
     * @return
     */
    public static NewOldClass decode(String code) {
      return DECODER.decode(code);
    }

    @Override
    public String getPropertyKey() {
      return this.propertyKey;
    }

    @Override
    public String encode() {
      return this.code;
    }
  }

  /**
   * 列挙体：債権ステータス
   */
  public enum ClaimStatus implements Encodable<String>, DefinedProperties {
    /** 未収納 */
    UN_DELIVERED("0", "claimstatus.0"),
    /** 収納済 */
    DELIVERED("1", "claimstatus.1"),
    /** 部分収納 */
    PARTIAL_DELIVERED("2", "claimstatus.2"),
    /** 過剰収納 */
    SURPLUS_DELIVERED("3", "claimstatus.3");

    private String code;
    private String propertyKey;
    private static final Decoder<String, ClaimStatus> DECODER = Decoder.create(values());

    private ClaimStatus(String code, String propertyKey) {
      this.code = code;
      this.propertyKey = propertyKey;
    }

    /**
     * 逆引きメソッド
     * 
     * @param code
     * @return
     */
    public static ClaimStatus decode(String code) {
      return DECODER.decode(code);
    }

    @Override
    public String getPropertyKey() {
      return this.propertyKey;
    }

    @Override
    public String encode() {
      return this.code;
    }
  }

  /**
   * 列挙体：経理ステータス
   */
  public enum AccountingStatus implements Encodable<String>, DefinedProperties {
    /** 通常 */
    NORMAL("0", "accountingstatus.0"),
    /** 償却 */
    REPAYMENT("1", "accountingstatus.1"),
    /** 社内利用 */
    COMPANY_USAGE("2", "accountingstatus.2");

    private String code;
    private String propertyKey;
    private static final Decoder<String, AccountingStatus> DECODER = Decoder.create(values());

    private AccountingStatus(String code, String propertyKey) {
      this.code = code;
      this.propertyKey = propertyKey;
    }

    /**
     * 逆引きメソッド
     * 
     * @param code
     * @return
     */
    public static AccountingStatus decode(String code) {
      return DECODER.decode(code);
    }

    @Override
    public String getPropertyKey() {
      return this.propertyKey;
    }

    @Override
    public String encode() {
      return this.code;
    }
  }

  /**
   * 列挙体：請求対象区分
   */
  public enum BillingTargetCategory implements Encodable<String>, DefinedProperties {
    /** 請求対象 */
    TARGET("0", "billingTargetCategory.0"),
    /** 請求対象外 */
    NOT_TARGET("1", "billingTargetCategory.1");

    private String code;
    private String propertyKey;
    private static final Decoder<String, BillingTargetCategory> DECODER = Decoder.create(values());

    private BillingTargetCategory(String code, String propertyKey) {
      this.code = code;
      this.propertyKey = propertyKey;
    }

    /**
     * 逆引きメソッド
     * 
     * @param code
     * @return
     */
    public static BillingTargetCategory decode(String code) {
      return DECODER.decode(code);
    }

    @Override
    public String getPropertyKey() {
      return this.propertyKey;
    }

    @Override
    public String encode() {
      return this.code;
    }
  }

  /**
   * 列挙体：部屋種別
   */
  public enum RoomClass implements Encodable<String>, DefinedProperties {
    /** 部屋種別-専有部 */
    EXCLUSIVE("01", "roomClass.01"),
    /** 部屋種別-共用部 */
    COMMON("02", "roomClass.02"),
    /** 部屋種別-店舗・事務所 */
    OFFICE("03", "roomClass.03");

    private String code;
    private String propertyKey;
    private static final Decoder<String, RoomClass> DECODER = Decoder.create(values());

    private RoomClass(String code, String propertyKey) {
      this.code = code;
      this.propertyKey = propertyKey;
    }

    /**
     * 逆引きメソッド
     * 
     * @param code
     * @return
     */
    public static RoomClass decode(String code) {
      return DECODER.decode(code);
    }

    @Override
    public String getPropertyKey() {
      return this.propertyKey;
    }

    @Override
    public String encode() {
      return this.code;
    }
  }

  /**
   * 列挙体：収納ステータス
   */
  public enum ReceiptStatus implements Encodable<String>, DefinedProperties {
    /** 請求未反映 */
    NO_REFLECTED("0", "receiptstatus.0"),
    /** 請求反映済 */
    REFLECTED("1", "receiptstatus.1"),
    /** 請求反映対象外 */
    NO_TARGET("2", "receiptstatus.2"),
    /** エラー */
    ERROR("9", "receiptstatus.9");

    private String code;
    private String propertyKey;
    private static final Decoder<String, ReceiptStatus> DECODER = Decoder.create(values());

    private ReceiptStatus(String code, String propertyKey) {
      this.code = code;
      this.propertyKey = propertyKey;
    }

    /**
     * 逆引きメソッド
     * 
     * @param code
     * @return
     */
    public static ReceiptStatus decode(String code) {
      return DECODER.decode(code);
    }

    @Override
    public String getPropertyKey() {
      return this.propertyKey;
    }

    @Override
    public String encode() {
      return this.code;
    }
  }

  /**
   * 列挙体：補正ステータス
   */
  public enum CorrectStatus implements Encodable<String>, DefinedProperties {
    /** 補正対象外 */
    NOT_CORRECTTARGET("0", "correctstatus.0"),
    /** 補正前 */
    BEFORE_CORRECT("1", "correctstatus.1"),
    /** 補正済 */
    CORRECTED("2", "correctstatus.2"),
    /** 補正承認済 */
    CORRECT_APPROVED("3", "correctstatus.3"),
    /** 削除登録済 */
    DELETE_REGISTED("4", "correctstatus.4");

    private String code;
    private String propertyKey;
    private static final Decoder<String, CorrectStatus> DECODER = Decoder.create(values());

    private CorrectStatus(String code, String propertyKey) {
      this.code = code;
      this.propertyKey = propertyKey;
    }

    /**
     * 逆引きメソッド
     * 
     * @param code
     * @return
     */
    public static CorrectStatus decode(String code) {
      return DECODER.decode(code);
    }

    @Override
    public String getPropertyKey() {
      return this.propertyKey;
    }

    @Override
    public String encode() {
      return this.code;
    }
  }
}
