package jp.co.unisys.enability.cis.common.util.constants;

/**
 * 定数クラス
 *
 * @author "Nihon Unisys, Ltd."
 */
public class ECISCodeConstants {

  /** 業務日数コード：支払期日日数 */
  public static final String WORK_DAYS_FOR_PAYMENT_FIXED_DATE_DAYS = "2";
  /** 業務日数コード：コンビニ未収判定日数 */
  public static final String WORK_DAYS_FOR_CONVENIENCE_STORE_ACCRUED_DECISION_DAYS = "3";
  /** 業務日数コード：請求書未収判定日数 */
  public static final String WORK_DAYS_FOR_BILL_ACCRUED_DECISION_DAYS = "4";
  /** 業務日数コード：クレジット未収判定日数 */
  public static final String WORK_DAYS_FOR_CREDIT_ACCRUED_DECISION_DAYS = "5";
  /** 業務日数コード：口座振替未収判定日数 */
  public static final String WORK_DAYS_FOR_ACCOUNT_TRANSFER_ACCRUED_DECISION_DAYS = "6";
  /** 業務日数コード：解約手続き日数 */
  public static final String WORK_DAYS_FOR_CANCELLATION_PROCEDURE_DATES = "7";
  /** 業務日数コード：口振依頼期限日数 */
  public static final String WORK_DAYS_FOR_MOUTH_VIBRATION_REQUEST_DEADLINE_DATES = "8";
  /** 業務日数コード：クレカ依頼期限日数 */
  public static final String WORK_DAYS_FOR_CREDIT_REQUEST_DEADLINE_DATES = "9";
  /** 業務日数コード：使用量未達判断日数 */
  public static final String WORK_DAYS_FOR_USAGE_UNACHIEVED_DECISION_DAYS = "10";
  /** 業務日数コード：料金確定日数 */
  public static final String WORK_DAYS_FOR_BATCH_EXEC_BASE_DATE = "11";
  /** 業務日数コード：督促情報表示日数 */
  public static final String WORK_DAYS_FOR_URGE_INFO_DISPLAY_DAYS = "12";
  /** 業務日数コード：クレカ有効期限警告日数 */
  public static final String WORK_DAYS_FOR_CREDIT_CARD_EXPIRATION_DATE_WARNING_DAYS = "13";
  /** 業務日数コード：契約情報出力対象日数 */
  public static final String WORK_DAYS_FOR_CONTRACT_INFO_OUTPUT_COVERED_DAYS = "14";
  /** 業務日数コード：債権回収支払期限日数 */
  public static final String WORK_DAYS_FOR_COL_OF_CLAIM_PAYMENT_DEADLINE_DATES = "16";
  /** 業務日数コード：債権回収未収判断日数 */
  public static final String WORK_DAYS_FOR_COL_OF_CLAIM_ACCRUED_DECISION_DAYS = "17";
  /** 業務日数コード：手動入力入金日許容日数（前） */
  public static final String WORK_DAYS_FOR_BEFORE_MANUAL_INPUT_PAYMENT_DAY_ALLOWABLE_NUMBER_OF_DAYS = "18";
  /** 業務日数コード：手動入力入金日許容日数（後） */
  public static final String WORK_DAYS_FOR_AFTER_MANUAL_INPUT_PAYMENT_DAY_ALLOWABLE_NUMBER_OF_DAYS = "19";
  /** 業務日数コード：次回検針予定日加算日数 */
  public static final String WORK_DAYS_FOR_NEXT_METER_READING_SCHEDULED_DATE_ADD_DAYS = "20";
  /** 業務日数コード：請求保留日数 */
  public static final String WORK_DAYS_FOR_REMAIN_DATE = "21";
  /** 提供モデルコード:直営(1) */
  public static final String PROVIDE_MODEL_CODE_DIRECT_MANAGEMENT = "1";
  /** 提供モデルコード:取次店(2) */
  public static final String PROVIDE_MODEL_CODE_AGENCY = "2";
  /** 料金ステータスコード:未確定(1) */
  public static final String CHARGE_STATUS_CODE_UNFIXED = "1";
  /** 料金ステータスコード:確定(2) */
  public static final String CHARGE_STATUS_CODE_FIX = "2";
  /** 個別設定:個別設定不可(0) */
  public static final String INDIVIDUAL_SETTING_FLAG_IMPOSSIBLE = "0";
  /** 個別設定:個別設定必須(1) */
  public static final String INDIVIDUAL_SETTING_FLAG_REQUIRED = "1";
  /** 売買区分コード:売電(1) */
  public static final String SALE_CATEGORY_SELLING = "1";
  /** 付帯種別コード：定額（1） */
  public static final String SUPPLEMENTARY_CLASS_CODE_FIXED_AMOUNT = "1";
  /** 付帯種別コード：定率（2） */
  public static final String SUPPLEMENTARY_CLASS_CODE_FIXED_RATE = "2";
  /** 支払方法コード:クレジットカード払い(1) */
  public static final String PAYMENT_WAY_CODE_CREDIT = "1";
  /** 支払方法コード:口座振替(2) */
  public static final String PAYMENT_WAY_CODE_ACCOUNT = "2";
  /** 支払方法コード:コンビニ払い(3) */
  public static final String PAYMENT_WAY_CODE_CONVENI = "3";
  /** 支払方法コード:振込用請求書(4) */
  public static final String PAYMENT_WAY_CODE_TRANSFER = "4";
  /** 支払方法コード：送金(9) */
  public static final String PAYMENT_WAY_CODE_REMITTANCE = "9";
  /** 送金金融機関コード：ゆうちょ銀行(9900) */
  public static final String REMITTANCE_FINANCIAL_INSTITUTION_YUUCHO = "9900";
  /** 口座クレカ区分コード:クレジットカード払い(1) */
  public static final String ACCOUNT_CREDIT_CATEGORY_CODE_CREDIT = "1";
  /** 口座クレカ区分コード:口座振替(2) */
  public static final String ACCOUNT_CREDIT_CATEGORY_CODE_ACCOUNT = "2";
  /** 口座クレカ区分コード:請求時振込先（自社口座）(4) */
  public static final String ACCOUNT_CREDIT_CATEGORY_CODE_TRANSFER = "4";
  /** 口座クレカ区分コード:購入時振込先(5) */
  public static final String ACCOUNT_CREDIT_CATEGORY_CODE_TRANSFER_BUY = "5";
  /** 個人・法人区分-すべて */
  public static final String PERSONAL_CORPORATION_CATEGORY_ALL = "";
  /** 個人・法人区分-個人 */
  public static final String PERSONAL_CORPORATION_CATEGORY_PERSONAL = "1";
  /** 個人・法人区分-法人 */
  public static final String PERSONAL_CORPORATION_CATEGORY_CORPORATION = "2";
  /** 送受電区分コード:すべて */
  public static final String TRANSMISSION_CATEGORY_CODE_ALL = "";
  /** 送受電区分コード:送電 */
  public static final String TRANSMISSION_CATEGORY_CODE_TRANSMISSION = "1";
  /** 送受電区分コード:受電 */
  public static final String TRANSMISSION_CATEGORY_CODE_RECEIVING = "2";
  /** 売買区分コード:買電 */
  public static final String SALE_CATEGORY_PURCHASING = "2";
  /** 基本料金 */
  public static final String SPL_COVERED_CAT_CODE_DC = "1";
  /** 従量料金 */
  public static final String SPL_COVERED_CAT_CODE_EC = "2";
  /** 基本料金＋従量料金 */
  public static final String SPL_COVERED_CAT_CODE_DCEC = "3";
  /** 完了：未完了(0) */
  public static final String COMPLETED_FLAG_NON_COMPLETE = "0";
  /** 完了：完了済(1) */
  public static final String COMPLETED_FLAGCOMPLETE_COMPLETED = "1";
  /** 預り金等発生契機区分コード：入金 */
  public static final String DEPOSITS_RECEIVED_AO_SEGMENT_CODE_DEPOSIT = "1";
  /** 預り金等種別コード：預り金 */
  public static final String DEPOSITS_RECEIVED_CLASS_CODE_DEPOSIT_RECEIVED = "1";
  /** 預り金等種別コード：経費 */
  public static final String DEPOSITS_RECEIVED_CLASS_CODE_APPLY_EXPENSE = "2";
  /** 収納結果コード：未処理 */
  public static final String RECEIPT_RESULT_CODE_UNTREATED = "0";
  /** 業務日程区分コード:経理データ締切日(3) */
  public static final String WORK_SCHEDULE_CATEGORY_CODE_ACCOUNTING_DATA_LIMIT = "3";
  /** 収納結果コード：正常収納 */
  public static final String RECEIPT_RESULT_CODE_NOMAL_RECEIPT = "1";
  /** 収納結果コード：振替 */
  public static final String RECEIPT_RESULT_CODE_TRANSFER = "9";
  /** 請求区分コード:クレジットカード払い(1) */
  public static final String BILLING_CATEGORY_CODE_CREDIT = "1";
  /** 請求区分コード:口座振替(2) */
  public static final String BILLING_CATEGORY_CODE_ACCOUNT = "2";
  /** 請求区分コード:コンビニ払い(3) */
  public static final String BILLING_CATEGORY_CODE_CONVENI = "3";
  /** 請求区分コード:振込用請求書(4) */
  public static final String BILLING_CATEGORY_CODE_TRANSFER = "4";
  /** 請求区分コード:債権回収依頼(5) */
  public static final String BILLING_CATEGORY_CODE_COMMISSION_COLLECTION_CLAIM_COVERED = "5";
  /** 請求ステータスコード:請求中(1) */
  public static final String BILLING_STATUS_CODE_BILLING = "1";
  /** 請求ステータスコード:未収(2) */
  public static final String BILLING_STATUS_CODE_UNPAID = "2";
  /** 請求ステータスコード:消込済(5) */
  public static final String BILLING_STATUS_CODE_RECONCILE = "5";
  /** 請求ステータスコード:無効(9) */
  public static final String BILLING_STATUS_CODE_INVALID = "9";
  /** 預り金等ステータスコード:未充当(0) */
  public static final String DEPOSITS_RECEIVED_STATUS_CODE_NOT_APPROPRIATION = "0";
  /** 預り金等ステータスコード:充当予約(1) */
  public static final String DEPOSITS_RECEIVED_STATUS_CODE_APPROPRIATION_RESERVATION = "1";
  /** 預り金等ステータスコード:充当済(2) */
  public static final String DEPOSITS_RECEIVED_STATUS_CODE_APPROPRIATION = "2";
  /** 預り金等ステータスコード:無効(9) */
  public static final String DEPOSITS_RECEIVED_STATUS_CODE_INVALID = "9";
  /** 契約終了理由コード:解約（破産）(7) */
  public static final String CONTRACT_END_REASON_CODE_CANCELLATION_BANKRUPTCY = "7";
  /** 督促ステータスコード:解約決定(3) */
  public static final String URGE_STATUS_CODE_CANCELLATION_DECISION = "3";
  /** 業務日程区分コード:口座振替日(1) */
  public static final String WORK_SCHEDULE_CATEGORY_CODE_ACCOUNT_TRANSFER_DATE = "1";
  /** 請求ステータスコード:仮消込（速報）(3) */
  public static final String BILLING_STATUS_CODE_RECONCILE_PRELIMINARY_REPORT = "3";
  /** 請求ステータスコード:仮消込（不足収納）(4) */
  public static final String BILLING_STATUS_CODE_RECONCILE_LACK_OF_STORAGE = "4";
  /** 請求ステータスコード:特別消込(6) */
  public static final String BILLING_STATUS_CODE_SPECIAL_RECONCILE = "6";
  /** 契約終了理由コード:廃止（スイッチング）(1) */
  public static final String CONTRACT_END_REASON_CODE_ABOLITION_SWITCHING = "1";
  /** 契約終了理由コード:廃止（転居）(2) */
  public static final String CONTRACT_END_REASON_CODE_ABOLITION_MOVE = "2";
  /** 契約終了理由コード:廃止（利用停止）(3) */
  public static final String CONTRACT_END_REASON_CODE_ABOLITION_SUSPENSION_OF_USE = "3";
  /** 契約終了理由コード:解約（未収）(6) */
  public static final String CONTRACT_END_REASON_CODE_CANCELLATION_UNPAID = "6";
  /** 契約終了理由コード:解約（契約不履行）(8) */
  public static final String CONTRACT_END_REASON_CODE_CANCELLATION_AGREEMENT_NONPERFORMANCE = "8";
  /** 督促ステータスコード:解約予告済(1) */
  public static final String URGE_STATUS_CODE_CANCELLATION_PREVIOUS_NOTICE = "1";
  /** 督促ステータスコード:解約回避(2) */
  public static final String URGE_STATUS_CODE_CANCELLATION_EVASION = "2";
  /** 検針理由コード:通常検針(1) */
  public static final String METER_READING_REASON_CODE_NORMAL = "1";
  /** 検針理由コード:廃止(2) */
  public static final String METER_READING_REASON_CODE_ABOLITION = "2";
  /** 検針理由コード:解約(3) */
  public static final String METER_READING_REASON_CODE_CANCELLATION = "3";
  /** 預り金等ステータスコード:特別消込(8) */
  public static final String DEPOSITS_RECEIVED_STATUS_CODE_SPECIAL_RECONCILE = "8";
  /** 入金ステータスコード:収納(1) */
  public static final String DEPOSIT_STATUS_CODE_RECEIPT = "1";
  /** 入金ステータスコード:本入金(2) */
  public static final String DEPOSIT_STATUS_CODE_FACT_DEPOSIT = "2";
  /** 入金ステータスコード:不明入金(9) */
  public static final String DEPOSIT_STATUS_CODE_UNKNOWN_DEPOSIT = "9";
  /** ファイル分類コード:債権譲渡候補(04) */
  public static final String FILE_CATEGORY_CODE_CLAIM_ASSIGNMENT_CANDIDATE = "04";
  /** 収納結果コード:未処理(0) */
  public static final String RR_CODE_NON_EXECUTE = "0";
  /** 収納結果コード:正常収納(1) */
  public static final String RR_CODE_NOMAL_RECEIPT = "1";
  /** 収納結果コード:不足収納(2) */
  public static final String RR_CODE_INSUFFICIENT_RECEIPT = "2";
  /** 収納結果コード:過収納(3) */
  public static final String RR_CODE_OVER_RECEIPT = "3";
  /** 収納結果コード:二重収納(4) */
  public static final String RR_CODE_DOUBLE_RECEIPT = "4";
  /** 収納結果コード:振替(9) */
  public static final String RR_CODE_TRANSFER = "9";
  /** 解約回避コード:入金済(1) */
  public static final String CE_REASON_CODE_DEPOSIT_COMPLETED = "1";
  /** 解約回避コード:協議(2) */
  public static final String CE_REASON_CODE_DISCUSSIONS = "2";
  /** 解約回避コード:その他(9) */
  public static final String CE_REASON_CODE_OTHER = "9";
  /** DCEC区分コード:DC(1) */
  public static final String DCEC_CATEGORY_CODE_DC = "1";
  /** DCEC区分コード:EC(2) */
  public static final String DCEC_CATEGORY_CODE_EC = "2";
  /** 計器区分コード:常用(1) */
  public static final String METER_CATEGORY_CODE_FOR_IN_COMMON = "1";
  /** 収納区分コード:手動入金(8) */
  public static final String RS_CODE_MANUAL_DEPOSIT = "8";
  /** 業務日付コード:手動入力入金日許容日数（前）(18) */
  public static final String WORK_DAYS_CODE_MANUAL_DEPOSIT_PERMIT_DATE_FROM = "18";
  /** 業務日付コード:手動入力入金日許容日数（後）(19) */
  public static final String WORK_DAYS_CODE_MANUAL_DEPOSIT_PERMIT_DATE_TO = "19";
  /** 収納区分コード:クレジットカード払い(1) */
  public static final String RS_CODE_CREDIT = "1";
  /** 収納区分コード:口座振替(2) */
  public static final String RS_CODE_ACCOUNT = "2";
  /** 収納区分コード:コンビニ払い(3) */
  public static final String RS_CODE_CONVENI = "3";
  /** 収納区分コード:振込(4) */
  public static final String RS_CODE_TRANSFER = "4";
  /** 収納区分コード:債権回収依頼(5) */
  public static final String RS_CODE_COMMISSION_COLLECTION_CLAIM_COVERED = "5";
  /** 請求区分コード:卸／取次事業者(9) */
  public static final String BILLING_CATEGORY_CODE_WHOLESALE_AGENCY_OPERATOR = "9";
  /** 収納結果保存：レコード区分：ヘッダー */
  public static final String RECEIPT_RESULT_PRESERVE_HEADER_RECORD = "1";
  /** 収納結果保存：レコード区分：データ */
  public static final String RECEIPT_RESULT_PRESERVE_DATA_RECORD = "2";
  /** ファイル分類コード:料金実績一覧（卸／取次事業者）(01) */
  public static final String FILE_CATEGORY_CODE_CHARGE_RESULT_LIST = "01";
  /** ファイル分類コード料金実績内訳（卸／取次事業者）(02) */
  public static final String FILE_CATEGORY_CODE_CHARGE_RESULT_BREAKDOWN = "02";
  /** ファイル分類コード:料金実績一覧・内訳（卸／取次事業者）(03) */
  public static final String FILE_CATEGORY_CODE_CHARGE_RESULT_LIST_BREAKDOWN = "03";
  /** 業務日程区分コード:卸／取次事業者向け料金実績一覧処理日(7) */
  public static final String WORK_SCHEDULE_CATEGORY_CODE_WS_AG_OP_CHARGE_RESULT_LIST_EXECUTE_DATE = "7";
  /** TODOステータスコード：未着手(0) */
  public static final String TODO_STATUS_CODE_NOT_STARTED = "0";
  /** TODOステータスコード：対応中(1) */
  public static final String TODO_STATUS_CODE_ONGOING = "1";
  /** 業務日程区分コード:経理データ作成処理日(4) */
  public static final String WORK_SCHEDULE_CATEGORY_CODE_ACCOUNT_DATA_CREATE_DATE = "4";
  /** 割引割増区分：割増 */
  public static final String DISCOUNT_CATEGORY_CODE_PREMIUM = "2";
  /** 割引割増区分：割引 */
  public static final String DISCOUNT_CATEGORY_CODE_DISCOUNT = "1";
  /** 請求特別消込理由コード：債権譲渡 */
  public static final String BILLING_SR_REASON_CLAIM_ASSIGNMENT = "2";
  /** 預り金等発生契機区分コード：請求特別消込 */
  public static final String DEPOSITS_RECEIVED_AO_SEGMENT_CODE_BL_SR = "4";
  /** ファイル分類コード:経理データ（料金実績）(05) */
  public static final String FILE_CATEGORY_CODE_ACCOUNT_DATA_CHARGE_RESULT = "05";
  /** TODOステータスコード：完了(2) */
  public static final String TODO_STATUS_CODE_COMPLETE = "2";
  /** 業務日程区分コード:卸／取次事業者向け請求処理日(6) */
  public static final String WORK_SCHEDULE_CATEGORY_CODE_WS_AG_OP_BILLING_EXECUTE_DATE = "6";
  /** 速報・確報区分コード:速報(1) */
  public static final String EARLY_FIX_NOTIFICATION_SEGMENT_CODE_EARLY = "1";
  /** 速報・確報区分コード:確報(2) */
  public static final String EARLY_FIX_NOTIFICATION_SEGMENT_CODE_FIX = "2";
  /** 速報・確報区分コード:速報取消(9) */
  public static final String EARLY_FIX_NOTIFICATION_SEGMENT_CODE_CANCEL = "9";
  /** 料金メニュー区分コード:料金メニュー(1) */
  public static final String RATE_MENU_CODE_RATE_MENU = "1";
  /** 料金メニュー区分コード:付帯メニュー(2) */
  public static final String RATE_MENU_CODE_SUPPLEMENTARY_MENU = "2";
  /** 仕訳コード：仕訳なし（全量）(1) */
  public static final String CATEGORIZE_MASTER_NOT_CATEGORIZE = "1";
  /** 月次実績エラー区分コード：通常（エラーなし）(0) */
  public static final String MONTHLY_USAGE_RESULT_ERROR_CATEGORY_CODE_NO_ERROR = "0";
  /** ファイル分類コード:債権譲渡明細書(10) */
  public static final String FILE_CATEGORY_CODE_CLAIM_ASSIGNMENT_DETAIL = "10";
  /** ファイル分類コード:貸倒明細書(11) */
  public static final String FILE_CATEGORY_CODE_UNCLCT_DETAIL = "11";
  /** 業務日程区分コード:債権譲渡・貸倒明細書作成処理日(5) */
  public static final String WORK_SCHEDULE_CATEGORY_CODE_CLM_ASGN_UNCLCT_EXECUTE_DATE = "5";
  /** 請求特別消込理由コード：貸倒れ(1) */
  public static final String BILLING_SR_REASON_UNCLCT = "1";
  /** ファイル分類コード:経理データ（入金）(06) */
  public static final String FILE_CATEGORY_CODE_ACCOUNT_DATA_DEPOSIT = "06";
  /** ファイル分類コード:経理データ（債権譲渡・破産等債権）(07) */
  public static final String FILE_CATEGORY_CODE_ACCOUNT_DATA_CLM_ASGN_BAN_CLM = "07";
  /** ファイル分類コード:経理データ（預り金等）(08) */
  public static final String FILE_CATEGORY_CODE_ACCOUNT_DATA_DEP_REC = "08";
  /** 預り金等発生契機区分コード：経費充当(3) */
  public static final String DEPOSITS_RECEIVED_AO_SEGMENT_CODE_APPLY_EXPENSE_APPROPRIATED = "3";
  /** ファイル分類コード:経理データ（前月残高）(09) */
  public static final String FILE_CATEGORY_CODE_ACCOUNT_DATA_PRE_MON_BAL = "09";
  /** 預り金等発生契機区分コード：充当(2) */
  public static final String DEPOSITS_RECEIVED_AO_SEGMENT_CODE_APPROPRIATED = "2";
  /** 電灯電力区分コード：電力(2) */
  public static final String ELECTRIC_LIGHT_AND_POWER_CATEGORY_CODE_POWER = "2";
  /** 確定料金実績内訳区分コード：基本料金(101) */
  public static final String FCR_BREAKDOWN_CATEGORY_CODE_BASIC_CHARGE = "101";
  /** 確定料金実績内訳区分コード：最低料金(102) */
  public static final String FCR_BREAKDOWN_CATEGORY_CODE_MINIMUM_CHARGE = "102";
  /** 確定料金実績内訳区分コード：基本料金(予備線)(103) */
  public static final String FCR_BREAKDOWN_CATEGORY_CODE_BASIC_CHARGE_RESERVE_LINE = "103";
  /** 確定料金実績内訳区分コード：基本料金(予備電源)(104) */
  public static final String FCR_BREAKDOWN_CATEGORY_CODE_BASIC_CHARGE_RESERVE_POWER_SUPPLY = "104";
  /** 確定料金実績内訳区分コード：従量料金(201) */
  public static final String FCR_BREAKDOWN_CATEGORY_CODE_USAGE_CHARGE = "201";
  /** 確定料金実績内訳区分コード：燃料費調整額(202) */
  public static final String FCR_BREAKDOWN_CATEGORY_CODE_FUEL_COST_ADJUSTMENT = "202";
  /** 確定料金実績内訳区分コード：最低金額適用前付帯金額(301) */
  public static final String FCR_BREAKDOWN_CATEGORY_CODE_MINIMUM_AMOUNT_APPLICATION_BEFORE_SPL_CHARGE = "301";
  /** 確定料金実績内訳区分コード：最低金額適用後付帯金額(302) */
  public static final String FCR_BREAKDOWN_CATEGORY_CODE_MINIMUM_AMOUNT_APPLICATION_AFTER_SPL_CHARGE = "302";
  /** 確定料金実績内訳区分コード：最低月額料金(401) */
  public static final String FCR_BREAKDOWN_CATEGORY_CODE_MINIMUM_MONTHLY_CHARGE = "401";
  /** 確定料金実績内訳区分コード：再エネ賦課金(501) */
  public static final String FCR_BREAKDOWN_CATEGORY_CODE_RENEWABLE_ENERGY_CHARGE = "501";
  /** 確定料金実績内訳区分コード：制限中止割引額(801) */
  public static final String FCR_BREAKDOWN_CATEGORY_CODE_LIMIT_DISCONTINUED_DISCOUNT = "801";
  /** 確定料金実績内訳区分コード：契約超過金(851) */
  public static final String FCR_BREAKDOWN_CATEGORY_CODE_CONTRACT_EXCEEDED_CHARGE = "851";
  /** 確定料金実績内訳区分コード：電気料金補正額(901) */
  public static final String FCR_BREAKDOWN_CATEGORY_CODE_POWER_RATE_CORRECT_CHARGE = "901";
  /** 確定料金実績内訳区分コード：再エネ賦課金補正額(902) */
  public static final String FCR_BREAKDOWN_CATEGORY_CODE_RENEWABLE_ENERGY_CORRECT_CHARGE = "902";
  /** 確定料金実績内訳区分コード：契約超過金補正額(903) */
  public static final String FCR_BREAKDOWN_CATEGORY_CODE_CONTRACT_EXCESS_CHARGE = "903";
  /** 契約容量単位コード：A(1) */
  public static final String CCA_UNIT_AMPERE = "1";
  /** 契約容量単位コード：kVA(2) */
  public static final String CCA_UNIT_KILOVOLT_AMPERE = "2";
  /** 契約容量単位コード：kW(3) */
  public static final String CCA_UNIT_KILOWATT = "3";
  /** 業務日程区分コード:クレジットカード決済日(2) */
  public static final String WORK_SCHEDULE_CATEGORY_CODE_CREDIT_DATE = "2";
  /** 最低金額適用前（1） */
  public static final String SPL_APPLY_CAT_CODE_BEFORE = "1";
  /** 最低金額適用後（2） */
  public static final String SPL_APPLY_CAT_CODE_AFTER = "2";
  /** 更新コード：更新なし(0) */
  public static final String MONTHLY_USAGE_RESULT_UPDATE_CODE_NOT_MODIFIED = "0";
  /** ファイル分類コード:都道府県別使用量集計ファイル */
  public static final String FILE_CATEGORY_CODE_PREFECTURAL_USAGE_TOTALING_FILE = "31";
  /** ファイル分類コード:再エネ賦課金および電力取引報用諸元リスト */
  public static final String FILE_CATEGORY_CODE_RE_ENERGYDUES_POWER_FILE = "32";
  /** 付帯種別コード：電力毎（3） */
  public static final String SUPPLEMENTARY_CLASS_CODE_EVERY_POWER = "3";
  /** ファイル分類コード:請求データ(A1) */
  public static final String CUSTOM_FILE_CATEGORY_CODE_BILLING_DATA = "A1";
  /** 合算指示区分:ガス合算(A) */
  public static final String CUSTOM_ADD_UP_INDICATION_CATEGORY_CODE_GAS_ADD_UP = "A";
  /** 合算指示区分:電気単独(B) */
  public static final String CUSTOM_ADD_UP_INDICATION_CATEGORY_CODE_ELECTRIC_SINGLE = "B";
  /** 電圧区分コード:低圧 */
  public static final String CUSTOM_VOLTAGE_CAT_CODE_LOW_TENSION = "1";
  /** 電圧区分コード:高圧 */
  public static final String CUSTOM_VOLTAGE_CAT_CODE_HIGH_TENSION = "2";
  /** 電圧区分コード:特高 */
  public static final String CUSTOM_VOLTAGE_CAT_CODE_SPECIALLY_HIGH = "3";
  /** スマートメータ区分コード: 従来機器（0） */
  public static final String SMART_METER_CATEGORY_CODE_NOT_REPLACED = "0";
  /** スマートメータ区分コード: 前回検針後にスマメ切替（1） */
  public static final String SMART_METER_CATEGORY_CODE_REPLACED_AFTER_LAST_METER_READING = "1";
  /** スマートメータ区分コード: スマメ切替済（2） */
  public static final String SMART_METER_CATEGORY_CODE_REPLACED_BEFORE_LAST_METER_READING = "2";
  /** 30分値収集可否・自動検針可否コード:３０分値収集不可（0） */
  public static final String AUTOMATIC_METER_READING_CHECK_CODE_UNAVAILABLE = "0";
  /** 30分値収集可否・自動検針可否コード:３０分値収集可 自動検針可（1） */
  public static final String AUTOMATIC_METER_READING_CHECK_CODE_AVAILABLE_AVAILABLE = "1";
  /** 30分値収集可否・自動検針可否コード:３０分値収集可 自動検針不可（2） */
  public static final String AUTOMATIC_METER_READING_CHECK_CODE_AVAILABLE_UNAVAILABLE = "2";
  /** 30分値収集可否・自動検針可否コード:未計器（協定扱）（8） */
  public static final String AUTOMATIC_METER_READING_CHECK_CODE_NO_METER = "8";
  /** 減設フラグ：ON */
  public static final String REDUCE_CONTRACT_CAPACITY_FLG_ON = "1";
  /** 減設フラグ：OFF */
  public static final String REDUCE_CONTRACT_CAPACITY_FLG_OFF = "0";
  /** 実量歴取込済フラグ：ON */
  public static final String REAL_QUANTITY_IMPORT_COMPLETE_FLAG_ON = "1";
  /** 実量歴取込済フラグ：OFF */
  public static final String REAL_QUANTITY_IMPORT_COMPLETE_FLAG_OFF = "0";
  /** 実量歴必須フラグ：任意(0) */
  public static final String ACTUAL_RECORD_REQUIRED_FLAG_OFF = "0";
  /** 実量歴必須フラグ：必須(1) */
  public static final String ACTUAL_RECORD_REQUIRED_FLAG_ON = "1";
  /** 契約電力決定区分コード：協議制(1) */
  public static final String CONTRACT_CAPACITY_DECISION_CATEGORY_CODE_DISCUSSIONS = "1";
  /** 契約電力決定区分コード：実量制(2) */
  public static final String CONTRACT_CAPACITY_DECISION_CATEGORY_CODE_REALQUANTITY = "2";
  /** 計器区分コード：常用(1) */
  public static final String METER_CATEGORY_CODE_NORMAL = "1";
  /** 警告種別コード：計量器交換・臨時検針データ受信 */
  public static final String WARNING_CLASS_CODE_METER_CHANGE_AND_SPECIAL_METER_READING_DATA_RECEIVE = "354";
  /** 対応要否フラグ：要(1) */
  public static final String DEAL_NEED_FLAG_NEED = "1";
  /** ファイル分類コード:請求データ（低圧高圧）(B1) */
  public static final String FILE_CATEGORY_CODE_BILLING_DATA_B1 = "B1";
  /** 契約決定方法：システム管理対象外(4) */
  public static final String CONTRACT_DECISION_WAY_CODE_SYSTEM_MANAGE_NA = "4";
  /** 警告対応区分マスタ：対応要 */
  public static final String WARNING_DEAL_CATEGORY_MASTER_NECESSARY = "2";
  /** ファイル分類コード:需要家契約情報ファイル(12) */
  public static final String FILE_CATEGORY_CODE_RETAILER_CONTRACT_INFO = "12";
  /** 確定対象料金計算月フラグ：ON */
  public static final String FIX_COVERED_CHARGE_CALC_MONTH_FLAG_ON = "1";
  /** 確定対象料金計算月フラグ：OFF */
  public static final String FIX_COVERED_CHARGE_CALC_MONTH_FLAG_OFF = "0";
  /** 検針日区分コード：分散検針 */
  public static final String METER_READING_DATE_CATEGORY_DISPERSION = "1";
  /** 検針日区分コード：定例日検針 */
  public static final String METER_READING_DATE_CATEGORY_REGULAR_DAY = "2";
  /** 日割山複数有無区分コード：無し */
  public static final String PRORATED_UNIT_MULTIPLE_CATEGORY_CODE_NOT_EXISTS = "0";
  /** 日割山複数有無区分コード：有り */
  public static final String PRORATED_UNIT_MULTIPLE_CATEGORY_CODE_EXISTS = "1";
  /** 割引対象コード：接続(10) */
  public static final String D_COVERED_CODE_CONNECT = "10";
  /** 割引対象コード：予備A(11) */
  public static final String D_COVERED_CODE_RESERVE_A = "11";
  /** 割引対象コード：予備B(12) */
  public static final String D_COVERED_CODE_RESERVE_B = "12";
  /** 割引対象コード：低圧(30) */
  public static final String D_COVERED_CODE_LOW_TENSION = "30";
  /** 部分供給区分コード：仕訳なし(0) */
  public static final String PS_INFO_CAT_CODE_NOT_CATEGORIZE = "0";
  /** 警告種別コード：計算済みの制限中止割引情報に更新あり */
  public static final String WARNING_CLASS_CODE_RES_DISCOUNT_INFO_UPDATED = "362";
  /** 請求ステータスコード:繰越(7) */
  public static final String BILLING_STATUS_CODE_CALLY_OVER = "7";
  /** 業務日数コード：決済予定日日数 */
  public static final String SETTLEMENT_SCHEDULED_DATE = "21";
  /** 送金依頼待 */
  public static final String REGIST_REMITTANCE_REQUEST_WAIT = "1";
  /** 送金依頼失敗 */
  public static final String REGIST_REMITTANCE_REQUEST_ERROR = "2";
  /** 送金依頼済 */
  public static final String REGIST_REMITTANCE_SUBMITTED = "3";
  /** 送金失敗 */
  public static final String REGIST_REMITTANCE_ERROR = "4";
  /** 送金完了 */
  public static final String REGIST_REMITTANCE_FINISH = "5";
  /** 無効 */
  public static final String REGIST_REMITTANCE_INVALID = "9";
  /** 送金指示登録（API連携） */
  public static final String REGIST_REMITTANCE_API_REGIST = "1";

}
