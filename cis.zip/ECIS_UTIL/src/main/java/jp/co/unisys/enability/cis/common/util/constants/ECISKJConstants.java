package jp.co.unisys.enability.cis.common.util.constants;

import java.math.BigDecimal;

/**
 * 定数クラス
 *
 * @author "Nihon Unisys, Ltd."
 */
public class ECISKJConstants {

  /** まとめ請求:まとめ請求なし */
  public static final String SUMMARY_BILLING_SUMMARY_BILLING_FALSE = "まとめ請求なし";
  /** まとめ請求:まとめ請求あり */
  public static final String SUMMARY_BILLING_SUMMARY_BILLING_TRUE = "まとめ請求あり";
  /** まとめ請求有無:無 */
  public static final String SUMMARY_BILLING_CHECK_FALSE = "無";
  /** まとめ請求有無:有 */
  public static final String SUMMARY_BILLING_CHECK_TRUE = "有";
  /** 複数月まとめ請求有無:無 */
  public static final String MULTIPLE_MONTHS_SUMMARY_BILLING_CHECK_FALSE = "無";
  /** 複数月まとめ請求有無:有 */
  public static final String MULTIPLE_MONTHS_SUMMARY_BILLING_CHECK_TRUE = "有";
  /** 契約者利用状況:利用可能 */
  public static final String CONTRACTOR_USE_STATUS_USE_POSSIBLE = "利用可能";
  /** 契約者利用状況:利用不能 */
  public static final String CONTRACTOR_USE_STATUS_USE_IMPOSSIBLE = "利用不能";
  /** 見える化利用状況:未利用 */
  public static final String VISUALIZATION_USE_STATUS_NON_USE = "未利用";
  /** 見える化利用状況:利用 */
  public static final String VISUALIZATION_USE_STATUS_USE = "利用";
  /** 個別設定:不可 */
  public static final String INDIVIDUAL_SETTING_IMPOSSIBLE = "不可";
  /** 個別設定:必須 */
  public static final String INDIVIDUAL_SETTING_MUST = "必須";
  /** 口振クレカ翌月請求:翌月にしない */
  public static final String DIRECT_DEBIT_CREDIT_CARD_NEXT_MONTH_BILLING_NEXT_MONTH_FALSE = "翌月にしない";
  /** 口振クレカ翌月請求:翌月にする */
  public static final String DIRECT_DEBIT_CREDIT_CARD_NEXT_MONTH_BILLING_NEXT_MONTH_TRUE = "翌月にする";
  /** 督促対象:督促対象 */
  public static final String URGE_COVERED_URGE_COVERED = "督促対象";
  /** 督促対象:督促対象外 */
  public static final String URGE_COVERED_URGE_NOT_COVERED = "督促対象外";
  /** 料金チェック:料金チェックなし */
  public static final String CHARGE_CHECK_CHARGE_CHECK_FALSE = "料金チェックなし";
  /** 料金チェック:料金チェックする */
  public static final String CHARGE_CHECK_CHARGE_CHECK_TRUE = "料金チェックする";
  /** 個別設定:なし(0) */
  public static final String INDIVIDUAL_SETTING_FLAG_OFF = "0";
  /** 個別設定:あり(1) */
  public static final String INDIVIDUAL_SETTING_FLAG_ON = "1";
  /** 契約終了後:未終了(0) */
  public static final String CONTRACT_END_FLAG_NON_END = "0";
  /** 契約終了後:終了済(1) */
  public static final String CONTRACT_END_FLAG_END_COMPLETED = "1";
  /** 付帯契約更新:更新不可(0) */
  public static final String SUPPLEMENTARY_CONTRACTUPDATE_FLAG_UPDATE_IMPOSSIBLE = "0";
  /** 付帯契約更新:更新可(1) */
  public static final String SUPPLEMENTARY_CONTRACTUPDATE_FLAG_UPDATE_POSSIBLE = "1";
  /** 付帯契約削除:削除不可(0) */
  public static final String SUPPLEMENTARY_CONTRACTDELETE_FLAG_DELETE_IMPOSSIBLE = "0";
  /** 付帯契約削除:削除可(1) */
  public static final String SUPPLEMENTARY_CONTRACTDELETE_FLAG_DELETE_POSSIBLE = "1";
  /** 督促対象外:督促対象(0) */
  public static final String URGE_NOT_COVERED_FLAG_URGE_COVERED = "0";
  /** 督促対象外:督促対象外(1) */
  public static final String URGE_NOT_COVERED_FLAG_URGE_NOT_COVERED = "1";
  /** 利用不能:利用可能(0) */
  public static final String UNAVAILABLE_FLAG_USE_POSSIBLE = "0";
  /** 利用不能:利用不可(1) */
  public static final String UNAVAILABLE_FLAG_USE_IMPOSSIBLE = "1";
  /** まとめ請求:まとめ請求なし(0) */
  public static final String COMBINED_BILLING_FLAG_SUMMARY_BILLING_OFF = "0";
  /** まとめ請求:まとめ請求あり(1) */
  public static final String COMBINED_BILLING_FLAG_SUMMARY_BILLING_ON = "1";
  /** 複数月まとめ請求:複数月まとめ請求なし(0) */
  public static final String MULTIPLE_MONTHS_COMBINED_BILLING_OFF = "0";
  /** 複数月まとめ請求:複数月まとめ請求あり(1) */
  public static final String MULTIPLE_MONTHS_COMBINED_BILLING_ON = "1";
  /** 料金チェック:補正なし(0) */
  public static final String CHARGE_CHECK_FLAG_CORRECTION_OFF = "0";
  /** 料金チェック:補正あり(1) */
  public static final String CHARGE_CHECK_FLAG_CORRECTION_ON = "1";
  /** 口振クレカ翌月請求:当月請求(0) */
  public static final String DIRECT_DEBIT_CREDIT_CARD_NEXT_MONTH_BILLING_FLAG_CURRENT_MONTH_BILLING = "0";
  /** 口振クレカ翌月請求:翌月請求(1) */
  public static final String DIRECT_DEBIT_CREDIT_CARD_NEXT_MONTH_BILLING_FLAG_NEXT_MONTH_BILLING = "1";
  /** 検索実施済み:未検索(0) */
  public static final String SEARCH_ENFORCE_COMPLETED_FLAG_NON_SEARCH = "0";
  /** 検索実施済み:検索済(1) */
  public static final String SEARCH_ENFORCE_COMPLETED_FLAG_SEARCH_COMPLETED = "1";
  /** 計器交換:未交換(0) */
  public static final String METER_REPLACEMENT_FLAG_NON_REPLACEMENT = "0";
  /** 計器交換交換済(1) */
  public static final String METER_REPLACEMENT_FLAGREPLACEMENT_COMPLETED = "1";
  /** 遷移可能:遷移不可(0) */
  public static final String TRANSITION_POSSIBLE_FLAG_TRANSITION_IMPOSSIBLE = "0";
  /** 遷移可能遷移可(1) */
  public static final String TRANSITION_POSSIBLE_FLAG_TRANSITION_POSSIBLE = "1";
  /** 表示:表示不可(0) */
  public static final String DISPLAY_FLAG_NON_DISPLAY = "0";
  /** 表示:表示可(1) */
  public static final String DISPLAY_FLAG_DISPLAY = "1";
  /** 完了:未完了(0) */
  public static final String COMPLETED_FLAG_NON_COMPLETE = "0";
  /** 完了完了済(1) */
  public static final String COMPLETED_FLAGCOMPLETE_COMPLETED = "1";
  /** 見える化提供:未提供(0) */
  public static final String VISUALIZATION_PROVIDE_FLAG_NON_PROVIDE = "0";
  /** 見える化提供:提供(1) */
  public static final String VISUALIZATION_PROVIDE_FLAG_PROVIDE = "1";
  /** 提供モデル企業有効:有効な企業 */
  public static final String PROVIDE_MODEL_COMPANYEFFECTIVE_FLAG_EFFECTIVE_COMPANY = "0";
  /** 提供モデル企業有効:全て */
  public static final String PROVIDE_MODEL_COMPANYEFFECTIVE_FLAG_ALL = "1";
  /** 契約終了分確定使用量連携済:未連携(0) */
  public static final String CONTRACT_END_FIX_USAGE_SENT_FLAG_NON_LINKAGE = "0";
  /** 契約終了分確定使用量連携済:連携済(1) */
  public static final String CONTRACT_END_FIX_USAGE_SENT_FLAG_LINKAGE_COMPLETED = "1";
  /** 合算請求:未合算請求(0) */
  public static final String ADD_UP_BILLING_FLAG_NON_ADD_UP_BILLING = "0";
  /** 合算請求:合算請求(1) */
  public static final String ADD_UP_BILLING_FLAG_ADD_UP_BILLING = "1";
  /** 先延ばし支払期日:未延長(0) */
  public static final String PROCRASTINATIONPAYMENT_FIXED_DATEFLAG_NON_EXTENSION = "0";
  /** 先延ばし支払期日:延長済(1) */
  public static final String PROCRASTINATIONPAYMENT_FIXED_DATEFLAG_EXTENSION_COMPLETED = "1";
  /** 複合消込:未複合消込(0) */
  public static final String MULTIPLE_RECONCILE_FLAG_NON_MULTIPLE_RECONCILE = "0";
  /** 複合消込:複合消込済(1) */
  public static final String MULTIPLE_RECONCILE_FLAG_MULTIPLE_RECONCILE_COMPLETED = "1";
  /** 請求消込時充当有無:未充当(0) */
  public static final String BILLING_RECONCILE_APPROPRIATION_FLAG_NON_APPROPRIATION = "0";
  /** 請求消込時充当有無:充当済(1) */
  public static final String BILLING_RECONCILE_APPROPRIATION_FLAG_APPROPRIATION_COMPLETED = "1";
  /** 債権回収依頼対象:未依頼(0) */
  public static final String COMMISSION_COLLECTION_CLAIM_COVERED_FLAG_NON_ASK = "0";
  /** 債権回収依頼対象:依頼済(1) */
  public static final String COMMISSION_COLLECTION_CLAIM_COVERED_FLAG_ASK_COMPLETED = "1";
  /** 営業委託先企業有効:有効な企業 */
  public static final String SALES_CONSIGNMENT_COMPANY_EFFECTIVE_FLAG_EFFECTIVE_COMPANY = "0";
  /** 営業委託先企業有効:全て */
  public static final String SALES_CONSIGNMENT_COMPANY_EFFECTIVE_FLAG_ALL = "1";
  /** 予備契約更新:更新不可(0) */
  public static final String RESERVE_CONTRACTUPDATE_FLAG_UPDATE_IMPOSSIBLE = "0";
  /** 予備契約更新:更新可(1) */
  public static final String RESERVE_CONTRACTUPDATE_FLAG_UPDATE_POSSIBLE = "1";
  /** 予備契約削除:削除不可(0) */
  public static final String RESERVE_CONTRACTDELETE_FLAG_DELETE_IMPOSSIBLE = "0";
  /** 予備契約削除:削除可(1) */
  public static final String RESERVE_CONTRACTDELETE_FLAG_DELETE_POSSIBLE = "1";
  /** 利用状況:利用可能(0) */
  public static final String USAGE_SITUSTION_USE_POSSIBLE = "0";
  /** 利用状況:利用不可含む(1) */
  public static final String USAGE_SITUSTION_UNSABLE_INCLUDE = "1";
  /** 契約管理情報ダウンロード：ファイル名接頭辞：契約者 */
  public static final String CONTRACT_MANAGEMENT_INFORMATION_DOWNLOAD_FILE_PREFIX_CONTRACTOR = "contractor";
  /** 契約管理情報ダウンロード：ファイル名接頭辞：支払 */
  public static final String CONTRACT_MANAGEMENT_INFORMATION_DOWNLOAD_FILE_PREFIX_PAYMENT = "payment";
  /** 契約管理情報ダウンロード：ファイル名接頭辞：口座クレカ */
  public static final String CONTRACT_MANAGEMENT_INFORMATION_DOWNLOAD_FILE_PREFIX_ACCOUNT_CREDIT_CARD = "accountCreditCard";
  /** 契約管理情報ダウンロード：ファイル名接頭辞：契約 */
  public static final String CONTRACT_MANAGEMENT_INFORMATION_DOWNLOAD_FILE_PREFIX_CONTRACT = "contract";
  /** 契約管理情報ダウンロード：ファイル名接頭辞：付帯契約 */
  public static final String CONTRACT_MANAGEMENT_INFORMATION_DOWNLOAD_FILE_PREFIX_SUPPLEMENTARY_CONTRACT = "supplementaryContract";
  /** 契約管理情報ダウンロード：ファイル名接頭辞：メータ設置場所 */
  public static final String CONTRACT_MANAGEMENT_INFORMATION_DOWNLOAD_FILE_PREFIX_METER_LOCATION = "meterLocation";
  /** 契約管理情報ダウンロード：ファイル名接頭辞：契約・メータ */
  public static final String CONTRACT_MANAGEMENT_INFORMATION_DOWNLOAD_FILE_PREFIX_CONTRACT_METER = "contractMeter";
  /** 契約管理情報ダウンロード：ファイル種別：契約者 */
  public static final String CONTRACT_MANAGEMENT_INFORMATION_DOWNLOAD_FILE_CLASS_CONTRACTOR = "1";
  /** 契約管理情報ダウンロード：ファイル種別：支払 */
  public static final String CONTRACT_MANAGEMENT_INFORMATION_DOWNLOAD_FILE_CLASS_PAYMENT = "2";
  /** 契約管理情報ダウンロード：ファイル種別：口座クレカ */
  public static final String CONTRACT_MANAGEMENT_INFORMATION_DOWNLOAD_FILE_CLASS_ACCOUNT_CREDIT_CARD = "3";
  /** 契約管理情報ダウンロード：ファイル種別：契約 */
  public static final String CONTRACT_MANAGEMENT_INFORMATION_DOWNLOAD_FILE_CLASS_CONTRACT = "4";
  /** 契約管理情報ダウンロード：ファイル種別：付帯契約 */
  public static final String CONTRACT_MANAGEMENT_INFORMATION_DOWNLOAD_FILE_CLASS_SUPPLEMENTARY_CONTRACT = "5";
  /** 契約管理情報ダウンロード：ファイル種別：メータ設置場所 */
  public static final String CONTRACT_MANAGEMENT_INFORMATION_DOWNLOAD_FILE_CLASS_METER_LOCATION = "6";
  /** 契約管理情報ダウンロード：ファイル種別：契約・メータ */
  public static final String CONTRACT_MANAGEMENT_INFORMATION_DOWNLOAD_FILE_CLASS_CONTRACT_METER = "7";
  /** 契約管理情報アップロード：表題：契約者情報ファイル */
  public static final String CONTRACT_MANAGEMENT_INFORMATION_DOWNLOAD_FILE_TITLE_VALUE_CONTRACTOR = "レコード種別,契約者番号,外部システム契約者番号,個人・法人区分コード,契約者名1（カナ）,契約者名1,契約者名2,契約者名1（宛名用）,契約者名2（宛名用）,敬称,契約者住所（郵便番号）,契約者住所（都道府県名）,契約者住所（市区郡町村名）,契約者住所（字名・丁目）,契約者住所（番地･号）,契約者住所（建物名）,契約者住所（部屋名）,契約者電話区分コード1,契約者電話1（市外局番）,契約者電話1（市内局番）,契約者電話1（加入者番号）,契約者電話区分コード2,契約者電話2（市外局番）,契約者電話2（市内局番）,契約者電話2（加入者番号）,契約者メールアドレス1,契約者メールアドレス2,提供モデルコード,提供モデル企業コード,取引先コード,督促対象外フラグ,見える化提供フラグ,備考,利用不能フラグ,卸取次店契約者番号,フリー項目1,フリー項目2,フリー項目3,フリー項目4,フリー項目5,フリー項目6,フリー項目7,フリー項目8,フリー項目9,フリー項目10,更新回数,登録・更新区分";
  /** 契約管理情報アップロード：表題：支払情報ファイル */
  public static final String CONTRACT_MANAGEMENT_INFORMATION_DOWNLOAD_FILE_TITLE_VALUE_PAYMENT = "レコード種別,契約者番号,支払番号,外部システム契約番号,外部システム支払番号,支払期限区分,個別支払期限（月数）,個別支払期限（日）,請求合算フラグ,口振クレカ翌月請求フラグ,口座クレカID,個人・法人区分コード,支払適用開始日,支払方法コード,請求先氏名1,請求先氏名2,敬称,請求先住所（郵便番号）,請求先住所（都道府県名）,請求先住所（市区郡町村名）,請求先住所（字名・丁目）,請求先住所（番地･号）,請求先住所（建物名）,請求先住所（部屋名）,請求先電話番号,請求先電話区分コード,請求先メールアドレス1,請求先メールアドレス2,フリー項目1,フリー項目2,更新回数,登録・更新・削除区分";
  /** 契約管理情報アップロード：表題：口座クレカ情報ファイル */
  public static final String CONTRACT_MANAGEMENT_INFORMATION_DOWNLOAD_FILE_TITLE_VALUE_ACCOUNT_CREDIT_CARD = "レコード種別,契約者番号,口座クレカID,決済アクセスキー,口座クレカ区分コード,金融機関コード,金融機関支店コード,金融機関預金種目コード,口座番号,口座名義,クレカ番号,クレカ有効期限,クレカブランドコード,利用不能フラグ,登録区分";
  /** 契約管理情報アップロード：表題：契約情報ファイル */
  public static final String CONTRACT_MANAGEMENT_INFORMATION_DOWNLOAD_FILE_TITLE_VALUE_CONTRACT = "レコード種別,契約番号,契約者番号,支払番号,メータ設置場所ID,契約グループ番号,契約開始日,契約終了日,契約終了理由コード,託送契約容量,託送契約容量単位,託送契約容量判定日,料金チェックフラグ,個人・法人区分コード,連絡先氏名（カナ）,連絡先氏名1,連絡先氏名2,連絡先住所（郵便番号）,連絡先住所（住所）,連絡先住所（建物・部屋名）,連絡先電話区分コード,連絡先電話（市外局番）,連絡先電話（市内局番）,連絡先電話（加入者番号）,需要者窓口連絡先所属,需要者窓口連絡先氏名,需要者窓口連絡先電話番号（市外局番）,需要者窓口連絡先電話番号（市内局番）,需要者窓口連絡先電話番号（加入者番号）,主任技術者連絡先所属,主任技術者連絡先氏名,主任技術者連絡先電話番号（市外局番）,主任技術者連絡先電話番号（市内局番）,主任技術者連絡先電話番号（加入者番号）,接続送電サービス区分コード,部分供給区分コード,備考,実量歴必須フラグ,フリー項目1,フリー項目2,フリー項目3,フリー項目4,フリー項目5,フリー項目6,フリー項目7,フリー項目8,設備ID,フリー項目10,フリー項目11,フリー項目12,フリー項目13,フリー項目14,委託先使用項目1,委託先使用項目2,委託先使用項目3,自社担当者コード,自社部署コード,業種コード,営業委託先コード,営業担当者・組織コード,問合わせ先コード,適用開始日,料金メニューID,契約容量,契約変更理由,電圧区分,契約電力決定区分,単価設定区分,最低月額料金,DCEC区分コード１,時間帯コード１,枝番１,単価明細金額１,DCEC区分コード２,時間帯コード２,枝番２,単価明細金額２,DCEC区分コード３,時間帯コード３,枝番３,単価明細金額３,DCEC区分コード４,時間帯コード４,枝番４,単価明細金額４,DCEC区分コード５,時間帯コード５,枝番５,単価明細金額５,DCEC区分コード６,時間帯コード６,枝番６,単価明細金額６,DCEC区分コード７,時間帯コード７,枝番７,単価明細金額７,DCEC区分コード８,時間帯コード８,枝番８,単価明細金額８,DCEC区分コード９,時間帯コード９,枝番９,単価明細金額９,DCEC区分コード１０,時間帯コード１０,枝番１０,単価明細金額１０,DCEC区分コード１１,時間帯コード１１,枝番１１,単価明細金額１１,DCEC区分コード１２,時間帯コード１２,枝番１２,単価明細金額１２,DCEC区分コード１３,時間帯コード１３,枝番１３,単価明細金額１３,DCEC区分コード１４,時間帯コード１４,枝番１４,単価明細金額１４,DCEC区分コード１５,時間帯コード１５,枝番１５,単価明細金額１５,卸取次店契約番号,契約付加情報フリー項目1,契約付加情報フリー項目2,契約付加情報フリー項目3,契約付加情報フリー項目4,契約付加情報フリー項目5,契約付加情報フリー項目6,契約付加情報フリー項目7,契約付加情報フリー項目8,契約付加情報フリー項目9,契約付加情報フリー項目10,更新回数,登録・更新・削除区分,予備線契約開始日,予備線契約終了日,予備線容量,予備線更新回数,予備線登録・更新・削除区分,予備電源契約開始日,予備電源契約終了日,予備電源容量,予備電源更新回数,予備電源登録・更新・削除区分";
  /** 契約管理情報アップロード：表題：付帯契約情報ファイル */
  public static final String CONTRACT_MANAGEMENT_INFORMATION_DOWNLOAD_FILE_TITLE_VALUE_SUPPLEMENTARY_CONTRACT = "レコード種別,付帯契約ID,契約番号,付帯メニューID,付帯契約開始日,付帯契約終了日,額・率,更新回数,登録・更新・削除区分";
  /** 契約管理情報アップロード：表題：メータ設置場所情報ファイル */
  public static final String CONTRACT_MANAGEMENT_INFORMATION_DOWNLOAD_FILE_TITLE_VALUE_METER_LOCATION = "レコード種別,メータ設置場所ID,契約番号,需要場所住所（郵便番号）,需要場所住所（住所）,需要場所住所（建物・部屋名）,地点特定番号,需要家識別番号,エリアコード,基本検針日,次回検針予定日,前回検針日,送受電区分コード,自家発連携有無コード,供給方式コード,計器識別番号1,計器識別番号2,計器識別番号3,計器識別番号4,計器識別番号5,30分値収集可否・自動検針可否コード1,30分値収集可否・自動検針可否コード2,30分値収集可否・自動検針可否コード3,30分値収集可否・自動検針可否コード4,30分値収集可否・自動検針可否コード5,検針日区分コード,フリー項目1,フリー項目2,フリー項目3,フリー項目4,フリー項目5,フリー項目6,フリー項目7,フリー項目8,フリー項目9,フリー項目10,更新回数,登録・更新区分";
  /** 契約管理情報アップロード：表題：契約・メータ情報ファイル */
  public static final String CONTRACT_MANAGEMENT_INFORMATION_DOWNLOAD_FILE_TITLE_VALUE_CONTRACT_METER = "レコード種別,契約者番号,外部システム契約者番号,契約者個人・法人区分コード,契約者個人・法人区分,契約者名1（カナ）,契約者名1,契約者名2,契約者名1（宛名用）,契約者名2（宛名用）,敬称,契約者住所（郵便番号）,契約者住所（住所）,契約者住所（建物・部屋名）,契約者住所（都道府県名）,契約者住所（市区郡町村名）,契約者住所（字名・丁目）,契約者住所（番地･号）,契約者住所（建物名）,契約者住所（部屋名）,契約者電話番号1,契約者電話区分コード1,契約者電話区分1,契約者電話1（市外局番）,契約者電話1（市内局番）,契約者電話1（加入者番号）,契約者電話番号2,契約者電話区分コード2,契約者電話区分2,契約者電話2（市外局番）,契約者電話2（市内局番）,契約者電話2（加入者番号）,契約者メールアドレス1,契約者メールアドレス2,提供モデルコード,提供モデル,提供モデル企業コード,提供モデル企業,取引先コード,督促対象外フラグ,見える化提供フラグ,契約者備考,卸取次店契約者番号,契約者付加情報フリー項目1,契約者付加情報フリー項目2,契約者付加情報フリー項目3,契約者付加情報フリー項目4,契約者付加情報フリー項目5,契約者付加情報フリー項目6,契約者付加情報フリー項目7,契約者付加情報フリー項目8,契約者付加情報フリー項目9,契約者付加情報フリー項目10,契約番号,契約開始日,契約終了日,契約終了理由コード,契約終了理由,料金チェックフラグ,営業委託先コード,営業委託先,営業担当者・組織コード,問合わせ先コード,契約グループ番号,連絡先個人・法人区分コード,連絡先個人・法人区分,連絡先氏名（カナ）,連絡先氏名1,連絡先氏名2,連絡先住所（郵便番号）,連絡先住所（住所）,連絡先住所（建物・部屋名）,連絡先電話番号,連絡先電話区分コード,連絡先電話区分,連絡先電話（市外局番）,連絡先電話（市内局番）,連絡先電話（加入者番号）,需要者窓口連絡先所属,需要者窓口連絡先氏名,需要者窓口連絡先電話番号,需要者窓口連絡先電話番号（市外局番）,需要者窓口連絡先電話番号（市内局番）,需要者窓口連絡先電話番号（加入者番号）,主任技術者連絡先所属,主任技術者連絡先氏名,主任技術者連絡先電話番号,主任技術者連絡先電話番号（市外局番）,主任技術者連絡先電話番号（市内局番）,主任技術者連絡先電話番号（加入者番号）,業種コード,接続送電サービス区分コード,接続送電サービス区分,託送契約容量,託送契約容量単位コード,託送契約容量単位,託送契約容量判定日,契約終了分確定使用量連携済フラグ,部分供給区分コード,部分供給区分,契約備考,実量歴必須フラグ,フリー項目1,フリー項目2,フリー項目3,フリー項目4,フリー項目5,フリー項目6,フリー項目7,フリー項目8,設備ID,フリー項目10,フリー項目11,フリー項目12,フリー項目13,フリー項目14,委託先使用項目1,委託先使用項目2,委託先使用項目3,自社担当者コード,自社部署コード,適用開始日,適用終了日,料金メニューID,料金メニュー名,契約容量,契約容量単位,契約変更理由,電圧区分,契約電力決定区分,単価設定区分,最低月額料金,DCEC区分コード１,時間帯コード１,枝番１,単価明細金額１,DCEC区分コード２,時間帯コード２,枝番２,単価明細金額２,DCEC区分コード３,時間帯コード３,枝番３,単価明細金額３,DCEC区分コード４,時間帯コード４,枝番４,単価明細金額４,DCEC区分コード５,時間帯コード５,枝番５,単価明細金額５,DCEC区分コード６,時間帯コード６,枝番６,単価明細金額６,DCEC区分コード７,時間帯コード７,枝番７,単価明細金額７,DCEC区分コード８,時間帯コード８,枝番８,単価明細金額８,DCEC区分コード９,時間帯コード９,枝番９,単価明細金額９,DCEC区分コード１０,時間帯コード１０,枝番１０,単価明細金額１０,DCEC区分コード１１,時間帯コード１１,枝番１１,単価明細金額１１,DCEC区分コード１２,時間帯コード１２,枝番１２,単価明細金額１２,DCEC区分コード１３,時間帯コード１３,枝番１３,単価明細金額１３,DCEC区分コード１４,時間帯コード１４,枝番１４,単価明細金額１４,DCEC区分コード１５,時間帯コード１５,枝番１５,単価明細金額１５,卸取次店契約番号,契約付加情報フリー項目1,契約付加情報フリー項目2,契約付加情報フリー項目3,契約付加情報フリー項目4,契約付加情報フリー項目5,契約付加情報フリー項目6,契約付加情報フリー項目7,契約付加情報フリー項目8,契約付加情報フリー項目9,契約付加情報フリー項目10,地点特定番号,需要場所住所（郵便番号）,需要場所住所（住所）,需要場所住所（建物・部屋名）,エリアコード,エリア名称,需要家識別番号,送受電区分コード,送受電区分,自家発連携有無コード,自家発連携有無,基本検針日,次回検針予定日,前回検針日,供給方式コード,供給方式,計器識別番号1,計器識別番号2,計器識別番号3,計器識別番号4,計器識別番号5,30分値収集可否・自動検針可否コード1,30分値収集可否・自動検針可否1,30分値収集可否・自動検針可否コード2,30分値収集可否・自動検針可否2,30分値収集可否・自動検針可否コード3,30分値収集可否・自動検針可否3,30分値収集可否・自動検針可否コード4,30分値収集可否・自動検針可否4,30分値収集可否・自動検針可否コード5,30分値収集可否・自動検針可否5,検針日区分コード,検針日区分,メータ設置場所付加情報フリー項目1,メータ設置場所付加情報フリー項目2,メータ設置場所付加情報フリー項目3,メータ設置場所付加情報フリー項目4,メータ設置場所付加情報フリー項目5,メータ設置場所付加情報フリー項目6,メータ設置場所付加情報フリー項目7,メータ設置場所付加情報フリー項目8,メータ設置場所付加情報フリー項目9,メータ設置場所付加情報フリー項目10,利用不能フラグ";
  /** プレースフォルダ：30分値収集可否・自動検針可否コード1 */
  public static final String METER_LOCATION_AUTOMATIC_METER_READING_CKECK_CODE_1 = "1";
  /** プレースフォルダ：30分値収集可否・自動検針可否コード2 */
  public static final String METER_LOCATION_AUTOMATIC_METER_READING_CKECK_CODE_2 = "2";
  /** プレースフォルダ：30分値収集可否・自動検針可否コード3 */
  public static final String METER_LOCATION_AUTOMATIC_METER_READING_CKECK_CODE_3 = "3";
  /** プレースフォルダ：30分値収集可否・自動検針可否コード4 */
  public static final String METER_LOCATION_AUTOMATIC_METER_READING_CKECK_CODE_4 = "4";
  /** プレースフォルダ：30分値収集可否・自動検針可否コード5 */
  public static final String METER_LOCATION_AUTOMATIC_METER_READING_CKECK_CODE_5 = "5";
  /** エンティティ照会時：照会パターン:1 */
  public static final String INQUIRY_PATTERN_1 = "1";
  /** エンティティ照会時：照会パターン:2 */
  public static final String INQUIRY_PATTERN_2 = "2";
  /** エンティティ照会時：照会パターン:3 */
  public static final String INQUIRY_PATTERN_3 = "3";
  /** 支払番号発番時：支払番号先頭文字 */
  public static final String PAYMENT_NO_HEDDER = "P";
  /** 契約終了年月日等：最大日付 */
  public static final String APPLY_END_DATE_MAX = "99991231";
  /** validasionチェック用：最大文字数(1) */
  public static final int MAX_DEGIT_1 = 1;
  /** validasionチェック用：最大文字数(2) */
  public static final int MAX_DEGIT_2 = 2;
  /** validasionチェック用：最大文字数(3) */
  public static final int MAX_DEGIT_3 = 3;
  /** validasionチェック用：最大文字数(4) */
  public static final int MAX_DEGIT_4 = 4;
  /** validasionチェック用：最大文字数(6) */
  public static final int MAX_DEGIT_6 = 6;
  /** validasionチェック用：最大文字数(7) */
  public static final int MAX_DEGIT_7 = 7;
  /** validasionチェック用：最大文字数(8) */
  public static final int MAX_DEGIT_8 = 8;
  /** validasionチェック用：最大文字数(10) */
  public static final int MAX_DEGIT_10 = 10;
  /** validasionチェック用：最大文字数(12) */
  public static final int MAX_DEGIT_12 = 12;
  /** validasionチェック用：最大文字数(15) */
  public static final int MAX_DEGIT_15 = 15;
  /** validasionチェック用：最大文字数(16) */
  public static final int MAX_DEGIT_16 = 16;
  /** validasionチェック用：最大文字数(20) */
  public static final int MAX_DEGIT_20 = 20;
  /** validasionチェック用：最大文字数(21) */
  public static final int MAX_DEGIT_21 = 21;
  /** validasionチェック用：最大文字数(22) */
  public static final int MAX_DEGIT_22 = 22;
  /** validasionチェック用：最大文字数(24) */
  public static final int MAX_DEGIT_24 = 24;
  /** validasionチェック用：最大文字数(25) */
  public static final int MAX_DEGIT_25 = 25;
  /** validasionチェック用：最大文字数(27) */
  public static final int MAX_DEGIT_27 = 27;
  /** validasionチェック用：最大文字数(30) */
  public static final int MAX_DEGIT_30 = 30;
  /** validasionチェック用：最大文字数(35) */
  public static final int MAX_DEGIT_35 = 35;
  /** validasionチェック用：最大文字数(36) */
  public static final int MAX_DEGIT_36 = 36;
  /** validasionチェック用：最大文字数(40) */
  public static final int MAX_DEGIT_40 = 40;
  /** validasionチェック用：最大文字数(50) */
  public static final int MAX_DEGIT_50 = 50;
  /** validasionチェック用：最大文字数(60) */
  public static final int MAX_DEGIT_60 = 60;
  /** validasionチェック用：最大文字数(128) */
  public static final int MAX_DEGIT_128 = 128;
  /** validasionチェック用：最大文字数(200) */
  public static final int MAX_DEGIT_200 = 200;
  /** validasionチェック用：指定文字数(1) */
  public static final int JUST_DEGIT_1 = 1;
  /** validasionチェック用：指定文字数(3) */
  public static final int JUST_DEGIT_3 = 3;
  /** validasionチェック用：指定文字数(4) */
  public static final int JUST_DEGIT_4 = 4;
  /** validasionチェック用：指定文字数(6) */
  public static final int JUST_DEGIT_6 = 6;
  /** validasionチェック用：指定文字数(7) */
  public static final int JUST_DEGIT_7 = 7;
  /** validasionチェック用：整数部桁数(4) */
  public static final int PRECISION_4 = 4;
  /** validasionチェック用：整数部桁数(6) */
  public static final int PRECISION_6 = 6;
  /** validasionチェック用：小数部桁数(4) */
  public static final int SCALE_2 = 2;
  /** validasionチェック用：小数部桁数(6) */
  public static final int SCALE_3 = 3;
  /** validasionチェック用：最小値(0) */
  public static final int OFFSET_0 = 0;
  /** validasionチェック用：最小値(1) */
  public static final int OFFSET_1 = 1;
  /** validasionチェック用：最大値(1) */
  public static final int LIMIT_1 = 1;
  /** validasionチェック用：最大値(31) */
  public static final int LIMIT_31 = 31;
  /** validasionチェック用：最大値(2147483647) */
  public static final int LIMIT_2147483647 = 2147483647;
  /** プレースフォルダ：指定文字列 */
  public static final String INQUIRY_METER_LOCATION = "メータ設置場所の照会";
  /** 口座クレカ種別:口座 */
  public static final String ACCOUNT_CREDIT_CLASS_ACCOUNT = "口座";
  /** 口座クレカ種別:クレカ */
  public static final String ACCOUNT_CREDIT_CLASS_CREDIT = "クレカ";
  /** 照会パターン:4 */
  public static final String INQUIRY_PATTERN_4 = "4";
  /** 照会パターン:5 */
  public static final String INQUIRY_PATTERN_5 = "5";
  /** メッセージ検索不可エラー */
  public static final String NO_SUCH_MESSAGE_EXCEPTION_EMSG = "エラーメッセージが見つかりません。";
  /** 文字連結用全角スペース */
  public static final String STRING_BUILDER_ZENKAKU_SPACE = "　";
  /** 確定料金情報照会パターン1：検針日前チェック */
  public static final int INQUIRY_FIX_CHANGE_RESULT_INFOEMATION_FLG_ON = 1;
  /** 確定料金情報照会パターン0：料金算定終了日以前チェック */
  public static final int INQUIRY_FIX_CHANGE_RESULT_INFOEMATION_FLG_OFF = 0;
  /** 更新対象外：更新対象外(1) */
  public static final String NO_UPD_FLG_ON = "1";
  /** 更新対象外：更新対象(0) */
  public static final String NO_UPD_FLG_OFF = "0";
  /** 契約情報管理アップロードファイル_登録・更新・削除区分:登録 区分 */
  public static final String REGISTER_UPDATE_DELETE_CATEGORY_REGISTER = "I";
  /** 契約情報管理アップロードファイル_登録・更新・削除区分:更新 区分 */
  public static final String REGISTER_UPDATE_DELETE_CATEGORY_UPDATE = "U";
  /** 契約情報管理アップロードファイル_登録・更新・削除区分:削除 区分 */
  public static final String REGISTER_UPDATE_DELETE_CATEGORY_DELETE = "D";
  /** 契約管理情報ダウンロード：ファイル名：契約者 */
  public static final String CONTRACT_MANAGEMENT_INFORMATION_DOWNLOAD_FILE_CLASS_NAME_CONTRACTOR = "契約者情報ファイル";
  /** 契約管理情報ダウンロード：ファイル名：支払 */
  public static final String CONTRACT_MANAGEMENT_INFORMATION_DOWNLOAD_FILE_CLASS_NAME_PAYMENT = "支払情報ファイル";
  /** 契約管理情報ダウンロード：ファイル名：口座クレカ */
  public static final String CONTRACT_MANAGEMENT_INFORMATION_DOWNLOAD_FILE_CLASS_NAME_ACCOUNT_CREDIT_CARD = "口座クレカ情報ファイル";
  /** 契約管理情報ダウンロード：ファイル名：契約 */
  public static final String CONTRACT_MANAGEMENT_INFORMATION_DOWNLOAD_FILE_CLASS_NAME_CONTRACT = "契約情報ファイル";
  /** 契約管理情報ダウンロード：ファイル名：付帯契約 */
  public static final String CONTRACT_MANAGEMENT_INFORMATION_DOWNLOAD_FILE_CLASS_NAME_SUPPLEMENTARY_CONTRACT = "付帯契約情報ファイル";
  /** 契約管理情報ダウンロード：ファイル名：メータ設置場所 */
  public static final String CONTRACT_MANAGEMENT_INFORMATION_DOWNLOAD_FILE_CLASS_NAME_METER_LOCATION = "メータ設置場所情報ファイル";
  /** 契約管理情報ダウンロード：ファイル名：契約・メータ */
  public static final String CONTRACT_MANAGEMENT_INFORMATION_DOWNLOAD_FILE_CLASS_NAME_CONTRACT_METER = "契約・メータ情報ファイル";
  /** 契約管理情報ダウンロード：個人・法人区分 - すべて */
  public static final String PERSONAL_CORPORATION_CATEGORY_ALL_NAME = "すべて";
  /** メッセージへのバインド用文言：CSVファイル取得 */
  public static final String BIND_WORD_CSVFILE = "CSVファイル取得";
  /** 契約管理情報ダウンロード：レコード種別：ヘッダー */
  public static final String CONTRACT_MANAGEMENT_INFORMATION_DOWNLOAD_HEADER_RECORD = "0";
  /** 契約管理情報ダウンロード：レコード種別：データ */
  public static final String CONTRACT_MANAGEMENT_INFORMATION_DOWNLOAD_DATA_RECORD = "1";
  /** 契約管理情報ダウンロード：督促対象条件文言 */
  public static final String CONTRACT_MANAGEMENT_INFORMATION_DOWNLOAD_URGE_NOT_COVERED_FLAG_MESSAGE = "督促対象外分は除く";
  /** 契約管理情報ダウンロード：契約者利用状況条件文言 */
  public static final String CONTRACT_MANAGEMENT_INFORMATION_DOWNLOAD_UNAVAILABLE_FLAG_MESSAGE = "契約者利用不能分を含む";
  /** メッセージへのバインド用文言：終了日 */
  public static final String BIND_WORD_END_DATE = "終了日";
  /** 百分率変換用数字 */
  public static final BigDecimal PERCENTAGE_CONVERSION_NUMBER = BigDecimal.valueOf(100);
  /** 契約更新パターン：契約変更(0) */
  public static final String CONTRACT_UPDATE_PATTERN_CHANGE = "0";
  /** 契約更新パターン：契約終了(1) */
  public static final String CONTRACT_UPDATE_PATTERN_TERMINATE = "1";
  /** 契約更新パターン：変更予約(2) */
  public static final String CONTRACT_UPDATE_PATTERN_RESERVE = "2";
  /** 画面表示用：ラジオボタン(未設定)のラベル */
  public static final String RADIO_BUTTON_NONE_NAME = "未設定";
  /** 更新結果区分：正常終了(0) */
  public static final String UPDATE_RESULT_CATEGORY_SUCCESS = "0";
  /** 更新結果区分：業務エラー(1)： */
  public static final String UPDATE_RESULT_CATEGORY_ERROR = "1";
  /** 契約管理情報エラーリスト：ファイル名接頭辞 */
  public static final String CONTRACT_MANAGEMENT_INFORMATION_PREFIX_ERRORLIST_FILE = "errorlist_";
  /** 契約管理情報エラーリストファイル：ダウンロード最大リトライ回数 */
  public static final int CONTRACT_MANAGEMENT_INFORMATION_ERRORLIST_FILE_DOWNLOAD_MAX_RETRY_COUNT = 3;
  /** 契約管理情報エラーリストファイル：ダウンロードリトライ間隔（ミリ秒） */
  public static final int CONTRACT_MANAGEMENT_INFORMATION_ERRORLIST_FILE_RETRY_INTERVAL_MSEC = 3000;
  /** 外部ファイル取得できないエラーメッセージ */
  public static final String IO_EXCEPTION = "外部ファイルが取得できません";
  /** 契約管理情報ダウンロード検索条件：エリア */
  public static final String S010107_SEARCH_KEY_AREA = "area";
  /** 契約管理情報ダウンロード検索条件：契約番号 */
  public static final String S010107_SEARCH_KEY_CONTRACT_NO = "contractNo";
  /** 契約管理情報ダウンロード検索条件：契約者番号 */
  public static final String S010107_SEARCH_KEY_CONTRACTOR_NO = "contractorNo";
  /** 契約管理情報ダウンロード検索条件：外部システム契約者番号 */
  public static final String S010107_SEARCH_KEY_EXTERNAL_MANAGE_CONTRACTOR_NO = "externalManageContractorNo";
  /** 契約管理情報ダウンロード検索条件：契約者利用状況 */
  public static final String S010107_SEARCH_KEY_CONTRACTOR_USE_STATUS = "contractorUseStatus";
  /** 契約管理情報ダウンロード検索条件：契約期間(終了日From) */
  public static final String S010107_SEARCH_KEY_CONTRACT_TERM_END_DATE_FROM = "contractTermEndDateFrom";
  /** 契約管理情報ダウンロード検索条件：契約期間(終了日To) */
  public static final String S010107_SEARCH_KEY_CONTRACT_TERM_END_DATE_TO = "contractTermEndDateTo";
  /** 契約管理情報ダウンロード検索条件：契約期間(開始日) */
  public static final String S010107_SEARCH_KEY_CONTRACT_TERM_START_DATE = "contractTermStartDate";
  /** 契約管理情報ダウンロード検索条件：契約期間(開始日From) */
  public static final String S010107_SEARCH_KEY_CONTRACT_TERM_START_DATE_FROM = "contractTermStartDateFrom";
  /** 契約管理情報ダウンロード検索条件：契約期間(開始日To) */
  public static final String S010107_SEARCH_KEY_CONTRACT_TERM_START_DATE_TO = "contractTermStartDateTo";
  /** 契約管理情報ダウンロード検索条件：取引先コード */
  public static final String S010107_SEARCH_KEY_CUSTOMER_CODE = "customerCode";
  /** 契約管理情報ダウンロード検索条件：個人・法人区分 */
  public static final String S010107_SEARCH_KEY_INDIVIDUAL_LEGAL_ENTITY_CATEGORY = "individualLegalEntityCategory";
  /** 契約管理情報ダウンロード検索条件：オンライン処理基準日 */
  public static final String S010107_SEARCH_KEY_ONLINE_EXECUTE_BASE_DATE = "onlineExecuteBaseDate";
  /** 契約管理情報ダウンロード検索条件：支払適用期間(終了日) */
  public static final String S010107_SEARCH_KEY_PAYMENT_APPLY_TERM_END_DATE = "paymentApplyTermEndDate";
  /** 契約管理情報ダウンロード検索条件：支払適用期間(開始日) */
  public static final String S010107_SEARCH_KEY_PAYMENT_APPLY_TERM_START_DATE = "paymentApplyTermStartDate";
  /** 契約管理情報ダウンロード検索条件：支払番号 */
  public static final String S010107_SEARCH_KEY_PAYMENT_NO = "paymentNo";
  /** 契約管理情報ダウンロード検索条件：支払方法(支払方法マスタ) */
  public static final String S010107_SEARCH_KEY_PAYMENT_WAY = "paymentWay";
  /** 契約管理情報ダウンロード検索条件：提供モデル */
  public static final String S010107_SEARCH_KEY_PROVIDE_MODEL = "provideModel";
  /** 契約管理情報ダウンロード検索条件：提供モデル企業 */
  public static final String S010107_SEARCH_KEY_PROVIDE_MODEL_COMPANY = "provideModelCompany";
  /** 契約管理情報ダウンロード検索条件：料金メニュー */
  public static final String S010107_SEARCH_KEY_RATE_MENU = "rateMenu";
  /** 契約管理情報ダウンロード検索条件：地点特定番号 */
  public static final String S010107_SEARCH_KEY_SPOT_NO = "spotNo";
  /** 契約管理情報ダウンロード検索条件：付帯契約期間(終了日) */
  public static final String S010107_SEARCH_KEY_SUPPLEMENTARY_CONTRACT_TERM_END_DATE = "supplementaryContractTermEndDate";
  /** 契約管理情報ダウンロード検索条件：付帯契約期間(開始日) */
  public static final String S010107_SEARCH_KEY_SUPPLEMENTARY_CONTRACT_TERM_START_DATE = "supplementaryContractTermStartDate";
  /** 契約管理情報ダウンロード検索条件：付帯メニュー */
  public static final String S010107_SEARCH_KEY_SUPPLEMENTARY_MENU = "supplementaryMenu";
  /** 契約管理情報ダウンロード検索条件：送受電区分 */
  public static final String S010107_SEARCH_KEY_TRANSMISSION_CATEGORY = "transmissionCategory";
  /** 契約管理情報ダウンロード検索条件：督促対象 */
  public static final String S010107_SEARCH_KEY_URGE_COVERED = "urgeCovered";
  /** メッセージへのバインド用文言：CSVファイル */
  public static final String NOT_FOUND_UPLOAD_CSV_FILE = "CSVファイル";
  /** 契約管理情報ダウンロード検索条件：エリアマスタ_ソート条件定数 */
  public static final String S010107_AREAM_ORDER_BY_COLUMN = "area_code";
  /** 契約管理情報ダウンロード検索条件：口座クレカ区分マスタ_ソート条件定数 */
  public static final String S010107_ACCATM_ORDER_BY_COLUMN = "ac_cat_code";
  /** 契約管理情報ダウンロード検索条件：個人法人区分マスタ_ソート条件定数 */
  public static final String S010107_ILCM_ORDER_BY_COLUMN = "ilc_code";
  /** 契約管理情報ダウンロード検索条件：送受電区分マスタ_ソート条件定数 */
  public static final String S010107_TRANSMISSIONCATM_ORDER_BY_COLUMN = "transmission_cat_code";
  /** 空文字 */
  public static final String EMPTY_STRING = "";
  /** ソート条件：個人・法人区分コード */
  public static final String ORDER_BY_CLAUSE_ILC_CODE = "ilc_code";
  /** ソート条件：電話番号区分コード */
  public static final String ORDER_BY_CLAUSE_PHONE_NO_CAT_CODE = "phone_no_cat_code";
  /** ソート条件：接続送電サービス区分コード */
  public static final String ORDER_BY_CLAUSE_CSS_CAT_CODE = "css_cat_code";
  /** ソート条件：契約容量単位コード */
  public static final String ORDER_BY_CLAUSE_CCA_UNIT_CODE = "cca_unit_code";
  /** ソート条件：契約終了理由コード */
  public static final String ORDER_BY_CLAUSE_CONTRACT_END_REASON_CODE = "contract_end_reason_code";
  /** 単位：円 */
  public static final String UNIT_YEN = "円";
  /** 単位：％ */
  public static final String UNIT_PERCENT = "％";
  /** 契約管理情報ダウンロード検索条件：支払方法マスタ_ソート条件定数 */
  public static final String S010107_PWM_ORDER_BY_COLUMN = "pw_code";
  /** 処理結果コード：履歴のみ */
  public static final String PROCESSING_RESULT_HIST_ONLY = "0";
  /** 処理結果コード：親エンティティおよび履歴削除 */
  public static final String PROCESSING_RESULT_PARENTS_AND_HIST = "1";
  /** プレースフォルダ：契約 */
  public static final String PLACEHOLDER_CONTRACT = "契約";
  /** 敬称：様 */
  public static final String PREFIX_MR = "様";
  /** 敬称：御中 */
  public static final String PREFIX_DEAR = "御中";
  /** プレースフォルダ：提供モデル企業一覧 */
  public static final String PLACEHOLDER_PROVIDEMODELINFORMATION = "提供モデル企業一覧";
  /** プレースフォルダ：営業委託先企業一覧 */
  public static final String PLACEHOLDER_SALESCONSIGNMENTCOMPANY = "営業委託先企業一覧";
  /** プレースフォルダ：送受電区分マスタ */
  public static final String PLACEHOLDER_TRANSMISSIONCATEGORY = "送受電区分マスタ";
  /** ソート条件：支払方法コード */
  public static final String ORDER_BY_CLAUSE_PW_CODE = "pw_code";
  /** ブランク選択名：すべて */
  public static final String ALL_NAME = "すべて";
  /** 郵便番号3桁_切り出し終了インデックス： 3 */
  public static final int POSTALCODE_3DIGITS_END_INDEX = 3;
  /** 郵便番号4桁_切り出し開始インデックス： 3 */
  public static final int POSTALCODE_4DIGITS_START_INDEX = 3;
  /** 空文字（キー値） */
  public static final String EMPTY_STRING_KEY = "";
  /** プレースフォルダ：支払方法マスタ */
  public static final String PLACEHOLDER_PWM = "支払方法マスタ";
  /** JSON定義：契約情報一覧照会：JSONリスト名 */
  public static final String JSON_CONTRACT_INFO_LIST_NAME = "contractInfoListJson";
  /** ソート条件：エリアコード */
  public static final String ORDER_BY_AREA_CODE = "area_code";
  /** ソート条件：30分値収集可否・自動検針可否コード */
  public static final String ORDER_BY_AMRC_CODE = "amrc_code";
  /** プレースフォルダ：エリアマスタ */
  public static final String PLACEHOLDER_AREA = "エリアマスタ";
  /** プレースフォルダ：30分値収集可否・自動検針可否マスタ */
  public static final String PLACEHOLDER_AMRC = "30分値収集可否・自動検針可否マスタ";
  /** JSONファイル名 督促管理契約情報 */
  public static final String JSON_URGE_COVERED_CONTRACT_FILE_NAME = "URGECOVEREDCONTRACT";
  /** JSONリスト名 督料金メニュー等情報 促管理契約情報 */
  public static final String JSON_URGE_COVERED_CONTRACT_LIST_NAME = "UrgeCoveredContractListJson";
  /** 料金メニュー等一覧用セッションキー */
  public static final String SESSION_KEY_RATE_MENU = "_contract_";
  /** 付帯契約用セッションキー */
  public static final String SESSION_KEY_SPL_CONTRACT = "_supplementaryContract_";
  /** 契約情報検索情報：JSONリスト名 */
  public static final String JSON_CONTRACT_INFO_SCH_LIST_NAME = "contractInfoSchListJson";
  /** 契約管理情報ダウンロード検索条件：支払方法(口座クレカ区分マスタ) */
  public static final String S010107_SEARCH_KEY_ACCOUNT_CREDIT_CATEGORY_PAYMENT_WAY = "accountCreditCategoryPaymentWay";
  /** 郵便番号3桁_切り出し開始インデックス： 3 */
  public static final int POSTALCODE_3DIGITS_START_INDEX = 0;
  /** 契約情報一覧照会向けインデックスマップキー */
  public static final String MAP_KEY_CONTRACTOR = "contractor";
  /** 契約情報照会向けインデックスマップキー */
  public static final String MAP_KEY_CONTRACT = "contract";
  /** Integerフォーマット：#,### */
  public static final String FORMAT_INTEGER_COMMA = "#,###";
  /** JSONリスト名：請求入金一覧照会 */
  public static final String JSON_BILLING_DEPOSIT_INFO_LIST_NAME = "billingDepositInformationListJson";
  /** プレースフォルダ：メータ設置場所 */
  public static final String PLACEHOLDER_METER_LOCATION = "メータ設置場所";
  /** AJAXリクエストパラメータ：ボタン表示判定フラグ */
  public static final String BUTTON_DISPLAY_FLG = "buttonDisplayFlg";
  /** 見える化提供:未提供 */
  public static final String VISUALIZATION_PROVIDE_NON_PROVIDE = "未提供";
  /** 見える化提供:提供 */
  public static final String VISUALIZATION_PROVIDE_PROVIDE = "提供";
  /** 規定文字数:契約者名1 */
  public static final Integer REGULATION_NUMBER_CONTRACTORNAME1 = 22;
  /** 規定文字数:契約者名2 */
  public static final Integer REGULATION_NUMBER_CONTRACTORNAME2 = 27;
  /** 電話番号:最大桁数 */
  public static final Integer PHONE_MAX = 14;
  /** 月：１月 */
  public static final String MONTH_JANUARY = "01";
  /** 月：２月 */
  public static final String MONTH_FEBRUARY = "02";
  /** 月：３月 */
  public static final String MONTH_MARCH = "03";
  /** 月：４月 */
  public static final String MONTH_APRIL = "04";
  /** 月：５月 */
  public static final String MONTH_MAY = "05";
  /** 月：６月 */
  public static final String MONTH_JUNE = "06";
  /** 月：７月 */
  public static final String MONTH_JULY = "07";
  /** 月：８月 */
  public static final String MONTH_AUGUST = "08";
  /** 月：９月 */
  public static final String MONTH_SEPTEMBER = "09";
  /** 月：１０月 */
  public static final String MONTH_OCTOBER = "10";
  /** 月：１１月 */
  public static final String MONTH_NOVEMBER = "11";
  /** 月：１２月 */
  public static final String MONTH_DECEMBER = "12";
  /** 月数：12 */
  public static final int MONTH_LENTH = 12;
  /** HTML改行コード */
  public static final String HTML_BR = "<BR>";
  /** 利用状況等:フラグ */
  public static final String USE_STATUS_FLG = "フラグ";
  /** 単位：kWh */
  public static final String UNIT_KWH = "kWh";
  /** 単位：kW */
  public static final String UNIT_KW = "kW";
  /** インデックス初期値:0 */
  public static final String LIST_DEFAULT_INDEX = "0";
  /** JSONファイル名：確定料金実績情報 */
  public static final String JSON_FIX_CHARGE_RESULT_INFO_FILE_NAME = "FIX_CHARGE_RESULT";
  /** JSONリスト名：確定料金実績情報 */
  public static final String JSON_FIX_CHARGE_RESULT_INFO_LIST_NAME = "fixChargeResultInformationListJson";
  /** JSONファイル名：督促対象契約情報 */
  public static final String JSON_URGE_COVERED_CONTRACT_INFO_FILE_NAME = "URGE_COVERED_CONTRACT";
  /** JSONリスト名：督促対象契約情報 */
  public static final String JSON_URGE_COVERED_CONTRACT_INFO_LIST_NAME = "urgeCoveredContractInformationListJson";
  /** 表示名称1:列方向結合：フラグ */
  public static final String UNIT_ROW_DISPLAY_NAME1_FLG = "0";
  /** 表示名称1:行方向結合数 */
  public static final String UNIT_COLUMN_DISPLAY_NAME1 = "2";
  /** 月の桁数補足：0 */
  public static final String MONTH_ZERO = "0";
  /** JSONファイル名：付帯契約情報（過去を含む） */
  public static final String JSON_SPL_CONTRACT_PAST_FILE_NAME = "SPLCONTRACTINCPAST";
  /** JSONリスト名：付帯契約情報（過去を含む） */
  public static final String JSON_SPL_CONTRACT_PAST_LIST_NAME = "splPastListJson";
  /** JSONファイル名：付帯契約情報（現在有効な付帯契約） */
  public static final String JSON_SPL_CONTRACT_FILE_NAME = "SPLCONTRACT";
  /** JSONリスト名：付帯契約情報（現在有効な付帯契約） */
  public static final String JSON_SPL_CONTRACT_LIST_NAME = "splListJson";
  /** 付帯契約リストデフォルトのソートカラム */
  public static final String SPL_DEFAULT_SORT_COL = "2";
  /** 契約終了年月日等：最大日付(YYYY/MM/DD) */
  public static final String APPLY_END_DATE_MAX_YYYYMMDD_SLASH = "9999/12/31";
  /** 支払履歴情報取得：ソート順キー */
  public static final String PAYMENT_HIST_ORDER_BY_KEY = "payment_sd DESC";
  /** 付帯契約 額・率(定額) ：小数部桁数 */
  public static final int SUPPLEMENTARY_CONTRACT_AMOUNT_SCALE = 2;
  /** 確定料金情報照会パターン2：料金算定終了日同日チェック */
  public static final int INQUIRY_FIX_CHANGE_RESULT_INFOEMATION_FLG_TWO = 2;
  /** 確定料金情報照会パターン3：料金算定終了日前チェック */
  public static final int INQUIRY_FIX_CHANGE_RESULT_INFOEMATION_FLG_THREE = 3;
  /** 使用開始区分:使用開始前(1) */
  public static final String USE_BEFORE_START_BEFORE = "1";
  /** 使用開始区分:使用開始後(2) */
  public static final String USE_BEFORE_START_AFTER = "2";
  /** 契約容量単位コード：A */
  public static final String CCA_UNIT_CODE_A = "A";
  /** 契約容量単位コード：kVA */
  public static final String CCA_UNIT_CODE_KVA = "kVA";
  /** 契約容量単位コード：kW */
  public static final String CCA_UNIT_CODE_KW = "kW";
  /** パティングサイズ:10 */
  public static final int PAD_SIZE_10 = 10;
  /** パティングサイズ:3 */
  public static final int PAD_SIZE_3 = 3;
  /** パティングサイズ:5 */
  public static final int PAD_SIZE_5 = 5;
  /** パティングサイズ:22 */
  public static final int PAD_SIZE_22 = 22;
  /** パティングサイズ:19 */
  public static final int PAD_SIZE_19 = 19;
  /** パティングサイズ:8 */
  public static final int PAD_SIZE_8 = 8;
  /** パティングサイズ:12 */
  public static final int PAD_SIZE_12 = 12;
  /** パティングサイズ:11 */
  public static final int PAD_SIZE_11 = 11;
  /** 電圧種別: 0 */
  public static final String VOLTAGE_TYPE_0 = "0";
  /** 用途コード:88888 */
  public static final String USE_TYPE_88888 = "88888";
  /** 用途コード:88888 */
  public static final String USE_CODE_88888 = "88888";
  /** 週間需要計画作成用諸元リストファイル名 */
  public static final String SPECIFICATIONS_LIST_NAME = "weekly_demand_";
  /** ファイル拡張子：.dat */
  public static final String FILE_EXTENSION_DAT = ".dat";
  /** 契約者利用状況:利用可能 */
  public static final String CONTRACTOR_USE_STATUS_USE_POSSIBLE_VALUE = "利用可能";
  /** 契約情報検索情報_カスタム：JSONリスト名 */
  public static final String CUSTOM_JSON_CONTRACT_INFO_SCH_LIST_NAME = "contractInfoSchListJson";
  /** ソート条件：スマートメータ区分コード */
  public static final String ORDER_BY_SM_CAT_CODE = "sm_cat_code";
  /** アンパサンド */
  public static final String AMPERSAND = "&";
  /** タグ（開始） */
  public static final String TAG_START = "<";
  /** タグ（終了） */
  public static final String TAG_END = ">";
  /** HTML特殊文字：アンパサンド */
  public static final String HTML_UNIQUE_CHARACTER_AMPERSAND = "&amp;";
  /** HTML特殊文字：タグ（開始） */
  public static final String HTML_UNIQUE_CHARACTER_TAG_START = "&lt;";
  /** HTML特殊文字：タグ（終了） */
  public static final String HTML_UNIQUE_CHARACTER_TAG_END = "&gt;";
  /** 実量歴必須フラグ：任意 */
  public static final String ACTUAL_RECORD_REQUIRED_FLAG_ANY = "任意";
  /** 実量歴必須フラグ：必須 */
  public static final String ACTUAL_RECORD_REQUIRED_FLAG_MUST = "必須";
  /** 実量歴取込済フラグ：未取込 */
  public static final String ACTUAL_RECORD_IMPORT_FLAG_NOIMPORT = "未取込";
  /** 実量歴取込済フラグ：取込 */
  public static final String ACTUAL_RECORD_IMPORT_FLAG_IMPORT = "取込済";
  /** 支払期限区分：デフォルト */
  public static final String PAYMENT_EXPIRATION_CATEGORY_DEFAULT = "デフォルト";
  /** 支払期限区分：個別 */
  public static final String PAYMENT_EXPIRATION_CATEGORY_INDIVIDUAL = "個別";
  /** 支払期限区分：デフォルト(0) */
  public static final String PAYMENT_EXPIRATION_CATEGORY_FLAG_DEFAULT = "0";
  /** 支払期限区分：個別(1) */
  public static final String PAYMENT_EXPIRATION_CATEGORY_FLAG_INDIVIDUAL = "1";
  /** 前月請求合算：要 */
  public static final String BILLING_ADD_UP_NECESSARY = "要";
  /** 前月請求合算：否 */
  public static final String BILLING_ADD_UP_UNNECESSARY = "否";
  /** 前月請求合算：要(1) */
  public static final String BILLING_ADD_UP_FLAG_NECESSARY = "1";
  /** 前月請求合算：否(0) */
  public static final String BILLING_ADD_UP_FLAG_UNNECESSARY = "0";
  /** 支払期限日 */
  public static final String PAYMENT_EXPIRATION_DATE = "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,末";
  /** 支払期限日：値 */
  public static final String PAYMENT_EXPIRATION_DATE_VALUE = "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,99";
  /** 契約電力決定区分：実量制(2) */
  public static final String CC_DECISION_CATEGORY_REAL_QUANTITY = "2";
  /** ソート条件：契約決定方法コード */
  public static final String ORDER_BY_CD_WAY_CODE = "cd_way_code";
  /** 実量歴管理設定：実量歴管理取得_ソート条件_対象年月 降順 */
  public static final String RQH_ORDER_BY_CLAUSE_DESC = "covered_period DESC";
  /** 実量歴取込済フラグ：OFF */
  public static final String ACTUAL_RECORD_IMPORT_FLAG_OFF = "0";
  /** 実量歴取込済フラグ：ON */
  public static final String ACTUAL_RECORD_IMPORT_FLAG_ON = "1";
  /** ソート条件：契約電力決定区分コード */
  public static final String ORDER_BY_CLAUSE_CC_DECISION_CATEGORY_CODE = "cc_decision_category_code";
  /** ソート条件：電圧区分コード */
  public static final String ORDER_BY_CLAUSE_VOLTAGE_CAT_CODE = "voltage_cat_code";
  /** ソート条件：単価設定区分コード */
  public static final String ORDER_BY_CLAUSE_UP_CAT_CODE = "up_cat_code";
  /** ソート条件：割引対象コード */
  public static final String ORDER_BY_CLAUSE_D_CONVERED_CODE = "d_covered_code";
  /** 連動MENU：li（開始）及料金メニューID */
  public static final String INTERLOCK_MENU_TAG_LI_AND_VALUE_START = "<li data-keycode='";
  /** 連動MENU：li（開始）及料金メニューID */
  public static final String INTERLOCK_MENU_TAG_LI_AND_VALUE_MENUID = " data-menucode='";
  /** 連動MENU：契約容量単位の開始 */
  public static final String INTERLOCK_MENU_LI_AND_CCU_VALUE = " data-contractcapacityunit='";
  /** 連動MENU：エリアコードの開始 */
  public static final String INTERLOCK_MENU_LI_AND_AREA_VALUE = " data-areacode='";
  /** 連動MENU：適用開始日の開始 */
  public static final String INTERLOCK_MENU_LI_AND_APPLYSD_VALUE = " data-applysd='";
  /** 連動MENU：適用終了日の開始 */
  public static final String INTERLOCK_MENU_LI_AND_APPLYED_VALUE = " data-applyed='";
  /** 連動MENU：電圧区分の開始 */
  public static final String INTERLOCK_MENU_LI_AND_VLTCAT_VALUE = " data-voltagecatcode='";
  /** 連動MENU：契約電力決定区分の開始 */
  public static final String INTERLOCK_MENU_LI_AND_CCDCAT_VALUE = " data-ccdecisioncategorycode='";
  /** 連動基本料金：li（開始）及閾値 */
  public static final String INTERLOCK_BASIC_THRESHOLD_TAG_LI_AND_VALUE_START = "<li data-basic-thresholdname='";
  /** 連動基本料金：単価 */
  public static final String INTERLOCK_BASIC_UNITPRICE_TAG_LI_AND_VALUE = " data-basic-unitprice='";
  /** 連動電力量料金：li（開始）及閾値 */
  public static final String INTERLOCK_USAGE_THRESHOLD_TAG_LI_AND_VALUE_START = "<li data-usage-thresholdname='";
  /** 連動電力量料金：単価 */
  public static final String INTERLOCK_USAGE_UNITPRICE_TAG_LI_AND_VALUE = " data-usage-unitprice='";
  /** 連動：' */
  public static final String INTERLOCK_MENU_TAG_END_VALUE = "'";
  /** 実量歴管理設定：実量歴管理取得_ソート条件_対象年月 昇順 */
  public static final String RQH_ORDER_BY_CLAUSE = "covered_period";
  /** 契約電力決定区分：実量制 */
  public static final String CC_DECISION_CATEGORY_REAL_QUANTITY_NAME = "実量制";
  /** 連動最低月額料金フラグ */
  public static final String INTERLOCK_MMC_FLAG = "<li data-mmcflag='";
  /** 連動最低月額料金 */
  public static final String INTERLOCK_MMC = " data-mmc='";
  /** 連動基本料金：表示名称 */
  public static final String INTERLOCK_BASIC_DISPLAYNAME = " data-basic-displayname='";
  /** 連動電力量料金：表示名称 */
  public static final String INTERLOCK_USAGE_DISPLAYNAME = " data-usage-displayname='";
  /** 連動基本料金：表示名称 */
  public static final String BASIC_DISPLAYNAME = "基本料金";
  /** 画面表示用：個別支払期限（月数） */
  public static final String SCREEN_DISPLAY_INDIVIDUAL_PAYMENT_EXPIRATION_MONTHS = "ヵ月後の";
  /** 画面表示用：個別支払期限（日） */
  public static final String SCREEN_DISPLAY_INDIVIDUAL_PAYMENT_EXPIRATION_DATE = "日";
  /** 画面表示用：個別支払期限（末日） */
  public static final String SCREEN_DISPLAY_INDIVIDUAL_PAYMENT_EXPIRATION_LAST_DATE = "末";
  /** 卸取次店契約者番号:ダミー(dummy) */
  public static final String AGENTCONTRACTORNO_DUMMY = "dummy";
  /** ソート条件：検針日区分コード */
  public static final String ORDER_BY_MR_DATE_CAT_CODE = "mr_date_cat_code";
  /** ソート条件：業種コード */
  public static final String ORDER_BY_CLAUSE_BUSINESS_TYPE_CODE = "business_type_code";
  /** ソート条件：都道府県コード */
  public static final String ORDER_BY_PREFECTURE_CODE = "prefecture_code";
  /** 予備契約用セッションキー */
  public static final String SESSION_KEY_RESERVE_CONTRACT = "reserveContract";
  /** 制限中止割引情報用セッションキー */
  public static final String SESSION_KEY_RESTRICT_DISCOUNT_INFO = "restrictionDiscountInfo";
  /** JSONファイル名：制限中止割引情報 */
  public static final String JSON_RESTRICT_DISCOUNT_INFO_FILE_NAME = "RESTRICTDISCOUNTINFO";
  /** JSONリスト名：制限中止割引情報 */
  public static final String JSON_RESTRICT_DISCOUNT_INFO_LIST_NAME = "restrictDiscountInfoListJson";
  /** JSONファイル名：予備契約情報（過去を含む） */
  public static final String JSON_RESERVE_CONTRACT_PAST_FILE_NAME = "RESERVECONTRACTPAST";
  /** JSONリスト名：予備契約情報（過去を含む） */
  public static final String JSON_RESERVE_CONTRACT_PAST_LIST_NAME = "reserveContractPastListJson";
  /** JSONファイル名：予備契約情報（現在有効な予備契約） */
  public static final String JSON_RESERVE_CONTRACT_FILE_NAME = "RESERVECONTRACT";
  /** JSONリスト名：予備契約情報（現在有効な予備契約） */
  public static final String JSON_RESERVE_CONTRACT_LIST_NAME = "reserveContractListJson";
  /** 予備契約リストデフォルトのソートカラム */
  public static final String RESERVE_DEFAULT_SORT_COL = "2";
  /** 予備契約種別：予備線(0) */
  public static final String RESERVE_CONTRACT_CLASS_LINE = "0";
  /** 予備契約種別：予備電源(1) */
  public static final String RESERVE_CONTRACT_CLASS_POWER = "1";
  /** 予備契約種別名:予備線 */
  public static final String RESERVE_CONTRACT_CLASS_NAME_LINE = "予備線";
  /** 予備契約種別名:予備電源 */
  public static final String RESERVE_CONTRACT_CLASS_NAME_POWER = "予備電源";
  /** 口座クレカ区分マスタ:外部システム(外部システム合算) */
  public static final String ACCOUNT_CREDIT_CATEGORY_CODE_A = "A";
  /** 口座クレカ区分マスタ:外部システム(電気単独) */
  public static final String ACCOUNT_CREDIT_CATEGORY_CODE_B = "B";
  /** 口座クレカ区分マスタ:クレジットカード払い */
  public static final String ACCOUNT_CREDIT_CATEGORY_CODE_1 = "1";
  /** 口座クレカ区分マスタ:口座振替 */
  public static final String ACCOUNT_CREDIT_CATEGORY_CODE_2 = "2";
  /** 口座クレカ区分マスタ:請求時振込先(自社口座) */
  public static final String ACCOUNT_CREDIT_CATEGORY_CODE_4 = "4";
  /** 予備契約変更区分コード：変更なし(0) */
  public static final String RESERVE_CONTRACT_CATEGORY_CODE_NO_CHANGE = "0";
  /** 予備契約変更区分コード：登録(1) */
  public static final String RESERVE_CONTRACT_CATEGORY_CODE_ADD = "1";
  /** 予備契約変更区分コード：更新(2) */
  public static final String RESERVE_CONTRACT_CATEGORY_CODE_UPDATE = "2";
  /** 予備契約変更区分コード：削除(3) */
  public static final String RESERVE_CONTRACT_CATEGORY_CODE_DELETE = "3";
  /** ソート条件：口座クレカ区分コード */
  public static final String ORDER_BY_CLAUSE_AC_CAT_CODE = "ac_cat_code ASC";
  /** ソート条件：クレカブランドコード */
  public static final String ORDER_BY_CLAUSE_CRE_BRAND_CODE = "cre_brand_code ASC";
  /** ソート条件：金融機関コード、金融機関支店コード */
  public static final String ORDER_BY_CLAUSE_BANK_CODE_BANK_BRANCH_CODE = "bank_code ASC, bank_branch_code ASC";
  /** ソート条件：金融機関預金種目コード */
  public static final String ORDER_BY_CLAUSE_BT_OF_ACCOUNT_CODE = "bt_of_account_code ASC";
  /** 利用状況:利用可能 */
  public static final String USE_STATUS_USE_POSSIBLE = "利用可能";
  /** 利用状況:利用不能 */
  public static final String USE_STATUS_USE_IMPOSSIBLE = "利用不能";
  /** 支払情報一覧照会画面_カスタム向けインデックスマップキー：口座クレカ情報 */
  public static final String MAP_KEY_ACCOUNT_CREDIT_INFORMATION = "accountCreditInformation";
  /** 支払情報一覧照会画面_カスタム向けインデックスマップキー：支払情報 */
  public static final String MAP_KEY_PAYMENT_INFORMATION = "paymentInformation";
  /** 割引対象:予備A */
  public static final String D_COVERED_CODE_RESERVE_A = "11";
  /** 割引対象:予備B */
  public static final String D_COVERED_CODE_RESERVE_B = "12";
  /** 高圧・特高 */
  public static final String HIGH_TENSION = "高圧・特高";
  /** 処理フラグ(処理中) */
  public static final String PROCESSING_FLAG = "1";
  /** 日中料金計算処理ID */
  public static final String DAY_TIME_CHARGE_CULCULATION_PROCESS_ID = "BRK0103";
  /** 登録最小日付 */
  public static final String REGISTER_MIN_DATE = "1900/01/01";
  /** ソート条件：部分供給区分コード */
  public static final String ORDER_BY_CLAUSE_PS_INFO_CAT_CODE = "ps_info_cat_code";
  /** ソート条件：料金メニュー単価明細（個別設定時） */
  public static final String ORDER_BY_RM_UP_DETAIL_INDIV = "up_apply_sd ,dcec_cat_code ,ts_code ,branch_no ,display_order ,detail_output_order";
  /** 基準日判定除外フラグ:除外 */
  public static final String BASE_DATE_EXCLUDE_FLAG_ON = "1";
}
