package jp.co.unisys.enability.cis.common.util;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.StringJoiner;

import org.apache.commons.lang3.StringUtils;

import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;

/**
 * 料金計算共通ユーティリティクラス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_CommonUtil {

  /**
   * 容量選択可能範囲を分解する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 1. 引数で指定された容量選択可能範囲をカンマ区切りの文字列に分解して返却する。
   * 1.1 固定値("10,20,30・・50")の場合、そのままの内容を返却する。
   * 1.2 範囲値("10-50")の場合、FROM値からTO値までの連番をカンマ区切りで返却する。("10,11,12,13・・49,50")
   * 1.3 固定値および範囲値（"0.5,10-50"）の場合、固定値と範囲値の連番をカンマ区切りで返却する。（"0.5,10,11,12,13・・49,50")
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param capacitySelectableRange
   *          容量選択可能範囲
   * @return カンマで区切られた選択可能な容量の値
   */
  public static String parseCapacitySelectableRange(
      String capacitySelectableRange) {

    // --- 引数チェック ---
    // 容量選択可能範囲
    if (capacitySelectableRange == null
        || capacitySelectableRange.length() == 0) {
      throw new IllegalArgumentException(
          "パラメータに誤りがあります。容量選択可能範囲を確認してください。");
    }

    // 容量選択可能範囲の分解処理
    StringJoiner result = new StringJoiner(
        ECISRKConstants.CAPACITY_SELECTABLE_RANGE_DELIMITER);
    // 区切り文字で分割した分、処理を繰り返し
    for (String temp : capacitySelectableRange
        .split(ECISRKConstants.CAPACITY_SELECTABLE_RANGE_DELIMITER)) {
      // 可能範囲指定文字が見つかった場合
      if (temp.contains(ECISRKConstants.CAPACITY_SELECTABLE_RANGE_RANGE_SYMBOL)) {
        String[] fromToValue = temp.split(
            ECISRKConstants.CAPACITY_SELECTABLE_RANGE_RANGE_SYMBOL,
            ECISRKConstants.CAPACITY_SELECTABLE_RANGE_MAX_BOUNDS);
        // 範囲の最小値と最大値の間の値をカンマ区切りで1ずつ結果に詰める
        for (int i = Integer.parseInt(fromToValue[0]); i <= Integer
            .parseInt(fromToValue[fromToValue.length - 1]); i++) {
          result.add(String.valueOf(i));
        }
      } else {
        result.add(temp);
      }
    }

    // 結果を文字列に変換し返却
    return result.toString();
  }

  /**
   * 契約容量をチェックする。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 1. 引数で指定された契約容量が容量選択可能範囲に含まれているかをチェックする。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractCapacity
   *          契約容量
   * @param capacitySelectableRange
   *          容量選択可能範囲
   * @return チェック結果。Trueの場合は正常、Falseの場合は異常。
   */
  public static boolean checkContractCapacity(String contractCapacity,
      String capacitySelectableRange) {
    // --- 引数チェック ---
    // 契約容量
    if (contractCapacity == null || contractCapacity.length() == 0) {
      throw new IllegalArgumentException("パラメータに誤りがあります。契約容量を確認してください。");
    }
    // 容量選択可能範囲
    if (capacitySelectableRange == null
        || capacitySelectableRange.length() == 0) {
      throw new IllegalArgumentException(
          "パラメータに誤りがあります。容量選択可能範囲を確認してください。");
    }

    // 契約容量チェック
    String[] validVals = parseCapacitySelectableRange(
        capacitySelectableRange).split(
            ECISRKConstants.CAPACITY_SELECTABLE_RANGE_DELIMITER);

    // 数値型に詰め替えを行いチェック
    List<String> decimalVals = new ArrayList<String>(validVals.length);
    DecimalFormat dFotmat = new DecimalFormat(ECISConstants.FORMAT_DECIMAL_SCALE_1_N3);
    for (String vals : validVals) {
      decimalVals.add(dFotmat.format(new BigDecimal(vals)));
    }

    // 区切り文字で分割した結果の配列の中に契約容量の値が
    // 存在＝True／存在しない＝Falseを返却
    return decimalVals.contains(dFotmat.format(new BigDecimal(contractCapacity)));
  }

  /**
   * 区切り文字列内の区切り内に対象文字列が存在するかチェックする。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 1. 引数で指定された区切り文字列内の区切り内に対象文字列が存在するかチェックする。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param checkTaget
   *          対象文字列
   * @param value
   *          区切り文字列
   * @param separater
   *          区切り文字
   * @return チェック結果。Trueの場合は正常、Falseの場合は異常。
   */
  public static boolean existCheckInSeparatedValues(String checkTaget,
      String value, String separater) {
    // --- 引数チェック ---
    // 対象文字列
    if (checkTaget == null || checkTaget.length() == 0) {
      throw new IllegalArgumentException("パラメータに誤りがあります。対象文字列を確認してください。");
    }
    // 区切り文字列
    if (value == null || value.length() == 0) {
      throw new IllegalArgumentException("パラメータに誤りがあります。区切り文字列を確認してください。");
    }
    // 区切り文字
    if (separater == null || separater.length() == 0) {
      throw new IllegalArgumentException("パラメータに誤りがあります。区切り文字を確認してください。");
    }

    // 引数.対象文字列が、区切り文字列の区切り毎に含まれているかチェック
    boolean ret = false;
    for (String temp : value.split(separater)) {
      if (temp.equals(checkTaget)) {
        ret = true;
        break;
      }
    }

    return ret;
  }

  /**
   * 日付型の比較を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 1. 引数で指定された2つの日付を、指定されたフォーマットでDate型に変換する。
   * 2. 変換した日付を、日付（前）.compareTo(日付（後）)で比較する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return チェック結果。比較対象日付（前） <= 比較対象日付（後）の場合はtrue。その他またはフォーマット不正の場合はfalse
   * @param beforeDate
   *          比較対象日付（前）
   * @param afterDate
   *          比較対象日付（後）
   * @param format
   *          日付型のフォーマット
   */
  public static boolean checkDateRange(String beforeDate, String afterDate, String format) {
    // 日付いずれかが空の場合、true
    if (StringUtils.isEmpty(beforeDate) || StringUtils.isEmpty(afterDate)) {
      return true;
    }
    // フォーマットが空の場合、デフォルトフォーマットにする
    if (StringUtils.isEmpty(format)) {
      format = EMSConstants.FORMAT_DATE_yyyyMMdd;
    }
    boolean result = false;
    SimpleDateFormat dateformat = new SimpleDateFormat(format);
    try {
      // 日付比較
      Date before = dateformat.parse(beforeDate);
      Date after = dateformat.parse(afterDate);

      if (before.compareTo(after) <= 0) {
        result = true;
      }
    } catch (ParseException e) {
      result = false;
    }
    return result;
  }
}
