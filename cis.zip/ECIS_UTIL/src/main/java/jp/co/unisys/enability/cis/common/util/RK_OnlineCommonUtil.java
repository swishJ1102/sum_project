package jp.co.unisys.enability.cis.common.util;

import java.util.LinkedHashMap;
import java.util.List;

import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;

/**
 * 料金計算オンライン共通ユーティリティクラス。
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_OnlineCommonUtil {

  /**
   * 連動セレクトボックスHTMLデータを作成する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 1. 引数で指定された連動セレクトボックスデータを解析し、HTML形式の連動セレクトボックスデータを返却する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param data
   *          連動セレクトボックスデータ
   * @return 連動セレクトボックスHTMLデータ
   */
  public static String createLinkedSelectBoxHtmlData(List<String> data) {
    // 解析結果格納マップ
    LinkedHashMap<String, Object> node = new LinkedHashMap<String, Object>();

    for (String lineData : data) {
      // 連動セレクトボックスデータをカンマ区切りで分解し、文字列配列にする
      parseLinkedSelectBoxData(
          node,
          lineData.split(ECISRKConstants.INTERLOCK_SELECTBOX_DELIMITER_COMMA),
          0);
    }
    // 連動セレクトボックスHTMLデータを返却する（繰返しではなく、項目数も少ないため、StringBuilderは使用しない）
    return ECISRKConstants.INTERLOCK_SELECTBOX_TAG_UL_START
        + convertLinkedSelectBoxDataToHtml(node)
        + ECISRKConstants.INTERLOCK_SELECTBOX_TAG_UL_END;
  }

  /**
   * 連動セレクトボックスデータの構文解析を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 1. 引数で指定された連動セレクトボックスデータを解析して、引数で指定された解析結果格納マップに格納する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param node
   *          解析結果格納マップ
   * @param data
   *          連動セレクトボックスデータ
   * @param depth
   *          深さ
   */
  @SuppressWarnings("unchecked")
  private static void parseLinkedSelectBoxData(
      LinkedHashMap<String, Object> node, String[] data, int depth) {
    // 引数.深さを要素番号とした連動セレクトボックスデータをキーとするデータが引数.解析結果格納マップに存在する場合
    if (node.containsKey(data[depth])) {
      // 連動セレクトボックスデータ構文解析を呼び出す
      parseLinkedSelectBoxData(
          (LinkedHashMap<String, Object>) node.get(data[depth]),
          data, depth + 1);
    } else {
      // 引数.深さが、連動セレクトボックスデータの個数-1 未満である場合
      if (depth < data.length - 1) {
        LinkedHashMap<String, Object> child = new LinkedHashMap<String, Object>();
        node.put(data[depth], child);
        parseLinkedSelectBoxData((LinkedHashMap<String, Object>) child,
            data, depth + 1);
      } else {
        // 引数.深さを要素番号とした連動セレクトボックスデータをキーとして、引数.解析結果格納マップにnullを追加する
        node.put(data[depth], null);
      }
    }
  }

  /**
   * 連動セレクトボックスデータをHTML形式に変換する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 1. 引数で指定された解析結果格納マップから、連動セレクトボックスデータをHTML形式で返却する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param node
   *          解析結果格納マップ
   * @return HTMLデータ
   */
  @SuppressWarnings("unchecked")
  private static String convertLinkedSelectBoxDataToHtml(
      LinkedHashMap<String, Object> node) {

    StringBuffer sb = new StringBuffer();
    for (String key : node.keySet()) {
      // 解析結果マップのキーを、セミコロン“:”を区切り文字として、文字列配列に分解する
      String[] vk = key
          .split(ECISRKConstants.INTERLOCK_SELECTBOX_DELIMITER_COLON);
      sb.append(
          ECISRKConstants.INTERLOCK_SELECTBOX_TAG_LI_AND_VALUE_START)
          .append(vk[0])
          .append(ECISRKConstants.INTERLOCK_SELECTBOX_TAG_VALUE_END)
          .append(ECISRKConstants.INTERLOCK_SELECTBOX_TAG_SPAN_START)
          .append(vk[1])
          .append(ECISRKConstants.INTERLOCK_SELECTBOX_TAG_SPAN_END);
      // 解析結果マップのキーで、引数.解析結果格納マップの値が null でない場合
      if (node.get(key) != null) {
        sb.append(ECISRKConstants.INTERLOCK_SELECTBOX_TAG_UL_START);
        sb.append(convertLinkedSelectBoxDataToHtml((LinkedHashMap<String, Object>) node
            .get(key)));
        sb.append(ECISRKConstants.INTERLOCK_SELECTBOX_TAG_UL_END);
      }
      sb.append(ECISRKConstants.INTERLOCK_SELECTBOX_TAG_LI_END);
    }
    // 文字列バッファを返却する
    return sb.toString();
  }

}
