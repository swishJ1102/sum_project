/*-------------------------------------------------------------------------------
 * All Rights Reserved. Copyright(C) Nihon Unisys, Ltd.
 * vendor : Nihon Unisys, Ltd.
 * since : 2015/02/06
 *-----------------------------------------------------------------------------*/
package jp.co.unisys.enability.cis.common.util;

import java.util.Comparator;

import org.json.JSONObject;

/**
 * JSONオブジェクト用コンパレータインタフェース実装クラス.<br>
 * datatableからのソートリクエストに対応するための並べ替えクラス.<br>
 * 数値型の項目は数値にして比較を行う.
 */
public class JSONIntegerComparator implements Comparator<JSONObject> {

  /**
   * カラム名
   */
  private String columName;

  /**
   * コンパレータのコンストラクタ.<br>
   * インスタンス生成時の初期化を行う
   * 
   * @param columName
   *          カラム名
   */
  public JSONIntegerComparator(String columName) {
    this.columName = columName;
  }

  /*
   * (非 Javadoc)
   * @see java.util.Comparator#compare(java.lang.Object, java.lang.Object)
   */
  @Override
  public int compare(JSONObject ja, JSONObject jb) {
    String sa = ja.optString(columName, "").toLowerCase();
    String sb = jb.optString(columName, "").toLowerCase();

    if (sa.isEmpty() && sb.isEmpty()) {
      // 両方空なら、同じ
      return 0;
    } else if (sa.isEmpty()) {
      // 比較前が空なら、前
      return -1;
    } else if (sb.isEmpty()) {
      // 比較後が空なら、後
      return 1;
    }

    // 数値に変換して比較する
    Integer ia = Integer.valueOf(sa.replace(EMSConstants.COMMA, ""));
    Integer ib = Integer.valueOf(sb.replace(EMSConstants.COMMA, ""));
    int result = ia.compareTo(ib);
    return result;
  }

}
