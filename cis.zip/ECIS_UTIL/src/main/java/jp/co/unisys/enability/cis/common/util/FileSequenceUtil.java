/*-------------------------------------------------------------------------------
 * All Rights Reserved. Copyright(C) Nihon Unisys, Ltd.
 * vendor : Nihon Unisys, Ltd.
 * since : 2015/02/06
 *-----------------------------------------------------------------------------*/
package jp.co.unisys.enability.cis.common.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

import org.apache.commons.lang.StringUtils;

import jp.co.unisys.enability.cis.common.Exception.ApplicationException;

/**
 * ファイルシーケンス共通クラス
 *
 * ファイル作成時に使用するシーケンスに関する共通処理を定義するクラス<br>
 * 基本的に、ファイル名にシーケンスを使用する処理を対象として定義する。<br>
 * シーケンスは9999までとする。
 */
public class FileSequenceUtil {

  private static final String STRING_COMMA = ",";

  private static final String STRING_ERROR_MESSAGE_1 = "シーケンスの取得に失敗しました。";

  private static final Integer INT_MAX_SEQUENCE = 9999;

  /**
   * ファイルシーケンス取得
   *
   * @param filePath
   *          ファイルパス
   * @param fileName
   *          ファイル名
   * @param date
   *          日付
   * @return シーケンス番号
   * @throws ApplicationException
   *           アプリケーション例外
   */
  public static String getFileSequence(String filePath, String fileName, String date)
      throws Exception {

    //初期化
    String sequence = "1";
    BufferedReader reader = null;
    FileWriter writer = null;

    try {

      // シーケンスファイル取得
      File sequenceFile = new File(filePath + fileName);

      // シーケンスファイルが存在しない場合はファイルを作成する
      if (!sequenceFile.exists()) {
        sequenceFile.createNewFile();
      } else {

        // ファイルを読込、チェックして日付が同じならインクリメントする
        reader = new BufferedReader(new FileReader(sequenceFile));

        // ファイルを読み込む
        String text = reader.readLine();

        if (!StringUtils.isEmpty(text)) {

          // カンマで分割する
          String[] textStrings = text.split(STRING_COMMA);

          if (textStrings.length == 2) {
            // インクリメント
            if (date.equals(textStrings[0])) {
              Integer sequenceInt = new Integer(textStrings[1]);
              // シーケンスがMAXより多い場合は初期化する
              if (INT_MAX_SEQUENCE.compareTo(sequenceInt) <= 0) {
                sequenceInt = 0;
              }
              sequence = String.valueOf(sequenceInt + 1);

            }
          } else {
            throw new ApplicationException(STRING_ERROR_MESSAGE_1);
          }
        }
      }

      // シーケンスファイルに書き込む
      writer = new FileWriter(sequenceFile);
      writer.write(date + STRING_COMMA + sequence);

    } catch (ApplicationException e) {
      throw e;
    } catch (Exception e) {
      throw new ApplicationException(STRING_ERROR_MESSAGE_1);
    } finally {
      try {
        if (reader != null) {
          reader.close();
        }
        if (writer != null) {
          writer.close();
        }
      } catch (Exception e) {
        throw new ApplicationException(STRING_ERROR_MESSAGE_1);
      }
    }

    return sequence;
  }
}
