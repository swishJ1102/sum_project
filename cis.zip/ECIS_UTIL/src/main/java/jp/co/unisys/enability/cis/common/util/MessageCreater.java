package jp.co.unisys.enability.cis.common.util;

/**
 * メッセージ転換クラス.<br>
 * メッセージ文言と引数合わせて、表示用メッセージ生成する
 *
 */
public class MessageCreater {

  /**
   * エラーリスト出力用の文字列生成を行う
   * 
   * @param fileName
   *          対象ファイル名
   * @param rowNo
   *          行番号
   * @param errContent
   *          メッセージ内容
   * @return 引数をカンマ区切りで連結した文字列
   */
  public static String makeErrorLog(String fileName, String rowNo,
      String errContent) {

    StringBuilder errorLog = new StringBuilder();
    errorLog.append(fileName);
    errorLog.append(EMSConstants.SPACE_ZENKAKU);
    errorLog.append(rowNo);
    errorLog.append(EMSConstants.SPACE_ZENKAKU);
    errorLog.append(errContent);

    return errorLog.toString();
  }

}
