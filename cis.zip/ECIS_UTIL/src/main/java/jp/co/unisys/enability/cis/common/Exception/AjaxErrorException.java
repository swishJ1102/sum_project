/*-------------------------------------------------------------------------------
 * All Rights Reserved. Copyright(C) Nihon Unisys, Ltd.
 * vendor : Nihon Unisys, Ltd.
 * since : 2014/09/01
 *-----------------------------------------------------------------------------*/
package jp.co.unisys.enability.cis.common.Exception;

/**
 * Ajax例外クラス.<br>
 * Ajaxによる非同期通信中にエラーが発生した場合にスローさせる例外クラス.
 *
 */
public class AjaxErrorException extends Exception {

  /**
   * デフォルトコンストラクタ
   */
  public AjaxErrorException() {
    super();
  }

  /**
   * 引数Throwableを元にAjaxErrorExceptionのインスタンスを生成する.
   */
  public AjaxErrorException(Throwable t) {
    super(t);
  }

}
