/*-------------------------------------------------------------------------------
 * All Rights Reserved. Copyright(C) Nihon Unisys, Ltd.
 * vendor : Nihon Unisys, Ltd.
 * since : 2015/02/06
 *-----------------------------------------------------------------------------*/
package jp.co.unisys.enability.cis.common.Exception;

/**
 * ECIS例外クラス.<br>
 * ECISでのアプリケーション例外基底クラス.
 *
 */
public class ApplicationException extends Exception {

  /**
   * 引数なしでAP例外を生成します。
   */
  public ApplicationException() {
    super();
  }

  /**
   * 発生例外を引数にAP例外を生成します。
   * 
   * @param t
   *          発生例外
   */
  public ApplicationException(Throwable t) {
    super(t);
  }

  /**
   * メッセージを引数にAP例外を生成します。
   * 
   * @param message
   *          メッセージ
   */
  public ApplicationException(String message) {
    super(message);
  }

  /**
   * メッセージ、発生例外を引数にAP例外を生成します。
   * 
   * @param message
   *          メッセージ
   * @param cause
   *          発生例外
   */
  public ApplicationException(String message, Throwable cause) {
    super(message, cause);
  }
}
