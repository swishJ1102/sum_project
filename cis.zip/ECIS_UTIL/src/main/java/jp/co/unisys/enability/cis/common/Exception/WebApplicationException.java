/*-------------------------------------------------------------------------------
 * All Rights Reserved. Copyright(C) Nihon Unisys, Ltd.
 * vendor : Nihon Unisys, Ltd.
 * since : 2015/02/06
 *-----------------------------------------------------------------------------*/
package jp.co.unisys.enability.cis.common.Exception;

/**
 * Web例外クラス.<br>
 * Web側での例外を通知するのに使用するクラスです。
 *
 */
public class WebApplicationException extends ApplicationException {

  /**
   * 引数なしでWeb例外を生成します。
   */
  public WebApplicationException() {
    super();
  }

  /**
   * 発生例外を引数にWeb例外を生成します。
   * 
   * @param t
   *          発生例外
   */
  public WebApplicationException(Throwable t) {
    super(t);
  }

  /**
   * メッセージを引数にWeb例外を生成します。
   * 
   * @param message
   *          メッセージ
   */
  public WebApplicationException(String message) {
    super(message);
  }

  /**
   * メッセージと発生例外を引数にWeb例外を生成します。
   * 
   * @param message
   *          メッセージ
   * @param cause
   *          発生例外
   */
  public WebApplicationException(String message, Throwable cause) {
    super(message, cause);
  }

}
