package jp.co.unisys.enability.cis.common.util.constants;

/**
 * 定数クラス
 *
 * @author "Nihon Unisys, Ltd."
 */
public class ECISConstants {

  /** セッションキー：メニュー情報 */
  public static final String SESSION_KEY_MENU_INFO = "menuinfo";
  /** セッションキー：権限情報（実行権限のあるアクションID） */
  public static final String SESSION_KEY_PERMISSION_ACTION_ID_MAP = "permissioninfo";
  /** CSV */
  public static final String CSV = "CSV";
  /** ZIP */
  public static final String ZIP = "ZIP";
  /** アスタリスク */
  public static final String ASTERISK = "*";
  /** ドット */
  public static final String DOT = ".";
  /** ThreadContext格納用キー： クラス名 */
  public static final String CLASS_NAME_KEY = "classname";
  /** ThreadContext格納用キー：ユーザID */
  public static final String USER_ID_KEY = "userid";
  /** ThreadContext格納用キー：セッションID */
  public static final String SESSION_ID_KEY = "sessionid";
  /** ThreadContext格納用キー：オンライン */
  public static final String ONLINE_FLAG_KEY = "onlineflag";
  /** APIリクエスト項目タグ：ユーザID */
  public static final String REQ_USERID_TAG = "userId";
  /** SOAPリクエスト・レスポンス出力先パス */
  public static final String API_XML_PATH = "/Enability/tenant/" + System.getProperty("spring.profiles.active") + "/internal/ecis/soap_xml_files/";
  /** オンライン：オンライン */
  public static final String ONLINE_FLAG_ONLINE = "0";
  /** オンライン：非オンライン */
  public static final String ONLINE_FLAG_NOTONLINE = "1";
  /** 処理基準日コード：オンライン処理基準日 */
  public static final String EXEC_BASE_DATE_ONLINE = "0";
  /** 処理基準日コード：バッチ処理基準日 */
  public static final String EXEC_BASE_DATE_BATCH = "1";
  /** 処理基準日コード：全て */
  public static final String EXEC_BASE_DATE_ALL = "99";
  /** ユーザID：システム */
  public static final String USER_ID_SYSTEM = "SYSTEM";
  /** カレンダー関連 事業者休日区分：事業者休日 */
  public static final String OPERATOR_HOLIDAY = "00";
  /** カレンダー関連 事業者休日区分：金融機関休日 */
  public static final String BANK_HOLIDAY = "01";
  /** カレンダー関連 事業者休日区分：北海道電力休日 */
  public static final String HOKKAIDO_AREA_HOLIDAY = "10";
  /** カレンダー関連 事業者休日区分：東北電力休日 */
  public static final String TOHOKU_AREA_HOLIDAY = "11";
  /** カレンダー関連 事業者休日区分：東京電力休日 */
  public static final String TOKYO_AREA_HOLIDAY = "12";
  /** カレンダー関連 事業者休日区分：中部電力休日 */
  public static final String CHUBU_AREA_HOLIDAY = "13";
  /** カレンダー関連 事業者休日区分：北陸電力休日 */
  public static final String HOKURIKU_AREA_HOLIDAY = "14";
  /** カレンダー関連 事業者休日区分：関西電力休日 */
  public static final String KANSAI_AREA_HOLIDAY = "15";
  /** カレンダー関連 事業者休日区分：中国電力休日 */
  public static final String CHUGOKU_AREA_HOLIDAY = "16";
  /** カレンダー関連 事業者休日区分：四国電力休日 */
  public static final String SHIKOKU_AREA_HOLIDAY = "17";
  /** カレンダー関連 事業者休日区分：九州電力休日 */
  public static final String KYUSYU_AREA_HOLIDAY = "18";
  /** カレンダー関連 事業者休日区分：沖縄電力休日 */
  public static final String OKINAWA_AREA_HOLIDAY = "19";
  /** 日時フォーマット：yyyy/MM/dd HH:mm:ss.SSS */
  public static final String FORMAT_DATE_yyyyMMddHHmmssSSS_OutputFormat = "yyyy/MM/dd HH:mm:ss.SSS";
  /** 日時フォーマット：HHmmss */
  public static final String FORMAT_DATE_HHmmss = "HHmmss";
  /** カレンダー対象列名区切り文字 **/
  public static final String CALENDAR_COVERED_COLUMN_NAME_DELIMITER = ",";
  /** カレンダー対象設置値区切り文字 **/
  public static final String COVERED_VALUE_LOGICAL_OPERATOR_DELIMITER = ":";
  /** カレンダー設定値区切り文字 **/
  public static final String COVERED_VALUE_DELIMITER = ",";
  /** 日付フォーマット：yyyyMMdd */
  public static final String FORMAT_DATE_yyyyMMdd = "yyyyMMdd";
  /** スラッシュ */
  public static final String SLASH = "/";
  /** underline 定数 */
  public static final String UNDERLINE = "_";
  /** 画面ID：TODO検索 */
  public static final String SCREEN_ID_SEARCH_TODO = "SGK0101-01";
  /** 画面ID：TODO更新 */
  public static final String SCREEN_ID_UPDATE_TODO = "SGK0101-02";
  /** 画面ID：ダウンロード */
  public static final String SCREEN_ID_DOWNLOAD = "SGK0201-01";
  /** 画面ID：契約情報照会 */
  public static final String SCREEN_ID_INQUIRY_CONTRACT = "SKJ0101-01";
  /** 画面ID：契約情報更新 */
  public static final String SCREEN_ID_UPDATE_CONTRACT = "SKJ0105-01";
  /** 画面ID：契約情報検索 */
  public static final String SCREEN_ID_SEARCH_CONTRACT_INFORMATION = "SKJ0201-01";
  /** 画面ID：契約情報一覧照会 */
  public static final String SCREEN_ID_INQUIRY_CONTRACT_INFORMATION_LIST = "SKJ0203-01";
  /** 画面ID：契約者情報更新 */
  public static final String SCREEN_ID_UPDATE_CONTRACTOR_INFOMATION = "SKJ0206-01";
  /** 画面ID：支払情報照会 */
  public static final String SCREEN_ID_INQUIRY_PAYMENT = "SKJ0301-01";
  /** 画面ID：支払情報一覧照会 */
  public static final String SCREEN_ID_INQUIRY_PAYMENT_LIST = "SKJ0303-01";
  /** 画面ID：支払情報更新 */
  public static final String SCREEN_ID_UPDATE_PAYMENT_INFORMATION = "SKJ0305-01";
  /** 画面ID：口座クレカ情報登録 */
  public static final String SCREEN_ID_REGIST_ACCOUNTCREDIT = "SKJ0305-03";
  /** 画面ID：口座クレカ情報更新 */
  public static final String SCREEN_ID_UPDATE_ACCOUNTCREDIT = "SKJ0305-04";
  /** 画面ID：付帯契約情報追加 */
  public static final String SCREEN_ID_ADD_SUPPLEMENTARY_CONTRACT = "SKJ0402-01";
  /** 画面ID：付帯契約情報更新 */
  public static final String SCREEN_ID_UPDATE_SUPPLEMENTARY_CONTRACT = "SKJ0404-01";
  /** 画面ID：付帯メニュー一覧照会 */
  public static final String SCREEN_ID_INQUIRY_SUPPLEMENTARY_MENU_LIST = "SKJ0407-01";
  /** 画面ID：メータ設置場所更新 */
  public static final String SCREEN_ID_UPDATE_METER_LOCATION = "SKJ0503-01";
  /** 画面ID：計算結果検索 */
  public static final String SCREEN_ID_CALCULATE_RESULT_SEARCH = "SRK0105-01";
  /** 画面ID：料金計算結果修正・補正 */
  public static final String SCREEN_ID_CHARGE_CALCULATE_RESULT_CORRECT = "SRK0106-01";
  /** 画面ID：料金再現計算 */
  public static final String SCREEN_ID_CHARGE_REPRODUCTION_CALCULATE = "SRK0107-01";
  /** 画面ID：確定料金実績明細照会 */
  public static final String SCREEN_ID_INQUIRY_FIX_CHARGE_RESULT_DETAIL = "SRK0110-01";
  /** 画面ID：計量器交換・臨時検針情報表示画面 */
  public static final String SCREEN_ID_IINQUIRY_MC_SMR_INFO_DISPLAY = "SRK0120-01";
  /** 画面ID：料金単価設定 */
  public static final String SCREEN_ID_UNIT_PRICE_MANAGEMENT = "SRK0202-01";
  /** 画面ID：付帯単価設定 */
  public static final String SCREEN_ID_SUPPLEMENTARY_UNIT_PRICE_MANAGEMENT = "SRK0202-02";
  /** 画面ID：料金実績情報ダウンロード */
  public static final String SCREEN_ID_CHARGE_RESULT_FILE_OUTPUT = "SRK0401-01";
  /** 画面ID：入金情報登録 */
  public static final String SCREEN_ID_REGIST_DEPOSIT = "SSN0301-01";
  /** 画面ID：不明入金一覧照会 */
  public static final String SCREEN_ID_INQUIRY_UNKNOWN_DEPOSIT = "SSN0302-01";
  /** 画面ID：不明入金消込登録 */
  public static final String SCREEN_ID_REGIST_RECONCILE_UNKNOWN_DEPOSIT = "SSN0302-02";
  /** 画面ID：請求消込登録 */
  public static final String SCREEN_ID_REGIST_BILLING_RECONCILE = "SSN0303-01";
  /** 画面ID：請求特別消込登録 */
  public static final String SCREEN_ID_BILL_SPEC_RECONCILE_REGIST = "SSN0304-01";
  /** 画面ID：預り金特別消込登録 */
  public static final String SCREEN_ID_DEP_REC_SPEC_RECONCILE_REGIST = "SSN0305-01";
  /** 画面ID：預り金一覧照会 */
  public static final String SCREEN_ID_DEPOSITS_RECEIVED_LIST = "SSN0306-01";
  /** 画面ID：督促更新 */
  public static final String SCREEN_ID_UPDATE_URGE = "SSN0404-01";
  /** 画面ID：債権譲渡登録 */
  public static final String SCREEN_ID_REGIST_CLAIM_ASSIGNMENT = "SSN0407-01";
  /** 画面ID：請求入金一覧照会 */
  public static final String SCREEN_ID_INQUIRY_BILLING_DEPOSIT_LIST = "SSN0501-01";
  /** 画面ID：請求入金明細照会 */
  public static final String SCREEN_ID_INQUIRY_BILLING_DEPOSIT_DETAIL = "SSN0701-01";
  /** 画面ID：完了 */
  public static final String SCREEN_ID_COMPLETE = "SZZ0001-01";
  /** 画面ID：ログイン */
  public static final String SCREEN_ID_LOGIN = "S0001-01";
  /** 画面ID：メニュー */
  public static final String SCREEN_ID_MENU = "S0003-01";
  /** 画面ID：パスワード変更 */
  public static final String SCREEN_ID_PASSWORD_CHANGE = "S0004-01";
  /** 画面ID：契約管理情報アップロード */
  public static final String SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD = "S0101-01";
  /** 画面ID：契約管理情報ダウンロード */
  public static final String SCREEN_ID_CONTRACT_MANAGEMENT_INFORMATION_DOWNLOAD = "S0101-07";
  /** 画面IDアクセスログダウンロード */
  public static final String SCREEN_ID_ACCESS_LOG_FILE_DOWNLOAD = "SGK0281-01";
  /** 画面ID：予備契約情報更新 */
  public static final String SCREEN_ID_UPDATE_RESERVE_CONTRACT = "SKJ0107-01";
  /** 画面ID：予備契約情報追加 */
  public static final String SCREEN_ID_ADD_RESERVE_CONTRACT = "SKJ0108-01";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SGK0101_01_EXECUTE = "SGK0101-01-A01";
  /** アクションID：検索対象検索 */
  public static final String ACTION_ID_SGK0101_01_SEARCH_TODO = "SGK0101-01-A02";
  /** アクションID：CSV出力 */
  public static final String ACTION_ID_SGK0101_01_EXPORT_CSV = "SGK0101-01-A06";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SGK0101_02_EXECUTE = "SGK0101-02-A01";
  /** アクションID：更新対象更新 */
  public static final String ACTION_ID_SGK0101_02_UPDATE_TODO = "SGK0101-02-A02";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SGK0201_01_EXECUTE = "SGK0201-01-A01";
  /** アクションID：ダウンロードファイル検索 */
  public static final String ACTION_ID_SGK0201_01_SEARCH_DOWNLOAD_FILE = "SGK0201-01-A02";
  /** アクションID：個別ダウンロード */
  public static final String ACTION_ID_SGK0201_01_INDIVIDUAL_DOWNLOAD = "SGK0201-01-A03";
  /** アクションID：一括ダウンロード */
  public static final String ACTION_ID_SGK0201_01_BULK_DOWNLOAD = "SGK0201-01-A04";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SKJ0101_01_EXECUTE = "SKJ0101-01-A01";
  /** アクションID：契約情報削除 */
  public static final String ACTION_ID_SKJ0101_01_DELETE_CONTRACT = "SKJ0101-01-A08";
  /** アクションID：過去を含む付帯契約情報検索 */
  public static final String ACTION_ID_SKJ0101_01_SEARCH_ALL_SUPPLEMENTARY_CONTRACT = "SKJ0101-01-A09";
  /** アクションID：付帯契約情報削除 */
  public static final String ACTION_ID_SKJ0101_01_DELETE_SUPPLEMENTARY_CONTRACT = "SKJ0101-01-A12";
  /** アクションID：予備契約情報表示切替 */
  public static final String ACTION_ID_SKJ0101_01_SEARCH_PAGING_RESERVE_CONTRACT = "SKJ0101-01-A17";
  /** アクションID：予備契約情報削除 */
  public static final String ACTION_ID_SKJ0101_01_DELETE_RESERVE_CONTRACT = "SKJ0101-01-A19";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SKJ0105_01_EXECUTE = "SKJ0105-01-A01";
  /** アクションID：契約情報更新(契約変更) */
  public static final String ACTION_ID_SKJ0105_01_UPDATE_CONTRACT_BY_CHANGE = "SKJ0105-01-A02";
  /** アクションID：契約情報更新(契約終了) */
  public static final String ACTION_ID_SKJ0105_01_UPDATE_CONTRACT_BY_TERMINATE = "SKJ0105-01-A05";
  /** アクションID：契約情報更新(変更予約) */
  public static final String ACTION_ID_SKJ0105_01_UPDATE_CONTRACT_BY_RESERVE = "SKJ0105-01-A06";
  /** アクションID：契約終了取消 */
  public static final String ACTION_ID_SKJ0105_01_UPDATE_CANCEL_CONTRACT_END = "SKJ0105-01-A04";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SKJ0107_01_EXECUTE = "SKJ0107-01-A01";
  /** アクションID：予備契約情報更新 */
  public static final String ACTION_ID_SKJ0107_01_UPDATE_RESERVE_CONTRACT = "SKJ0107-01-A03";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SKJ0108_01_EXECUTE = "SKJ0108-01-A01";
  /** アクションID：予備契約情報追加 */
  public static final String ACTION_ID_SKJ0108_01_ADD_RESERVE_CONTRACT = "SKJ0108-01-A03";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SKJ0201_01_EXECUTE = "SKJ0201-01-A01";
  /** アクションID：契約情報検索 */
  public static final String ACTION_ID_SKJ0201_01_SEARCH_CONTRACT_INFORMATION = "SKJ0201-01-A02";
  /** アクションID：提供モデル選択 */
  public static final String ACTION_ID_SKJ0201_01_SELECTION_PROVIDE_MODEL = "SKJ0201-01-A05";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SKJ0203_01_EXECUTE = "SKJ0203-01-A01";
  /** アクションID：過去を含む契約情報検索 */
  public static final String ACTION_ID_SKJ0203_01_SEARCH_INCLUDING_PAST_CONTRACT_INFORMATION = "SKJ0203-01-A03";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SKJ0206_01_EXECUTE = "SKJ0206-01-A01";
  /** アクションID：契約者情報更新 */
  public static final String ACTION_ID_SKJ0206_01_UPDATE_CONTRACTOR_INFOMATION = "SKJ0206-01-A02";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SKJ0301_01_EXECUTE = "SKJ0301-01-A01";
  /** アクションID：支払情報・支払履歴情報削除 */
  public static final String ACTION_ID_SKJ0301_01_DELETE_PAYMENT_PAYMENT_HISTORY = "SKJ0301-01-A03";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SKJ0303_01_EXECUTE = "SKJ0303-01-A01";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SKJ0305_01_EXECUTE = "SKJ0305-01-A01";
  /** アクションID：支払情報更新 */
  public static final String ACTION_ID_SKJ0305_01_UPDATE_PAYMENT_INFORMATION = "SKJ0305-01-A02";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SKJ0402_01_EXECUTE = "SKJ0402-01-A01";
  /** アクションID：付帯契約情報追加 */
  public static final String ACTION_ID_SKJ0402_01_ADD_SUPPLEMENTARY_CONTRACT = "SKJ0402-01-A02";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SKJ0404_01_EXECUTE = "SKJ0404-01-A01";
  /** アクションID：付帯契約情報更新 */
  public static final String ACTION_ID_SKJ0404_01_UPDATESUPPLEMENTARYCONTRACT = "SKJ0404-01-A02";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SKJ0407_01_EXECUTE = "SKJ0407-01-A01";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SKJ0503_01_EXECUTE = "SKJ0503-01-A01";
  /** アクションID：メータ設置場所更新 */
  public static final String ACTION_ID_SKJ0503_01_UPDATE_METER_LOCATION = "SKJ0503-01-A02";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SRK0105_01_EXECUTE = "SRK0105-01-A01";
  /** アクションID：計算結果一覧検索 */
  public static final String ACTION_ID_SRK0105_01_SEARCH = "SRK0105-01-A02";
  /** アクションID：料金計算確定 */
  public static final String ACTION_ID_SRK0105_01_CONFIRM = "SRK0105-01-A04";
  /** アクションID：料金計算確定取消 */
  public static final String ACTION_ID_SRK0105_01_CONFIRM_CANCEL = "SRK0105-01-A05";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SRK0106_01_EXECUTE = "SRK0106-01-A01";
  /** アクションID：料金再計算 */
  public static final String ACTION_ID_SRK0106_01_CALCULATERETRY_RATE = "SRK0106-01-A02";
  /** アクションID：行追加 */
  public static final String ACTION_ID_SRK0106_01_ADD_LINE = "SRK0106-01-A04";
  /** アクションID：行削除 */
  public static final String ACTION_ID_SRK0106_01_DELETE_LINE = "SRK0106-01-A05";
  /** アクションID：確認 */
  public static final String ACTION_ID_SRK0106_01_UPDATE_CONFIRMATION = "SRK0106-01-A06";
  /** アクションID：料金計算結果更新 */
  public static final String ACTION_ID_SRK0106_01_UPDATE_RATE_CALCULATE_RESULT = "SRK0106-01-A07";
  /** アクションID：料金計算結果確定更新 */
  public static final String ACTION_ID_SRK0106_01_UPDATE_RATE_CALCULATE_RESULT_CONFIRM = "SRK0106-01-A14";
  /** アクションID：料金計算結果確定解除 */
  public static final String ACTION_ID_SRK0106_01_RELEASE_RATE_CALCULATE_RESULT_CONFIRM = "SRK0106-01-A15";
  /** アクションID：遷移元画面へ遷移 */
  public static final String ACTION_ID_SRK0106_01_MOVE_PREVIOUS_SCREEN = "SRK0106-01-A09";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SRK0107_01_EXECUTE = "SRK0107-01-A01";
  /** アクションID：料金計算 */
  public static final String ACTION_ID_SRK0107_01_CALCULATE_RATE = "SRK0107-01-A02";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SRK0110_01_EXECUTE = "SRK0110-01-A01";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SRK0120_01_EXECUTE = "SRK0120-01-A01";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SRK0202_01_EXECUTE = "SRK0202-01-A01";
  /** アクションID：料金単価検索 */
  public static final String ACTION_ID_SRK0202_01_SEARCH_CHARGE_UNIT_PRICE = "SRK0202-01-A02";
  /** アクションID：料金単価登録 */
  public static final String ACTION_ID_SRK0202_01_REGISTER_CHARGE_UNIT_PRICE = "SRK0202-01-A03";
  /** アクションID：料金単価履歴表示 */
  public static final String ACTION_ID_SRK0202_01_DISPLAY_CHARGE_UNIT_PRICE_HISTORY = "SRK0202-01-A04";
  /** アクションID：料金単価履歴削除 */
  public static final String ACTION_ID_SRK0202_01_DELETE_CHARGE_UNIT_PRICE_HISTORY = "SRK0202-01-A05";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SRK0202_02_EXECUTE = "SRK0202-02-A01";
  /** アクションID：付帯メニュー名検索 */
  public static final String ACTION_ID_SRK0202_02_SEARCH_SUPPLEMENTARY_MENU_NAME = "SRK0202-02-A02";
  /** アクションID：付帯単価検索 */
  public static final String ACTION_ID_SRK0202_02_SEARCH_SUPPLEMENTARY_UNIT_PRICE = "SRK0202-02-A03";
  /** アクションID：付帯単価登録 */
  public static final String ACTION_ID_SRK0202_02_REGISTER_SUPPLEMENTARY_UNIT_PRICE = "SRK0202-02-A04";
  /** アクションID：付帯単価履歴表示 */
  public static final String ACTION_ID_SRK0202_02_DISPLAY_SUPPLEMENTARY_UNIT_PRICE_HISTORY = "SRK0202-02-A05";
  /** アクションID：付帯単価削除 */
  public static final String ACTION_ID_SRK0202_02_DELETE_SUPPLEMENTARY_UNIT_PRICE = "SRK0202-02-A06";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SRK0401_01_EXECUTE = "SRK0401-01-A01";
  /** アクションID：ファイル作成 */
  public static final String ACTION_ID_SRK0401_01_CREATE_FILE = "SRK0401-01-A02";
  /** アクションID：ファイルダウンロード */
  public static final String ACTION_ID_SRK0401_01_DOWNLOAD_FILE = "SRK0401-01-A03";
  /** アクションID：ファイル作成取消 */
  public static final String ACTION_ID_SRK0401_01_CANCEL_CREATE_FILE = "SRK0401-01-A04";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SSN0301_01_EXECUTE = "SSN0301-01-A01";
  /** アクションID：入金情報登録 */
  public static final String ACTION_ID_SSN0301_01_REGIST_DEPOSIT = "SSN0301-01-A02";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SSN0302_01_EXECUTE = "SSN0302-01-A01";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SSN0302_02_EXECUTE = "SSN0302-02-A01";
  /** アクションID：不明入金消込対象登録 */
  public static final String ACTION_ID_SSN0302_02_REGIST_UNKNOWN_DEPOSIT_RECONCILE = "SSN0302-02-A02";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SSN0303_01_EXECUTE = "SSN0303-01-A01";
  /** アクションID：請求消込登録 */
  public static final String ACTION_ID_SSN0303_01_REGIST_BILLING_RECONCILE = "SSN0303-01-A02";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SSN0304_01_EXECUTE = "SSN0304-01-A01";
  /** アクションID：請求特別消込登録 */
  public static final String ACTION_ID_SSN0304_01_REGIST_RECONCILE = "SSN0304-01-A02";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SSN0305_01_EXECUTE = "SSN0305-01-A01";
  /** アクションID：預り金特別消込登録 */
  public static final String ACTION_ID_SSN0305_01_REGIST_RECONCILE = "SSN0305-01-A02";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SSN0306_01_EXECUTE = "SSN0306-01-A01";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SSN0404_01_EXECUTE = "SSN0404-01-A01";
  /** アクションID：督促情報更新 */
  public static final String ACTION_ID_SSN0404_01_UPDATE_URGE = "SSN0404-01-A02";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SSN0407_01_EXECUTE = "SSN0407-01-A01";
  /** アクションID：債権譲渡登録ファイル読込 */
  public static final String ACTION_ID_SSN0407_01_UPLOAD_REGIST_CLAIM_ASSIGNMENT_FILE = "SSN0407-01-A02";
  /** アクションID：債権譲渡登録エラーリストダウンロード */
  public static final String ACTION_ID_SSN0407_01_DOWNLOAD_CLAIM_ASSIGNMENT_ERROR_LIST = "SSN0407-01-A03";
  /** アクションID：債権譲渡登録 */
  public static final String ACTION_ID_SSN0407_01_REGIST_CLAIM_ASSIGNMENT = "SSN0407-01-A04";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SSN0501_01_EXECUTE = "SSN0501-01-A01";
  /** アクションID：請求入金一覧検索 */
  public static final String ACTION_ID_SSN0501_01_SEARCH_BILLING_DEPOSIT_LIST = "SSN0501-01-A02";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SSN0701_01_EXECUTE = "SSN0701-01-A01";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SZZ0001_01_EXECUTE = "SZZ0001-01-A01";
  /** アクションID：画面遷移 */
  public static final String ACTION_ID_SZZ0001_01_SCREEN_TRANSITION = "SZZ0001-01-A02";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_S0001_01_EXECUTE = "S0001-01-A01";
  /** アクションID：再ログイン */
  public static final String ACTION_ID_S0001_01_RELOGIN = "S0001-01-A02";
  /** アクションID：ログイン */
  public static final String ACTION_ID_S0001_01_LOGIN = "S0001-01-A03";
  /** アクションID：ログアウト */
  public static final String ACTION_ID_S0001_01_LOGOUT = "S0001-01-A04";
  /** アクションID：初期画面 */
  public static final String ACTION_ID_S0004_01_EXECUTE = "S0004-01-A01";
  /** アクションID：パスワード変更 */
  public static final String ACTION_ID_S0004_01_PASSWORD_CHANGE = "S0004-01-A02";
  /** アクションID：パスワードリセット */
  public static final String ACTION_ID_S0004_01_PASSWORD_RESET = "S0004-01-A03";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_S0101_01_EXECUTE = "S0101-01-A01";
  /** アクションID：契約管理情報アップロード */
  public static final String ACTION_ID_S0101_01_UPLOAD = "S0101-01-A02";
  /** アクションID：エラーリストダウンロード */
  public static final String ACTION_ID_S0101_01_DOWNLOAD = "S0101-01-A03";
  /** アクションID：ロック強制解除 */
  public static final String ACTION_ID_S0101_01_UPDATE_LOCK_FORCE_CANCEL = "S0101-01-A04";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_S0107_01_EXECUTE = "S0101-07-A01";
  /** アクションID：契約管理情報ダウンロード */
  public static final String ACTION_ID_S0107_01_DOWNLOAD = "S0101-07-A02";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SGK0281_01_EXECUTE = "SGK0281-01-A01";
  /** アクションID：アクセスログダウンロード */
  public static final String ACTION_ID_SGK0281_01_DOWNLOAD_ACCESS_LOG_FILE = "SGK0281-01-A02";
  /** アクションID：当日アクセスログダウンロード */
  public static final String ACTION_ID_SGK0281_01_TODAY_DOWNLOAD_ACCESS_LOG_FILE = "SGK0281-01-A03";
  /** TODOステータスコード：未着手 */
  public static final String TODO_STATUS_CODE_NOT_STARTED = "0";
  /** 送信ステータスコード：未送信 */
  public static final String SEND_STATUS_CODE_UNSENT = "0";
  /** 業務日数 日数区分：暦日 */
  public static final String WORK_DAYS_CATEGORY_CALENDAR = "0";
  /** 業務日数 日数区分：エネット営業日 */
  public static final String WORK_DAYS_CATEGORY_ENNET = "1";
  /** 業務日数 日数区分：金融機関営業日 */
  public static final String WORK_DAYS_CATEGORY_FINANCIAL = "2";
  /** アクセスログ出力キーワード IF-ID 契約情報検索 */
  public static final String IF_ID_CIS0001 = "CIS0001";
  /** アクセスログ出力キーワード IF-ID 契約者情報照会 */
  public static final String IF_ID_CIS0002 = "CIS0002";
  /** アクセスログ出力キーワード IF-ID 契約者情報更新 */
  public static final String IF_ID_CIS0003 = "CIS0003";
  /** アクセスログ出力キーワード IF-ID 提供モデル企業一覧照会 */
  public static final String IF_ID_CIS0004 = "CIS0004";
  /** アクセスログ出力キーワード IF-ID 支払情報照会 */
  public static final String IF_ID_CIS0005 = "CIS0005";
  /** アクセスログ出力キーワード IF-ID 支払情報更新 */
  public static final String IF_ID_CIS0006 = "CIS0006";
  /** アクセスログ出力キーワード IF-ID 支払情報登録 */
  public static final String IF_ID_CIS0007 = "CIS0007";
  /** アクセスログ出力キーワード IF-ID 支払情報削除 */
  public static final String IF_ID_CIS0008 = "CIS0008";
  /** アクセスログ出力キーワード IF-ID 口座クレカ一覧情報照会 */
  public static final String IF_ID_CIS0009 = "CIS0009";
  /** アクセスログ出力キーワード IF-ID 口座クレカ情報登録 */
  public static final String IF_ID_CIS0010 = "CIS0010";
  /** アクセスログ出力キーワード IF-ID 契約情報照会 */
  public static final String IF_ID_CIS0011 = "CIS0011";
  /** アクセスログ出力キーワード IF-ID 契約情報更新 */
  public static final String IF_ID_CIS0012 = "CIS0012";
  /** アクセスログ出力キーワード IF-ID 契約情報追加 */
  public static final String IF_ID_CIS0013 = "CIS0013";
  /** アクセスログ出力キーワード IF-ID 契約情報削除 */
  public static final String IF_ID_CIS0014 = "CIS0014";
  /** アクセスログ出力キーワード IF-ID 付帯契約情報照会 */
  public static final String IF_ID_CIS0015 = "CIS0015";
  /** アクセスログ出力キーワード IF-ID 付帯契約情報更新 */
  public static final String IF_ID_CIS0016 = "CIS0016";
  /** アクセスログ出力キーワード IF-ID 付帯契約情報追加 */
  public static final String IF_ID_CIS0017 = "CIS0017";
  /** アクセスログ出力キーワード IF-ID 付帯契約情報削除 */
  public static final String IF_ID_CIS0018 = "CIS0018";
  /** アクセスログ出力キーワード IF-ID メータ設置場所照会 */
  public static final String IF_ID_CIS0019 = "CIS0019";
  /** アクセスログ出力キーワード IF-ID メータ設置場所更新 */
  public static final String IF_ID_CIS0020 = "CIS0020";
  /** アクセスログ出力キーワード IF-ID 新規契約者情報登録 */
  public static final String IF_ID_CIS0021 = "CIS0021";
  /** アクセスログ出力キーワード IF-ID 料金メニュ検索 */
  public static final String IF_ID_CIS0022 = "CIS0022";
  /** アクセスログ出力キーワード IF-ID 請求入金一覧照会 */
  public static final String IF_ID_CIS0023 = "CIS0023";
  /** アクセスログ出力キーワード IF-ID 確定料金実績照会 */
  public static final String IF_ID_CIS0024 = "CIS0024";
  /** アクセスログ出力キーワード IF-ID 解約対象者一覧照会 */
  public static final String IF_ID_CIS0025 = "CIS0025";
  /** アクセスログ出力キーワード IF-ID 営業委託先企業一覧照会 */
  public static final String IF_ID_CIS0026 = "CIS0026";
  /** アクセスログ出力キーワード IF-ID 契約者情報支払情報更新 */
  public static final String IF_ID_CIS0027 = "CIS0027";
  /** アクセスログ出力キーワード IF-ID 契約情報取得 */
  public static final String IF_ID_CIS0028 = "CIS0028";
  /** アクセスログ出力キーワード IF-ID 契約者情報登録 */
  public static final String IF_ID_CIS1001 = "CIS1001";
  /** アクセスログ出力キーワード IF-ID メータ設置場所登録 */
  public static final String IF_ID_CIS1002 = "CIS1002";
  /** アクセスログ出力キーワード IF-ID 契約情報登録 */
  public static final String IF_ID_CIS1003 = "CIS1003";
  /** アクセスログ出力キーワード IF-ID 卸取次店向け契約情報検索 */
  public static final String IF_ID_CIS9001 = "CIS9001";
  /** アクセスログ出力キーワード IF-ID 卸取次店向け契約者情報照会 */
  public static final String IF_ID_CIS9002 = "CIS9002";
  /** アクセスログ出力キーワード IF-ID 卸取次店向け契約者情報更新 */
  public static final String IF_ID_CIS9003 = "CIS9003";
  /** アクセスログ出力キーワード IF-ID 卸取次店向け契約情報照会 */
  public static final String IF_ID_CIS9011 = "CIS9011";
  /** アクセスログ出力キーワード IF-ID 卸取次店向け契約情報更新 */
  public static final String IF_ID_CIS9012 = "CIS9012";
  /** アクセスログ出力キーワード IF-ID 卸取次店向け契約情報追加 */
  public static final String IF_ID_CIS9013 = "CIS9013";
  /** アクセスログ出力キーワード IF-ID 卸取次店向け契約情報削除 */
  public static final String IF_ID_CIS9014 = "CIS9014";
  /** アクセスログ出力キーワード IF-ID 卸取次店向けメータ設置場所照会 */
  public static final String IF_ID_CIS9019 = "CIS9019";
  /** アクセスログ出力キーワード IF-ID 卸取次店向けメータ設置場所更新 */
  public static final String IF_ID_CIS9020 = "CIS9020";
  /** アクセスログ出力キーワード IF-ID 卸取次店向け新規契約者情報登録 */
  public static final String IF_ID_CIS9021 = "CIS9021";
  /** アクセスログ出力キーワード IF-ID 卸取次店向け確定料金実績照会 */
  public static final String IF_ID_CIS9024 = "CIS9024";
  /** アクセスログ出力キーワード IF-ID 料金シミュレーション */
  public static final String IF_ID_CIS9027 = "CIS9027";
  /** ファイル拡張子：.json */
  public static final String FILE_EXTENSION_JSON = ".json";
  /** ソート順:asc */
  public static final String VIEW_SORT_ASC = "asc";
  /** ソート順：desc */
  public static final String VIEW_SORT_DESC = "desc";
  /** AJAXリクエストパラメータ：開始インデックス */
  public static final String AJAX_IDISPLAY_START = "iDisplayStart";
  /** AJAXリクエストパラメータ：エコー番号 */
  public static final String AJAX_SECHO = "sEcho";
  /** AJAXリクエストパラメータ：1ページの表示件数 */
  public static final String AJAX_IDISPLAY_LENGTH = "iDisplayLength";
  /** AJAXリクエストパラメータ：カラム名（番号） */
  public static final String AJAX_ISORTCOL_0 = "iSortCol_0";
  /** AJAXリクエストパラメータ：ソート順 */
  public static final String AJAX_SSORTDIR_0 = "sSortDir_0";
  /** アクセスログキーワード:契約者ID */
  public static final String ACCESS_LOG_KEYWORD_CONTRACTOR_ID = "契約者ID";
  /** アクセスログキーワード:契約者番号 */
  public static final String ACCESS_LOG_KEYWORD_CONTRACTOR_NO = "契約者番号";
  /** アクセスログキーワード:提供モデルコード */
  public static final String ACCESS_LOG_KEYWORD_PROVIDE_MODEL_CODE = "提供モデルコード";
  /** アクセスログキーワード:提供モデル企業コード */
  public static final String ACCESS_LOG_KEYWORD_PROVIDE_MODEL_COMPANY_CODE = "提供モデル企業コード";
  /** アクセスログキーワード:提供モデル企業有効 */
  public static final String ACCESS_LOG_KEYWORD_PROVIDE_MODEL_COMPANY_EXPIRATION_FLAG = "提供モデル企業有効";
  /** アクセスログキーワード:支払ID */
  public static final String ACCESS_LOG_KEYWORD_PAYMENT_ID = "支払ID";
  /** アクセスログキーワード:支払番号 */
  public static final String ACCESS_LOG_KEYWORD_PAYMENT_NO = "支払番号";
  /** アクセスログキーワード:照会対象日付 */
  public static final String ACCESS_LOG_KEYWORD_INQUIRY_COVERED_VALUEDATE = "照会対象日付";
  /** アクセスログキーワード:支払適用開始日 */
  public static final String ACCESS_LOG_KEYWORD_PAYMENT_START_DATE = "支払適用開始日";
  /** アクセスログキーワード:口座クレカ区分コード */
  public static final String ACCESS_LOG_KEYWORD_ACCOUNT_CREDIT_CATEGORY_CODE = "口座クレカ区分コード";
  /** アクセスログキーワード:利用不能 */
  public static final String ACCESS_LOG_KEYWORD_UNAVAILABLE_FLAG = "利用不能";
  /** アクセスログキーワード:契約ID */
  public static final String ACCESS_LOG_KEYWORD_CONTRACT_ID = "契約ID";
  /** アクセスログキーワード:契約番号 */
  public static final String ACCESS_LOG_KEYWORD_CONTRACT_NO = "契約番号";
  /** アクセスログキーワード:適用開始日 */
  public static final String ACCESS_LOG_KEYWORD_APPLY_START_DATE = "適用開始日";
  /** アクセスログキーワード:契約開始日 */
  public static final String ACCESS_LOG_KEYWORD_CONTRACT_START_DATE = "契約開始日";
  /** アクセスログキーワード:付帯契約ID */
  public static final String ACCESS_LOG_KEYWORD_SUPPLEMENTARY_CONTRACT_ID = "付帯契約ID";
  /** アクセスログキーワード:付帯メニューID */
  public static final String ACCESS_LOG_KEYWORD_SUPPLEMENTARY_MENU_ID = "付帯メニューID";
  /** アクセスログキーワード:付帯契約開始日 */
  public static final String ACCESS_LOG_KEYWORD_SUPPLEMENTARY_CONTRACT_START_DATE = "付帯契約開始日";
  /** アクセスログキーワード:メータ設置場所ID */
  public static final String ACCESS_LOG_KEYWORD_METER_LOCATION_ID = "メータ設置場所ID";
  /** アクセスログキーワード:地点特定番号 */
  public static final String ACCESS_LOG_KEYWORD_SPOT_NO = "地点特定番号";
  /** アクセスログキーワード:ご利用年月FROM */
  public static final String ACCESS_LOG_KEYWORD_USE_PERIOD_FROM = "ご利用年月FROM";
  /** アクセスログキーワード:ご利用年月TO */
  public static final String ACCESS_LOG_KEYWORD_USE_PERIOD_TO = "ご利用年月TO";
  /** アクセスログキーワード:請求ID */
  public static final String ACCESS_LOG_KEYWORD_BILLING_ID = "請求ID";
  /** アクセスログキーワード:請求番号 */
  public static final String ACCESS_LOG_KEYWORD_BILLING_NO = "請求番号";
  /** アクセスログキーワード:解約通知日（From） */
  public static final String ACCESS_LOG_KEYWORD_CANCELLATION_NOTICE_DATE_FROM = "解約通知日（From）";
  /** アクセスログキーワード:解約通知日（To） */
  public static final String ACCESS_LOG_KEYWORD_CANCELLATION_NOTICE_DATE_TO = "解約通知日（To）";
  /** アクセスログキーワード:営業委託先コード */
  public static final String ACCESS_LOG_KEYWORD_SALES_CONSIGNMENT_CODE = "営業委託先コード";
  /** アクセスログキーワード:営業委託先企業有効 */
  public static final String ACCESS_LOG_KEYWORD_SALES_CONSIGNMENTCOMPANY_EXPIRATION_FLAG = "営業委託先企業有効";
  /** アクセスログキーワード:需要場所住所（郵便番号） */
  public static final String ACCESS_LOG_KEYWORD_PLACE_ADDRESS_POSTAL_CODE = "需要場所住所（郵便番号）";
  /** アクセスログキーワード:需要場所住所（住所） */
  public static final String ACCESS_LOG_KEYWORD_PLACE_ADDRESS_FULL = "需要場所住所（住所）";
  /** アクセスログキーワード:コロン */
  public static final String ACCESS_LOG_KEYWORD_COLON = ":";
  /** アクセスログキーワード:API */
  public static final String ACCESS_LOG_KEYWORD_API = "API";
  /** アクセスログキーワード:TODO_ID */
  public static final String ACCESS_LOG_KEYWORD_TODO_ID = "TODO_ID";
  /** アクセスログキーワード:付帯契約終了日 */
  public static final String ACCESS_LOG_KEYWORD_SUPPLEMENTARY_CONTRACT_END_DATE = "付帯契約終了日";
  /** アクセスログキーワード:確定料金実績ID */
  public static final String ACCESS_LOG_KEYWORD_FIX_CHARGE_RESULT_ID = "確定料金実績ID";
  /** アクセスログキーワード:利用年月 */
  public static final String ACCESS_LOG_KEYWORD_USE_PERIOD = "利用年月";
  /** アクセスログキーワード:料金メニューID */
  public static final String ACCESS_LOG_KEYWORD_RATE_MENU_ID = "料金メニューID";
  /** アクセスログキーワード:エリアコード */
  public static final String ACCESS_LOG_KEYWORD_AREA_CODE = "エリアコード";
  /** アクセスログキーワード:託送メニューID */
  public static final String ACCESS_LOG_KEYWORD_CONSIGNMENT_MENU_ID = "託送メニューID";
  /** アクセスログキーワード:料金メニューID */
  public static final String ACCESS_LOG_KEYWORD_RESERVE_CONTRACT_RATE_MENU_ID = "料金メニューID";
  /** アクセスログキーワード:単価選択区分 */
  public static final String ACCESS_LOG_KEYWORD_UNIT_PRICE_CHOICE_CATEGORY = "単価選択区分";
  /** アクセスログキーワード:入金ID */
  public static final String ACCESS_LOG_KEYWORD_DEPOSIT_ID = "入金ID";
  /** アクセスログキーワード:預り金等ID */
  public static final String ACCESS_LOG_KEYWORD_DEPOSITS_RECEIVED_ID = "預り金等ID";
  /** アクセスログキーワード:督促管理ID */
  public static final String ACCESS_LOG_KEYWORD_URGE_MANAGEMENT_ID = "督促管理ID";
  /** アクセスログキーワード:読込ファイル名 */
  public static final String ACCESS_LOG_KEYWORD_LOADING_FILE_NAME = "読込ファイル名";
  /** アクセスログキーワード:料金計算基準日 */
  public static final String ACCESS_LOG_KEYWORD_RATE_CALCULATION_BASE_DATE = "料金計算基準日";
  /** アクセスログキーワード:予備契約種別 */
  public static final String ACCESS_LOG_KEYWORD_RESERVE_CONTRACT_CLASS = "予備契約種別";
  /** アクセスログキーワード:予備契約開始日 */
  public static final String ACCESS_LOG_KEYWORD_RESERVE_CONTRACT_START_DATE = "予備契約開始日";
  /** アクセスログキーワード:予備契約終了日 */
  public static final String ACCESS_LOG_KEYWORD_RESERVE_CONTRACT_END_DATE = "予備契約終了日";
  /** アクセスログキーワード:制限中止割引情報ID */
  public static final String ACCESS_LOG_KEYWORD_RESTRICTION_DISCOUNT_INFO_ID = "制限中止割引情報ID";
  /** バッチステータス：正常 */
  public static final int JOB_RESULT_CODE_SUCCESS = 0;
  /** バッチステータス：異常 */
  public static final int JOB_RESULT_CODE_ERROR = 9;
  /** バッチステータス：警告 */
  public static final int JOB_RESULT_CODE_WARN = 50;
  /** バッチステータス：未処理 */
  public static final int JOB_RESULT_CODE_NON_EXECUTE = 2;
  /** パスワードロック：オン(1) */
  public static final short USER_PASSWORD_LOCK_FLG_ON = 1;
  /** パスワード初期化：オン(1) */
  public static final short USER_PASSWORD_INITIALIZATION_FLG_ON = 1;
  /** パスワード初期化：オフ(0) */
  public static final short USER_PASSWORD_INITIALIZATION_FLG_OFF = 0;
  /** 送信ステータスコード：送信済 */
  public static final String SEND_STATUS_CODE_SEND = "1";
  /** サブシステムID：業務共通 */
  public static final String SUBSYSTEM_ID_GK = "GK";
  /** サブシステムID：契約情報管理 */
  public static final String SUBSYSTEM_ID_KJ = "KJ";
  /** サブシステムID：料金計算 */
  public static final String SUBSYSTEM_ID_RK = "RK";
  /** サブシステムID：請求入金 */
  public static final String SUBSYSTEM_ID_SN = "SN";
  /** サブシステムID：他シス連携 */
  public static final String SUBSYSTEM_ID_SR = "SR";
  /** 遷移元 */
  public static final String TRANSFER_SCREEN_FLAG = "1";
  /** ：オン(1) */
  public static final String FLG_ON = "1";
  /** ：オフ(0) */
  public static final String FLG_OFF = "0";
  /** 日付フォーマット：yyyy */
  public static final String FORMAT_DATE_YYYY = "yyyy";
  /** セッションキー共通：ユーザ情報 */
  public static final String SESSION_KEY_USER = "uvo";
  /** セッションキー共通接頭辞：表示画面ID情報 */
  public static final String SESSION_KEY_SCREEN_ID_PREFIX = "transfer_forword_";
  /** セッションキー共通接頭辞：完了画面遷移先情報 */
  public static final String SESSION_KEY_DESTINATION_PREFIX = "transfer_destination_";
  /** セッションキー共通接頭辞：一覧・キー情報 */
  public static final String SESSION_KEY_PERMISSION_ACTION_ID_MAP_PREFIX = "transfer_";
  /** セッションキー共通接頭辞：検索条件情報 */
  public static final String SESSION_KEY_CONDITION_PREFIX = "condition_";
  /** 遷移元名 */
  public static final String TRANSFER_SCREEN_FLAG_NAME = "transferFlag";
  /** 一覧選択インデックス名 */
  public static final String LIST_SELECTION_INDEX = "listSelectionIndex";
  /** 料金計算結果修正・補正画面リクエストパラメータ：確定料金実績ID */
  public static final String TRANSFER_FCR_ID = "transferFcrId";
  /** 文字列連接用ハイフン **/
  public static final String HYPHEN = "-";
  /** 決済代行連携CSVファイル */
  public static final String SETTLEMENT_AGENCY_LINKAGE_CSV_FILE = "1";
  /** その他CSVファイル */
  public static final String OTHER_CSV_FILE = "2";
  /** アクセスログ出力キーワード:半角スペース */
  public static final String ACCESS_LOG_KEYWORD_SPACES = " ";
  /** 論理演算子：(AND) */
  public static final String OPERATOR_FOR_AND = "AND";
  /** 論理演算子：(OR) */
  public static final String OPERATOR_FOR_OR = "OR";
  /** シーケンス名：請求IDシーケンス */
  public static final String SEQUENCE_NAME_BL_ID = "sq_bl_id";
  /** シーケンス名：請求番号シーケンス */
  public static final String SEQUENCE_NAME_BL_NO = "sq_bl_no";
  /** シーケンス名：預り金等IDシーケンス */
  public static final String SEQUENCE_NAME_DPR_ID = "sq_dpr_id";
  /** シーケンス名：ダウンロード管理IDシーケンス */
  public static final String SEQUENCE_NAME_DL_MNGMNT_ID = "sq_dl_mng_id";
  /** ミリ秒・日数の相互変換：1日をミリ秒で表した数値 */
  public static final long ONE_DAY_MILLI_SECONDS = 24 * 60 * 60 * 1000;
  /** 日付フォーマット：yyyyMM */
  public static final String FORMAT_DATE_yyyyMM = "yyyyMM";
  /** 日付フォーマット：yyyy/MM */
  public static final String FORMAT_DATE_yyyyMM_SLASH = "yyyy/MM";
  /** 日付フォーマット：yyyy/MM/dd */
  public static final String FORMAT_DATE_yyyyMMdd_SLASH = "yyyy/MM/dd";
  /** 改行コード：LF */
  public static final String ENTER_CODE_LF = "\n";
  /** シーケンス名：収納結果IDシーケンス */
  public static final String SEQUENCE_NAME_RR_ID = "sq_rr_id";
  /** シーケンス名：取次店別請求実績IDシーケンス */
  public static final String SEQUENCE_NAME_AGENT_CHARGE_RESULT_ID = "sq_agent_charge_result_id";
  /** DECIMALフォーマット：####0.#### */
  public static final String FORMAT_DECIMAL_SCALE_1_N4 = "0.####";
  /** DECIMALフォーマット：####0.### */
  public static final String FORMAT_DECIMAL_SCALE_1_N3 = "0.###";
  /** DECIMALフォーマット：#####0.## */
  public static final String FORMAT_DECIMAL_SCALE_1_N2 = "0.##";
  /** DECIMALフォーマット：########0.00 */
  public static final String FORMAT_DECIMAL_SCALE_1_2 = "0.00";
  /** DECIMALフォーマット：##0.0 */
  public static final String FORMAT_DECIMAL_SCALE_1_1 = "0.0";
  /** シーケンス名：督促管理IDシーケンス */
  public static final String SEQUENCE_NAME_URGE_MNG_ID = "sq_urge_mng_id";
  /** 日時フォーマット：yyyyMMddHHmmss */
  public static final String FORMAT_DATE_yyyyMMddHHmmss = "yyyyMMddHHmmss";
  /** シーケンス名：入金IDシーケンス */
  public static final String SEQUENCE_NAME_DEPOSIT_ID = "sq_deposit_id";
  /** アクセスログZIPファイル接頭辞：アクセスログZIP */
  public static final String ACCESS_LOG_ZIP_FILE_PREFIX = "accesslog";
  /** 他 */
  public static final String OTHER = "他";
  /** メッセージへのバインド用文言：アクセス期間 */
  public static final String BIND_WORD_ACCESS_LOG_OUTPUT_TERM = "アクセス期間";
  /** DECIMALフォーマット：#,###.## */
  public static final String FORMAT_DECIMAL_COMMA = "#,###.##";
  /** ファイル拡張子：.txt */
  public static final String FILE_EXTENSION_TXT = ".txt";
  /** CSVファイル区切り文字 */
  public static final String CSV_FILE_DELIMITER = ",";
  /** コンテントタイプ：ファイルダウンロード */
  public static final String CONTENT_TYPE_FILE_DOWNLOAD = "application/octet-stream";
  /** コンテントディスポジション：ファイルダウンロード時にダイアログに表示するファイル名 */
  public static final String CONTENT_DISPOSITION_FILE_DOWNLOAD = "attachment;filename=";
  /** CSVファイル囲み文字 */
  public static final char CSV_FILE_ENCLOSURE = '"';
  /** コンテンツタイプファイル名囲み文字 */
  public static final char CONTENT_TYPE_FILE_NAME_ENCLOSURE = '"';
  /** エンコード：UTF-8 */
  public static final String ENCODE_TYPE_UTF8 = "UTF-8";
  /** ファイルダウンロード時のバッファサイズ */
  public static final int DOWNLOAD_BUFFER_SIZE = 1024;
  /** 改行コード：CRLF */
  public static final String ENTER_CODE = "\r\n";
  /** ファイル拡張子：.csv */
  public static final String FILE_EXTENSION_CSV = ".csv";
  /** ファイル拡張子：.zip */
  public static final String FILE_EXTENSION_ZIP = ".zip";
  /** 画面遷移：ファイルダウンロード */
  public static final String VIEW_RESULT_DOWNLOAD = "download";
  /** メッセージへのバインド用文言：ZIPファイル取得 */
  public static final String BIND_WORD_ZIPFILE = "ZIPファイル";
  /** DECIMALフォーマット：0.000 */
  public static final String FORMAT_DECIMAL_SCALE_1_3 = "0.000";
  /** DECIMALフォーマット：0.0000 */
  public static final String FORMAT_DECIMAL_SCALE_1_4 = "0.0000";
  /** コンマ */
  public static final String COMMA = ",";
  /** 画面遷移先情報： 完了画面へ */
  public static final String COMPLETE = "complete";
  /** 画面遷移先情報：ログアウト */
  public static final String LOGOUT = "logout";
  /** 日時フォーマット：yyyy/MM/dd HH:mm:ss */
  public static final String FORMAT_DATE_yyyyMMddHHmmss_OutputFormat = "yyyy/MM/dd HH:mm:ss";
  /** 文字コード：英数字 上限 */
  public static final char UNICODE_ALPHANUMERIC_UPPER_LIMIT = '\u007e';
  /** 文字コード：\記号 */
  public static final char UNICODE_YEN_SIGN = '\u00a5';
  /** 文字コード：~記号 */
  public static final char UNICODE_OVER_LINE = '\u203e';
  /** 文字コード：半角カナ 下限 */
  public static final char UNICODE_HALFKANA_LOWER_LIMIT = '\uff61';
  /** 文字コード：半角カナ 上限 */
  public static final char UNICODE_HALFKANA_UPPER_LIMIT = '\uff9f';
  /** 画面遷移：Ajax */
  public static final String VIEW_RESULT_SUCCESSAJAX = "successAjax";
  /** 画面遷移：警告 */
  public static final String VIEW_RESULT_WARN = "warn";
  /** 画面遷移：遷移失敗 */
  public static final String VIEW_RESULT_FAILED = "failed";
  /** 画面遷移：初期表示 */
  public static final String VIEW_RESULT_INIT = "init";
  /** 日付フォーマット：yyyy'年'MM'月'dd'日' */
  public static final String FORMAT_DATE_yyyyMMdd_CHINESE = "yyyy'年'MM'月'dd'日'";
  /** 波線 */
  public static final String WAVY_LINE = "～";
  /** 契約ID：最小値 */
  public static final int CONTRACT_ID_MIN_VALUE = 1;
  /** 契約ID：最大値 */
  public static final int CONTRACT_ID_MAX_VALUE = Integer.MAX_VALUE;
  /** 定数：半角スペース */
  public static final String SPACE_HANKAKU = " ";
  /** ZIPファイル解凍時のバッファサイズ */
  public static final int UNZIP_BUFFER_SIZE = 1024;
  /** validasionチェック用：半角 */
  public static final String HALF_WIDTH = "[ -~]+";
  /** CSVコンフィグオプション：ダブルクォートのみで表示 */
  public static final String CSVCONFIG_OPTION_NULL_STRING = "\"\"";
  /** 数値フォーマット：ナノ秒 */
  public static final String FORMAT_NUMBER_NANO_TIME = "000000000";
  /** エンコード：SJIS */
  public static final String ENCODE_TYPE_SJIS = "SJIS";
  /** 画面ID：トップ */
  public static final String SCREEN_ID_TOP = "S0002-01";
  /** 全角プラス記号 */
  public static final String FULLWIDTH_PLUS_SIGN = "＋";
  /** タブ */
  public static final String TABULATION = "\t";
  /** validasionチェック用：数字 */
  public static final String NUMBER = "^[0-9]+$";
  /** アクセスログキーワード:ダウンロード管理ID */
  public static final String ACCESS_LOG_KEYWORD_DL_MNG_ID = "ダウンロード管理ID";
  /** AJAX実行：ON */
  public static final String AJAXFLG_ON = "1";
  /** Oracle：VARCHAR2上限バイト数 */
  public static final int ORACLE_VARCHAR2_MAX_BYTES = 4000;
  /** 日付フォーマット：yyyy'年'MM'月' */
  public static final String FORMAT_DATE_yyyyMM_CHINESE = "yyyy'年'MM'月'";
  /** 定数：true */
  public static final String STRING_TRUE = "true";
  /** 定数：false */
  public static final String STRING_FALSE = "false";
  /** 画面ID：契約電力算定結果内訳帳票アップロード */
  public static final String SCREEN_ID_CONSIGNMENT_CCA_FILE__UPLOAD = "SSR0501-01";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SSR0501_01_EXECUTE = "SSR0501-01-A01";
  /** アクションID：契約電力算定結果内訳帳票アップロード */
  public static final String ACTION_ID_SSR0501_01_UPLOAD_FILE = "SSR0501-01-A02";
  /** アクションID：契約電力算定結果内訳帳票上書きアップロード */
  public static final String ACTION_ID_SSR0501_01_OVER_WRITE_UPLOAD_FILE = "SSR0501-01-A03";
  /** アクションID：契約電力算定結果内訳帳票アップロードキャンセル */
  public static final String ACTION_ID_SSR0501_01_CANCEL_UPLOAD_FILE = "SSR0501-01-A04";
  /** 画面ID：調定データアップロード */
  public static final String SCREEN_ID_SETTLEMENT_DATA_UPLOAD = "SSR0502-01";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SSR0502_01_EXECUTE = "SSR0502-01-A01";
  /** アクションID：調定データアップロード */
  public static final String ACTION_ID_SSR0502_01_UPLOAD_FILE = "SSR0501-01-A02";
  /** アクションID：調定データ上書きアップロード */
  public static final String ACTION_ID_SSR0502_01_OVER_WRITE_UPLOAD_FILE = "SSR0502-01-A03";
  /** アクションID：調定データアップロードキャンセル */
  public static final String ACTION_ID_SSR0502_01_CANCEL_UPLOAD_FILE = "SSR0502-01-A04";
  /** アクションID：調定データアップロードエラーリストダウンロード */
  public static final String ACTION_ID_SSR0502_01_DOWNLOAD = "SSR0502-01-A05";
  /** アクションID：調定データアップロードロック強制解除 */
  public static final String ACTION_ID_SSR0502_01_UPDATE_LOCK_FORCE_CANCEL = "SSR0502-01-A06";
  /** 画面遷移：画面を閉じる */
  public static final String VIEW_RESULT_CLOSE = "close";
  /** DECIMALフォーマット：#,###.00 */
  public static final String FORMAT_DECIMAL_COMMA_SCALE_1_2 = "#,##0.00";
  /** 改行コード：LF（エスケープ付） */
  public static final String ENTER_CODE_LF_ESC = "\\n";
  /** タブ（エスケープ付） */
  public static final String TABULATION_ESC = "\\t";
  /** 日付編集用：01日 */
  public static final String DATE_FIRST = "01";
  /** セミコロン */
  public static final String SEMICOLON = ";";
  /** アクセスログキーワード:適用年月 */
  public static final String ACCESS_LOG_KEYWORD_RENEWABLE_ENERGY_USE_PERIOD = "適用年月";
  /** 指示数フォーマット：#,###,##0.### */
  public static final String INDICATION_NO_FORMAT = "#,###,##0.###";
  /** 契約容量単位コード：A(1) */
  public static final String CCA_UNIT_AMPERE = "1";
  /** 契約容量単位コード：kW(3) */
  public static final String CCA_UNIT_KILOWATT = "3";
  /** 半角プラス記号 */
  public static final String HALFWIDTH_PLUS_SIGN = "+";
  /** 拡張子文字桁：4 */
  public static final int FILE_EXTENSION_DIGIT_4 = 4;
  /** パーセント */
  public static final String PERCENT = "%";
  /** 拡張子：XML */
  public static final String FILE_EXTENSION_XML = ".xml";
  /** 空文字 */
  public static final String EMPTY_STRING = "";
  /** 低圧電力単独 */
  public static final String CONTRACT_TYPE = "低圧電力単独";
  /** 検針区分 */
  public static final String CODE_2 = "2";
  /** 不明 */
  public static final String UNKNOWN = "不明";
  /** 画面ID：確定料金実績一覧照会画面_カスタム */
  public static final String CUSTOM_SCREEN_ID_CUSTOM_INQUIRY_FIX_CHARGE_RESULT_INFORMATION_LIST = "SRK01C01-01";
  /** アクションID：確定料金実績一覧照会画面_カスタム_初期表示 */
  public static final String CUSTOM_ACTION_ID_SRK01C01_01_EXECUTE = "SRK01C01-01-A01";
  /** アクションID：確定料金実績明細照会画面_カスタム_PDF出力 */
  public static final String CUSTOM_ACTION_ID_SRK0110_01C_DOWNLOAD_PDF = "SRK0110-01C-A03";
  /** アクションID：確定料金実績明細照会画面_カスタム_CSV出力 */
  public static final String CUSTOM_ACTION_ID_SRK0110_01C_DOWNLOAD_CSV = "SRK0110-01C-A04";
  /** 日時フォーマット：yyyyMMddHHmmssSSS */
  public static final String CUSTOM_FORMAT_DATE_yyyyMMddHHmmssSSS = "yyyyMMddHHmmssSSS";
  /** 単位：キロワットアワー */
  public static final String CUSTOM_UNIT_KILOWATT_HOUR = "kWh";
  /** 単位：円 */
  public static final String CUSTOM_UNIT_YEN = "円";
  /** アクセスログ出力キーワード IF-ID 確定料金実績明細照会 */
  public static final String CUSTOM_IF_ID_CISC0003 = "CISC003";
  /** アクセスログ出力キーワード IF-ID カスタム契約者情報照会 */
  public static final String CUSTOM_IF_ID_CISC0004 = "CISC004";
  /** アクセスログ出力キーワード IF-ID カスタム契約情報照会 */
  public static final String CUSTOM_IF_ID_CISC0002 = "CISC002";
  /** エンコード：ASCII */
  public static final String CUSTOM_ENCODE_TYPE_ASCII = "ASCII";
  /** 年間最大需要電力単位 */
  public static final String CUSTOM_YEAR_PEAK_DEMAND_UNIT = "kW";
  /** DECIMALフォーマット：5桁0フィル */
  public static final String CUSTOM_FORMAT_DECIMAL_FILL_ZERO_5 = "00000";
  /** アクセスログキーワード:スマートメータ区分コード */
  public static final String ACCESS_LOG_KEYWORD_SMART_METER_CATEGORY_CODE = "スマートメータ区分コード";
  /** アクセスログキーワード:次回検針予定日 */
  public static final String ACCESS_LOG_KEYWORD_NEXT_METER_READING_SCHEDULED_DATE = "次回検針予定日";
  /** 置換対象改行コード：CSVファイルダウンロード用 */
  public static final String REPLACEMENT_TARGET_ENTER_CODE_CSV_FILE_DOWNLOAD = "\r\n|\r|\n";
  /** 末日 */
  public static final int MATSUJITSU = 99;
  /** 表示名：末日 */
  public static final String MATSUJITSU_NAME = "末";
  /** モジュールコード定義：Custom_CIS0006C */
  public static final String MODULE_CODE_CUSTOM_CIS0006C = "Custom_CIS0006C";
  /** 画面ID：契約情報追加 */
  public static final String SCREEN_ID_ADD_CONTRACT = "SKJ0106-01";
  /** 画面ID：契約者情報登録 */
  public static final String SCREEN_ID_REGIST_CONTRACTOR_INFOMATION = "SKJ0207-01";
  /** 単価設定区分コード：個別単価 */
  public static final String UNIT_PRICE_SETTING_CATEGORY_INDIV = "indiv";
  /** 単価設定区分コード：メニュー毎単価 */
  public static final String UNIT_PRICE_SETTING_CATEGORY_DEF = "def";
  /** 画面ID：支払情報登録 */
  public static final String SCREEN_ID_REGIST_PAYMENT_INFORMATION = "SKJ0305-02";
  /** 画面ID：メータ設置場所登録 */
  public static final String SCREEN_ID_REGIST_METER_LOCATION = "SKJ0504-01";
  /** 画面ID：実量歴管理画面 */
  public static final String SCREEN_ID_SCREEN_ID_MANAGE_REAL_QUANTITY_HISTORY = "SKJ0601-01";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SKJ0601_01_EXECUTE = "SKJ0601-01-A01";
  /** アクションID：実量歴更新 */
  public static final String ACTION_ID_SKJ0601_01_UPDATE_REAL_QUANTITY_HISTORY = "SKJ0601-01-A02";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SKJ0207_01_EXECUTE = "SKJ0207-01-A01";
  /** アクションID：契約者情報登録 */
  public static final String ACTION_ID_SKJ0207_01_REGIST_CONTRACTOR_INFOMATION = "SKJ0207-01-A02";
  /** 実行機能区分コード：画面 */
  public static final int IMPLEMENT_FUNCTION_CODE_WEB = 0;
  /** 実行機能区分コード：バッチ */
  public static final int IMPLEMENT_FUNCTION_CODE_BATCH = 1;
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SKJ0305_02_EXECUTE = "SKJ0305-02-A01";
  /** アクションID：支払情報登録 */
  public static final String ACTION_ID_SKJ0305_02_REGIST_PAYMENT_INFORMATION = "SKJ0305-02-A02";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SKJ0106_01_EXECUTE = "SKJ0106-01-A01";
  /** アクションID：メータ設置場所情報検索 */
  public static final String ACTION_ID_SKJ0106_01_SEARCH_METER_LOCATION = "SKJ0106-01-A02";
  /** アクセスログキーワード:対象年月 */
  public static final String ACCESS_LOG_KEYWORD_COVERED_PERIOD = "対象年月";
  /** アクションID：登録 */
  public static final String ACTION_ID_SKJ0106_01_REGIST = "SKJ0106-01-A03";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SKJ0504_01_EXECUTE = "SKJ0504-01-A01";
  /** アクションID：メータ設置場所登録 */
  public static final String ACTION_ID_SKJ0504_01_REGIST_METER_LOCATION = "SKJ0504-01-A02";
  /** 単価設定区分：個別単価 */
  public static final String UNIT_PRICE_SETTING_CATEGORY_NAME_INDIV = "個別単価";
  /** 単価設定区分：メニュー毎単価 */
  public static final String UNIT_PRICE_SETTING_CATEGORY_NAME_DEF = "メニュー毎単価";
  /** アクションID：割引額算出処理 */
  public static final String ACTION_ID_SRK0106_01_DISCOUNT_CALCULATE = "SRK0106-01-A10";
  /** 日付フォーマット：yyyy'年'M'月' */
  public static final String FORMAT_DATE_yyyyM_CHINESE = "yyyy'年'M'月'";
  /** 全角スペース */
  public static final String FULL_SPACES = "　";
  /** 最大電力の単位：kW */
  public static final String PKW_UNIT = "kW";
  /** モジュールコード定義：契約管理情報アップロード画面 */
  public static final String MODULE_CODE_CONTRACT_MANAGEMENT_INFORMATION_UPLOAD_SCREEN = "S010101_ContractManagementInformationUploadAction";
  /** モジュールコード定義：支払情報更新画面 */
  public static final String MODULE_CODE_PAYMENT_INFORMATION_UPDATE_SCREEN = "KJ030501_UpdatePaymentInformationAction";
  /** 請求合算要否登録制御値：デフォルト（0） */
  public static final String BILLING_ADD_UP_CONTROL_0 = "0";
  /** 請求合算要否登録制御値：個別制御（1） */
  public static final String BILLING_ADD_UP_CONTROL_1 = "1";
  /** プラスマイナス記号 */
  public static final String PLUS_MINUS_SIGN = "±";
  /** 日付フォーマット：MM/dd */
  public static final String FORMAT_DATE_MMdd_SLASH = "MM/dd";
  /** アクセスログキーワード:口座クレカID */
  public static final String ACCESS_LOG_KEYWORD_ACCOUNT_CREDIT_CARD_ID = "口座クレカID";
  /** アクションID：口座クレカ情報削除 */
  public static final String ACTION_ID_SKJ0303_01_DELETE_ACCOUNT_CREDIT = "SKJ0303-01-A06";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SKJ0305_03_EXECUTE = "SKJ0305-03-A01";
  /** アクションID：口座クレカ情報登録 */
  public static final String ACTION_ID_SKJ0305_03_REGIST_ACCOUNT_CREDIT = "SKJ0305-03-A03";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SKJ0305_04_EXECUTE = "SKJ0305-04-A01";
  /** アクションID：口座クレカ情報更新 */
  public static final String ACTION_ID_SKJ0305_04_UPDATE_ACCOUNT_CREDIT = "SKJ0305-04-A02";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SKJ0701_02_EXECUTE = "SKJ0701-02-A01";
  /** アクションID：制限中止割引情報登録 */
  public static final String ACTION_ID_SKJ0701_02_INSERT = "SKJ0701-02-A03";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SKJ0701_01_EXECUTE = "SKJ0701-01-A01";
  /** アクションID：制限中止割引情報更新 */
  public static final String ACTION_ID_SKJ0701_01_UPDATE = "SKJ0701-01-A03";
  /** アクションID：制限中止割引情報削除 */
  public static final String ACTION_ID_SKJ0701_01_DELETE = "SKJ0701-01-A04";
  /** 画面ID：制限中止割引情報登録画面 */
  public static final String SCREEN_ID_INSERT_RESTRICTION_DISCOUNT_INFO = "SKJ0701-02";
  /** 画面ID：制限中止割引情報更新画面 */
  public static final String SCREEN_ID_UPDATE_RESTRICTION_DISCOUNT_INFO = "SKJ0701-01";
  /** 画面ID電力量認定申請書作成 */
  public static final String SCREEN_ID_ELECTRIC_CERTIFICATION_PETITION = "SGK0601-01";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SGK0601_EXECUTE = "SGK0601-01-A01";
  /** アクションID：ファイル作成 */
  public static final String ACTION_ID_SGK0601_CREATE_FILE = "SGK0601-01-A02";
  /** アクションID：ファイルダウンロード */
  public static final String ACTION_ID_SGK0601_DOWNLOAD = "SGK0601-01-A03";
  /** メッセージへのバインド用文言：ファイル */
  public static final String BIND_FILE = "ファイル";
  /** メッセージへのバインド用文言：ファイル作成 */
  public static final String BIND_FILE_CREATE = "ファイル作成";
  /** シーケンス名：送金IDシーケンス */
  public static final String SEQUENCE_NAME_REMIT_ID = "sq_remit_id";
  /** ロック用ファイル名 */
  public static final String FILE_LOCK = "lock";
  /** エラー用ファイル名 */
  public static final String FILE_ERROR = "error";
  /** 日付フォーマット：yyyy'年'MM'月'dd'日''HH'時'mm'分' */
  public static final String FORMAT_DATE_yyyyMMddHHmm_CHINESE = "yyyy'年'MM'月'dd'日'HH'時'mm'分'";
  /** 画面ID：確定使用量ファイルダウンロード */
  public static final String SCREEN_ID_FIX_USAGE_FILE_OUTPUT = "SSR0601-01";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SSR0601_01_EXECUTE = "SSR0601-01-A01";
  /** アクションID：ファイル作成 */
  public static final String ACTION_ID_SSR0601_01_CREATE_FILE = "SSR0601-01-A02";
  /** アクションID：ファイルダウンロード */
  public static final String ACTION_ID_SSR0601_01_DOWNLOAD_FILE = "R0601-01-A03";
  /** アクションID：ファイル作成取消 */
  public static final String ACTION_ID_SSR0601_01_CANCEL_CREATE_FILE = "R0601-01-A04";
  /** 画面ID：料金計算請求状況検索 */
  public static final String SCREEN_ID_BILLING_STATUS_SEARCH = "SRK0108-01";
  /** アクションID：初期表示 */
  public static final String ACTION_ID_SRK0108_01_EXECUTE = "SRK0108-01-A01";
  /** アクションID：料金計算請求状況検索 */
  public static final String ACTION_ID_SRK0108_01_SEARCH = "SRK0108-01-A02";
  /** アクションID：ファイル作成 */
  public static final String ACTION_ID_SRK0108_01_CREATE_FILE = "SRK0108-01-A03";
  /** アクションID：ファイルダウンロード */
  public static final String ACTION_ID_SRK0108_01_DOWNLOAD_FILE = "SRK0108-01-A04";
  /** アクションID：ファイル作成取消 */
  public static final String ACTION_ID_SRK0108_01_CANCEL_CREATE_FILE = "SRK0108-01-A05";

}
