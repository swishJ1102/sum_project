/*-------------------------------------------------------------------------------
 * All Rights Reserved. Copyright(C) Nihon Unisys, Ltd.
 * vendor : Nihon Unisys, Ltd.
 * since : 2014/09/01
 *-----------------------------------------------------------------------------*/
package jp.co.unisys.enability.cis.common.util;

import java.math.BigDecimal;
import java.util.Map;

import org.apache.struts2.util.StrutsTypeConverter;

import com.opensymphony.xwork2.conversion.TypeConversionException;

/**
 * BigDecimal型コンバータ.<br>
 * 画面とBeanの間の型変換を行うクラス
 * <p>
 * <h2>Beanから画面用の型変換</h2> Bean引数のjava.math.BigDecimal型をString型に変換<br>
 * <h2>画面からBean用の型変換</h2> 画面入力項目のString型をBeanのjava.math.BigDecimal型にカンマを排除した後に変換<br>
 * </p>
 */
public class BigDecimalConverter extends StrutsTypeConverter {

  /* (非 Javadoc)
   * @see org.apache.struts2.util.StrutsTypeConverter#convertFromString(java.util.Map, java.lang.String[], java.lang.Class)
   */
  @Override
  public Object convertFromString(Map context, String[] values, Class toClass) {
    // 値が無い場合は処理しない
    if (values == null || values.length == 0 || values[0].trim().length() == 0) {
      return null;
    }

    Object result = null;

    /*
     * 引用 http://qiita.com/alpha_pz/items/478f963b7d2d5e9e2da6
     * 今回は同名でのパラメータ送信を行わないため、不要
     */
    //		if (values.getClass().isArray() && toClass.isArray()) {
    //			Class<?> componentType = toClass.getComponentType();
    //
    //			result = Array.newInstance(componentType,
    //					Array.getLength(values));
    //			for (int i = 0, icount = Array.getLength(values); i < icount; i++) {
    //				Array.set(result, i,
    //						convertBigDecimalValue(
    //								context ,
    //								Array.get(values, i) ,
    //								toClass
    //								)
    //						);
    //			}
    //		} else {
    // カンマを取り除く
    result = convertBigDecimalValue(context, values[0], toClass);
    //		}

    return result;
  }

  /**
   * BigDecimalへの型変換。
   * 
   * @param Map
   *          コンテキスト情報Map
   * @param Object
   *          変換対象の文字列
   * @param Class
   *          変換後のクラス
   * @return 型変換した後のオブジェクト
   */
  protected Object convertBigDecimalValue(
      Map context, Object paramArrayOfString, Class toClass) {
    BigDecimal result;

    String value = (String) paramArrayOfString;
    value = value.replace(EMSConstants.COMMA, "");
    try {
      // Struts2標準で持っているBigDecimal変換
      result = bigDecValue(value);
    } catch (NumberFormatException e) {
      // 型変換エラーをStruts2へ通知し、変換前を表示させる
      super.performFallbackConversion(context, paramArrayOfString, toClass);
      throw new TypeConversionException();
    }
    return result;
  }

  /* (非 Javadoc)
   * @see org.apache.struts2.util.StrutsTypeConverter#convertToString(java.util.Map, java.lang.Object)
   */
  @Override
  public String convertToString(Map context, Object o) {
    return o.toString();
  }

}
