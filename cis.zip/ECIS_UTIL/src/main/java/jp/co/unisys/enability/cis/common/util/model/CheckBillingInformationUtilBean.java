package jp.co.unisys.enability.cis.common.util.model;

/**
 * 請求先情報チェックUtilBean
 *
 * @author "Nihon Unisys, Ltd."
 */
public class CheckBillingInformationUtilBean {

  /**
   * 個人・法人区分コードを保有する。
   */
  private String individualLegalEntityCategoryCode;

  /**
   * 請求先氏名1を保有する。
   */
  private String billingName1;

  /**
   * 請求先氏名2を保有する。
   */
  private String billingName2;

  /**
   * 敬称を保有する。
   */
  private String prefix;

  /**
   * 請求先住所（郵便番号）を保有する。
   */
  private String billingAddressPostalCode;

  /**
   * 請求先住所（都道府県名）を保有する。
   */
  private String billingAddressPrefectures;

  /**
   * 請求先住所（市区郡町村名）を保有する。
   */
  private String billingAddressMunicipality;

  /**
   * 請求先住所（字名・丁目）を保有する。
   */
  private String billingAddressSection;

  /**
   * 請求先住所（番地･号）を保有する。
   */
  private String billingAddressBlock;

  /**
   * 請求先住所（建物名）を保有する。
   */
  private String billingAddressBuildingName;

  /**
   * 請求先住所（部屋名）を保有する。
   */
  private String billingAddressRoom;

  /**
   * 請求先電話番号を保有する。
   */
  private String billingPhoneNo;

  /**
   * 請求先電話区分コードを保有する。
   */
  private String billingPhoneCategoryCode1;

  /**
   * 請求先メールアドレス1を保有する。
   */
  private String billingMailAddress1;

  /**
   * 請求先メールアドレス2を保有する。
   */
  private String billingMailAddress2;

  /**
   * フリー項目1を保有する。
   */
  private String free1;

  /**
   * フリー項目2を保有する。
   */
  private String free2;

  /**
   * 個人・法人区分コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 個人・法人区分コードを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 個人・法人区分コード
   */
  public String getIndividualLegalEntityCategoryCode() {
    return this.individualLegalEntityCategoryCode;
  }

  /**
   * 個人・法人区分コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 個人・法人区分コードを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param individualLegalEntityCategoryCode
   *          個人・法人区分コード
   */
  public void setIndividualLegalEntityCategoryCode(
      String individualLegalEntityCategoryCode) {
    this.individualLegalEntityCategoryCode = individualLegalEntityCategoryCode;
  }

  /**
   * 請求先氏名1のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先氏名1を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 請求先氏名1
   */
  public String getBillingName1() {
    return this.billingName1;
  }

  /**
   * 請求先氏名1のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先氏名1を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param billingName1
   *          請求先氏名1
   */
  public void setBillingName1(String billingName1) {
    this.billingName1 = billingName1;
  }

  /**
   * 請求先氏名2のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先氏名2を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 請求先氏名2
   */
  public String getBillingName2() {
    return this.billingName2;
  }

  /**
   * 請求先氏名2のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先氏名2を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param billingName2
   *          請求先氏名2
   */
  public void setBillingName2(String billingName2) {
    this.billingName2 = billingName2;
  }

  /**
   * 敬称のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 敬称を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 敬称
   */
  public String getPrefix() {
    return this.prefix;
  }

  /**
   * 敬称のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 敬称を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param prefix
   *          敬称
   */
  public void setPrefix(String prefix) {
    this.prefix = prefix;
  }

  /**
   * 請求先住所（郵便番号）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先住所（郵便番号）を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 請求先住所（郵便番号）
   */
  public String getBillingAddressPostalCode() {
    return this.billingAddressPostalCode;
  }

  /**
   * 請求先住所（郵便番号）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先住所（郵便番号）を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param billingAddressPostalCode
   *          請求先住所（郵便番号）
   */
  public void setBillingAddressPostalCode(String billingAddressPostalCode) {
    this.billingAddressPostalCode = billingAddressPostalCode;
  }

  /**
   * 請求先住所（都道府県名）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先住所（都道府県名）を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 請求先住所（都道府県名）
   */
  public String getBillingAddressPrefectures() {
    return this.billingAddressPrefectures;
  }

  /**
   * 請求先住所（都道府県名）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先住所（都道府県名）を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param billingAddressPrefectures
   *          請求先住所（都道府県名）
   */
  public void setBillingAddressPrefectures(String billingAddressPrefectures) {
    this.billingAddressPrefectures = billingAddressPrefectures;
  }

  /**
   * 請求先住所（市区郡町村名）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先住所（市区郡町村名）を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 請求先住所（市区郡町村名）
   */
  public String getBillingAddressMunicipality() {
    return this.billingAddressMunicipality;
  }

  /**
   * 請求先住所（市区郡町村名）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先住所（市区郡町村名）を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param billingAddressMunicipality
   *          請求先住所（市区郡町村名）
   */
  public void setBillingAddressMunicipality(String billingAddressMunicipality) {
    this.billingAddressMunicipality = billingAddressMunicipality;
  }

  /**
   * 請求先住所（字名・丁目）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先住所（字名・丁目）を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 請求先住所（字名・丁目）
   */
  public String getBillingAddressSection() {
    return this.billingAddressSection;
  }

  /**
   * 請求先住所（字名・丁目）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先住所（字名・丁目）を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param billingAddressSection
   *          請求先住所（字名・丁目）
   */
  public void setBillingAddressSection(String billingAddressSection) {
    this.billingAddressSection = billingAddressSection;
  }

  /**
   * 請求先住所（番地･号）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先住所（番地･号）を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 請求先住所（番地･号）
   */
  public String getBillingAddressBlock() {
    return this.billingAddressBlock;
  }

  /**
   * 請求先住所（番地･号）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先住所（番地･号）を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param billingAddressBlock
   *          請求先住所（番地･号）
   */
  public void setBillingAddressBlock(String billingAddressBlock) {
    this.billingAddressBlock = billingAddressBlock;
  }

  /**
   * 請求先住所（建物名）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先住所（建物名）を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 請求先住所（建物名）
   */
  public String getBillingAddressBuildingName() {
    return this.billingAddressBuildingName;
  }

  /**
   * 請求先住所（建物名）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先住所（建物名）を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param billingAddressBuildingName
   *          請求先住所（建物名）
   */
  public void setBillingAddressBuildingName(String billingAddressBuildingName) {
    this.billingAddressBuildingName = billingAddressBuildingName;
  }

  /**
   * 請求先住所（部屋名）のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先住所（部屋名）を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 請求先住所（部屋名）
   */
  public String getBillingAddressRoom() {
    return this.billingAddressRoom;
  }

  /**
   * 請求先住所（部屋名）のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先住所（部屋名）を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param billingAddressRoom
   *          請求先住所（部屋名）
   */
  public void setBillingAddressRoom(String billingAddressRoom) {
    this.billingAddressRoom = billingAddressRoom;
  }

  /**
   * 請求先電話番号のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先電話番号を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 請求先電話番号
   */
  public String getBillingPhoneNo() {
    return this.billingPhoneNo;
  }

  /**
   * 請求先電話番号のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先電話番号を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param billingPhoneNo
   *          請求先電話番号
   */
  public void setBillingPhoneNo(String billingPhoneNo) {
    this.billingPhoneNo = billingPhoneNo;
  }

  /**
   * 請求先電話区分コードのgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先電話区分コードを取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 請求先電話区分コード
   */
  public String getBillingPhoneCategoryCode1() {
    return this.billingPhoneCategoryCode1;
  }

  /**
   * 請求先電話区分コードのsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先電話区分コードを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param billingPhoneCategoryCode1
   *          請求先電話区分コード
   */
  public void setBillingPhoneCategoryCode1(String billingPhoneCategoryCode1) {
    this.billingPhoneCategoryCode1 = billingPhoneCategoryCode1;
  }

  /**
   * 請求先メールアドレス1のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先メールアドレス1を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 請求先メールアドレス1
   */
  public String getBillingMailAddress1() {
    return this.billingMailAddress1;
  }

  /**
   * 請求先メールアドレス1のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先メールアドレス1を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param billingMailAddress1
   *          請求先メールアドレス1
   */
  public void setBillingMailAddress1(String billingMailAddress1) {
    this.billingMailAddress1 = billingMailAddress1;
  }

  /**
   * 請求先メールアドレス2のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先メールアドレス2を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 請求先メールアドレス2
   */
  public String getBillingMailAddress2() {
    return this.billingMailAddress2;
  }

  /**
   * 請求先メールアドレス2のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 請求先メールアドレス2を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param billingMailAddress2
   *          請求先メールアドレス2
   */
  public void setBillingMailAddress2(String billingMailAddress2) {
    this.billingMailAddress2 = billingMailAddress2;
  }

  /**
   * フリー項目1のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * フリー項目1を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return フリー項目1
   */
  public String getFree1() {
    return this.free1;
  }

  /**
   * フリー項目1のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * フリー項目1を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param free1
   *          フリー項目1
   */
  public void setFree1(String free1) {
    this.free1 = free1;
  }

  /**
   * フリー項目2のgetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * フリー項目2を取得します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return フリー項目2
   */
  public String getFree2() {
    return this.free2;
  }

  /**
   * フリー項目2のsetter
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * フリー項目2を設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param free2
   *          フリー項目2
   */
  public void setFree2(String free2) {
    this.free2 = free2;
  }

}
