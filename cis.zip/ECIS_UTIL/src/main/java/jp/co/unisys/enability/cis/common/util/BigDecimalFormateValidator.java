/*-------------------------------------------------------------------------------
 * All Rights Reserved. Copyright(C) Nihon Unisys, Ltd.
 * vendor : Nihon Unisys, Ltd.
 * since : 2014/09/01
 *-----------------------------------------------------------------------------*/
package jp.co.unisys.enability.cis.common.util;

import com.opensymphony.xwork2.validator.ValidationException;
import com.opensymphony.xwork2.validator.validators.FieldValidatorSupport;

/**
 * BigDecimal型フィールドバリデータ.<br>
 * Struts2バリデーションで使用するBigDecimal型用カスタムバリデーションクラス
 */
public class BigDecimalFormateValidator extends FieldValidatorSupport {

  /** フィールド名 */
  private String fieldName;

  /*
   * (非 Javadoc)
   * @see com.opensymphony.xwork2.validator.Validator#validate(java.lang.Object)
   */
  @Override
  public void validate(Object object) throws ValidationException {

    // フィールド名を取得する。
    String fieldName = this.getFieldName();

    // 入力値を取得する。
    Object value = this.getFieldValue(fieldName, object);

    // 入力値がある場合、チェックを行う。
    if (value != null && !String.valueOf(value).isEmpty()) {

      String bigdecimalStr = String.valueOf(value).trim().replace(EMSConstants.COMMA, "");

      String patton = "[0-9]{1,4}\\.[0-9]{2}";

      try {

        if (!CommonValidationUtil.checkByPattern(bigdecimalStr, patton)) {

          this.addFieldError(fieldName, object);
        }

      } catch (Exception e) {

        this.addFieldError(fieldName, object);
      }
    }
  }

  /**
   * fieldNameのゲッター
   *
   * @return fieldName
   */
  public String getFieldName() {
    return fieldName;
  }

  /**
   * fieldNameのセッター
   *
   * @param fieldName
   *          セットする fieldName
   */
  public void setFieldName(String fieldName) {
    this.fieldName = fieldName;
  }

}
