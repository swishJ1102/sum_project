package jp.co.unisys.enability.cis.common.util.constants;

/**
 * 定数クラス
 *
 * @author "Nihon Unisys, Ltd."
 */
public class ECISSNConstants {

  /** 不明入金消込登録画面：請求消込 */
  public static final String REGIST_UKNOWN_DEPOSIT_BILLING_RECONCILE = "1";
  /** 不明入金消込登録画面：振替 */
  public static final String REGIST_UKNOWN_DEPOSIT_TRANSFER = "2";
  /** 決済代行連携CSVファイル */
  public static final String SETTLEMENT_AGENCY_LINKAGE_CSV_FILE = "1";
  /** その他CSVファイル */
  public static final String OTHER_CSV_FILE = "2";
  /** コンビニ請求額上限額 30万円 */
  public static final long CONVENI_BILLING_AMOUNT_UPPER_LIMIT = 300000;
  /** 債権回収請求作成処理:解約決定(1) */
  public static final String CLAIM_COLLECTION_CREATE_BILLING_PROCESSFLG_CANCELLATION_DECISION = "1";
  /** 債権回収請求作成処理:廃止・解約検針(2) */
  public static final String CLAIM_COLLECTION_CREATE_BILLING_PROCESSFLG_ABOLITION = "2";
  /** 入金振替理由マスタカラム名：入金振替理由コード */
  public static final String DT_REASON_M_COLUMN_NAME_DT_REASON_CODE = "dt_reason_code";
  /** 日付フォーマット(yyyy)の長さ */
  public static final int LENGTH_DATE_YYYY = 4;
  /** 日付フォーマット(yyyyMM)の長さ */
  public static final int LENGTH_DATE_YYYYMM = 6;
  /** 利用年月FROM */
  public static final String USE_PERIOD_AFTER_FROM = "01";
  /** 利用年月TO */
  public static final String USE_PERIOD_AFTER_TO = "12";
  /** 手動入金理由マスタカラム名：手動入金理由コード */
  public static final String MD_REASON_M_COLUMN_NAME_MD_REASON_CODE = "md_reason_code";
  /** メッセージ：請求依頼ファイル作成CSVファイル */
  public static final String BL_REQUESTFILE_CSV = "請求依頼ファイル作成CSVファイル";
  /** メッセージ：取次店請求ファイル作成CSVファイル */
  public static final String AGENCY_REQUESTFILE_CSV = "取次店請求ファイル作成CSVファイル";
  /** メッセージ：取次店用請求内訳ファイル作成CSVファイル */
  public static final String AGENCY_REQUESTBREAKDOWNFILE_CSV = "取次店用請求内訳ファイル作成CSVファイル";
  /** 請求番号の長さ */
  public static final int LENGTH_BILLING_NO = 12;
  /** 経理データ作成：CSV出力ファイルリスト項目数 */
  public static final int CREATE_ACCOUNT_DATA_CSV_OUTPUT_ITEM_COUNT = 12;
  /** 経理データ作成：CSV出力ファイルリスト項目順：計上日 */
  public static final int CREATE_ACCOUNT_DATA_CSV_OUTPUT_RECORDED_DATE = 0;
  /** 経理データ作成：CSV出力ファイルリスト項目順：部課コード */
  public static final int CREATE_ACCOUNT_DATA_CSV_OUTPUT_SECTION_CODE = 1;
  /** 経理データ作成：CSV出力ファイルリスト項目順：提供モデルコード */
  public static final int CREATE_ACCOUNT_DATA_CSV_OUTPUT_PROVIDE_MODEL_CODE = 2;
  /** 経理データ作成：CSV出力ファイルリスト項目順：提供モデル企業コード */
  public static final int CREATE_ACCOUNT_DATA_CSV_OUTPUT_PROVIDE_MODEL_COMPANY_CODE = 3;
  /** 経理データ作成：CSV出力ファイルリスト項目順：取引先コード */
  public static final int CREATE_ACCOUNT_DATA_CSV_OUTPUT_CUSTOMER_CODE = 4;
  /** 経理データ作成：CSV出力ファイルリスト項目順：消費税率 */
  public static final int CREATE_ACCOUNT_DATA_CSV_OUTPUT_CONSUMPTION_TAX_RATE = 5;
  /** 経理データ作成：CSV出力ファイルリスト項目順：借方勘定科目コード */
  public static final int CREATE_ACCOUNT_DATA_CSV_OUTPUT_DEBIT_ACCOUNT_ITEM_CODE = 6;
  /** 経理データ作成：CSV出力ファイルリスト項目順：借方勘定科目 */
  public static final int CREATE_ACCOUNT_DATA_CSV_OUTPUT_DEBIT_ACCOUNT_ITEM = 7;
  /** 経理データ作成：CSV出力ファイルリスト項目順：借方金額 */
  public static final int CREATE_ACCOUNT_DATA_CSV_OUTPUT_DEBIT_AMOUNT = 8;
  /** 経理データ作成：CSV出力ファイルリスト項目順：貸方勘定科目コード */
  public static final int CREATE_ACCOUNT_DATA_CSV_OUTPUT_CREDIT_ACCOUNT_ITEM_CODE = 9;
  /** 経理データ作成：CSV出力ファイルリスト項目順：貸方勘定科目 */
  public static final int CREATE_ACCOUNT_DATA_CSV_OUTPUT_CREDIT_ACCOUNT_ITEM = 10;
  /** 経理データ作成：CSV出力ファイルリスト項目順：貸方金額 */
  public static final int CREATE_ACCOUNT_DATA_CSV_OUTPUT_CREDIT_AMOUNT = 11;
  /** 経理データ作成：CSV出力ファイルリスト項目順：金額 */
  public static final int CREATE_ACCOUNT_DATA_CSV_OUTPUT_AMOUNT = 10;
  /** JSON定義：債権譲渡登録：契約者番号 */
  public static final String JSON_REGIST_CLAIM_ASSIGNMENT_CONTRACTOR_NO = "0";
  /** JSON定義：債権譲渡登録：契約者名1（漢字） */
  public static final String JSON_REGIST_CLAIM_ASSIGNMENT_CONTRACTOR_NAME1 = "1";
  /** JSON定義：債権譲渡登録：契約番号 */
  public static final String JSON_REGIST_CLAIM_ASSIGNMENT_CONTRACT_NO = "2";
  /** JSON定義：債権譲渡登録：請求番号 */
  public static final String JSON_REGIST_CLAIM_ASSIGNMENT_BILLING_NO = "3";
  /** JSON定義：債権譲渡登録：ご利用金額 */
  public static final String JSON_REGIST_CLAIM_ASSIGNMENT_USE_AMOUNT = "4";
  /** JSON定義：債権譲渡登録：預り金充当額 */
  public static final String JSON_REGIST_CLAIM_ASSIGNMENT_DPR_APPROPRIATED_AMOUNT = "5";
  /** JSON定義：債権譲渡登録：契約終了日 */
  public static final String JSON_REGIST_CLAIM_ASSIGNMENT_CONTRACT_END_DATE = "6";
  /** JSON定義：債権譲渡登録：譲渡日 */
  public static final String JSON_REGIST_CLAIM_ASSIGNMENT_ASSIGNMENT_DATE = "7";
  /** JSON定義：債権譲渡登録：JSONリスト名 */
  public static final String JSON_REGIST_CLAIM_ASSIGNMENT_LIST_NAME = "registClaimAssignmentListJson";
  /** 債権譲渡登録情報ファイル：要素数 */
  public static final int REGIST_CLAIM_ASSIGNMENT_FILE_ITEM_COUNT = 2;
  /** 債権譲渡登録情報ファイル：請求番号 */
  public static final int REGIST_CLAIM_ASSIGNMENT_FILE_BILLING_NO = 0;
  /** 債権譲渡登録情報ファイル：譲渡日 */
  public static final int REGIST_CLAIM_ASSIGNMENT_FILE_ASSIGNMENT_DATE = 1;
  /** yyyyMMddのyyyy開始位置 */
  public static final int YYYY_START_POSITION = 0;
  /** yyyyMMddのMM開始位置 */
  public static final int MM_START_POSITION = 4;
  /** yyyyMMddのdd開始位置 */
  public static final int DD_START_POSITION = 6;
  /** 解約予告・解約通知Todo備考用文字列データ区分：ヘッダ */
  public static final String TODO_NOTE_DATA_CATEGORY_HEADER = "1";
  /** 解約予告・解約通知Todo備考用文字列データ区分：データ */
  public static final String TODO_NOTE_DATA_CATEGORY_DATA = "2";
  /** 預り金等特別消込理由マスタカラム名：預り金等特別消込理由コード */
  public static final String DPR_SR_REASON_M_COLUMN_NAME_DPR_SR_REASON_CODE = "dpr_sr_reason_code";
  /** JSON定義：不明入金一覧照会：振込依頼者名（半角カナ） */
  public static final String JSON_INQUIRY_UNKNOWN_DEPOSIT_TRNSFR_CLT_NM_HWK = "0";
  /** JSON定義：不明入金一覧照会：金額 */
  public static final String JSON_INQUIRY_UNKNOWN_DEPOSIT_AMOUNT = "1";
  /** JSON定義：不明入金一覧照会：収納日 */
  public static final String JSON_INQUIRY_UNKNOWN_DEPOSIT_RCPT_DATE = "2";
  /** JSON定義：不明入金一覧照会：契約者名1 */
  public static final String JSON_INQUIRY_UNKNOWN_DEPOSIT_CNTRCTR_NM = "3";
  /** JSON定義：不明入金一覧照会：請求先氏名1 */
  public static final String JSON_INQUIRY_UNKNOWN_DEPOSIT_BLLNG_NM = "4";
  /** JSON定義：不明入金一覧照会：契約者番号 */
  public static final String JSON_INQUIRY_UNKNOWN_DEPOSIT_CNTRCTR_NO = "5";
  /** JSON定義：不明入金一覧照会：JSONリスト名 */
  public static final String JSON_INQUIRY_UNKNOWN_DEPOSIT_LIST_NAME = "unknownDepositListJson";
  /** CSVファイルレコード設定情報：文字列"null" */
  public static final String CSV_RECORD_SET_NULL = "null";
  /** JSON定義：督促更新：契約番号 */
  public static final String JSON_UPDATE_URGE_CONTRACT_NO = "0";
  /** JSON定義：督促更新：地点特定番号 */
  public static final String JSON_UPDATE_URGE_SPOT_NO = "1";
  /** JSON定義：督促更新：需要場所住所(住所) */
  public static final String JSON_UPDATE_URGE_PLACE_ADDRESS = "2";
  /** JSON定義：督促更新：需要場所住所(建物・部屋名) */
  public static final String JSON_UPDATE_URGE_PLACE_NAME = "3";
  /** JSON定義：督促更新：契約開始日 */
  public static final String JSON_UPDATE_URGE_CONTRACT_START_DATE = "4";
  /** JSON定義：督促更新：契約終了日 */
  public static final String JSON_UPDATE_URGE_CONTRACT_END_DATE = "5";
  /** JSON定義：督促更新：契約終了理由 */
  public static final String JSON_UPDATE_URGE_CONTRACT_END_REASON = "6";
  /** JSON定義：督促更新：JSONリスト名 */
  public static final String JSON_UPDATE_URGE_LIST_NAME = "updateUrgeListJson";
  /** JSON定義：預り金一覧照会：発生日 */
  public static final String JSON_DEP_REC_DATE = "0";
  /** JSON定義：預り金一覧照会：預り金等ステータス */
  public static final String JSON_DEP_REC_STS = "1";
  /** JSON定義：預り金一覧照会：金額 */
  public static final String JSON_DEP_REC_AMOUNT = "2";
  /** JSON定義：預り金一覧照会：請求番号 */
  public static final String JSON_DEP_REC_BL_NO = "3";
  /** JSON定義：預り金一覧照会：ご利用年月 */
  public static final String JSON_DEP_REC_USE_PERIOD = "4";
  /** JSON定義：預り金一覧照会：ご利用金額 */
  public static final String JSON_DEP_REC_USE_AMOUNT = "5";
  /** JSON定義：預り金一覧照会：請求額 */
  public static final String JSON_DEP_REC_BL_AMOUNT = "6";
  /** JSON定義：預り金一覧照会：支払方法 */
  public static final String JSON_DEP_REC_BL_CATEGORY = "7";
  /** JSON定義：預り金一覧照会：支払期日 */
  public static final String JSON_DEP_REC_PAYMENT_FIX_DATE = "8";
  /** JSON定義：預り金一覧照会：請求ステータス */
  public static final String JSON_DEP_REC_BL_STS = "9";
  /** JSON定義：預り金一覧照会：預り金等ステータスコード */
  public static final String JSON_DEP_REC_DPR_STS_CD = "10";
  /** JSON定義：預り金一覧照会：請求区分コード */
  public static final String JSON_DEP_REC_BL_CATE_CD = "11";
  /** JSON定義：預り金一覧照会：請求ステータスコード */
  public static final String JSON_DEP_REC_BL_STS_CD = "12";
  /** JSON定義：預り金一覧照会：JSONリスト名 */
  public static final String JSON_DEP_REC_LIST_NAME = "depositsReceivedListJson";
  /** 督促ステータスマスタカラム名：督促ステータスコード */
  public static final String URGE_STATUS_M_COLUMN_NAME_URGE_STATUS_CODE = "urge_status_code";
  /** 解約回避理由マスタカラム名：解約回避理由コード */
  public static final String CE_REASON_M_COLUMN_NAME_CE_REASON_CODE = "ce_reason_code";
  /** 債権譲渡明細書作成：CSV出力ファイルリスト項目数 */
  public static final int CREATE_CLM_ASGN_DETAIL_CSV_OUTPUT_ITEM_COUNT = 8;
  /** 債権譲渡明細書作成：CSV出力ファイルリスト項目順：契約者名 */
  public static final int CREATE_CLM_ASGN_DETAIL_CSV_OUTPUT_CONTRACTOR_NAME = 0;
  /** 債権譲渡明細書作成：CSV出力ファイルリスト項目順：契約者番号 */
  public static final int CREATE_CLM_ASGN_DETAIL_CSV_OUTPUT_CONTRACTOR_NO = 1;
  /** 債権譲渡明細書作成：CSV出力ファイルリスト項目順：確定料金実績ID */
  public static final int CREATE_CLM_ASGN_DETAIL_CSV_OUTPUT_FIX_CHARGE_RESULT_ID = 2;
  /** 債権譲渡明細書作成：CSV出力ファイルリスト項目順：計上日 */
  public static final int CREATE_CLM_ASGN_DETAIL_CSV_OUTPUT_RECORDED_DATE = 3;
  /** 債権譲渡明細書作成：CSV出力ファイルリスト項目順：電力販売収入（低圧） */
  public static final int CREATE_CLM_ASGN_DETAIL_CSV_OUTPUT_ELECTRIC_POWER_SALE_PROCEEDS = 4;
  /** 債権譲渡明細書作成：CSV出力ファイルリスト項目順：再エネ発電賦課金 */
  public static final int CREATE_CLM_ASGN_DETAIL_CSV_OUTPUT_RENEWABLE_ENERGY_GENERATE_LEVY = 5;
  /** 債権譲渡明細書作成：CSV出力ファイルリスト項目順：契約超過金 */
  public static final int CREATE_CLM_ASGN_DETAIL_CSV_OUTPUT_CONTRACT_OVER_AMOUNT = 6;
  /** 債権譲渡明細書作成：CSV出力ファイルリスト項目順：仮受消費税 */
  public static final int CREATE_CLM_ASGN_DETAIL_CSV_OUTPUT_SUSP_CONSUMPTION_TAX = 7;
  /** 貸倒明細書作成：CSV出力ファイルリスト項目数 */
  public static final int CREATE_UNCLCT_DETAIL_CSV_OUTPUT_ITEM_COUNT = 11;
  /** 貸倒明細書作成：CSV出力ファイルリスト項目順：契約者名 */
  public static final int CREATE_UNCLCT_DETAIL_CSV_OUTPUT_CONTRACTOR_NAME = 0;
  /** 貸倒明細書作成：CSV出力ファイルリスト項目順：契約者番号 */
  public static final int CREATE_UNCLCT_DETAIL_CSV_OUTPUT_CONTRACTOR_NO = 1;
  /** 貸倒明細書作成：CSV出力ファイルリスト項目順：請求番号 */
  public static final int CREATE_UNCLCT_DETAIL_CSV_OUTPUT_BILLING_NO = 2;
  /** 貸倒明細書作成：CSV出力ファイルリスト項目順：確定料金実績ID */
  public static final int CREATE_UNCLCT_DETAIL_CSV_OUTPUT_FIX_CHARGE_RESULT_ID = 3;
  /** 貸倒明細書作成：CSV出力ファイルリスト項目順：計上日 */
  public static final int CREATE_UNCLCT_DETAIL_CSV_OUTPUT_RECORDED_DATE = 4;
  /** 貸倒明細書作成：CSV出力ファイルリスト項目順：電力販売収入（低圧） */
  public static final int CREATE_UNCLCT_DETAIL_CSV_OUTPUT_ELECTRIC_POWER_SALE_PROCEEDS = 5;
  /** 貸倒明細書作成：CSV出力ファイルリスト項目順：再エネ発電賦課金 */
  public static final int CREATE_UNCLCT_DETAIL_CSV_OUTPUT_RENEWABLE_ENERGY_GENERATE_LEVY = 6;
  /** 貸倒明細書作成：CSV出力ファイルリスト項目順：契約超過金 */
  public static final int CREATE_UNCLCT_DETAIL_CSV_OUTPUT_CONTRACT_OVER_AMOUNT = 7;
  /** 貸倒明細書作成：CSV出力ファイルリスト項目順：仮受消費税 */
  public static final int CREATE_UNCLCT_DETAIL_CSV_OUTPUT_SUSP_CONSUMPTION_TAX = 8;
  /** 貸倒明細書作成：CSV出力ファイルリスト項目順：支払期日 */
  public static final int CREATE_UNCLCT_DETAIL_CSV_OUTPUT_PAYMENT_FIXED_DATE = 9;
  /** 貸倒明細書作成：CSV出力ファイルリスト項目順：備考 */
  public static final int CREATE_UNCLCT_DETAIL_CSV_OUTPUT_NOTE = 10;
  /** JSON定義：請求消込登録：選択 */
  public static final String JSON_REGIST_BILLING_RECONCILE_SELECTION = "0";
  /** JSON定義：請求消込登録：預り金等金額 */
  public static final String JSON_REGIST_BILLING_RECONCILE_DEPOSITS_RECEIVED_AMOUNT = "1";
  /** JSON定義：請求消込登録：預り金等ステータス */
  public static final String JSON_REGIST_BILLING_RECONCILE_DEPOSITS_RECEIVED_STATUS = "2";
  /** JSON定義：請求消込登録：預り金等ステータスコード */
  public static final String JSON_REGIST_BILLING_RECONCILE_DEPOSITS_RECEIVED_STATUS_CODE = "3";
  /** JSON定義：請求消込登録：入金額 */
  public static final String JSON_REGIST_BILLING_RECONCILE_DEPOSITS_AMOUNT = "4";
  /** JSON定義：請求消込登録：入金ステータス */
  public static final String JSON_REGIST_BILLING_RECONCILE_DEPOSITS_STATUS = "5";
  /** JSON定義：請求消込登録：消込先請求番号 */
  public static final String JSON_REGIST_BILLING_RECONCILE_BILLING_NO = "6";
  /** JSON定義：請求消込登録：ご利用年月 */
  public static final String JSON_REGIST_BILLING_RECONCILE_USE_PERIOD = "7";
  /** JSON定義：請求消込登録：入金日 */
  public static final String JSON_REGIST_BILLING_RECONCILE_DEPOSITS_DATE = "8";
  /** JSON定義：請求消込登録：JSONリスト名 */
  public static final String JSON_REGIST_BILLING_RECONCILE_LIST_NAME = "depositsReceivedListJson";
  /** 請求特別消込理由マスタカラム名：請求特別消込理由コード */
  public static final String BL_SR_REASON_M_COLUMN_NAME_BL_SR_REASON_CODE = "bl_sr_reason_code";
  /** 経理データ作成（前月残高）：CSV出力ファイルリスト項目数 */
  public static final int CREATE_ACCOUNT_DATA_PRE_MON_BAL_CSV_OUTPUT_ITEM_COUNT = 9;
  /** 経理データ作成（前月残高）：CSV出力ファイルリスト項目順：対象年月 */
  public static final int CREATE_ACCOUNT_DATA_PRE_MON_BAL_CSV_OUTPUT_COVERED_PERIOD = 0;
  /** 経理データ作成（前月残高）：CSV出力ファイルリスト項目順：部課コード */
  public static final int CREATE_ACCOUNT_DATA_PRE_MON_BAL_CSV_OUTPUT_SECTION_CODE = 1;
  /** 経理データ作成（前月残高）：CSV出力ファイルリスト項目順：提供モデルコード */
  public static final int CREATE_ACCOUNT_DATA_PRE_MON_BAL_CSV_OUTPUT_PROVIDE_MODEL_CODE = 2;
  /** 経理データ作成（前月残高）：CSV出力ファイルリスト項目順：提供モデル企業コード */
  public static final int CREATE_ACCOUNT_DATA_PRE_MON_BAL_CSV_OUTPUT_PROVIDE_MODEL_COMPANY_CODE = 3;
  /** 経理データ作成（前月残高）：CSV出力ファイルリスト項目順：取引先コード */
  public static final int CREATE_ACCOUNT_DATA_PRE_MON_BAL_CSV_OUTPUT_CUSTOMER_CODE = 4;
  /** 経理データ作成（前月残高）：CSV出力ファイルリスト項目順：消費税率 */
  public static final int CREATE_ACCOUNT_DATA_PRE_MON_BAL_CSV_OUTPUT_CONSUMPTION_TAX_RATE = 5;
  /** 経理データ作成（前月残高）：CSV出力ファイルリスト項目順：勘定科目コード */
  public static final int CREATE_ACCOUNT_DATA_PRE_MON_BAL_CSV_OUTPUT_ACCOUNT_ITEM_CODE = 6;
  /** 経理データ作成（前月残高）：CSV出力ファイルリスト項目順：勘定科目 */
  public static final int CREATE_ACCOUNT_DATA_PRE_MON_BAL_CSV_OUTPUT_ACCOUNT_ITEM = 7;
  /** 経理データ作成（前月残高）：CSV出力ファイルリスト項目順：金額 */
  public static final int CREATE_ACCOUNT_DATA_PRE_MON_BAL_CSV_OUTPUT_AMOUNT = 8;
  /** 経費充当理由マスタカラム名：経費充当理由コード */
  public static final String APA_REASON_M_COLUMN_NAME_APA_REASON_CODE = "apa_reason_code";
  /** 西暦下二桁開始位置 */
  public static final int YEAR_DIGITS_START_LOCATION = 2;
  /** 西暦下二桁終了位置 */
  public static final int YEAR_DIGITS_END_LOCATION = 4;
  /** 請求番号空き桁埋め文字 */
  public static final char BILLING_FREE_DIGIT_FILL_CHARACTER = '0';
  /** 収納結果情報取得_ソート条件 */
  public static final String SELECT_RECEIPT_RESULT_ORDER_QUERY = "receipt_date ASC, rr_id ASC";
  /** 日割あり */
  public static final String PER_DIEM_TRUE = "日割あり";
  /** ファイル種別：取次店月次報酬額ファイル */
  public static final String FILE_CAT_MONTHLYPAY1 = "monthlypay1";
  /** ファイル種別：取次店月次報酬額内訳ファイル */
  public static final String FILE_CAT_MONTHLYPAY2 = "monthlypay2";
  /** 契約時手数料実績フラグ：1 */
  public static final String CONTRACT_PAY_FLG = "1";
  /** 料金回収時手数料実績フラグ：1 */
  public static final String BILLING_PAY_FLG = "1";
  /** 請求設定：請求取得_ソート条件 */
  public static final String BSN010801_BL_ORDER_BY_CLAUSE = "bl_no ASC";
  /** 契約者設定：契約者取得_ソート条件 */
  public static final String BSN010801_CONTRACTOR_ORDER_BY_CLAUSE = "contractor_id ASC";
  /** 確定料金実績設定：確定料金実績取得_ソート条件 */
  public static final String BSN010801_FCR_ORDER_BY_CLAUSE = "contractor_id ASC, mr_date ASC";
  /** 確定料金実績内訳設定：確定料金実績内訳取得_ソート条件 */
  public static final String BSN010801_FCRBREAKDOWN_ORDER_BY_CLAUSE = "display_order ASC, detail_output_order ASC";
  /** 実量歴管理設定：実量歴管理取得_ソート条件 */
  public static final String BSN010801_RQH_ORDER_BY_CLAUSE = "covered_period ASC";
  /** 確定指示数設定：確定指示数取得_ソート条件 */
  public static final String BSN010801_FIXIN_ORDER_BY_CLAUSE = "meter_cat_code ASC";
  /** 時間帯別使用量設定：時間帯別使用量取得_ソート条件 */
  public static final String BSN010801_TSUSAGE_ORDER_BY_CLAUSE = "ts_code ASC";
  /** 請求情報ファイル出力：確定料金実績内訳取得_ソート条件 */
  public static final String BSN060401_FCRBREAKDOWN_ORDER_BY_CLAUSE = "display_order ASC, detail_output_order ASC";
  /** 請求情報ファイル出力：実量歴管理取得_ソート条件 */
  public static final String BSN060401_RQH_ORDER_BY_CLAUSE = "covered_period DESC";

}
