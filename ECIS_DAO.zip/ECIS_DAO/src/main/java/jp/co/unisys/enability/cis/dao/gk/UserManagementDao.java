/*-------------------------------------------------------------------------------
 * All Rights Reserved. Copyright(C) Nihon Unisys, Ltd.
 * vendor : Nihon Unisys, Ltd.
 * since : 2014/09/01
 *-----------------------------------------------------------------------------*/
package jp.co.unisys.enability.cis.dao.gk;

import org.springframework.dao.DataAccessException;

import jp.co.unisys.enability.cis.entity.common.UserManagementWithBLOBs;

/**
 * ユーザ管理DAOインタフェース.<br>
 * ユーザ管理に対するデータアクセスを定義したインタフェース
 *
 */
public interface UserManagementDao {

  /**
   * 引数の情報を元にユーザ管理情報を取得する
   *
   * @param userId
   *          ユーザID
   * @return ユーザ管理情報
   * @throws DataAccessException
   */
  UserManagementWithBLOBs selectUser(String userId)
      throws DataAccessException;

  /**
   * 指定された情報に該当するレコードを更新する 指定された値以外は更新しない
   *
   * @param record
   *          ユーザ管理レコード
   * @return 更新結果件数
   * @throws DataAccessException
   */
  int updateByPrimaryKeySelective(UserManagementWithBLOBs record)
      throws DataAccessException;

  /**
   * 引数の情報を元にパスワードの更新日時の情報を取得する
   *
   * @param userId
   *          ユーザID
   * @return ユーザ管理エンティティ
   * @throws DataAccessException
   */
  UserManagementWithBLOBs selectPasswordUpdate(String userId)
      throws DataAccessException;

  /**
   * 引数の情報を元にパスワード変更条件の情報を取得する
   *
   * @param userId
   *          ユーザID
   * @return ユーザ管理エンティティ
   * @throws DataAccessException
   */
  UserManagementWithBLOBs selectChangeCondition(String userId)
      throws DataAccessException;

  /**
   * 引数の情報を元にパスワードの更新を行う
   *
   * @param password
   *          パスワード
   * @param userId
   *          ユーザID
   * @param initialFlg
   *          初期化フラグ
   * @param updateModuleCode
   *          更新モジュールコード
   * @param updateUserId
   *          更新ユーザID
   * @return 0：成功、1：更新失敗、9：更新失敗（その他）
   * @throws DataAccessException
   */
  String updatePassword(String password, String userId, Short initialFlg,
      String updateModuleCode, String updateUserId, String updateTimeKey)
      throws DataAccessException;

  /**
   * 引数の情報を元にユーザ情報の称号
   *
   * @param password
   *          パスワード
   * @param userId
   *          ユーザID
   * @return 0：成功、1：照合失敗、9：照合失敗（その他）
   * @throws DataAccessException
   */
  String selectCallCollation(String password, String userId)
      throws DataAccessException;

}