package jp.co.unisys.enability.cis.dao.rk;

import java.util.List;

import org.springframework.dao.DataAccessException;

import jp.co.unisys.enability.cis.entity.rk.RK010301_CalcTargetEntityBean;

/**
 * 計算用使用量登録 に関するデータアクセス層へのインタフェースをサービス層に提供するクラス
 *
 * <pre>
 * <p><b>【仕様詳細】</b></p>
 * 以下のインタフェースを提供する。
 * ・計算対象データの取得
 *
 * <p><b>対象テーブル：</b></p>
 * 　・FIX_USAGE
 * 　・CONTRACT_HISTORY
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public interface RK010301_ChargeCalculateDao {

  /**
   * 計算対象となるデータを取得する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された条件で確定使用量、契約履歴を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param calcTargetEntityBean
   *          計算用使用量登録計算対象EntityBean
   * @return 計算対象となった確定使用量
   * @throws DataAccessException
   *           予期せぬエラーが発生した場合
   */
  List<RK010301_CalcTargetEntityBean> selectCalcurateTargetFixUsage(
      RK010301_CalcTargetEntityBean calcTargetEntityBean) throws DataAccessException;

}
