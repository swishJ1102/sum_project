package jp.co.unisys.enability.cis.dao.rk;

import java.util.Date;
import java.util.HashMap;
import java.util.List;

import jp.co.unisys.enability.cis.entity.rk.RK010201_NotLinkedEntityBean;
import jp.co.unisys.enability.cis.mapper.rk.RK010201_UsageLinkageCheckMapper;

/**
 * 使用量連携チェックに関するデータアクセス層へのインタフェース。
 *
 * <pre>
 * <p><b>【仕様詳細】</b></p>
 * 以下のインタフェースをサービス層に提供する。
 * 　・確定使用量メッセージ未達判定
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK010201_UsageLinkageCheckDaoImpl implements
    RK010201_UsageLinkageCheckDao {

  /** 使用量連携チェックMapper(DI) */
  private RK010201_UsageLinkageCheckMapper rk010201UsageLinkageCheckMapper;

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.dao.rk.RK010201_UsageLinkageCheckDao#
   * selectNotLinked(java.sql.Date, java.sql.Date)
   */
  @Override
  public List<RK010201_NotLinkedEntityBean> selectNotLinked(Date executeDate,
      Date decisionDate) {

    HashMap<String, Object> exampleMap = new HashMap<String, Object>();
    exampleMap.put("executeDate", executeDate);
    exampleMap.put("decisionDate", decisionDate);
    return rk010201UsageLinkageCheckMapper.selectNotLinked(exampleMap);
  }

  /**
   * 使用量連携チェックMapperを設定します。(DI)
   *
   * @param rk010201UsageLinkageCheckMapper
   *          使用量連携チェックMapper
   */
  public void setRk010201UsageLinkageCheckMapper(
      RK010201_UsageLinkageCheckMapper rk010201UsageLinkageCheckMapper) {
    this.rk010201UsageLinkageCheckMapper = rk010201UsageLinkageCheckMapper;
  }

}
