package jp.co.unisys.enability.cis.dao.rk;

/**
 * 料金計算ワークデータ削除に関するデータアクセス層へのインタフェース
 *
 * <pre>
 * <p><b>【仕様詳細】</b></p>
 * 以下のインタフェースを提供する。
 * ・計算用使用量の切捨て
 * ・計算用時間帯別使用量の切捨て
 * ・計算用指示数の切捨て
 * ・計算結果の切捨て
 * ・計算結果内訳の切捨て
 * ・計算結果警告データの切捨て
 *
 * <p><b>対象テーブル：</b></p>
 * ・計算用使用量
 * ・計算用時間帯別使用量
 * ・計算用指示数
 * ・計算結果
 * ・計算結果内訳
 * ・計算結果警告
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.mapper.rk.RK_DeleteWorkDataMapper
 */
public interface RK_DeleteWorkDataDao {

  /**
   * 計算用使用量データを切り捨てる。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計算用使用量エンティティのデータを切り捨てる。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   */
  public void truncateCalcForUsage();

  /**
   * 計算用日割別使用量データを切り捨てる。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計算用日割別使用量エンティティのデータを切り捨てる。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   */
  public void truncateCalcForDateSlotByUsage();

  /**
   * 計算用時間帯別使用量データを切り捨てる。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計算用時間帯別使用量エンティティのデータを切り捨てる。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   */
  public void truncateCalcForTimeSlotByUsage();

  /**
   * 計算用指示数データを切り捨てる。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計算用指示数エンティティのデータを切り捨てる。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   */
  public void truncateCalcForFixIndicationNo();

  /**
   * 計算結果データを切り捨てる。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計算結果エンティティのデータを切り捨てる。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   */
  public void truncateCalculateResult();

  /**
   * 計算結果内訳データを切り捨てる。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計算結果内訳エンティティのデータを切り捨てる。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   */
  public void truncateCalcResultBreakdown();

  /**
   * 計算結果警告データを切り捨てる。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計算結果警告エンティティのデータを切り捨てる。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   */
  public void truncateCalcResultWarningData();

}
