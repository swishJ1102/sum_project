package jp.co.unisys.enability.cis.dao.rk;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.dao.DataAccessException;

import jp.co.unisys.enability.cis.mapper.rk.RK020202_UnitPriceManagementMapper;

/**
 * 付帯単価に関するデータアクセスをビジネスロジック層に提供するクラス。
 *
 * <pre>
 * <p><b>【仕様詳細】</b></p>
 * 以下のインタフェースを提供する。
 * ・料金算定開始日の最大値を取得
 *
 * <p><b>対象テーブル：</b></p>
 * 　・FCR
 * 　・FCR_BREAKDOWN
 * 　・SPL_CONTRACT
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.dao.rk.RK020202_UnitPriceManagementDao
 */
public class RK020202_UnitPriceManagementDaoImpl implements
    RK020202_UnitPriceManagementDao {

  private RK020202_UnitPriceManagementMapper mapper;

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.dao.rk.RK020202_UnitPriceManagementDao#
   * selectFixChargeResultCalculationStartDateMaxBySupplementaryMenuId
   * (java.lang.String)
   */
  @Override
  public Date selectFixChargeResultCalculationStartDateMaxBySupplementaryMenuId(
      String conditionSupplementaryMenuId, Date upApplySd, Date upApplyEd) throws DataAccessException {

    Map<String, Object> map = new HashMap<String, Object>();
    map.put("conditionSupplementaryMenuId", conditionSupplementaryMenuId);
    map.put("upApplySd", upApplySd);
    map.put("upApplyEd", upApplyEd);

    return mapper
        .selectFixChargeResultCalculationStartDateMaxBySupplementaryMenuId(map);

  }

  /**
   * mapperを設定します。
   *
   * @param mapper
   *          mapper
   */
  public void setMapper(RK020202_UnitPriceManagementMapper mapper) {
    this.mapper = mapper;
  }

}
