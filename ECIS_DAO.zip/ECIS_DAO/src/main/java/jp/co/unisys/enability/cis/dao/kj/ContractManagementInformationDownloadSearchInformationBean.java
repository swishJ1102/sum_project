package jp.co.unisys.enability.cis.dao.kj;

import java.io.Serializable;

/**
 * 契約管理情報ダウンロード検索条件Bean
 *
 * @author "Nihon Unisys, Ltd."
 */
@SuppressWarnings("serial")
public class ContractManagementInformationDownloadSearchInformationBean implements Serializable {

  /**
   * ファイル種別を保有する。
   */
  private String fileClass;

  /**
   * エリアを保有する。
   */
  private String area;

  /**
   * 提供モデルを保有する。
   */
  private String provideModel;

  /**
   * 提供モデル企業を保有する。
   */
  private String provideModelCompany;

  /**
   * 契約者番号を保有する。
   */
  private String contractorNo;

  /**
   * 契約者利用状況を保有する。
   */
  private String contractorUseStatus;

  /**
   * 契約番号を保有する。
   */
  private String contractNo;

  /**
   * 契約期間(開始日From)を保有する。
   */
  private String contractTermStartDateFrom;

  /**
   * 契約期間(開始日To)を保有する。
   */
  private String contractTermStartDateTo;

  /**
   * 契約期間(終了日From)を保有する。
   */
  private String contractTermEndDateFrom;

  /**
   * 契約期間(終了日To)を保有する。
   */
  private String contractTermEndDateTo;

  /**
   * 付帯メニューを保有する。
   */
  private String supplementaryMenu;

  /**
   * 付帯契約期間(開始日)を保有する。
   */
  private String supplementaryContractTermStartDate;

  /**
   * 付帯契約期間(終了日)を保有する。
   */
  private String supplementaryContractTermEndDate;

  /**
   * 個人・法人区分を保有する。
   */
  private String individualLegalEntityCategory;

  /**
   * 支払番号を保有する。
   */
  private String paymentNo;

  /**
   * 支払方法（支払方法マスタ）を保有する。
   */
  private String paymentWay;

  /**
   * 支払方法（口座クレカ区分マスタ）を保有する。
   */
  private String accountCreditCategoryPaymentWay;

  /**
   * 支払適用期間(開始日)を保有する。
   */
  private String paymentApplyTermStartDate;

  /**
   * 支払適用期間(終了日)を保有する。
   */
  private String paymentApplyTermEndDate;

  /**
   * 取引先コードを保有する。
   */
  private String customerCode;

  /**
   * 送受電区分を保有する。
   */
  private String transmissionCategory;

  /**
   * 地点特定番号を保有する。
   */
  private String spotNo;

  /**
   * 督促対象を保有する。
   */
  private String urgeCovered;

  /**
   * 料金メニューを保有する。
   */
  private String rateMenu;

  /**
   * オンライン処理基準日を保有する。
   */
  private String onlineExecuteBaseDate;

  /**
   * 外部システム契約者番号を保有する。
   */
  private String externalManageContractorNo;

  /**
   * ファイル種別のgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * ファイル種別を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return ファイル種別
   */
  public String getFileClass() {
    return this.fileClass;
  }

  /**
   * ファイル種別のsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * ファイル種別を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param fileClass
   *          ファイル種別
   */
  public void setFileClass(String fileClass) {
    this.fileClass = fileClass;
  }

  /**
   * エリアのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * エリアを取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return エリア
   */
  public String getArea() {
    return this.area;
  }

  /**
   * エリアのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * エリアを設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param area
   *          エリア
   */
  public void setArea(String area) {
    this.area = area;
  }

  /**
   * 提供モデルのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 提供モデルを取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 提供モデル
   */
  public String getProvideModel() {
    return this.provideModel;
  }

  /**
   * 提供モデルのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 提供モデルを設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param provideModel
   *          提供モデル
   */
  public void setProvideModel(String provideModel) {
    this.provideModel = provideModel;
  }

  /**
   * 提供モデル企業のgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 提供モデル企業を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 提供モデル企業
   */
  public String getProvideModelCompany() {
    return this.provideModelCompany;
  }

  /**
   * 提供モデル企業のsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 提供モデル企業を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param provideModelCompany
   *          提供モデル企業
   */
  public void setProvideModelCompany(String provideModelCompany) {
    this.provideModelCompany = provideModelCompany;
  }

  /**
   * 契約者番号のgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 契約者番号を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 契約者番号
   */
  public String getContractorNo() {
    return this.contractorNo;
  }

  /**
   * 契約者番号のsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 契約者番号を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param contractorNo
   *          契約者番号
   */
  public void setContractorNo(String contractorNo) {
    this.contractorNo = contractorNo;
  }

  /**
   * 契約者利用状況のgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 契約者利用状況を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 契約者利用状況
   */
  public String getContractorUseStatus() {
    return this.contractorUseStatus;
  }

  /**
   * 契約者利用状況のsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 契約者利用状況を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param contractorUseStatus
   *          契約者利用状況
   */
  public void setContractorUseStatus(String contractorUseStatus) {
    this.contractorUseStatus = contractorUseStatus;
  }

  /**
   * 契約番号のgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 契約番号を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 契約番号
   */
  public String getContractNo() {
    return this.contractNo;
  }

  /**
   * 契約番号のsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 契約番号を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param contractNo
   *          契約番号
   */
  public void setContractNo(String contractNo) {
    this.contractNo = contractNo;
  }

  /**
   * 契約期間(開始日From)のgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 契約期間(開始日From)を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 契約期間(開始日From)
   */
  public String getContractTermStartDateFrom() {
    return this.contractTermStartDateFrom;
  }

  /**
   * 契約期間(開始日From)のsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 契約期間(開始日From)を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param contractTermStartDate
   *          契約期間(開始日From)
   */
  public void setContractTermStartDateFrom(String contractTermStartDateFrom) {
    this.contractTermStartDateFrom = contractTermStartDateFrom;
  }

  /**
   * 契約期間(開始日To)のgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 契約期間(開始日To)を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 契約期間(開始日To)
   */
  public String getContractTermStartDateTo() {
    return this.contractTermStartDateTo;
  }

  /**
   * 契約期間(開始日To)のsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 契約期間(開始日To)を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param contractTermStartDate
   *          契約期間(開始日To)
   */
  public void setContractTermStartDateTo(String contractTermStartDateTo) {
    this.contractTermStartDateTo = contractTermStartDateTo;
  }

  /**
   * 契約期間(終了日From)のgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 契約期間(終了日From)を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 契約期間(終了日From)
   */
  public String getContractTermEndDateFrom() {
    return this.contractTermEndDateFrom;
  }

  /**
   * 契約期間(終了日From)のsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 契約期間(終了日From)を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param contractTermEndDate
   *          契約期間(終了日From)
   */
  public void setContractTermEndDateFrom(String contractTermEndDateFrom) {
    this.contractTermEndDateFrom = contractTermEndDateFrom;
  }

  /**
   * 契約期間(終了日To)のgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 契約期間(終了日To)を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 契約期間(終了日To)
   */
  public String getContractTermEndDateTo() {
    return this.contractTermEndDateTo;
  }

  /**
   * 契約期間(終了日From)のsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 契約期間(終了日From)を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param contractTermEndDate
   *          契約期間(終了日From)
   */
  public void setContractTermEndDateTo(String contractTermEndDateTo) {
    this.contractTermEndDateTo = contractTermEndDateTo;
  }

  /**
   * 付帯メニューのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 付帯メニューを取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 付帯メニュー
   */
  public String getSupplementaryMenu() {
    return this.supplementaryMenu;
  }

  /**
   * 付帯メニューのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 付帯メニューを設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param supplementaryMenu
   *          付帯メニュー
   */
  public void setSupplementaryMenu(String supplementaryMenu) {
    this.supplementaryMenu = supplementaryMenu;
  }

  /**
   * 付帯契約期間(開始日)のgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 付帯契約期間(開始日)を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 付帯契約期間(開始日)
   */
  public String getSupplementaryContractTermStartDate() {
    return this.supplementaryContractTermStartDate;
  }

  /**
   * 付帯契約期間(開始日)のsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 付帯契約期間(開始日)を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param supplementaryContractTermStartDate
   *          付帯契約期間(開始日)
   */
  public void setSupplementaryContractTermStartDate(String supplementaryContractTermStartDate) {
    this.supplementaryContractTermStartDate = supplementaryContractTermStartDate;
  }

  /**
   * 付帯契約期間(終了日)のgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 付帯契約期間(終了日)を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 付帯契約期間(終了日)
   */
  public String getSupplementaryContractTermEndDate() {
    return this.supplementaryContractTermEndDate;
  }

  /**
   * 付帯契約期間(終了日)のsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 付帯契約期間(終了日)を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param supplementaryContractTermEndDate
   *          付帯契約期間(終了日)
   */
  public void setSupplementaryContractTermEndDate(String supplementaryContractTermEndDate) {
    this.supplementaryContractTermEndDate = supplementaryContractTermEndDate;
  }

  /**
   * 個人・法人区分のgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 個人・法人区分を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 個人・法人区分
   */
  public String getIndividualLegalEntityCategory() {
    return this.individualLegalEntityCategory;
  }

  /**
   * 個人・法人区分のsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 個人・法人区分を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param individualLegalEntityCategory
   *          個人・法人区分
   */
  public void setIndividualLegalEntityCategory(String individualLegalEntityCategory) {
    this.individualLegalEntityCategory = individualLegalEntityCategory;
  }

  /**
   * 支払番号のgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 支払番号を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 支払番号
   */
  public String getPaymentNo() {
    return this.paymentNo;
  }

  /**
   * 支払番号のsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 支払番号を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param paymentNo
   *          支払番号
   */
  public void setPaymentNo(String paymentNo) {
    this.paymentNo = paymentNo;
  }

  /**
   * 支払方法（支払方法マスタ）のgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 支払方法（支払方法マスタ）を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 支払方法
   */
  public String getPaymentWay() {
    return this.paymentWay;
  }

  /**
   * 支払方法（支払方法マスタ）のsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 支払方法（支払方法マスタ）を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param paymentWay
   *          支払方法
   */
  public void setPaymentWay(String paymentWay) {
    this.paymentWay = paymentWay;
  }

  /**
   * 支払方法（口座クレカ区分マスタ）のgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 支払方法（口座クレカ区分マスタ）を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 支払方法
   */
  public String getAccountCreditCategoryPaymentWay() {
    return accountCreditCategoryPaymentWay;
  }

  /**
   * 支払方法（口座クレカ区分マスタ）のsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 支払方法（口座クレカ区分マスタ）を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param paymentWay
   *          支払方法
   */
  public void setAccountCreditCategoryPaymentWay(
      String accountCreditCategoryPaymentWay) {
    this.accountCreditCategoryPaymentWay = accountCreditCategoryPaymentWay;
  }

  /**
   * 支払適用期間(開始日)のgetter
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 支払適用期間(開始日)を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 支払適用期間(開始日)
   */
  public String getPaymentApplyTermStartDate() {
    return this.paymentApplyTermStartDate;
  }

  /**
   * 支払適用期間(開始日)のsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 支払適用期間(開始日)を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param paymentApplyTermStartDate
   *          支払適用期間(開始日)
   */
  public void setPaymentApplyTermStartDate(String paymentApplyTermStartDate) {
    this.paymentApplyTermStartDate = paymentApplyTermStartDate;
  }

  /**
   * 支払適用期間(終了日)のgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 支払適用期間(終了日)を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 支払適用期間(終了日)
   */
  public String getPaymentApplyTermEndDate() {
    return this.paymentApplyTermEndDate;
  }

  /**
   * 支払適用期間(終了日)のsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 支払適用期間(終了日)を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param paymentApplyTermEndDate
   *          支払適用期間(終了日)
   */
  public void setPaymentApplyTermEndDate(String paymentApplyTermEndDate) {
    this.paymentApplyTermEndDate = paymentApplyTermEndDate;
  }

  /**
   * 取引先コードのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 取引先コードを取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 取引先コード
   */
  public String getCustomerCode() {
    return this.customerCode;
  }

  /**
   * 取引先コードのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 取引先コードを設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param customerCode
   *          取引先コード
   */
  public void setCustomerCode(String customerCode) {
    this.customerCode = customerCode;
  }

  /**
   * 送受電区分のgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 送受電区分を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 送受電区分
   */
  public String getTransmissionCategory() {
    return this.transmissionCategory;
  }

  /**
   * 送受電区分のsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 送受電区分を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param transmissionCategory
   *          送受電区分
   */
  public void setTransmissionCategory(String transmissionCategory) {
    this.transmissionCategory = transmissionCategory;
  }

  /**
   * 地点特定番号のgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 地点特定番号を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 地点特定番号
   */
  public String getSpotNo() {
    return this.spotNo;
  }

  /**
   * 地点特定番号のsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 地点特定番号を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param spotNo
   *          地点特定番号
   */
  public void setSpotNo(String spotNo) {
    this.spotNo = spotNo;
  }

  /**
   * 督促対象のgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 督促対象を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 督促対象
   */
  public String getUrgeCovered() {
    return this.urgeCovered;
  }

  /**
   * 督促対象のsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 督促対象を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param urgeCovered
   *          督促対象
   */
  public void setUrgeCovered(String urgeCovered) {
    this.urgeCovered = urgeCovered;
  }

  /**
   * 料金メニューのgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 料金メニューを取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 料金メニュー
   */
  public String getRateMenu() {
    return this.rateMenu;
  }

  /**
   * 料金メニューのsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 料金メニューを設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param rateMenu
   *          料金メニュー
   */
  public void setRateMenu(String rateMenu) {
    this.rateMenu = rateMenu;
  }

  /**
   * オンライン処理基準日のgetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * オンライン処理基準日を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return オンライン処理基準日
   */
  public String getOnlineExecuteBaseDate() {
    return this.onlineExecuteBaseDate;
  }

  /**
   * オンライン処理基準日のsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * オンライン処理基準日を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param onlineExecuteBaseDate
   *          オンライン処理基準日
   */
  public void setOnlineExecuteBaseDate(String onlineExecuteBaseDate) {
    this.onlineExecuteBaseDate = onlineExecuteBaseDate;
  }

  /**
   * 外部システム契約者番号getter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 外部システム契約者番号を取得します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @return 外部システム契約者番号
   */
  public String getExternalManageContractorNo() {
    return this.externalManageContractorNo;
  }

  /**
   * 外部システム契約者番号のsetter
   * 
   * <pre>
  * <p><b>【仕様詳細】</b></p>
  * 外部システム契約者番号を設定します。
   * </pre>
   * 
   * @author "Nihon Unisys, Ltd."
   * @param externalManageContractorNo
   *          外部システム契約者番号
   */
  public void setExternalManageContractorNo(String externalManageContractorNo) {
    this.externalManageContractorNo = externalManageContractorNo;
  }
}
