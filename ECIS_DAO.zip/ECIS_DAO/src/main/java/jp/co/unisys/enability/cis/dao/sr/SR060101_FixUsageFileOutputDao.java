package jp.co.unisys.enability.cis.dao.sr;

import java.util.Map;

import org.apache.ibatis.cursor.Cursor;
import org.springframework.dao.DataAccessException;

import jp.co.unisys.enability.cis.entity.sr.SR060101_SearchDownloadDemandResultEntityBean;

/**
 * ダウンロード用需要実績情報ダウンロード に関するデータアクセス層へのインタフェースをビジネスロジック層に提供するクラス
 *
 * <pre>
 * <p><b>【仕様詳細】</b></p>
 * 以下のインタフェースを提供する。
 * ・ダウンロード用需要実績情報の取得
 *
 * <p><b>対象テーブル：</b></p>
 * 　・DL_DEMAND_RESULT
 * 　・ML
 * 　・CONTRACT
 * 　・CONTRACT_HIST
 * 　・CONTRACTOR
 * 　・PM_COMPANY_M
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public interface SR060101_FixUsageFileOutputDao {

  /**
   * ダウンロード用需要実績情報を取得する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された条件で
   * ダウンロード用需要実績、メータ設置場所、契約、契約履歴、契約者、提供モデル企業マスタを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param searchDownloadDemandResultEntityBean
   *          確定使用量ファイルダウンロード用需要実績検索EntityBean
   * @return ダウンロード用需要実績情報Map
   * @throws DataAccessException
   *           予期せぬエラーが発生した場合
   */
  Cursor<Map<String, Object>> selectDlDemandResultInfo(
      SR060101_SearchDownloadDemandResultEntityBean searchDownloadDemandResultEntityBean)
      throws DataAccessException;

  /**
   * ダウンロード用需要実績件数を取得する。
   *
   * @author "Nihon Unisys, Ltd."
   * @param searchDownloadDemandResultEntityBean
   * @return ダウンロード用需要実績件数 予期せぬエラーが発生した場合
   * @throws DataAccessException
   */
  int countDlDemandResultInfo(
      SR060101_SearchDownloadDemandResultEntityBean searchDownloadDemandResultEntityBean)
      throws DataAccessException;
}
