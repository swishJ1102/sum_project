package jp.co.unisys.enability.cis.dao.sr;

import java.util.HashMap;
import java.util.Map;

import org.apache.ibatis.cursor.Cursor;
import org.springframework.dao.DataAccessException;

import jp.co.unisys.enability.cis.entity.sr.SR060101_SearchDownloadDemandResultEntityBean;
import jp.co.unisys.enability.cis.mapper.sr.SR060101_FixUsageInfoFileOutputMapper;

/**
 * 確定使用量ファイルダウンロード に関するデータアクセスをビジネスロジック層に提供するクラス。
 *
 * <pre>
 * <p><b>【仕様詳細】</b></p>
 * 以下のインタフェースを提供する。
 * ・ダウンロード用需要実績情報の取得
 *
 * <p><b>対象テーブル：</b></p>
 * 　・DL_DEMAND_RESULT
 * 　・ML
 * 　・CONTRACT
 * 　・CONTRACT_HIST
 * 　・CONTRACTOR
 * 　・PM_COMPANY_M
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class SR060101_FixUsageFileOutputDaoImpl implements
    SR060101_FixUsageFileOutputDao {

  /** 確定使用量ファイル出力マッパー（DI） **/
  private SR060101_FixUsageInfoFileOutputMapper sr060101FixUsageInfoFileOutputMapper;

  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.dao.sr.SR060101_FixUsageFileOutputDao#selectDlDemandResultInfo(jp.co.unisys.enability.cis.entity.sr.SR060101_SearchDownloadDemandResultEntityBean)
   */
  @Override
  public Cursor<Map<String, Object>> selectDlDemandResultInfo(
      SR060101_SearchDownloadDemandResultEntityBean searchDownloadDemandResultEntityBean)
      throws DataAccessException {

    // 条件Mapを作成
    Map<String, Object> exampleMap = new HashMap<String, Object>();

    // 条件Mapに以下の値を設定
    // 条件Map.対象期間（開始）
    // ＝《確定使用量ファイルダウンロード用需要実績検索EntityBean》.対象期間（開始）
    exampleMap.put("targetPeriodStart", searchDownloadDemandResultEntityBean.getTargetPeriodStart());

    // 条件Map.対象期間（終了）
    // ＝《確定使用量ファイルダウンロード用需要実績検索EntityBean》.対象期間（終了）
    exampleMap.put("targetPeriodEnd", searchDownloadDemandResultEntityBean.getTargetPeriodEnd());

    // 条件Map.エリア
    // ＝《確定使用量ファイルダウンロード用需要実績検索EntityBean》.エリア
    exampleMap.put("area", searchDownloadDemandResultEntityBean.getArea());

    // 条件Map.電圧区分
    // ＝《確定使用量ファイルダウンロード用需要実績検索EntityBean》.電圧区分
    exampleMap.put("volCategory", searchDownloadDemandResultEntityBean.getVolCategory());

    // 条件Map.送受電区分
    // ＝《確定使用量ファイルダウンロード用需要実績検索EntityBean》.送受電区分
    exampleMap.put("transmissionCategory", searchDownloadDemandResultEntityBean.getTransmissionCategory());

    // 条件Map.お客様番号
    // ＝《確定使用量ファイルダウンロード用需要実績検索EntityBean》.お客様番号
    exampleMap.put("customerNo", searchDownloadDemandResultEntityBean.getCustomerNo());

    // 条件Map.地点特定番号
    // ＝《確定使用量ファイルダウンロード用需要実績検索EntityBean》.地点特定番号
    exampleMap.put("spotNo", searchDownloadDemandResultEntityBean.getSpotNo());

    return sr060101FixUsageInfoFileOutputMapper.selectDownloadDemanadResultInfo(exampleMap);
  }

  /**
   * 確定使用量ファイル出力マッパーのsetter（DI）
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 確定使用量ファイル出力マッパーを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param sr060101FixUsageInfoFileOutputMapper
   *          確定使用量ファイル出力マッパー
   */
  public void setSr060101FixUsageInfoFileOutputMapper(
      SR060101_FixUsageInfoFileOutputMapper sr060101FixUsageInfoFileOutputMapper) {
    this.sr060101FixUsageInfoFileOutputMapper = sr060101FixUsageInfoFileOutputMapper;
  }

  @Override
  public int countDlDemandResultInfo(
      SR060101_SearchDownloadDemandResultEntityBean searchDownloadDemandResultEntityBean)
      throws DataAccessException {
    // 条件Mapを作成
    Map<String, Object> exampleMap = new HashMap<String, Object>();

    // 条件Mapに以下の値を設定
    // 条件Map.対象期間（開始）
    // ＝《確定使用量ファイルダウンロード用需要実績検索EntityBean》.対象期間（開始）
    exampleMap.put("targetPeriodStart", searchDownloadDemandResultEntityBean.getTargetPeriodStart());

    // 条件Map.対象期間（終了）
    // ＝《確定使用量ファイルダウンロード用需要実績検索EntityBean》.対象期間（終了）
    exampleMap.put("targetPeriodEnd", searchDownloadDemandResultEntityBean.getTargetPeriodEnd());

    // 条件Map.エリア
    // ＝《確定使用量ファイルダウンロード用需要実績検索EntityBean》.エリア
    exampleMap.put("area", searchDownloadDemandResultEntityBean.getArea());

    // 条件Map.電圧区分
    // ＝《確定使用量ファイルダウンロード用需要実績検索EntityBean》.電圧区分
    exampleMap.put("volCategory", searchDownloadDemandResultEntityBean.getVolCategory());

    // 条件Map.送受電区分
    // ＝《確定使用量ファイルダウンロード用需要実績検索EntityBean》.送受電区分
    exampleMap.put("transmissionCategory", searchDownloadDemandResultEntityBean.getTransmissionCategory());

    // 条件Map.お客様番号
    // ＝《確定使用量ファイルダウンロード用需要実績検索EntityBean》.お客様番号
    exampleMap.put("customerNo", searchDownloadDemandResultEntityBean.getCustomerNo());

    // 条件Map.地点特定番号
    // ＝《確定使用量ファイルダウンロード用需要実績検索EntityBean》.地点特定番号
    exampleMap.put("spotNo", searchDownloadDemandResultEntityBean.getSpotNo());

    return sr060101FixUsageInfoFileOutputMapper.countDownloadDemanadResultInfo(exampleMap);
  }
}
