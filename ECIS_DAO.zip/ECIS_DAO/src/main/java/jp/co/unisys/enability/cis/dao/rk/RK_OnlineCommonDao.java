package jp.co.unisys.enability.cis.dao.rk;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.dao.DataAccessException;

import jp.co.unisys.enability.cis.entity.common.Spm;
import jp.co.unisys.enability.cis.entity.common.TsUsage;
import jp.co.unisys.enability.cis.entity.common.WarningClassM;

/**
 * 料金計算オンライン共通ビジネスに関するデータアクセス層へのインタフェースを ビジネスロジック層に提供するクラス。
 *
 * <pre>
 * <p><b>【仕様詳細】</b></p>
 * 以下のインタフェースを提供する。
 * ・付帯メニューの取得
 * ・警告種別の取得
 *
 * <p><b>対象テーブル：</b></p>
 * 　・SUPPLEMENTARY_CONTRACT
 * 　・WARNING_CLASS_MASTER
 * 　・TIME_SLOT_USAGE
 * 　・RATE_MENU_TIME_SLOT
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public interface RK_OnlineCommonDao {

  /**
   * 付帯メニューを取得する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された条件で付帯メニューを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param supplementaryMenuIdList
   *          付帯メニューIDリスト
   * @return 付帯メニューリスト
   * @throws DataAccessException
   *           予期せぬエラーが発生した場合
   *
   */
  List<Spm> selectSupplementaryMenu(@Param("supplementaryMenuIdList") List<Integer> supplementaryMenuIdList)
      throws DataAccessException;

  /**
   * 警告種別マスタを取得する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された条件で警告種別マスタを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param warningClassCodeList
   *          警告種別コードリスト
   * @return 警告種別マスタリスト
   * @throws DataAccessException
   *           予期せぬエラーが発生した場合
   *
   */
  List<WarningClassM> selectWarningClass(@Param("warningClassCodeList") List<String> warningClassCodeList)
      throws DataAccessException;

  /**
   * 時間帯別使用量を取得する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された条件で時間帯別使用量を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param fixUsageId
   *          確定使用量ID
   * @param rateMenuId
   *          料金メニューID
   * @return 時間帯別使用量リスト
   * @throws DataAccessException
   *           予期せぬエラーが発生した場合
   *
   */
  List<TsUsage> selectTimeSlotUsage(Integer fixUsageId, String rateMenuId) throws DataAccessException;

}
