package jp.co.unisys.enability.cis.dao.rk;

import java.util.Date;

import org.springframework.dao.DataAccessException;

import jp.co.unisys.enability.cis.entity.common.AcInformation;
import jp.co.unisys.enability.cis.entity.common.CalculatingUsage;
import jp.co.unisys.enability.cis.entity.common.Rm;

/**
 * 料金計算警告チェック に関するデータアクセス層へのインタフェースをビジネスロジック層に提供するクラス。
 * 
 * <pre>
 * <p><b>【仕様詳細】</b></p>
 * 以下のインタフェースをビジネス層に提供する。
 * ・契約種別情報取得処理
 * ・力率情報取得処理
 * ・口座クレカ情報取得処理
 * 対象テーブル：
 * 　・RM
 * 　・CALCULATION_RESULT
 * 　・CALCULATING_USAGE
 * 　・CONTRACT
 * 　・PAYMENT
 * 　・PAYMENT_HIST
 * 　・AC_INFORMATION
 * </pre>
 * 
 * @author "Nihon Unisys, Ltd."
 */
public interface RK_ChargeCalcWarningCheckDao {

  /**
   * 契約種別情報・売買区分コードを取得する。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で契約種別情報・売買区分コードを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractID
   *          契約ID
   * @param usePeriod
   *          利用年月
   * @return 料金メニュー
   * @throws DataAccessException
   *           予期せぬエラーが発生した場合
   */
  Rm selectContractClassInfo(Integer contractID, String usePeriod) throws DataAccessException;

  /**
   * 力率情報を取得する。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で力率情報を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractID
   *          契約ID
   * @param usePeriod
   *          利用年月
   * @return 計算用使用量
   * @throws DataAccessException
   *           予期せぬエラーが発生した場合
   */
  CalculatingUsage selectPowerFactorInfo(Integer contractID, String usePeriod) throws DataAccessException;

  /**
   * 口座クレカ情報を取得する。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で口座クレカ情報を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractID
   *          契約ID
   * @param chargeCalculationStartDate
   *          料金算定開始日
   * @return 口座クレカ情報
   * @throws DataAccessException
   *           予期せぬエラーが発生した場合
   */
  AcInformation selectAccountCreditCardInfo(Integer contractID, Date chargeCalculationStartDate)
      throws DataAccessException;
}
