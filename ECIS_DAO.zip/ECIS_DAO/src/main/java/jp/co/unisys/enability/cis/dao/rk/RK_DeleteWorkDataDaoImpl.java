package jp.co.unisys.enability.cis.dao.rk;

import jp.co.unisys.enability.cis.mapper.rk.RK_DeleteWorkDataMapper;

/**
 * 料金計算ワークデータ削除に関するデータアクセスの実装クラス
 *
 * <pre>
 * <p><b>【仕様詳細】</b></p>
 * 以下のインタフェースを提供する。
 * ・計算用使用量の切捨て
 * ・計算用時間帯別使用量の切捨て
 * ・計算用指示数の切捨て
 * ・計算結果の切捨て
 * ・計算結果内訳の切捨て
 * ・計算結果警告データの切捨て
 *
 * <p><b>対象テーブル：</b></p>
 * ・計算用使用量
 * ・計算用時間帯別使用量
 * ・計算用指示数
 * ・計算結果
 * ・計算結果内訳
 * ・計算結果警告
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.mapper.rk.RK_DeleteWorkDataMapper
 */
public class RK_DeleteWorkDataDaoImpl implements RK_DeleteWorkDataDao {

  /**
   * ワークデータ削除マッパー(DI)
   */
  private RK_DeleteWorkDataMapper rkDeleteWorkDataMapper;

  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.dao.rk.RK_DeleteWorkDataDao#truncateCalcForUsage()
   */
  @Override
  public void truncateCalcForUsage() {
    rkDeleteWorkDataMapper.truncateCalcForUsage();
  }

  /*
   * (非 Javadoc)
   * @see jp.co.unisys.enability.cis.dao.rk.RK_DeleteWorkDataDao#truncateCalcForDateSlotByUsage()
   */
  @Override
  public void truncateCalcForDateSlotByUsage() {
    rkDeleteWorkDataMapper.truncateCalcForDateSlotByUsage();
  }

  /*
   * (非 Javadoc)
   * @see jp.co.unisys.enability.cis.dao.rk.RK_DeleteWorkDataDao#truncateCalcForTimeSlotByUsage()
   */
  @Override
  public void truncateCalcForTimeSlotByUsage() {
    rkDeleteWorkDataMapper.truncateCalcForTimeSlotByUsage();
  }

  /*
   * (非 Javadoc)
   * @see jp.co.unisys.enability.cis.dao.rk.RK_DeleteWorkDataDao#truncateCalcForFixIndicationNo()
   */
  @Override
  public void truncateCalcForFixIndicationNo() {
    rkDeleteWorkDataMapper.truncateCalcForFixIndicationNo();
  }

  /*
   * (非 Javadoc)
   * @see jp.co.unisys.enability.cis.dao.rk.RK_DeleteWorkDataDao#truncateCalculateResult()
   */
  @Override
  public void truncateCalculateResult() {
    rkDeleteWorkDataMapper.truncateCalculateResult();
  }

  /*
   * (非 Javadoc)
   * @see jp.co.unisys.enability.cis.dao.rk.RK_DeleteWorkDataDao#truncateCalcResultBreakdown()
   */
  @Override
  public void truncateCalcResultBreakdown() {
    rkDeleteWorkDataMapper.truncateCalcResultBreakdown();
  }

  /*
   * (非 Javadoc)
   * @see jp.co.unisys.enability.cis.dao.rk.RK_DeleteWorkDataDao#truncateCalcResultWarningData()
   */
  @Override
  public void truncateCalcResultWarningData() {
    rkDeleteWorkDataMapper.truncateCalcResultWarningData();
  }

  /**
   * ワークデータ削除マッパーのsetter（DI）。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * ワークデータ削除マッパーを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param rkDeleteWorkDataMapper
   *          ワークデータ削除マッパー
   */
  public void setRkDeleteWorkDataMapper(RK_DeleteWorkDataMapper rkDeleteWorkDataMapper) {
    this.rkDeleteWorkDataMapper = rkDeleteWorkDataMapper;
  }

}
