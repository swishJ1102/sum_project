package jp.co.unisys.enability.cis.dao;

import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.springframework.dao.DataAccessException;

import jp.co.unisys.enability.cis.entity.sn.SN900701_PrefecturalUsageTotalingEntityBean;
import jp.co.unisys.enability.cis.mapper.sn.SN900701_PrefecturalUsageTotalingMapper;

/**
 * 都道府県別の使用量集計へのインタフェース。
 *
 * <pre>
 * <p><b>【仕様詳細】</b></p>
 * 以下のインタフェースを提供する。
 * ・都道府県別の使用量集計の取得
 *
 * <p><b>対象テーブル：</b></p>
 * 　・【確定使用量】
 * 　・【設置場所_都道府県】
 * 　・【電圧区分マスタ】
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class SN900701_PrefecturalUsageTotalingDaoImpl implements SN900701_PrefecturalUsageTotalingDao {

  /** 都道府県別の使用量集計Mapper(DI) */
  private SN900701_PrefecturalUsageTotalingMapper prefecturalUsageTotalingMapper;

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.dao.rk.RK_FixUsageApplyDao#selectFixUsageApplyData
   * (java.util.Date)
   */
  @Override
  public List<SN900701_PrefecturalUsageTotalingEntityBean> selectPrefecturalUsageTotaling(
      Date executeDate) throws DataAccessException {
    HashMap<String, Object> exampleMap = new HashMap<String, Object>();
    exampleMap.put("executeDate", executeDate);
    return prefecturalUsageTotalingMapper.selectPrefecturalUsageTotaling(exampleMap);
  }

}
