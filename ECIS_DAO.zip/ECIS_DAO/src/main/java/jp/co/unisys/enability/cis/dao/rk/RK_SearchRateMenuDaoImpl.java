package jp.co.unisys.enability.cis.dao.rk;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;

import jp.co.unisys.enability.cis.entity.rk.RK_SearchRateMenuRateMenuConditionsEntityBean;
import jp.co.unisys.enability.cis.entity.rk.RK_SearchRateMenuSearchRateMenuAreaEntityBean;
import jp.co.unisys.enability.cis.entity.rk.RK_SearchRateMenuSupplementaryMenuConditionsEntityBean;
import jp.co.unisys.enability.cis.entity.rk.RK_SearchRateMenuSupplementaryMenuEntityBean;
import jp.co.unisys.enability.cis.mapper.rk.RK_SearchRateMenuMapper;

/**
 * 料金メニュー検索に関するデータアクセス。
 *
 * <pre>
 * <p><b>【仕様詳細】</b></p>
 * 以下のインタフェースを提供する。
 * ・料金メニューの取得
 * ・付帯メニューの取得
 *
 * <p><b>対象テーブル：</b></p>
 * 　・【エリアマスタ】
 * 　・【付帯メニュー】
 * 　・【付帯メニュー単価】
 * 　・【付帯対象区分マスタ】
 * 　・【付帯種別マスタ】
 * 　・【割引・割増区分マスタ】
 * 　・【売買区分マスタ】
 * 　・【契約種別マスタ】
 * 　・【提供モデル企業マスタ】
 * 　・【提供モデル企業別付帯メニューマスタ】
 * 　・【提供モデル企業別料金メニューマスタ】
 * 　・【料金メニュー】
 * 　・【料金メニュー単価】
 * 　・【料金メニュー単価明細】
 * 　・【電圧区分マスタ】
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.dao.rk.RK_SearchRateMenuDao
 */
public class RK_SearchRateMenuDaoImpl implements RK_SearchRateMenuDao {

  /** 料金メニュー検索マッパー(DI) **/
  private RK_SearchRateMenuMapper mapper;

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.dao.rk.RK_SearchRateMenuDao#selectRateMenu
   * (jp.co
   * .unisys.enability.cis.entity.rk.RK_SearchRateMenuRateMenuConditionsEntityBean
   * )
   */
  @Override
  public List<RK_SearchRateMenuSearchRateMenuAreaEntityBean> selectRateMenu(
      RK_SearchRateMenuRateMenuConditionsEntityBean rKSearchRateMenuRateMenuConditionsEntityBean)
      throws DataAccessException {

    // 条件Mapを作成
    Map<String, Object> exampleMap = new HashMap<String, Object>();

    // 条件Map.売買区分コード
    // ＝《料金メニュー検索条件EntityBean》.売買区分コード
    exampleMap.put("saleCategoryCode",
        rKSearchRateMenuRateMenuConditionsEntityBean
            .getSaleCategoryCode());

    // 条件Map.基準日_自
    // ＝《料金メニュー検索条件EntityBean》.基準日_自
    exampleMap
        .put("baseDateStart",
            rKSearchRateMenuRateMenuConditionsEntityBean
                .getBaseDateStart());

    // 条件Map.基準日_至
    // ＝《料金メニュー検索条件EntityBean》.基準日_至
    exampleMap.put("baseDateEnd",
        rKSearchRateMenuRateMenuConditionsEntityBean.getBaseDateEnd());

    // 条件Map.エリアコード
    // ＝《料金メニュー検索条件EntityBean》.エリアコード
    exampleMap.put("areaCode",
        rKSearchRateMenuRateMenuConditionsEntityBean.getAreaCode());

    // 条件Map.提供モデルコード
    // ＝《料金メニュー検索条件EntityBean》.提供モデルコード
    exampleMap.put("provideModelCode",
        rKSearchRateMenuRateMenuConditionsEntityBean
            .getProvideModelCode());

    // 条件Map.提供モデル企業コード
    // ＝《料金メニュー検索条件EntityBean》.提供モデル企業コード
    exampleMap.put("provideModelCompanyCode",
        rKSearchRateMenuRateMenuConditionsEntityBean
            .getProvideModelCompanyCode());

    // 条件Map.電圧区分コード
    // ＝《料金メニュー検索条件EntityBean》.電圧区分コード
    exampleMap.put("voltageCatCode",
        rKSearchRateMenuRateMenuConditionsEntityBean
            .getVoltageCatCode());

    // 条件Map.契約電力決定区分コード
    // ＝《料金メニュー検索条件EntityBean》.契約電力決定区分コード
    exampleMap.put("ccDecisionCategoryCode",
        rKSearchRateMenuRateMenuConditionsEntityBean
            .getCcDecisionCategoryCode());

    // 検索条件と一致する料金メニューを取得
    return mapper.selectRateMenu(exampleMap);
  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.dao.rk.RK_SearchRateMenuDao#
   * selectSupplementaryMenu(jp.co.unisys.enability.cis.entity.rk.
   * RK_SearchRateMenuSupplementaryMenuConditionsEntityBean)
   */
  @Override
  public List<RK_SearchRateMenuSupplementaryMenuEntityBean> selectSupplementaryMenu(
      RK_SearchRateMenuSupplementaryMenuConditionsEntityBean rKSearchRateMenuSupplementaryMenuConditionsEntityBean)
      throws DataAccessException {

    // 条件Mapを作成
    Map<String, Object> exampleMap = new HashMap<String, Object>();

    // 条件Map.売買区分コード
    // ＝《付帯メニュー検索条件EntityBean》.売買区分コード
    exampleMap.put("saleCategoryCode",
        rKSearchRateMenuSupplementaryMenuConditionsEntityBean
            .getSaleCategoryCode());

    // 条件Map.基準日_自
    // ＝《付帯メニュー検索条件EntityBean》.基準日_自
    exampleMap.put("baseDateStart",
        rKSearchRateMenuSupplementaryMenuConditionsEntityBean
            .getBaseDateStart());

    // 条件Map.基準日_至
    // ＝《付帯メニュー検索条件EntityBean》.基準日_至
    exampleMap.put("baseDateEnd",
        rKSearchRateMenuSupplementaryMenuConditionsEntityBean
            .getBaseDateEnd());

    // 条件Map.提供モデルコード
    // ＝《付帯メニュー検索条件EntityBean》.提供モデルコード
    exampleMap.put("provideModelCode",
        rKSearchRateMenuSupplementaryMenuConditionsEntityBean
            .getProvideModelCode());

    // 条件Map.提供モデル企業コード
    // ＝《付帯メニュー検索条件EntityBean》.提供モデル企業コード
    exampleMap.put("provideModelCompanyCode",
        rKSearchRateMenuSupplementaryMenuConditionsEntityBean
            .getProvideModelCompanyCode());

    return mapper.selectSupplementaryMenu(exampleMap);
  }

  /**
   * 料金メニュー検索マッパーのsetter（DI）。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金メニュー検索マッパーを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param searchRateMenuMapper
   *          料金メニュー検索マッパー
   */
  public void setRKSearchRateMenuMapper(RK_SearchRateMenuMapper searchRateMenuMapper) {
    this.mapper = searchRateMenuMapper;
  }
}
