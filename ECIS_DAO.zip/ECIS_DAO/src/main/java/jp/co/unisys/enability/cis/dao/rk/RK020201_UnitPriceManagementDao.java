package jp.co.unisys.enability.cis.dao.rk;

import java.util.Date;
import java.util.List;

import org.springframework.dao.DataAccessException;

import jp.co.unisys.enability.cis.entity.common.AreaM;
import jp.co.unisys.enability.cis.entity.common.Rm;
import jp.co.unisys.enability.cis.entity.common.VoltageCatM;
import jp.co.unisys.enability.cis.entity.rk.RK020201_ConsignmentRateMenuSelectBoxEntityBean;
import jp.co.unisys.enability.cis.entity.rk.RK020201_RateMenuSelectBoxEntityBean;

/**
 * 料金単価に関するデータアクセス層へのインタフェースを ビジネスロジック層に提供するクラス。
 *
 * <pre>
 * <p><b>【仕様詳細】</b></p>
 * 以下のインタフェースをサービス層に提供する。
 * ・料金メニューID、単価適用開始日、単価適用終了日を指定して確定料金実績より料金算定開始日を取得
 * ・エリアコード、単価適用開始日、単価適用終了日を指定して確定実績より料金算定開始日を取得
 * ・託送メニューID、単価適用開始日、単価適用終了日を指定して確定料金実績より料金算定開始日を取得
 * ・料金メニューセレクトボックスに出力するデータを取得
 * ・燃調セレクトボックスに出力するデータを取得
 * ・再エネセレクトボックスに出力するデータを取得
 * ・託送メニューセレクトボックスに出力するデータを取得
 * ・予備契約単価セレクトボックスに出力するデータを取得
 *
 * <p><b>対象テーブル：</b></p>
 * 　・FCR
 * 　・RM
 * 　・RM_M_BY_PM_COMPANY
 * 　・AREA_M
 * 　・PM_M
 * 　・PM_COMPANY_M
 * 　・FCA_UP_M
 * 　・REC_UP_M
 * 　・RC_UP_M
 * 　・CR
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public interface RK020201_UnitPriceManagementDao {

  /**
   * 料金メニューID、単価適用開始日、単価適用終了日を指定して確定料金実績より最新の料金算定開始日を取得する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された条件で確定料金実績より、最新の料金算定開始日を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param rateMenuId
   *          料金メニューID
   * @param upApplySd
   *          単価適用開始日
   * @param upApplyEd
   *          単価適用終了日
   * @return 料単価適用期間内の料金算定開始日
   * @throws DataAccessException
   *           予期せぬエラーが発生した場合
   *
   */
  Date selectFixChargeResultCalculationStartDateMax(String rateMenuId, Date upApplySd, Date upApplyEd)
      throws DataAccessException;

  /**
   * エリアコード、単価適用開始日、単価適用終了日を指定して確定料金実績より最新の料金算定開始日を取得する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された条件で確定料金実績より、最新の料金算定開始日を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param areaCd
   *          エリアコード
   * @param upApplySd
   *          単価適用開始日
   * @param upApplyEd
   *          単価適用終了日
   * @return 料金算定開始日の最大値
   * @throws DataAccessException
   *           予期せぬエラーが発生した場合
   *
   */
  Date selectFixChargeResultCalculationStartDateMaxByAreaCode(String areaCd, Date upApplySd, Date upApplyEd)
      throws DataAccessException;

  /**
   * 託送メニューID、単価適用開始日、単価適用終了日を指定して確定料金実績より最新の料金算定開始日を取得する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された条件で確定料金実績より、最新の料金算定開始日を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param consignmentMenuId
   *          託送メニューID
   * @param upApplySd
   *          単価適用開始日
   * @param upApplyEd
   *          単価適用終了日
   * @return 料金算定開始日の最大値
   * @throws DataAccessException
   *           予期せぬエラーが発生した場合
   *
   */
  Date selectFixResultCalculationStartDateMaxByConsignmentMenuId(
      String consignmentMenuId, Date upApplySd, Date upApplyEd) throws DataAccessException;

  /**
   * 料金メニュー単価用セレクトボックスデータを取得する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金メニューセレクトボックスに出力するデータを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 《料金単価設定料金メニューセレクトボックスEntityBean》リスト
   * @throws DataAccessException
   *           予期せぬエラーが発生した場合
   *
   */
  List<RK020201_RateMenuSelectBoxEntityBean> selectRateMenuSelectBoxData()
      throws DataAccessException;

  /**
   * 燃調単価用セレクトボックスデータを取得する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 燃調セレクトボックスに出力するデータを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 《エリアマスタEntityBean》リスト
   * @throws DataAccessException
   *           予期せぬエラーが発生した場合
   *
   */
  List<AreaM> selectFuelCostAdjustSelectBoxData() throws DataAccessException;

  /**
   * 燃調単価用電圧区分セレクトボックスデータを取得する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 燃調単価用電圧区分セレクトボックスに出力するデータを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 《電圧区分マスタEntityBean》リスト
   * @throws DataAccessException
   *           予期せぬエラーが発生した場合
   *
   */
  List<VoltageCatM> selectVoltageCategorySelectBoxData() throws DataAccessException;

  /**
   * 再エネ単価用セレクトボックスデータを取得する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 再エネセレクトボックスに出力するデータを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 《エリアマスタEntityBean》リスト
   * @throws DataAccessException
   *           予期せぬエラーが発生した場合
   *
   */
  List<AreaM> selectRenewableEnergySelectBoxData() throws DataAccessException;

  /**
   * 託送メニュー単価用セレクトボックスデータを取得する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 託送メニューセレクトボックスに出力するデータを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 《料金単価設定託送メニューセレクトボックスEntityBean》リスト
   * @throws DataAccessException
   *           予期せぬエラーが発生した場合
   *
   */
  List<RK020201_ConsignmentRateMenuSelectBoxEntityBean> selectConsignmentRateMenuSelectBoxData()
      throws DataAccessException;

  /**
   * 予備契約単価セレクトボックスデータを取得する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 予備契約単価セレクトボックスに出力するデータを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 《料金単価設定料金メニューセレクトボックスEntityBean》リスト
   * @throws DataAccessException
   *           予期せぬエラーが発生した場合
   *
   */
  List<RK020201_RateMenuSelectBoxEntityBean> selectReserveContractSelectBoxData() throws DataAccessException;

  /**
   * 予備契約単価（料金メニュー）セレクトボックスデータを取得する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 予備契約単価（料金メニュー）セレクトボックスに出力するデータを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @return 《料金メニューEntityBean》リスト
   * @throws DataAccessException
   *           予期せぬエラーが発生した場合
   *
   */
  List<Rm> selectReserveContractRateMenuSelectBoxData() throws DataAccessException;

  /**
   * エリアコード、適用年月を指定して最大利用年月を取得する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された条件で確定料金実績より、最大利用年月を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param areaCode
   *          エリアコード
   * @param usePeriod
   *          適用年月
   * @return 最大利用年月
   * @throws DataAccessException
   *           予期せぬエラーが発生した場合
   *
   */
  String selectMaxFcrUsePeriodByAreaCode(String areaCode, String usePeriod)
      throws DataAccessException;

}
