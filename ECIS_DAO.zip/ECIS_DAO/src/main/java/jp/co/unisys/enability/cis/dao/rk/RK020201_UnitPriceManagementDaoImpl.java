package jp.co.unisys.enability.cis.dao.rk;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;

import jp.co.unisys.enability.cis.entity.common.AreaM;
import jp.co.unisys.enability.cis.entity.common.Rm;
import jp.co.unisys.enability.cis.entity.common.VoltageCatM;
import jp.co.unisys.enability.cis.entity.rk.RK020201_ConsignmentRateMenuSelectBoxEntityBean;
import jp.co.unisys.enability.cis.entity.rk.RK020201_RateMenuSelectBoxEntityBean;
import jp.co.unisys.enability.cis.mapper.rk.RK020201_UnitPriceManagementMapper;

/**
 * 料金単価に関するデータアクセス。
 * 
 * <pre>
 * <p><b>【仕様詳細】</b></p>
 * 以下のインタフェースをサービス層に提供する。
 * ・料金メニューID、単価適用開始日、単価適用終了日を指定して確定料金実績より料金算定開始日を取得
 * ・エリアコード、単価適用開始日、単価適用終了日を指定して確定実績より料金算定開始日を取得
 * ・託送メニューID、単価適用開始日、単価適用終了日を指定して確定料金実績より料金算定開始日を取得
 * ・料金メニューセレクトボックスに出力するデータを取得
 * ・燃調セレクトボックスに出力するデータを取得
 * ・再エネセレクトボックスに出力するデータを取得
 * ・託送メニューセレクトボックスに出力するデータを取得
 * ・予備契約単価セレクトボックスに出力するデータを取得
 *
 * <p><b>対象テーブル：</b></p>
 * 　・FCR
 * 　・RM
 * 　・RM_M_BY_PM_COMPANY
 * 　・AREA_M
 * 　・PM_M
 * 　・PM_COMPANY_M
 * 　・FCA_UP_M
 * 　・REC_UP_M
 * 　・RC_UP_M
 * 　・CR
 * </pre>
 * 
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.dao.rk.RK020201_UnitPriceManagementDao
 */
public class RK020201_UnitPriceManagementDaoImpl implements
    RK020201_UnitPriceManagementDao {

  /** Mapper(DI) */
  private RK020201_UnitPriceManagementMapper mapper;

  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.dao.rk.RK020201_UnitPriceManagementDao#selectFixChargeResultCalculationStartDateMax(java.lang.String)
   */
  @Override
  public Date selectFixChargeResultCalculationStartDateMax(
      String rateMenuId, Date upApplySd, Date upApplyEd) throws DataAccessException {

    Map<String, Object> map = new HashMap<String, Object>();
    map.put("rateMenuId", rateMenuId);
    map.put("upApplySd", upApplySd);
    map.put("upApplyEd", upApplyEd);

    Date ret = mapper.selectFixChargeResultCalculationStartDateMax(map);

    return ret;
  }

  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.dao.rk.RK020201_UnitPriceManagementDao#selectFixChargeResultCalculationStartDateMaxByAreaCode(java.lang.String)
   */
  @Override
  public Date selectFixChargeResultCalculationStartDateMaxByAreaCode(
      String areaCd, Date upApplySd, Date upApplyEd) throws DataAccessException {

    Map<String, Object> map = new HashMap<String, Object>();
    map.put("areaCode", areaCd);
    map.put("upApplySd", upApplySd);
    map.put("upApplyEd", upApplyEd);

    return mapper.selectFixChargeResultCalculationStartDateMaxByAreaCode(map);
  }

  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.dao.rk.RK020201_UnitPriceManagementDao#selectFixResultCalculationStartDateMaxByConsignmentMenuId(java.lang.String)
   */
  @Override
  public Date selectFixResultCalculationStartDateMaxByConsignmentMenuId(
      String consignmentMenuId, Date upApplySd, Date upApplyEd) throws DataAccessException {

    Map<String, Object> map = new HashMap<String, Object>();
    map.put("consignmentMenuId", consignmentMenuId);
    map.put("upApplySd", upApplySd);
    map.put("upApplyEd", upApplyEd);

    return mapper.selectFixResultCalculationStartDateMaxByConsignmentMenuId(map);
  }

  @Override
  public List<RK020201_RateMenuSelectBoxEntityBean> selectRateMenuSelectBoxData()
      throws DataAccessException {

    return mapper.selectRateMenuSelectBoxData();
  }

  @Override
  public List<AreaM> selectFuelCostAdjustSelectBoxData()
      throws DataAccessException {

    return mapper.selectFuelCostAdjustSelectBoxData();
  }

  @Override
  public List<VoltageCatM> selectVoltageCategorySelectBoxData()
      throws DataAccessException {

    return mapper.selectVoltageCategorySelectBoxData();
  }

  @Override
  public List<AreaM> selectRenewableEnergySelectBoxData()
      throws DataAccessException {

    return mapper.selectRenewableEnergySelectBoxData();
  }

  @Override
  public List<RK020201_ConsignmentRateMenuSelectBoxEntityBean> selectConsignmentRateMenuSelectBoxData()
      throws DataAccessException {

    return mapper.selectConsignmentRateMenuSelectBoxData();
  }

  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.dao.rk.RK020201_UnitPriceManagementDao#selectMaxFcrUsePeriodByAreaCode(java.lang.String)
   */
  @Override
  public String selectMaxFcrUsePeriodByAreaCode(String areaCode,
      String usePeriod) throws DataAccessException {

    Map<String, Object> map = new HashMap<String, Object>();
    map.put("areaCode", areaCode);
    map.put("usePeriod", usePeriod);

    return mapper.selectMaxFcrUsePeriodByAreaCode(map);
  }

  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.dao.rk.RK020201_UnitPriceManagementDao#selectReserveContractSelectBoxData()
   */
  @Override
  public List<RK020201_RateMenuSelectBoxEntityBean> selectReserveContractSelectBoxData() throws DataAccessException {

    return mapper.selectReserveContractSelectBoxData();
  }

  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.dao.rk.RK020201_UnitPriceManagementDao#selectReserveContractSelectBoxData()
   */
  @Override
  public List<Rm> selectReserveContractRateMenuSelectBoxData() throws DataAccessException {

    return mapper.selectReserveContractRateMenuSelectBoxData();
  }

  /**
   * mapperを設定します。(DI)
   *
   * @param mapper
   *          mapper
   */
  public void setMapper(RK020201_UnitPriceManagementMapper mapper) {
    this.mapper = mapper;
  }
}
