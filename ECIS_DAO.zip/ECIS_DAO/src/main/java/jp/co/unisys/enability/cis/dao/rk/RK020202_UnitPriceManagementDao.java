package jp.co.unisys.enability.cis.dao.rk;

import java.util.Date;

import org.springframework.dao.DataAccessException;

/**
 * 付帯単価に関するデータアクセス層へのインタフェースをビジネスロジック層に提供するクラス。
 *
 * <pre>
 * <p><b>【仕様詳細】</b></p>
 * 以下のインタフェースを提供する。
 * ・料金算定開始日の最大値を取得
 *
 * <p><b>対象テーブル：</b></p>
 * 　・FCR
 * 　・FCR_BREAKDOWN
 * 　・SPL_CONTRACT
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public interface RK020202_UnitPriceManagementDao {

  /**
   * 付帯メニューID、単価適用開始日、単価適用終了日を指定して確定料金実績より、料金算定開始日の最大値を取得する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された条件で確定料金実績より、料金算定開始日の最大値を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param supplementaryMenuId
   *          付帯メニューID
   * @param upApplySd
   *          単価適用開始日
   * @param upApplyEd
   *          単価適用終了日
   * @return 料金算定開始日の最大値
   * @throws DataAccessException
   *           予期せぬエラーが発生した場合
   *
   */
  Date selectFixChargeResultCalculationStartDateMaxBySupplementaryMenuId(
      String conditionSupplementaryMenuId, Date upApplySd, Date upApplyEd) throws DataAccessException;

}
