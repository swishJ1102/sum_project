/*-------------------------------------------------------------------------------
 * All Rights Reserved. Copyright(C) Nihon Unisys, Ltd.
 * vendor : Nihon Unisys, Ltd.
 * since : 2014/09/01
 *-----------------------------------------------------------------------------*/
package jp.co.unisys.enability.cis.dao.gk;

import java.util.HashMap;
import java.util.Map;

import org.springframework.dao.DataAccessException;

import jp.co.unisys.enability.cis.entity.common.UserManagementWithBLOBs;
import jp.co.unisys.enability.cis.mapper.common.UserManagementMapper;

/**
 * ユーザ管理DAO.<br>
 * ユーザ管理に対するデータアクセスを実装したクラス
 *
 */
public class UserManagementDaoImpl implements UserManagementDao {

  /** ユーザ管理マッパー */
  private UserManagementMapper userManagementMapper;

  /**
   * userManagementMapperのセッター
   *
   * @param userManagementMapper
   *          セットする userManagementMapper
   */
  public void setUserManagementMapper(
      UserManagementMapper userManagementMapper) {
    this.userManagementMapper = userManagementMapper;
  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.dao.gk.UserManagementDao#selectUser(java.lang
   * .String)
   */
  @Override
  public UserManagementWithBLOBs selectUser(String userId)
      throws DataAccessException {
    return userManagementMapper.selectByPrimaryKeyWithCrypt(userId);
  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.dao.gk.UserManagementDao#
   * updateByPrimaryKeySelective(jp.co.
   * unisys.enability.cis.entity.common.UserManagementWithBLOBs)
   */
  @Override
  public int updateByPrimaryKeySelective(UserManagementWithBLOBs record)
      throws DataAccessException {
    return userManagementMapper.updateByPrimaryKeySelective(record);
  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.dao.gk.UserManagementDao#selectPasswordUpdate
   * (java.lang.String)
   */
  @Override
  public UserManagementWithBLOBs selectPasswordUpdate(String userId)
      throws DataAccessException {
    return userManagementMapper.selectByPrimaryKey(userId);
  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.dao.gk.UserManagementDao#selectPasswordHistory
   * (java.lang.String )
   */
  @Override
  public UserManagementWithBLOBs selectChangeCondition(String userId)
      throws DataAccessException {
    return userManagementMapper.selectChangeCondition(userId);
  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.dao.gk.UserManagementDao#updatePassword(java
   * .lang.String, java.lang.String, java.lang.String, java.lang.String,
   * java.lang.String)
   */
  @Override
  public String updatePassword(String password, String userId,
      Short initialFlg, String updateModuleCode, String updateUserId,
      String updateTimeKey) throws DataAccessException {
    Map<String, String> map = new HashMap<String, String>();
    map.put("userPassword", password);
    map.put("userId", userId);
    map.put("passwordInitializationFlag", initialFlg.toString());
    map.put("updateModulecode", updateModuleCode);
    map.put("updateUserId", updateUserId);
    map.put("updateTimeKey", updateTimeKey);
    return userManagementMapper.updatePassword(map);
  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.dao.gk.UserManagementDao#selectCallCollation
   * (java.lang.String, java.lang.String)
   */
  @Override
  public String selectCallCollation(String password,
      String userId) throws DataAccessException {
    Map<String, String> map = new HashMap<String, String>();
    map.put("userPassword", password);
    map.put("userId", userId);
    return userManagementMapper.selectCallCollation(map);
  }

}
