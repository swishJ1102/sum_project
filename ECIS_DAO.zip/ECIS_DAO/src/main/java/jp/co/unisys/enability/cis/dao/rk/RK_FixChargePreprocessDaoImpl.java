package jp.co.unisys.enability.cis.dao.rk;

import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;

import org.springframework.dao.DataAccessException;

import jp.co.unisys.enability.cis.mapper.rk.RK_FixChargePreprocessMapper;

/**
 * 確定使用量前処理に関するデータアクセス層へのインタフェース。
 *
 * <pre>
 * <p><b>【仕様詳細】</b></p>
 * 以下のインタフェースを提供する。
 * ・関西エリア検針日補正
 * ・検針日補正
 *
 * <p><b>対象テーブル：</b></p>
 * 　・【月次実績】
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_FixChargePreprocessDaoImpl implements RK_FixChargePreprocessDao {

  /** 確定使用量前処理Mapper(DI) */
  private RK_FixChargePreprocessMapper rkFixChargePreprocessMapper;

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.dao.rk.RK_FixChargePreprocessMapper#
   * updateMeterReadingDate(java.util.Date)
   */
  @Override
  public int updateMeterReadingDateForKansai(Date executeDate,
      Timestamp updateTime, String updateModuleCode)
      throws DataAccessException {
    HashMap<String, Object> exampleMap = new HashMap<String, Object>();
    exampleMap.put("executeDate", executeDate);
    exampleMap.put("updateTime", updateTime);
    exampleMap.put("updateModuleCode", updateModuleCode);
    return rkFixChargePreprocessMapper
        .updateMeterReadingDateForKansai(exampleMap);
  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.dao.rk.RK_FixChargePreprocessMapper#
   * updateMeterReadingDate(java.util.Date)
   */
  @Override
  public int updateMeterReadingDate(Date executeDate, String[] updateMeterReadingDateArea,
      Timestamp updateTime, String updateModuleCode)
      throws DataAccessException {
    HashMap<String, Object> exampleMap = new HashMap<String, Object>();
    exampleMap.put("executeDate", executeDate);
    if (updateMeterReadingDateArea.length != 0) {
      exampleMap.put("updateMeterReadingDateArea", updateMeterReadingDateArea);
    }
    exampleMap.put("updateTime", updateTime);
    exampleMap.put("updateModuleCode", updateModuleCode);
    return rkFixChargePreprocessMapper
        .updateMeterReadingDate(exampleMap);
  }

  /**
   * 確定使用量前処理Mapperを設定します。(DI)
   *
   * @param rkFixChargePreprocessMapper
   *          確定使用量前処理Mapper(DI)
   */
  public void setRkFixChargePreprocessMapper(
      RK_FixChargePreprocessMapper rkFixChargePreprocessMapper) {
    this.rkFixChargePreprocessMapper = rkFixChargePreprocessMapper;
  }

}
