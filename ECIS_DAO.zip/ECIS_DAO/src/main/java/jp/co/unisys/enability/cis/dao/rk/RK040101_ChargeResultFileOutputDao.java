package jp.co.unisys.enability.cis.dao.rk;

import java.util.Map;

import jp.co.unisys.enability.cis.entity.rk.RK040101_SearchFixChargeResultInfoEntityBean;

import org.apache.ibatis.cursor.Cursor;
import org.springframework.dao.DataAccessException;

/**
 * 料金実績情報ダウンロード に関するデータアクセス層へのインタフェースをビジネスロジック層に提供するクラス
 *
 * <pre>
 * <p><b>【仕様詳細】</b></p>
 * 以下のインタフェースを提供する。
 * ・確定料金実績情報の取得
 * ・確定料金実績内訳の取得
 *
 * <p><b>対象テーブル：</b></p>
 * 　・FCR
 * 　・CONTRACT
 * 　・ML
 * 　・PLACE
 * 　・FCR_BREAKDOWN
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public interface RK040101_ChargeResultFileOutputDao {

  /**
   * 確定料金実績の件数を取得する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された条件で確定料金実績の件数を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param searchFixChargeResultInfoEntityBean
   *          料金実績情報ダウンロード確定料金実績情報検索EntityBean
   * @return 確定料金実績件数
   * @throws DataAccessException
   *           予期せぬエラーが発生した場合
   */
  Integer selectFixChargeResultCount(
      RK040101_SearchFixChargeResultInfoEntityBean searchFixChargeResultInfoEntityBean)
      throws DataAccessException;

  /**
   * 確定料金実績情報を取得する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された条件で確定料金実績、契約、需要場所を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param searchFixChargeResultInfoEntityBean
   *          料金実績情報ダウンロード確定料金実績情報検索EntityBean
   * @return 確定料金実績情報Map
   * @throws DataAccessException
   *           予期せぬエラーが発生した場合
   */
  Cursor<Map<String, Object>> selectFixChargeResultInfo(
      RK040101_SearchFixChargeResultInfoEntityBean searchFixChargeResultInfoEntityBean)
      throws DataAccessException;

  /**
   * 確定料金実績内訳を取得する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された条件で確定料金実績内訳を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param searchFixChargeResultInfoEntityBean
   *          料金実績情報ダウンロード確定料金実績情報検索EntityBean
   * @return 確定料金実績内訳Map
   * @throws DataAccessException
   *           予期せぬエラーが発生した場合
   */
  Cursor<Map<String, Object>> selectFixChargeResultBreakdown(
      RK040101_SearchFixChargeResultInfoEntityBean searchFixChargeResultInfoEntityBean)
      throws DataAccessException;

  /**
   * 実量歴内訳情報を取得する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された条件で実量歴内訳を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param searchFixChargeResultInfoEntityBean
   *          料金実績情報ダウンロード確定料金実績情報検索EntityBean
   * @return 実量歴内訳Map
   * @throws DataAccessException
   *           予期せぬエラーが発生した場合
   */
  Cursor<Map<String, Object>> selectRealQuantityHistory(
      RK040101_SearchFixChargeResultInfoEntityBean searchFixChargeResultInfoEntityBean)
      throws DataAccessException;

  /**
   * 確定指示数を取得する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された条件で確定指示数を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param searchFixChargeResultInfoEntityBean
   *          料金実績情報ダウンロード確定料金実績情報検索EntityBean
   * @return 確定指示数Map
   * @throws DataAccessException
   *           予期せぬエラーが発生した場合
   */
  Cursor<Map<String, Object>> selectFixIn(
      RK040101_SearchFixChargeResultInfoEntityBean searchFixChargeResultInfoEntityBean)
      throws DataAccessException;

}
