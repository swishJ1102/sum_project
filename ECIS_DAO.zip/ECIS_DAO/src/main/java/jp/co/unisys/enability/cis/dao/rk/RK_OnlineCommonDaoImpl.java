package jp.co.unisys.enability.cis.dao.rk;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.springframework.dao.DataAccessException;

import jp.co.unisys.enability.cis.entity.common.Spm;
import jp.co.unisys.enability.cis.entity.common.TsUsage;
import jp.co.unisys.enability.cis.entity.common.WarningClassM;
import jp.co.unisys.enability.cis.mapper.rk.RK_OnlineCommonMapper;

/**
 * 料金計算オンライン共通ビジネスに関するデータアクセス層へのインタフェースを ビジネスロジック層に提供するクラス。
 *
 * <pre>
 * <p><b>【仕様詳細】</b></p>
 * 以下のインタフェースを提供する。
 * ・付帯メニューの取得
 * ・警告種別の取得
 *
 * <p><b>対象テーブル：</b></p>
 * 　・SUPPLEMENTARY_CONTRACT
 * 　・WARNING_CLASS_MASTER
 * 　・TIME_SLOT_USAGE
 * 　・RATE_MENU_TIME_SLOT
 * </pre>
 * 
 * @author "Nihon Unisys, Ltd."
 */
public class RK_OnlineCommonDaoImpl implements RK_OnlineCommonDao {

  /** 料金計算オンライン共通マッパー(DI) **/
  private RK_OnlineCommonMapper mapper;

  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.dao.rk.RK_OnlineCommonDao#selectSupplementaryMenu(java.util.List)
   */
  @Override
  public List<Spm> selectSupplementaryMenu(
      @Param("supplementaryMenuIdList") List<Integer> supplementaryMenuIdList) throws DataAccessException {
    return mapper.selectSupplementaryMenu(supplementaryMenuIdList);
  }

  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.dao.rk.RK_OnlineCommonDao#selectWarningClass(java.util.List)
   */
  @Override
  public List<WarningClassM> selectWarningClass(
      @Param("warningClassCodeList") List<String> warningClassCodeList) throws DataAccessException {
    return mapper.selectWarningClass(warningClassCodeList);
  }

  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.dao.rk.RK_OnlineCommonDao#selectTimeSlotUsage(java.lang.String, java.lang.String)
   */
  @Override
  public List<TsUsage> selectTimeSlotUsage(Integer fixUsageId,
      String rateMenuId) throws DataAccessException {
    Map<String, Object> map = new HashMap<String, Object>();
    map.put("fixusageid", fixUsageId);
    map.put("ratemenuid", rateMenuId);
    return mapper.selectTimeSlotUsage(map);
  }

  /**
   * mapperのセッター(DI)
   * 
   * @param mapper
   *          セットするRKOnlineCommonMapper
   */
  public void setRK_OnlineCommonMapper(RK_OnlineCommonMapper mapper) {
    this.mapper = mapper;
  }

}
