package jp.co.unisys.enability.cis.dao.rk;

import java.util.Date;
import java.util.List;

import org.springframework.dao.DataAccessException;

import jp.co.unisys.enability.cis.entity.rk.RK_UsageLinkageCheckCheckDataEntityBean;
import jp.co.unisys.enability.cis.entity.rk.RK_UsageLinkageCheckEndFixUsageNotLinkedEntityBean;
import jp.co.unisys.enability.cis.entity.rk.RK_UsageLinkageCheckLatestContractEntityBean;
import jp.co.unisys.enability.cis.entity.rk.RK_UsageLinkageCheckTermDecisionEntityBean;

/**
 * 使用量連携チェックに関するデータアクセス層へのインタフェース。
 *
 * <pre>
 * <p><b>【仕様詳細】</b></p>
 * 以下のインタフェースをサービス層に提供する。
 * 　・連携チェック対象データの取得
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public interface RK_UsageLinkageCheckDao {

  /**
   * 使用量連携チェックを行うためのデータを取得する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * バッチ実行日に取り込まれた確定使用量メッセージから、
   * 地点特定番号毎に使用量連携チェックを行うためのデータを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param executeDate
   *          バッチ実行日
   * @return チェック用データのリスト
   * @throws DataAccessException
   *           DBエラーが発生した場合
   */
  List<RK_UsageLinkageCheckCheckDataEntityBean> selectCheckData(
      Date executeDate) throws DataAccessException;

  /**
   * 契約期間に関わるチェックを行うためのデータを取得する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された確定使用量メッセージに紐づく契約の契約期間に対して、
   * 使用量の対象期間等の相関チェックを行うためのデータを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param spotNo
   *          地点特定番号
   * @param fixUsageFileName
   *          確定使用量ファイル名
   * @param areaCode
   *          エリアコード
   * @param abolitionFlag
   *          廃止判定フラグ
   * @return 期間判定データのリスト
   * @throws DataAccessException
   *           DBエラーが発生した場合
   */
  List<RK_UsageLinkageCheckTermDecisionEntityBean> selectTermDecision(
      String spotNo, String fixUsageFileName, String areaCode, String abolitionFlag)
      throws DataAccessException;

  /**
   * 最新の契約情報を取得する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された地点特定番号に紐づく契約の中で、最も新しい契約を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param spotNo
   *          地点特定番号
   * @return 最新契約情報データ
   * @throws DataAccessException
   *           DBエラーが発生した場合
   */
  RK_UsageLinkageCheckLatestContractEntityBean selectLatestContract(
      String spotNo) throws DataAccessException;

  /**
   * 判定日より前に契約期間が終了していて、契約終了分確定使用量連携済フラグが“OFF”の契約情報を取得する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された地点特定番号に紐づく契約の中で、契約終了日が判定日よりも前の日付で、
   * 契約終了分確定使用量連携済フラグが“OFF”の契約情報を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param spotNo
   *          地点特定番号
   * @param decisinoDate
   *          判定日
   * @return 終了分未連携契約情報のリスト
   * @throws DataAccessException
   *           DBエラーが発生した場合
   */
  List<RK_UsageLinkageCheckEndFixUsageNotLinkedEntityBean> selectEndFixUsageNotLinked(
      String spotNo, Date decisionDate) throws DataAccessException;

  /**
   * 指定された検針日より以前の使用終了日を取得する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された検針日より以前の月次実績検針日を確定使用量より検索し
   * 最大の使用終了日を取得する
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param contractNo
   *          契約番号
   * @param mrDate
   *          検針日
   * @return 最大の使用終了日
   * @throws DataAccessException
   *           DBエラーが発生した場合
   */
  Date selectLastTimeUsageEd(String contractNo, Date mrDate);
}
