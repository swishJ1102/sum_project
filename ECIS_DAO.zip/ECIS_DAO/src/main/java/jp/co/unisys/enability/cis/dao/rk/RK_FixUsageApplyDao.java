package jp.co.unisys.enability.cis.dao.rk;

import java.util.Date;
import java.util.List;

import org.springframework.dao.DataAccessException;

import jp.co.unisys.enability.cis.entity.rk.RK_FixUsageApplyDataEntityBean;
import jp.co.unisys.enability.cis.entity.rk.RK_FixUsageApplyRateMenuTimeSlotEntityBean;

/**
 * 確定使用量情報反映 に関するデータアクセス層へのインタフェースをビジネスロジック層に提供するクラス。
 *
 * <pre>
 * <p><b>【仕様詳細】</b></p>
 * 以下のインタフェースをサービス層に提供する。
 * 　・確定使用量メッセージの取り込みに関するデータの取得
 * 　・対象の確定使用量メッセージから、確定使用量対象日ごとの確定電力量を取得
 *
 * <p><b>対象テーブル：</b></p>
 * 　・USAGE_QUANTITYCOVERED_VALUETERM
 * 　・MONTHLY_USAGE_RESULT
 * 　・DEMAND_RESULT
 * 　・METER_LOCATION
 * 　・ML_CONTRACT_HISTORY
 * 　・CONTRACT
 * 　・CONTRACT_HISTORY
 * 　・RATE_MENU_TIME_SLOT
 * 　・RATE_MENU_TIME_SLOT_DETAIL
 * 　・TIME_SLOT_MASTER
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public interface RK_FixUsageApplyDao {

  /**
   * 確定使用量メッセージの取り込みを行うための情報を取得する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * バッチ実行日に取り込まれた確定使用量メッセージから、
   * 地点特定番号毎に取り込みを行うための情報を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param executeDate
   *          バッチ実行日
   * @return 取り込み用データのリスト
   * @throws DataAccessException
   *           DBエラーが発生した場合
   */
  public abstract List<RK_FixUsageApplyDataEntityBean> selectFixUsageApplyData(
      Date executeDate) throws DataAccessException;

  /**
   * 料金メニューに紐づく時間帯の情報を取得する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 対象の料金メニューから、使用量を時間帯ごとに仕訳るための情報を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param rateMenuId
   *          料金メニューID
   * @return 取り込み用データのリスト
   * @throws DataAccessException
   *           DBエラーが発生した場合
   */
  public abstract List<RK_FixUsageApplyRateMenuTimeSlotEntityBean> selectRateMenuTimeSlot(
      String rateMenuId) throws DataAccessException;
}
