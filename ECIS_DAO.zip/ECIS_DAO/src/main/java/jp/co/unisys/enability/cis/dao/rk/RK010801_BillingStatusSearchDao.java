package jp.co.unisys.enability.cis.dao.rk;

import java.util.List;

import org.apache.ibatis.cursor.Cursor;
import org.springframework.dao.DataAccessException;

import jp.co.unisys.enability.cis.entity.rk.RK010801_BillingStatusEntityBean;
import jp.co.unisys.enability.cis.entity.rk.RK010801_BillingStatusOutputEntityBean;
import jp.co.unisys.enability.cis.entity.rk.RK010801_SearchBillingStatusInfoEntityBean;

/**
 * 料金計算請求状況に関する データアクセス層へのインタフェースをビジネスロジック層に提供するクラス
 *
 * <pre>
 * <p><b>【仕様詳細】</b></p>
 * 以下のインタフェースを提供する。
 * ・料金計算請求状況関連情報取得
 *
 * <p><b>対象テーブル：</b></p>
 * 　・CONTRACT
 * 　・CONTRACT_ADD_INFO
 * 　・CONTRACT_HIST
 * 　・ML
 * 　・ML_CONTRACT_HIST
 * 　・TRANSMISSION_CAT_M
 * 　・MR_CALENDAR_M
 * 　・FCR
 * 　・FIX_CHARGE_BL_LINKAGE
 * 　・BL
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public interface RK010801_BillingStatusSearchDao {

  /**
   * 料金計算請求状況関連情報検索結果件数取得を取得する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された条件で
   * 【契約】
   * 【契約者】
   * 【契約付加情報】
   * 【契約履歴】
   * 【メーター設置場所契約履歴】
   * 【送受電区分マスタ】
   * 【確定料金実績】
   * 【請求】
   * 【請求ステータスマスタ】
   * 【検針カレンダー】
   * へアクセスし取得件数を返す
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param searchBillingStatusEntityBean
   *          料金計算請求状況検索条件EntityBean
   * @return 取得件数
   * @throws DataAccessException
   *           予期せぬエラーが発生した場合
   */
  int selectBillingStatusInfoCount(
      RK010801_SearchBillingStatusInfoEntityBean searchBillingStatusInfoEntityBean)
      throws DataAccessException;

  /**
   * 料金計算請求状況関連情報取得を取得する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された条件で
   * 【契約】
   * 【契約者】
   * 【契約付加情報】
   * 【契約履歴】
   * 【メーター設置場所契約履歴】
   * 【送受電区分マスタ】
   * 【確定料金実績】
   * 【請求】
   * 【請求ステータスマスタ】
   * 【検針カレンダー】
   * を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param searchBillingStatusEntityBean
   *          料金計算請求状況検索条件EntityBean
   * @return 《料金計算請求状況EntityBean》リスト
   * @throws DataAccessException
   *           予期せぬエラーが発生した場合
   */
  List<RK010801_BillingStatusEntityBean> selectBillingStatusInfo(
      RK010801_SearchBillingStatusInfoEntityBean searchBillingStatusInfoEntityBean)
      throws DataAccessException;

  /**
   * 料金計算請求状況関連情報取得を取得する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 引数で指定された条件で
   * 【契約】
   * 【契約者】
   * 【契約付加情報】
   * 【契約履歴】
   * 【メーター設置場所契約履歴】
   * 【送受電区分マスタ】
   * 【確定料金実績】
   * 【請求】
   * 【請求ステータスマスタ】
   * 【検針カレンダー】
   * を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param searchBillingStatusInfoEntityBean
   *          料金計算請求状況検索条件EntityBean
   * @return 料金計算請求状況ダウンロードファイル出力関連情報Map
   * @throws DataAccessException
   *           予期せぬエラーが発生した場合
   */
  Cursor<RK010801_BillingStatusOutputEntityBean> selectBillingStatusFileOutPutInfo(
      RK010801_SearchBillingStatusInfoEntityBean searchBillingStatusInfoEntityBean)
      throws DataAccessException;

}
