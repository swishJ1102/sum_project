package jp.co.unisys.enability.cis.dao.rk;

import java.util.HashMap;
import java.util.Map;

import jp.co.unisys.enability.cis.entity.rk.RK040101_SearchFixChargeResultInfoEntityBean;
import jp.co.unisys.enability.cis.mapper.rk.RK040101_ChargeResultFileOutputMapper;

import org.apache.ibatis.cursor.Cursor;
import org.springframework.dao.DataAccessException;

/**
 * 料金実績情報ダウンロード に関するデータアクセスをビジネスロジック層に提供するクラス。
 *
 * <pre>
 * <p><b>【仕様詳細】</b></p>
 * 以下のインタフェースを提供する。
 * ・確定料金実績情報の取得
 * ・確定料金実績内訳の取得
 *
 * <p><b>対象テーブル：</b></p>
 * 　・FCR
 * 　・CONTRACT
 * 　・ML
 * 　・PLACE
 * 　・FCR_BREAKDOWN
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK040101_ChargeResultFileOutputDaoImpl implements
    RK040101_ChargeResultFileOutputDao {

  /** 料金メニュー検索マッパー（DI） **/
  private RK040101_ChargeResultFileOutputMapper rk040101ChargeResultFileOutputMapper;

  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.dao.rk.RK040101_ChargeResultFileOutputDao#selectFixChargeResultInfo(jp.co.unisys.enability.cis.entity.rk.RK010401_SearchFixChargeResultInfoEntityBean)
   */
  @Override
  public Integer selectFixChargeResultCount(
      RK040101_SearchFixChargeResultInfoEntityBean searchFixChargeResultInfoEntityBean)
      throws DataAccessException {

    // 条件Mapを作成
    Map<String, Object> exampleMap = new HashMap<String, Object>();

    // 条件Mapに以下の値を設定
    // 条件Map.利用年月（開始）
    // ＝《料金実績情報ダウンロード確定料金実績情報検索EntityBean》.利用年月（開始）
    exampleMap.put("usePeriodStart", searchFixChargeResultInfoEntityBean.getUsePeriodStart());

    // 条件Map.利用年月（終了）
    // ＝《料金実績情報ダウンロード確定料金実績情報検索EntityBean》.利用年月（終了）
    exampleMap.put("usePeriodEnd", searchFixChargeResultInfoEntityBean.getUsePeriodEnd());

    // 条件Map.エリアコード
    // ＝《料金実績情報ダウンロード確定料金実績情報検索EntityBean》.エリア
    exampleMap.put("areaCd", searchFixChargeResultInfoEntityBean.getArea());

    // 条件Map.提供モデルコード
    // ＝《料金実績情報ダウンロード確定料金実績情報検索EntityBean》.提供モデルコード
    exampleMap.put("provideModelCode", searchFixChargeResultInfoEntityBean.getProvideModel());

    // 条件Map.提供モデル企業コード
    // ＝《料金実績情報ダウンロード確定料金実績情報検索EntityBean》.提供モデル企業コード
    exampleMap.put("provideModelCompanyCode", searchFixChargeResultInfoEntityBean.getProvideModelCompany());

    return rk040101ChargeResultFileOutputMapper.selectFixChargeResultCount(exampleMap);
  }

  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.dao.rk.RK040101_ChargeResultFileOutputDao#selectFixChargeResultInfo(jp.co.unisys.enability.cis.entity.rk.RK010401_SearchFixChargeResultInfoEntityBean)
   */
  @Override
  public Cursor<Map<String, Object>> selectFixChargeResultInfo(
      RK040101_SearchFixChargeResultInfoEntityBean searchFixChargeResultInfoEntityBean)
      throws DataAccessException {

    // 条件Mapを作成
    Map<String, Object> exampleMap = new HashMap<String, Object>();

    // 条件Mapに以下の値を設定
    // 条件Map.利用年月（開始）
    // ＝《料金実績情報ダウンロード確定料金実績情報検索EntityBean》.利用年月（開始）
    exampleMap.put("usePeriodStart", searchFixChargeResultInfoEntityBean.getUsePeriodStart());

    // 条件Map.利用年月（終了）
    // ＝《料金実績情報ダウンロード確定料金実績情報検索EntityBean》.利用年月（終了）
    exampleMap.put("usePeriodEnd", searchFixChargeResultInfoEntityBean.getUsePeriodEnd());

    // 条件Map.エリアコード
    // ＝《料金実績情報ダウンロード確定料金実績情報検索EntityBean》.エリア
    exampleMap.put("areaCd", searchFixChargeResultInfoEntityBean.getArea());

    // 条件Map.提供モデルコード
    // ＝《料金実績情報ダウンロード確定料金実績情報検索EntityBean》.提供モデルコード
    exampleMap.put("provideModelCode", searchFixChargeResultInfoEntityBean.getProvideModel());

    // 条件Map.提供モデル企業コード
    // ＝《料金実績情報ダウンロード確定料金実績情報検索EntityBean》.提供モデル企業コード
    exampleMap.put("provideModelCompanyCode", searchFixChargeResultInfoEntityBean.getProvideModelCompany());

    return rk040101ChargeResultFileOutputMapper.selectFixChargeResultInfo(exampleMap);
  }

  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.dao.rk.RK040101_ChargeResultFileOutputDao#selectFixChargeResultBreakdown(jp.co.unisys.enability.cis.entity.rk.RK010401_SearchFixChargeResultInfoEntityBean)
   */
  @Override
  public Cursor<Map<String, Object>> selectFixChargeResultBreakdown(
      RK040101_SearchFixChargeResultInfoEntityBean searchFixChargeResultInfoEntityBean)
      throws DataAccessException {

    // 条件Mapを作成
    Map<String, Object> exampleMap = new HashMap<String, Object>();

    // 条件Mapに以下の値を設定
    // 条件Map.利用年月（開始）
    // ＝《料金実績情報ダウンロード確定料金実績情報検索EntityBean》.利用年月（開始）
    exampleMap.put("usePeriodStart", searchFixChargeResultInfoEntityBean.getUsePeriodStart());

    // 条件Map.利用年月（終了）
    // ＝《料金実績情報ダウンロード確定料金実績情報検索EntityBean》.利用年月（終了）
    exampleMap.put("usePeriodEnd", searchFixChargeResultInfoEntityBean.getUsePeriodEnd());

    // 条件Map.エリアコード
    // ＝《料金実績情報ダウンロード確定料金実績情報検索EntityBean》.エリア
    exampleMap.put("areaCd", searchFixChargeResultInfoEntityBean.getArea());

    // 条件Map.提供モデルコード
    // ＝《料金実績情報ダウンロード確定料金実績情報検索EntityBean》.提供モデルコード
    exampleMap.put("provideModelCode", searchFixChargeResultInfoEntityBean.getProvideModel());

    // 条件Map.提供モデル企業コード
    // ＝《料金実績情報ダウンロード確定料金実績情報検索EntityBean》.提供モデル企業コード
    exampleMap.put("provideModelCompanyCode", searchFixChargeResultInfoEntityBean.getProvideModelCompany());

    return rk040101ChargeResultFileOutputMapper.selectFixChargeResultBreakdown(exampleMap);
  }

  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.dao.rk.RK040101_ChargeResultFileOutputDao#selectRealQuantityHistory(jp.co.unisys.enability.cis.entity.rk.RK010401_SearchFixChargeResultInfoEntityBean)
   */
  @Override
  public Cursor<Map<String, Object>> selectRealQuantityHistory(
      RK040101_SearchFixChargeResultInfoEntityBean searchFixChargeResultInfoEntityBean)
      throws DataAccessException {

    // 条件Mapを作成
    Map<String, Object> exampleMap = new HashMap<String, Object>();

    // 条件Mapに以下の値を設定
    // 条件Map.利用年月（開始）
    // ＝《料金実績情報ダウンロード確定料金実績情報検索EntityBean》.利用年月（開始）
    exampleMap.put("usePeriodStart", searchFixChargeResultInfoEntityBean.getUsePeriodStart());

    // 条件Map.利用年月（終了）
    // ＝《料金実績情報ダウンロード確定料金実績情報検索EntityBean》.利用年月（終了）
    exampleMap.put("usePeriodEnd", searchFixChargeResultInfoEntityBean.getUsePeriodEnd());

    // 条件Map.エリアコード
    // ＝《料金実績情報ダウンロード確定料金実績情報検索EntityBean》.エリア
    exampleMap.put("areaCd", searchFixChargeResultInfoEntityBean.getArea());

    // 条件Map.提供モデルコード
    // ＝《料金実績情報ダウンロード確定料金実績情報検索EntityBean》.提供モデルコード
    exampleMap.put("provideModelCode", searchFixChargeResultInfoEntityBean.getProvideModel());

    // 条件Map.提供モデル企業コード
    // ＝《料金実績情報ダウンロード確定料金実績情報検索EntityBean》.提供モデル企業コード
    exampleMap.put("provideModelCompanyCode", searchFixChargeResultInfoEntityBean.getProvideModelCompany());

    return rk040101ChargeResultFileOutputMapper.selectRealQuantityHistory(exampleMap);
  }

  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.dao.rk.RK040101_ChargeResultFileOutputDao#selectFixIn(jp.co.unisys.enability.cis.entity.rk.RK010401_SearchFixChargeResultInfoEntityBean)
   */
  @Override
  public Cursor<Map<String, Object>> selectFixIn(
      RK040101_SearchFixChargeResultInfoEntityBean searchFixChargeResultInfoEntityBean)
      throws DataAccessException {

    // 条件Mapを作成
    Map<String, Object> exampleMap = new HashMap<String, Object>();

    // 条件Mapに以下の値を設定
    // 条件Map.利用年月（開始）
    // ＝《料金実績情報ダウンロード確定料金実績情報検索EntityBean》.利用年月（開始）
    exampleMap.put("usePeriodStart", searchFixChargeResultInfoEntityBean.getUsePeriodStart());

    // 条件Map.利用年月（終了）
    // ＝《料金実績情報ダウンロード確定料金実績情報検索EntityBean》.利用年月（終了）
    exampleMap.put("usePeriodEnd", searchFixChargeResultInfoEntityBean.getUsePeriodEnd());

    // 条件Map.エリアコード
    // ＝《料金実績情報ダウンロード確定料金実績情報検索EntityBean》.エリア
    exampleMap.put("areaCd", searchFixChargeResultInfoEntityBean.getArea());

    // 条件Map.提供モデルコード
    // ＝《料金実績情報ダウンロード確定料金実績情報検索EntityBean》.提供モデルコード
    exampleMap.put("provideModelCode", searchFixChargeResultInfoEntityBean.getProvideModel());

    // 条件Map.提供モデル企業コード
    // ＝《料金実績情報ダウンロード確定料金実績情報検索EntityBean》.提供モデル企業コード
    exampleMap.put("provideModelCompanyCode", searchFixChargeResultInfoEntityBean.getProvideModelCompany());

    return rk040101ChargeResultFileOutputMapper.selectFixIn(exampleMap);
  }

  /**
   * 料金実績ファイル出力マッパーのsetter（DI）
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金実績ファイル出力マッパーを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param rk040101ChargeResultFileOutputMapper
   *          料金実績ファイル出力マッパー
   */
  public void setRk040101ChargeResultFileOutputMapper(
      RK040101_ChargeResultFileOutputMapper rk040101ChargeResultFileOutputMapper) {
    this.rk040101ChargeResultFileOutputMapper = rk040101ChargeResultFileOutputMapper;
  }

}
