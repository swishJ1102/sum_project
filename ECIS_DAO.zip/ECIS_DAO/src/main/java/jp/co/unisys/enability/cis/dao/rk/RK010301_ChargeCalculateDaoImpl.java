package jp.co.unisys.enability.cis.dao.rk;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;

import jp.co.unisys.enability.cis.entity.rk.RK010301_CalcTargetEntityBean;
import jp.co.unisys.enability.cis.mapper.rk.RK010301_ChargeCalculateMapper;

/**
 * 計算用使用量登録 に関するデータアクセスをサービス層に提供するクラス。
 *
 * <pre>
 * <p><b>【仕様詳細】</b></p>
 * 以下のインタフェースを提供する。
 * ・計算対象データの取得
 *
 * <p><b>対象テーブル：</b></p>
 * 　・FIX_USAGE
 * 　・CONTRACT_HISTORY
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK010301_ChargeCalculateDaoImpl implements
    RK010301_ChargeCalculateDao {

  /** 計算用使用量登録マッパー(DI) **/
  private RK010301_ChargeCalculateMapper mapper;

  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.dao.rk.RK010301_ChargeCalculateDao#selectCalcurateTargetFixUsage(jp.co.unisys.enability.cis.entity.rk.RK010301_CalcTargetEntityBean)
   */
  @Override
  public List<RK010301_CalcTargetEntityBean> selectCalcurateTargetFixUsage(
      RK010301_CalcTargetEntityBean calcTargetEntityBean)
      throws DataAccessException {

    // 条件Mapを作成
    Map<String, Object> exampleMap = new HashMap<String, Object>();

    // 条件Mapに以下の値を設定
    // 条件Map.作成日
    // ＝《計算用使用量登録計算対象EntityBean》.作成日
    exampleMap.put("CreateDate", calcTargetEntityBean.getCreateDate());

    // 条件Map.契約ID
    // ＝《計算用使用量登録計算対象EntityBean》.契約ID
    exampleMap.put("ContractId", calcTargetEntityBean.getContractId());

    // 条件Map.利用年月
    // ＝《計算用使用量登録計算対象EntityBean》.利用年月
    exampleMap.put("UsePeriod", calcTargetEntityBean.getUsePeriod());

    return mapper.selectCalcurateTargetFixUsage(exampleMap);
  }

  /**
   * 計算用使用量登録マッパーのsetter（DI）。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計算用使用量登録マッパーを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param mapper
   *          計算用使用量登録マッパー
   */
  public void setRK010301ChargeCalculateMapper(RK010301_ChargeCalculateMapper chargeCalculateMapper) {
    this.mapper = chargeCalculateMapper;
  }
}
