package jp.co.unisys.enability.cis.dao.rk;

import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.springframework.dao.DataAccessException;

import jp.co.unisys.enability.cis.entity.rk.RK_FixUsageApplyDataEntityBean;
import jp.co.unisys.enability.cis.entity.rk.RK_FixUsageApplyRateMenuTimeSlotEntityBean;
import jp.co.unisys.enability.cis.mapper.rk.RK_FixUsageApplyMapper;

/**
 * 料金メニュー検索に関するデータアクセス層へのインタフェース。
 *
 * <pre>
 * <p><b>【仕様詳細】</b></p>
 * 以下のインタフェースを提供する。
 * ・料金メニューの取得
 * ・付帯メニューの取得
 *
 * <p><b>対象テーブル：</b></p>
 * 　・【エリアマスタ】
 * 　・【付帯メニュー】
 * 　・【付帯メニュー単価】
 * 　・【付帯対象区分マスタ】
 * 　・【付帯種別マスタ】
 * 　・【割引・割増区分マスタ】
 * 　・【売買区分マスタ】
 * 　・【契約種別マスタ】
 * 　・【提供モデル企業マスタ】
 * 　・【提供モデル企業別付帯メニューマスタ】
 * 　・【提供モデル企業別料金メニューマスタ】
 * 　・【料金メニュー】
 * 　・【料金メニュー単価】
 * 　・【料金メニュー単価明細】
 * 　・【電圧区分マスタ】
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public class RK_FixUsageApplyDaoImpl implements RK_FixUsageApplyDao {

  /** 確定使用量情報反映Mapper(DI) */
  private RK_FixUsageApplyMapper fixUsageApplyMapper;

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.dao.rk.RK_FixUsageApplyDao#selectFixUsageApplyData
   * (java.util.Date)
   */
  @Override
  public List<RK_FixUsageApplyDataEntityBean> selectFixUsageApplyData(
      Date executeDate) throws DataAccessException {
    HashMap<String, Object> exampleMap = new HashMap<String, Object>();
    exampleMap.put("executeDate", executeDate);
    return fixUsageApplyMapper.selectFixUsageApplyData(exampleMap);
  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.dao.rk.RK_FixUsageApplyDao#selectRateMenuTimeSlot
   * (java.lang.String)
   */
  @Override
  public List<RK_FixUsageApplyRateMenuTimeSlotEntityBean> selectRateMenuTimeSlot(
      String rateMenuId) throws DataAccessException {
    HashMap<String, Object> exampleMap = new HashMap<String, Object>();
    exampleMap.put("rateMenuId", rateMenuId);
    return fixUsageApplyMapper.selectRateMenuTimeSlot(exampleMap);
  }

  /**
   * 確定使用量情報反映Mapperを設定します。(DI)
   *
   * @param fixUsageApplyMapper
   *          確定使用量情報反映Mapper(DI)
   */
  public void setFixUsageApplyMapper(
      RK_FixUsageApplyMapper fixUsageApplyMapper) {
    this.fixUsageApplyMapper = fixUsageApplyMapper;
  }

}
