package jp.co.unisys.enability.cis.dao.rk;

import java.util.Date;
import java.util.List;

import org.springframework.dao.DataAccessException;

import jp.co.unisys.enability.cis.entity.rk.RK010201_NotLinkedEntityBean;

/**
 * 使用量連携チェック に関するデータアクセス層へのインタフェースをビジネスロジック層に提供するクラス。
 *
 * <pre>
 * <p><b>【仕様詳細】</b></p>
 * 以下のインタフェースをサービス層に提供する。
 * 　・確定使用量メッセージ未達判定
 *
 * <p><b>対象テーブル：</b></p>
 * 　・CONTRACT
 * 　・METER_LOCATION
 * 　・ML_CONTRACT_HISTORY
 * 　・CONTRACT_HISTORY
 * 　・MONTHLY_USAGE_RESULT
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public interface RK010201_UsageLinkageCheckDao {

  /**
   * 確定使用量メッセージが未連携のメータ情報を取得する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 次回検針予定日が使用量未達判定日を過ぎているメータのうち、
   * 確定使用量メッセージが未連携のものを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param executeDate
   *          バッチ実行日
   * @param decisionDate
   *          使用量未達判定日
   * @return メータ情報のリスト
   * @throws DataAccessException
   *           予期せぬエラーが発生した場合
   */
  public List<RK010201_NotLinkedEntityBean> selectNotLinked(Date executeDate,
      Date decisionDate) throws DataAccessException;
}
