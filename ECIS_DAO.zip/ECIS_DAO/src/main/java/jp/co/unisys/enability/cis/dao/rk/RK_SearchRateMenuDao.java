package jp.co.unisys.enability.cis.dao.rk;

import java.util.List;

import org.springframework.dao.DataAccessException;

import jp.co.unisys.enability.cis.entity.rk.RK_SearchRateMenuRateMenuConditionsEntityBean;
import jp.co.unisys.enability.cis.entity.rk.RK_SearchRateMenuSearchRateMenuAreaEntityBean;
import jp.co.unisys.enability.cis.entity.rk.RK_SearchRateMenuSupplementaryMenuConditionsEntityBean;
import jp.co.unisys.enability.cis.entity.rk.RK_SearchRateMenuSupplementaryMenuEntityBean;

/**
 * 料金メニュー検索に関するデータアクセス層へのインタフェース。
 *
 * <pre>
 * <p><b>【仕様詳細】</b></p>
 * 以下のインタフェースを提供する。
 * ・料金メニューの取得
 * ・付帯メニューの取得
 *
 * <p><b>対象テーブル：</b></p>
 * 　・【エリアマスタ】
 * 　・【付帯メニュー】
 * 　・【付帯メニュー単価】
 * 　・【付帯対象区分マスタ】
 * 　・【付帯種別マスタ】
 * 　・【割引・割増区分マスタ】
 * 　・【売買区分マスタ】
 * 　・【契約種別マスタ】
 * 　・【提供モデル企業マスタ】
 * 　・【提供モデル企業別付帯メニューマスタ】
 * 　・【提供モデル企業別料金メニューマスタ】
 * 　・【料金メニュー】
 * 　・【料金メニュー単価】
 * 　・【料金メニュー単価明細】
 * 　・【電圧区分マスタ】
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public interface RK_SearchRateMenuDao {

  /**
   * 料金メニューを取得する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 指定された条件で料金メニューを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param rKSearchRateMenuRateMenuConditionsEntityBean
   *          料金メニュー検索条件ビジネスBeanリスト
   * @return 料金メニューエリアエンティティBeanリスト
   * @throws DataAccessException
   *           予期せぬエラーが発生した場合
   *
   */
  List<RK_SearchRateMenuSearchRateMenuAreaEntityBean> selectRateMenu(
      RK_SearchRateMenuRateMenuConditionsEntityBean rKSearchRateMenuRateMenuConditionsEntityBean)
      throws DataAccessException;

  /**
   * 付帯メニューを取得する。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 指定された条件で付帯メニューを取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param rKSearchRateMenuSupplementaryMenuConditionsEntityBean
   *          付帯メニュー検索条件ビジネスBeanリスト
   * @return 付帯メニューエンティティBeanリスト
   * @throws DataAccessException
   *           予期せぬエラーが発生した場合
   *
   */
  List<RK_SearchRateMenuSupplementaryMenuEntityBean> selectSupplementaryMenu(
      RK_SearchRateMenuSupplementaryMenuConditionsEntityBean rKSearchRateMenuSupplementaryMenuConditionsEntityBean)
      throws DataAccessException;
}
