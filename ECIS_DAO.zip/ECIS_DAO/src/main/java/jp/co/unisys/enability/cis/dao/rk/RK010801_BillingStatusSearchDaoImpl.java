package jp.co.unisys.enability.cis.dao.rk;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.ibatis.cursor.Cursor;
import org.springframework.dao.DataAccessException;

import jp.co.unisys.enability.cis.common.util.constants.ECISConstants;
import jp.co.unisys.enability.cis.common.util.constants.ECISRKConstants;
import jp.co.unisys.enability.cis.entity.rk.RK010801_BillingStatusEntityBean;
import jp.co.unisys.enability.cis.entity.rk.RK010801_BillingStatusOutputEntityBean;
import jp.co.unisys.enability.cis.entity.rk.RK010801_SearchBillingStatusInfoEntityBean;
import jp.co.unisys.enability.cis.mapper.rk.RK010801_BillingStatusSearchMapper;

/**
 * 料金計算請求状況に関する データアクセス層へのインタフェースをビジネスロジック層に提供するクラス
 *
 * <pre>
 * <p><b>【仕様詳細】</b></p>
 * 以下のインタフェースを提供する。
 * ・料金計算請求状況関連情報取得
 *
 * <p><b>対象テーブル：</b></p>
 * 　・CONTRACT
 * 　・CONTRACT_ADD_INFO
 * 　・CONTRACT_HIST
 * 　・ML
 * 　・ML_CONTRACT_HIST
 * 　・TRANSMISSION_CAT_M
 * 　・MR_CALENDAR_M
 * 　・FCR
 * 　・FIX_CHARGE_BL_LINKAGE
 * 　・BL
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */

public class RK010801_BillingStatusSearchDaoImpl implements RK010801_BillingStatusSearchDao {

  /** 料金計算請求状況検索Mapper（DI） **/
  private RK010801_BillingStatusSearchMapper rk010801BillingStatusSearchMapper;

  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.dao.rk.RK010801_BillingStatusSearchDao#selectBillingStatusInfoCount(jp.co.unisys.enability.cis.entity.rk.RK010801_SearchBillingStatusInfoEntityBean)
   */
  @Override
  public int selectBillingStatusInfoCount(RK010801_SearchBillingStatusInfoEntityBean searchBillingStatusInfoEntityBean)
      throws DataAccessException {

    // 条件Mapを作成
    Map<String, Object> exampleMap = new HashMap<String, Object>();

    // 条件Mapに以下の値を設定

    // 条件Map.提供モデルコード
    // ＝《料金計算請求状況検索条件画面Bean》.提供モデルコード
    exampleMap.put("provideModel", searchBillingStatusInfoEntityBean.getProvideModel());
    // 条件Map.提供モデル企業コード
    // ＝《料金計算請求状況検索条件画面Bean》.提供モデル企業コード
    exampleMap.put("provideModelCompany", searchBillingStatusInfoEntityBean.getProvideModelCompany());
    // 条件Map.利用年月
    // ＝《料金計算請求状況検索条件画面Bean》.利用年月
    exampleMap.put("usePeriod", searchBillingStatusInfoEntityBean.getUsePeriod());
    // 条件Map.契約者番号
    // ＝《料金計算請求状況検索条件画面Bean》.契約者番号
    exampleMap.put("contractorNo", searchBillingStatusInfoEntityBean.getContractorNo());
    // 条件Map.契約番号
    // ＝《料金計算請求状況検索条件画面Bean》.契約番号
    exampleMap.put("contractNo", searchBillingStatusInfoEntityBean.getContractNo());
    // 条件Map.お客様番号
    // ＝《料金計算請求状況検索条件画面Bean》.お客様番号
    exampleMap.put("agentContractorNo", searchBillingStatusInfoEntityBean.getAgentContractorNo());
    // 条件Map.供給地点特定番号
    // ＝《料金計算請求状況検索条件画面Bean》.供給地点特定番号
    exampleMap.put("spotNo", searchBillingStatusInfoEntityBean.getSpotNo());
    // 条件Map.契約者名(漢字)
    // ＝《料金計算請求状況検索条件画面Bean》.契約者名(漢字)
    exampleMap.put("contractorName", searchBillingStatusInfoEntityBean.getContractorName());
    // 条件Map.エリア
    // ＝《料金計算請求状況検索条件画面Bean》.エリア
    exampleMap.put("area", searchBillingStatusInfoEntityBean.getArea());
    // 条件Map.送受電区分
    // ＝《料金計算請求状況検索条件画面Bean》.送受電区分
    exampleMap.put("transmissionCategory", searchBillingStatusInfoEntityBean.getTransmissionCategory());

    // 条件Map.料金ステータス
    // ＝《料金計算請求状況検索条件画面Bean》.料金ステータス
    List<String> chargeStatusList = searchBillingStatusInfoEntityBean.getChargeStatusList();
    exampleMap.put("chargeStatusList", chargeStatusList);

    if (Objects.nonNull(chargeStatusList)) {
      // 未計算
      if (chargeStatusList.contains(ECISRKConstants.CHARGE_STATUS_1)) {
        exampleMap.put("chargeStatus1", ECISConstants.FLG_ON);
      }
      // 未確定(警告対応要)
      if (chargeStatusList.contains(ECISRKConstants.CHARGE_STATUS_2)) {
        exampleMap.put("chargeStatus2", ECISConstants.FLG_ON);
      }
      // 未確定(確定待ち)
      if (chargeStatusList.contains(ECISRKConstants.CHARGE_STATUS_3)) {
        exampleMap.put("chargeStatus3", ECISConstants.FLG_ON);
      }
      // 確定
      if (chargeStatusList.contains(ECISRKConstants.CHARGE_STATUS_4)) {
        exampleMap.put("chargeStatus4", ECISConstants.FLG_ON);
      }
    }
    // 条件Map.請求ステータス
    // ＝《料金計算請求状況検索条件画面Bean》.請求ステータス
    exampleMap.put("billingStatus", searchBillingStatusInfoEntityBean.getBillingStatus());

    // 条件Map.年月時点の契約状況
    // ＝《料金計算請求状況検索条件画面Bean》.年月時点の契約状況
    List<String> contractStatusList = searchBillingStatusInfoEntityBean.getContractStatusList();
    exampleMap.put("contractStatusList", contractStatusList);

    if (Objects.nonNull(contractStatusList)) {
      // 開始前
      if (contractStatusList.contains(ECISRKConstants.CONTRACT_STATUS_1)) {
        exampleMap.put("contractStatus1", ECISConstants.FLG_ON);
      }
      // 開始月
      if (contractStatusList.contains(ECISRKConstants.CONTRACT_STATUS_2)) {
        exampleMap.put("contractStatus2", ECISConstants.FLG_ON);
      }
      // 契約中
      if (contractStatusList.contains(ECISRKConstants.CONTRACT_STATUS_3)) {
        exampleMap.put("contractStatus3", ECISConstants.FLG_ON);
      }
      // 終了月
      if (contractStatusList.contains(ECISRKConstants.CONTRACT_STATUS_4)) {
        exampleMap.put("contractStatus4", ECISConstants.FLG_ON);
      }
      // 終了(最終検針なし)
      if (contractStatusList.contains(ECISRKConstants.CONTRACT_STATUS_5)) {
        exampleMap.put("contractStatus5", ECISConstants.FLG_ON);
      }
      // 終了(最終検針あり)
      if (contractStatusList.contains(ECISRKConstants.CONTRACT_STATUS_6)) {
        exampleMap.put("contractStatus6", ECISConstants.FLG_ON);
      }
    }

    return rk010801BillingStatusSearchMapper.selectBillingStatusInfoCount(exampleMap);
  }

  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.dao.rk.RK010801_BillingStatusSearchDao#selectBillingStatusInfo(jp.co.unisys.enability.cis.entity.rk.RK010801_SearchBillingStatusInfoEntityBean)
   */
  @Override
  public List<RK010801_BillingStatusEntityBean> selectBillingStatusInfo(
      RK010801_SearchBillingStatusInfoEntityBean searchBillingStatusInfoEntityBean)
      throws DataAccessException {

    // 条件Mapを作成
    Map<String, Object> exampleMap = new HashMap<String, Object>();

    // 条件Mapに以下の値を設定

    // 条件Map.提供モデルコード
    // ＝《料金計算請求状況検索条件画面Bean》.提供モデルコード
    exampleMap.put("provideModel", searchBillingStatusInfoEntityBean.getProvideModel());
    // 条件Map.提供モデル企業コード
    // ＝《料金計算請求状況検索条件画面Bean》.提供モデル企業コード
    exampleMap.put("provideModelCompany", searchBillingStatusInfoEntityBean.getProvideModelCompany());
    // 条件Map.利用年月
    // ＝《料金計算請求状況検索条件画面Bean》.利用年月
    exampleMap.put("usePeriod", searchBillingStatusInfoEntityBean.getUsePeriod());
    // 条件Map.契約者番号
    // ＝《料金計算請求状況検索条件画面Bean》.契約者番号
    exampleMap.put("contractorNo", searchBillingStatusInfoEntityBean.getContractorNo());
    // 条件Map.契約番号
    // ＝《料金計算請求状況検索条件画面Bean》.契約番号
    exampleMap.put("contractNo", searchBillingStatusInfoEntityBean.getContractNo());
    // 条件Map.お客様番号
    // ＝《料金計算請求状況検索条件画面Bean》.お客様番号
    exampleMap.put("agentContractorNo", searchBillingStatusInfoEntityBean.getAgentContractorNo());
    // 条件Map.供給地点特定番号
    // ＝《料金計算請求状況検索条件画面Bean》.供給地点特定番号
    exampleMap.put("spotNo", searchBillingStatusInfoEntityBean.getSpotNo());
    // 条件Map.契約者名(漢字)
    // ＝《料金計算請求状況検索条件画面Bean》.契約者名(漢字)
    exampleMap.put("contractorName", searchBillingStatusInfoEntityBean.getContractorName());
    // 条件Map.エリア
    // ＝《料金計算請求状況検索条件画面Bean》.エリア
    exampleMap.put("area", searchBillingStatusInfoEntityBean.getArea());
    // 条件Map.送受電区分
    // ＝《料金計算請求状況検索条件画面Bean》.送受電区分
    exampleMap.put("transmissionCategory", searchBillingStatusInfoEntityBean.getTransmissionCategory());

    // 条件Map.料金ステータス
    // ＝《料金計算請求状況検索条件画面Bean》.料金ステータス
    List<String> chargeStatusList = searchBillingStatusInfoEntityBean.getChargeStatusList();
    exampleMap.put("chargeStatusList", chargeStatusList);

    if (Objects.nonNull(chargeStatusList)) {
      // 未計算
      if (chargeStatusList.contains(ECISRKConstants.CHARGE_STATUS_1)) {
        exampleMap.put("chargeStatus1", ECISConstants.FLG_ON);
      }
      // 未確定(警告対応要)
      if (chargeStatusList.contains(ECISRKConstants.CHARGE_STATUS_2)) {
        exampleMap.put("chargeStatus2", ECISConstants.FLG_ON);
      }
      // 未確定(確定待ち)
      if (chargeStatusList.contains(ECISRKConstants.CHARGE_STATUS_3)) {
        exampleMap.put("chargeStatus3", ECISConstants.FLG_ON);
      }
      // 確定
      if (chargeStatusList.contains(ECISRKConstants.CHARGE_STATUS_4)) {
        exampleMap.put("chargeStatus4", ECISConstants.FLG_ON);
      }
    }
    // 条件Map.請求ステータス
    // ＝《料金計算請求状況検索条件画面Bean》.請求ステータス
    exampleMap.put("billingStatus", searchBillingStatusInfoEntityBean.getBillingStatus());

    // 条件Map.年月時点の契約状況
    // ＝《料金計算請求状況検索条件画面Bean》.年月時点の契約状況
    List<String> contractStatusList = searchBillingStatusInfoEntityBean.getContractStatusList();
    exampleMap.put("contractStatusList", contractStatusList);

    if (Objects.nonNull(contractStatusList)) {
      // 開始前
      if (contractStatusList.contains(ECISRKConstants.CONTRACT_STATUS_1)) {
        exampleMap.put("contractStatus1", ECISConstants.FLG_ON);
      }
      // 開始月
      if (contractStatusList.contains(ECISRKConstants.CONTRACT_STATUS_2)) {
        exampleMap.put("contractStatus2", ECISConstants.FLG_ON);
      }
      // 契約中
      if (contractStatusList.contains(ECISRKConstants.CONTRACT_STATUS_3)) {
        exampleMap.put("contractStatus3", ECISConstants.FLG_ON);
      }
      // 終了月
      if (contractStatusList.contains(ECISRKConstants.CONTRACT_STATUS_4)) {
        exampleMap.put("contractStatus4", ECISConstants.FLG_ON);
      }
      // 終了(最終検針なし)
      if (contractStatusList.contains(ECISRKConstants.CONTRACT_STATUS_5)) {
        exampleMap.put("contractStatus5", ECISConstants.FLG_ON);
      }
      // 終了(最終検針あり)
      if (contractStatusList.contains(ECISRKConstants.CONTRACT_STATUS_6)) {
        exampleMap.put("contractStatus6", ECISConstants.FLG_ON);
      }
    }

    // 条件Map.最大取得件数
    // ＝《料金計算請求状況検索条件画面Bean》.最大取得件数
    exampleMap.put("maxSearchCount", searchBillingStatusInfoEntityBean.getMaxSearchCount());

    return rk010801BillingStatusSearchMapper.selectBillingStatusInfo(exampleMap);
  }

  /* (非 Javadoc)
   * @see jp.co.unisys.enability.cis.dao.sr.RK010801_BillingStatusInfoFileOutputDao#selectBillingStatusInfo(jp.co.unisys.enability.cis.entity.rk.RK010801_SearchBillingStatusInfoEntityBean)
   */
  @Override
  public Cursor<RK010801_BillingStatusOutputEntityBean> selectBillingStatusFileOutPutInfo(
      RK010801_SearchBillingStatusInfoEntityBean searchBillingStatusInfoEntityBean)
      throws DataAccessException {

    // 条件Mapを作成
    Map<String, Object> exampleMap = new HashMap<String, Object>();

    // 条件Mapに以下の値を設定

    // 条件Map.提供モデルコード
    // ＝《料金計算請求状況検索条件画面Bean》.提供モデルコード
    exampleMap.put("provideModel", searchBillingStatusInfoEntityBean.getProvideModel());
    // 条件Map.提供モデル企業コード
    // ＝《料金計算請求状況検索条件画面Bean》.提供モデル企業コード
    exampleMap.put("provideModelCompany", searchBillingStatusInfoEntityBean.getProvideModelCompany());
    // 条件Map.利用年月
    // ＝《料金計算請求状況検索条件画面Bean》.利用年月
    exampleMap.put("usePeriod", searchBillingStatusInfoEntityBean.getUsePeriod());
    // 条件Map.契約者番号
    // ＝《料金計算請求状況検索条件画面Bean》.契約者番号
    exampleMap.put("contractorNo", searchBillingStatusInfoEntityBean.getContractorNo());
    // 条件Map.契約番号
    // ＝《料金計算請求状況検索条件画面Bean》.契約番号
    exampleMap.put("contractNo", searchBillingStatusInfoEntityBean.getContractNo());
    // 条件Map.お客様番号
    // ＝《料金計算請求状況検索条件画面Bean》.お客様番号
    exampleMap.put("agentContractorNo", searchBillingStatusInfoEntityBean.getAgentContractorNo());
    // 条件Map.供給地点特定番号
    // ＝《料金計算請求状況検索条件画面Bean》.供給地点特定番号
    exampleMap.put("spotNo", searchBillingStatusInfoEntityBean.getSpotNo());
    // 条件Map.契約者名(漢字)
    // ＝《料金計算請求状況検索条件画面Bean》.契約者名(漢字)
    exampleMap.put("contractorName", searchBillingStatusInfoEntityBean.getContractorName());
    // 条件Map.エリア
    // ＝《料金計算請求状況検索条件画面Bean》.エリア
    exampleMap.put("area", searchBillingStatusInfoEntityBean.getArea());
    // 条件Map.送受電区分
    // ＝《料金計算請求状況検索条件画面Bean》.送受電区分
    exampleMap.put("transmissionCategory", searchBillingStatusInfoEntityBean.getTransmissionCategory());

    // 条件Map.料金ステータス
    // ＝《料金計算請求状況検索条件画面Bean》.料金ステータス
    List<String> chargeStatusList = searchBillingStatusInfoEntityBean.getChargeStatusList();
    exampleMap.put("chargeStatusList", chargeStatusList);

    if (Objects.nonNull(chargeStatusList)) {
      // 未計算
      if (chargeStatusList.contains(ECISRKConstants.CHARGE_STATUS_1)) {
        exampleMap.put("chargeStatus1", ECISConstants.FLG_ON);
      }
      // 未確定(警告対応要)
      if (chargeStatusList.contains(ECISRKConstants.CHARGE_STATUS_2)) {
        exampleMap.put("chargeStatus2", ECISConstants.FLG_ON);
      }
      // 未確定(確定待ち)
      if (chargeStatusList.contains(ECISRKConstants.CHARGE_STATUS_3)) {
        exampleMap.put("chargeStatus3", ECISConstants.FLG_ON);
      }
      // 確定
      if (chargeStatusList.contains(ECISRKConstants.CHARGE_STATUS_4)) {
        exampleMap.put("chargeStatus4", ECISConstants.FLG_ON);
      }
    }
    // 条件Map.請求ステータス
    // ＝《料金計算請求状況検索条件画面Bean》.請求ステータス
    exampleMap.put("billingStatus", searchBillingStatusInfoEntityBean.getBillingStatus());

    // 条件Map.年月時点の契約状況
    // ＝《料金計算請求状況検索条件画面Bean》.年月時点の契約状況
    List<String> contractStatusList = searchBillingStatusInfoEntityBean.getContractStatusList();
    exampleMap.put("contractStatusList", contractStatusList);

    if (Objects.nonNull(contractStatusList)) {
      // 開始前
      if (contractStatusList.contains(ECISRKConstants.CONTRACT_STATUS_1)) {
        exampleMap.put("contractStatus1", ECISConstants.FLG_ON);
      }
      // 開始月
      if (contractStatusList.contains(ECISRKConstants.CONTRACT_STATUS_2)) {
        exampleMap.put("contractStatus2", ECISConstants.FLG_ON);
      }
      // 契約中
      if (contractStatusList.contains(ECISRKConstants.CONTRACT_STATUS_3)) {
        exampleMap.put("contractStatus3", ECISConstants.FLG_ON);
      }
      // 終了月
      if (contractStatusList.contains(ECISRKConstants.CONTRACT_STATUS_4)) {
        exampleMap.put("contractStatus4", ECISConstants.FLG_ON);
      }
      // 終了(最終検針なし)
      if (contractStatusList.contains(ECISRKConstants.CONTRACT_STATUS_5)) {
        exampleMap.put("contractStatus5", ECISConstants.FLG_ON);
      }
      // 終了(最終検針あり)
      if (contractStatusList.contains(ECISRKConstants.CONTRACT_STATUS_6)) {
        exampleMap.put("contractStatus6", ECISConstants.FLG_ON);
      }
    }

    return rk010801BillingStatusSearchMapper.selectBillingStatusFileOutPutInfo(exampleMap);
  }

  /**
   * *料金計算請求状況取得Mapperのsetter（DI）
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * *料金計算請求状況取得Mapperを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param rk010801BillingStatusSearchMapper
   *          *料金計算請求状況取得Mapper
   */
  public void setRk010801BillingStatusSearchMapper(
      RK010801_BillingStatusSearchMapper rk010801BillingStatusSearchMapper) {
    this.rk010801BillingStatusSearchMapper = rk010801BillingStatusSearchMapper;
  }

}
