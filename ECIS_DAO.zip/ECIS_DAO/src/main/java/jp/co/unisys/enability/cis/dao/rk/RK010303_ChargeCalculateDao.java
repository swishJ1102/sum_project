package jp.co.unisys.enability.cis.dao.rk;

import java.util.List;

import org.springframework.dao.DataAccessException;

import jp.co.unisys.enability.cis.entity.rk.RK010303_FixChargeResultGetCoveredInfoEntityBean;
import jp.co.unisys.enability.cis.entity.rk.RK010303_FixChargeResultRegisterCoveredInfoEntityBean;
import jp.co.unisys.enability.cis.entity.rk.RK010303_FixChargeResultRegisterInfoEntityBean;

/**
 * 確定料金実績登録 に関するデータアクセス層へのインタフェースをサービス層に提供するクラス。
 * 
 * <pre>
 * <p><b>【仕様詳細】</b></p>
 * 以下のインタフェースをサービス層に提供する。
 * ・確定料金実績登録の処理対象となるデータの取得
 * ・確定料金実績登録に必要な情報の取得
 *
 * 対象テーブル：
 * 　・CALCULATION_RESULT
 * 　・CALCULATING_USAGE
 * 　・CALCULATING_FIX_IN
 * 　・CALCULATING_USAGE
 * 　・CALCULATION_RESULT
 * 　・CONTRACT
 * 　・CONTRACTOR
 * 　・CONTRACT_HIST
 * 　・RM
 * 　・ML
 * 　・FU
 * 　・AREA_M
 * 　・CCL_M
 * 　・DEAL_CLASS_M
 * 　・CR
 * 　・CONTRACT_END_REASON_M
 * </pre>
 * 
 * @author "Nihon Unisys, Ltd."
 */
public interface RK010303_ChargeCalculateDao {

  /**
   * 確定料金実績登録の処理対象となるデータ情報を取得する。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 計算結果、計算用使用量、計算用確定指示数を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param fixChargeResultGetCoveredInfoEntityBean
   *          確定料金実績取得対象情報Bean
   * @return 確定料金実績登録の処理対象データ
   * @throws DataAccessException
   *           予期せぬエラーが発生した場合
   */
  List<RK010303_FixChargeResultGetCoveredInfoEntityBean> selectConfirmChargeDataInfo(
      RK010303_FixChargeResultGetCoveredInfoEntityBean fixChargeResultGetCoveredInfoEntityBean)
      throws DataAccessException;

  /**
   * 確定料金実績登録に必要な情報を取得する。
   * 
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 指定された条件で確定料金実績登録に必要な情報を取得する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param fixChargeResultRegisterCoveredInfoEntityBean
   *          確定料金実績登録対象情報EntityBean
   * @return 確定料金実績登録に必要な情報
   * @throws DataAccessException
   *           予期せぬエラーが発生した場合
   */
  RK010303_FixChargeResultRegisterInfoEntityBean selectFixChargeResultRegister(
      RK010303_FixChargeResultRegisterCoveredInfoEntityBean fixChargeResultRegisterCoveredInfoEntityBean)
      throws DataAccessException;

}
