package jp.co.unisys.enability.cis.dao.rk;

import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.springframework.dao.DataAccessException;

import jp.co.unisys.enability.cis.entity.rk.RK_UsageLinkageCheckCheckDataEntityBean;
import jp.co.unisys.enability.cis.entity.rk.RK_UsageLinkageCheckEndFixUsageNotLinkedEntityBean;
import jp.co.unisys.enability.cis.entity.rk.RK_UsageLinkageCheckLatestContractEntityBean;
import jp.co.unisys.enability.cis.entity.rk.RK_UsageLinkageCheckTermDecisionEntityBean;
import jp.co.unisys.enability.cis.mapper.rk.RK_UsageLinkageCheckMapper;

/**
 * 使用量連携チェックに関するデータアクセス。
 *
 * <pre>
 * <p><b>【仕様詳細】</b></p>
 * 以下のインタフェースをサービス層に提供する。
 * 　・連携チェック対象データの取得
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 * @see jp.co.unisys.enability.cis.dao.rk.RK_UsageLinkageCheckDao
 */
public class RK_UsageLinkageCheckDaoImpl implements RK_UsageLinkageCheckDao {

  /** 使用量連携チェックMapper(DI) */
  private RK_UsageLinkageCheckMapper rkUsageLinkageCheckMapper;

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.dao.rk.RK_UsageLinkageCheckDao#selectCheckData
   * (java.lang.String)
   */
  @Override
  public List<RK_UsageLinkageCheckCheckDataEntityBean> selectCheckData(
      Date executeDate) throws DataAccessException {

    HashMap<String, Object> exampleMap = new HashMap<String, Object>();
    exampleMap.put("executeDate", executeDate);

    return rkUsageLinkageCheckMapper.selectCheckData(exampleMap);
  }

  /*
   * (非 Javadoc)
   *
   * @see
   * jp.co.unisys.enability.cis.dao.rk.RK_UsageLinkageCheckDao#selectTermDecision
   * (java.lang.String, java.lang.String, java.lang.String, java.lang.String)
   */
  @Override
  public List<RK_UsageLinkageCheckTermDecisionEntityBean> selectTermDecision(
      String spotNo, String fixUsageFileName, String areaCode, String abolitionFlag)
      throws DataAccessException {

    HashMap<String, Object> exampleMap = new HashMap<String, Object>();
    exampleMap.put("spotNo", spotNo);
    exampleMap.put("fixUsageFileName", fixUsageFileName);
    exampleMap.put("areaCode", areaCode);
    exampleMap.put("abolitionFlag", abolitionFlag);

    return rkUsageLinkageCheckMapper.selectTermDecision(exampleMap);
  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.dao.rk.RK_UsageLinkageCheckDao#
   * selectLatestContractNo(java.lang.String)
   */
  @Override
  public RK_UsageLinkageCheckLatestContractEntityBean selectLatestContract(
      String spotNo) throws DataAccessException {

    HashMap<String, Object> exampleMap = new HashMap<String, Object>();
    exampleMap.put("spotNo", spotNo);

    return rkUsageLinkageCheckMapper.selectLatestContractNo(exampleMap);
  }

  /*
   * (非 Javadoc)
   *
   * @see jp.co.unisys.enability.cis.dao.rk.RK_UsageLinkageCheckDao#
   * selectLatestContractNo(java.lang.String)
   */
  @Override
  public List<RK_UsageLinkageCheckEndFixUsageNotLinkedEntityBean> selectEndFixUsageNotLinked(
      String spotNo, Date decisionDate) throws DataAccessException {

    HashMap<String, Object> exampleMap = new HashMap<String, Object>();
    exampleMap.put("spotNo", spotNo);
    exampleMap.put("decisionDate", decisionDate);

    return rkUsageLinkageCheckMapper.selectEndFixUsageNotLinked(exampleMap);
  }

  /*
   * (非 Javadoc)
   * @see jp.co.unisys.enability.cis.dao.rk.RK_UsageLinkageCheckDao#
   * selectLastTimeUsageEd(java.lang.String, java.util.Date)
   */
  @Override
  public Date selectLastTimeUsageEd(String contractNo, Date mrDate) {

    HashMap<String, Object> exampleMap = new HashMap<>();
    exampleMap.put("contractNo", contractNo);
    exampleMap.put("mrDate", mrDate);

    return rkUsageLinkageCheckMapper.selectLastTimeUsageEd(exampleMap);
  }

  /**
   * 使用量連携チェックMapperを設定します。(DI)
   *
   * @param rkUsageLinkageCheckMapper
   *          使用量連携チェックMapper
   */
  public void setRkUsageLinkageCheckMapper(
      RK_UsageLinkageCheckMapper rkUsageLinkageCheckMapper) {
    this.rkUsageLinkageCheckMapper = rkUsageLinkageCheckMapper;
  }

}
