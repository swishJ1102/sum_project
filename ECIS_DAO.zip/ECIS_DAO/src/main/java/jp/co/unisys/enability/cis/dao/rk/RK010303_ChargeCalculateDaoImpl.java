package jp.co.unisys.enability.cis.dao.rk;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;

import jp.co.unisys.enability.cis.entity.rk.RK010303_FixChargeResultGetCoveredInfoEntityBean;
import jp.co.unisys.enability.cis.entity.rk.RK010303_FixChargeResultRegisterCoveredInfoEntityBean;
import jp.co.unisys.enability.cis.entity.rk.RK010303_FixChargeResultRegisterInfoEntityBean;
import jp.co.unisys.enability.cis.mapper.rk.RK010303_ChargeCalculateMapper;

/**
 * 確定料金実績登録 に関するデータアクセスをサービス層に提供するクラス。
 * 
 * <pre>
 * <p><b>【仕様詳細】</b></p>
 * 以下のインタフェースをサービス層に提供する。
 * ・確定料金実績登録の処理対象となるデータの取得
 * ・確定料金実績登録に必要な情報の取得
 *
 * 対象テーブル：
 * 　・CALCULATION_RESULT
 * 　・CALCULATING_USAGE
 * 　・CALCULATING_FIX_IN
 * 　・CALCULATING_USAGE
 * 　・CALCULATION_RESULT
 * 　・CONTRACT
 * 　・CONTRACTOR
 * 　・CONTRACT_HIST
 * 　・RM
 * 　・ML
 * 　・FU
 * 　・AREA_M
 * 　・CCL_M
 * 　・DEAL_CLASS_M
 * 　・CR
 * 　・CONTRACT_END_REASON_M
 * </pre>
 * 
 * @author "Nihon Unisys, Ltd."
 */
public class RK010303_ChargeCalculateDaoImpl implements
    RK010303_ChargeCalculateDao {

  /**
   * 確定料金実績登録Mapper（DI）
   */
  private RK010303_ChargeCalculateMapper rk010303ChargeCalculateMapper;

  /*
   * (非 Javadoc)
   * @see jp.co.unisys.enability.cis.dao.rk.RK010303_ChargeCalculateDao#selectConfirmChargeDataInfo(jp.co.unisys.enability.cis.entity.rk.RK010303_FixChargeResultGetCoveredInfoEntityBean)
   */
  @Override
  public List<RK010303_FixChargeResultGetCoveredInfoEntityBean> selectConfirmChargeDataInfo(
      RK010303_FixChargeResultGetCoveredInfoEntityBean fixChargeResultGetCoveredInfoEntityBean)
      throws DataAccessException {
    // 条件Map生成
    Map<String, Object> exampleMap = new HashMap<String, Object>();
    exampleMap.put("contractId", fixChargeResultGetCoveredInfoEntityBean.getContractID());
    exampleMap.put("usePeriod", fixChargeResultGetCoveredInfoEntityBean.getUsePeriod());
    // 確定料金実績登録処理対象データ取得
    return rk010303ChargeCalculateMapper.selectConfirmChargeDataInfo(exampleMap);
  }

  /*
   * (非 Javadoc)
   * @see jp.co.unisys.enability.cis.dao.rk.RK010303_ChargeCalculateDao#selectFixChargeResultRegister(jp.co.unisys.enability.cis.entity.rk.RK010303_FixChargeResultRegisterCoveredInfoEntityBean)
   */
  @Override
  public RK010303_FixChargeResultRegisterInfoEntityBean selectFixChargeResultRegister(
      RK010303_FixChargeResultRegisterCoveredInfoEntityBean fixChargeResultRegisterInfoBean)
      throws DataAccessException {
    // 条件Map生成
    Map<String, Object> exampleMap = new HashMap<String, Object>();
    exampleMap.put("contractId", fixChargeResultRegisterInfoBean.getContractID());
    exampleMap.put("usePeriod", fixChargeResultRegisterInfoBean.getUsePeriod());
    // 確定料金実績登録に必要なデータ取得
    return rk010303ChargeCalculateMapper.selectFixChargeResultRegister(exampleMap);
  }

  /**
   * 確定料金実績登録Mapperのsetter（DI）。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 確定料金実績登録Mapperを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param rk010303ChargeCalculateMapper
   *          確定料金実績登録Mapper
   */
  public void setRk010303ChargeCalculateMapper(RK010303_ChargeCalculateMapper rk010303ChargeCalculateMapper) {
    this.rk010303ChargeCalculateMapper = rk010303ChargeCalculateMapper;
  }

}
