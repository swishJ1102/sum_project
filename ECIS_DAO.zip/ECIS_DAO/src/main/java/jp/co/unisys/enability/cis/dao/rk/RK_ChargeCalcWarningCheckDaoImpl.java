package jp.co.unisys.enability.cis.dao.rk;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.dao.DataAccessException;

import jp.co.unisys.enability.cis.entity.common.AcInformation;
import jp.co.unisys.enability.cis.entity.common.CalculatingUsage;
import jp.co.unisys.enability.cis.entity.common.Rm;
import jp.co.unisys.enability.cis.mapper.rk.RK_ChargeCalcWarningCheckMapper;

/**
 * 料金計算警告チェック に関するデータアクセスをビジネスロジック層に提供するクラス。
 * 
 * <pre>
 * <p><b>【仕様詳細】</b></p>
 * 以下のインタフェースをビジネス層に提供する。
 * ・契約種別情報取得処理
 * ・力率情報取得処理
 * ・口座クレカ情報取得処理
 * 対象テーブル：
 * 　・RM
 * 　・CALCULATION_RESULT
 * 　・CALCULATING_USAGE
 * 　・CONTRACT
 * 　・PAYMENT
 * 　・PAYMENT_HIST
 * 　・AC_INFORMATION
 * </pre>
 * 
 * @author "Nihon Unisys, Ltd."
 */
public class RK_ChargeCalcWarningCheckDaoImpl implements
    RK_ChargeCalcWarningCheckDao {

  /**
   * 料金計算警告チェックMapper(DI)
   */
  private RK_ChargeCalcWarningCheckMapper rkChargeCalcWarningCheckMapper;

  /*
   * (非 Javadoc)
   * @see jp.co.unisys.enability.cis.dao.rk.RK_ChargeCalcWarningCheckDao#selectContractClassInfo(java.lang.Integer, java.lang.String)
   */
  @Override
  public Rm selectContractClassInfo(Integer contractID, String usePeriod)
      throws DataAccessException {
    // 条件設定
    Map<String, Object> exampleMap = new HashMap<String, Object>();
    exampleMap.put("contractId", contractID);
    exampleMap.put("usePeriod", usePeriod);
    // 契約種別情報取得
    return rkChargeCalcWarningCheckMapper.selectContractClassInfo(exampleMap);
  }

  /*
   * (非 Javadoc)
   * @see jp.co.unisys.enability.cis.dao.rk.RK_ChargeCalcWarningCheckDao#selectPowerFactorInfo(java.lang.Integer, java.lang.String)
   */
  @Override
  public CalculatingUsage selectPowerFactorInfo(Integer contractID,
      String usePeriod) throws DataAccessException {
    // 条件設定
    Map<String, Object> exampleMap = new HashMap<String, Object>();
    exampleMap.put("contractId", contractID);
    exampleMap.put("usePeriod", usePeriod);
    // 力率情報取得
    return rkChargeCalcWarningCheckMapper.selectPowerFactorInfo(exampleMap);
  }

  /*
   * (非 Javadoc)
   * @see jp.co.unisys.enability.cis.dao.rk.RK_ChargeCalcWarningCheckDao#selectAccountCreditCardInfo(java.lang.Integer, java.util.Date)
   */
  @Override
  public AcInformation selectAccountCreditCardInfo(Integer contractID, Date checkBaseDate)
      throws DataAccessException {
    // 条件設定
    Map<String, Object> exampleMap = new HashMap<String, Object>();
    exampleMap.put("contractId", contractID);
    exampleMap.put("checkBaseDate", checkBaseDate);
    // 口座クレカ情報取得
    return rkChargeCalcWarningCheckMapper.selectAccountCreditCardInfo(exampleMap);
  }

  /**
   * 料金計算警告チェックMapperのsetter（DI）
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 料金計算警告チェックMapperを設定します。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param rkChargeCalcWarningCheckMapper
   *          料金計算警告チェックMapper
   */
  public void setRkChargeCalcWarningCheckMapper(RK_ChargeCalcWarningCheckMapper rkChargeCalcWarningCheckMapper) {
    this.rkChargeCalcWarningCheckMapper = rkChargeCalcWarningCheckMapper;
  }

}
