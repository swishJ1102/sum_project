package jp.co.unisys.enability.cis.dao.rk;

import java.sql.Timestamp;
import java.util.Date;

import org.springframework.dao.DataAccessException;

/**
 * 確定使用量前処理に関するデータアクセス層へのインタフェースをビジネスロジック層に提供するクラス。
 *
 * <pre>
 * <p><b>【仕様詳細】</b></p>
 * 以下のインタフェースをサービス層に提供する。
 * 　・確定日制の確定使用量（確定使用量ファイル名の検針日に確定日が設定される）の場合に、検針日の補正を行う。
 * 　・前月分の確定使用量と検針日が同日または過去、かつ算定期間が異なる確定使用量が連携される場合に、検針日の補正を行う。
 *
 * <p><b>対象テーブル：</b></p>
 * 　・mur
 * </pre>
 *
 * @author "Nihon Unisys, Ltd."
 */
public interface RK_FixChargePreprocessDao {

  /**
   * 確定日制の確定使用量の場合に、検針日の補正を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   * 関西エリアの【月次実績】.検針日を、それに紐づく【需要実績】.確定使用量対象日の最大値＋１日に更新する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param executeDate
   *          バッチ実行日
   * @return 更新した【月次実績】の件数
   * @throws DataAccessException
   *           DBエラーが発生した場合
   */
  public int updateMeterReadingDateForKansai(Date executeDate,
      Timestamp updateTime, String updateModuleCode)
      throws DataAccessException;

  /**
   * 前月分の確定使用量と検針日が同日または過去、かつ算定期間が異なる確定使用量が連携される場合に、検針日の補正を行う。
   *
   * <pre>
   * <p><b>【仕様詳細】</b></p>
   *  前月分の確定使用量と検針日が同日または過去、かつ算定期間が異なる確定使用量が連携される場合に、
   * 【月次実績】.検針日を前月分の【確定使用量】.月次実績検針日の最小値＋１日で更新する。
   * </pre>
   *
   * @author "Nihon Unisys, Ltd."
   * @param executeDate
   *          バッチ実行日
   * @param updateMeterReadingDateArea
   *          検針日補正エリア
   * @param updateTime
   *          更新日時
   * @param updateModuleCode
   *          更新モジュールコード
   * @return 更新した【月次実績】の件数
   * @throws DataAccessException
   *           DBエラーが発生した場合
   */
  public int updateMeterReadingDate(Date executeDate, String[] updateMeterReadingDateArea,
      Timestamp updateTime, String updateModuleCode)
      throws DataAccessException;
}
